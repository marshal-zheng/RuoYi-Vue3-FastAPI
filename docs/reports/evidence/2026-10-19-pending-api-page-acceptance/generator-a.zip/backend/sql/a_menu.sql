-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('验收临时 mvet0wd2', '3', '1', 'a', 'system/a/index', 1, 0, 'C', '0', '0', 'system:a:list', '#', 'admin', sysdate(), '', null, '验收临时 mvet0wd2菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('验收临时 mvet0wd2查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'system:a:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('验收临时 mvet0wd2新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'system:a:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('验收临时 mvet0wd2修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'system:a:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('验收临时 mvet0wd2删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'system:a:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('验收临时 mvet0wd2导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'system:a:export',       '#', 'admin', sysdate(), '', null, '');
