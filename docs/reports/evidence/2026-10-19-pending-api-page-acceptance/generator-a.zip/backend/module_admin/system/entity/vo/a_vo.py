from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel
from pydantic_validation_decorator import NotBlank
from typing import Optional
from module_admin.annotation.pydantic_annotation import as_query




class AModel(BaseModel):
    """
    验收临时 mvet0wd2表对应pydantic模型
    """
    model_config = ConfigDict(alias_generator=to_camel, from_attributes=True)

    item_id: Optional[int] = Field(default=None, description='编号')
    item_name: Optional[str] = Field(default=None, description='名称')
    status: Optional[str] = Field(default=None, description='状态')
    qa_note: Optional[str] = Field(default=None, description='补充说明')

    @NotBlank(field_name='item_name', message='名称不能为空')
    def get_item_name(self):
        return self.item_name


    def validate_fields(self):
        self.get_item_name()




class AQueryModel(AModel):
    """
    验收临时 mvet0wd2不分页查询模型
    """
    pass


@as_query
class APageQueryModel(AQueryModel):
    """
    验收临时 mvet0wd2分页查询模型
    """

    page: int = Field(default=1, description='当前页码')
    page_size: int = Field(default=10, description='每页记录数')


class DeleteAModel(BaseModel):
    """
    删除验收临时 mvet0wd2模型
    """

    model_config = ConfigDict(alias_generator=to_camel)

    item_ids: str = Field(description='需要删除的编号')
