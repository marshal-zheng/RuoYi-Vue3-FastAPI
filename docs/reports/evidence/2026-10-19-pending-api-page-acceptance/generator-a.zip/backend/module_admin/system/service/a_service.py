from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from config.constant import CommonConstant
from exceptions.exception import ServiceException
from module_admin.system.repository.a_repository import ARepository
from module_admin.system.entity.vo.a_vo import DeleteAModel, AModel, APageQueryModel
from utils.common_util import CamelCaseUtil
from utils.excel_util import ExcelUtil


class AService:
    """
    验收临时 mvet0wd2模块服务层
    """

    @classmethod
    async def get_a_list_services(
        cls, query_db: AsyncSession, query_object: APageQueryModel, is_page: bool = False
    ):
        """
        获取验收临时 mvet0wd2列表信息service

        :param query_db: orm对象
        :param query_object: 查询参数对象
        :param is_page: 是否开启分页
        :return: 验收临时 mvet0wd2列表信息对象
        """
        a_repo = ARepository(query_db)
        a_list_result = await a_repo.get_a_list(query_object, is_page)

        return a_list_result


    @classmethod
    async def add_a_services(cls, query_db: AsyncSession, page_object: AModel):
        """
        新增验收临时 mvet0wd2信息service

        :param query_db: orm对象
        :param page_object: 新增验收临时 mvet0wd2对象
        :return: 新增验收临时 mvet0wd2校验结果
        """
        a_repo = ARepository(query_db)
        try:
            add_a = await a_repo.add_a(page_object)
            created_item_id = add_a.item_id
            await query_db.commit()
            return await cls.a_detail_services(query_db, created_item_id)
        except Exception as e:
            await query_db.rollback()
            raise e

    @classmethod
    async def edit_a_services(cls, query_db: AsyncSession, page_object: AModel):
        """
        编辑验收临时 mvet0wd2信息service

        :param query_db: orm对象
        :param page_object: 编辑验收临时 mvet0wd2对象
        :return: 编辑验收临时 mvet0wd2校验结果
        """
        edit_a = page_object.model_dump(exclude_unset=True, exclude={})
        a_info = await cls.a_detail_services(query_db, page_object.item_id)
        if a_info.item_id:
            a_repo = ARepository(query_db)
            try:
                await a_repo.edit_a(edit_a)
                await query_db.commit()
                return await cls.a_detail_services(query_db, page_object.item_id)
            except Exception as e:
                await query_db.rollback()
                raise e
        else:
            raise ServiceException(message='验收临时 mvet0wd2不存在')

    @classmethod
    async def delete_a_services(cls, query_db: AsyncSession, page_object: DeleteAModel):
        """
        删除验收临时 mvet0wd2信息service

        :param query_db: orm对象
        :param page_object: 删除验收临时 mvet0wd2对象
        :return: 删除验收临时 mvet0wd2校验结果
        """
        if page_object.item_ids:
            item_id_list = page_object.item_ids.split(',')
            a_repo = ARepository(query_db)
            try:
                for item_id in item_id_list:
                    await a_repo.delete_a(
                        AModel(itemId=item_id)
                    )
                await query_db.commit()
                return None
            except Exception as e:
                await query_db.rollback()
                raise e
        else:
            raise ServiceException(message='传入编号为空')

    @classmethod
    async def a_detail_services(cls, query_db: AsyncSession, item_id: int):
        """
        获取验收临时 mvet0wd2详细信息service

        :param query_db: orm对象
        :param item_id: 编号
        :return: 编号对应的信息
        """
        a_repo = ARepository(query_db)
        a = await a_repo.get_a_detail_by_id(item_id)
        if a:
            result = AModel(**CamelCaseUtil.transform_result(a))
        else:
            result = AModel(**dict())

        return result

    @staticmethod
    async def export_a_list_services(a_list: List):
        """
        导出验收临时 mvet0wd2信息service

        :param a_list: 验收临时 mvet0wd2信息列表
        :return: 验收临时 mvet0wd2信息对应excel的二进制数据
        """
        # 创建一个映射字典，将英文键映射到中文键
        mapping_dict = {
            'itemId': '编号',
            'itemName': '名称',
            'status': '状态',
            'qaNote': '补充说明',
        }
        binary_data = ExcelUtil.export_list2excel(a_list, mapping_dict)

        return binary_data
