from sqlalchemy import String, CHAR, Column, BigInteger
from config.database import Base


class ZxqaMvet0wd2A(Base):
    """
    验收临时 mvet0wd2表
    """

    __tablename__ = 'zxqa_mvet0wd2_a'

    item_id = Column(BigInteger, primary_key=True, autoincrement=True, nullable=False, comment='编号')
    item_name = Column(String(80), nullable=False, comment='名称')
    status = Column(CHAR(1), nullable=True, comment='状态')
    qa_note = Column(String(100), nullable=True, comment='补充说明')



