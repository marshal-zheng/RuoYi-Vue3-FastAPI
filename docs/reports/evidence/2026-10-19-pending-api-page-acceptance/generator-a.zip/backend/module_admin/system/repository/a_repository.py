from sqlalchemy import delete, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from module_admin.system.entity.do.a_do import ZxqaMvet0wd2A
from module_admin.system.entity.vo.a_vo import AModel, APageQueryModel
from utils.page_util import PageUtil


class ARepository:
    """
    验收临时 mvet0wd2模块 Repository 层
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_a_detail_by_id(self, item_id: int):
        """
        根据编号获取验收临时 mvet0wd2详细信息

        :param db: orm对象
        :param item_id: 编号
        :return: 验收临时 mvet0wd2信息对象
        """
        a_info = (
            (
                await self.db.execute(
                    select(ZxqaMvet0wd2A)
                    .where(
                        ZxqaMvet0wd2A.item_id == item_id
                    )
                )
            )
            .scalars()
            .first()
        )

        return a_info

    async def get_a_detail_by_info(self, a: AModel):
        """
        根据验收临时 mvet0wd2参数获取验收临时 mvet0wd2信息

        :param db: orm对象
        :param a: 验收临时 mvet0wd2参数对象
        :return: 验收临时 mvet0wd2信息对象
        """
        a_info = (
            (
                await self.db.execute(
                    select(ZxqaMvet0wd2A).where(
                    )
                )
            )
            .scalars()
            .first()
        )

        return a_info

    async def get_a_list(self, query_object: APageQueryModel, is_page: bool = False):
        """
        根据查询参数获取验收临时 mvet0wd2列表信息

        :param db: orm对象
        :param query_object: 查询参数对象
        :param is_page: 是否开启分页
        :return: 验收临时 mvet0wd2列表信息对象
        """
        query = (
            select(ZxqaMvet0wd2A)
            .where(
                ZxqaMvet0wd2A.item_name.like(f'%{query_object.item_name}%') if query_object.item_name else True,
                ZxqaMvet0wd2A.status == query_object.status if query_object.status else True,
                ZxqaMvet0wd2A.qa_note == query_object.qa_note if query_object.qa_note else True,
            )
            .order_by(ZxqaMvet0wd2A.item_id)
            .distinct()
        )
        a_list = await PageUtil.paginate(self.db, query, query_object.page, query_object.page_size, is_page)

        return a_list

    async def add_a(self, a: AModel):
        """
        新增验收临时 mvet0wd2数据库操作

        :param db: orm对象
        :param a: 验收临时 mvet0wd2对象
        :return:
        """
        db_a = ZxqaMvet0wd2A(**a.model_dump(exclude={}))
        self.db.add(db_a)
        await self.db.flush()

        return db_a

    async def edit_a(self, a: dict):
        """
        编辑验收临时 mvet0wd2数据库操作

        :param db: orm对象
        :param a: 需要更新的验收临时 mvet0wd2字典
        :return:
        """
        await self.db.execute(update(ZxqaMvet0wd2A), [a])

    async def delete_a(self, a: AModel):
        """
        删除验收临时 mvet0wd2数据库操作

        :param db: orm对象
        :param a: 验收临时 mvet0wd2对象
        :return:
        """
        await self.db.execute(delete(ZxqaMvet0wd2A).where(ZxqaMvet0wd2A.item_id.in_([a.item_id])))

