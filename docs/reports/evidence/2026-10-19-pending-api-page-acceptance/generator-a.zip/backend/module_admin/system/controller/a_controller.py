from fastapi import APIRouter, Depends, Form, Request
from utils.validation_util import ValidateFields
from sqlalchemy.ext.asyncio import AsyncSession
from config.enums import BusinessType
from config.get_db import get_db
from module_admin.annotation.log_annotation import Log
from module_admin.aspect.interface_auth import CheckUserInterfaceAuth
from module_admin.entity.vo.user_vo import CurrentUserModel
from modules.identity.application.services.login_service import LoginService
from module_admin.system.service.a_service import AService
from module_admin.system.entity.vo.a_vo import DeleteAModel, AModel, APageQueryModel
from utils.common_util import bytes2file_response
from utils.log_util import logger
from utils.response_util import ResponseUtil


aController = APIRouter(prefix='/system/a', dependencies=[Depends(LoginService.get_current_user)])


@aController.get(
    '/list', dependencies=[Depends(CheckUserInterfaceAuth('system:a:list'))]
)
async def get_system_a_list(
    request: Request,
a_page_query: APageQueryModel = Depends(APageQueryModel.as_query),
    query_db: AsyncSession = Depends(get_db),
):
    # 获取分页数据
    a_page_query_result = await AService.get_a_list_services(query_db, a_page_query, is_page=True)
    logger.info('获取成功')

    return ResponseUtil.ok_page(
        items=a_page_query_result.items,
        total=a_page_query_result.total,
        page=a_page_query_result.page,
        page_size=a_page_query_result.page_size,
    )


@aController.post('', dependencies=[Depends(CheckUserInterfaceAuth('system:a:add'))])
@ValidateFields(validate_model='add_a')
@Log(title='验收临时 mvet0wd2', business_type=BusinessType.INSERT)
async def add_system_a(
    request: Request,
    add_a: AModel,
    query_db: AsyncSession = Depends(get_db),
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
):
    add_a_result = await AService.add_a_services(query_db, add_a)
    logger.info('新增成功')

    return ResponseUtil.created_resource(
        add_a_result,
        location=str(
            request.url_for(
                'query_detail_system_a',
                item_id=getattr(add_a_result, 'item_id'),
            )
        ),
    )


@aController.put('', dependencies=[Depends(CheckUserInterfaceAuth('system:a:edit'))])
@ValidateFields(validate_model='edit_a')
@Log(title='验收临时 mvet0wd2', business_type=BusinessType.UPDATE)
async def edit_system_a(
    request: Request,
    edit_a: AModel,
    query_db: AsyncSession = Depends(get_db),
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
):
    edit_a.update_by = current_user.user.user_name
    edit_a.update_time = datetime.now()
    edit_a_result = await AService.edit_a_services(query_db, edit_a)
    logger.info('更新成功')

    return ResponseUtil.ok_resource(edit_a_result)


@aController.delete('/{item_ids}', dependencies=[Depends(CheckUserInterfaceAuth('system:a:remove'))])
@Log(title='验收临时 mvet0wd2', business_type=BusinessType.DELETE)
async def delete_system_a(request: Request, item_ids: str, query_db: AsyncSession = Depends(get_db)):
    delete_a = DeleteAModel(itemIds=item_ids)
    await AService.delete_a_services(query_db, delete_a)
    logger.info('删除成功')

    return ResponseUtil.no_content()


@aController.get(
    '/{item_id}', response_model=AModel, dependencies=[Depends(CheckUserInterfaceAuth('system:a:query'))]
)
async def query_detail_system_a(request: Request, item_id: int, query_db: AsyncSession = Depends(get_db)):
    a_detail_result = await AService.a_detail_services(query_db, item_id)
    logger.info(f'获取item_id为{item_id}的信息成功')

    return ResponseUtil.ok_resource(a_detail_result)


@aController.post('/export', dependencies=[Depends(CheckUserInterfaceAuth('system:a:export'))])
@Log(title='验收临时 mvet0wd2', business_type=BusinessType.EXPORT)
async def export_system_a_list(
    request: Request,
    a_page_query: APageQueryModel = Form(),
    query_db: AsyncSession = Depends(get_db),
):
    # 获取全量数据
    a_query_result = await AService.get_a_list_services(query_db, a_page_query, is_page=False)
    a_export_result = await AService.export_a_list_services(a_query_result)
    logger.info('导出成功')

    return ResponseUtil.streaming(data=bytes2file_response(a_export_result))
