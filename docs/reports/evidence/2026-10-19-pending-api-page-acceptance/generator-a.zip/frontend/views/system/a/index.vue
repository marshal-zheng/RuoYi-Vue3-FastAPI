<template>
  <ZxPageLayout class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true" v-show="showSearch" label-width="68px">
      <el-form-item label="名称" prop="itemName">
        <el-input
          v-model="queryParams.itemName"
          placeholder="请输入名称"
          clearable
          style="width: 240px"
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="状态" prop="status">
        <el-select v-model="queryParams.status" placeholder="请选择状态" clearable style="width: 240px">
          <el-option label="请选择字典生成" value="" />
        </el-select>
      </el-form-item>
      <el-form-item label="补充说明" prop="qaNote">
        <el-input
          v-model="queryParams.qaNote"
          placeholder="请输入补充说明"
          clearable
          style="width: 240px"
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['system:a:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="Edit"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['system:a:edit']"
        >修改</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:a:remove']"
        >删除</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['system:a:export']"
        >导出</el-button>
      </el-col>
      <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
    </el-row>

    <el-table v-loading="loading" :data="aList" @selection-change="handleSelectionChange">
      <el-table-column type="selection" width="55" align="center" />
      <el-table-column label="编号" align="center" prop="itemId" />
      <el-table-column label="名称" align="center" prop="itemName" />
      <el-table-column label="状态" align="center" prop="status" />
      <el-table-column label="补充说明" align="center" prop="qaNote" />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width">
        <template #default="scope">
          <el-button link type="primary" icon="Edit" @click="handleUpdate(scope.row)" v-hasPermi="['system:a:edit']">修改</el-button>
          <el-button link type="primary" icon="Delete" @click="handleDelete(scope.row)" v-hasPermi="['system:a:remove']">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total>0"
      :total="total"
      v-model:page="queryParams.page"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加或修改验收临时 mvet0wd2对话框 -->
    <el-dialog :title="title" v-model="open" width="500px" append-to-body>
      <el-form ref="aRef" :model="form" :rules="rules" label-width="80px">
      <el-form-item v-if="renderField(true, true)" label="名称" prop="itemName">
        <el-input v-model="form.itemName" placeholder="请输入名称" />
      </el-form-item>
      <el-form-item v-if="renderField(true, true)" label="状态" prop="status">
        <el-radio-group v-model="form.status">
          <el-radio label="请选择字典生成" value="" />
        </el-radio-group>
      </el-form-item>
      <el-form-item v-if="renderField(true, true)" label="补充说明" prop="qaNote">
        <el-input v-model="form.qaNote" placeholder="请输入补充说明" />
      </el-form-item>

      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm" :loading="submitting">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </ZxPageLayout>
</template>

<script setup name="A">
import { useOperation } from "@/utils/operation";
import { listA, getA, delA, addA, updateA } from "@/api/system/a";

const { proxy } = getCurrentInstance();

const aList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  queryParams: {
    page: 1,
    pageSize: 10,
    itemName: null,
    status: null,
    qaNote: null,
  },
  rules: {
    itemName: [
      { required: true, message: "名称不能为空", trigger: "blur" }
    ],
  }
});

const { queryParams, form, rules } = toRefs(data);

/** 查询验收临时 mvet0wd2列表 */
function getList() {
  loading.value = true;
  listA(queryParams.value).then(response => {
    aList.value = response.items;
    total.value = response.total;
    loading.value = false;
  });
}

/** 取消按钮 */
function cancel() {
  open.value = false;
  reset();
}

/** 表单重置 */
function reset() {
  form.value = {
    itemId: null,
    itemName: null,
    status: null,
    qaNote: null,
  };
  proxy.resetForm("aRef");
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.page = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

/** 多选框选中数据  */
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.itemId);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "添加验收临时 mvet0wd2";
}

/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  const _itemId = row.itemId || ids.value;
  getA(_itemId).then(response => {
    form.value = response;
    open.value = true;
    title.value = "修改验收临时 mvet0wd2";
  });
}

/** 提交按钮 */
const { run: submitForm, pending: submitting } = useOperation(async () => {
  const valid = await proxy.$refs["aRef"].validate().catch(() => false);
    if (valid) {
      const submitData = { ...form.value };
      if (submitData.itemId != null) {
        await updateA(submitData).then(() => {
          open.value = false;
          getList();
        });
      } else {
        await addA(submitData).then(() => {
          open.value = false;
          getList();
        });
      }
    }
});

/** 删除按钮操作 */
const { run: handleDelete } = useOperation(async (row) => {
  const _itemIds = row.itemId || ids.value;
  await proxy.$modal.confirm('是否确认删除验收临时 mvet0wd2编号为"' + _itemIds + '"的数据项？').then(function() {
    return delA(_itemIds);
  }).then(() => {
    getList();
  }).catch(() => {});
});


/** 导出按钮操作 */
function handleExport() {
  proxy.download('system/a/export', {
    ...queryParams.value
  }, `a_${new Date().getTime()}.xlsx`);
}

/** 是否渲染字段 */
function renderField(insert, edit) {
  return form.value.itemId == null ? insert : edit;
}

getList();
</script>
