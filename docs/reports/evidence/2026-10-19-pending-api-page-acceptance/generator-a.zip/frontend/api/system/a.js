import request from '@/utils/request'

// 查询验收临时 mvet0wd2列表
export function listA(query) {
  return request({
    url: '/system/a/list',
    method: 'get',
    params: query
  })
}

// 查询验收临时 mvet0wd2详细
export function getA(itemId) {
  return request({
    url: '/system/a/' + itemId,
    method: 'get'
  })
}

// 新增验收临时 mvet0wd2
export function addA(data) {
  return request({
    url: '/system/a',
    method: 'post',
    data: data,
    feedback: { mode: 'auto', key: 'system.a.create' }
  })
}

// 修改验收临时 mvet0wd2
export function updateA(data) {
  return request({
    url: '/system/a',
    method: 'put',
    data: data,
    feedback: { mode: 'auto', key: 'system.a.update' }
  })
}

// 删除验收临时 mvet0wd2
export function delA(itemId) {
  return request({
    url: '/system/a/' + itemId,
    method: 'delete',
    feedback: { mode: 'auto', key: 'system.a.delete' }
  })
}
