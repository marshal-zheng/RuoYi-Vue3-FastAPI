# @zxio/theme-compiler

Deterministic, filesystem-free compilation of validated ZXIO Theme v4 sources.
Core compilation uses the public `@zxio/tokens/kernel` entrypoint. Business
extensions use `@zxio/tokens/extensions` and the shared CSS codec. Filesystem
writes are available solely through explicit writer APIs.

`@zxio/theme-compiler/extensions` exports `compileThemeExtensions({ package,
modules, coreContract, dependencies?, cssAdapters? })`. It returns an immutable
`{ manifest, files }` bundle with one theme-neutral CSS file, ESM/CJS token refs
and TypeScript declarations. The default encoder is `themeExtensionCssEncoder`.
Dependency manifests must be supplied explicitly during compilation and Host
registration; generated manifests contain exact dependency locks.

`writeThemeExtensionBundle({ directory, bundle, dependencies? })` writes a new
release directory atomically. Repeating the same release is a no-op. Existing
modified or unrelated output is preserved and rejected; use a new versioned
release directory for changed output. Generated `refs.d.ts` should be exposed
by the business package's `exports.types` alongside `refs.mjs` and `refs.cjs`.

Adapter ranges support exact versions, `^`, `~`, comparator sets, `||` and `*`.
Prereleases require an explicit prerelease comparator for the same version.
No adapter is required for ordinary business tokens. Optional CSS adapters map
public scalar token refs to an explicit third-party custom-property prefix and
only match an explicitly bound target whose required modules are enabled.
