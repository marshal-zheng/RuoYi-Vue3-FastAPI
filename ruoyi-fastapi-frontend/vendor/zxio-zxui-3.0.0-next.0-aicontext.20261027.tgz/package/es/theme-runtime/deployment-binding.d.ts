import type { ManifestIdentity } from './adapter-contract';
import type { ThemeRuntimePayloadV1 } from './runtime-payload';
export interface RuntimeDeploymentBinding {
    readonly identity: ManifestIdentity;
    readonly manifestSha256: string;
}
/** Internal factory port, deliberately absent from all public facades. */
export declare function bindRuntimeDeployment(resolver: object, input: readonly RuntimeDeploymentBinding[]): void;
export declare function runtimeDeploymentBinding(resolver: object): readonly RuntimeDeploymentBinding[] | undefined;
export declare function validateRuntimeDeploymentBinding(payload: ThemeRuntimePayloadV1, resolver: object): Readonly<{
    ok: false;
    diagnostics: readonly import("./diagnostics").ThemeRuntimeDiagnostic[];
}> | Readonly<{
    ok: true;
    value: undefined;
    diagnostics: readonly [];
}>;
