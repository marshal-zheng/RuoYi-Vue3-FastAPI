import { THEME_AXIS_ORDER } from './manifest-validation';
import type { ThemeRuntimeResult } from './result';
export { THEME_AXIS_ORDER, createVariantKey, manifestIdentityKey, } from './manifest-validation';
export type ThemeAxisName = (typeof THEME_AXIS_ORDER)[number];
export type ConcreteThemeSelection = Readonly<Record<ThemeAxisName, string>>;
export type ThemeStylesheetPolicy = 'aggregate' | 'on-demand';
export interface RuntimeAxisDeclaration {
    readonly default: string;
    readonly supported: readonly string[];
}
export interface RuntimeManifestIdentity {
    readonly themeId: string;
    readonly packageName: string;
    readonly packageVersion: string;
    readonly compilerName: '@zxio/theme-compiler';
    readonly compilerVersion: string;
    readonly sourceSchemaVersion: 4;
    readonly resolvedSchemaVersion: 1;
    readonly contractVersion: '4.0.0';
    readonly sourceContentHash: string;
    readonly contractContentHash: string;
    readonly typeRegistryContentHash: string;
}
export interface RuntimeManifestArtifactRef {
    readonly path: string;
    readonly sha256: string;
}
export interface RuntimeManifestArtifact extends RuntimeManifestArtifactRef {
    readonly mediaType: string;
    readonly bytes: number;
    readonly purpose: 'core-css' | 'aggregate-css' | 'typegen-runtime' | 'typegen-declarations' | 'element-plus-alias' | 'element-plus-resolved' | 'dtcg-token-set' | 'dtcg-index';
    readonly loadPhase: 'contract' | 'theme' | 'variant' | 'tooling';
}
export interface RuntimeManifestVariant {
    readonly variantKey: string;
    readonly selection: ConcreteThemeSelection;
    readonly resolvedContentHash: string;
    readonly selector: string;
    readonly artifacts: Readonly<{
        coreCss: RuntimeManifestArtifactRef;
        elementPlusResolvedCss: RuntimeManifestArtifactRef;
        dtcgTokens: RuntimeManifestArtifactRef;
    }>;
}
export interface RuntimeThemeManifest {
    readonly schema: 'zx.theme-manifest/1';
    readonly variantKeySchema: 'zx.variant-key/1';
    readonly selectorSchema: 'zx.theme-selector/1';
    readonly displayContract?: unknown;
    readonly identity: RuntimeManifestIdentity;
    readonly axes: Readonly<{
        applicationOrder: typeof THEME_AXIS_ORDER;
        declarations: Readonly<Record<ThemeAxisName, RuntimeAxisDeclaration>>;
        variantCount: number;
    }>;
    readonly publicSurface: readonly unknown[];
    readonly variants: readonly RuntimeManifestVariant[];
    readonly artifacts: readonly RuntimeManifestArtifact[];
    readonly adapters: Readonly<Record<'elementPlus' | 'tailwind' | 'dtcg', unknown>>;
}
export type ManifestIdentity = Readonly<Pick<RuntimeManifestIdentity, 'packageName' | 'packageVersion' | 'themeId' | 'contractVersion' | 'sourceContentHash' | 'contractContentHash' | 'typeRegistryContentHash'>>;
export interface RuntimeManifestIndex {
    readonly manifest: RuntimeThemeManifest;
    readonly identity: ManifestIdentity;
    readonly identityKey: string;
    readonly variantsByKey: ReadonlyMap<string, RuntimeManifestVariant>;
    readonly variantsBySelection: ReadonlyMap<string, RuntimeManifestVariant>;
    readonly artifactsByPath: ReadonlyMap<string, RuntimeManifestArtifact>;
}
export interface ThemeStylesheetLoadPlanEntry {
    readonly packageName: string;
    readonly packageVersion: string;
    readonly exportPath: string;
    readonly artifactPath: string;
    readonly sha256: string;
    readonly purpose: RuntimeManifestArtifact['purpose'];
    readonly loadPhase: RuntimeManifestArtifact['loadPhase'];
}
export interface ThemeStylesheetLoadPlan {
    readonly schema: 'zx.theme-runtime.stylesheet-load-plan/1';
    readonly manifestIdentity: ManifestIdentity;
    readonly policy: ThemeStylesheetPolicy;
    readonly variantKey: string;
    readonly entries: readonly ThemeStylesheetLoadPlanEntry[];
}
export interface AdapterContractPort {
    readonly contractVersion: '4.0.0';
    validateManifest(input: unknown): ThemeRuntimeResult<RuntimeThemeManifest>;
    identityOf(manifest: RuntimeThemeManifest): ManifestIdentity;
    indexManifest(manifest: RuntimeThemeManifest): RuntimeManifestIndex;
    resolveLoadPlan(input: {
        readonly manifest: RuntimeThemeManifest;
        readonly variant: RuntimeManifestVariant;
        readonly policy: ThemeStylesheetPolicy;
    }): ThemeRuntimeResult<ThemeStylesheetLoadPlan>;
}
export declare const providerOwnedAdapterContract: AdapterContractPort;
export declare function runtimeSelectionKey(selection: ConcreteThemeSelection): string;
