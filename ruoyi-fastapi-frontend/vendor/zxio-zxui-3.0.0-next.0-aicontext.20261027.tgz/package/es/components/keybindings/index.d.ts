export declare const componentKeyboardEnabled: import("@zxio/zxui/es/keybindings/core").ContextKey<true>;
export declare const contentWrapSaveAction: import("@zxio/zxui/es/keybindings/core").ActionToken<void, void>;
export declare const contentWrapCancelAction: import("@zxio/zxui/es/keybindings/core").ActionToken<void, void>;
export declare const overlayFullscreenAction: import("@zxio/zxui/es/keybindings/core").ActionToken<void, void>;
export declare const searchFocusAction: import("@zxio/zxui/es/keybindings/core").ActionToken<void, void>;
export declare const componentShortcuts: import("@zxio/zxui/es/keybindings/core").ShortcutContribution;
