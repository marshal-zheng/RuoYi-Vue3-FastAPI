export declare const ZxMessage: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    message: {
        type: import("vue").PropType<string | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | (() => import("vue").VNode) | undefined>;
    };
    description: {
        type: import("vue").PropType<string | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | (() => import("vue").VNode) | undefined>;
    };
    type: {
        type: import("vue").PropType<NonNullable<"primary" | "success" | "warning" | "info" | "error" | undefined>>;
        default: string;
    };
    appearance: {
        type: import("vue").PropType<import("./src/types").ZxMessageAppearance>;
    };
    icon: {
        type: import("vue").PropType<import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined>;
    };
    closeIcon: {
        type: import("vue").PropType<import("vue").Component>;
    };
    closeLabel: {
        type: StringConstructor;
    };
    action: {
        type: import("vue").PropType<import("./src/types").ZxMessageAction>;
    };
    customStyle: {
        type: import("vue").PropType<import("vue").CSSProperties>;
    };
    showClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    dangerouslyUseHTMLString: {
        type: BooleanConstructor;
        default: boolean;
    };
    announce: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => true;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    message: {
        type: import("vue").PropType<string | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | (() => import("vue").VNode) | undefined>;
    };
    description: {
        type: import("vue").PropType<string | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | (() => import("vue").VNode) | undefined>;
    };
    type: {
        type: import("vue").PropType<NonNullable<"primary" | "success" | "warning" | "info" | "error" | undefined>>;
        default: string;
    };
    appearance: {
        type: import("vue").PropType<import("./src/types").ZxMessageAppearance>;
    };
    icon: {
        type: import("vue").PropType<import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined>;
    };
    closeIcon: {
        type: import("vue").PropType<import("vue").Component>;
    };
    closeLabel: {
        type: StringConstructor;
    };
    action: {
        type: import("vue").PropType<import("./src/types").ZxMessageAction>;
    };
    customStyle: {
        type: import("vue").PropType<import("vue").CSSProperties>;
    };
    showClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    dangerouslyUseHTMLString: {
        type: BooleanConstructor;
        default: boolean;
    };
    announce: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onClose?: (() => any) | undefined;
}>, {
    type: NonNullable<"primary" | "success" | "warning" | "info" | "error" | undefined>;
    dangerouslyUseHTMLString: boolean;
    showClose: boolean;
    announce: boolean;
}, import("vue").SlotsType<import("./src/types").ZxMessageSlots>, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxMessage;
export type { ZxMessageAction, ZxMessageAppearance, ZxMessageConfig, ZxMessageOptions, ZxMessageParams, ZxMessageSlotScope, ZxMessageSlots, } from './src/types';
