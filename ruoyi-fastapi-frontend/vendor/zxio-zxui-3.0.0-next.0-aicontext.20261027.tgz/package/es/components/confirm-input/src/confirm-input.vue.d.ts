declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly dangerMessage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly description: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly targetName: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly targetType: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly keyword: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly pattern: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
        (): string | RegExp;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
        (): string | RegExp;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly validator: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
    readonly requireKeyword: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly confirmAction: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
    readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 520, boolean>;
    readonly closable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly maskClosable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly unmountOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly okText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly cancelText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showCancelButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly disabledWhenMismatch: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly caseSensitive: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly autofocus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly maxlength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly inputProps: import("@zxio/shared").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
    readonly rounded: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly tone: import("@zxio/shared").EpPropFinalized<StringConstructor, "warning" | "info" | "danger", unknown, "danger", boolean>;
    readonly showErrorMessage: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    formRef: import("vue").Ref<null, null>;
    inputRef: import("vue").Ref<null, null>;
    form: {
        value: string;
    };
    rules: any;
    localValid: import("vue").Ref<boolean, boolean>;
    isMatch: () => Promise<any>;
    errorText: import("vue").ComputedRef<string>;
    visible: import("vue").Ref<any, any>;
    handleOpen: () => void;
    handleOpenAutoFocus: () => void;
    handleClose: () => void;
    handleCancel: () => void;
    internalLoading: import("vue").Ref<boolean, boolean>;
    isLoading: import("vue").ComputedRef<any>;
    confirmDisabled: import("vue").ComputedRef<any>;
    tryConfirm: (formRef?: any) => Promise<any>;
    handleConfirm: () => Promise<any> | undefined;
    handleInputEnter: (event: Event) => void;
    handleEnterKey: (event: Event, confirmCallback: any) => void;
    handleEscapeKey: (event: KeyboardEvent, cancelCallback: any) => void;
    resolvedTitle: import("vue").ComputedRef<string>;
    resolvedOkText: import("vue").ComputedRef<string>;
    resolvedCancelText: import("vue").ComputedRef<string>;
    confirmationKeyword: import("vue").ComputedRef<string>;
    defaultDanger: import("vue").ComputedRef<string>;
    defaultDescription: import("vue").ComputedRef<string>;
    inputHintParts: import("vue").ComputedRef<{
        before: string;
        after: string;
    }>;
    props: import("@vue/shared").LooseRequired<Readonly<import("vue").ExtractPropTypes<{
        readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly dangerMessage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly description: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly targetName: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly targetType: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly keyword: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly pattern: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
            (): string | RegExp;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
            (): string | RegExp;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        readonly validator: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
        readonly requireKeyword: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly confirmAction: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
        readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 520, boolean>;
        readonly closable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly maskClosable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly unmountOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly okText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly cancelText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly showCancelButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly disabledWhenMismatch: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly caseSensitive: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly autofocus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly maxlength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly inputProps: import("@zxio/shared").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
        readonly rounded: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly tone: import("@zxio/shared").EpPropFinalized<StringConstructor, "warning" | "info" | "danger", unknown, "danger", boolean>;
        readonly showErrorMessage: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & Readonly<{
        onOpen?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((v: boolean) => any) | undefined;
        onCancel?: (() => any) | undefined;
        onClose?: (() => any) | undefined;
        onError?: ((_event: {
            error: Error;
            payload: {
                value: string;
            };
            result?: unknown;
        }) => any) | undefined;
        onConfirm?: ((_payload: {
            value: string;
            result?: unknown;
        }) => any) | undefined;
        onClosed?: (() => any) | undefined;
    }> & {}>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (v: boolean) => boolean;
    open: () => boolean;
    close: () => boolean;
    closed: () => boolean;
    confirm: (_payload: {
        value: string;
        result?: unknown;
    }) => boolean;
    cancel: () => boolean;
    error: (_event: {
        error: Error;
        payload: {
            value: string;
        };
        result?: unknown;
    }) => boolean;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly dangerMessage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly description: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly targetName: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly targetType: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly keyword: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly pattern: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
        (): string | RegExp;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
        (): string | RegExp;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly validator: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
    readonly requireKeyword: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly confirmAction: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
    readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 520, boolean>;
    readonly closable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly maskClosable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly unmountOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly okText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly cancelText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showCancelButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly disabledWhenMismatch: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly caseSensitive: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly autofocus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly maxlength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly inputProps: import("@zxio/shared").EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
    readonly rounded: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly tone: import("@zxio/shared").EpPropFinalized<StringConstructor, "warning" | "info" | "danger", unknown, "danger", boolean>;
    readonly showErrorMessage: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}>> & Readonly<{
    onOpen?: (() => any) | undefined;
    "onUpdate:modelValue"?: ((v: boolean) => any) | undefined;
    onCancel?: (() => any) | undefined;
    onClose?: (() => any) | undefined;
    onError?: ((_event: {
        error: Error;
        payload: {
            value: string;
        };
        result?: unknown;
    }) => any) | undefined;
    onConfirm?: ((_payload: {
        value: string;
        result?: unknown;
    }) => any) | undefined;
    onClosed?: (() => any) | undefined;
}>, {
    readonly description: string;
    readonly title: string;
    readonly pattern: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
        (): string | RegExp;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | RegExp) | (() => string | RegExp) | {
        (): string | RegExp;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly validator: Function;
    readonly placeholder: string;
    readonly autofocus: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showCancelButton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly rounded: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly maxlength: number;
    readonly cancelText: string;
    readonly closable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okText: string;
    readonly dangerMessage: string;
    readonly targetName: string;
    readonly targetType: string;
    readonly keyword: string;
    readonly requireKeyword: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmAction: Function;
    readonly maskClosable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly unmountOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly disabledWhenMismatch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly caseSensitive: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly inputProps: Record<string, any>;
    readonly tone: import("@zxio/shared").EpPropMergeType<StringConstructor, "warning" | "info" | "danger", unknown>;
    readonly showErrorMessage: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {
    ElButton: __ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, import("vue").PublicProps, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ButtonProps> & Readonly<{
        onClick?: ((evt: MouseEvent) => any) | undefined;
    }>, {
        ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
        size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
        disabled: import("vue").ComputedRef<boolean>;
        shouldAddSpace: import("vue").ComputedRef<boolean>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        click: (evt: MouseEvent) => void;
    }, string, {
        type: import("element-plus").ButtonType;
        text: boolean;
        disabled: boolean;
        round: boolean;
        dashed: boolean;
        tag: string | import("vue").Component;
        nativeType: import("element-plus").ButtonNativeType;
        loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
        plain: boolean;
        autoInsertSpace: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        setPropsDefaults: (defaults: {
            readonly size?: "" | "small" | "default" | "large" | (() => "" | "small" | "default" | "large") | undefined;
            readonly disabled?: boolean | (() => boolean) | undefined;
            readonly type?: "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger" | (() => "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger") | undefined;
            readonly icon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
            readonly nativeType?: "button" | "reset" | "submit" | (() => "button" | "reset" | "submit") | undefined;
            readonly loading?: boolean | (() => boolean) | undefined;
            readonly loadingIcon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
            readonly plain?: boolean | (() => boolean) | undefined;
            readonly text?: boolean | (() => boolean) | undefined;
            readonly link?: boolean | (() => boolean) | undefined;
            readonly bg?: boolean | (() => boolean) | undefined;
            readonly autofocus?: boolean | (() => boolean) | undefined;
            readonly round?: boolean | (() => boolean) | undefined;
            readonly circle?: boolean | (() => boolean) | undefined;
            readonly dashed?: boolean | (() => boolean) | undefined;
            readonly color?: string | (() => string) | undefined;
            readonly dark?: boolean | (() => boolean) | undefined;
            readonly autoInsertSpace?: boolean | (() => boolean) | undefined;
            readonly tag?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | (() => (string | import("vue").Component | undefined) & {}) | undefined;
        }) => void;
    } & {
        ButtonGroup: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>;
    }, {
        $slots: {
            loading?: (props: {}) => any;
        } & {
            icon?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        };
    }>;
    ElForm: __ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, import("vue").PublicProps, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
    }, string, {
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        setPropsDefaults: (defaults: {
            readonly model?: (() => Record<string, any>) | undefined;
            readonly rules?: (() => Partial<Record<string, Record<string, any> | import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>) | undefined;
            readonly labelPosition?: "top" | "right" | "left" | (() => "top" | "right" | "left") | undefined;
            readonly requireAsteriskPosition?: "right" | "left" | (() => "right" | "left") | undefined;
            readonly labelWidth?: string | number | (() => string | number) | undefined;
            readonly labelSuffix?: string | (() => string) | undefined;
            readonly inline?: boolean | (() => boolean) | undefined;
            readonly inlineMessage?: boolean | (() => boolean) | undefined;
            readonly statusIcon?: boolean | (() => boolean) | undefined;
            readonly showMessage?: boolean | (() => boolean) | undefined;
            readonly validateOnRuleChange?: boolean | (() => boolean) | undefined;
            readonly hideRequiredAsterisk?: boolean | (() => boolean) | undefined;
            readonly scrollToError?: boolean | (() => boolean) | undefined;
            readonly scrollIntoViewOptions?: boolean | (() => boolean | ScrollIntoViewOptions) | undefined;
            readonly size?: "" | "small" | "default" | "large" | (() => "" | "small" | "default" | "large") | undefined;
            readonly disabled?: boolean | (() => boolean) | undefined;
        }) => void;
    } & {
        FormItem: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").FormItemProps> & Readonly<{}>, {
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                validateMessage: import("vue").Ref<string, string>;
                validateState: import("vue").Ref<"" | "error" | "success" | "validating", "" | "error" | "success" | "validating">;
                validate: (trigger: string, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                clearValidate: () => void;
                resetField: () => void;
                setInitialValue: (value: any) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                required: boolean;
                labelPosition: "left" | "right" | "top" | "";
                inlineMessage: boolean;
                showMessage: boolean;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").FormItemProps> & Readonly<{}>, {
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                validateMessage: import("vue").Ref<string, string>;
                validateState: import("vue").Ref<"" | "error" | "success" | "validating", "" | "error" | "success" | "validating">;
                validate: (trigger: string, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                clearValidate: () => void;
                resetField: () => void;
                setInitialValue: (value: any) => void;
            }, {}, {}, {}, {
                required: boolean;
                labelPosition: "left" | "right" | "top" | "";
                inlineMessage: boolean;
                showMessage: boolean;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormItemProps> & Readonly<{}>, {
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            validateMessage: import("vue").Ref<string, string>;
            validateState: import("vue").Ref<"" | "error" | "success" | "validating", "" | "error" | "success" | "validating">;
            validate: (trigger: string, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            clearValidate: () => void;
            resetField: () => void;
            setInitialValue: (value: any) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            required: boolean;
            labelPosition: "left" | "right" | "top" | "";
            inlineMessage: boolean;
            showMessage: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                label?: (props: {
                    label: string;
                }) => any;
            } & {
                default?: (props: {}) => any;
            } & {
                error?: (props: {
                    error: string;
                }) => any;
            };
        }>;
    }, {
        $slots: {
            default?: (props: {}) => any;
        };
    }>;
    ElFormItem: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").FormItemProps> & Readonly<{}>, {
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            validateMessage: import("vue").Ref<string, string>;
            validateState: import("vue").Ref<"" | "error" | "success" | "validating", "" | "error" | "success" | "validating">;
            validate: (trigger: string, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            clearValidate: () => void;
            resetField: () => void;
            setInitialValue: (value: any) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
            required: boolean;
            labelPosition: "left" | "right" | "top" | "";
            inlineMessage: boolean;
            showMessage: boolean;
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").FormItemProps> & Readonly<{}>, {
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            validateMessage: import("vue").Ref<string, string>;
            validateState: import("vue").Ref<"" | "error" | "success" | "validating", "" | "error" | "success" | "validating">;
            validate: (trigger: string, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            clearValidate: () => void;
            resetField: () => void;
            setInitialValue: (value: any) => void;
        }, {}, {}, {}, {
            required: boolean;
            labelPosition: "left" | "right" | "top" | "";
            inlineMessage: boolean;
            showMessage: boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormItemProps> & Readonly<{}>, {
        size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        validateMessage: import("vue").Ref<string, string>;
        validateState: import("vue").Ref<"" | "error" | "success" | "validating", "" | "error" | "success" | "validating">;
        validate: (trigger: string, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        clearValidate: () => void;
        resetField: () => void;
        setInitialValue: (value: any) => void;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
        required: boolean;
        labelPosition: "left" | "right" | "top" | "";
        inlineMessage: boolean;
        showMessage: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            label?: (props: {
                label: string;
            }) => any;
        } & {
            default?: (props: {}) => any;
        } & {
            error?: (props: {
                error: string;
            }) => any;
        };
    }>>;
    ZxDialog: __ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
            readonly height: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly fullscreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("@zxio/zxui").DialogMessages>) | (() => Partial<import("@zxio/zxui").DialogMessages>) | {
                (): Partial<import("@zxio/zxui").DialogMessages>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Partial<import("@zxio/zxui").DialogMessages>) | (() => Partial<import("@zxio/zxui").DialogMessages>) | {
                (): Partial<import("@zxio/zxui").DialogMessages>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, false, boolean>;
            readonly beforeClose: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogBeforeClose) | (() => import("@zxio/zxui").DialogBeforeClose) | {
                (): import("@zxio/zxui").DialogBeforeClose;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogBeforeClose) | (() => import("@zxio/zxui").DialogBeforeClose) | {
                (): import("@zxio/zxui").DialogBeforeClose;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly onConfirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
                (): string[][];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
                (): string[][];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
                (): (step: number) => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
                (): (step: number) => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogDescriptionItem[]) | (() => import("@zxio/zxui").DialogDescriptionItem[]) | {
                (): import("@zxio/zxui").DialogDescriptionItem[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogDescriptionItem[]) | (() => import("@zxio/zxui").DialogDescriptionItem[]) | {
                (): import("@zxio/zxui").DialogDescriptionItem[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => never[], boolean>;
            readonly dialogSize: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown, "small", boolean>;
            readonly footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "spin", boolean>;
            readonly loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly okText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly cancelText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly saveContinueText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly dialogStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
                (): import("vue").CSSProperties;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
                (): import("vue").CSSProperties;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => {}, boolean>;
            readonly modalClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm) | (() => import("@zxio/zxui").DialogConfirm) | {
                (): import("@zxio/zxui").DialogConfirm;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm) | (() => import("@zxio/zxui").DialogConfirm) | {
                (): import("@zxio/zxui").DialogConfirm;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 24, boolean>;
            readonly draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
                (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
                (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
            readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
            readonly prevText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly nextText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly submitText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
                (): import("@zxio/constants").FooterButtonConfig[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
                (): import("@zxio/constants").FooterButtonConfig[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            }) | null)[], "right" | "left" | "center", unknown, "right", boolean>;
            readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
                (): () => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
                (): () => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
                (): (success: boolean) => void;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
                (): (success: boolean) => void;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            }) | null)[], "auto" | "none", unknown, undefined, boolean>;
        }>> & Readonly<{
            onNext?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
            onPrev?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
            onOpen?: (() => any) | undefined;
            "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
            onCancel?: (() => any) | undefined;
            onContinue?: (() => any) | undefined;
            onClose?: (() => any) | undefined;
            onBack?: (() => any) | undefined;
            onConfirm?: ((_result?: any) => any) | undefined;
            onClosed?: (() => any) | undefined;
            onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
            onSaveSuccess?: ((_data?: any) => any) | undefined;
            onSaveError?: ((_error: any) => any) | undefined;
            onButtonClick?: ((_buttonKey: string) => any) | undefined;
            "onUpdate:currentStep"?: ((val: number) => any) | undefined;
            "onUpdate:current-step"?: ((val: number) => any) | undefined;
            "onUpdate:fullscreen"?: ((_value: boolean) => any) | undefined;
            "onFullscreen-change"?: ((_value: boolean) => any) | undefined;
            onOpened?: (() => any) | undefined;
            onOpenAutoFocus?: (() => any) | undefined;
            onCloseAutoFocus?: (() => any) | undefined;
            "onBefore-close"?: ((_reason: "cancel" | "close") => any) | undefined;
            "onDirty-change"?: ((_value: boolean) => any) | undefined;
            "onConfirm-error"?: ((_error?: any) => any) | undefined;
        }>, {
            open: () => void;
            close: () => Promise<void>;
            cancel: () => Promise<void>;
            submit: () => Promise<void>;
            validate: () => Promise<boolean>;
            resetForm: () => void;
            scrollToFirstError: () => void;
            prev: () => void;
            next: () => Promise<void>;
            toggleFullscreen: () => import("@zxio/zxui/es/keybindings/core").ActionAdmission<void>;
            isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            isDirty: boolean;
            isSubmitting: boolean;
            currentStep: number;
            isFirstStep: boolean;
            isLastStep: boolean;
            resetSubmitting: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            next: (params: import("@zxio/constants").StepEventParams) => void;
            prev: (params: import("@zxio/constants").StepEventParams) => void;
            open: () => void;
            "update:modelValue": (val: boolean) => void;
            cancel: () => void;
            continue: () => void;
            close: () => void;
            back: () => void;
            confirm: (_result?: any) => void;
            closed: () => void;
            saveStart: (_done: () => void, _fail: (error?: any) => void) => void;
            saveSuccess: (_data?: any) => void;
            saveError: (_error: any) => void;
            buttonClick: (_buttonKey: string) => void;
            "update:currentStep": (val: number) => void;
            "update:current-step": (val: number) => void;
            "update:fullscreen": (_value: boolean) => void;
            "fullscreen-change": (_value: boolean) => void;
            opened: () => void;
            openAutoFocus: () => void;
            closeAutoFocus: () => void;
            "before-close": (_reason: "cancel" | "close") => void;
            "dirty-change": (_value: boolean) => void;
            "confirm-error": (_error?: any) => void;
        }, import("vue").PublicProps, {
            readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly title: string;
            readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
            readonly height: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly width: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly debounce: number;
            readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly throttle: number;
            readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly appendTo: import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
            readonly modalClass: string;
            readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly confirm: import("@zxio/zxui").DialogConfirm;
            readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly currentStep: number;
            readonly totalSteps: number;
            readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly buttons: import("@zxio/constants").FooterButtonConfig[];
            readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            }) | null)[], "right" | "left" | "center", unknown>;
            readonly beforeSave: () => boolean | Promise<boolean>;
            readonly afterSave: (success: boolean) => void;
            readonly formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly loadingText: string;
            readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly subtitle: string;
            readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly stepFields: string[][];
            readonly validateStep: (step: number) => boolean | Promise<boolean>;
            readonly titleTag: string;
            readonly titleTagColor: string;
            readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
            readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
            readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly loadingBackground: string;
            readonly okText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly dialogStyle: import("vue").CSSProperties;
            readonly handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly formModel: Record<string, any>;
            readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollErrorOffset: number;
            readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            }) | null)[], "auto" | "none", unknown>;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
            readonly height: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly fullscreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("@zxio/zxui").DialogMessages>) | (() => Partial<import("@zxio/zxui").DialogMessages>) | {
                (): Partial<import("@zxio/zxui").DialogMessages>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Partial<import("@zxio/zxui").DialogMessages>) | (() => Partial<import("@zxio/zxui").DialogMessages>) | {
                (): Partial<import("@zxio/zxui").DialogMessages>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, false, boolean>;
            readonly beforeClose: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogBeforeClose) | (() => import("@zxio/zxui").DialogBeforeClose) | {
                (): import("@zxio/zxui").DialogBeforeClose;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogBeforeClose) | (() => import("@zxio/zxui").DialogBeforeClose) | {
                (): import("@zxio/zxui").DialogBeforeClose;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly onConfirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
                (): string[][];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
                (): string[][];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
                (): (step: number) => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
                (): (step: number) => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogDescriptionItem[]) | (() => import("@zxio/zxui").DialogDescriptionItem[]) | {
                (): import("@zxio/zxui").DialogDescriptionItem[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogDescriptionItem[]) | (() => import("@zxio/zxui").DialogDescriptionItem[]) | {
                (): import("@zxio/zxui").DialogDescriptionItem[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => never[], boolean>;
            readonly dialogSize: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown, "small", boolean>;
            readonly footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "spin", boolean>;
            readonly loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly okText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly cancelText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly saveContinueText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly dialogStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
                (): import("vue").CSSProperties;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
                (): import("vue").CSSProperties;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => {}, boolean>;
            readonly modalClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm) | (() => import("@zxio/zxui").DialogConfirm) | {
                (): import("@zxio/zxui").DialogConfirm;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm) | (() => import("@zxio/zxui").DialogConfirm) | {
                (): import("@zxio/zxui").DialogConfirm;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, null, boolean>;
            readonly autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 24, boolean>;
            readonly draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
                (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
                (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
            readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
            readonly prevText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly nextText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly submitText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
            readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
                (): import("@zxio/constants").FooterButtonConfig[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
                (): import("@zxio/constants").FooterButtonConfig[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            }) | null)[], "right" | "left" | "center", unknown, "right", boolean>;
            readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
                (): () => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
                (): () => boolean | Promise<boolean>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
                (): (success: boolean) => void;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
                (): (success: boolean) => void;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, undefined, boolean>;
            readonly bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            }) | null)[], "auto" | "none", unknown, undefined, boolean>;
        }>> & Readonly<{
            onNext?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
            onPrev?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
            onOpen?: (() => any) | undefined;
            "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
            onCancel?: (() => any) | undefined;
            onContinue?: (() => any) | undefined;
            onClose?: (() => any) | undefined;
            onBack?: (() => any) | undefined;
            onConfirm?: ((_result?: any) => any) | undefined;
            onClosed?: (() => any) | undefined;
            onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
            onSaveSuccess?: ((_data?: any) => any) | undefined;
            onSaveError?: ((_error: any) => any) | undefined;
            onButtonClick?: ((_buttonKey: string) => any) | undefined;
            "onUpdate:currentStep"?: ((val: number) => any) | undefined;
            "onUpdate:current-step"?: ((val: number) => any) | undefined;
            "onUpdate:fullscreen"?: ((_value: boolean) => any) | undefined;
            "onFullscreen-change"?: ((_value: boolean) => any) | undefined;
            onOpened?: (() => any) | undefined;
            onOpenAutoFocus?: (() => any) | undefined;
            onCloseAutoFocus?: (() => any) | undefined;
            "onBefore-close"?: ((_reason: "cancel" | "close") => any) | undefined;
            "onDirty-change"?: ((_value: boolean) => any) | undefined;
            "onConfirm-error"?: ((_error?: any) => any) | undefined;
        }>, {
            open: () => void;
            close: () => Promise<void>;
            cancel: () => Promise<void>;
            submit: () => Promise<void>;
            validate: () => Promise<boolean>;
            resetForm: () => void;
            scrollToFirstError: () => void;
            prev: () => void;
            next: () => Promise<void>;
            toggleFullscreen: () => import("@zxio/zxui/es/keybindings/core").ActionAdmission<void>;
            isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            isDirty: boolean;
            isSubmitting: boolean;
            currentStep: number;
            isFirstStep: boolean;
            isLastStep: boolean;
            resetSubmitting: () => void;
        }, {}, {}, {}, {
            readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly title: string;
            readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
            readonly height: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
                (): import("@zxio/zxui").ZxOverlayLength;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly width: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly debounce: number;
            readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly throttle: number;
            readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly appendTo: import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
                (): import("@zxio/zxui").ZxOverlayPadding;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
            readonly modalClass: string;
            readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly confirm: import("@zxio/zxui").DialogConfirm;
            readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly currentStep: number;
            readonly totalSteps: number;
            readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly buttons: import("@zxio/constants").FooterButtonConfig[];
            readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
                (): "right" | "left" | "center";
                new (): any;
                readonly prototype: any;
            }) | null)[], "right" | "left" | "center", unknown>;
            readonly beforeSave: () => boolean | Promise<boolean>;
            readonly afterSave: (success: boolean) => void;
            readonly formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => {
                $: import("vue").ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly model?: Record<string, any> | undefined;
                    readonly rules?: import("element-plus").FormRules | undefined;
                    readonly labelPosition?: ("left" | "right" | "top") | undefined;
                    readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                    readonly labelWidth?: (string | number) | undefined;
                    readonly labelSuffix?: string | undefined;
                    readonly inline?: boolean | undefined;
                    readonly inlineMessage?: boolean | undefined;
                    readonly statusIcon?: boolean | undefined;
                    readonly showMessage?: boolean | undefined;
                    readonly validateOnRuleChange?: boolean | undefined;
                    readonly hideRequiredAsterisk?: boolean | undefined;
                    readonly scrollToError?: boolean | undefined;
                    readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                    readonly size?: import("element-plus").ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
                $attrs: import("vue").Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import("vue").Slot<any> | undefined;
                }>;
                $root: import("vue").ComponentPublicInstance | null;
                $parent: import("vue").ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                $el: any;
                $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                    onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
                }>, {
                    validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                    resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                    scrollToField: (prop: import("element-plus").FormItemProp) => void;
                    getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                    fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                    setInitialValues: (initModel: Record<string, any>) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
                }, string, {
                    labelWidth: string | number;
                    labelPosition: "left" | "right" | "top";
                    requireAsteriskPosition: "left" | "right";
                    labelSuffix: string;
                    showMessage: boolean;
                    validateOnRuleChange: boolean;
                    scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import("vue").nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
            } & Readonly<{
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            } & {} & import("vue").ComponentCustomProperties & {} & {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) | (() => import("element-plus").FormInstance | null) | {
                (): import("element-plus").FormInstance | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly loadingText: string;
            readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly subtitle: string;
            readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
                (): boolean | import("@zxio/zxui").DialogDirtyGuard;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
                (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly stepFields: string[][];
            readonly validateStep: (step: number) => boolean | Promise<boolean>;
            readonly titleTag: string;
            readonly titleTagColor: string;
            readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
            readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
            readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
                (): "spin" | "skeleton";
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly loadingBackground: string;
            readonly okText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
            readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly dialogStyle: import("vue").CSSProperties;
            readonly handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
                (): (() => unknown) | null;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly formModel: Record<string, any>;
            readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollErrorOffset: number;
            readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
                (): import("@zxio/zxui").ZxOverlayBodyScroll;
                new (): any;
                readonly prototype: any;
            }) | null)[], "auto" | "none", unknown>;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
        readonly height: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly fullscreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("@zxio/zxui").DialogMessages>) | (() => Partial<import("@zxio/zxui").DialogMessages>) | {
            (): Partial<import("@zxio/zxui").DialogMessages>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<import("@zxio/zxui").DialogMessages>) | (() => Partial<import("@zxio/zxui").DialogMessages>) | {
            (): Partial<import("@zxio/zxui").DialogMessages>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DialogDirtyGuard;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DialogDirtyGuard;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, false, boolean>;
        readonly beforeClose: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogBeforeClose) | (() => import("@zxio/zxui").DialogBeforeClose) | {
            (): import("@zxio/zxui").DialogBeforeClose;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DialogBeforeClose) | (() => import("@zxio/zxui").DialogBeforeClose) | {
            (): import("@zxio/zxui").DialogBeforeClose;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly onConfirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
            (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
            (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
            (): string[][];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
            (): string[][];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
            (): (step: number) => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
            (): (step: number) => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogDescriptionItem[]) | (() => import("@zxio/zxui").DialogDescriptionItem[]) | {
            (): import("@zxio/zxui").DialogDescriptionItem[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DialogDescriptionItem[]) | (() => import("@zxio/zxui").DialogDescriptionItem[]) | {
            (): import("@zxio/zxui").DialogDescriptionItem[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly dialogSize: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown, "small", boolean>;
        readonly footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "spin", boolean>;
        readonly loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly okText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
        readonly cancelText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
        readonly saveContinueText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
        readonly okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly dialogStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
            (): import("vue").CSSProperties;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
            (): import("vue").CSSProperties;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        readonly modalClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        readonly confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm) | (() => import("@zxio/zxui").DialogConfirm) | {
            (): import("@zxio/zxui").DialogConfirm;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm) | (() => import("@zxio/zxui").DialogConfirm) | {
            (): import("@zxio/zxui").DialogConfirm;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        readonly formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        readonly autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 24, boolean>;
        readonly draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
        readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
        readonly prevText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
        readonly nextText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
        readonly submitText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
        readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
            (): import("@zxio/constants").FooterButtonConfig[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
            (): import("@zxio/constants").FooterButtonConfig[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
            (): "right" | "left" | "center";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
            (): "right" | "left" | "center";
            new (): any;
            readonly prototype: any;
        }) | null)[], "right" | "left" | "center", unknown, "right", boolean>;
        readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
            (): () => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
            (): () => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
            (): (success: boolean) => void;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
            (): (success: boolean) => void;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        }) | null)[], "auto" | "none", unknown, undefined, boolean>;
    }>> & Readonly<{
        onNext?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
        onPrev?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
        onOpen?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
        onCancel?: (() => any) | undefined;
        onContinue?: (() => any) | undefined;
        onClose?: (() => any) | undefined;
        onBack?: (() => any) | undefined;
        onConfirm?: ((_result?: any) => any) | undefined;
        onClosed?: (() => any) | undefined;
        onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
        onSaveSuccess?: ((_data?: any) => any) | undefined;
        onSaveError?: ((_error: any) => any) | undefined;
        onButtonClick?: ((_buttonKey: string) => any) | undefined;
        "onUpdate:currentStep"?: ((val: number) => any) | undefined;
        "onUpdate:current-step"?: ((val: number) => any) | undefined;
        "onUpdate:fullscreen"?: ((_value: boolean) => any) | undefined;
        "onFullscreen-change"?: ((_value: boolean) => any) | undefined;
        onOpened?: (() => any) | undefined;
        onOpenAutoFocus?: (() => any) | undefined;
        onCloseAutoFocus?: (() => any) | undefined;
        "onBefore-close"?: ((_reason: "cancel" | "close") => any) | undefined;
        "onDirty-change"?: ((_value: boolean) => any) | undefined;
        "onConfirm-error"?: ((_error?: any) => any) | undefined;
    }>, {
        open: () => void;
        close: () => Promise<void>;
        cancel: () => Promise<void>;
        submit: () => Promise<void>;
        validate: () => Promise<boolean>;
        resetForm: () => void;
        scrollToFirstError: () => void;
        prev: () => void;
        next: () => Promise<void>;
        toggleFullscreen: () => import("@zxio/zxui/es/keybindings/core").ActionAdmission<void>;
        isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        isDirty: boolean;
        isSubmitting: boolean;
        currentStep: number;
        isFirstStep: boolean;
        isLastStep: boolean;
        resetSubmitting: () => void;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        next: (params: import("@zxio/constants").StepEventParams) => void;
        prev: (params: import("@zxio/constants").StepEventParams) => void;
        open: () => void;
        "update:modelValue": (val: boolean) => void;
        cancel: () => void;
        continue: () => void;
        close: () => void;
        back: () => void;
        confirm: (_result?: any) => void;
        closed: () => void;
        saveStart: (_done: () => void, _fail: (error?: any) => void) => void;
        saveSuccess: (_data?: any) => void;
        saveError: (_error: any) => void;
        buttonClick: (_buttonKey: string) => void;
        "update:currentStep": (val: number) => void;
        "update:current-step": (val: number) => void;
        "update:fullscreen": (_value: boolean) => void;
        "fullscreen-change": (_value: boolean) => void;
        opened: () => void;
        openAutoFocus: () => void;
        closeAutoFocus: () => void;
        "before-close": (_reason: "cancel" | "close") => void;
        "dirty-change": (_value: boolean) => void;
        "confirm-error": (_error?: any) => void;
    }, string, {
        readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly title: string;
        readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
        readonly height: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly width: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly debounce: number;
        readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly throttle: number;
        readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly appendTo: import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
        readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
        readonly modalClass: string;
        readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly confirm: import("@zxio/zxui").DialogConfirm;
        readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
        readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly currentStep: number;
        readonly totalSteps: number;
        readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
        readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
        readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
        readonly buttons: import("@zxio/constants").FooterButtonConfig[];
        readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
            (): "right" | "left" | "center";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "right" | "left" | "center") | (() => "right" | "left" | "center") | {
            (): "right" | "left" | "center";
            new (): any;
            readonly prototype: any;
        }) | null)[], "right" | "left" | "center", unknown>;
        readonly beforeSave: () => boolean | Promise<boolean>;
        readonly afterSave: (success: boolean) => void;
        readonly formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly loadingText: string;
        readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly subtitle: string;
        readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DialogDirtyGuard;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DialogDirtyGuard;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
            (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | {
            (): import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly stepFields: string[][];
        readonly validateStep: (step: number) => boolean | Promise<boolean>;
        readonly titleTag: string;
        readonly titleTagColor: string;
        readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
        readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
        readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly loadingBackground: string;
        readonly okText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
        readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
        readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly dialogStyle: import("vue").CSSProperties;
        readonly handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly formModel: Record<string, any>;
        readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollErrorOffset: number;
        readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "auto" | "none") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        }) | null)[], "auto" | "none", unknown>;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: import("@zxio/zxui").DialogSlots;
    }>;
    ZxInput: __ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "", boolean>;
            tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "right", boolean>;
            tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "hover", boolean>;
            formatter: {
                type: import("vue").PropType<(value: string) => string>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            parser: {
                type: import("vue").PropType<(value: string) => string>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            inputmode: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | (((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined)) | null)[], unknown, unknown, undefined, boolean>;
            name: StringConstructor;
            ariaLabel: StringConstructor;
            id: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            disabled: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            modelValue: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | (((new (...args: any[]) => string | number) | (() => string | number | null | undefined)) | null)[], unknown, unknown, "", boolean>;
            modelModifiers: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => import("element-plus").InputModelModifiers) | (() => import("element-plus").InputModelModifiers) | (((new (...args: any[]) => import("element-plus").InputModelModifiers) | (() => import("element-plus").InputModelModifiers)) | null)[], unknown, unknown, () => {}, boolean>;
            maxlength: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            minlength: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            type: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | (((new (...args: any[]) => string) | (() => import("element-plus").InputType)) | null)[], unknown, unknown, "text", boolean>;
            resize: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "horizontal" | "vertical" | "none" | "both", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            autosize: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => boolean | {
                minRows?: number;
                maxRows?: number;
            }) | (() => import("element-plus").InputAutoSize) | ((new (...args: any[]) => boolean | {
                minRows?: number;
                maxRows?: number;
            }) | (() => import("element-plus").InputAutoSize) | null)[], unknown, unknown, false, boolean>;
            autocomplete: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | ((new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | null)[], unknown, unknown, "off", boolean>;
            placeholder: {
                readonly type: import("vue").PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            form: {
                readonly type: import("vue").PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly: BooleanConstructor;
            clearable: BooleanConstructor;
            clearIcon: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, boolean>;
            showPassword: BooleanConstructor;
            showWordLimit: BooleanConstructor;
            wordLimitPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "inside" | "outside", unknown, "inside", boolean>;
            suffixIcon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            prefixIcon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            containerRole: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
            validateEvent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            inputStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | null)[], unknown, unknown, () => import("element-plus/es/utils/typescript.mjs").Mutable<{}>, boolean>;
            countGraphemes: {
                readonly type: import("vue").PropType<(value: string) => number>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            autofocus: BooleanConstructor;
            rows: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 2, boolean>;
        }>> & Readonly<{
            onInput?: ((value: string) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            focus: () => void | undefined;
            blur: () => void | undefined;
            select: () => void | undefined;
            clear: (evt?: MouseEvent | undefined) => void | undefined;
            input: import("vue").ComputedRef<HTMLInputElement | undefined>;
            textarea: import("vue").ComputedRef<HTMLTextAreaElement | undefined>;
            textareaStyle: import("vue").ComputedRef<import("vue").StyleValue>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            input: (value: string) => void;
            focus: (evt: FocusEvent) => void;
            clear: (evt: MouseEvent | undefined) => void;
            "update:modelValue": (value: string) => void;
            change: (value: string, evt?: Event | undefined) => void;
            blur: (evt: FocusEvent) => void;
            compositionend: (evt: CompositionEvent) => void;
            compositionstart: (evt: CompositionEvent) => void;
            compositionupdate: (evt: CompositionEvent) => void;
            keydown: (evt: Event | KeyboardEvent) => void;
            mouseenter: (evt: MouseEvent) => void;
            mouseleave: (evt: MouseEvent) => void;
        }, import("vue").PublicProps, {
            type: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType) | null)[], unknown, unknown>;
            id: string;
            disabled: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            autofocus: boolean;
            modelValue: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined) | null)[], unknown, unknown>;
            clearable: boolean;
            modelModifiers: import("element-plus").InputModelModifiers;
            autosize: import("element-plus").InputAutoSize;
            autocomplete: AutoFill;
            readonly: boolean;
            clearIcon: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | null)[], unknown, unknown>;
            showPassword: boolean;
            showWordLimit: boolean;
            wordLimitPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
            containerRole: string;
            validateEvent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            inputStyle: import("vue").StyleValue;
            rows: number;
            inputmode: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
            tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "", boolean>;
            tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "right", boolean>;
            tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "hover", boolean>;
            formatter: {
                type: import("vue").PropType<(value: string) => string>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            parser: {
                type: import("vue").PropType<(value: string) => string>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            inputmode: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | (((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined)) | null)[], unknown, unknown, undefined, boolean>;
            name: StringConstructor;
            ariaLabel: StringConstructor;
            id: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            disabled: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            modelValue: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | (((new (...args: any[]) => string | number) | (() => string | number | null | undefined)) | null)[], unknown, unknown, "", boolean>;
            modelModifiers: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => import("element-plus").InputModelModifiers) | (() => import("element-plus").InputModelModifiers) | (((new (...args: any[]) => import("element-plus").InputModelModifiers) | (() => import("element-plus").InputModelModifiers)) | null)[], unknown, unknown, () => {}, boolean>;
            maxlength: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            minlength: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            type: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | (((new (...args: any[]) => string) | (() => import("element-plus").InputType)) | null)[], unknown, unknown, "text", boolean>;
            resize: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "horizontal" | "vertical" | "none" | "both", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            autosize: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => boolean | {
                minRows?: number;
                maxRows?: number;
            }) | (() => import("element-plus").InputAutoSize) | ((new (...args: any[]) => boolean | {
                minRows?: number;
                maxRows?: number;
            }) | (() => import("element-plus").InputAutoSize) | null)[], unknown, unknown, false, boolean>;
            autocomplete: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | ((new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | null)[], unknown, unknown, "off", boolean>;
            placeholder: {
                readonly type: import("vue").PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            form: {
                readonly type: import("vue").PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly: BooleanConstructor;
            clearable: BooleanConstructor;
            clearIcon: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, boolean>;
            showPassword: BooleanConstructor;
            showWordLimit: BooleanConstructor;
            wordLimitPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "inside" | "outside", unknown, "inside", boolean>;
            suffixIcon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            prefixIcon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            containerRole: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
            validateEvent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            inputStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | null)[], unknown, unknown, () => import("element-plus/es/utils/typescript.mjs").Mutable<{}>, boolean>;
            countGraphemes: {
                readonly type: import("vue").PropType<(value: string) => number>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            autofocus: BooleanConstructor;
            rows: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 2, boolean>;
        }>> & Readonly<{
            onInput?: ((value: string) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            focus: () => void | undefined;
            blur: () => void | undefined;
            select: () => void | undefined;
            clear: (evt?: MouseEvent | undefined) => void | undefined;
            input: import("vue").ComputedRef<HTMLInputElement | undefined>;
            textarea: import("vue").ComputedRef<HTMLTextAreaElement | undefined>;
            textareaStyle: import("vue").ComputedRef<import("vue").StyleValue>;
        }, {}, {}, {}, {
            type: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType) | null)[], unknown, unknown>;
            id: string;
            disabled: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
                (): string | import("@zxio/zxui").InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            autofocus: boolean;
            modelValue: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined) | null)[], unknown, unknown>;
            clearable: boolean;
            modelModifiers: import("element-plus").InputModelModifiers;
            autosize: import("element-plus").InputAutoSize;
            autocomplete: AutoFill;
            readonly: boolean;
            clearIcon: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | null)[], unknown, unknown>;
            showPassword: boolean;
            showWordLimit: boolean;
            wordLimitPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
            containerRole: string;
            validateEvent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            inputStyle: import("vue").StyleValue;
            rows: number;
            inputmode: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
            tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
                (): import("@zxio/utils").Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
                (): import("@zxio/zxui").InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
            (): string | import("@zxio/zxui").InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
            (): string | import("@zxio/zxui").InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
            (): import("@zxio/utils").Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
            (): import("@zxio/utils").Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "right", boolean>;
        tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
            (): import("@zxio/zxui").InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
            (): import("@zxio/zxui").InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "hover", boolean>;
        formatter: {
            type: import("vue").PropType<(value: string) => string>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        parser: {
            type: import("vue").PropType<(value: string) => string>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        inputmode: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | (((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined)) | null)[], unknown, unknown, undefined, boolean>;
        name: StringConstructor;
        ariaLabel: StringConstructor;
        id: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        disabled: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        modelValue: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | (((new (...args: any[]) => string | number) | (() => string | number | null | undefined)) | null)[], unknown, unknown, "", boolean>;
        modelModifiers: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => import("element-plus").InputModelModifiers) | (() => import("element-plus").InputModelModifiers) | (((new (...args: any[]) => import("element-plus").InputModelModifiers) | (() => import("element-plus").InputModelModifiers)) | null)[], unknown, unknown, () => {}, boolean>;
        maxlength: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        minlength: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        type: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | (((new (...args: any[]) => string) | (() => import("element-plus").InputType)) | null)[], unknown, unknown, "text", boolean>;
        resize: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "horizontal" | "vertical" | "none" | "both", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        autosize: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => boolean | {
            minRows?: number;
            maxRows?: number;
        }) | (() => import("element-plus").InputAutoSize) | (((new (...args: any[]) => boolean | {
            minRows?: number;
            maxRows?: number;
        }) | (() => import("element-plus").InputAutoSize)) | null)[], unknown, unknown, false, boolean>;
        autocomplete: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | (((new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill)) | null)[], unknown, unknown, "off", boolean>;
        placeholder: {
            readonly type: import("vue").PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        form: {
            readonly type: import("vue").PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly: BooleanConstructor;
        clearable: BooleanConstructor;
        clearIcon: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, boolean>;
        showPassword: BooleanConstructor;
        showWordLimit: BooleanConstructor;
        wordLimitPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "inside" | "outside", unknown, "inside", boolean>;
        suffixIcon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        prefixIcon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        containerRole: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
        validateEvent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        inputStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, () => import("element-plus/es/utils/typescript.mjs").Mutable<{}>, boolean>;
        countGraphemes: {
            readonly type: import("vue").PropType<(value: string) => number>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        autofocus: BooleanConstructor;
        rows: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 2, boolean>;
    }>> & Readonly<{
        onInput?: ((value: string) => any) | undefined;
        onFocus?: ((evt: FocusEvent) => any) | undefined;
        onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
        onBlur?: ((evt: FocusEvent) => any) | undefined;
        onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
        onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
        onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
        onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
        onMouseenter?: ((evt: MouseEvent) => any) | undefined;
        onMouseleave?: ((evt: MouseEvent) => any) | undefined;
    }>, {
        focus: () => void | undefined;
        blur: () => void | undefined;
        select: () => void | undefined;
        clear: (evt?: MouseEvent | undefined) => void | undefined;
        input: import("vue").ComputedRef<HTMLInputElement | undefined>;
        textarea: import("vue").ComputedRef<HTMLTextAreaElement | undefined>;
        textareaStyle: import("vue").ComputedRef<import("vue").StyleValue>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        input: (value: string) => void;
        focus: (evt: FocusEvent) => void;
        clear: (evt: MouseEvent | undefined) => void;
        "update:modelValue": (value: string) => void;
        change: (value: string, evt?: Event | undefined) => void;
        blur: (evt: FocusEvent) => void;
        compositionend: (evt: CompositionEvent) => void;
        compositionstart: (evt: CompositionEvent) => void;
        compositionupdate: (evt: CompositionEvent) => void;
        keydown: (evt: Event | KeyboardEvent) => void;
        mouseenter: (evt: MouseEvent) => void;
        mouseleave: (evt: MouseEvent) => void;
    }, string, {
        type: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType) | null)[], unknown, unknown>;
        id: string;
        disabled: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
            (): string | import("@zxio/zxui").InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | {
            (): string | import("@zxio/zxui").InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        autofocus: boolean;
        modelValue: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined) | null)[], unknown, unknown>;
        clearable: boolean;
        modelModifiers: import("element-plus").InputModelModifiers;
        autosize: import("element-plus").InputAutoSize;
        autocomplete: AutoFill;
        readonly: boolean;
        clearIcon: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | null)[], unknown, unknown>;
        showPassword: boolean;
        showWordLimit: boolean;
        wordLimitPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
        containerRole: string;
        validateEvent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        inputStyle: import("vue").StyleValue;
        rows: number;
        inputmode: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
        tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
            (): import("@zxio/utils").Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string) | (() => import("@zxio/utils").Placement) | {
            (): import("@zxio/utils").Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
            (): import("@zxio/zxui").InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "focus" | "click" | "contextmenu" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | {
            (): import("@zxio/zxui").InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            prefix?(props: Record<string, unknown>): unknown;
            suffix?(props: Record<string, unknown>): unknown;
            prepend?(props: Record<string, unknown>): unknown;
            append?(props: Record<string, unknown>): unknown;
        };
    }>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
