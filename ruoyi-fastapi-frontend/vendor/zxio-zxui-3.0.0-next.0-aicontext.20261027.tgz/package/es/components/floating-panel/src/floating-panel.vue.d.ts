declare const _default: __ZXUI_WithSlots<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        ariaLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        collapsed: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        defaultCollapsed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        headerClickable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        customClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        position: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        collapsedSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        collapsedShape: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        zIndex: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
        expandIcon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        collapseIconProp: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        showCollapseBtn: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showStatus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        completed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        error: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        completedText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        errorText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        expandTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        collapseTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        closeTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        autoExpand: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        completedDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        transitionDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        autoDirection: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        positionStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        anchor: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        offset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, number, boolean>;
        shift: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        flip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        shiftPadding: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        keyboardStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        resizable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        minSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | (() => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | {
            (): import("@zxio/zxui").ZxFloatingPanelResizeEvent;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | (() => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | {
            (): import("@zxio/zxui").ZxFloatingPanelResizeEvent;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {
            width: number;
            height: number;
        }, boolean>;
        teleport: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        portalTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        responsive: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
            (): Record<string, unknown>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
            (): Record<string, unknown>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onCollapse?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((visible: boolean) => any) | undefined;
        onClose?: (() => any) | undefined;
        onToggle?: ((collapsed: boolean) => any) | undefined;
        "onResize-end"?: ((event: import("@zxio/zxui").ZxFloatingPanelResizeEvent) => any) | undefined;
        onExpand?: (() => any) | undefined;
        "onUpdate:collapsed"?: ((collapsed: boolean) => any) | undefined;
        "onDrag-start"?: ((event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => any) | undefined;
        "onDrag-end"?: ((event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => any) | undefined;
    }>, {
        isCollapsed: import("vue").ComputedRef<import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>>;
        visible: import("vue").ComputedRef<boolean>;
        toggleCollapse: () => void;
        expand: () => void;
        collapse: () => void;
        open: () => void;
        close: () => void;
        setPosition: (x: number, y: number) => void;
        resetPosition: () => void;
        setSize: (size: Partial<import("@zxio/zxui").ZxFloatingPanelResizeEvent>) => void;
        resetSize: () => void;
        getPosition: () => import("@zxio/zxui").ZxFloatingPanelPoint;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        collapse: () => void;
        "update:modelValue": (visible: boolean) => void;
        close: () => void;
        toggle: (collapsed: boolean) => void;
        "resize-end": (event: import("@zxio/zxui").ZxFloatingPanelResizeEvent) => void;
        expand: () => void;
        "update:collapsed": (collapsed: boolean) => void;
        "drag-start": (event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => void;
        "drag-end": (event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => void;
    }, import("vue").PublicProps, {
        anchor: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        shift: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        title: string;
        size: Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        position: Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        transitionDuration: number;
        zIndex: number;
        offset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        flip: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        ariaLabel: string;
        error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        customClass: string;
        showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        portalTarget: import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
        draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loadingText: string;
        titleTag: string;
        resizable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        minSize: import("@zxio/zxui").ZxFloatingPanelResizeEvent;
        errorText: string;
        completed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        collapsed: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        defaultCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        headerClickable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        collapsedSize: Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        collapsedShape: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        expandIcon: import("@zxio/zxui").ZxFloatingPanelIcon;
        collapseIconProp: import("@zxio/zxui").ZxFloatingPanelIcon;
        showCollapseBtn: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showStatus: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        completedText: string;
        expandTooltip: string;
        collapseTooltip: string;
        closeTooltip: string;
        autoExpand: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        completedDuration: number;
        autoDirection: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        positionStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        shiftPadding: number;
        keyboardStep: number;
        teleport: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        responsive: Record<string, unknown>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        ariaLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        collapsed: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        defaultCollapsed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        headerClickable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        customClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        position: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        collapsedSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
            (): Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
        collapsedShape: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        zIndex: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
        expandIcon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        collapseIconProp: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
            (): import("@zxio/zxui").ZxFloatingPanelIcon;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        showCollapseBtn: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showStatus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        completed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        error: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        completedText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        errorText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        expandTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        collapseTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        closeTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        autoExpand: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        completedDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        transitionDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        autoDirection: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        positionStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        anchor: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        offset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, number, boolean>;
        shift: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        flip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        shiftPadding: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        keyboardStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        resizable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        minSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | (() => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | {
            (): import("@zxio/zxui").ZxFloatingPanelResizeEvent;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | (() => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | {
            (): import("@zxio/zxui").ZxFloatingPanelResizeEvent;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {
            width: number;
            height: number;
        }, boolean>;
        teleport: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        portalTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        responsive: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
            (): Record<string, unknown>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
            (): Record<string, unknown>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onCollapse?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((visible: boolean) => any) | undefined;
        onClose?: (() => any) | undefined;
        onToggle?: ((collapsed: boolean) => any) | undefined;
        "onResize-end"?: ((event: import("@zxio/zxui").ZxFloatingPanelResizeEvent) => any) | undefined;
        onExpand?: (() => any) | undefined;
        "onUpdate:collapsed"?: ((collapsed: boolean) => any) | undefined;
        "onDrag-start"?: ((event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => any) | undefined;
        "onDrag-end"?: ((event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => any) | undefined;
    }>, {
        isCollapsed: import("vue").ComputedRef<import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>>;
        visible: import("vue").ComputedRef<boolean>;
        toggleCollapse: () => void;
        expand: () => void;
        collapse: () => void;
        open: () => void;
        close: () => void;
        setPosition: (x: number, y: number) => void;
        resetPosition: () => void;
        setSize: (size: Partial<import("@zxio/zxui").ZxFloatingPanelResizeEvent>) => void;
        resetSize: () => void;
        getPosition: () => import("@zxio/zxui").ZxFloatingPanelPoint;
    }, {}, {}, {}, {
        anchor: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
            (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        shift: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        title: string;
        size: Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        position: Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        transitionDuration: number;
        zIndex: number;
        offset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
            (): number | [number, number];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        flip: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        ariaLabel: string;
        error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        customClass: string;
        showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
            (): import("@floating-ui/dom").Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        portalTarget: import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
        draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loadingText: string;
        titleTag: string;
        resizable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        minSize: import("@zxio/zxui").ZxFloatingPanelResizeEvent;
        errorText: string;
        completed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        collapsed: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
            (): boolean | undefined;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        defaultCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        headerClickable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        collapsedSize: Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        collapsedShape: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
            (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        expandIcon: import("@zxio/zxui").ZxFloatingPanelIcon;
        collapseIconProp: import("@zxio/zxui").ZxFloatingPanelIcon;
        showCollapseBtn: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showStatus: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        completedText: string;
        expandTooltip: string;
        collapseTooltip: string;
        closeTooltip: string;
        autoExpand: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        completedDuration: number;
        autoDirection: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        positionStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
            (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        shiftPadding: number;
        keyboardStep: number;
        teleport: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        responsive: Record<string, unknown>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    ariaLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    collapsed: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    defaultCollapsed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    headerClickable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    customClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    position: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    collapsedSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    collapsedShape: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
        (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
        (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    zIndex: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    expandIcon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
        (): import("@zxio/zxui").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
        (): import("@zxio/zxui").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    collapseIconProp: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
        (): import("@zxio/zxui").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelIcon & {}) | (() => import("@zxio/zxui").ZxFloatingPanelIcon) | {
        (): import("@zxio/zxui").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    showCollapseBtn: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showStatus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    completed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    error: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    completedText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    errorText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    expandTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    collapseTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    closeTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    autoExpand: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    completedDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    transitionDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    autoDirection: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    positionStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
        (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
        (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    anchor: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
        (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
        (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    offset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, number, boolean>;
    shift: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    flip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    shiftPadding: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    keyboardStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    resizable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    minSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | (() => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | {
        (): import("@zxio/zxui").ZxFloatingPanelResizeEvent;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | (() => import("@zxio/zxui").ZxFloatingPanelResizeEvent) | {
        (): import("@zxio/zxui").ZxFloatingPanelResizeEvent;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {
        width: number;
        height: number;
    }, boolean>;
    teleport: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    portalTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
        (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget) | {
        (): import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    responsive: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
        (): Record<string, unknown>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
        (): Record<string, unknown>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onCollapse?: (() => any) | undefined;
    "onUpdate:modelValue"?: ((visible: boolean) => any) | undefined;
    onClose?: (() => any) | undefined;
    onToggle?: ((collapsed: boolean) => any) | undefined;
    "onResize-end"?: ((event: import("@zxio/zxui").ZxFloatingPanelResizeEvent) => any) | undefined;
    onExpand?: (() => any) | undefined;
    "onUpdate:collapsed"?: ((collapsed: boolean) => any) | undefined;
    "onDrag-start"?: ((event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => any) | undefined;
    "onDrag-end"?: ((event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => any) | undefined;
}>, {
    isCollapsed: import("vue").ComputedRef<import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>>;
    visible: import("vue").ComputedRef<boolean>;
    toggleCollapse: () => void;
    expand: () => void;
    collapse: () => void;
    open: () => void;
    close: () => void;
    setPosition: (x: number, y: number) => void;
    resetPosition: () => void;
    setSize: (size: Partial<import("@zxio/zxui").ZxFloatingPanelResizeEvent>) => void;
    resetSize: () => void;
    getPosition: () => import("@zxio/zxui").ZxFloatingPanelPoint;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    collapse: () => void;
    "update:modelValue": (visible: boolean) => void;
    close: () => void;
    toggle: (collapsed: boolean) => void;
    "resize-end": (event: import("@zxio/zxui").ZxFloatingPanelResizeEvent) => void;
    expand: () => void;
    "update:collapsed": (collapsed: boolean) => void;
    "drag-start": (event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => void;
    "drag-end": (event: import("@zxio/zxui").ZxFloatingPanelDragEvent) => void;
}, string, {
    anchor: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
        (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null, import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null> | (() => import("@zxio/zxui").ZxFloatingPanelAnchorTarget | null)) | (() => import("@zxio/zxui").ZxFloatingPanelAnchor | null) | {
        (): import("@zxio/zxui").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    shift: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    title: string;
    size: Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
    position: Partial<Record<"top" | "bottom" | "right" | "left", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
    transitionDuration: number;
    zIndex: number;
    offset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    flip: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    ariaLabel: string;
    error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    customClass: string;
    showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    portalTarget: import("@zxio/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loadingText: string;
    titleTag: string;
    resizable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    minSize: import("@zxio/zxui").ZxFloatingPanelResizeEvent;
    errorText: string;
    completed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapsed: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    defaultCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    headerClickable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapsedSize: Partial<Record<"height" | "width", import("@zxio/zxui").ZxFloatingPanelCssLength>>;
    collapsedShape: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
        (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("@zxio/zxui").ZxFloatingPanelCollapsedShape) | {
        (): import("@zxio/zxui").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    expandIcon: import("@zxio/zxui").ZxFloatingPanelIcon;
    collapseIconProp: import("@zxio/zxui").ZxFloatingPanelIcon;
    showCollapseBtn: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showStatus: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completedText: string;
    expandTooltip: string;
    collapseTooltip: string;
    closeTooltip: string;
    autoExpand: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completedDuration: number;
    autoDirection: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    positionStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
        (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "free" | "anchored") | (() => import("@zxio/zxui").ZxFloatingPanelPositionStrategy) | {
        (): import("@zxio/zxui").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    shiftPadding: number;
    keyboardStep: number;
    teleport: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    responsive: Record<string, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
    $slots: {
        header?: (props: {}) => any;
    } & {
        status?: (props: {
            loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            completed: boolean;
            error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        }) => any;
    } & {
        actions?: (props: {
            isCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            toggle: () => void;
            close: () => void;
        }) => any;
    } & {
        default?: (props: {
            isCollapsed: false;
            toggleCollapse: () => void;
            close: () => void;
        }) => any;
    };
}>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
