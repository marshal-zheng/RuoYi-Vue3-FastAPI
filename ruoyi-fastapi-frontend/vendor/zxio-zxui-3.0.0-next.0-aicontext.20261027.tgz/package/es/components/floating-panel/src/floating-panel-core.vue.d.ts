import { type ZxFloatingPanelAnchorTarget, type ZxFloatingPanelCssLength, type ZxFloatingPanelDragEvent, type ZxFloatingPanelPoint, type ZxFloatingPanelResizeEvent } from './props';
import type { ThemeRequiredPortalTarget } from '../../theme-provider';
declare var __VLS_5: {}, __VLS_11: {
    loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completed: boolean;
    error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, __VLS_22: {
    isCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    toggle: () => void;
    close: () => void;
}, __VLS_34: {
    isCollapsed: false;
    toggleCollapse: () => void;
    close: () => void;
};
type __VLS_Slots = {} & {
    header?: (props: typeof __VLS_5) => any;
} & {
    status?: (props: typeof __VLS_11) => any;
} & {
    actions?: (props: typeof __VLS_22) => any;
} & {
    default?: (props: typeof __VLS_34) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    ariaLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    collapsed: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    defaultCollapsed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    headerClickable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    customClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    position: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    collapsedSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    collapsedShape: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | {
        (): import("./props").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | {
        (): import("./props").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    zIndex: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    expandIcon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    collapseIconProp: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    showCollapseBtn: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showStatus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    completed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    error: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    completedText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    errorText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    expandTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    collapseTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    closeTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    autoExpand: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    completedDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    transitionDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    autoDirection: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    positionStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | {
        (): import("./props").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | {
        (): import("./props").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    anchor: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | {
        (): import("./props").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | {
        (): import("./props").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    offset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, number, boolean>;
    shift: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    flip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    shiftPadding: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    keyboardStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    resizable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    minSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => ZxFloatingPanelResizeEvent) | (() => ZxFloatingPanelResizeEvent) | {
        (): ZxFloatingPanelResizeEvent;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => ZxFloatingPanelResizeEvent) | (() => ZxFloatingPanelResizeEvent) | {
        (): ZxFloatingPanelResizeEvent;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {
        width: number;
        height: number;
    }, boolean>;
    teleport: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    portalTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    responsive: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
        (): Record<string, unknown>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
        (): Record<string, unknown>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
}>, {
    isCollapsed: import("vue").ComputedRef<import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>>;
    visible: import("vue").ComputedRef<boolean>;
    toggleCollapse: () => void;
    expand: () => void;
    collapse: () => void;
    open: () => void;
    close: () => void;
    setPosition: (x: number, y: number) => void;
    resetPosition: () => void;
    setSize: (size: Partial<ZxFloatingPanelResizeEvent>) => void;
    resetSize: () => void;
    getPosition: () => ZxFloatingPanelPoint;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    collapse: () => void;
    "update:modelValue": (visible: boolean) => void;
    close: () => void;
    toggle: (collapsed: boolean) => void;
    "resize-end": (event: ZxFloatingPanelResizeEvent) => void;
    expand: () => void;
    "update:collapsed": (collapsed: boolean) => void;
    "drag-start": (event: ZxFloatingPanelDragEvent) => void;
    "drag-end": (event: ZxFloatingPanelDragEvent) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    ariaLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    collapsed: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    defaultCollapsed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    headerClickable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    customClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    position: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    collapsedSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | (() => Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>) | {
        (): Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    collapsedShape: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | {
        (): import("./props").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | {
        (): import("./props").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    zIndex: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    expandIcon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    collapseIconProp: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").ZxFloatingPanelIcon & {}) | (() => import("./props").ZxFloatingPanelIcon) | {
        (): import("./props").ZxFloatingPanelIcon;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    showCollapseBtn: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showStatus: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    completed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    error: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    completedText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    errorText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    expandTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    collapseTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    closeTooltip: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    autoExpand: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    completedDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    transitionDuration: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    autoDirection: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    positionStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | {
        (): import("./props").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | {
        (): import("./props").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    anchor: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | {
        (): import("./props").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | {
        (): import("./props").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    offset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, number, boolean>;
    shift: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    flip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    shiftPadding: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    keyboardStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    resizable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    minSize: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => ZxFloatingPanelResizeEvent) | (() => ZxFloatingPanelResizeEvent) | {
        (): ZxFloatingPanelResizeEvent;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => ZxFloatingPanelResizeEvent) | (() => ZxFloatingPanelResizeEvent) | {
        (): ZxFloatingPanelResizeEvent;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {
        width: number;
        height: number;
    }, boolean>;
    teleport: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    portalTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Document | HTMLElement | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    responsive: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
        (): Record<string, unknown>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Record<string, unknown>) | (() => Record<string, unknown>) | {
        (): Record<string, unknown>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onCollapse?: (() => any) | undefined;
    "onUpdate:modelValue"?: ((visible: boolean) => any) | undefined;
    onClose?: (() => any) | undefined;
    onToggle?: ((collapsed: boolean) => any) | undefined;
    "onResize-end"?: ((event: ZxFloatingPanelResizeEvent) => any) | undefined;
    onExpand?: (() => any) | undefined;
    "onUpdate:collapsed"?: ((collapsed: boolean) => any) | undefined;
    "onDrag-start"?: ((event: ZxFloatingPanelDragEvent) => any) | undefined;
    "onDrag-end"?: ((event: ZxFloatingPanelDragEvent) => any) | undefined;
}>, {
    anchor: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | {
        (): import("./props").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | {
        (): import("./props").ZxFloatingPanelAnchor | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    shift: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    title: string;
    size: Partial<Record<"height" | "maxHeight" | "maxWidth" | "minHeight" | "minWidth" | "width", ZxFloatingPanelCssLength>>;
    position: Partial<Record<"top" | "bottom" | "right" | "left", ZxFloatingPanelCssLength>>;
    transitionDuration: number;
    zIndex: number;
    offset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | {
        (): number | [number, number];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    flip: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    ariaLabel: string;
    error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    customClass: string;
    showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "top" | "top-start" | "top-end" | "bottom" | "bottom-start" | "bottom-end" | "right" | "right-start" | "right-end" | "left" | "left-start" | "left-end") | (() => import("@floating-ui/dom").Placement) | {
        (): import("@floating-ui/dom").Placement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    portalTarget: ThemeRequiredPortalTarget;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loadingText: string;
    titleTag: string;
    resizable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    minSize: ZxFloatingPanelResizeEvent;
    errorText: string;
    completed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapsed: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean) | (() => boolean | undefined) | {
        (): boolean | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    defaultCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    headerClickable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapsedSize: Partial<Record<"height" | "width", ZxFloatingPanelCssLength>>;
    collapsedShape: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | {
        (): import("./props").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | {
        (): import("./props").ZxFloatingPanelCollapsedShape;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    expandIcon: import("./props").ZxFloatingPanelIcon;
    collapseIconProp: import("./props").ZxFloatingPanelIcon;
    showCollapseBtn: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showStatus: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completedText: string;
    expandTooltip: string;
    collapseTooltip: string;
    closeTooltip: string;
    autoExpand: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completedDuration: number;
    autoDirection: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    positionStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | {
        (): import("./props").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | {
        (): import("./props").ZxFloatingPanelPositionStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    shiftPadding: number;
    keyboardStep: number;
    teleport: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    responsive: Record<string, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
