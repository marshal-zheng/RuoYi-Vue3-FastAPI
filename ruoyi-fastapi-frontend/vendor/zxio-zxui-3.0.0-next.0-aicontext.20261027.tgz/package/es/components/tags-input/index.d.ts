export declare const ZxTagsInput: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
    readonly loadTags: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly suggestions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly transform: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, (list: any) => any, boolean>;
    readonly transformSuggestions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, (list: any) => any, boolean>;
    readonly valueKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "value", boolean>;
    readonly labelKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "label", boolean>;
    readonly suggestionValueKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "value", boolean>;
    readonly suggestionLabelKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "label", boolean>;
    readonly showSuggestions: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly maxSuggestions: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly tagsLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "已选标签", boolean>;
    readonly inputLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "添加标签", boolean>;
    readonly emptyText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "暂无标签", boolean>;
    readonly showDivider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "请输入标签，按回车添加", boolean>;
    readonly maxCount: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly maxLength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 20, boolean>;
    readonly minLength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly allowDuplicates: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly readonly: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "default" | "large", unknown, undefined, boolean>;
    readonly tagType: import("@zxio/shared").EpPropFinalized<StringConstructor, "primary" | "success" | "warning" | "info" | "danger", unknown, undefined, boolean>;
    readonly tagEffect: import("@zxio/shared").EpPropFinalized<StringConstructor, "dark" | "light" | "plain", unknown, "light", boolean>;
    readonly showAddButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly addButtonText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "添加", boolean>;
    readonly showWordLimit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showTip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly validator: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
    readonly addOnBlur: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly trimValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly beforeAdd: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly beforeRemove: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly inputPosition: import("@zxio/shared").EpPropFinalized<StringConstructor, "top" | "bottom", unknown, "bottom", boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    size: import("vue").ComputedRef<"" | "small" | "default" | "large">;
    boundaryAttrs: () => {
        role: string;
        class?: import("vue").ClassValue;
        style?: import("vue").StyleValue;
    } | {
        class: import("vue").ClassValue;
        style: import("vue").StyleValue;
    };
    controlAttrs: () => {
        'aria-label': string;
    };
    focus: () => any;
    blur: () => any;
    disabled: import("vue").ComputedRef<boolean>;
    innerModelValue: import("vue").Ref<string[], string[]>;
    inputValue: import("vue").Ref<string, string>;
    inputRef: import("vue").Ref<any, any>;
    reachedMaxCount: import("vue").ComputedRef<boolean>;
    errorMessage: import("vue").ComputedRef<string>;
    tipMessage: import("vue").ComputedRef<string>;
    hasTags: import("vue").ComputedRef<boolean>;
    showTagsHeader: import("vue").ComputedRef<boolean>;
    showInputHeader: import("vue").ComputedRef<boolean>;
    inputDisabled: import("vue").ComputedRef<boolean>;
    addButtonDisabled: import("vue").ComputedRef<boolean>;
    isAdding: import("vue").Ref<boolean, boolean>;
    isRemoving: (index: number) => boolean;
    canRemove: (index: number) => boolean;
    addTag: () => Promise<void>;
    removeTag: (index: number) => Promise<void>;
    handleBackspace: () => void;
    handleBlur: (evt: FocusEvent) => void;
    handleFocus: (evt: FocusEvent) => void;
    handleTagClick: (tag: string, index: number) => void;
    handleAdd: () => void;
    handleRemove: (index: number) => void;
    handleInputContainerClick: () => void;
    handleSuggestionClick: (option: any) => void;
    filteredSuggestions: import("vue").ComputedRef<any[]>;
    availableSuggestions: import("vue").Ref<any[], any[]>;
    suggestionsLoading: import("vue").Ref<boolean, boolean>;
    getTagLabel: (value: string) => string;
    suggestionValueKey: string;
    suggestionLabelKey: string;
    tagsLabel: string;
    inputLabel: string;
    emptyTagText: string;
    showDivider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    addButtonText: string;
    tagType: import("@zxio/shared").EpPropMergeType<StringConstructor, "primary" | "success" | "warning" | "info" | "danger", unknown> | undefined;
    tagEffect: import("@zxio/shared").EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
    inputPosition: import("@zxio/shared").EpPropMergeType<StringConstructor, "top" | "bottom", unknown>;
    reload: () => Promise<void>;
    loadTagsLoading: import("vue").Ref<boolean, boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (value: string[]) => boolean;
    change: (value: string[]) => boolean;
    add: (tag: string) => boolean;
    remove: (_tag: string, _index: number) => boolean;
    'add-cancel': (tag: string) => boolean;
    'remove-cancel': (tag: string, index: number) => boolean;
    'tag-click': (tag: string, index: number) => boolean;
    'suggestion-click': (_tag: any) => boolean;
    focus: (evt: FocusEvent) => boolean;
    blur: (evt: FocusEvent) => boolean;
    'input-change': (value: string) => boolean;
    'tags-loaded': (tags: any[]) => boolean;
    'suggestions-loaded': (tags: any[]) => boolean;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
    readonly loadTags: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly suggestions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly transform: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, (list: any) => any, boolean>;
    readonly transformSuggestions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (list: any) => any) | (() => (list: any) => any) | {
        (): (list: any) => any;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, (list: any) => any, boolean>;
    readonly valueKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "value", boolean>;
    readonly labelKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "label", boolean>;
    readonly suggestionValueKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "value", boolean>;
    readonly suggestionLabelKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "label", boolean>;
    readonly showSuggestions: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly maxSuggestions: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly tagsLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "已选标签", boolean>;
    readonly inputLabel: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "添加标签", boolean>;
    readonly emptyText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "暂无标签", boolean>;
    readonly showDivider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "请输入标签，按回车添加", boolean>;
    readonly maxCount: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly maxLength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 20, boolean>;
    readonly minLength: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly allowDuplicates: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly readonly: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "default" | "large", unknown, undefined, boolean>;
    readonly tagType: import("@zxio/shared").EpPropFinalized<StringConstructor, "primary" | "success" | "warning" | "info" | "danger", unknown, undefined, boolean>;
    readonly tagEffect: import("@zxio/shared").EpPropFinalized<StringConstructor, "dark" | "light" | "plain", unknown, "light", boolean>;
    readonly showAddButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly addButtonText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "添加", boolean>;
    readonly showWordLimit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showTip: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly validator: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, null, boolean>;
    readonly addOnBlur: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly trimValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly beforeAdd: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly beforeRemove: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | (() => (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>) | {
        (): (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly inputPosition: import("@zxio/shared").EpPropFinalized<StringConstructor, "top" | "bottom", unknown, "bottom", boolean>;
}>> & Readonly<{
    onFocus?: ((evt: FocusEvent) => any) | undefined;
    onAdd?: ((tag: string) => any) | undefined;
    onRemove?: ((_tag: string, _index: number) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string[]) => any) | undefined;
    onChange?: ((value: string[]) => any) | undefined;
    onBlur?: ((evt: FocusEvent) => any) | undefined;
    "onAdd-cancel"?: ((tag: string) => any) | undefined;
    "onRemove-cancel"?: ((tag: string, index: number) => any) | undefined;
    "onTag-click"?: ((tag: string, index: number) => any) | undefined;
    "onSuggestion-click"?: ((_tag: any) => any) | undefined;
    "onInput-change"?: ((value: string) => any) | undefined;
    "onTags-loaded"?: ((tags: any[]) => any) | undefined;
    "onSuggestions-loaded"?: ((tags: any[]) => any) | undefined;
}>, {
    readonly size: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "default" | "large", unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly transform: (list: any) => any;
    readonly validator: Function;
    readonly placeholder: string;
    readonly modelValue: unknown[];
    readonly readonly: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showWordLimit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly valueKey: string;
    readonly suggestions: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly labelKey: string;
    readonly tagType: import("@zxio/shared").EpPropMergeType<StringConstructor, "primary" | "success" | "warning" | "info" | "danger", unknown>;
    readonly tagEffect: import("@zxio/shared").EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
    readonly emptyText: string;
    readonly loadTags: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | (() => any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null)) | {
        (): any[] | ((keyword?: string) => any[] | Promise<any[]> | undefined | null);
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly transformSuggestions: (list: any) => any;
    readonly suggestionValueKey: string;
    readonly suggestionLabelKey: string;
    readonly showSuggestions: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly maxSuggestions: number;
    readonly tagsLabel: string;
    readonly inputLabel: string;
    readonly showDivider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly maxCount: number;
    readonly maxLength: number;
    readonly minLength: number;
    readonly allowDuplicates: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showAddButton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly addButtonText: string;
    readonly showTip: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly addOnBlur: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly trimValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly beforeAdd: (tag: string, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
    readonly beforeRemove: (tag: string, index: number, tags: string[]) => import("@zxio/utils").Awaitable<boolean | void>;
    readonly inputPosition: import("@zxio/shared").EpPropMergeType<StringConstructor, "top" | "bottom", unknown>;
}, {}, {
    ElTag: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").TagProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
            onClose?: ((evt: MouseEvent) => any) | undefined;
        }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
            close: (evt: MouseEvent) => void;
        }, import("vue").PublicProps, {
            type: "primary" | "success" | "info" | "warning" | "danger";
            effect: "dark" | "light" | "plain";
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").TagProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
            onClose?: ((evt: MouseEvent) => any) | undefined;
        }>, {}, {}, {}, {}, {
            type: "primary" | "success" | "info" | "warning" | "danger";
            effect: "dark" | "light" | "plain";
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").TagProps> & Readonly<{
        onClick?: ((evt: MouseEvent) => any) | undefined;
        onClose?: ((evt: MouseEvent) => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        click: (evt: MouseEvent) => void;
        close: (evt: MouseEvent) => void;
    }, string, {
        type: "primary" | "success" | "info" | "warning" | "danger";
        effect: "dark" | "light" | "plain";
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        };
    }>>;
    ElInput: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").InputProps> & Readonly<{
            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
            onInput?: ((value: string) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            input: import("vue").ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
            textarea: import("vue").ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
            ref: import("vue").ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
            textareaStyle: import("vue").ComputedRef<import("vue").StyleValue>;
            autosize: import("vue").Ref<import("element-plus").InputAutoSize | undefined, import("element-plus").InputAutoSize | undefined>;
            isComposing: import("vue").Ref<boolean, boolean>;
            passwordVisible: import("vue").Ref<boolean, boolean>;
            focus: () => void | undefined;
            blur: () => void | undefined;
            select: () => void;
            clear: (evt?: MouseEvent) => void;
            resizeTextarea: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            clear: (evt: MouseEvent | undefined) => void;
            "update:modelValue": (value: string) => void;
            change: (value: string, evt?: Event | undefined) => void;
            input: (value: string) => void;
            blur: (evt: FocusEvent) => void;
            compositionend: (evt: CompositionEvent) => void;
            compositionstart: (evt: CompositionEvent) => void;
            compositionupdate: (evt: CompositionEvent) => void;
            focus: (evt: FocusEvent) => void;
            keydown: (evt: Event | KeyboardEvent) => void;
            mouseenter: (evt: MouseEvent) => void;
            mouseleave: (evt: MouseEvent) => void;
        }, import("vue").PublicProps, {
            type: import("element-plus").InputType;
            disabled: boolean;
            modelValue: string | number | null;
            validateEvent: boolean;
            modelModifiers: import("element-plus").InputModelModifiers;
            autocomplete: string;
            clearIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            wordLimitPosition: "inside" | "outside";
            tabindex: string | number;
            inputStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            rows: number;
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").InputProps> & Readonly<{
            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
            onInput?: ((value: string) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            input: import("vue").ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
            textarea: import("vue").ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
            ref: import("vue").ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
            textareaStyle: import("vue").ComputedRef<import("vue").StyleValue>;
            autosize: import("vue").Ref<import("element-plus").InputAutoSize | undefined, import("element-plus").InputAutoSize | undefined>;
            isComposing: import("vue").Ref<boolean, boolean>;
            passwordVisible: import("vue").Ref<boolean, boolean>;
            focus: () => void | undefined;
            blur: () => void | undefined;
            select: () => void;
            clear: (evt?: MouseEvent) => void;
            resizeTextarea: () => void;
        }, {}, {}, {}, {
            type: import("element-plus").InputType;
            disabled: boolean;
            modelValue: string | number | null;
            validateEvent: boolean;
            modelModifiers: import("element-plus").InputModelModifiers;
            autocomplete: string;
            clearIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            wordLimitPosition: "inside" | "outside";
            tabindex: string | number;
            inputStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            rows: number;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").InputProps> & Readonly<{
        onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
        onInput?: ((value: string) => any) | undefined;
        onBlur?: ((evt: FocusEvent) => any) | undefined;
        onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
        onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
        onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
        onFocus?: ((evt: FocusEvent) => any) | undefined;
        onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
        onMouseenter?: ((evt: MouseEvent) => any) | undefined;
        onMouseleave?: ((evt: MouseEvent) => any) | undefined;
    }>, {
        input: import("vue").ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
        textarea: import("vue").ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
        ref: import("vue").ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
        textareaStyle: import("vue").ComputedRef<import("vue").StyleValue>;
        autosize: import("vue").Ref<import("element-plus").InputAutoSize | undefined, import("element-plus").InputAutoSize | undefined>;
        isComposing: import("vue").Ref<boolean, boolean>;
        passwordVisible: import("vue").Ref<boolean, boolean>;
        focus: () => void | undefined;
        blur: () => void | undefined;
        select: () => void;
        clear: (evt?: MouseEvent) => void;
        resizeTextarea: () => void;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        clear: (evt: MouseEvent | undefined) => void;
        "update:modelValue": (value: string) => void;
        change: (value: string, evt?: Event | undefined) => void;
        input: (value: string) => void;
        blur: (evt: FocusEvent) => void;
        compositionend: (evt: CompositionEvent) => void;
        compositionstart: (evt: CompositionEvent) => void;
        compositionupdate: (evt: CompositionEvent) => void;
        focus: (evt: FocusEvent) => void;
        keydown: (evt: Event | KeyboardEvent) => void;
        mouseenter: (evt: MouseEvent) => void;
        mouseleave: (evt: MouseEvent) => void;
    }, string, {
        type: import("element-plus").InputType;
        disabled: boolean;
        modelValue: string | number | null;
        validateEvent: boolean;
        modelModifiers: import("element-plus").InputModelModifiers;
        autocomplete: string;
        clearIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
        wordLimitPosition: "inside" | "outside";
        tabindex: string | number;
        inputStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
        rows: number;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            prepend?: (props: {}) => any;
        } & {
            prefix?: (props: {}) => any;
        } & {
            suffix?: (props: {}) => any;
        } & {
            'password-icon'?: (props: {
                visible: boolean;
            }) => any;
        } & {
            append?: (props: {}) => any;
        };
    }>>;
    ElButton: __ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, import("vue").PublicProps, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ButtonProps> & Readonly<{
        onClick?: ((evt: MouseEvent) => any) | undefined;
    }>, {
        ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
        size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
        disabled: import("vue").ComputedRef<boolean>;
        shouldAddSpace: import("vue").ComputedRef<boolean>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        click: (evt: MouseEvent) => void;
    }, string, {
        type: import("element-plus").ButtonType;
        text: boolean;
        disabled: boolean;
        round: boolean;
        dashed: boolean;
        tag: string | import("vue").Component;
        nativeType: import("element-plus").ButtonNativeType;
        loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
        plain: boolean;
        autoInsertSpace: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        setPropsDefaults: (defaults: {
            readonly size?: "" | "small" | "default" | "large" | (() => "" | "small" | "default" | "large") | undefined;
            readonly disabled?: boolean | (() => boolean) | undefined;
            readonly type?: "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger" | (() => "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger") | undefined;
            readonly icon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
            readonly nativeType?: "button" | "reset" | "submit" | (() => "button" | "reset" | "submit") | undefined;
            readonly loading?: boolean | (() => boolean) | undefined;
            readonly loadingIcon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
            readonly plain?: boolean | (() => boolean) | undefined;
            readonly text?: boolean | (() => boolean) | undefined;
            readonly link?: boolean | (() => boolean) | undefined;
            readonly bg?: boolean | (() => boolean) | undefined;
            readonly autofocus?: boolean | (() => boolean) | undefined;
            readonly round?: boolean | (() => boolean) | undefined;
            readonly circle?: boolean | (() => boolean) | undefined;
            readonly dashed?: boolean | (() => boolean) | undefined;
            readonly color?: string | (() => string) | undefined;
            readonly dark?: boolean | (() => boolean) | undefined;
            readonly autoInsertSpace?: boolean | (() => boolean) | undefined;
            readonly tag?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | (() => (string | import("vue").Component | undefined) & {}) | undefined;
        }) => void;
    } & {
        ButtonGroup: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>;
    }, {
        $slots: {
            loading?: (props: {}) => any;
        } & {
            icon?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        };
    }>;
    ElDivider: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").DividerProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
            direction: "horizontal" | "vertical";
            borderStyle: import("element-plus").BorderStyle;
            contentPosition: "left" | "center" | "right";
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").DividerProps> & Readonly<{}>, {}, {}, {}, {}, {
            direction: "horizontal" | "vertical";
            borderStyle: import("element-plus").BorderStyle;
            contentPosition: "left" | "center" | "right";
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").DividerProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
        direction: "horizontal" | "vertical";
        borderStyle: import("element-plus").BorderStyle;
        contentPosition: "left" | "center" | "right";
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        };
    }>>;
}, {
    loading: import("vue").Directive<import("element-plus/es/components/loading/src/directive.mjs").ElementLoading, import("element-plus/es/components/loading/src/directive.mjs").LoadingBinding>;
}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxTagsInput;
export * from './src/props';
export * from './src/instance';

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
