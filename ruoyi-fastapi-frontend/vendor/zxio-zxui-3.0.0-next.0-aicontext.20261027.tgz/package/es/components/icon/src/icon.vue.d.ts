declare const _default: __ZXUI_WithSlots<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
        readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    }>> & Readonly<{
        onClick?: ((ev: Event) => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
        click: (ev: Event) => any;
    }, import("vue").PublicProps, {
        readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
        readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly color: string;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly className: string;
        readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly hoverColor: string;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
        readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    }>> & Readonly<{
        onClick?: ((ev: Event) => any) | undefined;
    }>, {}, {}, {}, {}, {
        readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
        readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly color: string;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
            (): string | import("@zxio/zxui").TooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly className: string;
        readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
            (): string | import("vue").Component;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly hoverColor: string;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "", boolean>;
    readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "", boolean>;
    readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
    readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
        (): string | import("@zxio/zxui").TooltipConfig;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
        (): string | import("@zxio/zxui").TooltipConfig;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>> & Readonly<{
    onClick?: ((ev: Event) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    click: (ev: Event) => any;
}, string, {
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
        (): string | import("@zxio/zxui").TooltipConfig;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | {
        (): string | import("@zxio/zxui").TooltipConfig;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly className: string;
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | {
        (): string | import("vue").Component;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly hoverColor: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
}>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
