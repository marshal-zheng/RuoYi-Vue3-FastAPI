export declare const ZxTabs: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    items: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./src/props").ZxTabsItem[]) | (() => import("./src/props").ZxTabsItem[]) | {
        (): import("./src/props").ZxTabsItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./src/props").ZxTabsItem[]) | (() => import("./src/props").ZxTabsItem[]) | {
        (): import("./src/props").ZxTabsItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    lazy: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    trackTabRecord: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    useUrlParams: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    paramName: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    contentTransition: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | {
        (): "none" | "fade" | "slide";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | {
        (): "none" | "fade" | "slide";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    activeKey: import("vue").Ref<string, string>;
    sortedItems: import("vue").ComputedRef<any[]>;
    handleTabClick: (tab: any, event: Event) => void;
    handleTabRemove: (key: string | number) => any;
    handleTabAdd: () => any;
    handleEdit: (targetName: string | number | undefined, action: "add" | "remove") => any;
    handleComponentMounted: (instance: any) => any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:modelValue" | "edit" | "tab-click" | "tab-remove" | "tab-add" | "drag-ended" | "component-mounted")[], "update:modelValue" | "edit" | "tab-click" | "tab-remove" | "tab-add" | "drag-ended" | "component-mounted", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    items: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./src/props").ZxTabsItem[]) | (() => import("./src/props").ZxTabsItem[]) | {
        (): import("./src/props").ZxTabsItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./src/props").ZxTabsItem[]) | (() => import("./src/props").ZxTabsItem[]) | {
        (): import("./src/props").ZxTabsItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    lazy: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    trackTabRecord: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    useUrlParams: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    paramName: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    contentTransition: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | {
        (): "none" | "fade" | "slide";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | {
        (): "none" | "fade" | "slide";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    onEdit?: ((...args: any[]) => any) | undefined;
    "onTab-click"?: ((...args: any[]) => any) | undefined;
    "onTab-remove"?: ((...args: any[]) => any) | undefined;
    "onTab-add"?: ((...args: any[]) => any) | undefined;
    "onDrag-ended"?: ((...args: any[]) => any) | undefined;
    "onComponent-mounted"?: ((...args: any[]) => any) | undefined;
}>, {
    fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    lazy: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    items: import("./src/props").ZxTabsItem[];
    trackTabRecord: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    useUrlParams: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    paramName: string;
    contentTransition: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | {
        (): "none" | "fade" | "slide";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | {
        (): "none" | "fade" | "slide";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
}, {}, {
    ElTabs: {
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly type: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "" | "card" | "border-card", unknown, "", boolean>;
            readonly closable: BooleanConstructor;
            readonly addable: BooleanConstructor;
            readonly modelValue: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly defaultValue: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly editable: BooleanConstructor;
            readonly tabPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "bottom" | "top", unknown, "top", boolean>;
            readonly beforeLeave: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | {
                (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | {
                (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => true, boolean>;
            readonly stretch: BooleanConstructor;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
        }>> & Readonly<{
            "onUpdate:modelValue"?: ((name: import("element-plus").TabPaneName) => any) | undefined;
            onTabClick?: ((pane: {
                uid: number;
                getVnode: () => import("vue").VNode;
                slots: import("vue").Slots;
                props: {
                    label?: string | undefined;
                    name?: string | number | undefined;
                    closable?: boolean | undefined;
                    disabled?: boolean | undefined;
                    lazy?: boolean | undefined;
                };
                paneName: import("element-plus").TabPaneName | undefined;
                active: boolean;
                index: string | undefined;
                isClosable: boolean;
                isFocusInsidePane: () => boolean | undefined;
            }, ev: Event) => any) | undefined;
            onTabChange?: ((name: import("element-plus").TabPaneName) => any) | undefined;
            onEdit?: ((paneName: import("element-plus").TabPaneName | undefined, action: "remove" | "add") => any) | undefined;
            onTabRemove?: ((name: import("element-plus").TabPaneName) => any) | undefined;
            onTabAdd?: (() => any) | undefined;
        }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (name: import("element-plus").TabPaneName) => name is string | number;
            tabClick: (pane: import("element-plus").TabsPaneContext, ev: Event) => boolean;
            tabChange: (name: import("element-plus").TabPaneName) => name is string | number;
            edit: (paneName: import("element-plus").TabPaneName | undefined, action: "remove" | "add") => boolean;
            tabRemove: (name: import("element-plus").TabPaneName) => name is string | number;
            tabAdd: () => boolean;
        }, import("vue").PublicProps, {
            readonly type: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "card" | "border-card", unknown>;
            readonly stretch: boolean;
            readonly closable: boolean;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly editable: boolean;
            readonly tabPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "bottom" | "top", unknown>;
            readonly beforeLeave: (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
            readonly addable: boolean;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly type: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "" | "card" | "border-card", unknown, "", boolean>;
            readonly closable: BooleanConstructor;
            readonly addable: BooleanConstructor;
            readonly modelValue: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly defaultValue: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly editable: BooleanConstructor;
            readonly tabPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "bottom" | "top", unknown, "top", boolean>;
            readonly beforeLeave: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | {
                (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | {
                (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => true, boolean>;
            readonly stretch: BooleanConstructor;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
        }>> & Readonly<{
            "onUpdate:modelValue"?: ((name: import("element-plus").TabPaneName) => any) | undefined;
            onTabClick?: ((pane: {
                uid: number;
                getVnode: () => import("vue").VNode;
                slots: import("vue").Slots;
                props: {
                    label?: string | undefined;
                    name?: string | number | undefined;
                    closable?: boolean | undefined;
                    disabled?: boolean | undefined;
                    lazy?: boolean | undefined;
                };
                paneName: import("element-plus").TabPaneName | undefined;
                active: boolean;
                index: string | undefined;
                isClosable: boolean;
                isFocusInsidePane: () => boolean | undefined;
            }, ev: Event) => any) | undefined;
            onTabChange?: ((name: import("element-plus").TabPaneName) => any) | undefined;
            onEdit?: ((paneName: import("element-plus").TabPaneName | undefined, action: "remove" | "add") => any) | undefined;
            onTabRemove?: ((name: import("element-plus").TabPaneName) => any) | undefined;
            onTabAdd?: (() => any) | undefined;
        }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
            readonly type: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "card" | "border-card", unknown>;
            readonly stretch: boolean;
            readonly closable: boolean;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly editable: boolean;
            readonly tabPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "bottom" | "top", unknown>;
            readonly beforeLeave: (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
            readonly addable: boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly type: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "" | "card" | "border-card", unknown, "", boolean>;
        readonly closable: BooleanConstructor;
        readonly addable: BooleanConstructor;
        readonly modelValue: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly defaultValue: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly editable: BooleanConstructor;
        readonly tabPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "bottom" | "top", unknown, "top", boolean>;
        readonly beforeLeave: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | {
            (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | {
            (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => true, boolean>;
        readonly stretch: BooleanConstructor;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((name: import("element-plus").TabPaneName) => any) | undefined;
        onTabClick?: ((pane: {
            uid: number;
            getVnode: () => import("vue").VNode;
            slots: import("vue").Slots;
            props: {
                label?: string | undefined;
                name?: string | number | undefined;
                closable?: boolean | undefined;
                disabled?: boolean | undefined;
                lazy?: boolean | undefined;
            };
            paneName: import("element-plus").TabPaneName | undefined;
            active: boolean;
            index: string | undefined;
            isClosable: boolean;
            isFocusInsidePane: () => boolean | undefined;
        }, ev: Event) => any) | undefined;
        onTabChange?: ((name: import("element-plus").TabPaneName) => any) | undefined;
        onEdit?: ((paneName: import("element-plus").TabPaneName | undefined, action: "remove" | "add") => any) | undefined;
        onTabRemove?: ((name: import("element-plus").TabPaneName) => any) | undefined;
        onTabAdd?: (() => any) | undefined;
    }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        "update:modelValue": (name: import("element-plus").TabPaneName) => name is string | number;
        tabClick: (pane: import("element-plus").TabsPaneContext, ev: Event) => boolean;
        tabChange: (name: import("element-plus").TabPaneName) => name is string | number;
        edit: (paneName: import("element-plus").TabPaneName | undefined, action: "remove" | "add") => boolean;
        tabRemove: (name: import("element-plus").TabPaneName) => name is string | number;
        tabAdd: () => boolean;
    }, string, {
        readonly type: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "card" | "border-card", unknown>;
        readonly stretch: boolean;
        readonly closable: boolean;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly editable: boolean;
        readonly tabPosition: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "bottom" | "top", unknown>;
        readonly beforeLeave: (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>;
        readonly addable: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        setPropsDefaults: (defaults: {
            readonly type?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "" | "card" | "border-card", unknown> | (() => "" | "card" | "border-card") | undefined;
            readonly stretch?: boolean | (() => boolean) | undefined;
            readonly closable?: boolean | (() => boolean) | undefined;
            readonly tabindex?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | (() => string | number) | undefined;
            readonly editable?: boolean | (() => boolean) | undefined;
            readonly tabPosition?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "top" | "bottom" | "right" | "left", unknown> | (() => "top" | "bottom" | "right" | "left") | undefined;
            readonly beforeLeave?: ((newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.mjs").Awaitable<void | boolean>) | undefined;
            readonly addable?: boolean | (() => boolean) | undefined;
            readonly modelValue?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | (() => string | number) | undefined;
            readonly defaultValue?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | (() => string | number) | undefined;
        }) => void;
    } & {
        TabPane: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").TabPaneProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                label: string;
                closable: boolean;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").TabPaneProps> & Readonly<{}>, {}, {}, {}, {}, {
                label: string;
                closable: boolean;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").TabPaneProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            label: string;
            closable: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>;
    };
    ElTabPane: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").TabPaneProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
            label: string;
            closable: boolean;
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").TabPaneProps> & Readonly<{}>, {}, {}, {}, {}, {
            label: string;
            closable: boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").TabPaneProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
        label: string;
        closable: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        };
    }>>;
    ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        };
    }>>;
    Loading: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxTabs;
export * from './src/props';
export * from './src/instance';

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
