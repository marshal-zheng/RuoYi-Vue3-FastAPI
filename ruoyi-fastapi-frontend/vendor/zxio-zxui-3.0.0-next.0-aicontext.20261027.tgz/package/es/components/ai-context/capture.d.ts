import type { AIContextKnownValues } from './mask';
import type { AIContextScopeRuntime } from './scope';
import type { AIContextAction, AIContextReceipt, WireContextItem } from './types';
export interface AIContextSelection {
    readonly action: AIContextAction;
    readonly selectedContextIds: readonly string[];
    readonly revision: number;
}
export declare function captureAIContext<T extends {
    instruction: string;
    document: unknown;
    selection: unknown;
    candidate: unknown;
}>(scope: AIContextScopeRuntime, options: {
    purpose: string;
    selection: () => AIContextSelection;
    knownValues: AIContextKnownValues;
    signal: AbortSignal;
    request: T;
}): Promise<Readonly<{
    captureId: string;
    manifestRevision: string;
    policyRevision: string;
    scope: string;
    purpose: string;
    action: AIContextAction;
    selectedContextIds: readonly string[];
    items: readonly WireContextItem[];
    receipt: Readonly<{
        included: AIContextReceipt["included"][number][];
        withheld: AIContextReceipt["withheld"][number][];
    }>;
    request: Readonly<T & {
        instruction: string;
        document: unknown;
        selection: unknown;
        candidate: unknown;
    }>;
    assertCurrent: () => void;
    restore<D>(document: D): D;
}>>;
