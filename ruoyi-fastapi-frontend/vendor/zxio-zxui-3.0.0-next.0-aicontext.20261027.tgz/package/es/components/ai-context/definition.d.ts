import type { AIContextScopeDefinition } from './types';
/** Pure static metadata: never inspect bindings, Vue setup, or field values. */
export declare function defineAIContextScope<T extends AIContextScopeDefinition>(source: T): Readonly<T>;
