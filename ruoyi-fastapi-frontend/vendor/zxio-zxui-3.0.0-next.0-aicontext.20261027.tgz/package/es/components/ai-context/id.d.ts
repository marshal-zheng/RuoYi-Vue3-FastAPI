/** UUID v4 using Web Crypto, including HTTP intranet origins without randomUUID. */
export declare function createAIContextId(): string;
