declare const _default: __ZXUI_WithSlots<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<readonly import("@zxio/zxui").ZxToolbarAction[]>;
            required: true;
        };
        label: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        onAction?: ((action: import("@zxio/zxui").ZxToolbarAction) => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        action: (action: import("@zxio/zxui").ZxToolbarAction) => any;
    }, import("vue").PublicProps, {
        label: string;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<readonly import("@zxio/zxui").ZxToolbarAction[]>;
            required: true;
        };
        label: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        onAction?: ((action: import("@zxio/zxui").ZxToolbarAction) => any) | undefined;
    }>, {}, {}, {}, {}, {
        label: string;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    actions: {
        type: import("vue").PropType<readonly import("@zxio/zxui").ZxToolbarAction[]>;
        required: true;
    };
    label: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onAction?: ((action: import("@zxio/zxui").ZxToolbarAction) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: import("@zxio/zxui").ZxToolbarAction) => any;
}, string, {
    label: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
    $slots: {
        action?: (props: {
            action: import("@zxio/zxui").ZxToolbarAction;
        }) => any;
    };
}>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
