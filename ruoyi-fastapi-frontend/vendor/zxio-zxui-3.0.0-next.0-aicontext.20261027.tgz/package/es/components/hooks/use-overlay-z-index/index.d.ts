import type { MaybeRefOrGetter, Ref } from 'vue';
/**
 * Stacking level for an overlay that opens and closes.
 *
 * Each time `open` turns true the overlay takes the next level from Element
 * Plus' z-index counter, so ZXUI overlays, Element Plus overlays and hosted
 * features share one order: the one opened last is on top. The level is kept
 * while the overlay stays open or plays its leave transition. The counter's
 * base follows ZxConfigProvider `zIndex`. Server rendering needs the host to
 * provide Element Plus' `ZINDEX_INJECTION_KEY` per request, as Element Plus'
 * own overlays do.
 *
 * Call it from setup. The value is `undefined` until the first open.
 */
export declare function useOverlayZIndex(open: MaybeRefOrGetter<boolean>): Readonly<Ref<number | undefined>>;
