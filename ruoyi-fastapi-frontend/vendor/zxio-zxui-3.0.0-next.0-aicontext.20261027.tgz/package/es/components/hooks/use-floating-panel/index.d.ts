import { type ComputedRef, type Ref } from 'vue';
import type { ZxFloatingPanelInstance } from '../../floating-panel/src/instance';
import type { ZxFloatingPanelAnchor, ZxFloatingPanelCollapsedShape, ZxFloatingPanelCollapsedSize, ZxFloatingPanelDragEvent, ZxFloatingPanelIcon, ZxFloatingPanelPosition, ZxFloatingPanelPositionStrategy, ZxFloatingPanelResizeEvent, ZxFloatingPanelSize } from '../../floating-panel/src/props';
type MaybeRef<T> = T | Ref<T>;
export interface FloatingPanelOptions {
    title?: MaybeRef<string>;
    titleTag?: MaybeRef<string>;
    ariaLabel?: MaybeRef<string>;
    /** Initial visibility; later changes go through `open()` / `close()`. */
    visible?: MaybeRef<boolean>;
    defaultCollapsed?: MaybeRef<boolean>;
    headerClickable?: MaybeRef<boolean>;
    customClass?: MaybeRef<string>;
    position?: MaybeRef<ZxFloatingPanelPosition>;
    size?: MaybeRef<ZxFloatingPanelSize>;
    collapsedSize?: MaybeRef<ZxFloatingPanelCollapsedSize>;
    collapsedShape?: MaybeRef<ZxFloatingPanelCollapsedShape>;
    /** Fixed stacking level; omit it to join the shared overlay order on each show. */
    zIndex?: MaybeRef<number>;
    expandIcon?: MaybeRef<ZxFloatingPanelIcon | undefined>;
    collapseIcon?: MaybeRef<ZxFloatingPanelIcon | undefined>;
    showCollapseBtn?: MaybeRef<boolean>;
    showClose?: MaybeRef<boolean>;
    autoDirection?: MaybeRef<boolean>;
    showStatus?: MaybeRef<boolean>;
    loading?: MaybeRef<boolean>;
    completed?: MaybeRef<boolean>;
    error?: MaybeRef<boolean>;
    loadingText?: MaybeRef<string | undefined>;
    completedText?: MaybeRef<string | undefined>;
    errorText?: MaybeRef<string | undefined>;
    expandTooltip?: MaybeRef<string | undefined>;
    collapseTooltip?: MaybeRef<string | undefined>;
    closeTooltip?: MaybeRef<string | undefined>;
    autoExpand?: MaybeRef<boolean>;
    completedDuration?: MaybeRef<number>;
    transitionDuration?: MaybeRef<number>;
    positionStrategy?: MaybeRef<ZxFloatingPanelPositionStrategy>;
    anchor?: MaybeRef<ZxFloatingPanelAnchor | null>;
    placement?: MaybeRef<string>;
    offset?: MaybeRef<number | [number, number]>;
    shift?: MaybeRef<boolean>;
    flip?: MaybeRef<boolean>;
    shiftPadding?: MaybeRef<number>;
    draggable?: MaybeRef<boolean>;
    keyboardStep?: MaybeRef<number>;
    resizable?: MaybeRef<boolean>;
    minSize?: MaybeRef<ZxFloatingPanelResizeEvent>;
    teleport?: MaybeRef<boolean>;
    /** @deprecated see the `responsive` prop */
    responsive?: MaybeRef<Record<string, unknown>>;
    onToggle?: (isCollapsed: boolean) => void;
    onExpand?: () => void;
    onCollapse?: () => void;
    onClose?: () => void;
    onDragStart?: (event: ZxFloatingPanelDragEvent) => void;
    onDragEnd?: (event: ZxFloatingPanelDragEvent) => void;
    onResizeEnd?: (event: ZxFloatingPanelResizeEvent) => void;
}
export interface FloatingPanelState {
    isCollapsed: boolean;
    visible: boolean;
    isDragging: boolean;
    position: {
        x: number;
        y: number;
    };
    size: ZxFloatingPanelResizeEvent | null;
    isOnRightSide: boolean;
}
export interface UseFloatingPanelReturn {
    state: FloatingPanelState;
    /** Bind with `ref="panelRef"` or rely on the `ref` inside `panelProps`. */
    panelRef: Ref<ZxFloatingPanelInstance | null>;
    panelProps: ComputedRef<Record<string, any>>;
    panelEvents: ComputedRef<Record<string, any>>;
    toggle: () => void;
    expand: () => void;
    collapse: () => void;
    open: () => void;
    close: () => void;
    setPosition: (x: number, y: number) => void;
    resetPosition: () => void;
    setSize: (size: Partial<ZxFloatingPanelResizeEvent>) => void;
    resetSize: () => void;
    updateOptions: (newOptions: Partial<FloatingPanelOptions>) => void;
}
/**
 * Owns collapse and visibility state for a `ZxFloatingPanel` and mirrors the
 * panel's drag / resize reports back into `state`. The component stays the
 * single source of truth for geometry; this hook only relays it.
 */
export declare function useFloatingPanel(options?: FloatingPanelOptions): UseFloatingPanelReturn;
export {};
