import { type SFCWithInstall } from '@zxio/shared';
import DialogComponent from './src/dialog.vue';
import type { DialogSlots } from './src/slots';
type DialogComponentOptions = Pick<typeof DialogComponent, keyof typeof DialogComponent>;
type DialogPublicComponent = DialogComponentOptions & {
    new (): Omit<InstanceType<typeof DialogComponent>, '$slots'> & {
        $slots: DialogSlots;
    };
};
export declare const ZxDialog: SFCWithInstall<DialogPublicComponent>;
export default ZxDialog;
export * from './src/props';
export type { ZxDialogInstance, ZxDialogExpose } from './src/instance';
export type { DialogBeforeClose, DialogCloseReason, DialogConfirm, DialogConfirmContext, DialogDescriptionItem, DialogDirtyGuard, DialogSize, } from './src/constants';
export type { DialogMessages, DialogLocaleKey } from './src/locale';
export type { DialogSlots, DialogSlotContext } from './src/slots';
export type { ButtonVariant, FooterButtonConfig, } from '@zxio/constants/form-modal';
