import type { PropType } from 'vue';
import type { DrawerDirection } from './constants';
type __VLS_Slots = {
    header?(props: {
        titleId: string;
        titleClass: string;
    }): any;
    default?(): any;
    footer?(): any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    modelValue: BooleanConstructor;
    appendTo: {
        type: PropType<HTMLElement>;
        required: true;
    };
    title: StringConstructor;
    size: (NumberConstructor | StringConstructor)[];
    direction: {
        type: PropType<DrawerDirection>;
        default: string;
    };
    withHeader: {
        type: BooleanConstructor;
        default: boolean;
    };
    headerClass: StringConstructor;
    bodyClass: StringConstructor;
    footerClass: StringConstructor;
    zIndex: NumberConstructor;
    openDelay: NumberConstructor;
    closeDelay: NumberConstructor;
    destroyOnClose: BooleanConstructor;
    closeOnPressEscape: {
        type: BooleanConstructor;
        default: boolean;
    };
    beforeClose: PropType<(done: (cancel?: boolean) => void) => void>;
    modal: BooleanConstructor;
    lockScroll: BooleanConstructor;
    modalPenetrable: BooleanConstructor;
    trapFocus: BooleanConstructor;
    showClose: BooleanConstructor;
    closeOnClickModal: BooleanConstructor;
}>, {
    handleClose: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    open: () => void;
    close: () => void;
    closed: () => void;
    opened: () => void;
    "update:modelValue": (value: boolean) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    modelValue: BooleanConstructor;
    appendTo: {
        type: PropType<HTMLElement>;
        required: true;
    };
    title: StringConstructor;
    size: (NumberConstructor | StringConstructor)[];
    direction: {
        type: PropType<DrawerDirection>;
        default: string;
    };
    withHeader: {
        type: BooleanConstructor;
        default: boolean;
    };
    headerClass: StringConstructor;
    bodyClass: StringConstructor;
    footerClass: StringConstructor;
    zIndex: NumberConstructor;
    openDelay: NumberConstructor;
    closeDelay: NumberConstructor;
    destroyOnClose: BooleanConstructor;
    closeOnPressEscape: {
        type: BooleanConstructor;
        default: boolean;
    };
    beforeClose: PropType<(done: (cancel?: boolean) => void) => void>;
    modal: BooleanConstructor;
    lockScroll: BooleanConstructor;
    modalPenetrable: BooleanConstructor;
    trapFocus: BooleanConstructor;
    showClose: BooleanConstructor;
    closeOnClickModal: BooleanConstructor;
}>> & Readonly<{
    onOpen?: (() => any) | undefined;
    "onUpdate:modelValue"?: ((value: boolean) => any) | undefined;
    onClose?: (() => any) | undefined;
    onClosed?: (() => any) | undefined;
    onOpened?: (() => any) | undefined;
}>, {
    direction: DrawerDirection;
    modal: boolean;
    modelValue: boolean;
    showClose: boolean;
    lockScroll: boolean;
    closeOnClickModal: boolean;
    closeOnPressEscape: boolean;
    destroyOnClose: boolean;
    modalPenetrable: boolean;
    trapFocus: boolean;
    withHeader: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
