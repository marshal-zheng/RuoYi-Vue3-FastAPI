import type { RuntimeThemeRegistration } from '../theme-runtime/runtime-descriptor';
import type { ThemeHydrationSnapshotV1 } from '../theme-runtime/hydration-schema';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
import type { ThemeSsrScopeRequest } from '../theme-runtime/ssr-bootstrap';
export interface ThemeBootstrapPageV1 {
    readonly schema: 'zx.theme-bootstrap/1';
    readonly appKey: string;
    readonly pageName: string;
    readonly pageIdentity: string;
    readonly snapshotHash: string;
    readonly snapshot: ThemeHydrationSnapshotV1;
    readonly scopeRequests: readonly ThemeSsrScopeRequest[];
    readonly themeIds: readonly string[];
    readonly defaultThemeId: string;
    readonly storageKey: string;
    readonly profiles: readonly {
        readonly id: string;
        readonly sha256: string;
        readonly sources: readonly string[];
        readonly elementId: string;
    }[];
}
export interface ThemeStartupReceipt {
    readonly appKey: string;
    readonly pageIdentity: string;
    readonly status: 'success';
    readonly preference: {
        readonly themeId: string;
        readonly mode: 'light' | 'dark' | 'system';
    };
    readonly systemMode: 'light' | 'dark';
    readonly profileId: string;
    readonly profileHash: string;
}
export interface ZxThemeBootstrapOptions {
    readonly page: unknown;
    readonly receipt: unknown;
    readonly profileElements: readonly HTMLStyleElement[];
    /** Only this app's config, receipt, bootstrap script and CSP metadata nodes. */
    readonly temporaryElements: readonly HTMLElement[];
}
export interface ValidatedThemeBootstrap {
    readonly page: ThemeBootstrapPageV1;
    readonly receipt: ThemeStartupReceipt | null;
    readonly receiptFailure: string | null;
    readonly profileElements: readonly HTMLStyleElement[];
    readonly temporaryElements: readonly HTMLElement[];
}
/** Validates inert page data and exact owned nodes before any adoption or cleanup. */
export declare function validateThemeBootstrap(input: ZxThemeBootstrapOptions, appKey: string, snapshot: unknown, themes: readonly RuntimeThemeRegistration[], assetResolver?: object): ThemeRuntimeResult<ValidatedThemeBootstrap>;
