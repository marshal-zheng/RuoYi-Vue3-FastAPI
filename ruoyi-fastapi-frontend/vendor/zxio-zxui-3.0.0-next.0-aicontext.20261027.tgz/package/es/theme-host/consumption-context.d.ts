import type { RuntimeThemeDescriptor } from '../theme-runtime/runtime-payload';
import type { InjectionKey } from 'vue';
import type { ThemeExtensionTokenDescriptorV1 } from '@zxio/tokens/extensions';
import type { ZxThemeConsumptionService } from './consumption';
import type { ZxDisplayMetricsService } from './display-metrics';
import type { ZxDisplayLayoutCoordinator } from './display-layout';
export interface ThemeHostConsumptionContext {
    readonly themeDescriptor?: (themeId: string) => RuntimeThemeDescriptor | undefined;
    readonly service: ZxThemeConsumptionService | null;
    readonly publicTokens: readonly ThemeExtensionTokenDescriptorV1[];
    readonly displayMetrics: ReadonlyMap<string, {
        readonly variable: string;
        readonly moduleId?: string;
    }>;
    readonly metricsService: ZxDisplayMetricsService | null;
    readonly layoutService: ZxDisplayLayoutCoordinator | null;
    readonly server: boolean;
}
export declare const themeHostConsumptionKey: InjectionKey<ThemeHostConsumptionContext>;
