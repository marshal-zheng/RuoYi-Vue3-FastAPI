import type { ThemeExtensionTokenReference } from '@zxio/tokens/extensions';
import type { BuiltInTypeId, BuiltInTypeMap, ThemeSeedsV1 } from '@zxio/tokens/kernel';
import type { ZxThemeCompositionRequest } from './composition';
import type { RuntimeThemeCoreView } from '../theme-runtime/runtime-descriptor';
import type { ThemeRuntime, ThemeScopeUpdateResult } from '../theme-runtime/runtime';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
import type { ThemeScopeIdentity } from '../theme-runtime/composition-contract';
export interface ZxThemeCssTokenValue {
    readonly typeId: string;
    readonly cssValue?: string;
    readonly fields?: Readonly<Record<string, string>>;
}
export interface ZxThemeTokenSnapshot {
    readonly scopeId: string;
    readonly revision: number;
    readonly contentHash: string;
    /** Concrete browser CSS values, never Kernel canonical token objects. */
    readonly tokens: Readonly<Record<string, ZxThemeCssTokenValue>>;
}
export interface ZxThemeCompositionReset {
    readonly modules?: boolean;
    readonly seeds?: true | readonly (keyof ThemeSeedsV1)[];
    readonly overrides?: true | readonly string[];
}
export interface ZxThemeJsAdapter<T> {
    readonly id: string;
    readonly project: (snapshot: ZxThemeTokenSnapshot, context: {
        readonly signal: AbortSignal;
    }) => T | Promise<T>;
}
export interface ZxThemeAdapterBinding {
    readonly state: 'pending' | 'ready' | 'error' | 'disposed';
    readonly diagnostics: readonly string[];
    retry(): void;
    dispose(): void;
}
export declare function createThemeConsumptionService(runtime: ThemeRuntime, manifests: readonly RuntimeThemeCoreView[]): Readonly<{
    runtime: ThemeRuntime;
    readTokens: (scope: ThemeScopeIdentity) => ThemeRuntimeResult<ZxThemeTokenSnapshot>;
    read<K extends BuiltInTypeId>(scope: ThemeScopeIdentity, token: ThemeExtensionTokenReference<K>): ThemeRuntimeResult<ZxThemeCssTokenValue>;
    update(scope: ThemeScopeIdentity, patch: ZxThemeCompositionRequest): Promise<ThemeRuntimeResult<ThemeScopeUpdateResult>>;
    set<K extends BuiltInTypeId>(scope: ThemeScopeIdentity, token: ThemeExtensionTokenReference<K, true>, value: BuiltInTypeMap[K]): Promise<ThemeRuntimeResult<ThemeScopeUpdateResult>>;
    reset(scope: ThemeScopeIdentity, reset?: ZxThemeCompositionReset): Promise<ThemeRuntimeResult<ThemeScopeUpdateResult>>;
    bindCssAdapter(scope: ThemeScopeIdentity, target: HTMLElement, input: {
        readonly id: string;
        readonly actualVersion: string;
    }): Promise<Readonly<{
        ok: false;
        diagnostics: readonly import("..").ThemeRuntimeDiagnostic[];
    }> | Readonly<{
        ok: true;
        value: {
            release(): void;
        };
        diagnostics: readonly [];
    }>>;
    bindAdapter<T>(scope: ThemeScopeIdentity, adapter: ZxThemeJsAdapter<T>, instance: {
        readonly apply: (value: T, context: {
            readonly revision: number;
            readonly signal: AbortSignal;
        }) => void;
        readonly dispose?: () => void;
    }): ThemeRuntimeResult<ZxThemeAdapterBinding>;
    dispose(): void;
}>;
export type ZxThemeConsumptionService = ReturnType<typeof createThemeConsumptionService>;
