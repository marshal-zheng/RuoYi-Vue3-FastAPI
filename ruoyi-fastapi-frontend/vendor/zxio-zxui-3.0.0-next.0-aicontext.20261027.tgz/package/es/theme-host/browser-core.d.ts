import type { RuntimeThemeRegistration } from '../theme-runtime/runtime-descriptor';
import type { ThemeFeedbackFactory } from '../theme-runtime/runtime-core';
import type { ZxThemeCompositionOptions, createHostThemeComposition } from './composition';
import type { ThemeConsumerHydrationInput } from '../theme-runtime/consumer-contract';
import type { ZxThemeHostBootstrap } from './bootstrap-controller';
import type { ZxThemeBootstrapOptions } from './bootstrap-metadata';
import type { ZxThemeConsumptionService } from './consumption';
import type { ZxDisplayLayoutCoordinator } from './display-layout';
import type { ZxDisplayMetricsService } from './display-metrics';
import type { App } from 'vue';
import type { AdapterContractPort, SystemPreferencePort, ThemeAppHandle, ThemeAssetResolver, ThemeCompositionHydrationInput, ThemePortalContainerScope, ThemePortalTarget, ThemeRuntime, ThemeRuntimeResult, ThemeScopeRequest, ThemeStylesheetPolicy, ThemeTargetCoordinatorResolver } from '../theme-runtime';
export * from './preferences';
export * from './chart-projection';
export * from './consumption';
export * from './display-layout';
export * from './display-metrics';
export * from './use-theme-consumption';
export * from './echarts-adapter';
export type { ThemePortalContainerScope } from '../theme-runtime/portal-registry';
export type ZxThemeHostPortalTarget = Exclude<ThemePortalTarget, string>;
export interface ZxThemeHostHydrationOptions {
    readonly consumers?: unknown;
    readonly consumerPortalRoots?: ThemeConsumerHydrationInput['portalRoots'];
    readonly snapshot: unknown;
    readonly stylesheetElements: readonly HTMLElement[];
    /** Transfer only styles injected and owned by this Host; external adoption is read-only. */
    readonly stylesheetOwnership?: 'transferred' | 'external';
    readonly manualCompletion?: boolean;
    readonly composition?: ThemeCompositionHydrationInput;
}
export interface ZxThemeHostOptions extends ZxThemeCompositionOptions {
    readonly appKey: string;
    readonly themes: readonly RuntimeThemeRegistration[];
    readonly defaultThemeId: string;
    readonly adapterContract: AdapterContractPort;
    readonly assetResolver: ThemeAssetResolver;
    readonly targetCoordinatorResolver: ThemeTargetCoordinatorResolver;
    readonly systemPreference: SystemPreferencePort;
    readonly stylesheetPolicy: ThemeStylesheetPolicy;
    readonly portalTarget: ZxThemeHostPortalTarget;
    /**
     * `'mirrored'` also writes the scope identity onto the portal container
     * itself, so overlays a third party teleports straight into that container
     * — Element Plus poppers land in a div it appends to `document.body` —
     * still resolve the compiled adapter variables. Defaults to `'isolated'`.
     */
    readonly portalContainerScope?: ThemePortalContainerScope;
    readonly rootRequest: ThemeScopeRequest;
    readonly hydration?: ZxThemeHostHydrationOptions;
    readonly maxRegisteredManifests?: number;
}
export interface ZxThemeHost {
    readonly bootstrap?: ZxThemeHostBootstrap;
    readonly runtime: ThemeRuntime;
    readonly composition: ZxThemeConsumptionService;
    readonly displayMetrics: ZxDisplayMetricsService;
    readonly displayLayout: ZxDisplayLayoutCoordinator;
    bind(app: App): ThemeRuntimeResult<ThemeAppHandle>;
    dispose(): Promise<ThemeRuntimeResult<void>>;
}
export type ZxThemeHostDiagnosticCode = 'CONSUMER_HOST_INVALID_MANIFEST' | 'CONSUMER_HOST_BIND_FAILED' | 'CONSUMER_HOST_ALREADY_BOUND' | 'CONSUMER_HOST_DISPOSED';
export declare function createZxThemeHost(options: ZxThemeHostOptions, compose: typeof createHostThemeComposition, feedback?: ThemeFeedbackFactory): ThemeRuntimeResult<ZxThemeHost>;
export interface ZxDefaultBrowserThemeHostTheme {
    readonly runtime?: never;
    readonly manifest: unknown;
    /** Compiled CSS text keyed by the theme package export path (e.g. `./theme.css`). */
    readonly assets: Readonly<Record<string, string>>;
}
export interface ZxDefaultBrowserThemeHostHydrationOptions extends ZxThemeHostHydrationOptions {
    readonly bootstrap?: ZxThemeBootstrapOptions;
}
export interface ZxDefaultBrowserThemeHostCommonOptions extends ZxThemeCompositionOptions {
    readonly appKey: string;
    readonly defaultThemeId: string;
    readonly rootRequest?: ThemeScopeRequest;
    readonly stylesheetPolicy?: ThemeStylesheetPolicy;
    readonly portalTarget?: ZxThemeHostPortalTarget;
    readonly portalContainerScope?: ThemePortalContainerScope;
    readonly hydration?: ZxDefaultBrowserThemeHostHydrationOptions;
    readonly systemPreference?: SystemPreferencePort;
    /** Additional roots used by scopes or portals; the browser document is included. */
    readonly targetRoots?: readonly (Document | ShadowRoot)[];
    readonly maxRegisteredManifests?: number;
}
export type ZxDefaultBrowserThemeHostOptions = ZxDefaultBrowserThemeHostCommonOptions & ({
    readonly themes: readonly ZxDefaultBrowserThemeHostTheme[];
    readonly assetResolver?: never;
} | {
    readonly themes: readonly (RuntimeThemeRegistration & {
        readonly assets?: never;
    })[];
    readonly assetResolver: ThemeAssetResolver;
});
/** Text assets retain aggregate defaults; resolver registrations default to on-demand. */
export declare function createDefaultBrowserThemeHost(options: ZxDefaultBrowserThemeHostOptions, compose: typeof createHostThemeComposition, feedback?: ThemeFeedbackFactory): ThemeRuntimeResult<ZxThemeHost>;
export { createThemeDeploymentResolver } from './deployment-resolver';
export type { ThemeDeploymentMapV1, ThemeDeploymentResolverOptions, } from './deployment-resolver';
export type { ZxThemeHostBootstrap, ZxThemeHostBootstrapState, } from './bootstrap-controller';
export type { ThemeBootstrapPageV1, ThemeStartupReceipt, ZxThemeBootstrapOptions, } from './bootstrap-metadata';
export type { ThemeRuntimePayloadV1 } from '../theme-runtime/runtime-payload';
export type { RuntimeThemeRegistration } from '../theme-runtime/runtime-descriptor';
