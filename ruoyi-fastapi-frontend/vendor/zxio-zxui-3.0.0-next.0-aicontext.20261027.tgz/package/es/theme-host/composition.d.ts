import type { ZxThemeCompositionOptions } from './composition-core';
import type { RuntimeThemeCoreView } from '../theme-runtime/runtime-descriptor';
export type * from './composition-core';
export { parseCompositionRequest } from './composition-request';
export declare function createHostThemeComposition<Theme extends RuntimeThemeCoreView>(options: ZxThemeCompositionOptions, themes: readonly Theme[]): import("..").ThemeRuntimeResult<{
    readonly port: import("..").ThemeScopeCompositionPort;
    readonly bundles: readonly import("@zxio/tokens/extensions").ValidatedThemeExtensionBundleV1[];
    readonly manifests: readonly Theme[];
    dispose(): void;
}>;
