import { themeSeedGroups } from '@zxio/tokens/kernel';
import type { ThemeSeedsV1 } from '@zxio/tokens/kernel';
import type { RuntimeThemeCoreView } from '../theme-runtime/runtime-descriptor';
import type { ResolvedThemeState } from '../theme-runtime/runtime';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
export type ZxThemeSeedGroup = (typeof themeSeedGroups)[number];
export interface ZxThemeSeedPolicy {
    readonly allow: readonly ZxThemeSeedGroup[];
}
export type ThemeSeedDeclarations = readonly (readonly [string, string])[];
/** One app/request owns these bounded caches; no DOM or global tenant state. */
export declare function createThemeCompositionSeedResolver(input: {
    readonly themes: readonly RuntimeThemeCoreView[];
    readonly policy?: ZxThemeSeedPolicy;
    readonly maxEntries?: number;
}): Readonly<{
    resolve(seeds: ThemeSeedsV1 | undefined, state: ResolvedThemeState): ThemeRuntimeResult<ThemeSeedDeclarations>;
    stats(): Readonly<{
        sources: number;
        variants: number;
        resolutions: number;
    }>;
    dispose(): void;
}>;
