import type { ZxThemeSeedPolicy, createThemeCompositionSeedResolver } from './composition-seeds';
import type { ThemeSeedsV1 } from '@zxio/tokens/kernel';
import type { ResolvedThemeExtensionSelectionV1, ThemeExtensionBundleV1, ThemeExtensionOverrides, ValidatedThemeExtensionBundleV1 } from '@zxio/tokens/extensions';
import type { RuntimeThemeCoreView } from '../theme-runtime/runtime-descriptor';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
import type { ThemeScopeCompositionPort } from '../theme-runtime/composition-contract';
export interface ZxThemeCompositionRequest {
    readonly modules?: readonly string[];
    /** Groups replace the nearest inherited group; null explicitly disables tenant seeds. */
    readonly seeds?: Partial<ThemeSeedsV1> | null;
    readonly overrides?: ThemeExtensionOverrides;
}
export interface ZxThemeCompositionOptions {
    readonly extensions?: readonly ThemeExtensionBundleV1[];
    readonly composition?: ZxThemeCompositionRequest;
    readonly seedPolicy?: ZxThemeSeedPolicy;
    readonly compositionStyleNonce?: string;
}
export interface ZxThemeCompositionState {
    readonly modules: readonly string[];
    readonly seeds: ThemeSeedsV1 | null;
    readonly overrides: ThemeExtensionOverrides;
    readonly publicTokens: ResolvedThemeExtensionSelectionV1['publicTokens'];
    readonly cssAdapters: ResolvedThemeExtensionSelectionV1['cssAdapters'];
    readonly registeredCssAdapters: ResolvedThemeExtensionSelectionV1['cssAdapters'];
    readonly consumerAdapters: Readonly<Record<string, 'ready' | 'inactive'>>;
}
export { parseCompositionRequest } from './composition-request';
/** Host owns this trusted compiler port; application code only supplies typed data. */
export declare function createHostThemeComposition<Theme extends RuntimeThemeCoreView>(options: ZxThemeCompositionOptions, themes: readonly Theme[], createSeedResolver: typeof createThemeCompositionSeedResolver): ThemeRuntimeResult<{
    readonly port: ThemeScopeCompositionPort;
    readonly bundles: readonly ValidatedThemeExtensionBundleV1[];
    readonly manifests: readonly Theme[];
    dispose(): void;
}>;
