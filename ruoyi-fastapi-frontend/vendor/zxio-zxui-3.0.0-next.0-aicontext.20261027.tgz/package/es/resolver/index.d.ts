export interface ZxuiResolverOptions {
    /** Import canonical structural styles. Set false when the host imports them. */
    importStyle?: boolean;
    /** Use explicit app capabilities for components available from the core entry. */
    entry?: 'default' | 'core';
}
export interface ZxuiComponentImport {
    name: string;
    from: string;
    sideEffects?: string;
}
/** Compatible with unplugin-vue-components without loading the UI runtime. */
export declare function ZxuiResolver(options?: ZxuiResolverOptions): {
    type: "component";
    resolve(name: string): ZxuiComponentImport | undefined;
};
