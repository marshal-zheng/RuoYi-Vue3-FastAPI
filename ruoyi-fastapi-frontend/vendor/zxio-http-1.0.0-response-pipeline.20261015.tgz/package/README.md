# @zxio/http

通用 HTTP 请求库，基于 Axios 封装，支持插件化扩展、自定义通知、Token 管理等。

## 快速开始

### 基础使用

```typescript
import { createHttpClient } from '@zxio/http'

// 创建客户端
const http = createHttpClient({
  axiosConfig: {
    baseURL: '/api',
    timeout: 10000,
  },
})

// 发起请求
const data = await http.get({ url: '/users' })
const user = await http.post({ url: '/users', data: { name: 'John' } })
```

### 配置 Token

```typescript
const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  tokenProvider: {
    getToken: () => localStorage.getItem('token') || '',
  },
})

// 请求会自动携带 Authorization header
const data = await http.get({ url: '/profile' })
```

### 自定义成功判定

```typescript
const http = createHttpClient({
  successCodes: [200, 0], // 支持多个成功码
  successResolver: ({ response }) => {
    const { code, data, msg } = response.data
    return {
      ok: code === 0,
      data,
      message: msg,
      code,
      raw: response.data,
    }
  },
})
```

### 集成 Provider scope 管理的反馈

```typescript
import { createHttpClient } from '@zxio/http'
import type { ThemeFeedback } from '@zxio/zxui'

export function createOwnedHttpClient(feedback: ThemeFeedback) {
  return createHttpClient({
    axiosConfig: { baseURL: '/api' },
    notifier: {
      message(type, content) {
        void feedback.message({ type, message: content })
      },
      modal(type, { title, content }) {
        void feedback.confirm({ type, title, message: content })
      },
    },
  })
}
```

由发起请求的 Provider scope 注入 `ThemeFeedback`，消息、确认框、目标节点和
`appContext` 因而共享同一个 owner；不得在 client 单例中捕获无上下文服务。

### 使用 Grid List 插件

```typescript
import { createHttpClient, createGridListPlugin } from '@zxio/http'

const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  plugins: [createGridListPlugin()],
})

// 发送请求
await http.post({
  url: '/users',
  data: {
    pager: { page: 1, size: 20 },
    query: { name: 'John' },
  },
})

// 自动转换为
// { page: 1, size: 20, name: 'John' }

// 响应自动补充 pager
// { list: [...], total: 100 } → { list: [...], pager: { page: 1, size: 20, total: 100 } }
```

### 自定义插件

```typescript
const loggerPlugin = {
  name: 'logger',
  setup(client) {
    client.extendTransforms({
      async beforeRequest(config) {
        console.log('Request:', config.url)
        return config
      },
      async afterResponse(response) {
        console.log('Response:', response.status)
        return response
      },
    })
  },
}

const http = createHttpClient({
  plugins: [loggerPlugin],
})
```

### 响应处理顺序

响应按以下顺序处理：

1. 按注册顺序执行全部 `afterResponse`，包括创建后通过 `use` 或
   `extendTransforms` 注册的 hook。返回 `AxiosResponse` 替换当前响应；
   返回普通值（含 `null`、`false`、`0`、空字符串）替换 `response.data`；
   返回 `undefined`/`void` 则保留当前响应。返回数据不再提前结束管线。
2. 正常转换模式下，统一调用一次 `successResolver`，判定加工后的响应，
   处理成功通知或抛出业务错误。
3. 统一返回 resolver 的 `data`，只在最后解包。

`isReturnNativeResponse: true` 仍跳过业务成功判定与解包，返回包含加工后
`data` 的完整 Axios 响应；`isTransformResponse: false` 返回加工后的完整
响应体，同样跳过 resolver。两种模式均执行响应加工 hook，HTTP 传输错误
仍由 Axios 判定。

hook 应保留 resolver 所需的协议字段。Grid List 插件保留 `code/data`
等外层协议，在内层数据中补充列表与 pager，并保留业务附加的非枚举元数据。
它不会代替成功判定或提前解包。该修复改变了以前“返回普通值即终止”的行为；
需要自定义最终返回值时，通过 `successResolver` 明确返回 `data`。

### 文件上传

```typescript
const http = createHttpClient({ axiosConfig: { baseURL: '/api' } })

await http.upload(
  { url: '/upload' },
  {
    file: fileObject,
    name: 'avatar', // 自定义字段名
    data: { userId: 123 }, // 额外参数
  },
  { timeout: 120000 } // 可选：单次请求选项
)
```

`Content-Type` 交给 axios 与浏览器按 `FormData` 自动补全（含 multipart boundary），手写会让服务端解析失败。

### 请求选项

每个请求可覆盖全局配置：

```typescript
// 不显示成功提示
await http.post({ url: '/users', data }, { successMessageMode: 'none' })

// 错误使用弹窗
await http.get({ url: '/critical' }, { errorMessageMode: 'modal' })

// 不携带 token
await http.get({ url: '/public' }, { withToken: false })

// 自定义提示消息
await http.post(
  { url: '/users', data },
  {
    successNotice: { message: '创建成功！' },
    errorNotice: { message: '创建失败，请重试' },
  }
)
```

### 请求重试

失败自动重试，支持指数退避：

```typescript
import { createHttpClient, exponentialBackoff } from '@zxio/http'

const http = createHttpClient({
  retry: {
    count: 3, // 最多重试 3 次
    delay: exponentialBackoff, // 指数退避: 1s, 2s, 4s...
  },
})

// 单次请求禁用重试
await http.get({ url: '/api/data' }, { retry: false })
```

### 请求去重

相同请求复用同一个 Promise：

```typescript
const http = createHttpClient({
  deduplication: true,
})

// 这两个请求只会发送一次
const [r1, r2] = await Promise.all([
  http.get({ url: '/api/user/1' }),
  http.get({ url: '/api/user/1' }),
])
```

### 超时控制

超时优先级由高到低为：单次请求第二参数的 `timeout`、单次请求配置中的
`requestOptions.timeout`、单次 Axios 配置中的 `timeout`、客户端默认
`requestOptions.timeout`，最后使用客户端分类型超时。`0` 表示禁用超时。
普通请求的分类型默认值优先使用 `timeout.default`，然后回退到
`axiosConfig.timeout` 和内置的 10 秒；上传、下载保留独立的 60 秒默认值。

```typescript
// 单次 Axios 配置可直接覆盖下载默认超时。
await http.get({ url: '/export', responseType: 'blob', timeout: 120000 })
```

不同请求类型使用不同超时：

```typescript
const http = createHttpClient({
  timeout: {
    default: 10000, // 普通请求 10s
    upload: 60000, // 上传 60s
    download: 60000, // 下载 60s
  },
})
```

### 错误类型

`HttpError` 保留原始 `cause`、`response` 以及请求配置（`config` 与兼容的
`request` 指向同一配置）；重复调用 `createHttpError` 会返回已分类的原错误。
业务可在错误上附加领域信息，无需重新包装成普通 `Error`。

主动取消统一为 `AbortError`，`code` 为 `ERR_CANCELED`，可用
`isAbortError(error)` 判断。`reason` 保留外部 signal 的取消原因。默认客户端
不为取消发出失败通知或鉴权失败回调，业务反馈也应跳过取消。

每个请求结束后清除自己的登记和外部 signal 监听；旧请求结束不会删除其
替代请求，Axios 序列化请求体也不影响清理。并发插件取消使用实际派发的
signal，排队请求收到外部取消后立即拒绝，且不会反向取消调用方的 controller。

细分错误类型，便于精确处理：

```typescript
import {
  NetworkError,
  TimeoutError,
  ValidationError,
  ServerError,
} from '@zxio/http'

try {
  await http.get({ url: '/api/data' })
} catch (e) {
  if (e instanceof NetworkError) console.log('网络不可用')
  if (e instanceof TimeoutError) console.log('请求超时')
  if (e instanceof ValidationError) console.log('参数错误:', e.status)
  if (e instanceof ServerError) console.log('服务器错误:', e.status)
}
```

### 并发控制

限制最大并发数，支持优先级：

```typescript
import { createHttpClient, createConcurrencyPlugin } from '@zxio/http'

const http = createHttpClient({
  plugins: [createConcurrencyPlugin({ maxConcurrent: 6 })],
})

// 高优先级请求优先执行
await http.get({ url: '/api/important' }, { priority: 10 })
```

### 类型安全 API

定义 API 端点，获得完整类型推导：

```typescript
import { createHttpClient, createTypedAPI } from '@zxio/http'

const api = createTypedAPI(http, {
  getUser: { method: 'GET', url: '/api/users/:id' },
  createUser: { method: 'POST', url: '/api/users' },
})

const user = await api.getUser({ id: 1 })
```

### 增强日志

结构化日志输出：

```typescript
import { createHttpClient, createEnhancedLogger } from '@zxio/http'

const http = createHttpClient({
  logger: createEnhancedLogger({
    enabled: true,
    level: 'debug',
    format: 'pretty', // pretty | json
  }),
})
```

## API

### createHttpClient(config)

创建 HTTP 客户端实例。

**参数：**

- `axiosConfig` - Axios 配置对象
- `tokenProvider` - Token 提供器
  - `getToken(): string | Promise<string>` - 获取 token
  - `applyToken?(config, token, options)` - 自定义 token 应用方式
  - `onAuthError?(error)` - 401 错误回调
- `notifier` - 通知适配器
  - `message(type, content)` - 消息通知
  - `modal(type, { title, content })` - 弹窗通知
- `successResolver` - 自定义成功判定
- `successCodes` - 成功状态码数组
- `requestOptions` - 默认请求选项
- `plugins` - 插件数组
- `logger` - 日志记录器

### 请求方法

- `http.get(config, options)` - GET 请求
- `http.post(config, options)` - POST 请求
- `http.put(config, options)` - PUT 请求
- `http.delete(config, options)` - DELETE 请求
- `http.upload(config, uploadOption, options)` - 文件上传
- `http.request(config, options)` - 通用请求

### 客户端实例

- `createHttpClient(config)` - 默认多例；`singleton: true` 时复用同一实例
- `resetHttpClientSingleton()` - 释放单例，使下一次创建重新读取配置

### 插件

- `createGridListPlugin(options)` - Grid List 数据转换插件
- `createConcurrencyPlugin(options)` - 并发控制插件；同一 client 只会接管一次，`teardown(client)` 可还原

## 类型定义

```typescript
interface HttpClientConfig {
  axiosConfig?: AxiosRequestConfig
  tokenProvider?: HttpTokenProvider
  notifier?: HttpNotifier
  successResolver?: SuccessResolver
  successCodes?: Array<string | number>
  requestOptions?: RequestOptions
  plugins?: HttpPlugin[]
  logger?: HttpClientLogger
}

interface RequestOptions {
  withToken?: boolean
  successMessageMode?: 'auto' | 'message' | 'modal' | 'none'
  errorMessageMode?: 'message' | 'modal' | 'none'
  showSuccessMessage?: boolean
  showErrorMessage?: boolean
  isTransformResponse?: boolean
  isReturnNativeResponse?: boolean
  joinParamsToUrl?: boolean
  joinTime?: boolean
  ignoreCancelToken?: boolean
  successNotice?: { title?: string; message?: string }
  errorNotice?: { title?: string; message?: string }
  context?: Record<string, unknown>
}
```
