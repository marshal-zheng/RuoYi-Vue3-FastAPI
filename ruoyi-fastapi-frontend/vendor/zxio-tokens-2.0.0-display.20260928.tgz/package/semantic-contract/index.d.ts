import { ThemeExtensionCoreDescriptor } from '../extensions/model';
export type ThemeSemanticEntry = ThemeExtensionCoreDescriptor['publicSurface'][number];
export interface ThemeSemanticCatalog extends ThemeExtensionCoreDescriptor {
    readonly schema: 'zx.theme-semantic-contract/1';
    readonly entries: readonly (ThemeSemanticEntry & {
        readonly description: string;
    })[];
}
/** Every projection comes from the same validated canonical contract and CSS rules. */
export declare function createThemeSemanticCatalog(): ThemeSemanticCatalog;
export declare const themeSemanticCatalog: ThemeSemanticCatalog;
export declare const stableThemeSemantics: readonly ({
    readonly path: string;
    readonly typeId: string;
    readonly lifecycle: string;
    readonly css: {
        readonly publicVariable: string;
        readonly fields?: Readonly<Record<string, string>>;
    };
    readonly deprecated?: {
        readonly since: string;
        readonly replacement?: string;
        readonly noReplacementReason?: string;
    };
} & {
    readonly description: string;
})[];
