"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const kernel_index = require("../kernel/index.cjs");
const plan = require("../_chunks/plan-4Y2aAaJC.cjs");
function createThemeSemanticCatalog() {
  const entries = Object.entries(kernel_index.canonicalThemeContractV4.entries).sort(([a], [b]) => a.localeCompare(b)).map(([path, candidate]) => {
    const entry = candidate;
    return {
      path,
      typeId: entry.typeId,
      lifecycle: entry.lifecycle,
      description: entry.description,
      css: {
        publicVariable: plan.publicCoreVariable(path),
        ...entry.typeId === "typography" ? {
          fields: Object.fromEntries(
            plan.TYPOGRAPHY_FIELDS.map((field) => [
              field,
              `${plan.publicCoreVariable(path)}-${field}`
            ])
          )
        } : {}
      },
      ...entry.lifecycle === "deprecated" ? {
        deprecated: {
          since: entry.deprecatedSince,
          ...entry.migration.kind === "replacement" ? { replacement: entry.migration.path } : { noReplacementReason: entry.migration.reason.detail }
        }
      } : {}
    };
  });
  return plan.snapshot({
    schema: "zx.theme-semantic-contract/1",
    contractVersion: kernel_index.canonicalThemeContractV4.contractVersion,
    typeRegistryContentHash: kernel_index.themeKernel.typeRegistryContentHash,
    contractContentHash: plan.hashThemeExtensionContent(kernel_index.canonicalThemeContractV4),
    entries,
    publicSurface: entries.map(
      ({ description: _description, ...entry }) => entry
    )
  });
}
const themeSemanticCatalog = createThemeSemanticCatalog();
const stableThemeSemantics = Object.freeze(
  themeSemanticCatalog.entries.filter((entry) => entry.lifecycle === "stable")
);
exports.createThemeSemanticCatalog = createThemeSemanticCatalog;
exports.stableThemeSemantics = stableThemeSemantics;
exports.themeSemanticCatalog = themeSemanticCatalog;
