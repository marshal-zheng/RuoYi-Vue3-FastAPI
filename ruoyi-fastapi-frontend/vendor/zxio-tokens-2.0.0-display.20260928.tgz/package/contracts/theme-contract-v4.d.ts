export declare const canonicalThemeContractV4Input: {
    readonly contractVersion: "4.0.0";
    readonly entries: {
        readonly 'semantic.surface.page': {
            readonly typeId: "color";
            readonly lifecycle: "stable";
            readonly description: "Page-level background surface shared across applications.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Application shells and content pages share one page surface role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.surface.elevated': {
            readonly typeId: "color";
            readonly lifecycle: "stable";
            readonly description: "Elevated container surface shared by cards and overlays.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Cards, popups, and panels share an elevation surface role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.text.primary': {
            readonly typeId: "color";
            readonly lifecycle: "stable";
            readonly description: "Primary foreground text color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "All readable components require a common primary text role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.text.secondary': {
            readonly typeId: "color";
            readonly lifecycle: "stable";
            readonly description: "Secondary foreground text color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Supporting labels and metadata share a secondary text role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.action.focus-ring': {
            readonly typeId: "color";
            readonly lifecycle: "stable";
            readonly description: "Accessible focus indicator color for interactive controls.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Keyboard-focus affordances require one accessible role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.spacing.control-y': {
            readonly typeId: "dimension";
            readonly lifecycle: "stable";
            readonly description: "Vertical control padding derived from the selected density.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Inputs and buttons align to the same density rhythm.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.radius.control': {
            readonly typeId: "dimension";
            readonly lifecycle: "stable";
            readonly description: "Shared control corner radius.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Controls share one composable radius role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.motion.duration': {
            readonly typeId: "duration";
            readonly lifecycle: "stable";
            readonly description: "Default interaction motion duration.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Interactive components share a motion timing role.";
                readonly evidence: readonly ["packages/theme-default/src/theme.ts"];
            };
        };
        readonly 'semantic.border.subtle': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Low-emphasis border and divider color for quiet edges.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Editor containers, toolbars, tables, and popup surfaces need a quiet edge role instead of reusing secondary text color as borders.";
                readonly evidence: readonly ["packages/text-editor/style/_editor.scss", "packages/text-editor/style/_toolbar.scss", "packages/text-editor/style/extensions/_table.scss"];
            };
        };
        readonly 'semantic.border.strong': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Emphasized border and divider color for prominent edges.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Horizontal rules and emphasized separators need a stronger edge role than subtle borders without borrowing text colors.";
                readonly evidence: readonly ["packages/text-editor/style/_editor.scss", "packages/text-editor/style/_toolbar.scss"];
            };
        };
        readonly 'semantic.fill.hover': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Translucent hover fill for interactive rows and controls.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Menu items, toolbar buttons, and list rows need a hover fill that works on any surface instead of reusing the page background.";
                readonly evidence: readonly ["packages/text-editor/style/_toolbar.scss", "packages/text-editor/style/_menu.scss", "packages/text-editor/style/extensions/_drag-handle.scss"];
            };
        };
        readonly 'semantic.fill.active': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Translucent pressed/selected fill for interactive elements.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Active toolbar toggles, selected rows, and inline code chips need a fill one step stronger than hover.";
                readonly evidence: readonly ["packages/text-editor/style/_toolbar.scss", "packages/text-editor/style/_editor.scss"];
            };
        };
        readonly 'semantic.accent.base': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Full-strength brand fill and active indicator color; use accent.on-surface for readable text.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Brand fills, carets, and active-state indicators need an opaque accent role; action labels use the separate readable foreground roles.";
                readonly evidence: readonly ["packages/text-editor/style/_editor.scss", "packages/text-editor/style/_popup.scss"];
            };
        };
        readonly 'semantic.accent.subtle': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Low-emphasis accent wash for selected items and highlights.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Selected menu entries, selected table cells, and keyboard-highlighted suggestions share an accent-tinted background role.";
                readonly evidence: readonly ["packages/text-editor/style/extensions/_suggestion.scss", "packages/text-editor/style/extensions/_table.scss"];
            };
        };
        readonly 'semantic.status.danger': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Destructive action and error status color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Delete menu entries and inline validation errors need a status role instead of rendering in primary text color.";
                readonly evidence: readonly ["packages/text-editor/style/_popup.scss", "packages/text-editor/style/extensions/_table.scss"];
            };
        };
        readonly 'semantic.radius.surface': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.1.0";
            readonly description: "Corner radius for floating surfaces and cards.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Popovers, menus, and cards need a larger radius step than inline controls to read as elevated surfaces.";
                readonly evidence: readonly ["packages/text-editor/style/_menu.scss", "packages/text-editor/style/_popup.scss"];
            };
        };
        readonly 'semantic.status.success': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Positive confirmation status color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Structural styles and Element Plus components share one positive confirmation status role instead of hard-coding library defaults.";
                readonly evidence: readonly ["packages/theme-chalk/src/structural.css", "packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Cautionary status color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Structural styles and Element Plus components share one cautionary status role instead of hard-coding library defaults.";
                readonly evidence: readonly ["packages/theme-chalk/src/structural.css", "packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Neutral informational status color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "cross-component";
                readonly consumerUseCase: "Structural styles and Element Plus components share one neutral informational status role instead of hard-coding library defaults.";
                readonly evidence: readonly ["packages/theme-chalk/src/structural.css", "packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.accent.tint-3': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Brand accent tint step (tint-3) for hover emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives hover emphasis from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.accent.tint-5': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Brand accent tint step (tint-5) for muted emphasis and disabled strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.accent.tint-7': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Brand accent tint step (tint-7) for quiet strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives quiet strokes from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.accent.tint-8': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Brand accent tint step (tint-8) for tinted borders and quiet chips.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives tinted borders and quiet chips from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.accent.tint-9': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Brand accent tint step (tint-9) for wash backgrounds.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives wash backgrounds from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.accent.shade-2': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Brand accent shade step (shade-2) for pressed/active emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives pressed/active emphasis from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.success-tint-3': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Success status tint step (tint-3) for hover emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives hover emphasis from the success status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.success-tint-5': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Success status tint step (tint-5) for muted emphasis and disabled strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the success status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.success-tint-7': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Success status tint step (tint-7) for quiet strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives quiet strokes from the success status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.success-tint-8': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Success status tint step (tint-8) for tinted borders and quiet chips.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives tinted borders and quiet chips from the success status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.success-tint-9': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Success status tint step (tint-9) for wash backgrounds.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives wash backgrounds from the success status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.success-shade-2': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Success status shade step (shade-2) for pressed/active emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives pressed/active emphasis from the success status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning-tint-3': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Warning status tint step (tint-3) for hover emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives hover emphasis from the warning status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning-tint-5': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Warning status tint step (tint-5) for muted emphasis and disabled strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the warning status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning-tint-7': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Warning status tint step (tint-7) for quiet strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives quiet strokes from the warning status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning-tint-8': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Warning status tint step (tint-8) for tinted borders and quiet chips.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives tinted borders and quiet chips from the warning status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning-tint-9': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Warning status tint step (tint-9) for wash backgrounds.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives wash backgrounds from the warning status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.warning-shade-2': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Warning status shade step (shade-2) for pressed/active emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives pressed/active emphasis from the warning status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info-tint-3': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Info status tint step (tint-3) for hover emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives hover emphasis from the info status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info-tint-5': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Info status tint step (tint-5) for muted emphasis and disabled strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the info status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info-tint-7': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Info status tint step (tint-7) for quiet strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives quiet strokes from the info status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info-tint-8': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Info status tint step (tint-8) for tinted borders and quiet chips.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives tinted borders and quiet chips from the info status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info-tint-9': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Info status tint step (tint-9) for wash backgrounds.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives wash backgrounds from the info status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.info-shade-2': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Info status shade step (shade-2) for pressed/active emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives pressed/active emphasis from the info status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.danger-tint-3': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Danger status tint step (tint-3) for hover emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives hover emphasis from the danger status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.danger-tint-5': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Danger status tint step (tint-5) for muted emphasis and disabled strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the danger status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.danger-tint-7': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Danger status tint step (tint-7) for quiet strokes.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives quiet strokes from the danger status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.danger-tint-8': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Danger status tint step (tint-8) for tinted borders and quiet chips.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives tinted borders and quiet chips from the danger status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.danger-tint-9': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Danger status tint step (tint-9) for wash backgrounds.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives wash backgrounds from the danger status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.status.danger-shade-2': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Danger status shade step (shade-2) for pressed/active emphasis.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus derives pressed/active emphasis from the danger status color; without a themed ramp those states keep default-palette values after a reskin.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.surface.body': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Component body surface for dialogs, cards, tables, and menus.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus component bodies read one base background variable; without this role they stay light in dark variants.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.text.disabled': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Disabled text and icon color.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Disabled labels need one themed role; Element Plus reads a dedicated disabled text variable that otherwise keeps default values.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.overlay.modal': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Modal backdrop scrim at full strength.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Overlay scrims and loading masks must flip with the theme mode; Element Plus reads dedicated overlay/mask variables.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.overlay.mask': {
            readonly typeId: "color";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Loading mask surface tint.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Overlay scrims and loading masks must flip with the theme mode; Element Plus reads dedicated overlay/mask variables.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.motion.duration-fast': {
            readonly typeId: "duration";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Fast interaction motion duration for borders, color, and fades.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Element Plus fast transitions read a dedicated duration variable that must follow the motion axis with the base duration.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.family': {
            readonly typeId: "font-family";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Base interface font stack.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.size-extra-small': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Extra-small font size step.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.size-small': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Small font size step.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.size-base': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Base font size step.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.size-medium': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Medium font size step.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.size-large': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Large font size step.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.size-extra-large': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Extra-large font size step.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.weight-primary': {
            readonly typeId: "font-weight";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Primary emphasis font weight.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
        readonly 'semantic.typography.line-height-base': {
            readonly typeId: "dimension";
            readonly lifecycle: "experimental";
            readonly introducedIn: "4.2.0";
            readonly description: "Base line height for controls and labels.";
            readonly owner: "design-system";
            readonly rationale: {
                readonly kind: "external-api";
                readonly consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.";
                readonly evidence: readonly ["packages/theme-compiler/src/adapters/element-plus/mapping.ts"];
            };
        };
    };
};
