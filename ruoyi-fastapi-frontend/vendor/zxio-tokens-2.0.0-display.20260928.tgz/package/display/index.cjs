"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const DISPLAY_CONTRACT_VERSION = 1;
const DISPLAY_SCALES = [90, 100, 110, 125];
const DISPLAY_PROFILES = ["office", "distance"];
const displayMetricCatalog = Object.freeze({
  "text.extra-small": {
    source: "semantic.typography.size-extra-small",
    policy: "ui-length",
    role: "text",
    office100Px: 12,
    distance100Px: 20,
    officeFloorPx: 11,
    distanceFloorPx: 18
  },
  "text.small": {
    source: "semantic.typography.size-small",
    policy: "ui-length",
    role: "text",
    office100Px: 13,
    distance100Px: 20,
    officeFloorPx: 12,
    distanceFloorPx: 18
  },
  "text.body": {
    source: "semantic.typography.size-base",
    policy: "ui-length",
    role: "text",
    office100Px: 14,
    distance100Px: 24,
    officeFloorPx: 12,
    distanceFloorPx: 20
  },
  "text.medium": {
    source: "semantic.typography.size-medium",
    policy: "ui-length",
    role: "text",
    office100Px: 16,
    distance100Px: 24,
    officeFloorPx: 14,
    distanceFloorPx: 20
  },
  "text.large": {
    source: "semantic.typography.size-large",
    policy: "ui-length",
    role: "text",
    office100Px: 18,
    distance100Px: 28,
    officeFloorPx: 16,
    distanceFloorPx: 24
  },
  "text.title": {
    source: "semantic.typography.size-extra-large",
    policy: "ui-length",
    role: "text",
    office100Px: 20,
    distance100Px: 32,
    officeFloorPx: 18,
    distanceFloorPx: 28
  },
  "line.body": {
    source: "semantic.typography.line-height-base",
    policy: "ui-length",
    role: "line-box",
    office100Px: 24,
    distance100Px: 32,
    officeFloorPx: 22,
    distanceFloorPx: 28
  },
  "spacing.control-y": {
    source: "semantic.spacing.control-y",
    policy: "ui-length",
    role: "spacing",
    office100Px: 8,
    distance100Px: 12
  },
  "icon.default": {
    source: "display.icon.default",
    policy: "ui-length",
    role: "icon",
    office100Px: 16,
    distance100Px: 28,
    officeFloorPx: 14,
    distanceFloorPx: 24
  },
  "stroke.hairline": {
    source: "display.stroke.hairline",
    policy: "fixed-length",
    role: "stroke",
    office100Px: 1,
    distance100Px: 1
  },
  "content.canvas-pixel": {
    source: "display.content.canvas-pixel",
    policy: "domain-length",
    role: "content"
  },
  "text.line-height-ratio": {
    source: "display.text.line-height-ratio",
    policy: "unitless-ratio",
    role: "text"
  }
});
function displayCssVariables(id) {
  const suffix = id.replaceAll(".", "-");
  return {
    base: `--zx-display-base-${suffix}`,
    effective: `--zx-display-${suffix}`
  };
}
function displayProjectionDeclarations(profile, scale) {
  if (!isDisplayProfile(profile) || !isDisplayScale(scale))
    throw new TypeError("Invalid display request");
  const declarations = [];
  for (const [id, metric] of Object.entries(displayMetricCatalog)) {
    if (metric.policy !== "ui-length") continue;
    const ratio = profile === "distance" && metric.distance100Px && metric.office100Px ? metric.distance100Px / metric.office100Px : 1;
    const factor = Number((ratio * scale / 100).toPrecision(12));
    const fallback = metric.source.startsWith("semantic.") ? `, var(--zx-${metric.source.replaceAll(".", "-")})` : id === "icon.default" ? ", 1rem" : "";
    const value = `calc(var(${displayCssVariables(id).base}${fallback}) * ${factor})`;
    const floor = profile === "distance" ? metric.distanceFloorPx : metric.officeFloorPx;
    declarations.push([
      displayCssVariables(id).effective,
      floor === void 0 ? value : `max(${floor / 16}rem, ${value})`
    ]);
  }
  declarations.push([
    "--zx-display-control-factor",
    String(displayControlFactor(profile, scale))
  ]);
  declarations.push([
    "--zx-display-control-min",
    profile === "distance" ? `${3.5 * scale / 100}rem` : "0px"
  ]);
  return Object.freeze(
    declarations.sort(([left], [right]) => left.localeCompare(right))
  );
}
function displayControlFactor(profile, scale) {
  if (!isDisplayProfile(profile) || !isDisplayScale(scale))
    throw new TypeError("Invalid display request");
  return (profile === "distance" ? 1.5 : 1) * scale / 100;
}
const displayContractBody = {
  schema: "zx.display-contract/1",
  version: DISPLAY_CONTRACT_VERSION,
  scales: DISPLAY_SCALES,
  profiles: DISPLAY_PROFILES,
  metrics: displayMetricCatalog
};
const displayContractManifest = Object.freeze({
  ...displayContractBody,
  contentHash: "sha256:49178b3aa8469e5e0b25c156e4e00d5e0ca5260e99b8f9f58e78b4013a8e94b1"
});
function sameDisplayContractValue(left, right) {
  if (Object.is(left, right)) return true;
  if (Array.isArray(left) || Array.isArray(right))
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every(
      (entry, index) => sameDisplayContractValue(entry, right[index])
    );
  if (!left || !right || typeof left !== "object" || typeof right !== "object")
    return false;
  const lhs = left;
  const rhs = right;
  const keys = Object.keys(lhs);
  return keys.length === Object.keys(rhs).length && keys.every(
    (key) => Object.hasOwn(rhs, key) && sameDisplayContractValue(lhs[key], rhs[key])
  );
}
function checkDisplayContract(candidate, explicitDisplay) {
  if (candidate === void 0)
    return explicitDisplay ? { ok: false, code: "ZX_DISPLAY_CONTRACT_MISSING" } : { ok: true, capability: "legacy-default" };
  try {
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate))
      return { ok: false, code: "ZX_DISPLAY_CONTRACT_MISMATCH" };
    const record = candidate;
    if (Object.keys(record).length !== Object.keys(displayContractManifest).length || !Object.keys(displayContractManifest).every(
      (key) => Object.hasOwn(record, key)
    ) || record.schema !== displayContractManifest.schema || record.version !== displayContractManifest.version || record.contentHash !== displayContractManifest.contentHash)
      return { ok: false, code: "ZX_DISPLAY_CONTRACT_MISMATCH" };
    return sameDisplayContractValue(record, displayContractManifest) ? { ok: true, capability: "display-v1" } : { ok: false, code: "ZX_DISPLAY_CONTRACT_MISMATCH" };
  } catch {
    return { ok: false, code: "ZX_DISPLAY_CONTRACT_MISMATCH" };
  }
}
function isDisplayScale(value) {
  return DISPLAY_SCALES.some((scale) => scale === value);
}
function isDisplayProfile(value) {
  return DISPLAY_PROFILES.some((profile) => profile === value);
}
function projectDisplayLength(basePx, policy, scale) {
  if (!Number.isFinite(basePx) || !isDisplayScale(scale))
    throw new TypeError("Invalid display length or scale");
  return policy === "ui-length" ? basePx * scale / 100 : basePx;
}
function projectDisplayMetric(id, basePx, profile, scale) {
  if (!isDisplayProfile(profile)) throw new TypeError("Invalid display profile");
  const metric = displayMetricCatalog[id];
  if (!metric) throw new TypeError(`Unknown display metric: ${id}`);
  const source = profile === "distance" && "distance100Px" in metric && "office100Px" in metric ? basePx * metric.distance100Px / metric.office100Px : basePx;
  const projected = projectDisplayLength(source, metric.policy, scale);
  const floor = profile === "distance" ? "distanceFloorPx" in metric ? metric.distanceFloorPx : void 0 : "officeFloorPx" in metric ? metric.officeFloorPx : void 0;
  return floor === void 0 ? projected : Math.max(floor, projected);
}
const elementPlusSizeOffsets = {
  small: 8,
  default: 16,
  large: 24
};
function elementPlusDisplayProjectionDeclarations(profile, scale) {
  const factor = displayControlFactor(profile, scale);
  const minimum = profile === "distance" ? `${3.5 * scale / 100}rem` : "0px";
  return Object.entries(elementPlusSizeOffsets).map(
    ([size, offset]) => [
      size === "default" ? "--el-component-size" : `--el-component-size-${size}`,
      `max(calc((var(--zx-semantic-spacing-control-y) * 2 + ${offset}px) * ${factor}), ${minimum})`
    ]
  );
}
function elementPlusTypographyProjectionDeclarations() {
  const mapping = [
    ["--el-font-size-extra-small", "text.extra-small"],
    ["--el-font-size-small", "text.small"],
    ["--el-font-size-base", "text.body"],
    ["--el-font-size-medium", "text.medium"],
    ["--el-font-size-large", "text.large"],
    ["--el-font-size-extra-large", "text.title"],
    ["--el-font-line-height-primary", "line.body"]
  ];
  return mapping.map(([property, id]) => {
    const source = displayMetricCatalog[id].source;
    return [
      property,
      `var(${displayCssVariables(id).effective}, var(--zx-${source.replaceAll(
        ".",
        "-"
      )}))`
    ];
  });
}
function projectElementPlusControlHeight(controlYPx, size, profile, scale) {
  if (!Number.isFinite(controlYPx) || controlYPx < 0 || !isDisplayProfile(profile) || !(size in elementPlusSizeOffsets))
    throw new TypeError("Invalid Element Plus control recipe");
  const base = controlYPx * 2 + elementPlusSizeOffsets[size];
  const projected = base * displayControlFactor(profile, scale);
  return profile === "distance" ? Math.max(projected, 56 * scale / 100) : projected;
}
function projectInteractionHeight(contentHeightPx, touch) {
  if (!Number.isFinite(contentHeightPx) || contentHeightPx < 0)
    throw new TypeError("Invalid content height");
  return touch ? Math.max(contentHeightPx, 44) : contentHeightPx;
}
exports.DISPLAY_CONTRACT_VERSION = DISPLAY_CONTRACT_VERSION;
exports.DISPLAY_PROFILES = DISPLAY_PROFILES;
exports.DISPLAY_SCALES = DISPLAY_SCALES;
exports.checkDisplayContract = checkDisplayContract;
exports.displayContractManifest = displayContractManifest;
exports.displayControlFactor = displayControlFactor;
exports.displayCssVariables = displayCssVariables;
exports.displayMetricCatalog = displayMetricCatalog;
exports.displayProjectionDeclarations = displayProjectionDeclarations;
exports.elementPlusDisplayProjectionDeclarations = elementPlusDisplayProjectionDeclarations;
exports.elementPlusSizeOffsets = elementPlusSizeOffsets;
exports.elementPlusTypographyProjectionDeclarations = elementPlusTypographyProjectionDeclarations;
exports.isDisplayProfile = isDisplayProfile;
exports.isDisplayScale = isDisplayScale;
exports.projectDisplayLength = projectDisplayLength;
exports.projectDisplayMetric = projectDisplayMetric;
exports.projectElementPlusControlHeight = projectElementPlusControlHeight;
exports.projectInteractionHeight = projectInteractionHeight;
