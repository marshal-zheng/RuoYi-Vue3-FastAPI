import { canonicalJsonStringify } from '../kernel/canonical-json';
import { computeCanonicalHash } from '../kernel/content-hash';
import { CanonicalJsonValue, ThemeAxisSelection } from '../kernel/model';
import { ThemeExtensionDiagnostic, ThemeExtensionDiagnosticCode, ThemeExtensionResult } from './model';
export declare const AXES: readonly ["mode", "density", "contrast", "motion", "radius"];
export declare const DOMAINS: {
    readonly mode: readonly ["light", "dark"];
    readonly density: readonly ["compact", "default", "comfortable"];
    readonly contrast: readonly ["normal", "high", "forced-colors"];
    readonly motion: readonly ["full", "reduced", "none"];
    readonly radius: readonly ["sharp", "default", "rounded"];
};
export declare const TYPOGRAPHY_FIELDS: readonly ["fontFamily", "fontSize", "fontWeight", "lineHeight", "letterSpacing"];
export declare const ID: RegExp;
export declare const HASH: RegExp;
export declare const PACKAGE: RegExp;
export declare const VARIABLE: RegExp;
export declare const canonicalThemeExtensionJson: typeof canonicalJsonStringify;
export declare const hashThemeExtensionContent: typeof computeCanonicalHash;
export declare const hashThemeExtensionText: (text: string) => `sha256:${string}`;
export declare const sortText: (a: string, b: string) => 1 | 0 | -1;
export declare function record(value: unknown): value is Record<string, unknown>;
export declare class ExtensionFailureError extends Error {
    readonly diagnostic: ThemeExtensionDiagnostic;
    constructor(diagnostic: ThemeExtensionDiagnostic);
}
export declare function fail(code: ThemeExtensionDiagnosticCode, path: string, details?: Readonly<Record<string, CanonicalJsonValue>>): never;
export declare function requireThat(condition: unknown, code: ThemeExtensionDiagnosticCode, path: string, details?: Readonly<Record<string, CanonicalJsonValue>>): asserts condition;
export declare function exact(value: unknown, required: readonly string[], optional: readonly string[], path: string): asserts value is Record<string, unknown>;
export declare function text(value: unknown, path: string): asserts value is string;
export declare function safePath(value: unknown, path: string): asserts value is string;
export declare function snapshot<T>(value: T): T;
export declare function result<T>(run: () => T, warnings?: ThemeExtensionDiagnostic[]): ThemeExtensionResult<T>;
export declare function unwrap<T>(value: ThemeExtensionResult<T>): T;
export declare function axisSelection(input: unknown): ThemeAxisSelection;
export declare function allSelections(): ThemeAxisSelection[];
interface Version {
    readonly core: readonly number[];
    readonly pre: readonly string[];
}
export declare function parseVersion(input: unknown): Version | null;
/** Deliberately explicit stable semver range grammar: exact, ^, ~, comparators and ||. */
export declare function versionSatisfies(actual: string, range: string): boolean | null;
export {};
