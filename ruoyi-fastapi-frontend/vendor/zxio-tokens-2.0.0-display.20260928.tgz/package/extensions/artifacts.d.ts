import { CompiledThemeModuleV1, ThemeExtensionArtifact, ThemeExtensionFile, ThemeExtensionLiteralCssEncoder, ThemeExtensionManifestPlanV1, ThemeExtensionManifestV1 } from './model';
export declare const EXTENSION_ARTIFACTS: readonly [{
    readonly path: "extension.css";
    readonly mediaType: "text/css";
    readonly purpose: "css";
}, {
    readonly path: "refs.mjs";
    readonly mediaType: "text/javascript";
    readonly purpose: "refs-esm";
}, {
    readonly path: "refs.cjs";
    readonly mediaType: "text/javascript";
    readonly purpose: "refs-cjs";
}, {
    readonly path: "refs.d.ts";
    readonly mediaType: "text/typescript";
    readonly purpose: "types";
}];
export declare function renderThemeExtensionFiles(plan: ThemeExtensionManifestPlanV1 | ThemeExtensionManifestV1, encoder: ThemeExtensionLiteralCssEncoder, dependencies?: readonly CompiledThemeModuleV1[]): readonly ThemeExtensionFile[];
export declare function artifactDescriptors(files: readonly ThemeExtensionFile[]): readonly ThemeExtensionArtifact[];
export declare function sealThemeExtensionManifest(plan: ThemeExtensionManifestPlanV1, artifacts: readonly ThemeExtensionArtifact[]): ThemeExtensionManifestV1;
