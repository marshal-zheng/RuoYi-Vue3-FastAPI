import { CompiledThemeCssAdapterV1, ResolveThemeExtensionDeclarationsInput, ResolvedThemeExtensionSelectionV1, ThemeExtensionCoreDescriptor, ValidatedThemeExtensionManifestV1, ThemeExtensionResult } from './model';
export declare function validateThemeExtensionCoreRequirements(manifests: readonly ValidatedThemeExtensionManifestV1[], input: ThemeExtensionCoreDescriptor): ThemeExtensionResult<true>;
export declare function validateThemeCssAdapterTarget(input: {
    readonly adapter: CompiledThemeCssAdapterV1;
    readonly actualVersion: string;
}): ThemeExtensionResult<true>;
export declare function resolveThemeExtensionDeclarations(input: ResolveThemeExtensionDeclarationsInput): ThemeExtensionResult<ResolvedThemeExtensionSelectionV1>;
