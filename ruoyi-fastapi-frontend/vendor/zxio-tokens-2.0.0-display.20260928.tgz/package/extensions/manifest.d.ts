import { CreateThemeExtensionPlanInput, ThemeExtensionBundleV1, ThemeExtensionLiteralCssEncoder, ThemeExtensionManifestV1, ValidatedThemeExtensionBundleV1, ValidatedThemeExtensionManifestV1, ThemeExtensionResult } from './model';
export interface ThemeExtensionValidationOptions {
    readonly encoder: ThemeExtensionLiteralCssEncoder;
    readonly dependencies?: readonly ThemeExtensionManifestV1[];
}
export declare function validateThemeExtensionManifest(input: unknown, options: ThemeExtensionValidationOptions): ThemeExtensionResult<ValidatedThemeExtensionManifestV1>;
export declare function validateThemeExtensionBundle(input: unknown, options: ThemeExtensionValidationOptions): ThemeExtensionResult<ValidatedThemeExtensionBundleV1>;
/** Pure assembly for the Node compiler. The shared protocol owns no filesystem. */
export declare function createThemeExtensionBundle(input: CreateThemeExtensionPlanInput): ThemeExtensionResult<ThemeExtensionBundleV1>;
