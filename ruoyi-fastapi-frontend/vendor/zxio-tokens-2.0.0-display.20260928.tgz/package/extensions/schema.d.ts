import { BuiltInTypeId } from '../kernel/model';
import { ThemeCssAdapterInput, ThemeExtensionValue, ThemeModuleInput, ValidatedThemeModule, ThemeExtensionResult } from './model';
export declare function normalizeValue(input: unknown, typeId: BuiltInTypeId, path: string): ThemeExtensionValue;
export declare function normalizeModule(input: unknown): ThemeModuleInput;
export declare function defineThemeModule<const T extends ThemeModuleInput>(input: T): ThemeExtensionResult<ValidatedThemeModule<T>>;
export declare function normalizeAdapter(input: unknown): ThemeCssAdapterInput;
export declare function defineThemeCssAdapter(input: ThemeCssAdapterInput): ThemeExtensionResult<ThemeCssAdapterInput>;
