import { KernelResult } from './diagnostics';
import { AppliedTransform, CanonicalTokenPath, LogicalSourceLocator, ThemeAxisName, ThemeAxisSelection, ThemeTypeMap, ValidatedThemeSourceV4 } from './model';
import { TypeRegistry } from './token-types';
export interface EffectiveTokenDefinition {
    readonly path: CanonicalTokenPath;
    readonly layer: 'foundation' | 'semantic' | 'components';
    readonly component?: string;
    readonly typeId: string;
    readonly value: unknown;
    readonly source: LogicalSourceLocator;
    readonly appliedTransforms: readonly AppliedTransform[];
}
export interface EffectiveThemeDefinitions {
    readonly selection: ThemeAxisSelection;
    readonly definitions: Readonly<Record<CanonicalTokenPath, EffectiveTokenDefinition>>;
    readonly directWritesByAxis: Readonly<Record<ThemeAxisName, readonly CanonicalTokenPath[]>>;
}
export declare function applyThemeAxes<M extends ThemeTypeMap>(registry: TypeRegistry<M>, source: ValidatedThemeSourceV4<M>, requested: Partial<ThemeAxisSelection> | undefined): KernelResult<EffectiveThemeDefinitions>;
