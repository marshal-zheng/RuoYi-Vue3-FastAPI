import { Sha256 } from './content-hash';
import { KernelResult } from './diagnostics';
import { BuiltInTypeId, BuiltInTypeMap, CanonicalJsonValue, ExtensionSchemaInput, ExtensionTypeDescriptor, LogicalSourceLocator, ThemeTypeMap, TokenTypeId } from './model';
export declare const BUILT_IN_TYPE_IDS: readonly ["border", "color", "cubic-bezier", "dimension", "duration", "font-family", "font-weight", "gradient", "number", "shadow", "strokeStyle", "string", "transition", "typography"];
interface CanonicalizationSuccess<T> {
    readonly ok: true;
    readonly value: T;
}
interface CanonicalizationFailure {
    readonly ok: false;
    readonly rule: string;
    readonly instancePath: string;
}
type Canonicalization<T> = CanonicalizationSuccess<T> | CanonicalizationFailure;
export declare function canonicalizeBuiltIn<K extends BuiltInTypeId>(typeId: K, input: unknown): Canonicalization<BuiltInTypeMap[K]>;
export interface RegisteredExtension {
    readonly descriptorIndex: number;
    readonly typeId: string;
    readonly schemaVersion: number;
    readonly canonicalSchema: ExtensionSchemaInput;
    readonly canonicalSchemaHash: Sha256;
    readonly validate: (input: unknown) => readonly unknown[];
    readonly canonicalize: (input: unknown) => unknown;
}
export interface TypeRegistry<M extends ThemeTypeMap = BuiltInTypeMap> {
    readonly registeredTypeIds: readonly TokenTypeId<M>[];
    readonly typeRegistryContentHash: Sha256;
    readonly extensions: Readonly<Record<string, RegisteredExtension>>;
}
interface RuntimeTypeRegistry {
    readonly registeredTypeIds: readonly string[];
    readonly typeRegistryContentHash: Sha256;
    readonly extensions: Readonly<Record<string, RegisteredExtension>>;
}
export declare function createTypeRegistry<const D extends readonly ExtensionTypeDescriptor[]>(source: LogicalSourceLocator, descriptors: D): KernelResult<TypeRegistry<BuiltInTypeMap & Record<D[number]['typeId'], unknown>>>;
export declare function createBuiltInTypeRegistry(): TypeRegistry<BuiltInTypeMap>;
export declare function canonicalizeTypeValue(registry: RuntimeTypeRegistry, typeId: string, input: unknown, context: Readonly<{
    source: LogicalSourceLocator;
    tokenPath: string;
    themeId?: string;
}>): KernelResult<CanonicalJsonValue>;
export {};
