declare const DIAGNOSTIC_CORE_DEFINITIONS: {
    readonly TK_SOURCE_LOCATOR_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_SCHEMA_VERSION_REQUIRED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_SCHEMA_VERSION_UNSUPPORTED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_SCHEMA_THEME_ID_REQUIRED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_SCHEMA_NAME_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_SCHEMA_JSON_VALUE_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_CONTRACT_VERSION_REQUIRED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_CONTRACT_VERSION_UNSUPPORTED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_RESOLVED_VERSION_UNSUPPORTED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_UNKNOWN: {
        readonly phase: "schema";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_VALUE_INVALID: {
        readonly phase: "schema";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_ID_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_VERSION_MISMATCH: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_SCHEMA_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_DUPLICATE: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_BUILTIN_CONFLICT: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_REGISTRY_NON_DETERMINISTIC: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_TYPE_ALIAS_MISMATCH: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_EXPR_OPERATOR_UNKNOWN: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_EXPR_RESULT_TYPE_MISMATCH: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_EXPR_OPERAND_INVALID: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_EXPR_EVALUATION_INVALID: {
        readonly phase: "resolve";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_EXPR_NON_DETERMINISTIC: {
        readonly phase: "resolve";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_AXIS_DECLARATION_INVALID: {
        readonly phase: "schema";
        readonly location: "axis";
        readonly trace: "forbidden";
    };
    readonly TK_AXIS_DEFAULT_REQUIRED: {
        readonly phase: "schema";
        readonly location: "axis";
        readonly trace: "forbidden";
    };
    readonly TK_AXIS_DEFAULT_INVALID: {
        readonly phase: "schema";
        readonly location: "axis";
        readonly trace: "forbidden";
    };
    readonly TK_AXIS_VALUE_UNSUPPORTED: {
        readonly phase: "transform";
        readonly location: "axis";
        readonly trace: "forbidden";
    };
    readonly TK_TRANSFORM_PATH_UNKNOWN: {
        readonly phase: "transform";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_TRANSFORM_MUTATION_FORBIDDEN: {
        readonly phase: "transform";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_TRANSFORM_TYPE_MISMATCH: {
        readonly phase: "transform";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_TRANSFORM_CONFLICT: {
        readonly phase: "transform";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_DIFF_SOURCE_MISMATCH: {
        readonly phase: "resolve";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_DIFF_AXES_INVALID: {
        readonly phase: "resolve";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
    readonly TK_DIFF_OUTSIDE_CLOSURE: {
        readonly phase: "resolve";
        readonly location: "token";
        readonly trace: "optional";
    };
    readonly TK_REF_TARGET_MISSING: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_REF_LAYER_FORBIDDEN: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_REF_COMPONENT_FORBIDDEN: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_REF_CYCLE: {
        readonly phase: "reference/expression";
        readonly location: "token";
        readonly trace: "required";
    };
    readonly TK_CONTRACT_ENTRY_MISSING: {
        readonly phase: "contract";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_ELEVATION_GROUP_INCOMPLETE: {
        readonly phase: "contract";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_CONTRACT_TYPE_MISMATCH: {
        readonly phase: "contract";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_CONTRACT_LIFECYCLE_INVALID: {
        readonly phase: "contract";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_CONTRACT_REPLACEMENT_INVALID: {
        readonly phase: "contract";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_CONTRACT_BREAKING_CHANGE: {
        readonly phase: "contract";
        readonly location: "token";
        readonly trace: "forbidden";
    };
    readonly TK_RESOURCE_LIMIT_EXCEEDED: {
        readonly phase: "schema";
        readonly location: "theme";
        readonly trace: "forbidden";
    };
};
export type ThemeDiagnosticCode = keyof typeof DIAGNOSTIC_CORE_DEFINITIONS;
export type ThemeDiagnosticPhase = (typeof DIAGNOSTIC_CORE_DEFINITIONS)[ThemeDiagnosticCode]['phase'];
/** Required machine fields are versioned independently from reason/hint text. */
export declare const DIAGNOSTIC_DETAIL_FIELDS: {
    readonly TK_SOURCE_LOCATOR_INVALID: readonly ["entrypoint", "instancePath", "issue", "parameter", "receivedKind"];
    readonly TK_SCHEMA_VERSION_REQUIRED: readonly ["receivedVersion", "supportedVersions"];
    readonly TK_SCHEMA_VERSION_UNSUPPORTED: readonly ["receivedVersion", "supportedVersions"];
    readonly TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED: readonly ["matchedFields", "supportedVersions"];
    readonly TK_SCHEMA_THEME_ID_REQUIRED: readonly ["field", "received", "rule"];
    readonly TK_SCHEMA_NAME_INVALID: readonly ["field", "received", "rule"];
    readonly TK_SCHEMA_JSON_VALUE_INVALID: readonly ["instancePath", "valueKind"];
    readonly TK_CONTRACT_VERSION_REQUIRED: readonly ["receivedVersion", "supportedVersions"];
    readonly TK_CONTRACT_VERSION_UNSUPPORTED: readonly ["receivedVersion", "supportedVersions"];
    readonly TK_RESOLVED_VERSION_UNSUPPORTED: readonly ["receivedVersion", "supportedVersions"];
    readonly TK_TYPE_UNKNOWN: readonly ["receivedTypeId", "registeredTypeIds"];
    readonly TK_TYPE_VALUE_INVALID: readonly ["actualTypeId", "actualValue", "expectedTypeId", "validationRule"];
    readonly TK_TYPE_REGISTRY_ID_INVALID: readonly ["descriptorIndex", "rule", "typeId"];
    readonly TK_TYPE_REGISTRY_VERSION_MISMATCH: readonly ["descriptorIndex", "expectedSchemaVersion", "schemaVersion", "typeId"];
    readonly TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID: readonly ["descriptorIndex", "instancePath", "issue", "receivedKind", "typeId"];
    readonly TK_TYPE_REGISTRY_SCHEMA_INVALID: readonly ["descriptorIndex", "instancePath", "issue", "typeId"];
    readonly TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED: readonly ["descriptorIndex", "issue", "stage", "typeId"];
    readonly TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID: readonly ["descriptorIndex", "failure", "typeId"];
    readonly TK_TYPE_REGISTRY_DUPLICATE: readonly ["duplicateIndex", "firstIndex", "typeId"];
    readonly TK_TYPE_REGISTRY_BUILTIN_CONFLICT: readonly ["builtInTypeId", "descriptorIndex", "typeId"];
    readonly TK_TYPE_REGISTRY_NON_DETERMINISTIC: readonly ["descriptorIndex", "firstHash", "replayHash", "typeId"];
    readonly TK_TYPE_ALIAS_MISMATCH: readonly ["actualTypeId", "actualValue", "expectedTypeId", "from", "projection", "to"];
    readonly TK_EXPR_OPERATOR_UNKNOWN: readonly ["operator", "supportedOperators"];
    readonly TK_EXPR_RESULT_TYPE_MISMATCH: readonly ["declaredResultTypeId", "expectedResultTypeId", "mismatch", "operator", "operatorResultTypeIds"];
    readonly TK_EXPR_OPERAND_INVALID: readonly ["issue", "operator"];
    readonly TK_EXPR_EVALUATION_INVALID: readonly ["issue", "operator"];
    readonly TK_EXPR_NON_DETERMINISTIC: readonly ["firstHash", "operator", "replayHash"];
    readonly TK_AXIS_DECLARATION_INVALID: readonly ["axis", "issue", "platformDomain"];
    readonly TK_AXIS_DEFAULT_REQUIRED: readonly ["axis", "platformDomain", "themeSupportedValues"];
    readonly TK_AXIS_DEFAULT_INVALID: readonly ["axis", "platformDomain", "receivedValue", "themeSupportedValues"];
    readonly TK_AXIS_VALUE_UNSUPPORTED: readonly ["axis", "platformDomain", "receivedValue", "themeSupportedValues"];
    readonly TK_TRANSFORM_PATH_UNKNOWN: readonly ["path"];
    readonly TK_TRANSFORM_MUTATION_FORBIDDEN: readonly ["forbiddenFields", "path"];
    readonly TK_TRANSFORM_TYPE_MISMATCH: readonly ["baseTypeId", "expectTypeId", "issue", "path"];
    readonly TK_TRANSFORM_CONFLICT: readonly ["path", "writers"];
    readonly TK_DIFF_SOURCE_MISMATCH: readonly ["mismatches"];
    readonly TK_DIFF_AXES_INVALID: readonly ["differingAxes", "requiredDifferenceCount"];
    readonly TK_DIFF_OUTSIDE_CLOSURE: readonly ["changedFields", "path"];
    readonly TK_REF_TARGET_MISSING: readonly ["allowedTargets", "from", "to"];
    readonly TK_REF_LAYER_FORBIDDEN: readonly ["allowedTargets", "from", "to"];
    readonly TK_REF_COMPONENT_FORBIDDEN: readonly ["allowedTargets", "from", "to"];
    readonly TK_REF_CYCLE: readonly ["cycle", "edgeCount"];
    readonly TK_CONTRACT_ENTRY_MISSING: readonly ["path"];
    readonly TK_ELEVATION_GROUP_INCOMPLETE: readonly ["facets", "issue", "role"];
    readonly TK_CONTRACT_TYPE_MISMATCH: readonly ["actualTypeId", "expectedTypeId", "path"];
    readonly TK_CONTRACT_LIFECYCLE_INVALID: readonly ["from", "path", "rule", "to"];
    readonly TK_CONTRACT_REPLACEMENT_INVALID: readonly ["path", "reason", "replacement"];
    readonly TK_CONTRACT_BREAKING_CHANGE: readonly ["baselineVersion", "changedFields", "path"];
    readonly TK_RESOURCE_LIMIT_EXCEEDED: readonly ["actual", "limit", "resource", "truncated"];
};
export declare const DIAGNOSTIC_PHASE_SUPPRESSION: {
    readonly schema: readonly [];
    readonly transform: readonly ["schema"];
    readonly 'reference/expression': readonly ["schema", "transform"];
    readonly resolve: readonly ["schema", "transform", "reference/expression"];
    readonly contract: readonly ["schema", "transform", "reference/expression", "resolve"];
};
export interface DiagnosticDetailBranchSchema {
    readonly when?: Readonly<Record<string, string | number | boolean | readonly (string | number)[]>>;
    readonly required: readonly string[];
    readonly optional: readonly string[];
}
export interface DiagnosticDetailSchema {
    readonly fields: Readonly<Record<string, string>>;
    readonly branches: readonly DiagnosticDetailBranchSchema[];
}
export declare const DIAGNOSTIC_DETAIL_SCHEMAS: {
    readonly TK_SOURCE_LOCATOR_INVALID: DiagnosticDetailSchema;
    readonly TK_SCHEMA_VERSION_REQUIRED: DiagnosticDetailSchema;
    readonly TK_SCHEMA_VERSION_UNSUPPORTED: DiagnosticDetailSchema;
    readonly TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED: DiagnosticDetailSchema;
    readonly TK_SCHEMA_THEME_ID_REQUIRED: DiagnosticDetailSchema;
    readonly TK_SCHEMA_NAME_INVALID: DiagnosticDetailSchema;
    readonly TK_SCHEMA_JSON_VALUE_INVALID: DiagnosticDetailSchema;
    readonly TK_CONTRACT_VERSION_REQUIRED: DiagnosticDetailSchema;
    readonly TK_CONTRACT_VERSION_UNSUPPORTED: DiagnosticDetailSchema;
    readonly TK_RESOLVED_VERSION_UNSUPPORTED: DiagnosticDetailSchema;
    readonly TK_TYPE_UNKNOWN: DiagnosticDetailSchema;
    readonly TK_TYPE_VALUE_INVALID: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_ID_INVALID: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_VERSION_MISMATCH: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_SCHEMA_INVALID: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_DUPLICATE: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_BUILTIN_CONFLICT: DiagnosticDetailSchema;
    readonly TK_TYPE_REGISTRY_NON_DETERMINISTIC: DiagnosticDetailSchema;
    readonly TK_TYPE_ALIAS_MISMATCH: DiagnosticDetailSchema;
    readonly TK_EXPR_OPERATOR_UNKNOWN: DiagnosticDetailSchema;
    readonly TK_EXPR_RESULT_TYPE_MISMATCH: DiagnosticDetailSchema;
    readonly TK_EXPR_OPERAND_INVALID: DiagnosticDetailSchema;
    readonly TK_EXPR_EVALUATION_INVALID: DiagnosticDetailSchema;
    readonly TK_EXPR_NON_DETERMINISTIC: DiagnosticDetailSchema;
    readonly TK_AXIS_DECLARATION_INVALID: DiagnosticDetailSchema;
    readonly TK_AXIS_DEFAULT_REQUIRED: DiagnosticDetailSchema;
    readonly TK_AXIS_DEFAULT_INVALID: DiagnosticDetailSchema;
    readonly TK_AXIS_VALUE_UNSUPPORTED: DiagnosticDetailSchema;
    readonly TK_TRANSFORM_PATH_UNKNOWN: DiagnosticDetailSchema;
    readonly TK_TRANSFORM_MUTATION_FORBIDDEN: DiagnosticDetailSchema;
    readonly TK_TRANSFORM_TYPE_MISMATCH: DiagnosticDetailSchema;
    readonly TK_TRANSFORM_CONFLICT: DiagnosticDetailSchema;
    readonly TK_DIFF_SOURCE_MISMATCH: DiagnosticDetailSchema;
    readonly TK_DIFF_AXES_INVALID: DiagnosticDetailSchema;
    readonly TK_DIFF_OUTSIDE_CLOSURE: DiagnosticDetailSchema;
    readonly TK_REF_TARGET_MISSING: DiagnosticDetailSchema;
    readonly TK_REF_LAYER_FORBIDDEN: DiagnosticDetailSchema;
    readonly TK_REF_COMPONENT_FORBIDDEN: DiagnosticDetailSchema;
    readonly TK_REF_CYCLE: DiagnosticDetailSchema;
    readonly TK_CONTRACT_ENTRY_MISSING: DiagnosticDetailSchema;
    readonly TK_ELEVATION_GROUP_INCOMPLETE: DiagnosticDetailSchema;
    readonly TK_CONTRACT_TYPE_MISMATCH: DiagnosticDetailSchema;
    readonly TK_CONTRACT_LIFECYCLE_INVALID: DiagnosticDetailSchema;
    readonly TK_CONTRACT_REPLACEMENT_INVALID: DiagnosticDetailSchema;
    readonly TK_CONTRACT_BREAKING_CHANGE: DiagnosticDetailSchema;
    readonly TK_RESOURCE_LIMIT_EXCEEDED: DiagnosticDetailSchema;
};
type DiagnosticDefinitionMap = {
    readonly [Code in ThemeDiagnosticCode]: (typeof DIAGNOSTIC_CORE_DEFINITIONS)[Code] & Readonly<{
        details: (typeof DIAGNOSTIC_DETAIL_SCHEMAS)[Code];
        suppressedBy: (typeof DIAGNOSTIC_PHASE_SUPPRESSION)[(typeof DIAGNOSTIC_CORE_DEFINITIONS)[Code]['phase']];
        defaultHintKey: `theme-kernel.${Lowercase<Code>}`;
    }>;
};
export declare const DIAGNOSTIC_DEFINITIONS: DiagnosticDefinitionMap;
export declare function diagnosticDetailsMatch(code: ThemeDiagnosticCode, input: unknown): boolean;
export {};
