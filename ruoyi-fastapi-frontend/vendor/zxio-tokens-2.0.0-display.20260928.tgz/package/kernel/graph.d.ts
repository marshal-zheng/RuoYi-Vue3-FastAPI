import { KernelResult } from './diagnostics';
import { EffectiveThemeDefinitions, EffectiveTokenDefinition } from './axes';
import { CanonicalJsonValue, CanonicalTokenPath, ResolutionTraceEntry, ThemeTypeMap } from './model';
import { TypeRegistry } from './token-types';
export interface ResolvedGraphToken extends EffectiveTokenDefinition {
    readonly canonicalValue: CanonicalJsonValue;
    readonly directDependencies: readonly CanonicalTokenPath[];
    readonly trace: readonly ResolutionTraceEntry[];
}
export interface ResolvedGraph {
    readonly tokens: Readonly<Record<CanonicalTokenPath, ResolvedGraphToken>>;
    readonly dependencies: Readonly<Record<CanonicalTokenPath, readonly CanonicalTokenPath[]>>;
}
export declare function resolveEffectiveGraph<M extends ThemeTypeMap>(registry: TypeRegistry<M>, effective: EffectiveThemeDefinitions, themeId: string): KernelResult<ResolvedGraph>;
export declare function resolvedTokenSemanticProjection(token: Record<string, unknown>): CanonicalJsonValue;
export declare function projectionsEqual(left: unknown, right: unknown): boolean;
export declare function projectionHash(input: unknown): string;
