import { BuiltInFieldProjection, BuiltInTypeId, CanonicalJsonValue, OperatorId } from './model';
import { DiagnosticDetailsMap } from './diagnostics';
export interface RuntimeOperatorSignature {
    readonly args: readonly BuiltInTypeId[];
    readonly result: BuiltInTypeId;
}
export declare const OPERATOR_SIGNATURES: Readonly<Record<OperatorId, readonly RuntimeOperatorSignature[]>>;
export declare class OperatorEvaluationError extends Error {
    readonly issue: 'operand-order' | 'operand-range' | 'color-space-mismatch' | 'non-finite-result' | 'canonical-result-invalid';
    readonly details: DiagnosticDetailsMap['TK_EXPR_EVALUATION_INVALID'];
    constructor(issue: OperatorEvaluationError['issue'], details: DiagnosticDetailsMap['TK_EXPR_EVALUATION_INVALID']);
}
export declare function evaluateOperator(operator: OperatorId, args: readonly CanonicalJsonValue[]): Readonly<{
    typeId: BuiltInTypeId;
    value: CanonicalJsonValue;
    hash: string;
}>;
export interface ProjectionDescriptor {
    readonly targetType: BuiltInTypeId;
    readonly resultTypes: readonly BuiltInTypeId[];
}
export declare const FIELD_PROJECTIONS: Readonly<Record<BuiltInFieldProjection, ProjectionDescriptor>>;
export declare function projectField(field: BuiltInFieldProjection, value: CanonicalJsonValue): CanonicalJsonValue;
