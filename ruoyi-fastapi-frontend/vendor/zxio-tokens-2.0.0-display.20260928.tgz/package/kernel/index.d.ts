import { KernelResult } from './diagnostics';
import { AuthorLogicalSourceLocator, BuiltInTypeMap, DeepReadonly, ExtensionTypeDescriptor, KernelTypeMap, ResolveThemeInput, ResolvedThemeDiff, ThemeContractAuthorInput, ThemeKernelOptions, ThemeSourceAuthorInput, ThemeTypeMap, TokenTypeId, ValidatedResolvedThemeV1, ValidatedThemePublicContractV4, ValidatedThemeSourceV4 } from './model';
export { themeSeedGroups, validateThemeSeedsV1 } from './seed-validation';
export type * from './model';
export { THEME_DERIVATION_VERSION, THEME_SURFACE_FACETS, THEME_SURFACE_ROLES, deriveThemeSourceV4, } from './derivation';
export type { ThemeDerivationMeta, ThemeDerivationRefine, ThemeSeedRgb, ThemeSeedsV1, ThemeSurfaceDepthStyle, ThemeSurfaceFacet, ThemeSurfaceRole, ThemeTintBase, } from './derivation';
export type { DiagnosticDetails, DiagnosticFor, DiagnosticLocation, DiagnosticTraceEntry, KernelResult, ThemeDiagnostic, } from './diagnostics';
export type { ThemeDiagnosticCode, ThemeDiagnosticPhase, } from './diagnostic-registry';
export interface ValidateThemeSourceInput {
    readonly source: unknown;
    readonly sourceLocation: AuthorLogicalSourceLocator;
}
export interface ValidateThemeContractInput {
    readonly contract: unknown;
    readonly contractLocation: AuthorLogicalSourceLocator;
}
export interface ThemeKernel<M extends ThemeTypeMap> {
    readonly registeredTypeIds: readonly TokenTypeId<M>[];
    readonly typeRegistryContentHash: `sha256:${string}`;
    validateTokenLiteral<K extends TokenTypeId<M>>(input: {
        readonly typeId: K;
        readonly value: unknown;
        readonly source: AuthorLogicalSourceLocator;
    }): KernelResult<{
        readonly typeId: K;
        readonly value: DeepReadonly<M[K]>;
    }>;
    defineTheme<const T extends ThemeSourceAuthorInput<M>>(source: AuthorLogicalSourceLocator, input: T): KernelResult<ValidatedThemeSourceV4<M>>;
    defineThemeContract<const T extends ThemeContractAuthorInput<M>>(source: AuthorLogicalSourceLocator, input: T): KernelResult<ValidatedThemePublicContractV4<M>>;
    validateThemeSource(input: ValidateThemeSourceInput): KernelResult<ValidatedThemeSourceV4<M>>;
    validateThemeContract(input: ValidateThemeContractInput): KernelResult<ValidatedThemePublicContractV4<M>>;
    resolveTheme(input: ResolveThemeInput<M>): KernelResult<ValidatedResolvedThemeV1<M>>;
    resolveThemeDiff(from: ValidatedResolvedThemeV1<M>, fromLocation: AuthorLogicalSourceLocator, to: ValidatedResolvedThemeV1<M>, toLocation: AuthorLogicalSourceLocator): KernelResult<DeepReadonly<ResolvedThemeDiff>>;
    validateResolvedTheme(input: unknown, inputLocation: AuthorLogicalSourceLocator): KernelResult<ValidatedResolvedThemeV1<M>>;
    serializeResolvedTheme(input: unknown, inputLocation: AuthorLogicalSourceLocator): KernelResult<Uint8Array>;
    computeResolvedThemeHash(input: unknown, inputLocation: AuthorLogicalSourceLocator): KernelResult<`sha256:${string}`>;
}
export declare const themeKernel: ThemeKernel<BuiltInTypeMap>;
export declare const canonicalThemeContractV4: ValidatedThemePublicContractV4<BuiltInTypeMap>;
export declare function defineThemeV4<const T extends ThemeSourceAuthorInput<BuiltInTypeMap>>(source: AuthorLogicalSourceLocator, input: T): KernelResult<ValidatedThemeSourceV4<BuiltInTypeMap>>;
export declare function defineThemeContractV4<const T extends ThemeContractAuthorInput<BuiltInTypeMap>>(source: AuthorLogicalSourceLocator, input: T): KernelResult<ValidatedThemePublicContractV4<BuiltInTypeMap>>;
export declare function validateThemeSource(input: ValidateThemeSourceInput): KernelResult<ValidatedThemeSourceV4<BuiltInTypeMap>>;
export declare function validateThemeContract(input: ValidateThemeContractInput): KernelResult<ValidatedThemePublicContractV4<BuiltInTypeMap>>;
export declare function resolveTheme(input: ResolveThemeInput<BuiltInTypeMap>): KernelResult<ValidatedResolvedThemeV1<BuiltInTypeMap>>;
export declare function resolveThemeDiff(from: ValidatedResolvedThemeV1<BuiltInTypeMap>, fromLocation: AuthorLogicalSourceLocator, to: ValidatedResolvedThemeV1<BuiltInTypeMap>, toLocation: AuthorLogicalSourceLocator): KernelResult<DeepReadonly<ResolvedThemeDiff>>;
export declare function validateResolvedTheme(input: unknown, inputLocation: AuthorLogicalSourceLocator): KernelResult<ValidatedResolvedThemeV1<BuiltInTypeMap>>;
export declare function serializeResolvedTheme(input: unknown, inputLocation: AuthorLogicalSourceLocator): KernelResult<Uint8Array>;
export declare function computeResolvedThemeHash(input: unknown, inputLocation: AuthorLogicalSourceLocator): KernelResult<`sha256:${string}`>;
export declare function createThemeKernel(): ThemeKernel<BuiltInTypeMap>;
export declare function createThemeKernel<const D extends readonly ExtensionTypeDescriptor[]>(source: AuthorLogicalSourceLocator, options: ThemeKernelOptions<D>): KernelResult<ThemeKernel<KernelTypeMap<D>>>;
/** Canonicalize one literal without manufacturing a complete theme source. */
export declare const validateTokenLiteral: ThemeKernel<BuiltInTypeMap>['validateTokenLiteral'];
