import { f as canonicalizeBuiltIn, s as snapshotCanonicalJson, a as computeCanonicalHash, A as AXIS_ORDER$1, g as AXIS_DOMAINS, h as createDiagnostic, i as axisLocation, j as failure, p as parseCanonicalTokenPath, t as tokenLocation, k as canonicalizeTypeValue, l as compareAscii, o as ok, m as toCanonicalTokenPath, b as canonicalJsonStringify, n as themeLocation, q as parseLogicalSourceLocator, r as canonicalJsonBytes, u as applyPublicContract, w as isValidPublicAdmissionRationale, x as isStrictSemVer, y as isValidPublicMigration, T as THEME_SURFACE_ROLES, z as THEME_SURFACE_FACETS, c as createBuiltInTypeRegistry, C as createDefaultCanonicalContract, e as validateThemeContractObject, D as validateThemeSourceObject, E as defineThemeContractObject, F as defineThemeObject, v as validateTokenLiteralWithRegistry, G as createTypeRegistry } from "../_chunks/public-contract-UdLYIjLH.mjs";
function materialContractEntry(typeId, description, consumerUseCase) {
  return {
    typeId,
    lifecycle: "experimental",
    introducedIn: "4.3.0",
    description,
    owner: "design-system",
    rationale: {
      kind: "cross-component",
      consumerUseCase,
      evidence: [
        "packages/theme-chalk/src/structural.css",
        "packages/theme-compiler/src/adapters/tailwind/mapping.ts"
      ]
    }
  };
}
const elevationContractEntries = Object.fromEntries(
  [
    ["flat", "Page-level surfaces and explicit zero-elevation containers."],
    ["raised", "Cards and timeline markers at resting elevation."],
    ["overlay", "Tooltips, popovers, menus, and floating selectors."],
    ["blocking", "Dialogs, drawers, and blocking floating panels."]
  ].flatMap(
    ([role, consumers]) => [
      ["shadow", "shadow", "depth shadow"],
      ["surface", "color", "surface color"],
      ["border", "color", "hairline border color"]
    ].map(([facet, typeId, label]) => [
      `semantic.elevation.${role}.${facet}`,
      materialContractEntry(
        typeId,
        `${role[0].toUpperCase()}${role.slice(1)} elevation ${label}.`,
        `${consumers} The ${facet} facet is shared by at least two component surfaces. All three facets are consumed together for depth consistency.`
      )
    ])
  )
);
const roleContractEntries = Object.fromEntries(
  [
    [
      "semantic.fill.subtle",
      "color",
      "Quiet resting fill for headers and list group surfaces."
    ],
    [
      "semantic.fill.accent-hover",
      "color",
      "Accent hover fill for controls and drag targets."
    ],
    [
      "semantic.fill.selected",
      "color",
      "Selected-row and current-item fill."
    ],
    [
      "semantic.fill.selected-hover",
      "color",
      "Hover fill for already selected items."
    ],
    [
      "semantic.fill.accent-active",
      "color",
      "Pressed accent fill for interactive controls."
    ],
    [
      "semantic.fill.status-subtle",
      "color",
      "Quiet status fill for notices and state chips."
    ],
    [
      "semantic.fill.scrollbar-thumb",
      "color",
      "Resting scrollbar thumb fill."
    ],
    [
      "semantic.fill.scrollbar-thumb-hover",
      "color",
      "Hovered scrollbar thumb fill."
    ],
    ["semantic.fill.scrollbar-track", "color", "Scrollbar track fill."],
    [
      "semantic.fill.current-tint",
      "number",
      "Current-color fill mixing percentage."
    ],
    [
      "semantic.border.default",
      "color",
      "Default edge color for floating surfaces."
    ],
    [
      "semantic.border.control",
      "color",
      "Readable resting edge for compact checkable controls."
    ],
    [
      "semantic.border.current-tint",
      "number",
      "Current-color border mixing percentage."
    ],
    ["semantic.stroke.subtle", "border", "Complete quiet container stroke."],
    [
      "semantic.stroke.default",
      "border",
      "Complete floating-surface stroke."
    ],
    [
      "semantic.stroke.strong",
      "border",
      "Complete interactive-control stroke."
    ],
    ["semantic.stroke.focus", "border", "Standard keyboard focus outline."],
    [
      "semantic.stroke.focus-inline",
      "border",
      "Compact inline keyboard focus outline."
    ],
    [
      "semantic.status.danger-on-surface",
      "color",
      "Readable danger color on neutral surfaces."
    ],
    [
      "semantic.status.warning-on-surface",
      "color",
      "Readable warning color on neutral surfaces."
    ],
    [
      "semantic.status.info-on-surface",
      "color",
      "Readable information color on neutral surfaces."
    ]
  ].map(([path, typeId, description]) => [
    path,
    materialContractEntry(
      typeId,
      description,
      "Editors, lists, dialogs, and floating panels share this purpose-specific role; at least two component families consume it."
    )
  ])
);
const actionTextContractEntries = Object.fromEntries(
  [
    "accent",
    "status.success",
    "status.warning",
    "status.danger",
    "status.info"
  ].flatMap(
    (role) => ["on-surface", "on-fill", "on-fill-hover", "on-fill-active"].filter(
      (facet) => facet !== "on-surface" || role === "accent" || role === "status.success"
    ).map((facet) => [
      `semantic.${role}${role === "accent" ? "." : "-"}${facet}`,
      {
        ...materialContractEntry(
          "color",
          `${role} foreground for ${facet === "on-surface" ? "neutral surfaces" : facet.replace("on-", "")}.`,
          "Action links, buttons, and checkable controls share a readable foreground independently of their brand and status fills."
        ),
        introducedIn: "4.4.0"
      }
    ])
  )
);
const materialRoleContractEntries = Object.fromEntries(
  [
    ["semantic.material.tonal-tint", "color", "Optional tonal surface tint."],
    [
      "semantic.material.tonal-gradient",
      "gradient",
      "Optional tonal surface gradient."
    ],
    [
      "semantic.material.brand-shadow.raised",
      "shadow",
      "Brand-surface shadow at raised elevation."
    ],
    [
      "semantic.material.brand-shadow.overlay",
      "shadow",
      "Brand-surface shadow at overlay elevation."
    ],
    [
      "semantic.material.brand-shadow.blocking",
      "shadow",
      "Brand-surface shadow at blocking elevation."
    ],
    [
      "semantic.material.inner-glow",
      "shadow",
      "Optional inset glow for material surfaces."
    ],
    [
      "semantic.material.inner-stroke",
      "shadow",
      "Neutral inset stroke replacement."
    ],
    [
      "semantic.material.inner-stroke-accent",
      "shadow",
      "Accent inset stroke for selected states."
    ],
    [
      "semantic.material.inner-stroke-danger",
      "shadow",
      "Danger inset stroke for destructive states."
    ],
    [
      "semantic.material.focus-ring",
      "shadow",
      "Accessible focus ring shadow."
    ],
    [
      "semantic.material.cutout-ring",
      "shadow",
      "Surface-colored cutout ring."
    ],
    [
      "semantic.material.focus-ring-transition",
      "transition",
      "Motion-aware focus-ring transition."
    ]
  ].map(([path, typeId, description]) => [
    path,
    materialContractEntry(
      typeId,
      description,
      "Panels, cards, inputs, and selected states share this material primitive under the governed elevation binding inventory."
    )
  ])
);
function surfaceContractEntry(typeId, description, consumerUseCase) {
  return {
    typeId,
    lifecycle: "experimental",
    introducedIn: "4.4.0",
    description,
    owner: "design-system",
    rationale: {
      kind: "cross-component",
      consumerUseCase,
      evidence: [
        "packages/theme-chalk/src/structural.css",
        "docs/.vitepress/vitepress/styles/css-vars.scss"
      ]
    }
  };
}
const surfaceRoleConsumers = [
  ["canvas", "Application canvas behind every other surface."],
  ["panel", "Sidebars, navigation rails, and grouped list backgrounds."],
  ["card", "Resting content cards and content wrappers."],
  ["field", "Inputs, editors, and other text-entry surfaces."],
  ["header", "Sticky headers, toolbars, and table heads."],
  ["overlay", "Tooltips, popovers, menus, and floating selectors."],
  ["blocking", "Dialogs, drawers, and blocking floating panels."],
  ["selected", "Selected rows, active tabs, and chosen options."],
  ["brand", "Brand-filled heroes, primary calls to action, and accent chips."]
];
const surfaceFacetContracts = [
  ["fill", "color", "background fill"],
  ["edge", "border", "one-pixel edge stroke"],
  ["depth", "shadow", "outer depth shadow"],
  ["inner", "shadow", "inset material (glow or stroke)"],
  ["highlight", "gradient", "top sheen gradient"],
  ["on-text", "color", "primary text color"],
  ["on-text-secondary", "color", "secondary text color"]
];
const surfaceRoleContractEntries = Object.fromEntries(
  surfaceRoleConsumers.flatMap(
    ([role, consumers]) => surfaceFacetContracts.map(([facet, typeId, label]) => [
      `semantic.surface.${role}.${facet}`,
      surfaceContractEntry(
        typeId,
        `${role[0].toUpperCase()}${role.slice(1)} surface ${label}.`,
        `${consumers} The ${facet} facet is consumed together with the other six facets of the same role by every data-zx-surface consumer.`
      )
    ])
  )
);
const canonicalThemeContractV4Input = {
  contractVersion: "4.0.0",
  entries: {
    "semantic.surface.page": {
      typeId: "color",
      lifecycle: "stable",
      description: "Page-level background surface shared across applications.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Application shells and content pages share one page surface role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.surface.elevated": {
      typeId: "color",
      lifecycle: "stable",
      description: "Elevated container surface shared by cards and overlays.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Cards, popups, and panels share an elevation surface role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.text.primary": {
      typeId: "color",
      lifecycle: "stable",
      description: "Primary foreground text color.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "All readable components require a common primary text role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.text.secondary": {
      typeId: "color",
      lifecycle: "stable",
      description: "Secondary foreground text color.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Supporting labels and metadata share a secondary text role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.action.focus-ring": {
      typeId: "color",
      lifecycle: "stable",
      description: "Accessible focus indicator color for interactive controls.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Keyboard-focus affordances require one accessible role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.spacing.control-y": {
      typeId: "dimension",
      lifecycle: "stable",
      description: "Vertical control padding derived from the selected density.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Inputs and buttons align to the same density rhythm.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.radius.control": {
      typeId: "dimension",
      lifecycle: "stable",
      description: "Shared control corner radius.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Controls share one composable radius role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.motion.duration": {
      typeId: "duration",
      lifecycle: "stable",
      description: "Default interaction motion duration.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Interactive components share a motion timing role.",
        evidence: ["packages/theme-default/src/theme.ts"]
      }
    },
    "semantic.border.subtle": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Low-emphasis border and divider color for quiet edges.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Editor containers, toolbars, tables, and popup surfaces need a quiet edge role instead of reusing secondary text color as borders.",
        evidence: [
          "packages/text-editor/style/_editor.scss",
          "packages/text-editor/style/_toolbar.scss",
          "packages/text-editor/style/extensions/_table.scss"
        ]
      }
    },
    "semantic.border.strong": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Emphasized border and divider color for prominent edges.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Horizontal rules and emphasized separators need a stronger edge role than subtle borders without borrowing text colors.",
        evidence: [
          "packages/text-editor/style/_editor.scss",
          "packages/text-editor/style/_toolbar.scss"
        ]
      }
    },
    "semantic.fill.hover": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Translucent hover fill for interactive rows and controls.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Menu items, toolbar buttons, and list rows need a hover fill that works on any surface instead of reusing the page background.",
        evidence: [
          "packages/text-editor/style/_toolbar.scss",
          "packages/text-editor/style/_menu.scss",
          "packages/text-editor/style/extensions/_drag-handle.scss"
        ]
      }
    },
    "semantic.fill.active": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Translucent pressed/selected fill for interactive elements.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Active toolbar toggles, selected rows, and inline code chips need a fill one step stronger than hover.",
        evidence: [
          "packages/text-editor/style/_toolbar.scss",
          "packages/text-editor/style/_editor.scss"
        ]
      }
    },
    "semantic.accent.base": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Full-strength brand fill and active indicator color; use accent.on-surface for readable text.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Brand fills, carets, and active-state indicators need an opaque accent role; action labels use the separate readable foreground roles.",
        evidence: [
          "packages/text-editor/style/_editor.scss",
          "packages/text-editor/style/_popup.scss"
        ]
      }
    },
    "semantic.accent.subtle": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Low-emphasis accent wash for selected items and highlights.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Selected menu entries, selected table cells, and keyboard-highlighted suggestions share an accent-tinted background role.",
        evidence: [
          "packages/text-editor/style/extensions/_suggestion.scss",
          "packages/text-editor/style/extensions/_table.scss"
        ]
      }
    },
    "semantic.status.danger": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Destructive action and error status color.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Delete menu entries and inline validation errors need a status role instead of rendering in primary text color.",
        evidence: [
          "packages/text-editor/style/_popup.scss",
          "packages/text-editor/style/extensions/_table.scss"
        ]
      }
    },
    "semantic.radius.surface": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.1.0",
      description: "Corner radius for floating surfaces and cards.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Popovers, menus, and cards need a larger radius step than inline controls to read as elevated surfaces.",
        evidence: [
          "packages/text-editor/style/_menu.scss",
          "packages/text-editor/style/_popup.scss"
        ]
      }
    },
    "semantic.status.success": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Positive confirmation status color.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Structural styles and Element Plus components share one positive confirmation status role instead of hard-coding library defaults.",
        evidence: [
          "packages/theme-chalk/src/structural.css",
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Cautionary status color.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Structural styles and Element Plus components share one cautionary status role instead of hard-coding library defaults.",
        evidence: [
          "packages/theme-chalk/src/structural.css",
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Neutral informational status color.",
      owner: "design-system",
      rationale: {
        kind: "cross-component",
        consumerUseCase: "Structural styles and Element Plus components share one neutral informational status role instead of hard-coding library defaults.",
        evidence: [
          "packages/theme-chalk/src/structural.css",
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.accent.tint-3": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Brand accent tint step (tint-3) for hover emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives hover emphasis from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.accent.tint-5": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Brand accent tint step (tint-5) for muted emphasis and disabled strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.accent.tint-7": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Brand accent tint step (tint-7) for quiet strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives quiet strokes from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.accent.tint-8": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Brand accent tint step (tint-8) for tinted borders and quiet chips.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives tinted borders and quiet chips from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.accent.tint-9": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Brand accent tint step (tint-9) for wash backgrounds.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives wash backgrounds from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.accent.shade-2": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Brand accent shade step (shade-2) for pressed/active emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives pressed/active emphasis from the brand accent color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.success-tint-3": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Success status tint step (tint-3) for hover emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives hover emphasis from the success status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.success-tint-5": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Success status tint step (tint-5) for muted emphasis and disabled strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the success status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.success-tint-7": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Success status tint step (tint-7) for quiet strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives quiet strokes from the success status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.success-tint-8": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Success status tint step (tint-8) for tinted borders and quiet chips.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives tinted borders and quiet chips from the success status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.success-tint-9": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Success status tint step (tint-9) for wash backgrounds.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives wash backgrounds from the success status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.success-shade-2": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Success status shade step (shade-2) for pressed/active emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives pressed/active emphasis from the success status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning-tint-3": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Warning status tint step (tint-3) for hover emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives hover emphasis from the warning status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning-tint-5": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Warning status tint step (tint-5) for muted emphasis and disabled strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the warning status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning-tint-7": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Warning status tint step (tint-7) for quiet strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives quiet strokes from the warning status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning-tint-8": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Warning status tint step (tint-8) for tinted borders and quiet chips.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives tinted borders and quiet chips from the warning status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning-tint-9": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Warning status tint step (tint-9) for wash backgrounds.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives wash backgrounds from the warning status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.warning-shade-2": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Warning status shade step (shade-2) for pressed/active emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives pressed/active emphasis from the warning status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info-tint-3": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Info status tint step (tint-3) for hover emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives hover emphasis from the info status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info-tint-5": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Info status tint step (tint-5) for muted emphasis and disabled strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the info status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info-tint-7": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Info status tint step (tint-7) for quiet strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives quiet strokes from the info status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info-tint-8": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Info status tint step (tint-8) for tinted borders and quiet chips.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives tinted borders and quiet chips from the info status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info-tint-9": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Info status tint step (tint-9) for wash backgrounds.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives wash backgrounds from the info status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.info-shade-2": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Info status shade step (shade-2) for pressed/active emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives pressed/active emphasis from the info status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.danger-tint-3": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Danger status tint step (tint-3) for hover emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives hover emphasis from the danger status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.danger-tint-5": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Danger status tint step (tint-5) for muted emphasis and disabled strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives muted emphasis and disabled strokes from the danger status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.danger-tint-7": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Danger status tint step (tint-7) for quiet strokes.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives quiet strokes from the danger status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.danger-tint-8": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Danger status tint step (tint-8) for tinted borders and quiet chips.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives tinted borders and quiet chips from the danger status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.danger-tint-9": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Danger status tint step (tint-9) for wash backgrounds.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives wash backgrounds from the danger status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.status.danger-shade-2": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Danger status shade step (shade-2) for pressed/active emphasis.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus derives pressed/active emphasis from the danger status color; without a themed ramp those states keep default-palette values after a reskin.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.surface.body": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Component body surface for dialogs, cards, tables, and menus.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus component bodies read one base background variable; without this role they stay light in dark variants.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.text.disabled": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Disabled text and icon color.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Disabled labels need one themed role; Element Plus reads a dedicated disabled text variable that otherwise keeps default values.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.overlay.modal": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Modal backdrop scrim at full strength.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Overlay scrims and loading masks must flip with the theme mode; Element Plus reads dedicated overlay/mask variables.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.overlay.mask": {
      typeId: "color",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Loading mask surface tint.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Overlay scrims and loading masks must flip with the theme mode; Element Plus reads dedicated overlay/mask variables.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.motion.duration-fast": {
      typeId: "duration",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Fast interaction motion duration for borders, color, and fades.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Element Plus fast transitions read a dedicated duration variable that must follow the motion axis with the base duration.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.family": {
      typeId: "font-family",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Base interface font stack.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.size-extra-small": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Extra-small font size step.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.size-small": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Small font size step.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.size-base": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Base font size step.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.size-medium": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Medium font size step.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.size-large": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Large font size step.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.size-extra-large": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Extra-large font size step.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.weight-primary": {
      typeId: "font-weight",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Primary emphasis font weight.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    "semantic.typography.line-height-base": {
      typeId: "dimension",
      lifecycle: "experimental",
      introducedIn: "4.2.0",
      description: "Base line height for controls and labels.",
      owner: "design-system",
      rationale: {
        kind: "external-api",
        consumerUseCase: "Brand reskins change typography; Element Plus reads dedicated font variables that must follow the theme instead of library defaults.",
        evidence: [
          "packages/theme-compiler/src/adapters/element-plus/mapping.ts"
        ]
      }
    },
    ...elevationContractEntries,
    ...roleContractEntries,
    ...actionTextContractEntries,
    ...materialRoleContractEntries,
    ...surfaceRoleContractEntries
  }
};
const OPERATOR_SIGNATURES = Object.freeze({
  "number.add@1": [{ args: ["number", "number"], result: "number" }],
  "number.multiply@1": [{ args: ["number", "number"], result: "number" }],
  "number.clamp@1": [
    { args: ["number", "number", "number"], result: "number" }
  ],
  "dimension.add@1": [
    { args: ["dimension", "dimension"], result: "dimension" }
  ],
  "dimension.subtract@1": [
    { args: ["dimension", "dimension"], result: "dimension" }
  ],
  "dimension.multiply@1": [
    { args: ["dimension", "number"], result: "dimension" }
  ],
  "color.mix@1": [{ args: ["color", "color", "number"], result: "color" }],
  "color.alpha@1": [{ args: ["color", "number"], result: "color" }],
  "color.contrast-text@1": [{ args: ["color"], result: "color" }],
  "shadow.stack@1": [{ args: ["shadow", "shadow"], result: "shadow" }],
  "border.compose@1": [
    { args: ["dimension", "string", "color"], result: "border" }
  ],
  "typography.compose@1": [
    {
      args: ["font-family", "dimension", "font-weight", "number", "dimension"],
      result: "typography"
    },
    {
      args: [
        "font-family",
        "dimension",
        "font-weight",
        "dimension",
        "dimension"
      ],
      result: "typography"
    }
  ]
});
class OperatorEvaluationError extends Error {
  constructor(issue, details) {
    super(issue);
    this.name = "OperatorEvaluationError";
    this.issue = issue;
    this.details = details;
  }
}
function finiteResult(operator, value, resultTypeId, resultInstancePath, causalOperands) {
  if (!Number.isFinite(value)) {
    throw new OperatorEvaluationError("non-finite-result", {
      issue: "non-finite-result",
      operator,
      resultTypeId,
      resultInstancePath,
      numberKind: value === Number.POSITIVE_INFINITY ? "positive-infinity" : "negative-infinity",
      causalOperands: causalOperands.map((actualValue, operandIndex) => ({
        operandIndex,
        actualValue
      }))
    });
  }
  return Object.is(value, -0) ? 0 : value;
}
function dimensionAdd(operator, left, right) {
  const op = operator === "dimension.add@1" ? "add" : "subtract";
  if (left.kind === "value" && right.kind === "value" && left.unit === right.unit) {
    const raw = op === "add" ? left.value + right.value : left.value - right.value;
    return {
      kind: "value",
      value: finiteResult(operator, raw, "dimension", "$.value", [
        left,
        right
      ]),
      unit: left.unit
    };
  }
  return { kind: "calc", op, args: [left, right] };
}
function dimensionMultiply(dimension, multiplier) {
  if (dimension.kind === "value") {
    return {
      kind: "value",
      value: finiteResult(
        "dimension.multiply@1",
        dimension.value * multiplier,
        "dimension",
        "$.value",
        [dimension, multiplier]
      ),
      unit: dimension.unit
    };
  }
  return { kind: "calc", op: "multiply", args: [dimension, multiplier] };
}
function interpolateHue(left, right, weight) {
  const normalizedLeft = (left % 360 + 360) % 360;
  const normalizedRight = (right % 360 + 360) % 360;
  let delta = (normalizedRight - normalizedLeft + 540) % 360 - 180;
  if (delta === -180) delta = 180;
  return ((normalizedLeft + delta * weight) % 360 + 360) % 360;
}
function mixColor(left, right, weight) {
  if (left.colorSpace !== right.colorSpace) {
    throw new OperatorEvaluationError("color-space-mismatch", {
      issue: "color-space-mismatch",
      operator: "color.mix@1",
      leftOperandIndex: 0,
      rightOperandIndex: 1,
      leftColorSpace: left.colorSpace,
      rightColorSpace: right.colorSpace
    });
  }
  if (weight < 0 || weight > 1) {
    throw new OperatorEvaluationError("operand-range", {
      issue: "operand-range",
      operator: "color.mix@1",
      operandIndex: 2,
      operandRole: "rightWeight",
      receivedValue: weight,
      inclusiveMinimum: 0,
      inclusiveMaximum: 1
    });
  }
  const components = left.components.map((component, index) => {
    if (left.colorSpace === "oklch" && index === 2) {
      return interpolateHue(component, right.components[index], weight);
    }
    return finiteResult(
      "color.mix@1",
      component * (1 - weight) + right.components[index] * weight,
      "color",
      `$.components[${index}]`,
      [component, right.components[index], weight]
    );
  });
  return {
    colorSpace: left.colorSpace,
    components,
    alpha: finiteResult(
      "color.mix@1",
      left.alpha * (1 - weight) + right.alpha * weight,
      "color",
      "$.alpha",
      [left.alpha, right.alpha, weight]
    )
  };
}
function replaceAlpha(color2, alpha) {
  if (alpha < 0 || alpha > 1) {
    throw new OperatorEvaluationError("operand-range", {
      issue: "operand-range",
      operator: "color.alpha@1",
      operandIndex: 1,
      operandRole: "alpha",
      receivedValue: alpha,
      inclusiveMinimum: 0,
      inclusiveMaximum: 1
    });
  }
  return {
    ...color2,
    components: [...color2.components],
    alpha
  };
}
function evaluateOperator(operator, args) {
  let value;
  let resultType;
  switch (operator) {
    case "number.add@1":
      resultType = "number";
      value = finiteResult(
        operator,
        args[0] + args[1],
        resultType,
        "$",
        args
      );
      break;
    case "number.multiply@1":
      resultType = "number";
      value = finiteResult(
        operator,
        args[0] * args[1],
        resultType,
        "$",
        args
      );
      break;
    case "number.clamp@1": {
      resultType = "number";
      const [candidate, minimum, maximum] = args;
      if (minimum > maximum) {
        throw new OperatorEvaluationError("operand-order", {
          issue: "operand-order",
          operator,
          constraint: "min-lte-max",
          minOperandIndex: 1,
          maxOperandIndex: 2,
          minValue: minimum,
          maxValue: maximum
        });
      }
      value = Math.min(Math.max(candidate, minimum), maximum);
      break;
    }
    case "dimension.add@1":
    case "dimension.subtract@1":
      resultType = "dimension";
      value = dimensionAdd(
        operator,
        args[0],
        args[1]
      );
      break;
    case "dimension.multiply@1":
      resultType = "dimension";
      value = dimensionMultiply(
        args[0],
        args[1]
      );
      break;
    case "color.mix@1":
      resultType = "color";
      value = mixColor(
        args[0],
        args[1],
        args[2]
      );
      break;
    case "color.alpha@1":
      resultType = "color";
      value = replaceAlpha(
        args[0],
        args[1]
      );
      break;
    case "color.contrast-text@1": {
      const background = args[0];
      if (background.colorSpace !== "srgb" || background.alpha !== 1) {
        throw new OperatorEvaluationError("canonical-result-invalid", {
          issue: "canonical-result-invalid",
          operator,
          resultTypeId: "color",
          resultInstancePath: "$",
          validationRule: "contrast-text-requires-opaque-srgb-background",
          receivedValue: args[0],
          causalOperands: [{ operandIndex: 0, actualValue: args[0] }]
        });
      }
      const linear = background.components.map(
        (channel2) => channel2 <= 0.04045 ? channel2 / 12.92 : ((channel2 + 0.055) / 1.055) ** 2.4
      );
      const luminance = linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
      const channel = 1.05 / (luminance + 0.05) >= (luminance + 0.05) / 0.05 ? 1 : 0;
      resultType = "color";
      value = {
        colorSpace: "srgb",
        components: [channel, channel, channel],
        alpha: 1
      };
      break;
    }
    case "shadow.stack@1":
      resultType = "shadow";
      value = [
        ...args[0],
        ...args[1]
      ];
      break;
    case "border.compose@1":
      resultType = "border";
      value = {
        width: args[0],
        style: args[1],
        color: args[2]
      };
      break;
    case "typography.compose@1":
      resultType = "typography";
      value = {
        fontFamily: args[0],
        fontSize: args[1],
        fontWeight: args[2],
        lineHeight: args[3],
        letterSpacing: args[4]
      };
      break;
    default:
      throw new Error(`Unknown operator: ${String(operator)}`);
  }
  const canonical = canonicalizeBuiltIn(resultType, value);
  if (!canonical.ok) {
    throw new OperatorEvaluationError("canonical-result-invalid", {
      issue: "canonical-result-invalid",
      operator,
      resultTypeId: resultType,
      resultInstancePath: canonical.instancePath,
      validationRule: canonical.rule,
      receivedValue: snapshotCanonicalJson(value),
      causalOperands: args.map((actualValue, operandIndex) => ({
        operandIndex,
        actualValue
      }))
    });
  }
  const owned = snapshotCanonicalJson(canonical.value);
  return {
    typeId: resultType,
    value: owned,
    hash: computeCanonicalHash(owned)
  };
}
const FIELD_PROJECTIONS = Object.freeze({
  "color.alpha": { targetType: "color", resultTypes: ["number"] },
  "color.components.0": { targetType: "color", resultTypes: ["number"] },
  "color.components.1": { targetType: "color", resultTypes: ["number"] },
  "color.components.2": { targetType: "color", resultTypes: ["number"] },
  "border.width": { targetType: "border", resultTypes: ["dimension"] },
  "border.style": { targetType: "border", resultTypes: ["string"] },
  "border.color": { targetType: "border", resultTypes: ["color"] },
  "typography.fontFamily": {
    targetType: "typography",
    resultTypes: ["font-family"]
  },
  "typography.fontSize": {
    targetType: "typography",
    resultTypes: ["dimension"]
  },
  "typography.fontWeight": {
    targetType: "typography",
    resultTypes: ["font-weight"]
  },
  "typography.lineHeight": {
    targetType: "typography",
    resultTypes: ["number", "dimension"]
  },
  "typography.letterSpacing": {
    targetType: "typography",
    resultTypes: ["dimension"]
  }
});
function projectField(field, value) {
  switch (field) {
    case "color.alpha":
      return value.alpha;
    case "color.components.0":
      return value.components[0];
    case "color.components.1":
      return value.components[1];
    case "color.components.2":
      return value.components[2];
    case "border.width":
      return value.width;
    case "border.style":
      return value.style;
    case "border.color":
      return value.color;
    case "typography.fontFamily":
      return value.fontFamily;
    case "typography.fontSize":
      return value.fontSize;
    case "typography.fontWeight":
      return value.fontWeight;
    case "typography.lineHeight":
      return value.lineHeight;
    case "typography.letterSpacing":
      return value.letterSpacing;
  }
}
const FORBIDDEN_TRANSFORM_FIELDS = [
  "component",
  "delete",
  "lifecycle",
  "public",
  "type",
  "visibility"
];
function isRecord$3(input) {
  return Boolean(input) && typeof input === "object" && !Array.isArray(input);
}
function flattenSource(source) {
  const output = /* @__PURE__ */ Object.create(null);
  const addLayer = (layer, record, component) => {
    for (const localPath of Object.keys(record).sort(compareAscii)) {
      const definition = record[localPath];
      const path = toCanonicalTokenPath(layer, localPath, component);
      output[path] = {
        path,
        layer,
        ...component ? { component } : {},
        typeId: definition.type,
        value: definition.value,
        source: definition.source,
        appliedTransforms: []
      };
    }
  };
  addLayer(
    "foundation",
    source.foundation
  );
  addLayer("semantic", source.semantic);
  for (const component of Object.keys(source.components).sort(compareAscii)) {
    addLayer(
      "components",
      source.components[component],
      component
    );
  }
  return output;
}
function transformTrace(path, axis, axisValue, order) {
  return [
    {
      kind: "transform-write",
      token: path,
      axis,
      axisValue,
      order
    }
  ];
}
function applyThemeAxes(registry, source, requested) {
  var _a, _b;
  const diagnostics = [];
  const selection = /* @__PURE__ */ Object.create(null);
  for (const axis of AXIS_ORDER$1) {
    const declaration = source.axes[axis];
    const selected = (requested == null ? void 0 : requested[axis]) ?? declaration.default;
    if (typeof selected !== "string" || !AXIS_DOMAINS[axis].includes(selected) || !declaration.supported.includes(selected)) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_VALUE_UNSUPPORTED", {
          source: source.meta.source,
          themeId: source.meta.themeId,
          location: axisLocation(axis),
          details: {
            axis,
            receivedValue: typeof selected === "string" ? selected : "",
            platformDomain: AXIS_DOMAINS[axis],
            themeSupportedValues: declaration.supported
          }
        })
      );
      continue;
    }
    selection[axis] = selected;
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  const definitions = flattenSource(source);
  const writers = /* @__PURE__ */ new Map();
  const directWrites = {
    mode: [],
    density: [],
    contrast: [],
    motion: [],
    radius: []
  };
  let transformOrder = 0;
  for (const axis of AXIS_ORDER$1) {
    const selected = selection[axis];
    const axisTransforms = source.transforms[axis];
    const writes = axisTransforms[selected] ?? [];
    const seenInAxis = /* @__PURE__ */ new Set();
    for (const rawWrite of writes) {
      const write = rawWrite;
      const path = parseCanonicalTokenPath(write.path);
      if (!path || !definitions[path]) {
        const diagnosticPath = path ?? `foundation.invalid-path`;
        diagnostics.push(
          createDiagnostic("TK_TRANSFORM_PATH_UNKNOWN", {
            source: write.source ?? source.meta.source,
            themeId: source.meta.themeId,
            location: tokenLocation(diagnosticPath),
            details: {
              path: typeof write.path === "string" ? write.path : "foundation.invalid-path"
            },
            trace: transformTrace(
              diagnosticPath,
              axis,
              selected,
              transformOrder
            )
          })
        );
        transformOrder += 1;
        continue;
      }
      const base = definitions[path];
      const trace = transformTrace(path, axis, selected, transformOrder);
      const forbiddenFields = FORBIDDEN_TRANSFORM_FIELDS.filter(
        (field) => field in write
      );
      if (forbiddenFields.length > 0) {
        diagnostics.push(
          createDiagnostic("TK_TRANSFORM_MUTATION_FORBIDDEN", {
            source: write.source ?? source.meta.source,
            themeId: source.meta.themeId,
            location: tokenLocation(path),
            details: { path, forbiddenFields },
            trace
          })
        );
        transformOrder += 1;
        continue;
      }
      if (seenInAxis.has(path)) {
        diagnostics.push(
          createDiagnostic("TK_TRANSFORM_CONFLICT", {
            source: write.source ?? source.meta.source,
            themeId: source.meta.themeId,
            location: tokenLocation(path),
            details: { path, writers: [axis, axis] },
            trace
          })
        );
        transformOrder += 1;
        continue;
      }
      seenInAxis.add(path);
      if (write.expectType !== base.typeId) {
        diagnostics.push(
          createDiagnostic("TK_TRANSFORM_TYPE_MISMATCH", {
            source: write.source ?? source.meta.source,
            themeId: source.meta.themeId,
            location: tokenLocation(path),
            details: {
              issue: "expect-vs-base",
              path,
              baseTypeId: base.typeId,
              expectTypeId: typeof write.expectType === "string" ? write.expectType : ""
            },
            trace
          })
        );
        transformOrder += 1;
        continue;
      }
      const value = write.value;
      if ("$ref" in value && value.expect !== write.expectType || "$expr" in value && value.resultType !== write.expectType) {
        diagnostics.push(
          createDiagnostic("TK_TRANSFORM_TYPE_MISMATCH", {
            source: write.source ?? source.meta.source,
            themeId: source.meta.themeId,
            location: tokenLocation(path),
            details: {
              issue: "value-declared-type-vs-expect",
              path,
              baseTypeId: base.typeId,
              expectTypeId: write.expectType,
              valueKind: "$ref" in value ? "alias" : "expression",
              declaredValueTypeId: "$ref" in value ? value.expect : value.resultType
            },
            trace
          })
        );
        transformOrder += 1;
        continue;
      }
      let normalizedValue = value;
      if (value.kind === "literal") {
        const canonical = canonicalizeTypeValue(
          registry,
          base.typeId,
          value.value,
          {
            source: write.source ?? source.meta.source,
            tokenPath: path,
            themeId: source.meta.themeId
          }
        );
        if (!canonical.ok) {
          diagnostics.push(
            createDiagnostic("TK_TRANSFORM_TYPE_MISMATCH", {
              source: write.source ?? source.meta.source,
              themeId: source.meta.themeId,
              location: tokenLocation(path),
              details: {
                issue: "literal-invalid-for-expect",
                path,
                baseTypeId: base.typeId,
                expectTypeId: base.typeId,
                actualValue: (() => {
                  try {
                    return snapshotCanonicalJson(
                      value.value
                    );
                  } catch {
                    return null;
                  }
                })(),
                validationRule: "canonical-type-schema"
              },
              trace
            })
          );
          transformOrder += 1;
          continue;
        }
        normalizedValue = { kind: "literal", value: canonical.value };
      }
      const applied = {
        axis,
        value: selected,
        order: transformOrder,
        path
      };
      definitions[path] = {
        ...base,
        value: normalizedValue,
        source: write.source ?? base.source,
        appliedTransforms: [...base.appliedTransforms, applied]
      };
      const pathWriters = writers.get(path) ?? [];
      pathWriters.push(axis);
      writers.set(path, pathWriters);
      directWrites[axis].push(path);
      transformOrder += 1;
    }
  }
  for (const [path, pathWriters] of writers) {
    const uniqueWriters = AXIS_ORDER$1.filter(
      (axis) => pathWriters.includes(axis)
    );
    if (uniqueWriters.length < 2) continue;
    const policy = (_a = source.conflictPolicy) == null ? void 0 : _a[path];
    const policyWriters = Array.isArray(policy == null ? void 0 : policy.writers) ? policy.writers : [];
    const validPolicy = isRecord$3(policy) && policy.resolution === "fixed-axis-order" && policyWriters.length === uniqueWriters.length && uniqueWriters.every((axis, index) => policyWriters[index] === axis);
    if (!validPolicy) {
      diagnostics.push(
        createDiagnostic("TK_TRANSFORM_CONFLICT", {
          source: source.meta.source,
          themeId: source.meta.themeId,
          location: tokenLocation(path),
          details: { path, writers: uniqueWriters },
          trace: transformTrace(
            path,
            uniqueWriters[uniqueWriters.length - 1],
            selection[uniqueWriters[uniqueWriters.length - 1]],
            ((_b = definitions[path].appliedTransforms[definitions[path].appliedTransforms.length - 1]) == null ? void 0 : _b.order) ?? 0
          )
        })
      );
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  const sortedDefinitions = Object.fromEntries(
    Object.entries(definitions).sort(
      ([left], [right]) => compareAscii(left, right)
    )
  );
  const normalizedDirectWrites = Object.fromEntries(
    AXIS_ORDER$1.map((axis) => [
      axis,
      [...new Set(directWrites[axis])].sort(compareAscii)
    ])
  );
  return ok(
    snapshotCanonicalJson({
      selection,
      definitions: sortedDefinitions,
      directWritesByAxis: normalizedDirectWrites
    })
  );
}
function isRecord$2(input) {
  return Boolean(input) && typeof input === "object" && !Array.isArray(input);
}
function hasOwn$1(input, key) {
  return Object.prototype.hasOwnProperty.call(input, key);
}
function transformDiagnosticTrace(node) {
  return node.appliedTransforms.map(
    (transform2) => ({
      kind: "transform-write",
      token: node.path,
      axis: transform2.axis,
      axisValue: transform2.value,
      order: transform2.order
    })
  );
}
function referenceTrace(edge, node) {
  if (edge.kind === "alias") {
    return [
      ...transformDiagnosticTrace(node),
      { kind: "reference", from: edge.from, to: edge.to }
    ];
  }
  return [
    ...transformDiagnosticTrace(node),
    ...edge.ancestry.map((cause, index) => ({
      kind: "expression-operand",
      token: edge.from,
      operator: cause.operator,
      operandIndex: cause.operandIndex,
      ...index === edge.ancestry.length - 1 ? { dependency: edge.to } : {}
    }))
  ];
}
function expressionPrefixTrace(node, ancestry) {
  return [
    ...transformDiagnosticTrace(node),
    ...ancestry.map((cause) => ({
      kind: "expression-operand",
      token: node.path,
      operator: cause.operator,
      operandIndex: cause.operandIndex
    }))
  ];
}
function edgeTargetAllowed(from, target) {
  if (from.layer === "foundation") {
    return target.layer === "foundation" ? "allowed" : "layer";
  }
  if (from.layer === "semantic") {
    return target.layer === "components" ? "layer" : "allowed";
  }
  if (target.layer === "semantic") return "allowed";
  if (target.layer === "foundation") return "layer";
  return target.component === from.component ? "allowed" : "component";
}
function collectValueEdges(definitions, node, value, expectedTypeId, diagnostics, edges, depth, ancestry = []) {
  if (depth > 64) {
    diagnostics.push(
      createDiagnostic("TK_RESOURCE_LIMIT_EXCEEDED", {
        source: node.source,
        themeId: void 0,
        location: themeLocation(),
        details: {
          resource: "expression-depth",
          limit: 64,
          actual: depth,
          truncated: true
        }
      })
    );
    return;
  }
  if (!isRecord$2(value)) return;
  if ("$ref" in value) {
    const targetPath = value.$ref;
    const edge = {
      from: node.path,
      to: targetPath,
      kind: ancestry.length === 0 ? "alias" : "expression",
      ...ancestry.length === 0 ? {} : {
        operandIndex: ancestry.at(-1).operandIndex,
        operator: ancestry.at(-1).operator
      },
      ancestry,
      ...typeof value.field === "string" ? { projection: value.field } : {},
      expectedTypeId,
      ...typeof value.targetType === "string" ? { targetTypeId: value.targetType } : {}
    };
    const target = definitions[targetPath];
    if (!target) {
      diagnostics.push(
        createDiagnostic("TK_REF_TARGET_MISSING", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            from: node.path,
            to: targetPath,
            allowedTargets: ["existing canonical token path"]
          },
          trace: referenceTrace(edge, node)
        })
      );
      return;
    }
    const boundary = edgeTargetAllowed(node, target);
    if (boundary === "layer") {
      diagnostics.push(
        createDiagnostic("TK_REF_LAYER_FORBIDDEN", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            from: node.path,
            to: targetPath,
            allowedTargets: node.layer === "foundation" ? ["foundation.*"] : node.layer === "semantic" ? ["foundation.*", "semantic.*"] : ["semantic.*", `components.${node.component}.*`]
          },
          trace: referenceTrace(edge, node)
        })
      );
      return;
    }
    if (boundary === "component") {
      diagnostics.push(
        createDiagnostic("TK_REF_COMPONENT_FORBIDDEN", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            from: node.path,
            to: targetPath,
            allowedTargets: ["semantic.*", `components.${node.component}.*`]
          },
          trace: referenceTrace(edge, node)
        })
      );
      return;
    }
    edges.push(edge);
    return;
  }
  if ("$expr" in value) {
    const operator = value.$expr;
    if (typeof operator !== "string" || !hasOwn$1(OPERATOR_SIGNATURES, operator)) {
      diagnostics.push(
        createDiagnostic("TK_EXPR_OPERATOR_UNKNOWN", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            operator: typeof operator === "string" ? operator : "",
            supportedOperators: Object.keys(OPERATOR_SIGNATURES).sort(compareAscii)
          },
          trace: [
            ...expressionPrefixTrace(node, ancestry),
            {
              kind: "unknown-expression",
              token: node.path,
              rawOperator: typeof operator === "string" ? operator : "",
              ...ancestry.length === 0 ? {} : { operandIndex: ancestry.at(-1).operandIndex }
            }
          ]
        })
      );
      return;
    }
    const operatorId = operator;
    const signatures = OPERATOR_SIGNATURES[operatorId];
    const outputTypes = [
      ...new Set(signatures.map((signature) => signature.result))
    ];
    if (!outputTypes.includes(value.resultType)) {
      diagnostics.push(
        createDiagnostic("TK_EXPR_RESULT_TYPE_MISMATCH", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            mismatch: "declared-vs-operator",
            operator: operatorId,
            declaredResultTypeId: typeof value.resultType === "string" ? value.resultType : "",
            operatorResultTypeIds: outputTypes,
            expectedResultTypeId: expectedTypeId
          },
          trace: [
            ...expressionPrefixTrace(node, ancestry),
            {
              kind: "expression-result",
              token: node.path,
              operator: operatorId,
              declaredResultTypeId: typeof value.resultType === "string" ? value.resultType : "",
              expectedResultTypeId: expectedTypeId
            }
          ]
        })
      );
      return;
    }
    if (value.resultType !== expectedTypeId) {
      diagnostics.push(
        createDiagnostic("TK_EXPR_RESULT_TYPE_MISMATCH", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            mismatch: "declared-vs-context",
            operator: operatorId,
            declaredResultTypeId: value.resultType,
            operatorResultTypeIds: outputTypes,
            expectedResultTypeId: expectedTypeId
          },
          trace: [
            ...expressionPrefixTrace(node, ancestry),
            {
              kind: "expression-result",
              token: node.path,
              operator: operatorId,
              declaredResultTypeId: value.resultType,
              expectedResultTypeId: expectedTypeId
            }
          ]
        })
      );
      return;
    }
    const args = Array.isArray(value.args) ? value.args : [];
    const matchingArity = signatures.filter(
      (signature) => signature.args.length === args.length
    );
    if (matchingArity.length === 0) {
      const expectedArities = [
        ...new Set(signatures.map((signature) => signature.args.length))
      ].sort((left, right) => left - right);
      diagnostics.push(
        createDiagnostic("TK_EXPR_OPERAND_INVALID", {
          source: node.source,
          location: tokenLocation(node.path),
          details: {
            issue: "arity",
            operator: operatorId,
            receivedArity: args.length,
            expectedArities
          },
          trace: [
            ...expressionPrefixTrace(node, ancestry),
            {
              kind: "expression-arity",
              token: node.path,
              operator: operatorId,
              receivedArity: args.length,
              expectedArities
            }
          ]
        })
      );
      return;
    }
    args.forEach((operand, index) => {
      if (!isRecord$2(operand) || typeof operand.kind !== "string") {
        diagnostics.push(
          createDiagnostic("TK_EXPR_OPERAND_INVALID", {
            source: node.source,
            location: tokenLocation(node.path),
            details: {
              issue: "operand-type",
              operator: operatorId,
              operandIndex: index,
              expectedTypeIds: matchingArity.map(
                (signature) => signature.args[index]
              ),
              actualTypeId: null,
              actualValue: null
            },
            trace: [
              ...expressionPrefixTrace(node, ancestry),
              {
                kind: "expression-operand",
                token: node.path,
                operator: operatorId,
                operandIndex: index
              }
            ]
          })
        );
        return;
      }
      const expectedTypes = [
        ...new Set(
          matchingArity.map((signature) => signature.args[index]).filter(Boolean)
        )
      ];
      const actualType = operand.kind === "literal" ? operand.type : operand.kind === "ref" && isRecord$2(operand.ref) ? operand.ref.expect : operand.kind === "expr" && isRecord$2(operand.expr) ? operand.expr.resultType : null;
      if (typeof actualType !== "string" || !expectedTypes.includes(actualType)) {
        diagnostics.push(
          createDiagnostic("TK_EXPR_OPERAND_INVALID", {
            source: node.source,
            location: tokenLocation(node.path),
            details: {
              issue: "operand-type",
              operator: operatorId,
              operandIndex: index,
              expectedTypeIds: expectedTypes,
              actualTypeId: typeof actualType === "string" ? actualType : null,
              actualValue: operand.kind === "literal" ? (() => {
                try {
                  return snapshotCanonicalJson(
                    operand.value
                  );
                } catch {
                  return null;
                }
              })() : null
            },
            trace: [
              ...expressionPrefixTrace(node, ancestry),
              {
                kind: "expression-operand",
                token: node.path,
                operator: operatorId,
                operandIndex: index
              }
            ]
          })
        );
        return;
      }
      if (operand.kind === "ref") {
        collectValueEdges(
          definitions,
          node,
          operand.ref,
          actualType,
          diagnostics,
          edges,
          depth + 1,
          [...ancestry, { operator: operatorId, operandIndex: index }]
        );
      } else if (operand.kind === "expr") {
        collectValueEdges(
          definitions,
          node,
          operand.expr,
          actualType,
          diagnostics,
          edges,
          depth + 1,
          [...ancestry, { operator: operatorId, operandIndex: index }]
        );
      }
    });
  }
}
function collectGraphEdges(effective) {
  const diagnostics = [];
  const edges = [];
  const paths = Object.keys(effective.definitions).sort(
    compareAscii
  );
  if (paths.length > 1e4) {
    diagnostics.push(
      createDiagnostic("TK_RESOURCE_LIMIT_EXCEEDED", {
        location: themeLocation(),
        details: {
          resource: "tokens",
          limit: 1e4,
          actual: paths.length,
          truncated: true
        }
      })
    );
    return { edges, diagnostics };
  }
  for (const path of paths) {
    if (path.length > 512) {
      diagnostics.push(
        createDiagnostic("TK_RESOURCE_LIMIT_EXCEEDED", {
          source: effective.definitions[path].source,
          location: themeLocation(),
          details: {
            resource: "path-length",
            limit: 512,
            actual: path.length,
            truncated: false
          }
        })
      );
      continue;
    }
    const node = effective.definitions[path];
    collectValueEdges(
      effective.definitions,
      node,
      node.value,
      node.typeId,
      diagnostics,
      edges,
      0
    );
    if (edges.length > 1e5) {
      diagnostics.push(
        createDiagnostic("TK_RESOURCE_LIMIT_EXCEEDED", {
          source: node.source,
          location: themeLocation(),
          details: {
            resource: "edges",
            limit: 1e5,
            actual: edges.length,
            truncated: true
          }
        })
      );
      break;
    }
  }
  return { edges, diagnostics };
}
function compareEdge(left, right) {
  const kind = (left.kind === "alias" ? 0 : 1) - (right.kind === "alias" ? 0 : 1);
  if (kind !== 0) return kind;
  const ancestry = compareAscii(
    left.ancestry.map((cause) => `${cause.operator}:${cause.operandIndex}`).join(">"),
    right.ancestry.map((cause) => `${cause.operator}:${cause.operandIndex}`).join(">")
  );
  if (ancestry !== 0) return ancestry;
  return compareAscii(left.to, right.to);
}
function edgeIdentity(edge) {
  return [
    edge.from,
    edge.kind,
    edge.ancestry.map((cause) => `${cause.operator}:${cause.operandIndex}`).join(">"),
    edge.to
  ].join("\0");
}
function canonicalCycle(edges) {
  const rotations = edges.map((_, index) => [
    ...edges.slice(index),
    ...edges.slice(0, index)
  ]);
  return rotations.map((rotation) => rotation.map(edgeIdentity).join("")).sort(compareAscii)[0];
}
function shortestCycle(paths, edges) {
  const adjacency = /* @__PURE__ */ new Map();
  for (const edge of edges) {
    const list = adjacency.get(edge.from) ?? [];
    list.push(edge);
    adjacency.set(edge.from, list);
  }
  for (const list of adjacency.values()) list.sort(compareEdge);
  const candidates = [];
  for (const start of paths) {
    const queue = [start];
    const previous = /* @__PURE__ */ new Map([[start, null]]);
    let cursor = 0;
    while (cursor < queue.length) {
      const current = queue[cursor++];
      for (const edge of adjacency.get(current) ?? []) {
        if (edge.to === start) {
          const cycleEdges = [edge];
          let cursorNode = current;
          while (cursorNode !== start) {
            const prior = previous.get(cursorNode);
            if (!prior) break;
            cycleEdges.push(prior.edge);
            cursorNode = prior.parent;
          }
          cycleEdges.reverse();
          candidates.push({
            edges: cycleEdges,
            paths: [start, ...cycleEdges.map((item) => item.to)]
          });
          cursor = queue.length;
          break;
        }
        if (!previous.has(edge.to)) {
          previous.set(edge.to, { parent: current, edge });
          queue.push(edge.to);
        }
      }
    }
  }
  if (candidates.length === 0) return null;
  candidates.sort((left, right) => {
    const length = left.edges.length - right.edges.length;
    if (length !== 0) return length;
    return compareAscii(canonicalCycle(left.edges), canonicalCycle(right.edges));
  });
  return candidates[0];
}
function resolveEffectiveGraph(registry, effective, themeId) {
  const collected = collectGraphEdges(effective);
  if (collected.diagnostics.length > 0) return failure(collected.diagnostics);
  const paths = Object.keys(effective.definitions).sort(
    compareAscii
  );
  const cycle = shortestCycle(paths, collected.edges);
  if (cycle) {
    const node = effective.definitions[cycle.paths[0]];
    return failure([
      createDiagnostic("TK_REF_CYCLE", {
        source: node.source,
        themeId,
        location: tokenLocation(node.path),
        details: { cycle: cycle.paths, edgeCount: cycle.edges.length },
        trace: cycle.edges.flatMap(
          (edge) => referenceTrace(edge, effective.definitions[edge.from])
        )
      })
    ]);
  }
  const memo = /* @__PURE__ */ new Map();
  const failed = /* @__PURE__ */ new Set();
  const diagnostics = [];
  const resolveAlias = (node, alias, expectedTypeId, operator, operandIndex, diagnosticAncestry = []) => {
    const targetPath = alias.$ref;
    const target = resolveNode(targetPath);
    if (!target) return null;
    const field = typeof alias.field === "string" ? alias.field : void 0;
    let value = target.value;
    let actualTypeId = target.typeId;
    const diagnosticTrace = () => referenceTrace(
      {
        from: node.path,
        to: targetPath,
        kind: diagnosticAncestry.length === 0 ? "alias" : "expression",
        ancestry: diagnosticAncestry,
        ...diagnosticAncestry.length === 0 ? {} : {
          operator: diagnosticAncestry.at(-1).operator,
          operandIndex: diagnosticAncestry.at(-1).operandIndex
        },
        ...field ? { projection: field } : {}
      },
      node
    );
    if (field) {
      const projection = hasOwn$1(FIELD_PROJECTIONS, field) ? FIELD_PROJECTIONS[field] : void 0;
      if (!projection || projection.targetType !== target.typeId || !projection.resultTypes.includes(expectedTypeId)) {
        diagnostics.push(
          createDiagnostic("TK_TYPE_ALIAS_MISMATCH", {
            source: node.source,
            themeId,
            location: tokenLocation(node.path),
            details: {
              from: node.path,
              to: targetPath,
              projection: field,
              expectedTypeId,
              actualTypeId: target.typeId,
              actualValue: target.value
            },
            trace: diagnosticTrace()
          })
        );
        return null;
      }
      value = projectField(field, target.value);
      actualTypeId = expectedTypeId;
    }
    if (actualTypeId !== expectedTypeId) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_ALIAS_MISMATCH", {
          source: node.source,
          themeId,
          location: tokenLocation(node.path),
          details: {
            from: node.path,
            to: targetPath,
            projection: field ?? null,
            expectedTypeId,
            actualTypeId,
            actualValue: target.value
          },
          trace: diagnosticTrace()
        })
      );
      return null;
    }
    return {
      value,
      typeId: expectedTypeId,
      dependencies: [targetPath],
      trace: [
        ...operator ? [
          {
            kind: "expression",
            token: node.path,
            operator,
            operandIndex: operandIndex ?? 0,
            dependency: targetPath
          }
        ] : [
          {
            kind: "alias",
            from: node.path,
            to: targetPath,
            ...field ? { projection: field } : {}
          }
        ],
        ...target.trace
      ]
    };
  };
  const resolveExpression = (node, expression, expectedTypeId, ancestry = []) => {
    if (typeof expression.$expr !== "string" || !hasOwn$1(OPERATOR_SIGNATURES, expression.$expr)) {
      return null;
    }
    const operator = expression.$expr;
    const signatures = OPERATOR_SIGNATURES[operator];
    if (!Array.isArray(signatures)) return null;
    const args = expression.args;
    const matching = signatures.filter(
      (signature) => signature.args.length === args.length
    );
    const selected = matching.find(
      (signature) => args.every((operand, index) => {
        const actual = operand.kind === "literal" ? operand.type : operand.kind === "ref" ? operand.ref.expect : operand.expr.resultType;
        return actual === signature.args[index];
      })
    );
    if (!selected) return null;
    const values = [];
    const dependencies2 = /* @__PURE__ */ new Set();
    const trace = [];
    for (let index = 0; index < args.length; index += 1) {
      const operand = args[index];
      const operandType = selected.args[index];
      if (operand.kind === "literal") {
        const canonical = canonicalizeTypeValue(
          registry,
          operandType,
          operand.value,
          { source: node.source, tokenPath: node.path, themeId }
        );
        if (!canonical.ok) {
          diagnostics.push(...canonical.diagnostics);
          return null;
        }
        values.push(canonical.value);
        trace.push({
          kind: "expression",
          token: node.path,
          operator,
          operandIndex: index
        });
      } else if (operand.kind === "ref") {
        const resolved = resolveAlias(
          node,
          operand.ref,
          operandType,
          operator,
          index,
          [...ancestry, { operator, operandIndex: index }]
        );
        if (!resolved) return null;
        values.push(resolved.value);
        resolved.dependencies.forEach(
          (dependency) => dependencies2.add(dependency)
        );
        trace.push(...resolved.trace);
      } else {
        const resolved = resolveExpression(
          node,
          operand.expr,
          operandType,
          [...ancestry, { operator, operandIndex: index }]
        );
        if (!resolved) return null;
        values.push(resolved.value);
        resolved.dependencies.forEach(
          (dependency) => dependencies2.add(dependency)
        );
        trace.push({
          kind: "expression",
          token: node.path,
          operator,
          operandIndex: index
        });
        trace.push(...resolved.trace);
      }
    }
    try {
      const first = evaluateOperator(operator, values);
      const replay = evaluateOperator(operator, values);
      if (first.hash !== replay.hash) {
        diagnostics.push(
          createDiagnostic("TK_EXPR_NON_DETERMINISTIC", {
            source: node.source,
            themeId,
            location: tokenLocation(node.path),
            details: {
              operator,
              firstHash: first.hash,
              replayHash: replay.hash
            },
            trace: [
              ...expressionPrefixTrace(node, ancestry),
              {
                kind: "expression-evaluation",
                token: node.path,
                operator,
                issue: "non-deterministic",
                operandIndices: values.map((_, index) => index)
              }
            ]
          })
        );
        return null;
      }
      if (first.typeId !== expectedTypeId) return null;
      return {
        value: first.value,
        typeId: first.typeId,
        dependencies: [...dependencies2].sort(compareAscii),
        trace
      };
    } catch (error) {
      if (error instanceof OperatorEvaluationError) {
        diagnostics.push(
          createDiagnostic("TK_EXPR_EVALUATION_INVALID", {
            source: node.source,
            themeId,
            location: tokenLocation(node.path),
            details: error.details,
            trace: [
              ...expressionPrefixTrace(node, ancestry),
              {
                kind: "expression-evaluation",
                token: node.path,
                operator,
                issue: error.issue,
                operandIndices: values.map((_, index) => index)
              }
            ]
          })
        );
        return null;
      }
      throw error;
    }
  };
  const resolveNode = (path) => {
    const memoized = memo.get(path);
    if (memoized) return memoized;
    if (failed.has(path)) return null;
    const node = effective.definitions[path];
    const value = node.value;
    let resolved;
    if (value.kind === "literal") {
      resolved = {
        value: value.value,
        typeId: node.typeId,
        dependencies: [],
        trace: []
      };
    } else if ("$ref" in value) {
      resolved = resolveAlias(node, value, node.typeId);
    } else {
      resolved = resolveExpression(node, value, node.typeId);
    }
    if (!resolved) {
      failed.add(path);
      return null;
    }
    const transformTrace2 = node.appliedTransforms.map((transform2) => ({
      kind: "transform",
      token: node.path,
      axis: transform2.axis,
      axisValue: transform2.value,
      order: transform2.order
    }));
    const finalValue = {
      ...resolved,
      dependencies: [...new Set(resolved.dependencies)].sort(compareAscii),
      trace: [...transformTrace2, ...resolved.trace]
    };
    memo.set(path, finalValue);
    return finalValue;
  };
  const resolvedTokens = /* @__PURE__ */ Object.create(null);
  for (const path of paths) {
    const resolved = resolveNode(path);
    if (!resolved) continue;
    resolvedTokens[path] = {
      ...effective.definitions[path],
      canonicalValue: resolved.value,
      directDependencies: resolved.dependencies,
      trace: resolved.trace
    };
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  const dependencies = Object.fromEntries(
    paths.map((path) => [path, resolvedTokens[path].directDependencies])
  );
  return ok(
    snapshotCanonicalJson({
      tokens: resolvedTokens,
      dependencies
    })
  );
}
function resolvedTokenSemanticProjection(token) {
  return snapshotCanonicalJson({
    path: token.path,
    layer: token.layer,
    component: token.component ?? null,
    typeId: token.typeId,
    value: token.value,
    source: token.source,
    directDependencies: token.directDependencies,
    trace: token.trace,
    appliedTransforms: token.appliedTransforms,
    visibility: token.visibility,
    public: token.public ?? null
  });
}
function projectionsEqual(left, right) {
  return canonicalJsonStringify(left) === canonicalJsonStringify(right);
}
function isRecord$1(input) {
  return Boolean(input) && typeof input === "object" && !Array.isArray(input);
}
function hasOwn(input, key) {
  return Object.prototype.hasOwnProperty.call(input, key);
}
function exactKeys(input, required, optional = []) {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  return required.every((key) => Object.prototype.hasOwnProperty.call(input, key)) && Object.keys(input).every((key) => allowed.has(key));
}
function isSha256(input) {
  return typeof input === "string" && /^sha256:[a-f0-9]{64}$/.test(input);
}
function isSortedUnique(values) {
  return values.every(
    (value, index) => index === 0 || compareAscii(values[index - 1], value) < 0
  );
}
function locatorsEqual(left, right) {
  return left.file === right.file && left.line === right.line && left.column === right.column;
}
function hashResolvedWithoutContentHash(input) {
  const { contentHash: _contentHash, ...content } = input;
  return computeCanonicalHash(content);
}
function resolveThemeWithRegistry(registry, input) {
  const sourceLocation = parseLogicalSourceLocator(
    input.sourceLocation,
    "resolveTheme",
    "sourceLocation"
  );
  const contractLocation = parseLogicalSourceLocator(
    input.contractLocation,
    "resolveTheme",
    "contractLocation"
  );
  const locatorDiagnostics = [
    ...sourceLocation.ok ? [] : sourceLocation.diagnostics,
    ...contractLocation.ok ? [] : contractLocation.diagnostics
  ];
  if (locatorDiagnostics.length > 0) return failure(locatorDiagnostics);
  if (!sourceLocation.ok || !contractLocation.ok) {
    return failure(locatorDiagnostics);
  }
  if (!locatorsEqual(input.source.meta.source, sourceLocation.value) || !locatorsEqual(input.contract.source, contractLocation.value)) {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: sourceLocation.value,
        themeId: input.source.meta.themeId,
        location: themeLocation(),
        details: {
          valueKind: "object",
          instancePath: !locatorsEqual(
            input.source.meta.source,
            sourceLocation.value
          ) ? "$.sourceLocation" : "$.contractLocation",
          issue: "locator-mismatch"
        }
      })
    ]);
  }
  const effective = applyThemeAxes(registry, input.source, input.axes);
  if (!effective.ok) return effective;
  const graph = resolveEffectiveGraph(
    registry,
    effective.value,
    input.source.meta.themeId
  );
  if (!graph.ok) return graph;
  const tokens = applyPublicContract(
    graph.value,
    input.contract,
    input.source.meta.themeId
  );
  if (!tokens.ok) return tokens;
  const sourceContentHash = computeCanonicalHash(input.source);
  const contractContentHash = computeCanonicalHash(input.contract);
  const publicSurface = Object.keys(input.contract.entries).sort(
    compareAscii
  );
  const contentWithoutHash = snapshotCanonicalJson({
    sourceSchemaVersion: 4,
    resolvedSchemaVersion: 1,
    contractVersion: "4.0.0",
    themeId: input.source.meta.themeId,
    sourceContentHash,
    contractContentHash,
    typeRegistryContentHash: registry.typeRegistryContentHash,
    axes: {
      selection: effective.value.selection,
      applicationOrder: AXIS_ORDER$1
    },
    tokens: tokens.value,
    publicSurface
  });
  const contentHash = computeCanonicalHash(contentWithoutHash);
  return ok(
    snapshotCanonicalJson({
      ...contentWithoutHash,
      contentHash
    })
  );
}
function isLogicalLocatorShape(input) {
  if (!isRecord$1(input) || !exactKeys(input, ["file"], ["line", "column"])) {
    return false;
  }
  if (typeof input.file !== "string" || input.file.length === 0 || /^(?:\/|[A-Za-z]:[\\/]|\\\\)/.test(input.file) || input.file.includes("\\") || input.file.split("/").some((segment) => segment === "" || segment === "." || segment === "..")) {
    return false;
  }
  return ["line", "column"].every((key) => {
    const value = input[key];
    return value === void 0 || typeof value === "number" && Number.isSafeInteger(value) && value >= 1;
  });
}
function isResolutionTrace(input) {
  if (!isRecord$1(input) || typeof input.kind !== "string") return false;
  if (input.kind === "alias") {
    return exactKeys(input, ["kind", "from", "to"], ["projection"]) && parseCanonicalTokenPath(input.from) !== null && parseCanonicalTokenPath(input.to) !== null && (input.projection === void 0 || typeof input.projection === "string" && hasOwn(FIELD_PROJECTIONS, input.projection));
  }
  if (input.kind === "expression") {
    if (!exactKeys(
      input,
      ["kind", "token", "operator", "operandIndex"],
      ["dependency"]
    ) || parseCanonicalTokenPath(input.token) === null || typeof input.operator !== "string" || !hasOwn(OPERATOR_SIGNATURES, input.operator) || !Number.isSafeInteger(input.operandIndex) || input.operandIndex < 0 || input.dependency !== void 0 && parseCanonicalTokenPath(input.dependency) === null) {
      return false;
    }
    const signatures = OPERATOR_SIGNATURES[input.operator];
    return Array.isArray(signatures) && signatures.some(
      (signature) => input.operandIndex < signature.args.length
    );
  }
  if (input.kind === "transform") {
    return exactKeys(input, ["kind", "token", "axis", "axisValue", "order"]) && parseCanonicalTokenPath(input.token) !== null && typeof input.axis === "string" && AXIS_ORDER$1.includes(input.axis) && typeof input.axisValue === "string" && AXIS_DOMAINS[input.axis].includes(
      input.axisValue
    ) && Number.isSafeInteger(input.order) && input.order >= 0;
  }
  return false;
}
function resolutionTraceActor(input) {
  return input.kind === "alias" ? String(input.from) : String(input.token);
}
function dependencyCanProvideType(target, expectedTypeId) {
  if (target.typeId === expectedTypeId) return true;
  return Object.values(FIELD_PROJECTIONS).some(
    (projection) => projection.targetType === target.typeId && projection.resultTypes.includes(expectedTypeId)
  );
}
function expressionTraceEndIndices(entries, start, expectedTypeId, tokens, depth = 0, memo = /* @__PURE__ */ new Map()) {
  if (depth > 64 || start >= entries.length) return [];
  const memoKey = `${start}:${expectedTypeId}:${depth}`;
  const memoized = memo.get(memoKey);
  if (memoized) return memoized;
  const first = entries[start];
  if ((first == null ? void 0 : first.kind) !== "expression" || first.operandIndex !== 0 || typeof first.operator !== "string" || !hasOwn(OPERATOR_SIGNATURES, first.operator)) {
    return [];
  }
  const signatures = OPERATOR_SIGNATURES[first.operator];
  if (!Array.isArray(signatures)) return [];
  const ends = /* @__PURE__ */ new Set();
  for (const signature of signatures) {
    if (signature.result !== expectedTypeId) continue;
    let positions = [start];
    for (let operandIndex = 0; operandIndex < signature.args.length; operandIndex += 1) {
      const nextPositions = /* @__PURE__ */ new Set();
      for (const position of positions) {
        const entry = entries[position];
        if ((entry == null ? void 0 : entry.kind) !== "expression" || entry.operator !== first.operator || entry.operandIndex !== operandIndex) {
          continue;
        }
        const afterEntry = position + 1;
        if (entry.dependency !== void 0) {
          const target = tokens[String(entry.dependency)];
          if (target && dependencyCanProvideType(target, signature.args[operandIndex])) {
            nextPositions.add(afterEntry);
          }
          continue;
        }
        nextPositions.add(afterEntry);
        for (const nestedEnd of expressionTraceEndIndices(
          entries,
          afterEntry,
          signature.args[operandIndex],
          tokens,
          depth + 1,
          memo
        )) {
          nextPositions.add(nestedEnd);
        }
      }
      positions = [...nextPositions];
      if (positions.length === 0) break;
    }
    positions.forEach((position) => ends.add(position));
  }
  const output = [...ends];
  memo.set(memoKey, output);
  return output;
}
function hasConsistentResolutionCausality(token, path, tokens, selection) {
  const trace = token.trace;
  const directDependencies = token.directDependencies;
  const appliedTransforms = token.appliedTransforms;
  const ownTransformTrace = appliedTransforms.map((transform2) => ({
    kind: "transform",
    token: path,
    axis: transform2.axis,
    axisValue: transform2.value,
    order: transform2.order
  }));
  if (canonicalJsonStringify(trace.slice(0, ownTransformTrace.length)) !== canonicalJsonStringify(ownTransformTrace)) {
    return false;
  }
  const observedDirectDependencies = /* @__PURE__ */ new Set();
  const localTrace = [];
  let cursor = ownTransformTrace.length;
  while (cursor < trace.length) {
    const entry = trace[cursor];
    if (resolutionTraceActor(entry) !== path || entry.kind === "transform") {
      return false;
    }
    localTrace.push(entry);
    let dependency;
    if (entry.kind === "alias") {
      dependency = String(entry.to);
      const target = tokens[dependency];
      if (!target) return false;
      if (entry.projection !== void 0) {
        const projection = FIELD_PROJECTIONS[String(entry.projection)];
        if (!projection || target.typeId !== projection.targetType || !projection.resultTypes.includes(token.typeId)) {
          return false;
        }
      }
    } else if (entry.kind === "expression" && entry.dependency !== void 0) {
      dependency = String(entry.dependency);
    }
    cursor += 1;
    if (dependency !== void 0) {
      const target = tokens[dependency];
      if (!target || !Array.isArray(target.trace)) return false;
      observedDirectDependencies.add(dependency);
      const targetTrace = target.trace;
      if (canonicalJsonStringify(
        trace.slice(cursor, cursor + targetTrace.length)
      ) !== canonicalJsonStringify(targetTrace)) {
        return false;
      }
      cursor += targetTrace.length;
    }
  }
  if (localTrace.length > 0) {
    const first = localTrace[0];
    if (first.kind === "alias") {
      if (localTrace.length !== 1) return false;
      const target = tokens[String(first.to)];
      if (!target) return false;
      if (first.projection === void 0) {
        if (target.typeId !== token.typeId) return false;
      } else {
        const projection = FIELD_PROJECTIONS[String(first.projection)];
        if (!projection || target.typeId !== projection.targetType || !projection.resultTypes.includes(token.typeId)) {
          return false;
        }
      }
    } else if (first.kind !== "expression" || localTrace.some((entry) => entry.kind !== "expression") || !expressionTraceEndIndices(
      localTrace,
      0,
      String(token.typeId),
      tokens
    ).includes(localTrace.length)) {
      return false;
    }
  }
  if (canonicalJsonStringify(
    [...observedDirectDependencies].sort(compareAscii)
  ) !== canonicalJsonStringify(directDependencies)) {
    return false;
  }
  return appliedTransforms.every(
    (transform2) => selection[String(transform2.axis)] === transform2.value
  );
}
function isAppliedTransform(input, path) {
  if (!isRecord$1(input) || !exactKeys(input, ["axis", "value", "order", "path"]) || typeof input.axis !== "string" || !AXIS_ORDER$1.includes(input.axis) || typeof input.value !== "string" || input.path !== path || !Number.isSafeInteger(input.order) || input.order < 0) {
    return false;
  }
  const domain = AXIS_DOMAINS[input.axis];
  return domain.includes(input.value);
}
function isResolvedPublicMetadata(input, typeId, path) {
  if (!isRecord$1(input) || input.typeId !== typeId) return false;
  const base = [
    "typeId",
    "description",
    "owner",
    "rationale",
    "lifecycle",
    "source"
  ];
  if (typeof input.description !== "string" || input.description.length === 0 || typeof input.owner !== "string" || input.owner.length === 0 || !isValidPublicAdmissionRationale(path, input.rationale) || !isLogicalLocatorShape(input.source)) {
    return false;
  }
  if (input.lifecycle === "stable") return exactKeys(input, base);
  if (input.lifecycle === "experimental") {
    return exactKeys(input, [...base, "introducedIn"]) && isStrictSemVer(input.introducedIn);
  }
  return input.lifecycle === "deprecated" && exactKeys(input, [...base, "deprecatedSince", "migration"]) && isStrictSemVer(input.deprecatedSince) && isValidPublicMigration(input.migration);
}
function validateResolvedThemeWithRegistry(registry, input, inputLocation) {
  const locator = parseLogicalSourceLocator(
    inputLocation,
    "validateResolvedTheme",
    "inputLocation"
  );
  if (!locator.ok) return locator;
  let owned;
  try {
    owned = snapshotCanonicalJson(input);
  } catch {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: locator.value,
        location: themeLocation(),
        details: { valueKind: typeof input, instancePath: "$.resolved" }
      })
    ]);
  }
  if (!isRecord$1(owned)) {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: locator.value,
        location: themeLocation(),
        details: { valueKind: typeof owned, instancePath: "$.resolved" }
      })
    ]);
  }
  if (owned.resolvedSchemaVersion !== 1) {
    return failure([
      createDiagnostic("TK_RESOLVED_VERSION_UNSUPPORTED", {
        source: locator.value,
        location: themeLocation(),
        details: {
          receivedVersion: typeof owned.resolvedSchemaVersion === "string" || typeof owned.resolvedSchemaVersion === "number" ? owned.resolvedSchemaVersion : -1,
          supportedVersions: [1]
        }
      })
    ]);
  }
  const invalidShape = (instancePath, issue) => failure([
    createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
      source: locator.value,
      themeId: typeof owned.themeId === "string" ? owned.themeId : void 0,
      location: themeLocation(),
      details: {
        valueKind: "object",
        instancePath,
        issue
      }
    })
  ]);
  if (!exactKeys(owned, [
    "sourceSchemaVersion",
    "resolvedSchemaVersion",
    "contractVersion",
    "themeId",
    "sourceContentHash",
    "contractContentHash",
    "typeRegistryContentHash",
    "axes",
    "tokens",
    "publicSurface",
    "contentHash"
  ]) || owned.sourceSchemaVersion !== 4 || owned.contractVersion !== "4.0.0" || typeof owned.themeId !== "string" || owned.themeId.length === 0 || !isSha256(owned.sourceContentHash) || !isSha256(owned.contractContentHash) || owned.typeRegistryContentHash !== registry.typeRegistryContentHash || !isSha256(owned.contentHash)) {
    return invalidShape("$.resolved", "resolved-shape-invalid");
  }
  if (!isRecord$1(owned.axes) || !exactKeys(owned.axes, ["selection", "applicationOrder"]) || !isRecord$1(owned.axes.selection) || !exactKeys(owned.axes.selection, AXIS_ORDER$1) || !Array.isArray(owned.axes.applicationOrder) || canonicalJsonStringify(owned.axes.applicationOrder) !== canonicalJsonStringify(AXIS_ORDER$1) || AXIS_ORDER$1.some(
    (axis) => typeof owned.axes === "object" && (!isRecord$1(owned.axes.selection) || !AXIS_DOMAINS[axis].includes(
      owned.axes.selection[axis]
    ))
  )) {
    return invalidShape("$.axes", "resolved-axes-invalid");
  }
  if (!isRecord$1(owned.tokens) || Object.keys(owned.tokens).length === 0 || !Array.isArray(owned.publicSurface) || !owned.publicSurface.every(
    (path) => typeof path === "string" && parseCanonicalTokenPath(path) !== null
  ) || !isSortedUnique(owned.publicSurface)) {
    return invalidShape("$.tokens", "resolved-token-catalog-invalid");
  }
  const tokenPaths = Object.keys(owned.tokens).sort(compareAscii);
  const tokenPathSet = new Set(tokenPaths);
  const publicPaths = [];
  for (const path of tokenPaths) {
    const token = owned.tokens[path];
    const parsedPath = parseCanonicalTokenPath(path);
    const componentNamespace = path.startsWith("components.") ? path.split(".")[1] : void 0;
    if (parsedPath === null || !isRecord$1(token) || !exactKeys(
      token,
      [
        "path",
        "layer",
        "typeId",
        "value",
        "source",
        "directDependencies",
        "trace",
        "appliedTransforms",
        "visibility"
      ],
      ["component", "public"]
    ) || token.path !== path || !["foundation", "semantic", "components"].includes(String(token.layer)) || (path.startsWith("foundation.") ? token.layer !== "foundation" : path.startsWith("semantic.") ? token.layer !== "semantic" : token.layer !== "components") || typeof token.typeId !== "string" || !registry.registeredTypeIds.includes(token.typeId) || !isLogicalLocatorShape(token.source) || !Array.isArray(token.directDependencies) || !token.directDependencies.every(
      (dependency) => typeof dependency === "string" && parseCanonicalTokenPath(dependency) !== null
    ) || !isSortedUnique(token.directDependencies) || !Array.isArray(token.trace) || !token.trace.every(isResolutionTrace) || !Array.isArray(token.appliedTransforms) || !token.appliedTransforms.every(
      (transform2) => isAppliedTransform(transform2, path)
    ) || (token.layer === "components" ? typeof token.component !== "string" || token.component !== componentNamespace : token.component !== void 0)) {
      return invalidShape(`$.tokens.${path}`, "resolved-token-invalid");
    }
    const canonical = canonicalizeTypeValue(
      registry,
      token.typeId,
      token.value,
      {
        source: locator.value,
        tokenPath: path,
        themeId: owned.themeId
      }
    );
    if (!canonical.ok) return canonical;
    if (canonicalJsonStringify(canonical.value) !== canonicalJsonStringify(token.value)) {
      return invalidShape(
        `$.tokens.${path}.value`,
        "resolved-value-not-canonical"
      );
    }
    if (token.visibility === "public") {
      if (!isResolvedPublicMetadata(token.public, token.typeId, path)) {
        return invalidShape(
          `$.tokens.${path}.public`,
          "resolved-public-invalid"
        );
      }
      publicPaths.push(path);
    } else if (token.visibility !== "internal" || token.public !== void 0) {
      return invalidShape(
        `$.tokens.${path}.visibility`,
        "resolved-visibility-invalid"
      );
    }
  }
  for (const path of tokenPaths) {
    const token = owned.tokens[path];
    if (token.directDependencies.some(
      (dependency) => !tokenPathSet.has(dependency)
    )) {
      return invalidShape(
        `$.tokens.${path}.directDependencies`,
        "resolved-dependency-missing"
      );
    }
    if (!hasConsistentResolutionCausality(
      token,
      path,
      owned.tokens,
      owned.axes.selection
    )) {
      return invalidShape(
        `$.tokens.${path}.trace`,
        "resolved-trace-causality-invalid"
      );
    }
  }
  if (canonicalJsonStringify(publicPaths.sort(compareAscii)) !== canonicalJsonStringify(owned.publicSurface)) {
    return invalidShape("$.publicSurface", "resolved-public-surface-invalid");
  }
  const expectedHash = hashResolvedWithoutContentHash(owned);
  if (expectedHash !== owned.contentHash) {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: locator.value,
        themeId: owned.themeId,
        location: themeLocation(),
        details: {
          valueKind: "string",
          instancePath: "$.contentHash",
          issue: "content-hash-mismatch",
          expectedHash,
          receivedHash: owned.contentHash
        }
      })
    ]);
  }
  return ok(owned);
}
function serializeResolvedThemeWithRegistry(registry, input, inputLocation) {
  const locator = parseLogicalSourceLocator(
    inputLocation,
    "serializeResolvedTheme",
    "inputLocation"
  );
  if (!locator.ok) return locator;
  const validated = validateResolvedThemeWithRegistry(
    registry,
    input,
    inputLocation
  );
  if (!validated.ok) return validated;
  return ok(canonicalJsonBytes(validated.value));
}
function computeResolvedThemeHashWithRegistry(registry, input, inputLocation) {
  const locator = parseLogicalSourceLocator(
    inputLocation,
    "computeResolvedThemeHash",
    "inputLocation"
  );
  if (!locator.ok) return locator;
  const validated = validateResolvedThemeWithRegistry(
    registry,
    input,
    inputLocation
  );
  if (!validated.ok) return validated;
  return ok(validated.value.contentHash);
}
function reverseClosure(tokens, roots) {
  const reverse = /* @__PURE__ */ new Map();
  for (const [path, token] of Object.entries(tokens)) {
    const dependencies = token.directDependencies;
    for (const dependency of dependencies) {
      const consumers = reverse.get(dependency) ?? [];
      consumers.push(path);
      reverse.set(dependency, consumers);
    }
  }
  const closure = new Set(roots);
  const queue = [...roots];
  for (let index = 0; index < queue.length; index += 1) {
    for (const consumer of reverse.get(queue[index]) ?? []) {
      if (!closure.has(consumer)) {
        closure.add(consumer);
        queue.push(consumer);
      }
    }
  }
  return closure;
}
function resolveThemeDiffWithRegistry(_registry, from, fromLocation, to, toLocation) {
  const parsedFrom = parseLogicalSourceLocator(
    fromLocation,
    "resolveThemeDiff",
    "fromLocation"
  );
  const parsedTo = parseLogicalSourceLocator(
    toLocation,
    "resolveThemeDiff",
    "toLocation"
  );
  const locatorDiagnostics = [
    ...parsedFrom.ok ? [] : parsedFrom.diagnostics,
    ...parsedTo.ok ? [] : parsedTo.diagnostics
  ];
  if (locatorDiagnostics.length > 0) return failure(locatorDiagnostics);
  if (!parsedFrom.ok || !parsedTo.ok) return failure(locatorDiagnostics);
  const identityFields = [
    "sourceContentHash",
    "contractContentHash",
    "typeRegistryContentHash",
    "themeId",
    "contractVersion",
    "resolvedSchemaVersion"
  ];
  const mismatches = identityFields.filter((field) => from[field] !== to[field]).map((field) => ({
    field,
    fromValue: from[field],
    toValue: to[field]
  }));
  if (mismatches.length > 0) {
    return failure([
      createDiagnostic("TK_DIFF_SOURCE_MISMATCH", {
        source: parsedTo.value,
        themeId: to.themeId,
        location: themeLocation(),
        details: { mismatches }
      })
    ]);
  }
  const differingAxes = AXIS_ORDER$1.filter(
    (axis) => from.axes.selection[axis] !== to.axes.selection[axis]
  );
  if (differingAxes.length !== 1) {
    return failure([
      createDiagnostic("TK_DIFF_AXES_INVALID", {
        source: parsedTo.value,
        themeId: to.themeId,
        location: themeLocation(),
        details: { differingAxes, requiredDifferenceCount: 1 }
      })
    ]);
  }
  const changedAxis = differingAxes[0];
  const fromTokens = from.tokens;
  const toTokens = to.tokens;
  const directWrites = /* @__PURE__ */ new Set();
  for (const tokens of [fromTokens, toTokens]) {
    for (const token of Object.values(tokens)) {
      const transforms = token.appliedTransforms;
      if (transforms.some((transform2) => transform2.axis === changedAxis)) {
        directWrites.add(token.path);
      }
    }
  }
  const directWritePaths = [...directWrites].sort(compareAscii);
  const affected = /* @__PURE__ */ new Set([
    ...reverseClosure(fromTokens, directWritePaths),
    ...reverseClosure(toTokens, directWritePaths)
  ]);
  const allPaths = [
    .../* @__PURE__ */ new Set([...Object.keys(fromTokens), ...Object.keys(toTokens)])
  ].sort(compareAscii);
  const diagnostics = [];
  const valueChanges = [];
  for (const path of allPaths) {
    const left = fromTokens[path];
    const right = toTokens[path];
    const same = left && right && projectionsEqual(
      resolvedTokenSemanticProjection(left),
      resolvedTokenSemanticProjection(right)
    );
    if (!same && affected.has(path)) valueChanges.push(path);
    if (!same && !affected.has(path)) {
      const leftProjection = left ? resolvedTokenSemanticProjection(left) : void 0;
      const rightProjection = right ? resolvedTokenSemanticProjection(right) : void 0;
      const changedFields = [
        .../* @__PURE__ */ new Set([
          ...Object.keys(leftProjection ?? {}),
          ...Object.keys(rightProjection ?? {})
        ])
      ].filter(
        (field) => canonicalJsonStringify((leftProjection == null ? void 0 : leftProjection[field]) ?? null) !== canonicalJsonStringify((rightProjection == null ? void 0 : rightProjection[field]) ?? null)
      ).sort(compareAscii);
      diagnostics.push(
        createDiagnostic("TK_DIFF_OUTSIDE_CLOSURE", {
          source: parsedTo.value,
          themeId: to.themeId,
          location: tokenLocation(path),
          details: { path, changedFields },
          trace: [{ kind: "diff-projection", token: path, changedFields }]
        })
      );
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  return ok(
    snapshotCanonicalJson({
      sourceContentHash: from.sourceContentHash,
      contractContentHash: from.contractContentHash,
      typeRegistryContentHash: from.typeRegistryContentHash,
      fromHash: from.contentHash,
      toHash: to.contentHash,
      changedAxis,
      directWrites: directWritePaths,
      affectedClosure: [...affected].sort(compareAscii),
      valueChanges: valueChanges.sort(compareAscii)
    })
  );
}
const themeSeedGroups = Object.freeze([
  "brand",
  "neutral",
  "canvas",
  "glow",
  "tintBase",
  "material",
  "status",
  "typography",
  "metrics",
  "tone"
]);
const TINT_BASES = /* @__PURE__ */ new Set(["neutral", "brand", "glow"]);
const DEPTH_STYLES = /* @__PURE__ */ new Set(["shadow", "glow", "tonal"]);
const STATUS_KEYS = /* @__PURE__ */ new Set(["success", "warning", "danger", "info"]);
const METRIC_KEYS = /* @__PURE__ */ new Set([
  "spacingControlYPx",
  "radiusControlPx",
  "radiusSurfacePx",
  "motionDurationMs",
  "motionDurationFastMs"
]);
const TONE_KEYS = /* @__PURE__ */ new Set([
  "focusRingAlpha",
  "borderSubtleAlpha",
  "borderStrongAlpha",
  "borderDefaultAlpha",
  "hairlineAlpha",
  "fillHoverAlpha",
  "fillActiveAlpha",
  "accentSubtleAlpha"
]);
const FAMILY_NAME = /^[a-zA-Z0-9][a-zA-Z0-9 -]{0,63}$/;
function isUnitTuple(value) {
  return Array.isArray(value) && value.length === 3 && value.every(
    (entry) => typeof entry === "number" && entry >= 0 && entry <= 1
  );
}
function isRecord(value) {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}
function validateThemeSeedsV1(seeds) {
  if (!isRecord(seeds)) return "seeds-not-object";
  for (const key of Object.keys(seeds)) {
    if (!themeSeedGroups.includes(key))
      return `unknown-group:${key}`;
  }
  if (!isUnitTuple(seeds.brand)) return "brand-required";
  if (seeds.neutral !== void 0 && !isUnitTuple(seeds.neutral)) {
    return "neutral-invalid";
  }
  if (seeds.glow !== void 0 && !isUnitTuple(seeds.glow)) {
    return "glow-invalid";
  }
  if (seeds.canvas !== void 0) {
    if (!isRecord(seeds.canvas)) return "canvas-invalid";
    for (const [key, value] of Object.entries(seeds.canvas)) {
      if (key !== "dark" || !isUnitTuple(value)) return `canvas-invalid:${key}`;
    }
  }
  if (seeds.tintBase !== void 0 && (typeof seeds.tintBase !== "string" || !TINT_BASES.has(seeds.tintBase))) {
    return "tint-base-invalid";
  }
  if (seeds.material !== void 0) {
    if (!isRecord(seeds.material)) return "material-invalid";
    for (const [key, value] of Object.entries(seeds.material)) {
      if (key === "depthStyle") {
        if (typeof value !== "string" || !DEPTH_STYLES.has(value)) {
          return "material-invalid:depthStyle";
        }
      } else if (key === "glowIntensity") {
        if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 2) {
          return "material-invalid:glowIntensity";
        }
      } else {
        return `material-invalid:${key}`;
      }
    }
  }
  if (seeds.status !== void 0) {
    if (!isRecord(seeds.status)) return "status-invalid";
    for (const [key, value] of Object.entries(seeds.status)) {
      if (!STATUS_KEYS.has(key) || !isUnitTuple(value)) {
        return `status-invalid:${key}`;
      }
    }
  }
  if (seeds.typography !== void 0) {
    if (!isRecord(seeds.typography)) return "typography-invalid";
    const family = seeds.typography.family;
    if (family !== void 0 && (!Array.isArray(family) || family.length === 0 || family.length > 16 || !family.every(
      (entry) => typeof entry === "string" && FAMILY_NAME.test(entry)
    ))) {
      return "typography-family-invalid";
    }
    if (Object.keys(seeds.typography).some((key) => key !== "family")) {
      return "typography-invalid";
    }
  }
  for (const [group, keys, max] of [
    ["metrics", METRIC_KEYS, 1e4],
    ["tone", TONE_KEYS, 1]
  ]) {
    const record = seeds[group];
    if (record === void 0) continue;
    if (!isRecord(record)) return `${group}-invalid`;
    for (const [key, value] of Object.entries(record)) {
      if (group === "tone" && key === "dark") {
        if (!isRecord(value)) return "tone-invalid:dark";
        const darkKeys = /* @__PURE__ */ new Set([
          "borderSubtleAlpha",
          "borderStrongAlpha",
          "borderDefaultAlpha",
          "hairlineAlpha"
        ]);
        for (const [darkKey, alpha] of Object.entries(value)) {
          if (!darkKeys.has(darkKey) || typeof alpha !== "number" || !Number.isFinite(alpha) || alpha < 0 || alpha > 1)
            return `tone-invalid:dark.${darkKey}`;
        }
        continue;
      }
      if (!keys.has(key) || typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > max) {
        return `${group}-invalid:${key}`;
      }
    }
  }
  return null;
}
const THEME_DERIVATION_VERSION = "1.2.0";
function srgbToLinear(value) {
  return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
}
function linearToSrgb(value) {
  return value <= 31308e-7 ? value * 12.92 : 1.055 * value ** (1 / 2.4) - 0.055;
}
function rgbToOklch([r, g, b]) {
  const lr = srgbToLinear(r);
  const lg = srgbToLinear(g);
  const lb = srgbToLinear(b);
  const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
  const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
  const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
  const okL = 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s;
  const okA = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s;
  const okB = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
  return {
    l: okL,
    c: Math.hypot(okA, okB),
    h: Math.atan2(okB, okA)
  };
}
function oklchToRgb({ l: okL, c, h }) {
  const okA = c * Math.cos(h);
  const okB = c * Math.sin(h);
  const l = (okL + 0.3963377774 * okA + 0.2158037573 * okB) ** 3;
  const m = (okL - 0.1055613458 * okA - 0.0638541728 * okB) ** 3;
  const s = (okL - 0.0894841775 * okA - 1.291485548 * okB) ** 3;
  const lr = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
  const lg = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
  const lb = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;
  const clamp = (value) => Math.min(1, Math.max(0, value));
  const round = (value) => Math.round(value * 1e4) / 1e4;
  return [
    round(clamp(linearToSrgb(lr))),
    round(clamp(linearToSrgb(lg))),
    round(clamp(linearToSrgb(lb)))
  ];
}
function shift(seed, adjust) {
  return oklchToRgb(adjust(rgbToOklch(seed)));
}
function roundAlpha(value) {
  return Math.min(1, Math.max(0, Math.round(value * 1e4) / 1e4));
}
function color(rgb, alpha = 1) {
  return {
    colorSpace: "srgb",
    components: [rgb[0], rgb[1], rgb[2]],
    alpha
  };
}
function px(value) {
  return { kind: "value", value, unit: "px" };
}
function colorEntry(rgb, alpha = 1) {
  return {
    type: "color",
    value: { kind: "literal", value: color(rgb, alpha) }
  };
}
function dimensionEntry(value) {
  return {
    type: "dimension",
    value: { kind: "literal", value: px(value) }
  };
}
function durationEntry(value) {
  return {
    type: "duration",
    value: { kind: "literal", value: { value, unit: "ms" } }
  };
}
function numberEntry(value) {
  return {
    type: "number",
    value: { kind: "literal", value }
  };
}
function coloredShadowEntry(layers, rgb, alpha) {
  return {
    type: "shadow",
    value: {
      kind: "literal",
      value: layers.map(([offsetX, offsetY, blur, spread, inset]) => ({
        color: color(rgb, alpha),
        offsetX: px(offsetX),
        offsetY: px(offsetY),
        blur: px(blur),
        spread: px(spread),
        inset
      }))
    }
  };
}
function layeredShadowEntry(layers) {
  return {
    type: "shadow",
    value: {
      kind: "literal",
      value: layers.map(
        ([offsetX, offsetY, blur, spread, inset, rgb, alpha]) => ({
          color: color(rgb, roundAlpha(alpha)),
          offsetX: px(offsetX),
          offsetY: px(offsetY),
          blur: px(blur),
          spread: px(spread),
          inset
        })
      )
    }
  };
}
function gradientEntry(angle, stops) {
  return {
    type: "gradient",
    value: {
      kind: "literal",
      value: { angle, stops }
    }
  };
}
function sheenEntry(rgb, alpha, angle = 180, end = rgb) {
  return gradientEntry(angle, [
    { color: color(rgb, roundAlpha(alpha)), position: 0 },
    { color: color(end, 0), position: 1 }
  ]);
}
function transitionEntry(duration, delay = 0) {
  return {
    type: "transition",
    value: {
      kind: "literal",
      value: {
        duration: { value: duration, unit: "ms" },
        delay: { value: delay, unit: "ms" },
        timingFunction: [0.2, 0, 0, 1]
      }
    }
  };
}
function ref(path, expect) {
  return { type: expect, value: { $ref: path, expect } };
}
function colorRef(path) {
  return {
    type: "color",
    value: { $ref: path, expect: "color" }
  };
}
function refArg(path, expect) {
  return {
    kind: "ref",
    ref: { $ref: path, expect }
  };
}
function colorRefArg(path) {
  return refArg(path, "color");
}
function numberRefArg(path) {
  return refArg(path, "number");
}
function numberArg(value) {
  return { kind: "literal", type: "number", value };
}
function mixExpr(fromPath, toPath, ratio) {
  return {
    type: "color",
    value: {
      $expr: "color.mix@1",
      resultType: "color",
      args: [
        colorRefArg(fromPath),
        colorRefArg(toPath),
        typeof ratio === "number" ? numberArg(ratio) : numberRefArg(ratio.refPath)
      ]
    }
  };
}
function contrastTextExpr(fillPath) {
  return {
    type: "color",
    value: {
      $expr: "color.contrast-text@1",
      resultType: "color",
      args: [colorRefArg(fillPath)]
    }
  };
}
function strokeEntry(width, colorPath) {
  return {
    type: "border",
    value: {
      $expr: "border.compose@1",
      resultType: "border",
      args: [
        {
          kind: "literal",
          type: "dimension",
          value: px(width)
        },
        { kind: "literal", type: "string", value: "solid" },
        colorRefArg(colorPath)
      ]
    }
  };
}
function alphaExpr(path, alpha) {
  return {
    type: "color",
    value: {
      $expr: "color.alpha@1",
      resultType: "color",
      args: [colorRefArg(path), numberArg(alpha)]
    }
  };
}
function alphaRefExpr(path, alphaPath) {
  return {
    type: "color",
    value: {
      $expr: "color.alpha@1",
      resultType: "color",
      args: [colorRefArg(path), numberRefArg(alphaPath)]
    }
  };
}
function clamp01(value) {
  return Math.min(1, Math.max(0, value));
}
const GLOW_BLUR_PX = 48;
const GLOW_ALPHA = 0.3;
const GLOW_LIGHT_STRENGTH = 0.6;
function transform(path, expectType, value) {
  return { path, expectType, value };
}
function literalColorTransform(path, rgb, alpha = 1) {
  return transform(path, "color", {
    kind: "literal",
    value: color(rgb, alpha)
  });
}
function numberTransform(path, value) {
  return transform(path, "number", {
    kind: "literal",
    value
  });
}
function coloredShadowTransform(path, layers, rgb, alpha) {
  return transform(path, "shadow", coloredShadowEntry(layers, rgb, alpha).value);
}
function gradientTransform(path, angle, stops) {
  return transform(path, "gradient", gradientEntry(angle, stops).value);
}
function entryTransform(path, entry) {
  return transform(path, entry.type, entry.value);
}
function transitionTransform(path, duration) {
  return transform(path, "transition", transitionEntry(duration).value);
}
function durationTransform(path, value) {
  return transform(path, "duration", {
    kind: "literal",
    value: { value, unit: "ms" }
  });
}
function mergeTransforms(derived, refined) {
  if (!refined) return derived;
  const replaced = new Set(
    refined.map((entry) => entry.path ?? "")
  );
  return [...derived.filter((entry) => !replaced.has(entry.path)), ...refined];
}
const AXIS_ORDER = ["mode", "density", "contrast", "motion", "radius"];
const REFERENCE = {
  surfacePage: [0.95, 0.96, 0.98],
  surfaceElevated: [1, 1, 1],
  surfaceBase: [1, 1, 1],
  textPrimary: [0.12, 0.14, 0.18],
  textSecondary: [0.35, 0.38, 0.43],
  tint: [1, 1, 1],
  darkSurfacePage: [0.055, 0.065, 0.085],
  darkSurfaceElevated: [0.105, 0.12, 0.15],
  darkSurfaceBase: [0.08, 0.09, 0.115],
  darkTextPrimary: [0.93, 0.95, 0.98],
  darkTextSecondary: [0.67, 0.71, 0.78],
  darkTint: [0.078, 0.078, 0.078],
  success: [0.404, 0.761, 0.227],
  warning: [0.902, 0.635, 0.235],
  danger: [0.86, 0.25, 0.24],
  info: [0.565, 0.576, 0.6],
  darkDanger: [0.95, 0.45, 0.44],
  focusHighContrast: [0, 0.35, 1],
  focusForcedColors: [1, 0.85, 0],
  fontFamily: [
    "Helvetica Neue",
    "Helvetica",
    "PingFang SC",
    "Hiragino Sans GB",
    "Microsoft YaHei",
    "Arial",
    "sans-serif"
  ]
};
const RAMP = [
  ["tint-3", "mix.tint", 0.3],
  ["tint-5", "mix.tint", 0.5],
  ["tint-7", "mix.tint", 0.7],
  ["tint-8", "mix.tint", 0.8],
  ["tint-9", "mix.tint", 0.9],
  ["shade-2", "mix.shade", 0.2]
];
function derivePalette(seeds) {
  var _a;
  const brand = seeds.brand;
  const neutral = seeds.neutral;
  const canvasDark = (_a = seeds.canvas) == null ? void 0 : _a.dark;
  const light = neutral ? {
    surfacePage: neutral,
    surfaceElevated: shift(neutral, (value) => ({
      ...value,
      l: Math.min(1, value.l + 0.035),
      c: value.c * 0.5
    })),
    surfaceBase: shift(neutral, (value) => ({
      ...value,
      l: Math.min(1, value.l + 0.04),
      c: value.c * 0.35
    })),
    textPrimary: shift(neutral, (value) => ({
      ...value,
      l: 0.24,
      c: Math.min(value.c, 0.02)
    })),
    textSecondary: shift(neutral, (value) => ({
      ...value,
      l: 0.45,
      c: Math.min(value.c, 0.02)
    })),
    tint: shift(neutral, (value) => ({
      ...value,
      l: 0.99,
      c: value.c * 0.3
    }))
  } : {
    surfacePage: REFERENCE.surfacePage,
    surfaceElevated: REFERENCE.surfaceElevated,
    surfaceBase: REFERENCE.surfaceBase,
    textPrimary: REFERENCE.textPrimary,
    textSecondary: REFERENCE.textSecondary,
    tint: REFERENCE.tint
  };
  const dark = canvasDark ? {
    darkSurfacePage: canvasDark,
    darkSurfaceElevated: shift(canvasDark, (value) => ({
      ...value,
      l: Math.min(1, value.l + 0.06)
    })),
    darkSurfaceBase: shift(canvasDark, (value) => ({
      ...value,
      l: Math.min(1, value.l + 0.035)
    })),
    darkTextPrimary: shift(canvasDark, (value) => ({
      ...value,
      l: 0.96,
      c: Math.min(value.c, 0.02)
    })),
    darkTextSecondary: shift(canvasDark, (value) => ({
      ...value,
      l: 0.8,
      c: Math.min(value.c, 0.035)
    })),
    darkTint: shift(canvasDark, (value) => ({
      ...value,
      l: Math.max(0, value.l - 0.01)
    }))
  } : neutral ? {
    darkSurfacePage: shift(neutral, (value) => ({
      ...value,
      l: 0.17,
      c: Math.min(value.c * 0.6, 0.02)
    })),
    darkSurfaceElevated: shift(neutral, (value) => ({
      ...value,
      l: 0.24,
      c: Math.min(value.c * 0.6, 0.02)
    })),
    darkSurfaceBase: shift(neutral, (value) => ({
      ...value,
      l: 0.21,
      c: Math.min(value.c * 0.6, 0.02)
    })),
    darkTextPrimary: shift(neutral, (value) => ({
      ...value,
      l: 0.95,
      c: Math.min(value.c, 0.01)
    })),
    darkTextSecondary: shift(neutral, (value) => ({
      ...value,
      l: 0.75,
      c: Math.min(value.c, 0.015)
    })),
    darkTint: shift(neutral, (value) => ({
      ...value,
      l: 0.16,
      c: Math.min(value.c * 0.5, 0.015)
    }))
  } : {
    darkSurfacePage: REFERENCE.darkSurfacePage,
    darkSurfaceElevated: REFERENCE.darkSurfaceElevated,
    darkSurfaceBase: REFERENCE.darkSurfaceBase,
    darkTextPrimary: REFERENCE.darkTextPrimary,
    darkTextSecondary: REFERENCE.darkTextSecondary,
    darkTint: REFERENCE.darkTint
  };
  return {
    ...light,
    ...dark,
    focusHighContrast: neutral ? shift(brand, (value) => ({
      ...value,
      l: value.l * 0.8,
      c: value.c * 1.2
    })) : REFERENCE.focusHighContrast
  };
}
function isLiteralFacet(value) {
  return "light" in value && "dark" in value && "high" in value;
}
function deriveThemeSourceV4(seeds, meta, refine = {}) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _A, _B, _C, _D, _E, _F, _G, _H, _I, _J, _K, _L, _M, _N, _O, _P, _Q, _R, _S, _T, _U;
  const issue = validateThemeSeedsV1(seeds);
  if (issue) throw new TypeError(`invalid theme seeds: ${issue}`);
  const brand = seeds.brand;
  const glow = seeds.glow ?? brand;
  const tintBase = seeds.tintBase ?? "neutral";
  const depthStyle = ((_a = seeds.material) == null ? void 0 : _a.depthStyle) ?? "shadow";
  const glowStyle = depthStyle === "glow";
  const k = Math.min(2, Math.max(0, ((_b = seeds.material) == null ? void 0 : _b.glowIntensity) ?? 1));
  const palette = derivePalette(seeds);
  const success = ((_c = seeds.status) == null ? void 0 : _c.success) ?? REFERENCE.success;
  const warning = ((_d = seeds.status) == null ? void 0 : _d.warning) ?? REFERENCE.warning;
  const danger = ((_e = seeds.status) == null ? void 0 : _e.danger) ?? REFERENCE.danger;
  const info = ((_f = seeds.status) == null ? void 0 : _f.info) ?? REFERENCE.info;
  const darkDanger = ((_g = seeds.status) == null ? void 0 : _g.danger) ? shift(seeds.status.danger, (value) => ({
    ...value,
    l: Math.min(1, value.l + 0.12),
    c: value.c * 0.95
  })) : REFERENCE.darkDanger;
  const metrics = {
    spacingControlYPx: ((_h = seeds.metrics) == null ? void 0 : _h.spacingControlYPx) ?? 8,
    radiusControlPx: ((_i = seeds.metrics) == null ? void 0 : _i.radiusControlPx) ?? 6,
    radiusSurfacePx: ((_j = seeds.metrics) == null ? void 0 : _j.radiusSurfacePx) ?? 10,
    motionDurationMs: ((_k = seeds.metrics) == null ? void 0 : _k.motionDurationMs) ?? 180,
    motionDurationFastMs: ((_l = seeds.metrics) == null ? void 0 : _l.motionDurationFastMs) ?? 120
  };
  const tone = {
    focusRingAlpha: ((_m = seeds.tone) == null ? void 0 : _m.focusRingAlpha) ?? 0.72,
    borderSubtleAlpha: ((_n = seeds.tone) == null ? void 0 : _n.borderSubtleAlpha) ?? 0.1,
    borderStrongAlpha: ((_o = seeds.tone) == null ? void 0 : _o.borderStrongAlpha) ?? 0.2,
    borderDefaultAlpha: ((_p = seeds.tone) == null ? void 0 : _p.borderDefaultAlpha) ?? 0.36,
    hairlineAlpha: ((_q = seeds.tone) == null ? void 0 : _q.hairlineAlpha) ?? 0.5,
    fillHoverAlpha: ((_r = seeds.tone) == null ? void 0 : _r.fillHoverAlpha) ?? 0.06,
    fillActiveAlpha: ((_s = seeds.tone) == null ? void 0 : _s.fillActiveAlpha) ?? 0.1,
    accentSubtleAlpha: ((_t = seeds.tone) == null ? void 0 : _t.accentSubtleAlpha) ?? 0.12,
    dark: {
      borderSubtleAlpha: ((_v = (_u = seeds.tone) == null ? void 0 : _u.dark) == null ? void 0 : _v.borderSubtleAlpha) ?? 0.22,
      borderStrongAlpha: ((_x = (_w = seeds.tone) == null ? void 0 : _w.dark) == null ? void 0 : _x.borderStrongAlpha) ?? 0.42,
      borderDefaultAlpha: ((_z = (_y = seeds.tone) == null ? void 0 : _y.dark) == null ? void 0 : _z.borderDefaultAlpha) ?? 0.55,
      hairlineAlpha: ((_B = (_A = seeds.tone) == null ? void 0 : _A.dark) == null ? void 0 : _B.hairlineAlpha) ?? (glowStyle ? 0.55 : 0.9)
    }
  };
  const family = ((_C = seeds.typography) == null ? void 0 : _C.family) ?? REFERENCE.fontFamily;
  const tintBaseLight = tintBase === "brand" ? brand : tintBase === "glow" ? glow : palette.textPrimary;
  const tintBaseDark = tintBase === "neutral" ? palette.darkTextPrimary : tintBaseLight;
  const elevatedLightness = rgbToOklch(palette.surfaceElevated).l;
  const darkElevatedLightness = rgbToOklch(palette.darkSurfaceElevated).l;
  const glowTintLight = glowStyle ? shift(glow, (value) => ({
    ...value,
    l: clamp01(elevatedLightness - 0.1),
    c: Math.min(value.c * 0.6, 0.12)
  })) : shift(palette.surfaceElevated, (value) => ({
    ...value,
    l: clamp01(value.l - 0.06)
  }));
  const glowTintDark = glowStyle ? shift(glow, (value) => ({
    ...value,
    l: clamp01(darkElevatedLightness + 0.18),
    c: Math.min(value.c * 0.6, 0.12)
  })) : shift(palette.darkSurfaceElevated, (value) => ({
    ...value,
    l: clamp01(value.l + 0.25)
  }));
  const foundation = {
    "surface.page": colorEntry(palette.surfacePage),
    "surface.elevated": colorEntry(palette.surfaceElevated),
    "text.primary": colorEntry(palette.textPrimary),
    "text.secondary": colorEntry(palette.textSecondary),
    "action.focus-ring": colorEntry(brand),
    "spacing.control-y": dimensionEntry(metrics.spacingControlYPx),
    "radius.control": dimensionEntry(metrics.radiusControlPx),
    "motion.duration": durationEntry(metrics.motionDurationMs),
    "status.danger": colorEntry(danger),
    "radius.surface": dimensionEntry(metrics.radiusSurfacePx),
    "status.success": colorEntry(success),
    "status.warning": colorEntry(warning),
    "status.info": colorEntry(info),
    "mix.tint": colorEntry(palette.tint),
    "mix.shade": colorEntry([0, 0, 0]),
    "surface.body": colorEntry(palette.surfaceBase),
    "overlay.base": colorEntry([0, 0, 0]),
    "mask.base": colorEntry(palette.tint),
    "elevation.tint-weight.raised": numberEntry(0.02),
    "elevation.tint-weight.overlay": numberEntry(0.05),
    "elevation.tint-weight.blocking": numberEntry(0.09),
    "material.glow": glowStyle ? colorEntry(glow, roundAlpha(0.12 * k)) : colorEntry(brand, 0),
    "material.glow-tint": colorEntry(glowTintLight),
    "elevation.hairline": glowStyle ? colorEntry(glow, tone.hairlineAlpha) : colorEntry([0, 0, 0], 0.8),
    "tone.border-subtle-alpha": numberEntry(tone.borderSubtleAlpha),
    "tone.border-strong-alpha": numberEntry(tone.borderStrongAlpha),
    "tone.border-default-alpha": numberEntry(tone.borderDefaultAlpha),
    "elevation.hairline-weight": numberEntry(0.14),
    "motion.duration-fast": durationEntry(metrics.motionDurationFastMs),
    "typography.family": {
      type: "font-family",
      value: { kind: "literal", value: [...family] }
    },
    "typography.size-extra-small": dimensionEntry(12),
    "typography.size-small": dimensionEntry(13),
    "typography.size-base": dimensionEntry(14),
    "typography.size-medium": dimensionEntry(16),
    "typography.size-large": dimensionEntry(18),
    "typography.size-extra-large": dimensionEntry(20),
    "typography.weight-primary": {
      type: "font-weight",
      value: { kind: "literal", value: 500 }
    },
    "typography.line-height-base": dimensionEntry(24),
    "material.tint-base": tintBase === "neutral" ? colorRef("foundation.text.primary") : colorEntry(tintBaseLight),
    ...refine.foundation
  };
  const semantic = {
    "surface.page": colorRef("foundation.surface.page"),
    "surface.elevated": mixExpr(
      "foundation.surface.page",
      "foundation.surface.elevated",
      0.82
    ),
    "text.primary": colorRef("foundation.text.primary"),
    "text.secondary": colorRef("foundation.text.secondary"),
    "action.focus-ring": alphaExpr(
      "foundation.action.focus-ring",
      tone.focusRingAlpha
    ),
    "spacing.control-y": ref("foundation.spacing.control-y", "dimension"),
    "radius.control": ref("foundation.radius.control", "dimension"),
    "motion.duration": ref("foundation.motion.duration", "duration"),
    "border.subtle": alphaRefExpr(
      "foundation.material.tint-base",
      "foundation.tone.border-subtle-alpha"
    ),
    "border.strong": alphaRefExpr(
      "foundation.material.tint-base",
      "foundation.tone.border-strong-alpha"
    ),
    "fill.hover": alphaExpr(
      "foundation.material.tint-base",
      tone.fillHoverAlpha
    ),
    "fill.active": alphaExpr(
      "foundation.material.tint-base",
      tone.fillActiveAlpha
    ),
    "accent.base": colorRef("foundation.action.focus-ring"),
    "accent.subtle": alphaExpr(
      "foundation.action.focus-ring",
      tone.accentSubtleAlpha
    ),
    "status.danger": colorRef("foundation.status.danger"),
    "radius.surface": ref("foundation.radius.surface", "dimension"),
    "status.success": colorRef("foundation.status.success"),
    "status.warning": colorRef("foundation.status.warning"),
    "status.info": colorRef("foundation.status.info"),
    "surface.body": colorRef("foundation.surface.body"),
    "text.disabled": mixExpr(
      "foundation.surface.elevated",
      "foundation.text.primary",
      0.34
    ),
    "motion.duration-fast": ref("foundation.motion.duration-fast", "duration"),
    "overlay.modal": alphaExpr("foundation.overlay.base", 0.8),
    "overlay.mask": alphaExpr("foundation.mask.base", 0.9),
    "typography.family": ref("foundation.typography.family", "font-family"),
    "typography.size-extra-small": ref(
      "foundation.typography.size-extra-small",
      "dimension"
    ),
    "typography.size-small": ref(
      "foundation.typography.size-small",
      "dimension"
    ),
    "typography.size-base": ref("foundation.typography.size-base", "dimension"),
    "typography.size-medium": ref(
      "foundation.typography.size-medium",
      "dimension"
    ),
    "typography.size-large": ref(
      "foundation.typography.size-large",
      "dimension"
    ),
    "typography.size-extra-large": ref(
      "foundation.typography.size-extra-large",
      "dimension"
    ),
    "typography.weight-primary": ref(
      "foundation.typography.weight-primary",
      "font-weight"
    ),
    "typography.line-height-base": ref(
      "foundation.typography.line-height-base",
      "dimension"
    )
  };
  for (const [step, target, ratio] of RAMP) {
    semantic[`accent.${step}`] = mixExpr(
      "foundation.action.focus-ring",
      `foundation.${target}`,
      ratio
    );
    for (const familyName of ["success", "warning", "info", "danger"]) {
      semantic[`status.${familyName}-${step}`] = mixExpr(
        `foundation.status.${familyName}`,
        `foundation.${target}`,
        ratio
      );
    }
  }
  semantic["elevation.flat.shadow"] = coloredShadowEntry(
    [[0, 0, 0, 0, false]],
    [0, 0, 0],
    0
  );
  semantic["elevation.raised.shadow"] = coloredShadowEntry(
    [[0, 4, 12, 0, false]],
    [0, 0, 0],
    0.18
  );
  semantic["elevation.overlay.shadow"] = coloredShadowEntry(
    [[0, 6, 18, 0, false]],
    [0, 0, 0],
    0.18
  );
  semantic["elevation.blocking.shadow"] = coloredShadowEntry(
    [[0, 12, 32, 0, false]],
    [0, 0, 0],
    0.18
  );
  semantic["elevation.flat.surface"] = colorRef("semantic.surface.page");
  for (const role of ["raised", "overlay", "blocking"]) {
    semantic[`elevation.${role}.surface`] = mixExpr(
      "semantic.surface.elevated",
      "foundation.material.glow-tint",
      { refPath: `foundation.elevation.tint-weight.${role}` }
    );
  }
  for (const role of ["flat", "raised", "overlay", "blocking"]) {
    semantic[`elevation.${role}.border`] = mixExpr(
      `semantic.elevation.${role}.surface`,
      "foundation.elevation.hairline",
      { refPath: "foundation.elevation.hairline-weight" }
    );
  }
  const brandShadowGeometry = {
    raised: [0, 4, 12],
    overlay: [0, 6, 18],
    blocking: [0, 12, 32]
  };
  const brandShadowAlpha = {
    light: { raised: 0.28, overlay: 0.34, blocking: 0.4 },
    dark: { raised: 0.52, overlay: 0.58, blocking: 0.64 }
  };
  const brandShadow = (role, mode) => {
    const [x, y, blur] = brandShadowGeometry[role];
    return coloredShadowEntry(
      [[x, y, blur, 0, false]],
      brand,
      roundAlpha(brandShadowAlpha[mode][role] * k)
    );
  };
  Object.assign(semantic, {
    "fill.subtle": alphaExpr("foundation.material.tint-base", 0.07),
    "fill.accent-hover": alphaExpr("foundation.action.focus-ring", 0.07),
    "fill.selected": alphaExpr("foundation.action.focus-ring", 0.11),
    "fill.selected-hover": alphaExpr("foundation.action.focus-ring", 0.16),
    "fill.accent-active": alphaExpr("foundation.action.focus-ring", 0.18),
    "fill.status-subtle": alphaExpr("foundation.status.danger", 0.1),
    "fill.scrollbar-thumb": alphaExpr("foundation.text.secondary", 0.38),
    "fill.scrollbar-thumb-hover": alphaExpr("foundation.text.secondary", 0.56),
    "fill.scrollbar-track": alphaExpr("foundation.text.secondary", 0.16),
    "fill.current-tint": numberEntry(12),
    "border.default": alphaRefExpr(
      "foundation.material.tint-base",
      "foundation.tone.border-default-alpha"
    ),
    "border.control": alphaExpr("foundation.text.secondary", 0.7),
    "border.current-tint": numberEntry(32),
    "stroke.subtle": strokeEntry(1, "semantic.border.subtle"),
    "stroke.default": strokeEntry(1, "semantic.border.default"),
    "stroke.strong": strokeEntry(1, "semantic.border.strong"),
    "stroke.focus": strokeEntry(2, "semantic.action.focus-ring"),
    "stroke.focus-inline": strokeEntry(1, "semantic.action.focus-ring"),
    ...Object.fromEntries(
      [
        "accent",
        "status.success",
        "status.warning",
        "status.danger",
        "status.info"
      ].flatMap((role) => {
        const separator = role === "accent" ? "." : "-";
        const fill = role === "accent" ? "accent.base" : role;
        const path = (facet) => `${role}${separator}${facet}`;
        return [
          [
            path("on-surface"),
            mixExpr("foundation.text.primary", `semantic.${fill}`, 0.3)
          ],
          [path("on-fill"), contrastTextExpr(`semantic.${fill}`)],
          [
            path("on-fill-hover"),
            contrastTextExpr(`semantic.${path("tint-3")}`)
          ],
          [
            path("on-fill-active"),
            contrastTextExpr(`semantic.${path("shade-2")}`)
          ]
        ];
      })
    ),
    "material.tonal-tint": colorRef("foundation.material.glow"),
    "material.tonal-gradient": glowStyle ? sheenEntry(glowTintLight, 0.1 * k * GLOW_LIGHT_STRENGTH) : gradientEntry(180, [{ color: color(brand, 0), position: 0 }]),
    "material.brand-shadow.raised": glowStyle ? brandShadow("raised", "light") : ref("semantic.elevation.raised.shadow", "shadow"),
    "material.brand-shadow.overlay": glowStyle ? brandShadow("overlay", "light") : ref("semantic.elevation.overlay.shadow", "shadow"),
    "material.brand-shadow.blocking": glowStyle ? brandShadow("blocking", "light") : ref("semantic.elevation.blocking.shadow", "shadow"),
    // Overlays (tooltips, popovers, menus) are small: a third of the container
    // blur keeps the haze at the edge instead of flooding the whole surface.
    "material.inner-glow": glowStyle ? layeredShadowEntry([
      [
        0,
        0,
        GLOW_BLUR_PX / 3,
        0,
        true,
        glow,
        GLOW_ALPHA * k * GLOW_LIGHT_STRENGTH
      ]
    ]) : coloredShadowEntry([[0, 0, 0, 0, true]], brand, 0),
    "material.inner-stroke": coloredShadowEntry(
      [[0, 0, 0, 1, true]],
      palette.textPrimary,
      0.12
    ),
    "material.inner-stroke-accent": coloredShadowEntry(
      [[0, 0, 0, 1, true]],
      brand,
      0.28
    ),
    "material.inner-stroke-danger": coloredShadowEntry(
      [[0, 0, 0, 1, true]],
      danger,
      0.32
    ),
    "material.focus-ring": coloredShadowEntry(
      [[0, 0, 0, 2, false]],
      brand,
      tone.focusRingAlpha
    ),
    "material.cutout-ring": coloredShadowEntry(
      [[0, 0, 0, 2, false]],
      palette.surfaceBase,
      1
    ),
    "material.focus-ring-transition": transitionEntry(
      metrics.motionDurationFastMs
    )
  });
  const zeroInset = coloredShadowEntry([[0, 0, 0, 0, true]], brand, 0);
  const clearHighlight = gradientEntry(180, [
    { color: color(brand, 0), position: 0 },
    { color: color(brand, 0), position: 1 }
  ]);
  const highDepth = coloredShadowEntry([[0, 4, 12, 0, false]], [0, 0, 0], 0.3);
  const glowInset = (layers, strength) => layeredShadowEntry(
    layers.map(
      ([blur, spread, alpha]) => [0, 0, blur, spread, true, glow, alpha * k * strength]
    )
  );
  const glowInsetFacet = (layers) => ({
    light: glowInset(layers, GLOW_LIGHT_STRENGTH),
    dark: glowInset(layers, 1),
    high: zeroInset
  });
  const glowSheenFacet = (alpha, angle = 180, end = glow) => ({
    light: sheenEntry(glow, alpha * k * GLOW_LIGHT_STRENGTH, angle, end),
    dark: sheenEntry(glow, alpha * k, angle, end),
    high: clearHighlight
  });
  const tintSheenFacet = (alpha) => ({
    light: sheenEntry(glowTintLight, alpha * k * GLOW_LIGHT_STRENGTH),
    dark: sheenEntry(glowTintDark, alpha * k),
    high: clearHighlight
  });
  const tonalSheenFacet = (alpha) => ({
    light: sheenEntry(tintBaseLight, alpha * 0.6),
    dark: sheenEntry(tintBaseDark, alpha),
    high: clearHighlight
  });
  const brandSheenFacet = {
    light: sheenEntry([1, 1, 1], 0.18, 135),
    dark: sheenEntry([1, 1, 1], 0.12, 135),
    high: clearHighlight
  };
  const flatDepth = ref("semantic.elevation.flat.shadow", "shadow");
  const surfaceFill = {
    canvas: colorRef("semantic.surface.page"),
    panel: colorRef("semantic.surface.body"),
    card: colorRef("semantic.elevation.raised.surface"),
    field: colorRef("semantic.surface.elevated"),
    header: mixExpr(
      "semantic.surface.elevated",
      "foundation.material.tint-base",
      0.07
    ),
    overlay: colorRef("semantic.elevation.overlay.surface"),
    blocking: colorRef("semantic.elevation.blocking.surface"),
    selected: colorRef("semantic.fill.selected"),
    brand: colorRef("semantic.accent.base")
  };
  const surfaceEdge = {
    // The canvas has no visible edge; a zero-width stroke keeps the facet
    // set uniform for consumers that bind all seven facets.
    canvas: strokeEntry(0, "semantic.border.subtle"),
    panel: strokeEntry(1, "semantic.border.subtle"),
    card: strokeEntry(1, "semantic.elevation.raised.border"),
    field: strokeEntry(1, "semantic.border.strong"),
    header: strokeEntry(1, "semantic.border.subtle"),
    overlay: strokeEntry(1, "semantic.elevation.overlay.border"),
    blocking: strokeEntry(1, "semantic.elevation.blocking.border"),
    selected: strokeEntry(1, "semantic.accent.base"),
    brand: strokeEntry(1, "semantic.accent.shade-2")
  };
  const surfaceDepth = {
    canvas: flatDepth,
    panel: flatDepth,
    card: ref("semantic.elevation.raised.shadow", "shadow"),
    field: flatDepth,
    header: flatDepth,
    // Overlays are small and carry popper arrows, so their glow is an outer
    // halo on the depth facet while the body stays flat; an arrow drawn in the
    // same fill then joins the body seamlessly.
    overlay: glowStyle ? {
      light: layeredShadowEntry([
        [0, 6, 18, 0, false, [0, 0, 0], 0.18],
        [
          0,
          0,
          GLOW_BLUR_PX / 3,
          0,
          false,
          glow,
          GLOW_ALPHA * k * GLOW_LIGHT_STRENGTH
        ]
      ]),
      dark: layeredShadowEntry([
        [0, 6, 18, 0, false, [0, 0, 0], 0.55],
        [0, 0, GLOW_BLUR_PX / 3, 0, false, glow, GLOW_ALPHA * k]
      ]),
      high: coloredShadowEntry([[0, 6, 18, 0, false]], [0, 0, 0], 0.3)
    } : ref("semantic.elevation.overlay.shadow", "shadow"),
    blocking: ref("semantic.elevation.blocking.shadow", "shadow"),
    selected: flatDepth,
    brand: glowStyle ? {
      light: layeredShadowEntry([
        [0, 4, 12, 0, false, brand, 0.28 * k],
        [0, 0, 10, 0, false, brand, 0.27 * k]
      ]),
      dark: layeredShadowEntry([
        [0, 4, 12, 0, false, brand, 0.52 * k],
        [0, 0, 10, 0, false, brand, 0.45 * k]
      ]),
      high: highDepth
    } : ref("semantic.material.brand-shadow.raised", "shadow")
  };
  const surfaceInner = glowStyle ? {
    canvas: zeroInset,
    panel: glowInsetFacet([[GLOW_BLUR_PX / 2, 0, 0.14]]),
    card: glowInsetFacet([[GLOW_BLUR_PX, 0, 0.26]]),
    // Text-entry surfaces keep a one-pixel ring at the border alpha
    // so the field edge stays legible, plus a short haze inside it.
    field: {
      light: layeredShadowEntry([
        [0, 0, 0, 1, true, glow, tone.borderStrongAlpha],
        [
          0,
          0,
          GLOW_BLUR_PX / 3,
          0,
          true,
          glow,
          GLOW_ALPHA * k * GLOW_LIGHT_STRENGTH
        ]
      ]),
      dark: layeredShadowEntry([
        [0, 0, 0, 1, true, glow, tone.dark.borderStrongAlpha],
        [0, 0, GLOW_BLUR_PX / 3, 0, true, glow, GLOW_ALPHA * k]
      ]),
      high: coloredShadowEntry(
        [[0, 0, 0, 1, true]],
        [0.5, 0.5, 0.5],
        0.9
      )
    },
    header: glowInsetFacet([[GLOW_BLUR_PX / 4, 0, 0.16]]),
    overlay: zeroInset,
    blocking: glowInsetFacet([[GLOW_BLUR_PX * 1.2, 0, GLOW_ALPHA]]),
    selected: glowInsetFacet([[20, 0, 0.35]]),
    brand: zeroInset
  } : {
    canvas: zeroInset,
    panel: zeroInset,
    card: zeroInset,
    field: ref("semantic.material.inner-stroke", "shadow"),
    header: zeroInset,
    overlay: zeroInset,
    blocking: zeroInset,
    selected: ref("semantic.material.inner-stroke-accent", "shadow"),
    brand: zeroInset
  };
  const surfaceHighlight = glowStyle ? {
    canvas: clearHighlight,
    panel: clearHighlight,
    card: tintSheenFacet(0.08),
    field: clearHighlight,
    header: tintSheenFacet(0.05),
    overlay: clearHighlight,
    blocking: tintSheenFacet(0.06),
    selected: clearHighlight,
    brand: glowSheenFacet(0.25, 135, brand)
  } : depthStyle === "tonal" ? {
    canvas: clearHighlight,
    panel: tonalSheenFacet(0.1),
    card: tonalSheenFacet(0.16),
    field: clearHighlight,
    header: tonalSheenFacet(0.1),
    overlay: clearHighlight,
    blocking: tonalSheenFacet(0.14),
    selected: clearHighlight,
    brand: brandSheenFacet
  } : {
    canvas: clearHighlight,
    panel: clearHighlight,
    card: clearHighlight,
    field: clearHighlight,
    header: clearHighlight,
    overlay: clearHighlight,
    blocking: clearHighlight,
    selected: clearHighlight,
    brand: brandSheenFacet
  };
  const surfaceOnText = {
    canvas: colorRef("semantic.text.primary"),
    panel: colorRef("semantic.text.primary"),
    card: colorRef("semantic.text.primary"),
    field: colorRef("semantic.text.primary"),
    header: colorRef("semantic.text.primary"),
    overlay: colorRef("semantic.text.primary"),
    blocking: colorRef("semantic.text.primary"),
    selected: colorRef("semantic.text.primary"),
    brand: colorRef("semantic.accent.on-fill")
  };
  const surfaceOnTextSecondary = {
    canvas: colorRef("semantic.text.secondary"),
    panel: colorRef("semantic.text.secondary"),
    card: colorRef("semantic.text.secondary"),
    field: colorRef("semantic.text.secondary"),
    header: colorRef("semantic.text.secondary"),
    overlay: colorRef("semantic.text.secondary"),
    blocking: colorRef("semantic.text.secondary"),
    selected: colorRef("semantic.text.secondary"),
    brand: colorRef("semantic.accent.on-fill")
  };
  const surfaceDarkTransforms = [];
  const surfaceHighTransforms = [];
  for (const role of THEME_SURFACE_ROLES) {
    const facets = {
      fill: surfaceFill[role],
      edge: surfaceEdge[role],
      depth: surfaceDepth[role],
      inner: surfaceInner[role],
      highlight: surfaceHighlight[role],
      "on-text": surfaceOnText[role],
      "on-text-secondary": surfaceOnTextSecondary[role]
    };
    for (const facet of THEME_SURFACE_FACETS) {
      const spec = facets[facet];
      const key = `surface.${role}.${facet}`;
      if (!isLiteralFacet(spec)) {
        semantic[key] = spec;
        continue;
      }
      semantic[key] = spec.light;
      const path = `semantic.${key}`;
      const light = JSON.stringify(spec.light);
      const dark = JSON.stringify(spec.dark);
      const high = JSON.stringify(spec.high);
      if (dark !== light) {
        surfaceDarkTransforms.push(entryTransform(path, spec.dark));
      }
      if (high !== light || high !== dark) {
        surfaceHighTransforms.push(entryTransform(path, spec.high));
      }
    }
  }
  Object.assign(semantic, refine.semantic);
  const components = {
    button: {
      background: colorRef("semantic.surface.elevated"),
      "label-color": colorRef("semantic.text.primary"),
      "focus-ring": colorRef("semantic.action.focus-ring"),
      "padding-y": ref("semantic.spacing.control-y", "dimension"),
      radius: ref("semantic.radius.control", "dimension"),
      "motion-duration": ref("semantic.motion.duration", "duration")
    },
    panel: {
      background: colorRef("semantic.surface.page"),
      "label-color": colorRef("semantic.text.secondary")
    },
    ...refine.components
  };
  const darkTransforms = [
    literalColorTransform("foundation.surface.page", palette.darkSurfacePage),
    literalColorTransform(
      "foundation.surface.elevated",
      palette.darkSurfaceElevated
    ),
    literalColorTransform("foundation.text.primary", palette.darkTextPrimary),
    literalColorTransform(
      "foundation.text.secondary",
      palette.darkTextSecondary
    ),
    literalColorTransform("foundation.status.danger", darkDanger),
    literalColorTransform("foundation.mix.tint", palette.darkTint),
    literalColorTransform("foundation.mix.shade", [1, 1, 1]),
    literalColorTransform("foundation.surface.body", palette.darkSurfaceBase),
    literalColorTransform("foundation.mask.base", palette.darkTint),
    numberTransform("foundation.elevation.tint-weight.raised", 0.04),
    numberTransform("foundation.elevation.tint-weight.overlay", 0.08),
    numberTransform("foundation.elevation.tint-weight.blocking", 0.14),
    glowStyle ? literalColorTransform(
      "foundation.material.glow",
      glow,
      roundAlpha(0.14 * k)
    ) : literalColorTransform("foundation.material.glow", brand, 0),
    literalColorTransform("foundation.material.glow-tint", glowTintDark),
    glowStyle ? literalColorTransform(
      "foundation.elevation.hairline",
      glow,
      tone.dark.hairlineAlpha
    ) : literalColorTransform(
      "foundation.elevation.hairline",
      [1, 1, 1],
      tone.dark.hairlineAlpha
    ),
    numberTransform("foundation.elevation.hairline-weight", 0.24),
    numberTransform(
      "foundation.tone.border-subtle-alpha",
      tone.dark.borderSubtleAlpha
    ),
    numberTransform(
      "foundation.tone.border-strong-alpha",
      tone.dark.borderStrongAlpha
    ),
    numberTransform(
      "foundation.tone.border-default-alpha",
      tone.dark.borderDefaultAlpha
    ),
    coloredShadowTransform(
      "semantic.elevation.raised.shadow",
      [[0, 4, 12, 0, false]],
      [0, 0, 0],
      0.55
    ),
    coloredShadowTransform(
      "semantic.elevation.overlay.shadow",
      [[0, 6, 18, 0, false]],
      [0, 0, 0],
      0.55
    ),
    coloredShadowTransform(
      "semantic.elevation.blocking.shadow",
      [[0, 12, 32, 0, false]],
      [0, 0, 0],
      0.55
    ),
    glowStyle ? entryTransform(
      "semantic.material.inner-glow",
      layeredShadowEntry([
        [0, 0, GLOW_BLUR_PX / 3, 0, true, glow, GLOW_ALPHA * k]
      ])
    ) : coloredShadowTransform(
      "semantic.material.inner-glow",
      [[0, 0, 0, 0, true]],
      brand,
      0
    ),
    coloredShadowTransform(
      "semantic.material.inner-stroke",
      [[0, 0, 0, 1, true]],
      palette.darkTextPrimary,
      0.18
    ),
    coloredShadowTransform(
      "semantic.material.inner-stroke-accent",
      [[0, 0, 0, 1, true]],
      brand,
      0.4
    ),
    coloredShadowTransform(
      "semantic.material.inner-stroke-danger",
      [[0, 0, 0, 1, true]],
      darkDanger,
      0.42
    ),
    coloredShadowTransform(
      "semantic.material.focus-ring",
      [[0, 0, 0, 2, false]],
      brand,
      0.85
    ),
    coloredShadowTransform(
      "semantic.material.cutout-ring",
      [[0, 0, 0, 2, false]],
      palette.darkSurfaceBase,
      1
    ),
    ...glowStyle ? [
      entryTransform(
        "semantic.material.tonal-gradient",
        sheenEntry(glowTintDark, 0.1 * k)
      ),
      entryTransform(
        "semantic.material.brand-shadow.raised",
        brandShadow("raised", "dark")
      ),
      entryTransform(
        "semantic.material.brand-shadow.overlay",
        brandShadow("overlay", "dark")
      ),
      entryTransform(
        "semantic.material.brand-shadow.blocking",
        brandShadow("blocking", "dark")
      )
    ] : [],
    ...surfaceDarkTransforms
  ];
  const highContrastTransforms = [
    literalColorTransform(
      "foundation.action.focus-ring",
      palette.focusHighContrast
    ),
    numberTransform("foundation.elevation.tint-weight.raised", 0),
    numberTransform("foundation.elevation.tint-weight.overlay", 0),
    numberTransform("foundation.elevation.tint-weight.blocking", 0),
    literalColorTransform("foundation.material.glow", brand, 0),
    literalColorTransform("foundation.elevation.hairline", [0, 0, 0], 1),
    numberTransform("foundation.elevation.hairline-weight", 0.3),
    coloredShadowTransform(
      "semantic.elevation.raised.shadow",
      [[0, 4, 12, 0, false]],
      [0, 0, 0],
      0.3
    ),
    coloredShadowTransform(
      "semantic.elevation.overlay.shadow",
      [[0, 6, 18, 0, false]],
      [0, 0, 0],
      0.3
    ),
    coloredShadowTransform(
      "semantic.elevation.blocking.shadow",
      [[0, 12, 32, 0, false]],
      [0, 0, 0],
      0.3
    ),
    coloredShadowTransform(
      "semantic.material.inner-glow",
      [[0, 0, 0, 0, true]],
      brand,
      0
    ),
    gradientTransform("semantic.material.tonal-gradient", 180, [
      { color: color(brand, 0), position: 0 }
    ]),
    coloredShadowTransform(
      "semantic.material.focus-ring",
      [[0, 0, 0, 2, false]],
      palette.focusHighContrast,
      1
    ),
    ...glowStyle ? [
      coloredShadowTransform(
        "semantic.material.brand-shadow.raised",
        [[0, 4, 12, 0, false]],
        [0, 0, 0],
        0.3
      ),
      coloredShadowTransform(
        "semantic.material.brand-shadow.overlay",
        [[0, 6, 18, 0, false]],
        [0, 0, 0],
        0.3
      ),
      coloredShadowTransform(
        "semantic.material.brand-shadow.blocking",
        [[0, 12, 32, 0, false]],
        [0, 0, 0],
        0.3
      )
    ] : [],
    ...surfaceHighTransforms
  ];
  const transforms = {
    mode: {
      dark: mergeTransforms(darkTransforms, (_E = (_D = refine.transforms) == null ? void 0 : _D.mode) == null ? void 0 : _E.dark)
    },
    density: {
      compact: mergeTransforms(
        [
          transform("foundation.spacing.control-y", "dimension", {
            kind: "literal",
            value: px(metrics.spacingControlYPx - 2)
          })
        ],
        (_G = (_F = refine.transforms) == null ? void 0 : _F.density) == null ? void 0 : _G.compact
      ),
      comfortable: mergeTransforms(
        [
          transform("foundation.spacing.control-y", "dimension", {
            kind: "literal",
            value: px(metrics.spacingControlYPx + 2)
          })
        ],
        (_I = (_H = refine.transforms) == null ? void 0 : _H.density) == null ? void 0 : _I.comfortable
      )
    },
    contrast: {
      high: mergeTransforms(
        highContrastTransforms,
        (_K = (_J = refine.transforms) == null ? void 0 : _J.contrast) == null ? void 0 : _K.high
      ),
      "forced-colors": mergeTransforms(
        [
          literalColorTransform(
            "foundation.action.focus-ring",
            REFERENCE.focusForcedColors
          )
        ],
        (_M = (_L = refine.transforms) == null ? void 0 : _L.contrast) == null ? void 0 : _M["forced-colors"]
      )
    },
    motion: {
      reduced: mergeTransforms(
        [
          durationTransform("foundation.motion.duration", 80),
          durationTransform("foundation.motion.duration-fast", 60),
          transitionTransform("semantic.material.focus-ring-transition", 60)
        ],
        (_O = (_N = refine.transforms) == null ? void 0 : _N.motion) == null ? void 0 : _O.reduced
      ),
      none: mergeTransforms(
        [
          durationTransform("foundation.motion.duration", 0),
          durationTransform("foundation.motion.duration-fast", 0),
          transitionTransform("semantic.material.focus-ring-transition", 0)
        ],
        (_Q = (_P = refine.transforms) == null ? void 0 : _P.motion) == null ? void 0 : _Q.none
      )
    },
    radius: {
      sharp: mergeTransforms(
        [
          transform("foundation.radius.control", "dimension", {
            kind: "literal",
            value: px(0)
          }),
          transform("foundation.radius.surface", "dimension", {
            kind: "literal",
            value: px(0)
          })
        ],
        (_S = (_R = refine.transforms) == null ? void 0 : _R.radius) == null ? void 0 : _S.sharp
      ),
      rounded: mergeTransforms(
        [
          transform("foundation.radius.control", "dimension", {
            kind: "literal",
            value: px(14)
          }),
          transform("foundation.radius.surface", "dimension", {
            kind: "literal",
            value: px(16)
          })
        ],
        (_U = (_T = refine.transforms) == null ? void 0 : _T.radius) == null ? void 0 : _U.rounded
      )
    }
  };
  const writersByPath = /* @__PURE__ */ new Map();
  for (const axis of AXIS_ORDER) {
    for (const entries of Object.values(transforms[axis])) {
      for (const entry of entries) {
        const path = entry.path;
        if (!path) continue;
        const writers = writersByPath.get(path) ?? /* @__PURE__ */ new Set();
        writers.add(axis);
        writersByPath.set(path, writers);
      }
    }
  }
  const conflictPolicy = Object.fromEntries(
    [...writersByPath].filter(([, writers]) => writers.size > 1).sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0).map(([path, writers]) => [
      path,
      {
        writers: AXIS_ORDER.filter((axis) => writers.has(axis)),
        resolution: "fixed-axis-order",
        rationale: "Contrast is applied after mode so accessibility emphasis deterministically wins when both axes write this material fact."
      }
    ])
  );
  return {
    meta: {
      themeId: meta.themeId,
      name: meta.name,
      schemaVersion: 4,
      contractVersion: "4.0.0"
    },
    axes: {
      mode: { supported: ["light", "dark"], default: "light" },
      density: {
        supported: ["compact", "default", "comfortable"],
        default: "default"
      },
      contrast: {
        supported: ["normal", "high", "forced-colors"],
        default: "normal"
      },
      motion: { supported: ["full", "reduced", "none"], default: "full" },
      radius: {
        supported: ["sharp", "default", "rounded"],
        default: "default"
      }
    },
    foundation,
    semantic,
    components,
    transforms,
    conflictPolicy
  };
}
function buildKernel(registry) {
  const kernel = {
    registeredTypeIds: registry.registeredTypeIds,
    typeRegistryContentHash: registry.typeRegistryContentHash,
    validateTokenLiteral: (input) => validateTokenLiteralWithRegistry(registry, input),
    defineTheme: (source, input) => defineThemeObject(registry, source, input, "defineTheme"),
    defineThemeContract: (source, input) => defineThemeContractObject(registry, source, input, "defineThemeContract"),
    validateThemeSource: (input) => validateThemeSourceObject(
      registry,
      input.sourceLocation,
      input.source,
      "validateThemeSource"
    ),
    validateThemeContract: (input) => validateThemeContractObject(
      registry,
      input.contractLocation,
      input.contract,
      "validateThemeContract"
    ),
    resolveTheme: (input) => resolveThemeWithRegistry(registry, input),
    resolveThemeDiff: (from, fromLocation, to, toLocation) => resolveThemeDiffWithRegistry(
      registry,
      from,
      fromLocation,
      to,
      toLocation
    ),
    validateResolvedTheme: (input, inputLocation) => validateResolvedThemeWithRegistry(registry, input, inputLocation),
    serializeResolvedTheme: (input, inputLocation) => serializeResolvedThemeWithRegistry(registry, input, inputLocation),
    computeResolvedThemeHash: (input, inputLocation) => computeResolvedThemeHashWithRegistry(registry, input, inputLocation)
  };
  return Object.freeze(kernel);
}
const builtInRegistry = createBuiltInTypeRegistry();
const themeKernel = buildKernel(builtInRegistry);
const canonicalThemeContractV4 = createDefaultCanonicalContract(
  builtInRegistry,
  canonicalThemeContractV4Input
);
function defineThemeV4(source, input) {
  return defineThemeObject(builtInRegistry, source, input, "defineThemeV4");
}
function defineThemeContractV4(source, input) {
  return defineThemeContractObject(
    builtInRegistry,
    source,
    input,
    "defineThemeContractV4"
  );
}
function validateThemeSource(input) {
  return themeKernel.validateThemeSource(input);
}
function validateThemeContract(input) {
  return themeKernel.validateThemeContract(input);
}
function resolveTheme(input) {
  return themeKernel.resolveTheme(input);
}
function resolveThemeDiff(from, fromLocation, to, toLocation) {
  return themeKernel.resolveThemeDiff(from, fromLocation, to, toLocation);
}
function validateResolvedTheme(input, inputLocation) {
  return themeKernel.validateResolvedTheme(input, inputLocation);
}
function serializeResolvedTheme(input, inputLocation) {
  return themeKernel.serializeResolvedTheme(input, inputLocation);
}
function computeResolvedThemeHash(input, inputLocation) {
  return themeKernel.computeResolvedThemeHash(input, inputLocation);
}
function createThemeKernel(source, options) {
  if (source === void 0 && options === void 0) return themeKernel;
  if (!source || !options) {
    return {
      ok: false,
      diagnosticSchemaVersion: 1,
      diagnostics: []
    };
  }
  const locatorResult = parseLogicalSourceLocator(
    source,
    "createThemeKernel",
    "source"
  );
  if (!locatorResult.ok) return locatorResult;
  const registry = createTypeRegistry(
    locatorResult.value,
    options.extensionTypes
  );
  if (!registry.ok) return registry;
  return {
    ok: true,
    diagnosticSchemaVersion: 1,
    value: buildKernel(registry.value)
  };
}
const validateTokenLiteral = (input) => themeKernel.validateTokenLiteral(input);
export {
  THEME_DERIVATION_VERSION,
  THEME_SURFACE_FACETS,
  THEME_SURFACE_ROLES,
  canonicalThemeContractV4,
  computeResolvedThemeHash,
  createThemeKernel,
  defineThemeContractV4,
  defineThemeV4,
  deriveThemeSourceV4,
  resolveTheme,
  resolveThemeDiff,
  serializeResolvedTheme,
  themeKernel,
  themeSeedGroups,
  validateResolvedTheme,
  validateThemeContract,
  validateThemeSeedsV1,
  validateThemeSource,
  validateTokenLiteral
};
