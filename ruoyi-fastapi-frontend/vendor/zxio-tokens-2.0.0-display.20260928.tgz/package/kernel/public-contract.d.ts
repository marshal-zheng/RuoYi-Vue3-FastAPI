import { KernelResult } from './diagnostics';
import { ResolvedGraph } from './graph';
import { AuthorLogicalSourceLocator, AuthorPublicContractEntry, BuiltInTypeMap, CanonicalTokenPath, ThemeContractAuthorInput, ThemeTypeMap, ValidatedThemePublicContractV4 } from './model';
import { LogicalSourceEntrypoint } from './source-schema';
import { TypeRegistry } from './token-types';
export declare function isStrictSemVer(input: unknown): input is `${number}.${number}.${number}`;
export declare const NAMING_DISCIPLINE_CONSTRAINED_SEMANTIC_FAMILIES: readonly ["action", "border", "elevation", "fill", "material", "overlay", "stroke", "surface", "text"];
export declare const NAMING_DISCIPLINE_EXEMPT_SEMANTIC_FAMILIES: readonly ["accent", "motion", "radius", "spacing", "status", "typography"];
export declare const NAMING_DISCIPLINE_FORBIDDEN_SUFFIXES: readonly ["base", "dark", "darker", "extra-light", "light", "lighter"];
export interface SemanticNamingDisciplineViolation {
    readonly path: string;
    readonly reason: 'forbidden-suffix' | 'unclassified-family';
}
export declare function validateSemanticNamingDiscipline(entries: Readonly<Record<string, unknown>>): readonly SemanticNamingDisciplineViolation[];
export declare function isValidPublicAdmissionRationale(path: string, rationale: unknown): boolean;
export declare function isValidPublicMigration(input: unknown): boolean;
export declare function validateThemeContractObject<M extends ThemeTypeMap>(registry: TypeRegistry<M>, source: AuthorLogicalSourceLocator, input: unknown, entrypoint?: LogicalSourceEntrypoint): KernelResult<ValidatedThemePublicContractV4<M>>;
export declare function defineThemeContractObject<M extends ThemeTypeMap>(registry: TypeRegistry<M>, source: AuthorLogicalSourceLocator, input: ThemeContractAuthorInput<M>, entrypoint?: LogicalSourceEntrypoint): KernelResult<ValidatedThemePublicContractV4<M>>;
export interface ContractAppliedToken {
    readonly path: CanonicalTokenPath;
    readonly layer: 'foundation' | 'semantic' | 'components';
    readonly component?: string;
    readonly typeId: string;
    readonly value: unknown;
    readonly source: unknown;
    readonly directDependencies: readonly CanonicalTokenPath[];
    readonly trace: readonly unknown[];
    readonly appliedTransforms: readonly unknown[];
    readonly visibility: 'internal' | 'public';
    readonly public?: AuthorPublicContractEntry<ThemeTypeMap, CanonicalTokenPath, never>;
}
export declare function applyPublicContract<M extends ThemeTypeMap>(graph: ResolvedGraph, contract: ValidatedThemePublicContractV4<M>, themeId: string): KernelResult<Readonly<Record<CanonicalTokenPath, Record<string, unknown>>>>;
export type ContractSemanticReviewField = 'description' | 'owner' | 'source' | 'rationale.kind' | 'rationale.evidence';
type ContractEvidenceBase = {
    readonly path: CanonicalTokenPath;
    readonly release: `${number}.${number}.${number}`;
    readonly reason: string;
    readonly evidence: readonly [string, ...string[]];
};
export type ContractReleaseEvidence = ContractEvidenceBase & ({
    readonly from: 'experimental';
    readonly to: 'absent' | 'stable' | 'experimental' | 'deprecated';
} | {
    readonly from: 'deprecated';
    readonly to: 'stable';
} | {
    readonly from: 'stable' | 'deprecated';
    readonly to: 'stable' | 'deprecated';
    readonly changedFields: readonly [
        ContractSemanticReviewField,
        ...ContractSemanticReviewField[]
    ];
});
export declare function isValidContractReleaseEvidence(input: unknown): input is readonly ContractReleaseEvidence[];
export declare function comparePublicContractBaseline(baseline: unknown, next: ValidatedThemePublicContractV4, releaseEvidence?: readonly ContractReleaseEvidence[]): KernelResult<true>;
export declare function createDefaultCanonicalContract(registry: TypeRegistry<BuiltInTypeMap>, input: ThemeContractAuthorInput<BuiltInTypeMap>): ValidatedThemePublicContractV4<BuiltInTypeMap>;
export {};
