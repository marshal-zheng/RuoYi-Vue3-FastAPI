export type ThemeTypeMap = object;
export type TokenTypeId<M extends ThemeTypeMap> = Extract<keyof M, string>;
export type CanonicalJsonValue = null | boolean | string | number | readonly CanonicalJsonValue[] | {
    readonly [key: string]: CanonicalJsonValue;
};
type SnapshotPrimitive = null | undefined | string | number | boolean | bigint | symbol;
export type DeepReadonly<T> = T extends SnapshotPrimitive ? T : T extends (...args: infer Args) => unknown ? (...args: Args) => unknown : T extends readonly unknown[] ? {
    readonly [K in keyof T]: DeepReadonly<T[K]>;
} : T extends object ? {
    readonly [K in keyof T]: DeepReadonly<T[K]>;
} : T;
type IsAny<T> = 0 extends 1 & T ? true : false;
type IsBroadObject<T> = [T] extends [object] ? [keyof T] extends [never] ? true : false : false;
type TypeExactlyEqual<Left, Right> = (<T>() => T extends Left ? 1 : 2) extends <T>() => T extends Right ? 1 : 2 ? (<T>() => T extends Right ? 1 : 2) extends <T>() => T extends Left ? 1 : 2 ? true : false : false;
type SeenIncludes<Value, Seen extends readonly unknown[]> = Seen extends readonly [infer Head, ...infer Tail] ? TypeExactlyEqual<Value, Head> extends true ? true : SeenIncludes<Value, Tail> : false;
type IsCanonicalUmbrella<T> = TypeExactlyEqual<T, CanonicalJsonValue> extends true ? true : TypeExactlyEqual<T, Readonly<Record<string, CanonicalJsonValue>>> extends true ? true : false;
type CustomArrayKeys<T> = Exclude<keyof T, keyof (readonly unknown[])>;
type BroadIndexValues<T> = (string extends keyof T ? T extends Readonly<Record<string, infer Value>> ? Value : never : never) | (number extends keyof T ? T extends Readonly<Record<number, infer Value>> ? Value : never : never);
type ContainsAny<T, Seen extends readonly unknown[] = readonly [], Depth extends readonly unknown[] = readonly []> = IsAny<T> extends true ? true : [T] extends [never] ? false : IsCanonicalUmbrella<T> extends true ? false : Depth['length'] extends 16 ? true : true extends ContainsAnyMember<T, Seen, Depth> ? true : false;
type ContainsAnyMember<T, Seen extends readonly unknown[], Depth extends readonly unknown[]> = T extends unknown ? IsAny<T> extends true ? true : SeenIncludes<T, Seen> extends true ? false : T extends (...args: never[]) => unknown ? false : T extends readonly (infer Item)[] ? true extends ContainsAny<Item, readonly [T, ...Seen], readonly [unknown, ...Depth]> ? true : [CustomArrayKeys<T>] extends [never] ? false : true extends {
    [K in CustomArrayKeys<T>]-?: ContainsAny<T[K], readonly [T, ...Seen], readonly [unknown, ...Depth]>;
}[CustomArrayKeys<T>] ? true : false : T extends object ? [BroadIndexValues<T>] extends [never] ? true extends {
    [K in keyof T]-?: ContainsAny<T[K], readonly [T, ...Seen], readonly [unknown, ...Depth]>;
}[keyof T] ? true : false : true extends ContainsAny<BroadIndexValues<T>, readonly [T, ...Seen], readonly [unknown, ...Depth]> ? true : true extends {
    [K in keyof T]-?: ContainsAny<T[K], readonly [T, ...Seen], readonly [unknown, ...Depth]>;
}[keyof T] ? true : false : false : false;
export type JsonShapeCompatible<T> = ContainsAny<T> extends true ? false : JsonShapeCompatibleNoAny<T>;
type JsonShapeCompatibleNoAny<T, Seen extends readonly unknown[] = readonly [], Depth extends readonly unknown[] = readonly []> = [T] extends [never] ? false : IsCanonicalUmbrella<T> extends true ? true : Depth['length'] extends 16 ? false : false extends JsonShapeCompatibleMember<T, Seen, Depth> ? false : true;
type JsonShapeCompatibleMember<T, Seen extends readonly unknown[], Depth extends readonly unknown[]> = T extends unknown ? IsBroadObject<T> extends true ? false : T extends null | boolean | string | number ? true : T extends readonly (infer Item)[] ? SeenIncludes<T, Seen> extends true ? true : [Extract<CustomArrayKeys<T>, symbol>] extends [never] ? false extends JsonShapeCompatibleNoAny<Item, readonly [T, ...Seen], readonly [unknown, ...Depth]> ? false : [CustomArrayKeys<T>] extends [never] ? true : false extends {
    [K in CustomArrayKeys<T>]-?: JsonShapeCompatibleNoAny<T[K], readonly [T, ...Seen], readonly [unknown, ...Depth]>;
}[CustomArrayKeys<T>] ? false : true : false : T extends (...args: never[]) => unknown ? false : T extends object ? SeenIncludes<T, Seen> extends true ? true : [Extract<keyof T, symbol>] extends [never] ? [BroadIndexValues<T>] extends [never] ? false extends {
    [K in keyof T]-?: JsonShapeCompatibleNoAny<T[K], readonly [T, ...Seen], readonly [unknown, ...Depth]>;
}[keyof T] ? false : true : false extends JsonShapeCompatibleNoAny<BroadIndexValues<T>, readonly [T, ...Seen], readonly [unknown, ...Depth]> ? false : false extends {
    [K in keyof T]-?: JsonShapeCompatibleNoAny<T[K], readonly [T, ...Seen], readonly [unknown, ...Depth]>;
}[keyof T] ? false : true : false : false : false;
export type AssertJsonShapeCompatibleTypeMap<M extends ThemeTypeMap> = {
    readonly [K in keyof M]: JsonShapeCompatible<M[K]> extends true ? M[K] : never;
};
export type CanonicalDimension = {
    readonly kind: 'value';
    readonly value: number;
    readonly unit: DimensionUnit;
} | {
    readonly kind: 'calc';
    readonly op: 'add' | 'subtract';
    readonly args: readonly [CanonicalDimension, CanonicalDimension];
} | {
    readonly kind: 'calc';
    readonly op: 'multiply';
    readonly args: readonly [CanonicalDimension, number];
};
export type DimensionUnit = 'px' | 'rem' | 'em' | '%' | 'vw' | 'vh' | 'vmin' | 'vmax' | 'ch' | 'lh' | 'rlh';
export type CanonicalColor = Readonly<{
    colorSpace: 'srgb' | 'display-p3' | 'oklch';
    components: readonly [number, number, number];
    alpha: number;
}>;
export interface CanonicalGradientStop {
    readonly color: CanonicalColor;
    readonly position: number;
}
export interface CanonicalGradient {
    readonly angle: number;
    readonly stops: readonly CanonicalGradientStop[];
}
export type CanonicalStrokeStyle = 'solid' | 'dashed' | 'dotted' | 'double' | 'groove' | 'ridge' | 'outset' | 'inset' | Readonly<{
    dashArray: readonly CanonicalDimension[];
    lineCap: 'butt' | 'round' | 'square';
}>;
export interface CanonicalTransition {
    readonly duration: Readonly<{
        value: number;
        unit: 'ms';
    }>;
    readonly delay: Readonly<{
        value: number;
        unit: 'ms';
    }>;
    readonly timingFunction: readonly [number, number, number, number];
}
export interface CanonicalShadowLayer {
    readonly color: CanonicalColor;
    readonly offsetX: CanonicalDimension;
    readonly offsetY: CanonicalDimension;
    readonly blur: CanonicalDimension;
    readonly spread: CanonicalDimension;
    readonly inset: boolean;
}
export interface CanonicalBorder {
    readonly width: CanonicalDimension;
    readonly style: 'none' | 'solid' | 'dashed' | 'dotted' | 'double';
    readonly color: CanonicalColor;
}
export interface CanonicalTypography {
    readonly fontFamily: readonly string[];
    readonly fontSize: CanonicalDimension;
    readonly fontWeight: number;
    readonly lineHeight: number | CanonicalDimension;
    readonly letterSpacing: CanonicalDimension;
}
export interface BuiltInTypeMap {
    readonly color: CanonicalColor;
    readonly dimension: CanonicalDimension;
    readonly number: number;
    readonly duration: Readonly<{
        value: number;
        unit: 'ms';
    }>;
    readonly 'cubic-bezier': readonly [number, number, number, number];
    readonly 'font-family': readonly string[];
    readonly 'font-weight': number;
    readonly gradient: CanonicalGradient;
    readonly shadow: readonly CanonicalShadowLayer[];
    readonly strokeStyle: CanonicalStrokeStyle;
    readonly transition: CanonicalTransition;
    readonly border: CanonicalBorder;
    readonly typography: CanonicalTypography;
    readonly string: string;
}
export type BuiltInTypeId = keyof BuiltInTypeMap;
export interface AuthorLogicalSourceLocator {
    readonly file: string;
    readonly line?: number;
    readonly column?: number;
}
declare const logicalSourceLocatorBrand: unique symbol;
export type LogicalSourceLocator = DeepReadonly<AuthorLogicalSourceLocator> & {
    readonly [logicalSourceLocatorBrand]: true;
};
export type AuthorCanonicalTokenPath = `foundation.${string}` | `semantic.${string}` | `components.${string}.${string}`;
declare const canonicalTokenPathBrand: unique symbol;
export type CanonicalTokenPath = AuthorCanonicalTokenPath & {
    readonly [canonicalTokenPathBrand]: true;
};
export interface ThemeAxisDomains {
    readonly mode: 'light' | 'dark';
    readonly density: 'compact' | 'default' | 'comfortable';
    readonly contrast: 'normal' | 'high' | 'forced-colors';
    readonly motion: 'full' | 'reduced' | 'none';
    readonly radius: 'sharp' | 'default' | 'rounded';
}
export type ThemeAxisName = keyof ThemeAxisDomains;
export type AxisOrder = readonly [
    'mode',
    'density',
    'contrast',
    'motion',
    'radius'
];
export type ThemeAxisSelection = {
    readonly [K in ThemeAxisName]: ThemeAxisDomains[K];
};
export type ThemeAxisDeclarations = {
    readonly [K in ThemeAxisName]: Readonly<{
        supported: readonly ThemeAxisDomains[K][];
        default: ThemeAxisDomains[K];
    }>;
};
export type BuiltInFieldProjection = 'color.alpha' | 'color.components.0' | 'color.components.1' | 'color.components.2' | 'border.width' | 'border.style' | 'border.color' | 'typography.fontFamily' | 'typography.fontSize' | 'typography.fontWeight' | 'typography.lineHeight' | 'typography.letterSpacing';
export type AuthorTokenAlias<M extends ThemeTypeMap, Result extends TokenTypeId<M>> = Readonly<{
    $ref: AuthorCanonicalTokenPath;
    expect: Result;
    targetType?: never;
    field?: never;
}> | Readonly<{
    $ref: AuthorCanonicalTokenPath;
    expect: Result;
    targetType: TokenTypeId<M>;
    field: BuiltInFieldProjection;
}>;
export interface OperatorSignatureMap {
    readonly 'number.add@1': readonly [
        {
            readonly args: readonly ['number', 'number'];
            readonly result: 'number';
        }
    ];
    readonly 'number.multiply@1': readonly [
        {
            readonly args: readonly ['number', 'number'];
            readonly result: 'number';
        }
    ];
    readonly 'number.clamp@1': readonly [
        {
            readonly args: readonly ['number', 'number', 'number'];
            readonly result: 'number';
        }
    ];
    readonly 'dimension.add@1': readonly [
        {
            readonly args: readonly ['dimension', 'dimension'];
            readonly result: 'dimension';
        }
    ];
    readonly 'dimension.subtract@1': readonly [
        {
            readonly args: readonly ['dimension', 'dimension'];
            readonly result: 'dimension';
        }
    ];
    readonly 'dimension.multiply@1': readonly [
        {
            readonly args: readonly ['dimension', 'number'];
            readonly result: 'dimension';
        }
    ];
    readonly 'color.mix@1': readonly [
        {
            readonly args: readonly ['color', 'color', 'number'];
            readonly result: 'color';
        }
    ];
    readonly 'color.alpha@1': readonly [
        {
            readonly args: readonly ['color', 'number'];
            readonly result: 'color';
        }
    ];
    readonly 'color.contrast-text@1': readonly [
        {
            readonly args: readonly ['color'];
            readonly result: 'color';
        }
    ];
    readonly 'shadow.stack@1': readonly [
        {
            readonly args: readonly ['shadow', 'shadow'];
            readonly result: 'shadow';
        }
    ];
    readonly 'border.compose@1': readonly [
        {
            readonly args: readonly ['dimension', 'string', 'color'];
            readonly result: 'border';
        }
    ];
    readonly 'typography.compose@1': readonly [
        {
            readonly args: readonly [
                'font-family',
                'dimension',
                'font-weight',
                'number',
                'dimension'
            ];
            readonly result: 'typography';
        },
        {
            readonly args: readonly [
                'font-family',
                'dimension',
                'font-weight',
                'dimension',
                'dimension'
            ];
            readonly result: 'typography';
        }
    ];
}
export type OperatorId = keyof OperatorSignatureMap;
type ExpressionSignature = OperatorSignatureMap[OperatorId][number];
export type AuthorExpressionOperand<M extends ThemeTypeMap, TypeId extends TokenTypeId<M> = TokenTypeId<M>> = Readonly<{
    kind: 'literal';
    type: TypeId;
    value: M[TypeId];
}> | Readonly<{
    kind: 'ref';
    ref: AuthorTokenAlias<M, TypeId>;
}> | Readonly<{
    kind: 'expr';
    expr: AuthorThemeExpression<M, TypeId>;
}>;
type ExpressionArgs<M extends ThemeTypeMap, Args extends readonly BuiltInTypeId[]> = {
    readonly [I in keyof Args]: Args[I] extends TokenTypeId<M> ? AuthorExpressionOperand<M, Args[I]> : never;
};
type AuthorOperatorExpression<M extends ThemeTypeMap, Operator extends OperatorId, Signature extends ExpressionSignature, Result extends TokenTypeId<M>> = Signature['result'] extends Result ? Readonly<{
    $expr: Operator;
    resultType: Signature['result'];
    args: ExpressionArgs<M, Signature['args']>;
}> : never;
export type AuthorThemeExpression<M extends ThemeTypeMap, Result extends TokenTypeId<M>> = {
    [Operator in OperatorId]: OperatorSignatureMap[Operator][number] extends infer Signature extends ExpressionSignature ? AuthorOperatorExpression<M, Operator, Signature, Result> : never;
}[OperatorId];
export type AuthorTokenValue<M extends ThemeTypeMap, K extends TokenTypeId<M>> = Readonly<{
    kind: 'literal';
    value: M[K];
}> | AuthorTokenAlias<M, K> | AuthorThemeExpression<M, K>;
export type AuthorTokenDefinition<M extends ThemeTypeMap, K extends TokenTypeId<M>> = Readonly<{
    type: K;
    value: AuthorTokenValue<M, K>;
    source?: AuthorLogicalSourceLocator;
}>;
export type AnyAuthorTokenDefinition<M extends ThemeTypeMap> = {
    [K in TokenTypeId<M>]: AuthorTokenDefinition<M, K>;
}[TokenTypeId<M>];
export type AuthorTokenRecord<M extends ThemeTypeMap> = Readonly<Record<string, AnyAuthorTokenDefinition<M>>>;
export type AuthorTokenTransform<M extends ThemeTypeMap> = {
    [K in TokenTypeId<M>]: Readonly<{
        path: AuthorCanonicalTokenPath;
        expectType: K;
        value: AuthorTokenValue<M, K>;
        source?: AuthorLogicalSourceLocator;
    }>;
}[TokenTypeId<M>];
export type AuthorThemeTransforms<M extends ThemeTypeMap> = {
    readonly [K in ThemeAxisName]: Partial<Record<ThemeAxisDomains[K], readonly AuthorTokenTransform<M>[]>>;
};
export interface AxisConflictPolicy {
    readonly writers: readonly [ThemeAxisName, ThemeAxisName, ...ThemeAxisName[]];
    readonly resolution: 'fixed-axis-order';
    readonly rationale: string;
}
export interface ThemeSourceAuthorInput<M extends ThemeTypeMap = BuiltInTypeMap> {
    readonly meta: Readonly<{
        themeId: string;
        name: string;
        schemaVersion: 4;
        contractVersion: '4.0.0';
    }>;
    readonly axes: ThemeAxisDeclarations;
    readonly foundation: AuthorTokenRecord<M>;
    readonly semantic: AuthorTokenRecord<M>;
    readonly components: Readonly<Record<string, AuthorTokenRecord<M>>>;
    readonly transforms: AuthorThemeTransforms<M>;
    readonly conflictPolicy?: Readonly<Record<string, AxisConflictPolicy>>;
}
export type ThemeSourceV4<M extends ThemeTypeMap = BuiltInTypeMap> = ThemeSourceAuthorInput<M> & Readonly<{
    meta: ThemeSourceAuthorInput<M>['meta'] & {
        readonly source: LogicalSourceLocator;
    };
}>;
declare const validatedThemeSourceBrand: unique symbol;
export type ValidatedThemeSourceV4<M extends ThemeTypeMap = BuiltInTypeMap> = DeepReadonly<ThemeSourceV4<M>> & {
    readonly [validatedThemeSourceBrand]: true;
};
export type PublicLifecycle = 'stable' | 'experimental' | 'deprecated';
export type AuthorPublicAdmissionRationale<P extends AuthorCanonicalTokenPath> = P extends `foundation.${string}` ? Readonly<{
    kind: 'foundation-authoring';
    crossThemeAuthoringUseCase: string;
    evidence: readonly [string, ...string[]];
}> : P extends `components.${string}` ? Readonly<{
    kind: 'component-external-api';
    crossPackageUseCase: string;
    semanticGap: string;
    evidence: readonly [string, ...string[]];
}> : Readonly<{
    kind: 'cross-component' | 'external-api';
    consumerUseCase: string;
    evidence: readonly [string, ...string[]];
}>;
type PublicContractEntryBase<M extends ThemeTypeMap, P extends AuthorCanonicalTokenPath, K extends TokenTypeId<M>> = Readonly<{
    typeId: K;
    description: string;
    owner: string;
    rationale: AuthorPublicAdmissionRationale<P>;
    source?: AuthorLogicalSourceLocator;
}>;
export type AuthorPublicContractEntry<M extends ThemeTypeMap, P extends AuthorCanonicalTokenPath, K extends TokenTypeId<M> = TokenTypeId<M>> = PublicContractEntryBase<M, P, K> & (Readonly<{
    lifecycle: 'stable';
}> | Readonly<{
    lifecycle: 'experimental';
    introducedIn: `${number}.${number}.${number}`;
}> | Readonly<{
    lifecycle: 'deprecated';
    deprecatedSince: `${number}.${number}.${number}`;
    migration: Readonly<{
        kind: 'replacement';
        path: AuthorCanonicalTokenPath;
    }> | Readonly<{
        kind: 'none';
        reason: Readonly<{
            code: 'removed-concept' | 'merged-concept' | 'unsafe-api';
            detail: string;
        }>;
    }>;
}>);
export interface ThemeContractAuthorInput<M extends ThemeTypeMap = BuiltInTypeMap> {
    readonly contractVersion: '4.0.0';
    readonly entries: Readonly<{
        [P in AuthorCanonicalTokenPath]?: AuthorPublicContractEntry<M, P>;
    }>;
}
export type ThemePublicContractV4<M extends ThemeTypeMap = BuiltInTypeMap> = ThemeContractAuthorInput<M> & Readonly<{
    source: LogicalSourceLocator;
}>;
declare const validatedThemeContractBrand: unique symbol;
export type ValidatedThemePublicContractV4<M extends ThemeTypeMap = BuiltInTypeMap> = DeepReadonly<ThemePublicContractV4<M>> & {
    readonly [validatedThemeContractBrand]: true;
};
export type AppliedTransform = Readonly<{
    axis: ThemeAxisName;
    value: ThemeAxisDomains[ThemeAxisName];
    order: number;
    path: CanonicalTokenPath;
}>;
export type ResolutionTraceEntry = Readonly<{
    kind: 'alias';
    from: CanonicalTokenPath;
    to: CanonicalTokenPath;
    projection?: BuiltInFieldProjection;
}> | Readonly<{
    kind: 'expression';
    token: CanonicalTokenPath;
    operator: OperatorId;
    operandIndex: number;
    dependency?: CanonicalTokenPath;
}> | Readonly<{
    kind: 'transform';
    token: CanonicalTokenPath;
    axis: ThemeAxisName;
    axisValue: ThemeAxisDomains[ThemeAxisName];
    order: number;
}>;
export type ResolvedTokenFor<M extends ThemeTypeMap, K extends TokenTypeId<M>> = Readonly<{
    path: CanonicalTokenPath;
    layer: 'foundation' | 'semantic' | 'components';
    component?: string;
    typeId: K;
    value: DeepReadonly<M[K]>;
    source: LogicalSourceLocator;
    directDependencies: readonly CanonicalTokenPath[];
    trace: readonly ResolutionTraceEntry[];
    appliedTransforms: readonly AppliedTransform[];
}> & (Readonly<{
    visibility: 'internal';
    public?: never;
}> | Readonly<{
    visibility: 'public';
    public: AuthorPublicContractEntry<M, AuthorCanonicalTokenPath, K>;
}>);
export type ResolvedToken<M extends ThemeTypeMap = BuiltInTypeMap> = {
    [K in TokenTypeId<M>]: ResolvedTokenFor<M, K>;
}[TokenTypeId<M>];
export interface ResolvedThemeV1<M extends ThemeTypeMap = BuiltInTypeMap> {
    readonly sourceSchemaVersion: 4;
    readonly resolvedSchemaVersion: 1;
    readonly contractVersion: '4.0.0';
    readonly themeId: string;
    readonly sourceContentHash: `sha256:${string}`;
    readonly contractContentHash: `sha256:${string}`;
    readonly typeRegistryContentHash: `sha256:${string}`;
    readonly axes: Readonly<{
        selection: ThemeAxisSelection;
        applicationOrder: AxisOrder;
    }>;
    readonly tokens: Readonly<Record<CanonicalTokenPath, ResolvedToken<M>>>;
    readonly publicSurface: readonly CanonicalTokenPath[];
    readonly contentHash: `sha256:${string}`;
}
declare const validatedResolvedThemeBrand: unique symbol;
export type ValidatedResolvedThemeV1<M extends ThemeTypeMap = BuiltInTypeMap> = DeepReadonly<ResolvedThemeV1<M>> & {
    readonly [validatedResolvedThemeBrand]: true;
};
export interface ResolvedThemeDiff {
    readonly sourceContentHash: `sha256:${string}`;
    readonly contractContentHash: `sha256:${string}`;
    readonly typeRegistryContentHash: `sha256:${string}`;
    readonly fromHash: `sha256:${string}`;
    readonly toHash: `sha256:${string}`;
    readonly changedAxis: ThemeAxisName;
    readonly directWrites: readonly CanonicalTokenPath[];
    readonly affectedClosure: readonly CanonicalTokenPath[];
    readonly valueChanges: readonly CanonicalTokenPath[];
}
export type ExtensionTypeId = `${string}.${string}@${number}`;
export type ExtensionSchemaInput = Readonly<{
    type: 'null' | 'boolean' | 'string';
    enum?: readonly [CanonicalJsonValue, ...CanonicalJsonValue[]];
} | {
    type: 'number';
    enum?: readonly [CanonicalJsonValue, ...CanonicalJsonValue[]];
    minimum?: number;
    maximum?: number;
} | {
    type: 'array';
    enum?: readonly [CanonicalJsonValue, ...CanonicalJsonValue[]];
    items: ExtensionSchemaInput;
} | {
    type: 'object';
    enum?: readonly [CanonicalJsonValue, ...CanonicalJsonValue[]];
    properties: Readonly<Record<string, ExtensionSchemaInput>>;
    required?: readonly string[];
    additionalProperties: false;
}>;
export interface ExtensionValidationIssue {
    readonly keyword: string;
    readonly instancePath: string;
    readonly expected: CanonicalJsonValue;
    readonly actual: CanonicalJsonValue | null;
}
export interface ExtensionTypeDescriptor<Id extends ExtensionTypeId = ExtensionTypeId, Value = unknown> {
    readonly typeId: Id;
    readonly schemaVersion: Id extends `${string}@${infer Version extends number}` ? Version : number;
    readonly canonicalSchema: ExtensionSchemaInput;
    readonly canonicalSchemaHash: `sha256:${string}`;
    readonly validate: (input: unknown) => readonly ExtensionValidationIssue[];
    readonly canonicalize: (input: unknown) => Value;
}
export type ExtensionTypeMap<D extends readonly ExtensionTypeDescriptor[]> = {
    [Descriptor in D[number] as Descriptor['typeId']]: ReturnType<Descriptor['canonicalize']>;
};
export type KernelTypeMap<D extends readonly ExtensionTypeDescriptor[]> = BuiltInTypeMap & ExtensionTypeMap<D>;
export type ValidateExtensionTuple<D extends readonly ExtensionTypeDescriptor[]> = {
    readonly [I in keyof D]: D[I] extends ExtensionTypeDescriptor<infer _Id, infer Value> ? JsonShapeCompatible<Value> extends true ? D[I] : never : never;
};
export interface ThemeKernelOptions<D extends readonly ExtensionTypeDescriptor[]> {
    readonly extensionTypes: D & ValidateExtensionTuple<D>;
}
export interface ResolveThemeInput<M extends ThemeTypeMap = BuiltInTypeMap> {
    readonly source: ValidatedThemeSourceV4<M>;
    readonly sourceLocation: AuthorLogicalSourceLocator;
    readonly contract: ValidatedThemePublicContractV4<M>;
    readonly contractLocation: AuthorLogicalSourceLocator;
    readonly axes?: Partial<ThemeAxisSelection>;
}
export {};
