import { KernelResult } from './diagnostics';
import { AuthorLogicalSourceLocator, DeepReadonly, ThemeTypeMap, TokenTypeId } from './model';
import { TypeRegistry } from './token-types';
/** A narrow registry boundary for literals that do not belong to a complete theme. */
export declare function validateTokenLiteralWithRegistry<M extends ThemeTypeMap, K extends TokenTypeId<M>>(registry: TypeRegistry<M>, input: {
    readonly typeId: K;
    readonly value: unknown;
    readonly source: AuthorLogicalSourceLocator;
}): KernelResult<{
    readonly typeId: K;
    readonly value: DeepReadonly<M[K]>;
}>;
