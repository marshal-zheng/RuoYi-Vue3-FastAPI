export declare const themeSeedGroups: readonly ["brand", "neutral", "canvas", "glow", "tintBase", "material", "status", "typography", "metrics", "tone"];
export declare function validateThemeSeedsV1(seeds: unknown): string | null;
