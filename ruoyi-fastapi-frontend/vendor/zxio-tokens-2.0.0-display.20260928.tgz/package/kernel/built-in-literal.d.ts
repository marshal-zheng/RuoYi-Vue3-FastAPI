import { validateTokenLiteralWithRegistry } from './literal';
import { BuiltInTypeId, BuiltInTypeMap, DeepReadonly } from './model';
import { TypeRegistry } from './token-types';
import { KernelResult } from './diagnostics';
export declare const builtInLiteralRegistry: TypeRegistry<BuiltInTypeMap>;
export declare function validateBuiltInLiteral<K extends BuiltInTypeId>(input: Parameters<typeof validateTokenLiteralWithRegistry<BuiltInTypeMap, K>>[1]): KernelResult<{
    readonly typeId: K;
    readonly value: DeepReadonly<BuiltInTypeMap[K]>;
}>;
