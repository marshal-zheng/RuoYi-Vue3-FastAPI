import { DIAGNOSTIC_DEFINITIONS, ThemeDiagnosticCode } from './diagnostic-registry';
import { CanonicalJsonValue, CanonicalTokenPath, CanonicalColor, DeepReadonly, LogicalSourceLocator, OperatorId, ThemeAxisDomains, ThemeAxisName } from './model';
export type ThemeLocation = Readonly<{
    kind: 'theme';
    path: '$';
}>;
export type TokenLocation = Readonly<{
    kind: 'token';
    path: CanonicalTokenPath;
}>;
export type AxisLocation = Readonly<{
    kind: 'axis';
    path: ThemeAxisName;
}>;
export type DiagnosticLocation = ThemeLocation | TokenLocation | AxisLocation;
type DiagnosticTransformTraceEntry = {
    readonly [Axis in ThemeAxisName]: {
        kind: 'transform-write';
        token: CanonicalTokenPath;
        axis: Axis;
        axisValue: ThemeAxisDomains[Axis];
        order: number;
    };
}[ThemeAxisName];
export type DiagnosticTraceEntry = DeepReadonly<{
    kind: 'reference';
    from: CanonicalTokenPath;
    to: CanonicalTokenPath;
} | {
    kind: 'expression-operand';
    token: CanonicalTokenPath;
    operator: OperatorId;
    operandIndex: number;
    dependency?: CanonicalTokenPath;
} | {
    kind: 'unknown-expression';
    token: CanonicalTokenPath;
    rawOperator: string;
    operandIndex?: number;
} | {
    kind: 'expression-result';
    token: CanonicalTokenPath;
    operator: OperatorId;
    declaredResultTypeId: string;
    expectedResultTypeId: string;
} | {
    kind: 'expression-arity';
    token: CanonicalTokenPath;
    operator: OperatorId;
    receivedArity: number;
    expectedArities: readonly [number, ...number[]];
} | DiagnosticTransformTraceEntry | {
    kind: 'expression-evaluation';
    token: CanonicalTokenPath;
    operator: OperatorId;
    issue: 'operand-order' | 'operand-range' | 'color-space-mismatch' | 'non-finite-result' | 'canonical-result-invalid' | 'non-deterministic';
    operandIndices: readonly [number, ...number[]];
} | {
    kind: 'diff-projection';
    token: CanonicalTokenPath;
    changedFields: readonly string[];
}>;
type MissingVersionDetails = {
    receivedVersion: null;
    supportedVersions: readonly (string | number)[];
};
type UnsupportedVersionDetails = {
    receivedVersion: string | number;
    supportedVersions: readonly (string | number)[];
};
type ReferenceDetails = {
    from: CanonicalTokenPath;
    to: string;
    allowedTargets: readonly string[];
};
export type SchemaJsonIssue = 'unsupported-kind' | 'non-finite-number' | 'non-plain-object' | 'accessor-property' | 'symbol-key' | 'sparse-array' | 'cycle' | 'resource-limit' | 'inspection-failed' | 'alias-envelope' | 'component-namespace-invalid' | 'component-namespace-repeated' | 'conflict-policy-invalid' | 'conflict-policy-object-required' | 'contract-envelope' | 'expression-depth-limit' | 'expression-envelope' | 'expression-literal-envelope' | 'expression-nested-envelope' | 'expression-operand-envelope' | 'expression-operand-kind' | 'expression-ref-envelope' | 'literal-envelope' | 'locator-mismatch' | 'non-empty-components-required' | 'non-empty-token-record-required' | 'resolved-axes-invalid' | 'resolved-dependency-missing' | 'resolved-public-invalid' | 'resolved-public-surface-invalid' | 'resolved-shape-invalid' | 'resolved-token-catalog-invalid' | 'resolved-token-invalid' | 'resolved-trace-causality-invalid' | 'resolved-value-not-canonical' | 'resolved-visibility-invalid' | 'theme-envelope' | 'theme-object-required' | 'token-definition-invalid' | 'token-path-invalid' | 'token-value-branch' | 'transform-array-required' | 'transform-axis-object-required' | 'transform-invalid' | 'transforms-object-required' | 'unknown-axis' | 'unknown-transform-axis' | 'unknown-transform-axis-value';
type SourceLocatorInvalidDetails = {
    entrypoint: 'defineTheme' | 'defineThemeContract' | 'defineThemeV4' | 'defineThemeContractV4' | 'createThemeKernel' | 'validateThemeSource' | 'validateThemeContract' | 'resolveTheme' | 'resolveThemeDiff' | 'validateResolvedTheme' | 'serializeResolvedTheme' | 'computeResolvedThemeHash';
    parameter: 'source' | 'sourceLocation' | 'contractLocation' | 'fromLocation' | 'toLocation' | 'inputLocation';
    instancePath: string;
    issue: 'missing' | 'not-object' | 'non-plain-object' | 'accessor-property' | 'symbol-key' | 'inspection-failed' | 'file-not-string' | 'file-empty' | 'absolute-or-drive' | 'backslash' | 'dot-or-empty-segment' | 'nul' | 'unknown-property' | 'line-invalid' | 'column-invalid';
    receivedKind: 'undefined' | 'null' | 'boolean' | 'number' | 'bigint' | 'string' | 'symbol' | 'function' | 'array' | 'object';
};
type RegistrySchemaJcsInvalidDetails = {
    descriptorIndex: number;
    typeId: string | null;
    instancePath: string;
    receivedKind: string;
} & ({
    issue: 'non-finite-number';
    numberKind: 'nan' | 'positive-infinity' | 'negative-infinity';
} | {
    issue: 'cycle';
    firstSeenPath: string;
} | {
    issue: 'resource-limit';
    resource: 'schema-depth' | 'schema-nodes' | 'schema-properties' | 'schema-enum-members' | 'schema-bytes';
    limit: number;
    actual: number;
    truncated: boolean;
} | {
    issue: 'non-plain-object' | 'accessor-property' | 'symbol-key' | 'sparse-array' | 'unsupported-kind' | 'inspection-failed' | 'descriptor-non-plain' | 'descriptor-symbol-key' | 'descriptor-accessor';
});
type RegistrySchemaInvalidDetails = {
    descriptorIndex: number;
    typeId: string;
    instancePath: string;
    keyword: string | null;
    receivedKind: string;
} & ({
    issue: 'unknown-keyword' | 'keyword-not-allowed-for-type' | 'missing-required-keyword' | 'type-mismatch' | 'invalid-range' | 'duplicate-required' | 'required-property-unknown' | 'enum-empty' | 'enum-type-mismatch';
} | {
    issue: 'enum-duplicate';
    firstIndex: number;
    duplicateIndex: number;
});
type ExpressionCausalOperand = {
    operandIndex: number;
    actualValue: CanonicalJsonValue;
};
type ExpressionEvaluationInvalidDetails = {
    issue: 'operand-order';
    operator: 'number.clamp@1';
    constraint: 'min-lte-max';
    minOperandIndex: 1;
    maxOperandIndex: 2;
    minValue: number;
    maxValue: number;
} | {
    issue: 'color-space-mismatch';
    operator: 'color.mix@1';
    leftOperandIndex: 0;
    rightOperandIndex: 1;
    leftColorSpace: CanonicalColor['colorSpace'];
    rightColorSpace: CanonicalColor['colorSpace'];
} | {
    issue: 'operand-range';
    operator: 'color.mix@1';
    operandIndex: 2;
    operandRole: 'rightWeight';
    receivedValue: number;
    inclusiveMinimum: 0;
    inclusiveMaximum: 1;
} | {
    issue: 'operand-range';
    operator: 'color.alpha@1';
    operandIndex: 1;
    operandRole: 'alpha';
    receivedValue: number;
    inclusiveMinimum: 0;
    inclusiveMaximum: 1;
} | {
    issue: 'non-finite-result';
    operator: 'number.add@1' | 'number.multiply@1' | 'dimension.add@1' | 'dimension.subtract@1' | 'dimension.multiply@1' | 'color.mix@1';
    resultTypeId: 'number' | 'dimension' | 'color';
    resultInstancePath: string;
    numberKind: 'positive-infinity' | 'negative-infinity';
    causalOperands: readonly [
        ExpressionCausalOperand,
        ...ExpressionCausalOperand[]
    ];
} | {
    issue: 'canonical-result-invalid';
    operator: OperatorId;
    resultTypeId: string;
    resultInstancePath: string;
    validationRule: string;
    receivedValue: CanonicalJsonValue;
    causalOperands: readonly [
        ExpressionCausalOperand,
        ...ExpressionCausalOperand[]
    ];
};
type AxisDeclarationInvalidDetails = {
    issue: 'declaration-missing' | 'declaration-shape' | 'supported-missing' | 'supported-empty';
    axis: ThemeAxisName;
    platformDomain: readonly string[];
} | {
    issue: 'supported-value-unsupported';
    axis: ThemeAxisName;
    receivedValue: string;
    valueIndex: number;
    platformDomain: readonly string[];
} | {
    issue: 'supported-duplicate';
    axis: ThemeAxisName;
    receivedValue: string;
    firstIndex: number;
    duplicateIndex: number;
    platformDomain: readonly string[];
};
type TransformTypeMismatchDetails = {
    issue: 'expect-vs-base';
    path: CanonicalTokenPath;
    baseTypeId: string;
    expectTypeId: string;
} | {
    issue: 'value-declared-type-vs-expect';
    path: CanonicalTokenPath;
    baseTypeId: string;
    expectTypeId: string;
    valueKind: 'alias' | 'expression';
    declaredValueTypeId: string;
} | {
    issue: 'literal-invalid-for-expect';
    path: CanonicalTokenPath;
    baseTypeId: string;
    expectTypeId: string;
    actualValue: CanonicalJsonValue;
    validationRule: string;
};
export interface DiagnosticDetailsMap {
    readonly TK_SOURCE_LOCATOR_INVALID: SourceLocatorInvalidDetails;
    readonly TK_SCHEMA_VERSION_REQUIRED: MissingVersionDetails;
    readonly TK_SCHEMA_VERSION_UNSUPPORTED: UnsupportedVersionDetails;
    readonly TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED: {
        matchedFields: readonly string[];
        supportedVersions: readonly [4];
    };
    readonly TK_SCHEMA_THEME_ID_REQUIRED: {
        field: string;
        received: CanonicalJsonValue | null;
        rule: string;
    };
    readonly TK_SCHEMA_NAME_INVALID: {
        field: string;
        received: CanonicalJsonValue | null;
        rule: string;
    };
    readonly TK_SCHEMA_JSON_VALUE_INVALID: {
        valueKind: string;
        instancePath: string;
        issue?: SchemaJsonIssue;
    } | {
        valueKind: 'string';
        instancePath: '$.contentHash';
        issue: 'content-hash-mismatch';
        expectedHash: string;
        receivedHash: string;
    };
    readonly TK_CONTRACT_VERSION_REQUIRED: MissingVersionDetails;
    readonly TK_CONTRACT_VERSION_UNSUPPORTED: UnsupportedVersionDetails;
    readonly TK_RESOLVED_VERSION_UNSUPPORTED: UnsupportedVersionDetails;
    readonly TK_TYPE_UNKNOWN: {
        receivedTypeId: string;
        registeredTypeIds: readonly string[];
    };
    readonly TK_TYPE_VALUE_INVALID: {
        expectedTypeId: string;
        actualTypeId: string | null;
        actualValue: CanonicalJsonValue | null;
        validationRule: string;
        instancePath?: string;
    };
    readonly TK_TYPE_REGISTRY_ID_INVALID: {
        descriptorIndex: number;
        typeId: string;
        rule: string;
    };
    readonly TK_TYPE_REGISTRY_VERSION_MISMATCH: {
        descriptorIndex: number;
        typeId: string;
        schemaVersion: number | null;
        expectedSchemaVersion: number;
    };
    readonly TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID: RegistrySchemaJcsInvalidDetails;
    readonly TK_TYPE_REGISTRY_SCHEMA_INVALID: RegistrySchemaInvalidDetails;
    readonly TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED: {
        descriptorIndex: number;
        typeId: string;
        stage: 'jcs' | 'utf8';
        issue: 'serializer-rejected' | 'encoding-failed';
    };
    readonly TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID: {
        failure: 'format';
        descriptorIndex: number;
        typeId: string;
        declaredHash: string;
        requiredFormat: 'sha256:<64-lowercase-hex>';
    } | {
        failure: 'mismatch';
        descriptorIndex: number;
        typeId: string;
        declaredHash: string;
        computedHash: string;
    };
    readonly TK_TYPE_REGISTRY_DUPLICATE: {
        typeId: string;
        firstIndex: number;
        duplicateIndex: number;
    };
    readonly TK_TYPE_REGISTRY_BUILTIN_CONFLICT: {
        descriptorIndex: number;
        typeId: string;
        builtInTypeId: string;
    };
    readonly TK_TYPE_REGISTRY_NON_DETERMINISTIC: {
        descriptorIndex: number;
        typeId: string;
        firstHash: string;
        replayHash: string;
    };
    readonly TK_TYPE_ALIAS_MISMATCH: {
        from: CanonicalTokenPath;
        to: CanonicalTokenPath;
        projection: string | null;
        expectedTypeId: string;
        actualTypeId: string;
        actualValue: CanonicalJsonValue | null;
    };
    readonly TK_EXPR_OPERATOR_UNKNOWN: {
        operator: string;
        supportedOperators: readonly string[];
    };
    readonly TK_EXPR_RESULT_TYPE_MISMATCH: {
        mismatch: 'declared-vs-operator' | 'declared-vs-context';
        operator: OperatorId;
        declaredResultTypeId: string;
        operatorResultTypeIds: readonly [string, ...string[]];
        expectedResultTypeId: string;
    };
    readonly TK_EXPR_OPERAND_INVALID: {
        issue: 'arity';
        operator: string;
        receivedArity: number;
        expectedArities: readonly [number, ...number[]];
    } | {
        issue: 'operand-type';
        operator: string;
        operandIndex: number;
        expectedTypeIds: readonly [string, ...string[]];
        actualTypeId: string | null;
        actualValue: CanonicalJsonValue | null;
    };
    readonly TK_EXPR_EVALUATION_INVALID: ExpressionEvaluationInvalidDetails;
    readonly TK_EXPR_NON_DETERMINISTIC: {
        operator: OperatorId;
        firstHash: string;
        replayHash: string;
    };
    readonly TK_AXIS_DECLARATION_INVALID: AxisDeclarationInvalidDetails;
    readonly TK_AXIS_DEFAULT_REQUIRED: {
        axis: ThemeAxisName;
        platformDomain: readonly string[];
        themeSupportedValues: readonly string[];
    };
    readonly TK_AXIS_DEFAULT_INVALID: {
        axis: ThemeAxisName;
        receivedValue: string;
        platformDomain: readonly string[];
        themeSupportedValues: readonly string[];
    };
    readonly TK_AXIS_VALUE_UNSUPPORTED: {
        axis: ThemeAxisName;
        receivedValue: string;
        platformDomain: readonly string[];
        themeSupportedValues: readonly string[];
    };
    readonly TK_TRANSFORM_PATH_UNKNOWN: {
        path: CanonicalTokenPath;
    };
    readonly TK_TRANSFORM_MUTATION_FORBIDDEN: {
        path: CanonicalTokenPath;
        forbiddenFields: readonly string[];
    };
    readonly TK_TRANSFORM_TYPE_MISMATCH: TransformTypeMismatchDetails;
    readonly TK_TRANSFORM_CONFLICT: {
        path: CanonicalTokenPath;
        writers: readonly ThemeAxisName[];
    };
    readonly TK_DIFF_SOURCE_MISMATCH: {
        mismatches: readonly {
            field: 'sourceContentHash' | 'contractContentHash' | 'typeRegistryContentHash' | 'themeId' | 'contractVersion' | 'resolvedSchemaVersion';
            fromValue: string | number;
            toValue: string | number;
        }[];
    };
    readonly TK_DIFF_AXES_INVALID: {
        differingAxes: readonly ThemeAxisName[];
        requiredDifferenceCount: 1;
    };
    readonly TK_DIFF_OUTSIDE_CLOSURE: {
        path: CanonicalTokenPath;
        changedFields: readonly string[];
    };
    readonly TK_REF_TARGET_MISSING: ReferenceDetails;
    readonly TK_REF_LAYER_FORBIDDEN: ReferenceDetails;
    readonly TK_REF_COMPONENT_FORBIDDEN: ReferenceDetails;
    readonly TK_REF_CYCLE: {
        cycle: readonly CanonicalTokenPath[];
        edgeCount: number;
    };
    readonly TK_CONTRACT_ENTRY_MISSING: {
        path: CanonicalTokenPath;
    };
    readonly TK_ELEVATION_GROUP_INCOMPLETE: {
        role: string;
        issue: 'missing-facets' | 'unknown-role' | 'unknown-facet';
        facets: readonly string[];
    };
    readonly TK_CONTRACT_TYPE_MISMATCH: {
        path: CanonicalTokenPath;
        expectedTypeId: string;
        actualTypeId: string;
    };
    readonly TK_CONTRACT_LIFECYCLE_INVALID: {
        path: CanonicalTokenPath;
        from: string;
        to: string;
        rule: string;
    };
    readonly TK_CONTRACT_REPLACEMENT_INVALID: {
        path: CanonicalTokenPath;
        replacement: CanonicalTokenPath | null;
        reason: string;
    };
    readonly TK_CONTRACT_BREAKING_CHANGE: {
        path: CanonicalTokenPath;
        changedFields: readonly string[];
        baselineVersion: string;
    };
    readonly TK_RESOURCE_LIMIT_EXCEEDED: {
        resource: 'tokens' | 'edges' | 'path-length' | 'expression-depth' | 'diagnostics';
        limit: number;
        actual: number;
        truncated: boolean;
    };
}
export type DiagnosticDetails = DiagnosticDetailsMap[keyof DiagnosticDetailsMap];
type DefinitionFor<C extends ThemeDiagnosticCode> = (typeof DIAGNOSTIC_DEFINITIONS)[C];
type LocationFor<C extends ThemeDiagnosticCode> = DefinitionFor<C>['location'] extends 'theme' ? ThemeLocation : DefinitionFor<C>['location'] extends 'axis' ? AxisLocation : TokenLocation;
type TraceField<C extends ThemeDiagnosticCode> = DefinitionFor<C>['trace'] extends 'required' ? {
    trace: readonly [DiagnosticTraceEntry, ...DiagnosticTraceEntry[]];
} : DefinitionFor<C>['trace'] extends 'optional' ? {
    trace?: readonly [DiagnosticTraceEntry, ...DiagnosticTraceEntry[]];
} : {
    trace?: never;
};
export type DiagnosticFor<C extends ThemeDiagnosticCode> = DeepReadonly<{
    code: C;
    phase: DefinitionFor<C>['phase'];
    source: LogicalSourceLocator;
    themeId?: string;
    location: LocationFor<C>;
    reason: string;
    hint: string;
    details: DiagnosticDetailsMap[C];
} & TraceField<C>>;
export type ThemeDiagnostic = {
    [C in ThemeDiagnosticCode]: DiagnosticFor<C>;
}[ThemeDiagnosticCode];
export type KernelResult<T> = Readonly<{
    ok: true;
    diagnosticSchemaVersion: 1;
    value: T;
}> | Readonly<{
    ok: false;
    diagnosticSchemaVersion: 1;
    diagnostics: readonly ThemeDiagnostic[];
}>;
export declare const KERNEL_INPUT_DIAGNOSTIC_SOURCE: LogicalSourceLocator;
export declare const MAX_THEME_DIAGNOSTICS = 256;
export declare function sortAndDedupeDiagnostics(diagnostics: readonly ThemeDiagnostic[]): readonly ThemeDiagnostic[];
type DiagnosticInput<C extends ThemeDiagnosticCode> = Readonly<{
    source?: LogicalSourceLocator;
    themeId?: string;
    location: LocationFor<C>;
    details: DiagnosticDetailsMap[C];
    reason?: string;
    hint?: string;
} & TraceField<C>>;
export declare function createDiagnostic<C extends ThemeDiagnosticCode>(code: C, input: DiagnosticInput<C>): DiagnosticFor<C>;
export declare function ok<T>(value: T): KernelResult<T>;
export declare function failure<T = never>(diagnostics: readonly ThemeDiagnostic[]): KernelResult<T>;
export declare function themeLocation(): ThemeLocation;
export declare function tokenLocation(path: string): TokenLocation;
export declare function axisLocation(path: string): AxisLocation;
export {};
