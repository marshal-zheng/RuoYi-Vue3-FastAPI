import { DeepReadonly } from './model';
export type CanonicalJsonIssue = 'unsupported-kind' | 'non-finite-number' | 'non-plain-object' | 'accessor-property' | 'symbol-key' | 'sparse-array' | 'cycle' | 'resource-limit' | 'inspection-failed';
export declare class CanonicalJsonError extends Error {
    readonly issue: CanonicalJsonIssue;
    readonly instancePath: string;
    readonly firstSeenPath?: string;
    readonly numberKind?: 'nan' | 'positive-infinity' | 'negative-infinity';
    constructor(issue: CanonicalJsonIssue, instancePath: string, firstSeenPath?: string, numberKind?: CanonicalJsonError['numberKind']);
}
export declare function compareUtf16(left: string, right: string): number;
export declare function compareAscii(left: string, right: string): number;
export declare function compareBytes(left: Uint8Array, right: Uint8Array): number;
export declare function snapshotCanonicalJson<T>(input: T, options?: Readonly<{
    maxDepth?: number;
    maxNodes?: number;
}>): DeepReadonly<T>;
export declare function deepFreeze<T>(input: T): DeepReadonly<T>;
export declare function canonicalJsonStringify(input: unknown): string;
export declare function utf8ByteLength(value: string): number;
export declare function bytesToHex(bytes: Uint8Array): string;
export declare function canonicalJsonBytes(input: unknown): Uint8Array;
export declare function describeValueKind(input: unknown): string;
