export type Sha256 = `sha256:${string}`;
export declare function sha256Bytes(input: Uint8Array): Sha256;
export declare function computeCanonicalHash(input: unknown): Sha256;
