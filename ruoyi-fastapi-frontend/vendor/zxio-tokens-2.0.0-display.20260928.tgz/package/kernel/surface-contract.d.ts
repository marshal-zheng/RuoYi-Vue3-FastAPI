/** Surface vocabulary shared by contract validation and Seed derivation. */
export declare const THEME_SURFACE_ROLES: readonly ["canvas", "panel", "card", "field", "header", "overlay", "blocking", "selected", "brand"];
export declare const THEME_SURFACE_FACETS: readonly ["fill", "edge", "depth", "inner", "highlight", "on-text", "on-text-secondary"];
