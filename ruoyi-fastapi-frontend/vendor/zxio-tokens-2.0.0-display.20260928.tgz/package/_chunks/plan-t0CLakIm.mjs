import { v as validateTokenLiteralWithRegistry, c as createBuiltInTypeRegistry, a as computeCanonicalHash, s as snapshotCanonicalJson, b as canonicalJsonStringify, d as sha256Bytes, p as parseCanonicalTokenPath, B as BUILT_IN_TYPE_IDS, e as validateThemeContractObject } from "./public-contract-UdLYIjLH.mjs";
const builtInLiteralRegistry = /* @__PURE__ */ createBuiltInTypeRegistry();
function validateBuiltInLiteral(input) {
  return validateTokenLiteralWithRegistry(builtInLiteralRegistry, input);
}
const AXES = ["mode", "density", "contrast", "motion", "radius"];
const DOMAINS = {
  mode: ["light", "dark"],
  density: ["compact", "default", "comfortable"],
  contrast: ["normal", "high", "forced-colors"],
  motion: ["full", "reduced", "none"],
  radius: ["sharp", "default", "rounded"]
};
const TYPOGRAPHY_FIELDS = [
  "fontFamily",
  "fontSize",
  "fontWeight",
  "lineHeight",
  "letterSpacing"
];
const ID = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const HASH = /^sha256:[a-f0-9]{64}$/;
const PACKAGE = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/;
const canonicalThemeExtensionJson = canonicalJsonStringify;
const hashThemeExtensionContent = computeCanonicalHash;
const hashThemeExtensionText = (text2) => sha256Bytes(new TextEncoder().encode(text2));
const sortText = (a, b) => a < b ? -1 : a > b ? 1 : 0;
function record(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
class ExtensionFailureError extends Error {
  constructor(diagnostic) {
    super(diagnostic.code);
    this.diagnostic = diagnostic;
    this.name = "ExtensionFailureError";
  }
}
function fail(code, path, details = {}) {
  throw new ExtensionFailureError({ code, severity: "error", path, details });
}
function requireThat(condition, code, path, details = {}) {
  if (!condition) fail(code, path, details);
}
function exact(value, required, optional, path) {
  requireThat(record(value), "TX_INPUT_INVALID", path, {
    issue: "object-required"
  });
  const prototype = Object.getPrototypeOf(value);
  requireThat(
    (prototype === Object.prototype || prototype === null) && Object.getOwnPropertySymbols(value).length === 0 && Object.values(Object.getOwnPropertyDescriptors(value)).every(
      (descriptor) => "value" in descriptor
    ),
    "TX_INPUT_INVALID",
    path,
    { issue: "plain-data-properties-required" }
  );
  requireThat(
    required.every((key) => Object.prototype.hasOwnProperty.call(value, key)) && Object.keys(value).every(
      (key) => [...required, ...optional].includes(key)
    ),
    "TX_INPUT_INVALID",
    path,
    { issue: "exact-keys", required: [...required], optional: [...optional] }
  );
}
function text(value, path) {
  requireThat(
    typeof value === "string" && value.trim().length > 0 && value.length <= 4096,
    "TX_INPUT_INVALID",
    path,
    { issue: "bounded-nonempty-string" }
  );
}
function safePath(value, path) {
  requireThat(
    typeof value === "string" && value.length <= 256 && value.split(".").every(
      (segment) => ID.test(segment) && !["constructor", "prototype", "__proto__"].includes(segment)
    ),
    "TX_TOKEN_INVALID",
    path,
    { issue: "invalid-token-path" }
  );
}
function snapshot(value) {
  const copy = snapshotCanonicalJson(value, { maxDepth: 48, maxNodes: 2e5 });
  const scan = (input) => {
    if (!input || typeof input !== "object") return;
    for (const key of Object.keys(input)) {
      requireThat(
        !["__proto__", "constructor", "prototype"].includes(key),
        "TX_INPUT_INVALID",
        "$",
        { issue: "dangerous-key", key }
      );
      scan(input[key]);
    }
  };
  scan(copy);
  requireThat(
    new TextEncoder().encode(canonicalJsonStringify(copy)).byteLength <= 8 * 1024 * 1024,
    "TX_INPUT_INVALID",
    "$",
    { issue: "byte-budget" }
  );
  return copy;
}
function result(run, warnings = []) {
  try {
    return Object.freeze({
      ok: true,
      value: snapshot(run()),
      diagnostics: snapshot(warnings)
    });
  } catch (error) {
    const diagnostic = error instanceof ExtensionFailureError ? error.diagnostic : {
      code: "TX_INPUT_INVALID",
      severity: "error",
      path: "$",
      details: { issue: "non-json-or-invalid-input" }
    };
    return Object.freeze({ ok: false, diagnostics: snapshot([diagnostic]) });
  }
}
function unwrap(value) {
  if (!value.ok) throw new ExtensionFailureError(value.diagnostics[0]);
  return value.value;
}
function axisSelection(input) {
  exact(input, AXES, [], "$.axes");
  for (const axis of AXES)
    requireThat(
      DOMAINS[axis].includes(input[axis]),
      "TX_AXIS_INVALID",
      `$.axes.${axis}`
    );
  return input;
}
function allSelections() {
  let values = [{}];
  for (const axis of AXES)
    values = values.flatMap(
      (value) => DOMAINS[axis].map((entry) => ({ ...value, [axis]: entry }))
    );
  return values;
}
function parseVersion(input) {
  var _a;
  if (typeof input !== "string") return null;
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/.exec(
    input
  );
  if (!match) return null;
  const core = match.slice(1, 4).map(Number);
  const pre = ((_a = match[4]) == null ? void 0 : _a.split(".")) ?? [];
  return core.every(Number.isSafeInteger) && pre.every(
    (part) => !/^\d+$/.test(part) || part === "0" || !part.startsWith("0")
  ) ? { core, pre } : null;
}
function compareVersion(a, b) {
  for (let i = 0; i < 3; i++)
    if (a.core[i] !== b.core[i]) return a.core[i] - b.core[i];
  if (!a.pre.length || !b.pre.length)
    return a.pre.length ? -1 : b.pre.length ? 1 : 0;
  for (let i = 0; i < Math.max(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === void 0 || y === void 0) return x === void 0 ? -1 : 1;
    if (x === y) continue;
    if (/^\d+$/.test(x) && /^\d+$/.test(y)) return Number(x) - Number(y);
    if (/^\d+$/.test(x) !== /^\d+$/.test(y)) return /^\d+$/.test(x) ? -1 : 1;
    return sortText(x, y);
  }
  return 0;
}
function versionSatisfies(actual, range) {
  const current = parseVersion(actual);
  if (!current || typeof range !== "string" || range.length > 256) return null;
  const groups = range.split("||").map((group) => group.trim());
  if (groups.some((group) => !group)) return null;
  let any = false;
  for (const group of groups) {
    const clauses = group.replace(/(>=|<=|>|<|=|\^|~)\s+/g, "$1").split(/\s+/);
    let matches = true;
    let acceptsPrerelease = false;
    for (const clause of clauses) {
      if (clause === "*") continue;
      const match = /^(>=|<=|>|<|=|\^|~)?(.+)$/.exec(clause);
      const version = parseVersion(match[2]);
      if (!version) return null;
      if (version.pre.length && version.core.every((n, i) => n === current.core[i]))
        acceptsPrerelease = true;
      const order = compareVersion(current, version);
      const op = match[1] ?? "=";
      if (op === "^" || op === "~") {
        const upper = [...version.core];
        const at = op === "~" ? 1 : upper[0] ? 0 : upper[1] ? 1 : 2;
        upper[at] = upper[at] + 1;
        for (let i = at + 1; i < 3; i++) upper[i] = 0;
        matches && (matches = order >= 0 && compareVersion(current, { core: upper, pre: [] }) < 0);
      } else
        matches && (matches = op === ">=" ? order >= 0 : op === ">" ? order > 0 : op === "<=" ? order <= 0 : op === "<" ? order < 0 : order === 0);
    }
    any || (any = matches && (!current.pre.length || acceptsPrerelease));
  }
  return any;
}
function normalizeValue(input, typeId, path) {
  requireThat(record(input), "TX_TOKEN_INVALID", path);
  if (input.kind === "literal") {
    exact(input, ["kind", "value"], [], path);
    const literal = validateBuiltInLiteral({
      typeId,
      value: input.value,
      source: { file: "theme-extension/source.json" }
    });
    if (!literal.ok)
      fail("TX_TOKEN_INVALID", path, {
        issue: "literal-invalid",
        kernelCodes: literal.diagnostics.map((d) => d.code)
      });
    return { kind: "literal", value: literal.value.value };
  }
  if (input.kind === "core-ref") {
    exact(input, ["kind", "path"], [], path);
    requireThat(
      parseCanonicalTokenPath(input.path),
      "TX_REFERENCE_INVALID",
      path
    );
    return { kind: "core-ref", path: input.path };
  }
  exact(input, ["kind", "module", "path"], [], path);
  requireThat(
    input.kind === "module-ref" && typeof input.module === "string" && ID.test(input.module),
    "TX_REFERENCE_INVALID",
    path
  );
  safePath(input.path, `${path}.path`);
  return { kind: "module-ref", module: input.module, path: input.path };
}
function normalizeToken(input, owner, path) {
  exact(
    input,
    ["type", "description", "visibility", "lifecycle", "value"],
    ["owner", "overridable", "overrides", "conflictPolicy", "deprecated"],
    path
  );
  requireThat(
    BUILT_IN_TYPE_IDS.includes(input.type),
    "TX_TOKEN_INVALID",
    `${path}.type`
  );
  const type = input.type;
  text(input.description, `${path}.description`);
  if (input.owner !== void 0) text(input.owner, `${path}.owner`);
  requireThat(
    ["public", "private"].includes(String(input.visibility)) && ["stable", "experimental", "deprecated"].includes(
      String(input.lifecycle)
    ),
    "TX_TOKEN_INVALID",
    path
  );
  requireThat(
    input.overridable === void 0 || typeof input.overridable === "boolean",
    "TX_TOKEN_INVALID",
    `${path}.overridable`
  );
  requireThat(
    input.visibility !== "private" || input.overridable !== true,
    "TX_TOKEN_INVALID",
    path,
    { issue: "private-not-overridable" }
  );
  if (input.lifecycle === "deprecated") {
    exact(
      input.deprecated,
      ["since"],
      ["replacement", "reason"],
      `${path}.deprecated`
    );
    requireThat(
      parseVersion(input.deprecated.since),
      "TX_TOKEN_INVALID",
      `${path}.deprecated.since`
    );
    requireThat(
      Boolean(input.deprecated.replacement) !== Boolean(input.deprecated.reason),
      "TX_TOKEN_INVALID",
      `${path}.deprecated`,
      { issue: "one-migration-required" }
    );
    if (input.deprecated.reason)
      text(input.deprecated.reason, `${path}.deprecated.reason`);
    if (input.deprecated.replacement) {
      exact(
        input.deprecated.replacement,
        ["module", "path"],
        [],
        `${path}.deprecated.replacement`
      );
      requireThat(
        typeof input.deprecated.replacement.module === "string" && ID.test(input.deprecated.replacement.module),
        "TX_TOKEN_INVALID",
        path
      );
      safePath(input.deprecated.replacement.path, path);
    }
  } else
    requireThat(input.deprecated === void 0, "TX_TOKEN_INVALID", path, {
      issue: "unexpected-deprecation"
    });
  const overrides = {};
  if (input.overrides !== void 0) {
    exact(input.overrides, [], AXES, `${path}.overrides`);
    for (const axis of AXES) {
      const values = input.overrides[axis];
      if (values === void 0) continue;
      exact(values, [], DOMAINS[axis], `${path}.overrides.${axis}`);
      overrides[axis] = Object.fromEntries(
        Object.keys(values).sort(sortText).map((value) => [
          value,
          normalizeValue(
            values[value],
            type,
            `${path}.overrides.${axis}.${value}`
          )
        ])
      );
    }
  }
  const writers = AXES.filter(
    (axis) => Object.keys(overrides[axis] ?? {}).length > 0
  );
  if (input.conflictPolicy !== void 0) {
    exact(
      input.conflictPolicy,
      ["axisOrder", "rationale"],
      [],
      `${path}.conflictPolicy`
    );
    text(input.conflictPolicy.rationale, `${path}.conflictPolicy.rationale`);
    requireThat(
      Array.isArray(input.conflictPolicy.axisOrder) && input.conflictPolicy.axisOrder.length === writers.length && new Set(input.conflictPolicy.axisOrder).size === writers.length && input.conflictPolicy.axisOrder.every(
        (axis) => writers.includes(axis)
      ),
      "TX_AXIS_CONFLICT",
      `${path}.conflictPolicy`,
      { issue: "exact-writers-required", writers }
    );
  }
  requireThat(
    writers.length < 2 || input.conflictPolicy !== void 0,
    "TX_AXIS_CONFLICT",
    path,
    { issue: "explicit-policy-required", writers }
  );
  return {
    type,
    description: input.description,
    owner: input.owner ?? owner,
    visibility: input.visibility,
    lifecycle: input.lifecycle,
    overridable: input.overridable ?? false,
    value: normalizeValue(input.value, type, `${path}.value`),
    overrides,
    ...input.conflictPolicy ? { conflictPolicy: input.conflictPolicy } : {},
    ...input.deprecated ? { deprecated: input.deprecated } : {}
  };
}
function normalizeModule(input) {
  exact(
    input,
    ["schema", "id", "namespace", "version", "description", "owner", "tokens"],
    ["dependencies", "core", "displayMetrics"],
    "$.module"
  );
  requireThat(
    input.schema === "zx.theme-module/1",
    "TX_MODULE_INVALID",
    "$.module.schema"
  );
  for (const key of ["id", "namespace"])
    requireThat(
      typeof input[key] === "string" && input[key].length <= 64 && ID.test(input[key]),
      "TX_MODULE_INVALID",
      `$.module.${key}`
    );
  requireThat(
    parseVersion(input.version),
    "TX_MODULE_INVALID",
    "$.module.version"
  );
  text(input.description, "$.module.description");
  text(input.owner, "$.module.owner");
  requireThat(
    record(input.tokens) && Object.keys(input.tokens).length > 0 && Object.keys(input.tokens).length <= 2048,
    "TX_MODULE_INVALID",
    "$.module.tokens"
  );
  const tokens = {};
  for (const path of Object.keys(input.tokens).sort(sortText)) {
    safePath(path, `$.module.${input.id}.tokens.${path}`);
    tokens[path] = normalizeToken(
      input.tokens[path],
      input.owner,
      `$.module.${input.id}.tokens.${path}`
    );
  }
  const displayMetrics = {};
  if (input.displayMetrics !== void 0) {
    requireThat(
      record(input.displayMetrics) && Object.keys(input.displayMetrics).length <= 512,
      "TX_DISPLAY_METRIC_INVALID",
      "$.module.displayMetrics"
    );
    for (const path of Object.keys(input.displayMetrics).sort(sortText)) {
      safePath(path, `$.module.displayMetrics.${path}`);
      const metric = input.displayMetrics[path];
      exact(
        metric,
        ["role", "policy", "source"],
        [],
        `$.module.displayMetrics.${path}`
      );
      safePath(metric.role, `$.module.displayMetrics.${path}.role`);
      requireThat(
        [
          "ui-length",
          "fixed-length",
          "domain-length",
          "unitless-ratio"
        ].includes(String(metric.policy)),
        "TX_DISPLAY_METRIC_INVALID",
        `$.module.displayMetrics.${path}.policy`
      );
      exact(
        metric.source,
        ["module", "path"],
        ["field"],
        `$.module.displayMetrics.${path}.source`
      );
      requireThat(
        typeof metric.source.module === "string" && ID.test(metric.source.module),
        "TX_DISPLAY_METRIC_INVALID",
        `$.module.displayMetrics.${path}.source.module`
      );
      safePath(
        metric.source.path,
        `$.module.displayMetrics.${path}.source.path`
      );
      requireThat(
        metric.source.field === void 0 || ["fontSize", "letterSpacing"].includes(String(metric.source.field)),
        "TX_DISPLAY_METRIC_INVALID",
        `$.module.displayMetrics.${path}.source.field`
      );
      displayMetrics[path] = {
        role: metric.role,
        policy: metric.policy,
        source: {
          module: metric.source.module,
          path: metric.source.path,
          ...metric.source.field ? { field: metric.source.field } : {}
        }
      };
    }
  }
  const dependencies = input.dependencies ?? [];
  requireThat(
    Array.isArray(dependencies) && dependencies.length <= 128,
    "TX_DEPENDENCY_INVALID",
    "$.module.dependencies"
  );
  for (const dep of dependencies) {
    exact(dep, ["id", "version"], ["contractHash"], "$.module.dependencies");
    requireThat(
      typeof dep.id === "string" && ID.test(dep.id) && dep.id !== input.id && parseVersion(dep.version) && (dep.contractHash === void 0 || typeof dep.contractHash === "string" && HASH.test(dep.contractHash)),
      "TX_DEPENDENCY_INVALID",
      "$.module.dependencies"
    );
  }
  requireThat(
    new Set(dependencies.map((dep) => dep.id)).size === dependencies.length,
    "TX_DEPENDENCY_INVALID",
    "$.module.dependencies"
  );
  const core = input.core ?? {};
  exact(core, [], ["tokens", "experimental"], "$.module.core");
  for (const key of ["tokens", "experimental"])
    if (core[key] !== void 0) {
      requireThat(
        Array.isArray(core[key]) && core[key].every((entry) => parseCanonicalTokenPath(entry)) && new Set(core[key]).size === core[key].length,
        "TX_CORE_REQUIREMENT",
        `$.module.core.${key}`
      );
    }
  return {
    schema: "zx.theme-module/1",
    id: input.id,
    namespace: input.namespace,
    version: input.version,
    description: input.description,
    owner: input.owner,
    dependencies: [...dependencies].sort((a, b) => sortText(a.id, b.id)),
    core: {
      tokens: [...core.tokens ?? []].sort(sortText),
      experimental: [...core.experimental ?? []].sort(sortText)
    },
    tokens,
    ...input.displayMetrics !== void 0 ? { displayMetrics } : {}
  };
}
function defineThemeModule(input) {
  return result(
    () => normalizeModule(snapshot(input))
  );
}
function normalizeAdapter(input) {
  exact(
    input,
    ["id", "version", "targetPackage", "propertyPrefix", "mappings"],
    [],
    "$.adapter"
  );
  requireThat(
    typeof input.id === "string" && ID.test(input.id) && parseVersion(input.version),
    "TX_ADAPTER_INVALID",
    "$.adapter"
  );
  exact(
    input.targetPackage,
    ["name", "supportedRange"],
    [],
    "$.adapter.targetPackage"
  );
  requireThat(
    typeof input.targetPackage.name === "string" && PACKAGE.test(input.targetPackage.name) && typeof input.targetPackage.supportedRange === "string" && versionSatisfies("1.0.0", input.targetPackage.supportedRange) !== null,
    "TX_ADAPTER_INVALID",
    "$.adapter.targetPackage"
  );
  requireThat(
    typeof input.propertyPrefix === "string" && /^--[a-z][a-z0-9]*(?:-[a-z0-9]+)*-$/.test(input.propertyPrefix) && !input.propertyPrefix.startsWith("--zx-"),
    "TX_ADAPTER_INVALID",
    "$.adapter.propertyPrefix"
  );
  requireThat(
    Array.isArray(input.mappings) && input.mappings.length > 0 && input.mappings.length <= 512,
    "TX_ADAPTER_INVALID",
    "$.adapter.mappings"
  );
  for (const mapping of input.mappings) {
    exact(mapping, ["property", "token"], [], "$.adapter.mappings");
    exact(mapping.token, ["module", "path"], [], "$.adapter.mappings.token");
    requireThat(
      typeof mapping.property === "string" && /^--[a-z][a-z0-9-]*$/.test(mapping.property) && mapping.property.startsWith(input.propertyPrefix) && !mapping.property.startsWith("--zx-"),
      "TX_ADAPTER_INVALID",
      "$.adapter.mappings.property"
    );
    requireThat(
      typeof mapping.token.module === "string" && ID.test(mapping.token.module),
      "TX_ADAPTER_INVALID",
      "$.adapter.mappings.token.module"
    );
    safePath(mapping.token.path, "$.adapter.mappings.token.path");
  }
  requireThat(
    new Set(input.mappings.map((entry) => entry.property)).size === input.mappings.length,
    "TX_CSS_COLLISION",
    "$.adapter.mappings"
  );
  return {
    ...input,
    mappings: [...input.mappings].sort(
      (a, b) => sortText(a.property, b.property)
    )
  };
}
function defineThemeCssAdapter(input) {
  return result(() => normalizeAdapter(snapshot(input)));
}
function publicCoreVariable(path) {
  return `--zx-${path.split(".").map(
    (segment) => [...segment].map(
      (c) => /[a-z0-9-]/.test(c) ? c : `_${c.codePointAt(0).toString(16)}_`
    ).join("")
  ).join("-")}`;
}
function tokenCss(module, path, type) {
  const variable = `--zx-ext-${module.namespace}-${path.replace(/\./g, "-")}`;
  return type === "typography" ? {
    fields: Object.fromEntries(
      TYPOGRAPHY_FIELDS.map((field) => [field, `${variable}-${field}`])
    )
  } : { publicVariable: variable };
}
function cssVariables(css) {
  return css.publicVariable ? [css.publicVariable] : Object.values(css.fields ?? {});
}
function moduleContractHash(module) {
  return hashThemeExtensionContent({
    id: module.id,
    namespace: module.namespace,
    version: module.version,
    tokens: Object.fromEntries(
      Object.entries(module.tokens).filter(([, token]) => token.visibility === "public").map(([path, token]) => {
        const {
          value: _value,
          overrides: _overrides,
          conflictPolicy: _policy,
          ...contract
        } = token;
        return [path, contract];
      })
    ),
    ...module.displayMetrics ? { displayMetrics: module.displayMetrics } : {}
  });
}
function displayMetricReference(module, path, metric) {
  const suffix = `${module.namespace}-${path.replace(/\./g, "-")}`;
  const base = `--zx-display-base-${suffix}`;
  const effective = `--zx-display-${suffix}`;
  return {
    id: `${module.id}.${path}`,
    role: metric.role,
    policy: metric.policy,
    source: metric.source,
    base: { variable: base, ref: `var(${base})` },
    effective: { variable: effective, ref: `var(${effective})` }
  };
}
function tokenDescriptor(module, path, token) {
  const css = tokenCss(module, path, token.type);
  return {
    kind: "theme-extension-token",
    key: `${module.id}/${path}`,
    module: module.id,
    path,
    typeId: token.type,
    overridable: token.overridable ?? false,
    css,
    ...css.publicVariable ? { ref: `var(${css.publicVariable})` } : {
      fields: Object.fromEntries(
        Object.entries(css.fields).map(([key, variable]) => [
          key,
          `var(${variable})`
        ])
      )
    },
    visibility: "public",
    owner: token.owner ?? module.owner,
    description: token.description,
    lifecycle: token.lifecycle,
    ...token.deprecated ? { deprecated: token.deprecated } : {}
  };
}
function allValues(token) {
  return [
    token.value,
    ...AXES.flatMap((axis) => {
      var _a;
      return Object.values(((_a = token.overrides) == null ? void 0 : _a[axis]) ?? {});
    })
  ];
}
function effectiveValue(token, axes) {
  var _a, _b, _c;
  let value = token.value;
  for (const axis of ((_a = token.conflictPolicy) == null ? void 0 : _a.axisOrder) ?? AXES) {
    const candidate = (_c = (_b = token.overrides) == null ? void 0 : _b[axis]) == null ? void 0 : _c[axes[axis]];
    if (candidate) value = candidate;
  }
  return value;
}
function moduleCorePaths(module) {
  var _a;
  return [
    .../* @__PURE__ */ new Set([
      ...((_a = module.core) == null ? void 0 : _a.tokens) ?? [],
      ...Object.values(module.tokens).flatMap(
        (token) => allValues(token).flatMap(
          (value) => value.kind === "core-ref" ? [value.path] : []
        )
      ),
      ...Object.values(module.displayMetrics ?? {}).flatMap(
        (metric) => metric.source.module === "core" ? [metric.source.path] : []
      )
    ])
  ].sort(sortText);
}
function checkRequirementsShape(requirements) {
  exact(
    requirements,
    ["contractVersion", "typeRegistryContentHash", "tokens"],
    ["experimentalContractContentHash"],
    "$.coreRequirements"
  );
  requireThat(
    requirements.contractVersion === "4.0.0" && typeof requirements.typeRegistryContentHash === "string" && HASH.test(requirements.typeRegistryContentHash),
    "TX_CORE_REQUIREMENT",
    "$.coreRequirements"
  );
  requireThat(
    requirements.experimentalContractContentHash === void 0 || typeof requirements.experimentalContractContentHash === "string" && HASH.test(requirements.experimentalContractContentHash),
    "TX_CORE_REQUIREMENT",
    "$.coreRequirements.experimentalContractContentHash"
  );
  requireThat(
    Array.isArray(requirements.tokens) && requirements.tokens.length <= 4096,
    "TX_CORE_REQUIREMENT",
    "$.coreRequirements.tokens"
  );
  const paths = /* @__PURE__ */ new Set();
  for (const token of requirements.tokens) {
    exact(
      token,
      ["path", "typeId", "lifecycle", "css"],
      ["deprecated"],
      "$.coreRequirements.tokens"
    );
    requireThat(
      parseCanonicalTokenPath(token.path) && !paths.has(String(token.path)) && BUILT_IN_TYPE_IDS.includes(token.typeId) && ["stable", "experimental", "deprecated"].includes(
        String(token.lifecycle)
      ),
      "TX_CORE_REQUIREMENT",
      "$.coreRequirements.tokens"
    );
    paths.add(token.path);
    exact(
      token.css,
      ["publicVariable"],
      ["fields"],
      "$.coreRequirements.tokens.css"
    );
    requireThat(
      token.css.publicVariable === publicCoreVariable(token.path),
      "TX_CORE_REQUIREMENT",
      "$.coreRequirements.tokens.css"
    );
    const publicVariable = token.css.publicVariable;
    if (token.typeId === "typography")
      requireThat(
        canonicalThemeExtensionJson(token.css.fields) === canonicalThemeExtensionJson(
          Object.fromEntries(
            TYPOGRAPHY_FIELDS.map((field) => [
              field,
              `${publicVariable}-${field}`
            ])
          )
        ),
        "TX_CORE_REQUIREMENT",
        "$.coreRequirements.tokens.css.fields"
      );
    else
      requireThat(
        token.css.fields === void 0,
        "TX_CORE_REQUIREMENT",
        "$.coreRequirements.tokens.css.fields"
      );
    if (token.lifecycle === "experimental")
      requireThat(
        requirements.experimentalContractContentHash,
        "TX_EXPERIMENTAL_OPT_IN",
        "$.coreRequirements"
      );
    if (token.lifecycle === "deprecated") {
      exact(
        token.deprecated,
        ["since"],
        ["replacement", "noReplacementReason"],
        "$.coreRequirements.tokens.deprecated"
      );
      requireThat(
        parseVersion(token.deprecated.since) && Boolean(token.deprecated.replacement) !== Boolean(token.deprecated.noReplacementReason),
        "TX_CORE_REQUIREMENT",
        "$.coreRequirements.tokens.deprecated"
      );
      if (token.deprecated.replacement)
        requireThat(
          parseCanonicalTokenPath(token.deprecated.replacement),
          "TX_CORE_REQUIREMENT",
          "$.coreRequirements.tokens.deprecated"
        );
    } else
      requireThat(
        token.deprecated === void 0,
        "TX_CORE_REQUIREMENT",
        "$.coreRequirements.tokens.deprecated"
      );
  }
}
function coreRequirementsFromContract(input, modules) {
  const raw = snapshot(input.coreContract);
  const contractResult = validateThemeContractObject(
    builtInLiteralRegistry,
    raw.source,
    { contractVersion: raw.contractVersion, entries: raw.entries },
    "validateThemeContract"
  );
  requireThat(contractResult.ok, "TX_CORE_REQUIREMENT", "$.coreContract");
  const contract = contractResult.value;
  const paths = [...new Set(modules.flatMap(moduleCorePaths))].sort(sortText);
  let experimental = false;
  const tokens = paths.map((path) => {
    const entry = contract.entries[path];
    requireThat(entry, "TX_CORE_REQUIREMENT", path, {
      issue: "core-public-token-required"
    });
    if (entry.lifecycle === "experimental") experimental = true;
    return {
      path,
      typeId: entry.typeId,
      lifecycle: entry.lifecycle,
      css: {
        publicVariable: publicCoreVariable(path),
        ...entry.typeId === "typography" ? {
          fields: Object.fromEntries(
            TYPOGRAPHY_FIELDS.map((field) => [
              field,
              `${publicCoreVariable(path)}-${field}`
            ])
          )
        } : {}
      },
      ...entry.lifecycle === "deprecated" ? {
        deprecated: {
          since: entry.deprecatedSince,
          ...entry.migration.kind === "replacement" ? { replacement: entry.migration.path } : { noReplacementReason: entry.migration.reason.detail }
        }
      } : {}
    };
  });
  return {
    contractVersion: "4.0.0",
    typeRegistryContentHash: builtInLiteralRegistry.typeRegistryContentHash,
    ...experimental ? { experimentalContractContentHash: hashThemeExtensionContent(contract) } : {},
    tokens
  };
}
function validateReference(module, path, token, value, modules, core) {
  var _a, _b, _c;
  const location = `${module.id}/${path}`;
  if (value.kind === "literal") return;
  if (value.kind === "core-ref") {
    const target2 = core.get(value.path);
    requireThat(
      target2 && moduleCorePaths(module).includes(value.path),
      "TX_REFERENCE_INVALID",
      location,
      { target: value.path, issue: "undeclared-core-reference" }
    );
    requireThat(target2.typeId === token.type, "TX_TYPE_MISMATCH", location, {
      target: value.path,
      expected: token.type,
      actual: target2.typeId
    });
    if (target2.lifecycle === "experimental")
      requireThat(
        (_b = (_a = module.core) == null ? void 0 : _a.experimental) == null ? void 0 : _b.includes(value.path),
        "TX_EXPERIMENTAL_OPT_IN",
        location,
        { target: value.path }
      );
    return;
  }
  const targetModule = modules.get(value.module);
  const target = targetModule == null ? void 0 : targetModule.tokens[value.path];
  requireThat(target, "TX_REFERENCE_INVALID", location, {
    target: `${value.module}/${value.path}`,
    issue: "target-missing"
  });
  requireThat(
    module.id === value.module || ((_c = module.dependencies) == null ? void 0 : _c.some((dep) => dep.id === value.module)) && target.visibility === "public",
    "TX_REFERENCE_INVALID",
    location,
    {
      target: `${value.module}/${value.path}`,
      issue: "dependency-or-public-required"
    }
  );
  requireThat(target.type === token.type, "TX_TYPE_MISMATCH", location, {
    expected: token.type,
    actual: target.type
  });
}
function checkCycles(modules, axes, overrides = {}) {
  const done = /* @__PURE__ */ new Set();
  for (const initialModule of modules.values()) {
    for (const initialPath of Object.keys(initialModule.tokens)) {
      let module = initialModule;
      let path = initialPath;
      const chain = [];
      const visiting = /* @__PURE__ */ new Set();
      for (; ; ) {
        const key = `${module.id}/${path}`;
        if (done.has(key)) break;
        requireThat(!visiting.has(key), "TX_CYCLE", key, {
          chain: [...chain, key],
          axes
        });
        visiting.add(key);
        chain.push(key);
        const value = overrides[key] ?? effectiveValue(module.tokens[path], axes);
        if (value.kind !== "module-ref") break;
        const target = modules.get(value.module);
        requireThat(target == null ? void 0 : target.tokens[value.path], "TX_REFERENCE_INVALID", key, {
          target: `${value.module}/${value.path}`
        });
        module = target;
        path = value.path;
      }
      for (const key of chain) done.add(key);
    }
  }
}
function safeEncoding(encoding, type) {
  if (type === "typography")
    exact(encoding, ["kind", "fields"], [], "$.encoding");
  else exact(encoding, ["kind", "value"], [], "$.encoding");
  const values = [];
  if (type === "typography") {
    requireThat(encoding.kind === "fields", "TX_CSS_ENCODING", "$.encoding");
    exact(encoding.fields, TYPOGRAPHY_FIELDS, [], "$.encoding.fields");
    values.push(...Object.values(encoding.fields));
  } else {
    requireThat(encoding.kind === "scalar", "TX_CSS_ENCODING", "$.encoding");
    values.push(encoding.value);
  }
  for (const value of values) {
    requireThat(
      typeof value === "string" && value.length > 0 && value.length <= 16384 && !/[<>\0]/.test(value),
      "TX_CSS_ENCODING",
      "$.encoding",
      { issue: "unsafe-or-empty-css" }
    );
    let quote = "", escaped = false, depth = 0;
    for (const c of value) {
      if (escaped) {
        escaped = false;
        continue;
      }
      if (c === "\\") {
        escaped = true;
        continue;
      }
      if (quote) {
        if (c === quote) quote = "";
        continue;
      }
      if (c === '"' || c === "'") {
        quote = c;
        continue;
      }
      requireThat(!/[;{}\n\r]/.test(c), "TX_CSS_ENCODING", "$.encoding");
      if (c === "(") depth++;
      if (c === ")") depth--;
      requireThat(depth >= 0, "TX_CSS_ENCODING", "$.encoding");
    }
    requireThat(
      !quote && !escaped && depth === 0,
      "TX_CSS_ENCODING",
      "$.encoding"
    );
  }
}
function valueDeclarations(module, path, token, value, modules, core, encoder) {
  var _a;
  const target = tokenCss(module, path, token.type);
  if (value.kind === "literal") {
    const literal = snapshot({
      kind: "literal",
      typeId: token.type,
      value: value.value
    });
    const encoded = unwrap(encoder.encode(literal));
    safeEncoding(encoded, token.type);
    requireThat(
      canonicalThemeExtensionJson(encoded) === canonicalThemeExtensionJson(unwrap(encoder.encode(literal))),
      "TX_CSS_ENCODING",
      `${module.id}/${path}`,
      { issue: "nondeterministic-encoder" }
    );
    return encoded.kind === "scalar" ? [[target.publicVariable, encoded.value]] : TYPOGRAPHY_FIELDS.map(
      (field) => [target.fields[field], encoded.fields[field]]
    );
  }
  const source = value.kind === "core-ref" ? (_a = core.get(value.path)) == null ? void 0 : _a.css : tokenCss(modules.get(value.module), value.path, token.type);
  requireThat(source, "TX_REFERENCE_INVALID", `${module.id}/${path}`);
  return token.type === "typography" ? TYPOGRAPHY_FIELDS.map(
    (field) => [target.fields[field], `var(${source.fields[field]})`]
  ) : [[target.publicVariable, `var(${source.publicVariable})`]];
}
function cssBlock(selector, declarations) {
  return `${selector} {
${declarations.map(([property, value]) => `  ${property}: ${value};`).join("\n")}
}
`;
}
function renderThemeExtensionCss(plan, encoder, dependencyModules = []) {
  var _a, _b, _c, _d;
  const modules = new Map(
    [...dependencyModules, ...plan.modules].map((module) => [
      module.definition.id,
      module.definition
    ])
  );
  const core = new Map(
    plan.coreRequirements.tokens.map((token) => [token.path, token])
  );
  const output = [];
  for (const module of plan.modules) {
    const selector = `:where([data-zx-extension~="${module.selectorKey}"])`;
    const base = Object.entries(module.definition.tokens).flatMap(
      ([path, token]) => valueDeclarations(
        module.definition,
        path,
        token,
        token.value,
        modules,
        core,
        encoder
      )
    );
    for (const [path, metric] of Object.entries(
      module.definition.displayMetrics ?? {}
    )) {
      const reference = displayMetricReference(module.definition, path, metric);
      const source = metric.source.module === "core" ? (_a = core.get(metric.source.path)) == null ? void 0 : _a.css : (() => {
        const owner = modules.get(metric.source.module);
        const token = owner == null ? void 0 : owner.tokens[metric.source.path];
        return owner && token ? tokenCss(owner, metric.source.path, token.type) : void 0;
      })();
      const variable = metric.source.field ? (_b = source == null ? void 0 : source.fields) == null ? void 0 : _b[metric.source.field] : source == null ? void 0 : source.publicVariable;
      requireThat(variable, "TX_DISPLAY_METRIC_INVALID", reference.id);
      base.push([reference.base.variable, `var(${variable})`]);
      base.push([reference.effective.variable, reference.base.ref]);
    }
    output.push(
      cssBlock(
        selector,
        [...base].sort(([a], [b]) => sortText(a, b))
      )
    );
    for (const [path, token] of Object.entries(module.definition.tokens)) {
      for (const axis of ((_c = token.conflictPolicy) == null ? void 0 : _c.axisOrder) ?? AXES) {
        for (const [axisValue, value] of Object.entries(
          ((_d = token.overrides) == null ? void 0 : _d[axis]) ?? {}
        ).sort(([a], [b]) => sortText(a, b))) {
          const declarations = valueDeclarations(
            module.definition,
            path,
            token,
            value,
            modules,
            core,
            encoder
          );
          output.push(
            cssBlock(
              `:where([data-zx-extension~="${module.selectorKey}"][data-zx-ext-axes~="${axis}-${axisValue}"])`,
              declarations
            )
          );
        }
      }
    }
  }
  const compiled = new Map(
    [...dependencyModules, ...plan.modules].map((module) => [
      module.definition.id,
      module
    ])
  );
  for (const adapter of plan.cssAdapters) {
    const gates = adapter.moduleIds.map((id) => `[data-zx-extension~="${compiled.get(id).selectorKey}"]`).join("");
    output.push(
      cssBlock(
        `[data-zx-theme-adapter="${adapter.selectorKey}"]${gates}`,
        adapter.declarations
      )
    );
  }
  return output.join("");
}
function buildPlan(input, warnings = []) {
  var _a, _b, _c, _d, _e, _f;
  exact(input.package, ["name", "version"], [], "$.package");
  requireThat(
    PACKAGE.test(input.package.name) && input.package.name.length <= 214 && parseVersion(input.package.version),
    "TX_INPUT_INVALID",
    "$.package"
  );
  requireThat(
    input.encoder.abi === "zx.theme-extension-css/1" && typeof input.encoder.encode === "function",
    "TX_CSS_ENCODING",
    "$.encoder"
  );
  requireThat(
    input.modules.length > 0 && input.modules.length <= 128,
    "TX_MODULE_INVALID",
    "$.modules"
  );
  checkRequirementsShape(input.coreRequirements);
  const own = input.modules.map(normalizeModule).sort((a, b) => sortText(a.id, b.id));
  const all = [
    ...(input.dependencyModules ?? []).map((module) => module.definition),
    ...own
  ];
  const modules = new Map(all.map((module) => [module.id, module]));
  requireThat(
    modules.size === all.length && new Set(all.map((module) => module.namespace)).size === all.length,
    "TX_MODULE_INVALID",
    "$.modules",
    { issue: "duplicate-id-or-namespace" }
  );
  const core = new Map(
    input.coreRequirements.tokens.map((token) => [token.path, token])
  );
  requireThat(
    canonicalThemeExtensionJson([...new Set(all.flatMap(moduleCorePaths))].sort(sortText)) === canonicalThemeExtensionJson([...core.keys()].sort(sortText)),
    "TX_CORE_REQUIREMENT",
    "$.coreRequirements",
    { issue: "exact-required-path-set" }
  );
  const variables = /* @__PURE__ */ new Set();
  for (const module of all) {
    for (const dependency of module.dependencies ?? []) {
      const target = modules.get(dependency.id);
      requireThat(
        target && target.version === dependency.version && (!dependency.contractHash || dependency.contractHash === moduleContractHash(target)),
        "TX_DEPENDENCY_INVALID",
        module.id,
        {
          dependency: dependency.id,
          issue: "exact-version-and-contract-required"
        }
      );
    }
    for (const [path, token] of Object.entries(module.tokens)) {
      for (const variable of cssVariables(tokenCss(module, path, token.type))) {
        requireThat(
          !variables.has(variable),
          "TX_CSS_COLLISION",
          `${module.id}/${path}`,
          { variable }
        );
        variables.add(variable);
      }
      for (const value of allValues(token))
        validateReference(module, path, token, value, modules, core);
      if ((_a = token.deprecated) == null ? void 0 : _a.replacement) {
        const { module: id, path: replacement } = token.deprecated.replacement;
        const target = (_b = modules.get(id)) == null ? void 0 : _b.tokens[replacement];
        requireThat(
          (target == null ? void 0 : target.visibility) === "public" && target.type === token.type && target.lifecycle !== "deprecated",
          "TX_REFERENCE_INVALID",
          `${module.id}/${path}`,
          { issue: "invalid-replacement" }
        );
      }
    }
    for (const [path, metric] of Object.entries(module.displayMetrics ?? {})) {
      const location = `${module.id}.${path}`;
      const source = metric.source;
      const target = source.module === "core" ? core.get(source.path) : (_c = modules.get(source.module)) == null ? void 0 : _c.tokens[source.path];
      requireThat(target, "TX_DISPLAY_METRIC_INVALID", location, {
        issue: "source-missing",
        source: `${source.module}/${source.path}`
      });
      if (source.module !== "core") {
        const token = target;
        requireThat(
          token.visibility === "public" && (source.module === module.id || ((_d = module.dependencies) == null ? void 0 : _d.some((dep) => dep.id === source.module))),
          "TX_DISPLAY_METRIC_INVALID",
          location,
          {
            issue: "public-dependency-required",
            source: `${source.module}/${source.path}`
          }
        );
      }
      const type = source.module === "core" ? target.typeId : target.type;
      const length = type === "dimension" || type === "typography" && Boolean(source.field);
      requireThat(
        metric.policy === "unitless-ratio" && type === "number" && !source.field || metric.policy !== "unitless-ratio" && length,
        "TX_DISPLAY_METRIC_INVALID",
        location,
        { issue: "source-policy-type-mismatch", type, policy: metric.policy }
      );
      requireThat(
        type === "typography" === Boolean(source.field),
        "TX_DISPLAY_METRIC_INVALID",
        location,
        { issue: "typography-field-required-only-for-typography" }
      );
      const ref = displayMetricReference(module, path, metric);
      for (const variable of [ref.base.variable, ref.effective.variable]) {
        requireThat(!variables.has(variable), "TX_CSS_COLLISION", location, {
          variable
        });
        variables.add(variable);
      }
    }
    for (const path of moduleCorePaths(module)) {
      const requirement = core.get(path);
      requireThat(requirement, "TX_CORE_REQUIREMENT", module.id, { path });
      if (requirement.lifecycle === "experimental")
        requireThat(
          (_f = (_e = module.core) == null ? void 0 : _e.experimental) == null ? void 0 : _f.includes(path),
          "TX_EXPERIMENTAL_OPT_IN",
          module.id,
          { path }
        );
      if (requirement.lifecycle === "deprecated")
        warnings.push({
          code: "TX_DEPRECATED",
          severity: "warning",
          path,
          moduleId: module.id,
          details: { deprecated: requirement.deprecated }
        });
    }
  }
  for (const axes of allSelections()) checkCycles(modules, axes);
  const baseModules = own.map((definition) => ({
    definition: {
      ...definition,
      dependencies: (definition.dependencies ?? []).map((dep) => ({
        ...dep,
        contractHash: moduleContractHash(modules.get(dep.id))
      }))
    },
    contractHash: moduleContractHash(definition),
    corePaths: moduleCorePaths(definition)
  }));
  const adapterSources = input.cssAdapters.map(normalizeAdapter).sort((a, b) => sortText(a.id, b.id));
  requireThat(
    new Set(adapterSources.map((adapter) => adapter.id)).size === adapterSources.length,
    "TX_ADAPTER_INVALID",
    "$.adapters",
    { issue: "duplicate-id" }
  );
  const planHash = hashThemeExtensionContent({
    schema: "zx.theme-extension-plan/1",
    package: input.package,
    modules: baseModules,
    coreRequirements: input.coreRequirements,
    dependencies: input.dependencies,
    cssAdapters: adapterSources,
    encoderAbi: input.encoder.abi
  });
  const cssAdapters = adapterSources.map(
    (adapter) => ({
      ...adapter,
      selectorKey: `a-${planHash.slice(7)}-${adapter.id}`,
      moduleIds: [
        ...new Set(adapter.mappings.map((mapping) => mapping.token.module))
      ].sort(sortText),
      declarations: adapter.mappings.map((mapping) => {
        const module = modules.get(mapping.token.module), token = module == null ? void 0 : module.tokens[mapping.token.path];
        requireThat(
          module && (token == null ? void 0 : token.visibility) === "public" && token.type !== "typography",
          "TX_ADAPTER_INVALID",
          adapter.id,
          {
            issue: "public-scalar-token-required",
            token: `${mapping.token.module}/${mapping.token.path}`
          }
        );
        return [
          mapping.property,
          `var(${tokenCss(module, mapping.token.path, token.type).publicVariable})`
        ];
      })
    })
  );
  return {
    schema: "zx.theme-extension-manifest/1",
    identity: {
      packageName: input.package.name,
      packageVersion: input.package.version,
      planHash
    },
    selectorSchema: "zx.theme-extension-selector/1",
    encoderAbi: input.encoder.abi,
    modules: baseModules.map((module) => ({
      ...module,
      selectorKey: `x-${planHash.slice(7)}-${module.definition.namespace}`
    })),
    coreRequirements: input.coreRequirements,
    dependencies: input.dependencies,
    publicTokens: own.flatMap(
      (module) => Object.entries(module.tokens).filter(([, token]) => token.visibility === "public").map(([path, token]) => tokenDescriptor(module, path, token))
    ),
    cssAdapters
  };
}
export {
  AXES as A,
  defineThemeCssAdapter as B,
  TYPOGRAPHY_FIELDS as T,
  hashThemeExtensionText as a,
  result as b,
  canonicalThemeExtensionJson as c,
  displayMetricReference as d,
  exact as e,
  requireThat as f,
  sortText as g,
  hashThemeExtensionContent as h,
  buildPlan as i,
  coreRequirementsFromContract as j,
  axisSelection as k,
  fail as l,
  cssVariables as m,
  normalizeAdapter as n,
  moduleContractHash as o,
  publicCoreVariable as p,
  normalizeValue as q,
  renderThemeExtensionCss as r,
  snapshot as s,
  tokenCss as t,
  unwrap as u,
  versionSatisfies as v,
  validateReference as w,
  valueDeclarations as x,
  checkCycles as y,
  defineThemeModule as z
};
