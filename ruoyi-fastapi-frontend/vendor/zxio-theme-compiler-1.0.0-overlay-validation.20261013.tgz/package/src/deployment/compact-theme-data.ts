import { Buffer } from 'node:buffer'

type EncodedThemeString =
  | string
  | readonly [number, string]
  | readonly ['h', number, string, string]
  | readonly ['i', number]

/** Lossless build-time interning; generated modules need no external decoder. */
export function compactThemeData(value: unknown): {
  strings: EncodedThemeString[]
  hashes: string[]
  shapes: number[][]
  data: unknown
} {
  const unique = new Set<string>()
  const collect = (value: unknown): void => {
    if (typeof value === 'string') unique.add(value)
    else if (Array.isArray(value)) value.forEach(collect)
    else if (value && typeof value === 'object')
      for (const [key, entry] of Object.entries(value)) {
        unique.add(key)
        collect(entry)
      }
  }
  collect(value)
  const strings = [...unique].sort()
  const hashes: string[] = []
  const hashIndexes = new Map<string, number>()
  const hashIndex = (base64: string): number => {
    let index = hashIndexes.get(base64)
    if (index === undefined) {
      index = hashes.length
      hashIndexes.set(base64, index)
      hashes.push(base64)
    }
    return index
  }
  const indexes = new Map(strings.map((text, index) => [text, index]))
  const shapes: number[][] = []
  const shapeIndexes = new Map<string, number>()
  const encode = (value: unknown): unknown => {
    if (typeof value === 'string') return indexes.get(value)
    if (typeof value === 'number') return [2, value]
    if (Array.isArray(value)) return [0, ...value.map(encode)]
    if (value && typeof value === 'object') {
      const keys = Object.keys(value).map((key) => indexes.get(key)!)
      const identity = keys.join(',')
      let shape = shapeIndexes.get(identity)
      if (shape === undefined) {
        shape = shapes.length
        shapes.push(keys)
        shapeIndexes.set(identity, shape)
      }
      return [shape + 3, ...Object.values(value).map(encode)]
    }
    return value
  }
  return {
    strings: strings.map((text, index) => {
      // Deployment SRI, hashed asset paths and manifest SHA-256 references
      // describe the same bytes. Store that digest once without changing text.
      const sri = /^sha256-([A-Za-z0-9+/]{43}=)$/.exec(text)
      if (sri && Buffer.from(sri[1]!, 'base64').toString('base64') === sri[1])
        return ['i', hashIndex(sri[1]!)] as const
      const digest = /[a-f0-9]{64}/.exec(text)
      if (digest)
        return [
          'h',
          hashIndex(Buffer.from(digest[0], 'hex').toString('base64')),
          text.slice(0, digest.index),
          text.slice(digest.index + 64),
        ] as const
      const previous = strings[index - 1] ?? ''
      let common = 0
      while (
        common < text.length &&
        common < previous.length &&
        text[common] === previous[common]
      )
        common++
      return common > 5 ? ([common, text.slice(common)] as const) : text
    }),
    hashes,
    shapes,
    data: encode(value),
  }
}

export function themeDataModule(value: unknown, named = false): string {
  const encoded = compactThemeData(value)
  const fields =
    named && value && typeof value === 'object'
      ? Object.keys(value).filter((key) => /^[a-zA-Z_$][\w$]*$/.test(key))
      : []
  // Decoder tables are initialization temporaries, not module exports or
  // closures retained for the lifetime of the application.
  return `const value=(()=>{const s=${JSON.stringify(
    encoded.strings
  )},h=${JSON.stringify(
    encoded.hashes
  )},x=h.map(v=>Array.from(atob(v),c=>c.charCodeAt(0).toString(16).padStart(2,'0')).join('')),shapes=${JSON.stringify(
    encoded.shapes
  )};for(let i=0;i<s.length;i++){const v=s[i];if(Array.isArray(v))s[i]=v[0]==='i'?'sha256-'+h[v[1]]:v[0]==='h'?v[2]+x[v[1]]+v[3]:s[i-1].slice(0,v[0])+v[1];}function decode(v){if(typeof v==='number')return s[v];if(!Array.isArray(v))return v;if(v[0]===2)return v[1];if(v[0]===0)return v.slice(1).map(decode);const o={},keys=shapes[v[0]-3];for(let i=0;i<keys.length;i++)Object.defineProperty(o,s[keys[i]],{value:decode(v[i+1]),enumerable:true,writable:true,configurable:true});return o}return decode(${JSON.stringify(
    encoded.data
  )});})();export default value;${fields
    .map((key) => `export const ${key}=value.${key};`)
    .join('')}`
}
