# Release notes

## 1.0.0

- Add the Factory Blue Theme v4 package (`industrial-blue`) with 162 deterministic
  variants. It carries the original industrial cobalt seeds that
  `@zxio/theme-factory-blue` shipped before its 2026-09-10 Navy Blue recolor.
- Use public elevation and material roles for tonal depth, inset glow, and
  colored panel shadows.
