import { createHash } from 'node:crypto'
import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  rmSync,
  symlinkSync,
  watch,
} from 'node:fs'
import { createRequire } from 'node:module'
import { tmpdir } from 'node:os'
import { basename, dirname, resolve } from 'node:path'
import { emitThemeDeployment } from '../deployment/emitter'
import { themeDataModule } from '../deployment/compact-theme-data'
import { resolveThemeAssetRequest } from './assets'

import type { FSWatcher } from 'node:fs'

import type { Plugin, ResolvedConfig, ViteDevServer } from 'vite'
import type { ThemeDeploymentOutput } from '../deployment/emitter'

export {
  compactThemeData,
  themeDataModule,
} from '../deployment/compact-theme-data'
export { resolveThemeAssetRequest } from './assets'
export { zxuiSourcePlugin } from './source'
export type { ZxuiSourcePluginOptions } from './source'
export type { ThemeAssetRequest } from './assets'
export type { ThemeDeploymentOutput } from '../deployment/emitter'

export interface ThemeDeploymentPackage {
  readonly packageName: string
  /** Optional application catalog assertion, checked before publishing assets. */
  readonly themeId?: string
}

export interface ThemeDeploymentPluginOptions {
  readonly packages: readonly (string | ThemeDeploymentPackage)[]
  /** Defaults to virtual:zxui-theme-deployment; exports ThemeDeploymentOutput. */
  readonly virtualId?: string
  /** Application-base-relative directory; defaults to zx-theme-assets. */
  readonly assetDirectory?: string
  /** Installed package resolution anchor; defaults to Vite root/package.json. */
  readonly resolveFrom?: string
  /** Explicit ZXUI source workspace. Only theme package public exports are read. */
  readonly workspaceRoot?: string
}

/** Verified raw theme assets for Vite dev/build, isolated per plugin instance. */
export function themeDeploymentPlugin(
  options: ThemeDeploymentPluginOptions
): Plugin {
  const packages = options.packages.map((item) =>
    typeof item === 'string' ? { packageName: item } : item
  )
  const assetDirectory = options.assetDirectory ?? 'zx-theme-assets'
  const virtualId = options.virtualId ?? 'virtual:zxui-theme-deployment'
  if (!/^virtual:[\w/-]+$/.test(virtualId))
    throw new Error('[zxui-theme] Invalid virtual module ID')
  if (!/^[\w-]+(?:\/[\w-]+)*$/.test(assetDirectory))
    throw new Error('[zxui-theme] Invalid asset directory')
  if (
    !packages.length ||
    packages.some(({ packageName }) => !/^@[\w.-]+\/[\w.-]+$/.test(packageName))
  )
    throw new Error('[zxui-theme] Expected scoped theme package names')
  const moduleId = `\0${virtualId}`
  let config: ResolvedConfig
  let temporary: string | undefined
  let outputDir: string
  let resolveFrom: string
  let deployment: ThemeDeploymentOutput
  let fingerprint: string | undefined
  let server: ViteDevServer | undefined
  let timer: ReturnType<typeof setTimeout> | undefined
  let watchers: FSWatcher[] = []
  let sources: {
    packageRoot: string
    manifestPath: string
    packagePath: string
  }[] = []

  function stopWatchers() {
    if (timer) clearTimeout(timer)
    timer = undefined
    for (const watcher of watchers) watcher.close()
    watchers = []
  }

  function dispose() {
    stopWatchers()
    server = undefined
    if (temporary) rmSync(temporary, { recursive: true, force: true })
    temporary = undefined
  }

  function watchSources() {
    stopWatchers()
    const directories = new Map<string, Set<string>>()
    const add = (file: string) => {
      const directory = dirname(file)
      const names = directories.get(directory) ?? new Set<string>()
      names.add(basename(file))
      directories.set(directory, names)
    }
    for (const source of sources) {
      add(source.packagePath)
      // Watch every ancestor of the public export, including its stable package
      // root. An atomic directory replacement must not orphan the watcher.
      let file = source.manifestPath
      while (file !== source.packageRoot) {
        add(file)
        file = dirname(file)
      }
    }
    for (const [directory, names] of directories) {
      if (!existsSync(directory)) continue
      watchers.push(
        watch(directory, (_event, name) => {
          if (name && !names.has(name.toString())) return
          if (timer) clearTimeout(timer)
          timer = setTimeout(refreshServer, 100)
        })
      )
    }
  }

  function refresh(): boolean {
    const digest = createHash('sha256')
    for (const [index, source] of sources.entries()) {
      const manifestBytes = readFileSync(source.manifestPath)
      const identity = JSON.parse(manifestBytes.toString('utf8')).identity
      const expected = packages[index]!
      if (
        identity?.packageName !== expected.packageName ||
        (expected.themeId !== undefined &&
          identity?.themeId !== expected.themeId)
      )
        throw new Error(
          `[zxui-theme] Registered manifest identity mismatch: ${expected.packageName}`
        )
      digest.update(manifestBytes).update(readFileSync(source.packagePath))
    }
    const nextFingerprint = digest.digest('hex')
    if (fingerprint === nextFingerprint) return false
    const result = emitThemeDeployment({
      packages: packages.map(({ packageName }) => packageName),
      resolveFrom,
      outputDir,
      assetBasePath: assetDirectory,
    })
    if (!result.ok)
      throw new Error(
        `[zxui-theme] Deployment failed: ${JSON.stringify(result.diagnostics)}`
      )
    deployment = result.value
    fingerprint = nextFingerprint
    return true
  }

  function refreshServer() {
    if (!server) return
    try {
      if (refresh()) {
        const module = server.moduleGraph.getModuleById(moduleId)
        if (module) server.moduleGraph.invalidateModule(module)
        server.ws.send({ type: 'full-reload' })
      }
    } catch (error) {
      // The emitter validates before replacing owned assets. Keep both the old
      // virtual module and its exact CSS bytes available after a failed rebuild.
      server.config.logger.error(
        `[zxui-theme] Theme refresh failed: ${String(error)}`
      )
    } finally {
      watchSources()
    }
  }

  return {
    name: 'zxui-theme-deployment',
    configResolved(resolved) {
      config = resolved
      temporary = mkdtempSync(resolve(realpathSync(tmpdir()), 'zx-theme-vite-'))
      outputDir = resolve(temporary, 'assets')
      try {
        resolveFrom = resolve(
          options.resolveFrom ?? resolve(config.root, 'package.json')
        )
        if (options.workspaceRoot) {
          resolveFrom = resolve(temporary, 'package.json')
          for (const { packageName } of packages) {
            if (!packageName.startsWith('@zxio/'))
              throw new Error(
                `[zxui-theme] Not a ZXUI workspace package: ${packageName}`
              )
            const source = resolve(
              options.workspaceRoot,
              'packages',
              packageName.slice('@zxio/'.length)
            )
            const metadata = JSON.parse(
              readFileSync(resolve(source, 'package.json'), 'utf8')
            )
            if (metadata.name !== packageName)
              throw new Error(
                `[zxui-theme] Workspace package identity mismatch: ${packageName}`
              )
            const target = resolve(temporary, 'node_modules', packageName)
            mkdirSync(dirname(target), { recursive: true })
            symlinkSync(source, target, 'junction')
          }
        }
        const requirePackage = createRequire(resolveFrom)
        sources = packages.map(({ packageName }) => {
          const packagePath = requirePackage.resolve(
            `${packageName}/package.json`
          )
          const manifestPath = requirePackage.resolve(
            `${packageName}/manifest.json`
          )
          return {
            packageRoot: dirname(packagePath),
            manifestPath,
            packagePath,
          }
        })
        refresh()
      } catch (error) {
        dispose()
        throw error
      }
    },
    buildStart() {
      if (config.command === 'build') refresh()
      for (const source of sources) {
        this.addWatchFile(source.manifestPath)
        this.addWatchFile(source.packagePath)
      }
    },
    resolveId(id) {
      if (id === virtualId || id === `/@id/__x00__${virtualId}`) return moduleId
    },
    load(id) {
      if (id === moduleId) return themeDataModule(deployment)
    },
    configureServer: {
      order: 'pre',
      handler(devServer) {
        server = devServer
        watchSources()
        devServer.middlewares.use((req, res, next) => {
          const request = req.url?.split('?')[0]
          if (request?.endsWith(`/@id/__x00__${virtualId}`)) refreshServer()
          if (req.method !== 'GET' && req.method !== 'HEAD') return next()
          const asset = resolveThemeAssetRequest({
            url: req.url ?? '',
            base: config.base,
            outputDir,
            assetDirectory,
          })
          if (!asset) return next()
          const bytes = readFileSync(asset.file)
          res.setHeader('Content-Type', asset.contentType)
          res.setHeader('Content-Length', bytes.byteLength)
          res.setHeader('Cache-Control', 'no-cache')
          res.end(req.method === 'HEAD' ? undefined : bytes)
        })
      },
    },
    generateBundle() {
      for (const name of readdirSync(outputDir)) {
        if (name.startsWith('.')) continue
        this.emitFile({
          type: 'asset',
          fileName: `${assetDirectory}/${name}`,
          source: readFileSync(resolve(outputDir, name)),
        })
      }
    },
    closeBundle() {
      if (!config.build.watch || config.command === 'serve') dispose()
    },
    closeWatcher: dispose,
  }
}
