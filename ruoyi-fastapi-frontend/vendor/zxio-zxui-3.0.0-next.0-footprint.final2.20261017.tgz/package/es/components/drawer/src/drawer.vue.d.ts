import { nextTick } from 'vue';
import type { FooterButtonConfig } from '@zxio/constants/form-modal';
import type { DrawerSlots } from './slots';
import type { ThemeRequiredPortalTarget } from '../../theme-provider';
import type { DrawerConfirmContext, DrawerDescriptionItem, DrawerPlacement } from './constants';
type __VLS_Slots = DrawerSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    visible: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => DrawerPlacement) | (((new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => DrawerPlacement)) | null)[], string, unknown, string, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, string, boolean>;
    mode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("./constants").DrawerMode) | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("./constants").DrawerMode)) | null)[], import("./constants").DrawerMode, unknown, string, boolean>;
    pushTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown, string, boolean>;
    mobileFallback: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("./constants").DrawerMobileFallback) | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("./constants").DrawerMobileFallback)) | null)[], import("./constants").DrawerMobileFallback, unknown, string, boolean>;
    resizable: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./constants").DrawerResizableOptions) | (() => boolean | import("./constants").DrawerResizableOptions) | (((new (...args: any[]) => boolean | import("./constants").DrawerResizableOptions) | (() => boolean | import("./constants").DrawerResizableOptions)) | null)[], unknown, unknown, boolean, boolean>;
    selectable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("./locale").DrawerMessages>) | (() => Partial<import("./locale").DrawerMessages>) | (((new (...args: any[]) => Partial<import("./locale").DrawerMessages>) | (() => Partial<import("./locale").DrawerMessages>)) | null)[], unknown, unknown, undefined, boolean>;
    closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    lockScroll: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => DrawerDescriptionItem[]) | (() => DrawerDescriptionItem[]) | (((new (...args: any[]) => DrawerDescriptionItem[]) | (() => DrawerDescriptionItem[])) | null)[], unknown, unknown, () => never[], boolean>;
    showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown, string, boolean>;
    loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    okText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    cancelText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    saveContinueText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (context: DrawerConfirmContext) => unknown) | (() => (context: DrawerConfirmContext) => unknown) | {
        (): (context: DrawerConfirmContext) => unknown;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (context: DrawerConfirmContext) => unknown) | (() => (context: DrawerConfirmContext) => unknown) | {
        (): (context: DrawerConfirmContext) => unknown;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./constants").DrawerDirtyGuard) | (() => boolean | import("./constants").DrawerDirtyGuard) | (((new (...args: any[]) => boolean | import("./constants").DrawerDirtyGuard) | (() => boolean | import("./constants").DrawerDirtyGuard)) | null)[], unknown, unknown, boolean, boolean>;
    handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null)) | null)[], unknown, unknown, null, boolean>;
    formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelSuffix: string;
            readonly inlineMessage: boolean;
            readonly statusIcon: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
            readonly model?: Record<string, any> | undefined;
            readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        readonly disabled: boolean;
        readonly inline: boolean;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
        readonly inlineMessage: boolean;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
        readonly labelSuffix: string;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
        readonly statusIcon: boolean;
        readonly hideRequiredAsterisk: boolean;
        readonly scrollToError: boolean;
    }> & Omit<Readonly<import("vue").ExtractPropTypes<{
        readonly model: ObjectConstructor;
        readonly rules: {
            readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly inline: BooleanConstructor;
        readonly inlineMessage: BooleanConstructor;
        readonly statusIcon: BooleanConstructor;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly hideRequiredAsterisk: BooleanConstructor;
        readonly scrollToError: BooleanConstructor;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
    }>> & {
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelSuffix: string;
            readonly inlineMessage: boolean;
            readonly statusIcon: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
            readonly model?: Record<string, any> | undefined;
            readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        readonly disabled: boolean;
        readonly inline: boolean;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
        readonly inlineMessage: boolean;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
        readonly labelSuffix: string;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
        readonly statusIcon: boolean;
        readonly hideRequiredAsterisk: boolean;
        readonly scrollToError: boolean;
    }> & Omit<Readonly<import("vue").ExtractPropTypes<{
        readonly model: ObjectConstructor;
        readonly rules: {
            readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly inline: BooleanConstructor;
        readonly inlineMessage: BooleanConstructor;
        readonly statusIcon: BooleanConstructor;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly hideRequiredAsterisk: BooleanConstructor;
        readonly scrollToError: BooleanConstructor;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
    }>> & {
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null)) | null)[], unknown, unknown, null, boolean>;
    formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => object) | (() => object | null) | (((new (...args: any[]) => object) | (() => object | null)) | null)[], unknown, unknown, null, boolean>;
    autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget)) | null)[], unknown, unknown, undefined, boolean>;
    enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | (((new (...args: any[]) => string[][]) | (() => string[][])) | null)[], unknown, unknown, undefined, boolean>;
    validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    prevText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    nextText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    submitText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | (((new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[])) | null)[], unknown, unknown, undefined, boolean>;
    buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], string, unknown, string, boolean>;
    beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    disableUserSelect: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    disabledWidthDrag: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    showHandleBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength)) | null)[], unknown, unknown, undefined, boolean>;
    headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown, undefined, boolean>;
    bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown, undefined, boolean>;
    footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown, undefined, boolean>;
    bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown, undefined, boolean>;
}>, {
    open: () => void;
    close: () => Promise<void>;
    toggleFullScreen: () => import("@zxio/keybindings/vue").ActionAdmission<void>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    resize: (size: number) => void;
    resetSize: () => Promise<void> | undefined;
    isFullScreen: Readonly<import("vue").Ref<boolean, boolean>>;
    confirmLoading: import("vue").ComputedRef<boolean>;
    isDirty: import("vue").ComputedRef<boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (val: boolean) => void;
    cancel: () => void;
    prev: (params: import("@zxio/constants/form-modal").StepEventParams) => void;
    next: (params: import("@zxio/constants/form-modal").StepEventParams) => void;
    continue: () => void;
    close: () => void;
    resize: (payload: import("./constants").DrawerResizePayload) => void;
    open: () => void;
    confirm: (_result?: any) => void;
    closed: () => void;
    back: () => void;
    saveStart: (_done: () => void, _fail: (error?: any) => void) => void;
    saveSuccess: (_data?: any) => void;
    saveError: (_error: any) => void;
    buttonClick: (_buttonKey: string) => void;
    "update:currentStep": (val: number) => void;
    "update:current-step": (val: number) => void;
    "fullscreen-change": (val: boolean) => void;
    opened: () => void;
    "dirty-change": (val: boolean) => void;
    "confirm-error": (_error?: any) => void;
    "update:visible": (val: boolean) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    visible: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => DrawerPlacement) | (((new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => DrawerPlacement)) | null)[], string, unknown, string, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, string, boolean>;
    mode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("./constants").DrawerMode) | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("./constants").DrawerMode)) | null)[], import("./constants").DrawerMode, unknown, string, boolean>;
    pushTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown, string, boolean>;
    mobileFallback: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("./constants").DrawerMobileFallback) | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("./constants").DrawerMobileFallback)) | null)[], import("./constants").DrawerMobileFallback, unknown, string, boolean>;
    resizable: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./constants").DrawerResizableOptions) | (() => boolean | import("./constants").DrawerResizableOptions) | (((new (...args: any[]) => boolean | import("./constants").DrawerResizableOptions) | (() => boolean | import("./constants").DrawerResizableOptions)) | null)[], unknown, unknown, boolean, boolean>;
    selectable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("./locale").DrawerMessages>) | (() => Partial<import("./locale").DrawerMessages>) | (((new (...args: any[]) => Partial<import("./locale").DrawerMessages>) | (() => Partial<import("./locale").DrawerMessages>)) | null)[], unknown, unknown, undefined, boolean>;
    closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    lockScroll: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => DrawerDescriptionItem[]) | (() => DrawerDescriptionItem[]) | (((new (...args: any[]) => DrawerDescriptionItem[]) | (() => DrawerDescriptionItem[])) | null)[], unknown, unknown, () => never[], boolean>;
    showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown, string, boolean>;
    loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    okText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    cancelText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    saveContinueText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (context: DrawerConfirmContext) => unknown) | (() => (context: DrawerConfirmContext) => unknown) | {
        (): (context: DrawerConfirmContext) => unknown;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (context: DrawerConfirmContext) => unknown) | (() => (context: DrawerConfirmContext) => unknown) | {
        (): (context: DrawerConfirmContext) => unknown;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./constants").DrawerDirtyGuard) | (() => boolean | import("./constants").DrawerDirtyGuard) | (((new (...args: any[]) => boolean | import("./constants").DrawerDirtyGuard) | (() => boolean | import("./constants").DrawerDirtyGuard)) | null)[], unknown, unknown, boolean, boolean>;
    handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null)) | null)[], unknown, unknown, null, boolean>;
    formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelSuffix: string;
            readonly inlineMessage: boolean;
            readonly statusIcon: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
            readonly model?: Record<string, any> | undefined;
            readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        readonly disabled: boolean;
        readonly inline: boolean;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
        readonly inlineMessage: boolean;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
        readonly labelSuffix: string;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
        readonly statusIcon: boolean;
        readonly hideRequiredAsterisk: boolean;
        readonly scrollToError: boolean;
    }> & Omit<Readonly<import("vue").ExtractPropTypes<{
        readonly model: ObjectConstructor;
        readonly rules: {
            readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly inline: BooleanConstructor;
        readonly inlineMessage: BooleanConstructor;
        readonly statusIcon: BooleanConstructor;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly hideRequiredAsterisk: BooleanConstructor;
        readonly scrollToError: BooleanConstructor;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
    }>> & {
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelSuffix: string;
            readonly inlineMessage: boolean;
            readonly statusIcon: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
            readonly model?: Record<string, any> | undefined;
            readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        readonly disabled: boolean;
        readonly inline: boolean;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
        readonly inlineMessage: boolean;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
        readonly labelSuffix: string;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
        readonly statusIcon: boolean;
        readonly hideRequiredAsterisk: boolean;
        readonly scrollToError: boolean;
    }> & Omit<Readonly<import("vue").ExtractPropTypes<{
        readonly model: ObjectConstructor;
        readonly rules: {
            readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly inline: BooleanConstructor;
        readonly inlineMessage: BooleanConstructor;
        readonly statusIcon: BooleanConstructor;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly hideRequiredAsterisk: BooleanConstructor;
        readonly scrollToError: BooleanConstructor;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
    }>> & {
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null)) | null)[], unknown, unknown, null, boolean>;
    formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => object) | (() => object | null) | (((new (...args: any[]) => object) | (() => object | null)) | null)[], unknown, unknown, null, boolean>;
    autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget)) | null)[], unknown, unknown, undefined, boolean>;
    enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | (((new (...args: any[]) => string[][]) | (() => string[][])) | null)[], unknown, unknown, undefined, boolean>;
    validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    prevText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    nextText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    submitText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | (((new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[])) | null)[], unknown, unknown, undefined, boolean>;
    buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], string, unknown, string, boolean>;
    beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    disableUserSelect: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    disabledWidthDrag: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    showHandleBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength)) | null)[], unknown, unknown, undefined, boolean>;
    headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown, undefined, boolean>;
    bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown, undefined, boolean>;
    footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown, undefined, boolean>;
    bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown, undefined, boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
    onCancel?: (() => any) | undefined;
    onPrev?: ((params: import("@zxio/constants/form-modal").StepEventParams) => any) | undefined;
    onNext?: ((params: import("@zxio/constants/form-modal").StepEventParams) => any) | undefined;
    onContinue?: (() => any) | undefined;
    onClose?: (() => any) | undefined;
    onResize?: ((payload: import("./constants").DrawerResizePayload) => any) | undefined;
    onOpen?: (() => any) | undefined;
    onConfirm?: ((_result?: any) => any) | undefined;
    onClosed?: (() => any) | undefined;
    onBack?: (() => any) | undefined;
    onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
    onSaveSuccess?: ((_data?: any) => any) | undefined;
    onSaveError?: ((_error: any) => any) | undefined;
    onButtonClick?: ((_buttonKey: string) => any) | undefined;
    "onUpdate:currentStep"?: ((val: number) => any) | undefined;
    "onUpdate:current-step"?: ((val: number) => any) | undefined;
    "onFullscreen-change"?: ((val: boolean) => any) | undefined;
    onOpened?: (() => any) | undefined;
    "onDirty-change"?: ((val: boolean) => any) | undefined;
    "onConfirm-error"?: ((_error?: any) => any) | undefined;
    "onUpdate:visible"?: ((val: boolean) => any) | undefined;
}>, {
    footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    title: string;
    size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
    mode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("./constants").DrawerMode) | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("./constants").DrawerMode)) | null)[], import("./constants").DrawerMode, unknown>;
    loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    appendTo: ThemeRequiredPortalTarget;
    placement: string;
    locale: Partial<import("./locale").DrawerMessages>;
    modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    visible: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown>;
    footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown>;
    headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding)) | null)[], unknown, unknown>;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    lockScroll: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    confirm: (context: DrawerConfirmContext) => unknown;
    paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength)) | null)[], unknown, unknown>;
    debounce: number;
    throttle: number;
    cancelText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    currentStep: number;
    totalSteps: number;
    prevText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    nextText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    submitText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    buttons: FooterButtonConfig[];
    buttonAlign: string;
    beforeSave: () => boolean | Promise<boolean>;
    afterSave: (success: boolean) => void;
    formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelSuffix: string;
            readonly inlineMessage: boolean;
            readonly statusIcon: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
            readonly model?: Record<string, any> | undefined;
            readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        readonly disabled: boolean;
        readonly inline: boolean;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
        readonly inlineMessage: boolean;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
        readonly labelSuffix: string;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
        readonly statusIcon: boolean;
        readonly hideRequiredAsterisk: boolean;
        readonly scrollToError: boolean;
    }> & Omit<Readonly<import("vue").ExtractPropTypes<{
        readonly model: ObjectConstructor;
        readonly rules: {
            readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly inline: BooleanConstructor;
        readonly inlineMessage: BooleanConstructor;
        readonly statusIcon: BooleanConstructor;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly hideRequiredAsterisk: BooleanConstructor;
        readonly scrollToError: BooleanConstructor;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
    }>> & {
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelSuffix: string;
            readonly inlineMessage: boolean;
            readonly statusIcon: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
            readonly model?: Record<string, any> | undefined;
            readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        readonly disabled: boolean;
        readonly inline: boolean;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
        readonly inlineMessage: boolean;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
        readonly labelSuffix: string;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
        readonly statusIcon: boolean;
        readonly hideRequiredAsterisk: boolean;
        readonly scrollToError: boolean;
    }> & Omit<Readonly<import("vue").ExtractPropTypes<{
        readonly model: ObjectConstructor;
        readonly rules: {
            readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
        readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
        readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
        readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly inline: BooleanConstructor;
        readonly inlineMessage: BooleanConstructor;
        readonly statusIcon: BooleanConstructor;
        readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly hideRequiredAsterisk: BooleanConstructor;
        readonly scrollToError: BooleanConstructor;
        readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
    }>> & {
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null)) | null)[], unknown, unknown>;
    preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loadingText: string;
    destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    subtitle: string;
    showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./constants").DrawerDirtyGuard) | (() => boolean | import("./constants").DrawerDirtyGuard) | (((new (...args: any[]) => boolean | import("./constants").DrawerDirtyGuard) | (() => boolean | import("./constants").DrawerDirtyGuard)) | null)[], unknown, unknown>;
    stepFields: string[][];
    validateStep: (step: number) => boolean | Promise<boolean>;
    titleTag: string;
    titleTagColor: string;
    descriptions: DrawerDescriptionItem[];
    showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    loadingBackground: string;
    okText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    saveContinueText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null)) | null)[], unknown, unknown>;
    formModel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => object) | (() => object | null) | (((new (...args: any[]) => object) | (() => object | null)) | null)[], unknown, unknown>;
    autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    scrollErrorOffset: number;
    bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown>;
    pushTarget: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>;
    mobileFallback: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("./constants").DrawerMobileFallback) | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("./constants").DrawerMobileFallback)) | null)[], import("./constants").DrawerMobileFallback, unknown>;
    resizable: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./constants").DrawerResizableOptions) | (() => boolean | import("./constants").DrawerResizableOptions) | (((new (...args: any[]) => boolean | import("./constants").DrawerResizableOptions) | (() => boolean | import("./constants").DrawerResizableOptions)) | null)[], unknown, unknown>;
    selectable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    disableUserSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    disabledWidthDrag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showHandleBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
