type __VLS_Slots = {
    prefix?(props: Record<string, unknown>): unknown;
    suffix?(props: Record<string, unknown>): unknown;
    'increase-icon'?(props: Record<string, unknown>): unknown;
    'decrease-icon'?(props: Record<string, unknown>): unknown;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown, "", boolean>;
    tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown, "right", boolean>;
    tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown, "hover", boolean>;
    modelValue: {
        type: import("vue").PropType<number | null>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    inputmode: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown, undefined, boolean>;
    align: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right"))[], unknown, unknown, "center", boolean>;
    disabledScientific: BooleanConstructor;
    ariaLabel: StringConstructor;
    id: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    step: import("element-plus/es/utils/index.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    stepStrictly: BooleanConstructor;
    max: import("element-plus/es/utils/index.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    min: import("element-plus/es/utils/index.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    readonly: BooleanConstructor;
    disabled: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    controls: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    controlsPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
    valueOnClear: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null))[], unknown, unknown, null, boolean>;
    name: StringConstructor;
    placeholder: StringConstructor;
    precision: {
        readonly type: import("vue").PropType<number>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    validateEvent: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}>, {
    focus: () => void | undefined;
    blur: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    input: (val: number | null | undefined) => void;
    "update:modelValue": (value: number | null | undefined) => void;
    change: (value: number | null | undefined, oldValue: number | null | undefined) => void;
    blur: (e: FocusEvent) => void;
    focus: (e: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown, "", boolean>;
    tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown, "right", boolean>;
    tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown, "hover", boolean>;
    modelValue: {
        type: import("vue").PropType<number | null>;
        required: false;
        validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    inputmode: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown, undefined, boolean>;
    align: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right"))[], unknown, unknown, "center", boolean>;
    disabledScientific: BooleanConstructor;
    ariaLabel: StringConstructor;
    id: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    step: import("element-plus/es/utils/index.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    stepStrictly: BooleanConstructor;
    max: import("element-plus/es/utils/index.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    min: import("element-plus/es/utils/index.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    readonly: BooleanConstructor;
    disabled: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    controls: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    controlsPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
    valueOnClear: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null))[], unknown, unknown, null, boolean>;
    name: StringConstructor;
    placeholder: StringConstructor;
    precision: {
        readonly type: import("vue").PropType<number>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    validateEvent: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
}>> & Readonly<{
    onInput?: ((val: number | null | undefined) => any) | undefined;
    "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
    onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
    onBlur?: ((e: FocusEvent) => any) | undefined;
    onFocus?: ((e: FocusEvent) => any) | undefined;
}>, {
    id: string;
    disabled: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    valueOnClear: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null))[], unknown, unknown>;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    readonly: boolean;
    validateEvent: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    min: number;
    max: number;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown>;
    align: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right"))[], unknown, unknown>;
    disabledScientific: boolean;
    step: number;
    stepStrictly: boolean;
    controls: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    controlsPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "right", unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
