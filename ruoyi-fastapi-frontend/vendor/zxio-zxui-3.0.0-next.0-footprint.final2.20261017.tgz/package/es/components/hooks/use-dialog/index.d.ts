import type { Ref } from 'vue';
import type { ZxDialogProps } from '../../dialog/src/props';
import type { DialogConfirmContext } from '../../dialog/src/constants';
import type { ZxDialogExpose } from '../../dialog/src/instance';
import type { ThemeRequiredPortalTarget } from '../../theme-provider';
type MaybeRef<T> = T | Ref<T>;
declare const OPTION_KEYS: readonly ["width", "height", "dialogSize", "subtitle", "showCancel", "showContinue", "showClose", "showFullScreen", "divider", "showBack", "fullscreenShortcut", "destroyOnClose", "modal", "modalClass", "closeOnClickModal", "closeOnPressEscape", "footer", "noTitle", "dialogStyle", "headerPadding", "bodyPadding", "footerPadding", "paddingInline", "bodyScroll", "draggable", "titleTag", "titleTagColor", "descriptions", "loading", "loadingType", "loadingText", "loadingBackground", "showSkeleton", "okText", "cancelText", "saveContinueText", "prevText", "nextText", "submitText", "locale", "formRef", "autoResetForm", "preValidate", "autoScrollToError", "scrollErrorOffset", "confirmOnDirty", "enableSteps", "currentStep", "totalSteps", "stepFields", "validateStep", "buttons", "buttonAlign", "beforeSave", "afterSave", "beforeClose", "debounce", "throttle", "appendTo"];
type BindableOptions = {
    [K in (typeof OPTION_KEYS)[number]]?: MaybeRef<ZxDialogProps[K] | undefined>;
};
export interface DialogOptions<T = Record<string, unknown>> extends BindableOptions {
    title?: MaybeRef<string | ((data: T) => string)>;
    /** @deprecated Use showClose. */
    closable?: MaybeRef<boolean>;
    /** @deprecated Use closeOnClickModal. */
    maskClosable?: MaybeRef<boolean>;
    /** Maps to the component's class attribute. */
    customClass?: MaybeRef<string | string[] | Record<string, boolean>>;
    defaultData?: () => T;
    dataTransform?: (rawData: unknown) => T;
    onConfirm?: (data: T, context: DialogConfirmContext) => unknown | Promise<unknown>;
    onConfirmError?: (error: unknown) => void;
    onCancel?: (data: T) => void;
    onContinue?: (data: T) => void;
    onOpen?: (data: T) => void;
    onOpened?: (data: T) => void;
    onClose?: (data: T) => void;
    onClosed?: (data: T) => void;
    onBack?: (data: T) => void;
    onBeforeClose?: (data: T) => boolean | Promise<boolean>;
    onDataChange?: (data: T, key?: keyof T) => void;
    onFullscreenChange?: (fullscreen: boolean) => void;
}
export interface DialogState<T = Record<string, unknown>> {
    visible: boolean;
    loading: boolean;
    disabled: boolean;
    title: string;
    isFullscreen: boolean;
    data: T;
}
export declare function useDialog<T extends Record<string, any> = Record<string, any>>(options?: DialogOptions<T>): {
    state: {
        visible: boolean;
        loading: boolean;
        disabled: boolean;
        title: string;
        isFullscreen: boolean;
        data: import("vue").UnwrapRef<T>;
    };
    visible: Ref<boolean, boolean>;
    loading: Ref<boolean, boolean>;
    disabled: Ref<boolean, boolean>;
    isFullscreen: Ref<boolean, boolean>;
    isDirty: import("vue").ComputedRef<boolean>;
    dialogRef: import("vue").ShallowRef<ZxDialogExpose | undefined, ZxDialogExpose | undefined>;
    dialogProps: import("vue").ComputedRef<{
        ref: import("vue").ShallowRef<ZxDialogExpose | undefined, ZxDialogExpose | undefined>;
        modelValue: boolean;
        title: string;
        showClose: boolean;
        closeOnClickModal: boolean;
        class: string | string[] | Record<string, boolean> | undefined;
        okLoading: boolean;
        okDisabled: boolean;
        formModel: import("vue").UnwrapRef<T>;
        confirm: (context: DialogConfirmContext) => Promise<unknown>;
        handleBeforeCancel: (() => boolean | Promise<boolean>) | undefined;
        footer?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        width?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined;
        height?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined;
        loading?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        appendTo?: ThemeRequiredPortalTarget | undefined;
        locale?: Partial<import("@zxio/zxui").DialogMessages> | undefined;
        modal?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        divider?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        bodyPadding?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding)) | null)[], unknown, unknown> | undefined;
        footerPadding?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding)) | null)[], unknown, unknown> | undefined;
        headerPadding?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding)) | null)[], unknown, unknown> | undefined;
        beforeClose?: import("../../dialog/src/constants").DialogBeforeClose | undefined;
        modalClass?: string | undefined;
        draggable?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        closeOnPressEscape?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        paddingInline?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength)) | null)[], unknown, unknown> | undefined;
        debounce?: number | undefined;
        throttle?: number | undefined;
        cancelText?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown> | undefined;
        enableSteps?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        currentStep?: number | undefined;
        totalSteps?: number | undefined;
        prevText?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown> | undefined;
        nextText?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown> | undefined;
        submitText?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown> | undefined;
        buttons?: import("@zxio/constants/form-modal").FooterButtonConfig[] | undefined;
        buttonAlign?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown> | undefined;
        beforeSave?: (() => boolean | Promise<boolean>) | undefined;
        afterSave?: ((success: boolean) => void) | undefined;
        formRef?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: Partial<{
                readonly disabled: boolean;
                readonly inline: boolean;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
                readonly inlineMessage: boolean;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
                readonly labelSuffix: string;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
                readonly statusIcon: boolean;
                readonly hideRequiredAsterisk: boolean;
                readonly scrollToError: boolean;
            }> & Omit<{
                readonly disabled: boolean;
                readonly inline: boolean;
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                readonly labelSuffix: string;
                readonly inlineMessage: boolean;
                readonly statusIcon: boolean;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly hideRequiredAsterisk: boolean;
                readonly scrollToError: boolean;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
                readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
                readonly model?: Record<string, any> | undefined;
                readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly model: ObjectConstructor;
                readonly rules: {
                    readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
                readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly inline: BooleanConstructor;
                readonly inlineMessage: BooleanConstructor;
                readonly statusIcon: BooleanConstructor;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly hideRequiredAsterisk: BooleanConstructor;
                readonly scrollToError: BooleanConstructor;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly disabled: BooleanConstructor;
            }>> & {
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                readonly disabled: boolean;
                readonly inline: boolean;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
                readonly inlineMessage: boolean;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
                readonly labelSuffix: string;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
                readonly statusIcon: boolean;
                readonly hideRequiredAsterisk: boolean;
                readonly scrollToError: boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T_1 extends string | ((...args: any) => any)>(source: T_1, cb: T_1 extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: Partial<{
                readonly disabled: boolean;
                readonly inline: boolean;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
                readonly inlineMessage: boolean;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
                readonly labelSuffix: string;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
                readonly statusIcon: boolean;
                readonly hideRequiredAsterisk: boolean;
                readonly scrollToError: boolean;
            }> & Omit<{
                readonly disabled: boolean;
                readonly inline: boolean;
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                readonly labelSuffix: string;
                readonly inlineMessage: boolean;
                readonly statusIcon: boolean;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly hideRequiredAsterisk: boolean;
                readonly scrollToError: boolean;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
                readonly size?: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown> | undefined;
                readonly model?: Record<string, any> | undefined;
                readonly rules?: Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>> | undefined;
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, "disabled" | "inline" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions">;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly model: ObjectConstructor;
                readonly rules: {
                    readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
                readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly inline: BooleanConstructor;
                readonly inlineMessage: BooleanConstructor;
                readonly statusIcon: BooleanConstructor;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly hideRequiredAsterisk: BooleanConstructor;
                readonly scrollToError: BooleanConstructor;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly disabled: BooleanConstructor;
            }>> & {
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                readonly disabled: boolean;
                readonly inline: boolean;
                readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
                readonly inlineMessage: boolean;
                readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
                readonly labelSuffix: string;
                readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
                readonly statusIcon: boolean;
                readonly hideRequiredAsterisk: boolean;
                readonly scrollToError: boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T_1 extends string | ((...args: any) => any)>(source: T_1, cb: T_1 extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            readonly disabled: boolean;
            readonly inline: boolean;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right" | "top", unknown>;
            readonly inlineMessage: boolean;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "left" | "right", unknown>;
            readonly labelSuffix: string;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropMergeType<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown>;
            readonly statusIcon: boolean;
            readonly hideRequiredAsterisk: boolean;
            readonly scrollToError: boolean;
        }> & Omit<Readonly<import("vue").ExtractPropTypes<{
            readonly model: ObjectConstructor;
            readonly rules: {
                readonly type: import("vue").PropType<Partial<Record<string, import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemRule>>>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly labelPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right" | "top", unknown, "right", boolean>;
            readonly requireAsteriskPosition: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "left" | "right", unknown, "left", boolean>;
            readonly labelWidth: import("element-plus/es/utils/index.mjs").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
            readonly labelSuffix: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly inline: BooleanConstructor;
            readonly inlineMessage: BooleanConstructor;
            readonly statusIcon: BooleanConstructor;
            readonly showMessage: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly validateOnRuleChange: import("element-plus/es/utils/index.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly hideRequiredAsterisk: BooleanConstructor;
            readonly scrollToError: BooleanConstructor;
            readonly scrollIntoViewOptions: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions) | ((new (...args: any[]) => boolean | ScrollIntoViewOptions) | (() => boolean | ScrollIntoViewOptions))[], unknown, unknown, true, boolean>;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: BooleanConstructor;
        }>> & {
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }, "disabled" | "inline" | "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "inlineMessage" | "statusIcon" | "showMessage" | "validateOnRuleChange" | "hideRequiredAsterisk" | "scrollToError" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null)) | null)[], unknown, unknown> | undefined;
        loadingText?: string | undefined;
        destroyOnClose?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        showFullScreen?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        fullscreenShortcut?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        subtitle?: string | undefined;
        showBack?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        confirmOnDirty?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("../../dialog/src/constants").DialogDirtyGuard) | (() => boolean | import("../../dialog/src/constants").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("../../dialog/src/constants").DialogDirtyGuard) | (() => boolean | import("../../dialog/src/constants").DialogDirtyGuard)) | null)[], unknown, unknown> | undefined;
        stepFields?: string[][] | undefined;
        validateStep?: ((step: number) => boolean | Promise<boolean>) | undefined;
        titleTag?: string | undefined;
        titleTagColor?: string | undefined;
        descriptions?: import("../../dialog/src/constants").DialogDescriptionItem[] | undefined;
        dialogSize?: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown> | undefined;
        showCancel?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        showContinue?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        noTitle?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        showSkeleton?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        loadingType?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown> | undefined;
        loadingBackground?: string | undefined;
        okText?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown> | undefined;
        saveContinueText?: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown> | undefined;
        dialogStyle?: import("vue").CSSProperties | undefined;
        autoResetForm?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        preValidate?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        autoScrollToError?: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
        scrollErrorOffset?: number | undefined;
        bodyScroll?: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown> | undefined;
    }>;
    dialogEvents: import("vue").ComputedRef<{
        'update:modelValue': (value: boolean) => void;
        'update:currentStep': (value: number) => void;
        cancel: () => void | undefined;
        continue: () => void | undefined;
        open: () => void | undefined;
        opened: () => void | undefined;
        close: () => void | undefined;
        closed: () => void;
        back: () => void | undefined;
        'confirm-error': (error: unknown) => void | undefined;
        'fullscreen-change': (value: boolean) => void;
    }>;
    open: (data?: Partial<T> | T, title?: string) => void;
    close: () => Promise<void>;
    updateField: <K extends keyof T>(key: K, value: T[K]) => void;
    updateData: (data: Partial<T>) => void;
    setData: (data: T) => void;
    setTitle: (title: string) => void;
    setLoading: (value: boolean) => void;
    setDisabled: (value: boolean) => void;
    resetData: () => void;
    updateOptions: (value: Partial<DialogOptions<T>>) => void;
    toggleFullscreen: () => void | undefined;
};
export type UseDialogReturn<T extends Record<string, any> = Record<string, any>> = ReturnType<typeof useDialog<T>>;
export {};
