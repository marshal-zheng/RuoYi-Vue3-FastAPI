import { type ContentWrapSlots, type SaveEventParams } from './props';
import type { ActionRef } from '@zxio/keybindings/core';
import type { FooterButtonConfig, StepEventParams } from '@zxio/constants/form-modal';
declare const _default: __VLS_WithSlots<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly saveAction: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => ActionRef<unknown>) | (() => ActionRef<unknown>) | (((new (...args: any[]) => ActionRef<unknown>) | (() => ActionRef<unknown>)) | null)[], unknown, unknown, undefined, boolean>;
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly message: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showFooter: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly isEdit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly footerFixed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly cancelText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly saveText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly prevText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly nextText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly submitText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly handleBack: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | (((new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[])) | null)[], unknown, unknown, undefined, boolean>;
    readonly buttonAlign: import("@zxio/shared").EpPropFinalized<StringConstructor, "left" | "center" | "right", unknown, "right", boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly readonly: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly validateForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableKeyboardShortcuts: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly scrollOffset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 10, boolean>;
    readonly transformOffset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly contentPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, undefined, boolean>;
    readonly footerMarginOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    readonly fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>, {
    submit: () => import("@zxio/keybindings/vue").ActionAdmission<unknown>;
    validate: () => Promise<boolean>;
    scrollToFirstError: () => void;
    setLoading: (value: boolean) => {
        readonly status: "rejected";
        readonly reason: "host-action-owned";
    } | undefined;
    setDisabled: (value: boolean) => {
        readonly status: "rejected";
        readonly reason: "host-action-owned";
    } | undefined;
    reset: () => {
        readonly status: "rejected";
        readonly reason: "host-action-owned";
    } | {
        readonly status: "rejected";
        readonly reason: "save-in-progress";
    } | undefined;
    prev: () => void;
    next: () => Promise<import("@zxio/keybindings/vue").ActionAdmission<unknown> | undefined>;
    cancel: () => import("@zxio/keybindings/vue").ActionAdmission<void>;
    isSubmitting: import("vue").ComputedRef<boolean>;
    isLoading: import("vue").ComputedRef<boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    save: (params: SaveEventParams) => void;
    cancel: () => void;
    prev: (params: StepEventParams) => void;
    next: (params: StepEventParams) => void;
    saveStart: (done: () => void, fail: (error?: any) => void) => void;
    saveSuccess: (data?: any) => void;
    saveError: (error: any) => void;
    buttonClick: (buttonKey: string) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly saveAction: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => ActionRef<unknown>) | (() => ActionRef<unknown>) | (((new (...args: any[]) => ActionRef<unknown>) | (() => ActionRef<unknown>)) | null)[], unknown, unknown, undefined, boolean>;
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly message: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showFooter: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly isEdit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly footerFixed: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly cancelText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly saveText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly prevText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly nextText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly submitText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly handleBack: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | (((new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[])) | null)[], unknown, unknown, undefined, boolean>;
    readonly buttonAlign: import("@zxio/shared").EpPropFinalized<StringConstructor, "left" | "center" | "right", unknown, "right", boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly readonly: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly validateForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => any) | (() => any) | {
        (): any;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableKeyboardShortcuts: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly scrollOffset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 10, boolean>;
    readonly transformOffset: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly contentPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, undefined, boolean>;
    readonly footerMarginOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    readonly fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>> & Readonly<{
    onSave?: ((params: SaveEventParams) => any) | undefined;
    onCancel?: (() => any) | undefined;
    onPrev?: ((params: StepEventParams) => any) | undefined;
    onNext?: ((params: StepEventParams) => any) | undefined;
    onSaveStart?: ((done: () => void, fail: (error?: any) => void) => any) | undefined;
    onSaveSuccess?: ((data?: any) => any) | undefined;
    onSaveError?: ((error: any) => any) | undefined;
    onButtonClick?: ((buttonKey: string) => any) | undefined;
}>, {
    readonly title: string;
    readonly fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly message: string;
    readonly debounce: number;
    readonly readonly: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly throttle: number;
    readonly saveAction: ActionRef<unknown>;
    readonly showFooter: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly isEdit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly footerFixed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly cancelText: string;
    readonly saveText: string;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: string;
    readonly nextText: string;
    readonly submitText: string;
    readonly handleBack: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly buttons: FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<StringConstructor, "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly validateForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly enableKeyboardShortcuts: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollOffset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
    readonly transformOffset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly contentPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
    readonly footerMarginOffset: number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, ContentWrapSlots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
