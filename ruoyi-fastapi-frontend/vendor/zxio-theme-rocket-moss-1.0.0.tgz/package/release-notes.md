# Release notes

## 1.0.0

- Add the Rocket Moss Theme v4 package with 162 deterministic variants.
- Anchor chrome to a screen-safe reconstruction of Rocket Force 07 墨绿.
  Khaki is the glow material at 0.55 intensity. Light paper is khaki-tinted;
  dark canvas stays in the moss family at command-console depth.
