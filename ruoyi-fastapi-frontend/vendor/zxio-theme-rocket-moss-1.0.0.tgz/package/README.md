# @zxio/theme-rocket-moss

Rocket Moss is a PLA Rocket Force 07-series 墨绿 Theme v4 package. The
coat color matches missile-body green; khaki (卡其) is the glow seed from
the neighbouring service shirt. This is not the ceremonial orange-yellow
flag bar.

Run `pnpm -C packages/theme-rocket-moss build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
