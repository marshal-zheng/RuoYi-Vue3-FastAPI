# Release notes

## 1.0.0

- Add the Factory Blue Theme v4 package with 162 deterministic variants.
- Use public elevation and material roles for tonal depth, inset glow, and
  colored panel shadows.
- 2026-09-10 recolor to Navy Blue (package and theme id unchanged): the
  saturated cobalt canvas (#081B37) and accent (#296BF5) are replaced by a
  desaturated Sea Blue canvas (#16202E), naval blue light accent (#1F4F8C),
  lifted Intermediate Blue dark accent (#3B78B3), instrument-cyan glow at 0.6
  intensity, brand-tinted hairlines, wider dark surface steps, and lifted
  dark-mode status colors. Docs preset labels now read "Navy Blue / 海军蓝".
