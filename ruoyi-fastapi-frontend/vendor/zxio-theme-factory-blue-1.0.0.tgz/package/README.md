# @zxio/theme-factory-blue

Navy Blue is a naval steel-blue Theme v4 package that keeps its historical
`factory-blue` package and theme id. It expresses tinted depth, a faint
instrument-cyan edge glow, and colored panel elevation exclusively through the
public elevation and material contract.

The palette is anchored to naval standards: a Sea Blue / Deck Blue canvas, a
light accent between Pantone 289 C and Yale Blue, FS 35164 Intermediate Blue
lifted for dark-mode links, Light Gull Gray paper in light mode, and the
Astro UXDS / US Navy status scale for signal colors.

Run `pnpm -C packages/theme-factory-blue build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
