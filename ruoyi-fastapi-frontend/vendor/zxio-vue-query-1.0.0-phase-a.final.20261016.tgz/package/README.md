# @zxio/vue-query

Optional native TanStack Vue Query v5 helpers. Install `vue` and `@tanstack/vue-query` (at least 5.92.5), and install the native `VueQueryPlugin` once in your application. The package has no HTTP client, component runtime, styles or second cache. `@zxio/zxui` is an optional type peer for `./ui`.

```ts
import { invalidateQueryGroups } from '@zxio/vue-query/core'
import { useQuerySelect } from '@zxio/vue-query/ui'
// The root entry is equivalent to ./core.
```

`invalidateQueryGroups(client, filters)` accepts plain native filters, cancels their union, then invalidates that union once and refetches active queries. Empty filters do nothing. Inactive and disabled matches are also marked stale. Its promise does not guarantee that paused or failed reads are synchronized. Default business effects should target the resource root within the captured application scope; narrow them only after measuring cost and proving all affected variants are covered.

`useQuerySelect(options, { active?, queryClient? })` must run synchronously in component setup. Supply the same native options/ref/getter used by `useQuery` or `useQueries`. It returns the native `query`, computed `selectProps`, `selectEvents`, `ensureFresh()` and `refresh()`. Bind the props and events to `ZxSelect`. Options must resolve to an option array; arbitrary field mapping and response parsing belong to the business factory.

The binding preserves native `enabled`, including getters returning core callbacks; `active` and KeepAlive can only further disable this observer. `ensureFresh` checks the current observer's enabled/stale result; `refresh` explicitly revalidates with `cancelRefetch:false` and `throwOnError:true`. Both respect skipToken and current conditions. Events catch errors; imperative calls reject on read failure. A shared subscriber's unmount never explicitly cancels another subscriber's read.

`selectProps` provides readonly options plus loading, refreshing, error and paused. It does not infer keyword, empty-state wording or selected-value validity. A domain selector owns search parameters and the `empty`/`error` slots; a missing option in a partial result is not evidence of deletion. Keep selection and editing drafts outside cached data.

HTTP consumers can independently use `queryRequest`/`isQueryRequest` from `@zxio/http`. Native `fetchQuery` waits for data meeting the factory's staleTime policy; `ensureQueryData` can immediately return stale cached data, and `revalidateIfStale` only starts background work. Business imperative read functions must check conditions before either API.

See [Chinese guide](../../docs/zh-CN/guide/vue-query.md) and [English guide](../../docs/en-US/guide/vue-query.md) for composition examples.
