import { ComputedRef, MaybeRef, MaybeRefOrGetter, Ref } from 'vue';
import { DefaultError, QueryClient, QueryKey, UseQueryOptions, UseQueryReturnType } from '@tanstack/vue-query';
import { SelectOption } from '@zxio/zxui';
export interface QuerySelectConfig {
    active?: MaybeRefOrGetter<boolean>;
    queryClient?: QueryClient;
}
export interface QuerySelectProps<TOptions extends readonly SelectOption[], TError> {
    options: TOptions | readonly [];
    loading: boolean;
    refreshing: boolean;
    error: TError | null;
    paused: boolean;
}
export interface QuerySelectBinding<TOptions extends readonly SelectOption[], TError> {
    query: UseQueryReturnType<TOptions, TError>;
    selectProps: ComputedRef<QuerySelectProps<TOptions, TError>>;
    selectEvents: {
        'visible-change': (visible: boolean) => void;
        retry: () => void;
    };
    ensureFresh: () => Promise<void>;
    refresh: () => Promise<void>;
}
type MappedQuerySelectOptions<TQueryFnData, TError, TData, TQueryKey extends QueryKey> = MaybeRefOrGetter<Exclude<UseQueryOptions<TQueryFnData, TError, TData, TQueryFnData, TQueryKey>, Ref> & {
    select: MaybeRef<(data: TQueryFnData) => TData>;
}>;
/** Bind native Vue Query options to ZxSelect; query policy and option mapping stay in the caller. */
export declare function useQuerySelect<TQueryFnData extends readonly SelectOption[], TError = DefaultError, TData extends readonly SelectOption[] = TQueryFnData, TQueryKey extends QueryKey = QueryKey>(options: MaybeRefOrGetter<UseQueryOptions<TQueryFnData, TError, TData, TQueryFnData, TQueryKey>>, config?: QuerySelectConfig): QuerySelectBinding<TData, TError>;
export declare function useQuerySelect<TQueryFnData, TError = DefaultError, TData extends readonly SelectOption[] = readonly SelectOption[], TQueryKey extends QueryKey = QueryKey>(options: MappedQuerySelectOptions<TQueryFnData, TError, TData, TQueryKey>, config?: QuerySelectConfig): QuerySelectBinding<TData, TError>;
export {};
