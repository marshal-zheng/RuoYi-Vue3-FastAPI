"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const vue = require("vue");
const vueQuery = require("@tanstack/vue-query");
const EMPTY_OPTIONS = Object.freeze([]);
function useQuerySelect(options, config = {}) {
  if (!vue.getCurrentInstance()) {
    throw new Error(
      "useQuerySelect must be called synchronously inside setup()."
    );
  }
  const client = config.queryClient ?? vueQuery.useQueryClient();
  const activated = vue.ref(true);
  const active = vue.computed(
    () => activated.value && vue.toValue(config.active ?? true)
  );
  const currentOptions = vue.computed(() => vue.unref(vue.toValue(options)));
  const gatedOptions = vue.computed(
    () => active.value ? currentOptions.value : { ...currentOptions.value, enabled: false }
  );
  const query = vueQuery.useQuery(
    gatedOptions,
    client
  );
  const execute = async (onlyStale) => {
    await vue.nextTick();
    if (!active.value || vue.unref(currentOptions.value.queryFn) === vueQuery.skipToken || !query.isEnabled.value)
      return;
    if (onlyStale && !query.isStale.value) return;
    await query.refetch({ cancelRefetch: false, throwOnError: true });
  };
  const ensureFresh = () => execute(true);
  const refresh = () => execute(false);
  const fromEvent = (action) => {
    action().catch(() => {
    });
  };
  vue.onActivated(() => {
    const wasDeactivated = !activated.value;
    activated.value = true;
    if (wasDeactivated) fromEvent(ensureFresh);
  });
  vue.onDeactivated(() => {
    activated.value = false;
  });
  const selectProps = vue.computed(() => ({
    options: query.data.value ?? EMPTY_OPTIONS,
    loading: query.isLoading.value,
    refreshing: query.isFetching.value && query.data.value !== void 0,
    error: vueQuery.isCancelledError(query.error.value) ? null : query.error.value,
    paused: query.fetchStatus.value === "paused"
  }));
  return {
    query,
    selectProps,
    selectEvents: {
      "visible-change": (visible) => {
        if (visible) fromEvent(ensureFresh);
      },
      retry: () => fromEvent(refresh)
    },
    ensureFresh,
    refresh
  };
}
exports.useQuerySelect = useQuerySelect;
