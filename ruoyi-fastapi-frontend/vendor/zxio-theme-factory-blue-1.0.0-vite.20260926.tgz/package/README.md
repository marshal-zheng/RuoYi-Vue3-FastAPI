# @zxio/theme-factory-blue

Steel Blue is a desaturated blue Theme v4 package that keeps its historical
`factory-blue` package and theme id. It expresses tinted depth, a faint
cyan edge glow, and colored panel elevation exclusively through the public
elevation and material contract.

The dark canvas is a sea blue, the light accent sits between #0C2340 and
#00356B, the dark accent is a lifted intermediate blue, light mode uses cool
gray paper, and signal colors are green, amber, red, and cyan.

Run `pnpm -C packages/theme-factory-blue build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
