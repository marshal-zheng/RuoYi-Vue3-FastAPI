import {
  DASHBOARD_SCHEMA_VERSION,
  cloneDashboardJson,
  collectDashboardJsonIssues,
  isDashboardPlainObject,
} from '../schema'
import {
  hasBlockingDashboardIssues,
  validateDashboardDocument,
} from '../validation'

import type {
  DashboardDocument,
  DashboardJsonObject,
  DashboardPanel,
} from '../schema'
import type { DashboardSchemaIssue } from '../validation'
import type {
  DashboardMigrationOptions,
  DashboardMigrationReport,
  DashboardMigrationResult,
  DashboardMigrationStep,
} from './types'

export function migrateDashboardDocument(
  input: unknown,
  options: DashboardMigrationOptions = {}
): DashboardMigrationResult {
  const currentSchemaVersion =
    options.currentSchemaVersion ?? DASHBOARD_SCHEMA_VERSION
  const initialVersion = readSchemaVersion(input)
  const report = createEmptyReport(initialVersion ?? 0, currentSchemaVersion)
  const issues: DashboardSchemaIssue[] = []

  if (!Number.isInteger(currentSchemaVersion) || currentSchemaVersion <= 0) {
    addBlocking(report, issues, {
      severity: 'error',
      code: 'invalid_schema_version',
      message: 'currentSchemaVersion must be a positive integer.',
      path: '/schemaVersion',
    })
    return { report, issues }
  }

  if (!isDashboardPlainObject(input)) {
    addBlocking(report, issues, {
      severity: 'error',
      code: 'invalid_document',
      message:
        'Dashboard document must be a plain JSON object before migration.',
      path: '',
    })
    return { report, issues }
  }

  if (!Number.isInteger(initialVersion) || (initialVersion as number) <= 0) {
    addBlocking(report, issues, {
      severity: 'error',
      code: 'invalid_schema_version',
      message: 'schemaVersion must be a positive integer before migration.',
      path: '/schemaVersion',
    })
    return { report, issues }
  }

  if ((initialVersion as number) > currentSchemaVersion) {
    addBlocking(report, issues, {
      severity: 'error',
      code: 'unsupported_schema_version',
      message: `schemaVersion ${initialVersion} is newer than supported version ${currentSchemaVersion}.`,
      path: '/schemaVersion',
    })
    return { report, issues }
  }

  const jsonIssues = collectDashboardJsonIssues(input, '', { phase: 'import' })
  if (hasBlockingDashboardIssues(jsonIssues)) {
    jsonIssues.forEach((issue) => addBlocking(report, issues, issue))
    return { report, issues }
  }
  jsonIssues.forEach((issue) => addWarning(report, issues, issue))

  let document = cloneDashboardJson(input as DashboardJsonObject)
  let schemaVersion = initialVersion as number

  while (schemaVersion < currentSchemaVersion) {
    const step =
      findMigrationStep(schemaVersion, options.steps ?? []) ??
      (schemaVersion === 1
        ? {
            fromVersion: 1,
            toVersion: 2,
            summary:
              'Enable optional responsive layouts and grouping; preserve panel data',
            migrate: (document: DashboardJsonObject) => document,
          }
        : undefined)

    if (!step) {
      addBlocking(report, issues, {
        severity: 'error',
        code: 'migration_required',
        message: `No migration step found from schemaVersion ${schemaVersion}.`,
        path: '/schemaVersion',
        migratable: true,
      })
      return { report, issues }
    }

    const stepValidation = validateMigrationStep(step)
    if (stepValidation) {
      addBlocking(report, issues, stepValidation)
      return { report, issues }
    }

    try {
      const context = {
        currentSchemaVersion,
        addWarning: (issue: DashboardSchemaIssue) =>
          addWarning(report, issues, issue),
        addBlockingIssue: (issue: DashboardSchemaIssue) =>
          addBlocking(report, issues, issue),
      }
      const migrated = step.migrate(cloneDashboardJson(document), context)
      if (!isDashboardPlainObject(migrated)) {
        addBlocking(report, issues, {
          severity: 'error',
          code: 'invalid_migration_step',
          message: 'Migration step must return a JSON object.',
          path: '/schemaVersion',
        })
        return { report, issues }
      }

      document = {
        ...cloneDashboardJson(migrated),
        schemaVersion: step.toVersion,
      }
      schemaVersion = step.toVersion
      report.steps.push({
        fromVersion: step.fromVersion,
        toVersion: step.toVersion,
        summary: step.summary,
      })
      report.finalSchemaVersion = schemaVersion
    } catch (error) {
      addBlocking(report, issues, {
        severity: 'error',
        code: 'invalid_migration_step',
        message:
          error instanceof Error
            ? error.message
            : 'Migration step failed with an unknown error.',
        path: '/schemaVersion',
      })
      return { report, issues }
    }
  }

  applyWidgetMigrations(document, report, issues, options)

  if (hasBlockingDashboardIssues(report.blockingIssues)) {
    return { report, issues }
  }

  const validation = validateDashboardDocument(document, {
    phase: 'import',
    currentSchemaVersion,
    knownWidgets: options.knownWidgets,
  })
  validation.issues.forEach((issue) => {
    if (issue.severity === 'error') {
      addBlocking(report, issues, issue)
    } else {
      addWarning(report, issues, issue)
    }
  })

  if (hasBlockingDashboardIssues(report.blockingIssues)) {
    return { report, issues }
  }

  return {
    document: document as unknown as DashboardDocument,
    report,
    issues,
  }
}

function applyWidgetMigrations(
  document: DashboardJsonObject,
  report: DashboardMigrationReport,
  issues: DashboardSchemaIssue[],
  options: DashboardMigrationOptions
): void {
  if (!Array.isArray(document.panels)) return

  const pluginVersions = isDashboardPlainObject(document.pluginVersions)
    ? document.pluginVersions
    : {}
  const widgetMigrators = options.widgetMigrators
  const knownWidgets =
    options.knownWidgets === undefined
      ? undefined
      : new Set(Array.from(options.knownWidgets))

  document.panels = document.panels.map((panel, index) => {
    if (!isDashboardPlainObject(panel)) return panel

    const widget = panel.widget
    const id = panel.id
    if (typeof widget !== 'string' || typeof id !== 'string') return panel

    const fromVersion =
      typeof pluginVersions[widget] === 'string'
        ? (pluginVersions[widget] as string)
        : undefined

    if (!fromVersion) {
      addWarning(report, issues, {
        severity: 'warn',
        code: 'missing_widget_version',
        message: `pluginVersions is missing a version for widget "${widget}".`,
        path: `/panels/${index}/widget`,
        migratable: true,
      })
    }

    if (knownWidgets && !knownWidgets.has(widget)) {
      addWarning(report, issues, {
        severity: 'warn',
        code: 'unresolved_widget',
        message: `Widget "${widget}" is not registered in the current host.`,
        path: `/panels/${index}/widget`,
      })
    }

    const migrator = widgetMigrators?.[widget]
    if (!migrator) {
      if (widgetMigrators) {
        addWarning(report, issues, {
          severity: 'warn',
          code: 'unresolved_widget',
          message: `No widget migrator is available for "${widget}".`,
          path: `/panels/${index}/widget`,
          migratable: true,
        })
      }
      return panel
    }

    const toVersion = migrator.targetVersion
    if (toVersion && fromVersion === toVersion) {
      report.widgetMigrations.push({
        panelId: id,
        widget,
        fromVersion,
        toVersion,
        changed: false,
      })
      return panel
    }

    const before = cloneDashboardJson(panel)
    try {
      const migrated = migrator.migratePanel(
        panel as unknown as DashboardPanel,
        {
          widget,
          fromVersion,
          toVersion,
          documentSchemaVersion:
            typeof document.schemaVersion === 'number'
              ? document.schemaVersion
              : DASHBOARD_SCHEMA_VERSION,
        }
      )
      const migratedIssues = collectDashboardJsonIssues(
        migrated,
        `/panels/${index}`,
        {
          phase: 'import',
        }
      )
      if (hasBlockingDashboardIssues(migratedIssues)) {
        migratedIssues.forEach((issue) => addBlocking(report, issues, issue))
        return panel
      }

      const after = cloneDashboardJson(
        migrated as unknown as DashboardJsonObject
      )
      const changed = JSON.stringify(before) !== JSON.stringify(after)
      report.widgetMigrations.push({
        panelId: id,
        widget,
        fromVersion,
        toVersion,
        changed,
      })

      if (toVersion) {
        document.pluginVersions = {
          ...pluginVersions,
          [widget]: toVersion,
        }
      }

      return after
    } catch (error) {
      addBlocking(report, issues, {
        severity: 'error',
        code: 'invalid_migration_step',
        message:
          error instanceof Error
            ? error.message
            : `Widget migrator for "${widget}" failed.`,
        path: `/panels/${index}`,
      })
      return panel
    }
  }) as DashboardJsonObject[]
}

function validateMigrationStep(
  step: DashboardMigrationStep
): DashboardSchemaIssue | undefined {
  if (
    !Number.isInteger(step.fromVersion) ||
    !Number.isInteger(step.toVersion) ||
    step.fromVersion <= 0 ||
    step.toVersion <= step.fromVersion
  ) {
    return {
      severity: 'error',
      code: 'invalid_migration_step',
      message: 'Migration steps must use positive increasing integer versions.',
      path: '/schemaVersion',
    }
  }

  if (typeof step.summary !== 'string' || step.summary.trim().length === 0) {
    return {
      severity: 'error',
      code: 'invalid_migration_step',
      message: 'Migration steps must include a summary.',
      path: '/schemaVersion',
    }
  }

  return undefined
}

function findMigrationStep(
  fromVersion: number,
  steps: DashboardMigrationStep[]
): DashboardMigrationStep | undefined {
  return steps
    .filter((step) => step.fromVersion === fromVersion)
    .sort((a, b) => a.toVersion - b.toVersion)[0]
}

function readSchemaVersion(input: unknown): number | undefined {
  if (!isDashboardPlainObject(input)) return undefined
  return typeof input.schemaVersion === 'number'
    ? input.schemaVersion
    : undefined
}

function createEmptyReport(
  fromSchemaVersion: number,
  toSchemaVersion: number
): DashboardMigrationReport {
  return {
    fromSchemaVersion,
    toSchemaVersion,
    finalSchemaVersion: fromSchemaVersion,
    steps: [],
    widgetMigrations: [],
    warnings: [],
    blockingIssues: [],
  }
}

function addWarning(
  report: DashboardMigrationReport,
  issues: DashboardSchemaIssue[],
  issue: DashboardSchemaIssue
): void {
  report.warnings.push(issue)
  issues.push(issue)
}

function addBlocking(
  report: DashboardMigrationReport,
  issues: DashboardSchemaIssue[],
  issue: DashboardSchemaIssue
): void {
  report.blockingIssues.push(issue)
  issues.push(issue)
}
