/** One observer per renderer; mounted content is retained to preserve widget state. */
export function createDashboardContentVisibility() {
  const pending = new Map<Element, () => void>()
  let observer: IntersectionObserver | undefined
  return {
    observe(element: Element, reveal: () => void): () => void {
      if (typeof IntersectionObserver === 'undefined') {
        reveal()
        return () => undefined
      }
      observer ??= new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue
          const callback = pending.get(entry.target)
          pending.delete(entry.target)
          observer?.unobserve(entry.target)
          callback?.()
        }
      })
      pending.set(element, reveal)
      observer.observe(element)
      return () => {
        pending.delete(element)
        observer?.unobserve(element)
      }
    },
    dispose() {
      pending.clear()
      observer?.disconnect()
      observer = undefined
    },
  }
}
