import { computed, readonly, ref } from 'vue'
import { cloneDashboardJson, parseDashboardDataPointer } from '../schema'

import type { DashboardPanel } from '../schema'
import type {
  DashboardHostDataView,
  DashboardPanelLinkRequestEvent,
  DashboardPanelStateInfo,
  DashboardReadonlyDocument,
  DashboardRefreshRequestEvent,
  DashboardRuntimeContext,
  DashboardRuntimeMode,
} from './types'

/** Pure evaluation, with explicit host state taking precedence at the renderer. */
export function resolveDashboardThresholdState(
  panel: DashboardPanel
): DashboardPanelStateInfo | undefined {
  let result: DashboardPanelStateInfo | undefined
  for (const rule of panel.thresholds ?? []) {
    const parts = parseDashboardDataPointer(rule.path)
    if (
      !parts ||
      typeof rule.value !== 'number' ||
      !Number.isFinite(rule.value)
    )
      continue
    let value: unknown = panel.data
    for (const part of parts) {
      if (
        !value ||
        typeof value !== 'object' ||
        !Object.prototype.hasOwnProperty.call(value, part)
      ) {
        value = undefined
        break
      }
      value = (value as Record<string, unknown>)[part]
    }
    if (typeof value !== 'number' || !Number.isFinite(value)) continue
    const matches =
      rule.operator === 'gt'
        ? value > rule.value
        : rule.operator === 'gte'
        ? value >= rule.value
        : rule.operator === 'lt'
        ? value < rule.value
        : rule.operator === 'lte'
        ? value <= rule.value
        : false
    if (!matches || (rule.state !== 'warn' && rule.state !== 'error')) continue
    if (!result || (result.state === 'warn' && rule.state === 'error')) {
      result = { state: rule.state, label: rule.label ?? rule.state }
    }
  }
  return result
}

export function useDashboardHostData(options: {
  document: () => DashboardReadonlyDocument | undefined
  panels: () => DashboardPanel[]
  mode: () => DashboardRuntimeMode
  onRefresh: (event: DashboardRefreshRequestEvent) => void
  onLink: (event: DashboardPanelLinkRequestEvent) => void
}) {
  // Bound Vue's recursive DeepReadonly inference at the document boundary.
  const selection = () =>
    options.document() as
      | Pick<DashboardHostDataView, 'variables' | 'timeRange' | 'refresh'>
      | undefined
  const variables = computed(() => selection()?.variables ?? Object.freeze({}))
  const timeRange = computed(() => selection()?.timeRange)
  const refresh = computed(() => selection()?.refresh)
  const tick = ref(0)
  const refreshTick = readonly(tick)
  const view = (): DashboardHostDataView => ({
    variables: variables.value,
    timeRange: timeRange.value,
    refresh: refresh.value,
    refreshTick: tick.value,
  })
  // Requests are immutable snapshots: asynchronous host handlers never observe a later selection.
  const snapshot = (): DashboardHostDataView =>
    readonly<object>(cloneDashboardJson(view())) as DashboardHostDataView
  const requestRefresh: DashboardRuntimeContext['requestRefresh'] = (
    input = {}
  ) => {
    if (
      input.panelId !== undefined &&
      !options.panels().some((panel) => panel.id === input.panelId)
    )
      return false
    tick.value += 1
    options.onRefresh({
      ...snapshot(),
      type: 'refresh-request',
      mode: options.mode(),
      source: input.source ?? 'panel-content',
      ...(input.panelId === undefined ? {} : { panelId: input.panelId }),
    })
    return true
  }
  const requestPanelLink: DashboardRuntimeContext['requestPanelLink'] = (
    input
  ) => {
    const link = options
      .panels()
      .find((panel) => panel.id === input.panelId)
      ?.links?.find((link) => link.id === input.linkId)
    if (!link) return false
    options.onLink({
      ...snapshot(),
      type: 'panel-link-request',
      mode: options.mode(),
      source: input.source ?? 'panel-content',
      panelId: input.panelId,
      link: readonly<object>(
        cloneDashboardJson(link)
      ) as DashboardPanelLinkRequestEvent['link'],
    })
    return true
  }
  return {
    variables,
    timeRange,
    refresh,
    refreshTick,
    requestRefresh,
    requestPanelLink,
    view,
  }
}

/** Reserved action namespace; JSON encoding prevents collisions between arbitrary ids. */
export function dashboardPanelLinkAction(id: string): string {
  return `dashboard-link:${JSON.stringify(id)}`
}
