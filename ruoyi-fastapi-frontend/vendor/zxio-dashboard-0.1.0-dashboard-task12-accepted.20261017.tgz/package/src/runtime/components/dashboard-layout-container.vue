<script setup lang="ts">
import { computed, nextTick, ref, useId, watch } from 'vue'
import { useDashboardLocale } from '../../locale'
import { reorderDashboardRow } from '../grid/grouping'

import type { PropType } from 'vue'
import type { DashboardLayout, DashboardRowsContainer } from '../../schema'
import type { DashboardRuntimeMode } from '../types'

const props = defineProps({
  layout: { type: Object as PropType<DashboardLayout>, required: true },
  mode: { type: String as PropType<DashboardRuntimeMode>, required: true },
})
const emit = defineEmits<{
  (e: 'update:layout', value: DashboardLayout): void
}>()
defineSlots<{ grid(props: { panelIds: string[]; containerId: string }): any }>()
const locale = useDashboardLocale()
const uid = useId()
const root = ref<HTMLElement>()
const selectedTab = ref<string>()
const collapsed = ref(new Map<string, boolean>())
let dragging: string | undefined
const tab = computed(() =>
  props.layout.type === 'tabs'
    ? props.layout.children.find((item) => item.id === selectedTab.value) ??
      props.layout.children[0]
    : undefined
)
const content = computed(() => tab.value?.children ?? props.layout)
const editable = computed(() => props.mode !== 'view')
watch(
  () => props.layout,
  () => {
    collapsed.value = new Map()
  },
  { deep: true }
)

function toggleRow(id: string, initial: boolean) {
  const value = !(collapsed.value.get(id) ?? initial)
  if (!editable.value) {
    collapsed.value = new Map(collapsed.value).set(id, value)
    return
  }
  if (content.value.type !== 'rows') return
  updateRows({
    ...content.value,
    children: content.value.children.map((row) =>
      row.id === id ? { ...row, collapsed: value } : row
    ),
  })
}
function updateRows(rows: DashboardRowsContainer) {
  if (!editable.value) return
  emit(
    'update:layout',
    props.layout.type === 'tabs'
      ? {
          ...props.layout,
          children: props.layout.children.map((item) =>
            item.id === tab.value?.id ? { ...item, children: rows } : item
          ),
        }
      : rows
  )
}
function moveRow(from: string, to: string) {
  if (content.value.type === 'rows')
    updateRows(reorderDashboardRow(content.value, from, to))
  nextTick(() =>
    root.value
      ?.querySelectorAll<HTMLElement>('[data-row-move]')
      .forEach((button) => {
        if (button.dataset.rowMove === from) button.focus()
      })
  )
}
function startDrag(event: DragEvent, id: string) {
  if (!editable.value || !event.dataTransfer) {
    event.preventDefault()
    return
  }
  dragging = id
  event.dataTransfer.effectAllowed = 'move'
  event.dataTransfer.setData('application/x-zx-dashboard-row', id)
}
function dropRow(event: DragEvent, id: string) {
  if (!editable.value || !dragging) return
  event.preventDefault()
  moveRow(dragging, id)
  dragging = undefined
}
function navigateTabs(event: KeyboardEvent, index: number) {
  if (props.layout.type !== 'tabs') return
  const count = props.layout.children.length
  const rtl = root.value && getComputedStyle(root.value).direction === 'rtl'
  let next = index
  if (event.key === 'Home') next = 0
  else if (event.key === 'End') next = count - 1
  else if (event.key === 'ArrowRight')
    next = (index + (rtl ? -1 : 1) + count) % count
  else if (event.key === 'ArrowLeft')
    next = (index + (rtl ? 1 : -1) + count) % count
  else return
  event.preventDefault()
  selectedTab.value = props.layout.children[next].id
  nextTick(() =>
    root.value?.querySelectorAll<HTMLElement>('[role="tab"]')[next]?.focus()
  )
}
</script>

<template>
  <div ref="root" class="zx-dashboard-layout">
    <div
      v-if="layout.type === 'tabs'"
      class="zx-dashboard-layout__tabs"
      role="tablist"
      :aria-label="locale.layout.tabs"
    >
      <button
        v-for="(item, index) in layout.children"
        :id="`${uid}-tab-${index}`"
        :key="item.id"
        type="button"
        role="tab"
        :aria-selected="item.id === tab?.id"
        :aria-controls="`${uid}-content`"
        :tabindex="item.id === tab?.id ? 0 : -1"
        @click="selectedTab = item.id"
        @keydown="navigateTabs($event, index)"
      >
        {{ item.title }}
      </button>
    </div>
    <div
      :id="layout.type === 'tabs' ? `${uid}-content` : undefined"
      :role="layout.type === 'tabs' ? 'tabpanel' : undefined"
      :aria-labelledby="
        layout.type === 'tabs'
          ? `${uid}-tab-${layout.children.findIndex(
              (item) => item.id === tab?.id
            )}`
          : undefined
      "
      :tabindex="layout.type === 'tabs' ? 0 : undefined"
    >
      <slot
        v-if="content.type === 'grid'"
        name="grid"
        :panel-ids="content.children"
        :container-id="tab?.id ?? '$root'"
      />
      <template v-else-if="content.type === 'rows'">
        <section
          v-for="(row, index) in content.children"
          :key="row.id"
          class="zx-dashboard-row"
          :data-row-id="row.id"
          @dragover="dragging && $event.preventDefault()"
          @drop="dropRow($event, row.id)"
        >
          <div class="zx-dashboard-row__header">
            <button
              type="button"
              class="zx-dashboard-row__toggle"
              :aria-expanded="
                !(collapsed.get(row.id) ?? row.collapsed ?? false)
              "
              :aria-controls="`${uid}-row-${index}`"
              @click="toggleRow(row.id, row.collapsed ?? false)"
            >
              <span aria-hidden="true">{{
                collapsed.get(row.id) ?? row.collapsed ? '▸' : '▾'
              }}</span>
              {{ row.title }}
              <span class="zx-dashboard-row__count">{{
                row.children.length
              }}</span>
            </button>
            <div v-if="editable" class="zx-dashboard-row__tools">
              <button
                type="button"
                :data-row-move="row.id"
                draggable="true"
                :aria-label="`${locale.layout.moveRow}: ${row.title}`"
                @dragstart="startDrag($event, row.id)"
                @dragend="dragging = undefined"
              >
                ⠿
              </button>
              <button
                type="button"
                :disabled="index === 0"
                :aria-label="`${locale.layout.moveUp}: ${row.title}`"
                @click="
                  moveRow(
                    row.id,
                    content.type === 'rows'
                      ? content.children[index - 1].id
                      : ''
                  )
                "
              >
                ↑
              </button>
              <button
                type="button"
                :disabled="index === content.children.length - 1"
                :aria-label="`${locale.layout.moveDown}: ${row.title}`"
                @click="
                  moveRow(
                    row.id,
                    content.type === 'rows'
                      ? content.children[index + 1].id
                      : ''
                  )
                "
              >
                ↓
              </button>
            </div>
          </div>
          <div
            :id="`${uid}-row-${index}`"
            :hidden="collapsed.get(row.id) ?? row.collapsed ?? false"
            class="zx-dashboard-row__content"
          >
            <slot
              v-if="!(collapsed.get(row.id) ?? row.collapsed ?? false)"
              name="grid"
              :panel-ids="row.children"
              :container-id="row.id"
            />
          </div>
        </section>
      </template>
    </div>
  </div>
</template>
