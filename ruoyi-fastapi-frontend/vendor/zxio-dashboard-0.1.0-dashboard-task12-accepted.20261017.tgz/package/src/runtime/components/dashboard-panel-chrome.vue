<template>
  <article
    ref="rootRef"
    class="zx-dashboard-panel"
    :class="[
      `zx-dashboard-panel--${runtimeMode}`,
      {
        'zx-dashboard-panel--headerless': !resolvedShowHeader,
        'zx-dashboard-panel--no-padding': contentPadding === false,
        'is-hover-header': resolvedHeaderMode === 'hover',
        'is-header-visible':
          resolvedHeaderMode === 'hover' && hoverHeaderVisible,
        'is-elevation-disabled': resolvedHoverElevation === false,
        'is-selected': selected,
        'is-maximized': maximized,
        'is-locked': locked,
        'is-hidden': hidden,
        'is-menu-open': menuOpen,
      },
    ]"
    :data-panel-id="panel.id"
    :data-dashboard-chrome="resolvedChromeVariant"
    :data-zx-surface="resolvedChromeVariant === 'card' ? 'card' : 'panel'"
    :data-selected="selected ? 'true' : undefined"
    :data-maximized="maximized ? 'true' : undefined"
    :data-locked="locked ? 'true' : undefined"
    :data-hidden="hidden ? 'true' : undefined"
    :aria-current="!managedFocus && selected ? 'true' : undefined"
    :tabindex="resolvedFocusable ? 0 : undefined"
    @pointerenter="handlePointerEnter"
    @pointerleave="handlePointerLeave"
    @focusin="handleFocusIn"
    @focusout="handleFocusOut"
  >
    <slot
      v-if="$slots.header"
      name="header"
      :panel="panel"
      :mode="runtimeMode"
      :actions="visibleActions"
      :dispatch-panel-action="dispatchPanelAction"
      :request-panel-update="requestPanelUpdate"
    />
    <header v-else-if="resolvedShowHeader" class="zx-dashboard-panel__header">
      <div
        class="zx-dashboard-panel__title-group"
        :class="draggableHandleClass"
        data-dashboard-drag-handle
      >
        <div class="zx-dashboard-panel__title-row">
          <span
            v-if="$slots.icon"
            class="zx-dashboard-panel__icon"
            aria-hidden="true"
          >
            <slot name="icon" :panel="panel" :mode="runtimeMode" />
          </span>
          <div
            class="zx-dashboard-panel__title"
            :title="resolvedTitle || undefined"
          >
            <slot name="title" :panel="panel" :mode="runtimeMode">
              {{ resolvedTitle }}
            </slot>
          </div>
          <span
            v-if="resolvedHeaderMode === 'minimal' && resolvedDescription"
            class="zx-dashboard-panel__info"
            role="img"
            :title="resolvedDescription"
            :aria-label="resolvedDescription"
          >
            <svg
              viewBox="0 0 16 16"
              fill="none"
              stroke="currentColor"
              stroke-width="1.5"
              aria-hidden="true"
              focusable="false"
            >
              <circle cx="8" cy="8" r="6.25" />
              <path d="M8 7.25v4" stroke-linecap="round" />
              <circle cx="8" cy="5" r="0.6" fill="currentColor" stroke="none" />
            </svg>
          </span>
        </div>
        <div
          v-if="
            resolvedHeaderMode !== 'minimal' &&
            (resolvedDescription || $slots.description)
          "
          class="zx-dashboard-panel__description"
        >
          <slot name="description" :panel="panel" :mode="runtimeMode">
            {{ resolvedDescription }}
          </slot>
        </div>
      </div>
      <div
        v-if="
          resolvedHeaderMode !== 'minimal' &&
          (hasVisibleActions || $slots.actions)
        "
        ref="actionsRef"
        class="zx-dashboard-panel__actions"
        role="group"
        :aria-label="locale.panel.actionsLabel"
      >
        <slot
          name="actions"
          :panel="panel"
          :mode="runtimeMode"
          :actions="visibleActions"
          :dispatch-panel-action="dispatchPanelAction"
          :request-panel-update="requestPanelUpdate"
        >
          <button
            v-for="action in inlineActions"
            :key="action.type"
            class="zx-dashboard-panel__action"
            :class="{
              'zx-dashboard-panel__action--icon': Boolean(action.icon),
              'is-danger': action.danger,
            }"
            type="button"
            :disabled="action.disabled"
            :tabindex="managedFocus && !focusWithin ? -1 : undefined"
            :aria-label="action.icon ? actionLabel(action) : undefined"
            :title="actionTitle(action)"
            :data-dashboard-action="action.type"
            @click="dispatchPanelAction(action)"
          >
            <component
              :is="action.icon"
              v-if="action.icon"
              class="zx-dashboard-panel__action-icon"
            />
            <span v-else class="zx-dashboard-panel__action-label">
              {{ actionLabel(action) }}
            </span>
          </button>
          <template v-if="menuActions.length > 0">
            <button
              ref="moreRef"
              class="zx-dashboard-panel__action zx-dashboard-panel__action--icon zx-dashboard-panel__action--more"
              type="button"
              :popovertarget="supportsPopover ? menuId : undefined"
              :tabindex="managedFocus && !focusWithin ? -1 : undefined"
              aria-haspopup="menu"
              :aria-expanded="menuOpen ? 'true' : 'false'"
              :aria-controls="menuId"
              :aria-label="locale.panel.more"
              :title="locale.panel.more"
              data-dashboard-action="more"
              @click="handleMoreClick"
              @keydown="handleMoreKeydown"
            >
              <component
                :is="moreIcon"
                class="zx-dashboard-panel__action-icon"
              />
            </button>
            <div
              v-if="supportsPopover || menuOpen"
              :id="menuId"
              ref="menuRef"
              class="zx-dashboard-panel__menu"
              role="menu"
              data-zx-surface="overlay"
              :popover="supportsPopover ? 'auto' : undefined"
              :aria-label="locale.panel.more"
              :style="menuStyle"
              @beforetoggle="handleMenuBeforeToggle"
              @toggle="handleMenuToggle"
              @keydown="handleMenuKeydown"
            >
              <template v-for="entry in menuEntries" :key="entry.key">
                <div
                  v-if="entry.kind === 'separator'"
                  class="zx-dashboard-panel__menu-separator"
                  role="separator"
                />
                <button
                  v-else
                  class="zx-dashboard-panel__menu-item"
                  :class="{ 'is-danger': entry.action.danger }"
                  type="button"
                  role="menuitem"
                  tabindex="-1"
                  :disabled="entry.action.disabled"
                  :data-dashboard-action="entry.action.type"
                  @click="handleMenuItemClick(entry.action)"
                >
                  <span
                    class="zx-dashboard-panel__menu-item-icon"
                    aria-hidden="true"
                  >
                    <component
                      :is="entry.action.icon"
                      v-if="entry.action.icon"
                    />
                  </span>
                  <span class="zx-dashboard-panel__menu-item-label">
                    {{ actionLabel(entry.action) }}
                  </span>
                  <kbd
                    v-if="entry.action.shortcut"
                    class="zx-dashboard-panel__menu-shortcut"
                  >
                    {{ formatDashboardShortcut(entry.action.shortcut) }}
                  </kbd>
                </button>
              </template>
            </div>
          </template>
        </slot>
      </div>
    </header>
    <span
      v-if="resolvedPanelStateInfo"
      class="zx-dashboard-panel__status-indicator"
      :class="`is-${resolvedPanelStateInfo.state}`"
      :title="resolvedPanelStateInfo.label"
      aria-hidden="true"
    />
    <span v-if="resolvedPanelStateInfo" class="zx-dashboard-panel__status-sr">
      {{ resolvedPanelStateInfo.label }}
    </span>
    <div class="zx-dashboard-panel__content" :style="contentStyle">
      <slot :panel="panel" :mode="runtimeMode">
        <slot name="fallback" :panel="panel" :mode="runtimeMode" />
      </slot>
    </div>
  </article>
</template>

<script setup lang="ts">
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
  useId,
  watch,
} from 'vue'
import { useDashboardLocale } from '../../locale'
import {
  DASHBOARD_BUILTIN_PANEL_ACTIONS,
  DASHBOARD_PANEL_ACTION_ICONS,
  resolveDashboardPanelActions,
  splitDashboardPanelActions,
} from '../actions'
import { resolveDashboardRuntimeMode } from '../mode'
import { formatDashboardShortcut } from '../shortcut'
import { useDashboardRuntimeContext } from '../context/dashboard-runtime-context'
import { normalizeDashboardPanelState } from '../panel-state'
import { readDashboardPanelLayoutMetadata } from '../grid/panel-layout'

import type { DashboardPanel } from '../../schema'
import type { CSSProperties, PropType } from 'vue'
import type { DashboardBuiltinPanelActionType } from '../actions'
import type {
  DashboardChromeVariant,
  DashboardHeaderMode,
  DashboardPanelActionDefinition,
  DashboardPanelActionEvent,
  DashboardPanelStateInfo,
  DashboardPanelStateInput,
  DashboardPanelUpdateRequestEvent,
  DashboardRuntimeMode,
} from '../types'

const HOVER_HEADER_HIDE_DELAY_MS = 200
const MENU_GAP_PX = 4
const MENU_VIEWPORT_INSET_PX = 8

type MenuEntry =
  | { kind: 'action'; key: string; action: DashboardPanelActionDefinition }
  | { kind: 'separator'; key: string }

type ToggleLikeEvent = Event & { newState?: string }

const props = defineProps({
  panel: {
    type: Object as PropType<DashboardPanel>,
    required: true,
  },
  mode: String as PropType<DashboardRuntimeMode>,
  title: String,
  description: String,
  showHeader: {
    type: [Boolean, String] as PropType<boolean | 'auto'>,
    default: 'auto',
  },
  contentPadding: {
    type: [Number, String, Boolean] as PropType<number | string | false>,
    default: undefined,
  },
  draggableHandleClass: {
    type: String,
    default: 'zx-dashboard-panel__drag-handle',
  },
  actions: {
    type: Array as PropType<DashboardPanelActionDefinition[]>,
    default: () => [],
  },
  chromeVariant: {
    type: String as PropType<DashboardChromeVariant>,
    default: undefined,
  },
  headerMode: {
    type: String as PropType<DashboardHeaderMode>,
    default: undefined,
  },
  managedFocus: Boolean,
  focusable: {
    type: Boolean,
    default: undefined,
  },
  hoverElevation: {
    type: Boolean,
    default: undefined,
  },
  selected: {
    type: Boolean,
    default: false,
  },
  maximized: {
    type: Boolean,
    default: false,
  },
  state: {
    type: [String, Object] as PropType<DashboardPanelStateInput>,
    default: undefined,
  },
})

const emit = defineEmits<{
  (event: 'panel-action', payload: DashboardPanelActionEvent): void
  (
    event: 'panel-update-request',
    payload: DashboardPanelUpdateRequestEvent
  ): void
}>()

const locale = useDashboardLocale()
const runtimeContext = useDashboardRuntimeContext()
const rootRef = ref<HTMLElement | null>(null)
const actionsRef = ref<HTMLElement | null>(null)
const moreRef = ref<HTMLButtonElement | null>(null)
const menuRef = ref<HTMLElement | null>(null)
const menuId = useId()
const moreIcon = DASHBOARD_PANEL_ACTION_ICONS.more
const headerModeConflictReported = ref(false)
const hoverHeaderVisible = ref(false)
const menuOpen = ref(false)
const menuStyle = ref<CSSProperties | undefined>(undefined)
// Resolved after mount so SSR markup never carries `popover` attributes the
// client would have to reconcile; happy-dom lacks the API and takes the
// absolute-positioned fallback.
const supportsPopover = ref(false)
let hideTimer: ReturnType<typeof setTimeout> | null = null

const resolvedChromeVariant = computed<DashboardChromeVariant>(() => {
  if (props.chromeVariant) return props.chromeVariant
  const fromContext = runtimeContext?.chromeVariant?.value
  return fromContext ?? 'silent'
})

const runtimeMode = computed(() =>
  resolveDashboardRuntimeMode({ mode: props.mode })
)
const resolvedTitle = computed(() => props.title ?? props.panel.title ?? '')
const resolvedDescription = computed(
  () => props.description ?? props.panel.description ?? ''
)

// While maximized the `maximize` action turns into `restore` in place, so the
// host keeps a single declaration and the button toggles.
const layoutMeta = computed(() => readDashboardPanelLayoutMetadata(props.panel))
const locked = computed(() => layoutMeta.value.locked === true)
const hidden = computed(() => layoutMeta.value.hidden === true)

// `maximize`, `lock` and `hide` are toggles: the built-in counterpart takes
// the slot in place while the state is active, keeping the host's placement.
function resolveStateSwap(
  type: string
): DashboardBuiltinPanelActionType | undefined {
  if (type === 'maximize' && props.maximized) return 'restore'
  if (type === 'lock' && locked.value) return 'unlock'
  if (type === 'hide' && hidden.value) return 'show'
  return undefined
}

const resolvedActions = computed<DashboardPanelActionDefinition[]>(() =>
  props.actions.map((action: DashboardPanelActionDefinition) => {
    const swap = resolveStateSwap(action.type)
    if (!swap) return action
    const target = DASHBOARD_BUILTIN_PANEL_ACTIONS[swap]
    return {
      ...target,
      placement: action.placement ?? target.placement,
      visibleIn: action.visibleIn ?? target.visibleIn,
      disabled: action.disabled,
      hidden: action.hidden,
    }
  })
)
const visibleActions = computed(() =>
  resolveDashboardPanelActions(resolvedActions.value, runtimeMode.value)
)
const hasVisibleActions = computed(() => visibleActions.value.length > 0)
const splitActions = computed(() =>
  splitDashboardPanelActions(visibleActions.value)
)
const inlineActions = computed(() => splitActions.value.inline)
const menuActions = computed(() => splitActions.value.menu)
const menuEntries = computed<MenuEntry[]>(() => {
  const entries: MenuEntry[] = []
  let previousGroup: string | undefined
  menuActions.value.forEach((action, index) => {
    if (index > 0 && action.group !== previousGroup) {
      entries.push({ kind: 'separator', key: `separator:${index}` })
    }
    entries.push({ kind: 'action', key: `action:${action.type}`, action })
    previousGroup = action.group
  })
  return entries
})

const headerModeExplicit = computed(() => props.headerMode !== undefined)
const showHeaderExplicit = computed(() => props.showHeader !== 'auto')

watch(
  [headerModeExplicit, showHeaderExplicit, () => props.panel.id],
  () => {
    if (
      !headerModeExplicit.value ||
      !showHeaderExplicit.value ||
      headerModeConflictReported.value
    )
      return
    headerModeConflictReported.value = true
    runtimeContext?.reportRuntimeIssue({
      severity: 'warn',
      code: 'header_mode_conflict',
      message: locale.value.issues.header_mode_conflict,
      panelId: props.panel.id,
    })
  },
  { immediate: true }
)

const resolvedHeaderMode = computed<DashboardHeaderMode | undefined>(() => {
  if (headerModeExplicit.value) return props.headerMode

  if (resolvedChromeVariant.value === 'card' && !showHeaderExplicit.value)
    return 'always'

  return undefined
})

const resolvedShowHeader = computed(() => {
  if (resolvedHeaderMode.value === 'hover') return true
  if (resolvedHeaderMode.value === 'minimal') return true
  if (resolvedHeaderMode.value === 'always') return true

  if (props.showHeader !== 'auto') return props.showHeader
  return Boolean(
    resolvedTitle.value || resolvedDescription.value || hasVisibleActions.value
  )
})

const focusWithin = ref(false)
const resolvedFocusable = computed(() => props.focusable !== false)

const resolvedHoverElevation = computed(() => props.hoverElevation !== false)

const resolvedPanelStateInfo = computed<DashboardPanelStateInfo | undefined>(
  () => {
    const direct = normalizeDashboardPanelState(props.state)
    if (direct && direct.state !== 'idle') return direct

    const fromContext = runtimeContext?.resolvePanelState?.(props.panel)
    if (fromContext && fromContext.state !== 'idle') return fromContext

    return undefined
  }
)

const contentStyle = computed(() => {
  if (props.contentPadding === undefined) return undefined

  const value =
    props.contentPadding === false
      ? '0px'
      : typeof props.contentPadding === 'number'
      ? `${props.contentPadding}px`
      : props.contentPadding

  return {
    '--zx-dashboard-panel-content-padding': value,
  }
})

function actionLabel(action: DashboardPanelActionDefinition): string {
  if (action.label) return action.label
  const labels = locale.value.actions as Record<string, string | undefined>
  return labels[action.type] ?? action.type
}

function actionTitle(
  action: DashboardPanelActionDefinition
): string | undefined {
  if (!action.icon && !action.shortcut) return undefined
  const label = actionLabel(action)
  return action.shortcut
    ? `${label} (${formatDashboardShortcut(action.shortcut)})`
    : label
}

function clearHideTimer() {
  if (hideTimer !== null) {
    clearTimeout(hideTimer)
    hideTimer = null
  }
}

function scheduleHide() {
  if (resolvedHeaderMode.value !== 'hover') return
  clearHideTimer()
  hideTimer = setTimeout(() => {
    const root = rootRef.value
    if (
      menuOpen.value ||
      (root &&
        (root.matches(':hover') || root.contains(document.activeElement)))
    ) {
      return
    }
    hoverHeaderVisible.value = false
    hideTimer = null
  }, HOVER_HEADER_HIDE_DELAY_MS)
}

function handlePointerEnter() {
  if (resolvedHeaderMode.value !== 'hover') return
  clearHideTimer()
  hoverHeaderVisible.value = true
}

function handlePointerLeave() {
  if (resolvedHeaderMode.value !== 'hover') return
  scheduleHide()
}

function handleFocusIn() {
  focusWithin.value = true
  if (resolvedHeaderMode.value !== 'hover') return
  clearHideTimer()
  hoverHeaderVisible.value = true
}

function handleFocusOut(event: FocusEvent) {
  focusWithin.value = !!rootRef.value?.contains(
    event.relatedTarget as Node | null
  )
  if (resolvedHeaderMode.value !== 'hover') return
  scheduleHide()
}

// --- overflow menu -------------------------------------------------------

function menuItemElements(): HTMLButtonElement[] {
  const menu = menuRef.value
  if (!menu) return []
  return Array.from(
    menu.querySelectorAll<HTMLButtonElement>('[role="menuitem"]')
  ).filter((item) => !item.disabled)
}

function focusMenuItem(position: 'first' | 'last') {
  const items = menuItemElements()
  if (items.length === 0) return
  const target = position === 'first' ? items[0] : items[items.length - 1]
  target.focus()
}

function positionMenu() {
  const button = moreRef.value
  const menu = menuRef.value
  if (!button || !menu || !supportsPopover.value) return
  if (typeof window === 'undefined') return

  const rect = button.getBoundingClientRect()
  const menuRect = menu.getBoundingClientRect()
  const viewportWidth = window.innerWidth
  const viewportHeight = window.innerHeight

  let top = rect.bottom + MENU_GAP_PX
  const overflowsBottom =
    menuRect.height > 0 &&
    top + menuRect.height > viewportHeight - MENU_VIEWPORT_INSET_PX
  const fitsAbove =
    rect.top - MENU_GAP_PX - menuRect.height >= MENU_VIEWPORT_INSET_PX
  if (overflowsBottom && fitsAbove) {
    top = rect.top - MENU_GAP_PX - menuRect.height
  }

  menuStyle.value = {
    top: `${Math.max(MENU_VIEWPORT_INSET_PX, Math.round(top))}px`,
    right: `${Math.max(
      MENU_VIEWPORT_INSET_PX,
      Math.round(viewportWidth - rect.right)
    )}px`,
    left: 'auto',
    bottom: 'auto',
  }
}

function isPopoverOpen(menu: HTMLElement): boolean {
  try {
    return menu.matches(':popover-open')
  } catch {
    return false
  }
}

function openMenu(focus: 'first' | 'last' | 'none' = 'none') {
  if (menuOpen.value) {
    if (focus !== 'none') focusMenuItem(focus)
    return
  }

  if (supportsPopover.value) {
    const menu = menuRef.value
    if (!menu || isPopoverOpen(menu)) return
    menu.showPopover()
    if (focus !== 'none') focusMenuItem(focus)
    return
  }

  // The fallback menu renders on the next tick.
  menuOpen.value = true
  if (focus !== 'none') nextTick(() => focusMenuItem(focus))
}

function closeMenu(restoreFocus = false) {
  const menu = menuRef.value
  if (supportsPopover.value && menu && isPopoverOpen(menu)) {
    menu.hidePopover()
  }
  menuOpen.value = false
  if (restoreFocus) moreRef.value?.focus()
}

function handleMoreClick() {
  // With the Popover API the button's `popovertarget` toggles natively and the
  // `toggle` listener mirrors the state; the fallback toggles by hand.
  if (supportsPopover.value) return
  if (menuOpen.value) closeMenu()
  else openMenu('first')
}

function handleMoreKeydown(event: KeyboardEvent) {
  if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    event.preventDefault()
    openMenu(event.key === 'ArrowDown' ? 'first' : 'last')
  }
}

function handleMenuBeforeToggle(event: ToggleLikeEvent) {
  if (event.newState === 'open') positionMenu()
}

function handleMenuToggle(event: ToggleLikeEvent) {
  const open = event.newState === 'open'
  menuOpen.value = open
  if (open) {
    positionMenu()
    focusMenuItem('first')
  }
}

function handleMenuKeydown(event: KeyboardEvent) {
  const items = menuItemElements()
  const currentIndex = items.indexOf(event.target as HTMLButtonElement)

  switch (event.key) {
    case 'ArrowDown': {
      event.preventDefault()
      if (items.length === 0) return
      items[(currentIndex + 1) % items.length].focus()
      return
    }
    case 'ArrowUp': {
      event.preventDefault()
      if (items.length === 0) return
      items[(currentIndex - 1 + items.length) % items.length].focus()
      return
    }
    case 'Home': {
      event.preventDefault()
      focusMenuItem('first')
      return
    }
    case 'End': {
      event.preventDefault()
      focusMenuItem('last')
      return
    }
    case 'Escape': {
      event.preventDefault()
      event.stopPropagation()
      closeMenu(true)
      return
    }
    case 'Tab': {
      closeMenu()
      return
    }
    default:
  }
}

function handleMenuItemClick(action: DashboardPanelActionDefinition) {
  closeMenu(true)
  dispatchPanelAction(action)
}

function handleDocumentPointerDown(event: PointerEvent) {
  if (!menuOpen.value || supportsPopover.value) return
  const target = event.target as Node | null
  if (target && actionsRef.value?.contains(target)) return
  closeMenu()
}

function handleViewportChange() {
  if (menuOpen.value) closeMenu()
}

watch(menuOpen, (open) => {
  if (typeof document === 'undefined') return
  if (open) {
    document.addEventListener('pointerdown', handleDocumentPointerDown, true)
    window.addEventListener('scroll', handleViewportChange, {
      capture: true,
      passive: true,
    })
    window.addEventListener('resize', handleViewportChange)
    return
  }
  removeMenuListeners()
  if (resolvedHeaderMode.value === 'hover') scheduleHide()
})

function removeMenuListeners() {
  if (typeof document === 'undefined') return
  document.removeEventListener('pointerdown', handleDocumentPointerDown, true)
  window.removeEventListener('scroll', handleViewportChange, true)
  window.removeEventListener('resize', handleViewportChange)
}

onMounted(() => {
  supportsPopover.value =
    typeof HTMLElement !== 'undefined' && 'showPopover' in HTMLElement.prototype
})

onBeforeUnmount(() => {
  clearHideTimer()
  removeMenuListeners()
})

function dispatchPanelAction(action: DashboardPanelActionDefinition) {
  emit('panel-action', {
    type: 'panel-action',
    mode: runtimeMode.value,
    source: 'panel-chrome',
    panelId: props.panel.id,
    panel: props.panel,
    action: action.type,
  })
}

function requestPanelUpdate(patch: Partial<Omit<DashboardPanel, 'id'>>) {
  emit('panel-update-request', {
    type: 'panel-update-request',
    mode: runtimeMode.value,
    source: 'panel-chrome',
    panelId: props.panel.id,
    panel: props.panel,
    patch,
  })
}

defineExpose({
  dispatchPanelAction,
  requestPanelUpdate,
  openMenu,
  closeMenu,
})
</script>
