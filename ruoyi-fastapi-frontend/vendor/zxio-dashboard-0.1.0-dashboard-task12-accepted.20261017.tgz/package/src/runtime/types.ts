import type { DashboardLayoutExecutor } from './grid/vue-grid-layout-adapter'
import type { Component, DeepReadonly, Ref, VNodeChild } from 'vue'
import type {
  DashboardDocument,
  DashboardGridPosition,
  DashboardJsonValue,
  DashboardPanel,
  DashboardPanelLink,
  DashboardReadonlyJsonObject,
  DashboardRefresh,
  DashboardTimeRange,
} from '../schema'
import type { DashboardLocaleSource } from '../locale/types'

export type DashboardRuntimeMode = 'view' | 'edit' | 'layout'

export type DashboardReadonlyDocument = DeepReadonly<DashboardDocument>

export type DashboardRuntimeEventSource =
  | 'renderer'
  | 'grid'
  | 'panel-chrome'
  | 'panel-content'

export type DashboardGridDirection = 'auto' | 'ltr' | 'rtl'

/** Hold time in ms before a drag starts; a number applies to every pointer type. */
export type DashboardGridDragActivationDelay =
  | number
  | {
      mouse?: number
      pen?: number
      touch?: number
      coarse?: number
      default?: number
    }

export type DashboardGridItemOptions = Partial<
  Pick<
    DashboardGridLayoutItem,
    'minW' | 'minH' | 'maxW' | 'maxH' | 'static' | 'isDraggable' | 'isResizable'
  >
>

export type DashboardGridItemOptionsResolver = (
  panel: DashboardPanel
) => DashboardGridItemOptions | undefined

export interface DashboardGridOptions {
  /** Reuse the engine executor; scheduling remains automatic. */
  layoutEngine?: { executor?: DashboardLayoutExecutor }
  columns?: number
  rowHeight?: number
  margin?: readonly [number, number]
  containerPadding?: readonly [number, number]
  compactType?: 'vertical' | 'horizontal' | null
  draggableHandle?: string
  isDraggable?: boolean
  isResizable?: boolean
  isDroppable?: boolean
  useCssTransforms?: boolean
  measureBeforeMount?: boolean
  /** Writing direction handed to the engine. Defaults to `'auto'`. */
  direction?: DashboardGridDirection
  /** Defaults to a 300ms hold on touch / coarse pointers so scrolling never starts a drag. */
  dragActivationDelay?: DashboardGridDragActivationDelay
  /** Per-panel engine item options merged over the ones read from `panel.metadata.layout`. */
  getItemOptions?: DashboardGridItemOptionsResolver
  dropDragOver?: DashboardDropDragOverHandler
  defaultDropSize?: Pick<DashboardGridPosition, 'w' | 'h'>
}

/**
 * Per-panel layout state persisted under `panel.metadata.layout`. `locked`
 * makes the engine item static; `hidden` removes the panel from the grid
 * outside edit mode; the size bounds join the widget `minGrid` / `maxGrid`.
 */
export interface DashboardPanelLayoutMetadata {
  locked?: boolean
  hidden?: boolean
  minW?: number
  minH?: number
  maxW?: number
  maxH?: number
}

export type DashboardChromeVariant = 'silent' | 'card' | (string & {})

export type DashboardHeaderMode = 'always' | 'hover' | 'minimal'

export type DashboardPanelRuntimeState =
  | 'idle'
  | 'loading'
  | 'streaming'
  | 'error'
  | 'warn'

export interface DashboardPanelStateInfo {
  state: DashboardPanelRuntimeState
  label: string
}

export type DashboardPanelStateInput =
  | DashboardPanelStateInfo
  | DashboardPanelRuntimeState

export type DashboardGetPanelState = (
  panel: DashboardPanel
) => DashboardPanelStateInput | undefined

export type DashboardPanelStateMap =
  | ReadonlyMap<string, DashboardPanelStateInput>
  | Record<string, DashboardPanelStateInput>

export interface DashboardPanelChromeOptions {
  showHeader?: boolean | 'auto'
  contentPadding?: number | string | false
  draggableHandleClass?: string
  actions?: DashboardPanelActionDefinition[]
  headerMode?: DashboardHeaderMode
  focusable?: boolean
  hoverElevation?: boolean
  panelState?: DashboardPanelStateMap
  getPanelState?: DashboardGetPanelState
  /** Adjusts the action list per panel; receives the shared `actions`. */
  getPanelActions?: DashboardGetPanelActions
}

export type DashboardGetPanelActions = (
  panel: DashboardPanel,
  actions: readonly DashboardPanelActionDefinition[]
) => DashboardPanelActionDefinition[]

export type DashboardPanelActionPlacement = 'inline' | 'menu'

export interface DashboardPanelActionDefinition {
  type: string
  /** Visible label. Falls back to the locale entry for `type`, then to `type`. */
  label?: string
  /** Icon component rendered as an icon-only button; the label becomes its accessible name. */
  icon?: Component
  /** `inline` renders in the header; `menu` moves the action into the overflow menu. Defaults to `inline`. */
  placement?: DashboardPanelActionPlacement
  /** Runtime modes the action is rendered in. Defaults to `['edit']`. */
  visibleIn?: readonly DashboardRuntimeMode[]
  /** Display-only shortcut hint shown in the overflow menu. */
  shortcut?: string
  /** Menu actions with different groups are separated by a divider. */
  group?: string
  disabled?: boolean
  hidden?: boolean
  danger?: boolean
}

export interface DashboardGridLayoutItem {
  i: string
  x: number
  y: number
  w: number
  h: number
  minW?: number
  minH?: number
  maxW?: number
  maxH?: number
  static?: boolean
  isDraggable?: boolean
  isResizable?: boolean
}

export interface DashboardBuildLayoutOptions {
  getItemOptions?: DashboardGridItemOptionsResolver
}

export interface DashboardApplyLayoutOptions {
  keepMissingPanels?: boolean
}

export interface DashboardLayoutChange {
  panelId: string
  before: DashboardGridPosition
  after: DashboardGridPosition
}

export interface DashboardRuntimeBaseEvent {
  type: string
  mode: DashboardRuntimeMode
  source: DashboardRuntimeEventSource
  nativeEvent?: Event
}

export interface DashboardLayoutChangeEvent extends DashboardRuntimeBaseEvent {
  type: 'layout-change'
  panels: DashboardPanel[]
  changes: DashboardLayoutChange[]
}

export interface DashboardLayoutInteractionEvent
  extends DashboardRuntimeBaseEvent {
  type: 'drag-start' | 'drag-stop' | 'resize-start' | 'resize-stop'
  panelId: string
  panel?: DashboardPanel
  gridPos: DashboardGridPosition
}

export interface DashboardPanelActionInput {
  panelId: string
  action: string
  panel?: DashboardPanel
  payload?: DashboardJsonValue
  source?: DashboardRuntimeEventSource
}

export interface DashboardPanelActionEvent extends DashboardRuntimeBaseEvent {
  type: 'panel-action'
  panelId: string
  panel?: DashboardPanel
  action: string
  payload?: DashboardJsonValue
}

export interface DashboardWidgetEventInput {
  panelId: string
  panel?: DashboardPanel
  widget: string
  variant?: string
  event: string
  payload?: DashboardJsonValue
  source?: DashboardRuntimeEventSource
}

export interface DashboardWidgetEvent extends DashboardRuntimeBaseEvent {
  type: 'widget-event'
  panelId: string
  panel?: DashboardPanel
  widget: string
  variant?: string
  event: string
  payload?: DashboardJsonValue
}

export interface DashboardPanelUpdateRequestInput {
  panelId: string
  patch: Partial<Omit<DashboardPanel, 'id'>>
  panel?: DashboardPanel
  source?: DashboardRuntimeEventSource
}

export interface DashboardPanelUpdateRequestEvent
  extends DashboardRuntimeBaseEvent {
  type: 'panel-update-request'
  panelId: string
  panel?: DashboardPanel
  patch: Partial<Omit<DashboardPanel, 'id'>>
}

export interface DashboardPanelAddRequestEvent
  extends DashboardRuntimeBaseEvent {
  /** Originating row/tab grid for a targeted palette drop. */
  containerId?: string
  type: 'panel-add-request'
  gridPos: DashboardGridPosition
  raw?: unknown
}

/**
 * Grid editor commands the grid never runs itself: the host owns panel
 * removal, document history and persistence, so the engine's command is
 * cancelled and reported as a request instead.
 */
export type DashboardEditorHostCommand =
  | 'delete'
  | 'undo'
  | 'redo'
  | 'save'
  | 'discard'

export interface DashboardEditorCommandRequestEvent
  extends DashboardRuntimeBaseEvent {
  type: 'editor-command-request'
  command: DashboardEditorHostCommand
  /** Panel ids the engine targeted (its selection); empty when it had none. */
  targetIds: string[]
}

export type DashboardRuntimeIssueCode =
  | 'unresolved_widget'
  | 'invalid_layout_item'
  | 'unknown_layout_panel'
  | 'duplicate_layout_item'
  | 'missing_layout_item'
  | 'drop_ignored'
  | 'unknown_chrome_variant'
  | 'header_mode_conflict'

export interface DashboardMaximizeChangeEvent
  extends DashboardRuntimeBaseEvent {
  type: 'maximize-change'
  panelId: string | null
  panel?: DashboardPanel
}

export interface DashboardRuntimeIssue {
  severity: 'info' | 'warn' | 'error'
  code: DashboardRuntimeIssueCode
  message: string
  panelId?: string
  path?: string
}

/** Current host selection, never persisted or mutated by runtime actions. */
export interface DashboardHostDataView {
  variables: DashboardReadonlyJsonObject
  timeRange: DeepReadonly<DashboardTimeRange> | undefined
  refresh: Readonly<DashboardRefresh> | undefined
  refreshTick: number
}

export interface DashboardRefreshRequestInput {
  panelId?: string
  source?: DashboardRuntimeEventSource
}

export interface DashboardRefreshRequestEvent
  extends DashboardRuntimeBaseEvent,
    DashboardHostDataView {
  type: 'refresh-request'
  /** Omitted for a dashboard-wide request. */
  panelId?: string
}

export interface DashboardPanelLinkRequestInput {
  panelId: string
  linkId: string
  source?: DashboardRuntimeEventSource
}

export interface DashboardPanelLinkRequestEvent
  extends DashboardRuntimeBaseEvent,
    DashboardHostDataView {
  type: 'panel-link-request'
  panelId: string
  link: Readonly<Omit<DashboardPanelLink, 'params'>> & {
    readonly params?: DashboardReadonlyJsonObject
  }
}

export interface DashboardRuntimeContext {
  mode: Readonly<Ref<DashboardRuntimeMode>>
  editable: Readonly<Ref<boolean>>
  readonly: Readonly<Ref<boolean>>
  document: Readonly<Ref<DashboardReadonlyDocument | undefined>>
  variables: Readonly<Ref<DashboardHostDataView['variables']>>
  timeRange: Readonly<Ref<DashboardHostDataView['timeRange']>>
  refresh: Readonly<Ref<DashboardHostDataView['refresh']>>
  refreshTick: Readonly<Ref<number>>
  requestRefresh: (input?: DashboardRefreshRequestInput) => boolean
  requestPanelLink: (input: DashboardPanelLinkRequestInput) => boolean
  requestPanelUpdate: (event: DashboardPanelUpdateRequestInput) => void
  dispatchPanelAction: (event: DashboardPanelActionInput) => void
  emitWidgetEvent: (event: DashboardWidgetEventInput) => void
  reportRuntimeIssue: (issue: DashboardRuntimeIssue) => void
  chromeVariant?: Readonly<Ref<DashboardChromeVariant>>
  resolvePanelState?: (
    panel: DashboardPanel
  ) => DashboardPanelStateInfo | undefined
}

export interface DashboardPanelRenderContext extends DashboardHostDataView {
  requestRefresh: DashboardRuntimeContext['requestRefresh']
  requestPanelLink: DashboardRuntimeContext['requestPanelLink']
  mode: DashboardRuntimeMode
  document?: DashboardReadonlyDocument
  dispatchPanelAction: DashboardRuntimeContext['dispatchPanelAction']
  requestPanelUpdate: DashboardRuntimeContext['requestPanelUpdate']
  emitWidgetEvent: DashboardRuntimeContext['emitWidgetEvent']
}

export type DashboardPanelContentResolver = (
  panel: DashboardPanel,
  context: DashboardPanelRenderContext
) => VNodeChild | undefined

export type DashboardDropDragOverHandler = (event: {
  mode: DashboardRuntimeMode
  nativeEvent: DragEvent
  raw?: unknown
}) => false | Pick<DashboardGridPosition, 'w' | 'h'> | void

export interface ZxDashboardRendererProps {
  /** Mount content on first intersection or keyboard focus; chrome stays mounted. */
  lazy?: boolean
  /** Force view mode with a gapless canvas and no chrome controls. */
  kiosk?: boolean
  document?: DashboardDocument
  panels?: DashboardPanel[]
  mode?: DashboardRuntimeMode
  editable?: boolean
  layoutOnlyMode?: boolean
  grid?: DashboardGridOptions
  panelChrome?: DashboardPanelChromeOptions
  resolvePanelContent?: DashboardPanelContentResolver
  chromeVariant?: DashboardChromeVariant
  selectedPanelId?: string
  /** Controlled maximized panel. Leave `undefined` for internal state; `null` means none. */
  maximizedPanelId?: string | null
  locale?: DashboardLocaleSource
}

export interface ZxDashboardGridProps {
  panels: DashboardPanel[]
  mode?: DashboardRuntimeMode
  grid?: DashboardGridOptions
  readonly?: boolean
  editable?: boolean
  layoutOnlyMode?: boolean
}

export interface ZxDashboardPanelChromeProps {
  /** The surrounding engine owns the panel entry point. */
  managedFocus?: boolean
  panel: DashboardPanel
  mode?: DashboardRuntimeMode
  title?: string
  description?: string
  showHeader?: boolean | 'auto'
  contentPadding?: number | string | false
  draggableHandleClass?: string
  actions?: DashboardPanelActionDefinition[]
  chromeVariant?: DashboardChromeVariant
  headerMode?: DashboardHeaderMode
  focusable?: boolean
  hoverElevation?: boolean
  selected?: boolean
  maximized?: boolean
  state?: DashboardPanelStateInput
}
