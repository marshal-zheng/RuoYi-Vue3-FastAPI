import { cloneDashboardJson } from '../../schema'

import type {
  DashboardLayout,
  DashboardPanel,
  DashboardRowsContainer,
} from '../../schema'

export interface DashboardLayoutLeaf {
  id: string
  children: string[]
}

export function dashboardLayoutLeaves(
  layout: DashboardLayout
): DashboardLayoutLeaf[] {
  if (layout.type === 'grid')
    return [{ id: '$root', children: layout.children }]
  if (layout.type === 'rows') return layout.children
  return layout.children.flatMap((tab) =>
    tab.children.type === 'grid'
      ? [{ id: tab.id, children: tab.children.children }]
      : tab.children.children
  )
}

/** Geometry is local to a leaf; panel ids remain unique across the document. */
export function dashboardLayoutPanelPeers(
  panels: readonly DashboardPanel[],
  layout?: DashboardLayout,
  origin: { containerId?: string; panelId?: string } = {}
): readonly DashboardPanel[] {
  if (!layout) return panels
  const leaves = dashboardLayoutLeaves(layout)
  const leaf =
    leaves.find((item) =>
      origin.containerId !== undefined
        ? item.id === origin.containerId
        : origin.panelId !== undefined && item.children.includes(origin.panelId)
    ) ?? leaves[0]
  const ids = new Set(leaf?.children ?? [])
  return panels.filter((panel) => ids.has(panel.id))
}

/** Merge only the edited leaf. Hidden rows/tabs and unrelated references survive. */
export function mergeDashboardLeafPanels(
  all: readonly DashboardPanel[],
  members: readonly DashboardPanel[],
  next: readonly DashboardPanel[]
): DashboardPanel[] {
  const ids = new Set(members.map((panel) => panel.id))
  const updates = new Map(next.map((panel) => [panel.id, panel]))
  const known = new Set(all.map((panel) => panel.id))
  return all
    .flatMap((panel) =>
      ids.has(panel.id) ? updates.get(panel.id) ?? [] : panel
    )
    .concat(next.filter((panel) => !known.has(panel.id)))
}

export function reconcileDashboardLayout(
  layout: DashboardLayout | undefined,
  panels: readonly DashboardPanel[],
  options: { containerId?: string; sourcePanelId?: string } = {}
): DashboardLayout | undefined {
  if (!layout) return undefined
  const next = cloneDashboardJson(layout)
  let leaves = dashboardLayoutLeaves(next)
  const source = leaves.find(
    (leaf) =>
      leaf.id === options.containerId ||
      (options.sourcePanelId !== undefined &&
        leaf.children.includes(options.sourcePanelId))
  )
  const ids = new Set(panels.map((panel) => panel.id))
  for (const leaf of leaves)
    leaf.children = leaf.children.filter((id) => ids.has(id))
  // Root/tab grid leaves are adapters; assign back after reconciliation below.
  const assigned = new Set(leaves.flatMap((leaf) => leaf.children))
  const added = panels
    .filter((panel) => !assigned.has(panel.id))
    .map((panel) => panel.id)
  if (!leaves.length && added.length) {
    const rows =
      next.type === 'rows'
        ? next
        : next.type === 'tabs' && next.children[0]?.children.type === 'rows'
        ? next.children[0].children
        : undefined
    if (rows) {
      const groups = new Set(
        next.type === 'tabs' ? next.children.map((tab) => tab.id) : []
      )
      let id = 'row-1'
      while (groups.has(id)) id += '-1'
      rows.children.push({ id, title: 'Panels', children: [] })
      leaves = dashboardLayoutLeaves(next)
    }
  }
  const target = source ?? leaves[0]
  if (target) target.children.push(...added)
  if (next.type === 'grid') next.children = leaves[0].children
  if (next.type === 'tabs') {
    for (const tab of next.children) {
      if (tab.children.type === 'grid')
        tab.children.children =
          leaves.find((leaf) => leaf.id === tab.id)?.children ?? []
    }
  }
  return next
}

export function reorderDashboardRow(
  layout: DashboardRowsContainer,
  from: string,
  to: string
): DashboardRowsContainer {
  const children = [...layout.children]
  const start = children.findIndex((row) => row.id === from)
  const end = children.findIndex((row) => row.id === to)
  if (start < 0 || end < 0 || start === end) return layout
  const [row] = children.splice(start, 1)
  children.splice(end, 0, row)
  return { ...layout, children }
}
