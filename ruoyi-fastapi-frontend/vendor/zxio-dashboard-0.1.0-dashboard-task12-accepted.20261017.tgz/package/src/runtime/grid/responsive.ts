import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { DASHBOARD_BREAKPOINTS } from '../../schema'
import { sortPanelsByGridPosition } from './layout-adapter'

import type { Ref } from 'vue'
import type { DashboardBreakpoint, DashboardPanel } from '../../schema'

export function resolveDashboardBreakpoint(width: number): DashboardBreakpoint {
  return (
    (Object.keys(DASHBOARD_BREAKPOINTS) as DashboardBreakpoint[]).find(
      (key) => width >= DASHBOARD_BREAKPOINTS[key]
    ) ?? 'xxs'
  )
}

/** Projection only: neither fallback stacking nor width changes mutate the document. */
export function projectDashboardPanels(
  panels: readonly DashboardPanel[],
  breakpoint: DashboardBreakpoint,
  columns: number
): DashboardPanel[] {
  const mobile = DASHBOARD_BREAKPOINTS[breakpoint] < DASHBOARD_BREAKPOINTS.sm
  const stacked = new Map<string, number>()
  let y = 0
  for (const panel of sortPanelsByGridPosition(panels)) {
    stacked.set(panel.id, y)
    y += panel.gridPos.h
  }
  return panels.map((panel) => {
    const position =
      panel.layouts?.[breakpoint] ??
      (mobile
        ? {
            x: 0,
            y: stacked.get(panel.id) ?? 0,
            w: columns,
            h: panel.gridPos.h,
          }
        : panel.gridPos)
    const w = Math.min(columns, position.w)
    return {
      ...panel,
      gridPos: { ...position, w, x: Math.min(position.x, columns - w) },
    }
  })
}

export function writeDashboardBreakpointPanels(
  source: readonly DashboardPanel[],
  projected: readonly DashboardPanel[],
  breakpoint: DashboardBreakpoint,
  columns = 24
): DashboardPanel[] {
  const byId = new Map(projected.map((panel) => [panel.id, panel]))
  const before = new Map(
    projectDashboardPanels(source, breakpoint, columns).map((panel) => [
      panel.id,
      panel,
    ])
  )
  return source.map((panel) => {
    const next = byId.get(panel.id)
    if (!next) return panel
    if (
      JSON.stringify(before.get(panel.id)?.gridPos) ===
      JSON.stringify(next.gridPos)
    )
      return panel
    if (breakpoint === 'lg' && !panel.layouts?.lg) return { ...next }
    return {
      ...next,
      gridPos: panel.gridPos,
      layouts: { ...panel.layouts, [breakpoint]: next.gridPos },
    }
  })
}

/** Owns measurement/disposal and a short suppression window around projection. */
export function useDashboardResponsiveGrid(root: Ref<HTMLElement | undefined>) {
  const width = ref(1200)
  const breakpoint = computed(() => resolveDashboardBreakpoint(width.value))
  const projecting = ref(false)
  let observer: ResizeObserver | undefined
  let disposed = false
  const settle = () =>
    nextTick(() => {
      if (!disposed) projecting.value = false
    })
  watch(
    breakpoint,
    () => {
      projecting.value = true
      settle()
    },
    { flush: 'sync' }
  )
  onMounted(() => {
    const measure = (value: number) => {
      if (value > 0) width.value = value
    }
    measure(root.value?.getBoundingClientRect().width ?? 0)
    if (typeof ResizeObserver !== 'undefined' && root.value) {
      observer = new ResizeObserver((entries) =>
        measure(entries[0]?.contentRect.width ?? 0)
      )
      observer.observe(root.value)
    }
    settle()
  })
  onBeforeUnmount(() => {
    disposed = true
    observer?.disconnect()
  })
  return { width, breakpoint, projecting }
}
