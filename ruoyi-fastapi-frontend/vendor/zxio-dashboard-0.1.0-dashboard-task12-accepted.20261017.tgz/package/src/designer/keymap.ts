import {
  formatDashboardAriaKeyShortcuts,
  formatDashboardShortcut,
  isApplePlatform,
} from '../runtime/shortcut'

export type DashboardDesignerKeyAction =
  | 'undo'
  | 'redo'
  | 'save'
  | 'delete'
  | 'duplicate'
  | 'deselect'

/**
 * Designer bindings in canonical form; `Mod` is Cmd on Apple platforms and
 * Ctrl elsewhere. The first entry of each list is the one shown to users
 * (except `redo`, see {@link resolveDashboardDesignerShortcut}).
 */
export const DASHBOARD_DESIGNER_KEYMAP: Readonly<
  Record<DashboardDesignerKeyAction, readonly string[]>
> = {
  undo: ['Mod+Z'],
  redo: ['Mod+Shift+Z', 'Mod+Y'],
  save: ['Mod+S'],
  delete: ['Delete', 'Backspace'],
  duplicate: ['Mod+D'],
  deselect: ['Escape'],
}

/** Actions the designer claims before the grid engine sees the key. */
export const DASHBOARD_DESIGNER_CAPTURED_KEY_ACTIONS: ReadonlySet<DashboardDesignerKeyAction> =
  new Set<DashboardDesignerKeyAction>(['undo', 'redo', 'save', 'duplicate'])

export function resolveDashboardDesignerKeyAction(
  event: Pick<
    KeyboardEvent,
    'key' | 'metaKey' | 'ctrlKey' | 'shiftKey' | 'altKey' | 'isComposing'
  >,
  options: { apple?: boolean } = {}
): DashboardDesignerKeyAction | undefined {
  if (event.isComposing || event.key === 'Process') return undefined

  const apple = options.apple ?? isApplePlatform()
  const mod = apple ? event.metaKey : event.ctrlKey
  const foreignMod = apple ? event.ctrlKey : event.metaKey
  if (foreignMod || event.altKey) return undefined

  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key

  if (mod) {
    if (key === 'z') return event.shiftKey ? 'redo' : 'undo'
    if (event.shiftKey) return undefined
    if (key === 'y') return 'redo'
    if (key === 's') return 'save'
    if (key === 'd') return 'duplicate'
    return undefined
  }

  if (event.shiftKey) return undefined
  if (key === 'Delete' || key === 'Backspace') return 'delete'
  if (key === 'Escape') return 'deselect'
  return undefined
}

const EDITABLE_TARGET_SELECTOR = [
  'input',
  'textarea',
  'select',
  '[contenteditable]:not([contenteditable="false"])',
  '[role="textbox"]',
  '[role="combobox"]',
  '[role="searchbox"]',
].join(', ')

/** Text inputs keep their own undo / delete keys. */
export function isDashboardEditableKeyTarget(
  target: EventTarget | null | undefined
): boolean {
  if (!target || typeof (target as Element).closest !== 'function') return false
  const element = target as HTMLElement
  if (element.isContentEditable) return true
  return element.closest(EDITABLE_TARGET_SELECTOR) !== null
}

/** The binding shown for `action` on this platform (redo is Cmd+Shift+Z on Apple, Ctrl+Y elsewhere). */
export function resolveDashboardDesignerShortcut(
  action: DashboardDesignerKeyAction,
  options: { apple?: boolean } = {}
): string {
  const apple = options.apple ?? isApplePlatform()
  if (action === 'redo') return apple ? 'Mod+Shift+Z' : 'Mod+Y'
  return DASHBOARD_DESIGNER_KEYMAP[action][0]
}

export function formatDashboardDesignerShortcut(
  action: DashboardDesignerKeyAction,
  options: { apple?: boolean } = {}
): string {
  return formatDashboardShortcut(
    resolveDashboardDesignerShortcut(action, options),
    options
  )
}

export function formatDashboardDesignerAriaKeyShortcuts(
  action: DashboardDesignerKeyAction,
  options: { apple?: boolean } = {}
): string {
  return formatDashboardAriaKeyShortcuts(
    DASHBOARD_DESIGNER_KEYMAP[action],
    options
  )
}
