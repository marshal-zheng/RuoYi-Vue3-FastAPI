export { default as ZxDashboardDesigner } from './components/dashboard-designer.vue'
export {
  buildDashboardDesignerPalette,
  createDashboardDesignerPaletteKey,
} from './palette'
export { DASHBOARD_DESIGNER_RECENT_LIMIT } from './palette-preferences'
export {
  createDashboardDesignerPanel,
  createDefaultDashboardDesignerPanelId,
  findDashboardDesignerFreeSlot,
  resolveDashboardDesignerPanelSize,
} from './panel-factory'
export {
  clonePanels as cloneDashboardDesignerPanels,
  createDashboardDesignerLayoutMutation,
  createDashboardDesignerPanelAddMutation,
  createDashboardDesignerPanelDuplicateMutation,
  createDashboardDesignerPanelPatchMutation,
  createDashboardDesignerPanelRemoveMutation,
} from './panel-mutations'
export {
  createDashboardDesignerDocumentSnapshot,
  createDashboardDesignerExportRequest,
  createDashboardDesignerSaveRequest,
  validateDashboardDesignerSnapshot,
} from './validation'
export {
  provideDashboardDesignerContext,
  useDashboardDesignerContext,
  useRequiredDashboardDesignerContext,
} from './context/dashboard-designer-context'
export {
  createDashboardDesignerIssue,
  hasBlockingDashboardDesignerIssues,
  toDashboardDesignerIssue,
} from './issues'
export {
  DASHBOARD_DESIGNER_DRAG_MIME,
  beginDashboardDesignerDrag,
  encodeDashboardDesignerDragPayload,
  endDashboardDesignerDrag,
  parseDashboardDesignerDragPayload,
  readDashboardDesignerActiveDrag,
} from './drag'
export {
  DASHBOARD_DESIGNER_HISTORY_LIMIT,
  DASHBOARD_DESIGNER_HISTORY_SETTLE_WINDOW,
  createDashboardDesignerHistory,
  serializeDashboardPanels,
} from './history'
export { DASHBOARD_DESIGNER_ICONS } from './icons'
export {
  DASHBOARD_DESIGNER_CAPTURED_KEY_ACTIONS,
  DASHBOARD_DESIGNER_KEYMAP,
  formatDashboardDesignerAriaKeyShortcuts,
  formatDashboardDesignerShortcut,
  isDashboardEditableKeyTarget,
  resolveDashboardDesignerKeyAction,
  resolveDashboardDesignerShortcut,
} from './keymap'

export type {
  DashboardDesignerHistory,
  DashboardDesignerHistoryEntry,
  DashboardDesignerHistoryOptions,
} from './history'
export type { DashboardDesignerKeyAction } from './keymap'
export type {
  DashboardDesignerPalettePreferences,
  DashboardDesignerContext,
  DashboardDesignerCreatePanelId,
  DashboardDesignerEvent,
  DashboardDesignerEventSource,
  DashboardDesignerExportRequestEvent,
  DashboardDesignerHistoryAction,
  DashboardDesignerGroupingChangeEvent,
  DashboardDesignerHistoryChangeEvent,
  DashboardDesignerIssue,
  DashboardDesignerMode,
  DashboardDesignerPaletteGroup,
  DashboardDesignerPaletteItem,
  DashboardDesignerPanelAddRequestEvent,
  DashboardDesignerPanelCreateInput,
  DashboardDesignerPanelCreateResult,
  DashboardDesignerPanelDuplicateRequestEvent,
  DashboardDesignerPanelEditorProps,
  DashboardDesignerPanelMutationEvent,
  DashboardDesignerPanelPatchRequestEvent,
  DashboardDesignerPanelRemoveRequestEvent,
  DashboardDesignerSaveRequestEvent,
  DashboardDesignerValidationSummary,
  ZxDashboardDesignerProps,
} from './types'
