import type {
  DashboardDesignerPaletteGroup,
  DashboardDesignerPaletteItem,
} from './types'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetRegistryReadonly,
  DashboardWidgetVariantDefinition,
} from '../widget'

export function buildDashboardDesignerPalette(
  registry: DashboardWidgetRegistryReadonly,
  options: {
    search?: string
    includeVariants?: boolean
  } = {}
): DashboardDesignerPaletteGroup[] {
  const search = normalizeSearch(options.search)
  const includeVariants = options.includeVariants !== false
  const items = registry
    .list()
    .filter((definition) => definition.palette !== false)
    .flatMap((definition) => {
      const baseItem = createPaletteItem(definition)
      const variantItems = includeVariants
        ? (definition.variants ?? []).map((variant) =>
            createPaletteItem(definition, variant)
          )
        : []

      return [baseItem, ...variantItems]
    })
    .filter(
      (item) => item.lifecycle !== 'hidden' && matchesSearch(item, search)
    )
    .sort(comparePaletteItems)

  const groups = new Map<
    string,
    { name: string; order: number; items: DashboardDesignerPaletteItem[] }
  >()

  for (const item of items) {
    const group = groups.get(item.group)
    if (group) {
      group.items.push(item)
    } else {
      groups.set(item.group, {
        name: item.group,
        order: item.order,
        items: [item],
      })
    }
  }

  return Array.from(groups.values())
    .map((group) => ({
      ...group,
      order: Math.min(...group.items.map((item) => item.order)),
      items: group.items.sort(comparePaletteItems),
    }))
    .sort(comparePaletteGroups)
}

export function createDashboardDesignerPaletteKey(
  widget: string,
  variant?: string
): string {
  return JSON.stringify([widget, variant ?? null])
}

function createPaletteItem(
  definition: DashboardWidgetDefinition,
  variant?: DashboardWidgetVariantDefinition
): DashboardDesignerPaletteItem {
  const group = definition.group?.trim() || 'General'
  const title = variant?.title ?? definition.title ?? definition.name
  const description = variant?.description ?? definition.description
  const order = variant?.order ?? definition.order ?? 0
  const tags = Array.from(
    new Set(
      [
        ...(definition.tags ?? []),
        definition.name,
        definition.title,
        group,
        variant?.name,
        variant?.title,
      ].filter((value): value is string => Boolean(value?.trim()))
    )
  )

  return {
    key: createDashboardDesignerPaletteKey(definition.name, variant?.name),
    widget: definition.name,
    variant: variant?.name,
    title,
    description,
    group,
    icon: variant?.icon ?? definition.icon,
    thumbnail: variant?.thumbnail ?? definition.thumbnail,
    preview: variant?.preview ?? definition.preview,
    lifecycle: variant?.lifecycle ?? definition.lifecycle,
    tags,
    order,
    defaultGrid: {
      ...(definition.defaultGrid ?? {}),
      ...(variant?.defaultGrid ?? {}),
    },
  }
}

function normalizeSearch(search: string | undefined): string {
  return search?.trim().toLocaleLowerCase() ?? ''
}

export function matchesSearch(
  item: DashboardDesignerPaletteItem,
  search: string
): boolean {
  if (!search) return true

  const fields = [
    item.widget,
    item.variant,
    item.title,
    item.description,
    item.group,
    ...item.tags,
  ]

  return fields.some((field) => field?.toLocaleLowerCase().includes(search))
}

function comparePaletteGroups(
  a: DashboardDesignerPaletteGroup,
  b: DashboardDesignerPaletteGroup
): number {
  const byOrder = a.order - b.order
  if (byOrder !== 0) return byOrder
  return a.name.localeCompare(b.name)
}

function comparePaletteItems(
  a: DashboardDesignerPaletteItem,
  b: DashboardDesignerPaletteItem
): number {
  const byGroup = a.group.localeCompare(b.group)
  if (byGroup !== 0) return byGroup

  const byOrder = a.order - b.order
  if (byOrder !== 0) return byOrder

  const byTitle = a.title.localeCompare(b.title)
  if (byTitle !== 0) return byTitle

  const byWidget = a.widget.localeCompare(b.widget)
  if (byWidget !== 0) return byWidget

  return (a.variant ?? '').localeCompare(b.variant ?? '')
}
