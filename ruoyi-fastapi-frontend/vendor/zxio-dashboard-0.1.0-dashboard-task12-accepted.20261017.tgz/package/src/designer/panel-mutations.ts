import { cloneDashboardJson } from '../schema'
import { findDashboardDesignerFreeSlot } from './panel-factory'
import { dashboardLayoutPanelPeers } from '../runtime/grid/grouping'
import { projectDashboardPanels } from '../runtime/grid/responsive'

import type {
  DashboardBreakpoint,
  DashboardGridPosition,
  DashboardLayout,
  DashboardPanel,
} from '../schema'
import type {
  DashboardDesignerEventSource,
  DashboardDesignerMode,
  DashboardDesignerPanelDuplicateRequestEvent,
  DashboardDesignerPanelMutationEvent,
  DashboardDesignerPanelPatchRequestEvent,
  DashboardDesignerPanelRemoveRequestEvent,
} from './types'

export function createDashboardDesignerPanelAddMutation(input: {
  panels: readonly DashboardPanel[]
  panel: DashboardPanel
  mode: DashboardDesignerMode
  source: DashboardDesignerEventSource
}): DashboardDesignerPanelMutationEvent {
  const previousPanels = clonePanels(input.panels)
  const panel = cloneDashboardJson(input.panel)
  const panels = [...previousPanels, panel]

  return {
    type: 'panel-add-request',
    mode: input.mode,
    source: input.source,
    panelId: panel.id,
    panel,
    gridPos: panel.gridPos,
    previousPanels,
    panels,
  }
}

export function createDashboardDesignerPanelRemoveMutation(input: {
  panels: readonly DashboardPanel[]
  panelId: string
  mode: DashboardDesignerMode
  source: DashboardDesignerEventSource
}): DashboardDesignerPanelRemoveRequestEvent | undefined {
  const previousPanels = clonePanels(input.panels)
  const panel = previousPanels.find(
    (candidate) => candidate.id === input.panelId
  )
  if (!panel) return undefined

  return {
    type: 'panel-remove-request',
    mode: input.mode,
    source: input.source,
    panelId: panel.id,
    panel,
    previousPanels,
    panels: previousPanels.filter((candidate) => candidate.id !== panel.id),
  }
}

export function createDashboardDesignerPanelDuplicateMutation(input: {
  panels: readonly DashboardPanel[]
  panelId: string
  nextPanelId: string
  mode: DashboardDesignerMode
  source: DashboardDesignerEventSource
  /** Builds the duplicate's title from the source title. Defaults to `"<title> Copy"`. */
  formatCopyTitle?: (title: string) => string
  layout?: DashboardLayout
  columns?: number
}): DashboardDesignerPanelDuplicateRequestEvent | undefined {
  const previousPanels = clonePanels(input.panels)
  const panel = previousPanels.find(
    (candidate) => candidate.id === input.panelId
  )
  if (!panel) return undefined

  const formatCopyTitle =
    input.formatCopyTitle ?? ((title: string) => `${title} Copy`)
  const columns = input.columns ?? 24
  const peers = dashboardLayoutPanelPeers(previousPanels, input.layout, {
    panelId: panel.id,
  })
  const size = { w: Math.min(panel.gridPos.w, columns), h: panel.gridPos.h }
  const duplicate: DashboardPanel = {
    ...cloneDashboardJson(panel),
    id: input.nextPanelId,
    title: panel.title ? formatCopyTitle(panel.title) : undefined,
    gridPos: {
      ...size,
      ...findDashboardDesignerFreeSlot(peers, size, columns),
    },
  }
  if (panel.layouts) {
    duplicate.layouts = Object.fromEntries(
      Object.entries(panel.layouts).map(([key, position]) => {
        const size = { w: Math.min(position.w, columns), h: position.h }
        return [
          key,
          {
            ...size,
            ...findDashboardDesignerFreeSlot(
              projectDashboardPanels(
                peers,
                key as DashboardBreakpoint,
                columns
              ),
              size,
              columns
            ),
          },
        ]
      })
    )
  }

  return {
    type: 'panel-duplicate-request',
    mode: input.mode,
    source: input.source,
    panelId: panel.id,
    panel: duplicate,
    gridPos: duplicate.gridPos,
    previousPanels,
    panels: [...previousPanels, duplicate],
  }
}

export function createDashboardDesignerPanelPatchMutation(input: {
  panels: readonly DashboardPanel[]
  panelId: string
  patch: Partial<Omit<DashboardPanel, 'id'>>
  mode: DashboardDesignerMode
  source: DashboardDesignerEventSource
}): DashboardDesignerPanelPatchRequestEvent | undefined {
  const previousPanels = clonePanels(input.panels)
  const panel = previousPanels.find(
    (candidate) => candidate.id === input.panelId
  )
  if (!panel) return undefined

  const safePatch = stripProtectedPatch(input.patch)
  const patchedPanel = {
    ...panel,
    ...cloneDashboardJson(safePatch),
    id: panel.id,
  }

  return {
    type: 'panel-patch-request',
    mode: input.mode,
    source: input.source,
    panelId: panel.id,
    panel: patchedPanel,
    patch: safePatch,
    previousPanels,
    panels: previousPanels.map((candidate) =>
      candidate.id === panel.id ? patchedPanel : candidate
    ),
  }
}

export function createDashboardDesignerLayoutMutation(input: {
  previousPanels: readonly DashboardPanel[]
  panels: readonly DashboardPanel[]
  mode: DashboardDesignerMode
  source: DashboardDesignerEventSource
}): DashboardDesignerPanelMutationEvent {
  const previousPanels = clonePanels(input.previousPanels)
  const panels = clonePanels(input.panels)
  const previousById = new Map(
    previousPanels.map((panel) => [panel.id, panel.gridPos])
  )
  const changes = panels.flatMap((panel) => {
    const before = previousById.get(panel.id)
    if (!before || isSameGridPosition(before, panel.gridPos)) return []

    return [
      {
        panelId: panel.id,
        before,
        after: panel.gridPos,
      },
    ]
  })

  return {
    type: 'layout-change',
    mode: input.mode,
    source: input.source,
    previousPanels,
    panels,
    changes,
  }
}

export function clonePanels(
  panels: readonly DashboardPanel[]
): DashboardPanel[] {
  return cloneDashboardJson(panels) as DashboardPanel[]
}

function stripProtectedPatch(
  patch: Partial<Omit<DashboardPanel, 'id'>>
): Partial<Omit<DashboardPanel, 'id'>> {
  const { id: _stripId, ...rest } = patch as Partial<DashboardPanel>

  return rest
}

function isSameGridPosition(
  a: DashboardGridPosition,
  b: DashboardGridPosition
): boolean {
  return a.x === b.x && a.y === b.y && a.w === b.w && a.h === b.h
}
