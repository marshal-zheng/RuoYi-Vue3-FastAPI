import { dashboardLocaleEn, formatDashboardIssueMessage } from '../locale'

import type { DashboardLocale } from '../locale'
import type {
  DashboardDesignerAnyIssue,
  DashboardDesignerEventSource,
  DashboardDesignerIssue,
} from './types'

export function createDashboardDesignerIssue(
  issue: DashboardDesignerIssue
): DashboardDesignerIssue {
  return issue
}

export function toDashboardDesignerIssue(
  issue: DashboardDesignerAnyIssue,
  source: DashboardDesignerEventSource = 'designer'
): DashboardDesignerIssue {
  return {
    severity: issue.severity,
    code: issue.code,
    message: issue.message,
    path: 'path' in issue ? issue.path : undefined,
    panelId: 'panelId' in issue ? issue.panelId : undefined,
    widget: 'widget' in issue ? issue.widget : undefined,
    variant: 'variant' in issue ? issue.variant : undefined,
    suggestion: 'suggestion' in issue ? issue.suggestion : undefined,
    source,
  }
}

export function hasBlockingDashboardDesignerIssues(
  issues: readonly DashboardDesignerIssue[]
): boolean {
  return issues.some((issue) => issue.severity === 'error')
}

export function formatDesignerIssue(
  locale: DashboardLocale,
  issue: DashboardDesignerIssue
): string {
  // Keep detailed default English diagnostics. Every locale may replace a
  // known message, including an English host override.
  const template = (locale.issues as Record<string, string | undefined>)[
    issue.code
  ]
  const defaultTemplate = (
    dashboardLocaleEn.issues as Record<string, string | undefined>
  )[issue.code]
  if (
    template === defaultTemplate &&
    issue.code !== 'grid_below_min' &&
    issue.code !== 'grid_above_max'
  )
    return issue.message
  const translated = formatDashboardIssueMessage(locale, issue.code, {
    panelId: issue.panelId,
    widget: issue.widget,
    path: issue.path,
  })
  return translated && !/\{\w+\}/.test(translated) ? translated : issue.message
}
