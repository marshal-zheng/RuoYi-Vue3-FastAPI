import { computed, ref, watch } from 'vue'
import {
  cloneDashboardJson,
  collectDashboardJsonIssues,
  joinDashboardJsonPointer,
} from '../schema'
import {
  createDashboardWidgetSettingsDefaults,
  validateDashboardWidgetSettings,
} from '../widget/settings'

import type { DashboardJsonObject, DashboardJsonValue } from '../schema'
import type {
  DashboardWidgetSettingsDescriptor,
  DashboardWidgetSettingsField,
  DashboardWidgetSettingsIssue,
} from '../widget/settings'

/** A draft belongs to one form instance; only a valid Apply leaves this boundary. */
export function useDashboardSettingsFormState(
  props: {
    descriptor: DashboardWidgetSettingsDescriptor
    modelValue?: DashboardJsonObject
    disabled?: boolean
  },
  commit: (value: DashboardJsonObject) => void
) {
  const raw = ref<Record<string, string | boolean>>({})
  const invalidNumbers = ref<Record<string, boolean>>({})
  const touched = ref(false)

  function populate(value: DashboardJsonObject) {
    const next: Record<string, string | boolean> = {}
    for (const field of props.descriptor.fields) {
      const data = Object.prototype.hasOwnProperty.call(value, field.id)
        ? value[field.id]
        : undefined
      next[field.id] =
        field.type === 'boolean'
          ? data === undefined
            ? ''
            : typeof data === 'boolean'
            ? data
            : JSON.stringify(data)
          : data === undefined
          ? ''
          : ['enum', 'json', 'object', 'array'].includes(field.type)
          ? JSON.stringify(data, null, field.type === 'enum' ? 0 : 2)
          : String(data)
    }
    raw.value = next
    invalidNumbers.value = {}
    touched.value = false
  }
  watch(
    () => JSON.stringify([props.descriptor, props.modelValue ?? {}]),
    () => {
      populate(
        createDashboardWidgetSettingsDefaults(
          props.descriptor,
          props.modelValue
        )
      )
    },
    { immediate: true }
  )

  const parsed = computed(() => {
    const params = cloneDashboardJson(props.modelValue ?? {})
    const issues: DashboardWidgetSettingsIssue[] = []
    for (const field of props.descriptor.fields) {
      const input = raw.value[field.id]
      delete params[field.id]
      if (invalidNumbers.value[field.id] === true) {
        issues.push({
          severity: 'error',
          code: 'setting_type',
          fieldId: field.id,
          path: joinDashboardJsonPointer('/params', field.id),
          message: 'Enter a valid number.',
        })
        continue
      }
      if (input === '' || input === undefined) continue
      try {
        const value: DashboardJsonValue =
          field.type === 'number'
            ? Number(input)
            : ['enum', 'json', 'object', 'array'].includes(field.type)
            ? JSON.parse(String(input))
            : input
        const invalidJson = collectDashboardJsonIssues(
          value,
          joinDashboardJsonPointer('/params', field.id),
          { phase: 'import' }
        )
        if (invalidJson.length) {
          issues.push(
            ...invalidJson.map((issue) => ({ ...issue, fieldId: field.id }))
          )
          continue
        }
        params[field.id] = value
      } catch {
        issues.push({
          severity: 'error',
          code: 'setting_json',
          fieldId: field.id,
          path: joinDashboardJsonPointer('/params', field.id),
          message: 'Enter valid JSON.',
        })
      }
    }
    const invalidFields = new Set(issues.map((issue) => issue.fieldId))
    issues.push(
      ...validateDashboardWidgetSettings(
        props.descriptor,
        params
      ).issues.filter((issue) => !invalidFields.has(issue.fieldId))
    )
    return { params, issues }
  })
  function set(
    field: DashboardWidgetSettingsField,
    value: string | boolean,
    badInput = false
  ) {
    raw.value = { ...raw.value, [field.id]: value }
    invalidNumbers.value = { ...invalidNumbers.value, [field.id]: badInput }
    touched.value = true
  }
  function apply() {
    touched.value = true
    if (props.disabled || parsed.value.issues.length) return
    commit(cloneDashboardJson(parsed.value.params))
  }
  function reset() {
    const retained = cloneDashboardJson(props.modelValue ?? {})
    for (const field of props.descriptor.fields) delete retained[field.id]
    populate(createDashboardWidgetSettingsDefaults(props.descriptor, retained))
    touched.value = true
  }
  return { raw, touched, parsed, set, apply, reset }
}
