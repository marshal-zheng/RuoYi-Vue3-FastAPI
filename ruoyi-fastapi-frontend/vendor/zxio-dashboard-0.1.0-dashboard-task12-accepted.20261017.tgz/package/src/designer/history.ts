import { computed, shallowRef } from 'vue'
import { cloneDashboardJson } from '../schema'

import type { ComputedRef } from 'vue'
import type { DashboardLayout, DashboardPanel } from '../schema'
import type { DashboardDesignerEventSource } from './types'

export const DASHBOARD_DESIGNER_HISTORY_LIMIT = 100

/**
 * How long (ms) after a push the grid engine's own layout echo (compaction
 * after a removal, placement after a paste) still merges into that push.
 */
export const DASHBOARD_DESIGNER_HISTORY_SETTLE_WINDOW = 300

export interface DashboardDesignerHistoryEntry {
  /** Mutation that produced the entry (`panel-add-request`, `layout-change`, …). */
  type: string
  source: DashboardDesignerEventSource
  before: DashboardPanel[]
  after: DashboardPanel[]
  beforeLayout?: DashboardLayout
  afterLayout?: DashboardLayout
  /** Key of the batch (`beginBatch`) the entry was recorded in, if any. */
  batch?: string
}

export interface DashboardDesignerHistoryOptions {
  /** The live panels; `dirty` compares them with the saved snapshot. */
  current: () => readonly DashboardPanel[]
  currentLayout?: () => DashboardLayout | undefined
  /** Undo depth. Defaults to {@link DASHBOARD_DESIGNER_HISTORY_LIMIT}. */
  limit?: number
  /** Settle window in ms. Defaults to {@link DASHBOARD_DESIGNER_HISTORY_SETTLE_WINDOW}. */
  settleWindow?: number
  /** Clock used for the settle window; tests inject a fake one. */
  now?: () => number
}

/**
 * Document-level undo history over `panels` snapshots. It is independent of
 * the grid engine's own geometry history on purpose: panel titles, params and
 * removals are not engine transactions, and one history must own them all.
 *
 * Engine echoes are folded in rather than recorded: a grid `layout-change`
 * that arrives inside the settle window after a push (the compaction that
 * follows a removal, the placement that follows a paste) extends that push;
 * one that follows an `undo` / `redo` is dropped; one that follows creation
 * or `reset` (the engine compacting a freshly loaded document) moves the
 * clean baseline instead of making the document dirty.
 */
export interface DashboardDesignerHistory {
  canUndo: ComputedRef<boolean>
  canRedo: ComputedRef<boolean>
  /** Whether the live panels differ from the last saved snapshot. */
  dirty: ComputedRef<boolean>
  past: () => readonly DashboardDesignerHistoryEntry[]
  future: () => readonly DashboardDesignerHistoryEntry[]
  /**
   * Records a mutation. Returns `false` when nothing was recorded: `before`
   * equals `after`, or the push was an engine echo folded in as described above.
   */
  push: (entry: Omit<DashboardDesignerHistoryEntry, 'batch'>) => boolean
  undo: () => DashboardDesignerHistoryEntry | undefined
  redo: () => DashboardDesignerHistoryEntry | undefined
  /**
   * Opens a batch: every push until `endBatch()` merges into one entry, so a
   * drag or resize with several layout echoes is one undo step. A batch that
   * ends where it started leaves no entry.
   */
  beginBatch: (key: string) => void
  endBatch: () => void
  isDirty: (
    panels?: readonly DashboardPanel[],
    layout?: DashboardLayout
  ) => boolean
  savedPanels: () => DashboardPanel[]
  savedLayout: () => DashboardLayout | undefined
  /** Makes `panels` (default: the live panels) the clean baseline. */
  markSaved: (
    panels?: readonly DashboardPanel[],
    layout?: DashboardLayout
  ) => void
  /** Clears both stacks and makes `panels` (default: the live panels) the clean baseline. */
  reset: (panels?: readonly DashboardPanel[], layout?: DashboardLayout) => void
}

export function createDashboardDesignerHistory(
  options: DashboardDesignerHistoryOptions
): DashboardDesignerHistory {
  const limit = Math.max(
    1,
    Math.floor(options.limit ?? DASHBOARD_DESIGNER_HISTORY_LIMIT)
  )
  const settleWindow = Math.max(
    0,
    options.settleWindow ?? DASHBOARD_DESIGNER_HISTORY_SETTLE_WINDOW
  )
  const now = options.now ?? Date.now
  const past = shallowRef<DashboardDesignerHistoryEntry[]>([])
  const future = shallowRef<DashboardDesignerHistoryEntry[]>([])
  const saved = shallowRef(
    snapshot(options.current(), options.currentLayout?.())
  )

  let openBatch:
    | { key: string; entry?: DashboardDesignerHistoryEntry }
    | undefined
  // The entry the next engine echo extends, and until when.
  let settleEntry: DashboardDesignerHistoryEntry | undefined
  let settleUntil = 0
  // Echoes after an undo / redo are dropped until this time.
  let ignoreUntil = 0
  // Echoes after creation / reset move the baseline until this time.
  let baselineUntil = now() + settleWindow

  const canUndo = computed(() => past.value.length > 0)
  const canRedo = computed(() => future.value.length > 0)
  const dirty = computed(
    () =>
      signature(options.current(), options.currentLayout?.()) !==
      saved.value.signature
  )

  function push(input: Omit<DashboardDesignerHistoryEntry, 'batch'>): boolean {
    const afterSignature = signature(input.after, input.afterLayout)
    if (signature(input.before, input.beforeLayout) === afterSignature)
      return false

    const time = now()
    const last = past.value[past.value.length - 1]
    const echo =
      !openBatch &&
      input.type === 'layout-change' &&
      input.source === 'grid' &&
      input.before.length === input.after.length &&
      input.before.every((panel) =>
        input.after.some((next) => next.id === panel.id)
      )

    if (echo) {
      if (time <= ignoreUntil) return false
      if (
        time <= baselineUntil &&
        past.value.length === 0 &&
        future.value.length === 0
      ) {
        saved.value = snapshot(input.after, input.afterLayout)
        return false
      }
    }

    const mergeInto = openBatch
      ? openBatch.entry && last === openBatch.entry
        ? last
        : undefined
      : echo && last && last === settleEntry && time <= settleUntil
      ? last
      : undefined

    if (mergeInto) {
      const head = past.value.slice(0, -1)
      // A batch that ends where it started (drag back to the origin) is no step.
      const merged =
        signature(mergeInto.before, mergeInto.beforeLayout) === afterSignature
          ? undefined
          : {
              ...mergeInto,
              after: clonePanels(input.after),
              afterLayout: cloneLayout(input.afterLayout),
            }
      past.value = merged ? [...head, merged] : head
      future.value = []
      if (openBatch) openBatch.entry = merged
      else settleEntry = merged
      if (merged) settleUntil = time + settleWindow
      return true
    }

    const entry: DashboardDesignerHistoryEntry = {
      type: input.type,
      source: input.source,
      before: clonePanels(input.before),
      after: clonePanels(input.after),
      beforeLayout: cloneLayout(input.beforeLayout),
      afterLayout: cloneLayout(input.afterLayout),
      batch: openBatch?.key,
    }
    const next = [...past.value, entry]
    past.value = next.length > limit ? next.slice(next.length - limit) : next
    future.value = []
    if (openBatch) {
      openBatch.entry = entry
    } else {
      settleEntry = entry
      settleUntil = time + settleWindow
    }
    return true
  }

  function undo(): DashboardDesignerHistoryEntry | undefined {
    const entry = past.value[past.value.length - 1]
    if (!entry) return undefined
    past.value = past.value.slice(0, -1)
    future.value = [...future.value, entry]
    settleApplied()
    return entry
  }

  function redo(): DashboardDesignerHistoryEntry | undefined {
    const entry = future.value[future.value.length - 1]
    if (!entry) return undefined
    future.value = future.value.slice(0, -1)
    past.value = [...past.value, entry]
    settleApplied()
    return entry
  }

  function settleApplied(): void {
    openBatch = undefined
    settleEntry = undefined
    ignoreUntil = now() + settleWindow
  }

  function beginBatch(key: string): void {
    openBatch = { key }
    settleEntry = undefined
    ignoreUntil = 0
    baselineUntil = 0
  }

  function endBatch(): void {
    if (!openBatch) return
    settleEntry = openBatch.entry
    settleUntil = now() + settleWindow
    openBatch = undefined
  }

  function markSaved(
    panels?: readonly DashboardPanel[],
    layout?: DashboardLayout
  ): void {
    saved.value = snapshot(
      panels ?? options.current(),
      arguments.length > 1 ? layout : options.currentLayout?.()
    )
  }

  function reset(
    panels?: readonly DashboardPanel[],
    layout?: DashboardLayout
  ): void {
    past.value = []
    future.value = []
    openBatch = undefined
    settleEntry = undefined
    ignoreUntil = 0
    baselineUntil = now() + settleWindow
    saved.value = snapshot(
      panels ?? options.current(),
      arguments.length > 1 ? layout : options.currentLayout?.()
    )
  }

  return {
    canUndo,
    canRedo,
    dirty,
    past: () => past.value,
    future: () => future.value,
    push,
    undo,
    redo,
    beginBatch,
    endBatch,
    isDirty(panels, layout) {
      return (
        signature(
          panels ?? options.current(),
          arguments.length > 1 ? layout : options.currentLayout?.()
        ) !== saved.value.signature
      )
    },
    savedPanels: () => clonePanels(saved.value.panels),
    savedLayout: () => cloneLayout(saved.value.layout),
    markSaved,
    reset,
  }
}

/**
 * Order-insensitive JSON form of `panels` (object keys sorted, `undefined`
 * members dropped) so two snapshots compare by value.
 */
export function serializeDashboardPanels(
  panels: readonly DashboardPanel[]
): string {
  return stableSerialize(panels)
}

function snapshot(
  panels: readonly DashboardPanel[],
  layout?: DashboardLayout
): {
  layout?: DashboardLayout
  panels: DashboardPanel[]
  signature: string
} {
  return {
    panels: clonePanels(panels),
    layout: cloneLayout(layout),
    signature: signature(panels, layout),
  }
}

function clonePanels(panels: readonly DashboardPanel[]): DashboardPanel[] {
  return cloneDashboardJson(panels) as DashboardPanel[]
}

function stableSerialize(value: unknown): string {
  if (Array.isArray(value)) {
    return `[${value.map((item) => stableSerialize(item)).join(',')}]`
  }
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>
    const members = Object.keys(record)
      .sort()
      .filter((key) => record[key] !== undefined)
      .map((key) => `${JSON.stringify(key)}:${stableSerialize(record[key])}`)
    return `{${members.join(',')}}`
  }
  return JSON.stringify(value) ?? 'null'
}

function signature(
  panels: readonly DashboardPanel[],
  layout?: DashboardLayout
): string {
  return stableSerialize({ panels, layout })
}
function cloneLayout(layout?: DashboardLayout): DashboardLayout | undefined {
  return layout ? cloneDashboardJson(layout) : undefined
}
