<script setup lang="ts">
import { computed, nextTick, ref, watch } from 'vue'
import { useDashboardLocale } from '../../locale'
import ZxDashboardPaletteCard from './dashboard-palette-card.vue'
import { matchesSearch } from '../palette'

import type {
  DashboardDesignerPaletteGroup,
  DashboardDesignerPaletteItem,
  DashboardDesignerPalettePreferences,
} from '../types'

const props = defineProps<{
  groups: DashboardDesignerPaletteGroup[]
  search?: string
  preferences?: DashboardDesignerPalettePreferences
}>()
const emit = defineEmits<{
  (e: 'update:search', value: string): void
  (e: 'add', item: DashboardDesignerPaletteItem): void
  (e: 'toggleFavorite', key: string): void
}>()
defineSlots<{ empty?(): any }>()
const locale = useDashboardLocale()
const root = ref<HTMLElement>()
const view = ref<'all' | 'recent' | 'favorites'>('all')
const category = ref('')
watch(
  () => props.groups,
  (groups) => {
    if (
      category.value &&
      !groups.some((group) => group.name === category.value)
    )
      category.value = ''
  }
)
const views = ['all', 'recent', 'favorites'] as const
const filtered = computed(() => {
  const search = props.search?.trim().toLocaleLowerCase() ?? ''
  const groups = props.groups
    .filter((group) => !category.value || group.name === category.value)
    .map((group) => ({
      ...group,
      items: group.items.filter((item) => matchesSearch(item, search)),
    }))
    .filter((group) => group.items.length)
  if (view.value === 'all') return groups
  const order = props.preferences?.[view.value] ?? []
  const items = groups
    .flatMap((group) => group.items)
    .filter((item) => order.includes(item.key))
    .sort((a, b) => order.indexOf(a.key) - order.indexOf(b.key))
  return items.length
    ? [{ name: locale.value.palette[view.value], order: 0, items }]
    : []
})
function toggleFavorite(key: string) {
  const active = document.activeElement
  const owned = !!active && root.value?.contains(active)
  emit('toggleFavorite', key)
  nextTick(() => {
    if (owned && active && !active.isConnected)
      root.value
        ?.querySelector<HTMLElement>(
          '.zx-dashboard-designer-palette__views [aria-pressed="true"]'
        )
        ?.focus()
  })
}
</script>

<template>
  <aside
    ref="root"
    class="zx-dashboard-designer-palette"
    data-dashboard-designer-region="palette"
  >
    <div class="zx-dashboard-designer-palette__search">
      <input
        class="zx-dashboard-designer-palette__input"
        type="search"
        :value="search ?? ''"
        :placeholder="locale.palette.search"
        :aria-label="locale.palette.search"
        @input="
          emit('update:search', ($event.target as HTMLInputElement).value)
        "
      />
    </div>
    <div
      class="zx-dashboard-designer-palette__views"
      role="group"
      :aria-label="locale.palette.all"
    >
      <button
        v-for="key in views"
        :key="key"
        type="button"
        :aria-pressed="view === key"
        @click="view = key"
      >
        {{ locale.palette[key] }}
      </button>
    </div>
    <label class="zx-dashboard-designer-palette__category"
      >{{ locale.palette.category }}
      <select v-model="category">
        <option value="">{{ locale.palette.allCategories }}</option>
        <option v-for="group in groups" :key="group.name" :value="group.name">
          {{ group.name }}
        </option>
      </select>
    </label>
    <slot v-if="filtered.length === 0" name="empty"
      ><div class="zx-dashboard-designer-palette__empty">
        {{ locale.palette.empty }}
      </div></slot
    >
    <section
      v-for="group in filtered"
      :key="group.name"
      class="zx-dashboard-designer-palette__group"
      :data-palette-group="group.name"
    >
      <h3 class="zx-dashboard-designer-palette__group-title">
        {{ group.name }}
      </h3>
      <ZxDashboardPaletteCard
        v-for="item in group.items"
        :key="item.key"
        :item="item"
        :favorite="preferences?.favorites.includes(item.key) ?? false"
        @add="emit('add', $event)"
        @toggle-favorite="toggleFavorite"
      />
    </section>
  </aside>
</template>
