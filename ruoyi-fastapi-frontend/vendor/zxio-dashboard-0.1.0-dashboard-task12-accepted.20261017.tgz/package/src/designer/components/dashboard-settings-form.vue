<script setup lang="ts">
import { computed, useId } from 'vue'
import { evaluateDashboardWidgetSettingsPredicate } from '../../widget/settings'
import { formatDashboardIssueMessage, useDashboardLocale } from '../../locale'
import { useDashboardSettingsFormState } from '../settings-form-state'

import type { PropType } from 'vue'
import type { DashboardJsonObject } from '../../schema'
import type {
  DashboardWidgetSettingsDescriptor,
  DashboardWidgetSettingsField,
} from '../../widget/settings'

const props = defineProps({
  descriptor: {
    type: Object as PropType<DashboardWidgetSettingsDescriptor>,
    required: true,
  },
  modelValue: Object as PropType<DashboardJsonObject>,
  disabled: Boolean,
})
const emit = defineEmits<{
  (e: 'update:modelValue', value: DashboardJsonObject): void
}>()
const locale = useDashboardLocale()
const uid = useId()
const state = useDashboardSettingsFormState(props, (value) =>
  emit('update:modelValue', value)
)
const groups = computed(() => {
  const fields = props.descriptor.fields
    .filter(
      (field) =>
        field.status !== 'hidden' &&
        (!field.visibleWhen ||
          evaluateDashboardWidgetSettingsPredicate(
            field.visibleWhen,
            state.parsed.value.params
          ))
    )
    .slice()
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
  const groups = new Map<
    string,
    {
      id: string
      label?: string
      order: number
      fields: DashboardWidgetSettingsField[]
    }
  >()
  for (const field of fields) {
    const id = field.group ?? ''
    if (!groups.has(id)) {
      const group = props.descriptor.groups?.find((item) => item.id === id)
      groups.set(id, {
        id,
        label: group?.label ?? (id || undefined),
        order: group?.order ?? 0,
        fields: [],
      })
    }
    groups.get(id)!.fields.push(field)
  }
  return [...groups.values()].sort((a, b) => a.order - b.order)
})
const generalIssues = computed(() =>
  state.touched.value
    ? state.parsed.value.issues.filter((issue) => !issue.fieldId)
    : []
)
const fieldId = (field: DashboardWidgetSettingsField) =>
  `${uid}-${props.descriptor.fields.indexOf(field)}`
const label = (field: DashboardWidgetSettingsField) =>
  field.label ?? field.labelKey ?? field.id
const error = (field: DashboardWidgetSettingsField) =>
  state.touched.value
    ? state.parsed.value.issues.find((issue) => issue.fieldId === field.id)
    : undefined
const disabledField = (field: DashboardWidgetSettingsField) =>
  props.disabled ||
  !!(
    field.enabledWhen &&
    !evaluateDashboardWidgetSettingsPredicate(
      field.enabledWhen,
      state.parsed.value.params
    )
  )
function input(field: DashboardWidgetSettingsField, event: Event) {
  const target = event.target as HTMLInputElement
  state.set(
    field,
    field.type === 'boolean' ? target.checked : target.value,
    field.type === 'number' && target.validity.badInput
  )
}
</script>

<template>
  <form class="zx-dashboard-settings" novalidate @submit.prevent="state.apply">
    <p
      v-for="issue in generalIssues"
      :key="issue.path"
      role="alert"
      class="zx-dashboard-settings__error"
    >
      {{ formatDashboardIssueMessage(locale, issue.code) ?? issue.message }}
    </p>
    <fieldset
      v-for="group in groups"
      :key="group.id"
      :disabled="disabled"
      class="zx-dashboard-settings__group"
    >
      <legend v-if="group.label">{{ group.label }}</legend>
      <div
        v-for="field in group.fields"
        :key="field.id"
        class="zx-dashboard-settings__field"
        :data-setting="field.id"
      >
        <label :for="fieldId(field)"
          >{{ label(field)
          }}<span v-if="field.required" aria-hidden="true"> *</span></label
        >
        <input
          v-if="field.type === 'boolean'"
          :id="fieldId(field)"
          type="checkbox"
          :checked="state.raw.value[field.id] === true"
          :disabled="disabledField(field)"
          :aria-required="field.required"
          :aria-invalid="!!error(field)"
          :aria-describedby="`${fieldId(field)}-hint ${fieldId(field)}-error`"
          @change="input(field, $event)"
        />
        <select
          v-else-if="field.type === 'enum'"
          :id="fieldId(field)"
          :value="String(state.raw.value[field.id] ?? '')"
          :disabled="disabledField(field)"
          :aria-required="field.required"
          :aria-invalid="!!error(field)"
          :aria-describedby="`${fieldId(field)}-hint ${fieldId(field)}-error`"
          @change="input(field, $event)"
        >
          <option value="">{{ locale.settings.choose }}</option>
          <option
            v-for="(option, index) in field.options"
            :key="index"
            :value="JSON.stringify(option.value)"
          >
            {{ option.label ?? option.labelKey ?? String(option.value) }}
          </option>
        </select>
        <textarea
          v-else-if="['text', 'json', 'object', 'array'].includes(field.type)"
          :id="fieldId(field)"
          :value="String(state.raw.value[field.id] ?? '')"
          :rows="field.type === 'text' ? 3 : 5"
          :disabled="disabledField(field)"
          :aria-required="field.required"
          :aria-invalid="!!error(field)"
          :aria-describedby="`${fieldId(field)}-hint ${fieldId(field)}-error`"
          @input="input(field, $event)"
        />
        <div v-else class="zx-dashboard-settings__input-row">
          <input
            :id="fieldId(field)"
            :type="field.type === 'number' ? 'number' : 'text'"
            :value="String(state.raw.value[field.id] ?? '')"
            :min="field.validation?.min"
            :max="field.validation?.max"
            :maxlength="field.validation?.maxLength"
            step="any"
            :disabled="disabledField(field)"
            :aria-required="field.required"
            :aria-invalid="!!error(field)"
            :aria-describedby="`${fieldId(field)}-hint ${fieldId(field)}-error`"
            @input="input(field, $event)"
          />
          <input
            v-if="field.type === 'color'"
            type="color"
            :aria-label="`${label(field)}: ${locale.settings.colorPicker}`"
            :disabled="disabledField(field)"
            :value="
              /^#[\da-f]{6}$/i.test(String(state.raw.value[field.id]))
                ? String(state.raw.value[field.id])
                : '#000000'
            "
            @input="input(field, $event)"
          />
        </div>
        <small :id="`${fieldId(field)}-hint`">{{ field.description }}</small>
        <small
          :id="`${fieldId(field)}-error`"
          class="zx-dashboard-settings__error"
          :role="error(field) ? 'alert' : undefined"
          >{{
            error(field)
              ? formatDashboardIssueMessage(locale, error(field)!.code) ??
                error(field)!.message
              : ''
          }}</small
        >
      </div>
    </fieldset>
    <div class="zx-dashboard-settings__actions">
      <button type="submit" :disabled="disabled">
        {{ locale.settings.apply }}
      </button>
      <button type="button" :disabled="disabled" @click="state.reset">
        {{ locale.settings.reset }}
      </button>
    </div>
  </form>
</template>
