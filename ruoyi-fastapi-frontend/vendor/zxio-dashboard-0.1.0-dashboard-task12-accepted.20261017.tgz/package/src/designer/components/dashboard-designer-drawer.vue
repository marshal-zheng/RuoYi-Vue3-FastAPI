<template>
  <aside
    v-if="panel"
    class="zx-dashboard-designer-drawer"
    data-dashboard-designer-region="drawer"
  >
    <header class="zx-dashboard-designer-drawer__header">
      <div class="zx-dashboard-designer-drawer__title">
        {{ panel.title || definition?.title || panel.widget }}
      </div>
      <button
        class="zx-dashboard-designer-drawer__close"
        type="button"
        :aria-label="locale.drawer.close"
        :title="locale.drawer.close"
        @click="$emit('close')"
      >
        ×
      </button>
    </header>

    <div class="zx-dashboard-designer-drawer__body">
      <slot
        name="editor"
        :panel="panel"
        :definition="definition"
        :variant="variant"
        :request-panel-patch="requestPanelPatch"
      >
        <component
          :is="editor"
          v-if="editor"
          :panel="panel"
          :definition="definition"
          :variant="variant"
          :request-panel-patch="requestPanelPatch"
        />
        <ZxDashboardSettingsForm
          v-else-if="settings?.fields.length"
          :key="panel.id"
          :descriptor="settings"
          :model-value="panel.params"
          @update:model-value="requestPanelPatch({ params: $event })"
        />
        <slot
          v-else
          name="fallback"
          :panel="panel"
          :definition="definition"
          :variant="variant"
        >
          <div class="zx-dashboard-designer-drawer__fallback">
            {{ locale.drawer.fallback }}
          </div>
        </slot>
      </slot>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useDashboardLocale } from '../../locale'
import { resolveDashboardWidgetComponent } from '../../widget/async-component'
import ZxDashboardSettingsForm from './dashboard-settings-form.vue'

import type { DashboardPanel } from '../../schema'
import type {
  DashboardWidgetComponent,
  DashboardWidgetDefinition,
  DashboardWidgetVariantDefinition,
} from '../../widget'

const props = defineProps<{
  panel?: Readonly<DashboardPanel>
  definition?: Readonly<DashboardWidgetDefinition>
  variant?: Readonly<DashboardWidgetVariantDefinition>
  editor?: DashboardWidgetComponent
  requestPanelPatch: (patch: Partial<Omit<DashboardPanel, 'id'>>) => void
}>()

defineEmits<{
  (event: 'close'): void
}>()

const locale = useDashboardLocale()
const settings = computed(
  () => props.variant?.settings ?? props.definition?.settings
)
const editor = computed(() =>
  props.editor
    ? resolveDashboardWidgetComponent(props.editor, {
        widget: props.panel?.widget ?? '',
        variant: props.panel?.variant,
      })
    : undefined
)
</script>
