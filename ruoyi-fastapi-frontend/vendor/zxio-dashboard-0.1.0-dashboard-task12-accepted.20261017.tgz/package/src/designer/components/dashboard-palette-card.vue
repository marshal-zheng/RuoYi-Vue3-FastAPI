<script setup lang="ts">
import {
  defineComponent,
  h,
  onBeforeUnmount,
  ref,
  shallowRef,
  watch,
} from 'vue'
import { resolveDashboardWidgetComponent } from '../../widget/async-component'
import { formatDashboardCopy, useDashboardLocale } from '../../locale'
import {
  beginDashboardDesignerDrag,
  endDashboardDesignerDrag,
  endDashboardDesignerDragFrom,
  setDashboardDesignerDragImage,
} from '../drag'

import type { Component } from 'vue'
import type { DashboardDesignerPaletteItem } from '../types'

const props = defineProps<{
  item: DashboardDesignerPaletteItem
  favorite: boolean
}>()
const emit = defineEmits<{
  (e: 'add', item: DashboardDesignerPaletteItem): void
  (e: 'toggleFavorite', key: string): void
}>()
const locale = useDashboardLocale()
const root = ref<HTMLElement>()
const imageFailed = ref(false)
const preview = shallowRef<Component>()
const PreviewError = defineComponent({
  setup: () => () => h('span', locale.value.palette.previewFailed),
})
watch(
  () => props.item.thumbnail,
  () => {
    imageFailed.value = false
  }
)
watch(
  () => props.item.preview,
  (component) => {
    preview.value = component
      ? resolveDashboardWidgetComponent(component, {
          widget: props.item.widget,
          variant: props.item.variant,
          errorComponent: PreviewError,
        })
      : undefined
  },
  { immediate: true }
)
onBeforeUnmount(() => endDashboardDesignerDragFrom(root.value))
function drag(event: DragEvent) {
  beginDashboardDesignerDrag(event.dataTransfer, {
    widget: props.item.widget,
    variant: props.item.variant,
  })
  if (root.value) setDashboardDesignerDragImage(event.dataTransfer, root.value)
}
</script>

<template>
  <div ref="root" class="zx-dashboard-designer-palette__card">
    <span
      v-if="(item.thumbnail && !imageFailed) || preview"
      class="zx-dashboard-designer-palette__preview"
      aria-hidden="true"
      inert
    >
      <img
        v-if="item.thumbnail && !imageFailed"
        :src="item.thumbnail"
        alt=""
        loading="lazy"
        decoding="async"
        draggable="false"
        @error="imageFailed = true"
      />
      <component
        :is="preview"
        v-else
        :widget="item.widget"
        :variant="item.variant"
        :title="item.title"
      />
    </span>

    <button
      class="zx-dashboard-designer-palette__item"
      type="button"
      draggable="true"
      :data-widget="item.widget"
      :data-variant="item.variant"
      @click="emit('add', item)"
      @dragstart="drag"
      @dragend="endDashboardDesignerDrag"
    >
      <span
        v-if="item.icon && !(item.thumbnail && !imageFailed) && !preview"
        class="zx-dashboard-designer-palette__item-icon"
        aria-hidden="true"
      >
        <template v-if="typeof item.icon === 'string'">{{
          item.icon
        }}</template>
        <component :is="item.icon" v-else />
      </span>
      <span class="zx-dashboard-designer-palette__item-body">
        <span class="zx-dashboard-designer-palette__item-title">{{
          item.title
        }}</span>
        <span
          v-if="
            item.lifecycle === 'experimental' || item.lifecycle === 'deprecated'
          "
          class="zx-dashboard-designer-palette__badge"
          >{{ locale.palette[item.lifecycle] }}</span
        >
        <span
          v-if="item.description"
          class="zx-dashboard-designer-palette__item-description"
          >{{ item.description }}</span
        >
      </span>
    </button>
    <button
      type="button"
      class="zx-dashboard-designer-palette__favorite"
      :aria-pressed="favorite"
      :aria-label="
        formatDashboardCopy(
          favorite ? locale.palette.unfavorite : locale.palette.favorite,
          { title: item.title }
        )
      "
      @click="emit('toggleFavorite', item.key)"
    >
      {{ favorite ? '★' : '☆' }}
    </button>
  </div>
</template>
