import { computed, ref } from 'vue'
import { createDashboardDesignerPaletteKey } from './palette'

import type { DashboardDesignerPalettePreferences } from './types'

export const DASHBOARD_DESIGNER_RECENT_LIMIT = 12

export function useDashboardDesignerPalettePreferences(props: {
  value?: DashboardDesignerPalettePreferences
  onChange: (value: DashboardDesignerPalettePreferences) => void
}) {
  const internal = ref<DashboardDesignerPalettePreferences>({
    favorites: [],
    recent: [],
  })
  const value = computed(() => ({
    favorites: unique(props.value?.favorites ?? internal.value.favorites),
    recent: unique(props.value?.recent ?? internal.value.recent).slice(
      0,
      DASHBOARD_DESIGNER_RECENT_LIMIT
    ),
  }))
  function publish(next: DashboardDesignerPalettePreferences) {
    if (props.value === undefined) internal.value = next
    props.onChange({ favorites: [...next.favorites], recent: [...next.recent] })
  }
  function toggleFavorite(key: string) {
    const current = value.value
    publish({
      ...current,
      favorites: current.favorites.includes(key)
        ? current.favorites.filter((item) => item !== key)
        : [...current.favorites, key],
    })
  }
  function recordRecent(widget: string, variant?: string) {
    const current = value.value
    const key = createDashboardDesignerPaletteKey(widget, variant)
    publish({
      ...current,
      recent: [key, ...current.recent.filter((item) => item !== key)].slice(
        0,
        DASHBOARD_DESIGNER_RECENT_LIMIT
      ),
    })
  }
  return { value, toggleFavorite, recordRecent }
}

function unique(values: readonly string[]): string[] {
  return Array.isArray(values)
    ? [...new Set(values.filter((value) => typeof value === 'string'))]
    : []
}
