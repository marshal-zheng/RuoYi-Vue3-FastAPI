import {
  DASHBOARD_BREAKPOINTS,
  isDashboardPlainObject,
  validateDashboardGridPositionInput,
} from '../schema'

import type { DashboardSchemaIssue } from './issues'

export function validateDashboardResponsiveLayouts(
  value: unknown,
  path: string,
  issues: DashboardSchemaIssue[]
): void {
  if (value === undefined) return
  if (!isDashboardPlainObject(value)) {
    issues.push(issue(path, 'layouts must be a breakpoint-to-position object.'))
    return
  }
  for (const [key, position] of Object.entries(value)) {
    if (!Object.prototype.hasOwnProperty.call(DASHBOARD_BREAKPOINTS, key)) {
      issues.push(issue(`${path}/${key}`, 'Unknown dashboard breakpoint.'))
    } else {
      issues.push(
        ...validateDashboardGridPositionInput(position, `${path}/${key}`).issues
      )
    }
  }
}

export function validateDashboardLayout(
  value: unknown,
  panels: unknown,
  issues: DashboardSchemaIssue[]
): void {
  if (value === undefined) return
  const panelIds = new Set(
    Array.isArray(panels)
      ? panels.filter(isDashboardPlainObject).map((panel) => panel.id)
      : []
  )
  const members = new Set<string>()
  const groupIds = new Set<string>()
  const fail = (path: string, message: string) =>
    issues.push(issue(path, message))

  function fields(
    input: Record<string, unknown>,
    allowed: string[],
    path: string
  ) {
    for (const key of Object.keys(input)) {
      if (!allowed.includes(key))
        fail(`${path}/${key}`, 'Unknown layout field.')
    }
  }
  function membership(children: unknown, path: string) {
    if (!Array.isArray(children)) {
      fail(path, 'children must be panel ids.')
      return
    }
    children.forEach((id, index) => {
      if (typeof id !== 'string' || !panelIds.has(id)) {
        fail(`${path}/${index}`, 'Layout references an unknown panel.')
      } else if (members.has(id)) {
        fail(
          `${path}/${index}`,
          'A panel must belong to exactly one container.'
        )
      } else members.add(id)
    })
  }
  function group(input: unknown, path: string, row: boolean) {
    if (!isDashboardPlainObject(input)) {
      fail(path, 'Group must be an object.')
      return false
    }
    fields(
      input,
      row
        ? ['id', 'title', 'collapsed', 'children']
        : ['id', 'title', 'children'],
      path
    )
    if (
      typeof input.id !== 'string' ||
      !input.id.trim() ||
      groupIds.has(input.id)
    ) {
      fail(`${path}/id`, 'Group ids must be non-empty and globally unique.')
    } else groupIds.add(input.id)
    if (typeof input.title !== 'string' || !input.title.trim())
      fail(`${path}/title`, 'Group title is required.')
    if (
      row &&
      input.collapsed !== undefined &&
      typeof input.collapsed !== 'boolean'
    ) {
      fail(`${path}/collapsed`, 'collapsed must be boolean.')
    }
    return true
  }
  function container(input: unknown, path: string, allowTabs: boolean) {
    if (!isDashboardPlainObject(input)) {
      fail(path, 'Layout must be an object.')
      return
    }
    fields(input, ['type', 'children'], path)
    if (input.type === 'grid') {
      membership(input.children, `${path}/children`)
      return
    }
    if (!Array.isArray(input.children)) {
      fail(`${path}/children`, 'children must be an array.')
      return
    }
    if (input.type === 'rows') {
      input.children.forEach((row, i) => {
        const p = `${path}/children/${i}`
        if (group(row, p, true))
          membership((row as Record<string, unknown>).children, `${p}/children`)
      })
    } else if (input.type === 'tabs' && allowTabs) {
      if (!input.children.length)
        fail(`${path}/children`, 'Tabs require at least one tab.')
      input.children.forEach((tab, i) => {
        const p = `${path}/children/${i}`
        if (group(tab, p, false))
          container(
            (tab as Record<string, unknown>).children,
            `${p}/children`,
            false
          )
      })
    } else fail(`${path}/type`, 'Expected grid, rows, or top-level tabs.')
  }
  container(value, '/layout', true)
  for (const id of panelIds) {
    if (typeof id === 'string' && !members.has(id))
      fail('/layout', `Panel "${id}" has no layout container.`)
  }
}

function issue(path: string, message: string): DashboardSchemaIssue {
  return { severity: 'error', code: 'invalid_layout', path, message }
}
