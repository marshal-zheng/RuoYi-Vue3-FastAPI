import {
  isDashboardPlainObject,
  joinDashboardJsonPointer,
  parseDashboardDataPointer,
} from '../schema'

import type { DashboardSchemaIssue } from './issues'

export function validateDashboardHostData(
  input: Record<string, unknown>,
  issues: DashboardSchemaIssue[]
): void {
  if (
    input.variables !== undefined &&
    !isDashboardPlainObject(input.variables)
  ) {
    invalid(issues, '/variables', 'variables must be a JSON object.')
  }
  if (input.refresh !== undefined) {
    const refresh = object(input.refresh, '/refresh', ['intervalMs'], issues)
    if (refresh && !duration(refresh.intervalMs, true)) {
      invalid(
        issues,
        '/refresh/intervalMs',
        'intervalMs must be a nonnegative safe integer.'
      )
    }
  }
  if (input.timeRange !== undefined) {
    const path = '/timeRange'
    const range = object(
      input.timeRange,
      path,
      ['mode', 'from', 'to', 'lastMs'],
      issues
    )
    if (!range) return
    if (range.mode === 'relative') {
      keys(range, path, ['mode', 'lastMs'], issues)
      if (!duration(range.lastMs))
        invalid(
          issues,
          `${path}/lastMs`,
          'lastMs must be a positive safe integer.'
        )
    } else if (range.mode === 'absolute') {
      keys(range, path, ['mode', 'from', 'to'], issues)
      for (const name of ['from', 'to']) {
        if (
          !Number.isSafeInteger(range[name]) ||
          Math.abs(range[name] as number) > 8640000000000000
        ) {
          invalid(
            issues,
            `${path}/${name}`,
            'Endpoint must be a valid integer UTC epoch millisecond.'
          )
        }
      }
      if (
        typeof range.from === 'number' &&
        typeof range.to === 'number' &&
        range.from > range.to
      ) {
        invalid(
          issues,
          `${path}/to`,
          'to must be greater than or equal to from.'
        )
      }
    } else invalid(issues, `${path}/mode`, 'mode must be absolute or relative.')
  }
}

export function validateDashboardPanelHostData(
  panel: Record<string, unknown>,
  base: string,
  issues: DashboardSchemaIssue[]
): void {
  array(panel.thresholds, `${base}/thresholds`, issues, (entry, path) => {
    const rule = object(
      entry,
      path,
      ['path', 'operator', 'value', 'state', 'label'],
      issues
    )
    if (!rule) return
    if (!parseDashboardDataPointer(rule.path))
      invalid(
        issues,
        `${path}/path`,
        'path must be a safe RFC 6901 pointer into panel.data.'
      )
    if (!['gt', 'gte', 'lt', 'lte'].includes(rule.operator as string))
      invalid(issues, `${path}/operator`, 'Unsupported threshold operator.')
    if (typeof rule.value !== 'number' || !Number.isFinite(rule.value))
      invalid(issues, `${path}/value`, 'value must be a finite number.')
    if (rule.state !== 'warn' && rule.state !== 'error')
      invalid(issues, `${path}/state`, 'state must be warn or error.')
    if (rule.label !== undefined && typeof rule.label !== 'string')
      invalid(issues, `${path}/label`, 'label must be a string.')
  })
  const ids = new Set<string>()
  array(panel.links, `${base}/links`, issues, (entry, path) => {
    const link = object(
      entry,
      path,
      ['id', 'title', 'target', 'params'],
      issues
    )
    if (!link) return
    for (const name of ['id', 'title', 'target']) {
      if (typeof link[name] !== 'string' || !(link[name] as string).trim())
        invalid(
          issues,
          `${path}/${name}`,
          `${name} must be a non-empty string.`
        )
    }
    if (typeof link.id === 'string') {
      if (ids.has(link.id))
        invalid(issues, `${path}/id`, 'Link ids must be unique within a panel.')
      ids.add(link.id)
    }
    if (link.params !== undefined && !isDashboardPlainObject(link.params))
      invalid(issues, `${path}/params`, 'params must be a JSON object.')
  })
}

function duration(value: unknown, zero = false): boolean {
  return Number.isSafeInteger(value) && (value as number) >= (zero ? 0 : 1)
}
function invalid(
  issues: DashboardSchemaIssue[],
  path: string,
  message: string
) {
  issues.push({ severity: 'error', code: 'invalid_host_data', path, message })
}
function keys(
  input: Record<string, unknown>,
  path: string,
  allowed: string[],
  issues: DashboardSchemaIssue[]
) {
  for (const key of Object.keys(input)) {
    if (!allowed.includes(key))
      invalid(
        issues,
        joinDashboardJsonPointer(path, key),
        `Unknown host contract field "${key}".`
      )
  }
}
function object(
  input: unknown,
  path: string,
  allowed: string[],
  issues: DashboardSchemaIssue[]
) {
  if (!isDashboardPlainObject(input)) {
    invalid(issues, path, 'Expected a plain JSON object.')
    return undefined
  }
  keys(input, path, allowed, issues)
  return input
}
function array(
  input: unknown,
  path: string,
  issues: DashboardSchemaIssue[],
  visit: (entry: unknown, path: string) => void
) {
  if (input === undefined) return
  if (!Array.isArray(input)) {
    invalid(issues, path, 'Expected an array.')
    return
  }
  input.forEach((entry, index) => visit(entry, `${path}/${index}`))
}
