import type { Component, DeepReadonly } from 'vue'
import type {
  DashboardDocument,
  DashboardGridPosition,
  DashboardJsonObject,
  DashboardJsonValue,
  DashboardPanel,
  DashboardReadonlyJsonObject,
  DashboardReadonlyJsonValue,
} from '../schema'
import type { DashboardWidgetMigrator } from '../migration'
import type {
  DashboardWidgetLifecycle,
  DashboardWidgetSettingsDescriptor,
} from './settings'
import type {
  DashboardHostDataView,
  DashboardPanelContentResolver,
  DashboardPanelRenderContext,
  DashboardRuntimeMode,
  DashboardWidgetEvent as DashboardRuntimeWidgetEvent,
} from '../runtime'

type DashboardHostReadonlyPanel = DeepReadonly<DashboardPanel>

export type DashboardWidgetComponent =
  | Component
  | DashboardWidgetComponentLoader

export type DashboardWidgetComponentModule =
  | Component
  | {
      default: Component
    }

export type DashboardWidgetComponentLoader =
  () => Promise<DashboardWidgetComponentModule>

export type DashboardWidgetDefaultPanel = Partial<
  Omit<DashboardPanel, 'id' | 'widget' | 'gridPos'>
>

/** Grid size bound in columns (`w`) and rows (`h`); an omitted axis is unconstrained. */
export type DashboardWidgetGridConstraint = Partial<
  Pick<DashboardGridPosition, 'w' | 'h'>
>

export type DashboardWidgetReadonlyJsonValue = DashboardReadonlyJsonValue
export type DashboardWidgetReadonlyJsonObject = DashboardReadonlyJsonObject

export interface DashboardWidgetReadonlyPanel
  extends Readonly<
    Omit<
      DashboardPanel,
      | 'gridPos'
      | 'params'
      | 'data'
      | 'metadata'
      | 'references'
      | 'thresholds'
      | 'links'
    >
  > {
  readonly thresholds?: DashboardHostReadonlyPanel['thresholds']
  readonly links?: DashboardHostReadonlyPanel['links']
  readonly gridPos: Readonly<DashboardGridPosition>
  readonly params?: DashboardWidgetReadonlyJsonObject
  readonly data?: DashboardWidgetReadonlyJsonValue
  readonly metadata?: DashboardWidgetReadonlyJsonObject
  readonly references?: readonly string[]
}

export type DashboardWidgetResolveProps = (
  panel: DashboardWidgetReadonlyPanel,
  context: DashboardWidgetRenderContext
) => Record<string, unknown>

export type DashboardWidgetValidate = (
  panel: DashboardPanel,
  context: DashboardWidgetValidationContext
) => DashboardWidgetIssue[]

export type DashboardWidgetMigrate = (
  panel: DashboardPanel,
  context: DashboardWidgetMigrationContext
) => DashboardPanel | DashboardWidgetDefaultPanel | void

export interface DashboardWidgetSourceMetadata {
  plugin?: string
  pluginVersion?: string
}

export interface DashboardWidgetVariantDefinition {
  name: string
  title?: string
  description?: string
  icon?: string | Component
  order?: number
  component?: DashboardWidgetComponent
  editor?: DashboardWidgetComponent
  preview?: DashboardWidgetComponent
  thumbnail?: string
  lifecycle?: DashboardWidgetLifecycle
  settings?: DashboardWidgetSettingsDescriptor
  defaultGrid?: Partial<DashboardGridPosition>
  /** Smallest size the designer creates and the grid resizes to; overrides the definition per axis. */
  minGrid?: DashboardWidgetGridConstraint
  /** Largest size the designer creates and the grid resizes to; overrides the definition per axis. */
  maxGrid?: DashboardWidgetGridConstraint
  /** Whether the designer offers lock / unlock for this variant. Falls back to the definition. */
  lockable?: boolean
  defaultPanel?: DashboardWidgetDefaultPanel
  resolveProps?: DashboardWidgetResolveProps
  validate?: DashboardWidgetValidate
  migrate?: DashboardWidgetMigrate
}

export interface DashboardWidgetDefinition {
  name: string
  title: string
  version?: string
  group?: string
  description?: string
  icon?: string | Component
  tags?: string[]
  order?: number
  hidden?: boolean
  palette?: boolean
  component: DashboardWidgetComponent
  editor?: DashboardWidgetComponent
  preview?: DashboardWidgetComponent
  thumbnail?: string
  lifecycle?: DashboardWidgetLifecycle
  settings?: DashboardWidgetSettingsDescriptor
  defaultGrid?: Partial<DashboardGridPosition>
  /** Smallest size the designer creates and the grid resizes to. */
  minGrid?: DashboardWidgetGridConstraint
  /** Largest size the designer creates and the grid resizes to. */
  maxGrid?: DashboardWidgetGridConstraint
  /** Whether the designer offers lock / unlock for panels of this widget. Defaults to `true`. */
  lockable?: boolean
  defaultPanel?: DashboardWidgetDefaultPanel
  variants?: DashboardWidgetVariantDefinition[]
  resolveProps?: DashboardWidgetResolveProps
  validate?: DashboardWidgetValidate
  migrate?: DashboardWidgetMigrate
  source?: DashboardWidgetSourceMetadata
}

export type DashboardWidgetIssueSeverity = 'error' | 'warn' | 'info'

export interface DashboardWidgetRegistryIssue {
  severity: DashboardWidgetIssueSeverity
  code:
    | 'invalid_widget_definition'
    | 'duplicate_widget'
    | 'duplicate_plugin'
    | 'unresolved_widget'
    | 'unresolved_widget_variant'
    | 'invalid_glob_widget_module'
    | 'async_component_load_failed'
    | 'missing_plugin_dependency'
    | 'widget_dispose_failed'
    | 'invalid_widget_migration'
    | 'grid_below_min'
    | 'grid_above_max'
    | string
  message: string
  widget?: string
  variant?: string
  plugin?: string
  panelId?: string
  path?: string
  suggestion?: string
}

export interface DashboardWidgetIssue extends DashboardWidgetRegistryIssue {
  panelId: string
  path: string
}

export interface DashboardWidgetRegistryResult<T> {
  ok: boolean
  value?: T
  issues: DashboardWidgetRegistryIssue[]
}

export interface DashboardWidgetRegisterOptions {
  override?: boolean
}

export interface DashboardWidgetRegistrationResult
  extends DashboardWidgetRegistryResult<DashboardWidgetDefinition> {
  unregister?: () => DashboardWidgetRegistryResult<void>
}

export interface DashboardWidgetPluginInstallOptions {
  override?: boolean
}

export type DashboardWidgetPluginInstallResult =
  DashboardWidgetRegistryResult<DashboardWidgetPlugin>

export interface DashboardWidgetListOptions {
  includeHidden?: boolean
}

export interface DashboardWidgetResolveResult
  extends DashboardWidgetRegistryResult<DashboardWidgetDefinition> {
  definition?: DashboardWidgetDefinition
  variant?: DashboardWidgetVariantDefinition
  component?: DashboardWidgetComponent
  resolveProps?: DashboardWidgetResolveProps
  validate?: DashboardWidgetValidate
  migrate?: DashboardWidgetMigrate
}

export interface DashboardWidgetRegistryReadonly {
  has(name: string): boolean
  get(name: string): DashboardWidgetDefinition | undefined
  list(options?: DashboardWidgetListOptions): DashboardWidgetDefinition[]
  names(): string[]
  resolve(panel: DashboardPanel): DashboardWidgetResolveResult
}

export interface DashboardWidgetRegistry
  extends DashboardWidgetRegistryReadonly {
  register(
    definition: DashboardWidgetDefinition,
    options?: DashboardWidgetRegisterOptions
  ): DashboardWidgetRegistrationResult
  use(
    plugin: DashboardWidgetPlugin,
    options?: DashboardWidgetPluginInstallOptions
  ): DashboardWidgetPluginInstallResult
  clear(): DashboardWidgetRegistryResult<void>
}

export interface DashboardWidgetPlugin {
  name: string
  version?: string
  widgets?: DashboardWidgetDefinition[]
  metadata?: DashboardJsonObject
  configure?: DashboardJsonObject
  install?: (context: DashboardWidgetPluginInstallContext) => void
}

export interface DashboardWidgetPluginInstallContext {
  register: DashboardWidgetRegistry['register']
  has: DashboardWidgetRegistry['has']
  get: DashboardWidgetRegistry['get']
  list: DashboardWidgetRegistry['list']
  addIssue: (issue: DashboardWidgetRegistryIssue) => void
}

export type DashboardWidgetEvent = DashboardRuntimeWidgetEvent

export interface DashboardWidgetResizeEvent {
  type: 'widget-resize'
  mode: DashboardRuntimeMode
  panelId: string
  widget: string
  variant?: string
  gridPos: DashboardPanel['gridPos']
  rect?: {
    width: number
    height: number
  }
  reason: 'mounted' | 'observer' | 'grid' | 'manual'
}

export type DashboardWidgetResizeHandler = (
  event: DashboardWidgetResizeEvent
) => void

export type DashboardWidgetDisposeHandler = () => void

export interface DashboardWidgetRenderContext extends DashboardHostDataView {
  requestRefresh: () => boolean
  requestPanelLink: (linkId: string) => boolean
  mode: DashboardRuntimeMode
  editable: boolean
  readonly: boolean
  panel: DashboardWidgetReadonlyPanel
  definition: Readonly<DashboardWidgetDefinition>
  variant?: Readonly<DashboardWidgetVariantDefinition>
  registry: DashboardWidgetRegistryReadonly
  updatePanel: (patch: Partial<Omit<DashboardPanel, 'id'>>) => void
  requestAction: (action: string, payload?: DashboardJsonValue) => void
  emitWidgetEvent: (event: string, payload?: DashboardJsonValue) => void
  onWidgetResize: (handler: DashboardWidgetResizeHandler) => () => void
  onWidgetDispose: (handler: DashboardWidgetDisposeHandler) => () => void
  requestWidgetResize: (reason?: 'grid' | 'manual') => void
}

export interface DashboardWidgetValidationContext {
  definition: Readonly<DashboardWidgetDefinition>
  variant?: Readonly<DashboardWidgetVariantDefinition>
  registry: DashboardWidgetRegistryReadonly
  document?: DashboardDocument
  panelIndex: number
  pluginVersion?: string
}

export interface DashboardWidgetValidationOptions {
  document?: DashboardDocument
}

export interface DashboardWidgetValidationResult {
  valid: boolean
  issues: DashboardWidgetIssue[]
}

export interface DashboardWidgetMigrationContext {
  definition: Readonly<DashboardWidgetDefinition>
  variant?: Readonly<DashboardWidgetVariantDefinition>
  registry: DashboardWidgetRegistryReadonly
  fromVersion?: string
  toVersion?: string
  documentSchemaVersion: number
}

export interface DashboardWidgetMigrationAdapterOptions {
  onIssue?: (issue: DashboardWidgetRegistryIssue) => void
}

export type DashboardWidgetMigratorMap = Record<string, DashboardWidgetMigrator>

export interface DashboardWidgetResolverOptions {
  onWidgetEvent?: (event: DashboardWidgetEvent) => void
  onIssue?: (issue: DashboardWidgetRegistryIssue) => void
  loadingComponent?: Component
  errorComponent?: Component
  asyncDelay?: number
  asyncTimeout?: number
}

export type DashboardWidgetPanelContentResolverFactory = (
  registry: DashboardWidgetRegistry,
  options?: DashboardWidgetResolverOptions
) => DashboardPanelContentResolver

export type DashboardWidgetHostRenderContext = DashboardPanelRenderContext
