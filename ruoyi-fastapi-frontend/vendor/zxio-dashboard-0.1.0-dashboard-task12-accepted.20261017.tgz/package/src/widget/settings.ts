import {
  cloneDashboardJson,
  collectDashboardJsonIssues,
  hasDashboardDangerousKey,
  isDashboardPlainObject,
  joinDashboardJsonPointer,
} from '../schema'

import type { DashboardJsonObject, DashboardJsonValue } from '../schema'
import type { DashboardWidgetRegistryIssue } from './types'

export type DashboardWidgetLifecycle =
  | 'stable'
  | 'experimental'
  | 'deprecated'
  | 'hidden'

export type DashboardWidgetSettingsFieldType =
  | 'string'
  | 'number'
  | 'boolean'
  | 'enum'
  | 'color'
  | 'text'
  | 'json'
  | 'object'
  | 'array'
  | 'ref'

export type DashboardWidgetSettingsPredicate =
  | { op: 'exists'; path: string }
  | { op: 'equals'; path: string; value: DashboardJsonValue }
  | { op: 'not'; predicate: DashboardWidgetSettingsPredicate }
  | { op: 'all'; predicates: DashboardWidgetSettingsPredicate[] }
  | { op: 'any'; predicates: DashboardWidgetSettingsPredicate[] }

export interface DashboardWidgetSettingsField {
  /** Literal top-level key in panel.params; dots do not create nested objects. */
  id: string
  type: DashboardWidgetSettingsFieldType
  label?: string
  labelKey?: string
  description?: string
  defaultValue?: DashboardJsonValue
  required?: boolean
  group?: string
  order?: number
  options?: {
    value: string | number | boolean
    label?: string
    labelKey?: string
  }[]
  validation?: {
    min?: number
    max?: number
    pattern?: string
    maxLength?: number
  }
  visibleWhen?: DashboardWidgetSettingsPredicate
  enabledWhen?: DashboardWidgetSettingsPredicate
  status?: DashboardWidgetLifecycle
  replacement?: string
  extensions?: DashboardJsonObject
}

export interface DashboardWidgetSettingsDescriptor {
  version?: string
  fields: DashboardWidgetSettingsField[]
  groups?: {
    id: string
    label?: string
    order?: number
    extensions?: DashboardJsonObject
  }[]
  extensions?: DashboardJsonObject
}

export interface DashboardWidgetSettingsIssue
  extends DashboardWidgetRegistryIssue {
  fieldId?: string
}

const fieldTypes = new Set([
  'string',
  'number',
  'boolean',
  'enum',
  'color',
  'text',
  'json',
  'object',
  'array',
  'ref',
])
const lifecycles = new Set(['stable', 'experimental', 'deprecated', 'hidden'])

export function isDashboardWidgetLifecycle(
  value: unknown
): value is DashboardWidgetLifecycle {
  return typeof value === 'string' && lifecycles.has(value)
}

/** Descriptor validation runs at registration and is also safe for direct callers. */
export function validateDashboardWidgetSettingsDescriptor(
  input: unknown,
  path = '/settings'
): DashboardWidgetSettingsIssue[] {
  if (input === undefined) return []
  const fail = (message: string, at = path): DashboardWidgetSettingsIssue => ({
    severity: 'error',
    code: 'invalid_settings_descriptor',
    message,
    path: at,
  })
  const jsonIssues = collectDashboardJsonIssues(input, path, {
    phase: 'import',
  })
  if (jsonIssues.length)
    return jsonIssues.map((issue) => fail(issue.message, issue.path))
  if (!isDashboardPlainObject(input) || !Array.isArray(input.fields))
    return [fail('Settings descriptor must contain a fields array.')]
  const issues: DashboardWidgetSettingsIssue[] = []
  function checkKeys(
    value: Record<string, unknown>,
    keys: string[],
    at: string
  ) {
    for (const key of Object.keys(value))
      if (!keys.includes(key))
        issues.push(
          fail(
            `Unknown descriptor field "${key}".`,
            joinDashboardJsonPointer(at, key)
          )
        )
    if (
      value.extensions !== undefined &&
      !isDashboardPlainObject(value.extensions)
    )
      issues.push(fail('Extensions must be a JSON object.', `${at}/extensions`))
  }
  checkKeys(input, ['version', 'fields', 'groups', 'extensions'], path)
  const ids = new Set<string>()
  const groups = new Set<string>()
  if (input.version !== undefined && typeof input.version !== 'string')
    issues.push(fail('Descriptor version must be a string.'))
  if (input.groups !== undefined && !Array.isArray(input.groups))
    issues.push(fail('Descriptor groups must be an array.'))
  for (const [index, group] of (Array.isArray(input.groups)
    ? input.groups
    : []
  ).entries()) {
    const at = `${path}/groups/${index}`
    if (
      !isDashboardPlainObject(group) ||
      typeof group.id !== 'string' ||
      !group.id.trim() ||
      groups.has(group.id)
    ) {
      issues.push(fail('Settings group ids must be nonempty and unique.', at))
      continue
    }
    groups.add(group.id)
    checkKeys(group, ['id', 'label', 'order', 'extensions'], at)
    if (
      (group.label !== undefined && typeof group.label !== 'string') ||
      (group.order !== undefined && typeof group.order !== 'number')
    )
      issues.push(fail('Invalid settings group metadata.', at))
  }
  for (const [index, field] of input.fields.entries()) {
    const at = `${path}/fields/${index}`
    const previousIssueCount = issues.length
    if (
      !isDashboardPlainObject(field) ||
      typeof field.id !== 'string' ||
      !field.id.trim() ||
      hasDashboardDangerousKey(field.id) ||
      ids.has(field.id)
    ) {
      issues.push(
        fail('Settings field ids must be safe, nonempty and unique.', at)
      )
      continue
    }
    ids.add(field.id)
    checkKeys(
      field,
      [
        'id',
        'type',
        'label',
        'labelKey',
        'description',
        'defaultValue',
        'required',
        'group',
        'order',
        'options',
        'validation',
        'visibleWhen',
        'enabledWhen',
        'status',
        'replacement',
        'extensions',
      ],
      at
    )
    if (typeof field.type !== 'string' || !fieldTypes.has(field.type))
      issues.push(fail('Unsupported settings field type.', `${at}/type`))
    for (const key of [
      'label',
      'labelKey',
      'description',
      'group',
      'replacement',
    ])
      if (field[key] !== undefined && typeof field[key] !== 'string')
        issues.push(fail(`Field ${key} must be a string.`, `${at}/${key}`))
    if (
      (field.required !== undefined && typeof field.required !== 'boolean') ||
      (field.order !== undefined && typeof field.order !== 'number') ||
      (field.status !== undefined && !isDashboardWidgetLifecycle(field.status))
    )
      issues.push(fail('Invalid field metadata.', at))
    if (
      field.options !== undefined &&
      (!Array.isArray(field.options) ||
        field.options.some(
          (option) =>
            !isDashboardPlainObject(option) ||
            !['string', 'number', 'boolean'].includes(typeof option.value) ||
            (option.label !== undefined && typeof option.label !== 'string') ||
            (option.labelKey !== undefined &&
              typeof option.labelKey !== 'string')
        ))
    )
      issues.push(
        fail(
          'Options must contain typed primitive values and labels.',
          `${at}/options`
        )
      )
    if (
      field.type === 'enum' &&
      (!Array.isArray(field.options) || !field.options.length)
    )
      issues.push(fail('Enum fields require options.', `${at}/options`))
    if (Array.isArray(field.options)) {
      const values = new Set<string>()
      field.options.forEach((option, index) => {
        if (!isDashboardPlainObject(option)) return
        checkKeys(
          option,
          ['value', 'label', 'labelKey'],
          `${at}/options/${index}`
        )
        const key = JSON.stringify(option.value)
        if (values.has(key))
          issues.push(
            fail('Enum option values must be unique.', `${at}/options/${index}`)
          )
        values.add(key)
      })
    }
    if (field.validation !== undefined) {
      const rules = field.validation
      if (!isDashboardPlainObject(rules))
        issues.push(
          fail('Validation rules must be an object.', `${at}/validation`)
        )
      else {
        checkKeys(
          rules,
          ['min', 'max', 'pattern', 'maxLength'],
          `${at}/validation`
        )
        if (
          ['min', 'max', 'maxLength'].some(
            (key) => rules[key] !== undefined && typeof rules[key] !== 'number'
          ) ||
          (typeof rules.maxLength === 'number' &&
            (!Number.isInteger(rules.maxLength) || rules.maxLength < 0)) ||
          (typeof rules.min === 'number' &&
            typeof rules.max === 'number' &&
            rules.min > rules.max)
        )
          issues.push(fail('Invalid field bounds.', `${at}/validation`))
        if (rules.pattern !== undefined) {
          try {
            if (typeof rules.pattern !== 'string')
              throw new Error('A field pattern must be a string.')
            new RegExp(rules.pattern)
          } catch {
            issues.push(
              fail('Invalid field pattern.', `${at}/validation/pattern`)
            )
          }
        }
      }
    }
    for (const key of ['visibleWhen', 'enabledWhen'])
      if (field[key] !== undefined && !validPredicate(field[key]))
        issues.push(fail('Invalid settings predicate.', `${at}/${key}`))
    if (
      field.defaultValue !== undefined &&
      issues.length === previousIssueCount
    ) {
      const issue = fieldValueIssue(
        field as unknown as DashboardWidgetSettingsField,
        field.defaultValue,
        false
      )
      if (issue) issues.push(fail(issue.message, `${at}/defaultValue`))
    }
  }
  return issues
}

function validPredicate(value: unknown, depth = 0): boolean {
  if (!isDashboardPlainObject(value) || depth > 32) return false
  if (value.op === 'exists' || value.op === 'equals')
    return (
      typeof value.path === 'string' &&
      value.path
        .split('.')
        .every((part) => !!part && !hasDashboardDangerousKey(part)) &&
      (value.op === 'exists' ||
        Object.prototype.hasOwnProperty.call(value, 'value'))
    )
  if (value.op === 'not') return validPredicate(value.predicate, depth + 1)
  return (
    (value.op === 'all' || value.op === 'any') &&
    Array.isArray(value.predicates) &&
    value.predicates.every((item) => validPredicate(item, depth + 1))
  )
}

export function evaluateDashboardWidgetSettingsPredicate(
  predicate: DashboardWidgetSettingsPredicate,
  settings: DashboardJsonObject
): boolean {
  if (predicate.op === 'not')
    return !evaluateDashboardWidgetSettingsPredicate(
      predicate.predicate,
      settings
    )
  if (predicate.op === 'all')
    return predicate.predicates.every((item) =>
      evaluateDashboardWidgetSettingsPredicate(item, settings)
    )
  if (predicate.op === 'any')
    return predicate.predicates.some((item) =>
      evaluateDashboardWidgetSettingsPredicate(item, settings)
    )
  let value: unknown = settings
  for (const part of predicate.path.split('.')) {
    if (
      !isDashboardPlainObject(value) ||
      hasDashboardDangerousKey(part) ||
      !Object.prototype.hasOwnProperty.call(value, part)
    )
      return false
    value = value[part]
  }
  return predicate.op === 'exists'
    ? value !== undefined
    : equalJson(value, predicate.value)
}

function equalJson(a: unknown, b: unknown): boolean {
  if (a === b) return true
  if (Array.isArray(a) && Array.isArray(b))
    return (
      a.length === b.length &&
      a.every((value, index) => equalJson(value, b[index]))
    )
  if (isDashboardPlainObject(a) && isDashboardPlainObject(b)) {
    const keys = Object.keys(a)
    return (
      keys.length === Object.keys(b).length &&
      keys.every(
        (key) =>
          Object.prototype.hasOwnProperty.call(b, key) &&
          equalJson(a[key], b[key])
      )
    )
  }
  return false
}

export function createDashboardWidgetSettingsDefaults(
  descriptor?: DashboardWidgetSettingsDescriptor,
  overrides: DashboardJsonObject = {}
): DashboardJsonObject {
  const issues = validateDashboardWidgetSettingsDescriptor(descriptor)
  issues.push(
    ...collectDashboardJsonIssues(overrides, '/params', { phase: 'import' })
  )
  if (issues.length || !isDashboardPlainObject(overrides))
    throw new Error(issues[0]?.message ?? 'Settings must be a JSON object.')
  const defaults: DashboardJsonObject = {}
  for (const field of descriptor?.fields ?? [])
    if (field.defaultValue !== undefined)
      defaults[field.id] = cloneDashboardJson(field.defaultValue)
  return { ...defaults, ...cloneDashboardJson(overrides) }
}

export function validateDashboardWidgetSettings(
  descriptor: DashboardWidgetSettingsDescriptor | undefined,
  settings: unknown
): { valid: boolean; issues: DashboardWidgetSettingsIssue[] } {
  const issues = validateDashboardWidgetSettingsDescriptor(descriptor)
  const value = settings === undefined ? {} : settings
  issues.push(
    ...collectDashboardJsonIssues(value, '/params', { phase: 'import' })
  )
  if (!isDashboardPlainObject(value))
    issues.push({
      severity: 'error',
      code: 'setting_type',
      path: '/params',
      message: 'Widget settings must be a JSON object.',
    })
  if (issues.length) return { valid: false, issues }
  const params = value as DashboardJsonObject
  for (const field of descriptor?.fields ?? []) {
    const active =
      field.status !== 'hidden' &&
      (!field.visibleWhen ||
        evaluateDashboardWidgetSettingsPredicate(field.visibleWhen, params)) &&
      (!field.enabledWhen ||
        evaluateDashboardWidgetSettingsPredicate(field.enabledWhen, params))
    const value = Object.prototype.hasOwnProperty.call(params, field.id)
      ? params[field.id]
      : undefined
    const issue = fieldValueIssue(field, value, active)
    if (issue) issues.push(issue)
  }
  return { valid: !issues.length, issues }
}

function fieldValueIssue(
  field: DashboardWidgetSettingsField,
  value: unknown,
  active: boolean
): DashboardWidgetSettingsIssue | undefined {
  const issue = (
    code: string,
    message: string
  ): DashboardWidgetSettingsIssue => ({
    severity: 'error',
    code,
    message,
    fieldId: field.id,
    path: joinDashboardJsonPointer('/params', field.id),
  })
  if (
    value === undefined ||
    (value === '' && ['string', 'text', 'ref', 'color'].includes(field.type))
  )
    return active && field.required
      ? issue('setting_required', 'A required setting is missing.')
      : undefined
  const type = field.type
  if (
    (['string', 'text', 'ref', 'color'].includes(type) &&
      typeof value !== 'string') ||
    (type === 'number' &&
      (typeof value !== 'number' || !Number.isFinite(value))) ||
    (type === 'boolean' && typeof value !== 'boolean') ||
    (type === 'object' && !isDashboardPlainObject(value)) ||
    (type === 'array' && !Array.isArray(value))
  )
    return issue('setting_type', `Setting must have type ${type}.`)
  if (
    type === 'enum' &&
    !field.options?.some((option) => option.value === value)
  )
    return issue('setting_enum', 'Choose a declared option.')
  if (
    typeof value === 'number' &&
    ((field.validation?.min !== undefined && value < field.validation.min) ||
      (field.validation?.max !== undefined && value > field.validation.max))
  )
    return issue('setting_bounds', 'Setting is outside the declared bounds.')
  if (typeof value === 'string') {
    if (
      field.validation?.maxLength !== undefined &&
      value.length > field.validation.maxLength
    )
      return issue('setting_length', 'Setting exceeds the maximum length.')
    if (
      field.validation?.pattern &&
      !new RegExp(field.validation.pattern).test(value)
    )
      return issue(
        'setting_pattern',
        'Setting does not match the required pattern.'
      )
  }
  return undefined
}
