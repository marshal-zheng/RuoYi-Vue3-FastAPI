import {
  cloneDashboardWidgetDefinition,
  cloneDashboardWidgetVariantDefinition,
  createDuplicatePluginIssue,
  createDuplicateWidgetIssue,
  createInvalidWidgetDefinitionIssue,
  createUnresolvedWidgetIssue,
  createUnresolvedWidgetVariantIssue,
  normalizeDashboardWidgetDefinition,
  validateDashboardWidgetKey,
} from './issues'

import type { DashboardPanel } from '../schema'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetListOptions,
  DashboardWidgetPlugin,
  DashboardWidgetPluginInstallContext,
  DashboardWidgetPluginInstallOptions,
  DashboardWidgetPluginInstallResult,
  DashboardWidgetRegisterOptions,
  DashboardWidgetRegistrationResult,
  DashboardWidgetRegistry,
  DashboardWidgetRegistryIssue,
  DashboardWidgetRegistryReadonly,
  DashboardWidgetRegistryResult,
  DashboardWidgetResolveResult,
  DashboardWidgetSourceMetadata,
} from './types'

interface DashboardWidgetRegistryEntry {
  definition: DashboardWidgetDefinition
  token: symbol
}

interface DashboardWidgetPluginEntry {
  name: string
  version?: string
}

export function createDashboardRegistry(): DashboardWidgetRegistry {
  const definitions = new Map<string, DashboardWidgetRegistryEntry>()
  const plugins = new Map<string, DashboardWidgetPluginEntry>()

  function register(
    definition: DashboardWidgetDefinition,
    options: DashboardWidgetRegisterOptions = {}
  ): DashboardWidgetRegistrationResult {
    return registerInternal(definition, options)
  }

  function registerInternal(
    definition: DashboardWidgetDefinition,
    options: DashboardWidgetRegisterOptions = {},
    source?: DashboardWidgetSourceMetadata
  ): DashboardWidgetRegistrationResult {
    const normalized = normalizeDashboardWidgetDefinition(definition, source)
    if (!normalized.definition) {
      return {
        ok: false,
        issues: normalized.issues,
      }
    }

    const name = normalized.definition.name
    if (definitions.has(name) && !options.override) {
      return {
        ok: false,
        value: get(name),
        issues: [...normalized.issues, createDuplicateWidgetIssue(name)],
      }
    }

    const token = Symbol(name)
    definitions.set(name, {
      definition: normalized.definition,
      token,
    })

    return {
      ok: true,
      value: cloneDashboardWidgetDefinition(normalized.definition),
      issues: normalized.issues,
      unregister: () => {
        const entry = definitions.get(name)
        if (entry?.token !== token) {
          return { ok: true, issues: [] }
        }
        definitions.delete(name)
        return { ok: true, issues: [] }
      },
    }
  }

  function use(
    plugin: DashboardWidgetPlugin,
    options: DashboardWidgetPluginInstallOptions = {}
  ): DashboardWidgetPluginInstallResult {
    const issues: DashboardWidgetRegistryIssue[] = []

    if (!isDashboardWidgetPlugin(plugin)) {
      return {
        ok: false,
        issues: [
          createInvalidWidgetDefinitionIssue(
            'Widget plugin must be a plain object with a stable name.',
            { path: '/plugin' }
          ),
        ],
      }
    }

    issues.push(
      ...validateDashboardWidgetKey(plugin.name, '/name', 'Widget plugin name')
    )
    if (issues.some((issue) => issue.severity === 'error')) {
      return { ok: false, value: plugin, issues }
    }

    if (plugins.has(plugin.name)) {
      return {
        ok: false,
        value: plugin,
        issues: [createDuplicatePluginIssue(plugin.name)],
      }
    }

    const source: DashboardWidgetSourceMetadata = {
      plugin: plugin.name,
      pluginVersion: plugin.version,
    }
    const installContext: DashboardWidgetPluginInstallContext = {
      register: (definition, registerOptions) => {
        const result = registerInternal(
          definition,
          {
            override: registerOptions?.override ?? options.override,
          },
          source
        )
        issues.push(...result.issues)
        return result
      },
      has,
      get,
      list,
      addIssue: (issue) => {
        issues.push({
          plugin: plugin.name,
          ...issue,
        })
      },
    }

    for (const definition of plugin.widgets ?? []) {
      installContext.register(definition)
    }

    try {
      plugin.install?.(installContext)
    } catch (error) {
      issues.push({
        severity: 'error',
        code: 'invalid_widget_definition',
        plugin: plugin.name,
        message:
          error instanceof Error
            ? error.message
            : `Widget plugin "${plugin.name}" failed during install.`,
      })
    }

    const ok = !issues.some((issue) => issue.severity === 'error')
    if (ok) {
      plugins.set(plugin.name, {
        name: plugin.name,
        version: plugin.version,
      })
    }

    return {
      ok,
      value: plugin,
      issues,
    }
  }

  function has(name: string): boolean {
    return definitions.has(name)
  }

  function get(name: string): DashboardWidgetDefinition | undefined {
    const entry = definitions.get(name)
    return entry ? cloneDashboardWidgetDefinition(entry.definition) : undefined
  }

  function list(
    options: DashboardWidgetListOptions = {}
  ): DashboardWidgetDefinition[] {
    return Array.from(definitions.values())
      .filter(
        (entry) =>
          options.includeHidden === true ||
          (!entry.definition.hidden && entry.definition.lifecycle !== 'hidden')
      )
      .map((entry) => cloneDashboardWidgetDefinition(entry.definition))
      .sort(compareWidgetDefinitions)
  }

  function names(): string[] {
    return list({ includeHidden: true }).map((definition) => definition.name)
  }

  function resolve(panel: DashboardPanel): DashboardWidgetResolveResult {
    const entry = definitions.get(panel.widget)
    if (!entry) {
      return {
        ok: false,
        issues: [
          createUnresolvedWidgetIssue(panel.widget, {
            panelId: panel.id,
            path: `/panels/${panel.id}/widget`,
          }),
        ],
      }
    }

    const definition = cloneDashboardWidgetDefinition(entry.definition)
    let variant = panel.variant
      ? definition.variants?.find((item) => item.name === panel.variant)
      : undefined

    if (panel.variant && definition.variants && !variant) {
      return {
        ok: false,
        value: definition,
        definition,
        issues: [
          createUnresolvedWidgetVariantIssue(panel.widget, panel.variant, {
            panelId: panel.id,
            path: `/panels/${panel.id}/variant`,
          }),
        ],
      }
    }

    variant = variant
      ? cloneDashboardWidgetVariantDefinition(variant)
      : undefined

    return {
      ok: true,
      value: definition,
      definition,
      variant,
      component: variant?.component ?? definition.component,
      resolveProps: variant?.resolveProps ?? definition.resolveProps,
      validate: variant?.validate ?? definition.validate,
      migrate: variant?.migrate ?? definition.migrate,
      issues: [],
    }
  }

  function clear(): DashboardWidgetRegistryResult<void> {
    definitions.clear()
    plugins.clear()
    return { ok: true, issues: [] }
  }

  return {
    register,
    use,
    has,
    get,
    list,
    names,
    resolve,
    clear,
  }
}

export function createReadonlyDashboardWidgetRegistry(
  registry: DashboardWidgetRegistryReadonly
): DashboardWidgetRegistryReadonly {
  return {
    has: registry.has,
    get: registry.get,
    list: registry.list,
    names: registry.names,
    resolve: registry.resolve,
  }
}

function compareWidgetDefinitions(
  a: DashboardWidgetDefinition,
  b: DashboardWidgetDefinition
): number {
  return (
    compareString(a.group, b.group) ||
    compareNumber(a.order, b.order) ||
    compareString(a.title, b.title) ||
    compareString(a.name, b.name)
  )
}

function compareString(a: string | undefined, b: string | undefined): number {
  return (a ?? '').localeCompare(b ?? '')
}

function compareNumber(a: number | undefined, b: number | undefined): number {
  return (a ?? Number.MAX_SAFE_INTEGER) - (b ?? Number.MAX_SAFE_INTEGER)
}

function isDashboardWidgetPlugin(
  value: unknown
): value is DashboardWidgetPlugin {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as DashboardWidgetPlugin).name === 'string'
  )
}
