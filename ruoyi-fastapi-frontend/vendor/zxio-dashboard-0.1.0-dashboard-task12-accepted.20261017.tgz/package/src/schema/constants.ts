export const DASHBOARD_SCHEMA_VERSION = 2 as const

export const DASHBOARD_BREAKPOINTS = {
  lg: 1200,
  md: 996,
  sm: 768,
  xs: 480,
  xxs: 0,
} as const

export const DASHBOARD_SCHEMA_TOP_LEVEL_FIELDS = [
  'schemaVersion',
  'uid',
  'title',
  'description',
  'panels',
  'layout',
  'pluginVersions',
  'references',
  'variables',
  'refresh',
  'timeRange',
  'meta',
] as const

export const DASHBOARD_GRID_POSITION_FIELDS = ['x', 'y', 'w', 'h'] as const

export const DASHBOARD_DANGEROUS_KEYS = [
  '__proto__',
  'prototype',
  'constructor',
] as const
