# @zxio/theme-pap-olive

Amber is a deep olive Theme v4 package with a faint gold glow. The package
id remains `pap-olive`.

Run `pnpm -C packages/theme-pap-olive build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
