# Release notes

## 1.0.0

- Add the Amber Theme v4 package with 162 deterministic variants. The
  package id remains `pap-olive`.
- Anchor chrome to a deep olive. Gold is the glow material at 0.45 intensity
  so it reads as a warm edge rather than a neon frame.
