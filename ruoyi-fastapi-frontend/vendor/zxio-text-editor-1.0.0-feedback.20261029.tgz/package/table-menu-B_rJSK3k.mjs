import { defineComponent as F, ref as h, watch as G, computed as N, createBlock as $, openBlock as v, unref as e, withCtx as f, renderSlot as I, normalizeProps as L, guardReactiveProps as U, createElementVNode as a, normalizeClass as o, createElementBlock as H, Fragment as B, createVNode as d, renderList as P, toDisplayString as W, createCommentVNode as S } from "vue";
import { useNamespace as X } from "@zxio/zxui/hooks";
import { ZxIcon as r } from "@zxio/zxui/core";
import { ZxTooltipOrPopover as C } from "@zxio/zxui/tooltip-or-popover";
import { H as j, X as _ } from "./runtime-extensions-ClrqjOfa.mjs";
const J = ["onMouseenter", "onClick"], K = ["disabled"], Q = ["disabled"], Y = ["disabled"], ee = ["disabled"], te = ["disabled"], oe = ["disabled"], ae = ["disabled"], le = ["disabled"], se = ["disabled"], ne = ["disabled"], de = ["disabled"], pe = /* @__PURE__ */ F({
  name: "ZxTextEditorTableMenu",
  __name: "table-menu",
  props: {
    editor: {}
  },
  setup(A) {
    const s = A, t = X("text-editor-table-menu"), { binding: b } = j(), k = h(!1), T = h(_(null, 2));
    G(
      k,
      (u) => {
        var l;
        u && (T.value = _((l = b.value) == null ? void 0 : l.target, 2));
      },
      { flush: "sync" }
    );
    const m = h(0), w = h(0), V = (u, l) => {
      m.value = u, w.value = l;
    }, Z = () => {
      m.value = 0, w.value = 0;
    }, O = (u, l) => {
      var g;
      (g = s.editor) == null || g.chain().focus().insertTable({ rows: u, cols: l, withHeaderRow: !0 }).run(), k.value = !1;
    }, c = (u) => {
      if (s.editor)
        switch (u) {
          case "addRowBefore":
            s.editor.chain().focus().addRowBefore().run();
            break;
          case "addRowAfter":
            s.editor.chain().focus().addRowAfter().run();
            break;
          case "deleteRow":
            s.editor.chain().focus().deleteRow().run();
            break;
          case "addColumnBefore":
            s.editor.chain().focus().addColumnBefore().run();
            break;
          case "addColumnAfter":
            s.editor.chain().focus().addColumnAfter().run();
            break;
          case "deleteColumn":
            s.editor.chain().focus().deleteColumn().run();
            break;
          case "mergeCells":
            s.editor.chain().focus().mergeCells().run();
            break;
          case "splitCell":
            s.editor.chain().focus().splitCell().run();
            break;
          case "toggleHeaderRow":
            s.editor.chain().focus().toggleHeaderRow().run();
            break;
          case "toggleHeaderColumn":
            s.editor.chain().focus().toggleHeaderColumn().run();
            break;
          case "toggleHeaderCell":
            s.editor.chain().focus().toggleHeaderCell().run();
            break;
          case "deleteTable":
            s.editor.chain().focus().deleteTable().run();
            break;
        }
    }, n = (u) => {
      if (!s.editor) return !1;
      switch (u) {
        case "addRowBefore":
          return s.editor.can().addRowBefore();
        case "addRowAfter":
          return s.editor.can().addRowAfter();
        case "deleteRow":
          return s.editor.can().deleteRow();
        case "addColumnBefore":
          return s.editor.can().addColumnBefore();
        case "addColumnAfter":
          return s.editor.can().addColumnAfter();
        case "deleteColumn":
          return s.editor.can().deleteColumn();
        case "mergeCells":
          return s.editor.can().mergeCells();
        case "splitCell":
          return s.editor.can().splitCell();
        case "toggleHeaderRow":
          return s.editor.can().toggleHeaderRow();
        case "toggleHeaderColumn":
          return s.editor.can().toggleHeaderColumn();
        case "toggleHeaderCell":
          return s.editor.can().toggleHeaderCell();
        case "deleteTable":
          return s.editor.can().deleteTable();
        default:
          return !0;
      }
    }, y = N(() => !1), q = N(() => !1);
    return (u, l) => {
      var g;
      return v(), $(e(C), {
        visible: k.value,
        "onUpdate:visible": l[11] || (l[11] = (p) => k.value = p),
        variant: "popover",
        trigger: "click",
        "show-arrow": !1,
        placement: "bottom-start",
        "popper-class": e(t).b(),
        offset: T.value,
        "append-to": (g = e(b)) == null ? void 0 : g.target,
        disabled: !e(b)
      }, {
        content: f(() => {
          var p, x, z, E, M;
          return [
            a("div", {
              class: o(e(t).e("content"))
            }, [
              (p = A.editor) != null && p.isActive("table") ? (v(), H(B, { key: 1 }, [
                a("div", {
                  class: o(e(t).e("quick-bar"))
                }, [
                  a("div", {
                    class: o(e(t).e("quick-group"))
                  }, [
                    d(e(C), {
                      content: "上方插入行",
                      placement: "top",
                      "show-after": 300,
                      "append-to": (x = e(b)) == null ? void 0 : x.target
                    }, {
                      default: f(() => [
                        a("button", {
                          class: o([
                            e(t).e("quick-btn"),
                            { "is-disabled": !n("addRowBefore") }
                          ]),
                          disabled: !n("addRowBefore"),
                          onClick: l[0] || (l[0] = (i) => c("addRowBefore"))
                        }, [
                          d(e(r), { icon: "lucide:arrow-up" })
                        ], 10, K)
                      ]),
                      _: 1
                    }, 8, ["append-to"]),
                    d(e(C), {
                      content: "下方插入行",
                      placement: "top",
                      "show-after": 300,
                      "append-to": (z = e(b)) == null ? void 0 : z.target
                    }, {
                      default: f(() => [
                        a("button", {
                          class: o([
                            e(t).e("quick-btn"),
                            { "is-disabled": !n("addRowAfter") }
                          ]),
                          disabled: !n("addRowAfter"),
                          onClick: l[1] || (l[1] = (i) => c("addRowAfter"))
                        }, [
                          d(e(r), { icon: "lucide:arrow-down" })
                        ], 10, Q)
                      ]),
                      _: 1
                    }, 8, ["append-to"])
                  ], 2),
                  a("div", {
                    class: o(e(t).e("quick-divider"))
                  }, null, 2),
                  a("div", {
                    class: o(e(t).e("quick-group"))
                  }, [
                    d(e(C), {
                      content: "左侧插入列",
                      placement: "top",
                      "show-after": 300,
                      "append-to": (E = e(b)) == null ? void 0 : E.target
                    }, {
                      default: f(() => [
                        a("button", {
                          class: o([
                            e(t).e("quick-btn"),
                            { "is-disabled": !n("addColumnBefore") }
                          ]),
                          disabled: !n("addColumnBefore"),
                          onClick: l[2] || (l[2] = (i) => c("addColumnBefore"))
                        }, [
                          d(e(r), { icon: "lucide:arrow-left" })
                        ], 10, Y)
                      ]),
                      _: 1
                    }, 8, ["append-to"]),
                    d(e(C), {
                      content: "右侧插入列",
                      placement: "top",
                      "show-after": 300,
                      "append-to": (M = e(b)) == null ? void 0 : M.target
                    }, {
                      default: f(() => [
                        a("button", {
                          class: o([
                            e(t).e("quick-btn"),
                            { "is-disabled": !n("addColumnAfter") }
                          ]),
                          disabled: !n("addColumnAfter"),
                          onClick: l[3] || (l[3] = (i) => c("addColumnAfter"))
                        }, [
                          d(e(r), { icon: "lucide:arrow-right" })
                        ], 10, ee)
                      ]),
                      _: 1
                    }, 8, ["append-to"])
                  ], 2)
                ], 2),
                a("div", {
                  class: o(e(t).e("divider"))
                }, null, 2),
                a("div", {
                  class: o(e(t).e("actions"))
                }, [
                  a("button", {
                    class: o([e(t).e("action"), { "is-disabled": !n("mergeCells") }]),
                    disabled: !n("mergeCells"),
                    onClick: l[4] || (l[4] = (i) => c("mergeCells"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:combine" })
                    ], 2),
                    a("div", {
                      class: o(e(t).e("action-content"))
                    }, [
                      a("span", {
                        class: o(e(t).e("action-title"))
                      }, "合并单元格", 2),
                      a("span", {
                        class: o(e(t).e("action-desc"))
                      }, "将选中的单元格合并为一个", 2)
                    ], 2)
                  ], 10, te),
                  a("button", {
                    class: o([e(t).e("action"), { "is-disabled": !n("splitCell") }]),
                    disabled: !n("splitCell"),
                    onClick: l[5] || (l[5] = (i) => c("splitCell"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:split" })
                    ], 2),
                    a("div", {
                      class: o(e(t).e("action-content"))
                    }, [
                      a("span", {
                        class: o(e(t).e("action-title"))
                      }, "拆分单元格", 2),
                      a("span", {
                        class: o(e(t).e("action-desc"))
                      }, "将合并的单元格拆分还原", 2)
                    ], 2)
                  ], 10, oe),
                  a("button", {
                    class: o([
                      e(t).e("action"),
                      {
                        "is-active": y.value,
                        "is-disabled": !n("toggleHeaderRow")
                      }
                    ]),
                    disabled: !n("toggleHeaderRow"),
                    onClick: l[6] || (l[6] = (i) => c("toggleHeaderRow"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:rows-3" })
                    ], 2),
                    a("div", {
                      class: o(e(t).e("action-content"))
                    }, [
                      a("span", {
                        class: o(e(t).e("action-title"))
                      }, "切换表头行", 2),
                      a("span", {
                        class: o(e(t).e("action-desc"))
                      }, "将首行设置为表头样式", 2)
                    ], 2),
                    y.value ? (v(), $(e(r), {
                      key: 0,
                      icon: "lucide:check",
                      class: o(e(t).e("action-check"))
                    }, null, 8, ["class"])) : S("", !0)
                  ], 10, ae),
                  a("button", {
                    class: o([
                      e(t).e("action"),
                      {
                        "is-active": q.value,
                        "is-disabled": !n("toggleHeaderColumn")
                      }
                    ]),
                    disabled: !n("toggleHeaderColumn"),
                    onClick: l[7] || (l[7] = (i) => c("toggleHeaderColumn"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:columns-3" })
                    ], 2),
                    a("div", {
                      class: o(e(t).e("action-content"))
                    }, [
                      a("span", {
                        class: o(e(t).e("action-title"))
                      }, "切换表头列", 2),
                      a("span", {
                        class: o(e(t).e("action-desc"))
                      }, "将首列设置为表头样式", 2)
                    ], 2),
                    q.value ? (v(), $(e(r), {
                      key: 0,
                      icon: "lucide:check",
                      class: o(e(t).e("action-check"))
                    }, null, 8, ["class"])) : S("", !0)
                  ], 10, le)
                ], 2),
                a("div", {
                  class: o(e(t).e("divider"))
                }, null, 2),
                a("div", {
                  class: o(e(t).e("danger-zone"))
                }, [
                  a("button", {
                    class: o([
                      e(t).e("action"),
                      e(t).m("danger"),
                      { "is-disabled": !n("deleteRow") }
                    ]),
                    disabled: !n("deleteRow"),
                    onClick: l[8] || (l[8] = (i) => c("deleteRow"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:minus" })
                    ], 2),
                    a("span", {
                      class: o(e(t).e("action-title"))
                    }, "删除当前行", 2)
                  ], 10, se),
                  a("button", {
                    class: o([
                      e(t).e("action"),
                      e(t).m("danger"),
                      { "is-disabled": !n("deleteColumn") }
                    ]),
                    disabled: !n("deleteColumn"),
                    onClick: l[9] || (l[9] = (i) => c("deleteColumn"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:minus" })
                    ], 2),
                    a("span", {
                      class: o(e(t).e("action-title"))
                    }, "删除当前列", 2)
                  ], 10, ne),
                  a("button", {
                    class: o([
                      e(t).e("action"),
                      e(t).m("danger"),
                      e(t).m("destructive"),
                      { "is-disabled": !n("deleteTable") }
                    ]),
                    disabled: !n("deleteTable"),
                    onClick: l[10] || (l[10] = (i) => c("deleteTable"))
                  }, [
                    a("div", {
                      class: o(e(t).e("action-icon"))
                    }, [
                      d(e(r), { icon: "lucide:trash-2" })
                    ], 2),
                    a("span", {
                      class: o(e(t).e("action-title"))
                    }, "删除表格", 2)
                  ], 10, de)
                ], 2)
              ], 64)) : (v(), H(B, { key: 0 }, [
                a("div", {
                  class: o(e(t).e("header"))
                }, [
                  d(e(r), {
                    icon: "lucide:table",
                    class: o(e(t).e("header-icon"))
                  }, null, 8, ["class"]),
                  l[12] || (l[12] = a("span", null, "插入表格", -1))
                ], 2),
                a("div", {
                  class: o(e(t).e("grid-picker"))
                }, [
                  (v(), H(B, null, P(6, (i) => a("div", {
                    key: i,
                    class: o(e(t).e("grid-row"))
                  }, [
                    (v(), H(B, null, P(6, (R) => a("button", {
                      key: R,
                      type: "button",
                      class: o([
                        e(t).e("grid-cell"),
                        { "is-active": i <= m.value && R <= w.value }
                      ]),
                      onMouseenter: (D) => V(i, R),
                      onMouseleave: Z,
                      onClick: (D) => O(i, R)
                    }, null, 42, J)), 64))
                  ], 2)), 64))
                ], 2),
                a("div", {
                  class: o(e(t).e("grid-hint"))
                }, W(m.value > 0 ? `${m.value} × ${w.value}` : "选择表格大小"), 3)
              ], 64))
            ], 2)
          ];
        }),
        default: f(() => {
          var p;
          return [
            I(u.$slots, "default", L(U({ isActive: (p = A.editor) == null ? void 0 : p.isActive("table") })))
          ];
        }),
        _: 3
      }, 8, ["visible", "popper-class", "offset", "append-to", "disabled"]);
    };
  }
});
export {
  pe as default
};
//# sourceMappingURL=table-menu-B_rJSK3k.mjs.map
