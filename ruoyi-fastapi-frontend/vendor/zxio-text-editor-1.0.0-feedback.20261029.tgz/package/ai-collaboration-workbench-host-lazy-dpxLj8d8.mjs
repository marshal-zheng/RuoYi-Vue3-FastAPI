const a = async (o) => (await import("./ai-collaboration-workbench-host-IIPakMIi.mjs")).createAICollaborationWorkbenchCommitHost(o), n = async (o) => (await import("./ai-collaboration-workbench-host-IIPakMIi.mjs")).readAICollaborationWorkbenchCanonicalDocument(o);
export {
  a as c,
  n as r
};
//# sourceMappingURL=ai-collaboration-workbench-host-lazy-dpxLj8d8.mjs.map
