import { G as f } from "./use-text-editor-command-keybindings-FrTE8ei0.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-link-DuvucRvV.mjs.map
