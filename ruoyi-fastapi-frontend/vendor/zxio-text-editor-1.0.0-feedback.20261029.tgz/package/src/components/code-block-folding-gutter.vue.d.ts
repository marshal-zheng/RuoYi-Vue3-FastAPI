import { ZxCodeBlockDisplayRow } from '../code-block';
import { ZxCodeBlockFoldingGutterMode } from './use-code-block-folding';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    mode: Exclude<ZxCodeBlockFoldingGutterMode, 'none'>;
    rows: readonly ZxCodeBlockDisplayRow[];
    highlightedLineNumbers: ReadonlySet<number>;
    /**
     * Measured pixel height per logical line while the code wraps. Rows without
     * a measurement keep the fixed line box.
     */
    rowHeights?: readonly number[] | null;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    "toggle-fold": (rangeKey: string) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onToggle-fold"?: ((rangeKey: string) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=code-block-folding-gutter.vue.d.ts.map