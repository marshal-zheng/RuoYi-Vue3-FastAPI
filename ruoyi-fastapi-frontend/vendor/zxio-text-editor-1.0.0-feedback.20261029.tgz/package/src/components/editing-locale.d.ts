export declare const useEditingLocale: () => {
    text: (key: string | undefined, fallback: string) => string;
    format: (key: string | undefined, fallback: string, params: Record<string, string | number>) => string;
};
//# sourceMappingURL=editing-locale.d.ts.map