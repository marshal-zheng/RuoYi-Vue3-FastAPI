import { CodeBlockLowlightOptions } from '@tiptap/extension-code-block-lowlight';
import { ZxCodeBlockLanguageDetectionQueue, ZxCodeBlockUserPreferences } from '../code-block';
import { Node, Mark } from '@tiptap/core';
import { CodeOptions } from '@tiptap/extension-code';
export declare const inputRegex: RegExp;
export declare const CODE_BLOCK_FENCE_INPUT_REGEX: RegExp;
interface ExtendedCodeBlockOptions extends CodeBlockLowlightOptions {
    codeBlockPreferences: Partial<ZxCodeBlockUserPreferences> | null;
}
interface ExtendedCodeBlockStorage {
    /**
     * Pasted code waiting for a UI-only language suggestion. The paste path
     * enqueues; the NodeView that mounts for the block consumes it once.
     */
    pendingLanguageDetection: ZxCodeBlockLanguageDetectionQueue;
}
declare module '@tiptap/core' {
    interface Storage {
        codeBlock: ExtendedCodeBlockStorage;
    }
}
export declare const ExtendedCodeBlock: Node<ExtendedCodeBlockOptions, ExtendedCodeBlockStorage>;
export declare const ExtendedCode: Mark<CodeOptions, any>;
export {};
//# sourceMappingURL=code-block.d.ts.map