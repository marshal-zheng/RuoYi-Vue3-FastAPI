function Ne(e) {
  return `zx-${e}`;
}
function zt(e, t) {
  return `zx-${e}__${t}`;
}
const De = "pageBreak", It = "data-zx-page-break", Nt = Ne("text-editor-page-break"), Dt = "<!-- zx-page-break -->", F = (e) => !e || typeof e != "object" ? e : Array.isArray(e) ? (e.forEach((t) => F(t)), Object.freeze(e)) : (Object.values(e).forEach((t) => F(t)), Object.freeze(e)), v = (e) => F({
  ...e,
  table: e.table ? { ...e.table } : void 0
}), u = (e) => v(e), $ = (e, t = `Pages layout can paginate "${e}" at top-level block boundaries.`) => u({
  nodeType: e,
  split: "block-boundary",
  atomic: !1,
  nonSplittable: !1,
  asyncSized: !1,
  measurable: !0,
  exportSensitive: !1,
  risk: "safe",
  defaultSeverity: "info",
  diagnosticCode: "pages.blockSafety.unsupported",
  message: t,
  recoveryHint: "Continue using automatic Pages layout; no block-specific action is required."
}), b = (e, t, r = `Pages layout treats top-level "${e}" as one non-splittable block in this phase.`) => u({
  nodeType: e,
  split: "block-boundary",
  atomic: !1,
  nonSplittable: !0,
  asyncSized: !1,
  measurable: !0,
  exportSensitive: !1,
  risk: "partial",
  defaultSeverity: "warning",
  diagnosticCode: "pages.blockSafety.unsupported",
  message: r,
  recoveryHint: t
}), ne = u({
  nodeType: "*",
  split: "unsupported",
  atomic: !0,
  nonSplittable: !0,
  asyncSized: !1,
  measurable: !1,
  exportSensitive: !0,
  risk: "unsupported",
  defaultSeverity: "warning",
  diagnosticCode: "pages.blockSafety.unknown",
  message: "Pages layout encountered an unknown top-level block and is using a conservative partial page map.",
  recoveryHint: "Register an explicit block safety rule before treating this custom block as safely splittable."
}), Re = F([
  $("paragraph"),
  $("heading"),
  $("blockquote"),
  b(
    "bulletList",
    "Split long lists into smaller sections if page boundaries need to be exact."
  ),
  b(
    "orderedList",
    "Split long lists into smaller sections if page boundaries need to be exact."
  ),
  b(
    "taskList",
    "Split long task lists into smaller sections if page boundaries need to be exact."
  ),
  b(
    "toggle",
    "Move or split toggle content when it must align with page boundaries."
  ),
  u({
    nodeType: "table",
    split: "future-row-boundary",
    atomic: !1,
    nonSplittable: !0,
    asyncSized: !1,
    measurable: !0,
    exportSensitive: !0,
    risk: "unsupported",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.table-non-splittable",
    message: "Tables are paginated as one non-splittable top-level block in this phase.",
    recoveryHint: "Move the table, reduce its height, or split it manually; row splitting is reserved for a later phase.",
    table: {
      rowSplitting: "not-supported",
      hasRowMetadata: !0
    }
  }),
  b(
    "image",
    "Reduce the image size, move it to a new page, or adjust page settings."
  ),
  b(
    "imageGroup",
    "Split the image group, reduce image sizes, or adjust page settings."
  ),
  u({
    nodeType: "video",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !0,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.async-sized",
    message: "Video blocks depend on async media sizing and remain non-splittable.",
    recoveryHint: "Wait for media load remeasurement, reduce the block size, or move it to a dedicated page."
  }),
  u({
    nodeType: "iframe",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !0,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.async-sized",
    message: "Iframe blocks depend on async embed sizing and remain non-splittable.",
    recoveryHint: "Wait for iframe load remeasurement, reduce the embed size, or move it to a dedicated page."
  }),
  u({
    nodeType: "embed",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !0,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.async-sized",
    message: "Embed blocks may depend on async content sizing and remain non-splittable.",
    recoveryHint: "Wait for embed load remeasurement, reduce the embed size, or move it to a dedicated page."
  }),
  b(
    "codeBlock",
    "Split large code blocks manually; inline-level code splitting is not enabled in this phase."
  ),
  u({
    nodeType: "attachment",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !1,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.unsupported",
    message: "Attachment blocks are treated as atomic non-splittable content.",
    recoveryHint: "Move oversized attachments or accept a partial page map for the affected page."
  }),
  u({
    nodeType: De,
    split: "manual-boundary",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !1,
    measurable: !1,
    exportSensitive: !1,
    risk: "safe",
    defaultSeverity: "info",
    diagnosticCode: "pages.pageBreak.command-invalid",
    message: "PageBreak creates a user-authored forced page boundary.",
    recoveryHint: "Keep PageBreak nodes in the document when explicit page boundaries are required."
  })
]), G = (e, t) => v({
  ...e,
  ...t,
  table: t.table || e.table ? {
    ...e.table ?? {
      rowSplitting: "not-supported",
      hasRowMetadata: !1
    },
    ...t.table ?? {}
  } : void 0
}), je = (e, t) => F({
  version: 1,
  rules: Array.from(e, v),
  unknownRule: v(t)
}), Rt = (e = []) => {
  const t = /* @__PURE__ */ new Map();
  Re.forEach((a) => {
    t.set(a.nodeType, v(a));
  });
  let r = v(ne);
  return e.forEach((a) => {
    if (!a.nodeType)
      return;
    if (a.nodeType === "*" || a.nodeType === "unknown") {
      r = G(r, {
        ...a,
        nodeType: "*"
      });
      return;
    }
    const o = t.get(a.nodeType);
    t.set(
      a.nodeType,
      G(o || {
        ...ne,
        nodeType: a.nodeType
      }, a)
    );
  }), F({
    resolveRule: (a) => v(t.get(a) ?? { ...r, nodeType: a }),
    getSnapshot: () => je(t.values(), r)
  });
}, jt = (e, t) => e.resolveRule(t), Vt = (e) => e.getSnapshot();
class ye extends Error {
  constructor(t) {
    super(t.message), this.name = "ZxPagesContractError", this.diagnostic = t;
  }
}
const Ve = (e) => ({ ...e }), Ht = (e, t) => {
  e.push(Ve(t));
}, y = (e) => new ye(e), Ut = (e) => e instanceof ye, h = 96, be = 2.54, we = 72, c = (e, t = "value") => {
  if (!Number.isFinite(e))
    throw y({
      code: "pages.unit.invalid",
      severity: "error",
      message: `Pages ${t} must be a finite number.`,
      target: t
    });
  return e;
}, P = (e) => c(e, "inches") * h, x = (e) => c(e, "centimeters") / be * h, ve = (e) => c(e, "pixels") / h, $t = (e) => ve(e) * be, _ = (e) => ve(e) * we, C = (e) => c(e, "printPoints") / we * h, Le = {
  top: h,
  right: h,
  bottom: h,
  left: h
}, ke = (e) => ({
  top: e.top,
  right: e.right,
  bottom: e.bottom,
  left: e.left
}), Se = (e) => ({
  id: e.id,
  label: e.label,
  width: e.width,
  height: e.height,
  defaultMargins: ke(e.defaultMargins),
  ...e.metadata ? { metadata: { ...e.metadata } } : {}
}), He = (e) => (e.metadata && Object.freeze(e.metadata), Object.freeze(e.defaultMargins), Object.freeze(e)), E = (e, t, r, a) => He({
  id: e,
  label: t,
  width: r,
  height: a,
  defaultMargins: ke(Le)
}), f = /* @__PURE__ */ new Map([
  ["a4", E("a4", "A4", x(21), x(29.7))],
  ["a3", E("a3", "A3", x(29.7), x(42))],
  ["a5", E("a5", "A5", x(14.8), x(21))],
  [
    "letter",
    E(
      "letter",
      "Letter",
      P(8.5),
      P(11)
    )
  ],
  [
    "legal",
    E(
      "legal",
      "Legal",
      P(8.5),
      P(14)
    )
  ],
  [
    "tabloid",
    E(
      "tabloid",
      "Tabloid",
      P(11),
      P(17)
    )
  ]
]);
class Ue {
  get size() {
    return f.size;
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  entries() {
    return f.entries();
  }
  forEach(t, r) {
    f.forEach(
      (a, o) => t.call(r, a, o, this)
    );
  }
  get(t) {
    return f.get(t);
  }
  has(t) {
    return f.has(t);
  }
  keys() {
    return f.keys();
  }
  values() {
    return f.values();
  }
}
const $e = Object.freeze(new Ue()), Gt = (e) => $e.has(e), W = (e) => {
  const t = f.get(e);
  return t ? Se(t) : null;
}, Y = (e, t) => {
  const r = {
    top: c(e.top, "margin.top"),
    right: c(e.right, "margin.right"),
    bottom: c(e.bottom, "margin.bottom"),
    left: c(e.left, "margin.left")
  }, a = Object.entries(r).find(([, o]) => o < 0);
  if (a)
    throw y({
      code: "pages.margins.invalid",
      severity: "error",
      message: `Pages margin "${a[0]}" must be non-negative.`,
      path: `margins.${a[0]}`
    });
  if (r.left + r.right >= t.width)
    throw y({
      code: "pages.margins.invalid",
      severity: "error",
      message: "Pages horizontal margins must be smaller than page width.",
      path: "margins.left+right"
    });
  if (r.top + r.bottom >= t.height)
    throw y({
      code: "pages.margins.invalid",
      severity: "error",
      message: "Pages vertical margins must be smaller than page height.",
      path: "margins.top+bottom"
    });
  return r;
}, X = (e) => {
  if (typeof e == "string") {
    const s = W(e);
    if (!s)
      throw y({
        code: "pages.format.unknown",
        severity: "error",
        message: `Unknown Pages page format "${e}".`,
        target: e
      });
    return s;
  }
  const t = typeof e.id == "string" ? e.id.trim() : "", r = typeof e.label == "string" ? e.label.trim() : "", a = c(e.width, "page.width"), o = c(e.height, "page.height");
  if (!t || !r || a <= 0 || o <= 0)
    throw y({
      code: "pages.format.invalid",
      severity: "error",
      message: "Custom Pages page formats require id, label, positive width and positive height.",
      target: t || void 0
    });
  const i = {
    id: t,
    label: r,
    width: a,
    height: o,
    defaultMargins: Y(e.defaultMargins, {
      width: a,
      height: o
    }),
    ...e.metadata ? { metadata: { ...e.metadata } } : {}
  };
  return Se(i);
}, D = (e = {}, t = Le) => ({
  top: e.top ?? t.top,
  right: e.right ?? t.right,
  bottom: e.bottom ?? t.bottom,
  left: e.left ?? t.left
}), Q = [
  "default",
  "firstPage",
  "oddPage",
  "evenPage"
], Ge = ["header", "footer"], Pe = (e) => JSON.parse(JSON.stringify(e)), L = (e) => typeof e == "object" && e !== null && !Array.isArray(e), le = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0, Zt = (e) => typeof e == "string" && Ge.includes(e), qt = (e) => typeof e == "string" && Q.includes(e), Kt = () => ({
  version: 1,
  differentFirstPage: !1,
  differentOddEven: !1
}), xe = (e) => e.state === "empty" ? { state: "empty" } : {
  state: "content",
  ...e.content ? { content: Pe(e.content) } : {}
}, Ze = (e) => {
  if (L(e)) {
    if (e.state === "empty")
      return { state: "empty" };
    if (e.state === "content" && L(e.content))
      return {
        state: "content",
        content: Pe(e.content)
      };
  }
}, qe = (e) => {
  if (!e)
    return;
  const t = {};
  return Q.forEach((r) => {
    const a = e[r];
    a && (t[r] = xe(a));
  }), Object.keys(t).length ? t : void 0;
}, R = (e) => {
  if (!L(e))
    return;
  const t = {};
  return Q.forEach((r) => {
    const a = Ze(e[r]);
    a && (t[r] = a);
  }), Object.keys(t).length ? t : void 0;
}, Ke = (e) => {
  if (!Array.isArray(e))
    return;
  const t = e.filter(
    (r) => L(r) && typeof r.sectionId == "string" && !!r.sectionId.trim()
  ).map((r) => {
    const a = R(r.header), o = R(r.footer);
    return {
      sectionId: r.sectionId.trim(),
      ...typeof r.startBlockId == "string" && r.startBlockId.trim() ? { startBlockId: r.startBlockId.trim() } : {},
      ...typeof r.differentFirstPage == "boolean" ? { differentFirstPage: r.differentFirstPage } : {},
      ...typeof r.differentOddEven == "boolean" ? { differentOddEven: r.differentOddEven } : {},
      ...a ? { header: a } : {},
      ...o ? { footer: o } : {}
    };
  });
  return t.length ? t : void 0;
}, k = (e = {}) => {
  const t = L(e) ? e : {}, r = R(t.header), a = R(t.footer), o = Ke(t.sections);
  return {
    version: 1,
    differentFirstPage: t.differentFirstPage === !0,
    differentOddEven: t.differentOddEven === !0,
    ...le(t.headerTopMargin) ? { headerTopMargin: t.headerTopMargin } : {},
    ...le(t.footerBottomMargin) ? { footerBottomMargin: t.footerBottomMargin } : {},
    ...r ? { header: r } : {},
    ...a ? { footer: a } : {},
    ...o ? { sections: o } : {}
  };
}, Xt = k, Ee = (e) => !L(e) && !Array.isArray(e) ? e : (Object.values(e).forEach((t) => {
  (L(t) || Array.isArray(t)) && Ee(t);
}), Object.freeze(e)), Jt = (e = {}) => Ee(k(e)), j = "a4", _e = "portrait", S = (e) => JSON.parse(JSON.stringify(e)), p = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Xe = (e) => !("meta" in e), Je = (e) => Xe(e) ? e : e.meta, ee = (e, t = _e) => e === "portrait" || e === "landscape" ? e : t, T = (e) => typeof e == "number" && Number.isFinite(e) && e > 0, te = (e, t = { id: j }) => typeof e == "string" && e.trim() ? { id: e.trim() } : !p(e) || typeof e.id != "string" || !e.id.trim() ? { ...t } : {
  id: e.id.trim(),
  ...typeof e.label == "string" && e.label.trim() ? { label: e.label.trim() } : {},
  ...typeof e.width == "number" && Number.isFinite(e.width) ? { width: e.width } : {},
  ...typeof e.height == "number" && Number.isFinite(e.height) ? { height: e.height } : {}
}, A = (e, t = {}) => {
  const r = W(e.id);
  if (r && e.width === void 0 && e.height === void 0)
    return r;
  if (T(e.width) && T(e.height))
    return X({
      id: e.id,
      label: e.label ?? e.id,
      width: e.width,
      height: e.height,
      defaultMargins: (r == null ? void 0 : r.defaultMargins) ?? z().defaultMargins
    });
  if (r)
    return r;
  const a = t.unknownFormatFallback;
  if (!a)
    throw y({
      code: "pages.format.unknown",
      severity: "error",
      message: `Unknown Pages page format "${e.id}" requires width and height.`,
      target: e.id,
      path: "pageFormat"
    });
  return X({
    id: e.id,
    label: e.label ?? e.id,
    width: a.width,
    height: a.height,
    defaultMargins: a.defaultMargins,
    metadata: {
      fallback: !0
    }
  });
}, Ce = (e) => A(e, {
  unknownFormatFallback: z()
}), z = () => X(j), re = (e, t, r) => {
  const a = p(e) ? D(
    {
      top: typeof e.top == "number" ? e.top : void 0,
      right: typeof e.right == "number" ? e.right : void 0,
      bottom: typeof e.bottom == "number" ? e.bottom : void 0,
      left: typeof e.left == "number" ? e.left : void 0
    },
    t
  ) : D({}, t);
  return Y(a, r);
}, Be = (e, t) => {
  if (p(e))
    return D(
      {
        ...typeof e.top == "number" ? { top: C(e.top) } : {},
        ...typeof e.right == "number" ? { right: C(e.right) } : {},
        ...typeof e.bottom == "number" ? { bottom: C(e.bottom) } : {},
        ...typeof e.left == "number" ? { left: C(e.left) } : {}
      },
      t
    );
}, We = (e) => ({
  top: _(e.top),
  right: _(e.right),
  bottom: _(e.bottom),
  left: _(e.left)
}), Me = (e, t) => {
  const r = p(e) ? e : {}, a = typeof r.size == "string" && r.size.trim() ? r.size.trim() : t.id, o = typeof r.label == "string" && r.label.trim() ? r.label.trim() : t.label, i = T(r.width) ? C(r.width) : void 0, s = T(r.height) ? C(r.height) : void 0;
  if (i !== void 0 && s !== void 0)
    return {
      id: a,
      ...o ? { label: o } : {},
      width: i,
      height: s
    };
  if (W(a))
    return {
      id: a,
      ...o ? { label: o } : {}
    };
  const n = Ce(t);
  return {
    id: a,
    label: o ?? a,
    width: n.width,
    height: n.height
  };
}, Ye = (e, t) => {
  const r = (t == null ? void 0 : t.pageFormat) ?? { id: j }, a = te(
    p(e) ? e.pageFormat : void 0,
    r
  ), o = A(a), i = (t == null ? void 0 : t.margins) ?? o.defaultMargins ?? z().defaultMargins;
  return {
    pageFormat: a,
    orientation: ee(
      p(e) ? e.orientation : void 0,
      t == null ? void 0 : t.orientation
    ),
    margins: re(
      p(e) ? e.margins : void 0,
      i,
      o
    )
  };
}, Qe = (e, t) => {
  const r = { id: j }, a = p(e) ? e : {}, o = Me(e, r), i = Ce(o), s = i.defaultMargins ?? z().defaultMargins, n = Be(
    a.margins,
    s
  );
  return {
    pageFormat: o,
    orientation: ee(
      a.orientation,
      t == null ? void 0 : t.orientation
    ),
    margins: re(n, s, i)
  };
}, et = (e, t) => {
  if (!p(e))
    return;
  const r = "pageFormat" in e, a = "orientation" in e, o = "margins" in e;
  if (!r && !a && !o)
    return;
  const i = r ? te(e.pageFormat, t.pageFormat) : t.pageFormat, s = A(i), n = {};
  return r && (n.pageFormat = i), a && (n.orientation = ee(
    e.orientation,
    t.orientation
  )), o && (n.margins = re(
    e.margins,
    t.margins,
    s
  )), n;
}, tt = (e, t) => {
  const r = e.page ? et(e.page, t) : void 0;
  return {
    id: e.id,
    startBlockId: e.startBlockId,
    ...r ? { page: r } : {},
    ...e.intent ? { intent: S(e.intent) } : {}
  };
}, rt = (e, t) => {
  if (!Array.isArray(e))
    return;
  const r = e.filter(
    (a) => p(a) && typeof a.id == "string" && !!a.id.trim() && typeof a.startBlockId == "string" && !!a.startBlockId.trim()
  ).map(
    (a) => tt(
      {
        ...a,
        id: a.id.trim(),
        startBlockId: a.startBlockId.trim()
      },
      t
    )
  );
  return r.length ? r : void 0;
}, at = (e, t) => {
  if (e != null && e.length)
    return e.map((r) => ({
      id: r.id,
      startBlockId: r.startBlockId,
      ...r.page ? {
        page: {
          ...r.page.size ? {
            pageFormat: Me(
              r.page,
              t.pageFormat
            )
          } : {},
          ...r.page.orientation ? { orientation: r.page.orientation } : {},
          ...r.page.margins ? {
            margins: Be(
              r.page.margins,
              t.margins
            )
          } : {}
        }
      } : {},
      ...r.intent ? { intent: S(r.intent) } : {}
    }));
}, g = (e = {}) => {
  var s, n;
  const t = z(), r = {
    pageFormat: {
      id: t.id
    },
    orientation: _e,
    margins: t.defaultMargins
  }, a = Ye((s = e.defaults) == null ? void 0 : s.page, r), o = rt(e.sections, a), i = e.headerFooter ? k(e.headerFooter) : void 0;
  return {
    version: 1,
    defaults: {
      page: a,
      ...(n = e.defaults) != null && n.intent ? { intent: S(e.defaults.intent) } : {}
    },
    ...o ? { sections: o } : {},
    ...i ? { headerFooter: i } : {}
  };
}, ot = (e) => {
  var a, o;
  const t = Je(e);
  if (t.pages)
    return g(t.pages);
  const r = t.binaryExport;
  if (r) {
    const i = Qe((a = r.defaults) == null ? void 0 : a.page), s = at(
      r.sections,
      i
    );
    return g({
      defaults: {
        page: i,
        ...(o = r.defaults) != null && o.intent ? { intent: S(r.defaults.intent) } : {}
      },
      ...s ? { sections: s } : {}
    });
  }
  return g();
}, Wt = (e, t) => {
  const r = g(e), a = r.defaults.page, o = t.pageFormat ? te(t.pageFormat, a.pageFormat) : a.pageFormat, i = A(o), s = Y(
    D(t.margins, a.margins),
    i
  );
  return g({
    ...r,
    defaults: {
      ...r.defaults,
      page: {
        pageFormat: o,
        orientation: t.orientation ?? a.orientation,
        margins: s
      }
    }
  });
}, it = (e, t) => t === "header" ? e.header : e.footer, st = (e, t, r) => t === "header" ? {
  ...e,
  ...r ? { header: r } : { header: void 0 }
} : {
  ...e,
  ...r ? { footer: r } : { footer: void 0 }
}, Yt = (e, t) => {
  const r = t.mode ?? "set", a = g(e), o = k(
    a.headerFooter
  ), i = {
    ...qe(
      it(o, t.kind)
    ) ?? {}
  };
  if (r === "unset")
    delete i[t.slot];
  else if (r === "empty")
    i[t.slot] = { state: "empty" };
  else if (t.value)
    i[t.slot] = xe(t.value);
  else
    throw y({
      code: "pages.headerFooter.content-invalid",
      severity: "error",
      message: "Header/footer slot replacement requires content value.",
      target: `${t.kind}.${t.slot}`,
      path: `headerFooter.${t.kind}.${t.slot}`,
      recoveryHint: 'Pass a normalized content value, use mode "empty", or use mode "unset".'
    });
  const s = st(
    o,
    t.kind,
    Object.keys(i).length ? i : void 0
  );
  return g({
    ...a,
    headerFooter: k(s)
  });
}, Qt = (e, t) => {
  const r = g(e), a = k(
    r.headerFooter
  );
  return g({
    ...r,
    headerFooter: k({
      ...a,
      ...typeof t.differentFirstPage == "boolean" ? { differentFirstPage: t.differentFirstPage } : {},
      ...typeof t.differentOddEven == "boolean" ? { differentOddEven: t.differentOddEven } : {}
    })
  });
}, de = (e) => {
  const t = e.pageFormat;
  return {
    ...t != null && t.id ? { size: t.id } : {},
    ...t != null && t.label ? { label: t.label } : {},
    ...T(t == null ? void 0 : t.width) && T(t == null ? void 0 : t.height) ? {
      width: _(t.width),
      height: _(t.height)
    } : {},
    ...e.orientation ? { orientation: e.orientation } : {},
    ...e.margins ? { margins: We(e.margins) } : {}
  };
}, er = (e) => ({
  ...e,
  pageFormat: A(e.pageFormat)
}), nt = (e) => {
  var r;
  const t = g(e);
  return {
    defaults: {
      page: de(t.defaults.page),
      ...t.defaults.intent ? { intent: S(t.defaults.intent) } : {}
    },
    ...(r = t.sections) != null && r.length ? {
      sections: t.sections.map((a) => ({
        id: a.id,
        startBlockId: a.startBlockId,
        ...a.page ? { page: de(a.page) } : {},
        ...a.intent ? { intent: S(a.intent) } : {}
      }))
    } : {}
  };
}, tr = (e) => e.meta.pages ? nt(
  ot(e)
) : e.meta.binaryExport ? S(e.meta.binaryExport) : void 0, ae = "zx-code-block/v2", rr = [
  "platform-default",
  "user-preference",
  "node-explicit",
  "migration"
], lt = (e = "platform-default") => ({
  contractVersion: "platform-default",
  language: e,
  detectedLanguage: "platform-default",
  filename: e,
  caption: e,
  showLineNumbers: e,
  startLine: e,
  wrap: e,
  collapsed: e,
  previewLines: e,
  heightMode: e,
  height: e,
  theme: e,
  highlightLines: e,
  copyMode: e,
  variant: e,
  groupId: e,
  tabLabel: e
}), dt = (e = "platform-default") => ({
  contractVersion: ae,
  language: null,
  detectedLanguage: null,
  filename: "",
  caption: "",
  showLineNumbers: !0,
  startLine: 1,
  wrap: "inherit",
  collapsed: !1,
  previewLines: null,
  heightMode: "max",
  height: null,
  theme: null,
  highlightLines: [],
  copyMode: "plain",
  variant: "code",
  groupId: null,
  tabLabel: "",
  defaultSource: lt(e)
}), ar = [
  {
    field: "contractVersion",
    type: "'zx-code-block/v2'",
    defaultValue: ae,
    sourcePolicy: "platform-default/generated",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Migration idempotency marker"
  },
  {
    field: "language",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Normalized language id"
  },
  {
    field: "detectedLanguage",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved for language detection"
  },
  {
    field: "filename",
    type: "string",
    defaultValue: "",
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Display filename or migrated legacy title"
  },
  {
    field: "caption",
    type: "string",
    defaultValue: "",
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Optional prose caption"
  },
  {
    field: "showLineNumbers",
    type: "boolean",
    defaultValue: !0,
    sourcePolicy: "node-explicit | user-preference | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Line number display state"
  },
  {
    field: "startLine",
    type: "number",
    defaultValue: 1,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "First rendered line number"
  },
  {
    field: "wrap",
    type: "'inherit' | 'off' | 'on'",
    defaultValue: "inherit",
    sourcePolicy: "node-explicit | user-preference | markdown-sidecar | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Wrap preference state"
  },
  {
    field: "collapsed",
    type: "boolean",
    defaultValue: !1,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Collapsed display state"
  },
  {
    field: "previewLines",
    type: "number | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | user-preference | markdown-sidecar | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Preview line count when collapsed"
  },
  {
    field: "heightMode",
    type: "'auto' | 'max' | 'fixed'",
    defaultValue: "max",
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Height semantics for current and later UI"
  },
  {
    field: "height",
    type: "number | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Fixed or max height value in pixels"
  },
  {
    field: "theme",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | user-preference | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved highlighter theme preference"
  },
  {
    field: "highlightLines",
    type: "ZxCodeBlockLineRange[]",
    defaultValue: [],
    sourcePolicy: "node-explicit | markdown-sidecar | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Line highlight ranges"
  },
  {
    field: "copyMode",
    type: "'plain' | 'markdown'",
    defaultValue: "plain",
    sourcePolicy: "node-explicit | user-preference | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Copy behavior preference"
  },
  {
    field: "variant",
    type: "'code'",
    defaultValue: "code",
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved variant discriminator"
  },
  {
    field: "groupId",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved multilingual group id"
  },
  {
    field: "tabLabel",
    type: "string",
    defaultValue: "",
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved multilingual tab label"
  },
  {
    field: "defaultSource",
    type: "field source map",
    defaultValue: "generated",
    sourcePolicy: "generated from normalization",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Per-field source provenance"
  }
], ce = (e) => e, m = (e, t) => {
  e.some(
    (a) => a.code === t.code && a.path === t.path && a.message === t.message
  ) || e.push(t);
}, ct = Object.freeze([
  "arduino",
  "bash",
  "c",
  "cpp",
  "csharp",
  "css",
  "diff",
  "go",
  "graphql",
  "html",
  "ini",
  "java",
  "javascript",
  "json",
  "kotlin",
  "less",
  "lua",
  "makefile",
  "markdown",
  "objectivec",
  "perl",
  "php",
  "php-template",
  "plaintext",
  "python",
  "python-repl",
  "r",
  "ruby",
  "rust",
  "scss",
  "shell",
  "sql",
  "swift",
  "typescript",
  "vbnet",
  "wasm",
  "xml",
  "yaml"
]), pt = Object.freeze({
  js: "javascript",
  javascript: "javascript",
  jsx: "javascript",
  mjs: "javascript",
  cjs: "javascript",
  ts: "typescript",
  typescript: "typescript",
  tsx: "typescript",
  mts: "typescript",
  cts: "typescript",
  sh: "bash",
  bash: "bash",
  shell: "bash",
  zsh: "bash",
  console: "bash",
  shellsession: "bash",
  plaintext: "plaintext",
  "plain text": "plaintext",
  plain: "plaintext",
  text: "plaintext",
  txt: "plaintext",
  json: "json",
  jsonc: "json",
  html: "html",
  xhtml: "html",
  xml: "xml",
  svg: "xml",
  css: "css",
  scss: "scss",
  less: "less",
  yaml: "yaml",
  yml: "yaml",
  markdown: "markdown",
  md: "markdown",
  python: "python",
  py: "python",
  "python-repl": "python-repl",
  pycon: "python-repl",
  java: "java",
  jsp: "java",
  c: "c",
  h: "c",
  cpp: "cpp",
  "c++": "cpp",
  cc: "cpp",
  cxx: "cpp",
  hpp: "cpp",
  hh: "cpp",
  hxx: "cpp",
  csharp: "csharp",
  cs: "csharp",
  "c#": "csharp",
  objectivec: "objectivec",
  objc: "objectivec",
  "objective-c": "objectivec",
  "obj-c": "objectivec",
  mm: "objectivec",
  go: "go",
  golang: "go",
  rust: "rust",
  rs: "rust",
  ruby: "ruby",
  rb: "ruby",
  php: "php",
  "php-template": "php-template",
  swift: "swift",
  kotlin: "kotlin",
  kt: "kotlin",
  kts: "kotlin",
  sql: "sql",
  diff: "diff",
  patch: "diff",
  graphql: "graphql",
  gql: "graphql",
  ini: "ini",
  toml: "ini",
  lua: "lua",
  makefile: "makefile",
  make: "makefile",
  mk: "makefile",
  perl: "perl",
  pl: "perl",
  pm: "perl",
  r: "r",
  vbnet: "vbnet",
  vb: "vbnet",
  wasm: "wasm",
  arduino: "arduino",
  ino: "arduino"
}), Fe = new Set(
  ct
), gt = /^[a-z0-9][a-z0-9#+._-]*$/, ut = (e) => typeof e != "string" ? null : e.trim().toLowerCase().replace(/\s+/g, " ") || null, J = (e, t = {}) => {
  const r = ut(e), a = t.source ?? (r ? "explicit" : "fallback"), o = t.supportedLanguages ?? Fe;
  if (!r)
    return {
      id: null,
      original: null,
      source: "fallback",
      supported: !0,
      diagnostics: []
    };
  const i = (e == null ? void 0 : e.trim()) || null, s = pt[r] ?? r;
  return o.has(s) ? {
    id: s,
    original: i,
    source: a,
    supported: !0,
    diagnostics: []
  } : gt.test(s) ? {
    id: s,
    original: i,
    source: a,
    supported: !1,
    diagnostics: [
      ce({
        code: "codeBlock.highlighter.unsupportedLanguage",
        severity: "info",
        path: "attrs.language",
        message: `Language "${e}" is kept, but the bundled highlighter cannot highlight it.`
      })
    ]
  } : {
    id: "plaintext",
    original: i,
    source: "fallback",
    supported: !1,
    diagnostics: [
      ce({
        code: "codeBlock.highlighter.invalidLanguage",
        severity: "warning",
        path: "attrs.language",
        message: `Language "${e}" is not a valid identifier and was downgraded to plaintext.`
      })
    ]
  };
}, mt = (e = {}) => () => {
  const t = e.supportedLanguages ?? Fe;
  return {
    normalizeLanguage: (r) => J(r, { supportedLanguages: t }),
    getLanguageSupport: (r) => {
      const a = J(r, {
        supportedLanguages: t
      });
      return {
        supported: a.supported !== !1,
        reason: a.supported === !1 ? "Language is not in the highlighter capability map." : void 0
      };
    },
    getThemeSupport: (r) => ({
      supported: r == null || r === "",
      reason: r ? "Theme support is reserved for a later highlighter adapter." : void 0
    })
  };
}, ft = /* @__PURE__ */ new Set(["inherit", "off", "on"]), ht = /* @__PURE__ */ new Set([
  "auto",
  "max",
  "fixed"
]), yt = /* @__PURE__ */ new Set(["plain", "markdown"]), bt = /* @__PURE__ */ new Set(["code"]), Te = (e) => typeof e == "object" && e !== null, l = (e, t) => Object.prototype.hasOwnProperty.call(e, t), pe = (e, t) => e === "platform-default" || e === "user-preference" || e === "node-explicit" || e === "migration" ? e : t, Z = (e) => typeof e == "string" && e.trim() ? e.trim() : null, q = (e) => typeof e == "string" ? e.trim() : "", ge = (e, t, r, a) => typeof e == "boolean" ? e : (e === void 0 || m(a, {
  code: "codeBlock.attr.invalid",
  severity: "warning",
  path: r,
  message: "Expected a boolean value; fallback was used."
}), t), wt = (e, t, r, a, o = {}) => {
  const i = typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null;
  return i !== null && i >= 1 ? i : (e === void 0 || m(a, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: r,
    message: o.nullable === !1 ? "Expected a positive integer; fallback was used." : "Expected a positive integer or null; fallback was used."
  }), t);
}, ue = (e, t, r, a) => {
  if (e == null || e === "") return t;
  const o = typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null;
  return o !== null && o >= 1 ? o : (m(a, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: r,
    message: "Expected a positive integer or null; fallback was used."
  }), t);
}, N = (e, t, r, a, o) => typeof e == "string" && t.has(e) ? e : (e === void 0 || m(o, {
  code: "codeBlock.attr.invalid",
  severity: "warning",
  path: a,
  message: `Unknown enum value "${String(e)}"; fallback was used.`
}), r), vt = (e, t) => e === void 0 ? [] : Array.isArray(e) ? e.flatMap((r, a) => {
  if (!Te(r))
    return m(t, {
      code: "codeBlock.attr.invalid",
      severity: "warning",
      path: `attrs.highlightLines.${a}`,
      message: "Expected highlight range to be an object."
    }), [];
  const o = typeof r.from == "number" && Number.isFinite(r.from) ? Math.round(r.from) : null, i = r.to === void 0 || r.to === null ? void 0 : typeof r.to == "number" && Number.isFinite(r.to) ? Math.round(r.to) : null;
  return !o || o < 1 || i === null || i !== void 0 && i < o ? (m(t, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: `attrs.highlightLines.${a}`,
    message: "Invalid highlight range was discarded."
  }), []) : i === void 0 ? [{ from: o }] : [{ from: o, to: i }];
}) : (m(t, {
  code: "codeBlock.attr.invalid",
  severity: "warning",
  path: "attrs.highlightLines",
  message: "Expected highlightLines to be an array; fallback was used."
}), []), Lt = (e = {}, t = {}) => {
  const r = [], a = t.source ?? "node-explicit", o = {
    ...dt(),
    ...t.defaults ?? {}
  }, i = new Set(t.explicitKeys ?? Object.keys(e)), s = Te(e.defaultSource) ? e.defaultSource : {}, n = (U, Ie = a) => i.has(U) ? pe(s[U], Ie) : pe(o.defaultSource[U], "platform-default"), ie = l(e, "language") ? e.language : o.language, V = J(
    typeof ie == "string" ? ie : null
  );
  r.push(...V.diagnostics);
  const Ae = l(e, "height") ? e.height : o.height, H = ue(
    Ae,
    o.height,
    "attrs.height",
    r
  ), ze = l(e, "heightMode") ? e.heightMode : o.heightMode;
  let I = N(
    ze,
    ht,
    o.heightMode,
    "attrs.heightMode",
    r
  );
  H !== null && !l(e, "heightMode") && (I = "fixed"), I === "fixed" && H === null && (m(r, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: "attrs.heightMode",
    message: "Fixed height mode requires a valid height; max mode was used."
  }), I = "max");
  const se = {
    contractVersion: ae,
    language: V.id,
    detectedLanguage: Z(
      l(e, "detectedLanguage") ? e.detectedLanguage : o.detectedLanguage
    ),
    filename: q(
      l(e, "filename") ? e.filename : o.filename
    ),
    caption: q(
      l(e, "caption") ? e.caption : o.caption
    ),
    showLineNumbers: ge(
      l(e, "showLineNumbers") ? e.showLineNumbers : o.showLineNumbers,
      o.showLineNumbers,
      "attrs.showLineNumbers",
      r
    ),
    startLine: wt(
      l(e, "startLine") ? e.startLine : o.startLine,
      o.startLine,
      "attrs.startLine",
      r,
      { nullable: !1 }
    ),
    wrap: N(
      l(e, "wrap") ? e.wrap : o.wrap,
      ft,
      o.wrap,
      "attrs.wrap",
      r
    ),
    collapsed: ge(
      l(e, "collapsed") ? e.collapsed : o.collapsed,
      o.collapsed,
      "attrs.collapsed",
      r
    ),
    previewLines: ue(
      l(e, "previewLines") ? e.previewLines : o.previewLines,
      o.previewLines,
      "attrs.previewLines",
      r
    ),
    heightMode: I,
    height: H,
    theme: Z(l(e, "theme") ? e.theme : o.theme),
    highlightLines: vt(
      l(e, "highlightLines") ? e.highlightLines : o.highlightLines,
      r
    ),
    copyMode: N(
      l(e, "copyMode") ? e.copyMode : o.copyMode,
      yt,
      o.copyMode,
      "attrs.copyMode",
      r
    ),
    variant: N(
      l(e, "variant") ? e.variant : o.variant,
      bt,
      o.variant,
      "attrs.variant",
      r
    ),
    groupId: Z(
      l(e, "groupId") ? e.groupId : o.groupId
    ),
    tabLabel: q(
      l(e, "tabLabel") ? e.tabLabel : o.tabLabel
    ),
    defaultSource: {}
  };
  return se.defaultSource = {
    contractVersion: "platform-default",
    language: n("language", V.source === "fallback" ? "platform-default" : a),
    detectedLanguage: n("detectedLanguage"),
    filename: n("filename"),
    caption: n("caption"),
    showLineNumbers: n("showLineNumbers"),
    startLine: n("startLine"),
    wrap: n("wrap"),
    collapsed: n("collapsed"),
    previewLines: n("previewLines"),
    heightMode: n("heightMode"),
    height: n("height"),
    theme: n("theme"),
    highlightLines: n("highlightLines"),
    copyMode: n("copyMode"),
    variant: n("variant"),
    groupId: n("groupId"),
    tabLabel: n("tabLabel")
  }, { attrs: se, diagnostics: r };
}, kt = (e) => e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), St = (e, t) => {
  const r = kt(e), a = r === "" ? [""] : r.split(`
`), o = a.length, i = Array.from(
    { length: o },
    (s, n) => t + n
  );
  return {
    normalizedText: r,
    visualLines: a,
    visualLineCount: o,
    lineNumbers: i
  };
}, Pt = (e, t) => e === null ? t : Math.min(Math.max(e, 1), t), xt = (e) => e.filename || e.tabLabel || e.language || "Code", Et = (e) => {
  const t = Lt(e.attrs, {
    defaults: e.defaults
  }), r = t.attrs, o = (e.highlighter ?? mt()()).normalizeLanguage(r.language), i = St(e.code, r.startLine), s = Pt(r.previewLines, i.visualLineCount);
  return {
    attrs: r,
    language: o,
    lines: i,
    display: {
      showLineNumbers: r.showLineNumbers,
      wrap: r.wrap,
      collapsed: r.collapsed,
      previewFrom: 1,
      previewTo: s,
      heightMode: r.heightMode,
      height: r.height
    },
    copy: {
      mode: r.copyMode,
      text: e.code
    },
    summary: {
      label: xt(r),
      lineCount: i.visualLineCount
    },
    diagnostics: [...t.diagnostics, ...o.diagnostics]
  };
}, _t = "text-editor.code-block-descriptor/v2", Ct = (e) => e.lines.visualLines.slice(0, e.display.previewTo).join(`
`), me = (e, t, r) => ({
  code: e,
  severity: "info",
  path: t,
  message: r
}), Bt = (e) => {
  var o;
  const t = Et(e), r = [...t.diagnostics], a = (o = e.highlighter) == null ? void 0 : o.getThemeSupport(t.attrs.theme);
  return t.attrs.copyMode === "markdown" && r.push(
    me(
      "codeBlock.delivery.partial",
      "attrs.copyMode",
      "copyMode markdown is preserved in the descriptor but plain text remains the stable copy payload."
    )
  ), t.attrs.theme && (a == null ? void 0 : a.supported) === !1 && r.push(
    me(
      "codeBlock.delivery.partial",
      "attrs.theme",
      a.reason ?? "Theme support is partial for this delivery surface."
    )
  ), {
    version: _t,
    nodeType: "codeBlock",
    attrs: t.attrs,
    code: e.code,
    language: t.language,
    displayLabel: t.summary.label,
    display: {
      filename: t.attrs.filename,
      caption: t.attrs.caption,
      showLineNumbers: t.display.showLineNumbers,
      startLine: t.attrs.startLine,
      wrap: t.display.wrap,
      collapsed: t.display.collapsed,
      previewFrom: t.display.previewFrom,
      previewTo: t.display.previewTo,
      heightMode: t.display.heightMode,
      height: t.display.height,
      highlightLines: t.attrs.highlightLines,
      theme: t.attrs.theme
    },
    lines: t.lines,
    copy: t.copy,
    summary: {
      text: e.code,
      previewText: Ct(t),
      lineCount: t.summary.lineCount
    },
    capabilities: {
      highlight: t.language.supported === !1 ? "unsupported" : "partial",
      markdownMeta: "supported",
      binaryExport: r.some(
        (i) => i.code === "codeBlock.delivery.partial"
      ) ? "partial" : "supported"
    },
    diagnostics: r
  };
}, or = [
  "public-read-page",
  "ssr-fragment-html",
  "ssr-fragment-react",
  "markdown-serializer",
  "markdown-parser",
  "html-serializer",
  "html-parser",
  "search-record",
  "excerpt-summary",
  "pdf-composition",
  "docx-composition"
], ir = [
  "code",
  "language",
  "display",
  "lines",
  "copy",
  "summary",
  "capabilities",
  "diagnostics"
], sr = [
  "codeBlock.delivery.contractRepairRequired",
  "codeBlock.delivery.fieldPartial",
  "codeBlock.delivery.fieldUnsupported",
  "codeBlock.delivery.securityRedacted",
  "codeBlock.delivery.legacyFallbackForbidden",
  "codeBlock.delivery.htmlFirstForbidden"
], d = {
  code: "supported",
  language: "supported",
  display: "supported",
  lines: "supported",
  copy: "supported",
  summary: "supported",
  capabilities: "supported",
  diagnostics: "supported"
}, Mt = {
  "public-read-page": {
    ...d,
    summary: "partial"
  },
  "ssr-fragment-html": {
    ...d,
    summary: "partial"
  },
  "ssr-fragment-react": {
    ...d,
    summary: "partial"
  },
  "markdown-serializer": {
    ...d,
    language: "partial",
    lines: "partial",
    copy: "partial",
    summary: "not-emitted"
  },
  "markdown-parser": {
    ...d,
    language: "partial"
  },
  "html-serializer": {
    ...d,
    lines: "partial",
    copy: "not-emitted",
    summary: "not-emitted"
  },
  "html-parser": d,
  "search-record": {
    ...d,
    language: "not-emitted",
    display: "not-emitted",
    lines: "not-emitted",
    copy: "not-emitted"
  },
  "excerpt-summary": {
    ...d,
    code: "partial",
    language: "not-emitted",
    display: "not-emitted",
    lines: "not-emitted",
    copy: "not-emitted"
  },
  "pdf-composition": {
    ...d,
    display: "partial",
    lines: "partial",
    copy: "partial",
    summary: "partial"
  },
  "docx-composition": {
    ...d,
    display: "partial",
    lines: "partial",
    copy: "partial",
    summary: "partial"
  }
}, B = (e) => typeof e == "object" && e !== null, fe = (e, t) => B(e[t]), K = (e, t) => typeof e[t] == "string", Oe = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? `
` : (e.content ?? []).map(Oe).join(""), Ft = (e) => {
  if (typeof e == "object" && e !== null && "toJSON" in e && typeof e.toJSON == "function")
    return e.toJSON();
  if (!B(e))
    return {};
  const t = B(e.type) ? typeof e.type.name == "string" ? e.type.name : void 0 : typeof e.type == "string" ? e.type : void 0, r = Array.isArray(e.content) ? e.content : typeof e.textContent == "string" ? [
    {
      type: "text",
      text: e.textContent
    }
  ] : void 0;
  return {
    ...t ? { type: t } : {},
    ...B(e.attrs) ? { attrs: e.attrs } : {},
    ...typeof e.text == "string" ? { text: e.text } : {},
    ...r ? { content: r } : {}
  };
}, O = (e, t, r, a) => ({
  code: e,
  severity: t,
  path: r,
  message: a
}), w = (e, t) => O(
  "codeBlock.delivery.contractRepairRequired",
  "error",
  e,
  t
), M = (e, t) => {
  t.forEach(
    (r) => m(e, r)
  );
}, nr = (e) => {
  const t = Ft(e);
  return Bt({
    code: Oe(t),
    attrs: B(t.attrs) ? t.attrs : {}
  });
}, Tt = (e) => {
  const t = [];
  return B(e) ? (K(e, "version") || t.push(
    w(
      "descriptor.version",
      "Code block descriptor version is required."
    )
  ), e.nodeType !== "codeBlock" && t.push(
    w(
      "descriptor.nodeType",
      'Code block descriptor nodeType must be "codeBlock".'
    )
  ), K(e, "code") || t.push(
    w(
      "descriptor.code",
      "Descriptor code text is required."
    )
  ), (!fe(e, "language") || !K(e, "displayLabel")) && t.push(
    w(
      "descriptor.language",
      "Descriptor language and displayLabel fields are required."
    )
  ), [
    "display",
    "lines",
    "copy",
    "summary",
    "capabilities"
  ].forEach((a) => {
    fe(e, a) || t.push(
      w(
        `descriptor.${a}`,
        `Descriptor field group "${a}" is required.`
      )
    );
  }), Array.isArray(e.diagnostics) || t.push(
    w(
      "descriptor.diagnostics",
      "Descriptor diagnostics array is required."
    )
  ), {
    ok: t.every((a) => a.severity !== "error"),
    diagnostics: t
  }) : (t.push(
    w(
      "descriptor",
      "Code block delivery descriptor must be an object."
    )
  ), {
    ok: !1,
    diagnostics: t
  });
}, Ot = (e, t) => Object.entries(t).flatMap(([r, a]) => a !== "partial" && a !== "unsupported" ? [] : [
  O(
    a === "partial" ? "codeBlock.delivery.fieldPartial" : "codeBlock.delivery.fieldUnsupported",
    a === "partial" ? "warning" : "error",
    `${e}.${r}`,
    `Code block descriptor field group "${r}" is ${a} on "${e}".`
  )
]), oe = (e) => {
  const t = e.lines.visualLineCount, r = Math.max(e.display.previewFrom, 1), a = Math.min(
    Math.max(e.display.previewTo, r),
    t
  ), o = e.display.collapsed || a < t, i = o ? r - 1 : 0, s = o ? a : t;
  return {
    lines: e.lines.visualLines.slice(i, s),
    lineNumbers: e.lines.lineNumbers.slice(i, s),
    previewed: o,
    previewFrom: o ? r : 1,
    previewTo: o ? a : t,
    totalLineCount: t
  };
}, he = (e) => {
  const t = Tt(e.descriptor), r = {
    ...Mt[e.surface]
  }, a = [];
  return M(a, e.descriptor.diagnostics), M(a, t.diagnostics), M(
    a,
    Ot(e.surface, r)
  ), {
    surface: e.surface,
    descriptorVersion: e.descriptor.version,
    descriptor: e.descriptor,
    fieldSupport: r,
    diagnostics: a,
    code: e.descriptor.code,
    language: e.descriptor.language,
    displayLabel: e.descriptor.displayLabel,
    display: e.descriptor.display,
    lines: e.descriptor.lines,
    visibleLines: oe(e.descriptor),
    copy: e.descriptor.copy,
    summary: e.descriptor.summary,
    capabilities: e.descriptor.capabilities
  };
}, lr = (e) => e.summary.text || e.code, dr = (e) => e.summary.previewText || e.summary.text || e.code, At = (e) => {
  const t = [];
  return oe(e).previewed && t.push(
    O(
      "codeBlock.binary.interactionPartial",
      "warning",
      "display.collapsed",
      "Binary formats cannot preserve interactive collapsed or preview state; full code text remains in the composition plan."
    )
  ), (e.display.showLineNumbers || e.display.wrap !== "inherit" || e.display.highlightLines.length > 0 || e.display.theme) && t.push(
    O(
      "codeBlock.binary.lineModelPartial",
      "warning",
      "lines",
      "Binary lowering preserves code block line intent, while final wrapping/highlight layout is adapter-owned."
    )
  ), e.copy.mode !== "plain" && t.push(
    O(
      "codeBlock.binary.copyModeUnsupported",
      "warning",
      "copy.mode",
      "Binary formats keep full code text but do not preserve editor copyMode interaction."
    )
  ), t;
}, cr = (e) => {
  const t = he({
    surface: "pdf-composition",
    descriptor: e
  }), r = he({
    surface: "docx-composition",
    descriptor: e
  }), a = [];
  return M(a, t.diagnostics), M(a, r.diagnostics), M(
    a,
    At(e)
  ), {
    kind: "code-block",
    descriptorVersion: e.version,
    code: e.code,
    language: {
      id: e.language.id,
      displayLabel: e.displayLabel,
      supported: e.language.supported
    },
    title: {
      filename: e.display.filename,
      caption: e.display.caption
    },
    display: {
      showLineNumbers: e.display.showLineNumbers,
      startLine: e.display.startLine,
      wrap: e.display.wrap,
      collapsed: e.display.collapsed,
      previewFrom: e.display.previewFrom,
      previewTo: e.display.previewTo,
      previewed: oe(e).previewed,
      heightMode: e.display.heightMode,
      height: e.display.height,
      highlightLines: e.display.highlightLines,
      theme: e.display.theme
    },
    lines: e.lines,
    copy: e.copy,
    capabilities: e.capabilities,
    diagnostics: a,
    fieldSupport: {
      pdf: t.fieldSupport,
      docx: r.fieldSupport
    }
  };
};
export {
  Q as $,
  cr as A,
  Rt as B,
  jt as C,
  Re as D,
  Vt as E,
  ye as F,
  Ve as G,
  Ht as H,
  y as I,
  Ut as J,
  A as K,
  g as L,
  ot as M,
  Wt as N,
  Yt as O,
  Qt as P,
  er as Q,
  nt as R,
  tr as S,
  $e as T,
  ne as U,
  Gt as V,
  W,
  Y as X,
  X as Y,
  ae as Z,
  D as _,
  rr as a,
  Ge as a0,
  Zt as a1,
  qt as a2,
  Kt as a3,
  xe as a4,
  qe as a5,
  k as a6,
  Xt as a7,
  Jt as a8,
  De as a9,
  It as aa,
  Nt as ab,
  Dt as ac,
  h as ad,
  be as ae,
  we as af,
  c as ag,
  P as ah,
  x as ai,
  ve as aj,
  $t as ak,
  _ as al,
  C as am,
  Ne as an,
  zt as ao,
  dt as b,
  lt as c,
  ar as d,
  ce as e,
  ct as f,
  pt as g,
  Fe as h,
  J as i,
  mt as j,
  kt as k,
  Et as l,
  _t as m,
  Lt as n,
  Bt as o,
  m as p,
  or as q,
  ir as r,
  sr as s,
  Mt as t,
  nr as u,
  Tt as v,
  oe as w,
  he as x,
  lr as y,
  dr as z
};
//# sourceMappingURL=delivery-surfaces-C8goSxeE.mjs.map
