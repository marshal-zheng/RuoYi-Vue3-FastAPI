import { Extension as ae, combineTransactionSteps as ho, getChangedRanges as yo, findChildrenInRange as ga, Node as Re, mergeAttributes as Te, Mark as Eo, textblockTypeInputRule as nc } from "@tiptap/core";
import { B as _o, a9 as Kt, Y as ac, M as Vt, L as Pa, N as rc, J as So, Q as ko, G as vo, a6 as En, a2 as Sr, P as oc, O as sc, $ as ic, a3 as cc, ab as To, aa as ma, Z as lc, n as Ge, p as Je, i as Fa, l as wo, o as dc, x as za, k as uc, e as pa, an as Dt, u as On, z as gc, y as mc, ac as kr } from "./delivery-surfaces-C8goSxeE.mjs";
import { S as mt, b as _n, a as No, G as ht, i as Ha, e as $a, H as Ua, J as pc, f as fc, E as bc } from "./envelope-CrN5-dS1.mjs";
import { Step as xo, StepResult as hc, StepMap as yc } from "@tiptap/pm/transform";
import { serializeChildrenToHTMLString as Co, serializeAttrsToHTMLString as Ec } from "@tiptap/static-renderer/pm/html-string";
import { Slice as _c, Fragment as Sc } from "@tiptap/pm/model";
import { Plugin as Ao, PluginKey as Mo, TextSelection as vr } from "@tiptap/pm/state";
import { h as kc, f as vc, I as Sn, C as Se, F as pt, O as Tc, P as wc, D as Xe, Q as Nc, g as xc, v as Cc } from "./actions-Sd62WBGv.mjs";
import "@tiptap/extension-text-style";
import Ac from "@tiptap/extension-link";
import { TaskList as Mc, TaskItem as Ic } from "@tiptap/extension-list";
import { TableRow as Oc, TableHeader as Lc, TableCell as Rc, Table as Dc } from "@tiptap/extension-table";
import { MarkdownManager as Tr } from "@tiptap/markdown";
import wr from "@tiptap/starter-kit";
import Bc from "@tiptap/extension-heading";
const Pc = (e, t = {}) => ({
  code: e.diagnosticCode,
  severity: e.defaultSeverity,
  message: t.message ?? e.message,
  target: t.target ?? t.blockId ?? e.nodeType,
  recoveryHint: t.recoveryHint ?? e.recoveryHint,
  blockId: t.blockId,
  pos: t.pos,
  nodeType: e.nodeType
}), Fc = "pages", Nr = (e) => {
  const t = e[Fc];
  return t && typeof t == "object" ? t : null;
}, ab = ae.create({
  name: "pagesBlockSafety",
  addOptions() {
    return {
      rules: []
    };
  },
  addStorage() {
    const e = _o(this.options.rules);
    return {
      registry: e.getSnapshot(),
      diagnostics: [],
      resolveRule: (t) => e.resolveRule(t)
    };
  },
  onCreate() {
    const e = Nr(
      this.editor.storage
    );
    e && (e.blockSafety = this.storage);
  },
  onDestroy() {
    const e = Nr(
      this.editor.storage
    );
    (e == null ? void 0 : e.blockSafety) === this.storage && (e.blockSafety = void 0);
  }
}), Io = "zxTextEditorPages", Ga = "zxTextEditorPagesContract", zc = /* @__PURE__ */ new Set([
  "setPageFormat",
  "setHeader",
  "setFooter",
  "setDifferentFirstPage",
  "setDifferentOddEven"
]), Ce = (e) => e === void 0 ? e : JSON.parse(JSON.stringify(e)), Ka = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Oo = (e) => typeof e == "string" && zc.has(e), Hc = (e) => {
  if (Ka(e))
    return {
      ...typeof e.kind == "string" ? { kind: e.kind } : {},
      ...typeof e.slot == "string" ? { slot: e.slot } : {},
      ...typeof e.mode == "string" ? { mode: e.mode } : {}
    };
};
class yt extends xo {
  constructor(t, n, a, r) {
    super(), this.previousPages = t, this.nextPages = n, this.reason = a, this.headerFooter = r;
  }
  apply(t) {
    return hc.ok(t);
  }
  getMap() {
    return yc.empty;
  }
  invert() {
    return new yt(
      Ce(this.nextPages),
      Ce(this.previousPages),
      this.reason,
      this.headerFooter ? Ce(this.headerFooter) : void 0
    );
  }
  map(t) {
    return this;
  }
  toJSON() {
    return {
      stepType: Ga,
      previousPages: Ce(this.previousPages),
      nextPages: Ce(this.nextPages),
      reason: this.reason,
      ...this.headerFooter ? { headerFooter: Ce(this.headerFooter) } : {}
    };
  }
  static fromJSON(t, n) {
    const a = Ka(n) ? n : {}, r = Oo(a.reason) ? a.reason : "setPageFormat";
    return new yt(
      Ce(
        a.previousPages
      ),
      Ce(a.nextPages),
      r,
      Hc(a.headerFooter)
    );
  }
  getTransactionMeta() {
    return {
      pages: Ce(this.nextPages),
      reason: this.reason,
      ...this.headerFooter ? { headerFooter: Ce(this.headerFooter) } : {}
    };
  }
}
try {
  xo.jsonID(Ga, yt);
} catch {
}
const $c = (e) => {
  if (e instanceof yt)
    return e.getTransactionMeta();
  const t = e && typeof e.toJSON == "function" ? e.toJSON() : null;
  return !Ka(t) || t.stepType !== Ga ? null : yt.fromJSON({}, t).getTransactionMeta();
}, fa = (e, t) => {
  const n = {
    pages: t.pages,
    reason: t.reason,
    ...t.headerFooter ? { headerFooter: t.headerFooter } : {}
  };
  return e.step(
    new yt(
      Ce(t.previousPages),
      Ce(t.pages),
      t.reason,
      t.headerFooter ? Ce(t.headerFooter) : void 0
    )
  ).setMeta(Io, n).setMeta("preventUpdate", !0);
}, Va = (e) => {
  var a;
  const t = (a = e.getMeta) == null ? void 0 : a.call(e, Io);
  if (t && typeof t == "object" && "pages" in t && "reason" in t && Oo(t.reason))
    return t;
  const n = e.steps;
  if (n != null && n.length)
    for (let r = n.length - 1; r >= 0; r -= 1) {
      const o = $c(n[r]);
      if (o)
        return o;
    }
  return null;
}, ft = (e) => typeof HTMLElement < "u" && e instanceof HTMLElement, Uc = () => typeof window > "u" || typeof document > "u" ? null : {
  scrollTop: window.scrollY,
  scrollLeft: window.scrollX,
  viewportHeight: window.innerHeight,
  viewportWidth: window.innerWidth
}, Gc = (e) => ({
  scrollTop: e.scrollTop,
  scrollLeft: e.scrollLeft,
  viewportHeight: e.clientHeight,
  viewportWidth: e.clientWidth
}), Kc = (e) => ({
  getContentRoot() {
    return ft(e.view.dom) ? e.view.dom : null;
  },
  getScrollContainer() {
    const t = ft(e.view.dom) ? e.view.dom : null;
    return (t == null ? void 0 : t.parentElement) ?? (typeof window < "u" ? window : null);
  },
  getOverlayHost() {
    return null;
  },
  getViewportSnapshot() {
    const t = this.getScrollContainer();
    return ft(t) ? Gc(t) : t ? Uc() : null;
  },
  resolveBlockElement(t) {
    const n = e.view.nodeDOM(t.pos);
    return ft(n) ? n : t.dom;
  }
}), xr = (e) => {
  const t = Number.parseFloat(e);
  return Number.isFinite(t) ? t : 0;
}, Vc = (e, t) => {
  const n = e.offsetWidth, a = e.offsetHeight, r = n > 0 && Number.isFinite(t.width) && t.width > 0 ? t.width / n : 1, o = a > 0 && Number.isFinite(t.height) && t.height > 0 ? t.height / a : 1;
  return {
    x: Number.isFinite(r) && r > 0 ? r : 1,
    y: Number.isFinite(o) && o > 0 ? o : 1
  };
}, Wc = ({
  blocks: e,
  contentRoot: t
}) => {
  const n = t.getBoundingClientRect(), a = Vc(t, n), r = [];
  return {
    blocks: e.map((s) => {
      const i = s.dom;
      if (!i)
        return s.safety.split === "manual-boundary" ? {
          blockId: s.blockId,
          nodeType: s.nodeType,
          pos: s.pos,
          nodeSize: s.nodeSize,
          top: 0,
          bottom: 0,
          height: 0,
          status: "measured",
          safety: s.safety,
          manualBoundary: {
            nodeId: s.blockId,
            pos: s.pos
          },
          asyncSized: s.asyncSized,
          tableMetadata: s.tableMetadata
        } : (r.push({
          code: "pages.layout.dom-missing",
          severity: "warning",
          message: `Pages layout block "${s.blockId}" does not have a DOM element.`,
          target: s.blockId
        }), {
          blockId: s.blockId,
          nodeType: s.nodeType,
          pos: s.pos,
          nodeSize: s.nodeSize,
          top: 0,
          bottom: 0,
          height: 0,
          status: "unknown",
          safety: s.safety,
          asyncSized: s.asyncSized,
          tableMetadata: s.tableMetadata
        });
      const c = typeof window < "u" && typeof window.getComputedStyle == "function" ? window.getComputedStyle(i) : null;
      if ((c == null ? void 0 : c.display) === "none")
        return r.push({
          code: "pages.layout.measurement-failed",
          severity: "warning",
          message: `Pages layout block "${s.blockId}" is display:none.`,
          target: s.blockId
        }), {
          blockId: s.blockId,
          nodeType: s.nodeType,
          pos: s.pos,
          nodeSize: s.nodeSize,
          top: 0,
          bottom: 0,
          height: 0,
          status: "unknown",
          safety: s.safety,
          asyncSized: s.asyncSized,
          tableMetadata: s.tableMetadata
        };
      const l = i.getBoundingClientRect(), d = c ? xr(c.marginTop) : 0, u = c ? xr(c.marginBottom) : 0, m = (l.top - n.top) / a.y - d, g = l.height / a.y + d + u, f = Number.isFinite(g) && g > 0 ? g : 0, b = f > 0 ? "measured" : "unknown";
      return b === "unknown" && r.push({
        code: "pages.layout.measurement-failed",
        severity: "warning",
        message: `Pages layout block "${s.blockId}" has no stable measurable height.`,
        target: s.blockId
      }), {
        blockId: s.blockId,
        nodeType: s.nodeType,
        pos: s.pos,
        nodeSize: s.nodeSize,
        top: m,
        bottom: m + f,
        height: f,
        status: b,
        safety: s.safety,
        asyncSized: s.asyncSized,
        tableMetadata: s.tableMetadata,
        unsupportedReason: s.unsupportedReason
      };
    }),
    diagnostics: r
  };
}, ba = (e) => ({
  status: {
    ...e.status,
    diagnostics: [...e.status.diagnostics]
  },
  metrics: e.metrics ? {
    ...e.metrics,
    margins: { ...e.metrics.margins }
  } : null,
  measuredBlocks: e.measuredBlocks.map((t) => ({ ...t })),
  dirtyRange: e.dirtyRange ? { ...e.dirtyRange } : null,
  scheduler: {
    ...e.scheduler,
    pendingReasons: [...e.scheduler.pendingReasons]
  },
  diagnostics: e.diagnostics.map((t) => ({ ...t })),
  pageMap: e.pageMap.map((t) => ({
    ...t,
    boundary: { ...t.boundary },
    manualBoundary: t.manualBoundary ? { ...t.manualBoundary } : null,
    blockSafety: t.blockSafety ? {
      ...t.blockSafety,
      nodeTypes: t.blockSafety.nodeTypes ? [...t.blockSafety.nodeTypes] : void 0,
      table: t.blockSafety.table ? { ...t.blockSafety.table } : void 0
    } : void 0
  }))
}), an = (e) => Number.isFinite(e) && e > 0, Zn = (e, t) => ({
  code: "pages.layout.page-settings-invalid",
  severity: "error",
  message: e,
  target: t
}), Cr = (e) => {
  const { pageSettings: t } = e, n = t.pageFormat.width, a = t.pageFormat.height, r = t.orientation === "landscape" ? Math.max(n, a) : Math.min(n, a), o = t.orientation === "landscape" ? Math.min(n, a) : Math.max(n, a), s = { ...t.margins }, i = r - s.left - s.right, c = o - s.top - s.bottom, l = [];
  return (!an(r) || !an(o)) && l.push(
    Zn(
      "Pages layout page size must be finite and positive.",
      "pageFormat"
    )
  ), Object.entries(s).forEach(([d, u]) => {
    (!Number.isFinite(u) || u < 0) && l.push(
      Zn(
        `Pages layout margin "${d}" must be finite and non-negative.`,
        `margins.${d}`
      )
    );
  }), (!an(i) || !an(c)) && l.push(
    Zn(
      "Pages layout content box must have positive width and height.",
      "contentBox"
    )
  ), l.length ? {
    metrics: null,
    diagnostics: l
  } : {
    metrics: {
      pageWidth: r,
      pageHeight: o,
      contentWidth: i,
      contentHeight: c,
      margins: s,
      zoom: e.zoom,
      pageGap: e.pageGap,
      pageGapBackground: e.pageGapBackground
    },
    diagnostics: l
  };
}, Ar = (e) => {
  const { metrics: t } = e, n = t.pageHeight * t.zoom + t.pageGap;
  return {
    available: e.overlayHostAvailable,
    unavailableReason: e.overlayHostAvailable ? void 0 : "overlay-host-missing",
    pages: e.pageMap.map((a) => {
      const r = a.pageIndex * n, o = t.pageWidth * t.zoom, s = t.pageHeight * t.zoom;
      return {
        pageIndex: a.pageIndex,
        pageBox: {
          x: 0,
          y: r,
          width: o,
          height: s
        },
        contentBox: {
          x: t.margins.left * t.zoom,
          y: r + t.margins.top * t.zoom,
          width: t.contentWidth * t.zoom,
          height: t.contentHeight * t.zoom
        },
        gapRegion: t.pageGap > 0 ? {
          y: r + s,
          height: t.pageGap
        } : null,
        boundaryY: a.boundary.contentBottomY * t.zoom,
        statusToken: a.boundary.statusToken
      };
    }),
    boundaries: e.pageMap.map((a) => a.boundary),
    gapBackground: t.pageGapBackground,
    revision: e.revision
  };
}, Wt = (e) => {
  const t = Math.round((e + Number.EPSILON) * 1e3) / 1e3;
  return Object.is(t, -0) ? 0 : t;
}, qc = (e, t, n, a, r, o = {}) => ({
  pageIndex: e,
  type: o.type ?? "derived",
  y: Wt(e * t),
  contentBottomY: Wt((e + 1) * t),
  previousBlockId: n,
  nextBlockId: a,
  source: o.source ?? "automatic",
  statusToken: r,
  reason: o.reason
}), Yc = (e, t, n) => {
  var o;
  const a = e.flatMap(
    (s) => s.safety ? [s.safety] : []
  ), r = (o = e.find((s) => s.tableMetadata)) == null ? void 0 : o.tableMetadata;
  return {
    nonSplittable: t || a.some((s) => s.nonSplittable),
    unsupported: n || a.some((s) => s.risk === "unsupported"),
    asyncSized: a.some((s) => s.asyncSized),
    risk: a.some((s) => s.risk === "unsupported") ? "unsupported" : a.some((s) => s.risk === "partial") ? "partial" : "safe",
    nodeTypes: Array.from(new Set(e.map((s) => s.nodeType))),
    table: r
  };
}, Xc = (e, t, n, a, r, o, s = {}) => {
  const i = t[0] ?? null, c = t[t.length - 1] ?? null;
  return {
    pageIndex: e,
    startBlockId: (i == null ? void 0 : i.blockId) ?? null,
    endBlockId: (c == null ? void 0 : c.blockId) ?? null,
    startPos: (i == null ? void 0 : i.pos) ?? null,
    endPos: c ? c.pos + c.nodeSize : null,
    contentHeightUsed: Wt(n),
    overflow: r,
    partial: o,
    boundary: qc(
      e,
      a,
      (c == null ? void 0 : c.blockId) ?? null,
      null,
      r ? "overflow" : o ? "partial" : "ready",
      {
        type: s.boundaryType,
        source: s.boundarySource,
        reason: s.boundaryReason
      }
    ),
    manualBoundary: s.manualBoundary ?? null,
    sectionId: null,
    headerFooterAnchor: {
      pageIndex: e,
      totalPages: null
    },
    blockSafety: Yc(t, r, o)
  };
}, Zc = (e, t) => {
  const n = t.metrics.contentHeight, a = [], r = [];
  let o = [], s = 0, i = !1, c = !1, l = !1, d = !1;
  const u = (g = {}) => {
    r.push(
      Xc(
        r.length,
        o,
        s,
        n,
        c,
        i,
        g
      )
    ), o = [], s = 0, i = !1, c = !1;
  };
  e.forEach((g) => {
    var y, x, C, O, P, G, K;
    if (((y = g.safety) == null ? void 0 : y.split) === "manual-boundary" || !!g.manualBoundary) {
      const oe = g.manualBoundary ?? {
        nodeId: g.blockId,
        pos: g.pos
      };
      u({
        boundaryType: "forced",
        boundarySource: "manual-page-break",
        boundaryReason: "pageBreak",
        manualBoundary: oe
      }), d = !0;
      return;
    }
    d = !1;
    const b = Wt(g.height), E = Number.isFinite(b) && b > 0, _ = g.status === "unknown" || g.status === "unsupported", k = _ && !E, S = E && (g.status === "oversize" || b > n);
    if (_) {
      l = !0, i = !0;
      const oe = g.asyncSized || (x = g.safety) != null && x.asyncSized ? "pages.blockSafety.async-sized" : ((C = g.safety) == null ? void 0 : C.diagnosticCode) ?? (g.status === "unsupported" ? "pages.layout.block-unsupported" : "pages.layout.measurement-failed"), L = ((O = g.safety) == null ? void 0 : O.recoveryHint) ?? (g.status === "unsupported" ? "Keep this top-level block as a partial page map until a block-specific splitting strategy is implemented." : "Wait for the block DOM to become measurable or provide a measurement adapter result.");
      a.push({
        code: oe,
        severity: ((P = g.safety) == null ? void 0 : P.defaultSeverity) ?? "warning",
        message: ((G = g.safety) == null ? void 0 : G.message) ?? (k ? `Pages layout could not produce a complete measurement for block "${g.blockId}".` : `Pages layout measured block "${g.blockId}" but only has partial support for its page-splitting semantics.`),
        target: g.blockId,
        blockId: g.blockId,
        pos: g.pos,
        nodeType: g.nodeType,
        recoveryHint: L
      });
    }
    S && (l = !0, c = !0, a.push({
      code: "pages.layout.block-oversize",
      severity: "warning",
      message: `Pages layout block "${g.blockId}" is taller than one page content box.`,
      target: g.blockId,
      blockId: g.blockId,
      pos: g.pos,
      nodeType: g.nodeType,
      recoveryHint: ((K = g.safety) == null ? void 0 : K.recoveryHint) ?? "Treat this block as non-splittable for now and surface partial/overflow UI guidance."
    })), o.length > 0 && E && s + b > n && u(), o.push({
      ...g,
      height: b,
      status: S ? "oversize" : g.status
    }), s = Wt(
      s + (E ? b : 0)
    );
  }), (o.length || r.length === 0 || d) && u();
  const m = r.map((g, f) => {
    const b = r[f + 1];
    return {
      ...g,
      boundary: {
        ...g.boundary,
        nextBlockId: (b == null ? void 0 : b.startBlockId) ?? null
      },
      headerFooterAnchor: {
        pageIndex: g.pageIndex,
        totalPages: r.length
      }
    };
  });
  return {
    pageMap: m,
    pageBoundaries: m.map((g) => g.boundary),
    diagnostics: a,
    partial: l
  };
}, Jc = (e) => e.map(
  (t) => `${t.pageIndex}:${t.startBlockId ?? "-"}:${t.endBlockId ?? "-"}:${t.contentHeightUsed}:${t.overflow}:${t.partial}:${t.boundary.source}:${t.boundary.type}`
).join("|"), Lo = () => globalThis.setTimeout.bind(globalThis), Ro = () => globalThis.clearTimeout.bind(globalThis), jc = () => {
  const e = globalThis.requestAnimationFrame;
  if (typeof e == "function")
    return e.bind(globalThis);
  const t = Lo();
  return (n) => t(n, 16);
}, Qc = () => {
  const e = globalThis.cancelAnimationFrame;
  return typeof e == "function" ? e.bind(globalThis) : Ro();
}, el = (e) => {
  const t = e.setTimeout ?? Lo(), n = e.clearTimeout ?? Ro(), a = e.requestAnimationFrame ?? jc(), r = e.cancelAnimationFrame ?? Qc(), o = e.debounceMs ?? 24;
  let s = 0, i = 0, c = 0, l = !1, d = !1, u = null, m = null, g = null;
  const f = /* @__PURE__ */ new Set(), b = () => {
    u !== null && (n(u), u = null), m !== null && (r(m), m = null);
  }, E = () => {
    m = null, l = !1, d = !0;
    const k = {
      revision: s,
      reasons: [...f],
      dirtyRange: g
    };
    f.clear(), g = null, Promise.resolve(e.measure(k)).finally(() => {
      var S;
      d = !1, k.revision !== s && (c += 1, (S = e.onDiscardedMeasurement) == null || S.call(e, k));
    });
  }, _ = () => {
    b(), l = !0, u = t(() => {
      u = null, m = a(E);
    }, o);
  };
  return {
    invalidate(k, S = null) {
      var y;
      return k === "scroll" || k === "selection" ? ((y = e.updateCurrentPage) == null || y.call(e, k), s) : (s += 1, f.add(k), g = S ?? g, _(), s);
    },
    updateCurrentPage(k) {
      var S;
      (S = e.updateCurrentPage) == null || S.call(e, k);
    },
    applyMeasurement(k) {
      return k !== s ? (c += 1, !1) : (i = k, !0);
    },
    cancel() {
      b(), l = !1, f.clear(), g = null;
    },
    destroy() {
      b(), l = !1, d = !1, f.clear(), g = null;
    },
    getSnapshot() {
      return {
        revision: s,
        scheduled: l,
        measuring: d,
        pendingReasons: [...f],
        latestAppliedRevision: i,
        discardedMeasurements: c,
        loopGuardTrips: 0
      };
    }
  };
}, tl = (e = 3) => {
  let t = -1, n = "", a = 0, r = 0;
  return {
    record(o, s) {
      return o !== t ? (t = o, n = s, a = 0, null) : s === n || (n = s, a += 1, a < e) ? null : (r += 1, {
        code: "pages.layout.loop-guard",
        severity: "error",
        message: "Pages layout boundaries changed repeatedly within the same revision.",
        target: `revision:${o}`
      });
    },
    reset() {
      t = -1, n = "", a = 0;
    },
    getSnapshot() {
      return { trips: r };
    }
  };
}, Wa = 50, ha = () => ({
  engine: "unavailable",
  pageCount: null,
  reason: "layout-engine-not-installed",
  revision: 0,
  lastMeasurementReason: null,
  measuredAt: null,
  diagnostics: []
}), at = (e) => ({
  pageCount: e.pageCount ?? null,
  reason: e.reason ?? "layout-engine-disabled",
  revision: e.revision ?? 0,
  lastMeasurementReason: e.lastMeasurementReason ?? null,
  measuredAt: e.measuredAt ?? null,
  diagnostics: e.diagnostics ?? [],
  engine: e.engine
}), rn = (e, t, n = Wa) => [...e, ...t].slice(-n), Mr = (e) => e.getAttribute(_n) || e.getAttribute(`data-${mt}`) || null, nl = ae.create({
  name: "stableBlockDomAttributes",
  addOptions() {
    return {
      types: [...No]
    };
  },
  addGlobalAttributes() {
    const e = this.options.types.filter((n) => n === "heading");
    return [
      {
        types: this.options.types.filter((n) => n !== "heading"),
        attributes: {
          [mt]: {
            default: null,
            parseHTML: (n) => Mr(n),
            renderHTML: (n) => {
              const a = n[mt];
              return typeof a != "string" || !a ? {} : {
                [_n]: a
              };
            }
          }
        }
      },
      {
        types: e,
        attributes: {
          [mt]: {
            default: null,
            parseHTML: (n) => Mr(n) || n.getAttribute("id"),
            renderHTML: (n) => {
              const a = n[mt];
              return typeof a != "string" || !a ? {} : {
                id: a,
                [_n]: a
              };
            }
          }
        }
      }
    ];
  }
}), ya = "stableBlockIdentityRepair", Do = (e, t) => {
  const n = [];
  return e.descendants((a, r) => (t.includes(a.type.name) && n.push({ node: a, pos: r }), !0)), n;
}, Ir = (e, t) => Do(e, t).map(({ node: n, pos: a }) => ({
  node: n,
  pos: a,
  blockId: ht(n.attrs)
})), al = (e, t, n) => {
  var c, l;
  const a = Ir(e, n), r = Ir(t, n), o = /* @__PURE__ */ new Map();
  let s = 0, i = 0;
  for (; s < a.length && i < r.length; ) {
    const d = a[s], u = r[i], m = d.blockId, g = u.blockId;
    if (!m || !Ha(m)) {
      s += 1, i += 1;
      continue;
    }
    if (d.node.type.name !== u.node.type.name) {
      const f = r[i + 1], b = a[s + 1];
      if ((f == null ? void 0 : f.node.type.name) === d.node.type.name) {
        i += 1;
        continue;
      }
      if ((b == null ? void 0 : b.node.type.name) === u.node.type.name) {
        s += 1;
        continue;
      }
    }
    if (g === m) {
      s += 1, i += 1;
      continue;
    }
    if (((c = r[i + 1]) == null ? void 0 : c.blockId) === m) {
      i += 1;
      continue;
    }
    if (g && ((l = a[s + 1]) == null ? void 0 : l.blockId) === g) {
      s += 1;
      continue;
    }
    o.set(u.pos, m), s += 1, i += 1;
  }
  return o;
}, rl = (e, t, n, a = {}) => {
  const r = e, o = /* @__PURE__ */ new Set(), s = a.remoteTransaction && a.previousDoc ? al(
    a.previousDoc,
    t,
    n.types
  ) : /* @__PURE__ */ new Map(), i = {
    origin: a.remoteTransaction ? "remote" : "local",
    regeneratedBlockIds: 0,
    restoredBlockIds: 0
  };
  let c = !1;
  return Do(t, n.types).forEach(({ node: l, pos: d }) => {
    const u = ht(
      l.attrs
    ), m = !!(u && o.has(u)), g = !!(u && !Ha(u)), f = s.get(d), b = !!(f && f !== u && !o.has(f));
    let E = u;
    if (b && f ? E = f : (!u || m || g) && (E = $a(
      {
        nodeType: l.type.name,
        nodeAttrs: l.attrs ?? {}
      },
      o,
      n.generateId
    )), !E)
      return;
    const _ = Ua(
      l.type.name,
      l.attrs,
      E
    );
    if (!u || m || g || _.headingIdentityChanged || b) {
      r.setNodeMarkup(
        d,
        void 0,
        _.attrs
      ), b ? i.restoredBlockIds += 1 : (!u || m || g) && (i.regeneratedBlockIds += 1), o.add(E), c = !0;
      return;
    }
    o.add(E);
  }), c ? (r.setMeta("addToHistory", !1), r.setMeta(ya, i), r) : null;
}, yn = (e, t) => {
  e.set(t, (e.get(t) ?? 0) + 1);
}, ol = (e, t) => {
  const n = (e.get(t) ?? 0) - 1;
  if (n <= 0) {
    e.delete(t);
    return;
  }
  e.set(t, n);
}, kn = (e, t) => t.includes(e.type.name), Jn = (e, t) => {
  const n = /* @__PURE__ */ new Map(), a = new Set(t), r = new Set(kc()), o = vc(e.toJSON());
  o.index.forEach((i) => {
    a.has(i.nodeType) && yn(n, i.blockId);
  }), o.issues.forEach((i) => {
    i.blockId && a.has(i.nodeType) && yn(n, i.blockId);
  });
  const s = new Set(t.filter((i) => !r.has(i)));
  return s.size > 0 && e.descendants((i) => {
    if (!s.has(i.type.name)) return !0;
    const c = ht(
      i.attrs
    );
    return c && yn(n, c), !0;
  }), n;
}, sl = (e, t, n, a, r) => {
  if (!t.docChanged)
    return e;
  const o = new Map(e), s = ho(n.doc, [t]), i = yo(s), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map();
  return i.forEach(({ oldRange: d, newRange: u }) => {
    ga(
      n.doc,
      d,
      (m) => kn(m, r)
    ).forEach(({ node: m, pos: g }) => {
      c.set(g, m);
    }), ga(
      a.doc,
      u,
      (m) => kn(m, r)
    ).forEach(({ node: m, pos: g }) => {
      l.set(g, m);
    });
  }), c.forEach((d) => {
    const u = ht(
      d.attrs
    );
    u && ol(o, u);
  }), l.forEach((d) => {
    const u = ht(
      d.attrs
    );
    u && yn(o, u);
  }), o;
}, il = (e, t, n, a) => {
  const r = ho(
    n.doc,
    t
  ), o = yo(r), s = /* @__PURE__ */ new Map();
  return o.forEach(({ newRange: i }) => {
    ga(
      e,
      i,
      (c) => kn(c, a)
    ).forEach(({ node: c, pos: l }) => {
      s.set(l, c);
    });
  }), {
    changedNodes: Array.from(s.entries()).sort(([i], [c]) => i - c).map(([i, c]) => ({ pos: i, node: c })),
    transform: r
  };
}, cl = (e, t, n, a, r) => {
  const o = e.mapping.invert().mapResult(a);
  if (o.deleted)
    return !1;
  const s = t.doc.nodeAt(o.pos);
  return (s == null ? void 0 : s.type.name) === n.type.name && ht(s.attrs) === r;
}, Bo = (e, t, n, a) => {
  const r = [];
  return e.forEach((o) => {
    if (o.isText) {
      r.push(o);
      return;
    }
    const s = Bo(
      o.content,
      t,
      n,
      a
    );
    if (!t.includes(o.type.name)) {
      r.push(o.copy(s));
      return;
    }
    const i = $a(
      {
        nodeType: o.type.name,
        nodeAttrs: o.attrs ?? {}
      },
      n,
      a
    );
    n.add(i), r.push(
      o.type.create(
        Ua(
          o.type.name,
          o.attrs,
          i
        ).attrs,
        s,
        o.marks
      )
    );
  }), Sc.from(r);
}, Or = new Mo(
  "stableBlockIdentityEngine"
), ll = ae.create({
  name: "stableBlockIdentityEngine",
  priority: 1e4,
  addOptions() {
    return {
      types: [...No],
      generateId: void 0,
      filterRemoteTransactions: !0
    };
  },
  addStorage() {
    return {
      lastRepair: null
    };
  },
  onCreate() {
    var i;
    const e = this.editor.extensionManager.extensions.find(
      (c) => c.name === "collaboration"
    ), t = this.editor.extensionManager.extensions.find(
      (c) => c.name === "collaborationCaret"
    ), a = (i = [e, t].filter(
      Boolean
    ).find(
      (c) => {
        var l;
        return (l = c == null ? void 0 : c.options) == null ? void 0 : l.provider;
      }
    )) == null ? void 0 : i.options, r = a == null ? void 0 : a.provider, o = (c) => {
      var d, u;
      const l = rl(
        this.editor.state.tr,
        this.editor.state.doc,
        this.options,
        {
          remoteTransaction: c === "remote"
        }
      );
      if (!(l != null && l.docChanged)) {
        c === "remote" && ((d = r == null ? void 0 : r.off) == null || d.call(r, "synced", s));
        return;
      }
      this.storage.lastRepair = l.getMeta(ya) ?? null, this.editor.view.dispatch(l), c === "remote" && ((u = r == null ? void 0 : r.off) == null || u.call(r, "synced", s));
    }, s = () => o("remote");
    if (r != null && r.on) {
      r.on("synced", s);
      return;
    }
    o("local");
  },
  addProseMirrorPlugins() {
    const e = this;
    let t = null, n = !1;
    return [
      new Ao({
        key: Or,
        state: {
          init: (a, r) => ({
            idCountByValue: Jn(
              r.doc,
              e.options.types
            )
          }),
          apply(a, r, o, s) {
            return {
              idCountByValue: sl(
                r.idCountByValue,
                a,
                o,
                s,
                e.options.types
              )
            };
          }
        },
        appendTransaction(a, r, o) {
          var E;
          if (!(a.some((_) => _.docChanged) && !r.doc.eq(o.doc)))
            return null;
          const i = a.some(
            (_) => pc(_)
          );
          if (e.options.filterRemoteTransactions && i)
            return null;
          const { changedNodes: c, transform: l } = il(
            o.doc,
            a,
            r,
            e.options.types
          );
          if (!c.length)
            return null;
          const d = ((E = Or.getState(o)) == null ? void 0 : E.idCountByValue) ?? Jn(o.doc, e.options.types), u = new Set(d.keys()), m = o.tr;
          let g = 0, f = !1;
          if (c.forEach(({ pos: _ }) => {
            const k = m.doc.nodeAt(_);
            if (!k || !kn(k, e.options.types))
              return;
            const S = ht(
              k.attrs
            ), y = !!(S && !Ha(S)), x = !!(S && (d.get(S) ?? 0) > 1), C = !S || y || x && !cl(l, r, k, _, S), O = C ? $a(
              {
                nodeType: k.type.name,
                nodeAttrs: k.attrs ?? {}
              },
              u,
              e.options.generateId
            ) : S;
            if (!O)
              return;
            const P = Ua(
              k.type.name,
              k.attrs,
              O
            );
            if (!C && !P.changed) {
              u.add(O);
              return;
            }
            m.setNodeMarkup(
              _,
              void 0,
              P.attrs
            ), u.add(O), C && (g += 1), f = !0;
          }), !f)
            return null;
          const b = {
            origin: i ? "remote" : "local",
            regeneratedBlockIds: g,
            restoredBlockIds: 0
          };
          return m.setMeta("addToHistory", !1), m.setMeta(ya, b), m.setStoredMarks(o.tr.storedMarks), e.storage.lastRepair = b, m;
        },
        view(a) {
          const r = (o) => {
            var s;
            t = (s = a.dom.parentElement) != null && s.contains(
              o.target
            ) ? a.dom.parentElement : null;
          };
          return window.addEventListener("dragstart", r), {
            destroy() {
              window.removeEventListener("dragstart", r);
            }
          };
        },
        props: {
          handleDOMEvents: {
            drop(a, r) {
              var s;
              const o = (s = r.dataTransfer) == null ? void 0 : s.effectAllowed;
              return (t !== a.dom.parentElement || o === "copyMove" || o === "copy") && (t = null, n = !0), !1;
            },
            paste() {
              return n = !0, !1;
            }
          },
          transformPasted(a) {
            return n ? (n = !1, new _c(
              Bo(
                a.content,
                e.options.types,
                new Set(
                  Jn(
                    e.editor.state.doc,
                    e.options.types
                  ).keys()
                ),
                e.options.generateId
              ),
              a.openStart,
              a.openEnd
            )) : a;
          }
        }
      })
    ];
  }
}), rb = ae.create({
  name: "stableBlockIdentity",
  addOptions() {
    return {
      types: [],
      generateId: void 0,
      filterRemoteTransactions: !0
    };
  },
  addExtensions() {
    const e = fc(this.options.types);
    return [
      nl.configure({
        types: e
      }),
      ll.configure({
        types: e,
        generateId: this.options.generateId,
        filterRemoteTransactions: this.options.filterRemoteTransactions ?? !0
      })
    ];
  }
}), dl = _o(), ul = (e) => {
  const n = e.attrs[mt];
  return typeof n == "string" && n ? n : null;
}, gl = (e, t) => {
  const n = e.view.nodeDOM(t);
  return ft(n) ? n : null;
}, ml = (e, t = {}) => {
  const n = [], a = [];
  let r = !1;
  return e.state.doc.forEach((o, s, i) => {
    var b, E, _;
    const c = ul(o), l = o.type.name, d = ((b = t.resolveBlockSafetyRule) == null ? void 0 : b.call(t, l)) ?? ((_ = (E = e.storage.pages) == null ? void 0 : E.blockSafety) != null && _.resolveRule ? e.storage.pages.blockSafety.resolveRule(l) : dl.resolveRule(l)), u = s, m = {
      blockId: c ?? `missing-block-id:${i}`,
      nodeType: l,
      pos: u,
      nodeSize: o.nodeSize,
      index: i,
      safety: d,
      asyncSized: d.asyncSized,
      tableMetadata: d.table,
      unsupportedReason: d.risk === "safe" ? void 0 : `top-level-${l}`
    }, g = t.resolveBlockElement ? t.resolveBlockElement(m) : gl(e, u), f = {
      ...m,
      dom: g
    };
    c || (r = !0, a.push({
      code: "pages.layout.block-identity-missing",
      severity: "warning",
      message: `Pages layout top-level block at index ${i} is missing a stable block id.`,
      target: `index:${i}`
    })), !g && l !== Kt && (r = !0, a.push({
      code: "pages.layout.dom-missing",
      severity: "warning",
      message: `Pages layout top-level block "${m.blockId}" does not have a DOM element.`,
      target: m.blockId
    })), (m.unsupportedReason || d.diagnosticCode === "pages.blockSafety.unknown") && (r = !0, a.push(
      Pc(d, {
        blockId: m.blockId,
        pos: u,
        target: m.blockId
      })
    )), n.push(f);
  }), {
    blocks: n,
    diagnostics: a,
    partial: r
  };
}, pl = "pages", jn = "img,video,iframe", fl = ["class", "style"], Lr = "ProseMirror-selectednode", bl = () => typeof window < "u" && typeof document < "u", Rr = (e) => ({ ...e }), We = (e) => {
  const n = e.storage[pl];
  return n && typeof n == "object" ? n : null;
}, hl = (e, t) => {
  if (!e.docChanged)
    return null;
  let n = Number.POSITIVE_INFINITY, a = 0;
  return e.steps.forEach((r) => {
    r.getMap().forEach((o, s, i, c) => {
      n = Math.min(n, i), a = Math.max(a, c);
    });
  }), Number.isFinite(n) ? {
    from: n,
    to: a,
    fromBlockIndex: null,
    toBlockIndex: null,
    reason: t
  } : null;
}, Dr = (e) => new Set((e ?? "").split(/\s+/).filter(Boolean)), yl = (e, t) => {
  const n = Dr(e), a = Dr(t);
  return n.delete(Lr), a.delete(Lr), n.size !== a.size ? !0 : [...n].some((r) => !a.has(r));
}, El = (e) => e.attributeName === "style" ? !0 : e.attributeName !== "class" || !(e.target instanceof Element) ? !1 : yl(
  e.oldValue,
  e.target.getAttribute("class")
);
class _l {
  constructor(t, n) {
    this.loopGuard = tl(), this.cleanupCallbacks = [], this.destroyed = !1, this.state = {
      revision: 0,
      metrics: null,
      measuredBlocks: [],
      pageMap: [],
      diagnostics: [],
      dirtyRange: null,
      currentPage: null,
      latestBoundarySignature: ""
    }, this.editor = t, this.options = {
      diagnosticsLimit: n.diagnosticsLimit ?? Wa,
      maxSynchronousBlocks: n.maxSynchronousBlocks ?? 1e3,
      ...n
    }, this.adapter = n.adapter ?? Kc(t), this.measurement = n.measurement ?? Wc, this.scheduler = n.scheduler ?? el({
      measure: (a) => this.measure(a),
      updateCurrentPage: (a) => this.updateCurrentPage(a)
    });
  }
  install() {
    const t = We(this.editor);
    if (t) {
      if (t.requestLayoutUpdate = (n) => this.invalidate(n), t.getCurrentPage = () => this.state.currentPage, t.getPagesDebugSnapshot = () => this.createDebugSnapshot(), this.setStatus({
        engine: "idle",
        reason: "scheduled",
        revision: this.state.revision
      }), !bl()) {
        this.pushDiagnostics([
          {
            code: "pages.layout.dom-missing",
            severity: "warning",
            message: "Pages layout engine is disabled because browser DOM APIs are unavailable.",
            recoveryHint: "Enable pagesLayout only in an editor browser runtime."
          }
        ]), this.setStatus({
          engine: "disabled",
          reason: "layout-engine-disabled",
          revision: this.state.revision
        });
        return;
      }
      this.attachDomListeners(), this.invalidate("initial");
    }
  }
  invalidate(t, n = null) {
    if (!this.destroyed) {
      if (t === "view-state") {
        this.updateVisualState(t);
        return;
      }
      if (t === "scroll" || t === "selection") {
        this.scheduler.invalidate(t, n);
        return;
      }
      this.state = {
        ...this.state,
        dirtyRange: n
      }, this.setStatus({
        engine: "stale",
        reason: "layout-stale",
        revision: this.state.revision,
        lastMeasurementReason: t
      }), this.scheduler.invalidate(t, n);
    }
  }
  handleTransaction(t) {
    const a = Va(t) ? "page-settings" : t.docChanged ? "transaction" : "selection";
    if (a === "selection") {
      this.invalidate("selection");
      return;
    }
    this.invalidate(a, hl(t, a));
  }
  destroy() {
    this.destroyed = !0, this.scheduler.destroy(), this.cleanupCallbacks.splice(0).forEach((t) => t()), this.pushDiagnostics([
      {
        code: "pages.layout.destroyed",
        severity: "info",
        message: "Pages layout engine was destroyed and released DOM listeners."
      }
    ]), this.writeStorage({
      status: ha(),
      pageCount: null,
      pageMap: null,
      pageBoundaries: null,
      overlayModel: null,
      currentPage: null,
      requestLayoutUpdate: null,
      resetDebugSnapshot: !0
    });
  }
  async measure(t) {
    var C, O, P, G;
    if (this.destroyed)
      return;
    const n = We(this.editor);
    if (!n)
      return;
    this.state = {
      ...this.state,
      revision: t.revision,
      dirtyRange: t.dirtyRange
    }, this.setStatus({
      engine: "measuring",
      reason: "measuring",
      revision: t.revision,
      lastMeasurementReason: t.reasons[0] ?? "manual"
    });
    const a = this.adapter.getContentRoot();
    if (!a) {
      this.pushDiagnostics([
        {
          code: "pages.layout.dom-missing",
          severity: "warning",
          message: "Pages layout is waiting for the editor content root before measuring.",
          recoveryHint: "Provide a pagesLayout adapter with getContentRoot()."
        }
      ]), this.setStatus({
        engine: "waiting-for-dom",
        reason: "dom-missing",
        revision: t.revision,
        lastMeasurementReason: t.reasons[0] ?? "manual"
      });
      return;
    }
    const r = Cr({
      pageSettings: n.pageSettings,
      zoom: n.zoom,
      pageGap: n.pageGap,
      pageGapBackground: n.pageGapBackground
    });
    if (!r.metrics) {
      this.pushDiagnostics(r.diagnostics), this.setStatus({
        engine: "failed",
        reason: "measurement-failed",
        revision: t.revision,
        diagnostics: this.state.diagnostics
      });
      return;
    }
    const o = ml(this.editor, {
      resolveBlockElement: (K) => {
        var oe, L;
        return ((L = (oe = this.adapter).resolveBlockElement) == null ? void 0 : L.call(oe, { ...K, dom: null })) ?? null;
      }
    }), s = t.dirtyRange && o.blocks.length ? o.blocks.findIndex(
      (K) => K.pos + K.nodeSize >= t.dirtyRange.from && K.pos <= t.dirtyRange.to
    ) : -1, i = s >= 0 ? s : 0, c = this.options.maxSynchronousBlocks, l = o.blocks.length > c, d = l ? this.state.measuredBlocks.slice(0, i) : this.state.measuredBlocks.slice(0, i), u = o.blocks.slice(i).slice(0, l ? c : void 0), m = l ? [
      {
        code: "pages.layout.performance-budget",
        severity: "warning",
        message: "Pages layout measured a windowed subset because the document exceeds the synchronous block budget.",
        target: `${o.blocks.length} blocks`,
        recoveryHint: "Use incremental/windowed shell rendering for very large documents."
      }
    ] : [], g = await this.measurement({
      blocks: u,
      contentRoot: a
    }), f = [...d, ...g.blocks], b = Zc(f, {
      metrics: r.metrics
    }), E = b.pageMap, _ = Jc(E), k = this.loopGuard.record(
      t.revision,
      _
    ), S = [
      ...o.diagnostics,
      ...r.diagnostics,
      ...g.diagnostics,
      ...m,
      ...b.diagnostics,
      ...k ? [k] : []
    ], y = o.partial || l || b.partial || !!k, x = Ar({
      pageMap: E,
      metrics: r.metrics,
      revision: t.revision,
      overlayHostAvailable: !!((O = (C = this.adapter).getOverlayHost) != null && O.call(C))
    });
    this.scheduler.applyMeasurement(t.revision) && (this.state = {
      revision: t.revision,
      metrics: r.metrics,
      measuredBlocks: f,
      pageMap: E,
      diagnostics: rn(
        this.state.diagnostics,
        S,
        this.options.diagnosticsLimit
      ),
      dirtyRange: t.dirtyRange,
      currentPage: null,
      latestBoundarySignature: _
    }, this.state = {
      ...this.state,
      currentPage: this.resolveCurrentPage("viewport")
    }, this.writeStorage({
      status: at({
        engine: k ? "failed" : y ? "partial" : "ready",
        reason: k ? "measurement-failed" : y ? "measurement-partial" : "measurement-complete",
        revision: t.revision,
        pageCount: E.length,
        lastMeasurementReason: t.reasons[0] ?? "manual",
        measuredAt: Date.now(),
        diagnostics: this.state.diagnostics
      }),
      pageCount: E.length,
      pageMap: E,
      pageBoundaries: b.pageBoundaries,
      overlayModel: x,
      currentPage: this.state.currentPage
    }), (G = (P = this.adapter).onDebugEvent) == null || G.call(P, {
      type: "measured",
      payload: {
        revision: t.revision,
        pageCount: E.length,
        partial: y
      }
    }));
  }
  updateVisualState(t) {
    var s, i;
    const n = We(this.editor);
    if (!n || !this.state.metrics || !this.state.pageMap.length) {
      this.scheduler.invalidate(t);
      return;
    }
    const a = Cr({
      pageSettings: n.pageSettings,
      zoom: n.zoom,
      pageGap: n.pageGap,
      pageGapBackground: n.pageGapBackground
    });
    if (!a.metrics) {
      this.pushDiagnostics(a.diagnostics), this.setStatus({
        engine: "failed",
        reason: "measurement-failed",
        diagnostics: this.state.diagnostics
      });
      return;
    }
    const r = this.state.revision + 1, o = Ar({
      pageMap: this.state.pageMap,
      metrics: a.metrics,
      revision: r,
      overlayHostAvailable: !!((i = (s = this.adapter).getOverlayHost) != null && i.call(s))
    });
    this.state = {
      ...this.state,
      revision: r,
      metrics: a.metrics,
      currentPage: this.resolveCurrentPage("viewport")
    }, this.writeStorage({
      status: at({
        engine: n.layoutStatus.engine === "partial" ? "partial" : "ready",
        reason: "view-state-updated",
        revision: r,
        pageCount: this.state.pageMap.length,
        lastMeasurementReason: t,
        measuredAt: n.layoutStatus.measuredAt,
        diagnostics: this.state.diagnostics
      }),
      pageCount: this.state.pageMap.length,
      pageMap: this.state.pageMap,
      pageBoundaries: this.state.pageMap.map((c) => c.boundary),
      overlayModel: o,
      currentPage: this.state.currentPage
    });
  }
  updateCurrentPage(t) {
    var a, r, o;
    const n = We(this.editor);
    n && (this.state = {
      ...this.state,
      currentPage: this.resolveCurrentPage(
        t === "selection" ? "selection" : "viewport"
      )
    }, n.getCurrentPage = () => this.state.currentPage, n.layoutStatus = at({
      ...n.layoutStatus,
      reason: "current-page-updated",
      lastMeasurementReason: t
    }), (o = (r = this.adapter).onDebugEvent) == null || o.call(r, {
      type: "current-page",
      payload: {
        reason: t,
        pageIndex: ((a = this.state.currentPage) == null ? void 0 : a.pageIndex) ?? null
      }
    }));
  }
  resolveCurrentPage(t) {
    var s, i;
    if (!this.state.pageMap.length)
      return null;
    const n = ((i = (s = this.adapter).getViewportSnapshot) == null ? void 0 : i.call(s)) ?? null;
    let a = this.state.pageMap[0], r = null, o = null;
    if (t === "viewport" && n && this.state.metrics) {
      r = n.scrollTop, o = n.scrollTop + n.viewportHeight;
      const c = n.scrollTop + n.viewportHeight / 2, l = this.state.metrics.pageHeight * this.state.metrics.zoom + this.state.metrics.pageGap, d = Math.max(
        0,
        Math.min(this.state.pageMap.length - 1, Math.floor(c / l))
      );
      a = this.state.pageMap[d] ?? a;
    } else {
      const c = this.editor.state.selection.from;
      a = this.state.pageMap.find(
        (l) => l.startPos !== null && l.endPos !== null && c >= l.startPos && c <= l.endPos
      ) ?? a;
    }
    return {
      pageIndex: a.pageIndex,
      pageNumber: a.pageIndex + 1,
      pageCount: this.state.pageMap.length,
      blockId: a.startBlockId,
      pos: a.startPos,
      source: t,
      viewportTop: r,
      viewportBottom: o
    };
  }
  setStatus(t) {
    const n = We(this.editor);
    n && (n.layoutStatus = at({
      ...n.layoutStatus,
      ...t,
      diagnostics: t.diagnostics ?? this.state.diagnostics
    }));
  }
  pushDiagnostics(t) {
    const n = We(this.editor);
    t.length && (this.state = {
      ...this.state,
      diagnostics: rn(
        this.state.diagnostics,
        t.map(Rr),
        this.options.diagnosticsLimit
      )
    }, n && (n.diagnostics = rn(
      n.diagnostics,
      t.map(Rr),
      this.options.diagnosticsLimit
    ), n.layoutStatus = at({
      ...n.layoutStatus,
      diagnostics: this.state.diagnostics
    })));
  }
  writeStorage(t) {
    const n = We(this.editor);
    n && (n.layoutStatus = t.status, n.pageCount = t.pageCount, n.pageMap = t.pageMap, n.pageBoundaries = t.pageBoundaries, n.overlayModel = t.overlayModel, this.state = {
      ...this.state,
      currentPage: t.currentPage
    }, n.getCurrentPage = () => this.state.currentPage, n.getPagesDebugSnapshot = t.resetDebugSnapshot ? () => ba({
      status: n.layoutStatus,
      metrics: null,
      measuredBlocks: [],
      dirtyRange: null,
      scheduler: {
        revision: 0,
        scheduled: !1,
        measuring: !1,
        pendingReasons: [],
        latestAppliedRevision: 0,
        discardedMeasurements: 0,
        loopGuardTrips: 0
      },
      diagnostics: n.diagnostics,
      pageMap: []
    }) : () => this.createDebugSnapshot(), "requestLayoutUpdate" in t && (n.requestLayoutUpdate = t.requestLayoutUpdate ?? void 0), n.diagnostics = rn(
      n.diagnostics,
      t.status.diagnostics,
      this.options.diagnosticsLimit
    ));
  }
  createDebugSnapshot() {
    var t;
    return ba({
      status: ((t = We(this.editor)) == null ? void 0 : t.layoutStatus) ?? ha(),
      metrics: this.state.metrics,
      measuredBlocks: this.state.measuredBlocks,
      dirtyRange: this.state.dirtyRange,
      scheduler: {
        ...this.scheduler.getSnapshot(),
        loopGuardTrips: this.loopGuard.getSnapshot().trips
      },
      diagnostics: this.state.diagnostics,
      pageMap: this.state.pageMap
    });
  }
  attachDomListeners() {
    const t = this.adapter.getContentRoot(), n = this.adapter.getScrollContainer(), a = /* @__PURE__ */ new Map();
    if (t && typeof ResizeObserver < "u") {
      const c = new ResizeObserver(() => this.invalidate("resize"));
      c.observe(t), this.cleanupCallbacks.push(() => c.disconnect());
    }
    if (ft(n)) {
      const c = () => this.invalidate("scroll");
      n.addEventListener("scroll", c, { passive: !0 }), this.cleanupCallbacks.push(
        () => n.removeEventListener("scroll", c)
      );
    } else if (n && "addEventListener" in n) {
      const c = () => this.invalidate("scroll");
      n.addEventListener("scroll", c, { passive: !0 }), this.cleanupCallbacks.push(
        () => n.removeEventListener("scroll", c)
      );
    }
    const r = (c) => {
      if (!ft(c) || a.has(c))
        return !1;
      const l = () => this.invalidate("media-load");
      return c.addEventListener("load", l), c.addEventListener("loadeddata", l), a.set(c, () => {
        c.removeEventListener("load", l), c.removeEventListener("loadeddata", l);
      }), !0;
    }, o = (c) => {
      if (!(c instanceof Element))
        return !1;
      let l = c.matches(jn) ? r(c) : !1;
      return c.querySelectorAll(jn).forEach((d) => {
        l = r(d) || l;
      }), l;
    }, s = (c) => {
      if (!(c instanceof Element))
        return;
      const l = a.get(c);
      l && (l(), a.delete(c)), c.querySelectorAll(jn).forEach((d) => {
        const u = a.get(d);
        u && (u(), a.delete(d));
      });
    };
    if (t && (o(t), this.cleanupCallbacks.push(() => {
      a.forEach((c) => c()), a.clear();
    })), t && typeof MutationObserver < "u") {
      const c = new MutationObserver((l) => {
        let d = !1, u = !1;
        l.forEach((m) => {
          m.type === "attributes" && El(m) && (u = !0), m.removedNodes.forEach((g) => s(g)), m.addedNodes.forEach((g) => {
            d = o(g) || d;
          });
        }), u && this.invalidate("style-change"), d && this.invalidate("media-load");
      });
      c.observe(t, {
        attributes: !0,
        attributeOldValue: !0,
        attributeFilter: fl,
        childList: !0,
        subtree: !0
      }), this.cleanupCallbacks.push(() => c.disconnect());
    }
    const i = document.fonts;
    if (i && "addEventListener" in i) {
      const c = () => this.invalidate("font-load");
      i.addEventListener("loadingdone", c), i.addEventListener("loadingerror", c), this.cleanupCallbacks.push(() => {
        i.removeEventListener("loadingdone", c), i.removeEventListener("loadingerror", c);
      });
    }
  }
}
const ob = ae.create({
  name: "pagesLayout",
  addOptions() {
    return {
      adapter: null,
      scheduler: null,
      measurement: null,
      diagnosticsLimit: Wa,
      maxSynchronousBlocks: 1e3,
      pageWindow: {
        before: 1,
        after: 2
      },
      debug: !1
    };
  },
  addStorage() {
    const e = [
      {
        code: "pages.layout.contract-missing",
        severity: "error",
        message: "Pages layout extension requires editor.storage.pages from the Pages contract extension.",
        recoveryHint: "Install TextEditorPagesContractExtension or enable pages before pagesLayout."
      }
    ];
    return {
      controller: null,
      layoutStatus: at({
        engine: "disabled",
        reason: "contract-missing",
        diagnostics: e
      }),
      diagnostics: e
    };
  },
  onCreate() {
    if (!We(this.editor)) {
      this.storage.diagnostics = [
        {
          code: "pages.layout.contract-missing",
          severity: "error",
          message: "Pages layout extension requires editor.storage.pages from the Pages contract extension.",
          recoveryHint: "Install TextEditorPagesContractExtension or enable pages before pagesLayout."
        }
      ], this.storage.layoutStatus = at({
        engine: "disabled",
        reason: "contract-missing",
        diagnostics: this.storage.diagnostics
      });
      return;
    }
    this.storage.diagnostics = [], this.storage.layoutStatus = at({
      engine: "idle",
      reason: "scheduled"
    });
    const t = new _l(this.editor, this.options);
    this.storage.controller = t, t.install();
  },
  onTransaction({ transaction: e }) {
    var t;
    (t = this.storage.controller) == null || t.handleTransaction(e);
  },
  onSelectionUpdate() {
    var e;
    (e = this.storage.controller) == null || e.invalidate("selection");
  },
  onDestroy() {
    var e;
    (e = this.storage.controller) == null || e.destroy(), this.storage.controller = null;
  }
}), Ln = "pages", Sl = (e, t) => ba({
  status: e,
  metrics: null,
  measuredBlocks: [],
  dirtyRange: null,
  scheduler: {
    revision: 0,
    scheduled: !1,
    measuring: !1,
    pendingReasons: [],
    latestAppliedRevision: 0,
    discardedMeasurements: 0,
    loopGuardTrips: 0
  },
  diagnostics: t,
  pageMap: []
}), kl = (e, t) => typeof t == "string" ? { id: e.id } : {
  id: e.id,
  label: e.label,
  width: e.width,
  height: e.height
}, vl = (e) => Number.isFinite(e) && e >= 0.25 && e <= 4, Tl = (e) => Number.isFinite(e) && e >= 0, wl = (e) => {
  var n;
  const t = (n = e.getCurrentDocument) == null ? void 0 : n.call(e);
  return t ? Vt(t) : Pa(e.initialPages ?? void 0);
}, Qn = (e, t) => {
  const n = ko(t.defaults.page);
  e.pageFormat = n.pageFormat, e.pageSettings = n;
}, on = (e, t) => {
  e.diagnostics = [
    ...e.diagnostics,
    vo(t)
  ].slice(-20);
}, sn = (e) => e.editor.storage[Ln], sb = ae.create({
  name: Ln,
  addOptions() {
    return {
      getCurrentDocument: null,
      initialPages: null,
      zoom: 1,
      pageGap: 24,
      pageGapBackground: "transparent"
    };
  },
  addStorage() {
    const e = wl(this.options), t = ko(e.defaults.page), n = ha();
    return {
      pageFormat: t.pageFormat,
      pageSettings: t,
      zoom: this.options.zoom,
      pageGap: this.options.pageGap,
      pageGapBackground: this.options.pageGapBackground,
      layoutStatus: n,
      pageCount: null,
      pageMap: null,
      pageBoundaries: null,
      overlayModel: null,
      getCurrentPage: () => null,
      getPagesDebugSnapshot: () => Sl(n, []),
      requestLayoutUpdate: void 0,
      diagnostics: []
    };
  },
  onTransaction({ transaction: e }) {
    var a, r;
    const t = Va(e);
    if (t != null && t.pages) {
      Qn(this.storage, t.pages);
      return;
    }
    const n = (r = (a = this.options).getCurrentDocument) == null ? void 0 : r.call(a);
    n && Qn(
      this.storage,
      Vt(n)
    );
  },
  addCommands() {
    return {
      setPageFormat: (e, t = {}) => (n) => {
        var r, o, s;
        const a = sn(n);
        try {
          const i = ac(e), c = (o = (r = this.options).getCurrentDocument) == null ? void 0 : o.call(r), l = c ? Vt(c) : Pa(this.options.initialPages ?? void 0), d = rc(l, {
            pageFormat: kl(i, e),
            orientation: t.orientation,
            margins: t.margins
          });
          return n.dispatch && (n.dispatch(
            fa(n.state.tr, {
              previousPages: l,
              pages: d,
              reason: "setPageFormat"
            })
          ), Qn(a, d), (s = a.requestLayoutUpdate) == null || s.call(a, "page-settings")), !0;
        } catch (i) {
          return on(
            a,
            So(i) ? i.diagnostic : {
              code: "pages.command.invalid",
              severity: "error",
              message: "Failed to set Pages page format."
            }
          ), !1;
        }
      },
      setZoom: (e) => (t) => {
        var a;
        const n = sn(t);
        return vl(e) ? (t.dispatch && (n.zoom = e, (a = n.requestLayoutUpdate) == null || a.call(n, "view-state")), !0) : (on(n, {
          code: "pages.command.invalid",
          severity: "error",
          message: "Pages zoom must be between 0.25 and 4.",
          target: "zoom"
        }), !1);
      },
      setPageGap: (e) => (t) => {
        var a;
        const n = sn(t);
        return Tl(e) ? (t.dispatch && (n.pageGap = e, (a = n.requestLayoutUpdate) == null || a.call(n, "view-state")), !0) : (on(n, {
          code: "pages.command.invalid",
          severity: "error",
          message: "Pages page gap must be a finite non-negative number.",
          target: "pageGap"
        }), !1);
      },
      setPageGapBackground: (e) => (t) => {
        var a;
        const n = sn(t);
        return typeof e != "string" ? (on(n, {
          code: "pages.command.invalid",
          severity: "error",
          message: "Pages page gap background must be a string.",
          target: "pageGapBackground"
        }), !1) : (t.dispatch && (n.pageGapBackground = e, (a = n.requestLayoutUpdate) == null || a.call(n, "view-state")), !0);
      }
    };
  }
}), Nl = /* @__PURE__ */ new Set(["doc", "paragraph", "text", "hardBreak"]), xl = /* @__PURE__ */ new Set([
  "bold",
  "italic",
  "underline",
  "strike",
  "code",
  "link"
]), Cl = /* @__PURE__ */ new Set(["http:", "https:", "mailto:", "tel:"]), Po = (e) => JSON.parse(JSON.stringify(e)), vn = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Le = (e, t = {}) => ({
  severity: e.severity ?? "error",
  ...e,
  ...t.kind ? { kind: t.kind } : {},
  ...t.slot ? { slot: t.slot } : {}
}), Al = (e) => ({
  type: "doc",
  content: [
    {
      type: "paragraph",
      ...e ? {
        content: [
          {
            type: "text",
            text: e
          }
        ]
      } : {}
    }
  ]
}), Fo = (e) => e.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (t, n) => {
  const a = n.toLowerCase();
  if (a === "amp") return "&";
  if (a === "lt") return "<";
  if (a === "gt") return ">";
  if (a === "quot") return '"';
  if (a === "apos") return "'";
  if (a === "nbsp") return " ";
  if (a.startsWith("#x")) {
    const r = Number.parseInt(a.slice(2), 16);
    return Number.isFinite(r) ? String.fromCodePoint(r) : t;
  }
  if (a.startsWith("#")) {
    const r = Number.parseInt(a.slice(1), 10);
    return Number.isFinite(r) ? String.fromCodePoint(r) : t;
  }
  return t;
}), zo = (e) => {
  if (typeof e != "string")
    return !1;
  const t = e.trim();
  if (!t)
    return !1;
  try {
    const n = new URL(t, "https://zx.local");
    return Cl.has(n.protocol) || n.protocol === "https:" && !/^[a-z][a-z0-9+.-]*:/i.test(t);
  } catch {
    return !1;
  }
}, Ho = (e) => {
  const t = e.trim();
  let n = t.startsWith("/") ? 1 : 0, a = "";
  for (; n < t.length; ) {
    const r = t[n];
    if (!r || /\s|\/|>/.test(r))
      break;
    a += r.toLowerCase(), n += 1;
  }
  return a;
}, Ml = (e) => {
  const t = {}, n = e.replace(/\/$/, "");
  let a = Ho(n).length;
  for (; a < n.length; ) {
    for (; a < n.length && /\s/.test(n[a]); )
      a += 1;
    let r = "";
    for (; a < n.length && /[^\s=/>]/.test(n[a]); )
      r += n[a].toLowerCase(), a += 1;
    for (; a < n.length && /\s/.test(n[a]); )
      a += 1;
    if (!r || n[a] !== "=")
      continue;
    for (a += 1; a < n.length && /\s/.test(n[a]); )
      a += 1;
    const o = n[a];
    let s = "";
    if (o === '"' || o === "'") {
      for (a += 1; a < n.length && n[a] !== o; )
        s += n[a], a += 1;
      a += 1;
    } else
      for (; a < n.length && /[^\s>]/.test(n[a]); )
        s += n[a], a += 1;
    t[r] = Fo(s);
  }
  return t;
}, Il = (e, t, n) => {
  if (e === "strong" || e === "b")
    return { mark: { type: "bold" }, diagnostics: [] };
  if (e === "em" || e === "i")
    return { mark: { type: "italic" }, diagnostics: [] };
  if (e === "u")
    return { mark: { type: "underline" }, diagnostics: [] };
  if (e === "s" || e === "strike" || e === "del")
    return { mark: { type: "strike" }, diagnostics: [] };
  if (e === "code")
    return { mark: { type: "code" }, diagnostics: [] };
  if (e === "a") {
    const a = t.href;
    return zo(a) ? {
      mark: {
        type: "link",
        attrs: {
          href: a.trim()
        }
      },
      diagnostics: []
    } : {
      diagnostics: [
        Le(
          {
            code: "pages.headerFooter.link-unsafe",
            message: "Header/footer link href uses an unsupported protocol.",
            target: "link.href",
            recoveryHint: "Use http, https, mailto, tel, or a relative link href."
          },
          n
        )
      ]
    };
  }
  return { diagnostics: [] };
}, Br = (e, t) => Le(
  {
    code: "pages.headerFooter.content-unsupported",
    message: `Header/footer HTML tag "${e}" is not supported.`,
    target: e,
    recoveryHint: "Use paragraph text, line breaks, basic inline formatting, or safe links."
  },
  t
), Ol = (e, t) => {
  const n = [], a = [];
  let r = [];
  const o = [], s = (l) => {
    const d = Fo(l);
    d && r.push({
      type: "text",
      text: d,
      ...o.length ? { marks: Po(o) } : {}
    });
  }, i = () => {
    r.length && (a.push({
      type: "paragraph",
      content: r
    }), r = []);
  };
  let c = 0;
  for (; c < e.length; ) {
    const l = e.indexOf("<", c);
    if (l === -1) {
      s(e.slice(c));
      break;
    }
    s(e.slice(c, l));
    const d = e.indexOf(">", l + 1);
    if (d === -1) {
      n.push(
        Le(
          {
            code: "pages.headerFooter.html-parse-failed",
            message: "Header/footer HTML contains an unclosed tag.",
            target: "content",
            recoveryHint: "Close all HTML tags before saving."
          },
          t
        )
      );
      break;
    }
    const m = e.slice(l + 1, d).trim();
    if (c = d + 1, !m || m.startsWith("!") || m.startsWith("?"))
      continue;
    const g = m.startsWith("/"), f = m.endsWith("/"), b = Ho(m);
    if (!b)
      continue;
    if (b === "script" || b === "style") {
      n.push(Br(b, t));
      const _ = `</${b}>`, S = e.slice(c).toLowerCase().indexOf(_);
      S >= 0 && (c += S + _.length);
      continue;
    }
    if (b === "p" || b === "div") {
      (g || r.length) && i();
      continue;
    }
    if (b === "br") {
      r.push({ type: "hardBreak" });
      continue;
    }
    if ([
      "strong",
      "b",
      "em",
      "i",
      "u",
      "s",
      "strike",
      "del",
      "code",
      "a"
    ].includes(b)) {
      const _ = b === "b" || b === "strong" ? "bold" : b === "i" || b === "em" ? "italic" : b === "u" ? "underline" : b === "s" || b === "strike" || b === "del" ? "strike" : b === "a" ? "link" : b;
      if (g) {
        const S = [...o].reverse().findIndex((y) => y.type === _);
        S >= 0 && o.splice(o.length - 1 - S, 1);
        continue;
      }
      const k = Il(
        b,
        Ml(m),
        t
      );
      n.push(...k.diagnostics), k.mark && o.push(k.mark), f && k.mark && o.pop();
      continue;
    }
    g || n.push(Br(b, t));
  }
  return i(), n.some((l) => l.severity === "error") ? {
    ok: !1,
    diagnostics: n
  } : Ea(
    {
      type: "doc",
      ...a.length ? { content: a } : {}
    },
    t
  );
}, Ll = (e, t) => {
  if (!Array.isArray(e))
    return { diagnostics: [] };
  const n = [], a = e.map((r) => {
    if (!vn(r) || typeof r.type != "string")
      return n.push(
        Le(
          {
            code: "pages.headerFooter.content-invalid",
            message: "Header/footer mark must declare a string type.",
            target: "mark",
            recoveryHint: "Remove malformed mark data before saving."
          },
          t
        )
      ), null;
    if (!xl.has(r.type))
      return n.push(
        Le(
          {
            code: "pages.headerFooter.content-unsupported",
            message: `Header/footer mark "${r.type}" is not supported.`,
            target: r.type,
            recoveryHint: "Use only bold, italic, underline, strike, code, or link marks."
          },
          t
        )
      ), null;
    if (r.type !== "link")
      return { type: r.type };
    const o = vn(r.attrs) ? r.attrs.href : void 0;
    return zo(o) ? {
      type: "link",
      attrs: {
        href: o.trim()
      }
    } : (n.push(
      Le(
        {
          code: "pages.headerFooter.link-unsafe",
          message: "Header/footer link href uses an unsupported protocol.",
          target: "link.href",
          recoveryHint: "Use http, https, mailto, tel, or a relative link href."
        },
        t
      )
    ), null);
  }).filter(
    (r) => !!r
  );
  return {
    ...a.length ? { marks: a } : {},
    diagnostics: n
  };
}, $o = (e, t) => {
  const n = [];
  if (!vn(e) || typeof e.type != "string")
    return n.push(
      Le(
        {
          code: "pages.headerFooter.content-invalid",
          message: "Header/footer content node must declare a string type.",
          target: "node",
          recoveryHint: "Provide valid Tiptap JSONContent."
        },
        t
      )
    ), { diagnostics: n };
  if (!Nl.has(e.type))
    return n.push(
      Le(
        {
          code: "pages.headerFooter.content-unsupported",
          message: `Header/footer node "${e.type}" is not supported.`,
          target: e.type,
          recoveryHint: "Use only paragraph, text, hardBreak, and supported inline marks."
        },
        t
      )
    ), { diagnostics: n };
  if (e.type === "text") {
    if (typeof e.text != "string")
      return n.push(
        Le(
          {
            code: "pages.headerFooter.content-invalid",
            message: "Header/footer text node must contain string text.",
            target: "text",
            recoveryHint: "Remove malformed text nodes before saving."
          },
          t
        )
      ), { diagnostics: n };
    const r = Ll(e.marks, t);
    return n.push(...r.diagnostics), {
      node: {
        type: "text",
        text: e.text,
        ...r.marks ? { marks: r.marks } : {}
      },
      diagnostics: n
    };
  }
  if (e.type === "hardBreak")
    return {
      node: { type: "hardBreak" },
      diagnostics: n
    };
  const a = Array.isArray(e.content) ? e.content.map((r) => {
    const o = $o(r, t);
    return n.push(...o.diagnostics), o.node;
  }).filter((r) => !!r) : [];
  return {
    node: {
      type: e.type,
      ...a.length ? { content: a } : {}
    },
    diagnostics: n
  };
}, Ea = (e, t) => {
  var s;
  const n = $o(e, t), a = n.diagnostics.some(
    (i) => i.severity === "error"
  );
  if (!n.node || a)
    return {
      ok: !1,
      diagnostics: n.diagnostics
    };
  const r = n.node.type === "doc" ? n.node : {
    type: "doc",
    content: [n.node]
  };
  return {
    ok: !0,
    value: !!((s = r.content) != null && s.some(
      (i) => {
        var c;
        return i.type !== "paragraph" || !!((c = i.content) != null && c.length);
      }
    )) ? {
      state: "content",
      content: Po(r)
    } : { state: "empty" },
    diagnostics: n.diagnostics
  };
}, Rl = (e, t = {}) => {
  const n = t.inputFormat ?? (typeof e == "string" ? "text" : "json");
  return n === "text" ? typeof e != "string" ? {
    ok: !1,
    diagnostics: [
      Le(
        {
          code: "pages.headerFooter.content-invalid",
          message: "Header/footer text input must be a string.",
          target: "content",
          recoveryHint: 'Pass a string or use inputFormat "json".'
        },
        t
      )
    ]
  } : Ea(Al(e), t) : n === "html" ? typeof e != "string" ? {
    ok: !1,
    diagnostics: [
      Le(
        {
          code: "pages.headerFooter.content-invalid",
          message: "Header/footer HTML input must be a string.",
          target: "content",
          recoveryHint: 'Pass an HTML string or use inputFormat "json".'
        },
        t
      )
    ]
  } : Ol(e, t) : vn(e) ? Ea(e, t) : {
    ok: !1,
    diagnostics: [
      Le(
        {
          code: "pages.headerFooter.content-invalid",
          message: "Header/footer JSON input must be Tiptap JSONContent.",
          target: "content",
          recoveryHint: "Pass a JSONContent object."
        },
        t
      )
    ]
  };
}, _a = (e) => JSON.parse(JSON.stringify(e)), Uo = (e) => typeof e == "number" && Number.isFinite(e) && Number.isInteger(e) && e > 0, Dl = (e) => typeof e == "number" && Number.isFinite(e) && Number.isInteger(e) && e >= 0, Go = (e) => e.layoutReady !== !1 && e.layoutPartial !== !0, qt = (e) => ({
  severity: e.severity ?? "warning",
  ...e
}), Bl = (e, t) => t === "header" ? e.header : e.footer, Pl = (e, t) => {
  const n = t.pageIndex + 1;
  return e.differentFirstPage && t.pageIndex === 0 ? "firstPage" : e.differentOddEven ? n % 2 === 0 ? "evenPage" : "oddPage" : "default";
}, Sa = (e, t, n) => {
  const a = En(e), r = Bl(a, t), o = Pl(a, n), s = r == null ? void 0 : r[o];
  if (s)
    return {
      kind: t,
      slot: o,
      source: o,
      value: _a(s),
      explicitEmpty: s.state === "empty",
      fallbackApplied: !1
    };
  const i = r == null ? void 0 : r.default;
  return o !== "default" && i ? {
    kind: t,
    slot: o,
    source: "default",
    value: _a(i),
    explicitEmpty: i.state === "empty",
    fallbackApplied: !0
  } : {
    kind: t,
    slot: o,
    source: null,
    value: null,
    explicitEmpty: !1,
    fallbackApplied: !1
  };
}, ib = (e, t) => ({
  header: Sa(e, "header", t),
  footer: Sa(e, "footer", t)
}), Fl = (e) => e.pageNumbering === "hidden" ? {
  value: null,
  diagnostics: [
    qt({
      code: "pages.headerFooter.placeholder-hidden",
      message: "Header/footer page number placeholder is hidden.",
      target: "{page}",
      recoveryHint: "Change section page numbering or remove the page placeholder."
    })
  ]
} : Uo(e.pageNumber) ? { value: e.pageNumber, diagnostics: [] } : Go(e) ? e.pageNumbering === "restart-1" && Dl(e.sectionStartPageIndex) ? {
  value: Math.max(1, e.pageIndex - e.sectionStartPageIndex + 1),
  diagnostics: []
} : {
  value: e.pageIndex + 1,
  diagnostics: []
} : {
  value: null,
  diagnostics: [
    qt({
      code: "pages.headerFooter.placeholder-unresolved",
      message: "Header/footer page placeholder cannot resolve before layout is ready.",
      target: "{page}",
      recoveryHint: "Wait for the Pages layout engine to finish."
    })
  ]
}, zl = (e) => e.pageNumbering === "hidden" ? {
  value: null,
  diagnostics: [
    qt({
      code: "pages.headerFooter.placeholder-hidden",
      message: "Header/footer total pages placeholder is hidden.",
      target: "{total}",
      recoveryHint: "Change section page numbering or remove the total pages placeholder."
    })
  ]
} : Go(e) && Uo(e.totalPages) ? { value: e.totalPages, diagnostics: [] } : {
  value: null,
  diagnostics: [
    qt({
      code: "pages.headerFooter.placeholder-unresolved",
      message: "Header/footer total pages placeholder cannot resolve until total pages are known.",
      target: "{total}",
      recoveryHint: "Wait for the Pages layout engine to report page count."
    })
  ]
}, Hl = (e, t, n, a) => e.replace(/\{(page|total)\}/g, (r, o) => {
  const s = o === "page" ? Fl(t) : zl(t);
  return n.push(...s.diagnostics), s.value === null ? t.pageNumbering === "hidden" ? "" : (a.push(r), r) : String(s.value);
}), Ko = (e, t, n, a) => e.type === "text" && typeof e.text == "string" ? {
  ...e,
  text: Hl(
    e.text,
    t,
    n,
    a
  )
} : {
  ...e,
  ...e.content ? {
    content: e.content.map(
      (r) => Ko(
        r,
        t,
        n,
        a
      )
    )
  } : {}
}, cb = (e, t) => {
  if (!e || e.state === "empty" || !e.content)
    return {
      state: "empty",
      content: null,
      diagnostics: [],
      unresolvedPlaceholders: []
    };
  const n = [], a = [], r = Ko(
    _a(e.content),
    t,
    n,
    a
  );
  return {
    state: a.length ? "unresolved" : "resolved",
    content: r,
    diagnostics: n,
    unresolvedPlaceholders: a
  };
}, lb = (e, t) => qt({
  code: "pages.headerFooter.slot-unsupported",
  message: "Per-page arbitrary header/footer styling is not supported in this phase.",
  target: `${e}.${t}`,
  kind: e,
  slot: t,
  recoveryHint: "Use default, firstPage, oddPage, or evenPage document-level slots."
}), $l = "pagesHeaderFooter", At = (e) => {
  var n;
  const t = (n = e.storage) == null ? void 0 : n[Ln];
  return t && typeof t == "object" ? t : null;
}, Ot = (e) => typeof e.editable == "function" ? e.editable() : e.editable !== !1, Ul = () => ({
  inlineRich: !0,
  complexBlocks: !1,
  wholeSlotCollaboration: !0,
  fineGrainedCollaboration: !1
}), ka = () => ({
  code: "pages.headerFooter.contract-missing",
  severity: "error",
  message: "Pages header/footer extension requires editor.storage.pages from the Pages contract extension.",
  target: Ln,
  recoveryHint: "Install TextEditorPagesContractExtension or enable pages before pagesHeaderFooter."
}), Vo = (e, t) => ({
  available: t.available,
  status: t.available ? t.readonly ? "readonly" : "ready" : "unavailable",
  ...t.unavailableReason ? { unavailableReason: t.unavailableReason } : {},
  contract: e,
  activeEditor: null,
  availableSlots: [...ic],
  capabilities: Ul(),
  diagnostics: [...t.diagnostics ?? []]
}), qa = (e) => {
  var n, a;
  const t = (n = e.getCurrentDocument) == null ? void 0 : n.call(e);
  return (a = t == null ? void 0 : t.meta.pages) != null && a.headerFooter ? En(
    t.meta.pages.headerFooter
  ) : e.initialHeaderFooter ? En(e.initialHeaderFooter) : cc();
}, Wo = (e, t) => (e.headerFooter || (e.headerFooter = Vo(
  qa(t),
  {
    available: !0,
    readonly: !Ot(t)
  }
)), e.headerFooter), qe = (e, t) => {
  e.diagnostics = [
    ...e.diagnostics,
    vo(t)
  ].slice(-20);
}, cn = (e, t, n) => {
  const a = Wo(e, t);
  a.available = !0, a.status = Ot(t) ? "ready" : "readonly", a.unavailableReason = void 0, a.contract = En(
    n ?? qa(t)
  );
}, Pr = (e, t) => {
  var a;
  const n = (a = e.getCurrentDocument) == null ? void 0 : a.call(e);
  return n ? Vt(n) : Pa({
    headerFooter: t.contract
  });
}, Gl = (e, t, n, a = {}) => {
  var u, m, g;
  const r = typeof a.pageIndex == "number" && Number.isFinite(a.pageIndex) && a.pageIndex >= 0 ? Math.floor(a.pageIndex) : 0, o = ((u = e.pageMap) == null ? void 0 : u.find((f) => f.pageIndex === r)) ?? null, s = ((m = o == null ? void 0 : o.headerFooterAnchor) == null ? void 0 : m.totalPages) ?? e.layoutStatus.pageCount ?? e.pageCount ?? null, i = e.layoutStatus.engine === "ready", c = e.layoutStatus.engine === "partial" || e.layoutStatus.engine === "stale", l = a.slot;
  if (l) {
    const f = ((g = t.contract[n]) == null ? void 0 : g[l]) ?? null;
    return {
      kind: n,
      slot: l,
      pageIndex: r,
      pageNumber: r + 1,
      totalPages: s,
      sectionId: (o == null ? void 0 : o.sectionId) ?? null,
      layoutReady: i,
      layoutPartial: c,
      content: f ?? { state: "empty" }
    };
  }
  const d = Sa(t.contract, n, {
    pageIndex: r,
    sectionId: (o == null ? void 0 : o.sectionId) ?? null
  });
  return {
    kind: n,
    slot: d.slot,
    pageIndex: r,
    pageNumber: r + 1,
    totalPages: s,
    sectionId: (o == null ? void 0 : o.sectionId) ?? null,
    layoutReady: i,
    layoutPartial: c,
    content: d.value ?? { state: "empty" }
  };
}, ln = (e, t, n) => {
  const a = At(e.editor);
  return a ? Wo(a, n) : (qe(t, ka()), null);
}, db = ae.create({
  name: $l,
  priority: 90,
  addOptions() {
    return {
      getCurrentDocument: null,
      initialHeaderFooter: null,
      editable: !0,
      headerFooterExtensions: [],
      onCloseGuard: void 0
    };
  },
  addStorage() {
    return {
      diagnostics: [ka()]
    };
  },
  onCreate() {
    const e = () => {
      if (this.editor.isDestroyed)
        return !1;
      const t = At(this.editor);
      return t ? (t.headerFooter = Vo(
        qa(this.options),
        {
          available: !0,
          readonly: !Ot(this.options)
        }
      ), this.storage.diagnostics = [], !0) : !1;
    };
    e() || (this.storage.diagnostics = [ka()], queueMicrotask(() => {
      e();
    }), setTimeout(() => {
      e();
    }, 0));
  },
  onTransaction({ transaction: e }) {
    var r, o;
    const t = At(this.editor);
    if (!t)
      return;
    const n = Va(e);
    if (n != null && n.pages) {
      cn(
        t,
        this.options,
        n.pages.headerFooter
      );
      return;
    }
    const a = (o = (r = this.options).getCurrentDocument) == null ? void 0 : o.call(r);
    a && cn(
      t,
      this.options,
      Vt(a).headerFooter
    );
  },
  addCommands() {
    const e = (a, r, o = {}) => (s) => {
      var u;
      const i = ln(s, this.storage, this.options);
      if (!i || !i.available)
        return i && qe(i, {
          code: "pages.headerFooter.unavailable",
          severity: "error",
          message: "Pages header/footer is unavailable.",
          target: a,
          recoveryHint: "Enable Pages and pagesHeaderFooter first."
        }), !1;
      if (!Ot(this.options))
        return qe(i, {
          code: "pages.headerFooter.readonly",
          severity: "error",
          message: "Readonly editor cannot update header/footer content.",
          target: a,
          recoveryHint: "Enable editing before changing header/footer slots."
        }), !1;
      const c = o.slot ?? "default";
      if (!Sr(c))
        return qe(i, {
          code: "pages.headerFooter.slot-invalid",
          severity: "error",
          message: "Unknown header/footer slot.",
          target: String(c),
          recoveryHint: "Use default, firstPage, oddPage, or evenPage."
        }), !1;
      const l = o.mode ?? "set", d = l === "set" ? Rl(r, {
        inputFormat: o.inputFormat,
        kind: a,
        slot: c,
        headerFooterExtensions: this.options.headerFooterExtensions
      }) : { ok: !0, diagnostics: [], value: void 0 };
      if (d.diagnostics.forEach(
        (m) => qe(i, m)
      ), !d.ok)
        return !1;
      try {
        const m = Pr(this.options, i), g = sc(m, {
          kind: a,
          slot: c,
          mode: l,
          value: d.value
        });
        return s.dispatch && (s.dispatch(
          fa(s.state.tr, {
            previousPages: m,
            pages: g,
            reason: a === "header" ? "setHeader" : "setFooter",
            headerFooter: {
              kind: a,
              slot: c,
              mode: l === "set" && ((u = d.value) == null ? void 0 : u.state) === "empty" ? "empty" : l
            }
          })
        ), cn(
          At(s.editor),
          this.options,
          g.headerFooter
        )), !0;
      } catch (m) {
        return qe(
          i,
          So(m) ? m.diagnostic : {
            code: "pages.headerFooter.content-invalid",
            severity: "error",
            message: "Failed to update header/footer content.",
            target: a,
            recoveryHint: "Verify the header/footer input and slot."
          }
        ), !1;
      }
    }, t = (a, r) => (o) => {
      const s = ln(o, this.storage, this.options);
      if (!s || !s.available)
        return !1;
      if (!Ot(this.options))
        return qe(s, {
          code: "pages.headerFooter.readonly",
          severity: "error",
          message: "Readonly editor cannot update header/footer options.",
          target: a,
          recoveryHint: "Enable editing before changing header/footer options."
        }), !1;
      const i = Pr(this.options, s), c = oc(i, {
        [a]: r
      });
      return o.dispatch && (o.dispatch(
        fa(o.state.tr, {
          previousPages: i,
          pages: c,
          reason: a === "differentFirstPage" ? "setDifferentFirstPage" : "setDifferentOddEven",
          headerFooter: {}
        })
      ), cn(
        At(o.editor),
        this.options,
        c.headerFooter
      )), !0;
    }, n = (a, r = {}) => (o) => {
      const s = ln(o, this.storage, this.options);
      if (!s || !s.available)
        return !1;
      if (!Ot(this.options))
        return qe(s, {
          code: "pages.headerFooter.readonly",
          severity: "error",
          message: "Readonly editor cannot open editable header/footer editor.",
          target: a,
          recoveryHint: "Use shell readonly preview instead."
        }), !1;
      if (r.slot && !Sr(r.slot))
        return qe(s, {
          code: "pages.headerFooter.slot-invalid",
          severity: "error",
          message: "Unknown header/footer editor slot.",
          target: String(r.slot),
          recoveryHint: "Use default, firstPage, oddPage, or evenPage."
        }), !1;
      if (o.dispatch) {
        const i = At(o.editor);
        if (!i)
          return !1;
        s.activeEditor = Gl(
          i,
          s,
          a,
          r
        );
      }
      return !0;
    };
    return {
      setHeader: (a, r) => e("header", a, r),
      setFooter: (a, r) => e("footer", a, r),
      setDifferentFirstPage: (a) => t("differentFirstPage", a),
      setDifferentOddEven: (a) => t("differentOddEven", a),
      openHeaderEditor: (a) => n("header", a),
      openFooterEditor: (a) => n("footer", a),
      closeHeaderFooterEditors: () => (a) => {
        var i, c;
        const r = ln(a, this.storage, this.options);
        if (!r)
          return !1;
        const o = r.activeEditor;
        return o ? ((c = (i = this.options).onCloseGuard) == null ? void 0 : c.call(i, {
          kind: o.kind,
          slot: o.slot
        })) === !1 ? !1 : (a.dispatch && (r.activeEditor = null), !0) : !0;
      }
    };
  }
}), Kl = "pages", Vl = (e) => {
  const t = e.editor.storage[Kl];
  return t && typeof t == "object" ? t : null;
}, dn = (e, t) => {
  const n = Vl(e);
  n && (n.diagnostics = [
    ...n.diagnostics ?? [],
    { ...t }
  ].slice(-20));
}, Wl = (e) => {
  const { selection: t, doc: n } = e.state, a = t.$to;
  return a.depth <= 0 ? Math.min(t.to, n.content.size) : Math.min(a.after(1), n.content.size);
}, ql = (e) => {
  const t = e.state.schema.nodes[Kt];
  if (!e.editor.isEditable)
    return dn(e, {
      code: "pages.pageBreak.readonly",
      severity: "warning",
      message: "Cannot insert a page break while the editor is readonly.",
      recoveryHint: "Switch the editor to editable mode before inserting a page break."
    }), !1;
  if (!t)
    return dn(e, {
      code: "pages.pageBreak.schema-missing",
      severity: "error",
      message: "Cannot insert a page break because the pageBreak schema is not installed.",
      recoveryHint: "Enable Pages or install TextEditorPageBreakExtension."
    }), !1;
  if (!e.dispatch)
    return dn(e, {
      code: "pages.pageBreak.command-invalid",
      severity: "warning",
      message: "Cannot insert a page break without a transaction dispatcher.",
      recoveryHint: "Run insertPageBreak() through an editable editor command."
    }), !1;
  try {
    const n = t.create(), a = Wl(e), r = e.state.tr.insert(a, n).scrollIntoView();
    return e.dispatch(r), !0;
  } catch {
    return dn(e, {
      code: "pages.pageBreak.command-invalid",
      severity: "error",
      message: "Cannot insert a page break at the current selection.",
      recoveryHint: "Move the selection into a valid top-level document block and try again."
    }), !1;
  }
}, ub = Re.create({
  name: Kt,
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !1,
  isolating: !0,
  addAttributes() {
    return {
      id: {
        default: null,
        parseHTML: (e) => e.getAttribute("data-zx-page-break-id"),
        renderHTML: (e) => typeof e.id == "string" && e.id ? {
          "data-zx-page-break-id": e.id
        } : {}
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: `div[${ma}="true"]`
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Te(e, {
        [ma]: "true",
        class: To,
        role: "separator",
        "aria-label": "Page break"
      })
    ];
  },
  addCommands() {
    return {
      insertPageBreak: () => ql
    };
  }
}), Tn = Object.freeze([
  {
    id: "plaintext",
    label: "Plain Text",
    aliases: ["plain text", "text", "txt"],
    group: "popular"
  },
  {
    id: "javascript",
    label: "JavaScript",
    aliases: ["js", "jsx"],
    group: "popular"
  },
  {
    id: "typescript",
    label: "TypeScript",
    aliases: ["ts", "tsx"],
    group: "popular"
  },
  { id: "json", label: "JSON", group: "data" },
  {
    id: "bash",
    label: "Shell",
    aliases: ["sh", "shell", "zsh", "console"],
    group: "shell"
  },
  { id: "html", label: "HTML", group: "web" },
  { id: "css", label: "CSS", group: "web" },
  { id: "scss", label: "SCSS", group: "web" },
  { id: "less", label: "Less", group: "web" },
  { id: "graphql", label: "GraphQL", aliases: ["gql"], group: "web" },
  { id: "markdown", label: "Markdown", aliases: ["md"], group: "data" },
  { id: "yaml", label: "YAML", aliases: ["yml"], group: "data" },
  { id: "ini", label: "INI / TOML", aliases: ["toml"], group: "data" },
  { id: "sql", label: "SQL", group: "data" },
  { id: "xml", label: "XML", aliases: ["svg"], group: "data" },
  { id: "diff", label: "Diff", aliases: ["patch"], group: "data" },
  {
    id: "makefile",
    label: "Makefile",
    aliases: ["make", "mk"],
    group: "shell"
  },
  { id: "python", label: "Python", aliases: ["py"], group: "other" },
  { id: "java", label: "Java", group: "other" },
  { id: "kotlin", label: "Kotlin", aliases: ["kt"], group: "other" },
  { id: "go", label: "Go", aliases: ["golang"], group: "other" },
  { id: "rust", label: "Rust", aliases: ["rs"], group: "other" },
  { id: "c", label: "C", group: "other" },
  { id: "cpp", label: "C++", aliases: ["c++", "cc"], group: "other" },
  { id: "csharp", label: "C#", aliases: ["c#", "cs"], group: "other" },
  {
    id: "objectivec",
    label: "Objective-C",
    aliases: ["objc", "objective-c"],
    group: "other"
  },
  { id: "swift", label: "Swift", group: "other" },
  { id: "ruby", label: "Ruby", aliases: ["rb"], group: "other" },
  { id: "php", label: "PHP", group: "other" },
  { id: "perl", label: "Perl", aliases: ["pl"], group: "other" },
  { id: "lua", label: "Lua", group: "other" },
  { id: "r", label: "R", group: "other" },
  { id: "vbnet", label: "VB.NET", aliases: ["vb"], group: "other" },
  { id: "arduino", label: "Arduino", aliases: ["ino"], group: "other" },
  { id: "wasm", label: "WebAssembly", group: "other" }
]), wn = (e) => e.trim().toLowerCase().replace(/\s+/g, " "), Yl = (e) => {
  const t = typeof e == "string" ? wn(e) : "";
  return t ? Tn.find(
    (n) => {
      var a;
      return n.id === t || ((a = n.aliases) == null ? void 0 : a.some((r) => wn(r) === t));
    }
  ) ?? null : null;
}, gb = (e) => {
  var t;
  return ((t = Ya(e)) == null ? void 0 : t.id) ?? "plaintext";
}, Ya = (e) => Yl(e), mb = (e) => {
  var t;
  return ((t = Ya(e)) == null ? void 0 : t.label) ?? (e && e.trim() ? e.trim() : "Plain Text");
}, pb = (e = "") => {
  const t = wn(e);
  return t ? Tn.filter((n) => [n.id, n.label, ...n.aliases ?? []].some((r) => wn(r).includes(t))) : [...Tn];
}, fb = (e = Tn, t = null) => {
  const n = [
    (t == null ? void 0 : t.defaultLanguage) ?? null,
    ...(t == null ? void 0 : t.recentLanguages) ?? []
  ].map(
    (r) => typeof r == "string" ? Ya(r) : null
  ).filter((r) => !!r).map((r) => r.id), a = new Map(
    [...new Set(n)].map((r, o) => [r, o])
  );
  return [...e].sort((r, o) => {
    const s = a.get(r.id) ?? Number.POSITIVE_INFINITY, i = a.get(o.id) ?? Number.POSITIVE_INFINITY;
    return s - i;
  });
}, Xl = [
  "contractVersion",
  "language",
  "detectedLanguage",
  "filename",
  "caption",
  "showLineNumbers",
  "startLine",
  "wrap",
  "collapsed",
  "previewLines",
  "heightMode",
  "height",
  "theme",
  "highlightLines",
  "copyMode",
  "variant",
  "groupId",
  "tabLabel",
  "defaultSource"
], qo = (e, t) => Object.prototype.hasOwnProperty.call(e, t), Lt = (e) => typeof e == "string" && e.trim() ? e.trim() : null, bt = (e, t, n, a) => {
  if (typeof e == "boolean") return e;
  if (!(e == null || e === "")) {
    if (!a.strictJson && typeof e == "string") {
      if (e === "true") return !0;
      if (e === "false") return !1;
    }
    Je(n, {
      code: "codeBlock.attr.invalid",
      severity: "warning",
      path: t,
      message: `Invalid boolean value "${String(
        e
      )}" was discarded; default ${String(a.defaultValue)} applies.`
    });
  }
}, va = (e, t, n) => {
  if (e == null || e === "") return;
  const a = typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null;
  if (a !== null && a > 0) return a;
  Je(n, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: t,
    message: `Invalid legacy height value "${String(e)}" was discarded.`
  });
}, Zl = (e) => {
  if (!e) return null;
  const t = e.match(/(?:^|\s)language-([^\s]+)/);
  return (t == null ? void 0 : t[1]) ?? null;
}, ne = (e, t) => (e == null ? void 0 : e[t]) ?? (e == null ? void 0 : e[t.replace(/-([a-z])/g, (n, a) => a.toUpperCase())]), Fr = (e, t, n, a, r) => bt(ne(e, t), n, r, {
  defaultValue: a
}), te = (e, t, n) => {
  n != null && (e[t] = n);
}, Jl = (e, t) => JSON.stringify(e) !== JSON.stringify(t), Tt = (e, t, n, a) => {
  if (n == null || a === void 0 || a === null)
    return;
  const r = Ge(
    { [t]: n },
    { explicitKeys: [t] }
  ).attrs[t], o = Ge(
    { [t]: a },
    { explicitKeys: [t], source: "migration" }
  ).attrs[t];
  Jl(r, o) && Je(e, {
    code: "codeBlock.legacy.conflict",
    severity: "warning",
    path: `attrs.${t}`,
    message: `Legacy ${t} conflicts with V2 ${t}; V2 value was kept.`
  });
}, jl = (e, t) => {
  const n = e.attrs ?? {}, a = e.htmlDataset, r = {};
  if (Xl.forEach((o) => {
    qo(n, o) && (r[o] = n[o]);
  }), a && (te(r, "language", ne(a, "zxCodeLanguage")), te(r, "filename", ne(a, "zxCodeFilename")), te(r, "caption", ne(a, "zxCodeCaption")), te(
    r,
    "showLineNumbers",
    Fr(
      a,
      "zxCodeShowLineNumbers",
      "attrs.showLineNumbers",
      !0,
      t
    )
  ), te(r, "startLine", ne(a, "zxCodeStartLine")), te(r, "wrap", ne(a, "zxCodeWrap")), te(
    r,
    "collapsed",
    Fr(
      a,
      "zxCodeCollapsed",
      "attrs.collapsed",
      !1,
      t
    )
  ), te(r, "previewLines", ne(a, "zxCodePreviewLines")), te(r, "heightMode", ne(a, "zxCodeHeightMode")), te(r, "height", ne(a, "zxCodeHeight")), te(r, "theme", ne(a, "zxCodeTheme")), te(
    r,
    "highlightLines",
    ne(a, "zxCodeHighlightLines")
  ), te(r, "copyMode", ne(a, "zxCodeCopyMode")), te(r, "variant", ne(a, "zxCodeVariant")), te(r, "groupId", ne(a, "zxCodeGroupId")), te(r, "tabLabel", ne(a, "zxCodeTabLabel"))), typeof r.highlightLines == "string")
    try {
      r.highlightLines = JSON.parse(r.highlightLines);
    } catch {
      r.highlightLines = [];
    }
  return r;
}, Ql = (e, t) => {
  const n = e.attrs ?? {}, a = e.htmlDataset, r = {};
  te(r, "language", Lt(n.language)), te(r, "filename", Lt(n.title)), te(
    r,
    "collapsed",
    bt(n.collapsed, "legacy.collapsed", t, {
      defaultValue: !1,
      strictJson: !0
    })
  ), te(
    r,
    "showLineNumbers",
    bt(n.showLineNumbers, "legacy.showLineNumbers", t, {
      defaultValue: !0,
      strictJson: !0
    })
  );
  const o = va(n.height, "legacy.height", t);
  if (o !== void 0 && (r.height = o, r.heightMode = "fixed"), a) {
    r.language === void 0 && te(
      r,
      "language",
      Lt(ne(a, "language"))
    ), r.filename === void 0 && te(
      r,
      "filename",
      Lt(ne(a, "title"))
    ), r.collapsed === void 0 && te(
      r,
      "collapsed",
      bt(
        ne(a, "collapsed"),
        "legacy.data-collapsed",
        t,
        {
          defaultValue: !1
        }
      )
    ), r.showLineNumbers === void 0 && te(
      r,
      "showLineNumbers",
      bt(
        ne(a, "showLineNumbers"),
        "legacy.data-show-line-numbers",
        t,
        {
          defaultValue: !0
        }
      )
    );
    const s = va(
      ne(a, "height"),
      "legacy.data-height",
      t
    );
    s !== void 0 && r.height === void 0 && (r.height = s, r.heightMode = "fixed");
  }
  return r.language === void 0 && te(r, "language", Zl(e.className)), r;
}, Yo = (e) => {
  const t = [], n = jl(e, t), a = Ql(e, t), r = n.contractVersion === lc || Object.keys(n).some((m) => m !== "contractVersion"), o = { ...n }, s = new Set(Object.keys(n)), i = /* @__PURE__ */ new Set(), c = e.htmlDataset;
  c && (Tt(
    t,
    "language",
    n.language,
    Lt(ne(c, "language"))
  ), Tt(
    t,
    "filename",
    n.filename,
    Lt(ne(c, "title"))
  ), Tt(
    t,
    "collapsed",
    n.collapsed,
    bt(
      ne(c, "collapsed"),
      "legacy.data-collapsed",
      t,
      {
        defaultValue: !1
      }
    )
  ), Tt(
    t,
    "showLineNumbers",
    n.showLineNumbers,
    bt(
      ne(c, "showLineNumbers"),
      "legacy.data-show-line-numbers",
      t,
      {
        defaultValue: !0
      }
    )
  ), Tt(
    t,
    "height",
    n.height,
    va(ne(c, "height"), "legacy.data-height", t)
  )), Object.entries(a).forEach(([m, g]) => {
    if (g !== void 0) {
      if (!qo(o, m) || o[m] === void 0 || o[m] === null || o[m] === "") {
        o[m] = g, s.add(m), i.add(m);
        return;
      }
      Tt(t, m, o[m], g);
    }
  });
  const l = {}, d = typeof o.defaultSource == "object" && o.defaultSource ? o.defaultSource : {};
  s.forEach((m) => {
    d[m] === void 0 && (l[m] = i.has(m) ? "migration" : "node-explicit");
  }), o.defaultSource = {
    ...d,
    ...l
  };
  const u = Ge(o, {
    source: r ? "node-explicit" : "migration",
    explicitKeys: s
  });
  return {
    attrs: u.attrs,
    diagnostics: [...t, ...u.diagnostics],
    migrated: !r || Object.keys(a).length > 0
  };
}, ed = (e) => "dataset" in e ? { ...e.dataset } : Object.fromEntries(
  Object.entries(e).filter(
    ([, t]) => typeof t == "string" || t === void 0
  )
), td = (e) => "className" in e && typeof e.className == "string" ? e.className : typeof e.class == "string" ? String(e.class) : "", nd = (e) => Yo({
  htmlDataset: ed(e),
  className: td(e)
}), Ee = (e, t, n, a = {}) => {
  a.omit || n === null || n === void 0 || n === "" || (e[t] = typeof n == "string" ? n : JSON.stringify(n));
}, Xa = (e) => {
  const { attrs: t } = Yo({
    attrs: e
  }), n = {
    "data-zx-code-block": "v2"
  };
  return Ee(n, "data-zx-code-language", t.language), Ee(n, "data-zx-code-filename", t.filename), Ee(n, "data-zx-code-caption", t.caption), Ee(n, "data-zx-code-show-line-numbers", t.showLineNumbers), Ee(n, "data-zx-code-start-line", t.startLine, {
    omit: t.startLine === 1
  }), Ee(n, "data-zx-code-wrap", t.wrap, {
    omit: t.wrap === "inherit"
  }), Ee(n, "data-zx-code-collapsed", t.collapsed, {
    omit: t.collapsed === !1
  }), Ee(n, "data-zx-code-preview-lines", t.previewLines), Ee(n, "data-zx-code-height-mode", t.heightMode, {
    omit: t.heightMode === "max"
  }), Ee(n, "data-zx-code-height", t.height), Ee(n, "data-zx-code-theme", t.theme), Ee(
    n,
    "data-zx-code-highlight-lines",
    t.highlightLines,
    { omit: t.highlightLines.length === 0 }
  ), Ee(n, "data-zx-code-copy-mode", t.copyMode, {
    omit: t.copyMode === "plain"
  }), Ee(n, "data-zx-code-variant", t.variant, {
    omit: t.variant === "code"
  }), Ee(n, "data-zx-code-group-id", t.groupId), Ee(n, "data-zx-code-tab-label", t.tabLabel), n;
}, zr = "<!-- zx-code-block:", ad = 16384, Xo = [
  "filename",
  "caption",
  "showLineNumbers",
  "startLine",
  "wrap",
  "collapsed",
  "previewLines",
  "heightMode",
  "height",
  "theme",
  "highlightLines",
  "copyMode",
  "variant",
  "groupId",
  "tabLabel"
], rd = {
  filename: "",
  caption: "",
  showLineNumbers: !0,
  startLine: 1,
  wrap: "inherit",
  collapsed: !1,
  previewLines: null,
  heightMode: "max",
  height: null,
  theme: null,
  highlightLines: [],
  copyMode: "plain",
  variant: "code",
  groupId: null,
  tabLabel: ""
}, od = (e) => typeof e == "object" && e !== null, Zo = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? `
` : (e.content ?? []).map(Zo).join(""), sd = (e) => {
  const t = e.trim();
  return !t.startsWith(zr) || !t.endsWith("-->") ? null : t.slice(zr.length, -3).trim();
}, id = (e) => {
  const t = e.match(/^(`{3,}|~{3,})(.*)$/);
  if (!t) return null;
  const n = t[1], a = (t[2] ?? "").trim();
  return {
    marker: n,
    markerChar: n[0],
    markerLength: n.length,
    language: a.split(/\s+/)[0] || null
  };
}, cd = (e, t, n) => {
  const a = e.trim();
  return a.startsWith(t.repeat(n)) && [...a].every((r) => r === t);
}, Jo = (e) => {
  const t = [];
  if (!e)
    return { attrs: {}, diagnostics: t };
  if (e.length > ad)
    return {
      attrs: {},
      diagnostics: [
        {
          code: "codeBlock.markdown.sidecarInvalid",
          severity: "warning",
          path: "markdown.sidecar",
          message: "Code block sidecar exceeds the supported size limit."
        }
      ]
    };
  try {
    const n = JSON.parse(e);
    if (!od(n))
      throw new Error("sidecar must be an object");
    const a = {};
    return Object.entries(n).forEach(([r, o]) => {
      if (Xo.includes(r)) {
        a[r] = o;
        return;
      }
      Je(t, {
        code: "codeBlock.markdown.unsupportedField",
        severity: "warning",
        path: `markdown.sidecar.${r}`,
        message: `Unsupported code block sidecar field "${r}" was ignored.`
      });
    }), { attrs: a, diagnostics: t };
  } catch {
    return {
      attrs: {},
      diagnostics: [
        {
          code: "codeBlock.markdown.sidecarInvalid",
          severity: "warning",
          path: "markdown.sidecar",
          message: "Code block sidecar JSON could not be parsed."
        }
      ]
    };
  }
}, Hr = (e, t, n) => {
  const a = id(e[t] ?? "");
  if (!a) return null;
  const r = [];
  let o = t + 1;
  for (; o < e.length; o += 1) {
    const s = e[o] ?? "";
    if (cd(s, a.markerChar, a.markerLength))
      return {
        token: {
          type: "zx_code_block",
          raw: (n ? e.slice(t - 1, o + 1) : e.slice(t, o + 1)).join(`
`),
          text: r.join(`
`),
          language: a.language,
          sidecarRaw: n
        },
        nextIndex: o + 1
      };
    r.push(s);
  }
  return null;
}, ld = (e, t) => {
  const n = sd(e[t] ?? "");
  return n !== null ? Hr(e, t + 1, n) : Hr(e, t, null);
}, dd = (e) => {
  const t = e, n = Jo(t.sidecarRaw);
  return [
    {
      type: "codeBlock",
      attrs: Ge(
        {
          ...n.attrs,
          language: t.language || void 0,
          defaultSource: Object.fromEntries(
            Object.keys(n.attrs).map((r) => [r, "node-explicit"])
          )
        },
        {
          explicitKeys: [
            ...Object.keys(n.attrs),
            ...t.language ? ["language"] : []
          ]
        }
      ).attrs,
      content: t.text ? [
        {
          type: "text",
          text: t.text
        }
      ] : void 0
    }
  ];
}, ud = (e) => Math.max(2, ...Array.from(e.matchAll(/`+/g), (t) => t[0].length)), gd = (e, t, n) => e === "highlightLines" ? Array.isArray(t) && t.length > 0 : e === "copyMode" && t === "markdown" ? (Je(n, {
  code: "codeBlock.markdown.unsupportedField",
  severity: "info",
  path: "attrs.copyMode",
  message: "copyMode markdown is preserved in sidecar but external Markdown renderers may ignore it."
}), !0) : e === "theme" && t ? (Je(n, {
  code: "codeBlock.markdown.unsupportedField",
  severity: "info",
  path: "attrs.theme",
  message: "theme is preserved in sidecar but external Markdown renderers may ignore it."
}), !0) : (e === "groupId" || e === "tabLabel") && t ? (Je(n, {
  code: "codeBlock.markdown.unsupportedField",
  severity: "info",
  path: `attrs.${e}`,
  message: "Tab metadata is preserved in sidecar but multi-code-block tabs are deferred."
}), !0) : JSON.stringify(t) !== JSON.stringify(rd[e]), Za = (e) => {
  const t = Zo(e), n = Ge(
    e.attrs ?? {}
  ), a = n.attrs, r = [...n.diagnostics], o = {};
  a.detectedLanguage && Je(r, {
    code: "codeBlock.markdown.unsupportedField",
    severity: "info",
    path: "attrs.detectedLanguage",
    message: "detectedLanguage is runtime metadata and is not exported to Markdown."
  }), Xo.forEach((d) => {
    const u = a[d];
    gd(d, u, r) && (o[d] = u);
  });
  const s = "`".repeat(ud(t) + 1), i = a.language ? a.language : "", c = `${s}${i || ""}
${t}
${s}`;
  return {
    markdown: Object.keys(o).length ? `<!-- zx-code-block: ${JSON.stringify(o)} -->
${c}` : c,
    diagnostics: r
  };
}, bb = () => ({
  blockTokenizers: [ld],
  tokenParsers: {
    zx_code_block: (e) => dd(e)
  },
  nodeSerializers: {
    codeBlock: (e) => Za(e).markdown
  }
}), md = [
  "contractVersion",
  "language",
  "detectedLanguage",
  "filename",
  "caption",
  "showLineNumbers",
  "startLine",
  "wrap",
  "collapsed",
  "previewLines",
  "heightMode",
  "height",
  "theme",
  "highlightLines",
  "copyMode",
  "variant",
  "groupId",
  "tabLabel",
  "defaultSource"
], pd = (e) => nd(e).attrs, fd = (e) => e.getAttribute("data-block-id") || e.getAttribute("data-blockid") || e.getAttribute("data-blockId") || null, bd = (e) => {
  const t = typeof e.blockId == "string" ? e.blockId.trim() : "";
  return t ? { "data-block-id": t } : {};
}, hb = () => ({
  blockId: {
    default: null,
    parseHTML: fd,
    renderHTML: bd
  },
  ...Object.fromEntries(
    md.map((e) => [
      e,
      {
        default: Ge({}).attrs[e],
        parseHTML: (t) => pd(t)[e],
        renderHTML: (t) => e === "contractVersion" ? Xa(t) : {}
      }
    ])
  )
}), hd = ({ state: e }) => {
  const { $from: t } = e.selection;
  let n = t.depth;
  for (; n > 0 && t.node(n).type.name !== "codeBlock"; )
    n -= 1;
  return n > 0 ? t.node(n).attrs : {};
}, Zt = (e, t) => {
  const n = {
    ...e,
    ...t
  }, a = Ge(
    n,
    {
      explicitKeys: Object.keys(n)
    }
  );
  return {
    ...e,
    ...a.attrs
  };
}, Rn = (e, t) => {
  var n;
  return typeof ((n = e.attrs) == null ? void 0 : n.blockId) == "string" && e.attrs.blockId.trim() ? e.attrs.blockId.trim() : `path:${t.join(".")}`;
}, Dn = (e, t, n, a, r = !1) => {
  var o;
  a(e, t, n), (o = e.forEach) == null || o.call(e, (s, i, c) => {
    Dn(s, t + i + (r ? 0 : 1), [...n, c], a);
  });
}, yb = () => (e) => (t) => {
  const n = hd(t);
  return t.commands.updateAttributes(
    "codeBlock",
    Zt(n, e)
  );
}, Eb = () => (e, t) => ({ state: n, dispatch: a }) => {
  const r = Number.isFinite(e) ? n.doc.nodeAt(e) : null;
  return !r || r.type.name !== "codeBlock" ? !1 : (a && a(
    n.tr.setNodeMarkup(
      e,
      void 0,
      Zt(r.attrs, t)
    )
  ), !0);
}, _b = () => (e, t) => ({ state: n, dispatch: a }) => {
  if (!e.trim()) return !1;
  let r = null;
  Dn(
    n.doc,
    0,
    [],
    (s, i, c) => {
      var l;
      r || ((l = s.type) == null ? void 0 : l.name) !== "codeBlock" || Rn(s, c) === e && (r = { node: s, pos: i });
    },
    !0
  );
  const o = r;
  return o ? (a && a(
    n.tr.setNodeMarkup(
      o.pos,
      void 0,
      Zt(o.node.attrs, t)
    )
  ), !0) : !1;
}, yd = (e) => new Map(
  e.items.filter((t) => t.status === "will-change").map((t) => [t.blockId, t])
), Sb = () => (e) => ({ state: t, dispatch: n }) => {
  const a = yd(e);
  if (!a.size) return !1;
  const r = t.tr;
  let o = 0;
  const s = (i, c, l) => {
    var d;
    if (((d = i.type) == null ? void 0 : d.name) === "codeBlock") {
      const u = Rn(i, l), m = a.get(u);
      m && (r.setNodeMarkup(
        c,
        void 0,
        Zt(i.attrs, m.after)
      ), o += 1);
    }
  };
  return Dn(t.doc, 0, [], s, !0), o ? (r.setMeta("codeBlockBulkPreview", {
    scope: e.scope,
    changed: o
  }), n == null || n(r), !0) : !1;
}, kb = () => (e) => ({ state: t, dispatch: n }) => {
  const a = new Map(
    e.filter((s) => s.blockId.trim()).map((s) => [s.blockId, s.attrs])
  );
  if (!a.size) return !1;
  const r = t.tr;
  let o = 0;
  return Dn(
    t.doc,
    0,
    [],
    (s, i, c) => {
      var d;
      if (((d = s.type) == null ? void 0 : d.name) !== "codeBlock") return;
      const l = a.get(Rn(s, c));
      l && (r.setNodeMarkup(
        i,
        void 0,
        Zt(s.attrs, l)
      ), o += 1);
    },
    !0
  ), o ? (r.setMeta("codeBlockTabsEdit", { changed: o }), n == null || n(r), !0) : !1;
}, vb = () => (e, t) => ({ state: n, dispatch: a }) => {
  if (!e.trim()) return !1;
  let r = null;
  const o = (i, c, l, d = !1) => {
    var E, _, k, S;
    if (r) return;
    const u = [];
    (E = i.forEach) == null || E.call(i, (y, x, C) => {
      const O = [...l, C], P = c + x + (d ? 0 : 1);
      u.push({ node: y, pos: P, path: O });
    });
    const m = u.findIndex(
      (y) => {
        var x;
        return ((x = y.node.type) == null ? void 0 : x.name) === "codeBlock" && Rn(y.node, y.path) === e;
      }
    ), g = t === "previous" ? m - 1 : m === -1 ? -1 : m + 1, f = u[m], b = u[g];
    if (f && ((_ = b == null ? void 0 : b.node.type) == null ? void 0 : _.name) === "codeBlock") {
      const y = typeof ((k = f.node.attrs) == null ? void 0 : k.groupId) == "string" ? f.node.attrs.groupId.trim() : "", x = typeof ((S = b.node.attrs) == null ? void 0 : S.groupId) == "string" ? b.node.attrs.groupId.trim() : "";
      if (y && y === x) {
        const C = t === "previous" ? b : f, O = t === "previous" ? f : b;
        r = {
          from: C.pos,
          to: O.pos + O.node.nodeSize,
          nodes: t === "previous" ? [f.node, b.node] : [b.node, f.node]
        };
        return;
      }
    }
    u.forEach(
      (y) => o(y.node, y.pos, y.path, !1)
    );
  };
  o(n.doc, 0, [], !0);
  const s = r;
  if (!s) return !1;
  if (a) {
    const i = n.tr.replaceWith(
      s.from,
      s.to,
      s.nodes
    );
    i.setMeta("codeBlockTabsReorder", { blockId: e, direction: t }), a(i);
  }
  return !0;
}, Ed = [
  "code",
  "text",
  "markdown",
  "payload",
  "raw",
  "snippet",
  "filename",
  "caption",
  "content",
  "user",
  "token",
  "secret"
], _d = (e) => e <= 0 ? "empty" : e <= 200 ? "short" : e <= 2e3 ? "medium" : e <= 2e4 ? "long" : "over-budget", jo = (e) => e <= 10 ? "0-10ms" : e <= 50 ? "11-50ms" : e <= 100 ? "51-100ms" : e <= 500 ? "101-500ms" : "over-500ms", Sd = (e) => {
  const t = e.toLowerCase();
  return Ed.some(
    (n) => t.includes(n)
  );
}, kd = (e = {}) => {
  const t = {};
  return Object.entries(e).forEach(([n, a]) => {
    Sd(n) || (typeof a == "string" || typeof a == "number" || typeof a == "boolean" || a === null) && (t[n] = a);
  }), t;
}, $e = (e) => ({
  type: e.type,
  status: e.status,
  diagnosticCodes: Array.from(
    new Set((e.diagnostics ?? []).map((t) => t.code))
  ),
  metadata: kd(e.metadata)
}), Ue = (e, t) => {
  e == null || e(t);
}, $r = {
  maxChars: 2e4,
  maxCandidates: 3,
  confidenceThreshold: 0.65,
  timeoutMs: 50,
  allowedProviders: ["local-heuristic"]
}, tt = (e, t, n, a) => ({
  code: e,
  severity: t,
  path: n,
  message: a
}), vd = (e) => Math.min(Math.max(Number.isFinite(e) ? e : 0, 0), 1), ze = (e, t, n) => ({
  language: e,
  confidence: vd(t),
  source: "local-heuristic",
  reason: n
}), Td = (e) => {
  const t = e.trim(), n = [];
  if (!t) return n;
  if (/^[\[{]/.test(t) && /[\]}]$/.test(t) || /^\s*"(?:[^"]+)":/m.test(t))
    try {
      JSON.parse(t), n.push(ze("json", 0.96, "valid-json"));
    } catch {
      /^\s*"(?:[^"]+)":/m.test(t) && n.push(ze("json", 0.68, "json-like-key-value"));
    }
  return (/^#!.*\b(?:bash|sh|zsh)\b/m.test(t) || /^\s*(?:pnpm|npm|yarn|git|curl|docker|kubectl|cd|echo|set -e)\b/m.test(
    t
  ) || /^\s*export\s+[A-Za-z_]\w*=/m.test(t)) && n.push(ze("bash", 0.88, "shell-command-patterns")), (/\b(?:interface|type)\s+\w+/.test(t) || /\b(?:const|let|var)\s+\w+\s*:\s*[\w<{]/.test(t) || /\bas\s+const\b/.test(t)) && n.push(ze("typescript", 0.86, "typescript-syntax")), (/\b(?:import|export)\s+/.test(t) || /\b(?:const|let|var|function)\s+\w+/.test(t) || /\bconsole\.log\(/.test(t)) && n.push(ze("javascript", 0.78, "javascript-syntax")), /^\s*<[a-z][\w-]*(\s|>|\/>)/im.test(t) && n.push(ze("html", 0.86, "html-tag-patterns")), /^\s*[$.#]?[a-z][\w-]*\s*\{[\s\S]*\}/im.test(t) && n.push(
    ze(
      /[$&]|\bnesting\b/.test(t) ? "scss" : "css",
      0.74,
      "stylesheet-block"
    )
  ), /^\s*[\w.-]+\s*:\s+.+$/m.test(t) && !/[{};]/.test(t) && n.push(ze("yaml", 0.76, "yaml-key-value")), (/^\s{0,3}#{1,6}\s+\S/m.test(t) || /^```/m.test(t)) && n.push(ze("markdown", 0.74, "markdown-markup")), n.length || n.push(ze("plaintext", 0.55, "no-strong-language-signal")), n;
}, wd = () => ({
  provider: "local-heuristic",
  detect: (e) => Td(e.code)
}), Nd = (e) => {
  const t = Fa(e.language, {
    source: e.source === "local-heuristic" ? "detected" : "explicit"
  });
  return {
    normalized: t,
    candidate: {
      ...e,
      language: t.supported === !1 ? null : t.id
    }
  };
}, nt = (e, t, n) => ({
  status: e,
  candidates: t,
  diagnostics: n
}), Tb = async (e, t = {}) => {
  const n = Date.now(), a = {
    ...$r,
    ...e,
    currentLanguage: e.currentLanguage ?? null,
    allowedProviders: e.allowedProviders ?? $r.allowedProviders
  }, r = [], o = t.detector ?? wd(), s = (i) => (Ue(
    t.onEvent,
    $e({
      type: "language-detection",
      status: i.status === "success" ? "success" : "degraded",
      diagnostics: i.diagnostics,
      metadata: {
        provider: o.provider,
        result: i.status,
        candidateCount: i.candidates.length,
        lengthBucket: _d(a.code.length),
        durationBucket: jo(Date.now() - n)
      }
    })
  ), i);
  if (!a.allowedProviders.includes(o.provider))
    return s(
      nt(
        "disabled",
        [],
        [
          tt(
            "codeBlock.languageDetection.disabled",
            "info",
            "provider",
            "Language detection provider is disabled by host policy."
          )
        ]
      )
    );
  if (!a.code.trim())
    return s(
      nt(
        "empty",
        [],
        [
          tt(
            "codeBlock.languageDetection.empty",
            "info",
            "code",
            "Empty code text was not detected."
          )
        ]
      )
    );
  if (a.code.length > a.maxChars)
    return s(
      nt(
        "failed",
        [],
        [
          tt(
            "codeBlock.languageDetection.overBudget",
            "warning",
            "code",
            "Code text exceeds the configured local detection budget."
          )
        ]
      )
    );
  o.provider === "host-explicit-remote" && r.push(
    tt(
      "codeBlock.languageDetection.remoteOptIn",
      "info",
      "provider",
      "Remote language detection is host-provided and must be explicit opt-in."
    )
  );
  try {
    const i = await o.detect(a);
    if (Date.now() - n > a.timeoutMs)
      return s(
        nt(
          "timeout",
          [],
          [
            ...r,
            tt(
              "codeBlock.languageDetection.timeout",
              "warning",
              "timeoutMs",
              "Language detection exceeded the configured timeout."
            )
          ]
        )
      );
    const l = i.map((g) => Nd(g)).sort((g, f) => f.candidate.confidence - g.candidate.confidence), d = l.find(
      (g) => g.normalized.supported === !1
    ), u = l.filter((g) => g.normalized.supported !== !1).map((g) => g.candidate).slice(0, Math.max(a.maxCandidates, 1)), m = u[0];
    return d && !u.length ? s(
      nt(
        "unsupported",
        [],
        [
          ...r,
          ...d.normalized.diagnostics,
          tt(
            "codeBlock.languageDetection.unsupported",
            "warning",
            "candidate.language",
            "Detected language is not supported by the code block capability map."
          )
        ]
      )
    ) : !m || m.confidence < a.confidenceThreshold ? s(
      nt("low-confidence", u, [
        ...r,
        tt(
          "codeBlock.languageDetection.lowConfidence",
          "info",
          "candidate.confidence",
          "Language detection confidence is below the configured threshold."
        )
      ])
    ) : s(nt("success", u, r));
  } catch {
    return s(
      nt(
        "failed",
        [],
        [
          ...r,
          tt(
            "codeBlock.languageDetection.failed",
            "warning",
            "provider",
            "Language detection failed without exposing code text."
          )
        ]
      )
    );
  }
}, xd = 32, wb = () => {
  const e = /* @__PURE__ */ new Map();
  return {
    enqueue(t) {
      if (t.trim()) {
        if (!e.has(t) && e.size >= xd) {
          const n = e.keys().next().value;
          n !== void 0 && e.delete(n);
        }
        e.set(t, (e.get(t) ?? 0) + 1);
      }
    },
    consume(t) {
      const n = e.get(t);
      return n ? (n > 1 ? e.set(t, n - 1) : e.delete(t), !0) : !1;
    },
    get size() {
      return e.size;
    }
  };
}, Cd = (e) => typeof e == "object" && e !== null && typeof e.enqueue == "function" && typeof e.consume == "function", Nb = (e) => {
  const t = e == null ? void 0 : e.pendingLanguageDetection;
  return Cd(t) ? t : null;
}, xb = (e, t = 0) => {
  if (e.status !== "success") return null;
  const n = e.candidates[t];
  return n != null && n.language ? {
    language: n.language,
    detectedLanguage: n.language,
    defaultSource: {
      language: "node-explicit",
      detectedLanguage: "node-explicit"
    }
  } : null;
}, rt = "codeBlock.preferences", Ja = {
  recentLanguages: [],
  defaultLanguage: null,
  defaultWrap: null,
  defaultShowLineNumbers: null,
  defaultCopyMode: null,
  rememberLastSettings: !1
}, Ad = {
  language: null,
  wrap: "inherit",
  showLineNumbers: !0,
  copyMode: "plain"
}, Nn = (e, t, n, a) => ({
  code: e,
  severity: t,
  path: n,
  message: a
}), Md = /* @__PURE__ */ new Set(["inherit", "off", "on"]), Id = /* @__PURE__ */ new Set(["plain", "markdown"]), Qo = (e) => typeof e == "string" && Md.has(e) ? e : null, es = (e) => typeof e == "string" && Id.has(e) ? e : null, xn = (e, t, n) => {
  const a = Fa(
    typeof e == "string" ? e : null
  );
  return t.push(...a.diagnostics), a.supported === !1 && t.push(
    Nn(
      "codeBlock.preferences.unsupportedLanguage",
      "warning",
      n,
      "Unsupported preference language was downgraded."
    )
  ), a.supported === !1 ? null : a.id;
}, Et = (e) => {
  const t = [];
  return {
    preferences: {
      recentLanguages: Array.from(
        new Set(
          ((e == null ? void 0 : e.recentLanguages) ?? []).map(
            (a, r) => xn(
              a,
              t,
              `preferences.recentLanguages.${r}`
            )
          ).filter((a) => !!a)
        )
      ),
      defaultLanguage: xn(
        (e == null ? void 0 : e.defaultLanguage) ?? null,
        t,
        "preferences.defaultLanguage"
      ),
      defaultWrap: Qo(e == null ? void 0 : e.defaultWrap),
      defaultShowLineNumbers: typeof (e == null ? void 0 : e.defaultShowLineNumbers) == "boolean" ? e.defaultShowLineNumbers : null,
      defaultCopyMode: es(e == null ? void 0 : e.defaultCopyMode),
      rememberLastSettings: (e == null ? void 0 : e.rememberLastSettings) === !0
    },
    diagnostics: t
  };
}, Od = (e, t) => {
  var a;
  return !e || !(t in e) || e[t] === void 0 ? !1 : ((a = e.defaultSource) == null ? void 0 : a[t]) !== "platform-default";
}, Ld = (e, t, n, a) => {
  var s, i, c, l, d;
  const r = (s = t.oneOff) == null ? void 0 : s[e];
  if (r !== void 0)
    return a[e] = r, "node-explicit";
  if (Od(t.nodeAttrs, e))
    return a[e] = (i = t.nodeAttrs) == null ? void 0 : i[e], ((l = (c = t.nodeAttrs) == null ? void 0 : c.defaultSource) == null ? void 0 : l[e]) ?? "node-explicit";
  const o = e === "language" ? n.defaultLanguage : e === "wrap" ? n.defaultWrap : e === "showLineNumbers" ? n.defaultShowLineNumbers : n.defaultCopyMode;
  return o != null ? (a[e] = o, "user-preference") : (a[e] = ((d = t.platformDefaults) == null ? void 0 : d[e]) ?? Ad[e], "platform-default");
}, Rd = (e = {}) => {
  const t = Et(e.preferences), n = {}, a = {};
  return ["language", "wrap", "showLineNumbers", "copyMode"].forEach(
    (r) => {
      a[r] = Ld(
        r,
        e,
        t.preferences,
        n
      );
    }
  ), n.defaultSource = a, {
    attrs: n,
    diagnostics: t.diagnostics
  };
}, Cb = (e, t, n = {}) => {
  const a = Et(e), r = {
    ...Ja,
    ...a.preferences
  }, o = [...a.diagnostics];
  if (t.language && n.rememberRecentLanguage === !0) {
    const s = xn(
      t.language,
      o,
      "selection.language"
    );
    s && (r.recentLanguages = [
      s,
      ...r.recentLanguages.filter((i) => i !== s)
    ].slice(0, 8));
  }
  return n.setAsDefault === !0 && (t.language !== void 0 && (r.defaultLanguage = xn(
    t.language,
    o,
    "selection.language"
  )), t.wrap !== void 0 && (r.defaultWrap = Qo(t.wrap)), t.showLineNumbers !== void 0 && (r.defaultShowLineNumbers = t.showLineNumbers), t.copyMode !== void 0 && (r.defaultCopyMode = es(t.copyMode))), {
    preferences: r,
    diagnostics: o
  };
}, Dd = (e) => ({
  ...Ja,
  ...Et(e).preferences,
  recentLanguages: []
}), Ab = async (e, t = {}) => {
  if (!e) {
    const n = [
      Nn(
        "codeBlock.preferences.disabled",
        "info",
        rt,
        "Host preference adapter is disabled."
      )
    ];
    return Ue(
      t.onEvent,
      $e({
        type: "preference-read",
        status: "degraded",
        diagnostics: n,
        metadata: { namespace: rt }
      })
    ), {
      preferences: null,
      diagnostics: n
    };
  }
  try {
    const n = await e.read(), a = Et(n);
    return Ue(
      t.onEvent,
      $e({
        type: "preference-read",
        status: "success",
        diagnostics: a.diagnostics,
        metadata: { namespace: rt }
      })
    ), a;
  } catch {
    const n = [
      Nn(
        "codeBlock.preferences.readFailed",
        "warning",
        rt,
        "Host preference adapter read failed; platform defaults were used."
      )
    ];
    return Ue(
      t.onEvent,
      $e({
        type: "preference-read",
        status: "degraded",
        diagnostics: n,
        metadata: { namespace: rt }
      })
    ), {
      preferences: null,
      diagnostics: n
    };
  }
}, Mb = async (e, t, n = {}) => {
  const a = Et(t);
  if (!e) {
    const r = [
      Nn(
        "codeBlock.preferences.disabled",
        "info",
        rt,
        "Host preference adapter is disabled."
      )
    ];
    return Ue(
      n.onEvent,
      $e({
        type: "preference-write",
        status: "cancelled",
        diagnostics: r,
        metadata: { namespace: rt }
      })
    ), {
      ok: !1,
      diagnostics: r
    };
  }
  return await e.write(a.preferences), Ue(
    n.onEvent,
    $e({
      type: "preference-write",
      status: "success",
      diagnostics: a.diagnostics,
      metadata: { namespace: rt }
    })
  ), {
    ok: !0,
    diagnostics: a.diagnostics
  };
}, Ib = (e = null) => {
  let t = Et(e).preferences;
  return {
    async read() {
      return t;
    },
    async write(n) {
      t = Et(n).preferences;
    },
    async clear(n = "all") {
      t = n === "recent-languages" ? Dd(t) : { ...Ja };
    }
  };
}, Bd = (e, t, n, a) => ({
  code: e,
  severity: t,
  path: n,
  message: a
}), ja = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? `
` : (e.content ?? []).map(ja).join(""), ts = (e) => e.attrs ?? {}, Pd = (e) => {
  var t;
  return e.scope === "group" && ((t = e.groupBlocks) != null && t.length) ? e.groupBlocks : [e.block];
}, Fd = (e, t) => e.map((n) => {
  const a = wo({
    code: ja(n),
    attrs: ts(n)
  });
  return t.push(...a.diagnostics), a.copy.text;
}).join(e.length > 1 ? `

` : ""), zd = (e, t) => e.map((n, a) => {
  const r = Za(n);
  t.push(...r.diagnostics);
  const o = dc({
    code: ja(n),
    attrs: ts(n)
  }), s = za({
    surface: "markdown-serializer",
    descriptor: o
  });
  return t.push(...s.diagnostics), (o.display.filename || o.display.caption || o.display.highlightLines.length || o.attrs.groupId || o.attrs.tabLabel || o.attrs.copyMode !== "plain") && t.push(
    Bd(
      "codeBlock.copy.markdownSidecarRequired",
      "info",
      `blocks.${a}`,
      "Markdown copy uses zx-code-block sidecar to preserve code block metadata."
    )
  ), r.markdown;
}).join(`

`), Hd = (e) => e.some((t) => t.severity === "error") ? "failed" : e.length ? "degraded" : "success", Ob = (e, t = {}) => {
  const n = Date.now(), a = [], r = Pd(e), o = e.mode === "plain" ? Fd(r, a) : zd(r, a), s = {
    status: Hd(a),
    mimeType: e.mode === "plain" ? "text/plain" : "text/markdown",
    text: o,
    diagnostics: a
  };
  return Ue(
    t.onEvent,
    $e({
      type: "copy",
      status: s.status,
      diagnostics: a,
      metadata: {
        mode: e.mode,
        scope: e.scope,
        result: s.status,
        durationBucket: jo(Date.now() - n)
      }
    })
  ), s;
}, Lb = (e, t) => ({
  type: "codeBlock",
  attrs: t,
  content: e ? [{ type: "text", text: e }] : []
}), ns = (e, t, n, a) => ({
  code: e,
  severity: t,
  path: n,
  message: a
}), Rb = (e) => {
  const t = uc(e);
  return t === "" ? 1 : t.split(`
`).length;
}, $d = (e, t, n, a) => {
  const r = Math.round(e.from), o = Math.round(e.to ?? e.from);
  return !Number.isFinite(r) || !Number.isFinite(o) || r < 1 || o < r || o > n ? (a.push(
    ns(
      "codeBlock.highlight.invalidRange",
      "warning",
      `highlightLines.${t}`,
      "Invalid highlight range was rejected or dropped."
    )
  ), null) : { from: r, to: o };
}, ea = (e = [], t, n = {}) => {
  const a = [], r = e.flatMap((s, i) => {
    const c = $d(s, i, t, a);
    return c ? [c] : [];
  });
  if (n.interactive && a.length)
    return {
      status: "failed",
      ranges: [],
      diagnostics: a
    };
  if (r.sort((s, i) => s.from - i.from || s.to - i.to), n.interactive) {
    const s = r.findIndex((i, c) => {
      const l = r[c - 1];
      return !!(l && i.from <= l.to);
    });
    if (s > 0)
      return a.push(
        ns(
          "codeBlock.highlight.overlappingRange",
          "warning",
          `highlightLines.${s}`,
          "Overlapping highlight ranges are rejected before writing."
        )
      ), {
        status: "failed",
        ranges: [],
        diagnostics: a
      };
  }
  const o = [];
  return r.forEach((s) => {
    const i = o[o.length - 1];
    if (!i || s.from > i.to + 1) {
      o.push({ ...s });
      return;
    }
    i.to = Math.max(i.to, s.to);
  }), {
    status: "success",
    ranges: o.map(
      (s) => s.from === s.to ? { from: s.from } : s
    ),
    diagnostics: a
  };
}, Ud = (e, t) => {
  let n = e.map((a) => ({
    from: a.from,
    to: a.to ?? a.from
  }));
  return t.forEach((a) => {
    const r = a.from, o = a.to ?? a.from;
    n = n.flatMap((s) => o < s.from || r > s.to ? [s] : [
      r > s.from ? { from: s.from, to: r - 1 } : null,
      o < s.to ? { from: o + 1, to: s.to } : null
    ].filter((i) => !!i));
  }), n.map(
    (a) => a.from === a.to ? { from: a.from } : a
  );
}, Db = (e, t = {}) => {
  const n = ea(
    e.currentRanges ?? [],
    e.lineCount
  ), a = ea(
    e.edit.ranges,
    e.lineCount,
    {
      interactive: e.interactive
    }
  ), r = [...n.diagnostics, ...a.diagnostics];
  if (e.interactive && a.status === "failed") {
    const c = {
      status: "failed",
      ranges: n.ranges,
      patch: null,
      diagnostics: r
    };
    return Ue(
      t.onEvent,
      $e({
        type: "highlight-edit",
        status: "failed",
        diagnostics: r,
        metadata: { mode: e.edit.mode }
      })
    ), c;
  }
  const o = e.edit.mode === "add" ? ea(
    [...n.ranges, ...a.ranges],
    e.lineCount,
    {
      interactive: e.interactive
    }
  ) : null;
  if (e.interactive && (o == null ? void 0 : o.status) === "failed") {
    const c = [...r, ...o.diagnostics], l = {
      status: "failed",
      ranges: n.ranges,
      patch: null,
      diagnostics: c
    };
    return Ue(
      t.onEvent,
      $e({
        type: "highlight-edit",
        status: "failed",
        diagnostics: c,
        metadata: { mode: e.edit.mode }
      })
    ), l;
  }
  const s = e.edit.mode === "clear" ? [] : e.edit.mode === "replace" ? a.ranges : e.edit.mode === "add" ? (o == null ? void 0 : o.ranges) ?? [] : Ud(n.ranges, a.ranges), i = {
    status: "success",
    ranges: s,
    patch: {
      highlightLines: s
    },
    diagnostics: r
  };
  return Ue(
    t.onEvent,
    $e({
      type: "highlight-edit",
      status: r.some(
        (c) => c.severity === "warning"
      ) ? "degraded" : "success",
      diagnostics: r,
      metadata: { mode: e.edit.mode, rangeCount: s.length }
    })
  ), i;
}, Bb = (e) => e.split(",").map((t) => t.trim()).filter(Boolean).flatMap((t) => {
  const n = t.match(/^(\d+)(?:\s*-\s*(\d+))?$/);
  if (!n) return [{ from: Number.NaN }];
  const a = Number.parseInt(n[1], 10), r = n[2] ? Number.parseInt(n[2], 10) : void 0;
  return [{ from: a, ...r ? { to: r } : {} }];
}), Pb = (e) => e.map((t) => t.to ? `${t.from}-${t.to}` : `${t.from}`).join(", "), Gd = /* @__PURE__ */ new Set([
  "c",
  "cpp",
  "csharp",
  "css",
  "go",
  "java",
  "javascript",
  "js",
  "jsx",
  "less",
  "rust",
  "scss",
  "typescript",
  "ts",
  "tsx"
]), Kd = /* @__PURE__ */ new Set(["python", "py", "ruby", "yaml", "yml"]), Vd = /* @__PURE__ */ new Set(["diff", "html", "markdown", "md", "xml"]), Wd = /* @__PURE__ */ new Set(["plaintext", "text", "txt"]), qd = /* @__PURE__ */ new Set([
  "javascript",
  "js",
  "jsx",
  "typescript",
  "ts",
  "tsx"
]), as = (e) => {
  const t = (e == null ? void 0 : e.trim().toLowerCase()) || null;
  return t === "json" ? "brace-json" : t && Gd.has(t) ? "brace-c-comments" : t && Kd.has(t) ? "indent-hash-comments" : t && Vd.has(t) ? "region-only" : t && Wd.has(t) ? "none" : "indent-only";
}, Yd = {
  "(": ")",
  "[": "]",
  "{": "}"
}, Xd = {
  ")": "(",
  "]": "[",
  "}": "{"
}, Zd = 64, Jd = (e, t) => {
  const n = e.match(
    /^(?:\/\/|#)\s*#?(region|endregion)(?=$|[^A-Za-z0-9_])/i
  );
  return !n || t && n[0].length === e.length ? null : n[1].toLowerCase() === "region" ? "start" : "end";
}, jd = (e) => e.profile === "brace-json" ? !1 : e.profile === "brace-c-comments" ? e.window.endsWith("String.raw") || e.window.endsWith('R"') || e.window.endsWith('r"') || e.window.endsWith("r#") || e.window.endsWith('@"') || e.window.endsWith('"""') : e.profile === "indent-hash-comments" || e.profile === "indent-only" ? e.window.endsWith("'''") || e.window.endsWith('"""') || e.window.endsWith("String.raw") || e.window.endsWith("r#") || e.window.endsWith("<<") || (e.language === "yaml" || e.language === "yml") && (e.char === "|" || e.char === ">") : !1, Qd = (e) => {
  var oe;
  const t = as(e.language), n = ((oe = e.language) == null ? void 0 : oe.trim().toLowerCase()) ?? "", a = t === "indent-hash-comments" || t === "indent-only", r = t === "brace-c-comments" || t === "brace-json", o = t === "brace-c-comments", s = [], i = [], c = [], l = [], d = [];
  let u = 0, m = 0, g = !1;
  const f = /* @__PURE__ */ new Set();
  let b = !1, E = !1, _ = null, k = !1, S = null, y = null, x = null;
  const C = (L) => {
    m = Math.max(m, L), L > e.budget.maxNestingDepth && (g = !0);
  }, O = (L) => {
    if (!(L.endLine <= L.startLine || g)) {
      if (s.length >= e.budget.maxCandidates) {
        g = !0;
        return;
      }
      s.push(L);
    }
  }, P = (L = [
    "region",
    "comment",
    "bracket",
    "indent"
  ]) => {
    L.forEach((Z) => f.add(Z));
  }, G = (L) => {
    for (L.ambiguous && (E = !0); !g && d.length && L.columns <= d[d.length - 1].indent; ) {
      const Z = d.pop();
      Z && y && O({
        startLine: Z.startLine,
        endLine: y.line,
        kind: "indent",
        depth: Z.depth
      });
    }
    if (!g && y && L.columns > y.indent) {
      const Z = d.length + 1;
      C(Z), g || d.push({
        indent: y.indent,
        startLine: y.line,
        depth: Z
      });
    }
    y = { indent: L.columns, line: L.line }, x = L.line;
  };
  for (let L = 0; L < e.lines.length && !g; L += 1) {
    const Z = e.lines[L] ?? "", V = L + 1, re = Math.max(
      0,
      e.budget.maxScannedCharacters - u
    );
    if (Z.length > re) {
      u += re, g = !0;
      break;
    }
    const be = !r || _ === null && S === null;
    let we = "", H = !1, se = "", me = !1, de = 0, ue = !1, Me = !1, _t = !1;
    for (let ie = 0; ie < Z.length && !g; ie += 1) {
      if (u >= e.budget.maxScannedCharacters) {
        g = !0;
        break;
      }
      u += 1;
      const J = Z[ie], Ne = Z[ie + 1];
      if (se = `${se}${J}`.slice(-16), jd({
        window: se,
        char: J,
        profile: t,
        language: n
      }) && P(), me || (J === " " ? (ue = !0, de += 1) : J === "	" ? (Me = !0, de += 2) : /\s/.test(J) || (me = !0, a && !(t === "indent-hash-comments" && J === "#") && G({
        columns: de,
        ambiguous: ue && Me,
        line: V
      }))), me && (we.length < Zd ? we += J : H = !0), !r) continue;
      if (S) {
        if (o && J === "/" && Ne === "*" && P(), J === "*" && Ne === "/") {
          if (O({
            startLine: S.line,
            endLine: V,
            kind: "comment",
            depth: S.depth
          }), g) break;
          S = null, ie += 1, u < e.budget.maxScannedCharacters ? u += 1 : ie < Z.length && (g = !0);
        }
        continue;
      }
      if (_t) continue;
      if (_) {
        if (k) {
          k = !1;
          continue;
        }
        if (J === "\\") {
          k = !0;
          continue;
        }
        J === _ && (_ = null);
        continue;
      }
      if (qd.has(n) && J === "/" && Ne !== "/" && Ne !== "*" && P(["bracket"]), t === "brace-json" && (J === "'" || J === "/" && (Ne === "/" || Ne === "*"))) {
        P();
        continue;
      }
      if (o && J === "/" && Ne === "/") {
        _t = !0;
        continue;
      }
      if (o && J === "/" && Ne === "*") {
        const Be = l.length + 1;
        if (C(Be), g) break;
        S = { line: V, depth: Be }, ie += 1, u < e.budget.maxScannedCharacters ? u += 1 : ie < Z.length && (g = !0);
        continue;
      }
      if (J === '"' || t === "brace-c-comments" && (J === "'" || J === "`")) {
        _ = J;
        continue;
      }
      const Bt = Yd[J];
      if (Bt) {
        const Be = l.length + 1;
        C(Be), g || l.push({ open: J, close: Bt, line: V, depth: Be });
        continue;
      }
      const Ke = Xd[J];
      if (!Ke) continue;
      const je = l[l.length - 1];
      if (!je || je.open !== Ke) {
        b = !0, l.length = 0;
        continue;
      }
      l.pop(), O({
        startLine: je.line,
        endLine: V,
        kind: "bracket",
        depth: je.depth
      });
    }
    if (g) break;
    const it = be ? Jd(we, H) : null;
    if (it === "start") {
      const ie = c.length + 1;
      C(ie), g || c.push({ line: V, depth: ie });
    } else if (it === "end") {
      const ie = c.pop();
      ie && O({
        startLine: ie.line,
        endLine: V,
        kind: "region",
        depth: ie.depth
      });
    }
  }
  if (!g && t === "indent-hash-comments" && x !== null)
    for (; d.length; ) {
      const L = d.pop();
      L && O({
        startLine: L.startLine,
        endLine: x,
        kind: "indent",
        depth: L.depth
      });
    }
  if (g)
    return {
      status: "budget-exceeded",
      candidates: [],
      diagnostics: [
        pa({
          code: "codeBlock.folding.scanBudgetExceeded",
          severity: "warning",
          path: "folding",
          message: "The bounded folding scanner exhausted its deterministic budget."
        })
      ],
      metrics: {
        scannedCharacters: u,
        candidateCount: s.length,
        maxObservedDepth: m
      }
    };
  const K = /* @__PURE__ */ new Set();
  return f.size && (f.forEach((L) => K.add(L)), i.push(
    pa({
      code: "codeBlock.folding.lexicalHazard",
      severity: "info",
      path: "folding.language",
      message: "An undeclared lexical construct was detected; ambiguous fallback ranges were discarded."
    })
  )), S && K.add("comment"), (b || l.length || _ || S) && K.add("bracket"), E && K.add("indent"), {
    status: "complete",
    candidates: s.filter(
      (L) => !K.has(L.kind)
    ),
    diagnostics: i,
    metrics: {
      scannedCharacters: u,
      candidateCount: s.length,
      maxObservedDepth: m
    }
  };
}, rs = {
  "(": ")",
  "[": "]",
  "{": "}"
}, eu = Object.fromEntries(
  Object.entries(rs).map(([e, t]) => [t, e])
), tu = (e) => {
  let t = 0;
  for (const n of e) {
    if (n === " ") {
      t += 1;
      continue;
    }
    if (n === "	") {
      t += 2;
      continue;
    }
    break;
  }
  return t;
}, nu = (e) => {
  let t = "", n = null, a = !1;
  for (let r = 0; r < e.length; r += 1) {
    const o = e[r], s = e[r + 1];
    if (n) {
      if (t += " ", a) {
        a = !1;
        continue;
      }
      if (o === "\\") {
        a = !0;
        continue;
      }
      o === n && (n = null);
      continue;
    }
    if (o === "/" && s === "/") break;
    if (o === "'" || o === '"' || o === "`") {
      n = o, t += " ";
      continue;
    }
    t += o;
  }
  return t;
}, Yt = (e, t) => {
  if (t.endLine <= t.startLine) return;
  const n = e.get(t.startLine);
  (!n || t.endLine > n.endLine) && e.set(t.startLine, t);
}, au = (e, t) => {
  let n = null;
  const a = [];
  e.forEach((r, o) => {
    const s = o + 1, i = r.trim();
    if (n === null && /\/\*\*?/.test(r)) {
      const c = r.indexOf("/*");
      r.indexOf("*/", c + 2) === -1 && (n = s);
    } else n !== null && r.includes("*/") && (Yt(t, {
      startLine: n,
      endLine: s,
      kind: "comment"
    }), n = null);
    if (/^(\/\/|#)\s*region\b/i.test(i)) {
      a.push(s);
      return;
    }
    if (/^(\/\/|#)\s*endregion\b/i.test(i)) {
      const c = a.pop();
      c && Yt(t, {
        startLine: c,
        endLine: s,
        kind: "region"
      });
    }
  });
}, ru = (e, t) => {
  const n = [];
  e.forEach((a, r) => {
    const o = nu(a), s = r + 1;
    for (const i of o) {
      const c = rs[i];
      if (c) {
        n.push({ open: i, close: c, line: s });
        continue;
      }
      if (!eu[i]) continue;
      let d = -1;
      for (let m = n.length - 1; m >= 0; m -= 1)
        if (n[m].close === i) {
          d = m;
          break;
        }
      if (d === -1) continue;
      const [u] = n.splice(d, 1);
      Yt(t, {
        startLine: u.line,
        endLine: s,
        kind: "bracket"
      });
    }
  });
}, ou = (e, t) => {
  const n = [];
  let a = null, r = null;
  for (e.forEach((o, s) => {
    if (!o.trim()) return;
    const i = s + 1, c = tu(o);
    for (; n.length && c <= n[n.length - 1].indent; ) {
      const l = n.pop();
      l && a && Yt(t, {
        startLine: l.startLine,
        endLine: a.lineNumber,
        kind: "indent"
      });
    }
    a && c > a.indent && n.push({
      indent: a.indent,
      startLine: a.lineNumber
    }), a = { indent: c, lineNumber: i }, r = i;
  }); n.length; ) {
    const o = n.pop();
    o && r !== null && Yt(t, {
      startLine: o.startLine,
      endLine: r,
      kind: "indent"
    });
  }
}, su = (e) => {
  const t = /* @__PURE__ */ new Map();
  return au(e, t), ru(e, t), ou(e, t), [...t.values()].sort(
    (n, a) => n.startLine === a.startLine ? n.endLine - a.endLine : n.startLine - a.startLine
  );
}, Fb = (e) => su(e), wt = Object.freeze({
  maxLines: 5e3,
  maxCharacters: 2e5,
  maxLineLength: 2e4,
  maxCandidates: 1e3,
  maxNestingDepth: 128,
  maxScannedCharacters: 2e5
}), zb = "folding-safety/v1", Nt = (e, t) => typeof e == "number" && Number.isFinite(e) && e >= 0 ? Math.floor(e) : t, Qa = (e = {}) => ({
  maxLines: Nt(
    e.maxLines,
    wt.maxLines
  ),
  maxCharacters: Nt(
    e.maxCharacters,
    wt.maxCharacters
  ),
  maxLineLength: Nt(
    e.maxLineLength,
    wt.maxLineLength
  ),
  maxCandidates: Nt(
    e.maxCandidates,
    wt.maxCandidates
  ),
  maxNestingDepth: Nt(
    e.maxNestingDepth,
    wt.maxNestingDepth
  ),
  maxScannedCharacters: Nt(
    e.maxScannedCharacters,
    wt.maxScannedCharacters
  )
}), Hb = (e = {}) => {
  const t = Qa(e);
  return [
    t.maxLines,
    t.maxCharacters,
    t.maxLineLength,
    t.maxCandidates,
    t.maxNestingDepth,
    t.maxScannedCharacters
  ].join(":");
}, $b = (e, t) => e === "inherit" ? t ?? "off" : e, Ub = (e) => {
  const t = [0];
  for (let n = 0; n < e.length; n += 1) {
    const a = e[n];
    a !== `
` && a !== "\r" || (a === "\r" && e[n + 1] === `
` && (n += 1), t.push(n + 1));
  }
  return t;
}, iu = (e) => ({
  lineCount: e.lines.length,
  characterCount: Number.isFinite(e.characterCount) && e.characterCount >= 0 ? Math.floor(e.characterCount) : e.lines.reduce(
    (t, n, a) => t + n.length + (a === e.lines.length - 1 ? 0 : 1),
    0
  ),
  maxLineLength: e.lines.reduce(
    (t, n) => Math.max(t, n.length),
    0
  )
}), cu = (e) => {
  const t = Qa(e.budget), n = iu(e);
  return e.effectiveWrap === "on" && !e.wrapAlignmentSupported ? { status: "disabled", reason: "wrap-unsupported", metrics: n } : n.lineCount > t.maxLines ? { status: "disabled", reason: "line-budget", metrics: n } : n.characterCount > t.maxCharacters ? { status: "disabled", reason: "character-budget", metrics: n } : n.maxLineLength > t.maxLineLength ? { status: "disabled", reason: "long-line-budget", metrics: n } : as(e.language) === "none" ? { status: "disabled", reason: "unsupported-language", metrics: n } : e.visible ? e.blockCollapsed ? { status: "deferred", reason: "block-collapsed", metrics: n } : e.foldingRequested ? { status: "enabled", reason: "ready", metrics: n } : { status: "deferred", reason: "gutter-not-requested", metrics: n } : { status: "deferred", reason: "not-visible", metrics: n };
}, lu = (e) => {
  if (e.status === "enabled" || e.status === "deferred")
    return null;
  const t = {
    "wrap-unsupported": "The lightweight code surface cannot prove gutter alignment while wrapping.",
    "line-budget": "The code block exceeds the folding line budget.",
    "character-budget": "The code block exceeds the folding character budget.",
    "long-line-budget": "The code block exceeds the longest-line folding budget.",
    "unsupported-language": "The selected language has no safe lightweight folding profile.",
    "scan-budget-exceeded": "The bounded folding scanner exhausted its deterministic budget."
  };
  return pa({
    code: e.reason === "wrap-unsupported" ? "codeBlock.folding.wrapAlignmentUnsupported" : `codeBlock.folding.${e.reason}`,
    severity: "warning",
    path: "folding",
    message: t[e.reason]
  });
}, du = (e) => {
  let t = 2166136261;
  for (let n = 0; n < e.length; n += 1)
    t ^= e.charCodeAt(n), t = Math.imul(t, 16777619);
  return (t >>> 0).toString(36);
}, xt = {
  region: 0,
  comment: 1,
  bracket: 2,
  indent: 3
}, uu = (e, t) => e.startLine < t.startLine && t.startLine <= e.endLine && e.endLine < t.endLine || t.startLine < e.startLine && e.startLine <= t.endLine && t.endLine < e.endLine, gu = (e, t) => {
  const n = /* @__PURE__ */ new Map();
  for (const o of t) {
    if (!Number.isInteger(o.startLine) || !Number.isInteger(o.endLine) || o.startLine < 1 || o.endLine > e.length || o.endLine <= o.startLine)
      continue;
    const s = n.get(o.startLine);
    (!s || xt[o.kind] < xt[s.kind] || o.kind === s.kind && o.endLine > s.endLine) && n.set(o.startLine, o);
  }
  const a = [...n.values()].sort(
    (o, s) => xt[o.kind] - xt[s.kind] || o.startLine - s.startLine || s.endLine - o.endLine
  ), r = [];
  for (const o of a)
    r.some((s) => uu(s, o)) || r.push(o);
  return r.sort(
    (o, s) => o.startLine - s.startLine || s.endLine - o.endLine || xt[o.kind] - xt[s.kind]
  ).map((o) => {
    const s = e[o.startLine - 1] ?? "", i = e[o.endLine - 1] ?? "", c = o.endLine - o.startLine, l = {
      startText: s,
      endText: i,
      span: c,
      depth: o.depth
    }, d = du(
      `${o.kind}\0${s}\0${i}\0${c}\0${o.depth}`
    );
    return {
      startLine: o.startLine,
      endLine: o.endLine,
      kind: o.kind,
      source: "fallback",
      key: `fallback:${o.kind}:${o.startLine}:${o.endLine}:${d}`,
      anchor: l
    };
  });
}, mu = Object.freeze({
  scannedCharacters: 0,
  candidateCount: 0,
  maxObservedDepth: 0
}), pu = (e) => {
  const t = lu(e);
  return {
    decision: e,
    scanStatus: "not-run",
    ranges: [],
    diagnostics: t ? [t] : [],
    scanMetrics: mu
  };
}, Gb = (e) => {
  const t = cu(e);
  if (t.status !== "enabled")
    return pu(t);
  const n = Qd({
    lines: e.lines,
    language: e.language,
    budget: Qa(e.budget)
  });
  return n.status === "budget-exceeded" ? {
    decision: {
      ...t,
      status: "disabled",
      reason: "scan-budget-exceeded"
    },
    scanStatus: "budget-exceeded",
    ranges: [],
    diagnostics: n.diagnostics,
    scanMetrics: n.metrics
  } : {
    decision: t,
    scanStatus: "complete",
    ranges: gu(e.lines, n.candidates),
    diagnostics: n.diagnostics,
    scanMetrics: n.metrics
  };
}, fu = (e, t) => e.startText === t.startText && e.endText === t.endText && e.span === t.span && e.depth === t.depth, Bn = (e, t) => e.source === t.source && e.kind === t.kind && fu(e.anchor, t.anchor), Cn = (e, t) => {
  const n = [], a = /* @__PURE__ */ new Set();
  for (const r of e) {
    const o = t.filter(
      (s) => Bn(r, s)
    );
    o.length !== 1 || a.has(o[0].key) || (a.add(o[0].key), n.push({ intent: r, range: o[0] }));
  }
  return n.map(({ range: r }) => ({
    state: n.some(
      ({ range: s }) => s.key !== r.key && s.startLine <= r.startLine && s.endLine >= r.endLine
    ) ? "suspended" : "active",
    source: r.source,
    kind: r.kind,
    anchor: { ...r.anchor }
  }));
}, bu = (e) => {
  const t = e.ranges.find(
    (r) => r.key === e.rangeKey
  );
  if (!t) return Cn(e.previous, e.ranges);
  const n = e.previous.filter(
    (r) => !Bn(r, t)
  ), a = e.folded ? [
    ...n,
    {
      state: "active",
      source: t.source,
      kind: t.kind,
      anchor: { ...t.anchor }
    }
  ] : n;
  return Cn(a, e.ranges);
}, Kb = (e) => {
  const t = e.ranges.find(
    (a) => a.key === e.rangeKey
  );
  if (!t) return Cn(e.previous, e.ranges);
  const n = !e.previous.some(
    (a) => Bn(a, t)
  );
  return bu({ ...e, folded: n });
}, Vb = (e) => {
  var c;
  const t = Cn(
    e.activeIntents,
    e.ranges
  ), n = e.ranges.filter(
    (l) => t.some(
      (d) => d.state === "active" && Bn(d, l)
    )
  ), a = new Map(
    n.map((l) => [l.startLine, l])
  ), r = new Map(
    e.ranges.map((l) => [l.startLine, l])
  ), o = [];
  let s = 0;
  e.lines.forEach((l, d) => {
    o.push(s), s += l.length + (d === e.lines.length - 1 ? 0 : 1);
  });
  const i = [];
  for (let l = 0; l < e.lines.length; l += 1) {
    const d = l + 1, u = a.get(d), m = u ?? r.get(d) ?? null;
    i.push({
      lineIndex: l,
      lineNumber: e.lineNumbers[l] ?? d,
      fromOffset: ((c = e.lineOffsets) == null ? void 0 : c[l]) ?? o[l] ?? 0,
      text: e.lines[l] ?? "",
      rangeKey: (m == null ? void 0 : m.key) ?? null,
      folded: !!u,
      hiddenLineCount: u ? Math.max(0, u.endLine - u.startLine) : 0
    }), u && (l = u.endLine - 1);
  }
  return i;
}, os = {
  longCodePreviewThreshold: 40,
  longCodePreviewLines: 24,
  longCodeMaxBodyHeight: "420px",
  newBlockDefaults: {
    showLineNumbers: !0,
    wrap: "inherit",
    collapsed: !1,
    previewLines: null
  }
}, hu = [
  "showLineNumbers",
  "wrap",
  "collapsed",
  "previewLines"
], yu = (e, t) => Object.prototype.hasOwnProperty.call(e, t), Ta = (e, t) => !yu(e, t) || e[t] === void 0 ? !1 : (typeof e.defaultSource == "object" && e.defaultSource ? e.defaultSource[t] : null) !== "platform-default", ss = (e, t) => ({
  ...typeof e.defaultSource == "object" && e.defaultSource ? e.defaultSource : {},
  ...Object.fromEntries(
    t.map((n) => [n, "platform-default"])
  )
}), Eu = (e = {}, t = os) => {
  const n = {
    ...e
  }, a = [];
  return hu.forEach((r) => {
    if (!Ta(n, r)) {
      switch (r) {
        case "showLineNumbers":
          n.showLineNumbers = t.newBlockDefaults.showLineNumbers;
          break;
        case "wrap":
          n.wrap = t.newBlockDefaults.wrap;
          break;
        case "collapsed":
          n.collapsed = t.newBlockDefaults.collapsed;
          break;
        case "previewLines":
          n.previewLines = t.newBlockDefaults.previewLines;
          break;
      }
      a.push(r);
    }
  }), a.length > 0 && (n.defaultSource = ss(n, a)), n;
}, _u = (e, t = os) => {
  const n = {
    ...e.attrs ?? {}
  }, a = e.model ?? wo({
    code: e.code,
    attrs: n
  }), r = [], o = a.lines.visualLineCount > t.longCodePreviewThreshold, s = Ta(n, "collapsed"), i = Ta(n, "previewLines");
  return o && !s && (n.collapsed = !1, r.push("collapsed")), o && !i && (n.previewLines = s && n.collapsed === !0 ? t.longCodePreviewLines : null, r.push("previewLines")), r.length > 0 && (n.defaultSource = ss(n, r)), n;
}, Su = (e, t) => Ge(e, {
  explicitKeys: t ?? Object.keys(e)
}), Ur = (e) => e === "slash" || e === "toolbar" || e === "markdown-fence", ku = (e) => e === "paste" || e === "file-intake", is = (e, t) => {
  const n = {
    ...e.attrs ?? {}
  }, a = Fa(e.language);
  e.language !== void 0 && (n.language = a.id);
  const r = Ur(e.source) ? Rd({
    nodeAttrs: n,
    preferences: e.preferences,
    platformDefaults: {
      showLineNumbers: (t == null ? void 0 : t.newBlockDefaults.showLineNumbers) ?? void 0,
      wrap: (t == null ? void 0 : t.newBlockDefaults.wrap) ?? void 0
    }
  }) : null, o = r ? {
    ...n,
    ...r.attrs,
    defaultSource: {
      ...n.defaultSource ?? {},
      ...r.attrs.defaultSource ?? {}
    }
  } : n, s = Ur(e.source) ? Eu(o, t) : o, i = ku(e.source) && e.code ? _u(
    {
      code: e.code,
      attrs: s
    },
    t
  ) : s, c = Su(i);
  return {
    attrs: c.attrs,
    diagnostics: [...a.diagnostics, ...c.diagnostics]
  };
}, Wb = (e, t) => {
  const n = e.code ?? "";
  return {
    type: "codeBlock",
    attrs: is(e, t).attrs,
    content: n ? [{ type: "text", text: n }] : []
  };
}, cs = (e) => {
  var t;
  return typeof e.text == "string" ? e.text : ((t = e.content) == null ? void 0 : t.map(cs).join("")) ?? "";
}, vu = (e, t, n) => {
  var a;
  if (e.type === "codeBlock") {
    const r = e.attrs ?? {}, o = cs(e), s = is(
      {
        code: o,
        attrs: r,
        source: t
      },
      n
    );
    return {
      ...e,
      attrs: s.attrs
    };
  }
  return (a = e.content) != null && a.length ? {
    ...e,
    content: e.content.map(
      (r) => vu(r, t, n)
    )
  } : e;
}, qb = [
  "paragraph",
  "heading-1",
  "heading-2",
  "heading-3",
  "heading-4",
  "heading-5",
  "heading-6",
  "bullet-list",
  "ordered-list",
  "task-list",
  "blockquote",
  "code-block"
], Yb = [
  "none",
  "text-style",
  "stored-mark",
  "block-default",
  "fallback"
], Tu = {
  cssValue: "16px",
  displayValue: "16px"
}, wu = {
  cssValue: "'Helvetica Neue', Helvetica, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', Arial, sans-serif",
  displayValue: "Default"
}, Nu = {
  cssValue: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace",
  displayValue: "Monospace"
}, Rt = (e, t) => Object.prototype.hasOwnProperty.call(e, t), wa = (e) => e ? {
  cssValue: e.cssValue,
  ...Rt(e, "displayValue") ? { displayValue: e.displayValue } : {}
} : void 0, Gr = (e, t) => t ? {
  cssValue: t.cssValue,
  ...Rt(t, "displayValue") ? { displayValue: t.displayValue } : Rt(e ?? {}, "displayValue") ? { displayValue: e == null ? void 0 : e.displayValue } : {}
} : wa(e), Kr = (e = {}, t = {}) => {
  const n = {}, a = Rt(t, "fontSize") ? Gr(e.fontSize, t.fontSize) : wa(e.fontSize), r = Rt(t, "fontFamily") ? Gr(e.fontFamily, t.fontFamily) : wa(e.fontFamily);
  return a && (n.fontSize = a), r && (n.fontFamily = r), n;
}, xu = () => ({
  paragraph: {},
  "heading-1": {
    fontSize: {
      cssValue: "2em",
      displayValue: "32px"
    }
  },
  "heading-2": {
    fontSize: {
      cssValue: "1.5em",
      displayValue: "24px"
    }
  },
  "heading-3": {
    fontSize: {
      cssValue: "1.25em",
      displayValue: "20px"
    }
  },
  "heading-4": {
    fontSize: {
      cssValue: "1.1em",
      displayValue: "18px"
    }
  },
  "heading-5": {
    fontSize: {
      cssValue: "1em",
      displayValue: "16px"
    }
  },
  "heading-6": {
    fontSize: {
      cssValue: "0.9em",
      displayValue: "14px"
    }
  },
  "bullet-list": {},
  "ordered-list": {},
  "task-list": {},
  blockquote: {},
  "code-block": {
    fontFamily: Nu,
    fontSize: {
      cssValue: "14px",
      displayValue: "14px"
    }
  }
}), ls = Object.freeze({
  root: Object.freeze({
    fontSize: Object.freeze(Tu),
    fontFamily: Object.freeze(wu)
  }),
  blocks: Object.freeze(xu()),
  fallback: Object.freeze({
    allowUnknownNodeFallback: !0
  })
}), er = (e = {}) => {
  const t = e.base ?? ls, n = e.override ?? null, a = /* @__PURE__ */ new Set([
    ...Object.keys(t.blocks),
    ...Object.keys((n == null ? void 0 : n.blocks) ?? {})
  ]), r = {};
  return a.forEach((o) => {
    var s;
    r[o] = Kr(
      t.blocks[o],
      (s = n == null ? void 0 : n.blocks) == null ? void 0 : s[o]
    );
  }), {
    root: Kr(t.root, n == null ? void 0 : n.root),
    blocks: r,
    fallback: {
      allowUnknownNodeFallback: n != null && n.fallback && Rt(n.fallback, "allowUnknownNodeFallback") ? n.fallback.allowUnknownNodeFallback : t.fallback.allowUnknownNodeFallback
    }
  };
}, tr = "zxTextEditorTypography", Xb = ae.create({
  name: tr,
  addOptions() {
    return {
      contract: er()
    };
  },
  addStorage() {
    return {
      contract: this.options.contract
    };
  }
}), ds = Re.create({
  name: "attachment",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null
      },
      display: {
        default: "card"
      },
      href: {
        default: null
      },
      fileName: {
        default: null
      },
      title: {
        default: null
      },
      mimeType: {
        default: null
      },
      fileSize: {
        default: null
      },
      sizeLabel: {
        default: null
      },
      fileKind: {
        default: null
      },
      badgeLabel: {
        default: null
      },
      downloadName: {
        default: null
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="attachment"]',
        getAttrs: (e) => ({
          assetId: e.dataset.assetId,
          display: e.dataset.display === "compact" ? "compact" : "card"
        })
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Te(this.options.HTMLAttributes, e, {
        "data-type": "attachment"
      })
    ];
  }
}), us = Eo.create({
  name: "comment",
  addOptions() {
    return {
      HTMLAttributes: {},
      onCommentActivated: void 0
    };
  },
  addAttributes() {
    return {
      commentId: {
        default: null,
        parseHTML: (e) => e.dataset.commentId,
        renderHTML: () => ({})
      },
      resolved: {
        default: !1,
        parseHTML: (e) => Object.hasOwn(e.dataset, "resolved"),
        renderHTML: () => ({})
      }
    };
  },
  parseHTML() {
    return [{ tag: "span[data-comment-id]" }];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "span",
      Te(this.options.HTMLAttributes, e, {
        class: Dt("text-editor-comment")
      }),
      0
    ];
  },
  addCommands() {
    return {
      setComment: (e) => ({ commands: t }) => t.setMark(this.name, { commentId: e }),
      unsetComment: (e) => ({ state: t, tr: n, dispatch: a }) => {
        const { doc: r } = t, o = t.schema.marks[this.name];
        return r.descendants((s, i) => (s.isText && s.marks.forEach((c) => {
          c.type === o && c.attrs.commentId === e && n.removeMark(i, i + s.nodeSize, o);
        }), !0)), n.docChanged && a ? (a(n), !0) : !1;
      },
      resolveComment: (e, t = !0) => ({ state: n, tr: a, dispatch: r }) => {
        const { doc: o } = n, s = n.schema.marks[this.name];
        return o.descendants((i, c) => (i.isText && i.marks.forEach((l) => {
          if (l.type === s && l.attrs.commentId === e) {
            const d = s.create({ ...l.attrs, resolved: t });
            a.removeMark(c, c + i.nodeSize, s), a.addMark(c, c + i.nodeSize, d);
          }
        }), !0)), a.docChanged && r ? (r(a), !0) : !1;
      }
    };
  }
}), Vr = (e) => {
  const t = typeof e.title == "string" ? e.title : typeof e["data-embed-title"] == "string" ? e["data-embed-title"] : "", n = typeof e.name == "string" ? e.name : typeof e["data-embed-name"] == "string" ? e["data-embed-name"] : "";
  return t || n;
}, gs = Re.create({
  name: "embed",
  group: "inline",
  inline: !0,
  atom: !0,
  selectable: !0,
  draggable: !1,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId,
        renderHTML: (e) => e.assetId ? { "data-asset-id": e.assetId } : {}
      },
      name: {
        default: null,
        parseHTML: (e) => e.dataset.embedName,
        renderHTML: (e) => e.name ? { "data-embed-name": e.name } : {}
      },
      title: {
        default: null,
        parseHTML: (e) => {
          var t;
          return e.dataset.embedTitle || ((t = e.textContent) == null ? void 0 : t.replace(/^\[\[|\]\]$/g, ""));
        },
        renderHTML: (e) => e.title ? { "data-embed-title": e.title } : {}
      },
      url: {
        default: null,
        parseHTML: (e) => e.getAttribute("href"),
        renderHTML: (e) => e.url ? { href: e.url } : {}
      },
      icon: {
        default: null,
        parseHTML: (e) => e.dataset.embedIcon,
        renderHTML: (e) => e.icon ? { "data-embed-icon": e.icon } : {}
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'a[data-type="embed"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e, node: t }) {
    const n = Vr(t.attrs);
    return [
      "a",
      Te(this.options.HTMLAttributes, e, {
        "data-type": "embed",
        class: Dt("text-editor-embed")
      }),
      `[[${n}]]`
    ];
  },
  renderText({ node: e }) {
    const t = Vr(e.attrs);
    return t ? `[[${t}]]` : "";
  }
}), ms = Re.create({
  name: "iframe",
  group: "block",
  selectable: !0,
  draggable: !0,
  atom: !0,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: {
        default: null,
        parseHTML: (e) => e.getAttribute("src"),
        renderHTML: (e) => ({
          src: e.src
        })
      },
      width: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("width");
          return t ? Number.parseInt(t, 10) : null;
        },
        renderHTML: (e) => ({
          width: e.width ? String(e.width) : null
        })
      },
      height: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("height");
          return t ? Number.parseInt(t, 10) : null;
        },
        renderHTML: (e) => ({
          height: e.height ? String(e.height) : null
        })
      },
      aspectRatio: {
        default: 9 / 16,
        parseHTML: () => null,
        renderHTML: () => ({})
      },
      align: {
        default: "center",
        parseHTML: (e) => {
          const t = (e.dataset.align || e.getAttribute("align") || "left").toLowerCase();
          return ["left", "center", "right"].includes(t) ? t : "left";
        },
        renderHTML: (e) => ({
          "data-align": e.align || "center"
        })
      },
      title: {
        default: null,
        parseHTML: (e) => e.getAttribute("title"),
        renderHTML: (e) => ({
          title: e.title
        })
      },
      frameborder: {
        default: "0",
        renderHTML: () => ({
          frameborder: "0"
        })
      },
      allowfullscreen: {
        default: "true",
        renderHTML: () => ({
          allowfullscreen: "true"
        })
      },
      sandbox: {
        default: "allow-scripts allow-same-origin allow-popups allow-forms",
        renderHTML: (e) => ({
          sandbox: e.sandbox
        })
      },
      interactive: {
        default: !1,
        parseHTML: (e) => e.dataset.interactive === "true",
        renderHTML: (e) => ({
          "data-interactive": e.interactive ? "true" : "false"
        })
      },
      fullWidth: {
        default: !1,
        parseHTML: (e) => e.dataset.fullWidth === "true",
        renderHTML: (e) => ({
          "data-full-width": e.fullWidth ? "true" : "false"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "iframe[src]",
        getAttrs: (e) => {
          const t = e.getAttribute("src"), n = e.getAttribute("width"), a = e.getAttribute("height"), r = e.getAttribute("title"), o = e.dataset.align;
          return {
            assetId: e.dataset.assetId ?? null,
            src: t,
            width: n ? Number.parseInt(n, 10) : null,
            height: a ? Number.parseInt(a, 10) : null,
            title: r || null,
            align: o || "center"
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "iframe",
      Te(this.options.HTMLAttributes, e, {
        loading: "lazy",
        referrerpolicy: "no-referrer-when-downgrade"
      })
    ];
  }
}), ps = Re.create({
  name: "image",
  group: "block",
  draggable: !0,
  selectable: !0,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: { default: null },
      alt: { default: null },
      title: { default: null },
      width: { default: null },
      height: { default: null },
      align: {
        default: "left",
        parseHTML: (e) => {
          const t = (e.dataset.align || e.getAttribute("align") || "left").toLowerCase();
          return ["left", "center", "right"].includes(t) ? t : "left";
        },
        renderHTML: (e) => ({
          "data-align": e.align || "left"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "img[src]",
        getAttrs: (e) => {
          if (typeof e == "string")
            return {};
          const t = e;
          return {
            assetId: t.dataset.assetId ?? null,
            src: t.getAttribute("src"),
            alt: t.getAttribute("alt"),
            title: t.getAttribute("title"),
            width: t.getAttribute("width"),
            height: t.getAttribute("height")
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "img",
      Te(this.options.HTMLAttributes || {}, e)
    ];
  }
}), fs = Re.create({
  name: "imageGroup",
  group: "block",
  content: "image+",
  selectable: !0,
  draggable: !0,
  isolating: !0,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      columns: {
        default: 4
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="image-group"]',
        getAttrs: (e) => {
          if (typeof e == "string")
            return {};
          const t = e;
          return {
            columns: t.dataset.columns ? Number(t.dataset.columns) : 4
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e, node: t }) {
    return [
      "div",
      Te(
        {
          "data-type": "image-group",
          "data-columns": t.attrs.columns
        },
        this.options.HTMLAttributes,
        e
      ),
      0
    ];
  }
}), bs = Re.create({
  name: "mention",
  group: "inline",
  inline: !0,
  selectable: !0,
  atom: !0,
  addAttributes() {
    return {
      id: {
        default: null,
        parseHTML: (e) => e.dataset.id,
        renderHTML: (e) => e.id ? { "data-id": e.id } : {}
      },
      label: {
        default: null,
        parseHTML: (e) => e.dataset.label,
        renderHTML: (e) => e.label ? { "data-label": e.label } : {}
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'span.mention[data-type="mention"]',
        getAttrs: (e) => {
          const t = e;
          return {
            id: t.dataset.id,
            label: t.dataset.label
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "span",
      Te(e, {
        class: "mention",
        "data-type": "mention"
      }),
      `@${e["data-label"] || e.id || ""}`
    ];
  },
  renderText({ node: e }) {
    return `@${e.attrs.label || e.attrs.id || ""}`;
  }
}), z = (e, t, n, a = !1) => {
  const r = `#${[e, t, n].map((o) => Math.max(0, Math.min(255, o)).toString(16).padStart(2, "0")).join("")}`;
  return a ? r.toUpperCase() : r;
}, hs = {
  black: z(0, 0, 0),
  red: z(220, 38, 38),
  blue: z(21, 121, 208, !0),
  green: z(22, 163, 74),
  yellow: z(202, 138, 4),
  orange: z(234, 88, 12),
  purple: z(147, 51, 234),
  pink: z(219, 39, 119),
  gray: z(107, 114, 128),
  indigo: z(79, 70, 229),
  teal: z(13, 148, 136),
  cyan: z(6, 182, 212)
}, ys = {
  red: z(254, 202, 202),
  blue: z(191, 219, 254),
  green: z(187, 247, 208),
  yellow: z(254, 240, 138),
  orange: z(254, 215, 170),
  purple: z(233, 213, 255),
  pink: z(251, 207, 232),
  gray: z(229, 231, 235),
  indigo: z(199, 210, 254),
  teal: z(153, 246, 228),
  cyan: z(165, 243, 252)
}, Es = {
  [z(31, 39, 46, !0)]: "gray",
  [z(202, 138, 4)]: "yellow",
  [z(234, 88, 12)]: "orange",
  [z(220, 38, 38)]: "red",
  [z(22, 163, 74)]: "green",
  [z(21, 121, 208, !0)]: "blue",
  [z(147, 51, 234)]: "purple",
  [z(219, 39, 119)]: "pink"
}, _s = {
  [z(254, 249, 195)]: "yellow",
  [z(255, 237, 213)]: "orange",
  [z(254, 226, 226)]: "red",
  [z(220, 252, 231)]: "green",
  [z(211, 233, 252, !0)]: "blue",
  [z(243, 232, 255)]: "purple",
  [z(252, 231, 243)]: "pink"
};
function Na(e, t, n, a) {
  if (a && e.startsWith("#") && a[e])
    return a[e];
  let r = 0, o = 0, s = 0;
  if (e.startsWith("#")) {
    const l = e.slice(1);
    l.length === 6 && (r = Number.parseInt(l.slice(0, 2), 16), o = Number.parseInt(l.slice(2, 4), 16), s = Number.parseInt(l.slice(4, 6), 16));
  } else if (e.startsWith("rgb")) {
    const l = /rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/i.exec(e);
    l && (r = Number.parseInt(l[1], 10), o = Number.parseInt(l[2], 10), s = Number.parseInt(l[3], 10));
  }
  if (Number.isNaN(r) || Number.isNaN(o) || Number.isNaN(s))
    return null;
  let i = null, c = Number.POSITIVE_INFINITY;
  for (const l of t) {
    const d = n[l];
    if (!d) continue;
    const u = d.startsWith("#") ? d.slice(1) : d;
    if (u.length !== 6) continue;
    const m = Number.parseInt(u.slice(0, 2), 16), g = Number.parseInt(u.slice(2, 4), 16), f = Number.parseInt(u.slice(4, 6), 16), b = Math.sqrt((r - m) ** 2 + (o - g) ** 2 + (s - f) ** 2);
    b < c && (c = b, i = l);
  }
  return i;
}
function Ss(e, t, n = hs, a = Es, r = "color") {
  const o = Object.keys(n), s = new RegExp(`${r}:\\s*(#[0-9a-f]{6})`, "i").exec(
    e
  );
  if (s && s[1]) {
    const c = Na(
      s[1],
      o,
      // Search in all colors from the map
      n,
      a
    );
    if (c && t.includes(c))
      return c === "gray" ? null : c;
  }
  const i = new RegExp(
    `${r}:\\s*(rgb\\(\\s*\\d+\\s*,\\s*\\d+\\s*,\\s*\\d+\\s*\\))`,
    "i"
  ).exec(e);
  if (i && i[1]) {
    const c = Na(
      i[1],
      o,
      // Search in all colors from the map
      n,
      a
    );
    if (c && t.includes(c))
      return c === "gray" ? null : c;
  }
  return null;
}
function Cu(e, t) {
  return Ss(
    e,
    t,
    hs,
    Es,
    "color"
  );
}
function Au(e, t) {
  return Ss(
    e,
    t,
    ys,
    _s,
    "background-color"
  );
}
const Mu = /^#(?:[0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i, Iu = /^rgba?\(\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})\s*,\s*([0-9]{1,3})(?:\s*,\s*(0|1|0?\.\d+))?\s*\)$/i, Ou = /^hsla?\(\s*([0-9]{1,3})(?:deg)?\s*,\s*([0-9]{1,3})%\s*,\s*([0-9]{1,3})%(?:\s*,\s*(0|1|0?\.\d+))?\s*\)$/i, ta = (e) => {
  const t = Number(e);
  return Number.isInteger(t) && t >= 0 && t <= 255;
}, Wr = (e) => {
  const t = Number(e);
  return Number.isFinite(t) && t >= 0 && t <= 100;
}, qr = (e) => {
  if (e === void 0) return !0;
  const t = Number(e);
  return Number.isFinite(t) && t >= 0 && t <= 1;
}, Pn = (e) => {
  const t = e.trim();
  if (!t) return !1;
  if (t === "transparent" || Mu.test(t)) return !0;
  const n = Iu.exec(t);
  if (n) {
    const [, r, o, s, i] = n;
    return ta(r) && ta(o) && ta(s) && qr(i);
  }
  const a = Ou.exec(t);
  if (a) {
    const [, r, o, s, i] = a, c = Number(r);
    return Number.isFinite(c) && c >= 0 && c <= 360 && Wr(o) && Wr(s) && qr(i);
  }
  return !1;
}, ks = (e, t) => {
  var r;
  const n = new RegExp(`(?:^|;)\\s*${t}\\s*:\\s*([^;]+)`, "i").exec(
    e
  ), a = (r = n == null ? void 0 : n[1]) == null ? void 0 : r.trim();
  return a && Pn(a) ? a : null;
}, vs = ae.create({
  name: "namedColor",
  addOptions() {
    return {
      types: ["textStyle"],
      colors: [
        "red",
        "blue",
        "green",
        "yellow",
        "orange",
        "purple",
        "pink",
        "gray",
        "teal",
        "cyan"
      ]
    };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          color: {
            default: null,
            parseHTML: (e) => {
              const t = e.getAttribute("style");
              if (t) {
                const n = t.match(
                  /color:\s*var\(--prose-color-(\w+)\)/
                );
                if (n && this.options.colors.includes(n[1]))
                  return n[1];
                const a = ks(t, "color");
                if (a)
                  return a;
                const r = Cu(
                  t,
                  this.options.colors
                );
                if (r)
                  return r;
              }
              return null;
            },
            renderHTML: (e) => {
              if (!e.color) return {};
              const t = String(e.color).trim();
              if (!t) return {};
              const n = t.match(/^var\(--prose-color-(\w+)\)$/);
              return n && this.options.colors.includes(n[1]) ? { style: `color: ${t}` } : this.options.colors.includes(t) ? { style: `color: var(--prose-color-${t})` } : Pn(t) ? { style: `color: ${t}` } : {};
            }
          }
        }
      }
    ];
  },
  addCommands() {
    return {
      setColorByName: (e) => ({ chain: t, state: n, editor: a }) => {
        if (!this.options.colors.includes(e))
          return console.warn(
            `Color "${e}" is not in the allowed colors list`
          ), !1;
        const { to: r, empty: o } = n.selection;
        let s = t().setMark("textStyle", { color: e });
        return o || (s = s.setTextSelection(r).command(({ tr: i }) => (i.setStoredMarks([]), !0))), s.focus().run();
      },
      unsetColor: () => ({ chain: e }) => e().setMark("textStyle", { color: null }).removeEmptyTextStyle().run()
    };
  }
});
let Ts = "#fff2cc";
const Lu = () => Ts, Zb = (e) => {
  e && (Ts = e);
}, ws = Eo.create({
  name: "namedHighlight",
  inclusive: !1,
  addOptions() {
    return {
      HTMLAttributes: {},
      multicolor: !0,
      colors: [
        "yellow",
        "blue",
        "green",
        "red",
        "orange",
        "purple",
        "pink",
        "gray",
        "teal",
        "cyan"
      ]
    };
  },
  addAttributes() {
    return this.options.multicolor ? {
      color: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("style");
          if (t) {
            const a = t.match(
              /background-color:\s*var\(--prose-highlight-(\w+)\)/
            );
            if (a && this.options.colors.includes(a[1]))
              return a[1];
            const r = ks(
              t,
              "background-color"
            );
            if (r)
              return r;
          }
          const n = e.dataset.color;
          if (n) {
            const a = Na(
              n,
              this.options.colors,
              ys,
              _s
            );
            if (a)
              return a;
          }
          if (t) {
            const a = Au(
              t,
              this.options.colors
            );
            if (a)
              return a;
          }
          return null;
        },
        renderHTML: (e) => {
          if (!e.color) return {};
          const t = String(e.color).trim();
          if (!t) return {};
          const n = t.match(/^var\(--prose-highlight-(\w+)\)$/);
          return n && this.options.colors.includes(n[1]) ? { style: `background-color: ${t}` } : this.options.colors.includes(t) ? {
            style: `background-color: var(--prose-highlight-${t})`
          } : Pn(t) ? { style: `background-color: ${t}` } : {};
        }
      }
    } : {};
  },
  parseHTML() {
    return [
      {
        tag: "mark"
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "mark",
      Te(this.options.HTMLAttributes, e),
      0
    ];
  },
  addCommands() {
    return {
      setHighlightByName: (e) => ({ chain: t, commands: n, editor: a, state: r }) => {
        if (!this.options.colors.includes(e))
          return console.warn(
            `Highlight color "${e}" is not in the allowed colors list`
          ), !1;
        const { from: o, to: s, empty: i } = r.selection;
        let c = t();
        return this.options.multicolor ? c = c.setMark(this.name, { color: e }) : c = c.setMark(this.name), i || (c = c.setTextSelection(s).command(({ tr: l }) => (l.setStoredMarks([]), !0))), c.focus().run();
      },
      toggleHighlightByName: (e) => ({ chain: t, commands: n, editor: a, state: r }) => {
        if (!this.options.colors.includes(e))
          return console.warn(
            `Highlight color "${e}" is not in the allowed colors list`
          ), !1;
        const { to: o, empty: s } = r.selection, i = this.options.multicolor ? { color: e } : void 0, c = a.isActive(
          this.name,
          i
        );
        let l = t().toggleMark(this.name, i);
        return !s && !c && (l = l.setTextSelection(o).command(({ tr: d }) => (d.setStoredMarks([]), !0))), l.focus().run();
      },
      unsetHighlight: () => ({ commands: e }) => e.unsetMark(this.name)
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-h": () => {
        if (this.editor.isActive(this.name))
          return this.editor.commands.unsetHighlight();
        const e = Lu();
        return this.editor.chain().focus().setMark(this.name, { color: e }).run();
      }
    };
  }
}), Ru = ae.create({
  name: "highlightEnterClear",
  addKeyboardShortcuts() {
    return {
      Enter: ({ editor: e }) => ((e.state.storedMarks ?? e.state.selection.$from.marks()).some(
        (a) => a.type.name === "namedHighlight"
      ) && queueMicrotask(() => {
        e.isDestroyed || e.commands.command(({ tr: a, state: r }) => {
          const o = (r.storedMarks ?? r.selection.$from.marks()).filter((s) => s.type.name !== "namedHighlight");
          return a.setMeta("addToHistory", !1), a.setStoredMarks(o.length ? o : null), !0;
        });
      }), !1)
    };
  }
}), Ns = Re.create({
  name: "tagItem",
  group: "inline",
  inline: !0,
  selectable: !0,
  atom: !0,
  addAttributes() {
    return {
      tagId: {
        default: null,
        parseHTML: (e) => e.dataset.tagId,
        renderHTML: (e) => e.tagId ? { "data-tag-id": e.tagId } : {}
      },
      tagLabel: {
        default: "tag",
        parseHTML: (e) => e.dataset.tagLabel,
        renderHTML: (e) => ({
          "data-tag-label": e.tagLabel
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "span.tag-item",
        getAttrs: (e) => {
          const t = e;
          return {
            tagId: t.dataset.tagId,
            tagLabel: t.dataset.tagLabel || t.innerText.replace(/^#/, "")
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "span",
      Te(e, { class: "tag-item" }),
      `#${e["data-tag-label"]}`
    ];
  },
  renderText({ node: e }) {
    return `#${e.attrs.tagLabel || ""}`;
  },
  addCommands() {
    return {
      setTag: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: e
      })
    };
  }
}), xs = Re.create({
  name: "toggle",
  group: "block",
  content: "toggleSummary toggleContent",
  defining: !0,
  isolating: !0,
  addOptions() {
    return {
      HTMLAttributes: {},
      persist: !0,
      openClassName: "is-open"
    };
  },
  addAttributes() {
    return {
      open: {
        default: !1,
        parseHTML: (e) => e.dataset.open === "true",
        renderHTML: (e) => ({
          "data-open": e.open ? "true" : "false"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Te(this.options.HTMLAttributes, e, {
        "data-type": "toggle"
      }),
      0
    ];
  }
}), Cs = Re.create({
  name: "toggleSummary",
  priority: 1e3,
  group: "block",
  content: "inline*",
  defining: !0,
  selectable: !1,
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle-summary"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Te(e, { "data-type": "toggle-summary" }),
      0
    ];
  }
}), As = Re.create({
  name: "toggleContent",
  priority: 1e3,
  group: "block",
  content: "block+",
  defining: !0,
  selectable: !1,
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle-content"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Te(e, { "data-type": "toggle-content" }),
      0
    ];
  }
}), Ms = Re.create({
  name: "video",
  group: "block",
  selectable: !0,
  draggable: !0,
  atom: !0,
  addOptions() {
    return {
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: {
        default: null
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "video"
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "video",
      Te(this.options.HTMLAttributes, e, {
        controls: ""
      })
    ];
  }
}), Du = (e) => typeof e == "string" && e.trim() ? e.trim() : null, Is = (e, t) => {
  const n = Du(e);
  if (!n)
    return;
  if (n.match(
    new RegExp(`^var\\(--${t}-([\\w-]+)\\)$`)
  ))
    return n;
  if (/^[\w-]+$/.test(n))
    return `var(--${t}-${n})`;
  if (Pn(n))
    return n;
}, Jb = (e) => Is(e, "prose-color"), Bu = (e) => Is(e, "prose-highlight"), Ze = (e) => e.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;"), U = (e) => typeof e == "string" && e.trim() ? e.trim() : null, na = (e) => e === !0 || e === "true" || e === "", Ct = (e) => typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null, Ye = (e) => {
  const t = U(e[mt]);
  return t ? { [_n]: t } : {};
}, Yr = (e) => {
  const t = U(e);
  return t && ["left", "center", "right", "justify"].includes(t) ? t : null;
}, q = (e, t = {}, n, a = {}) => {
  const r = Object.fromEntries(
    Object.entries(t).filter(
      ([, s]) => s != null && s !== !1
    )
  ), o = Ec(r);
  return a.selfClosing ? `<${e}${o}/>` : `<${e}${o}>${Co(
    n
  )}</${e}>`;
}, Pu = (e) => U(e.title) ?? U(e.name) ?? "", Fu = (e) => U(e.label) ?? U(e.id) ?? "", zu = (e) => U(e.tagLabel) ?? U(e.tagId) ?? "tag", xa = () => Dt("text-editor-attachment"), ut = (e) => e ? `${xa()}__${e}` : xa(), Hu = (e) => U(e.fileName) ?? U(e.title) ?? U(e.assetId) ?? "Attachment", Xr = (e) => [U(e.mimeType), U(e.sizeLabel)].filter(
  Boolean
), $u = (e) => {
  const t = Bu(e);
  return t ? `background-color: ${t}` : null;
}, Ca = () => Dt("text-editor-code-block"), ot = (e) => e ? `${Ca()}__${e}` : Ca(), Uu = (e) => {
  const t = e.display.filename || e.display.caption, n = [
    e.displayLabel,
    e.visibleLines.previewed ? `${e.visibleLines.previewTo}/${e.visibleLines.totalLineCount}` : null
  ].filter(Boolean);
  return !t && !n.length ? "" : q(
    "figcaption",
    {
      class: ot("header")
    },
    [
      t ? q(
        "span",
        {
          class: ot("title")
        },
        Ze(t)
      ) : "",
      n.length ? q(
        "span",
        {
          class: ot("meta")
        },
        Ze(n.join(" | "))
      ) : ""
    ]
  );
}, Gu = (e) => e.visibleLines.lines.map(
  (t, n) => q(
    "span",
    {
      class: ot("line"),
      "data-line": e.visibleLines.lineNumbers[n] ?? e.display.startLine + n
    },
    [
      e.display.showLineNumbers ? q(
        "span",
        {
          class: ot("line-number"),
          "aria-hidden": "true"
        },
        String(
          e.visibleLines.lineNumbers[n] ?? e.display.startLine + n
        )
      ) : "",
      q(
        "span",
        {
          class: ot("line-code")
        },
        Ze(t || " ")
      )
    ]
  )
).join(`
`), Ku = (e) => {
  const t = On(e), n = za({
    surface: "ssr-fragment-html",
    descriptor: t
  }), a = n.diagnostics.map(
    (r) => r.code
  );
  return q(
    "figure",
    {
      ...Ye(e.attrs ?? {}),
      ...Xa(t.attrs),
      class: Ca(),
      "data-type": "code-block",
      "data-zx-code-language-label": n.displayLabel,
      "data-zx-code-copy-text": n.copy.text,
      "data-zx-code-previewed": n.visibleLines.previewed ? "true" : void 0,
      "data-zx-code-line-count": n.visibleLines.totalLineCount,
      "data-zx-code-diagnostics": a.length ? a.join(" ") : void 0
    },
    [
      Uu(n),
      q(
        "pre",
        {
          class: ot("pre"),
          "data-wrap": n.display.wrap
        },
        q(
          "code",
          {
            class: ot("code")
          },
          Gu(n)
        )
      )
    ]
  );
}, Ie = {
  codeBlock: ({ node: e }) => Ku(e),
  attachment: ({ node: e }) => {
    const t = e.attrs ?? {}, n = U(t.href), a = Hu(t), r = n ? [
      q(
        "a",
        {
          class: ut("action"),
          href: n,
          rel: "noopener noreferrer",
          target: "_blank"
        },
        "Open"
      ),
      q(
        "a",
        {
          class: ut("action"),
          href: n,
          rel: "noopener noreferrer",
          target: "_blank"
        },
        "Download"
      )
    ] : [];
    return q(
      "div",
      {
        ...Ye(e.attrs),
        class: xa(),
        "data-type": "attachment"
      },
      [
        q(
          "span",
          {
            class: ut("badge")
          },
          Ze(U(t.badgeLabel) ?? "FILE")
        ),
        q(
          "span",
          {
            class: ut("content")
          },
          [
            q(
              "span",
              {
                class: ut("name")
              },
              Ze(a)
            ),
            Xr(t).length ? q(
              "span",
              {
                class: ut("meta")
              },
              Ze(Xr(t).join(" • "))
            ) : ""
          ]
        ),
        r.length ? q(
          "span",
          {
            class: ut("actions")
          },
          r
        ) : ""
      ]
    );
  },
  embed: ({ node: e }) => {
    const t = Pu(e.attrs);
    return q(
      "a",
      {
        href: U(e.attrs.url),
        rel: U(e.attrs.rel),
        target: U(e.attrs.target),
        class: Dt("text-editor-embed"),
        "data-type": "embed",
        "data-embed-name": U(e.attrs.name),
        "data-embed-title": U(e.attrs.title),
        "data-embed-icon": U(e.attrs.icon)
      },
      Ze(t ? `[[${t}]]` : "[[]]")
    );
  },
  iframe: ({ node: e }) => q("iframe", {
    ...Ye(e.attrs),
    src: U(e.attrs.src),
    width: Ct(e.attrs.width),
    height: Ct(e.attrs.height),
    title: U(e.attrs.title),
    frameborder: Ct(e.attrs.frameborder) ?? 0,
    allowfullscreen: !0,
    loading: "lazy",
    referrerpolicy: "no-referrer-when-downgrade",
    sandbox: U(e.attrs.sandbox) ?? "allow-scripts allow-same-origin allow-popups allow-forms",
    "data-align": Yr(e.attrs.align) ?? "center",
    "data-interactive": na(e.attrs.interactive) ? "true" : "false",
    "data-full-width": na(e.attrs.fullWidth) ? "true" : "false"
  }),
  image: ({ node: e }) => q(
    "img",
    {
      ...Ye(e.attrs),
      src: U(e.attrs.src),
      alt: U(e.attrs.alt),
      title: U(e.attrs.title),
      width: Ct(e.attrs.width),
      height: Ct(e.attrs.height),
      loading: U(e.attrs.loading),
      "data-align": Yr(e.attrs.align) ?? "left"
    },
    void 0,
    { selfClosing: !0 }
  ),
  imageGroup: ({ node: e, children: t }) => q(
    "div",
    {
      ...Ye(e.attrs),
      "data-type": "image-group",
      "data-columns": Ct(e.attrs.columns) ?? 4
    },
    t
  ),
  mention: ({ node: e }) => {
    const t = Fu(e.attrs);
    return q(
      "span",
      {
        class: "mention",
        "data-type": "mention",
        "data-id": U(e.attrs.id),
        "data-label": U(e.attrs.label)
      },
      Ze(`@${t}`)
    );
  },
  tagItem: ({ node: e }) => {
    const t = zu(e.attrs);
    return q(
      "span",
      {
        class: "tag-item",
        "data-tag-id": U(e.attrs.tagId),
        "data-tag-label": U(e.attrs.tagLabel) ?? t
      },
      Ze(`#${t}`)
    );
  },
  toggle: ({ node: e, children: t }) => q(
    "div",
    {
      ...Ye(e.attrs),
      "data-type": "toggle",
      "data-open": na(e.attrs.open) ? "true" : "false"
    },
    t
  ),
  toggleSummary: ({ node: e, children: t }) => q(
    "div",
    {
      ...Ye(e.attrs),
      "data-type": "toggle-summary"
    },
    t
  ),
  toggleContent: ({ node: e, children: t }) => q(
    "div",
    {
      ...Ye(e.attrs),
      "data-type": "toggle-content"
    },
    t
  ),
  video: ({ node: e }) => q("video", {
    ...Ye(e.attrs),
    src: U(e.attrs.src),
    controls: !0
  })
}, aa = {
  comment: ({ children: e }) => q(
    "span",
    {
      class: Dt("text-editor-comment")
    },
    e
  ),
  namedColor: ({ children: e }) => Co(e),
  namedHighlight: ({ mark: e, children: t }) => q(
    "mark",
    {
      style: $u(e.attrs.color)
    },
    t
  )
}, Vu = (e, t) => t(e.title) ?? t(e.name) ?? "", Wu = (e, t) => t(e.label) ?? t(e.id) ?? "", qu = (e, t) => t(e.tagLabel) ?? t(e.tagId) ?? "tag", Aa = () => "zx-text-editor-attachment", gt = (e) => e ? `${Aa()}__${e}` : Aa(), Yu = (e, t) => t(e.fileName) ?? t(e.title) ?? t(e.assetId) ?? "Attachment", Zr = (e, t) => [t(e.mimeType), t(e.sizeLabel)].filter(
  Boolean
), Ma = (e) => e.getBlockClass("text-editor-code-block"), st = (e, t) => t ? `${Ma(e)}__${t}` : Ma(e), Xu = (e, t) => {
  const { helpers: n } = e, a = t.display.filename || t.display.caption, r = [
    t.displayLabel,
    t.visibleLines.previewed ? `${t.visibleLines.previewTo}/${t.visibleLines.totalLineCount}` : null
  ].filter(Boolean);
  return !a && !r.length ? null : n.createElement(
    "figcaption",
    {
      className: st(n, "header")
    },
    a ? n.createElement(
      "span",
      {
        className: st(n, "title")
      },
      a
    ) : null,
    r.length ? n.createElement(
      "span",
      {
        className: st(n, "meta")
      },
      r.join(" | ")
    ) : null
  );
}, Zu = (e, t) => {
  const { helpers: n, path: a } = e;
  return t.visibleLines.lines.map(
    (r, o) => n.createElement(
      "span",
      {
        key: `${n.toPathString(a)}-line-${o}`,
        className: st(n, "line"),
        "data-line": t.visibleLines.lineNumbers[o] ?? t.display.startLine + o
      },
      t.display.showLineNumbers ? n.createElement(
        "span",
        {
          className: st(n, "line-number"),
          "aria-hidden": "true"
        },
        String(
          t.visibleLines.lineNumbers[o] ?? t.display.startLine + o
        )
      ) : null,
      n.createElement(
        "span",
        {
          className: st(n, "line-code")
        },
        r || " "
      )
    )
  );
}, Ju = (e) => {
  const { node: t, path: n, helpers: a } = e, r = On(t), o = za({
    surface: "ssr-fragment-react",
    descriptor: r
  }), s = o.diagnostics.map(
    (i) => i.code
  );
  return a.createElement(
    "figure",
    {
      key: a.toPathString(n),
      ...a.resolveBlockProps(t.attrs ?? {}),
      ...Xa(r.attrs),
      className: Ma(a),
      "data-type": "code-block",
      "data-zx-code-language-label": o.displayLabel,
      "data-zx-code-copy-text": o.copy.text,
      "data-zx-code-previewed": o.visibleLines.previewed ? "true" : void 0,
      "data-zx-code-line-count": o.visibleLines.totalLineCount,
      "data-zx-code-diagnostics": s.length ? s.join(" ") : void 0
    },
    Xu(e, o),
    a.createElement(
      "pre",
      {
        className: st(a, "pre"),
        "data-wrap": o.display.wrap
      },
      a.createElement(
        "code",
        {
          className: st(a, "code")
        },
        ...Zu(e, o)
      )
    )
  );
}, Oe = {
  attachment: ({ attrs: e, path: t, helpers: n }) => {
    const a = n.sanitizeHref(e.href), r = Yu(e, n.toStringValue), o = a ? [
      n.createElement(
        "a",
        {
          key: `${n.toPathString(t)}-open`,
          className: gt("action"),
          href: a,
          rel: "noopener noreferrer",
          target: "_blank",
          "data-action": "open"
        },
        "Open"
      ),
      n.createElement(
        "a",
        {
          key: `${n.toPathString(t)}-download`,
          className: gt("action"),
          href: a,
          rel: "noopener noreferrer",
          target: "_blank",
          download: n.toStringValue(e.downloadName) ?? r,
          "data-action": "download"
        },
        "Download"
      )
    ] : [];
    return n.createElement(
      "div",
      {
        key: n.toPathString(t),
        ...n.resolveBlockProps(e),
        className: Aa(),
        "data-type": "attachment",
        "data-asset-id": n.toStringValue(e.assetId) ?? void 0,
        "data-display": n.toStringValue(e.display) ?? "card",
        "data-file-kind": n.toStringValue(e.fileKind) ?? void 0
      },
      n.createElement(
        "span",
        {
          className: gt("badge")
        },
        n.toStringValue(e.badgeLabel) ?? "FILE"
      ),
      n.createElement(
        "span",
        {
          className: gt("content")
        },
        n.createElement(
          "span",
          {
            className: gt("name")
          },
          r
        ),
        Zr(e, n.toStringValue).length ? n.createElement(
          "span",
          {
            className: gt("meta")
          },
          Zr(e, n.toStringValue).join(" • ")
        ) : null
      ),
      o.length ? n.createElement(
        "span",
        {
          className: gt("actions")
        },
        ...o
      ) : null
    );
  },
  doc: ({ path: e, children: t, helpers: n }) => n.createFragment(n.toPathString(e), ...t),
  text: ({ node: e, path: t, applyMarks: n }) => n(e, typeof e.text == "string" ? e.text : "", t),
  hardBreak: ({ path: e, helpers: t }) => t.createElement("br", { key: t.toPathString(e) }),
  paragraph: ({ attrs: e, children: t, path: n, helpers: a }) => a.createElement(
    "p",
    {
      key: a.toPathString(n),
      ...a.resolveBlockProps(e),
      ...a.resolveAlign(e.align) ? { style: { textAlign: a.resolveAlign(e.align) } } : {}
    },
    ...t
  ),
  heading: ({ attrs: e, children: t, path: n, helpers: a }) => {
    const r = Math.min(
      Math.max(a.toIntegerValue(e.level) ?? 1, 1),
      6
    );
    return a.createElement(
      `h${r}`,
      {
        key: a.toPathString(n),
        ...a.resolveBlockProps(e),
        ...a.resolveHeadingIdProps(e),
        ...a.resolveAlign(e.align) ? { style: { textAlign: a.resolveAlign(e.align) } } : {}
      },
      ...t
    );
  },
  blockquote: ({ children: e, path: t, helpers: n }) => n.createElement(
    "blockquote",
    {
      key: n.toPathString(t)
    },
    ...e
  ),
  bulletList: ({ children: e, path: t, helpers: n }) => n.createElement(
    "ul",
    { key: n.toPathString(t) },
    ...e
  ),
  orderedList: ({ attrs: e, children: t, path: n, helpers: a }) => a.createElement(
    "ol",
    {
      key: a.toPathString(n),
      ...a.toIntegerValue(e.start) ? { start: a.toIntegerValue(e.start) } : {}
    },
    ...t
  ),
  listItem: ({ children: e, path: t, helpers: n }) => n.createElement(
    "li",
    { key: n.toPathString(t) },
    ...e
  ),
  taskList: ({ children: e, path: t, helpers: n }) => n.createElement(
    "ul",
    {
      key: n.toPathString(t),
      "data-type": "task-list"
    },
    ...e
  ),
  taskItem: ({ attrs: e, children: t, path: n, helpers: a }) => {
    const r = a.toBooleanValue(e.checked);
    return a.createElement(
      "li",
      {
        key: a.toPathString(n),
        "data-checked": r ? "true" : "false",
        "data-type": "task-item"
      },
      a.createElement("input", {
        checked: r,
        disabled: !0,
        type: "checkbox"
      }),
      a.createElement("label", {}, ...t)
    );
  },
  codeBlock: Ju,
  table: ({ children: e, path: t, helpers: n }) => n.createElement(
    "table",
    { key: n.toPathString(t) },
    n.createElement("tbody", {}, ...e)
  ),
  tableRow: ({ children: e, path: t, helpers: n }) => n.createElement(
    "tr",
    { key: n.toPathString(t) },
    ...e
  ),
  tableCell: ({ children: e, path: t, helpers: n }) => n.createElement(
    "td",
    { key: n.toPathString(t) },
    ...e
  ),
  tableHeader: ({ children: e, path: t, helpers: n }) => n.createElement(
    "th",
    { key: n.toPathString(t) },
    ...e
  ),
  horizontalRule: ({ path: e, helpers: t }) => t.createElement("hr", { key: t.toPathString(e) }),
  pageBreak: ({ attrs: e, path: t, helpers: n }) => n.createElement("div", {
    key: n.toPathString(t),
    ...n.resolveBlockProps(e),
    [ma]: "true",
    className: To,
    role: "separator",
    "aria-label": "Page break"
  }),
  embed: ({ attrs: e, path: t, helpers: n }) => {
    const a = Vu(e, n.toStringValue);
    return n.createElement(
      "a",
      {
        key: n.toPathString(t),
        className: n.getBlockClass("text-editor-embed"),
        "data-type": "embed",
        "data-embed-name": n.toStringValue(e.name) ?? void 0,
        "data-embed-title": n.toStringValue(e.title) ?? void 0,
        "data-embed-icon": n.toStringValue(e.icon) ?? void 0,
        href: n.sanitizeHref(e.url),
        rel: n.toStringValue(e.rel) ?? void 0,
        target: n.toStringValue(e.target) ?? void 0
      },
      a ? `[[${a}]]` : "[[]]"
    );
  },
  iframe: ({ attrs: e, path: t, helpers: n }) => n.createElement("iframe", {
    key: n.toPathString(t),
    ...n.resolveBlockProps(e),
    src: n.sanitizeMediaSource("iframe", e.src),
    width: n.toIntegerValue(e.width) ?? void 0,
    height: n.toIntegerValue(e.height) ?? void 0,
    title: n.toStringValue(e.title) ?? void 0,
    frameBorder: n.toIntegerValue(e.frameborder) ?? 0,
    allowFullScreen: !0,
    loading: "lazy",
    referrerPolicy: "no-referrer-when-downgrade",
    sandbox: n.toStringValue(e.sandbox) ?? "allow-scripts allow-same-origin allow-popups allow-forms",
    "data-align": n.resolveAlign(e.align) ?? "center",
    "data-interactive": n.toBooleanValue(e.interactive) ? "true" : "false",
    "data-full-width": n.toBooleanValue(e.fullWidth) ? "true" : "false"
  }),
  image: ({ attrs: e, path: t, helpers: n }) => n.createElement("img", {
    key: n.toPathString(t),
    ...n.resolveBlockProps(e),
    src: n.sanitizeMediaSource("img", e.src),
    alt: n.toStringValue(e.alt) ?? void 0,
    title: n.toStringValue(e.title) ?? void 0,
    width: n.toIntegerValue(e.width) ?? void 0,
    height: n.toIntegerValue(e.height) ?? void 0,
    loading: n.toStringValue(e.loading) ?? void 0,
    "data-align": n.resolveAlign(e.align) ?? "left"
  }),
  imageGroup: ({ attrs: e, children: t, path: n, helpers: a }) => a.createElement(
    "div",
    {
      key: a.toPathString(n),
      ...a.resolveBlockProps(e),
      "data-type": "image-group",
      "data-columns": a.toIntegerValue(e.columns) ?? 4
    },
    ...t
  ),
  mention: ({ attrs: e, path: t, helpers: n }) => n.createElement(
    "span",
    {
      key: n.toPathString(t),
      className: "mention",
      "data-type": "mention",
      "data-id": n.toStringValue(e.id) ?? void 0,
      "data-label": n.toStringValue(e.label) ?? void 0
    },
    `@${Wu(e, n.toStringValue)}`
  ),
  tagItem: ({ attrs: e, path: t, helpers: n }) => {
    const a = qu(e, n.toStringValue);
    return n.createElement(
      "span",
      {
        key: n.toPathString(t),
        className: "tag-item",
        "data-tag-id": n.toStringValue(e.tagId) ?? void 0,
        "data-tag-label": n.toStringValue(e.tagLabel) ?? a
      },
      `#${a}`
    );
  },
  toggle: ({ attrs: e, children: t, path: n, helpers: a }) => a.createElement(
    "div",
    {
      key: a.toPathString(n),
      ...a.resolveBlockProps(e),
      "data-type": "toggle",
      "data-open": a.toBooleanValue(e.open) ? "true" : "false"
    },
    ...t
  ),
  toggleSummary: ({ attrs: e, children: t, path: n, helpers: a }) => a.createElement(
    "div",
    {
      key: a.toPathString(n),
      ...a.resolveBlockProps(e),
      "data-type": "toggle-summary"
    },
    ...t
  ),
  toggleContent: ({ attrs: e, children: t, path: n, helpers: a }) => a.createElement(
    "div",
    {
      key: a.toPathString(n),
      ...a.resolveBlockProps(e),
      "data-type": "toggle-content"
    },
    ...t
  ),
  video: ({ attrs: e, path: t, helpers: n }) => n.createElement("video", {
    key: n.toPathString(t),
    ...n.resolveBlockProps(e),
    controls: !0,
    src: n.sanitizeMediaSource("video", e.src)
  })
}, un = {
  bold: ({ child: e, path: t, helpers: n }) => n.createElement("strong", { key: n.toPathString(t) }, e),
  italic: ({ child: e, path: t, helpers: n }) => n.createElement("em", { key: n.toPathString(t) }, e),
  strike: ({ child: e, path: t, helpers: n }) => n.createElement("s", { key: n.toPathString(t) }, e),
  underline: ({ child: e, path: t, helpers: n }) => n.createElement("u", { key: n.toPathString(t) }, e),
  code: ({ child: e, path: t, helpers: n }) => n.createElement("code", { key: n.toPathString(t) }, e),
  link: ({ attrs: e, child: t, path: n, helpers: a }) => {
    const r = a.toStringValue(e.target), o = r === "_blank" ? "noopener noreferrer" : void 0;
    return a.createElement(
      "a",
      {
        key: a.toPathString(n),
        href: a.sanitizeHref(e.href),
        rel: o,
        target: r && ["_blank", "_self"].includes(r) ? r : void 0
      },
      t
    );
  },
  textStyle: ({ attrs: e, child: t, path: n, helpers: a }) => a.createElement(
    "span",
    {
      key: a.toPathString(n),
      ...a.resolveTextStyleProps(e)
    },
    t
  ),
  comment: ({ child: e, path: t, helpers: n }) => n.createElement(
    "span",
    {
      key: n.toPathString(t),
      className: n.getBlockClass("text-editor-comment")
    },
    e
  ),
  namedColor: ({ attrs: e, child: t, path: n, helpers: a }) => a.createElement(
    "span",
    {
      key: a.toPathString(n),
      ...a.resolveTextStyleProps({
        color: e.color
      })
    },
    t
  ),
  namedHighlight: ({ attrs: e, child: t, path: n, helpers: a }) => a.createElement(
    "mark",
    {
      key: a.toPathString(n),
      ...a.resolveHighlightStyle(e.color) ? {
        style: {
          backgroundColor: a.resolveHighlightStyle(e.color)
        }
      } : {}
    },
    t
  )
}, ju = (e) => e.replace(/^\n+|\n+$/g, ""), Qu = (e) => e === !0 || e === "true" || e === "", eg = (e) => typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null, tg = /* @__PURE__ */ new Set([
  "text",
  "hardBreak",
  "mention",
  "tagItem",
  "embed"
]), ng = (e) => typeof e.type == "string" && tg.has(e.type), ag = (e = []) => e.some((t) => !ng(t)), rg = (e, t, n) => !n && (e === "heading" || t === "heading") ? `
` : `

`, og = (e, t, n = {}) => {
  const a = e.map((r) => ({
    type: r.type,
    text: n.compact ? r.text.trim() : ju(r.text)
  })).filter((r) => r.text);
  return a.reduce((r, o, s) => {
    var l;
    if (s === 0)
      return o.text;
    const i = (l = a[s - 1]) == null ? void 0 : l.type, c = n.compact ? " " : rg(i, o.type, t);
    return `${r}${c}${o.text}`;
  }, "");
}, sg = (e, t) => {
  const n = " ".repeat(t.length);
  return e.split(`
`).map(
    (a, r) => r === 0 ? `${t}${a}` : a ? `${n}${a}` : n.trimEnd()
  ).join(`
`);
}, nr = (e, t, n, a, r = {}) => {
  if (!(e != null && e.length))
    return "";
  const o = e.map((s, i) => ({
    type: typeof s.type == "string" ? s.type : void 0,
    text: t(s, [...n, "content", i])
  }));
  return ag(e) ? og(o, a, {
    compact: r.compactBlocks
  }) : o.map((s) => s.text).join("");
}, ra = (e, t, n, a, r) => (e ?? []).map((o, s) => {
  const i = [...a, "content", s], c = nr(
    o.content,
    t,
    i,
    n
  );
  return c ? sg(c, r(o, s)) : "";
}).filter(Boolean).join(`
`), ig = (e, t, n, a) => (e ?? []).map((r, o) => {
  const s = [...a, "content", o];
  return (r.content ?? []).map(
    (c, l) => nr(
      c.content,
      t,
      [...s, "content", l],
      n,
      {
        compactBlocks: !0
      }
    )
  ).filter(Boolean).join("	");
}).filter(Boolean).join(`
`), cg = ({
  resolveAttribute: e
}) => {
  const t = e("fileName") ?? e("title") ?? e("assetId") ?? "attachment", n = [
    e("mimeType"),
    e("sizeLabel") ?? e("fileSize")
  ].filter(Boolean), a = e("href") ?? e("src");
  return `Attachment: ${t}${n.length ? ` (${n.join(", ")})` : ""}${a ? ` <${a}>` : ""}`;
}, lg = {
  doc: ({
    node: e,
    path: t,
    renderChildren: n,
    includeHeadingBreaks: a
  }) => n(e.content, t, {
    compactBlocks: !1
  }),
  text: ({ node: e }) => typeof e.text == "string" ? e.text : "",
  hardBreak: () => `
`,
  paragraph: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !1
  }),
  heading: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !1
  }),
  blockquote: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !1
  }).split(`
`).map((r) => r ? `> ${r}` : ">").join(`
`),
  bulletList: ({ node: e, path: t, renderNode: n, includeHeadingBreaks: a }) => ra(
    e.content,
    n,
    a,
    t,
    () => "- "
  ),
  orderedList: ({ node: e, path: t, renderNode: n, includeHeadingBreaks: a }) => {
    var o;
    const r = eg((o = e.attrs) == null ? void 0 : o.start) ?? 1;
    return ra(
      e.content,
      n,
      a,
      t,
      (s, i) => `${r + i}. `
    );
  },
  taskList: ({ node: e, path: t, renderNode: n, includeHeadingBreaks: a }) => ra(
    e.content,
    n,
    a,
    t,
    (r) => {
      var o;
      return Qu((o = r.attrs) == null ? void 0 : o.checked) ? "- [x] " : "- [ ] ";
    }
  ),
  listItem: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !1
  }),
  taskItem: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !1
  }),
  codeBlock: ({ node: e }) => mc(
    On(e)
  ),
  table: ({ node: e, path: t, renderNode: n, includeHeadingBreaks: a }) => ig(e.content, n, a, t),
  tableRow: ({ node: e, path: t, renderNode: n, includeHeadingBreaks: a }) => (e.content ?? []).map(
    (r, o) => nr(
      r.content,
      n,
      [...t, "content", o],
      a,
      {
        compactBlocks: !0
      }
    )
  ).filter(Boolean).join("	"),
  tableCell: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !0
  }),
  tableHeader: ({ node: e, path: t, renderChildren: n }) => n(e.content, t, {
    compactBlocks: !0
  }),
  horizontalRule: () => "---",
  pageBreak: () => "[Page break]"
}, dg = {
  codeBlock: ({ node: e }) => gc(
    On(e)
  )
}, jb = (e) => e, ke = (e) => {
  const t = Sn.find(
    (l) => l.name === e.name
  );
  if (!t)
    throw new TypeError(`Unknown default descriptor "${e.name}".`);
  const {
    name: n,
    attrs: a = [],
    nodes: r = [],
    marks: o = [],
    ai: s,
    ...i
  } = e;
  if (pt({ name: n, attrs: a, nodes: r, marks: o, ai: s }) !== pt(t))
    throw new TypeError(
      `Default descriptor "${n}" does not match its canonical contract.`
    );
  return Tc(n, i), t;
}, Ia = (e) => e ? Array.isArray(e) ? e : [e] : [], ug = (e) => Array.from(/* @__PURE__ */ new Set([e.name, ...e.extensionNames ?? []])), oa = Object.freeze({
  html: {
    supported: !0,
    strategy: "extension-render-html"
  },
  react: {
    supported: !0,
    strategy: "dom-equivalent"
  },
  text: {
    supported: !0
  }
}), Ft = Object.freeze({
  "safe-html": {
    supported: !0,
    degrade: "none"
  },
  "public-html": {
    supported: !0,
    degrade: "none"
  },
  "email-html": {
    supported: !0,
    degrade: "none"
  },
  "search-text": {
    supported: !0,
    degrade: "semantic"
  },
  excerpt: {
    supported: !0,
    degrade: "semantic"
  }
}), sa = Object.freeze({
  node: "fail",
  mark: "fail",
  profiles: {
    "safe-html": "fail",
    "public-html": "fail",
    "email-html": "fail",
    "search-text": "semantic-degrade",
    excerpt: "semantic-degrade"
  }
}), ia = (e, t) => t ? t.supported ? {
  ...e,
  ...t
} : { ...t } : { ...e }, gg = (e) => ({
  html: ia(
    oa.html,
    e == null ? void 0 : e.html
  ),
  react: ia(
    oa.react,
    e == null ? void 0 : e.react
  ),
  text: ia(
    oa.text,
    e == null ? void 0 : e.text
  )
}), zt = (e, t) => t ? t.supported ? {
  ...e,
  ...t
} : { ...t } : { ...e }, mg = (e) => ({
  "safe-html": zt(
    Ft["safe-html"],
    e == null ? void 0 : e["safe-html"]
  ),
  "public-html": zt(
    Ft["public-html"],
    e == null ? void 0 : e["public-html"]
  ),
  "email-html": zt(
    Ft["email-html"],
    e == null ? void 0 : e["email-html"]
  ),
  "search-text": zt(
    Ft["search-text"],
    e == null ? void 0 : e["search-text"]
  ),
  excerpt: zt(
    Ft.excerpt,
    e == null ? void 0 : e.excerpt
  )
}), pg = (e) => ({
  node: (e == null ? void 0 : e.node) ?? sa.node,
  mark: (e == null ? void 0 : e.mark) ?? sa.mark,
  profiles: {
    ...sa.profiles,
    ...(e == null ? void 0 : e.profiles) ?? {}
  }
}), ve = (e) => ({
  ...e,
  targets: gg(e.targets),
  profiles: mg(e.profiles),
  unsupported: pg(e.unsupported)
}), Jr = [
  ke({
    name: "builtinNodes",
    attrs: [
      "blockId",
      "cellId",
      "checked",
      "language",
      "level",
      "rowId",
      "start",
      "textAlign"
    ],
    nodes: [
      "blockquote",
      "bulletList",
      "codeBlock",
      "doc",
      "hardBreak",
      "heading",
      "horizontalRule",
      "listItem",
      "orderedList",
      "pageBreak",
      "paragraph",
      "table",
      "tableCell",
      "tableHeader",
      "tableRow",
      "taskItem",
      "taskList",
      "text"
    ],
    ai: Se.builtinNodes,
    render: ve({
      profiles: {
        "safe-html": {
          supported: !0,
          degrade: "none"
        },
        "search-text": {
          supported: !0,
          degrade: "none"
        },
        excerpt: {
          supported: !0,
          degrade: "none"
        }
      },
      nodes: {
        blockquote: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        bulletList: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        codeBlock: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        doc: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        hardBreak: {
          htmlStrategy: "extension-render-html",
          textStrategy: "literal",
          textFallback: `
`
        },
        heading: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        horizontalRule: {
          htmlStrategy: "extension-render-html",
          textStrategy: "literal",
          textFallback: "---"
        },
        listItem: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        orderedList: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        pageBreak: {
          htmlStrategy: "extension-render-html",
          textStrategy: "literal",
          textFallback: "[Page break]"
        },
        paragraph: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        table: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        tableCell: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        tableHeader: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        tableRow: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        taskItem: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        taskList: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        text: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        }
      },
      htmlNodeMapping: {
        codeBlock: Ie.codeBlock
      },
      reactNodeMapping: Oe,
      textSerializers: lg,
      excerptSerializers: dg
    })
  }),
  ke({
    name: "builtinMarks",
    attrs: ["color", "fontFamily", "fontSize", "href", "rel", "target"],
    marks: [
      "bold",
      "code",
      "italic",
      "link",
      "strike",
      "textStyle",
      "underline"
    ],
    ai: Se.builtinMarks,
    render: ve({
      profiles: {
        "safe-html": {
          supported: !0,
          degrade: "none"
        },
        "search-text": {
          supported: !0,
          degrade: "none"
        },
        excerpt: {
          supported: !0,
          degrade: "none"
        }
      },
      marks: {
        bold: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        },
        code: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        },
        italic: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        },
        link: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        },
        strike: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        },
        textStyle: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        },
        underline: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        }
      },
      reactMarkMapping: un
    })
  }),
  ke({
    name: "attachment",
    nodes: ["attachment"],
    attrs: ["assetId", "display"],
    ai: Se.attachment,
    core: () => ds,
    editorOnlyCapabilities: ["node-view"],
    render: ve({
      htmlNodeMapping: {
        attachment: Ie.attachment
      },
      reactNodeMapping: {
        attachment: Oe.attachment
      },
      nodes: {
        attachment: {
          htmlStrategy: "extension-render-html",
          textStrategy: "literal",
          textFallback: "[Attachment]"
        }
      },
      textSerializers: {
        attachment: cg
      }
    })
  }),
  ke({
    name: "comment",
    marks: ["comment"],
    attrs: ["commentId", "resolved"],
    ai: Se.comment,
    core: () => us,
    editorOnlyCapabilities: ["annotation-activation"],
    render: ve({
      htmlMarkMapping: {
        comment: aa.comment
      },
      reactMarkMapping: {
        comment: un.comment
      },
      marks: {
        comment: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        }
      }
    })
  }),
  ke({
    name: "embed",
    allowExternalOverride: !0,
    nodes: ["embed"],
    attrs: ["assetId", "name", "title", "url", "icon"],
    ai: Se.embed,
    core: () => gs.configure({
      HTMLAttributes: {}
    }),
    editorOnlyCapabilities: ["suggestion"],
    render: ve({
      htmlNodeMapping: {
        embed: Ie.embed
      },
      reactNodeMapping: {
        embed: Oe.embed
      },
      nodes: {
        embed: {
          htmlStrategy: "extension-render-html",
          textStrategy: "attribute",
          textAttrs: ["title", "name", "url"],
          textPrefix: "[[",
          textSuffix: "]]"
        }
      }
    })
  }),
  ke({
    name: "iframe",
    nodes: ["iframe"],
    attrs: [
      "assetId",
      "src",
      "width",
      "height",
      "aspectRatio",
      "align",
      "title",
      "interactive",
      "fullWidth"
    ],
    ai: Se.iframe,
    core: () => ms,
    editorOnlyCapabilities: ["node-view"],
    render: ve({
      htmlNodeMapping: {
        iframe: Ie.iframe
      },
      reactNodeMapping: {
        iframe: Oe.iframe
      },
      nodes: {
        iframe: {
          htmlStrategy: "extension-render-html",
          textStrategy: "attribute",
          textAttrs: ["title", "src"]
        }
      }
    })
  }),
  ke({
    name: "image",
    extensionNames: ["imageViewer"],
    nodes: ["image"],
    attrs: [
      "assetId",
      "src",
      "alt",
      "title",
      "width",
      "height",
      "align",
      "loading"
    ],
    ai: Se.image,
    core: () => ps,
    editorOnlyCapabilities: ["node-view", "upload"],
    render: ve({
      htmlNodeMapping: {
        image: Ie.image
      },
      reactNodeMapping: {
        image: Oe.image
      },
      nodes: {
        image: {
          htmlStrategy: "extension-render-html",
          textStrategy: "attribute",
          textAttrs: ["alt", "title", "src"]
        }
      }
    })
  }),
  ke({
    name: "imageGroup",
    nodes: ["imageGroup"],
    attrs: ["columns"],
    ai: Se.imageGroup,
    core: () => fs,
    editorOnlyCapabilities: ["node-view", "upload"],
    render: ve({
      htmlNodeMapping: {
        imageGroup: Ie.imageGroup
      },
      reactNodeMapping: {
        imageGroup: Oe.imageGroup
      },
      nodes: {
        imageGroup: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        }
      }
    })
  }),
  ke({
    name: "mention",
    extensionNames: ["mentionExtension", "mentionSuggestion"],
    nodes: ["mention"],
    attrs: ["id", "label"],
    ai: Se.mention,
    core: () => bs,
    editorOnlyCapabilities: ["node-view", "suggestion"],
    render: ve({
      htmlNodeMapping: {
        mention: Ie.mention
      },
      reactNodeMapping: {
        mention: Oe.mention
      },
      nodes: {
        mention: {
          htmlStrategy: "extension-render-html",
          textStrategy: "attribute",
          textAttrs: ["label", "id"],
          textPrefix: "@"
        }
      }
    })
  }),
  ke({
    name: "namedColor",
    marks: ["namedColor"],
    attrs: ["color"],
    ai: Se.namedColor,
    core: () => vs,
    render: ve({
      htmlMarkMapping: {
        namedColor: aa.namedColor
      },
      reactMarkMapping: {
        namedColor: un.namedColor
      },
      marks: {
        namedColor: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        }
      }
    })
  }),
  ke({
    name: "namedHighlight",
    extensionNames: ["highlightEnterClear"],
    marks: ["namedHighlight"],
    attrs: ["color"],
    ai: Se.namedHighlight,
    core: () => ws,
    editorOnly: () => Ru,
    render: ve({
      htmlMarkMapping: {
        namedHighlight: aa.namedHighlight
      },
      reactMarkMapping: {
        namedHighlight: un.namedHighlight
      },
      marks: {
        namedHighlight: {
          htmlStrategy: "extension-render-html",
          textStrategy: "preserve-text"
        }
      }
    })
  }),
  ke({
    name: "tag",
    extensionNames: ["tagSuggestion"],
    nodes: ["tagItem"],
    attrs: ["tagId", "tagLabel"],
    ai: Se.tag,
    core: () => Ns,
    editorOnlyCapabilities: ["suggestion"],
    render: ve({
      htmlNodeMapping: {
        tagItem: Ie.tagItem
      },
      reactNodeMapping: {
        tagItem: Oe.tagItem
      },
      nodes: {
        tagItem: {
          htmlStrategy: "extension-render-html",
          textStrategy: "attribute",
          textAttrs: ["tagLabel", "tagId"],
          textPrefix: "#"
        }
      }
    })
  }),
  ke({
    name: "toggle",
    nodes: ["toggle", "toggleSummary", "toggleContent"],
    attrs: ["open"],
    ai: Se.toggle,
    core: () => [xs, Cs, As],
    editorOnlyCapabilities: ["node-view"],
    render: ve({
      htmlNodeMapping: {
        toggle: Ie.toggle,
        toggleSummary: Ie.toggleSummary,
        toggleContent: Ie.toggleContent
      },
      reactNodeMapping: {
        toggle: Oe.toggle,
        toggleSummary: Oe.toggleSummary,
        toggleContent: Oe.toggleContent
      },
      nodes: {
        toggle: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        toggleSummary: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        },
        toggleContent: {
          htmlStrategy: "extension-render-html",
          textStrategy: "children"
        }
      }
    })
  }),
  ke({
    name: "video",
    nodes: ["video"],
    attrs: ["assetId", "src", "controls"],
    ai: Se.video,
    core: () => Ms,
    editorOnlyCapabilities: ["node-view", "upload"],
    render: ve({
      htmlNodeMapping: {
        video: Ie.video
      },
      reactNodeMapping: {
        video: Oe.video
      },
      nodes: {
        video: {
          htmlStrategy: "extension-render-html",
          textStrategy: "attribute",
          textAttrs: ["src"]
        }
      }
    })
  })
];
if (Jr.length !== Sn.length || Jr.some(
  (e, t) => e !== Sn[t]
))
  throw new TypeError(
    "Default text-editor platform bindings do not cover the canonical descriptor list exactly."
  );
const ar = Sn, fg = (e, t = ar) => t.flatMap((n) => {
  var a, r;
  return [
    ...Ia((a = n.core) == null ? void 0 : a.call(n, e)),
    ...e.mode === "editor" ? Ia((r = n.editorOnly) == null ? void 0 : r.call(n, e)) : []
  ];
}), Os = ar, bg = Object.freeze([
  "attachment",
  "comment",
  "embed",
  "iframe",
  "image",
  "imageGroup",
  "mention",
  "namedColor",
  "namedHighlight",
  "tag",
  "toggle",
  "video"
]), Qb = (e = Os) => e.flatMap((t) => {
  const n = hg[t.name];
  return n ? Ia(n()) : fg(
    {
      mode: "render"
    },
    [t]
  );
}), hg = {
  attachment: () => ds,
  comment: () => us,
  embed: () => gs,
  iframe: () => ms,
  image: () => ps,
  imageGroup: () => fs,
  mention: () => bs,
  namedColor: () => vs,
  namedHighlight: () => ws,
  tag: () => Ns,
  toggle: () => [xs, Cs, As],
  video: () => Ms
}, yg = /* @__PURE__ */ new Set([
  "deterministicRuntimeCommitClosure",
  "assetTaskPlaceholder",
  "fileHandler",
  "heading",
  "link",
  "pagesHeaderFooter",
  "pagesBlockSafety",
  "pageBreak",
  "underline",
  "stableBlockIdentity",
  "stableBlockIdentityEngine",
  "stableBlockDomAttributes",
  "textEditorShortcutKeymap"
]), Eg = Object.freeze([
  "code",
  "codeBlock",
  "heading",
  "link",
  "underline"
]), _g = Object.freeze([
  "heading",
  "paragraph"
]), Sg = Object.freeze({
  resizable: !0
}), kg = Object.freeze({
  nested: !0
}), vg = Object.freeze([
  "descriptor-capability:attachment:node-view",
  "descriptor-capability:comment:annotation-activation",
  "descriptor-capability:embed:suggestion",
  "descriptor-capability:iframe:node-view",
  "descriptor-capability:image:node-view",
  "descriptor-capability:image:upload",
  "descriptor-capability:imageGroup:node-view",
  "descriptor-capability:imageGroup:upload",
  "descriptor-capability:mention:node-view",
  "descriptor-capability:mention:suggestion",
  "descriptor-capability:tag:suggestion",
  "descriptor-capability:toggle:node-view",
  "descriptor-capability:video:node-view",
  "descriptor-capability:video:upload",
  "editor-extra:asset-placeholder",
  "editor-extra:content-paste",
  "editor-extra:drag-handle",
  "editor-extra:emoji",
  "editor-extra:file-handler",
  "editor-extra:placeholder",
  "editor-extra:pages-contract",
  "editor-extra:pages-block-safety",
  "editor-extra:page-break",
  "editor-extra:pages-header-footer",
  "editor-extra:pages-layout",
  "editor-extra:slash-commands"
]), Tg = Object.freeze([
  "headless-descriptor:attachment",
  "headless-descriptor:comment",
  "headless-descriptor:embed",
  "headless-descriptor:iframe",
  "headless-descriptor:image",
  "headless-descriptor:imageGroup",
  "headless-descriptor:mention",
  "headless-descriptor:namedColor",
  "headless-descriptor:namedHighlight",
  "headless-descriptor:tag",
  "headless-descriptor:toggle",
  "headless-descriptor:video",
  "render-extra:headless-code",
  "render-extra:headless-code-block",
  "render-extra:page-break",
  "render-extra:stable-block-identity-baseline"
]), wg = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Xt = (e) => !e || typeof e != "object" ? e : Array.isArray(e) ? (e.forEach((t) => Xt(t)), Object.freeze(e)) : (Object.values(e).forEach((t) => Xt(t)), Object.freeze(e)), Fn = (e) => [...new Set(e)].sort(), Ls = (e) => `canonical:${pt(
  [...e].sort((t, n) => t.name.localeCompare(n.name)).map((t) => ({
    name: t.name,
    attrs: [...new Set(t.attrs ?? [])].sort(),
    nodes: [...new Set(t.nodes ?? [])].sort(),
    marks: [...new Set(t.marks ?? [])].sort(),
    ai: t.ai
  }))
)}`, Rs = (e) => (e == null ? void 0 : e.name) ?? null, Ng = (e, t) => e.some((n) => Rs(n) === t), xg = (e, t = yg) => e.filter((n) => {
  const a = Rs(n);
  return !a || !t.has(a);
}), Cg = (e, t) => e.allowExternalOverride && ug(e).some(
  (n) => Ng(t, n)
), eh = (e) => ({
  ...e ?? {},
  code: !1,
  codeBlock: !1,
  heading: !1,
  link: !1,
  underline: !1
}), Ag = (e) => wg(e == null ? void 0 : e.heading) ? { ...e.heading } : {}, Ds = (e, t) => ({
  starterKit: {
    disabledExtensions: [...Eg]
  },
  heading: e,
  table: {
    ...Sg
  },
  taskList: {
    enabled: !0
  },
  taskItem: {
    ...kg
  },
  textAlign: {
    types: [..._g]
  },
  link: {
    openOnClick: !1
  },
  typography: {
    storageKey: tr,
    contract: t
  },
  textStyle: {
    enabled: !0
  },
  fontFamily: {
    enabled: !0
  },
  fontSize: {
    enabled: !0
  },
  pages: {
    storageKey: "pages"
  }
}), Bs = (e) => {
  const t = xg(e.extensions ?? []);
  return ar.filter(
    (n) => !Cg(n, t)
  );
}, Ps = (e) => e.descriptors ?? Os, Mg = (e, t) => {
  const n = e.flatMap(
    (a) => (a.editorOnlyCapabilities ?? []).map(
      (r) => `descriptor-capability:${a.name}:${r}`
    )
  );
  return n.push(
    "editor-extra:asset-placeholder",
    "editor-extra:file-handler",
    ...t.pages === !1 ? [] : ["editor-extra:pages-contract"],
    ...t.pages === !1 ? [] : ["editor-extra:pages-block-safety"],
    ...t.pages === !1 ? [] : ["editor-extra:page-break"],
    ...t.pagesHeaderFooter !== void 0 && t.pagesHeaderFooter !== !1 ? ["editor-extra:pages-header-footer"] : [],
    ...t.pagesLayout !== void 0 && t.pagesLayout !== !1 ? ["editor-extra:pages-layout"] : [],
    "editor-extra:placeholder",
    "editor-extra:slash-commands",
    "editor-extra:emoji",
    "editor-extra:content-paste"
  ), t.dragHandle && n.push("editor-extra:drag-handle"), Fn(n);
}, Ig = (e) => Fn([
  "render-extra:headless-code",
  "render-extra:headless-code-block",
  "render-extra:page-break",
  "render-extra:stable-block-identity-baseline",
  ...e.map((t) => t.name).filter((t) => bg.includes(t)).map((t) => `headless-descriptor:${t}`)
]), Og = (e = {}) => {
  const t = Bs(e), n = er({
    override: e.typography
  }), a = {
    sharedDescriptors: Fn(
      t.map((r) => r.name)
    ),
    sharedDescriptorCapabilityFingerprint: Ls(t),
    editorOnlyEntries: Mg(t, e),
    renderOnlyEntries: [],
    sharedDefaults: Ds(
      Ag(e.starterkitOptions),
      n
    )
  };
  return Xt(a);
}, Lg = (e = {}) => {
  const t = Ps(e), n = er({
    override: e.typography
  }), a = {
    sharedDescriptors: Fn(
      t.map((r) => r.name)
    ),
    sharedDescriptorCapabilityFingerprint: Ls(t),
    editorOnlyEntries: [],
    renderOnlyEntries: Ig(t),
    sharedDefaults: Ds({}, n)
  };
  return Xt(a);
}, th = (e = {}) => {
  const t = Og(e.editor), n = Lg(e.render), a = [], r = wc(
    Bs(e.editor ?? {}),
    Ps(e.render ?? {})
  );
  return pt(t.sharedDescriptors) !== pt(n.sharedDescriptors) && a.push({
    code: "shared-descriptor-drift",
    severity: "error",
    message: "Editor/runtime and render/runtime do not resolve the same shared descriptor truth."
  }), (t.sharedDescriptorCapabilityFingerprint !== n.sharedDescriptorCapabilityFingerprint || !r.valid) && a.push({
    code: "shared-descriptor-capability-drift",
    severity: "error",
    message: "Editor/runtime and render/runtime do not resolve the same descriptor AI capability truth."
  }), Object.keys(t.sharedDefaults).forEach((o) => {
    pt(t.sharedDefaults[o]) !== pt(n.sharedDefaults[o]) && a.push({
      code: "shared-default-mismatch",
      severity: "error",
      field: o,
      message: `Editor/runtime and render/runtime disagree on shared default "${o}".`
    });
  }), t.editorOnlyEntries.forEach((o) => {
    vg.includes(o) || a.push({
      code: "unexpected-editor-only-entry",
      severity: "error",
      entry: o,
      message: `Editor/runtime exposes unexpected editor-only assembly entry "${o}".`
    });
  }), n.renderOnlyEntries.forEach((o) => {
    Tg.includes(o) || a.push({
      code: "unexpected-render-only-entry",
      severity: "error",
      entry: o,
      message: `Render/runtime exposes unexpected render-only assembly entry "${o}".`
    });
  }), Xt({
    valid: a.length === 0,
    issues: a,
    editor: t,
    render: n
  });
}, Rg = "basicRichTextAdmission", Dg = (e) => {
  const t = e == null ? void 0 : e.storage, n = t == null ? void 0 : t[Rg];
  return (n == null ? void 0 : n.capabilities) instanceof Set ? n : null;
}, nh = [
  "workbench-top",
  "bubble",
  "floating",
  "slash",
  "node-contextual",
  "ai-rewrite"
], ah = [
  "action",
  "toggle",
  "dropdown",
  "select",
  "color",
  "split-button",
  "separator",
  "spacer",
  "custom"
], rh = [
  "paragraph",
  "heading-1",
  "heading-2",
  "heading-3",
  "heading-4",
  "heading-5",
  "heading-6",
  "bullet-list",
  "ordered-list",
  "task-list",
  "blockquote",
  "code-block"
], Fs = [
  "left",
  "center",
  "right",
  "justify"
], oh = [
  "bullet-list",
  "ordered-list",
  "task-list"
], zs = [
  "blockStyle",
  "fontFamily",
  "fontSize",
  "textColor",
  "highlightColor",
  "alignment",
  "listKind"
], sh = (e = {}) => ({
  visible: !0,
  disabled: !1,
  active: !1,
  mixed: !1,
  value: null,
  indicatorColor: null,
  ...e
}), jr = {
  none: 0,
  fallback: 1,
  "block-default": 2,
  "stored-mark": 3,
  "text-style": 4
}, Bg = {
  addColumnAfter: ["table"],
  addColumnBefore: ["table"],
  addRowAfter: ["table"],
  addRowBefore: ["table"],
  deleteColumn: ["table"],
  deleteRow: ["table"],
  deleteTable: ["table"],
  insertTable: ["insert.table", "table"],
  mergeCells: ["table"],
  openLinkEditor: ["insert.link"],
  redo: ["history", "history.redo"],
  selectAndUploadVideo: ["insert.video"],
  setHorizontalRule: ["insert.horizontal-rule"],
  setParagraph: ["block-style.paragraph"],
  setColorByName: ["text-color"],
  setFontFamily: ["font-family"],
  setFontSize: ["font-size"],
  setLink: ["insert.link"],
  setTextAlign: ["alignment"],
  setToggle: ["block-style.toggle"],
  splitCell: ["table"],
  toggleBlockquote: ["block-style.blockquote"],
  toggleBold: ["format.bold"],
  toggleBulletList: ["list.bullet", "block-style.list"],
  toggleCodeBlock: ["block-style.code-block"],
  toggleHeaderCell: ["table"],
  toggleHeaderColumn: ["table"],
  toggleHeaderRow: ["table"],
  toggleHeading: ["block-style.heading"],
  toggleItalic: ["format.italic"],
  toggleOrderedList: ["list.ordered", "block-style.list"],
  toggleStrike: ["format.strike"],
  toggleTaskList: ["list.task", "block-style.list"],
  toggleUnderline: ["format.underline"],
  undo: ["history", "history.undo"],
  unsetColor: ["text-color"],
  unsetFontFamily: ["font-family"],
  unsetFontSize: ["font-size"],
  unsetHighlight: ["highlight-color"]
}, Pg = {
  heading: ["block-style.heading"],
  iframe: ["insert.iframe"],
  image: ["insert.image"],
  imageGroup: ["insert.image"],
  link: ["insert.link"],
  namedColor: ["text-color"],
  namedHighlight: ["highlight-color"],
  table: ["insert.table", "table"],
  taskItem: ["list.task"],
  taskList: ["list.task", "block-style.list"],
  textAlign: ["alignment"],
  textStyle: ["font-family", "font-size", "text-color"],
  toggle: ["block-style.toggle"],
  video: ["insert.video"]
}, Hs = (e) => !!(e && typeof e == "object"), Ae = (e) => {
  if (typeof e != "string")
    return null;
  const t = e.trim();
  return t || null;
}, An = (e) => typeof e == "number" ? Number.isFinite(e) ? e : null : Ae(e), gn = (e, t, n) => {
  var r, o, s;
  return (s = (o = (((r = e.state) == null ? void 0 : r.storedMarks) ?? []).find((i) => {
    var c;
    return ((c = i.type) == null ? void 0 : c.name) === t;
  })) == null ? void 0 : o.attrs) == null ? void 0 : s[n];
}, $s = (e, t, n, a) => {
  var d, u, m;
  if (typeof window > "u")
    return null;
  const r = (d = e.state) == null ? void 0 : d.selection, o = (u = e.view) == null ? void 0 : u.domAtPos, s = (m = e.view) == null ? void 0 : m.nodeDOM;
  if (!r)
    return null;
  const i = a ?? r.from, c = [], l = (g) => {
    g && !c.includes(g) && c.push(g);
  };
  try {
    if (i === r.from && r.$from && typeof s == "function")
      for (let g = r.$from.depth; g > 0; g -= 1)
        l(s(r.$from.before(g)));
  } catch {
  }
  try {
    typeof s == "function" && l(s(i));
  } catch {
  }
  try {
    typeof o == "function" && l(o(i).node);
  } catch {
  }
  for (const g of c) {
    let f = g instanceof Element ? g : g.parentElement;
    for (; f; ) {
      const b = n(window.getComputedStyle(f)[t]);
      if (b != null)
        return b;
      f = f.parentElement;
    }
  }
  return null;
}, Fg = (e, t) => $s(e, "fontSize", An, t), zg = (e, t) => $s(e, "fontFamily", Ae, t), Hg = (e) => {
  var n;
  const t = (n = e.storage) == null ? void 0 : n[tr];
  return (t == null ? void 0 : t.contract) ?? ls;
}, Us = (e, t) => e === "fontSize" ? An(t) : Ae(t), Oa = (e, t, n) => {
  if (!t)
    return {
      value: null,
      source: "none"
    };
  const r = (e.blocks[t] ?? {})[n] ?? e.root[n], o = Us(
    n,
    (r == null ? void 0 : r.displayValue) ?? (r == null ? void 0 : r.cssValue) ?? null
  );
  return o == null ? {
    value: null,
    source: "none"
  } : {
    value: o,
    source: "block-default"
  };
}, La = (e, t, n) => {
  const a = t === "fontSize" ? Fg(e, n) : zg(e, n);
  return a == null ? {
    value: null,
    source: "none"
  } : {
    value: a,
    source: "fallback"
  };
}, Ra = (e) => {
  const t = Ae(e);
  return t && Fs.includes(t) ? t : null;
}, Gs = (e) => {
  switch (e) {
    case "bulletList":
      return "bullet-list";
    case "orderedList":
      return "ordered-list";
    case "taskList":
      return "task-list";
    default:
      return null;
  }
}, Ks = (e, t) => {
  var r, o, s;
  const n = (r = e.type) == null ? void 0 : r.name, a = (o = t == null ? void 0 : t.type) == null ? void 0 : o.name;
  switch (n) {
    case "bulletList":
    case "orderedList":
    case "taskList":
      return Gs(n);
    case "heading": {
      const i = Number((s = e.attrs) == null ? void 0 : s.level);
      return Number.isInteger(i) && i >= 1 && i <= 6 ? `heading-${i}` : null;
    }
    case "blockquote":
      return "blockquote";
    case "codeBlock":
      return "code-block";
    case "paragraph":
      return a === "listItem" || a === "blockquote" ? null : "paragraph";
    default:
      return null;
  }
}, $g = (e, t) => (e.marks ?? []).filter((n) => {
  var a;
  return ((a = n.type) == null ? void 0 : a.name) === t;
}), Da = (e, t, n) => {
  var a, r;
  return (r = (a = $g(e, t)[0]) == null ? void 0 : a.attrs) == null ? void 0 : r[n];
}, Ug = (e) => e.isBlock ? typeof e.textContent == "string" ? !e.textContent.trim() : typeof e.nodeSize == "number" ? e.nodeSize <= 2 : !1 : !1, Gg = (e) => {
  var r, o;
  const t = {
    blockRanges: [],
    textNodes: [],
    emptyBlocks: []
  }, n = (r = e.state) == null ? void 0 : r.selection, a = (o = e.state) == null ? void 0 : o.doc;
  return !n || n.empty || typeof (a == null ? void 0 : a.nodesBetween) != "function" || a.nodesBetween(
    n.from,
    n.to,
    (s, i, c, l) => {
      const d = Ks(s, c), u = s.nodeSize ?? 0;
      d && u > 0 && t.blockRanges.push({
        from: i,
        to: i + u,
        style: d
      }), s.isText && t.textNodes.push({
        node: s,
        pos: i
      }), Ug(s) && t.emptyBlocks.push({
        node: s,
        pos: i
      });
    }
  ), t;
}, Kg = (e, t) => {
  let n = null, a = Number.POSITIVE_INFINITY;
  for (const r of e) {
    if (t < r.from || t >= r.to)
      continue;
    const o = r.to - r.from;
    o < a && (n = r.style, a = o);
  }
  return n;
}, Vs = (e, t, n, a, r) => {
  const o = Kg(a, r), s = Oa(
    t,
    o,
    n
  );
  return s.value != null ? s : !o && t.fallback.allowUnknownNodeFallback ? La(e, n, r) : {
    value: null,
    source: "none"
  };
}, Vg = (e, t, n, a, r, o) => {
  const s = Us(
    n,
    Da(r, "textStyle", n)
  );
  return s != null ? {
    value: s,
    source: "text-style"
  } : Vs(e, t, n, a, o);
}, Wg = (e, t) => jr[e] >= jr[t] ? e : t, qg = (e, t) => {
  var o, s;
  const n = /* @__PURE__ */ new Set(), a = (o = e.state) == null ? void 0 : o.selection, r = (s = e.state) == null ? void 0 : s.doc;
  return !a || a.empty || typeof (r == null ? void 0 : r.nodesBetween) != "function" || r.nodesBetween(
    a.from,
    a.to,
    (i, c, l, d) => {
      const u = t(i, l);
      u !== void 0 && n.add(u);
    }
  ), n;
}, Ht = (e, t, n) => {
  var o;
  const a = (o = e.state) == null ? void 0 : o.selection;
  if (!a || a.empty)
    return {
      value: t,
      indeterminate: !1
    };
  const r = [...qg(e, n)];
  return r.length === 0 ? {
    value: t,
    indeterminate: !1
  } : r.length === 1 ? {
    value: r[0] ?? t,
    indeterminate: !1
  } : {
    value: null,
    indeterminate: !0
  };
}, Qr = (e, t, n, a) => {
  var d, u;
  const r = (d = e.state) == null ? void 0 : d.selection;
  if (!r || r.empty)
    return {
      value: a.value,
      source: a.source,
      indeterminate: !1
    };
  const o = Gg(e), s = [];
  if (o.textNodes.forEach(({ node: m, pos: g }) => {
    const f = Vg(
      e,
      t,
      n,
      o.blockRanges,
      m,
      g
    );
    f.value != null && s.push(f);
  }), o.emptyBlocks.forEach(({ pos: m, node: g }) => {
    const f = Vs(
      e,
      t,
      n,
      o.blockRanges,
      m + (g.nodeSize && g.nodeSize > 1 ? 1 : 0)
    );
    f.value != null && s.push(f);
  }), s.length === 0)
    return {
      value: a.value,
      source: a.source,
      indeterminate: !1
    };
  const i = ((u = s[0]) == null ? void 0 : u.value) ?? null;
  if (s.some(
    (m) => !Object.is(m.value, i)
  ))
    return {
      value: null,
      source: "none",
      indeterminate: !0
    };
  const l = s.reduce(
    (m, g) => Wg(m, g.source),
    "none"
  );
  return {
    value: i,
    source: l,
    indeterminate: !1
  };
}, Yg = (e) => {
  var a, r;
  const t = (a = e == null ? void 0 : e.can) == null ? void 0 : a.call(e), n = (r = t == null ? void 0 : t.chain) == null ? void 0 : r.call(t);
  return !n || typeof n != "object" ? null : typeof n.focus == "function" ? n.focus() : n;
}, eo = (e, t) => {
  var o;
  const n = Yg(e), a = n == null ? void 0 : n[t];
  if (typeof a != "function")
    return !1;
  const r = a.call(n);
  return ((o = r == null ? void 0 : r.run) == null ? void 0 : o.call(r)) ?? !1;
}, Xg = (e) => {
  if (!e)
    return null;
  if (e.isActive("bulletList")) return "bullet-list";
  if (e.isActive("orderedList")) return "ordered-list";
  if (e.isActive("taskList")) return "task-list";
  for (let t = 1; t <= 6; t += 1)
    if (e.isActive("heading", { level: t }))
      return `heading-${t}`;
  return e.isActive("blockquote") ? "blockquote" : e.isActive("codeBlock") ? "code-block" : e.isActive("paragraph") ? "paragraph" : null;
}, Zg = (e) => e ? e.isActive("bulletList") ? "bullet-list" : e.isActive("orderedList") ? "ordered-list" : e.isActive("taskList") ? "task-list" : null : null, Jg = (e) => {
  var a, r;
  if (!e)
    return null;
  for (const o of Fs)
    if (e.isActive({ textAlign: o }))
      return o;
  const t = Ra(
    (a = e.getAttributes("paragraph")) == null ? void 0 : a.textAlign
  ), n = Ra(
    (r = e.getAttributes("heading")) == null ? void 0 : r.textAlign
  );
  return t ?? n ?? "left";
}, Ws = () => Object.fromEntries(
  zs.map((e) => [e, !1])
), jg = () => ({
  blockStyle: null,
  fontFamily: null,
  fontSize: null,
  textColor: null,
  highlightColor: null,
  alignment: null,
  listKind: null,
  sources: {
    fontFamily: "none",
    fontSize: "none"
  },
  indeterminate: Ws(),
  history: {
    canUndo: !1,
    canRedo: !1
  },
  selection: {
    isCollapsed: !0,
    isMixed: !1,
    isEmpty: !0
  },
  capabilities: /* @__PURE__ */ new Set()
}), Qg = (e) => {
  var a, r;
  const t = /* @__PURE__ */ new Set();
  if (!Hs(e))
    return t;
  Object.entries(Bg).forEach(
    ([o, s]) => {
      var i;
      typeof ((i = e.commands) == null ? void 0 : i[o]) == "function" && s.forEach((c) => t.add(c));
    }
  ), (r = (a = e.extensionManager) == null ? void 0 : a.extensions) == null || r.forEach((o) => {
    var i;
    const s = Ae(o.name);
    s && ((i = Pg[s]) == null || i.forEach(
      (c) => t.add(c)
    ));
  });
  const n = Dg(e);
  return n && t.forEach((o) => {
    n.capabilities.has(o) || t.delete(o);
  }), t;
}, em = (e, t) => {
  var o, s, i;
  const n = (o = e == null ? void 0 : e.state) == null ? void 0 : o.selection, a = zs.some(
    (c) => t[c]
  ), r = ((i = (s = e == null ? void 0 : e.state) == null ? void 0 : s.doc) == null ? void 0 : i.textContent) ?? "";
  return {
    isCollapsed: (n == null ? void 0 : n.empty) ?? !0,
    isMixed: a,
    isEmpty: (e == null ? void 0 : e.isEmpty) ?? (typeof r == "string" ? !r.trim() : !0)
  };
}, ih = (e) => {
  if (!Hs(e))
    return jg();
  const t = Hg(e), n = e.getAttributes("textStyle"), a = e.getAttributes("namedHighlight"), r = Xg(e), o = Ae(
    n == null ? void 0 : n.fontFamily
  ), s = Ae(
    gn(e, "textStyle", "fontFamily")
  ), i = An(
    n == null ? void 0 : n.fontSize
  ), c = An(
    gn(e, "textStyle", "fontSize")
  ), l = o != null ? {
    value: o,
    source: "text-style"
  } : s != null ? {
    value: s,
    source: "stored-mark"
  } : (() => {
    const y = Oa(
      t,
      r,
      "fontFamily"
    );
    return y.value != null ? y : !r && t.fallback.allowUnknownNodeFallback ? La(e, "fontFamily") : {
      value: null,
      source: "none"
    };
  })(), d = i != null ? {
    value: i,
    source: "text-style"
  } : c != null ? {
    value: c,
    source: "stored-mark"
  } : (() => {
    const y = Oa(
      t,
      r,
      "fontSize"
    );
    return y.value != null ? y : !r && t.fallback.allowUnknownNodeFallback ? La(e, "fontSize") : {
      value: null,
      source: "none"
    };
  })(), u = {
    blockStyle: r,
    fontFamily: l.value,
    fontSize: d.value,
    textColor: Ae(n == null ? void 0 : n.color) ?? Ae(gn(e, "textStyle", "color")),
    highlightColor: Ae(a == null ? void 0 : a.color) ?? Ae(
      gn(e, "namedHighlight", "color")
    ),
    alignment: Jg(e),
    listKind: Zg(e)
  }, m = Ht(
    e,
    u.blockStyle,
    (y, x) => Ks(y, x) ?? void 0
  ), g = Qr(
    e,
    t,
    "fontFamily",
    l
  ), f = Qr(
    e,
    t,
    "fontSize",
    d
  ), b = Ht(
    e,
    u.textColor,
    (y) => y.isText ? Ae(Da(y, "textStyle", "color")) : void 0
  ), E = Ht(
    e,
    u.highlightColor,
    (y) => y.isText ? Ae(Da(y, "namedHighlight", "color")) : void 0
  ), _ = Ht(
    e,
    u.alignment,
    (y) => {
      var C, O;
      if (!y.isBlock)
        return;
      const x = (C = y.type) == null ? void 0 : C.name;
      if (!(x !== "paragraph" && x !== "heading"))
        return Ra((O = y.attrs) == null ? void 0 : O.textAlign) ?? "left";
    }
  ), k = Ht(
    e,
    u.listKind,
    (y) => {
      var x;
      return Gs(((x = y.type) == null ? void 0 : x.name) ?? "") ?? void 0;
    }
  ), S = Ws();
  return S.blockStyle = m.indeterminate, S.fontFamily = g.indeterminate, S.fontSize = f.indeterminate, S.textColor = b.indeterminate, S.highlightColor = E.indeterminate, S.alignment = _.indeterminate, S.listKind = k.indeterminate, {
    blockStyle: m.value,
    fontFamily: g.value,
    fontSize: f.value,
    textColor: b.value,
    highlightColor: E.value,
    alignment: _.value,
    listKind: k.value,
    sources: {
      fontFamily: g.source,
      fontSize: f.source
    },
    indeterminate: S,
    history: {
      canUndo: eo(e, "undo"),
      canRedo: eo(e, "redo")
    },
    selection: em(e, S),
    capabilities: Qg(e)
  };
}, ch = (e, t) => e.indeterminate[t], qs = (e) => ({
  default: null,
  parseHTML: (t) => t.getAttribute(e),
  renderHTML: (t) => {
    const n = e.endsWith("row-id") ? t.rowId : t.cellId;
    return typeof n == "string" && n.length > 0 ? { [e]: n } : {};
  }
}), tm = Oc.extend({
  addAttributes() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      rowId: qs("data-zx-row-id")
    };
  }
}), Ys = function() {
  var e;
  return {
    ...(e = this.parent) == null ? void 0 : e.call(this),
    cellId: qs("data-zx-cell-id")
  };
}, nm = Rc.extend({
  addAttributes: Ys
}), am = Lc.extend({
  addAttributes: Ys
}), rm = (e = []) => {
  const t = e[e.length - 1];
  return ((t == null ? void 0 : t.raw) ?? (t == null ? void 0 : t.text) ?? "").slice(-1);
}, om = (e) => e.flatMap((t, n) => {
  const a = `zx_registry_inline_${n}`;
  return [
    ae.create({
      name: `${a}_tokenizer`,
      markdownTokenizer: {
        name: a,
        level: "inline",
        start: (r) => {
          for (let o = 0; o < r.length; o++)
            if (t(r.slice(o), {
              prevChar: o > 0 ? r[o - 1] : void 0
            }))
              return o;
          return -1;
        },
        tokenize: (r, o = []) => {
          const s = t(r, {
            prevChar: rm(o)
          });
          if (s)
            return {
              type: a,
              raw: r.slice(0, s.length),
              content: s.content
            };
        }
      }
    }),
    ae.create({
      name: a,
      markdownTokenName: a,
      parseMarkdown: (r) => r.content ?? null
    })
  ];
}), sm = (e) => e.map(
  (t, n) => ae.create({
    name: `zx_registry_block_tokenizer_${n}`,
    markdownTokenizer: {
      name: `zx_registry_block_tokenizer_${n}`,
      level: "block",
      start: (a) => {
        const r = a.split(`
`);
        let o = 0;
        for (let s = 0; s < r.length; s += 1) {
          if (t(r, s))
            return o;
          o += r[s].length + 1;
        }
        return -1;
      },
      tokenize: (a) => {
        var s;
        const r = a.split(`
`), o = t(r, 0);
        if ((s = o == null ? void 0 : o.token) != null && s.type)
          return {
            ...o.token,
            raw: o.token.raw ?? r.slice(0, o.nextIndex).join(`
`)
          };
      }
    }
  })
), im = (e) => Object.entries(e).map(
  ([t, n]) => ae.create({
    name: `zx_registry_parser_${t}`,
    markdownTokenName: t,
    parseMarkdown: (a, r) => n(a, {
      parseBlocks: (o) => r.parseChildren(o),
      parseInlines: (o) => r.parseInline(o)
    })
  })
), cm = (e) => Object.entries(e).map(
  ([t, n]) => ae.create({
    name: t,
    renderMarkdown: (a, r) => n(a, {
      serializeNodes: (o) => r.renderChildren(o, `

`),
      serializeInline: (o) => r.renderChildren(o, "")
    })
  })
), lm = (e) => e ? [
  ...om(e.inlineTextTokenizers),
  ...sm(e.blockTokenizers),
  ...im(e.tokenParsers),
  ...cm(e.nodeSerializers)
] : [], dm = /^#([\p{L}\p{N}_-]+)/u, um = /[\p{L}\p{N}_-]/u, gm = /^\[\[([^[\]]+)\]\]/, mm = /^:::toggle(?:\s+([^\n]*))?\n([\s\S]*?)\n:::(?:\n|$)/, pm = /^:::image-group(?:\s+([^\n]*))?\n([\s\S]*?)\n:::(?:\n|$)/, to = {
  gfm: !0,
  breaks: !0
}, fm = (e) => e.replace(/\)/g, "%29").replace(/\(/g, "%28"), bm = (e = []) => {
  const t = e[e.length - 1];
  return ((t == null ? void 0 : t.raw) ?? (t == null ? void 0 : t.text) ?? "").slice(-1);
}, hm = (e) => !e || !um.test(e), Xs = (e) => ({
  type: "image",
  attrs: {
    src: e.href,
    alt: e.text || null,
    title: e.title || null
  }
}), ym = (e) => {
  const t = [...e], n = () => {
    const r = t[0];
    if ((r == null ? void 0 : r.type) !== "text" || typeof r.text != "string")
      return;
    const o = r.text.replace(/^\s+/, "");
    if (o) {
      t[0] = {
        ...r,
        text: o
      };
      return;
    }
    t.shift(), n();
  }, a = () => {
    const r = t.length - 1, o = t[r];
    if ((o == null ? void 0 : o.type) !== "text" || typeof o.text != "string")
      return;
    const s = o.text.replace(/\s+$/, "");
    if (s) {
      t[r] = {
        ...o,
        text: s
      };
      return;
    }
    t.pop(), a();
  };
  return n(), a(), t;
}, Em = (e) => {
  const t = ym(e);
  return t.length ? {
    type: "paragraph",
    content: t
  } : null;
}, Ba = (e, t, n = "") => Array.isArray(t) && t.length ? e.renderChildren(t, n) : "", _m = (e) => e.replace(/\s+/g, " ").trim(), Sm = (e, t) => {
  if (!Array.isArray(e.content) || !e.content.length)
    return "";
  const n = e.content.map(
    (u) => (u.content ?? []).map((m) => ({
      text: _m(
        Array.isArray(m.content) && m.content.length ? t.renderChildren(m.content, "") : ""
      ),
      isHeader: m.type === "tableHeader"
    }))
  ), a = n.reduce((u, m) => Math.max(u, m.length), 0);
  if (!a)
    return "";
  const r = Array.from(
    { length: a },
    (u, m) => Math.max(3, ...n.map((g) => {
      var f;
      return ((f = g[m]) == null ? void 0 : f.text.length) ?? 0;
    }))
  ), o = (u, m) => u + " ".repeat(Math.max(0, m - u.length)), s = n[0] ?? [], i = s.some((u) => u.isHeader), c = Array.from(
    { length: a },
    (u, m) => {
      var g;
      return i ? ((g = s[m]) == null ? void 0 : g.text) ?? "" : "";
    }
  ), l = r.map((u) => "-".repeat(u)), d = i ? n.slice(1) : n;
  return [
    `| ${c.map((u, m) => o(u, r[m])).join(" | ")} |`,
    `| ${l.join(" | ")} |`,
    ...d.map(
      (u) => `| ${Array.from(
        { length: a },
        (m, g) => {
          var f;
          return o(((f = u[g]) == null ? void 0 : f.text) ?? "", r[g]);
        }
      ).join(" | ")} |`
    )
  ].join(`
`);
}, km = ae.create({
  name: "paragraph",
  priority: 1e4,
  parseMarkdown: (e, t) => {
    const a = e.tokens ?? [];
    if (!a.some((i) => i.type === "image"))
      return null;
    const r = [];
    let o = [];
    const s = () => {
      const i = Em(
        t.parseInline(o)
      );
      o = [], i && r.push(i);
    };
    return a.forEach((i) => {
      if (i.type !== "image") {
        o.push(i);
        return;
      }
      s(), r.push(Xs(i));
    }), s(), r;
  },
  renderMarkdown: (e, t) => Ba(t, e.content, "")
}), vm = ae.create({
  name: "image",
  markdownTokenName: "image",
  parseMarkdown: (e) => Xs(e),
  renderMarkdown: (e) => {
    var r, o, s;
    const t = typeof ((r = e.attrs) == null ? void 0 : r.src) == "string" ? e.attrs.src : "", n = typeof ((o = e.attrs) == null ? void 0 : o.alt) == "string" ? e.attrs.alt : "", a = typeof ((s = e.attrs) == null ? void 0 : s.title) == "string" && e.attrs.title ? ` "${e.attrs.title}"` : "";
    return t ? `![${n}](${fm(t)}${a})` : "";
  }
}), Tm = ae.create({
  name: "tagItem",
  markdownTokenName: "zx_tag",
  markdownTokenizer: {
    name: "zx_tag",
    level: "inline",
    start: "#",
    tokenize: (e, t) => {
      const n = bm(t);
      if (!e.startsWith("#") || !hm(n))
        return;
      const a = e.match(dm);
      if (a)
        return {
          type: "zx_tag",
          raw: a[0],
          text: a[1]
        };
    }
  },
  parseMarkdown: (e) => {
    const t = e;
    return t.text ? {
      type: "tagItem",
      attrs: {
        tagLabel: t.text
      }
    } : null;
  },
  renderMarkdown: (e) => {
    var n;
    const t = typeof ((n = e.attrs) == null ? void 0 : n.tagLabel) == "string" ? e.attrs.tagLabel.trim() : "";
    return t ? `#${t}` : "";
  }
}), wm = (e) => {
  const t = e.split("|").map((r) => r.trim()).filter(Boolean);
  if (!t.length)
    return null;
  if (t.length === 1)
    return {
      name: t[0],
      title: t[0]
    };
  const [n, ...a] = t;
  return {
    name: n,
    title: a.join("|")
  };
}, Nm = ae.create({
  name: "embed",
  markdownTokenName: "zx_embed",
  markdownTokenizer: {
    name: "zx_embed",
    level: "inline",
    start: "[[",
    tokenize: (e) => {
      const t = e.match(gm);
      if (!t)
        return;
      const n = wm(t[1]);
      if (n)
        return {
          type: "zx_embed",
          raw: t[0],
          ...n
        };
    }
  },
  parseMarkdown: (e) => {
    const t = e;
    return {
      type: "embed",
      attrs: {
        name: t.name ?? null,
        title: t.title ?? null
      }
    };
  },
  renderMarkdown: (e) => {
    var r, o;
    const t = typeof ((r = e.attrs) == null ? void 0 : r.name) == "string" ? e.attrs.name.trim() : "", n = typeof ((o = e.attrs) == null ? void 0 : o.title) == "string" ? e.attrs.title.trim() : "";
    return !t && !n ? "" : `[[${t && n && t !== n ? `${t}|${n}` : n || t}]]`;
  }
}), xm = ae.create({
  name: "toggle",
  markdownTokenName: "zx_toggle",
  markdownTokenizer: {
    name: "zx_toggle",
    level: "block",
    start: ":::toggle",
    tokenize: (e, t, n) => {
      var l;
      const a = e.match(mm);
      if (!a)
        return;
      const r = a[0], o = a[1] ?? "", i = (a[2] ?? "").split(`
`), c = i.shift() ?? "";
      return ((l = i[0]) == null ? void 0 : l.trim()) === "" && i.shift(), {
        type: "zx_toggle",
        raw: r,
        open: /\bopen=true\b/.test(o),
        summaryTokens: n.inlineTokens(c),
        contentTokens: n.blockTokens(i.join(`
`))
      };
    }
  },
  parseMarkdown: (e, t) => {
    const n = e, a = t.parseInline(n.summaryTokens ?? []), r = t.parseChildren(n.contentTokens ?? []);
    return {
      type: "toggle",
      attrs: {
        open: !!n.open
      },
      content: [
        {
          type: "toggleSummary",
          content: a.length ? a : void 0
        },
        {
          type: "toggleContent",
          content: r.length ? r : [{ type: "paragraph" }]
        }
      ]
    };
  },
  renderMarkdown: (e, t) => {
    var i;
    const [n, a] = e.content ?? [], r = Ba(t, n == null ? void 0 : n.content, "").trim(), o = Ba(t, a == null ? void 0 : a.content, `

`).trim(), s = `:::toggle open=${(i = e.attrs) != null && i.open ? "true" : "false"}`;
    return r && o ? `${s}
${r}

${o}
:::` : o ? `${s}

${o}
:::` : `${s}
${r}
:::`;
  }
}), Cm = ae.create({
  name: "imageGroup",
  markdownTokenName: "zx_image_group",
  markdownTokenizer: {
    name: "zx_image_group",
    level: "block",
    start: ":::image-group",
    tokenize: (e, t, n) => {
      const a = e.match(pm);
      if (!a)
        return;
      const r = a[0], o = a[1] ?? "", s = a[2] ?? "", i = o.match(/\bcolumns=(\d+)\b/);
      return {
        type: "zx_image_group",
        raw: r,
        columns: Number((i == null ? void 0 : i[1]) ?? 4),
        contentTokens: n.blockTokens(s)
      };
    }
  },
  parseMarkdown: (e, t) => {
    const n = e, a = t.parseChildren(n.contentTokens ?? []).filter((r) => r.type === "image");
    return a.length ? {
      type: "imageGroup",
      attrs: {
        columns: typeof n.columns == "number" && n.columns > 0 ? n.columns : 4
      },
      content: a
    } : null;
  },
  renderMarkdown: (e, t) => {
    var r;
    const n = typeof ((r = e.attrs) == null ? void 0 : r.columns) == "number" && e.attrs.columns > 0 ? e.attrs.columns : 4, a = t.renderChildren(
      (e.content ?? []).filter((o) => o.type === "image"),
      `
`
    ).trim();
    return a ? `:::image-group columns=${n}
${a}
:::` : "";
  }
}), Am = ae.create({
  name: Kt,
  markdownTokenName: "zx_page_break",
  markdownTokenizer: {
    name: "zx_page_break",
    level: "block",
    start: (e) => e.indexOf(kr),
    tokenize: (e) => {
      const t = e.match(/^[ \t]*<!-- zx-page-break -->[ \t]*(?:\n|$)/);
      if (t)
        return {
          type: "zx_page_break",
          raw: t[0]
        };
    }
  },
  parseMarkdown: () => ({
    type: Kt
  }),
  renderMarkdown: () => kr
}), Mm = Dc.extend({
  renderMarkdown: (e, t) => Sm(e, t)
}), no = [
  wr,
  km,
  vm,
  Tm,
  Nm,
  xm,
  Cm,
  Am,
  wr,
  Mm,
  tm,
  am,
  nm,
  Mc,
  Ic,
  Ac
];
let ca = null;
const Zs = (e) => e ? new Tr({
  markedOptions: to,
  extensions: [
    ...lm(e),
    ...no
  ]
}) : (ca || (ca = new Tr({
  markedOptions: to,
  extensions: no
})), ca), Im = (e, t = {}) => {
  const n = Rm(e), a = Zs(t.registry).parse(
    n.markdown
  );
  return Js(
    a,
    n.sidecars,
    t.diagnostics
  );
}, ao = "<!-- zx-code-block:", Om = (e) => {
  const t = e.trim();
  return !t.startsWith(ao) || !t.endsWith("-->") ? null : t.slice(ao.length, -3).trim();
}, ro = (e) => {
  const t = e.match(/^(`{3,}|~{3,})(.*)$/);
  return t ? {
    markerChar: t[1][0],
    markerLength: t[1].length
  } : null;
}, Lm = (e, t, n) => {
  const a = e.trim();
  return a.startsWith(t.repeat(n)) && [...a].every((r) => r === t);
}, Rm = (e) => {
  const t = e.split(`
`), n = [], a = /* @__PURE__ */ new Map();
  let r = 0;
  for (let o = 0; o < t.length; o += 1) {
    const s = Om(t[o] ?? ""), i = ro(t[o + 1] ?? "");
    if (s !== null && i) {
      a.set(r, s);
      continue;
    }
    const c = ro(t[o] ?? "");
    if (!c) {
      n.push(t[o] ?? "");
      continue;
    }
    for (n.push(t[o] ?? ""), o += 1; o < t.length; o += 1)
      if (n.push(t[o] ?? ""), Lm(t[o] ?? "", c.markerChar, c.markerLength)) {
        r += 1;
        break;
      }
  }
  return {
    markdown: n.join(`
`),
    sidecars: a
  };
}, Js = (e, t, n, a = { index: 0 }) => {
  var c, l, d;
  const r = (c = e.content) == null ? void 0 : c.map(
    (u) => Js(u, t, n, a)
  );
  if (e.type !== "codeBlock")
    return {
      ...e,
      content: r
    };
  const o = Jo(t.get(a.index));
  a.index += 1;
  const s = [
    ...Object.keys(o.attrs),
    ...(l = e.attrs) != null && l.language ? ["language"] : []
  ], i = Ge(
    {
      ...o.attrs,
      language: (d = e.attrs) == null ? void 0 : d.language,
      defaultSource: Object.fromEntries(
        Object.keys(o.attrs).map((u) => [u, "node-explicit"])
      )
    },
    {
      explicitKeys: s
    }
  );
  return n == null || n.push(...o.diagnostics, ...i.diagnostics), {
    ...e,
    attrs: i.attrs,
    content: r
  };
}, Dm = /* @__PURE__ */ new Set([
  "bold",
  "italic",
  "strike",
  "code",
  "link"
]), Bm = (e) => {
  if (!(e != null && e.length)) return;
  const t = e.filter((n) => Dm.has(n.type)).map((n) => {
    var a, r;
    return n.type !== "link" ? { type: n.type } : {
      type: "link",
      attrs: {
        href: (a = n.attrs) == null ? void 0 : a.href,
        title: (r = n.attrs) == null ? void 0 : r.title
      }
    };
  });
  return t.length ? t : void 0;
}, Pm = (e) => {
  var t, n, a, r, o, s, i, c, l, d, u;
  switch (e.type) {
    case "heading":
      return typeof ((t = e.attrs) == null ? void 0 : t.level) == "number" ? { level: e.attrs.level } : void 0;
    case "orderedList":
      return typeof ((n = e.attrs) == null ? void 0 : n.start) == "number" ? { start: e.attrs.start } : void 0;
    case "taskItem":
      return {
        checked: !!((a = e.attrs) != null && a.checked)
      };
    case "codeBlock":
      return Ge(
        e.attrs ?? {}
      ).attrs;
    case "image":
      return {
        src: (r = e.attrs) == null ? void 0 : r.src,
        alt: ((o = e.attrs) == null ? void 0 : o.alt) ?? null,
        title: ((s = e.attrs) == null ? void 0 : s.title) ?? null
      };
    case "tagItem":
      return typeof ((i = e.attrs) == null ? void 0 : i.tagLabel) == "string" ? { tagLabel: e.attrs.tagLabel } : void 0;
    case "toggle":
      return {
        open: !!((c = e.attrs) != null && c.open)
      };
    case "imageGroup":
      return typeof ((l = e.attrs) == null ? void 0 : l.columns) == "number" ? { columns: e.attrs.columns } : void 0;
    case "embed": {
      const m = {};
      return typeof ((d = e.attrs) == null ? void 0 : d.name) == "string" && e.attrs.name && (m.name = e.attrs.name), typeof ((u = e.attrs) == null ? void 0 : u.title) == "string" && e.attrs.title && (m.title = e.attrs.title), Object.keys(m).length ? m : void 0;
    }
    default:
      return;
  }
}, js = (e) => {
  var t;
  return {
    type: e.type,
    text: e.text,
    attrs: Pm(e),
    marks: Bm(e.marks),
    content: (t = e.content) == null ? void 0 : t.map(js)
  };
}, Qs = (e, t = {}) => {
  const n = t.mode === "semantic" || t.mode === void 0 ? js(e) : e, a = Zs(t.registry).serialize(n).trim();
  return Hm(
    a,
    n,
    t.diagnostics
  );
}, lh = (e = [], t) => Qs(
  {
    type: "doc",
    content: e
  },
  { registry: t }
), ei = (e, t = []) => {
  var n;
  return e.type === "codeBlock" && t.push(e), (n = e.content) == null || n.forEach((a) => ei(a, t)), t;
}, Fm = (e) => {
  const t = e.match(/^(`{3,}|~{3,})(.*)$/);
  return t ? {
    markerChar: t[1][0],
    markerLength: t[1].length
  } : null;
}, zm = (e, t, n) => {
  const a = e.trim();
  return a.startsWith(t.repeat(n)) && [...a].every((r) => r === t);
}, Hm = (e, t, n) => {
  const a = ei(t);
  if (!a.length) return e;
  const r = a.map((c) => {
    const l = Za(c);
    return n && l.diagnostics.forEach(
      (d) => Je(n, d)
    ), l.markdown;
  }), o = e.split(`
`), s = [];
  let i = 0;
  for (let c = 0; c < o.length; c += 1) {
    const l = Fm(o[c] ?? "");
    if (!l || i >= r.length) {
      s.push(o[c] ?? "");
      continue;
    }
    for (s.push(r[i]), i += 1, c += 1; c < o.length && !zm(o[c] ?? "", l.markerChar, l.markerLength); c += 1)
      ;
  }
  return s.join(`
`).trim();
}, dh = (e, t = {}) => Im(e, t), uh = (e, t = {}) => Qs(e, t);
function $m(e) {
  const t = e.regex, n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }), a = "decltype\\(auto\\)", r = "[a-zA-Z_]\\w*::", s = "(?!struct)(" + a + "|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")", i = {
    className: "type",
    begin: "\\b[a-z\\d_]*_t\\b"
  }, l = {
    className: "string",
    variants: [
      {
        begin: '(u8?|U|L)?"',
        end: '"',
        illegal: "\\n",
        contains: [e.BACKSLASH_ESCAPE]
      },
      {
        begin: "(u8?|U|L)?'(" + "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)" + "|.)",
        end: "'",
        illegal: "."
      },
      e.END_SAME_AS_BEGIN({
        begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
        end: /\)([^()\\ ]{0,16})"/
      })
    ]
  }, d = {
    className: "number",
    variants: [
      // Floating-point literal.
      {
        begin: "[+-]?(?:(?:[0-9](?:'?[0-9])*\\.(?:[0-9](?:'?[0-9])*)?|\\.[0-9](?:'?[0-9])*)(?:[Ee][+-]?[0-9](?:'?[0-9])*)?|[0-9](?:'?[0-9])*[Ee][+-]?[0-9](?:'?[0-9])*|0[Xx](?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*(?:\\.(?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)?)?|\\.[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)[Pp][+-]?[0-9](?:'?[0-9])*)(?:[Ff](?:16|32|64|128)?|(BF|bf)16|[Ll]|)"
      },
      // Integer literal.
      {
        begin: "[+-]?\\b(?:0[Bb][01](?:'?[01])*|0[Xx][0-9A-Fa-f](?:'?[0-9A-Fa-f])*|0(?:'?[0-7])*|[1-9](?:'?[0-9])*)(?:[Uu](?:LL?|ll?)|[Uu][Zz]?|(?:LL?|ll?)[Uu]?|[Zz][Uu]|)"
        // Note: there are user-defined literal suffixes too, but perhaps having the custom suffix not part of the
        // literal highlight actually makes it stand out more.
      }
    ],
    relevance: 0
  }, u = {
    className: "meta",
    begin: /#\s*[a-z]+\b/,
    end: /$/,
    keywords: { keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include" },
    contains: [
      {
        begin: /\\\n/,
        relevance: 0
      },
      e.inherit(l, { className: "string" }),
      {
        className: "string",
        begin: /<.*?>/
      },
      n,
      e.C_BLOCK_COMMENT_MODE
    ]
  }, m = {
    className: "title",
    begin: t.optional(r) + e.IDENT_RE,
    relevance: 0
  }, g = t.optional(r) + e.IDENT_RE + "\\s*\\(", f = [
    "alignas",
    "alignof",
    "and",
    "and_eq",
    "asm",
    "atomic_cancel",
    "atomic_commit",
    "atomic_noexcept",
    "auto",
    "bitand",
    "bitor",
    "break",
    "case",
    "catch",
    "class",
    "co_await",
    "co_return",
    "co_yield",
    "compl",
    "concept",
    "const_cast|10",
    "consteval",
    "constexpr",
    "constinit",
    "continue",
    "decltype",
    "default",
    "delete",
    "do",
    "dynamic_cast|10",
    "else",
    "enum",
    "explicit",
    "export",
    "extern",
    "false",
    "final",
    "for",
    "friend",
    "goto",
    "if",
    "import",
    "inline",
    "module",
    "mutable",
    "namespace",
    "new",
    "noexcept",
    "not",
    "not_eq",
    "nullptr",
    "operator",
    "or",
    "or_eq",
    "override",
    "private",
    "protected",
    "public",
    "reflexpr",
    "register",
    "reinterpret_cast|10",
    "requires",
    "return",
    "sizeof",
    "static_assert",
    "static_cast|10",
    "struct",
    "switch",
    "synchronized",
    "template",
    "this",
    "thread_local",
    "throw",
    "transaction_safe",
    "transaction_safe_dynamic",
    "true",
    "try",
    "typedef",
    "typeid",
    "typename",
    "union",
    "using",
    "virtual",
    "volatile",
    "while",
    "xor",
    "xor_eq"
  ], b = [
    "bool",
    "char",
    "char16_t",
    "char32_t",
    "char8_t",
    "double",
    "float",
    "int",
    "long",
    "short",
    "void",
    "wchar_t",
    "unsigned",
    "signed",
    "const",
    "static"
  ], E = [
    "any",
    "auto_ptr",
    "barrier",
    "binary_semaphore",
    "bitset",
    "complex",
    "condition_variable",
    "condition_variable_any",
    "counting_semaphore",
    "deque",
    "false_type",
    "flat_map",
    "flat_set",
    "future",
    "imaginary",
    "initializer_list",
    "istringstream",
    "jthread",
    "latch",
    "lock_guard",
    "multimap",
    "multiset",
    "mutex",
    "optional",
    "ostringstream",
    "packaged_task",
    "pair",
    "promise",
    "priority_queue",
    "queue",
    "recursive_mutex",
    "recursive_timed_mutex",
    "scoped_lock",
    "set",
    "shared_future",
    "shared_lock",
    "shared_mutex",
    "shared_timed_mutex",
    "shared_ptr",
    "stack",
    "string_view",
    "stringstream",
    "timed_mutex",
    "thread",
    "true_type",
    "tuple",
    "unique_lock",
    "unique_ptr",
    "unordered_map",
    "unordered_multimap",
    "unordered_multiset",
    "unordered_set",
    "variant",
    "vector",
    "weak_ptr",
    "wstring",
    "wstring_view"
  ], _ = [
    "abort",
    "abs",
    "acos",
    "apply",
    "as_const",
    "asin",
    "atan",
    "atan2",
    "calloc",
    "ceil",
    "cerr",
    "cin",
    "clog",
    "cos",
    "cosh",
    "cout",
    "declval",
    "endl",
    "exchange",
    "exit",
    "exp",
    "fabs",
    "floor",
    "fmod",
    "forward",
    "fprintf",
    "fputs",
    "free",
    "frexp",
    "fscanf",
    "future",
    "invoke",
    "isalnum",
    "isalpha",
    "iscntrl",
    "isdigit",
    "isgraph",
    "islower",
    "isprint",
    "ispunct",
    "isspace",
    "isupper",
    "isxdigit",
    "labs",
    "launder",
    "ldexp",
    "log",
    "log10",
    "make_pair",
    "make_shared",
    "make_shared_for_overwrite",
    "make_tuple",
    "make_unique",
    "malloc",
    "memchr",
    "memcmp",
    "memcpy",
    "memset",
    "modf",
    "move",
    "pow",
    "printf",
    "putchar",
    "puts",
    "realloc",
    "scanf",
    "sin",
    "sinh",
    "snprintf",
    "sprintf",
    "sqrt",
    "sscanf",
    "std",
    "stderr",
    "stdin",
    "stdout",
    "strcat",
    "strchr",
    "strcmp",
    "strcpy",
    "strcspn",
    "strlen",
    "strncat",
    "strncmp",
    "strncpy",
    "strpbrk",
    "strrchr",
    "strspn",
    "strstr",
    "swap",
    "tan",
    "tanh",
    "terminate",
    "to_underlying",
    "tolower",
    "toupper",
    "vfprintf",
    "visit",
    "vprintf",
    "vsprintf"
  ], y = {
    type: b,
    keyword: f,
    literal: [
      "NULL",
      "false",
      "nullopt",
      "nullptr",
      "true"
    ],
    built_in: ["_Pragma"],
    _type_hints: E
  }, x = {
    className: "function.dispatch",
    relevance: 0,
    keywords: {
      // Only for relevance, not highlighting.
      _hint: _
    },
    begin: t.concat(
      /\b/,
      /(?!decltype)/,
      /(?!if)/,
      /(?!for)/,
      /(?!switch)/,
      /(?!while)/,
      e.IDENT_RE,
      t.lookahead(/(<[^<>]+>|)\s*\(/)
    )
  }, C = [
    x,
    u,
    i,
    n,
    e.C_BLOCK_COMMENT_MODE,
    d,
    l
  ], O = {
    // This mode covers expression context where we can't expect a function
    // definition and shouldn't highlight anything that looks like one:
    // `return some()`, `else if()`, `(x*sum(1, 2))`
    variants: [
      {
        begin: /=/,
        end: /;/
      },
      {
        begin: /\(/,
        end: /\)/
      },
      {
        beginKeywords: "new throw return else",
        end: /;/
      }
    ],
    keywords: y,
    contains: C.concat([
      {
        begin: /\(/,
        end: /\)/,
        keywords: y,
        contains: C.concat(["self"]),
        relevance: 0
      }
    ]),
    relevance: 0
  }, P = {
    className: "function",
    begin: "(" + s + "[\\*&\\s]+)+" + g,
    returnBegin: !0,
    end: /[{;=]/,
    excludeEnd: !0,
    keywords: y,
    illegal: /[^\w\s\*&:<>.]/,
    contains: [
      {
        // to prevent it from being confused as the function title
        begin: a,
        keywords: y,
        relevance: 0
      },
      {
        begin: g,
        returnBegin: !0,
        contains: [m],
        relevance: 0
      },
      // needed because we do not have look-behind on the below rule
      // to prevent it from grabbing the final : in a :: pair
      {
        begin: /::/,
        relevance: 0
      },
      // initializers
      {
        begin: /:/,
        endsWithParent: !0,
        contains: [
          l,
          d
        ]
      },
      // allow for multiple declarations, e.g.:
      // extern void f(int), g(char);
      {
        relevance: 0,
        match: /,/
      },
      {
        className: "params",
        begin: /\(/,
        end: /\)/,
        keywords: y,
        relevance: 0,
        contains: [
          n,
          e.C_BLOCK_COMMENT_MODE,
          l,
          d,
          i,
          // Count matching parentheses.
          {
            begin: /\(/,
            end: /\)/,
            keywords: y,
            relevance: 0,
            contains: [
              "self",
              n,
              e.C_BLOCK_COMMENT_MODE,
              l,
              d,
              i
            ]
          }
        ]
      },
      i,
      n,
      e.C_BLOCK_COMMENT_MODE,
      u
    ]
  };
  return {
    name: "C++",
    aliases: [
      "cc",
      "c++",
      "h++",
      "hpp",
      "hh",
      "hxx",
      "cxx"
    ],
    keywords: y,
    illegal: "</",
    classNameAliases: { "function.dispatch": "built_in" },
    contains: [].concat(
      O,
      P,
      x,
      C,
      [
        u,
        {
          // containers: ie, `vector <int> rooms (9);`
          begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function|flat_map|flat_set)\\s*<(?!<)",
          end: ">",
          keywords: y,
          contains: [
            "self",
            i
          ]
        },
        {
          begin: e.IDENT_RE + "::",
          keywords: y
        },
        {
          match: [
            // extra complexity to deal with `enum class` and `enum struct`
            /\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/,
            /\s+/,
            /\w+/
          ],
          className: {
            1: "keyword",
            3: "title.class"
          }
        }
      ]
    )
  };
}
function Um(e) {
  const t = {
    type: [
      "boolean",
      "byte",
      "word",
      "String"
    ],
    built_in: [
      "KeyboardController",
      "MouseController",
      "SoftwareSerial",
      "EthernetServer",
      "EthernetClient",
      "LiquidCrystal",
      "RobotControl",
      "GSMVoiceCall",
      "EthernetUDP",
      "EsploraTFT",
      "HttpClient",
      "RobotMotor",
      "WiFiClient",
      "GSMScanner",
      "FileSystem",
      "Scheduler",
      "GSMServer",
      "YunClient",
      "YunServer",
      "IPAddress",
      "GSMClient",
      "GSMModem",
      "Keyboard",
      "Ethernet",
      "Console",
      "GSMBand",
      "Esplora",
      "Stepper",
      "Process",
      "WiFiUDP",
      "GSM_SMS",
      "Mailbox",
      "USBHost",
      "Firmata",
      "PImage",
      "Client",
      "Server",
      "GSMPIN",
      "FileIO",
      "Bridge",
      "Serial",
      "EEPROM",
      "Stream",
      "Mouse",
      "Audio",
      "Servo",
      "File",
      "Task",
      "GPRS",
      "WiFi",
      "Wire",
      "TFT",
      "GSM",
      "SPI",
      "SD"
    ],
    _hints: [
      "setup",
      "loop",
      "runShellCommandAsynchronously",
      "analogWriteResolution",
      "retrieveCallingNumber",
      "printFirmwareVersion",
      "analogReadResolution",
      "sendDigitalPortPair",
      "noListenOnLocalhost",
      "readJoystickButton",
      "setFirmwareVersion",
      "readJoystickSwitch",
      "scrollDisplayRight",
      "getVoiceCallStatus",
      "scrollDisplayLeft",
      "writeMicroseconds",
      "delayMicroseconds",
      "beginTransmission",
      "getSignalStrength",
      "runAsynchronously",
      "getAsynchronously",
      "listenOnLocalhost",
      "getCurrentCarrier",
      "readAccelerometer",
      "messageAvailable",
      "sendDigitalPorts",
      "lineFollowConfig",
      "countryNameWrite",
      "runShellCommand",
      "readStringUntil",
      "rewindDirectory",
      "readTemperature",
      "setClockDivider",
      "readLightSensor",
      "endTransmission",
      "analogReference",
      "detachInterrupt",
      "countryNameRead",
      "attachInterrupt",
      "encryptionType",
      "readBytesUntil",
      "robotNameWrite",
      "readMicrophone",
      "robotNameRead",
      "cityNameWrite",
      "userNameWrite",
      "readJoystickY",
      "readJoystickX",
      "mouseReleased",
      "openNextFile",
      "scanNetworks",
      "noInterrupts",
      "digitalWrite",
      "beginSpeaker",
      "mousePressed",
      "isActionDone",
      "mouseDragged",
      "displayLogos",
      "noAutoscroll",
      "addParameter",
      "remoteNumber",
      "getModifiers",
      "keyboardRead",
      "userNameRead",
      "waitContinue",
      "processInput",
      "parseCommand",
      "printVersion",
      "readNetworks",
      "writeMessage",
      "blinkVersion",
      "cityNameRead",
      "readMessage",
      "setDataMode",
      "parsePacket",
      "isListening",
      "setBitOrder",
      "beginPacket",
      "isDirectory",
      "motorsWrite",
      "drawCompass",
      "digitalRead",
      "clearScreen",
      "serialEvent",
      "rightToLeft",
      "setTextSize",
      "leftToRight",
      "requestFrom",
      "keyReleased",
      "compassRead",
      "analogWrite",
      "interrupts",
      "WiFiServer",
      "disconnect",
      "playMelody",
      "parseFloat",
      "autoscroll",
      "getPINUsed",
      "setPINUsed",
      "setTimeout",
      "sendAnalog",
      "readSlider",
      "analogRead",
      "beginWrite",
      "createChar",
      "motorsStop",
      "keyPressed",
      "tempoWrite",
      "readButton",
      "subnetMask",
      "debugPrint",
      "macAddress",
      "writeGreen",
      "randomSeed",
      "attachGPRS",
      "readString",
      "sendString",
      "remotePort",
      "releaseAll",
      "mouseMoved",
      "background",
      "getXChange",
      "getYChange",
      "answerCall",
      "getResult",
      "voiceCall",
      "endPacket",
      "constrain",
      "getSocket",
      "writeJSON",
      "getButton",
      "available",
      "connected",
      "findUntil",
      "readBytes",
      "exitValue",
      "readGreen",
      "writeBlue",
      "startLoop",
      "IPAddress",
      "isPressed",
      "sendSysex",
      "pauseMode",
      "gatewayIP",
      "setCursor",
      "getOemKey",
      "tuneWrite",
      "noDisplay",
      "loadImage",
      "switchPIN",
      "onRequest",
      "onReceive",
      "changePIN",
      "playFile",
      "noBuffer",
      "parseInt",
      "overflow",
      "checkPIN",
      "knobRead",
      "beginTFT",
      "bitClear",
      "updateIR",
      "bitWrite",
      "position",
      "writeRGB",
      "highByte",
      "writeRed",
      "setSpeed",
      "readBlue",
      "noStroke",
      "remoteIP",
      "transfer",
      "shutdown",
      "hangCall",
      "beginSMS",
      "endWrite",
      "attached",
      "maintain",
      "noCursor",
      "checkReg",
      "checkPUK",
      "shiftOut",
      "isValid",
      "shiftIn",
      "pulseIn",
      "connect",
      "println",
      "localIP",
      "pinMode",
      "getIMEI",
      "display",
      "noBlink",
      "process",
      "getBand",
      "running",
      "beginSD",
      "drawBMP",
      "lowByte",
      "setBand",
      "release",
      "bitRead",
      "prepare",
      "pointTo",
      "readRed",
      "setMode",
      "noFill",
      "remove",
      "listen",
      "stroke",
      "detach",
      "attach",
      "noTone",
      "exists",
      "buffer",
      "height",
      "bitSet",
      "circle",
      "config",
      "cursor",
      "random",
      "IRread",
      "setDNS",
      "endSMS",
      "getKey",
      "micros",
      "millis",
      "begin",
      "print",
      "write",
      "ready",
      "flush",
      "width",
      "isPIN",
      "blink",
      "clear",
      "press",
      "mkdir",
      "rmdir",
      "close",
      "point",
      "yield",
      "image",
      "BSSID",
      "click",
      "delay",
      "read",
      "text",
      "move",
      "peek",
      "beep",
      "rect",
      "line",
      "open",
      "seek",
      "fill",
      "size",
      "turn",
      "stop",
      "home",
      "find",
      "step",
      "tone",
      "sqrt",
      "RSSI",
      "SSID",
      "end",
      "bit",
      "tan",
      "cos",
      "sin",
      "pow",
      "map",
      "abs",
      "max",
      "min",
      "get",
      "run",
      "put"
    ],
    literal: [
      "DIGITAL_MESSAGE",
      "FIRMATA_STRING",
      "ANALOG_MESSAGE",
      "REPORT_DIGITAL",
      "REPORT_ANALOG",
      "INPUT_PULLUP",
      "SET_PIN_MODE",
      "INTERNAL2V56",
      "SYSTEM_RESET",
      "LED_BUILTIN",
      "INTERNAL1V1",
      "SYSEX_START",
      "INTERNAL",
      "EXTERNAL",
      "DEFAULT",
      "OUTPUT",
      "INPUT",
      "HIGH",
      "LOW"
    ]
  }, n = $m(e), a = (
    /** @type {Record<string,any>} */
    n.keywords
  );
  return a.type = [
    ...a.type,
    ...t.type
  ], a.literal = [
    ...a.literal,
    ...t.literal
  ], a.built_in = [
    ...a.built_in,
    ...t.built_in
  ], a._hints = t._hints, n.name = "Arduino", n.aliases = ["ino"], n.supersetOf = "cpp", n;
}
function Gm(e) {
  const t = e.regex, n = {}, a = {
    begin: /\$\{/,
    end: /\}/,
    contains: [
      "self",
      {
        begin: /:-/,
        contains: [n]
      }
      // default values
    ]
  };
  Object.assign(n, {
    className: "variable",
    variants: [
      { begin: t.concat(
        /\$[\w\d#@][\w\d_]*/,
        // negative look-ahead tries to avoid matching patterns that are not
        // Perl at all like $ident$, @ident@, etc.
        "(?![\\w\\d])(?![$])"
      ) },
      a
    ]
  });
  const r = {
    className: "subst",
    begin: /\$\(/,
    end: /\)/,
    contains: [e.BACKSLASH_ESCAPE]
  }, o = e.inherit(
    e.COMMENT(),
    {
      match: [
        /(^|\s)/,
        /#.*$/
      ],
      scope: {
        2: "comment"
      }
    }
  ), s = {
    begin: /<<-?\s*(?=\w+)/,
    starts: { contains: [
      e.END_SAME_AS_BEGIN({
        begin: /(\w+)/,
        end: /(\w+)/,
        className: "string"
      })
    ] }
  }, i = {
    className: "string",
    begin: /"/,
    end: /"/,
    contains: [
      e.BACKSLASH_ESCAPE,
      n,
      r
    ]
  };
  r.contains.push(i);
  const c = {
    match: /\\"/
  }, l = {
    className: "string",
    begin: /'/,
    end: /'/
  }, d = {
    match: /\\'/
  }, u = {
    begin: /\$?\(\(/,
    end: /\)\)/,
    contains: [
      {
        begin: /\d+#[0-9a-f]+/,
        className: "number"
      },
      e.NUMBER_MODE,
      n
    ]
  }, m = [
    "fish",
    "bash",
    "zsh",
    "sh",
    "csh",
    "ksh",
    "tcsh",
    "dash",
    "scsh"
  ], g = e.SHEBANG({
    binary: `(${m.join("|")})`,
    relevance: 10
  }), f = {
    className: "function",
    begin: /\w[\w\d_]*\s*\(\s*\)\s*\{/,
    returnBegin: !0,
    contains: [e.inherit(e.TITLE_MODE, { begin: /\w[\w\d_]*/ })],
    relevance: 0
  }, b = [
    "if",
    "then",
    "else",
    "elif",
    "fi",
    "time",
    "for",
    "while",
    "until",
    "in",
    "do",
    "done",
    "case",
    "esac",
    "coproc",
    "function",
    "select"
  ], E = [
    "true",
    "false"
  ], _ = { match: /(\/[a-z._-]+)+/ }, k = [
    "break",
    "cd",
    "continue",
    "eval",
    "exec",
    "exit",
    "export",
    "getopts",
    "hash",
    "pwd",
    "readonly",
    "return",
    "shift",
    "test",
    "times",
    "trap",
    "umask",
    "unset"
  ], S = [
    "alias",
    "bind",
    "builtin",
    "caller",
    "command",
    "declare",
    "echo",
    "enable",
    "help",
    "let",
    "local",
    "logout",
    "mapfile",
    "printf",
    "read",
    "readarray",
    "source",
    "sudo",
    "type",
    "typeset",
    "ulimit",
    "unalias"
  ], y = [
    "autoload",
    "bg",
    "bindkey",
    "bye",
    "cap",
    "chdir",
    "clone",
    "comparguments",
    "compcall",
    "compctl",
    "compdescribe",
    "compfiles",
    "compgroups",
    "compquote",
    "comptags",
    "comptry",
    "compvalues",
    "dirs",
    "disable",
    "disown",
    "echotc",
    "echoti",
    "emulate",
    "fc",
    "fg",
    "float",
    "functions",
    "getcap",
    "getln",
    "history",
    "integer",
    "jobs",
    "kill",
    "limit",
    "log",
    "noglob",
    "popd",
    "print",
    "pushd",
    "pushln",
    "rehash",
    "sched",
    "setcap",
    "setopt",
    "stat",
    "suspend",
    "ttyctl",
    "unfunction",
    "unhash",
    "unlimit",
    "unsetopt",
    "vared",
    "wait",
    "whence",
    "where",
    "which",
    "zcompile",
    "zformat",
    "zftp",
    "zle",
    "zmodload",
    "zparseopts",
    "zprof",
    "zpty",
    "zregexparse",
    "zsocket",
    "zstyle",
    "ztcp"
  ], x = [
    "chcon",
    "chgrp",
    "chown",
    "chmod",
    "cp",
    "dd",
    "df",
    "dir",
    "dircolors",
    "ln",
    "ls",
    "mkdir",
    "mkfifo",
    "mknod",
    "mktemp",
    "mv",
    "realpath",
    "rm",
    "rmdir",
    "shred",
    "sync",
    "touch",
    "truncate",
    "vdir",
    "b2sum",
    "base32",
    "base64",
    "cat",
    "cksum",
    "comm",
    "csplit",
    "cut",
    "expand",
    "fmt",
    "fold",
    "head",
    "join",
    "md5sum",
    "nl",
    "numfmt",
    "od",
    "paste",
    "ptx",
    "pr",
    "sha1sum",
    "sha224sum",
    "sha256sum",
    "sha384sum",
    "sha512sum",
    "shuf",
    "sort",
    "split",
    "sum",
    "tac",
    "tail",
    "tr",
    "tsort",
    "unexpand",
    "uniq",
    "wc",
    "arch",
    "basename",
    "chroot",
    "date",
    "dirname",
    "du",
    "echo",
    "env",
    "expr",
    "factor",
    // "false", // keyword literal already
    "groups",
    "hostid",
    "id",
    "link",
    "logname",
    "nice",
    "nohup",
    "nproc",
    "pathchk",
    "pinky",
    "printenv",
    "printf",
    "pwd",
    "readlink",
    "runcon",
    "seq",
    "sleep",
    "stat",
    "stdbuf",
    "stty",
    "tee",
    "test",
    "timeout",
    // "true", // keyword literal already
    "tty",
    "uname",
    "unlink",
    "uptime",
    "users",
    "who",
    "whoami",
    "yes"
  ];
  return {
    name: "Bash",
    aliases: [
      "sh",
      "zsh"
    ],
    keywords: {
      $pattern: /\b[a-z][a-z0-9._-]+\b/,
      keyword: b,
      literal: E,
      built_in: [
        ...k,
        ...S,
        // Shell modifiers
        "set",
        "shopt",
        ...y,
        ...x
      ]
    },
    contains: [
      g,
      // to catch known shells and boost relevancy
      e.SHEBANG(),
      // to catch unknown shells but still highlight the shebang
      f,
      u,
      o,
      s,
      _,
      i,
      c,
      l,
      d,
      n
    ]
  };
}
function Km(e) {
  const t = e.regex, n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }), a = "decltype\\(auto\\)", r = "[a-zA-Z_]\\w*::", s = "(" + a + "|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")", i = {
    className: "type",
    variants: [
      { begin: "\\b[a-z\\d_]*_t\\b" },
      { match: /\batomic_[a-z]{3,6}\b/ }
    ]
  }, l = {
    className: "string",
    variants: [
      {
        begin: '(u8?|U|L)?"',
        end: '"',
        illegal: "\\n",
        contains: [e.BACKSLASH_ESCAPE]
      },
      {
        begin: "(u8?|U|L)?'(" + "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)" + "|.)",
        end: "'",
        illegal: "."
      },
      e.END_SAME_AS_BEGIN({
        begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
        end: /\)([^()\\ ]{0,16})"/
      })
    ]
  }, d = {
    className: "number",
    variants: [
      { match: /\b(0b[01']+)/ },
      { match: /(-?)\b([\d']+(\.[\d']*)?|\.[\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)/ },
      { match: /(-?)\b(0[xX][a-fA-F0-9]+(?:'[a-fA-F0-9]+)*(?:\.[a-fA-F0-9]*(?:'[a-fA-F0-9]*)*)?(?:[pP][-+]?[0-9]+)?(l|L)?(u|U)?)/ },
      { match: /(-?)\b\d+(?:'\d+)*(?:\.\d*(?:'\d*)*)?(?:[eE][-+]?\d+)?/ }
    ],
    relevance: 0
  }, u = {
    className: "meta",
    begin: /#\s*[a-z]+\b/,
    end: /$/,
    keywords: { keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef elifdef elifndef include" },
    contains: [
      {
        begin: /\\\n/,
        relevance: 0
      },
      e.inherit(l, { className: "string" }),
      {
        className: "string",
        begin: /<.*?>/
      },
      n,
      e.C_BLOCK_COMMENT_MODE
    ]
  }, m = {
    className: "title",
    begin: t.optional(r) + e.IDENT_RE,
    relevance: 0
  }, g = t.optional(r) + e.IDENT_RE + "\\s*\\(", E = {
    keyword: [
      "asm",
      "auto",
      "break",
      "case",
      "continue",
      "default",
      "do",
      "else",
      "enum",
      "extern",
      "for",
      "fortran",
      "goto",
      "if",
      "inline",
      "register",
      "restrict",
      "return",
      "sizeof",
      "typeof",
      "typeof_unqual",
      "struct",
      "switch",
      "typedef",
      "union",
      "volatile",
      "while",
      "_Alignas",
      "_Alignof",
      "_Atomic",
      "_Generic",
      "_Noreturn",
      "_Static_assert",
      "_Thread_local",
      // aliases
      "alignas",
      "alignof",
      "noreturn",
      "static_assert",
      "thread_local",
      // not a C keyword but is, for all intents and purposes, treated exactly like one.
      "_Pragma"
    ],
    type: [
      "float",
      "double",
      "signed",
      "unsigned",
      "int",
      "short",
      "long",
      "char",
      "void",
      "_Bool",
      "_BitInt",
      "_Complex",
      "_Imaginary",
      "_Decimal32",
      "_Decimal64",
      "_Decimal96",
      "_Decimal128",
      "_Decimal64x",
      "_Decimal128x",
      "_Float16",
      "_Float32",
      "_Float64",
      "_Float128",
      "_Float32x",
      "_Float64x",
      "_Float128x",
      // modifiers
      "const",
      "static",
      "constexpr",
      // aliases
      "complex",
      "bool",
      "imaginary"
    ],
    literal: "true false NULL",
    // TODO: apply hinting work similar to what was done in cpp.js
    built_in: "std string wstring cin cout cerr clog stdin stdout stderr stringstream istringstream ostringstream auto_ptr deque list queue stack vector map set pair bitset multiset multimap unordered_set unordered_map unordered_multiset unordered_multimap priority_queue make_pair array shared_ptr abort terminate abs acos asin atan2 atan calloc ceil cosh cos exit exp fabs floor fmod fprintf fputs free frexp fscanf future isalnum isalpha iscntrl isdigit isgraph islower isprint ispunct isspace isupper isxdigit tolower toupper labs ldexp log10 log malloc realloc memchr memcmp memcpy memset modf pow printf putchar puts scanf sinh sin snprintf sprintf sqrt sscanf strcat strchr strcmp strcpy strcspn strlen strncat strncmp strncpy strpbrk strrchr strspn strstr tanh tan vfprintf vprintf vsprintf endl initializer_list unique_ptr"
  }, _ = [
    u,
    i,
    n,
    e.C_BLOCK_COMMENT_MODE,
    d,
    l
  ], k = {
    // This mode covers expression context where we can't expect a function
    // definition and shouldn't highlight anything that looks like one:
    // `return some()`, `else if()`, `(x*sum(1, 2))`
    variants: [
      {
        begin: /=/,
        end: /;/
      },
      {
        begin: /\(/,
        end: /\)/
      },
      {
        beginKeywords: "new throw return else",
        end: /;/
      }
    ],
    keywords: E,
    contains: _.concat([
      {
        begin: /\(/,
        end: /\)/,
        keywords: E,
        contains: _.concat(["self"]),
        relevance: 0
      }
    ]),
    relevance: 0
  }, S = {
    begin: "(" + s + "[\\*&\\s]+)+" + g,
    returnBegin: !0,
    end: /[{;=]/,
    excludeEnd: !0,
    keywords: E,
    illegal: /[^\w\s\*&:<>.]/,
    contains: [
      {
        // to prevent it from being confused as the function title
        begin: a,
        keywords: E,
        relevance: 0
      },
      {
        begin: g,
        returnBegin: !0,
        contains: [e.inherit(m, { className: "title.function" })],
        relevance: 0
      },
      // allow for multiple declarations, e.g.:
      // extern void f(int), g(char);
      {
        relevance: 0,
        match: /,/
      },
      {
        className: "params",
        begin: /\(/,
        end: /\)/,
        keywords: E,
        relevance: 0,
        contains: [
          n,
          e.C_BLOCK_COMMENT_MODE,
          l,
          d,
          i,
          // Count matching parentheses.
          {
            begin: /\(/,
            end: /\)/,
            keywords: E,
            relevance: 0,
            contains: [
              "self",
              n,
              e.C_BLOCK_COMMENT_MODE,
              l,
              d,
              i
            ]
          }
        ]
      },
      i,
      n,
      e.C_BLOCK_COMMENT_MODE,
      u
    ]
  };
  return {
    name: "C",
    aliases: ["h"],
    keywords: E,
    // Until differentiations are added between `c` and `cpp`, `c` will
    // not be auto-detected to avoid auto-detect conflicts between C and C++
    disableAutodetect: !0,
    illegal: "</",
    contains: [].concat(
      k,
      S,
      _,
      [
        u,
        {
          begin: e.IDENT_RE + "::",
          keywords: E
        },
        {
          className: "class",
          beginKeywords: "enum class struct union",
          end: /[{;:<>=]/,
          contains: [
            { beginKeywords: "final class struct" },
            e.TITLE_MODE
          ]
        }
      ]
    ),
    exports: {
      preprocessor: u,
      strings: l,
      keywords: E
    }
  };
}
function Vm(e) {
  const t = e.regex, n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }), a = "decltype\\(auto\\)", r = "[a-zA-Z_]\\w*::", s = "(?!struct)(" + a + "|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")", i = {
    className: "type",
    begin: "\\b[a-z\\d_]*_t\\b"
  }, l = {
    className: "string",
    variants: [
      {
        begin: '(u8?|U|L)?"',
        end: '"',
        illegal: "\\n",
        contains: [e.BACKSLASH_ESCAPE]
      },
      {
        begin: "(u8?|U|L)?'(" + "\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)" + "|.)",
        end: "'",
        illegal: "."
      },
      e.END_SAME_AS_BEGIN({
        begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
        end: /\)([^()\\ ]{0,16})"/
      })
    ]
  }, d = {
    className: "number",
    variants: [
      // Floating-point literal.
      {
        begin: "[+-]?(?:(?:[0-9](?:'?[0-9])*\\.(?:[0-9](?:'?[0-9])*)?|\\.[0-9](?:'?[0-9])*)(?:[Ee][+-]?[0-9](?:'?[0-9])*)?|[0-9](?:'?[0-9])*[Ee][+-]?[0-9](?:'?[0-9])*|0[Xx](?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*(?:\\.(?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)?)?|\\.[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)[Pp][+-]?[0-9](?:'?[0-9])*)(?:[Ff](?:16|32|64|128)?|(BF|bf)16|[Ll]|)"
      },
      // Integer literal.
      {
        begin: "[+-]?\\b(?:0[Bb][01](?:'?[01])*|0[Xx][0-9A-Fa-f](?:'?[0-9A-Fa-f])*|0(?:'?[0-7])*|[1-9](?:'?[0-9])*)(?:[Uu](?:LL?|ll?)|[Uu][Zz]?|(?:LL?|ll?)[Uu]?|[Zz][Uu]|)"
        // Note: there are user-defined literal suffixes too, but perhaps having the custom suffix not part of the
        // literal highlight actually makes it stand out more.
      }
    ],
    relevance: 0
  }, u = {
    className: "meta",
    begin: /#\s*[a-z]+\b/,
    end: /$/,
    keywords: { keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include" },
    contains: [
      {
        begin: /\\\n/,
        relevance: 0
      },
      e.inherit(l, { className: "string" }),
      {
        className: "string",
        begin: /<.*?>/
      },
      n,
      e.C_BLOCK_COMMENT_MODE
    ]
  }, m = {
    className: "title",
    begin: t.optional(r) + e.IDENT_RE,
    relevance: 0
  }, g = t.optional(r) + e.IDENT_RE + "\\s*\\(", f = [
    "alignas",
    "alignof",
    "and",
    "and_eq",
    "asm",
    "atomic_cancel",
    "atomic_commit",
    "atomic_noexcept",
    "auto",
    "bitand",
    "bitor",
    "break",
    "case",
    "catch",
    "class",
    "co_await",
    "co_return",
    "co_yield",
    "compl",
    "concept",
    "const_cast|10",
    "consteval",
    "constexpr",
    "constinit",
    "continue",
    "decltype",
    "default",
    "delete",
    "do",
    "dynamic_cast|10",
    "else",
    "enum",
    "explicit",
    "export",
    "extern",
    "false",
    "final",
    "for",
    "friend",
    "goto",
    "if",
    "import",
    "inline",
    "module",
    "mutable",
    "namespace",
    "new",
    "noexcept",
    "not",
    "not_eq",
    "nullptr",
    "operator",
    "or",
    "or_eq",
    "override",
    "private",
    "protected",
    "public",
    "reflexpr",
    "register",
    "reinterpret_cast|10",
    "requires",
    "return",
    "sizeof",
    "static_assert",
    "static_cast|10",
    "struct",
    "switch",
    "synchronized",
    "template",
    "this",
    "thread_local",
    "throw",
    "transaction_safe",
    "transaction_safe_dynamic",
    "true",
    "try",
    "typedef",
    "typeid",
    "typename",
    "union",
    "using",
    "virtual",
    "volatile",
    "while",
    "xor",
    "xor_eq"
  ], b = [
    "bool",
    "char",
    "char16_t",
    "char32_t",
    "char8_t",
    "double",
    "float",
    "int",
    "long",
    "short",
    "void",
    "wchar_t",
    "unsigned",
    "signed",
    "const",
    "static"
  ], E = [
    "any",
    "auto_ptr",
    "barrier",
    "binary_semaphore",
    "bitset",
    "complex",
    "condition_variable",
    "condition_variable_any",
    "counting_semaphore",
    "deque",
    "false_type",
    "flat_map",
    "flat_set",
    "future",
    "imaginary",
    "initializer_list",
    "istringstream",
    "jthread",
    "latch",
    "lock_guard",
    "multimap",
    "multiset",
    "mutex",
    "optional",
    "ostringstream",
    "packaged_task",
    "pair",
    "promise",
    "priority_queue",
    "queue",
    "recursive_mutex",
    "recursive_timed_mutex",
    "scoped_lock",
    "set",
    "shared_future",
    "shared_lock",
    "shared_mutex",
    "shared_timed_mutex",
    "shared_ptr",
    "stack",
    "string_view",
    "stringstream",
    "timed_mutex",
    "thread",
    "true_type",
    "tuple",
    "unique_lock",
    "unique_ptr",
    "unordered_map",
    "unordered_multimap",
    "unordered_multiset",
    "unordered_set",
    "variant",
    "vector",
    "weak_ptr",
    "wstring",
    "wstring_view"
  ], _ = [
    "abort",
    "abs",
    "acos",
    "apply",
    "as_const",
    "asin",
    "atan",
    "atan2",
    "calloc",
    "ceil",
    "cerr",
    "cin",
    "clog",
    "cos",
    "cosh",
    "cout",
    "declval",
    "endl",
    "exchange",
    "exit",
    "exp",
    "fabs",
    "floor",
    "fmod",
    "forward",
    "fprintf",
    "fputs",
    "free",
    "frexp",
    "fscanf",
    "future",
    "invoke",
    "isalnum",
    "isalpha",
    "iscntrl",
    "isdigit",
    "isgraph",
    "islower",
    "isprint",
    "ispunct",
    "isspace",
    "isupper",
    "isxdigit",
    "labs",
    "launder",
    "ldexp",
    "log",
    "log10",
    "make_pair",
    "make_shared",
    "make_shared_for_overwrite",
    "make_tuple",
    "make_unique",
    "malloc",
    "memchr",
    "memcmp",
    "memcpy",
    "memset",
    "modf",
    "move",
    "pow",
    "printf",
    "putchar",
    "puts",
    "realloc",
    "scanf",
    "sin",
    "sinh",
    "snprintf",
    "sprintf",
    "sqrt",
    "sscanf",
    "std",
    "stderr",
    "stdin",
    "stdout",
    "strcat",
    "strchr",
    "strcmp",
    "strcpy",
    "strcspn",
    "strlen",
    "strncat",
    "strncmp",
    "strncpy",
    "strpbrk",
    "strrchr",
    "strspn",
    "strstr",
    "swap",
    "tan",
    "tanh",
    "terminate",
    "to_underlying",
    "tolower",
    "toupper",
    "vfprintf",
    "visit",
    "vprintf",
    "vsprintf"
  ], y = {
    type: b,
    keyword: f,
    literal: [
      "NULL",
      "false",
      "nullopt",
      "nullptr",
      "true"
    ],
    built_in: ["_Pragma"],
    _type_hints: E
  }, x = {
    className: "function.dispatch",
    relevance: 0,
    keywords: {
      // Only for relevance, not highlighting.
      _hint: _
    },
    begin: t.concat(
      /\b/,
      /(?!decltype)/,
      /(?!if)/,
      /(?!for)/,
      /(?!switch)/,
      /(?!while)/,
      e.IDENT_RE,
      t.lookahead(/(<[^<>]+>|)\s*\(/)
    )
  }, C = [
    x,
    u,
    i,
    n,
    e.C_BLOCK_COMMENT_MODE,
    d,
    l
  ], O = {
    // This mode covers expression context where we can't expect a function
    // definition and shouldn't highlight anything that looks like one:
    // `return some()`, `else if()`, `(x*sum(1, 2))`
    variants: [
      {
        begin: /=/,
        end: /;/
      },
      {
        begin: /\(/,
        end: /\)/
      },
      {
        beginKeywords: "new throw return else",
        end: /;/
      }
    ],
    keywords: y,
    contains: C.concat([
      {
        begin: /\(/,
        end: /\)/,
        keywords: y,
        contains: C.concat(["self"]),
        relevance: 0
      }
    ]),
    relevance: 0
  }, P = {
    className: "function",
    begin: "(" + s + "[\\*&\\s]+)+" + g,
    returnBegin: !0,
    end: /[{;=]/,
    excludeEnd: !0,
    keywords: y,
    illegal: /[^\w\s\*&:<>.]/,
    contains: [
      {
        // to prevent it from being confused as the function title
        begin: a,
        keywords: y,
        relevance: 0
      },
      {
        begin: g,
        returnBegin: !0,
        contains: [m],
        relevance: 0
      },
      // needed because we do not have look-behind on the below rule
      // to prevent it from grabbing the final : in a :: pair
      {
        begin: /::/,
        relevance: 0
      },
      // initializers
      {
        begin: /:/,
        endsWithParent: !0,
        contains: [
          l,
          d
        ]
      },
      // allow for multiple declarations, e.g.:
      // extern void f(int), g(char);
      {
        relevance: 0,
        match: /,/
      },
      {
        className: "params",
        begin: /\(/,
        end: /\)/,
        keywords: y,
        relevance: 0,
        contains: [
          n,
          e.C_BLOCK_COMMENT_MODE,
          l,
          d,
          i,
          // Count matching parentheses.
          {
            begin: /\(/,
            end: /\)/,
            keywords: y,
            relevance: 0,
            contains: [
              "self",
              n,
              e.C_BLOCK_COMMENT_MODE,
              l,
              d,
              i
            ]
          }
        ]
      },
      i,
      n,
      e.C_BLOCK_COMMENT_MODE,
      u
    ]
  };
  return {
    name: "C++",
    aliases: [
      "cc",
      "c++",
      "h++",
      "hpp",
      "hh",
      "hxx",
      "cxx"
    ],
    keywords: y,
    illegal: "</",
    classNameAliases: { "function.dispatch": "built_in" },
    contains: [].concat(
      O,
      P,
      x,
      C,
      [
        u,
        {
          // containers: ie, `vector <int> rooms (9);`
          begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function|flat_map|flat_set)\\s*<(?!<)",
          end: ">",
          keywords: y,
          contains: [
            "self",
            i
          ]
        },
        {
          begin: e.IDENT_RE + "::",
          keywords: y
        },
        {
          match: [
            // extra complexity to deal with `enum class` and `enum struct`
            /\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/,
            /\s+/,
            /\w+/
          ],
          className: {
            1: "keyword",
            3: "title.class"
          }
        }
      ]
    )
  };
}
function Wm(e) {
  const t = [
    "bool",
    "byte",
    "char",
    "decimal",
    "delegate",
    "double",
    "dynamic",
    "enum",
    "float",
    "int",
    "long",
    "nint",
    "nuint",
    "object",
    "sbyte",
    "short",
    "string",
    "ulong",
    "uint",
    "ushort"
  ], n = [
    "public",
    "private",
    "protected",
    "static",
    "internal",
    "protected",
    "abstract",
    "async",
    "extern",
    "override",
    "unsafe",
    "virtual",
    "new",
    "sealed",
    "partial"
  ], a = [
    "default",
    "false",
    "null",
    "true"
  ], r = [
    "abstract",
    "as",
    "base",
    "break",
    "case",
    "catch",
    "class",
    "const",
    "continue",
    "do",
    "else",
    "event",
    "explicit",
    "extern",
    "finally",
    "fixed",
    "for",
    "foreach",
    "goto",
    "if",
    "implicit",
    "in",
    "interface",
    "internal",
    "is",
    "lock",
    "namespace",
    "new",
    "operator",
    "out",
    "override",
    "params",
    "private",
    "protected",
    "public",
    "readonly",
    "record",
    "ref",
    "return",
    "scoped",
    "sealed",
    "sizeof",
    "stackalloc",
    "static",
    "struct",
    "switch",
    "this",
    "throw",
    "try",
    "typeof",
    "unchecked",
    "unsafe",
    "using",
    "virtual",
    "void",
    "volatile",
    "while"
  ], o = [
    "add",
    "alias",
    "and",
    "ascending",
    "args",
    "async",
    "await",
    "by",
    "descending",
    "dynamic",
    "equals",
    "file",
    "from",
    "get",
    "global",
    "group",
    "init",
    "into",
    "join",
    "let",
    "nameof",
    "not",
    "notnull",
    "on",
    "or",
    "orderby",
    "partial",
    "record",
    "remove",
    "required",
    "scoped",
    "select",
    "set",
    "unmanaged",
    "value|0",
    "var",
    "when",
    "where",
    "with",
    "yield"
  ], s = {
    keyword: r.concat(o),
    built_in: t,
    literal: a
  }, i = e.inherit(e.TITLE_MODE, { begin: "[a-zA-Z](\\.?\\w)*" }), c = {
    className: "number",
    variants: [
      { begin: "\\b(0b[01']+)" },
      { begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)(u|U|l|L|ul|UL|f|F|b|B)" },
      { begin: "(-?)(\\b0[xX][a-fA-F0-9']+|(\\b[\\d']+(\\.[\\d']*)?|\\.[\\d']+)([eE][-+]?[\\d']+)?)" }
    ],
    relevance: 0
  }, l = {
    className: "string",
    begin: /"""("*)(?!")(.|\n)*?"""\1/,
    relevance: 1
  }, d = {
    className: "string",
    begin: '@"',
    end: '"',
    contains: [{ begin: '""' }]
  }, u = e.inherit(d, { illegal: /\n/ }), m = {
    className: "subst",
    begin: /\{/,
    end: /\}/,
    keywords: s
  }, g = e.inherit(m, { illegal: /\n/ }), f = {
    className: "string",
    begin: /\$"/,
    end: '"',
    illegal: /\n/,
    contains: [
      { begin: /\{\{/ },
      { begin: /\}\}/ },
      e.BACKSLASH_ESCAPE,
      g
    ]
  }, b = {
    className: "string",
    begin: /\$@"/,
    end: '"',
    contains: [
      { begin: /\{\{/ },
      { begin: /\}\}/ },
      { begin: '""' },
      m
    ]
  }, E = e.inherit(b, {
    illegal: /\n/,
    contains: [
      { begin: /\{\{/ },
      { begin: /\}\}/ },
      { begin: '""' },
      g
    ]
  });
  m.contains = [
    b,
    f,
    d,
    e.APOS_STRING_MODE,
    e.QUOTE_STRING_MODE,
    c,
    e.C_BLOCK_COMMENT_MODE
  ], g.contains = [
    E,
    f,
    u,
    e.APOS_STRING_MODE,
    e.QUOTE_STRING_MODE,
    c,
    e.inherit(e.C_BLOCK_COMMENT_MODE, { illegal: /\n/ })
  ];
  const _ = { variants: [
    l,
    b,
    f,
    d,
    e.APOS_STRING_MODE,
    e.QUOTE_STRING_MODE
  ] }, k = {
    begin: "<",
    end: ">",
    contains: [
      { beginKeywords: "in out" },
      i
    ]
  }, S = e.IDENT_RE + "(<" + e.IDENT_RE + "(\\s*,\\s*" + e.IDENT_RE + ")*>)?(\\[\\])?", y = {
    // prevents expressions like `@class` from incorrect flagging
    // `class` as a keyword
    begin: "@" + e.IDENT_RE,
    relevance: 0
  };
  return {
    name: "C#",
    aliases: [
      "cs",
      "c#"
    ],
    keywords: s,
    illegal: /::/,
    contains: [
      e.COMMENT(
        "///",
        "$",
        {
          returnBegin: !0,
          contains: [
            {
              className: "doctag",
              variants: [
                {
                  begin: "///",
                  relevance: 0
                },
                { begin: "<!--|-->" },
                {
                  begin: "</?",
                  end: ">"
                }
              ]
            }
          ]
        }
      ),
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      {
        className: "meta",
        begin: "#",
        end: "$",
        keywords: { keyword: "if else elif endif define undef warning error line region endregion pragma checksum" }
      },
      _,
      c,
      {
        beginKeywords: "class interface",
        relevance: 0,
        end: /[{;=]/,
        illegal: /[^\s:,]/,
        contains: [
          { beginKeywords: "where class" },
          i,
          k,
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      {
        beginKeywords: "namespace",
        relevance: 0,
        end: /[{;=]/,
        illegal: /[^\s:]/,
        contains: [
          i,
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      {
        beginKeywords: "record",
        relevance: 0,
        end: /[{;=]/,
        illegal: /[^\s:]/,
        contains: [
          i,
          k,
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      {
        // [Attributes("")]
        className: "meta",
        begin: "^\\s*\\[(?=[\\w])",
        excludeBegin: !0,
        end: "\\]",
        excludeEnd: !0,
        contains: [
          {
            className: "string",
            begin: /"/,
            end: /"/
          }
        ]
      },
      {
        // Expression keywords prevent 'keyword Name(...)' from being
        // recognized as a function definition
        beginKeywords: "new return throw await else",
        relevance: 0
      },
      {
        className: "function",
        begin: "(" + S + "\\s+)+" + e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
        returnBegin: !0,
        end: /\s*[{;=]/,
        excludeEnd: !0,
        keywords: s,
        contains: [
          // prevents these from being highlighted `title`
          {
            beginKeywords: n.join(" "),
            relevance: 0
          },
          {
            begin: e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
            returnBegin: !0,
            contains: [
              e.TITLE_MODE,
              k
            ],
            relevance: 0
          },
          { match: /\(\)/ },
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: s,
            relevance: 0,
            contains: [
              _,
              c,
              e.C_BLOCK_COMMENT_MODE
            ]
          },
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      y
    ]
  };
}
const qm = (e) => ({
  IMPORTANT: {
    scope: "meta",
    begin: "!important"
  },
  BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
  HEXCOLOR: {
    scope: "number",
    begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
  },
  FUNCTION_DISPATCH: {
    className: "built_in",
    begin: /[\w-]+(?=\()/
  },
  ATTRIBUTE_SELECTOR_MODE: {
    scope: "selector-attr",
    begin: /\[/,
    end: /\]/,
    illegal: "$",
    contains: [
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE
    ]
  },
  CSS_NUMBER_MODE: {
    scope: "number",
    begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
    relevance: 0
  },
  CSS_VARIABLE: {
    className: "attr",
    begin: /--[A-Za-z_][A-Za-z0-9_-]*/
  }
}), Ym = [
  "a",
  "abbr",
  "address",
  "article",
  "aside",
  "audio",
  "b",
  "blockquote",
  "body",
  "button",
  "canvas",
  "caption",
  "cite",
  "code",
  "dd",
  "del",
  "details",
  "dfn",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "header",
  "hgroup",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "main",
  "mark",
  "menu",
  "nav",
  "object",
  "ol",
  "optgroup",
  "option",
  "p",
  "picture",
  "q",
  "quote",
  "samp",
  "section",
  "select",
  "source",
  "span",
  "strong",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "ul",
  "var",
  "video"
], Xm = [
  "defs",
  "g",
  "marker",
  "mask",
  "pattern",
  "svg",
  "switch",
  "symbol",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feFlood",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTile",
  "feTurbulence",
  "linearGradient",
  "radialGradient",
  "stop",
  "circle",
  "ellipse",
  "image",
  "line",
  "path",
  "polygon",
  "polyline",
  "rect",
  "text",
  "use",
  "textPath",
  "tspan",
  "foreignObject",
  "clipPath"
], Zm = [
  ...Ym,
  ...Xm
], Jm = [
  "any-hover",
  "any-pointer",
  "aspect-ratio",
  "color",
  "color-gamut",
  "color-index",
  "device-aspect-ratio",
  "device-height",
  "device-width",
  "display-mode",
  "forced-colors",
  "grid",
  "height",
  "hover",
  "inverted-colors",
  "monochrome",
  "orientation",
  "overflow-block",
  "overflow-inline",
  "pointer",
  "prefers-color-scheme",
  "prefers-contrast",
  "prefers-reduced-motion",
  "prefers-reduced-transparency",
  "resolution",
  "scan",
  "scripting",
  "update",
  "width",
  // TODO: find a better solution?
  "min-width",
  "max-width",
  "min-height",
  "max-height"
].sort().reverse(), jm = [
  "active",
  "any-link",
  "blank",
  "checked",
  "current",
  "default",
  "defined",
  "dir",
  // dir()
  "disabled",
  "drop",
  "empty",
  "enabled",
  "first",
  "first-child",
  "first-of-type",
  "fullscreen",
  "future",
  "focus",
  "focus-visible",
  "focus-within",
  "has",
  // has()
  "host",
  // host or host()
  "host-context",
  // host-context()
  "hover",
  "indeterminate",
  "in-range",
  "invalid",
  "is",
  // is()
  "lang",
  // lang()
  "last-child",
  "last-of-type",
  "left",
  "link",
  "local-link",
  "not",
  // not()
  "nth-child",
  // nth-child()
  "nth-col",
  // nth-col()
  "nth-last-child",
  // nth-last-child()
  "nth-last-col",
  // nth-last-col()
  "nth-last-of-type",
  //nth-last-of-type()
  "nth-of-type",
  //nth-of-type()
  "only-child",
  "only-of-type",
  "optional",
  "out-of-range",
  "past",
  "placeholder-shown",
  "read-only",
  "read-write",
  "required",
  "right",
  "root",
  "scope",
  "target",
  "target-within",
  "user-invalid",
  "valid",
  "visited",
  "where"
  // where()
].sort().reverse(), Qm = [
  "after",
  "backdrop",
  "before",
  "cue",
  "cue-region",
  "first-letter",
  "first-line",
  "grammar-error",
  "marker",
  "part",
  "placeholder",
  "selection",
  "slotted",
  "spelling-error"
].sort().reverse(), ep = [
  "accent-color",
  "align-content",
  "align-items",
  "align-self",
  "alignment-baseline",
  "all",
  "anchor-name",
  "animation",
  "animation-composition",
  "animation-delay",
  "animation-direction",
  "animation-duration",
  "animation-fill-mode",
  "animation-iteration-count",
  "animation-name",
  "animation-play-state",
  "animation-range",
  "animation-range-end",
  "animation-range-start",
  "animation-timeline",
  "animation-timing-function",
  "appearance",
  "aspect-ratio",
  "backdrop-filter",
  "backface-visibility",
  "background",
  "background-attachment",
  "background-blend-mode",
  "background-clip",
  "background-color",
  "background-image",
  "background-origin",
  "background-position",
  "background-position-x",
  "background-position-y",
  "background-repeat",
  "background-size",
  "baseline-shift",
  "block-size",
  "border",
  "border-block",
  "border-block-color",
  "border-block-end",
  "border-block-end-color",
  "border-block-end-style",
  "border-block-end-width",
  "border-block-start",
  "border-block-start-color",
  "border-block-start-style",
  "border-block-start-width",
  "border-block-style",
  "border-block-width",
  "border-bottom",
  "border-bottom-color",
  "border-bottom-left-radius",
  "border-bottom-right-radius",
  "border-bottom-style",
  "border-bottom-width",
  "border-collapse",
  "border-color",
  "border-end-end-radius",
  "border-end-start-radius",
  "border-image",
  "border-image-outset",
  "border-image-repeat",
  "border-image-slice",
  "border-image-source",
  "border-image-width",
  "border-inline",
  "border-inline-color",
  "border-inline-end",
  "border-inline-end-color",
  "border-inline-end-style",
  "border-inline-end-width",
  "border-inline-start",
  "border-inline-start-color",
  "border-inline-start-style",
  "border-inline-start-width",
  "border-inline-style",
  "border-inline-width",
  "border-left",
  "border-left-color",
  "border-left-style",
  "border-left-width",
  "border-radius",
  "border-right",
  "border-right-color",
  "border-right-style",
  "border-right-width",
  "border-spacing",
  "border-start-end-radius",
  "border-start-start-radius",
  "border-style",
  "border-top",
  "border-top-color",
  "border-top-left-radius",
  "border-top-right-radius",
  "border-top-style",
  "border-top-width",
  "border-width",
  "bottom",
  "box-align",
  "box-decoration-break",
  "box-direction",
  "box-flex",
  "box-flex-group",
  "box-lines",
  "box-ordinal-group",
  "box-orient",
  "box-pack",
  "box-shadow",
  "box-sizing",
  "break-after",
  "break-before",
  "break-inside",
  "caption-side",
  "caret-color",
  "clear",
  "clip",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "color-scheme",
  "column-count",
  "column-fill",
  "column-gap",
  "column-rule",
  "column-rule-color",
  "column-rule-style",
  "column-rule-width",
  "column-span",
  "column-width",
  "columns",
  "contain",
  "contain-intrinsic-block-size",
  "contain-intrinsic-height",
  "contain-intrinsic-inline-size",
  "contain-intrinsic-size",
  "contain-intrinsic-width",
  "container",
  "container-name",
  "container-type",
  "content",
  "content-visibility",
  "counter-increment",
  "counter-reset",
  "counter-set",
  "cue",
  "cue-after",
  "cue-before",
  "cursor",
  "cx",
  "cy",
  "direction",
  "display",
  "dominant-baseline",
  "empty-cells",
  "enable-background",
  "field-sizing",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "flex",
  "flex-basis",
  "flex-direction",
  "flex-flow",
  "flex-grow",
  "flex-shrink",
  "flex-wrap",
  "float",
  "flood-color",
  "flood-opacity",
  "flow",
  "font",
  "font-display",
  "font-family",
  "font-feature-settings",
  "font-kerning",
  "font-language-override",
  "font-optical-sizing",
  "font-palette",
  "font-size",
  "font-size-adjust",
  "font-smooth",
  "font-smoothing",
  "font-stretch",
  "font-style",
  "font-synthesis",
  "font-synthesis-position",
  "font-synthesis-small-caps",
  "font-synthesis-style",
  "font-synthesis-weight",
  "font-variant",
  "font-variant-alternates",
  "font-variant-caps",
  "font-variant-east-asian",
  "font-variant-emoji",
  "font-variant-ligatures",
  "font-variant-numeric",
  "font-variant-position",
  "font-variation-settings",
  "font-weight",
  "forced-color-adjust",
  "gap",
  "glyph-orientation-horizontal",
  "glyph-orientation-vertical",
  "grid",
  "grid-area",
  "grid-auto-columns",
  "grid-auto-flow",
  "grid-auto-rows",
  "grid-column",
  "grid-column-end",
  "grid-column-start",
  "grid-gap",
  "grid-row",
  "grid-row-end",
  "grid-row-start",
  "grid-template",
  "grid-template-areas",
  "grid-template-columns",
  "grid-template-rows",
  "hanging-punctuation",
  "height",
  "hyphenate-character",
  "hyphenate-limit-chars",
  "hyphens",
  "icon",
  "image-orientation",
  "image-rendering",
  "image-resolution",
  "ime-mode",
  "initial-letter",
  "initial-letter-align",
  "inline-size",
  "inset",
  "inset-area",
  "inset-block",
  "inset-block-end",
  "inset-block-start",
  "inset-inline",
  "inset-inline-end",
  "inset-inline-start",
  "isolation",
  "justify-content",
  "justify-items",
  "justify-self",
  "kerning",
  "left",
  "letter-spacing",
  "lighting-color",
  "line-break",
  "line-height",
  "line-height-step",
  "list-style",
  "list-style-image",
  "list-style-position",
  "list-style-type",
  "margin",
  "margin-block",
  "margin-block-end",
  "margin-block-start",
  "margin-bottom",
  "margin-inline",
  "margin-inline-end",
  "margin-inline-start",
  "margin-left",
  "margin-right",
  "margin-top",
  "margin-trim",
  "marker",
  "marker-end",
  "marker-mid",
  "marker-start",
  "marks",
  "mask",
  "mask-border",
  "mask-border-mode",
  "mask-border-outset",
  "mask-border-repeat",
  "mask-border-slice",
  "mask-border-source",
  "mask-border-width",
  "mask-clip",
  "mask-composite",
  "mask-image",
  "mask-mode",
  "mask-origin",
  "mask-position",
  "mask-repeat",
  "mask-size",
  "mask-type",
  "masonry-auto-flow",
  "math-depth",
  "math-shift",
  "math-style",
  "max-block-size",
  "max-height",
  "max-inline-size",
  "max-width",
  "min-block-size",
  "min-height",
  "min-inline-size",
  "min-width",
  "mix-blend-mode",
  "nav-down",
  "nav-index",
  "nav-left",
  "nav-right",
  "nav-up",
  "none",
  "normal",
  "object-fit",
  "object-position",
  "offset",
  "offset-anchor",
  "offset-distance",
  "offset-path",
  "offset-position",
  "offset-rotate",
  "opacity",
  "order",
  "orphans",
  "outline",
  "outline-color",
  "outline-offset",
  "outline-style",
  "outline-width",
  "overflow",
  "overflow-anchor",
  "overflow-block",
  "overflow-clip-margin",
  "overflow-inline",
  "overflow-wrap",
  "overflow-x",
  "overflow-y",
  "overlay",
  "overscroll-behavior",
  "overscroll-behavior-block",
  "overscroll-behavior-inline",
  "overscroll-behavior-x",
  "overscroll-behavior-y",
  "padding",
  "padding-block",
  "padding-block-end",
  "padding-block-start",
  "padding-bottom",
  "padding-inline",
  "padding-inline-end",
  "padding-inline-start",
  "padding-left",
  "padding-right",
  "padding-top",
  "page",
  "page-break-after",
  "page-break-before",
  "page-break-inside",
  "paint-order",
  "pause",
  "pause-after",
  "pause-before",
  "perspective",
  "perspective-origin",
  "place-content",
  "place-items",
  "place-self",
  "pointer-events",
  "position",
  "position-anchor",
  "position-visibility",
  "print-color-adjust",
  "quotes",
  "r",
  "resize",
  "rest",
  "rest-after",
  "rest-before",
  "right",
  "rotate",
  "row-gap",
  "ruby-align",
  "ruby-position",
  "scale",
  "scroll-behavior",
  "scroll-margin",
  "scroll-margin-block",
  "scroll-margin-block-end",
  "scroll-margin-block-start",
  "scroll-margin-bottom",
  "scroll-margin-inline",
  "scroll-margin-inline-end",
  "scroll-margin-inline-start",
  "scroll-margin-left",
  "scroll-margin-right",
  "scroll-margin-top",
  "scroll-padding",
  "scroll-padding-block",
  "scroll-padding-block-end",
  "scroll-padding-block-start",
  "scroll-padding-bottom",
  "scroll-padding-inline",
  "scroll-padding-inline-end",
  "scroll-padding-inline-start",
  "scroll-padding-left",
  "scroll-padding-right",
  "scroll-padding-top",
  "scroll-snap-align",
  "scroll-snap-stop",
  "scroll-snap-type",
  "scroll-timeline",
  "scroll-timeline-axis",
  "scroll-timeline-name",
  "scrollbar-color",
  "scrollbar-gutter",
  "scrollbar-width",
  "shape-image-threshold",
  "shape-margin",
  "shape-outside",
  "shape-rendering",
  "speak",
  "speak-as",
  "src",
  // @font-face
  "stop-color",
  "stop-opacity",
  "stroke",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke-width",
  "tab-size",
  "table-layout",
  "text-align",
  "text-align-all",
  "text-align-last",
  "text-anchor",
  "text-combine-upright",
  "text-decoration",
  "text-decoration-color",
  "text-decoration-line",
  "text-decoration-skip",
  "text-decoration-skip-ink",
  "text-decoration-style",
  "text-decoration-thickness",
  "text-emphasis",
  "text-emphasis-color",
  "text-emphasis-position",
  "text-emphasis-style",
  "text-indent",
  "text-justify",
  "text-orientation",
  "text-overflow",
  "text-rendering",
  "text-shadow",
  "text-size-adjust",
  "text-transform",
  "text-underline-offset",
  "text-underline-position",
  "text-wrap",
  "text-wrap-mode",
  "text-wrap-style",
  "timeline-scope",
  "top",
  "touch-action",
  "transform",
  "transform-box",
  "transform-origin",
  "transform-style",
  "transition",
  "transition-behavior",
  "transition-delay",
  "transition-duration",
  "transition-property",
  "transition-timing-function",
  "translate",
  "unicode-bidi",
  "user-modify",
  "user-select",
  "vector-effect",
  "vertical-align",
  "view-timeline",
  "view-timeline-axis",
  "view-timeline-inset",
  "view-timeline-name",
  "view-transition-name",
  "visibility",
  "voice-balance",
  "voice-duration",
  "voice-family",
  "voice-pitch",
  "voice-range",
  "voice-rate",
  "voice-stress",
  "voice-volume",
  "white-space",
  "white-space-collapse",
  "widows",
  "width",
  "will-change",
  "word-break",
  "word-spacing",
  "word-wrap",
  "writing-mode",
  "x",
  "y",
  "z-index",
  "zoom"
].sort().reverse();
function tp(e) {
  const t = e.regex, n = qm(e), a = { begin: /-(webkit|moz|ms|o)-(?=[a-z])/ }, r = "and or not only", o = /@-?\w[\w]*(-\w+)*/, s = "[a-zA-Z-][a-zA-Z0-9_-]*", i = [
    e.APOS_STRING_MODE,
    e.QUOTE_STRING_MODE
  ];
  return {
    name: "CSS",
    case_insensitive: !0,
    illegal: /[=|'\$]/,
    keywords: { keyframePosition: "from to" },
    classNameAliases: {
      // for visual continuity with `tag {}` and because we
      // don't have a great class for this?
      keyframePosition: "selector-tag"
    },
    contains: [
      n.BLOCK_COMMENT,
      a,
      // to recognize keyframe 40% etc which are outside the scope of our
      // attribute value mode
      n.CSS_NUMBER_MODE,
      {
        className: "selector-id",
        begin: /#[A-Za-z0-9_-]+/,
        relevance: 0
      },
      {
        className: "selector-class",
        begin: "\\." + s,
        relevance: 0
      },
      n.ATTRIBUTE_SELECTOR_MODE,
      {
        className: "selector-pseudo",
        variants: [
          { begin: ":(" + jm.join("|") + ")" },
          { begin: ":(:)?(" + Qm.join("|") + ")" }
        ]
      },
      // we may actually need this (12/2020)
      // { // pseudo-selector params
      //   begin: /\(/,
      //   end: /\)/,
      //   contains: [ hljs.CSS_NUMBER_MODE ]
      // },
      n.CSS_VARIABLE,
      {
        className: "attribute",
        begin: "\\b(" + ep.join("|") + ")\\b"
      },
      // attribute values
      {
        begin: /:/,
        end: /[;}{]/,
        contains: [
          n.BLOCK_COMMENT,
          n.HEXCOLOR,
          n.IMPORTANT,
          n.CSS_NUMBER_MODE,
          ...i,
          // needed to highlight these as strings and to avoid issues with
          // illegal characters that might be inside urls that would tigger the
          // languages illegal stack
          {
            begin: /(url|data-uri)\(/,
            end: /\)/,
            relevance: 0,
            // from keywords
            keywords: { built_in: "url data-uri" },
            contains: [
              ...i,
              {
                className: "string",
                // any character other than `)` as in `url()` will be the start
                // of a string, which ends with `)` (from the parent mode)
                begin: /[^)]/,
                endsWithParent: !0,
                excludeEnd: !0
              }
            ]
          },
          n.FUNCTION_DISPATCH
        ]
      },
      {
        begin: t.lookahead(/@/),
        end: "[{;]",
        relevance: 0,
        illegal: /:/,
        // break on Less variables @var: ...
        contains: [
          {
            className: "keyword",
            begin: o
          },
          {
            begin: /\s/,
            endsWithParent: !0,
            excludeEnd: !0,
            relevance: 0,
            keywords: {
              $pattern: /[a-z-]+/,
              keyword: r,
              attribute: Jm.join(" ")
            },
            contains: [
              {
                begin: /[a-z-]+(?=:)/,
                className: "attribute"
              },
              ...i,
              n.CSS_NUMBER_MODE
            ]
          }
        ]
      },
      {
        className: "selector-tag",
        begin: "\\b(" + Zm.join("|") + ")\\b"
      }
    ]
  };
}
function np(e) {
  const t = e.regex;
  return {
    name: "Diff",
    aliases: ["patch"],
    contains: [
      {
        className: "meta",
        relevance: 10,
        match: t.either(
          /^@@ +-\d+,\d+ +\+\d+,\d+ +@@/,
          /^\*\*\* +\d+,\d+ +\*\*\*\*$/,
          /^--- +\d+,\d+ +----$/
        )
      },
      {
        className: "comment",
        variants: [
          {
            begin: t.either(
              /Index: /,
              /^index/,
              /={3,}/,
              /^-{3}/,
              /^\*{3} /,
              /^\+{3}/,
              /^diff --git/
            ),
            end: /$/
          },
          { match: /^\*{15}$/ }
        ]
      },
      {
        className: "addition",
        begin: /^\+/,
        end: /$/
      },
      {
        className: "deletion",
        begin: /^-/,
        end: /$/
      },
      {
        className: "addition",
        begin: /^!/,
        end: /$/
      }
    ]
  };
}
function ap(e) {
  const o = {
    keyword: [
      "break",
      "case",
      "chan",
      "const",
      "continue",
      "default",
      "defer",
      "else",
      "fallthrough",
      "for",
      "func",
      "go",
      "goto",
      "if",
      "import",
      "interface",
      "map",
      "package",
      "range",
      "return",
      "select",
      "struct",
      "switch",
      "type",
      "var"
    ],
    type: [
      "bool",
      "byte",
      "complex64",
      "complex128",
      "error",
      "float32",
      "float64",
      "int8",
      "int16",
      "int32",
      "int64",
      "string",
      "uint8",
      "uint16",
      "uint32",
      "uint64",
      "int",
      "uint",
      "uintptr",
      "rune"
    ],
    literal: [
      "true",
      "false",
      "iota",
      "nil"
    ],
    built_in: [
      "append",
      "cap",
      "close",
      "complex",
      "copy",
      "imag",
      "len",
      "make",
      "new",
      "panic",
      "print",
      "println",
      "real",
      "recover",
      "delete"
    ]
  };
  return {
    name: "Go",
    aliases: ["golang"],
    keywords: o,
    illegal: "</",
    contains: [
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      {
        className: "string",
        variants: [
          e.QUOTE_STRING_MODE,
          e.APOS_STRING_MODE,
          {
            begin: "`",
            end: "`"
          }
        ]
      },
      {
        className: "number",
        variants: [
          {
            match: /-?\b0[xX]\.[a-fA-F0-9](_?[a-fA-F0-9])*[pP][+-]?\d(_?\d)*i?/,
            // hex without a present digit before . (making a digit afterwards required)
            relevance: 0
          },
          {
            match: /-?\b0[xX](_?[a-fA-F0-9])+((\.([a-fA-F0-9](_?[a-fA-F0-9])*)?)?[pP][+-]?\d(_?\d)*)?i?/,
            // hex with a present digit before . (making a digit afterwards optional)
            relevance: 0
          },
          {
            match: /-?\b0[oO](_?[0-7])*i?/,
            // leading 0o octal
            relevance: 0
          },
          {
            match: /-?\.\d(_?\d)*([eE][+-]?\d(_?\d)*)?i?/,
            // decimal without a present digit before . (making a digit afterwards required)
            relevance: 0
          },
          {
            match: /-?\b\d(_?\d)*(\.(\d(_?\d)*)?)?([eE][+-]?\d(_?\d)*)?i?/,
            // decimal with a present digit before . (making a digit afterwards optional)
            relevance: 0
          }
        ]
      },
      {
        begin: /:=/
        // relevance booster
      },
      {
        className: "function",
        beginKeywords: "func",
        end: "\\s*(\\{|$)",
        excludeEnd: !0,
        contains: [
          e.TITLE_MODE,
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            endsParent: !0,
            keywords: o,
            illegal: /["']/
          }
        ]
      }
    ]
  };
}
function rp(e) {
  const t = e.regex, n = /[_A-Za-z][_0-9A-Za-z]*/;
  return {
    name: "GraphQL",
    aliases: ["gql"],
    case_insensitive: !0,
    disableAutodetect: !1,
    keywords: {
      keyword: [
        "query",
        "mutation",
        "subscription",
        "type",
        "input",
        "schema",
        "directive",
        "interface",
        "union",
        "scalar",
        "fragment",
        "enum",
        "on"
      ],
      literal: [
        "true",
        "false",
        "null"
      ]
    },
    contains: [
      e.HASH_COMMENT_MODE,
      e.QUOTE_STRING_MODE,
      e.NUMBER_MODE,
      {
        scope: "punctuation",
        match: /[.]{3}/,
        relevance: 0
      },
      {
        scope: "punctuation",
        begin: /[\!\(\)\:\=\[\]\{\|\}]{1}/,
        relevance: 0
      },
      {
        scope: "variable",
        begin: /\$/,
        end: /\W/,
        excludeEnd: !0,
        relevance: 0
      },
      {
        scope: "meta",
        match: /@\w+/,
        excludeEnd: !0
      },
      {
        scope: "symbol",
        begin: t.concat(n, t.lookahead(/\s*:/)),
        relevance: 0
      }
    ],
    illegal: [
      /[;<']/,
      /BEGIN/
    ]
  };
}
function op(e) {
  const t = e.regex, n = {
    className: "number",
    relevance: 0,
    variants: [
      { begin: /([+-]+)?[\d]+_[\d_]+/ },
      { begin: e.NUMBER_RE }
    ]
  }, a = e.COMMENT();
  a.variants = [
    {
      begin: /;/,
      end: /$/
    },
    {
      begin: /#/,
      end: /$/
    }
  ];
  const r = {
    className: "variable",
    variants: [
      { begin: /\$[\w\d"][\w\d_]*/ },
      { begin: /\$\{(.*?)\}/ }
    ]
  }, o = {
    className: "literal",
    begin: /\bon|off|true|false|yes|no\b/
  }, s = {
    className: "string",
    contains: [e.BACKSLASH_ESCAPE],
    variants: [
      {
        begin: "'''",
        end: "'''",
        relevance: 10
      },
      {
        begin: '"""',
        end: '"""',
        relevance: 10
      },
      {
        begin: '"',
        end: '"'
      },
      {
        begin: "'",
        end: "'"
      }
    ]
  }, i = {
    begin: /\[/,
    end: /\]/,
    contains: [
      a,
      o,
      r,
      s,
      n,
      "self"
    ],
    relevance: 0
  }, c = /[A-Za-z0-9_-]+/, l = /"(\\"|[^"])*"/, d = /'[^']*'/, u = t.either(
    c,
    l,
    d
  ), m = t.concat(
    u,
    "(\\s*\\.\\s*",
    u,
    ")*",
    t.lookahead(/\s*=\s*[^#\s]/)
  );
  return {
    name: "TOML, also INI",
    aliases: ["toml"],
    case_insensitive: !0,
    illegal: /\S/,
    contains: [
      a,
      {
        className: "section",
        begin: /\[+/,
        end: /\]+/
      },
      {
        begin: m,
        className: "attr",
        starts: {
          end: /$/,
          contains: [
            a,
            i,
            o,
            r,
            s,
            n
          ]
        }
      }
    ]
  };
}
var Mt = "[0-9](_*[0-9])*", mn = `\\.(${Mt})`, pn = "[0-9a-fA-F](_*[0-9a-fA-F])*", oo = {
  className: "number",
  variants: [
    // DecimalFloatingPointLiteral
    // including ExponentPart
    { begin: `(\\b(${Mt})((${mn})|\\.)?|(${mn}))[eE][+-]?(${Mt})[fFdD]?\\b` },
    // excluding ExponentPart
    { begin: `\\b(${Mt})((${mn})[fFdD]?\\b|\\.([fFdD]\\b)?)` },
    { begin: `(${mn})[fFdD]?\\b` },
    { begin: `\\b(${Mt})[fFdD]\\b` },
    // HexadecimalFloatingPointLiteral
    { begin: `\\b0[xX]((${pn})\\.?|(${pn})?\\.(${pn}))[pP][+-]?(${Mt})[fFdD]?\\b` },
    // DecimalIntegerLiteral
    { begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b" },
    // HexIntegerLiteral
    { begin: `\\b0[xX](${pn})[lL]?\\b` },
    // OctalIntegerLiteral
    { begin: "\\b0(_*[0-7])*[lL]?\\b" },
    // BinaryIntegerLiteral
    { begin: "\\b0[bB][01](_*[01])*[lL]?\\b" }
  ],
  relevance: 0
};
function ti(e, t, n) {
  return n === -1 ? "" : e.replace(t, (a) => ti(e, t, n - 1));
}
function sp(e) {
  const t = e.regex, n = "[À-ʸa-zA-Z_$][À-ʸa-zA-Z_$0-9]*", a = n + ti("(?:<" + n + "~~~(?:\\s*,\\s*" + n + "~~~)*>)?", /~~~/g, 2), c = {
    keyword: [
      "synchronized",
      "abstract",
      "private",
      "var",
      "static",
      "if",
      "const ",
      "for",
      "while",
      "strictfp",
      "finally",
      "protected",
      "import",
      "native",
      "final",
      "void",
      "enum",
      "else",
      "break",
      "transient",
      "catch",
      "instanceof",
      "volatile",
      "case",
      "assert",
      "package",
      "default",
      "public",
      "try",
      "switch",
      "continue",
      "throws",
      "protected",
      "public",
      "private",
      "module",
      "requires",
      "exports",
      "do",
      "sealed",
      "yield",
      "permits",
      "goto",
      "when"
    ],
    literal: [
      "false",
      "true",
      "null"
    ],
    type: [
      "char",
      "boolean",
      "long",
      "float",
      "int",
      "byte",
      "short",
      "double"
    ],
    built_in: [
      "super",
      "this"
    ]
  }, l = {
    className: "meta",
    begin: "@" + n,
    contains: [
      {
        begin: /\(/,
        end: /\)/,
        contains: ["self"]
        // allow nested () inside our annotation
      }
    ]
  }, d = {
    className: "params",
    begin: /\(/,
    end: /\)/,
    keywords: c,
    relevance: 0,
    contains: [e.C_BLOCK_COMMENT_MODE],
    endsParent: !0
  };
  return {
    name: "Java",
    aliases: ["jsp"],
    keywords: c,
    illegal: /<\/|#/,
    contains: [
      e.COMMENT(
        "/\\*\\*",
        "\\*/",
        {
          relevance: 0,
          contains: [
            {
              // eat up @'s in emails to prevent them to be recognized as doctags
              begin: /\w+@/,
              relevance: 0
            },
            {
              className: "doctag",
              begin: "@[A-Za-z]+"
            }
          ]
        }
      ),
      // relevance boost
      {
        begin: /import java\.[a-z]+\./,
        keywords: "import",
        relevance: 2
      },
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      {
        begin: /"""/,
        end: /"""/,
        className: "string",
        contains: [e.BACKSLASH_ESCAPE]
      },
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE,
      {
        match: [
          /\b(?:class|interface|enum|extends|implements|new)/,
          /\s+/,
          n
        ],
        className: {
          1: "keyword",
          3: "title.class"
        }
      },
      {
        // Exceptions for hyphenated keywords
        match: /non-sealed/,
        scope: "keyword"
      },
      {
        begin: [
          t.concat(/(?!else)/, n),
          /\s+/,
          n,
          /\s+/,
          /=(?!=)/
        ],
        className: {
          1: "type",
          3: "variable",
          5: "operator"
        }
      },
      {
        begin: [
          /record/,
          /\s+/,
          n
        ],
        className: {
          1: "keyword",
          3: "title.class"
        },
        contains: [
          d,
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      {
        // Expression keywords prevent 'keyword Name(...)' from being
        // recognized as a function definition
        beginKeywords: "new throw return else",
        relevance: 0
      },
      {
        begin: [
          "(?:" + a + "\\s+)",
          e.UNDERSCORE_IDENT_RE,
          /\s*(?=\()/
        ],
        className: { 2: "title.function" },
        keywords: c,
        contains: [
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            keywords: c,
            relevance: 0,
            contains: [
              l,
              e.APOS_STRING_MODE,
              e.QUOTE_STRING_MODE,
              oo,
              e.C_BLOCK_COMMENT_MODE
            ]
          },
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      oo,
      l
    ]
  };
}
const so = "[A-Za-z$_][0-9A-Za-z$_]*", ip = [
  "as",
  // for exports
  "in",
  "of",
  "if",
  "for",
  "while",
  "finally",
  "var",
  "new",
  "function",
  "do",
  "return",
  "void",
  "else",
  "break",
  "catch",
  "instanceof",
  "with",
  "throw",
  "case",
  "default",
  "try",
  "switch",
  "continue",
  "typeof",
  "delete",
  "let",
  "yield",
  "const",
  "class",
  // JS handles these with a special rule
  // "get",
  // "set",
  "debugger",
  "async",
  "await",
  "static",
  "import",
  "from",
  "export",
  "extends",
  // It's reached stage 3, which is "recommended for implementation":
  "using"
], cp = [
  "true",
  "false",
  "null",
  "undefined",
  "NaN",
  "Infinity"
], ni = [
  // Fundamental objects
  "Object",
  "Function",
  "Boolean",
  "Symbol",
  // numbers and dates
  "Math",
  "Date",
  "Number",
  "BigInt",
  // text
  "String",
  "RegExp",
  // Indexed collections
  "Array",
  "Float32Array",
  "Float64Array",
  "Int8Array",
  "Uint8Array",
  "Uint8ClampedArray",
  "Int16Array",
  "Int32Array",
  "Uint16Array",
  "Uint32Array",
  "BigInt64Array",
  "BigUint64Array",
  // Keyed collections
  "Set",
  "Map",
  "WeakSet",
  "WeakMap",
  // Structured data
  "ArrayBuffer",
  "SharedArrayBuffer",
  "Atomics",
  "DataView",
  "JSON",
  // Control abstraction objects
  "Promise",
  "Generator",
  "GeneratorFunction",
  "AsyncFunction",
  // Reflection
  "Reflect",
  "Proxy",
  // Internationalization
  "Intl",
  // WebAssembly
  "WebAssembly"
], ai = [
  "Error",
  "EvalError",
  "InternalError",
  "RangeError",
  "ReferenceError",
  "SyntaxError",
  "TypeError",
  "URIError"
], ri = [
  "setInterval",
  "setTimeout",
  "clearInterval",
  "clearTimeout",
  "require",
  "exports",
  "eval",
  "isFinite",
  "isNaN",
  "parseFloat",
  "parseInt",
  "decodeURI",
  "decodeURIComponent",
  "encodeURI",
  "encodeURIComponent",
  "escape",
  "unescape"
], lp = [
  "arguments",
  "this",
  "super",
  "console",
  "window",
  "document",
  "localStorage",
  "sessionStorage",
  "module",
  "global"
  // Node.js
], dp = [].concat(
  ri,
  ni,
  ai
);
function up(e) {
  const t = e.regex, n = (H, { after: se }) => {
    const me = "</" + H[0].slice(1);
    return H.input.indexOf(me, se) !== -1;
  }, a = so, r = {
    begin: "<>",
    end: "</>"
  }, o = /<[A-Za-z0-9\\._:-]+\s*\/>/, s = {
    begin: /<[A-Za-z0-9\\._:-]+/,
    end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
    /**
     * @param {RegExpMatchArray} match
     * @param {CallbackResponse} response
     */
    isTrulyOpeningTag: (H, se) => {
      const me = H[0].length + H.index, de = H.input[me];
      if (
        // HTML should not include another raw `<` inside a tag
        // nested type?
        // `<Array<Array<number>>`, etc.
        de === "<" || // the , gives away that this is not HTML
        // `<T, A extends keyof T, V>`
        de === ","
      ) {
        se.ignoreMatch();
        return;
      }
      de === ">" && (n(H, { after: me }) || se.ignoreMatch());
      let ue;
      const Me = H.input.substring(me);
      if (ue = Me.match(/^\s*=/)) {
        se.ignoreMatch();
        return;
      }
      if ((ue = Me.match(/^\s+extends\s+/)) && ue.index === 0) {
        se.ignoreMatch();
        return;
      }
    }
  }, i = {
    $pattern: so,
    keyword: ip,
    literal: cp,
    built_in: dp,
    "variable.language": lp
  }, c = "[0-9](_?[0-9])*", l = `\\.(${c})`, d = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*", u = {
    className: "number",
    variants: [
      // DecimalLiteral
      { begin: `(\\b(${d})((${l})|\\.)?|(${l}))[eE][+-]?(${c})\\b` },
      { begin: `\\b(${d})\\b((${l})\\b|\\.)?|(${l})\\b` },
      // DecimalBigIntegerLiteral
      { begin: "\\b(0|[1-9](_?[0-9])*)n\\b" },
      // NonDecimalIntegerLiteral
      { begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b" },
      { begin: "\\b0[bB][0-1](_?[0-1])*n?\\b" },
      { begin: "\\b0[oO][0-7](_?[0-7])*n?\\b" },
      // LegacyOctalIntegerLiteral (does not include underscore separators)
      // https://tc39.es/ecma262/#sec-additional-syntax-numeric-literals
      { begin: "\\b0[0-7]+n?\\b" }
    ],
    relevance: 0
  }, m = {
    className: "subst",
    begin: "\\$\\{",
    end: "\\}",
    keywords: i,
    contains: []
    // defined later
  }, g = {
    begin: ".?html`",
    end: "",
    starts: {
      end: "`",
      returnEnd: !1,
      contains: [
        e.BACKSLASH_ESCAPE,
        m
      ],
      subLanguage: "xml"
    }
  }, f = {
    begin: ".?css`",
    end: "",
    starts: {
      end: "`",
      returnEnd: !1,
      contains: [
        e.BACKSLASH_ESCAPE,
        m
      ],
      subLanguage: "css"
    }
  }, b = {
    begin: ".?gql`",
    end: "",
    starts: {
      end: "`",
      returnEnd: !1,
      contains: [
        e.BACKSLASH_ESCAPE,
        m
      ],
      subLanguage: "graphql"
    }
  }, E = {
    className: "string",
    begin: "`",
    end: "`",
    contains: [
      e.BACKSLASH_ESCAPE,
      m
    ]
  }, k = {
    className: "comment",
    variants: [
      e.COMMENT(
        /\/\*\*(?!\/)/,
        "\\*/",
        {
          relevance: 0,
          contains: [
            {
              begin: "(?=@[A-Za-z]+)",
              relevance: 0,
              contains: [
                {
                  className: "doctag",
                  begin: "@[A-Za-z]+"
                },
                {
                  className: "type",
                  begin: "\\{",
                  end: "\\}",
                  excludeEnd: !0,
                  excludeBegin: !0,
                  relevance: 0
                },
                {
                  className: "variable",
                  begin: a + "(?=\\s*(-)|$)",
                  endsParent: !0,
                  relevance: 0
                },
                // eat spaces (not newlines) so we can find
                // types or variables
                {
                  begin: /(?=[^\n])\s/,
                  relevance: 0
                }
              ]
            }
          ]
        }
      ),
      e.C_BLOCK_COMMENT_MODE,
      e.C_LINE_COMMENT_MODE
    ]
  }, S = [
    e.APOS_STRING_MODE,
    e.QUOTE_STRING_MODE,
    g,
    f,
    b,
    E,
    // Skip numbers when they are part of a variable name
    { match: /\$\d+/ },
    u
    // This is intentional:
    // See https://github.com/highlightjs/highlight.js/issues/3288
    // hljs.REGEXP_MODE
  ];
  m.contains = S.concat({
    // we need to pair up {} inside our subst to prevent
    // it from ending too early by matching another }
    begin: /\{/,
    end: /\}/,
    keywords: i,
    contains: [
      "self"
    ].concat(S)
  });
  const y = [].concat(k, m.contains), x = y.concat([
    // eat recursive parens in sub expressions
    {
      begin: /(\s*)\(/,
      end: /\)/,
      keywords: i,
      contains: ["self"].concat(y)
    }
  ]), C = {
    className: "params",
    // convert this to negative lookbehind in v12
    begin: /(\s*)\(/,
    // to match the parms with
    end: /\)/,
    excludeBegin: !0,
    excludeEnd: !0,
    keywords: i,
    contains: x
  }, O = {
    variants: [
      // class Car extends vehicle
      {
        match: [
          /class/,
          /\s+/,
          a,
          /\s+/,
          /extends/,
          /\s+/,
          t.concat(a, "(", t.concat(/\./, a), ")*")
        ],
        scope: {
          1: "keyword",
          3: "title.class",
          5: "keyword",
          7: "title.class.inherited"
        }
      },
      // class Car
      {
        match: [
          /class/,
          /\s+/,
          a
        ],
        scope: {
          1: "keyword",
          3: "title.class"
        }
      }
    ]
  }, P = {
    relevance: 0,
    match: t.either(
      // Hard coded exceptions
      /\bJSON/,
      // Float32Array, OutT
      /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/,
      // CSSFactory, CSSFactoryT
      /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/,
      // FPs, FPsT
      /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/
      // P
      // single letters are not highlighted
      // BLAH
      // this will be flagged as a UPPER_CASE_CONSTANT instead
    ),
    className: "title.class",
    keywords: {
      _: [
        // se we still get relevance credit for JS library classes
        ...ni,
        ...ai
      ]
    }
  }, G = {
    label: "use_strict",
    className: "meta",
    relevance: 10,
    begin: /^\s*['"]use (strict|asm)['"]/
  }, K = {
    variants: [
      {
        match: [
          /function/,
          /\s+/,
          a,
          /(?=\s*\()/
        ]
      },
      // anonymous function
      {
        match: [
          /function/,
          /\s*(?=\()/
        ]
      }
    ],
    className: {
      1: "keyword",
      3: "title.function"
    },
    label: "func.def",
    contains: [C],
    illegal: /%/
  }, oe = {
    relevance: 0,
    match: /\b[A-Z][A-Z_0-9]+\b/,
    className: "variable.constant"
  };
  function L(H) {
    return t.concat("(?!", H.join("|"), ")");
  }
  const Z = {
    match: t.concat(
      /\b/,
      L([
        ...ri,
        "super",
        "import"
      ].map((H) => `${H}\\s*\\(`)),
      a,
      t.lookahead(/\s*\(/)
    ),
    className: "title.function",
    relevance: 0
  }, V = {
    begin: t.concat(/\./, t.lookahead(
      t.concat(a, /(?![0-9A-Za-z$_(])/)
    )),
    end: a,
    excludeBegin: !0,
    keywords: "prototype",
    className: "property",
    relevance: 0
  }, re = {
    match: [
      /get|set/,
      /\s+/,
      a,
      /(?=\()/
    ],
    className: {
      1: "keyword",
      3: "title.function"
    },
    contains: [
      {
        // eat to avoid empty params
        begin: /\(\)/
      },
      C
    ]
  }, be = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>", we = {
    match: [
      /const|var|let/,
      /\s+/,
      a,
      /\s*/,
      /=\s*/,
      /(async\s*)?/,
      // async is optional
      t.lookahead(be)
    ],
    keywords: "async",
    className: {
      1: "keyword",
      3: "title.function"
    },
    contains: [
      C
    ]
  };
  return {
    name: "JavaScript",
    aliases: ["js", "jsx", "mjs", "cjs"],
    keywords: i,
    // this will be extended by TypeScript
    exports: { PARAMS_CONTAINS: x, CLASS_REFERENCE: P },
    illegal: /#(?![$_A-z])/,
    contains: [
      e.SHEBANG({
        label: "shebang",
        binary: "node",
        relevance: 5
      }),
      G,
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE,
      g,
      f,
      b,
      E,
      k,
      // Skip numbers when they are part of a variable name
      { match: /\$\d+/ },
      u,
      P,
      {
        scope: "attr",
        match: a + t.lookahead(":"),
        relevance: 0
      },
      we,
      {
        // "value" container
        begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
        keywords: "return throw case",
        relevance: 0,
        contains: [
          k,
          e.REGEXP_MODE,
          {
            className: "function",
            // we have to count the parens to make sure we actually have the
            // correct bounding ( ) before the =>.  There could be any number of
            // sub-expressions inside also surrounded by parens.
            begin: be,
            returnBegin: !0,
            end: "\\s*=>",
            contains: [
              {
                className: "params",
                variants: [
                  {
                    begin: e.UNDERSCORE_IDENT_RE,
                    relevance: 0
                  },
                  {
                    className: null,
                    begin: /\(\s*\)/,
                    skip: !0
                  },
                  {
                    begin: /(\s*)\(/,
                    end: /\)/,
                    excludeBegin: !0,
                    excludeEnd: !0,
                    keywords: i,
                    contains: x
                  }
                ]
              }
            ]
          },
          {
            // could be a comma delimited list of params to a function call
            begin: /,/,
            relevance: 0
          },
          {
            match: /\s+/,
            relevance: 0
          },
          {
            // JSX
            variants: [
              { begin: r.begin, end: r.end },
              { match: o },
              {
                begin: s.begin,
                // we carefully check the opening tag to see if it truly
                // is a tag and not a false positive
                "on:begin": s.isTrulyOpeningTag,
                end: s.end
              }
            ],
            subLanguage: "xml",
            contains: [
              {
                begin: s.begin,
                end: s.end,
                skip: !0,
                contains: ["self"]
              }
            ]
          }
        ]
      },
      K,
      {
        // prevent this from getting swallowed up by function
        // since they appear "function like"
        beginKeywords: "while if switch catch for"
      },
      {
        // we have to count the parens to make sure we actually have the correct
        // bounding ( ).  There could be any number of sub-expressions inside
        // also surrounded by parens.
        begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
        // end parens
        returnBegin: !0,
        label: "func.def",
        contains: [
          C,
          e.inherit(e.TITLE_MODE, { begin: a, className: "title.function" })
        ]
      },
      // catch ... so it won't trigger the property rule below
      {
        match: /\.\.\./,
        relevance: 0
      },
      V,
      // hack: prevents detection of keywords in some circumstances
      // .keyword()
      // $keyword = x
      {
        match: "\\$" + a,
        relevance: 0
      },
      {
        match: [/\bconstructor(?=\s*\()/],
        className: { 1: "title.function" },
        contains: [C]
      },
      Z,
      oe,
      O,
      re,
      {
        match: /\$[(.]/
        // relevance booster for a pattern common to JS libs: `$(something)` and `$.something`
      }
    ]
  };
}
function gp(e) {
  const t = {
    className: "attr",
    begin: /"(\\.|[^\\"\r\n])*"(?=\s*:)/,
    relevance: 1.01
  }, n = {
    match: /[{}[\],:]/,
    className: "punctuation",
    relevance: 0
  }, a = [
    "true",
    "false",
    "null"
  ], r = {
    scope: "literal",
    beginKeywords: a.join(" ")
  };
  return {
    name: "JSON",
    aliases: ["jsonc"],
    keywords: {
      literal: a
    },
    contains: [
      t,
      n,
      e.QUOTE_STRING_MODE,
      r,
      e.C_NUMBER_MODE,
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE
    ],
    illegal: "\\S"
  };
}
var It = "[0-9](_*[0-9])*", fn = `\\.(${It})`, bn = "[0-9a-fA-F](_*[0-9a-fA-F])*", mp = {
  className: "number",
  variants: [
    // DecimalFloatingPointLiteral
    // including ExponentPart
    { begin: `(\\b(${It})((${fn})|\\.)?|(${fn}))[eE][+-]?(${It})[fFdD]?\\b` },
    // excluding ExponentPart
    { begin: `\\b(${It})((${fn})[fFdD]?\\b|\\.([fFdD]\\b)?)` },
    { begin: `(${fn})[fFdD]?\\b` },
    { begin: `\\b(${It})[fFdD]\\b` },
    // HexadecimalFloatingPointLiteral
    { begin: `\\b0[xX]((${bn})\\.?|(${bn})?\\.(${bn}))[pP][+-]?(${It})[fFdD]?\\b` },
    // DecimalIntegerLiteral
    { begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b" },
    // HexIntegerLiteral
    { begin: `\\b0[xX](${bn})[lL]?\\b` },
    // OctalIntegerLiteral
    { begin: "\\b0(_*[0-7])*[lL]?\\b" },
    // BinaryIntegerLiteral
    { begin: "\\b0[bB][01](_*[01])*[lL]?\\b" }
  ],
  relevance: 0
};
function pp(e) {
  const t = {
    keyword: "abstract as val var vararg get set class object open private protected public noinline crossinline dynamic final enum if else do while for when throw try catch finally import package is in fun override companion reified inline lateinit init interface annotation data sealed internal infix operator out by constructor super tailrec where const inner suspend typealias external expect actual",
    built_in: "Byte Short Char Int Long Boolean Float Double Void Unit Nothing",
    literal: "true false null"
  }, n = {
    className: "keyword",
    begin: /\b(break|continue|return|this)\b/,
    starts: { contains: [
      {
        className: "symbol",
        begin: /@\w+/
      }
    ] }
  }, a = {
    className: "symbol",
    begin: e.UNDERSCORE_IDENT_RE + "@"
  }, r = {
    className: "subst",
    begin: /\$\{/,
    end: /\}/,
    contains: [e.C_NUMBER_MODE]
  }, o = {
    className: "variable",
    begin: "\\$" + e.UNDERSCORE_IDENT_RE
  }, s = {
    className: "string",
    variants: [
      {
        begin: '"""',
        end: '"""(?=[^"])',
        contains: [
          o,
          r
        ]
      },
      // Can't use built-in modes easily, as we want to use STRING in the meta
      // context as 'meta-string' and there's no syntax to remove explicitly set
      // classNames in built-in modes.
      {
        begin: "'",
        end: "'",
        illegal: /\n/,
        contains: [e.BACKSLASH_ESCAPE]
      },
      {
        begin: '"',
        end: '"',
        illegal: /\n/,
        contains: [
          e.BACKSLASH_ESCAPE,
          o,
          r
        ]
      }
    ]
  };
  r.contains.push(s);
  const i = {
    className: "meta",
    begin: "@(?:file|property|field|get|set|receiver|param|setparam|delegate)\\s*:(?:\\s*" + e.UNDERSCORE_IDENT_RE + ")?"
  }, c = {
    className: "meta",
    begin: "@" + e.UNDERSCORE_IDENT_RE,
    contains: [
      {
        begin: /\(/,
        end: /\)/,
        contains: [
          e.inherit(s, { className: "string" }),
          "self"
        ]
      }
    ]
  }, l = mp, d = e.COMMENT(
    "/\\*",
    "\\*/",
    { contains: [e.C_BLOCK_COMMENT_MODE] }
  ), u = { variants: [
    {
      className: "type",
      begin: e.UNDERSCORE_IDENT_RE
    },
    {
      begin: /\(/,
      end: /\)/,
      contains: []
      // defined later
    }
  ] }, m = u;
  return m.variants[1].contains = [u], u.variants[1].contains = [m], {
    name: "Kotlin",
    aliases: [
      "kt",
      "kts"
    ],
    keywords: t,
    contains: [
      e.COMMENT(
        "/\\*\\*",
        "\\*/",
        {
          relevance: 0,
          contains: [
            {
              className: "doctag",
              begin: "@[A-Za-z]+"
            }
          ]
        }
      ),
      e.C_LINE_COMMENT_MODE,
      d,
      n,
      a,
      i,
      c,
      {
        className: "function",
        beginKeywords: "fun",
        end: "[(]|$",
        returnBegin: !0,
        excludeEnd: !0,
        keywords: t,
        relevance: 5,
        contains: [
          {
            begin: e.UNDERSCORE_IDENT_RE + "\\s*\\(",
            returnBegin: !0,
            relevance: 0,
            contains: [e.UNDERSCORE_TITLE_MODE]
          },
          {
            className: "type",
            begin: /</,
            end: />/,
            keywords: "reified",
            relevance: 0
          },
          {
            className: "params",
            begin: /\(/,
            end: /\)/,
            endsParent: !0,
            keywords: t,
            relevance: 0,
            contains: [
              {
                begin: /:/,
                end: /[=,\/]/,
                endsWithParent: !0,
                contains: [
                  u,
                  e.C_LINE_COMMENT_MODE,
                  d
                ],
                relevance: 0
              },
              e.C_LINE_COMMENT_MODE,
              d,
              i,
              c,
              s,
              e.C_NUMBER_MODE
            ]
          },
          d
        ]
      },
      {
        begin: [
          /class|interface|trait/,
          /\s+/,
          e.UNDERSCORE_IDENT_RE
        ],
        beginScope: {
          3: "title.class"
        },
        keywords: "class interface trait",
        end: /[:\{(]|$/,
        excludeEnd: !0,
        illegal: "extends implements",
        contains: [
          { beginKeywords: "public protected internal private constructor" },
          e.UNDERSCORE_TITLE_MODE,
          {
            className: "type",
            begin: /</,
            end: />/,
            excludeBegin: !0,
            excludeEnd: !0,
            relevance: 0
          },
          {
            className: "type",
            begin: /[,:]\s*/,
            end: /[<\(,){\s]|$/,
            excludeBegin: !0,
            returnEnd: !0
          },
          i,
          c
        ]
      },
      s,
      {
        className: "meta",
        begin: "^#!/usr/bin/env",
        end: "$",
        illegal: `
`
      },
      l
    ]
  };
}
const fp = (e) => ({
  IMPORTANT: {
    scope: "meta",
    begin: "!important"
  },
  BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
  HEXCOLOR: {
    scope: "number",
    begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
  },
  FUNCTION_DISPATCH: {
    className: "built_in",
    begin: /[\w-]+(?=\()/
  },
  ATTRIBUTE_SELECTOR_MODE: {
    scope: "selector-attr",
    begin: /\[/,
    end: /\]/,
    illegal: "$",
    contains: [
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE
    ]
  },
  CSS_NUMBER_MODE: {
    scope: "number",
    begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
    relevance: 0
  },
  CSS_VARIABLE: {
    className: "attr",
    begin: /--[A-Za-z_][A-Za-z0-9_-]*/
  }
}), bp = [
  "a",
  "abbr",
  "address",
  "article",
  "aside",
  "audio",
  "b",
  "blockquote",
  "body",
  "button",
  "canvas",
  "caption",
  "cite",
  "code",
  "dd",
  "del",
  "details",
  "dfn",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "header",
  "hgroup",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "main",
  "mark",
  "menu",
  "nav",
  "object",
  "ol",
  "optgroup",
  "option",
  "p",
  "picture",
  "q",
  "quote",
  "samp",
  "section",
  "select",
  "source",
  "span",
  "strong",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "ul",
  "var",
  "video"
], hp = [
  "defs",
  "g",
  "marker",
  "mask",
  "pattern",
  "svg",
  "switch",
  "symbol",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feFlood",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTile",
  "feTurbulence",
  "linearGradient",
  "radialGradient",
  "stop",
  "circle",
  "ellipse",
  "image",
  "line",
  "path",
  "polygon",
  "polyline",
  "rect",
  "text",
  "use",
  "textPath",
  "tspan",
  "foreignObject",
  "clipPath"
], yp = [
  ...bp,
  ...hp
], Ep = [
  "any-hover",
  "any-pointer",
  "aspect-ratio",
  "color",
  "color-gamut",
  "color-index",
  "device-aspect-ratio",
  "device-height",
  "device-width",
  "display-mode",
  "forced-colors",
  "grid",
  "height",
  "hover",
  "inverted-colors",
  "monochrome",
  "orientation",
  "overflow-block",
  "overflow-inline",
  "pointer",
  "prefers-color-scheme",
  "prefers-contrast",
  "prefers-reduced-motion",
  "prefers-reduced-transparency",
  "resolution",
  "scan",
  "scripting",
  "update",
  "width",
  // TODO: find a better solution?
  "min-width",
  "max-width",
  "min-height",
  "max-height"
].sort().reverse(), oi = [
  "active",
  "any-link",
  "blank",
  "checked",
  "current",
  "default",
  "defined",
  "dir",
  // dir()
  "disabled",
  "drop",
  "empty",
  "enabled",
  "first",
  "first-child",
  "first-of-type",
  "fullscreen",
  "future",
  "focus",
  "focus-visible",
  "focus-within",
  "has",
  // has()
  "host",
  // host or host()
  "host-context",
  // host-context()
  "hover",
  "indeterminate",
  "in-range",
  "invalid",
  "is",
  // is()
  "lang",
  // lang()
  "last-child",
  "last-of-type",
  "left",
  "link",
  "local-link",
  "not",
  // not()
  "nth-child",
  // nth-child()
  "nth-col",
  // nth-col()
  "nth-last-child",
  // nth-last-child()
  "nth-last-col",
  // nth-last-col()
  "nth-last-of-type",
  //nth-last-of-type()
  "nth-of-type",
  //nth-of-type()
  "only-child",
  "only-of-type",
  "optional",
  "out-of-range",
  "past",
  "placeholder-shown",
  "read-only",
  "read-write",
  "required",
  "right",
  "root",
  "scope",
  "target",
  "target-within",
  "user-invalid",
  "valid",
  "visited",
  "where"
  // where()
].sort().reverse(), si = [
  "after",
  "backdrop",
  "before",
  "cue",
  "cue-region",
  "first-letter",
  "first-line",
  "grammar-error",
  "marker",
  "part",
  "placeholder",
  "selection",
  "slotted",
  "spelling-error"
].sort().reverse(), _p = [
  "accent-color",
  "align-content",
  "align-items",
  "align-self",
  "alignment-baseline",
  "all",
  "anchor-name",
  "animation",
  "animation-composition",
  "animation-delay",
  "animation-direction",
  "animation-duration",
  "animation-fill-mode",
  "animation-iteration-count",
  "animation-name",
  "animation-play-state",
  "animation-range",
  "animation-range-end",
  "animation-range-start",
  "animation-timeline",
  "animation-timing-function",
  "appearance",
  "aspect-ratio",
  "backdrop-filter",
  "backface-visibility",
  "background",
  "background-attachment",
  "background-blend-mode",
  "background-clip",
  "background-color",
  "background-image",
  "background-origin",
  "background-position",
  "background-position-x",
  "background-position-y",
  "background-repeat",
  "background-size",
  "baseline-shift",
  "block-size",
  "border",
  "border-block",
  "border-block-color",
  "border-block-end",
  "border-block-end-color",
  "border-block-end-style",
  "border-block-end-width",
  "border-block-start",
  "border-block-start-color",
  "border-block-start-style",
  "border-block-start-width",
  "border-block-style",
  "border-block-width",
  "border-bottom",
  "border-bottom-color",
  "border-bottom-left-radius",
  "border-bottom-right-radius",
  "border-bottom-style",
  "border-bottom-width",
  "border-collapse",
  "border-color",
  "border-end-end-radius",
  "border-end-start-radius",
  "border-image",
  "border-image-outset",
  "border-image-repeat",
  "border-image-slice",
  "border-image-source",
  "border-image-width",
  "border-inline",
  "border-inline-color",
  "border-inline-end",
  "border-inline-end-color",
  "border-inline-end-style",
  "border-inline-end-width",
  "border-inline-start",
  "border-inline-start-color",
  "border-inline-start-style",
  "border-inline-start-width",
  "border-inline-style",
  "border-inline-width",
  "border-left",
  "border-left-color",
  "border-left-style",
  "border-left-width",
  "border-radius",
  "border-right",
  "border-right-color",
  "border-right-style",
  "border-right-width",
  "border-spacing",
  "border-start-end-radius",
  "border-start-start-radius",
  "border-style",
  "border-top",
  "border-top-color",
  "border-top-left-radius",
  "border-top-right-radius",
  "border-top-style",
  "border-top-width",
  "border-width",
  "bottom",
  "box-align",
  "box-decoration-break",
  "box-direction",
  "box-flex",
  "box-flex-group",
  "box-lines",
  "box-ordinal-group",
  "box-orient",
  "box-pack",
  "box-shadow",
  "box-sizing",
  "break-after",
  "break-before",
  "break-inside",
  "caption-side",
  "caret-color",
  "clear",
  "clip",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "color-scheme",
  "column-count",
  "column-fill",
  "column-gap",
  "column-rule",
  "column-rule-color",
  "column-rule-style",
  "column-rule-width",
  "column-span",
  "column-width",
  "columns",
  "contain",
  "contain-intrinsic-block-size",
  "contain-intrinsic-height",
  "contain-intrinsic-inline-size",
  "contain-intrinsic-size",
  "contain-intrinsic-width",
  "container",
  "container-name",
  "container-type",
  "content",
  "content-visibility",
  "counter-increment",
  "counter-reset",
  "counter-set",
  "cue",
  "cue-after",
  "cue-before",
  "cursor",
  "cx",
  "cy",
  "direction",
  "display",
  "dominant-baseline",
  "empty-cells",
  "enable-background",
  "field-sizing",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "flex",
  "flex-basis",
  "flex-direction",
  "flex-flow",
  "flex-grow",
  "flex-shrink",
  "flex-wrap",
  "float",
  "flood-color",
  "flood-opacity",
  "flow",
  "font",
  "font-display",
  "font-family",
  "font-feature-settings",
  "font-kerning",
  "font-language-override",
  "font-optical-sizing",
  "font-palette",
  "font-size",
  "font-size-adjust",
  "font-smooth",
  "font-smoothing",
  "font-stretch",
  "font-style",
  "font-synthesis",
  "font-synthesis-position",
  "font-synthesis-small-caps",
  "font-synthesis-style",
  "font-synthesis-weight",
  "font-variant",
  "font-variant-alternates",
  "font-variant-caps",
  "font-variant-east-asian",
  "font-variant-emoji",
  "font-variant-ligatures",
  "font-variant-numeric",
  "font-variant-position",
  "font-variation-settings",
  "font-weight",
  "forced-color-adjust",
  "gap",
  "glyph-orientation-horizontal",
  "glyph-orientation-vertical",
  "grid",
  "grid-area",
  "grid-auto-columns",
  "grid-auto-flow",
  "grid-auto-rows",
  "grid-column",
  "grid-column-end",
  "grid-column-start",
  "grid-gap",
  "grid-row",
  "grid-row-end",
  "grid-row-start",
  "grid-template",
  "grid-template-areas",
  "grid-template-columns",
  "grid-template-rows",
  "hanging-punctuation",
  "height",
  "hyphenate-character",
  "hyphenate-limit-chars",
  "hyphens",
  "icon",
  "image-orientation",
  "image-rendering",
  "image-resolution",
  "ime-mode",
  "initial-letter",
  "initial-letter-align",
  "inline-size",
  "inset",
  "inset-area",
  "inset-block",
  "inset-block-end",
  "inset-block-start",
  "inset-inline",
  "inset-inline-end",
  "inset-inline-start",
  "isolation",
  "justify-content",
  "justify-items",
  "justify-self",
  "kerning",
  "left",
  "letter-spacing",
  "lighting-color",
  "line-break",
  "line-height",
  "line-height-step",
  "list-style",
  "list-style-image",
  "list-style-position",
  "list-style-type",
  "margin",
  "margin-block",
  "margin-block-end",
  "margin-block-start",
  "margin-bottom",
  "margin-inline",
  "margin-inline-end",
  "margin-inline-start",
  "margin-left",
  "margin-right",
  "margin-top",
  "margin-trim",
  "marker",
  "marker-end",
  "marker-mid",
  "marker-start",
  "marks",
  "mask",
  "mask-border",
  "mask-border-mode",
  "mask-border-outset",
  "mask-border-repeat",
  "mask-border-slice",
  "mask-border-source",
  "mask-border-width",
  "mask-clip",
  "mask-composite",
  "mask-image",
  "mask-mode",
  "mask-origin",
  "mask-position",
  "mask-repeat",
  "mask-size",
  "mask-type",
  "masonry-auto-flow",
  "math-depth",
  "math-shift",
  "math-style",
  "max-block-size",
  "max-height",
  "max-inline-size",
  "max-width",
  "min-block-size",
  "min-height",
  "min-inline-size",
  "min-width",
  "mix-blend-mode",
  "nav-down",
  "nav-index",
  "nav-left",
  "nav-right",
  "nav-up",
  "none",
  "normal",
  "object-fit",
  "object-position",
  "offset",
  "offset-anchor",
  "offset-distance",
  "offset-path",
  "offset-position",
  "offset-rotate",
  "opacity",
  "order",
  "orphans",
  "outline",
  "outline-color",
  "outline-offset",
  "outline-style",
  "outline-width",
  "overflow",
  "overflow-anchor",
  "overflow-block",
  "overflow-clip-margin",
  "overflow-inline",
  "overflow-wrap",
  "overflow-x",
  "overflow-y",
  "overlay",
  "overscroll-behavior",
  "overscroll-behavior-block",
  "overscroll-behavior-inline",
  "overscroll-behavior-x",
  "overscroll-behavior-y",
  "padding",
  "padding-block",
  "padding-block-end",
  "padding-block-start",
  "padding-bottom",
  "padding-inline",
  "padding-inline-end",
  "padding-inline-start",
  "padding-left",
  "padding-right",
  "padding-top",
  "page",
  "page-break-after",
  "page-break-before",
  "page-break-inside",
  "paint-order",
  "pause",
  "pause-after",
  "pause-before",
  "perspective",
  "perspective-origin",
  "place-content",
  "place-items",
  "place-self",
  "pointer-events",
  "position",
  "position-anchor",
  "position-visibility",
  "print-color-adjust",
  "quotes",
  "r",
  "resize",
  "rest",
  "rest-after",
  "rest-before",
  "right",
  "rotate",
  "row-gap",
  "ruby-align",
  "ruby-position",
  "scale",
  "scroll-behavior",
  "scroll-margin",
  "scroll-margin-block",
  "scroll-margin-block-end",
  "scroll-margin-block-start",
  "scroll-margin-bottom",
  "scroll-margin-inline",
  "scroll-margin-inline-end",
  "scroll-margin-inline-start",
  "scroll-margin-left",
  "scroll-margin-right",
  "scroll-margin-top",
  "scroll-padding",
  "scroll-padding-block",
  "scroll-padding-block-end",
  "scroll-padding-block-start",
  "scroll-padding-bottom",
  "scroll-padding-inline",
  "scroll-padding-inline-end",
  "scroll-padding-inline-start",
  "scroll-padding-left",
  "scroll-padding-right",
  "scroll-padding-top",
  "scroll-snap-align",
  "scroll-snap-stop",
  "scroll-snap-type",
  "scroll-timeline",
  "scroll-timeline-axis",
  "scroll-timeline-name",
  "scrollbar-color",
  "scrollbar-gutter",
  "scrollbar-width",
  "shape-image-threshold",
  "shape-margin",
  "shape-outside",
  "shape-rendering",
  "speak",
  "speak-as",
  "src",
  // @font-face
  "stop-color",
  "stop-opacity",
  "stroke",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke-width",
  "tab-size",
  "table-layout",
  "text-align",
  "text-align-all",
  "text-align-last",
  "text-anchor",
  "text-combine-upright",
  "text-decoration",
  "text-decoration-color",
  "text-decoration-line",
  "text-decoration-skip",
  "text-decoration-skip-ink",
  "text-decoration-style",
  "text-decoration-thickness",
  "text-emphasis",
  "text-emphasis-color",
  "text-emphasis-position",
  "text-emphasis-style",
  "text-indent",
  "text-justify",
  "text-orientation",
  "text-overflow",
  "text-rendering",
  "text-shadow",
  "text-size-adjust",
  "text-transform",
  "text-underline-offset",
  "text-underline-position",
  "text-wrap",
  "text-wrap-mode",
  "text-wrap-style",
  "timeline-scope",
  "top",
  "touch-action",
  "transform",
  "transform-box",
  "transform-origin",
  "transform-style",
  "transition",
  "transition-behavior",
  "transition-delay",
  "transition-duration",
  "transition-property",
  "transition-timing-function",
  "translate",
  "unicode-bidi",
  "user-modify",
  "user-select",
  "vector-effect",
  "vertical-align",
  "view-timeline",
  "view-timeline-axis",
  "view-timeline-inset",
  "view-timeline-name",
  "view-transition-name",
  "visibility",
  "voice-balance",
  "voice-duration",
  "voice-family",
  "voice-pitch",
  "voice-range",
  "voice-rate",
  "voice-stress",
  "voice-volume",
  "white-space",
  "white-space-collapse",
  "widows",
  "width",
  "will-change",
  "word-break",
  "word-spacing",
  "word-wrap",
  "writing-mode",
  "x",
  "y",
  "z-index",
  "zoom"
].sort().reverse(), Sp = oi.concat(si).sort().reverse();
function kp(e) {
  const t = fp(e), n = Sp, a = "and or not only", r = "[\\w-]+", o = "(" + r + "|@\\{" + r + "\\})", s = [], i = [], c = function(S) {
    return {
      // Less strings are not multiline (also include '~' for more consistent coloring of "escaped" strings)
      className: "string",
      begin: "~?" + S + ".*?" + S
    };
  }, l = function(S, y, x) {
    return {
      className: S,
      begin: y,
      relevance: x
    };
  }, d = {
    $pattern: /[a-z-]+/,
    keyword: a,
    attribute: Ep.join(" ")
  }, u = {
    // used only to properly balance nested parens inside mixin call, def. arg list
    begin: "\\(",
    end: "\\)",
    contains: i,
    keywords: d,
    relevance: 0
  };
  i.push(
    e.C_LINE_COMMENT_MODE,
    e.C_BLOCK_COMMENT_MODE,
    c("'"),
    c('"'),
    t.CSS_NUMBER_MODE,
    // fixme: it does not include dot for numbers like .5em :(
    {
      begin: "(url|data-uri)\\(",
      starts: {
        className: "string",
        end: "[\\)\\n]",
        excludeEnd: !0
      }
    },
    t.HEXCOLOR,
    u,
    l("variable", "@@?" + r, 10),
    l("variable", "@\\{" + r + "\\}"),
    l("built_in", "~?`[^`]*?`"),
    // inline javascript (or whatever host language) *multiline* string
    {
      // @media features (it’s here to not duplicate things in AT_RULE_MODE with extra PARENS_MODE overriding):
      className: "attribute",
      begin: r + "\\s*:",
      end: ":",
      returnBegin: !0,
      excludeEnd: !0
    },
    t.IMPORTANT,
    { beginKeywords: "and not" },
    t.FUNCTION_DISPATCH
  );
  const m = i.concat({
    begin: /\{/,
    end: /\}/,
    contains: s
  }), g = {
    beginKeywords: "when",
    endsWithParent: !0,
    contains: [{ beginKeywords: "and not" }].concat(i)
    // using this form to override VALUE’s 'function' match
  }, f = {
    begin: o + "\\s*:",
    returnBegin: !0,
    end: /[;}]/,
    relevance: 0,
    contains: [
      { begin: /-(webkit|moz|ms|o)-/ },
      t.CSS_VARIABLE,
      {
        className: "attribute",
        begin: "\\b(" + _p.join("|") + ")\\b",
        end: /(?=:)/,
        starts: {
          endsWithParent: !0,
          illegal: "[<=$]",
          relevance: 0,
          contains: i
        }
      }
    ]
  }, b = {
    className: "keyword",
    begin: "@(import|media|charset|font-face|(-[a-z]+-)?keyframes|supports|document|namespace|page|viewport|host)\\b",
    starts: {
      end: "[;{}]",
      keywords: d,
      returnEnd: !0,
      contains: i,
      relevance: 0
    }
  }, E = {
    className: "variable",
    variants: [
      // using more strict pattern for higher relevance to increase chances of Less detection.
      // this is *the only* Less specific statement used in most of the sources, so...
      // (we’ll still often loose to the css-parser unless there's '//' comment,
      // simply because 1 variable just can't beat 99 properties :)
      {
        begin: "@" + r + "\\s*:",
        relevance: 15
      },
      { begin: "@" + r }
    ],
    starts: {
      end: "[;}]",
      returnEnd: !0,
      contains: m
    }
  }, _ = {
    // first parse unambiguous selectors (i.e. those not starting with tag)
    // then fall into the scary lookahead-discriminator variant.
    // this mode also handles mixin definitions and calls
    variants: [
      {
        begin: "[\\.#:&\\[>]",
        end: "[;{}]"
        // mixin calls end with ';'
      },
      {
        begin: o,
        end: /\{/
      }
    ],
    returnBegin: !0,
    returnEnd: !0,
    illegal: `[<='$"]`,
    relevance: 0,
    contains: [
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      g,
      l("keyword", "all\\b"),
      l("variable", "@\\{" + r + "\\}"),
      // otherwise it’s identified as tag
      {
        begin: "\\b(" + yp.join("|") + ")\\b",
        className: "selector-tag"
      },
      t.CSS_NUMBER_MODE,
      l("selector-tag", o, 0),
      l("selector-id", "#" + o),
      l("selector-class", "\\." + o, 0),
      l("selector-tag", "&", 0),
      t.ATTRIBUTE_SELECTOR_MODE,
      {
        className: "selector-pseudo",
        begin: ":(" + oi.join("|") + ")"
      },
      {
        className: "selector-pseudo",
        begin: ":(:)?(" + si.join("|") + ")"
      },
      {
        begin: /\(/,
        end: /\)/,
        relevance: 0,
        contains: m
      },
      // argument list of parametric mixins
      { begin: "!important" },
      // eat !important after mixin call or it will be colored as tag
      t.FUNCTION_DISPATCH
    ]
  }, k = {
    begin: r + `:(:)?(${n.join("|")})`,
    returnBegin: !0,
    contains: [_]
  };
  return s.push(
    e.C_LINE_COMMENT_MODE,
    e.C_BLOCK_COMMENT_MODE,
    b,
    E,
    k,
    f,
    _,
    g,
    t.FUNCTION_DISPATCH
  ), {
    name: "Less",
    case_insensitive: !0,
    illegal: `[=>'/<($"]`,
    contains: s
  };
}
function vp(e) {
  const t = "\\[=*\\[", n = "\\]=*\\]", a = {
    begin: t,
    end: n,
    contains: ["self"]
  }, r = [
    e.COMMENT("--(?!" + t + ")", "$"),
    e.COMMENT(
      "--" + t,
      n,
      {
        contains: [a],
        relevance: 10
      }
    )
  ];
  return {
    name: "Lua",
    aliases: ["pluto"],
    keywords: {
      $pattern: e.UNDERSCORE_IDENT_RE,
      literal: "true false nil",
      keyword: "and break do else elseif end for goto if in local not or repeat return then until while",
      built_in: (
        // Metatags and globals:
        "_G _ENV _VERSION __index __newindex __mode __call __metatable __tostring __len __gc __add __sub __mul __div __mod __pow __concat __unm __eq __lt __le assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring type unpack xpcall arg self coroutine resume yield status wrap create running debug getupvalue debug sethook getmetatable gethook setmetatable setlocal traceback setfenv getinfo setupvalue getlocal getregistry getfenv io lines write close flush open output type read stderr stdin input stdout popen tmpfile math log max acos huge ldexp pi cos tanh pow deg tan cosh sinh random randomseed frexp ceil floor rad abs sqrt modf asin min mod fmod log10 atan2 exp sin atan os exit setlocale date getenv difftime remove time clock tmpname rename execute package preload loadlib loaded loaders cpath config path seeall string sub upper len gfind rep find match char dump gmatch reverse byte format gsub lower table setn insert getn foreachi maxn foreach concat sort remove"
      )
    },
    contains: r.concat([
      {
        className: "function",
        beginKeywords: "function",
        end: "\\)",
        contains: [
          e.inherit(e.TITLE_MODE, { begin: "([_a-zA-Z]\\w*\\.)*([_a-zA-Z]\\w*:)?[_a-zA-Z]\\w*" }),
          {
            className: "params",
            begin: "\\(",
            endsWithParent: !0,
            contains: r
          }
        ].concat(r)
      },
      e.C_NUMBER_MODE,
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE,
      {
        className: "string",
        begin: t,
        end: n,
        contains: [a],
        relevance: 5
      }
    ])
  };
}
function Tp(e) {
  const t = {
    className: "variable",
    variants: [
      {
        begin: "\\$\\(" + e.UNDERSCORE_IDENT_RE + "\\)",
        contains: [e.BACKSLASH_ESCAPE]
      },
      { begin: /\$[@%<?\^\+\*]/ }
    ]
  }, n = {
    className: "string",
    begin: /"/,
    end: /"/,
    contains: [
      e.BACKSLASH_ESCAPE,
      t
    ]
  }, a = {
    className: "variable",
    begin: /\$\([\w-]+\s/,
    end: /\)/,
    keywords: { built_in: "subst patsubst strip findstring filter filter-out sort word wordlist firstword lastword dir notdir suffix basename addsuffix addprefix join wildcard realpath abspath error warning shell origin flavor foreach if or and call eval file value" },
    contains: [
      t,
      n
      // Added QUOTE_STRING as they can be a part of functions
    ]
  }, r = { begin: "^" + e.UNDERSCORE_IDENT_RE + "\\s*(?=[:+?]?=)" }, o = {
    className: "meta",
    begin: /^\.PHONY:/,
    end: /$/,
    keywords: {
      $pattern: /[\.\w]+/,
      keyword: ".PHONY"
    }
  }, s = {
    className: "section",
    begin: /^[^\s]+:/,
    end: /$/,
    contains: [t]
  };
  return {
    name: "Makefile",
    aliases: [
      "mk",
      "mak",
      "make"
    ],
    keywords: {
      $pattern: /[\w-]+/,
      keyword: "define endef undefine ifdef ifndef ifeq ifneq else endif include -include sinclude override export unexport private vpath"
    },
    contains: [
      e.HASH_COMMENT_MODE,
      t,
      n,
      a,
      r,
      o,
      s
    ]
  };
}
function wp(e) {
  const t = e.regex, n = {
    begin: /<\/?[A-Za-z_]/,
    end: ">",
    subLanguage: "xml",
    relevance: 0
  }, a = {
    begin: "^[-\\*]{3,}",
    end: "$"
  }, r = {
    className: "code",
    variants: [
      // TODO: fix to allow these to work with sublanguage also
      { begin: "(`{3,})[^`](.|\\n)*?\\1`*[ ]*" },
      { begin: "(~{3,})[^~](.|\\n)*?\\1~*[ ]*" },
      // needed to allow markdown as a sublanguage to work
      {
        begin: "```",
        end: "```+[ ]*$"
      },
      {
        begin: "~~~",
        end: "~~~+[ ]*$"
      },
      { begin: "`.+?`" },
      {
        begin: "(?=^( {4}|\\t))",
        // use contains to gobble up multiple lines to allow the block to be whatever size
        // but only have a single open/close tag vs one per line
        contains: [
          {
            begin: "^( {4}|\\t)",
            end: "(\\n)$"
          }
        ],
        relevance: 0
      }
    ]
  }, o = {
    className: "bullet",
    begin: "^[ 	]*([*+-]|(\\d+\\.))(?=\\s+)",
    end: "\\s+",
    excludeEnd: !0
  }, s = {
    begin: /^\[[^\n]+\]:/,
    returnBegin: !0,
    contains: [
      {
        className: "symbol",
        begin: /\[/,
        end: /\]/,
        excludeBegin: !0,
        excludeEnd: !0
      },
      {
        className: "link",
        begin: /:\s*/,
        end: /$/,
        excludeBegin: !0
      }
    ]
  }, i = /[A-Za-z][A-Za-z0-9+.-]*/, c = {
    variants: [
      // too much like nested array access in so many languages
      // to have any real relevance
      {
        begin: /\[.+?\]\[.*?\]/,
        relevance: 0
      },
      // popular internet URLs
      {
        begin: /\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,
        relevance: 2
      },
      {
        begin: t.concat(/\[.+?\]\(/, i, /:\/\/.*?\)/),
        relevance: 2
      },
      // relative urls
      {
        begin: /\[.+?\]\([./?&#].*?\)/,
        relevance: 1
      },
      // whatever else, lower relevance (might not be a link at all)
      {
        begin: /\[.*?\]\(.*?\)/,
        relevance: 0
      }
    ],
    returnBegin: !0,
    contains: [
      {
        // empty strings for alt or link text
        match: /\[(?=\])/
      },
      {
        className: "string",
        relevance: 0,
        begin: "\\[",
        end: "\\]",
        excludeBegin: !0,
        returnEnd: !0
      },
      {
        className: "link",
        relevance: 0,
        begin: "\\]\\(",
        end: "\\)",
        excludeBegin: !0,
        excludeEnd: !0
      },
      {
        className: "symbol",
        relevance: 0,
        begin: "\\]\\[",
        end: "\\]",
        excludeBegin: !0,
        excludeEnd: !0
      }
    ]
  }, l = {
    className: "strong",
    contains: [],
    // defined later
    variants: [
      {
        begin: /_{2}(?!\s)/,
        end: /_{2}/
      },
      {
        begin: /\*{2}(?!\s)/,
        end: /\*{2}/
      }
    ]
  }, d = {
    className: "emphasis",
    contains: [],
    // defined later
    variants: [
      {
        begin: /\*(?![*\s])/,
        end: /\*/
      },
      {
        begin: /_(?![_\s])/,
        end: /_/,
        relevance: 0
      }
    ]
  }, u = e.inherit(l, { contains: [] }), m = e.inherit(d, { contains: [] });
  l.contains.push(m), d.contains.push(u);
  let g = [
    n,
    c
  ];
  return [
    l,
    d,
    u,
    m
  ].forEach((_) => {
    _.contains = _.contains.concat(g);
  }), g = g.concat(l, d), {
    name: "Markdown",
    aliases: [
      "md",
      "mkdown",
      "mkd"
    ],
    contains: [
      {
        className: "section",
        variants: [
          {
            begin: "^#{1,6}",
            end: "$",
            contains: g
          },
          {
            begin: "(?=^.+?\\n[=-]{2,}$)",
            contains: [
              { begin: "^[=-]*$" },
              {
                begin: "^",
                end: "\\n",
                contains: g
              }
            ]
          }
        ]
      },
      n,
      o,
      l,
      d,
      {
        className: "quote",
        begin: "^>\\s+",
        contains: g,
        end: "$"
      },
      r,
      a,
      c,
      s,
      {
        //https://spec.commonmark.org/0.31.2/#entity-references
        scope: "literal",
        match: /&([a-zA-Z0-9]+|#[0-9]{1,7}|#[Xx][0-9a-fA-F]{1,6});/
      }
    ]
  };
}
function Np(e) {
  const t = {
    className: "built_in",
    begin: "\\b(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)\\w+"
  }, n = /[a-zA-Z@][a-zA-Z0-9_]*/, i = {
    "variable.language": [
      "this",
      "super"
    ],
    $pattern: n,
    keyword: [
      "while",
      "export",
      "sizeof",
      "typedef",
      "const",
      "struct",
      "for",
      "union",
      "volatile",
      "static",
      "mutable",
      "if",
      "do",
      "return",
      "goto",
      "enum",
      "else",
      "break",
      "extern",
      "asm",
      "case",
      "default",
      "register",
      "explicit",
      "typename",
      "switch",
      "continue",
      "inline",
      "readonly",
      "assign",
      "readwrite",
      "self",
      "@synchronized",
      "id",
      "typeof",
      "nonatomic",
      "IBOutlet",
      "IBAction",
      "strong",
      "weak",
      "copy",
      "in",
      "out",
      "inout",
      "bycopy",
      "byref",
      "oneway",
      "__strong",
      "__weak",
      "__block",
      "__autoreleasing",
      "@private",
      "@protected",
      "@public",
      "@try",
      "@property",
      "@end",
      "@throw",
      "@catch",
      "@finally",
      "@autoreleasepool",
      "@synthesize",
      "@dynamic",
      "@selector",
      "@optional",
      "@required",
      "@encode",
      "@package",
      "@import",
      "@defs",
      "@compatibility_alias",
      "__bridge",
      "__bridge_transfer",
      "__bridge_retained",
      "__bridge_retain",
      "__covariant",
      "__contravariant",
      "__kindof",
      "_Nonnull",
      "_Nullable",
      "_Null_unspecified",
      "__FUNCTION__",
      "__PRETTY_FUNCTION__",
      "__attribute__",
      "getter",
      "setter",
      "retain",
      "unsafe_unretained",
      "nonnull",
      "nullable",
      "null_unspecified",
      "null_resettable",
      "class",
      "instancetype",
      "NS_DESIGNATED_INITIALIZER",
      "NS_UNAVAILABLE",
      "NS_REQUIRES_SUPER",
      "NS_RETURNS_INNER_POINTER",
      "NS_INLINE",
      "NS_AVAILABLE",
      "NS_DEPRECATED",
      "NS_ENUM",
      "NS_OPTIONS",
      "NS_SWIFT_UNAVAILABLE",
      "NS_ASSUME_NONNULL_BEGIN",
      "NS_ASSUME_NONNULL_END",
      "NS_REFINED_FOR_SWIFT",
      "NS_SWIFT_NAME",
      "NS_SWIFT_NOTHROW",
      "NS_DURING",
      "NS_HANDLER",
      "NS_ENDHANDLER",
      "NS_VALUERETURN",
      "NS_VOIDRETURN"
    ],
    literal: [
      "false",
      "true",
      "FALSE",
      "TRUE",
      "nil",
      "YES",
      "NO",
      "NULL"
    ],
    built_in: [
      "dispatch_once_t",
      "dispatch_queue_t",
      "dispatch_sync",
      "dispatch_async",
      "dispatch_once"
    ],
    type: [
      "int",
      "float",
      "char",
      "unsigned",
      "signed",
      "short",
      "long",
      "double",
      "wchar_t",
      "unichar",
      "void",
      "bool",
      "BOOL",
      "id|0",
      "_Bool"
    ]
  }, c = {
    $pattern: n,
    keyword: [
      "@interface",
      "@class",
      "@protocol",
      "@implementation"
    ]
  };
  return {
    name: "Objective-C",
    aliases: [
      "mm",
      "objc",
      "obj-c",
      "obj-c++",
      "objective-c++"
    ],
    keywords: i,
    illegal: "</",
    contains: [
      t,
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      e.C_NUMBER_MODE,
      e.QUOTE_STRING_MODE,
      e.APOS_STRING_MODE,
      {
        className: "string",
        variants: [
          {
            begin: '@"',
            end: '"',
            illegal: "\\n",
            contains: [e.BACKSLASH_ESCAPE]
          }
        ]
      },
      {
        className: "meta",
        begin: /#\s*[a-z]+\b/,
        end: /$/,
        keywords: { keyword: "if else elif endif define undef warning error line pragma ifdef ifndef include" },
        contains: [
          {
            begin: /\\\n/,
            relevance: 0
          },
          e.inherit(e.QUOTE_STRING_MODE, { className: "string" }),
          {
            className: "string",
            begin: /<.*?>/,
            end: /$/,
            illegal: "\\n"
          },
          e.C_LINE_COMMENT_MODE,
          e.C_BLOCK_COMMENT_MODE
        ]
      },
      {
        className: "class",
        begin: "(" + c.keyword.join("|") + ")\\b",
        end: /(\{|$)/,
        excludeEnd: !0,
        keywords: c,
        contains: [e.UNDERSCORE_TITLE_MODE]
      },
      {
        begin: "\\." + e.UNDERSCORE_IDENT_RE,
        relevance: 0
      }
    ]
  };
}
function xp(e) {
  const t = e.regex, n = [
    "abs",
    "accept",
    "alarm",
    "and",
    "atan2",
    "bind",
    "binmode",
    "bless",
    "break",
    "caller",
    "chdir",
    "chmod",
    "chomp",
    "chop",
    "chown",
    "chr",
    "chroot",
    "class",
    "close",
    "closedir",
    "connect",
    "continue",
    "cos",
    "crypt",
    "dbmclose",
    "dbmopen",
    "defined",
    "delete",
    "die",
    "do",
    "dump",
    "each",
    "else",
    "elsif",
    "endgrent",
    "endhostent",
    "endnetent",
    "endprotoent",
    "endpwent",
    "endservent",
    "eof",
    "eval",
    "exec",
    "exists",
    "exit",
    "exp",
    "fcntl",
    "field",
    "fileno",
    "flock",
    "for",
    "foreach",
    "fork",
    "format",
    "formline",
    "getc",
    "getgrent",
    "getgrgid",
    "getgrnam",
    "gethostbyaddr",
    "gethostbyname",
    "gethostent",
    "getlogin",
    "getnetbyaddr",
    "getnetbyname",
    "getnetent",
    "getpeername",
    "getpgrp",
    "getpriority",
    "getprotobyname",
    "getprotobynumber",
    "getprotoent",
    "getpwent",
    "getpwnam",
    "getpwuid",
    "getservbyname",
    "getservbyport",
    "getservent",
    "getsockname",
    "getsockopt",
    "given",
    "glob",
    "gmtime",
    "goto",
    "grep",
    "gt",
    "hex",
    "if",
    "index",
    "int",
    "ioctl",
    "join",
    "keys",
    "kill",
    "last",
    "lc",
    "lcfirst",
    "length",
    "link",
    "listen",
    "local",
    "localtime",
    "log",
    "lstat",
    "lt",
    "ma",
    "map",
    "method",
    "mkdir",
    "msgctl",
    "msgget",
    "msgrcv",
    "msgsnd",
    "my",
    "ne",
    "next",
    "no",
    "not",
    "oct",
    "open",
    "opendir",
    "or",
    "ord",
    "our",
    "pack",
    "package",
    "pipe",
    "pop",
    "pos",
    "print",
    "printf",
    "prototype",
    "push",
    "q|0",
    "qq",
    "quotemeta",
    "qw",
    "qx",
    "rand",
    "read",
    "readdir",
    "readline",
    "readlink",
    "readpipe",
    "recv",
    "redo",
    "ref",
    "rename",
    "require",
    "reset",
    "return",
    "reverse",
    "rewinddir",
    "rindex",
    "rmdir",
    "say",
    "scalar",
    "seek",
    "seekdir",
    "select",
    "semctl",
    "semget",
    "semop",
    "send",
    "setgrent",
    "sethostent",
    "setnetent",
    "setpgrp",
    "setpriority",
    "setprotoent",
    "setpwent",
    "setservent",
    "setsockopt",
    "shift",
    "shmctl",
    "shmget",
    "shmread",
    "shmwrite",
    "shutdown",
    "sin",
    "sleep",
    "socket",
    "socketpair",
    "sort",
    "splice",
    "split",
    "sprintf",
    "sqrt",
    "srand",
    "stat",
    "state",
    "study",
    "sub",
    "substr",
    "symlink",
    "syscall",
    "sysopen",
    "sysread",
    "sysseek",
    "system",
    "syswrite",
    "tell",
    "telldir",
    "tie",
    "tied",
    "time",
    "times",
    "tr",
    "truncate",
    "uc",
    "ucfirst",
    "umask",
    "undef",
    "unless",
    "unlink",
    "unpack",
    "unshift",
    "untie",
    "until",
    "use",
    "utime",
    "values",
    "vec",
    "wait",
    "waitpid",
    "wantarray",
    "warn",
    "when",
    "while",
    "write",
    "x|0",
    "xor",
    "y|0"
  ], a = /[dualxmsipngr]{0,12}/, r = {
    $pattern: /[\w.]+/,
    keyword: n.join(" ")
  }, o = {
    className: "subst",
    begin: "[$@]\\{",
    end: "\\}",
    keywords: r
  }, s = {
    begin: /->\{/,
    end: /\}/
    // contains defined later
  }, i = {
    scope: "attr",
    match: /\s+:\s*\w+(\s*\(.*?\))?/
  }, c = {
    scope: "variable",
    variants: [
      { begin: /\$\d/ },
      {
        begin: t.concat(
          /[$%@](?!")(\^\w\b|#\w+(::\w+)*|\{\w+\}|\w+(::\w*)*)/,
          // negative look-ahead tries to avoid matching patterns that are not
          // Perl at all like $ident$, @ident@, etc.
          "(?![A-Za-z])(?![@$%])"
        )
      },
      {
        // Only $= is a special Perl variable and one can't declare @= or %=.
        begin: /[$%@](?!")[^\s\w{=]|\$=/,
        relevance: 0
      }
    ],
    contains: [i]
  }, l = {
    className: "number",
    variants: [
      // decimal numbers:
      // include the case where a number starts with a dot (eg. .9), and
      // the leading 0? avoids mixing the first and second match on 0.x cases
      { match: /0?\.[0-9][0-9_]+\b/ },
      // include the special versioned number (eg. v5.38)
      { match: /\bv?(0|[1-9][0-9_]*(\.[0-9_]+)?|[1-9][0-9_]*)\b/ },
      // non-decimal numbers:
      { match: /\b0[0-7][0-7_]*\b/ },
      { match: /\b0x[0-9a-fA-F][0-9a-fA-F_]*\b/ },
      { match: /\b0b[0-1][0-1_]*\b/ }
    ],
    relevance: 0
  }, d = [
    e.BACKSLASH_ESCAPE,
    o,
    c
  ], u = [
    /!/,
    /\//,
    /\|/,
    /\?/,
    /'/,
    /"/,
    // valid but infrequent and weird
    /#/
    // valid but infrequent and weird
  ], m = (b, E, _ = "\\1") => {
    const k = _ === "\\1" ? _ : t.concat(_, E);
    return t.concat(
      t.concat("(?:", b, ")"),
      E,
      /(?:\\.|[^\\\/])*?/,
      k,
      /(?:\\.|[^\\\/])*?/,
      _,
      a
    );
  }, g = (b, E, _) => t.concat(
    t.concat("(?:", b, ")"),
    E,
    /(?:\\.|[^\\\/])*?/,
    _,
    a
  ), f = [
    c,
    e.HASH_COMMENT_MODE,
    e.COMMENT(
      /^=\w/,
      /=cut/,
      { endsWithParent: !0 }
    ),
    s,
    {
      className: "string",
      contains: d,
      variants: [
        {
          begin: "q[qwxr]?\\s*\\(",
          end: "\\)",
          relevance: 5
        },
        {
          begin: "q[qwxr]?\\s*\\[",
          end: "\\]",
          relevance: 5
        },
        {
          begin: "q[qwxr]?\\s*\\{",
          end: "\\}",
          relevance: 5
        },
        {
          begin: "q[qwxr]?\\s*\\|",
          end: "\\|",
          relevance: 5
        },
        {
          begin: "q[qwxr]?\\s*<",
          end: ">",
          relevance: 5
        },
        {
          begin: "qw\\s+q",
          end: "q",
          relevance: 5
        },
        {
          begin: "'",
          end: "'",
          contains: [e.BACKSLASH_ESCAPE]
        },
        {
          begin: '"',
          end: '"'
        },
        {
          begin: "`",
          end: "`",
          contains: [e.BACKSLASH_ESCAPE]
        },
        {
          begin: /\{\w+\}/,
          relevance: 0
        },
        {
          begin: "-?\\w+\\s*=>",
          relevance: 0
        }
      ]
    },
    l,
    {
      // regexp container
      begin: "(\\/\\/|" + e.RE_STARTERS_RE + "|\\b(split|return|print|reverse|grep)\\b)\\s*",
      keywords: "split return print reverse grep",
      relevance: 0,
      contains: [
        e.HASH_COMMENT_MODE,
        {
          className: "regexp",
          variants: [
            // allow matching common delimiters
            { begin: m("s|tr|y", t.either(...u, { capture: !0 })) },
            // and then paired delmis
            { begin: m("s|tr|y", "\\(", "\\)") },
            { begin: m("s|tr|y", "\\[", "\\]") },
            { begin: m("s|tr|y", "\\{", "\\}") }
          ],
          relevance: 2
        },
        {
          className: "regexp",
          variants: [
            {
              // could be a comment in many languages so do not count
              // as relevant
              begin: /(m|qr)\/\//,
              relevance: 0
            },
            // prefix is optional with /regex/
            { begin: g("(?:m|qr)?", /\//, /\//) },
            // allow matching common delimiters
            { begin: g("m|qr", t.either(...u, { capture: !0 }), /\1/) },
            // allow common paired delmins
            { begin: g("m|qr", /\(/, /\)/) },
            { begin: g("m|qr", /\[/, /\]/) },
            { begin: g("m|qr", /\{/, /\}/) }
          ]
        }
      ]
    },
    {
      className: "function",
      beginKeywords: "sub method",
      end: "(\\s*\\(.*?\\))?[;{]",
      excludeEnd: !0,
      relevance: 5,
      contains: [e.TITLE_MODE, i]
    },
    {
      className: "class",
      beginKeywords: "class",
      end: "[;{]",
      excludeEnd: !0,
      relevance: 5,
      contains: [e.TITLE_MODE, i, l]
    },
    {
      begin: "-\\w\\b",
      relevance: 0
    },
    {
      begin: "^__DATA__$",
      end: "^__END__$",
      subLanguage: "mojolicious",
      contains: [
        {
          begin: "^@@.*",
          end: "$",
          className: "comment"
        }
      ]
    }
  ];
  return o.contains = f, s.contains = f, {
    name: "Perl",
    aliases: [
      "pl",
      "pm"
    ],
    keywords: r,
    contains: f
  };
}
function Cp(e) {
  const t = e.regex, n = /(?![A-Za-z0-9])(?![$])/, a = t.concat(
    /[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/,
    n
  ), r = t.concat(
    /(\\?[A-Z][a-z0-9_\x7f-\xff]+|\\?[A-Z]+(?=[A-Z][a-z0-9_\x7f-\xff])){1,}/,
    n
  ), o = t.concat(
    /[A-Z]+/,
    n
  ), s = {
    scope: "variable",
    match: "\\$+" + a
  }, i = {
    scope: "meta",
    variants: [
      { begin: /<\?php/, relevance: 10 },
      // boost for obvious PHP
      { begin: /<\?=/ },
      // less relevant per PSR-1 which says not to use short-tags
      { begin: /<\?/, relevance: 0.1 },
      { begin: /\?>/ }
      // end php tag
    ]
  }, c = {
    scope: "subst",
    variants: [
      { begin: /\$\w+/ },
      {
        begin: /\{\$/,
        end: /\}/
      }
    ]
  }, l = e.inherit(e.APOS_STRING_MODE, { illegal: null }), d = e.inherit(e.QUOTE_STRING_MODE, {
    illegal: null,
    contains: e.QUOTE_STRING_MODE.contains.concat(c)
  }), u = {
    begin: /<<<[ \t]*(?:(\w+)|"(\w+)")\n/,
    end: /[ \t]*(\w+)\b/,
    contains: e.QUOTE_STRING_MODE.contains.concat(c),
    "on:begin": (V, re) => {
      re.data._beginMatch = V[1] || V[2];
    },
    "on:end": (V, re) => {
      re.data._beginMatch !== V[1] && re.ignoreMatch();
    }
  }, m = e.END_SAME_AS_BEGIN({
    begin: /<<<[ \t]*'(\w+)'\n/,
    end: /[ \t]*(\w+)\b/
  }), g = `[ 	
]`, f = {
    scope: "string",
    variants: [
      d,
      l,
      u,
      m
    ]
  }, b = {
    scope: "number",
    variants: [
      { begin: "\\b0[bB][01]+(?:_[01]+)*\\b" },
      // Binary w/ underscore support
      { begin: "\\b0[oO][0-7]+(?:_[0-7]+)*\\b" },
      // Octals w/ underscore support
      { begin: "\\b0[xX][\\da-fA-F]+(?:_[\\da-fA-F]+)*\\b" },
      // Hex w/ underscore support
      // Decimals w/ underscore support, with optional fragments and scientific exponent (e) suffix.
      { begin: "(?:\\b\\d+(?:_\\d+)*(\\.(?:\\d+(?:_\\d+)*))?|\\B\\.\\d+)(?:[eE][+-]?\\d+)?" }
    ],
    relevance: 0
  }, E = [
    "false",
    "null",
    "true"
  ], _ = [
    // Magic constants:
    // <https://www.php.net/manual/en/language.constants.predefined.php>
    "__CLASS__",
    "__DIR__",
    "__FILE__",
    "__FUNCTION__",
    "__COMPILER_HALT_OFFSET__",
    "__LINE__",
    "__METHOD__",
    "__NAMESPACE__",
    "__TRAIT__",
    // Function that look like language construct or language construct that look like function:
    // List of keywords that may not require parenthesis
    "die",
    "echo",
    "exit",
    "include",
    "include_once",
    "print",
    "require",
    "require_once",
    // These are not language construct (function) but operate on the currently-executing function and can access the current symbol table
    // 'compact extract func_get_arg func_get_args func_num_args get_called_class get_parent_class ' +
    // Other keywords:
    // <https://www.php.net/manual/en/reserved.php>
    // <https://www.php.net/manual/en/language.types.type-juggling.php>
    "array",
    "abstract",
    "and",
    "as",
    "binary",
    "bool",
    "boolean",
    "break",
    "callable",
    "case",
    "catch",
    "class",
    "clone",
    "const",
    "continue",
    "declare",
    "default",
    "do",
    "double",
    "else",
    "elseif",
    "empty",
    "enddeclare",
    "endfor",
    "endforeach",
    "endif",
    "endswitch",
    "endwhile",
    "enum",
    "eval",
    "extends",
    "final",
    "finally",
    "float",
    "for",
    "foreach",
    "from",
    "global",
    "goto",
    "if",
    "implements",
    "instanceof",
    "insteadof",
    "int",
    "integer",
    "interface",
    "isset",
    "iterable",
    "list",
    "match|0",
    "mixed",
    "new",
    "never",
    "object",
    "or",
    "private",
    "protected",
    "public",
    "readonly",
    "real",
    "return",
    "string",
    "switch",
    "throw",
    "trait",
    "try",
    "unset",
    "use",
    "var",
    "void",
    "while",
    "xor",
    "yield"
  ], k = [
    // Standard PHP library:
    // <https://www.php.net/manual/en/book.spl.php>
    "Error|0",
    "AppendIterator",
    "ArgumentCountError",
    "ArithmeticError",
    "ArrayIterator",
    "ArrayObject",
    "AssertionError",
    "BadFunctionCallException",
    "BadMethodCallException",
    "CachingIterator",
    "CallbackFilterIterator",
    "CompileError",
    "Countable",
    "DirectoryIterator",
    "DivisionByZeroError",
    "DomainException",
    "EmptyIterator",
    "ErrorException",
    "Exception",
    "FilesystemIterator",
    "FilterIterator",
    "GlobIterator",
    "InfiniteIterator",
    "InvalidArgumentException",
    "IteratorIterator",
    "LengthException",
    "LimitIterator",
    "LogicException",
    "MultipleIterator",
    "NoRewindIterator",
    "OutOfBoundsException",
    "OutOfRangeException",
    "OuterIterator",
    "OverflowException",
    "ParentIterator",
    "ParseError",
    "RangeException",
    "RecursiveArrayIterator",
    "RecursiveCachingIterator",
    "RecursiveCallbackFilterIterator",
    "RecursiveDirectoryIterator",
    "RecursiveFilterIterator",
    "RecursiveIterator",
    "RecursiveIteratorIterator",
    "RecursiveRegexIterator",
    "RecursiveTreeIterator",
    "RegexIterator",
    "RuntimeException",
    "SeekableIterator",
    "SplDoublyLinkedList",
    "SplFileInfo",
    "SplFileObject",
    "SplFixedArray",
    "SplHeap",
    "SplMaxHeap",
    "SplMinHeap",
    "SplObjectStorage",
    "SplObserver",
    "SplPriorityQueue",
    "SplQueue",
    "SplStack",
    "SplSubject",
    "SplTempFileObject",
    "TypeError",
    "UnderflowException",
    "UnexpectedValueException",
    "UnhandledMatchError",
    // Reserved interfaces:
    // <https://www.php.net/manual/en/reserved.interfaces.php>
    "ArrayAccess",
    "BackedEnum",
    "Closure",
    "Fiber",
    "Generator",
    "Iterator",
    "IteratorAggregate",
    "Serializable",
    "Stringable",
    "Throwable",
    "Traversable",
    "UnitEnum",
    "WeakReference",
    "WeakMap",
    // Reserved classes:
    // <https://www.php.net/manual/en/reserved.classes.php>
    "Directory",
    "__PHP_Incomplete_Class",
    "parent",
    "php_user_filter",
    "self",
    "static",
    "stdClass"
  ], y = {
    keyword: _,
    literal: ((V) => {
      const re = [];
      return V.forEach((be) => {
        re.push(be), be.toLowerCase() === be ? re.push(be.toUpperCase()) : re.push(be.toLowerCase());
      }), re;
    })(E),
    built_in: k
  }, x = (V) => V.map((re) => re.replace(/\|\d+$/, "")), C = { variants: [
    {
      match: [
        /new/,
        t.concat(g, "+"),
        // to prevent built ins from being confused as the class constructor call
        t.concat("(?!", x(k).join("\\b|"), "\\b)"),
        r
      ],
      scope: {
        1: "keyword",
        4: "title.class"
      }
    }
  ] }, O = t.concat(a, "\\b(?!\\()"), P = { variants: [
    {
      match: [
        t.concat(
          /::/,
          t.lookahead(/(?!class\b)/)
        ),
        O
      ],
      scope: { 2: "variable.constant" }
    },
    {
      match: [
        /::/,
        /class/
      ],
      scope: { 2: "variable.language" }
    },
    {
      match: [
        r,
        t.concat(
          /::/,
          t.lookahead(/(?!class\b)/)
        ),
        O
      ],
      scope: {
        1: "title.class",
        3: "variable.constant"
      }
    },
    {
      match: [
        r,
        t.concat(
          "::",
          t.lookahead(/(?!class\b)/)
        )
      ],
      scope: { 1: "title.class" }
    },
    {
      match: [
        r,
        /::/,
        /class/
      ],
      scope: {
        1: "title.class",
        3: "variable.language"
      }
    }
  ] }, G = {
    scope: "attr",
    match: t.concat(a, t.lookahead(":"), t.lookahead(/(?!::)/))
  }, K = {
    relevance: 0,
    begin: /\(/,
    end: /\)/,
    keywords: y,
    contains: [
      G,
      s,
      P,
      e.C_BLOCK_COMMENT_MODE,
      f,
      b,
      C
    ]
  }, oe = {
    relevance: 0,
    match: [
      /\b/,
      // to prevent keywords from being confused as the function title
      t.concat("(?!fn\\b|function\\b|", x(_).join("\\b|"), "|", x(k).join("\\b|"), "\\b)"),
      a,
      t.concat(g, "*"),
      t.lookahead(/(?=\()/)
    ],
    scope: { 3: "title.function.invoke" },
    contains: [K]
  };
  K.contains.push(oe);
  const L = [
    G,
    P,
    e.C_BLOCK_COMMENT_MODE,
    f,
    b,
    C
  ], Z = {
    begin: t.concat(
      /#\[\s*\\?/,
      t.either(
        r,
        o
      )
    ),
    beginScope: "meta",
    end: /]/,
    endScope: "meta",
    keywords: {
      literal: E,
      keyword: [
        "new",
        "array"
      ]
    },
    contains: [
      {
        begin: /\[/,
        end: /]/,
        keywords: {
          literal: E,
          keyword: [
            "new",
            "array"
          ]
        },
        contains: [
          "self",
          ...L
        ]
      },
      ...L,
      {
        scope: "meta",
        variants: [
          { match: r },
          { match: o }
        ]
      }
    ]
  };
  return {
    case_insensitive: !1,
    keywords: y,
    contains: [
      Z,
      e.HASH_COMMENT_MODE,
      e.COMMENT("//", "$"),
      e.COMMENT(
        "/\\*",
        "\\*/",
        { contains: [
          {
            scope: "doctag",
            match: "@[A-Za-z]+"
          }
        ] }
      ),
      {
        match: /__halt_compiler\(\);/,
        keywords: "__halt_compiler",
        starts: {
          scope: "comment",
          end: e.MATCH_NOTHING_RE,
          contains: [
            {
              match: /\?>/,
              scope: "meta",
              endsParent: !0
            }
          ]
        }
      },
      i,
      {
        scope: "variable.language",
        match: /\$this\b/
      },
      s,
      oe,
      P,
      {
        match: [
          /const/,
          /\s/,
          a
        ],
        scope: {
          1: "keyword",
          3: "variable.constant"
        }
      },
      C,
      {
        scope: "function",
        relevance: 0,
        beginKeywords: "fn function",
        end: /[;{]/,
        excludeEnd: !0,
        illegal: "[$%\\[]",
        contains: [
          { beginKeywords: "use" },
          e.UNDERSCORE_TITLE_MODE,
          {
            begin: "=>",
            // No markup, just a relevance booster
            endsParent: !0
          },
          {
            scope: "params",
            begin: "\\(",
            end: "\\)",
            excludeBegin: !0,
            excludeEnd: !0,
            keywords: y,
            contains: [
              "self",
              Z,
              s,
              P,
              e.C_BLOCK_COMMENT_MODE,
              f,
              b
            ]
          }
        ]
      },
      {
        scope: "class",
        variants: [
          {
            beginKeywords: "enum",
            illegal: /[($"]/
          },
          {
            beginKeywords: "class interface trait",
            illegal: /[:($"]/
          }
        ],
        relevance: 0,
        end: /\{/,
        excludeEnd: !0,
        contains: [
          { beginKeywords: "extends implements" },
          e.UNDERSCORE_TITLE_MODE
        ]
      },
      // both use and namespace still use "old style" rules (vs multi-match)
      // because the namespace name can include `\` and we still want each
      // element to be treated as its own *individual* title
      {
        beginKeywords: "namespace",
        relevance: 0,
        end: ";",
        illegal: /[.']/,
        contains: [e.inherit(e.UNDERSCORE_TITLE_MODE, { scope: "title.class" })]
      },
      {
        beginKeywords: "use",
        relevance: 0,
        end: ";",
        contains: [
          // TODO: title.function vs title.class
          {
            match: /\b(as|const|function)\b/,
            scope: "keyword"
          },
          // TODO: could be title.class or title.function
          e.UNDERSCORE_TITLE_MODE
        ]
      },
      f,
      b
    ]
  };
}
function Ap(e) {
  return {
    name: "PHP template",
    subLanguage: "xml",
    contains: [
      {
        begin: /<\?(php|=)?/,
        end: /\?>/,
        subLanguage: "php",
        contains: [
          // We don't want the php closing tag ?> to close the PHP block when
          // inside any of the following blocks:
          {
            begin: "/\\*",
            end: "\\*/",
            skip: !0
          },
          {
            begin: 'b"',
            end: '"',
            skip: !0
          },
          {
            begin: "b'",
            end: "'",
            skip: !0
          },
          e.inherit(e.APOS_STRING_MODE, {
            illegal: null,
            className: null,
            contains: null,
            skip: !0
          }),
          e.inherit(e.QUOTE_STRING_MODE, {
            illegal: null,
            className: null,
            contains: null,
            skip: !0
          })
        ]
      }
    ]
  };
}
function Mp(e) {
  return {
    name: "Plain text",
    aliases: [
      "text",
      "txt"
    ],
    disableAutodetect: !0
  };
}
function Ip(e) {
  const t = e.regex, n = new RegExp("[\\p{XID_Start}_]\\p{XID_Continue}*", "u"), a = [
    "and",
    "as",
    "assert",
    "async",
    "await",
    "break",
    "case",
    "class",
    "continue",
    "def",
    "del",
    "elif",
    "else",
    "except",
    "finally",
    "for",
    "from",
    "global",
    "if",
    "import",
    "in",
    "is",
    "lambda",
    "match",
    "nonlocal|10",
    "not",
    "or",
    "pass",
    "raise",
    "return",
    "try",
    "while",
    "with",
    "yield"
  ], i = {
    $pattern: /[A-Za-z]\w+|__\w+__/,
    keyword: a,
    built_in: [
      "__import__",
      "abs",
      "all",
      "any",
      "ascii",
      "bin",
      "bool",
      "breakpoint",
      "bytearray",
      "bytes",
      "callable",
      "chr",
      "classmethod",
      "compile",
      "complex",
      "delattr",
      "dict",
      "dir",
      "divmod",
      "enumerate",
      "eval",
      "exec",
      "filter",
      "float",
      "format",
      "frozenset",
      "getattr",
      "globals",
      "hasattr",
      "hash",
      "help",
      "hex",
      "id",
      "input",
      "int",
      "isinstance",
      "issubclass",
      "iter",
      "len",
      "list",
      "locals",
      "map",
      "max",
      "memoryview",
      "min",
      "next",
      "object",
      "oct",
      "open",
      "ord",
      "pow",
      "print",
      "property",
      "range",
      "repr",
      "reversed",
      "round",
      "set",
      "setattr",
      "slice",
      "sorted",
      "staticmethod",
      "str",
      "sum",
      "super",
      "tuple",
      "type",
      "vars",
      "zip"
    ],
    literal: [
      "__debug__",
      "Ellipsis",
      "False",
      "None",
      "NotImplemented",
      "True"
    ],
    type: [
      "Any",
      "Callable",
      "Coroutine",
      "Dict",
      "List",
      "Literal",
      "Generic",
      "Optional",
      "Sequence",
      "Set",
      "Tuple",
      "Type",
      "Union"
    ]
  }, c = {
    className: "meta",
    begin: /^(>>>|\.\.\.) /
  }, l = {
    className: "subst",
    begin: /\{/,
    end: /\}/,
    keywords: i,
    illegal: /#/
  }, d = {
    begin: /\{\{/,
    relevance: 0
  }, u = {
    className: "string",
    contains: [e.BACKSLASH_ESCAPE],
    variants: [
      {
        begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,
        end: /'''/,
        contains: [
          e.BACKSLASH_ESCAPE,
          c
        ],
        relevance: 10
      },
      {
        begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,
        end: /"""/,
        contains: [
          e.BACKSLASH_ESCAPE,
          c
        ],
        relevance: 10
      },
      {
        begin: /([fF][rR]|[rR][fF]|[fF])'''/,
        end: /'''/,
        contains: [
          e.BACKSLASH_ESCAPE,
          c,
          d,
          l
        ]
      },
      {
        begin: /([fF][rR]|[rR][fF]|[fF])"""/,
        end: /"""/,
        contains: [
          e.BACKSLASH_ESCAPE,
          c,
          d,
          l
        ]
      },
      {
        begin: /([uU]|[rR])'/,
        end: /'/,
        relevance: 10
      },
      {
        begin: /([uU]|[rR])"/,
        end: /"/,
        relevance: 10
      },
      {
        begin: /([bB]|[bB][rR]|[rR][bB])'/,
        end: /'/
      },
      {
        begin: /([bB]|[bB][rR]|[rR][bB])"/,
        end: /"/
      },
      {
        begin: /([fF][rR]|[rR][fF]|[fF])'/,
        end: /'/,
        contains: [
          e.BACKSLASH_ESCAPE,
          d,
          l
        ]
      },
      {
        begin: /([fF][rR]|[rR][fF]|[fF])"/,
        end: /"/,
        contains: [
          e.BACKSLASH_ESCAPE,
          d,
          l
        ]
      },
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE
    ]
  }, m = "[0-9](_?[0-9])*", g = `(\\b(${m}))?\\.(${m})|\\b(${m})\\.`, f = `\\b|${a.join("|")}`, b = {
    className: "number",
    relevance: 0,
    variants: [
      // exponentfloat, pointfloat
      // https://docs.python.org/3.9/reference/lexical_analysis.html#floating-point-literals
      // optionally imaginary
      // https://docs.python.org/3.9/reference/lexical_analysis.html#imaginary-literals
      // Note: no leading \b because floats can start with a decimal point
      // and we don't want to mishandle e.g. `fn(.5)`,
      // no trailing \b for pointfloat because it can end with a decimal point
      // and we don't want to mishandle e.g. `0..hex()`; this should be safe
      // because both MUST contain a decimal point and so cannot be confused with
      // the interior part of an identifier
      {
        begin: `(\\b(${m})|(${g}))[eE][+-]?(${m})[jJ]?(?=${f})`
      },
      {
        begin: `(${g})[jJ]?`
      },
      // decinteger, bininteger, octinteger, hexinteger
      // https://docs.python.org/3.9/reference/lexical_analysis.html#integer-literals
      // optionally "long" in Python 2
      // https://docs.python.org/2.7/reference/lexical_analysis.html#integer-and-long-integer-literals
      // decinteger is optionally imaginary
      // https://docs.python.org/3.9/reference/lexical_analysis.html#imaginary-literals
      {
        begin: `\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=${f})`
      },
      {
        begin: `\\b0[bB](_?[01])+[lL]?(?=${f})`
      },
      {
        begin: `\\b0[oO](_?[0-7])+[lL]?(?=${f})`
      },
      {
        begin: `\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=${f})`
      },
      // imagnumber (digitpart-based)
      // https://docs.python.org/3.9/reference/lexical_analysis.html#imaginary-literals
      {
        begin: `\\b(${m})[jJ](?=${f})`
      }
    ]
  }, E = {
    className: "comment",
    begin: t.lookahead(/# type:/),
    end: /$/,
    keywords: i,
    contains: [
      {
        // prevent keywords from coloring `type`
        begin: /# type:/
      },
      // comment within a datatype comment includes no keywords
      {
        begin: /#/,
        end: /\b\B/,
        endsWithParent: !0
      }
    ]
  }, _ = {
    className: "params",
    variants: [
      // Exclude params in functions without params
      {
        className: "",
        begin: /\(\s*\)/,
        skip: !0
      },
      {
        begin: /\(/,
        end: /\)/,
        excludeBegin: !0,
        excludeEnd: !0,
        keywords: i,
        contains: [
          "self",
          c,
          b,
          u,
          e.HASH_COMMENT_MODE
        ]
      }
    ]
  };
  return l.contains = [
    u,
    b,
    c
  ], {
    name: "Python",
    aliases: [
      "py",
      "gyp",
      "ipython"
    ],
    unicodeRegex: !0,
    keywords: i,
    illegal: /(<\/|\?)|=>/,
    contains: [
      c,
      b,
      {
        // very common convention
        scope: "variable.language",
        match: /\bself\b/
      },
      {
        // eat "if" prior to string so that it won't accidentally be
        // labeled as an f-string
        beginKeywords: "if",
        relevance: 0
      },
      { match: /\bor\b/, scope: "keyword" },
      u,
      E,
      e.HASH_COMMENT_MODE,
      {
        match: [
          /\bdef/,
          /\s+/,
          n
        ],
        scope: {
          1: "keyword",
          3: "title.function"
        },
        contains: [_]
      },
      {
        variants: [
          {
            match: [
              /\bclass/,
              /\s+/,
              n,
              /\s*/,
              /\(\s*/,
              n,
              /\s*\)/
            ]
          },
          {
            match: [
              /\bclass/,
              /\s+/,
              n
            ]
          }
        ],
        scope: {
          1: "keyword",
          3: "title.class",
          6: "title.class.inherited"
        }
      },
      {
        className: "meta",
        begin: /^[\t ]*@/,
        end: /(?=#)|$/,
        contains: [
          b,
          _,
          u
        ]
      }
    ]
  };
}
function Op(e) {
  return {
    aliases: ["pycon"],
    contains: [
      {
        className: "meta.prompt",
        starts: {
          // a space separates the REPL prefix from the actual code
          // this is purely for cleaner HTML output
          end: / |$/,
          starts: {
            end: "$",
            subLanguage: "python"
          }
        },
        variants: [
          { begin: /^>>>(?=[ ]|$)/ },
          { begin: /^\.\.\.(?=[ ]|$)/ }
        ]
      }
    ]
  };
}
function Lp(e) {
  const t = e.regex, n = /(?:(?:[a-zA-Z]|\.[._a-zA-Z])[._a-zA-Z0-9]*)|\.(?!\d)/, a = t.either(
    // Special case: only hexadecimal binary powers can contain fractions
    /0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/,
    // Hexadecimal numbers without fraction and optional binary power
    /0[xX][0-9a-fA-F]+(?:[pP][+-]?\d+)?[Li]?/,
    // Decimal numbers
    /(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?[Li]?/
  ), r = /[=!<>:]=|\|\||&&|:::?|<-|<<-|->>|->|\|>|[-+*\/?!$&|:<=>@^~]|\*\*/, o = t.either(
    /[()]/,
    /[{}]/,
    /\[\[/,
    /[[\]]/,
    /\\/,
    /,/
  );
  return {
    name: "R",
    keywords: {
      $pattern: n,
      keyword: "function if in break next repeat else for while",
      literal: "NULL NA TRUE FALSE Inf NaN NA_integer_|10 NA_real_|10 NA_character_|10 NA_complex_|10",
      built_in: (
        // Builtin constants
        "LETTERS letters month.abb month.name pi T F abs acos acosh all any anyNA Arg as.call as.character as.complex as.double as.environment as.integer as.logical as.null.default as.numeric as.raw asin asinh atan atanh attr attributes baseenv browser c call ceiling class Conj cos cosh cospi cummax cummin cumprod cumsum digamma dim dimnames emptyenv exp expression floor forceAndCall gamma gc.time globalenv Im interactive invisible is.array is.atomic is.call is.character is.complex is.double is.environment is.expression is.finite is.function is.infinite is.integer is.language is.list is.logical is.matrix is.na is.name is.nan is.null is.numeric is.object is.pairlist is.raw is.recursive is.single is.symbol lazyLoadDBfetch length lgamma list log max min missing Mod names nargs nzchar oldClass on.exit pos.to.env proc.time prod quote range Re rep retracemem return round seq_along seq_len seq.int sign signif sin sinh sinpi sqrt standardGeneric substitute sum switch tan tanh tanpi tracemem trigamma trunc unclass untracemem UseMethod xtfrm"
      )
    },
    contains: [
      // Roxygen comments
      e.COMMENT(
        /#'/,
        /$/,
        { contains: [
          {
            // Handle `@examples` separately to cause all subsequent code
            // until the next `@`-tag on its own line to be kept as-is,
            // preventing highlighting. This code is example R code, so nested
            // doctags shouldn’t be treated as such. See
            // `test/markup/r/roxygen.txt` for an example.
            scope: "doctag",
            match: /@examples/,
            starts: {
              end: t.lookahead(t.either(
                // end if another doc comment
                /\n^#'\s*(?=@[a-zA-Z]+)/,
                // or a line with no comment
                /\n^(?!#')/
              )),
              endsParent: !0
            }
          },
          {
            // Handle `@param` to highlight the parameter name following
            // after.
            scope: "doctag",
            begin: "@param",
            end: /$/,
            contains: [
              {
                scope: "variable",
                variants: [
                  { match: n },
                  { match: /`(?:\\.|[^`\\])+`/ }
                ],
                endsParent: !0
              }
            ]
          },
          {
            scope: "doctag",
            match: /@[a-zA-Z]+/
          },
          {
            scope: "keyword",
            match: /\\[a-zA-Z]+/
          }
        ] }
      ),
      e.HASH_COMMENT_MODE,
      {
        scope: "string",
        contains: [e.BACKSLASH_ESCAPE],
        variants: [
          e.END_SAME_AS_BEGIN({
            begin: /[rR]"(-*)\(/,
            end: /\)(-*)"/
          }),
          e.END_SAME_AS_BEGIN({
            begin: /[rR]"(-*)\{/,
            end: /\}(-*)"/
          }),
          e.END_SAME_AS_BEGIN({
            begin: /[rR]"(-*)\[/,
            end: /\](-*)"/
          }),
          e.END_SAME_AS_BEGIN({
            begin: /[rR]'(-*)\(/,
            end: /\)(-*)'/
          }),
          e.END_SAME_AS_BEGIN({
            begin: /[rR]'(-*)\{/,
            end: /\}(-*)'/
          }),
          e.END_SAME_AS_BEGIN({
            begin: /[rR]'(-*)\[/,
            end: /\](-*)'/
          }),
          {
            begin: '"',
            end: '"',
            relevance: 0
          },
          {
            begin: "'",
            end: "'",
            relevance: 0
          }
        ]
      },
      // Matching numbers immediately following punctuation and operators is
      // tricky since we need to look at the character ahead of a number to
      // ensure the number is not part of an identifier, and we cannot use
      // negative look-behind assertions. So instead we explicitly handle all
      // possible combinations of (operator|punctuation), number.
      // TODO: replace with negative look-behind when available
      // { begin: /(?<![a-zA-Z0-9._])0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/ },
      // { begin: /(?<![a-zA-Z0-9._])0[xX][0-9a-fA-F]+([pP][+-]?\d+)?[Li]?/ },
      // { begin: /(?<![a-zA-Z0-9._])(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?[Li]?/ }
      {
        relevance: 0,
        variants: [
          {
            scope: {
              1: "operator",
              2: "number"
            },
            match: [
              r,
              a
            ]
          },
          {
            scope: {
              1: "operator",
              2: "number"
            },
            match: [
              /%[^%]*%/,
              a
            ]
          },
          {
            scope: {
              1: "punctuation",
              2: "number"
            },
            match: [
              o,
              a
            ]
          },
          {
            scope: { 2: "number" },
            match: [
              /[^a-zA-Z0-9._]|^/,
              // not part of an identifier, or start of document
              a
            ]
          }
        ]
      },
      // Operators/punctuation when they're not directly followed by numbers
      {
        // Relevance boost for the most common assignment form.
        scope: { 3: "operator" },
        match: [
          n,
          /\s+/,
          /<-/,
          /\s+/
        ]
      },
      {
        scope: "operator",
        relevance: 0,
        variants: [
          { match: r },
          { match: /%[^%]*%/ }
        ]
      },
      {
        scope: "punctuation",
        relevance: 0,
        match: o
      },
      {
        // Escaped identifier
        begin: "`",
        end: "`",
        contains: [{ begin: /\\./ }]
      }
    ]
  };
}
function Rp(e) {
  const t = e.regex, n = "([a-zA-Z_]\\w*[!?=]?|[-+~]@|<<|>>|=~|===?|<=>|[<>]=?|\\*\\*|[-/+%^&*~`|]|\\[\\]=?)", a = t.either(
    /\b([A-Z]+[a-z0-9]+)+/,
    // ends in caps
    /\b([A-Z]+[a-z0-9]+)+[A-Z]+/
  ), r = t.concat(a, /(::\w+)*/), s = {
    "variable.constant": [
      "__FILE__",
      "__LINE__",
      "__ENCODING__"
    ],
    "variable.language": [
      "self",
      "super"
    ],
    keyword: [
      "alias",
      "and",
      "begin",
      "BEGIN",
      "break",
      "case",
      "class",
      "defined",
      "do",
      "else",
      "elsif",
      "end",
      "END",
      "ensure",
      "for",
      "if",
      "in",
      "module",
      "next",
      "not",
      "or",
      "redo",
      "require",
      "rescue",
      "retry",
      "return",
      "then",
      "undef",
      "unless",
      "until",
      "when",
      "while",
      "yield",
      ...[
        "include",
        "extend",
        "prepend",
        "public",
        "private",
        "protected",
        "raise",
        "throw"
      ]
    ],
    built_in: [
      "proc",
      "lambda",
      "attr_accessor",
      "attr_reader",
      "attr_writer",
      "define_method",
      "private_constant",
      "module_function"
    ],
    literal: [
      "true",
      "false",
      "nil"
    ]
  }, i = {
    className: "doctag",
    begin: "@[A-Za-z]+"
  }, c = {
    begin: "#<",
    end: ">"
  }, l = [
    e.COMMENT(
      "#",
      "$",
      { contains: [i] }
    ),
    e.COMMENT(
      "^=begin",
      "^=end",
      {
        contains: [i],
        relevance: 10
      }
    ),
    e.COMMENT("^__END__", e.MATCH_NOTHING_RE)
  ], d = {
    className: "subst",
    begin: /#\{/,
    end: /\}/,
    keywords: s
  }, u = {
    className: "string",
    contains: [
      e.BACKSLASH_ESCAPE,
      d
    ],
    variants: [
      {
        begin: /'/,
        end: /'/
      },
      {
        begin: /"/,
        end: /"/
      },
      {
        begin: /`/,
        end: /`/
      },
      {
        begin: /%[qQwWx]?\(/,
        end: /\)/
      },
      {
        begin: /%[qQwWx]?\[/,
        end: /\]/
      },
      {
        begin: /%[qQwWx]?\{/,
        end: /\}/
      },
      {
        begin: /%[qQwWx]?</,
        end: />/
      },
      {
        begin: /%[qQwWx]?\//,
        end: /\//
      },
      {
        begin: /%[qQwWx]?%/,
        end: /%/
      },
      {
        begin: /%[qQwWx]?-/,
        end: /-/
      },
      {
        begin: /%[qQwWx]?\|/,
        end: /\|/
      },
      // in the following expressions, \B in the beginning suppresses recognition of ?-sequences
      // where ? is the last character of a preceding identifier, as in: `func?4`
      { begin: /\B\?(\\\d{1,3})/ },
      { begin: /\B\?(\\x[A-Fa-f0-9]{1,2})/ },
      { begin: /\B\?(\\u\{?[A-Fa-f0-9]{1,6}\}?)/ },
      { begin: /\B\?(\\M-\\C-|\\M-\\c|\\c\\M-|\\M-|\\C-\\M-)[\x20-\x7e]/ },
      { begin: /\B\?\\(c|C-)[\x20-\x7e]/ },
      { begin: /\B\?\\?\S/ },
      // heredocs
      {
        // this guard makes sure that we have an entire heredoc and not a false
        // positive (auto-detect, etc.)
        begin: t.concat(
          /<<[-~]?'?/,
          t.lookahead(/(\w+)(?=\W)[^\n]*\n(?:[^\n]*\n)*?\s*\1\b/)
        ),
        contains: [
          e.END_SAME_AS_BEGIN({
            begin: /(\w+)/,
            end: /(\w+)/,
            contains: [
              e.BACKSLASH_ESCAPE,
              d
            ]
          })
        ]
      }
    ]
  }, m = "[1-9](_?[0-9])*|0", g = "[0-9](_?[0-9])*", f = {
    className: "number",
    relevance: 0,
    variants: [
      // decimal integer/float, optionally exponential or rational, optionally imaginary
      { begin: `\\b(${m})(\\.(${g}))?([eE][+-]?(${g})|r)?i?\\b` },
      // explicit decimal/binary/octal/hexadecimal integer,
      // optionally rational and/or imaginary
      { begin: "\\b0[dD][0-9](_?[0-9])*r?i?\\b" },
      { begin: "\\b0[bB][0-1](_?[0-1])*r?i?\\b" },
      { begin: "\\b0[oO][0-7](_?[0-7])*r?i?\\b" },
      { begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*r?i?\\b" },
      // 0-prefixed implicit octal integer, optionally rational and/or imaginary
      { begin: "\\b0(_?[0-7])+r?i?\\b" }
    ]
  }, b = {
    variants: [
      {
        match: /\(\)/
      },
      {
        className: "params",
        begin: /\(/,
        end: /(?=\))/,
        excludeBegin: !0,
        endsParent: !0,
        keywords: s
      }
    ]
  }, C = [
    u,
    {
      variants: [
        {
          match: [
            /class\s+/,
            r,
            /\s+<\s+/,
            r
          ]
        },
        {
          match: [
            /\b(class|module)\s+/,
            r
          ]
        }
      ],
      scope: {
        2: "title.class",
        4: "title.class.inherited"
      },
      keywords: s
    },
    {
      match: [
        /(include|extend)\s+/,
        r
      ],
      scope: {
        2: "title.class"
      },
      keywords: s
    },
    {
      relevance: 0,
      match: [
        r,
        /\.new[. (]/
      ],
      scope: {
        1: "title.class"
      }
    },
    {
      relevance: 0,
      match: /\b[A-Z][A-Z_0-9]+\b/,
      className: "variable.constant"
    },
    {
      relevance: 0,
      match: a,
      scope: "title.class"
    },
    {
      match: [
        /def/,
        /\s+/,
        n
      ],
      scope: {
        1: "keyword",
        3: "title.function"
      },
      contains: [
        b
      ]
    },
    {
      // swallow namespace qualifiers before symbols
      begin: e.IDENT_RE + "::"
    },
    {
      className: "symbol",
      begin: e.UNDERSCORE_IDENT_RE + "(!|\\?)?:",
      relevance: 0
    },
    {
      className: "symbol",
      begin: ":(?!\\s)",
      contains: [
        u,
        { begin: n }
      ],
      relevance: 0
    },
    f,
    {
      // negative-look forward attempts to prevent false matches like:
      // @ident@ or $ident$ that might indicate this is not ruby at all
      className: "variable",
      begin: "(\\$\\W)|((\\$|@@?)(\\w+))(?=[^@$?])(?![A-Za-z])(?![@$?'])"
    },
    {
      className: "params",
      begin: /\|(?!=)/,
      end: /\|/,
      excludeBegin: !0,
      excludeEnd: !0,
      relevance: 0,
      // this could be a lot of things (in other languages) other than params
      keywords: s
    },
    {
      // regexp container
      begin: "(" + e.RE_STARTERS_RE + "|unless)\\s*",
      keywords: "unless",
      contains: [
        {
          className: "regexp",
          contains: [
            e.BACKSLASH_ESCAPE,
            d
          ],
          illegal: /\n/,
          variants: [
            {
              begin: "/",
              end: "/[a-z]*"
            },
            {
              begin: /%r\{/,
              end: /\}[a-z]*/
            },
            {
              begin: "%r\\(",
              end: "\\)[a-z]*"
            },
            {
              begin: "%r!",
              end: "![a-z]*"
            },
            {
              begin: "%r\\[",
              end: "\\][a-z]*"
            }
          ]
        }
      ].concat(c, l),
      relevance: 0
    }
  ].concat(c, l);
  d.contains = C, b.contains = C;
  const K = [
    {
      begin: /^\s*=>/,
      starts: {
        end: "$",
        contains: C
      }
    },
    {
      className: "meta.prompt",
      begin: "^(" + "[>?]>" + "|" + "[\\w#]+\\(\\w+\\):\\d+:\\d+[>*]" + "|" + "(\\w+-)?\\d+\\.\\d+\\.\\d+(p\\d+)?[^\\d][^>]+>" + ")(?=[ ])",
      starts: {
        end: "$",
        keywords: s,
        contains: C
      }
    }
  ];
  return l.unshift(c), {
    name: "Ruby",
    aliases: [
      "rb",
      "gemspec",
      "podspec",
      "thor",
      "irb"
    ],
    keywords: s,
    illegal: /\/\*/,
    contains: [e.SHEBANG({ binary: "ruby" })].concat(K).concat(l).concat(C)
  };
}
function Dp(e) {
  const t = e.regex, n = /(r#)?/, a = t.concat(n, e.UNDERSCORE_IDENT_RE), r = t.concat(n, e.IDENT_RE), o = {
    className: "title.function.invoke",
    relevance: 0,
    begin: t.concat(
      /\b/,
      /(?!let|for|while|if|else|match\b)/,
      r,
      t.lookahead(/\s*\(/)
    )
  }, s = "([ui](8|16|32|64|128|size)|f(32|64))?", i = [
    "abstract",
    "as",
    "async",
    "await",
    "become",
    "box",
    "break",
    "const",
    "continue",
    "crate",
    "do",
    "dyn",
    "else",
    "enum",
    "extern",
    "false",
    "final",
    "fn",
    "for",
    "if",
    "impl",
    "in",
    "let",
    "loop",
    "macro",
    "match",
    "mod",
    "move",
    "mut",
    "override",
    "priv",
    "pub",
    "ref",
    "return",
    "self",
    "Self",
    "static",
    "struct",
    "super",
    "trait",
    "true",
    "try",
    "type",
    "typeof",
    "union",
    "unsafe",
    "unsized",
    "use",
    "virtual",
    "where",
    "while",
    "yield"
  ], c = [
    "true",
    "false",
    "Some",
    "None",
    "Ok",
    "Err"
  ], l = [
    // functions
    "drop ",
    // traits
    "Copy",
    "Send",
    "Sized",
    "Sync",
    "Drop",
    "Fn",
    "FnMut",
    "FnOnce",
    "ToOwned",
    "Clone",
    "Debug",
    "PartialEq",
    "PartialOrd",
    "Eq",
    "Ord",
    "AsRef",
    "AsMut",
    "Into",
    "From",
    "Default",
    "Iterator",
    "Extend",
    "IntoIterator",
    "DoubleEndedIterator",
    "ExactSizeIterator",
    "SliceConcatExt",
    "ToString",
    // macros
    "assert!",
    "assert_eq!",
    "bitflags!",
    "bytes!",
    "cfg!",
    "col!",
    "concat!",
    "concat_idents!",
    "debug_assert!",
    "debug_assert_eq!",
    "env!",
    "eprintln!",
    "panic!",
    "file!",
    "format!",
    "format_args!",
    "include_bytes!",
    "include_str!",
    "line!",
    "local_data_key!",
    "module_path!",
    "option_env!",
    "print!",
    "println!",
    "select!",
    "stringify!",
    "try!",
    "unimplemented!",
    "unreachable!",
    "vec!",
    "write!",
    "writeln!",
    "macro_rules!",
    "assert_ne!",
    "debug_assert_ne!"
  ], d = [
    "i8",
    "i16",
    "i32",
    "i64",
    "i128",
    "isize",
    "u8",
    "u16",
    "u32",
    "u64",
    "u128",
    "usize",
    "f32",
    "f64",
    "str",
    "char",
    "bool",
    "Box",
    "Option",
    "Result",
    "String",
    "Vec"
  ];
  return {
    name: "Rust",
    aliases: ["rs"],
    keywords: {
      $pattern: e.IDENT_RE + "!?",
      type: d,
      keyword: i,
      literal: c,
      built_in: l
    },
    illegal: "</",
    contains: [
      e.C_LINE_COMMENT_MODE,
      e.COMMENT("/\\*", "\\*/", { contains: ["self"] }),
      e.inherit(e.QUOTE_STRING_MODE, {
        begin: /b?"/,
        illegal: null
      }),
      {
        className: "symbol",
        // negative lookahead to avoid matching `'`
        begin: /'[a-zA-Z_][a-zA-Z0-9_]*(?!')/
      },
      {
        scope: "string",
        variants: [
          { begin: /b?r(#*)"(.|\n)*?"\1(?!#)/ },
          {
            begin: /b?'/,
            end: /'/,
            contains: [
              {
                scope: "char.escape",
                match: /\\('|\w|x\w{2}|u\w{4}|U\w{8})/
              }
            ]
          }
        ]
      },
      {
        className: "number",
        variants: [
          { begin: "\\b0b([01_]+)" + s },
          { begin: "\\b0o([0-7_]+)" + s },
          { begin: "\\b0x([A-Fa-f0-9_]+)" + s },
          { begin: "\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)" + s }
        ],
        relevance: 0
      },
      {
        begin: [
          /fn/,
          /\s+/,
          a
        ],
        className: {
          1: "keyword",
          3: "title.function"
        }
      },
      {
        className: "meta",
        begin: "#!?\\[",
        end: "\\]",
        contains: [
          {
            className: "string",
            begin: /"/,
            end: /"/,
            contains: [
              e.BACKSLASH_ESCAPE
            ]
          }
        ]
      },
      {
        begin: [
          /let/,
          /\s+/,
          /(?:mut\s+)?/,
          a
        ],
        className: {
          1: "keyword",
          3: "keyword",
          4: "variable"
        }
      },
      // must come before impl/for rule later
      {
        begin: [
          /for/,
          /\s+/,
          a,
          /\s+/,
          /in/
        ],
        className: {
          1: "keyword",
          3: "variable",
          5: "keyword"
        }
      },
      {
        begin: [
          /type/,
          /\s+/,
          a
        ],
        className: {
          1: "keyword",
          3: "title.class"
        }
      },
      {
        begin: [
          /(?:trait|enum|struct|union|impl|for)/,
          /\s+/,
          a
        ],
        className: {
          1: "keyword",
          3: "title.class"
        }
      },
      {
        begin: e.IDENT_RE + "::",
        keywords: {
          keyword: "Self",
          built_in: l,
          type: d
        }
      },
      {
        className: "punctuation",
        begin: "->"
      },
      o
    ]
  };
}
const Bp = (e) => ({
  IMPORTANT: {
    scope: "meta",
    begin: "!important"
  },
  BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
  HEXCOLOR: {
    scope: "number",
    begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
  },
  FUNCTION_DISPATCH: {
    className: "built_in",
    begin: /[\w-]+(?=\()/
  },
  ATTRIBUTE_SELECTOR_MODE: {
    scope: "selector-attr",
    begin: /\[/,
    end: /\]/,
    illegal: "$",
    contains: [
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE
    ]
  },
  CSS_NUMBER_MODE: {
    scope: "number",
    begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
    relevance: 0
  },
  CSS_VARIABLE: {
    className: "attr",
    begin: /--[A-Za-z_][A-Za-z0-9_-]*/
  }
}), Pp = [
  "a",
  "abbr",
  "address",
  "article",
  "aside",
  "audio",
  "b",
  "blockquote",
  "body",
  "button",
  "canvas",
  "caption",
  "cite",
  "code",
  "dd",
  "del",
  "details",
  "dfn",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "header",
  "hgroup",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "main",
  "mark",
  "menu",
  "nav",
  "object",
  "ol",
  "optgroup",
  "option",
  "p",
  "picture",
  "q",
  "quote",
  "samp",
  "section",
  "select",
  "source",
  "span",
  "strong",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "ul",
  "var",
  "video"
], Fp = [
  "defs",
  "g",
  "marker",
  "mask",
  "pattern",
  "svg",
  "switch",
  "symbol",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feFlood",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTile",
  "feTurbulence",
  "linearGradient",
  "radialGradient",
  "stop",
  "circle",
  "ellipse",
  "image",
  "line",
  "path",
  "polygon",
  "polyline",
  "rect",
  "text",
  "use",
  "textPath",
  "tspan",
  "foreignObject",
  "clipPath"
], zp = [
  ...Pp,
  ...Fp
], Hp = [
  "any-hover",
  "any-pointer",
  "aspect-ratio",
  "color",
  "color-gamut",
  "color-index",
  "device-aspect-ratio",
  "device-height",
  "device-width",
  "display-mode",
  "forced-colors",
  "grid",
  "height",
  "hover",
  "inverted-colors",
  "monochrome",
  "orientation",
  "overflow-block",
  "overflow-inline",
  "pointer",
  "prefers-color-scheme",
  "prefers-contrast",
  "prefers-reduced-motion",
  "prefers-reduced-transparency",
  "resolution",
  "scan",
  "scripting",
  "update",
  "width",
  // TODO: find a better solution?
  "min-width",
  "max-width",
  "min-height",
  "max-height"
].sort().reverse(), $p = [
  "active",
  "any-link",
  "blank",
  "checked",
  "current",
  "default",
  "defined",
  "dir",
  // dir()
  "disabled",
  "drop",
  "empty",
  "enabled",
  "first",
  "first-child",
  "first-of-type",
  "fullscreen",
  "future",
  "focus",
  "focus-visible",
  "focus-within",
  "has",
  // has()
  "host",
  // host or host()
  "host-context",
  // host-context()
  "hover",
  "indeterminate",
  "in-range",
  "invalid",
  "is",
  // is()
  "lang",
  // lang()
  "last-child",
  "last-of-type",
  "left",
  "link",
  "local-link",
  "not",
  // not()
  "nth-child",
  // nth-child()
  "nth-col",
  // nth-col()
  "nth-last-child",
  // nth-last-child()
  "nth-last-col",
  // nth-last-col()
  "nth-last-of-type",
  //nth-last-of-type()
  "nth-of-type",
  //nth-of-type()
  "only-child",
  "only-of-type",
  "optional",
  "out-of-range",
  "past",
  "placeholder-shown",
  "read-only",
  "read-write",
  "required",
  "right",
  "root",
  "scope",
  "target",
  "target-within",
  "user-invalid",
  "valid",
  "visited",
  "where"
  // where()
].sort().reverse(), Up = [
  "after",
  "backdrop",
  "before",
  "cue",
  "cue-region",
  "first-letter",
  "first-line",
  "grammar-error",
  "marker",
  "part",
  "placeholder",
  "selection",
  "slotted",
  "spelling-error"
].sort().reverse(), Gp = [
  "accent-color",
  "align-content",
  "align-items",
  "align-self",
  "alignment-baseline",
  "all",
  "anchor-name",
  "animation",
  "animation-composition",
  "animation-delay",
  "animation-direction",
  "animation-duration",
  "animation-fill-mode",
  "animation-iteration-count",
  "animation-name",
  "animation-play-state",
  "animation-range",
  "animation-range-end",
  "animation-range-start",
  "animation-timeline",
  "animation-timing-function",
  "appearance",
  "aspect-ratio",
  "backdrop-filter",
  "backface-visibility",
  "background",
  "background-attachment",
  "background-blend-mode",
  "background-clip",
  "background-color",
  "background-image",
  "background-origin",
  "background-position",
  "background-position-x",
  "background-position-y",
  "background-repeat",
  "background-size",
  "baseline-shift",
  "block-size",
  "border",
  "border-block",
  "border-block-color",
  "border-block-end",
  "border-block-end-color",
  "border-block-end-style",
  "border-block-end-width",
  "border-block-start",
  "border-block-start-color",
  "border-block-start-style",
  "border-block-start-width",
  "border-block-style",
  "border-block-width",
  "border-bottom",
  "border-bottom-color",
  "border-bottom-left-radius",
  "border-bottom-right-radius",
  "border-bottom-style",
  "border-bottom-width",
  "border-collapse",
  "border-color",
  "border-end-end-radius",
  "border-end-start-radius",
  "border-image",
  "border-image-outset",
  "border-image-repeat",
  "border-image-slice",
  "border-image-source",
  "border-image-width",
  "border-inline",
  "border-inline-color",
  "border-inline-end",
  "border-inline-end-color",
  "border-inline-end-style",
  "border-inline-end-width",
  "border-inline-start",
  "border-inline-start-color",
  "border-inline-start-style",
  "border-inline-start-width",
  "border-inline-style",
  "border-inline-width",
  "border-left",
  "border-left-color",
  "border-left-style",
  "border-left-width",
  "border-radius",
  "border-right",
  "border-right-color",
  "border-right-style",
  "border-right-width",
  "border-spacing",
  "border-start-end-radius",
  "border-start-start-radius",
  "border-style",
  "border-top",
  "border-top-color",
  "border-top-left-radius",
  "border-top-right-radius",
  "border-top-style",
  "border-top-width",
  "border-width",
  "bottom",
  "box-align",
  "box-decoration-break",
  "box-direction",
  "box-flex",
  "box-flex-group",
  "box-lines",
  "box-ordinal-group",
  "box-orient",
  "box-pack",
  "box-shadow",
  "box-sizing",
  "break-after",
  "break-before",
  "break-inside",
  "caption-side",
  "caret-color",
  "clear",
  "clip",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "color-scheme",
  "column-count",
  "column-fill",
  "column-gap",
  "column-rule",
  "column-rule-color",
  "column-rule-style",
  "column-rule-width",
  "column-span",
  "column-width",
  "columns",
  "contain",
  "contain-intrinsic-block-size",
  "contain-intrinsic-height",
  "contain-intrinsic-inline-size",
  "contain-intrinsic-size",
  "contain-intrinsic-width",
  "container",
  "container-name",
  "container-type",
  "content",
  "content-visibility",
  "counter-increment",
  "counter-reset",
  "counter-set",
  "cue",
  "cue-after",
  "cue-before",
  "cursor",
  "cx",
  "cy",
  "direction",
  "display",
  "dominant-baseline",
  "empty-cells",
  "enable-background",
  "field-sizing",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "flex",
  "flex-basis",
  "flex-direction",
  "flex-flow",
  "flex-grow",
  "flex-shrink",
  "flex-wrap",
  "float",
  "flood-color",
  "flood-opacity",
  "flow",
  "font",
  "font-display",
  "font-family",
  "font-feature-settings",
  "font-kerning",
  "font-language-override",
  "font-optical-sizing",
  "font-palette",
  "font-size",
  "font-size-adjust",
  "font-smooth",
  "font-smoothing",
  "font-stretch",
  "font-style",
  "font-synthesis",
  "font-synthesis-position",
  "font-synthesis-small-caps",
  "font-synthesis-style",
  "font-synthesis-weight",
  "font-variant",
  "font-variant-alternates",
  "font-variant-caps",
  "font-variant-east-asian",
  "font-variant-emoji",
  "font-variant-ligatures",
  "font-variant-numeric",
  "font-variant-position",
  "font-variation-settings",
  "font-weight",
  "forced-color-adjust",
  "gap",
  "glyph-orientation-horizontal",
  "glyph-orientation-vertical",
  "grid",
  "grid-area",
  "grid-auto-columns",
  "grid-auto-flow",
  "grid-auto-rows",
  "grid-column",
  "grid-column-end",
  "grid-column-start",
  "grid-gap",
  "grid-row",
  "grid-row-end",
  "grid-row-start",
  "grid-template",
  "grid-template-areas",
  "grid-template-columns",
  "grid-template-rows",
  "hanging-punctuation",
  "height",
  "hyphenate-character",
  "hyphenate-limit-chars",
  "hyphens",
  "icon",
  "image-orientation",
  "image-rendering",
  "image-resolution",
  "ime-mode",
  "initial-letter",
  "initial-letter-align",
  "inline-size",
  "inset",
  "inset-area",
  "inset-block",
  "inset-block-end",
  "inset-block-start",
  "inset-inline",
  "inset-inline-end",
  "inset-inline-start",
  "isolation",
  "justify-content",
  "justify-items",
  "justify-self",
  "kerning",
  "left",
  "letter-spacing",
  "lighting-color",
  "line-break",
  "line-height",
  "line-height-step",
  "list-style",
  "list-style-image",
  "list-style-position",
  "list-style-type",
  "margin",
  "margin-block",
  "margin-block-end",
  "margin-block-start",
  "margin-bottom",
  "margin-inline",
  "margin-inline-end",
  "margin-inline-start",
  "margin-left",
  "margin-right",
  "margin-top",
  "margin-trim",
  "marker",
  "marker-end",
  "marker-mid",
  "marker-start",
  "marks",
  "mask",
  "mask-border",
  "mask-border-mode",
  "mask-border-outset",
  "mask-border-repeat",
  "mask-border-slice",
  "mask-border-source",
  "mask-border-width",
  "mask-clip",
  "mask-composite",
  "mask-image",
  "mask-mode",
  "mask-origin",
  "mask-position",
  "mask-repeat",
  "mask-size",
  "mask-type",
  "masonry-auto-flow",
  "math-depth",
  "math-shift",
  "math-style",
  "max-block-size",
  "max-height",
  "max-inline-size",
  "max-width",
  "min-block-size",
  "min-height",
  "min-inline-size",
  "min-width",
  "mix-blend-mode",
  "nav-down",
  "nav-index",
  "nav-left",
  "nav-right",
  "nav-up",
  "none",
  "normal",
  "object-fit",
  "object-position",
  "offset",
  "offset-anchor",
  "offset-distance",
  "offset-path",
  "offset-position",
  "offset-rotate",
  "opacity",
  "order",
  "orphans",
  "outline",
  "outline-color",
  "outline-offset",
  "outline-style",
  "outline-width",
  "overflow",
  "overflow-anchor",
  "overflow-block",
  "overflow-clip-margin",
  "overflow-inline",
  "overflow-wrap",
  "overflow-x",
  "overflow-y",
  "overlay",
  "overscroll-behavior",
  "overscroll-behavior-block",
  "overscroll-behavior-inline",
  "overscroll-behavior-x",
  "overscroll-behavior-y",
  "padding",
  "padding-block",
  "padding-block-end",
  "padding-block-start",
  "padding-bottom",
  "padding-inline",
  "padding-inline-end",
  "padding-inline-start",
  "padding-left",
  "padding-right",
  "padding-top",
  "page",
  "page-break-after",
  "page-break-before",
  "page-break-inside",
  "paint-order",
  "pause",
  "pause-after",
  "pause-before",
  "perspective",
  "perspective-origin",
  "place-content",
  "place-items",
  "place-self",
  "pointer-events",
  "position",
  "position-anchor",
  "position-visibility",
  "print-color-adjust",
  "quotes",
  "r",
  "resize",
  "rest",
  "rest-after",
  "rest-before",
  "right",
  "rotate",
  "row-gap",
  "ruby-align",
  "ruby-position",
  "scale",
  "scroll-behavior",
  "scroll-margin",
  "scroll-margin-block",
  "scroll-margin-block-end",
  "scroll-margin-block-start",
  "scroll-margin-bottom",
  "scroll-margin-inline",
  "scroll-margin-inline-end",
  "scroll-margin-inline-start",
  "scroll-margin-left",
  "scroll-margin-right",
  "scroll-margin-top",
  "scroll-padding",
  "scroll-padding-block",
  "scroll-padding-block-end",
  "scroll-padding-block-start",
  "scroll-padding-bottom",
  "scroll-padding-inline",
  "scroll-padding-inline-end",
  "scroll-padding-inline-start",
  "scroll-padding-left",
  "scroll-padding-right",
  "scroll-padding-top",
  "scroll-snap-align",
  "scroll-snap-stop",
  "scroll-snap-type",
  "scroll-timeline",
  "scroll-timeline-axis",
  "scroll-timeline-name",
  "scrollbar-color",
  "scrollbar-gutter",
  "scrollbar-width",
  "shape-image-threshold",
  "shape-margin",
  "shape-outside",
  "shape-rendering",
  "speak",
  "speak-as",
  "src",
  // @font-face
  "stop-color",
  "stop-opacity",
  "stroke",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke-width",
  "tab-size",
  "table-layout",
  "text-align",
  "text-align-all",
  "text-align-last",
  "text-anchor",
  "text-combine-upright",
  "text-decoration",
  "text-decoration-color",
  "text-decoration-line",
  "text-decoration-skip",
  "text-decoration-skip-ink",
  "text-decoration-style",
  "text-decoration-thickness",
  "text-emphasis",
  "text-emphasis-color",
  "text-emphasis-position",
  "text-emphasis-style",
  "text-indent",
  "text-justify",
  "text-orientation",
  "text-overflow",
  "text-rendering",
  "text-shadow",
  "text-size-adjust",
  "text-transform",
  "text-underline-offset",
  "text-underline-position",
  "text-wrap",
  "text-wrap-mode",
  "text-wrap-style",
  "timeline-scope",
  "top",
  "touch-action",
  "transform",
  "transform-box",
  "transform-origin",
  "transform-style",
  "transition",
  "transition-behavior",
  "transition-delay",
  "transition-duration",
  "transition-property",
  "transition-timing-function",
  "translate",
  "unicode-bidi",
  "user-modify",
  "user-select",
  "vector-effect",
  "vertical-align",
  "view-timeline",
  "view-timeline-axis",
  "view-timeline-inset",
  "view-timeline-name",
  "view-transition-name",
  "visibility",
  "voice-balance",
  "voice-duration",
  "voice-family",
  "voice-pitch",
  "voice-range",
  "voice-rate",
  "voice-stress",
  "voice-volume",
  "white-space",
  "white-space-collapse",
  "widows",
  "width",
  "will-change",
  "word-break",
  "word-spacing",
  "word-wrap",
  "writing-mode",
  "x",
  "y",
  "z-index",
  "zoom"
].sort().reverse();
function Kp(e) {
  const t = Bp(e), n = Up, a = $p, r = "@[a-z-]+", o = "and or not only", i = {
    className: "variable",
    begin: "(\\$" + "[a-zA-Z-][a-zA-Z0-9_-]*" + ")\\b",
    relevance: 0
  };
  return {
    name: "SCSS",
    case_insensitive: !0,
    illegal: "[=/|']",
    contains: [
      e.C_LINE_COMMENT_MODE,
      e.C_BLOCK_COMMENT_MODE,
      // to recognize keyframe 40% etc which are outside the scope of our
      // attribute value mode
      t.CSS_NUMBER_MODE,
      {
        className: "selector-id",
        begin: "#[A-Za-z0-9_-]+",
        relevance: 0
      },
      {
        className: "selector-class",
        begin: "\\.[A-Za-z0-9_-]+",
        relevance: 0
      },
      t.ATTRIBUTE_SELECTOR_MODE,
      {
        className: "selector-tag",
        begin: "\\b(" + zp.join("|") + ")\\b",
        // was there, before, but why?
        relevance: 0
      },
      {
        className: "selector-pseudo",
        begin: ":(" + a.join("|") + ")"
      },
      {
        className: "selector-pseudo",
        begin: ":(:)?(" + n.join("|") + ")"
      },
      i,
      {
        // pseudo-selector params
        begin: /\(/,
        end: /\)/,
        contains: [t.CSS_NUMBER_MODE]
      },
      t.CSS_VARIABLE,
      {
        className: "attribute",
        begin: "\\b(" + Gp.join("|") + ")\\b"
      },
      { begin: "\\b(whitespace|wait|w-resize|visible|vertical-text|vertical-ideographic|uppercase|upper-roman|upper-alpha|underline|transparent|top|thin|thick|text|text-top|text-bottom|tb-rl|table-header-group|table-footer-group|sw-resize|super|strict|static|square|solid|small-caps|separate|se-resize|scroll|s-resize|rtl|row-resize|ridge|right|repeat|repeat-y|repeat-x|relative|progress|pointer|overline|outside|outset|oblique|nowrap|not-allowed|normal|none|nw-resize|no-repeat|no-drop|newspaper|ne-resize|n-resize|move|middle|medium|ltr|lr-tb|lowercase|lower-roman|lower-alpha|loose|list-item|line|line-through|line-edge|lighter|left|keep-all|justify|italic|inter-word|inter-ideograph|inside|inset|inline|inline-block|inherit|inactive|ideograph-space|ideograph-parenthesis|ideograph-numeric|ideograph-alpha|horizontal|hidden|help|hand|groove|fixed|ellipsis|e-resize|double|dotted|distribute|distribute-space|distribute-letter|distribute-all-lines|disc|disabled|default|decimal|dashed|crosshair|collapse|col-resize|circle|char|center|capitalize|break-word|break-all|bottom|both|bolder|bold|block|bidi-override|below|baseline|auto|always|all-scroll|absolute|table|table-cell)\\b" },
      {
        begin: /:/,
        end: /[;}{]/,
        relevance: 0,
        contains: [
          t.BLOCK_COMMENT,
          i,
          t.HEXCOLOR,
          t.CSS_NUMBER_MODE,
          e.QUOTE_STRING_MODE,
          e.APOS_STRING_MODE,
          t.IMPORTANT,
          t.FUNCTION_DISPATCH
        ]
      },
      // matching these here allows us to treat them more like regular CSS
      // rules so everything between the {} gets regular rule highlighting,
      // which is what we want for page and font-face
      {
        begin: "@(page|font-face)",
        keywords: {
          $pattern: r,
          keyword: "@page @font-face"
        }
      },
      {
        begin: "@",
        end: "[{;]",
        returnBegin: !0,
        keywords: {
          $pattern: /[a-z-]+/,
          keyword: o,
          attribute: Hp.join(" ")
        },
        contains: [
          {
            begin: r,
            className: "keyword"
          },
          {
            begin: /[a-z-]+(?=:)/,
            className: "attribute"
          },
          i,
          e.QUOTE_STRING_MODE,
          e.APOS_STRING_MODE,
          t.HEXCOLOR,
          t.CSS_NUMBER_MODE
        ]
      },
      t.FUNCTION_DISPATCH
    ]
  };
}
function Vp(e) {
  return {
    name: "Shell Session",
    aliases: [
      "console",
      "shellsession"
    ],
    contains: [
      {
        className: "meta.prompt",
        // We cannot add \s (spaces) in the regular expression otherwise it will be too broad and produce unexpected result.
        // For instance, in the following example, it would match "echo /path/to/home >" as a prompt:
        // echo /path/to/home > t.exe
        begin: /^\s{0,3}[/~\w\d[\]()@-]*[>%$#][ ]?/,
        starts: {
          end: /[^\\](?=\s*$)/,
          subLanguage: "bash"
        }
      }
    ]
  };
}
function Wp(e) {
  const t = e.regex, n = e.COMMENT("--", "$"), a = {
    scope: "string",
    variants: [
      {
        begin: /'/,
        end: /'/,
        contains: [{ match: /''/ }]
      }
    ]
  }, r = {
    begin: /"/,
    end: /"/,
    contains: [{ match: /""/ }]
  }, o = [
    "true",
    "false",
    // Not sure it's correct to call NULL literal, and clauses like IS [NOT] NULL look strange that way.
    // "null",
    "unknown"
  ], s = [
    "double precision",
    "large object",
    "with timezone",
    "without timezone"
  ], i = [
    "bigint",
    "binary",
    "blob",
    "boolean",
    "char",
    "character",
    "clob",
    "date",
    "dec",
    "decfloat",
    "decimal",
    "float",
    "int",
    "integer",
    "interval",
    "nchar",
    "nclob",
    "national",
    "numeric",
    "real",
    "row",
    "smallint",
    "time",
    "timestamp",
    "varchar",
    "varying",
    // modifier (character varying)
    "varbinary"
  ], c = [
    "add",
    "asc",
    "collation",
    "desc",
    "final",
    "first",
    "last",
    "view"
  ], l = [
    "abs",
    "acos",
    "all",
    "allocate",
    "alter",
    "and",
    "any",
    "are",
    "array",
    "array_agg",
    "array_max_cardinality",
    "as",
    "asensitive",
    "asin",
    "asymmetric",
    "at",
    "atan",
    "atomic",
    "authorization",
    "avg",
    "begin",
    "begin_frame",
    "begin_partition",
    "between",
    "bigint",
    "binary",
    "blob",
    "boolean",
    "both",
    "by",
    "call",
    "called",
    "cardinality",
    "cascaded",
    "case",
    "cast",
    "ceil",
    "ceiling",
    "char",
    "char_length",
    "character",
    "character_length",
    "check",
    "classifier",
    "clob",
    "close",
    "coalesce",
    "collate",
    "collect",
    "column",
    "commit",
    "condition",
    "connect",
    "constraint",
    "contains",
    "convert",
    "copy",
    "corr",
    "corresponding",
    "cos",
    "cosh",
    "count",
    "covar_pop",
    "covar_samp",
    "create",
    "cross",
    "cube",
    "cume_dist",
    "current",
    "current_catalog",
    "current_date",
    "current_default_transform_group",
    "current_path",
    "current_role",
    "current_row",
    "current_schema",
    "current_time",
    "current_timestamp",
    "current_path",
    "current_role",
    "current_transform_group_for_type",
    "current_user",
    "cursor",
    "cycle",
    "date",
    "day",
    "deallocate",
    "dec",
    "decimal",
    "decfloat",
    "declare",
    "default",
    "define",
    "delete",
    "dense_rank",
    "deref",
    "describe",
    "deterministic",
    "disconnect",
    "distinct",
    "double",
    "drop",
    "dynamic",
    "each",
    "element",
    "else",
    "empty",
    "end",
    "end_frame",
    "end_partition",
    "end-exec",
    "equals",
    "escape",
    "every",
    "except",
    "exec",
    "execute",
    "exists",
    "exp",
    "external",
    "extract",
    "false",
    "fetch",
    "filter",
    "first_value",
    "float",
    "floor",
    "for",
    "foreign",
    "frame_row",
    "free",
    "from",
    "full",
    "function",
    "fusion",
    "get",
    "global",
    "grant",
    "group",
    "grouping",
    "groups",
    "having",
    "hold",
    "hour",
    "identity",
    "in",
    "indicator",
    "initial",
    "inner",
    "inout",
    "insensitive",
    "insert",
    "int",
    "integer",
    "intersect",
    "intersection",
    "interval",
    "into",
    "is",
    "join",
    "json_array",
    "json_arrayagg",
    "json_exists",
    "json_object",
    "json_objectagg",
    "json_query",
    "json_table",
    "json_table_primitive",
    "json_value",
    "lag",
    "language",
    "large",
    "last_value",
    "lateral",
    "lead",
    "leading",
    "left",
    "like",
    "like_regex",
    "listagg",
    "ln",
    "local",
    "localtime",
    "localtimestamp",
    "log",
    "log10",
    "lower",
    "match",
    "match_number",
    "match_recognize",
    "matches",
    "max",
    "member",
    "merge",
    "method",
    "min",
    "minute",
    "mod",
    "modifies",
    "module",
    "month",
    "multiset",
    "national",
    "natural",
    "nchar",
    "nclob",
    "new",
    "no",
    "none",
    "normalize",
    "not",
    "nth_value",
    "ntile",
    "null",
    "nullif",
    "numeric",
    "octet_length",
    "occurrences_regex",
    "of",
    "offset",
    "old",
    "omit",
    "on",
    "one",
    "only",
    "open",
    "or",
    "order",
    "out",
    "outer",
    "over",
    "overlaps",
    "overlay",
    "parameter",
    "partition",
    "pattern",
    "per",
    "percent",
    "percent_rank",
    "percentile_cont",
    "percentile_disc",
    "period",
    "portion",
    "position",
    "position_regex",
    "power",
    "precedes",
    "precision",
    "prepare",
    "primary",
    "procedure",
    "ptf",
    "range",
    "rank",
    "reads",
    "real",
    "recursive",
    "ref",
    "references",
    "referencing",
    "regr_avgx",
    "regr_avgy",
    "regr_count",
    "regr_intercept",
    "regr_r2",
    "regr_slope",
    "regr_sxx",
    "regr_sxy",
    "regr_syy",
    "release",
    "result",
    "return",
    "returns",
    "revoke",
    "right",
    "rollback",
    "rollup",
    "row",
    "row_number",
    "rows",
    "running",
    "savepoint",
    "scope",
    "scroll",
    "search",
    "second",
    "seek",
    "select",
    "sensitive",
    "session_user",
    "set",
    "show",
    "similar",
    "sin",
    "sinh",
    "skip",
    "smallint",
    "some",
    "specific",
    "specifictype",
    "sql",
    "sqlexception",
    "sqlstate",
    "sqlwarning",
    "sqrt",
    "start",
    "static",
    "stddev_pop",
    "stddev_samp",
    "submultiset",
    "subset",
    "substring",
    "substring_regex",
    "succeeds",
    "sum",
    "symmetric",
    "system",
    "system_time",
    "system_user",
    "table",
    "tablesample",
    "tan",
    "tanh",
    "then",
    "time",
    "timestamp",
    "timezone_hour",
    "timezone_minute",
    "to",
    "trailing",
    "translate",
    "translate_regex",
    "translation",
    "treat",
    "trigger",
    "trim",
    "trim_array",
    "true",
    "truncate",
    "uescape",
    "union",
    "unique",
    "unknown",
    "unnest",
    "update",
    "upper",
    "user",
    "using",
    "value",
    "values",
    "value_of",
    "var_pop",
    "var_samp",
    "varbinary",
    "varchar",
    "varying",
    "versioning",
    "when",
    "whenever",
    "where",
    "width_bucket",
    "window",
    "with",
    "within",
    "without",
    "year"
  ], d = [
    "abs",
    "acos",
    "array_agg",
    "asin",
    "atan",
    "avg",
    "cast",
    "ceil",
    "ceiling",
    "coalesce",
    "corr",
    "cos",
    "cosh",
    "count",
    "covar_pop",
    "covar_samp",
    "cume_dist",
    "dense_rank",
    "deref",
    "element",
    "exp",
    "extract",
    "first_value",
    "floor",
    "json_array",
    "json_arrayagg",
    "json_exists",
    "json_object",
    "json_objectagg",
    "json_query",
    "json_table",
    "json_table_primitive",
    "json_value",
    "lag",
    "last_value",
    "lead",
    "listagg",
    "ln",
    "log",
    "log10",
    "lower",
    "max",
    "min",
    "mod",
    "nth_value",
    "ntile",
    "nullif",
    "percent_rank",
    "percentile_cont",
    "percentile_disc",
    "position",
    "position_regex",
    "power",
    "rank",
    "regr_avgx",
    "regr_avgy",
    "regr_count",
    "regr_intercept",
    "regr_r2",
    "regr_slope",
    "regr_sxx",
    "regr_sxy",
    "regr_syy",
    "row_number",
    "sin",
    "sinh",
    "sqrt",
    "stddev_pop",
    "stddev_samp",
    "substring",
    "substring_regex",
    "sum",
    "tan",
    "tanh",
    "translate",
    "translate_regex",
    "treat",
    "trim",
    "trim_array",
    "unnest",
    "upper",
    "value_of",
    "var_pop",
    "var_samp",
    "width_bucket"
  ], u = [
    "current_catalog",
    "current_date",
    "current_default_transform_group",
    "current_path",
    "current_role",
    "current_schema",
    "current_transform_group_for_type",
    "current_user",
    "session_user",
    "system_time",
    "system_user",
    "current_time",
    "localtime",
    "current_timestamp",
    "localtimestamp"
  ], m = [
    "create table",
    "insert into",
    "primary key",
    "foreign key",
    "not null",
    "alter table",
    "add constraint",
    "grouping sets",
    "on overflow",
    "character set",
    "respect nulls",
    "ignore nulls",
    "nulls first",
    "nulls last",
    "depth first",
    "breadth first"
  ], g = d, f = [
    ...l,
    ...c
  ].filter((x) => !d.includes(x)), b = {
    scope: "variable",
    match: /@[a-z0-9][a-z0-9_]*/
  }, E = {
    scope: "operator",
    match: /[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,
    relevance: 0
  }, _ = {
    match: t.concat(/\b/, t.either(...g), /\s*\(/),
    relevance: 0,
    keywords: { built_in: g }
  };
  function k(x) {
    return t.concat(
      /\b/,
      t.either(...x.map((C) => C.replace(/\s+/, "\\s+"))),
      /\b/
    );
  }
  const S = {
    scope: "keyword",
    match: k(m),
    relevance: 0
  };
  function y(x, {
    exceptions: C,
    when: O
  } = {}) {
    const P = O;
    return C = C || [], x.map((G) => G.match(/\|\d+$/) || C.includes(G) ? G : P(G) ? `${G}|0` : G);
  }
  return {
    name: "SQL",
    case_insensitive: !0,
    // does not include {} or HTML tags `</`
    illegal: /[{}]|<\//,
    keywords: {
      $pattern: /\b[\w\.]+/,
      keyword: y(f, { when: (x) => x.length < 3 }),
      literal: o,
      type: i,
      built_in: u
    },
    contains: [
      {
        scope: "type",
        match: k(s)
      },
      S,
      _,
      b,
      a,
      r,
      e.C_NUMBER_MODE,
      e.C_BLOCK_COMMENT_MODE,
      n,
      E
    ]
  };
}
function ii(e) {
  return e ? typeof e == "string" ? e : e.source : null;
}
function $t(e) {
  return X("(?=", e, ")");
}
function X(...e) {
  return e.map((n) => ii(n)).join("");
}
function qp(e) {
  const t = e[e.length - 1];
  return typeof t == "object" && t.constructor === Object ? (e.splice(e.length - 1, 1), t) : {};
}
function _e(...e) {
  return "(" + (qp(e).capture ? "" : "?:") + e.map((a) => ii(a)).join("|") + ")";
}
const rr = (e) => X(
  /\b/,
  e,
  /\w$/.test(e) ? /\b/ : /\B/
), Yp = [
  "Protocol",
  // contextual
  "Type"
  // contextual
].map(rr), io = [
  "init",
  "self"
].map(rr), Xp = [
  "Any",
  "Self"
], la = [
  // strings below will be fed into the regular `keywords` engine while regex
  // will result in additional modes being created to scan for those keywords to
  // avoid conflicts with other rules
  "actor",
  "any",
  // contextual
  "associatedtype",
  "async",
  "await",
  /as\?/,
  // operator
  /as!/,
  // operator
  "as",
  // operator
  "borrowing",
  // contextual
  "break",
  "case",
  "catch",
  "class",
  "consume",
  // contextual
  "consuming",
  // contextual
  "continue",
  "convenience",
  // contextual
  "copy",
  // contextual
  "default",
  "defer",
  "deinit",
  "didSet",
  // contextual
  "distributed",
  "do",
  "dynamic",
  // contextual
  "each",
  "else",
  "enum",
  "extension",
  "fallthrough",
  /fileprivate\(set\)/,
  "fileprivate",
  "final",
  // contextual
  "for",
  "func",
  "get",
  // contextual
  "guard",
  "if",
  "import",
  "indirect",
  // contextual
  "infix",
  // contextual
  /init\?/,
  /init!/,
  "inout",
  /internal\(set\)/,
  "internal",
  "in",
  "is",
  // operator
  "isolated",
  // contextual
  "nonisolated",
  // contextual
  "lazy",
  // contextual
  "let",
  "macro",
  "mutating",
  // contextual
  "nonmutating",
  // contextual
  /open\(set\)/,
  // contextual
  "open",
  // contextual
  "operator",
  "optional",
  // contextual
  "override",
  // contextual
  "package",
  "postfix",
  // contextual
  "precedencegroup",
  "prefix",
  // contextual
  /private\(set\)/,
  "private",
  "protocol",
  /public\(set\)/,
  "public",
  "repeat",
  "required",
  // contextual
  "rethrows",
  "return",
  "set",
  // contextual
  "some",
  // contextual
  "static",
  "struct",
  "subscript",
  "super",
  "switch",
  "throws",
  "throw",
  /try\?/,
  // operator
  /try!/,
  // operator
  "try",
  // operator
  "typealias",
  /unowned\(safe\)/,
  // contextual
  /unowned\(unsafe\)/,
  // contextual
  "unowned",
  // contextual
  "var",
  "weak",
  // contextual
  "where",
  "while",
  "willSet"
  // contextual
], co = [
  "false",
  "nil",
  "true"
], Zp = [
  "assignment",
  "associativity",
  "higherThan",
  "left",
  "lowerThan",
  "none",
  "right"
], Jp = [
  "#colorLiteral",
  "#column",
  "#dsohandle",
  "#else",
  "#elseif",
  "#endif",
  "#error",
  "#file",
  "#fileID",
  "#fileLiteral",
  "#filePath",
  "#function",
  "#if",
  "#imageLiteral",
  "#keyPath",
  "#line",
  "#selector",
  "#sourceLocation",
  "#warning"
], lo = [
  "abs",
  "all",
  "any",
  "assert",
  "assertionFailure",
  "debugPrint",
  "dump",
  "fatalError",
  "getVaList",
  "isKnownUniquelyReferenced",
  "max",
  "min",
  "numericCast",
  "pointwiseMax",
  "pointwiseMin",
  "precondition",
  "preconditionFailure",
  "print",
  "readLine",
  "repeatElement",
  "sequence",
  "stride",
  "swap",
  "swift_unboxFromSwiftValueWithType",
  "transcode",
  "type",
  "unsafeBitCast",
  "unsafeDowncast",
  "withExtendedLifetime",
  "withUnsafeMutablePointer",
  "withUnsafePointer",
  "withVaList",
  "withoutActuallyEscaping",
  "zip"
], ci = _e(
  /[/=\-+!*%<>&|^~?]/,
  /[\u00A1-\u00A7]/,
  /[\u00A9\u00AB]/,
  /[\u00AC\u00AE]/,
  /[\u00B0\u00B1]/,
  /[\u00B6\u00BB\u00BF\u00D7\u00F7]/,
  /[\u2016-\u2017]/,
  /[\u2020-\u2027]/,
  /[\u2030-\u203E]/,
  /[\u2041-\u2053]/,
  /[\u2055-\u205E]/,
  /[\u2190-\u23FF]/,
  /[\u2500-\u2775]/,
  /[\u2794-\u2BFF]/,
  /[\u2E00-\u2E7F]/,
  /[\u3001-\u3003]/,
  /[\u3008-\u3020]/,
  /[\u3030]/
), li = _e(
  ci,
  /[\u0300-\u036F]/,
  /[\u1DC0-\u1DFF]/,
  /[\u20D0-\u20FF]/,
  /[\uFE00-\uFE0F]/,
  /[\uFE20-\uFE2F]/
  // TODO: The following characters are also allowed, but the regex isn't supported yet.
  // /[\u{E0100}-\u{E01EF}]/u
), da = X(ci, li, "*"), di = _e(
  /[a-zA-Z_]/,
  /[\u00A8\u00AA\u00AD\u00AF\u00B2-\u00B5\u00B7-\u00BA]/,
  /[\u00BC-\u00BE\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]/,
  /[\u0100-\u02FF\u0370-\u167F\u1681-\u180D\u180F-\u1DBF]/,
  /[\u1E00-\u1FFF]/,
  /[\u200B-\u200D\u202A-\u202E\u203F-\u2040\u2054\u2060-\u206F]/,
  /[\u2070-\u20CF\u2100-\u218F\u2460-\u24FF\u2776-\u2793]/,
  /[\u2C00-\u2DFF\u2E80-\u2FFF]/,
  /[\u3004-\u3007\u3021-\u302F\u3031-\u303F\u3040-\uD7FF]/,
  /[\uF900-\uFD3D\uFD40-\uFDCF\uFDF0-\uFE1F\uFE30-\uFE44]/,
  /[\uFE47-\uFEFE\uFF00-\uFFFD]/
  // Should be /[\uFE47-\uFFFD]/, but we have to exclude FEFF.
  // The following characters are also allowed, but the regexes aren't supported yet.
  // /[\u{10000}-\u{1FFFD}\u{20000-\u{2FFFD}\u{30000}-\u{3FFFD}\u{40000}-\u{4FFFD}]/u,
  // /[\u{50000}-\u{5FFFD}\u{60000-\u{6FFFD}\u{70000}-\u{7FFFD}\u{80000}-\u{8FFFD}]/u,
  // /[\u{90000}-\u{9FFFD}\u{A0000-\u{AFFFD}\u{B0000}-\u{BFFFD}\u{C0000}-\u{CFFFD}]/u,
  // /[\u{D0000}-\u{DFFFD}\u{E0000-\u{EFFFD}]/u
), Mn = _e(
  di,
  /\d/,
  /[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/
), He = X(di, Mn, "*"), hn = X(/[A-Z]/, Mn, "*"), jp = [
  "attached",
  "autoclosure",
  X(/convention\(/, _e("swift", "block", "c"), /\)/),
  "discardableResult",
  "dynamicCallable",
  "dynamicMemberLookup",
  "escaping",
  "freestanding",
  "frozen",
  "GKInspectable",
  "IBAction",
  "IBDesignable",
  "IBInspectable",
  "IBOutlet",
  "IBSegueAction",
  "inlinable",
  "main",
  "nonobjc",
  "NSApplicationMain",
  "NSCopying",
  "NSManaged",
  X(/objc\(/, He, /\)/),
  "objc",
  "objcMembers",
  "propertyWrapper",
  "requires_stored_property_inits",
  "resultBuilder",
  "Sendable",
  "testable",
  "UIApplicationMain",
  "unchecked",
  "unknown",
  "usableFromInline",
  "warn_unqualified_access"
], Qp = [
  "iOS",
  "iOSApplicationExtension",
  "macOS",
  "macOSApplicationExtension",
  "macCatalyst",
  "macCatalystApplicationExtension",
  "watchOS",
  "watchOSApplicationExtension",
  "tvOS",
  "tvOSApplicationExtension",
  "swift"
];
function ef(e) {
  const t = {
    match: /\s+/,
    relevance: 0
  }, n = e.COMMENT(
    "/\\*",
    "\\*/",
    { contains: ["self"] }
  ), a = [
    e.C_LINE_COMMENT_MODE,
    n
  ], r = {
    match: [
      /\./,
      _e(...Yp, ...io)
    ],
    className: { 2: "keyword" }
  }, o = {
    // Consume .keyword to prevent highlighting properties and methods as keywords.
    match: X(/\./, _e(...la)),
    relevance: 0
  }, s = la.filter((Y) => typeof Y == "string").concat(["_|0"]), i = la.filter((Y) => typeof Y != "string").concat(Xp).map(rr), c = { variants: [
    {
      className: "keyword",
      match: _e(...i, ...io)
    }
  ] }, l = {
    $pattern: _e(
      /\b\w+/,
      // regular keywords
      /#\w+/
      // number keywords
    ),
    keyword: s.concat(Jp),
    literal: co
  }, d = [
    r,
    o,
    c
  ], u = {
    // Consume .built_in to prevent highlighting properties and methods.
    match: X(/\./, _e(...lo)),
    relevance: 0
  }, m = {
    className: "built_in",
    match: X(/\b/, _e(...lo), /(?=\()/)
  }, g = [
    u,
    m
  ], f = {
    // Prevent -> from being highlighting as an operator.
    match: /->/,
    relevance: 0
  }, b = {
    className: "operator",
    relevance: 0,
    variants: [
      { match: da },
      {
        // dot-operator: only operators that start with a dot are allowed to use dots as
        // characters (..., ...<, .*, etc). So there rule here is: a dot followed by one or more
        // characters that may also include dots.
        match: `\\.(\\.|${li})+`
      }
    ]
  }, E = [
    f,
    b
  ], _ = "([0-9]_*)+", k = "([0-9a-fA-F]_*)+", S = {
    className: "number",
    relevance: 0,
    variants: [
      // decimal floating-point-literal (subsumes decimal-literal)
      { match: `\\b(${_})(\\.(${_}))?([eE][+-]?(${_}))?\\b` },
      // hexadecimal floating-point-literal (subsumes hexadecimal-literal)
      { match: `\\b0x(${k})(\\.(${k}))?([pP][+-]?(${_}))?\\b` },
      // octal-literal
      { match: /\b0o([0-7]_*)+\b/ },
      // binary-literal
      { match: /\b0b([01]_*)+\b/ }
    ]
  }, y = (Y = "") => ({
    className: "subst",
    variants: [
      { match: X(/\\/, Y, /[0\\tnr"']/) },
      { match: X(/\\/, Y, /u\{[0-9a-fA-F]{1,8}\}/) }
    ]
  }), x = (Y = "") => ({
    className: "subst",
    match: X(/\\/, Y, /[\t ]*(?:[\r\n]|\r\n)/)
  }), C = (Y = "") => ({
    className: "subst",
    label: "interpol",
    begin: X(/\\/, Y, /\(/),
    end: /\)/
  }), O = (Y = "") => ({
    begin: X(Y, /"""/),
    end: X(/"""/, Y),
    contains: [
      y(Y),
      x(Y),
      C(Y)
    ]
  }), P = (Y = "") => ({
    begin: X(Y, /"/),
    end: X(/"/, Y),
    contains: [
      y(Y),
      C(Y)
    ]
  }), G = {
    className: "string",
    variants: [
      O(),
      O("#"),
      O("##"),
      O("###"),
      P(),
      P("#"),
      P("##"),
      P("###")
    ]
  }, K = [
    e.BACKSLASH_ESCAPE,
    {
      begin: /\[/,
      end: /\]/,
      relevance: 0,
      contains: [e.BACKSLASH_ESCAPE]
    }
  ], oe = {
    begin: /\/[^\s](?=[^/\n]*\/)/,
    end: /\//,
    contains: K
  }, L = (Y) => {
    const St = X(Y, /\//), ct = X(/\//, Y);
    return {
      begin: St,
      end: ct,
      contains: [
        ...K,
        {
          scope: "comment",
          begin: `#(?!.*${ct})`,
          end: /$/
        }
      ]
    };
  }, Z = {
    scope: "regexp",
    variants: [
      L("###"),
      L("##"),
      L("#"),
      oe
    ]
  }, V = { match: X(/`/, He, /`/) }, re = {
    className: "variable",
    match: /\$\d+/
  }, be = {
    className: "variable",
    match: `\\$${Mn}+`
  }, we = [
    V,
    re,
    be
  ], H = {
    match: /(@|#(un)?)available/,
    scope: "keyword",
    starts: { contains: [
      {
        begin: /\(/,
        end: /\)/,
        keywords: Qp,
        contains: [
          ...E,
          S,
          G
        ]
      }
    ] }
  }, se = {
    scope: "keyword",
    match: X(/@/, _e(...jp), $t(_e(/\(/, /\s+/)))
  }, me = {
    scope: "meta",
    match: X(/@/, He)
  }, de = [
    H,
    se,
    me
  ], ue = {
    match: $t(/\b[A-Z]/),
    relevance: 0,
    contains: [
      {
        // Common Apple frameworks, for relevance boost
        className: "type",
        match: X(/(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)/, Mn, "+")
      },
      {
        // Type identifier
        className: "type",
        match: hn,
        relevance: 0
      },
      {
        // Optional type
        match: /[?!]+/,
        relevance: 0
      },
      {
        // Variadic parameter
        match: /\.\.\./,
        relevance: 0
      },
      {
        // Protocol composition
        match: X(/\s+&\s+/, $t(hn)),
        relevance: 0
      }
    ]
  }, Me = {
    begin: /</,
    end: />/,
    keywords: l,
    contains: [
      ...a,
      ...d,
      ...de,
      f,
      ue
    ]
  };
  ue.contains.push(Me);
  const _t = {
    match: X(He, /\s*:/),
    keywords: "_|0",
    relevance: 0
  }, it = {
    begin: /\(/,
    end: /\)/,
    relevance: 0,
    keywords: l,
    contains: [
      "self",
      _t,
      ...a,
      Z,
      ...d,
      ...g,
      ...E,
      S,
      G,
      ...we,
      ...de,
      ue
    ]
  }, ie = {
    begin: /</,
    end: />/,
    keywords: "repeat each",
    contains: [
      ...a,
      ue
    ]
  }, J = {
    begin: _e(
      $t(X(He, /\s*:/)),
      $t(X(He, /\s+/, He, /\s*:/))
    ),
    end: /:/,
    relevance: 0,
    contains: [
      {
        className: "keyword",
        match: /\b_\b/
      },
      {
        className: "params",
        match: He
      }
    ]
  }, Ne = {
    begin: /\(/,
    end: /\)/,
    keywords: l,
    contains: [
      J,
      ...a,
      ...d,
      ...E,
      S,
      G,
      ...de,
      ue,
      it
    ],
    endsParent: !0,
    illegal: /["']/
  }, Bt = {
    match: [
      /(func|macro)/,
      /\s+/,
      _e(V.match, He, da)
    ],
    className: {
      1: "keyword",
      3: "title.function"
    },
    contains: [
      ie,
      Ne,
      t
    ],
    illegal: [
      /\[/,
      /%/
    ]
  }, Ke = {
    match: [
      /\b(?:subscript|init[?!]?)/,
      /\s*(?=[<(])/
    ],
    className: { 1: "keyword" },
    contains: [
      ie,
      Ne,
      t
    ],
    illegal: /\[|%/
  }, je = {
    match: [
      /operator/,
      /\s+/,
      da
    ],
    className: {
      1: "keyword",
      3: "title"
    }
  }, Be = {
    begin: [
      /precedencegroup/,
      /\s+/,
      hn
    ],
    className: {
      1: "keyword",
      3: "title"
    },
    contains: [ue],
    keywords: [
      ...Zp,
      ...co
    ],
    end: /}/
  }, zn = {
    match: [
      /class\b/,
      /\s+/,
      /func\b/,
      /\s+/,
      /\b[A-Za-z_][A-Za-z0-9_]*\b/
    ],
    scope: {
      1: "keyword",
      3: "keyword",
      5: "title.function"
    }
  }, Hn = {
    match: [
      /class\b/,
      /\s+/,
      /var\b/
    ],
    scope: {
      1: "keyword",
      3: "keyword"
    }
  }, $n = {
    begin: [
      /(struct|protocol|class|extension|enum|actor)/,
      /\s+/,
      He,
      /\s*/
    ],
    beginScope: {
      1: "keyword",
      3: "title.class"
    },
    keywords: l,
    contains: [
      ie,
      ...d,
      {
        begin: /:/,
        end: /\{/,
        keywords: l,
        contains: [
          {
            scope: "title.class.inherited",
            match: hn
          },
          ...d
        ],
        relevance: 0
      }
    ]
  };
  for (const Y of G.variants) {
    const St = Y.contains.find((Un) => Un.label === "interpol");
    St.keywords = l;
    const ct = [
      ...d,
      ...g,
      ...E,
      S,
      G,
      ...we
    ];
    St.contains = [
      ...ct,
      {
        begin: /\(/,
        end: /\)/,
        contains: [
          "self",
          ...ct
        ]
      }
    ];
  }
  return {
    name: "Swift",
    keywords: l,
    contains: [
      ...a,
      Bt,
      Ke,
      zn,
      Hn,
      $n,
      je,
      Be,
      {
        beginKeywords: "import",
        end: /$/,
        contains: [...a],
        relevance: 0
      },
      Z,
      ...d,
      ...g,
      ...E,
      S,
      G,
      ...we,
      ...de,
      ue,
      it
    ]
  };
}
const In = "[A-Za-z$_][0-9A-Za-z$_]*", ui = [
  "as",
  // for exports
  "in",
  "of",
  "if",
  "for",
  "while",
  "finally",
  "var",
  "new",
  "function",
  "do",
  "return",
  "void",
  "else",
  "break",
  "catch",
  "instanceof",
  "with",
  "throw",
  "case",
  "default",
  "try",
  "switch",
  "continue",
  "typeof",
  "delete",
  "let",
  "yield",
  "const",
  "class",
  // JS handles these with a special rule
  // "get",
  // "set",
  "debugger",
  "async",
  "await",
  "static",
  "import",
  "from",
  "export",
  "extends",
  // It's reached stage 3, which is "recommended for implementation":
  "using"
], gi = [
  "true",
  "false",
  "null",
  "undefined",
  "NaN",
  "Infinity"
], mi = [
  // Fundamental objects
  "Object",
  "Function",
  "Boolean",
  "Symbol",
  // numbers and dates
  "Math",
  "Date",
  "Number",
  "BigInt",
  // text
  "String",
  "RegExp",
  // Indexed collections
  "Array",
  "Float32Array",
  "Float64Array",
  "Int8Array",
  "Uint8Array",
  "Uint8ClampedArray",
  "Int16Array",
  "Int32Array",
  "Uint16Array",
  "Uint32Array",
  "BigInt64Array",
  "BigUint64Array",
  // Keyed collections
  "Set",
  "Map",
  "WeakSet",
  "WeakMap",
  // Structured data
  "ArrayBuffer",
  "SharedArrayBuffer",
  "Atomics",
  "DataView",
  "JSON",
  // Control abstraction objects
  "Promise",
  "Generator",
  "GeneratorFunction",
  "AsyncFunction",
  // Reflection
  "Reflect",
  "Proxy",
  // Internationalization
  "Intl",
  // WebAssembly
  "WebAssembly"
], pi = [
  "Error",
  "EvalError",
  "InternalError",
  "RangeError",
  "ReferenceError",
  "SyntaxError",
  "TypeError",
  "URIError"
], fi = [
  "setInterval",
  "setTimeout",
  "clearInterval",
  "clearTimeout",
  "require",
  "exports",
  "eval",
  "isFinite",
  "isNaN",
  "parseFloat",
  "parseInt",
  "decodeURI",
  "decodeURIComponent",
  "encodeURI",
  "encodeURIComponent",
  "escape",
  "unescape"
], bi = [
  "arguments",
  "this",
  "super",
  "console",
  "window",
  "document",
  "localStorage",
  "sessionStorage",
  "module",
  "global"
  // Node.js
], hi = [].concat(
  fi,
  mi,
  pi
);
function tf(e) {
  const t = e.regex, n = (H, { after: se }) => {
    const me = "</" + H[0].slice(1);
    return H.input.indexOf(me, se) !== -1;
  }, a = In, r = {
    begin: "<>",
    end: "</>"
  }, o = /<[A-Za-z0-9\\._:-]+\s*\/>/, s = {
    begin: /<[A-Za-z0-9\\._:-]+/,
    end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
    /**
     * @param {RegExpMatchArray} match
     * @param {CallbackResponse} response
     */
    isTrulyOpeningTag: (H, se) => {
      const me = H[0].length + H.index, de = H.input[me];
      if (
        // HTML should not include another raw `<` inside a tag
        // nested type?
        // `<Array<Array<number>>`, etc.
        de === "<" || // the , gives away that this is not HTML
        // `<T, A extends keyof T, V>`
        de === ","
      ) {
        se.ignoreMatch();
        return;
      }
      de === ">" && (n(H, { after: me }) || se.ignoreMatch());
      let ue;
      const Me = H.input.substring(me);
      if (ue = Me.match(/^\s*=/)) {
        se.ignoreMatch();
        return;
      }
      if ((ue = Me.match(/^\s+extends\s+/)) && ue.index === 0) {
        se.ignoreMatch();
        return;
      }
    }
  }, i = {
    $pattern: In,
    keyword: ui,
    literal: gi,
    built_in: hi,
    "variable.language": bi
  }, c = "[0-9](_?[0-9])*", l = `\\.(${c})`, d = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*", u = {
    className: "number",
    variants: [
      // DecimalLiteral
      { begin: `(\\b(${d})((${l})|\\.)?|(${l}))[eE][+-]?(${c})\\b` },
      { begin: `\\b(${d})\\b((${l})\\b|\\.)?|(${l})\\b` },
      // DecimalBigIntegerLiteral
      { begin: "\\b(0|[1-9](_?[0-9])*)n\\b" },
      // NonDecimalIntegerLiteral
      { begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b" },
      { begin: "\\b0[bB][0-1](_?[0-1])*n?\\b" },
      { begin: "\\b0[oO][0-7](_?[0-7])*n?\\b" },
      // LegacyOctalIntegerLiteral (does not include underscore separators)
      // https://tc39.es/ecma262/#sec-additional-syntax-numeric-literals
      { begin: "\\b0[0-7]+n?\\b" }
    ],
    relevance: 0
  }, m = {
    className: "subst",
    begin: "\\$\\{",
    end: "\\}",
    keywords: i,
    contains: []
    // defined later
  }, g = {
    begin: ".?html`",
    end: "",
    starts: {
      end: "`",
      returnEnd: !1,
      contains: [
        e.BACKSLASH_ESCAPE,
        m
      ],
      subLanguage: "xml"
    }
  }, f = {
    begin: ".?css`",
    end: "",
    starts: {
      end: "`",
      returnEnd: !1,
      contains: [
        e.BACKSLASH_ESCAPE,
        m
      ],
      subLanguage: "css"
    }
  }, b = {
    begin: ".?gql`",
    end: "",
    starts: {
      end: "`",
      returnEnd: !1,
      contains: [
        e.BACKSLASH_ESCAPE,
        m
      ],
      subLanguage: "graphql"
    }
  }, E = {
    className: "string",
    begin: "`",
    end: "`",
    contains: [
      e.BACKSLASH_ESCAPE,
      m
    ]
  }, k = {
    className: "comment",
    variants: [
      e.COMMENT(
        /\/\*\*(?!\/)/,
        "\\*/",
        {
          relevance: 0,
          contains: [
            {
              begin: "(?=@[A-Za-z]+)",
              relevance: 0,
              contains: [
                {
                  className: "doctag",
                  begin: "@[A-Za-z]+"
                },
                {
                  className: "type",
                  begin: "\\{",
                  end: "\\}",
                  excludeEnd: !0,
                  excludeBegin: !0,
                  relevance: 0
                },
                {
                  className: "variable",
                  begin: a + "(?=\\s*(-)|$)",
                  endsParent: !0,
                  relevance: 0
                },
                // eat spaces (not newlines) so we can find
                // types or variables
                {
                  begin: /(?=[^\n])\s/,
                  relevance: 0
                }
              ]
            }
          ]
        }
      ),
      e.C_BLOCK_COMMENT_MODE,
      e.C_LINE_COMMENT_MODE
    ]
  }, S = [
    e.APOS_STRING_MODE,
    e.QUOTE_STRING_MODE,
    g,
    f,
    b,
    E,
    // Skip numbers when they are part of a variable name
    { match: /\$\d+/ },
    u
    // This is intentional:
    // See https://github.com/highlightjs/highlight.js/issues/3288
    // hljs.REGEXP_MODE
  ];
  m.contains = S.concat({
    // we need to pair up {} inside our subst to prevent
    // it from ending too early by matching another }
    begin: /\{/,
    end: /\}/,
    keywords: i,
    contains: [
      "self"
    ].concat(S)
  });
  const y = [].concat(k, m.contains), x = y.concat([
    // eat recursive parens in sub expressions
    {
      begin: /(\s*)\(/,
      end: /\)/,
      keywords: i,
      contains: ["self"].concat(y)
    }
  ]), C = {
    className: "params",
    // convert this to negative lookbehind in v12
    begin: /(\s*)\(/,
    // to match the parms with
    end: /\)/,
    excludeBegin: !0,
    excludeEnd: !0,
    keywords: i,
    contains: x
  }, O = {
    variants: [
      // class Car extends vehicle
      {
        match: [
          /class/,
          /\s+/,
          a,
          /\s+/,
          /extends/,
          /\s+/,
          t.concat(a, "(", t.concat(/\./, a), ")*")
        ],
        scope: {
          1: "keyword",
          3: "title.class",
          5: "keyword",
          7: "title.class.inherited"
        }
      },
      // class Car
      {
        match: [
          /class/,
          /\s+/,
          a
        ],
        scope: {
          1: "keyword",
          3: "title.class"
        }
      }
    ]
  }, P = {
    relevance: 0,
    match: t.either(
      // Hard coded exceptions
      /\bJSON/,
      // Float32Array, OutT
      /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/,
      // CSSFactory, CSSFactoryT
      /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/,
      // FPs, FPsT
      /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/
      // P
      // single letters are not highlighted
      // BLAH
      // this will be flagged as a UPPER_CASE_CONSTANT instead
    ),
    className: "title.class",
    keywords: {
      _: [
        // se we still get relevance credit for JS library classes
        ...mi,
        ...pi
      ]
    }
  }, G = {
    label: "use_strict",
    className: "meta",
    relevance: 10,
    begin: /^\s*['"]use (strict|asm)['"]/
  }, K = {
    variants: [
      {
        match: [
          /function/,
          /\s+/,
          a,
          /(?=\s*\()/
        ]
      },
      // anonymous function
      {
        match: [
          /function/,
          /\s*(?=\()/
        ]
      }
    ],
    className: {
      1: "keyword",
      3: "title.function"
    },
    label: "func.def",
    contains: [C],
    illegal: /%/
  }, oe = {
    relevance: 0,
    match: /\b[A-Z][A-Z_0-9]+\b/,
    className: "variable.constant"
  };
  function L(H) {
    return t.concat("(?!", H.join("|"), ")");
  }
  const Z = {
    match: t.concat(
      /\b/,
      L([
        ...fi,
        "super",
        "import"
      ].map((H) => `${H}\\s*\\(`)),
      a,
      t.lookahead(/\s*\(/)
    ),
    className: "title.function",
    relevance: 0
  }, V = {
    begin: t.concat(/\./, t.lookahead(
      t.concat(a, /(?![0-9A-Za-z$_(])/)
    )),
    end: a,
    excludeBegin: !0,
    keywords: "prototype",
    className: "property",
    relevance: 0
  }, re = {
    match: [
      /get|set/,
      /\s+/,
      a,
      /(?=\()/
    ],
    className: {
      1: "keyword",
      3: "title.function"
    },
    contains: [
      {
        // eat to avoid empty params
        begin: /\(\)/
      },
      C
    ]
  }, be = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>", we = {
    match: [
      /const|var|let/,
      /\s+/,
      a,
      /\s*/,
      /=\s*/,
      /(async\s*)?/,
      // async is optional
      t.lookahead(be)
    ],
    keywords: "async",
    className: {
      1: "keyword",
      3: "title.function"
    },
    contains: [
      C
    ]
  };
  return {
    name: "JavaScript",
    aliases: ["js", "jsx", "mjs", "cjs"],
    keywords: i,
    // this will be extended by TypeScript
    exports: { PARAMS_CONTAINS: x, CLASS_REFERENCE: P },
    illegal: /#(?![$_A-z])/,
    contains: [
      e.SHEBANG({
        label: "shebang",
        binary: "node",
        relevance: 5
      }),
      G,
      e.APOS_STRING_MODE,
      e.QUOTE_STRING_MODE,
      g,
      f,
      b,
      E,
      k,
      // Skip numbers when they are part of a variable name
      { match: /\$\d+/ },
      u,
      P,
      {
        scope: "attr",
        match: a + t.lookahead(":"),
        relevance: 0
      },
      we,
      {
        // "value" container
        begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
        keywords: "return throw case",
        relevance: 0,
        contains: [
          k,
          e.REGEXP_MODE,
          {
            className: "function",
            // we have to count the parens to make sure we actually have the
            // correct bounding ( ) before the =>.  There could be any number of
            // sub-expressions inside also surrounded by parens.
            begin: be,
            returnBegin: !0,
            end: "\\s*=>",
            contains: [
              {
                className: "params",
                variants: [
                  {
                    begin: e.UNDERSCORE_IDENT_RE,
                    relevance: 0
                  },
                  {
                    className: null,
                    begin: /\(\s*\)/,
                    skip: !0
                  },
                  {
                    begin: /(\s*)\(/,
                    end: /\)/,
                    excludeBegin: !0,
                    excludeEnd: !0,
                    keywords: i,
                    contains: x
                  }
                ]
              }
            ]
          },
          {
            // could be a comma delimited list of params to a function call
            begin: /,/,
            relevance: 0
          },
          {
            match: /\s+/,
            relevance: 0
          },
          {
            // JSX
            variants: [
              { begin: r.begin, end: r.end },
              { match: o },
              {
                begin: s.begin,
                // we carefully check the opening tag to see if it truly
                // is a tag and not a false positive
                "on:begin": s.isTrulyOpeningTag,
                end: s.end
              }
            ],
            subLanguage: "xml",
            contains: [
              {
                begin: s.begin,
                end: s.end,
                skip: !0,
                contains: ["self"]
              }
            ]
          }
        ]
      },
      K,
      {
        // prevent this from getting swallowed up by function
        // since they appear "function like"
        beginKeywords: "while if switch catch for"
      },
      {
        // we have to count the parens to make sure we actually have the correct
        // bounding ( ).  There could be any number of sub-expressions inside
        // also surrounded by parens.
        begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
        // end parens
        returnBegin: !0,
        label: "func.def",
        contains: [
          C,
          e.inherit(e.TITLE_MODE, { begin: a, className: "title.function" })
        ]
      },
      // catch ... so it won't trigger the property rule below
      {
        match: /\.\.\./,
        relevance: 0
      },
      V,
      // hack: prevents detection of keywords in some circumstances
      // .keyword()
      // $keyword = x
      {
        match: "\\$" + a,
        relevance: 0
      },
      {
        match: [/\bconstructor(?=\s*\()/],
        className: { 1: "title.function" },
        contains: [C]
      },
      Z,
      oe,
      O,
      re,
      {
        match: /\$[(.]/
        // relevance booster for a pattern common to JS libs: `$(something)` and `$.something`
      }
    ]
  };
}
function nf(e) {
  const t = e.regex, n = tf(e), a = In, r = [
    "any",
    "void",
    "number",
    "boolean",
    "string",
    "object",
    "never",
    "symbol",
    "bigint",
    "unknown"
  ], o = {
    begin: [
      /namespace/,
      /\s+/,
      e.IDENT_RE
    ],
    beginScope: {
      1: "keyword",
      3: "title.class"
    }
  }, s = {
    beginKeywords: "interface",
    end: /\{/,
    excludeEnd: !0,
    keywords: {
      keyword: "interface extends",
      built_in: r
    },
    contains: [n.exports.CLASS_REFERENCE]
  }, i = {
    className: "meta",
    relevance: 10,
    begin: /^\s*['"]use strict['"]/
  }, c = [
    "type",
    // "namespace",
    "interface",
    "public",
    "private",
    "protected",
    "implements",
    "declare",
    "abstract",
    "readonly",
    "enum",
    "override",
    "satisfies"
  ], l = {
    $pattern: In,
    keyword: ui.concat(c),
    literal: gi,
    built_in: hi.concat(r),
    "variable.language": bi
  }, d = {
    className: "meta",
    begin: "@" + a
  }, u = (b, E, _) => {
    const k = b.contains.findIndex((S) => S.label === E);
    if (k === -1)
      throw new Error("can not find mode to replace");
    b.contains.splice(k, 1, _);
  };
  Object.assign(n.keywords, l), n.exports.PARAMS_CONTAINS.push(d);
  const m = n.contains.find((b) => b.scope === "attr"), g = Object.assign(
    {},
    m,
    { match: t.concat(a, t.lookahead(/\s*\?:/)) }
  );
  n.exports.PARAMS_CONTAINS.push([
    n.exports.CLASS_REFERENCE,
    // class reference for highlighting the params types
    m,
    // highlight the params key
    g
    // Added for optional property assignment highlighting
  ]), n.contains = n.contains.concat([
    d,
    o,
    s,
    g
    // Added for optional property assignment highlighting
  ]), u(n, "shebang", e.SHEBANG()), u(n, "use_strict", i);
  const f = n.contains.find((b) => b.label === "func.def");
  return f.relevance = 0, Object.assign(n, {
    name: "TypeScript",
    aliases: [
      "ts",
      "tsx",
      "mts",
      "cts"
    ]
  }), n;
}
function af(e) {
  const t = e.regex, n = {
    className: "string",
    begin: /"(""|[^/n])"C\b/
  }, a = {
    className: "string",
    begin: /"/,
    end: /"/,
    illegal: /\n/,
    contains: [
      {
        // double quote escape
        begin: /""/
      }
    ]
  }, r = /\d{1,2}\/\d{1,2}\/\d{4}/, o = /\d{4}-\d{1,2}-\d{1,2}/, s = /(\d|1[012])(:\d+){0,2} *(AM|PM)/, i = /\d{1,2}(:\d{1,2}){1,2}/, c = {
    className: "literal",
    variants: [
      {
        // #YYYY-MM-DD# (ISO-Date) or #M/D/YYYY# (US-Date)
        begin: t.concat(/# */, t.either(o, r), / *#/)
      },
      {
        // #H:mm[:ss]# (24h Time)
        begin: t.concat(/# */, i, / *#/)
      },
      {
        // #h[:mm[:ss]] A# (12h Time)
        begin: t.concat(/# */, s, / *#/)
      },
      {
        // date plus time
        begin: t.concat(
          /# */,
          t.either(o, r),
          / +/,
          t.either(s, i),
          / *#/
        )
      }
    ]
  }, l = {
    className: "number",
    relevance: 0,
    variants: [
      {
        // Float
        begin: /\b\d[\d_]*((\.[\d_]+(E[+-]?[\d_]+)?)|(E[+-]?[\d_]+))[RFD@!#]?/
      },
      {
        // Integer (base 10)
        begin: /\b\d[\d_]*((U?[SIL])|[%&])?/
      },
      {
        // Integer (base 16)
        begin: /&H[\dA-F_]+((U?[SIL])|[%&])?/
      },
      {
        // Integer (base 8)
        begin: /&O[0-7_]+((U?[SIL])|[%&])?/
      },
      {
        // Integer (base 2)
        begin: /&B[01_]+((U?[SIL])|[%&])?/
      }
    ]
  }, d = {
    className: "label",
    begin: /^\w+:/
  }, u = e.COMMENT(/'''/, /$/, { contains: [
    {
      className: "doctag",
      begin: /<\/?/,
      end: />/
    }
  ] }), m = e.COMMENT(null, /$/, { variants: [
    { begin: /'/ },
    {
      // TODO: Use multi-class for leading spaces
      begin: /([\t ]|^)REM(?=\s)/
    }
  ] });
  return {
    name: "Visual Basic .NET",
    aliases: ["vb"],
    case_insensitive: !0,
    classNameAliases: { label: "symbol" },
    keywords: {
      keyword: "addhandler alias aggregate ansi as async assembly auto binary by byref byval call case catch class compare const continue custom declare default delegate dim distinct do each equals else elseif end enum erase error event exit explicit finally for friend from function get global goto group handles if implements imports in inherits interface into iterator join key let lib loop me mid module mustinherit mustoverride mybase myclass namespace narrowing new next notinheritable notoverridable of off on operator option optional order overloads overridable overrides paramarray partial preserve private property protected public raiseevent readonly redim removehandler resume return select set shadows shared skip static step stop structure strict sub synclock take text then throw to try unicode until using when where while widening with withevents writeonly yield",
      built_in: (
        // Operators https://docs.microsoft.com/dotnet/visual-basic/language-reference/operators
        "addressof and andalso await directcast gettype getxmlnamespace is isfalse isnot istrue like mod nameof new not or orelse trycast typeof xor cbool cbyte cchar cdate cdbl cdec cint clng cobj csbyte cshort csng cstr cuint culng cushort"
      ),
      type: (
        // Data types https://docs.microsoft.com/dotnet/visual-basic/language-reference/data-types
        "boolean byte char date decimal double integer long object sbyte short single string uinteger ulong ushort"
      ),
      literal: "true false nothing"
    },
    illegal: "//|\\{|\\}|endif|gosub|variant|wend|^\\$ ",
    contains: [
      n,
      a,
      c,
      l,
      d,
      u,
      m,
      {
        className: "meta",
        // TODO: Use multi-class for indentation once available
        begin: /[\t ]*#(const|disable|else|elseif|enable|end|externalsource|if|region)\b/,
        end: /$/,
        keywords: { keyword: "const disable else elseif enable end externalsource if region then" },
        contains: [m]
      }
    ]
  };
}
function rf(e) {
  e.regex;
  const t = e.COMMENT(/\(;/, /;\)/);
  t.contains.push("self");
  const n = e.COMMENT(/;;/, /$/), a = [
    "anyfunc",
    "block",
    "br",
    "br_if",
    "br_table",
    "call",
    "call_indirect",
    "data",
    "drop",
    "elem",
    "else",
    "end",
    "export",
    "func",
    "global.get",
    "global.set",
    "local.get",
    "local.set",
    "local.tee",
    "get_global",
    "get_local",
    "global",
    "if",
    "import",
    "local",
    "loop",
    "memory",
    "memory.grow",
    "memory.size",
    "module",
    "mut",
    "nop",
    "offset",
    "param",
    "result",
    "return",
    "select",
    "set_global",
    "set_local",
    "start",
    "table",
    "tee_local",
    "then",
    "type",
    "unreachable"
  ], r = {
    begin: [
      /(?:func|call|call_indirect)/,
      /\s+/,
      /\$[^\s)]+/
    ],
    className: {
      1: "keyword",
      3: "title.function"
    }
  }, o = {
    className: "variable",
    begin: /\$[\w_]+/
  }, s = {
    match: /(\((?!;)|\))+/,
    className: "punctuation",
    relevance: 0
  }, i = {
    className: "number",
    relevance: 0,
    // borrowed from Prism, TODO: split out into variants
    match: /[+-]?\b(?:\d(?:_?\d)*(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?|0x[\da-fA-F](?:_?[\da-fA-F])*(?:\.[\da-fA-F](?:_?[\da-fA-D])*)?(?:[pP][+-]?\d(?:_?\d)*)?)\b|\binf\b|\bnan(?::0x[\da-fA-F](?:_?[\da-fA-D])*)?\b/
  }, c = {
    // look-ahead prevents us from gobbling up opcodes
    match: /(i32|i64|f32|f64)(?!\.)/,
    className: "type"
  }, l = {
    className: "keyword",
    // borrowed from Prism, TODO: split out into variants
    match: /\b(f32|f64|i32|i64)(?:\.(?:abs|add|and|ceil|clz|const|convert_[su]\/i(?:32|64)|copysign|ctz|demote\/f64|div(?:_[su])?|eqz?|extend_[su]\/i32|floor|ge(?:_[su])?|gt(?:_[su])?|le(?:_[su])?|load(?:(?:8|16|32)_[su])?|lt(?:_[su])?|max|min|mul|nearest|neg?|or|popcnt|promote\/f32|reinterpret\/[fi](?:32|64)|rem_[su]|rot[lr]|shl|shr_[su]|store(?:8|16|32)?|sqrt|sub|trunc(?:_[su]\/f(?:32|64))?|wrap\/i64|xor))\b/
  };
  return {
    name: "WebAssembly",
    keywords: {
      $pattern: /[\w.]+/,
      keyword: a
    },
    contains: [
      n,
      t,
      {
        match: [
          /(?:offset|align)/,
          /\s*/,
          /=/
        ],
        className: {
          1: "keyword",
          3: "operator"
        }
      },
      o,
      s,
      r,
      e.QUOTE_STRING_MODE,
      c,
      l,
      i
    ]
  };
}
function of(e) {
  const t = e.regex, n = t.concat(/[\p{L}_]/u, t.optional(/[\p{L}0-9_.-]*:/u), /[\p{L}0-9_.-]*/u), a = /[\p{L}0-9._:-]+/u, r = {
    className: "symbol",
    begin: /&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/
  }, o = {
    begin: /\s/,
    contains: [
      {
        className: "keyword",
        begin: /#?[a-z_][a-z1-9_-]+/,
        illegal: /\n/
      }
    ]
  }, s = e.inherit(o, {
    begin: /\(/,
    end: /\)/
  }), i = e.inherit(e.APOS_STRING_MODE, { className: "string" }), c = e.inherit(e.QUOTE_STRING_MODE, { className: "string" }), l = {
    endsWithParent: !0,
    illegal: /</,
    relevance: 0,
    contains: [
      {
        className: "attr",
        begin: a,
        relevance: 0
      },
      {
        begin: /=\s*/,
        relevance: 0,
        contains: [
          {
            className: "string",
            endsParent: !0,
            variants: [
              {
                begin: /"/,
                end: /"/,
                contains: [r]
              },
              {
                begin: /'/,
                end: /'/,
                contains: [r]
              },
              { begin: /[^\s"'=<>`]+/ }
            ]
          }
        ]
      }
    ]
  };
  return {
    name: "HTML, XML",
    aliases: [
      "html",
      "xhtml",
      "rss",
      "atom",
      "xjb",
      "xsd",
      "xsl",
      "plist",
      "wsf",
      "svg"
    ],
    case_insensitive: !0,
    unicodeRegex: !0,
    contains: [
      {
        className: "meta",
        begin: /<![a-z]/,
        end: />/,
        relevance: 10,
        contains: [
          o,
          c,
          i,
          s,
          {
            begin: /\[/,
            end: /\]/,
            contains: [
              {
                className: "meta",
                begin: /<![a-z]/,
                end: />/,
                contains: [
                  o,
                  s,
                  c,
                  i
                ]
              }
            ]
          }
        ]
      },
      e.COMMENT(
        /<!--/,
        /-->/,
        { relevance: 10 }
      ),
      {
        begin: /<!\[CDATA\[/,
        end: /\]\]>/,
        relevance: 10
      },
      r,
      // xml processing instructions
      {
        className: "meta",
        end: /\?>/,
        variants: [
          {
            begin: /<\?xml/,
            relevance: 10,
            contains: [
              c
            ]
          },
          {
            begin: /<\?[a-z][a-z0-9]+/
          }
        ]
      },
      {
        className: "tag",
        /*
        The lookahead pattern (?=...) ensures that 'begin' only matches
        '<style' as a single word, followed by a whitespace or an
        ending bracket.
        */
        begin: /<style(?=\s|>)/,
        end: />/,
        keywords: { name: "style" },
        contains: [l],
        starts: {
          end: /<\/style>/,
          returnEnd: !0,
          subLanguage: [
            "css",
            "xml"
          ]
        }
      },
      {
        className: "tag",
        // See the comment in the <style tag about the lookahead pattern
        begin: /<script(?=\s|>)/,
        end: />/,
        keywords: { name: "script" },
        contains: [l],
        starts: {
          end: /<\/script>/,
          returnEnd: !0,
          subLanguage: [
            "javascript",
            "handlebars",
            "xml"
          ]
        }
      },
      // we need this for now for jSX
      {
        className: "tag",
        begin: /<>|<\/>/
      },
      // open tag
      {
        className: "tag",
        begin: t.concat(
          /</,
          t.lookahead(t.concat(
            n,
            // <tag/>
            // <tag>
            // <tag ...
            t.either(/\/>/, />/, /\s/)
          ))
        ),
        end: /\/?>/,
        contains: [
          {
            className: "name",
            begin: n,
            relevance: 0,
            starts: l
          }
        ]
      },
      // close tag
      {
        className: "tag",
        begin: t.concat(
          /<\//,
          t.lookahead(t.concat(
            n,
            />/
          ))
        ),
        contains: [
          {
            className: "name",
            begin: n,
            relevance: 0
          },
          {
            begin: />/,
            relevance: 0,
            endsParent: !0
          }
        ]
      }
    ]
  };
}
function sf(e) {
  const t = "true false yes no null", n = "[\\w#;/?:@&=+$,.~*'()[\\]]+", a = {
    className: "attr",
    variants: [
      // added brackets support and special char support
      { begin: /[\w*@][\w*@ :()\./-]*:(?=[ \t]|$)/ },
      {
        // double quoted keys - with brackets and special char support
        begin: /"[\w*@][\w*@ :()\./-]*":(?=[ \t]|$)/
      },
      {
        // single quoted keys - with brackets and special char support
        begin: /'[\w*@][\w*@ :()\./-]*':(?=[ \t]|$)/
      }
    ]
  }, r = {
    className: "template-variable",
    variants: [
      {
        // jinja templates Ansible
        begin: /\{\{/,
        end: /\}\}/
      },
      {
        // Ruby i18n
        begin: /%\{/,
        end: /\}/
      }
    ]
  }, o = {
    className: "string",
    relevance: 0,
    begin: /'/,
    end: /'/,
    contains: [
      {
        match: /''/,
        scope: "char.escape",
        relevance: 0
      }
    ]
  }, s = {
    className: "string",
    relevance: 0,
    variants: [
      {
        begin: /"/,
        end: /"/
      },
      { begin: /\S+/ }
    ],
    contains: [
      e.BACKSLASH_ESCAPE,
      r
    ]
  }, i = e.inherit(s, { variants: [
    {
      begin: /'/,
      end: /'/,
      contains: [
        {
          begin: /''/,
          relevance: 0
        }
      ]
    },
    {
      begin: /"/,
      end: /"/
    },
    { begin: /[^\s,{}[\]]+/ }
  ] }), m = {
    className: "number",
    begin: "\\b" + "[0-9]{4}(-[0-9][0-9]){0,2}" + "([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?" + "(\\.[0-9]*)?" + "([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?" + "\\b"
  }, g = {
    end: ",",
    endsWithParent: !0,
    excludeEnd: !0,
    keywords: t,
    relevance: 0
  }, f = {
    begin: /\{/,
    end: /\}/,
    contains: [g],
    illegal: "\\n",
    relevance: 0
  }, b = {
    begin: "\\[",
    end: "\\]",
    contains: [g],
    illegal: "\\n",
    relevance: 0
  }, E = [
    a,
    {
      className: "meta",
      begin: "^---\\s*$",
      relevance: 10
    },
    {
      // multi line string
      // Blocks start with a | or > followed by a newline
      //
      // Indentation of subsequent lines must be the same to
      // be considered part of the block
      className: "string",
      begin: "[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*"
    },
    {
      // Ruby/Rails erb
      begin: "<%[%=-]?",
      end: "[%-]?%>",
      subLanguage: "ruby",
      excludeBegin: !0,
      excludeEnd: !0,
      relevance: 0
    },
    {
      // named tags
      className: "type",
      begin: "!\\w+!" + n
    },
    // https://yaml.org/spec/1.2/spec.html#id2784064
    {
      // verbatim tags
      className: "type",
      begin: "!<" + n + ">"
    },
    {
      // primary tags
      className: "type",
      begin: "!" + n
    },
    {
      // secondary tags
      className: "type",
      begin: "!!" + n
    },
    {
      // fragment id &ref
      className: "meta",
      begin: "&" + e.UNDERSCORE_IDENT_RE + "$"
    },
    {
      // fragment reference *ref
      className: "meta",
      begin: "\\*" + e.UNDERSCORE_IDENT_RE + "$"
    },
    {
      // array listing
      className: "bullet",
      // TODO: remove |$ hack when we have proper look-ahead support
      begin: "-(?=[ ]|$)",
      relevance: 0
    },
    e.HASH_COMMENT_MODE,
    {
      beginKeywords: t,
      keywords: { literal: t }
    },
    m,
    // numbers are any valid C-style number that
    // sit isolated from other words
    {
      className: "number",
      begin: e.C_NUMBER_RE + "\\b",
      relevance: 0
    },
    f,
    b,
    o,
    s
  ], _ = [...E];
  return _.pop(), _.push(i), g.contains = _, {
    name: "YAML",
    case_insensitive: !0,
    aliases: ["yml"],
    contains: E
  };
}
const gh = {
  arduino: Um,
  bash: Gm,
  c: Km,
  cpp: Vm,
  csharp: Wm,
  css: tp,
  diff: np,
  go: ap,
  graphql: rp,
  ini: op,
  java: sp,
  javascript: up,
  json: gp,
  kotlin: pp,
  less: kp,
  lua: vp,
  makefile: Tp,
  markdown: wp,
  objectivec: Np,
  perl: xp,
  php: Cp,
  "php-template": Ap,
  plaintext: Mp,
  python: Ip,
  "python-repl": Op,
  r: Lp,
  ruby: Rp,
  rust: Dp,
  scss: Kp,
  shell: Vp,
  sql: Wp,
  swift: ef,
  typescript: nf,
  vbnet: af,
  wasm: rf,
  xml: of,
  yaml: sf
};
var mh = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function cf(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var ua, uo;
function lf() {
  if (uo) return ua;
  uo = 1;
  function e(p) {
    return p instanceof Map ? p.clear = p.delete = p.set = function() {
      throw new Error("map is read-only");
    } : p instanceof Set && (p.add = p.clear = p.delete = function() {
      throw new Error("set is read-only");
    }), Object.freeze(p), Object.getOwnPropertyNames(p).forEach((h) => {
      const T = p[h], D = typeof T;
      (D === "object" || D === "function") && !Object.isFrozen(T) && e(T);
    }), p;
  }
  class t {
    /**
     * @param {CompiledMode} mode
     */
    constructor(h) {
      h.data === void 0 && (h.data = {}), this.data = h.data, this.isMatchIgnored = !1;
    }
    ignoreMatch() {
      this.isMatchIgnored = !0;
    }
  }
  function n(p) {
    return p.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
  }
  function a(p, ...h) {
    const T = /* @__PURE__ */ Object.create(null);
    for (const D in p)
      T[D] = p[D];
    return h.forEach(function(D) {
      for (const ce in D)
        T[ce] = D[ce];
    }), /** @type {T} */
    T;
  }
  const r = "</span>", o = (p) => !!p.scope, s = (p, { prefix: h }) => {
    if (p.startsWith("language:"))
      return p.replace("language:", "language-");
    if (p.includes(".")) {
      const T = p.split(".");
      return [
        `${h}${T.shift()}`,
        ...T.map((D, ce) => `${D}${"_".repeat(ce + 1)}`)
      ].join(" ");
    }
    return `${h}${p}`;
  };
  class i {
    /**
     * Creates a new HTMLRenderer
     *
     * @param {Tree} parseTree - the parse tree (must support `walk` API)
     * @param {{classPrefix: string}} options
     */
    constructor(h, T) {
      this.buffer = "", this.classPrefix = T.classPrefix, h.walk(this);
    }
    /**
     * Adds texts to the output stream
     *
     * @param {string} text */
    addText(h) {
      this.buffer += n(h);
    }
    /**
     * Adds a node open to the output stream (if needed)
     *
     * @param {Node} node */
    openNode(h) {
      if (!o(h)) return;
      const T = s(
        h.scope,
        { prefix: this.classPrefix }
      );
      this.span(T);
    }
    /**
     * Adds a node close to the output stream (if needed)
     *
     * @param {Node} node */
    closeNode(h) {
      o(h) && (this.buffer += r);
    }
    /**
     * returns the accumulated buffer
    */
    value() {
      return this.buffer;
    }
    // helpers
    /**
     * Builds a span element
     *
     * @param {string} className */
    span(h) {
      this.buffer += `<span class="${h}">`;
    }
  }
  const c = (p = {}) => {
    const h = { children: [] };
    return Object.assign(h, p), h;
  };
  class l {
    constructor() {
      this.rootNode = c(), this.stack = [this.rootNode];
    }
    get top() {
      return this.stack[this.stack.length - 1];
    }
    get root() {
      return this.rootNode;
    }
    /** @param {Node} node */
    add(h) {
      this.top.children.push(h);
    }
    /** @param {string} scope */
    openNode(h) {
      const T = c({ scope: h });
      this.add(T), this.stack.push(T);
    }
    closeNode() {
      if (this.stack.length > 1)
        return this.stack.pop();
    }
    closeAllNodes() {
      for (; this.closeNode(); ) ;
    }
    toJSON() {
      return JSON.stringify(this.rootNode, null, 4);
    }
    /**
     * @typedef { import("./html_renderer").Renderer } Renderer
     * @param {Renderer} builder
     */
    walk(h) {
      return this.constructor._walk(h, this.rootNode);
    }
    /**
     * @param {Renderer} builder
     * @param {Node} node
     */
    static _walk(h, T) {
      return typeof T == "string" ? h.addText(T) : T.children && (h.openNode(T), T.children.forEach((D) => this._walk(h, D)), h.closeNode(T)), h;
    }
    /**
     * @param {Node} node
     */
    static _collapse(h) {
      typeof h != "string" && h.children && (h.children.every((T) => typeof T == "string") ? h.children = [h.children.join("")] : h.children.forEach((T) => {
        l._collapse(T);
      }));
    }
  }
  class d extends l {
    /**
     * @param {*} options
     */
    constructor(h) {
      super(), this.options = h;
    }
    /**
     * @param {string} text
     */
    addText(h) {
      h !== "" && this.add(h);
    }
    /** @param {string} scope */
    startScope(h) {
      this.openNode(h);
    }
    endScope() {
      this.closeNode();
    }
    /**
     * @param {Emitter & {root: DataNode}} emitter
     * @param {string} name
     */
    __addSublanguage(h, T) {
      const D = h.root;
      T && (D.scope = `language:${T}`), this.add(D);
    }
    toHTML() {
      return new i(this, this.options).value();
    }
    finalize() {
      return this.closeAllNodes(), !0;
    }
  }
  function u(p) {
    return p ? typeof p == "string" ? p : p.source : null;
  }
  function m(p) {
    return b("(?=", p, ")");
  }
  function g(p) {
    return b("(?:", p, ")*");
  }
  function f(p) {
    return b("(?:", p, ")?");
  }
  function b(...p) {
    return p.map((T) => u(T)).join("");
  }
  function E(p) {
    const h = p[p.length - 1];
    return typeof h == "object" && h.constructor === Object ? (p.splice(p.length - 1, 1), h) : {};
  }
  function _(...p) {
    return "(" + (E(p).capture ? "" : "?:") + p.map((D) => u(D)).join("|") + ")";
  }
  function k(p) {
    return new RegExp(p.toString() + "|").exec("").length - 1;
  }
  function S(p, h) {
    const T = p && p.exec(h);
    return T && T.index === 0;
  }
  const y = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;
  function x(p, { joinWith: h }) {
    let T = 0;
    return p.map((D) => {
      T += 1;
      const ce = T;
      let le = u(D), A = "";
      for (; le.length > 0; ) {
        const N = y.exec(le);
        if (!N) {
          A += le;
          break;
        }
        A += le.substring(0, N.index), le = le.substring(N.index + N[0].length), N[0][0] === "\\" && N[1] ? A += "\\" + String(Number(N[1]) + ce) : (A += N[0], N[0] === "(" && T++);
      }
      return A;
    }).map((D) => `(${D})`).join(h);
  }
  const C = /\b\B/, O = "[a-zA-Z]\\w*", P = "[a-zA-Z_]\\w*", G = "\\b\\d+(\\.\\d+)?", K = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)", oe = "\\b(0b[01]+)", L = "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~", Z = (p = {}) => {
    const h = /^#![ ]*\//;
    return p.binary && (p.begin = b(
      h,
      /.*\b/,
      p.binary,
      /\b.*/
    )), a({
      scope: "meta",
      begin: h,
      end: /$/,
      relevance: 0,
      /** @type {ModeCallback} */
      "on:begin": (T, D) => {
        T.index !== 0 && D.ignoreMatch();
      }
    }, p);
  }, V = {
    begin: "\\\\[\\s\\S]",
    relevance: 0
  }, re = {
    scope: "string",
    begin: "'",
    end: "'",
    illegal: "\\n",
    contains: [V]
  }, be = {
    scope: "string",
    begin: '"',
    end: '"',
    illegal: "\\n",
    contains: [V]
  }, we = {
    begin: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/
  }, H = function(p, h, T = {}) {
    const D = a(
      {
        scope: "comment",
        begin: p,
        end: h,
        contains: []
      },
      T
    );
    D.contains.push({
      scope: "doctag",
      // hack to avoid the space from being included. the space is necessary to
      // match here to prevent the plain text rule below from gobbling up doctags
      begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
      end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
      excludeBegin: !0,
      relevance: 0
    });
    const ce = _(
      // list of common 1 and 2 letter words in English
      "I",
      "a",
      "is",
      "so",
      "us",
      "to",
      "at",
      "if",
      "in",
      "it",
      "on",
      // note: this is not an exhaustive list of contractions, just popular ones
      /[A-Za-z]+['](d|ve|re|ll|t|s|n)/,
      // contractions - can't we'd they're let's, etc
      /[A-Za-z]+[-][a-z]+/,
      // `no-way`, etc.
      /[A-Za-z][a-z]{2,}/
      // allow capitalized words at beginning of sentences
    );
    return D.contains.push(
      {
        // TODO: how to include ", (, ) without breaking grammars that use these for
        // comment delimiters?
        // begin: /[ ]+([()"]?([A-Za-z'-]{3,}|is|a|I|so|us|[tT][oO]|at|if|in|it|on)[.]?[()":]?([.][ ]|[ ]|\))){3}/
        // ---
        // this tries to find sequences of 3 english words in a row (without any
        // "programming" type syntax) this gives us a strong signal that we've
        // TRULY found a comment - vs perhaps scanning with the wrong language.
        // It's possible to find something that LOOKS like the start of the
        // comment - but then if there is no readable text - good chance it is a
        // false match and not a comment.
        //
        // for a visual example please see:
        // https://github.com/highlightjs/highlight.js/issues/2827
        begin: b(
          /[ ]+/,
          // necessary to prevent us gobbling up doctags like /* @author Bob Mcgill */
          "(",
          ce,
          /[.]?[:]?([.][ ]|[ ])/,
          "){3}"
        )
        // look for 3 words in a row
      }
    ), D;
  }, se = H("//", "$"), me = H("/\\*", "\\*/"), de = H("#", "$"), ue = {
    scope: "number",
    begin: G,
    relevance: 0
  }, Me = {
    scope: "number",
    begin: K,
    relevance: 0
  }, _t = {
    scope: "number",
    begin: oe,
    relevance: 0
  }, it = {
    scope: "regexp",
    begin: /\/(?=[^/\n]*\/)/,
    end: /\/[gimuy]*/,
    contains: [
      V,
      {
        begin: /\[/,
        end: /\]/,
        relevance: 0,
        contains: [V]
      }
    ]
  }, ie = {
    scope: "title",
    begin: O,
    relevance: 0
  }, J = {
    scope: "title",
    begin: P,
    relevance: 0
  }, Ne = {
    // excludes method names from keyword processing
    begin: "\\.\\s*" + P,
    relevance: 0
  };
  var Ke = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    APOS_STRING_MODE: re,
    BACKSLASH_ESCAPE: V,
    BINARY_NUMBER_MODE: _t,
    BINARY_NUMBER_RE: oe,
    COMMENT: H,
    C_BLOCK_COMMENT_MODE: me,
    C_LINE_COMMENT_MODE: se,
    C_NUMBER_MODE: Me,
    C_NUMBER_RE: K,
    END_SAME_AS_BEGIN: function(p) {
      return Object.assign(
        p,
        {
          /** @type {ModeCallback} */
          "on:begin": (h, T) => {
            T.data._beginMatch = h[1];
          },
          /** @type {ModeCallback} */
          "on:end": (h, T) => {
            T.data._beginMatch !== h[1] && T.ignoreMatch();
          }
        }
      );
    },
    HASH_COMMENT_MODE: de,
    IDENT_RE: O,
    MATCH_NOTHING_RE: C,
    METHOD_GUARD: Ne,
    NUMBER_MODE: ue,
    NUMBER_RE: G,
    PHRASAL_WORDS_MODE: we,
    QUOTE_STRING_MODE: be,
    REGEXP_MODE: it,
    RE_STARTERS_RE: L,
    SHEBANG: Z,
    TITLE_MODE: ie,
    UNDERSCORE_IDENT_RE: P,
    UNDERSCORE_TITLE_MODE: J
  });
  function je(p, h) {
    p.input[p.index - 1] === "." && h.ignoreMatch();
  }
  function Be(p, h) {
    p.className !== void 0 && (p.scope = p.className, delete p.className);
  }
  function zn(p, h) {
    h && p.beginKeywords && (p.begin = "\\b(" + p.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", p.__beforeBegin = je, p.keywords = p.keywords || p.beginKeywords, delete p.beginKeywords, p.relevance === void 0 && (p.relevance = 0));
  }
  function Hn(p, h) {
    Array.isArray(p.illegal) && (p.illegal = _(...p.illegal));
  }
  function $n(p, h) {
    if (p.match) {
      if (p.begin || p.end) throw new Error("begin & end are not supported with match");
      p.begin = p.match, delete p.match;
    }
  }
  function Y(p, h) {
    p.relevance === void 0 && (p.relevance = 1);
  }
  const St = (p, h) => {
    if (!p.beforeMatch) return;
    if (p.starts) throw new Error("beforeMatch cannot be used with starts");
    const T = Object.assign({}, p);
    Object.keys(p).forEach((D) => {
      delete p[D];
    }), p.keywords = T.keywords, p.begin = b(T.beforeMatch, m(T.begin)), p.starts = {
      relevance: 0,
      contains: [
        Object.assign(T, { endsParent: !0 })
      ]
    }, p.relevance = 0, delete T.beforeMatch;
  }, ct = [
    "of",
    "and",
    "for",
    "in",
    "not",
    "or",
    "if",
    "then",
    "parent",
    // common variable name
    "list",
    // common variable name
    "value"
    // common variable name
  ], Un = "keyword";
  function or(p, h, T = Un) {
    const D = /* @__PURE__ */ Object.create(null);
    return typeof p == "string" ? ce(T, p.split(" ")) : Array.isArray(p) ? ce(T, p) : Object.keys(p).forEach(function(le) {
      Object.assign(
        D,
        or(p[le], h, le)
      );
    }), D;
    function ce(le, A) {
      h && (A = A.map((N) => N.toLowerCase())), A.forEach(function(N) {
        const R = N.split("|");
        D[R[0]] = [le, xi(R[0], R[1])];
      });
    }
  }
  function xi(p, h) {
    return h ? Number(h) : Ci(p) ? 0 : 1;
  }
  function Ci(p) {
    return ct.includes(p.toLowerCase());
  }
  const sr = {}, lt = (p) => {
    console.error(p);
  }, ir = (p, ...h) => {
    console.log(`WARN: ${p}`, ...h);
  }, kt = (p, h) => {
    sr[`${p}/${h}`] || (console.log(`Deprecated as of ${p}. ${h}`), sr[`${p}/${h}`] = !0);
  }, Jt = new Error();
  function cr(p, h, { key: T }) {
    let D = 0;
    const ce = p[T], le = {}, A = {};
    for (let N = 1; N <= h.length; N++)
      A[N + D] = ce[N], le[N + D] = !0, D += k(h[N - 1]);
    p[T] = A, p[T]._emit = le, p[T]._multi = !0;
  }
  function Ai(p) {
    if (Array.isArray(p.begin)) {
      if (p.skip || p.excludeBegin || p.returnBegin)
        throw lt("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), Jt;
      if (typeof p.beginScope != "object" || p.beginScope === null)
        throw lt("beginScope must be object"), Jt;
      cr(p, p.begin, { key: "beginScope" }), p.begin = x(p.begin, { joinWith: "" });
    }
  }
  function Mi(p) {
    if (Array.isArray(p.end)) {
      if (p.skip || p.excludeEnd || p.returnEnd)
        throw lt("skip, excludeEnd, returnEnd not compatible with endScope: {}"), Jt;
      if (typeof p.endScope != "object" || p.endScope === null)
        throw lt("endScope must be object"), Jt;
      cr(p, p.end, { key: "endScope" }), p.end = x(p.end, { joinWith: "" });
    }
  }
  function Ii(p) {
    p.scope && typeof p.scope == "object" && p.scope !== null && (p.beginScope = p.scope, delete p.scope);
  }
  function Oi(p) {
    Ii(p), typeof p.beginScope == "string" && (p.beginScope = { _wrap: p.beginScope }), typeof p.endScope == "string" && (p.endScope = { _wrap: p.endScope }), Ai(p), Mi(p);
  }
  function Li(p) {
    function h(A, N) {
      return new RegExp(
        u(A),
        "m" + (p.case_insensitive ? "i" : "") + (p.unicodeRegex ? "u" : "") + (N ? "g" : "")
      );
    }
    class T {
      constructor() {
        this.matchIndexes = {}, this.regexes = [], this.matchAt = 1, this.position = 0;
      }
      // @ts-ignore
      addRule(N, R) {
        R.position = this.position++, this.matchIndexes[this.matchAt] = R, this.regexes.push([R, N]), this.matchAt += k(N) + 1;
      }
      compile() {
        this.regexes.length === 0 && (this.exec = () => null);
        const N = this.regexes.map((R) => R[1]);
        this.matcherRe = h(x(N, { joinWith: "|" }), !0), this.lastIndex = 0;
      }
      /** @param {string} s */
      exec(N) {
        this.matcherRe.lastIndex = this.lastIndex;
        const R = this.matcherRe.exec(N);
        if (!R)
          return null;
        const fe = R.findIndex((Pt, Kn) => Kn > 0 && Pt !== void 0), ge = this.matchIndexes[fe];
        return R.splice(0, fe), Object.assign(R, ge);
      }
    }
    class D {
      constructor() {
        this.rules = [], this.multiRegexes = [], this.count = 0, this.lastIndex = 0, this.regexIndex = 0;
      }
      // @ts-ignore
      getMatcher(N) {
        if (this.multiRegexes[N]) return this.multiRegexes[N];
        const R = new T();
        return this.rules.slice(N).forEach(([fe, ge]) => R.addRule(fe, ge)), R.compile(), this.multiRegexes[N] = R, R;
      }
      resumingScanAtSamePosition() {
        return this.regexIndex !== 0;
      }
      considerAll() {
        this.regexIndex = 0;
      }
      // @ts-ignore
      addRule(N, R) {
        this.rules.push([N, R]), R.type === "begin" && this.count++;
      }
      /** @param {string} s */
      exec(N) {
        const R = this.getMatcher(this.regexIndex);
        R.lastIndex = this.lastIndex;
        let fe = R.exec(N);
        if (this.resumingScanAtSamePosition() && !(fe && fe.index === this.lastIndex)) {
          const ge = this.getMatcher(0);
          ge.lastIndex = this.lastIndex + 1, fe = ge.exec(N);
        }
        return fe && (this.regexIndex += fe.position + 1, this.regexIndex === this.count && this.considerAll()), fe;
      }
    }
    function ce(A) {
      const N = new D();
      return A.contains.forEach((R) => N.addRule(R.begin, { rule: R, type: "begin" })), A.terminatorEnd && N.addRule(A.terminatorEnd, { type: "end" }), A.illegal && N.addRule(A.illegal, { type: "illegal" }), N;
    }
    function le(A, N) {
      const R = (
        /** @type CompiledMode */
        A
      );
      if (A.isCompiled) return R;
      [
        Be,
        // do this early so compiler extensions generally don't have to worry about
        // the distinction between match/begin
        $n,
        Oi,
        St
      ].forEach((ge) => ge(A, N)), p.compilerExtensions.forEach((ge) => ge(A, N)), A.__beforeBegin = null, [
        zn,
        // do this later so compiler extensions that come earlier have access to the
        // raw array if they wanted to perhaps manipulate it, etc.
        Hn,
        // default to 1 relevance if not specified
        Y
      ].forEach((ge) => ge(A, N)), A.isCompiled = !0;
      let fe = null;
      return typeof A.keywords == "object" && A.keywords.$pattern && (A.keywords = Object.assign({}, A.keywords), fe = A.keywords.$pattern, delete A.keywords.$pattern), fe = fe || /\w+/, A.keywords && (A.keywords = or(A.keywords, p.case_insensitive)), R.keywordPatternRe = h(fe, !0), N && (A.begin || (A.begin = /\B|\b/), R.beginRe = h(R.begin), !A.end && !A.endsWithParent && (A.end = /\B|\b/), A.end && (R.endRe = h(R.end)), R.terminatorEnd = u(R.end) || "", A.endsWithParent && N.terminatorEnd && (R.terminatorEnd += (A.end ? "|" : "") + N.terminatorEnd)), A.illegal && (R.illegalRe = h(
        /** @type {RegExp | string} */
        A.illegal
      )), A.contains || (A.contains = []), A.contains = [].concat(...A.contains.map(function(ge) {
        return Ri(ge === "self" ? A : ge);
      })), A.contains.forEach(function(ge) {
        le(
          /** @type Mode */
          ge,
          R
        );
      }), A.starts && le(A.starts, N), R.matcher = ce(R), R;
    }
    if (p.compilerExtensions || (p.compilerExtensions = []), p.contains && p.contains.includes("self"))
      throw new Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation.");
    return p.classNameAliases = a(p.classNameAliases || {}), le(
      /** @type Mode */
      p
    );
  }
  function lr(p) {
    return p ? p.endsWithParent || lr(p.starts) : !1;
  }
  function Ri(p) {
    return p.variants && !p.cachedVariants && (p.cachedVariants = p.variants.map(function(h) {
      return a(p, { variants: null }, h);
    })), p.cachedVariants ? p.cachedVariants : lr(p) ? a(p, { starts: p.starts ? a(p.starts) : null }) : Object.isFrozen(p) ? a(p) : p;
  }
  var Di = "11.11.1";
  class Bi extends Error {
    constructor(h, T) {
      super(h), this.name = "HTMLInjectionError", this.html = T;
    }
  }
  const Gn = n, dr = a, ur = Symbol("nomatch"), Pi = 7, gr = function(p) {
    const h = /* @__PURE__ */ Object.create(null), T = /* @__PURE__ */ Object.create(null), D = [];
    let ce = !0;
    const le = "Could not find the language '{}', did you forget to load/include a language module?", A = { disableAutodetect: !0, name: "Plain text", contains: [] };
    let N = {
      ignoreUnescapedHTML: !1,
      throwUnescapedHTML: !1,
      noHighlightRe: /^(no-?highlight)$/i,
      languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
      classPrefix: "hljs-",
      cssSelector: "pre code",
      languages: null,
      // beta configuration options, subject to change, welcome to discuss
      // https://github.com/highlightjs/highlight.js/issues/1086
      __emitter: d
    };
    function R(v) {
      return N.noHighlightRe.test(v);
    }
    function fe(v) {
      let I = v.className + " ";
      I += v.parentNode ? v.parentNode.className : "";
      const $ = N.languageDetectRe.exec(I);
      if ($) {
        const j = Qe($[1]);
        return j || (ir(le.replace("{}", $[1])), ir("Falling back to no-highlight mode for this block.", v)), j ? $[1] : "no-highlight";
      }
      return I.split(/\s+/).find((j) => R(j) || Qe(j));
    }
    function ge(v, I, $) {
      let j = "", pe = "";
      typeof I == "object" ? (j = v, $ = I.ignoreIllegals, pe = I.language) : (kt("10.7.0", "highlight(lang, code, ...args) has been deprecated."), kt("10.7.0", `Please use highlight(code, options) instead.
https://github.com/highlightjs/highlight.js/issues/2277`), pe = v, j = I), $ === void 0 && ($ = !0);
      const De = {
        code: j,
        language: pe
      };
      Qt("before:highlight", De);
      const et = De.result ? De.result : Pt(De.language, De.code, $);
      return et.code = De.code, Qt("after:highlight", et), et;
    }
    function Pt(v, I, $, j) {
      const pe = /* @__PURE__ */ Object.create(null);
      function De(w, M) {
        return w.keywords[M];
      }
      function et() {
        if (!B.keywords) {
          he.addText(Q);
          return;
        }
        let w = 0;
        B.keywordPatternRe.lastIndex = 0;
        let M = B.keywordPatternRe.exec(Q), F = "";
        for (; M; ) {
          F += Q.substring(w, M.index);
          const W = Fe.case_insensitive ? M[0].toLowerCase() : M[0], ye = De(B, W);
          if (ye) {
            const [Ve, ec] = ye;
            if (he.addText(F), F = "", pe[W] = (pe[W] || 0) + 1, pe[W] <= Pi && (nn += ec), Ve.startsWith("_"))
              F += M[0];
            else {
              const tc = Fe.classNameAliases[Ve] || Ve;
              Pe(M[0], tc);
            }
          } else
            F += M[0];
          w = B.keywordPatternRe.lastIndex, M = B.keywordPatternRe.exec(Q);
        }
        F += Q.substring(w), he.addText(F);
      }
      function en() {
        if (Q === "") return;
        let w = null;
        if (typeof B.subLanguage == "string") {
          if (!h[B.subLanguage]) {
            he.addText(Q);
            return;
          }
          w = Pt(B.subLanguage, Q, !0, _r[B.subLanguage]), _r[B.subLanguage] = /** @type {CompiledMode} */
          w._top;
        } else
          w = Vn(Q, B.subLanguage.length ? B.subLanguage : null);
        B.relevance > 0 && (nn += w.relevance), he.__addSublanguage(w._emitter, w.language);
      }
      function xe() {
        B.subLanguage != null ? en() : et(), Q = "";
      }
      function Pe(w, M) {
        w !== "" && (he.startScope(M), he.addText(w), he.endScope());
      }
      function br(w, M) {
        let F = 1;
        const W = M.length - 1;
        for (; F <= W; ) {
          if (!w._emit[F]) {
            F++;
            continue;
          }
          const ye = Fe.classNameAliases[w[F]] || w[F], Ve = M[F];
          ye ? Pe(Ve, ye) : (Q = Ve, et(), Q = ""), F++;
        }
      }
      function hr(w, M) {
        return w.scope && typeof w.scope == "string" && he.openNode(Fe.classNameAliases[w.scope] || w.scope), w.beginScope && (w.beginScope._wrap ? (Pe(Q, Fe.classNameAliases[w.beginScope._wrap] || w.beginScope._wrap), Q = "") : w.beginScope._multi && (br(w.beginScope, M), Q = "")), B = Object.create(w, { parent: { value: B } }), B;
      }
      function yr(w, M, F) {
        let W = S(w.endRe, F);
        if (W) {
          if (w["on:end"]) {
            const ye = new t(w);
            w["on:end"](M, ye), ye.isMatchIgnored && (W = !1);
          }
          if (W) {
            for (; w.endsParent && w.parent; )
              w = w.parent;
            return w;
          }
        }
        if (w.endsWithParent)
          return yr(w.parent, M, F);
      }
      function Xi(w) {
        return B.matcher.regexIndex === 0 ? (Q += w[0], 1) : (Xn = !0, 0);
      }
      function Zi(w) {
        const M = w[0], F = w.rule, W = new t(F), ye = [F.__beforeBegin, F["on:begin"]];
        for (const Ve of ye)
          if (Ve && (Ve(w, W), W.isMatchIgnored))
            return Xi(M);
        return F.skip ? Q += M : (F.excludeBegin && (Q += M), xe(), !F.returnBegin && !F.excludeBegin && (Q = M)), hr(F, w), F.returnBegin ? 0 : M.length;
      }
      function Ji(w) {
        const M = w[0], F = I.substring(w.index), W = yr(B, w, F);
        if (!W)
          return ur;
        const ye = B;
        B.endScope && B.endScope._wrap ? (xe(), Pe(M, B.endScope._wrap)) : B.endScope && B.endScope._multi ? (xe(), br(B.endScope, w)) : ye.skip ? Q += M : (ye.returnEnd || ye.excludeEnd || (Q += M), xe(), ye.excludeEnd && (Q = M));
        do
          B.scope && he.closeNode(), !B.skip && !B.subLanguage && (nn += B.relevance), B = B.parent;
        while (B !== W.parent);
        return W.starts && hr(W.starts, w), ye.returnEnd ? 0 : M.length;
      }
      function ji() {
        const w = [];
        for (let M = B; M !== Fe; M = M.parent)
          M.scope && w.unshift(M.scope);
        w.forEach((M) => he.openNode(M));
      }
      let tn = {};
      function Er(w, M) {
        const F = M && M[0];
        if (Q += w, F == null)
          return xe(), 0;
        if (tn.type === "begin" && M.type === "end" && tn.index === M.index && F === "") {
          if (Q += I.slice(M.index, M.index + 1), !ce) {
            const W = new Error(`0 width match regex (${v})`);
            throw W.languageName = v, W.badRule = tn.rule, W;
          }
          return 1;
        }
        if (tn = M, M.type === "begin")
          return Zi(M);
        if (M.type === "illegal" && !$) {
          const W = new Error('Illegal lexeme "' + F + '" for mode "' + (B.scope || "<unnamed>") + '"');
          throw W.mode = B, W;
        } else if (M.type === "end") {
          const W = Ji(M);
          if (W !== ur)
            return W;
        }
        if (M.type === "illegal" && F === "")
          return Q += `
`, 1;
        if (Yn > 1e5 && Yn > M.index * 3)
          throw new Error("potential infinite loop, way more iterations than matches");
        return Q += F, F.length;
      }
      const Fe = Qe(v);
      if (!Fe)
        throw lt(le.replace("{}", v)), new Error('Unknown language: "' + v + '"');
      const Qi = Li(Fe);
      let qn = "", B = j || Qi;
      const _r = {}, he = new N.__emitter(N);
      ji();
      let Q = "", nn = 0, dt = 0, Yn = 0, Xn = !1;
      try {
        if (Fe.__emitTokens)
          Fe.__emitTokens(I, he);
        else {
          for (B.matcher.considerAll(); ; ) {
            Yn++, Xn ? Xn = !1 : B.matcher.considerAll(), B.matcher.lastIndex = dt;
            const w = B.matcher.exec(I);
            if (!w) break;
            const M = I.substring(dt, w.index), F = Er(M, w);
            dt = w.index + F;
          }
          Er(I.substring(dt));
        }
        return he.finalize(), qn = he.toHTML(), {
          language: v,
          value: qn,
          relevance: nn,
          illegal: !1,
          _emitter: he,
          _top: B
        };
      } catch (w) {
        if (w.message && w.message.includes("Illegal"))
          return {
            language: v,
            value: Gn(I),
            illegal: !0,
            relevance: 0,
            _illegalBy: {
              message: w.message,
              index: dt,
              context: I.slice(dt - 100, dt + 100),
              mode: w.mode,
              resultSoFar: qn
            },
            _emitter: he
          };
        if (ce)
          return {
            language: v,
            value: Gn(I),
            illegal: !1,
            relevance: 0,
            errorRaised: w,
            _emitter: he,
            _top: B
          };
        throw w;
      }
    }
    function Kn(v) {
      const I = {
        value: Gn(v),
        illegal: !1,
        relevance: 0,
        _top: A,
        _emitter: new N.__emitter(N)
      };
      return I._emitter.addText(v), I;
    }
    function Vn(v, I) {
      I = I || N.languages || Object.keys(h);
      const $ = Kn(v), j = I.filter(Qe).filter(fr).map(
        (xe) => Pt(xe, v, !1)
      );
      j.unshift($);
      const pe = j.sort((xe, Pe) => {
        if (xe.relevance !== Pe.relevance) return Pe.relevance - xe.relevance;
        if (xe.language && Pe.language) {
          if (Qe(xe.language).supersetOf === Pe.language)
            return 1;
          if (Qe(Pe.language).supersetOf === xe.language)
            return -1;
        }
        return 0;
      }), [De, et] = pe, en = De;
      return en.secondBest = et, en;
    }
    function Fi(v, I, $) {
      const j = I && T[I] || $;
      v.classList.add("hljs"), v.classList.add(`language-${j}`);
    }
    function Wn(v) {
      let I = null;
      const $ = fe(v);
      if (R($)) return;
      if (Qt(
        "before:highlightElement",
        { el: v, language: $ }
      ), v.dataset.highlighted) {
        console.log("Element previously highlighted. To highlight again, first unset `dataset.highlighted`.", v);
        return;
      }
      if (v.children.length > 0 && (N.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(v)), N.throwUnescapedHTML))
        throw new Bi(
          "One of your code blocks includes unescaped HTML.",
          v.innerHTML
        );
      I = v;
      const j = I.textContent, pe = $ ? ge(j, { language: $, ignoreIllegals: !0 }) : Vn(j);
      v.innerHTML = pe.value, v.dataset.highlighted = "yes", Fi(v, $, pe.language), v.result = {
        language: pe.language,
        // TODO: remove with version 11.0
        re: pe.relevance,
        relevance: pe.relevance
      }, pe.secondBest && (v.secondBest = {
        language: pe.secondBest.language,
        relevance: pe.secondBest.relevance
      }), Qt("after:highlightElement", { el: v, result: pe, text: j });
    }
    function zi(v) {
      N = dr(N, v);
    }
    const Hi = () => {
      jt(), kt("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now.");
    };
    function $i() {
      jt(), kt("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now.");
    }
    let mr = !1;
    function jt() {
      function v() {
        jt();
      }
      if (document.readyState === "loading") {
        mr || window.addEventListener("DOMContentLoaded", v, !1), mr = !0;
        return;
      }
      document.querySelectorAll(N.cssSelector).forEach(Wn);
    }
    function Ui(v, I) {
      let $ = null;
      try {
        $ = I(p);
      } catch (j) {
        if (lt("Language definition for '{}' could not be registered.".replace("{}", v)), ce)
          lt(j);
        else
          throw j;
        $ = A;
      }
      $.name || ($.name = v), h[v] = $, $.rawDefinition = I.bind(null, p), $.aliases && pr($.aliases, { languageName: v });
    }
    function Gi(v) {
      delete h[v];
      for (const I of Object.keys(T))
        T[I] === v && delete T[I];
    }
    function Ki() {
      return Object.keys(h);
    }
    function Qe(v) {
      return v = (v || "").toLowerCase(), h[v] || h[T[v]];
    }
    function pr(v, { languageName: I }) {
      typeof v == "string" && (v = [v]), v.forEach(($) => {
        T[$.toLowerCase()] = I;
      });
    }
    function fr(v) {
      const I = Qe(v);
      return I && !I.disableAutodetect;
    }
    function Vi(v) {
      v["before:highlightBlock"] && !v["before:highlightElement"] && (v["before:highlightElement"] = (I) => {
        v["before:highlightBlock"](
          Object.assign({ block: I.el }, I)
        );
      }), v["after:highlightBlock"] && !v["after:highlightElement"] && (v["after:highlightElement"] = (I) => {
        v["after:highlightBlock"](
          Object.assign({ block: I.el }, I)
        );
      });
    }
    function Wi(v) {
      Vi(v), D.push(v);
    }
    function qi(v) {
      const I = D.indexOf(v);
      I !== -1 && D.splice(I, 1);
    }
    function Qt(v, I) {
      const $ = v;
      D.forEach(function(j) {
        j[$] && j[$](I);
      });
    }
    function Yi(v) {
      return kt("10.7.0", "highlightBlock will be removed entirely in v12.0"), kt("10.7.0", "Please use highlightElement now."), Wn(v);
    }
    Object.assign(p, {
      highlight: ge,
      highlightAuto: Vn,
      highlightAll: jt,
      highlightElement: Wn,
      // TODO: Remove with v12 API
      highlightBlock: Yi,
      configure: zi,
      initHighlighting: Hi,
      initHighlightingOnLoad: $i,
      registerLanguage: Ui,
      unregisterLanguage: Gi,
      listLanguages: Ki,
      getLanguage: Qe,
      registerAliases: pr,
      autoDetection: fr,
      inherit: dr,
      addPlugin: Wi,
      removePlugin: qi
    }), p.debugMode = function() {
      ce = !1;
    }, p.safeMode = function() {
      ce = !0;
    }, p.versionString = Di, p.regex = {
      concat: b,
      lookahead: m,
      either: _,
      optional: f,
      anyNumberOfTimes: g
    };
    for (const v in Ke)
      typeof Ke[v] == "object" && e(Ke[v]);
    return Object.assign(p, Ke), p;
  }, vt = gr({});
  return vt.newInstance = () => gr({}), ua = vt, vt.HighlightJS = vt, vt.default = vt, ua;
}
var df = /* @__PURE__ */ lf();
const uf = /* @__PURE__ */ cf(df), go = {}, gf = "hljs-";
function ph(e) {
  const t = uf.newInstance();
  return e && o(e), {
    highlight: n,
    highlightAuto: a,
    listLanguages: r,
    register: o,
    registerAlias: s,
    registered: i
  };
  function n(c, l, d) {
    const u = d || go, m = typeof u.prefix == "string" ? u.prefix : gf;
    if (!t.getLanguage(c))
      throw new Error("Unknown language: `" + c + "` is not registered");
    t.configure({ __emitter: mf, classPrefix: m });
    const g = (
      /** @type {HighlightResult & {_emitter: HastEmitter}} */
      t.highlight(l, { ignoreIllegals: !0, language: c })
    );
    if (g.errorRaised)
      throw new Error("Could not highlight with `Highlight.js`", {
        cause: g.errorRaised
      });
    const f = g._emitter.root, b = (
      /** @type {RootData} */
      f.data
    );
    return b.language = g.language, b.relevance = g.relevance, f;
  }
  function a(c, l) {
    const u = (l || go).subset || r();
    let m = -1, g = 0, f;
    for (; ++m < u.length; ) {
      const b = u[m];
      if (!t.getLanguage(b)) continue;
      const E = n(b, c, l);
      E.data && E.data.relevance !== void 0 && E.data.relevance > g && (g = E.data.relevance, f = E);
    }
    return f || {
      type: "root",
      children: [],
      data: { language: void 0, relevance: g }
    };
  }
  function r() {
    return t.listLanguages();
  }
  function o(c, l) {
    if (typeof c == "string")
      t.registerLanguage(c, l);
    else {
      let d;
      for (d in c)
        Object.hasOwn(c, d) && t.registerLanguage(d, c[d]);
    }
  }
  function s(c, l) {
    if (typeof c == "string")
      t.registerAliases(
        // Note: copy needed because hljs doesn’t accept readonly arrays yet.
        typeof l == "string" ? l : [...l],
        { languageName: c }
      );
    else {
      let d;
      for (d in c)
        if (Object.hasOwn(c, d)) {
          const u = c[d];
          t.registerAliases(
            // Note: copy needed because hljs doesn’t accept readonly arrays yet.
            typeof u == "string" ? u : [...u],
            { languageName: d }
          );
        }
    }
  }
  function i(c) {
    return !!t.getLanguage(c);
  }
}
class mf {
  /**
   * @param {Readonly<HljsOptions>} options
   *   Configuration.
   * @returns
   *   Instance.
   */
  constructor(t) {
    this.options = t, this.root = {
      type: "root",
      children: [],
      data: { language: void 0, relevance: 0 }
    }, this.stack = [this.root];
  }
  /**
   * @param {string} value
   *   Text to add.
   * @returns {undefined}
   *   Nothing.
   *
   */
  addText(t) {
    if (t === "") return;
    const n = this.stack[this.stack.length - 1], a = n.children[n.children.length - 1];
    a && a.type === "text" ? a.value += t : n.children.push({ type: "text", value: t });
  }
  /**
   *
   * @param {unknown} rawName
   *   Name to add.
   * @returns {undefined}
   *   Nothing.
   */
  startScope(t) {
    this.openNode(String(t));
  }
  /**
   * @returns {undefined}
   *   Nothing.
   */
  endScope() {
    this.closeNode();
  }
  /**
   * @param {HastEmitter} other
   *   Other emitter.
   * @param {string} name
   *   Name of the sublanguage.
   * @returns {undefined}
   *   Nothing.
   */
  __addSublanguage(t, n) {
    const a = this.stack[this.stack.length - 1], r = (
      /** @type {Array<ElementContent>} */
      t.root.children
    );
    n ? a.children.push({
      type: "element",
      tagName: "span",
      properties: { className: [n] },
      children: r
    }) : a.children.push(...r);
  }
  /**
   * @param {string} name
   *   Name to add.
   * @returns {undefined}
   *   Nothing.
   */
  openNode(t) {
    const n = this, a = t.split(".").map(function(s, i) {
      return i ? s + "_".repeat(i) : n.options.classPrefix + s;
    }), r = this.stack[this.stack.length - 1], o = {
      type: "element",
      tagName: "span",
      properties: { className: a },
      children: []
    };
    r.children.push(o), this.stack.push(o);
  }
  /**
   * @returns {undefined}
   *   Nothing.
   */
  closeNode() {
    this.stack.pop();
  }
  /**
   * @returns {undefined}
   *   Nothing.
   */
  finalize() {
  }
  /**
   * @returns {string}
   *   Nothing.
   */
  toHTML() {
    return "";
  }
}
const pf = (e) => (t) => {
  if (!t.endsWith(" ") && !t.endsWith(" "))
    return null;
  const a = new RegExp(`^(#{${e}})( |\\u00A0)$`).exec(t);
  return a ? {
    index: 0,
    text: a[0]
  } : null;
}, fh = Bc.extend({
  addInputRules() {
    return this.options.levels.map((e) => nc({
      find: pf(e),
      type: this.type,
      getAttributes: { level: e }
    }));
  }
}), ff = ae.create({
  name: "textEditorSchemaKernelBinding",
  addStorage() {
    return {
      schemaKernel: {
        id: Xe.schemaKernelId,
        version: Xe.schemaKernelVersion,
        fingerprint: Xe.schemaKernelFingerprint
      }
    };
  },
  extendNodeSchema(e) {
    const t = Xe.nodes.find(
      (n) => n.key === e.name
    );
    return t ? {
      zxSchemaKernel: {
        key: t.key,
        version: Xe.schemaKernelVersion
      }
    } : {};
  },
  extendMarkSchema(e) {
    const t = Xe.marks.find(
      (n) => n.key === e.name
    );
    return t ? {
      zxSchemaKernel: {
        key: t.key,
        version: Xe.schemaKernelVersion
      }
    } : {};
  }
}), mo = (e, t) => {
  const n = (t == null ? void 0 : t()) ?? {}, a = Object.keys(n), r = e.attrs.map((s) => s.name), o = a.filter((s) => !r.includes(s));
  if (o.length > 0)
    throw new TypeError(
      `Tiptap extension "${e.key}" declares attrs outside schema kernel: ${o.join(", ")}.`
    );
  return Object.fromEntries(
    e.attrs.map((s) => [
      s.name,
      {
        ...n[s.name] ?? {},
        default: s.default,
        validate: Nc(s.validator)
      }
    ])
  );
}, yi = (e) => {
  const t = Xe.nodes.find(
    (a) => a.key === e.name
  );
  if (t)
    return e.extend({
      priority: 1e3 - t.order,
      content: t.content,
      group: t.group,
      marks: t.marks,
      inline: t.inline,
      atom: t.atom,
      isolating: t.isolating,
      defining: t.defining,
      selectable: t.selectable,
      draggable: t.draggable,
      code: t.code,
      whitespace: t.whitespace,
      linebreakReplacement: t.linebreakReplacement,
      addAttributes() {
        return mo(t, this.parent);
      }
    });
  const n = Xe.marks.find(
    (a) => a.key === e.name
  );
  return n ? e.extend({
    priority: 1e3 - n.order,
    group: n.group,
    excludes: n.excludes,
    inclusive: n.inclusive,
    spanning: n.spanning,
    code: n.code,
    addAttributes() {
      return mo(n, this.parent);
    }
  }) : e.type === "extension" && typeof e.config.addExtensions == "function" ? e.extend({
    addExtensions() {
      var r;
      return (((r = this.parent) == null ? void 0 : r.call(this)) ?? []).map(yi);
    }
  }) : e;
}, bh = (e) => [
  ff,
  ...e.map(yi)
], bf = [
  "application/zip",
  "application/x-zip-compressed",
  "application/x-tar",
  "application/x-7z-compressed",
  "application/x-rar-compressed"
], hf = [
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/csv"
], yf = [
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation"
], Ef = [
  "application/json",
  "application/xml",
  "application/javascript",
  "application/x-javascript",
  "application/x-typescript"
], _f = ["text/markdown", "text/plain"], Sf = (e) => typeof e == "string" && e.trim().length > 0, Ut = (e) => Sf(e) ? e.trim() : null, po = (e) => typeof e == "number" && Number.isFinite(e) ? e : typeof e == "string" && /^\d+(?:\.\d+)?$/.test(e.trim()) ? Number.parseFloat(e.trim()) : null, Ei = (e) => {
  var t;
  if (!e)
    return null;
  try {
    const a = new URL(e).pathname.split("/").filter(Boolean);
    return a.length ? decodeURIComponent(a.at(-1)) : null;
  } catch {
    const a = (((t = e.split("?")[0]) == null ? void 0 : t.split("#")[0]) ?? e).split("/").filter(Boolean);
    return a.length ? decodeURIComponent(a.at(-1)) : null;
  }
}, _i = (e, t) => {
  var r;
  const n = e ?? Ei(t);
  if (!n || !n.includes("."))
    return null;
  const a = ((r = n.split(".").at(-1)) == null ? void 0 : r.trim().toLowerCase()) ?? null;
  return a && a.length <= 8 ? a : null;
}, Gt = (e, t) => t.some((n) => e.startsWith(n)), kf = (e, t, n) => {
  const a = (e == null ? void 0 : e.toLowerCase()) ?? null, r = _i(t, n);
  return a === "application/pdf" || r === "pdf" ? "pdf" : a != null && a.startsWith("image/") ? "image" : a != null && a.startsWith("video/") ? "video" : a != null && a.startsWith("audio/") ? "audio" : a && Gt(a, bf) || ["zip", "rar", "7z", "tar", "gz", "bz2"].includes(r ?? "") ? "archive" : a && Gt(a, hf) || ["xls", "xlsx", "csv", "numbers"].includes(r ?? "") ? "spreadsheet" : a && Gt(a, yf) || ["ppt", "pptx", "key"].includes(r ?? "") ? "presentation" : a && Gt(a, Ef) || [
    "js",
    "jsx",
    "ts",
    "tsx",
    "json",
    "xml",
    "yaml",
    "yml",
    "html",
    "css",
    "scss",
    "md"
  ].includes(r ?? "") ? "code" : a && Gt(a, _f) || ["txt", "md", "rtf"].includes(r ?? "") ? "text" : a === "application/msword" || a === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || ["doc", "docx", "pages"].includes(r ?? "") ? "document" : "file";
}, hh = (e) => {
  switch (e) {
    case "pdf":
      return "lucide:file-text";
    case "image":
      return "lucide:image";
    case "video":
      return "lucide:film";
    case "audio":
      return "lucide:music-4";
    case "archive":
      return "lucide:archive";
    case "spreadsheet":
      return "lucide:sheet";
    case "presentation":
      return "lucide:presentation";
    case "code":
      return "lucide:file-code-2";
    case "text":
      return "lucide:file-terminal";
    case "document":
      return "lucide:file-text";
    default:
      return "lucide:paperclip";
  }
}, vf = (e) => {
  if (typeof e != "number" || !Number.isFinite(e) || e < 0)
    return null;
  if (e < 1024)
    return `${Math.round(e)} B`;
  const t = ["KB", "MB", "GB", "TB"];
  let n = e / 1024, a = 0;
  for (; n >= 1024 && a < t.length - 1; )
    n /= 1024, a += 1;
  return `${n >= 100 ? Math.round(n) : Math.round(n * 10) / 10} ${t[a]}`;
}, Tf = (e, t) => {
  if (e === "file" && t)
    return t.toUpperCase();
  switch (e) {
    case "pdf":
      return "PDF";
    case "image":
      return "IMG";
    case "video":
      return "VIDEO";
    case "audio":
      return "AUDIO";
    case "archive":
      return "ZIP";
    case "spreadsheet":
      return "SHEET";
    case "presentation":
      return "SLIDE";
    case "code":
      return "CODE";
    case "text":
      return "TEXT";
    case "document":
      return "DOC";
    default:
      return "FILE";
  }
}, wf = (e) => {
  var l, d, u;
  const t = Ut(e == null ? void 0 : e.src) ?? null, n = Ei(t) ?? "Attachment", a = Ut(e == null ? void 0 : e.title) ?? n, r = Ut((l = e == null ? void 0 : e.meta) == null ? void 0 : l.fileName) ?? Ut(e == null ? void 0 : e.title) ?? n, o = Ut(e == null ? void 0 : e.mimeType), s = po((d = e == null ? void 0 : e.meta) == null ? void 0 : d.size) ?? po((u = e == null ? void 0 : e.meta) == null ? void 0 : u.fileSize), i = _i(r, t), c = kf(o, r, t);
  return {
    href: t,
    fileName: r,
    downloadName: r,
    title: a,
    mimeType: o,
    sizeBytes: s,
    sizeLabel: vf(s),
    fileKind: c,
    badgeLabel: Tf(c, i)
  };
}, yh = (e) => {
  const t = wf(e);
  return {
    href: t.href,
    fileName: t.fileName,
    title: t.title,
    mimeType: t.mimeType,
    fileSize: typeof t.sizeBytes == "number" ? Math.round(t.sizeBytes) : null,
    sizeLabel: t.sizeLabel,
    fileKind: t.fileKind,
    badgeLabel: t.badgeLabel,
    downloadName: t.downloadName
  };
}, Eh = [
  "youtube.com",
  "www.youtube.com",
  "youtu.be",
  "vimeo.com",
  "player.vimeo.com",
  "codepen.io",
  "codesandbox.io",
  "figma.com",
  "www.figma.com",
  "embed.figma.com",
  "docs.google.com",
  "drive.google.com",
  "notion.so",
  "www.notion.so"
], Nf = [
  {
    name: "YouTube",
    ratio: 9 / 16,
    // 16:9 aspect ratio
    defaultWidth: 640,
    urlPatterns: ["youtube.com", "youtu.be", "youtube-nocookie.com"]
  },
  {
    name: "Vimeo",
    ratio: 9 / 16,
    // 16:9 aspect ratio
    defaultWidth: 640,
    urlPatterns: ["vimeo.com", "player.vimeo.com"]
  },
  {
    name: "CodePen",
    ratio: 3 / 2,
    // 2:3 aspect ratio (taller for code demos)
    defaultWidth: 500,
    urlPatterns: ["codepen.io"]
  },
  {
    name: "CodeSandbox",
    ratio: 3 / 2,
    // 2:3 aspect ratio
    defaultWidth: 500,
    urlPatterns: ["codesandbox.io"]
  },
  {
    name: "Figma",
    ratio: 9 / 16,
    // 16:9 default for design embeds
    defaultWidth: 800,
    urlPatterns: ["figma.com", "www.figma.com", "embed.figma.com"]
  },
  {
    name: "Google Docs",
    ratio: 4 / 3,
    // 4:3 for documents
    defaultWidth: 600,
    urlPatterns: ["docs.google.com", "drive.google.com"]
  },
  {
    name: "Notion",
    ratio: 4 / 3,
    // 4:3 for pages
    defaultWidth: 600,
    urlPatterns: ["notion.so", "www.notion.so"]
  }
];
function xf(e) {
  try {
    const n = new URL(e).hostname.toLowerCase();
    return Nf.find(
      (a) => a.urlPatterns.some((r) => n.includes(r))
    ) || null;
  } catch {
    return null;
  }
}
function Cf(e) {
  const t = xf(e);
  return t ? {
    ratio: t.ratio,
    width: t.defaultWidth,
    height: Math.round(t.defaultWidth * t.ratio),
    platform: t.name
  } : {
    ratio: 9 / 16,
    width: 640,
    height: 360,
    platform: "Generic"
  };
}
function _h(e, t) {
  const n = Cf(e);
  if (t) {
    const r = Math.min(
      t - 40,
      n.width
    );
    return {
      width: r,
      height: Math.round(r * n.ratio)
    };
  }
  return {
    width: n.width,
    height: n.height
  };
}
function Sh(e, t) {
  var n, a;
  try {
    if (e.startsWith("/")) return !0;
    const o = new URL(e).hostname.toLowerCase();
    return (n = t.blockedDomains) != null && n.some((s) => o.includes(s)) ? !1 : (a = t.allowedDomains) != null && a.length ? t.allowedDomains.some(
      (s) => o.includes(s.toLowerCase())
    ) : !0;
  } catch {
    return !1;
  }
}
function kh(e) {
  try {
    const n = new URL(e).hostname.toLowerCase();
    return n.includes("youtube.com") || n.includes("youtu.be") ? Af(e) : n.includes("vimeo.com") ? Mf(e) : n.includes("codepen.io") ? If(e) : n.includes("figma.com") ? Of(e) : e;
  } catch {
    return e;
  }
}
function Af(e) {
  try {
    const t = new URL(e);
    let n = "";
    if (t.hostname === "youtu.be")
      n = t.pathname.slice(1);
    else if (t.hostname.includes("youtube.com") && (n = t.searchParams.get("v") || "", t.pathname.includes("/embed/")))
      return e;
    if (n)
      return `https://www.youtube.com/embed/${n}?rel=0&modestbranding=1`;
  } catch (t) {
    console.warn("Failed to convert YouTube URL:", t);
  }
  return e;
}
function Mf(e) {
  try {
    if (e.includes("player.vimeo.com"))
      return e;
    const t = e.match(/vimeo\.com\/(?:.*\/)?(\d+)/);
    if (t != null && t[1])
      return `https://player.vimeo.com/video/${t[1]}?title=0&byline=0&portrait=0`;
  } catch (t) {
    console.warn("Failed to convert Vimeo URL:", t);
  }
  return e;
}
function If(e) {
  try {
    if (e.includes("/embed/"))
      return e;
    const t = e.match(/codepen\.io\/([^\/]+)\/pen\/([^\/\?]+)/);
    if (t != null && t[1] && (t != null && t[2]))
      return `https://codepen.io/${t[1]}/embed/${t[2]}?default-tab=result`;
  } catch (t) {
    console.warn("Failed to convert CodePen URL:", t);
  }
  return e;
}
function Of(e) {
  try {
    const t = new URL(e);
    return (t.hostname === "www.figma.com" || t.hostname === "figma.com") && t.pathname.startsWith("/design/") ? (t.hostname = "embed.figma.com", t.searchParams.set("embed-host", "share"), t.toString()) : t.hostname === "embed.figma.com" ? (t.searchParams.has("embed-host") || t.searchParams.set("embed-host", "share"), t.toString()) : e;
  } catch (t) {
    console.warn("Failed to convert Figma URL:", t);
  }
  return e;
}
const Si = Object.freeze({
  characters: 5e3,
  bytes: 262144,
  nodes: 2e3,
  listDepth: 3,
  treeDepth: 12,
  containerDepth: 32,
  href: 2048
}), ki = [
  "doc",
  "paragraph",
  "text",
  "hardBreak",
  "bulletList",
  "orderedList",
  "listItem"
], vi = ["link", "textStyle", "bold", "italic"], Ti = Object.freeze([
  "red",
  "orange",
  "green",
  "blue",
  "purple",
  "gray"
]), fo = xc(), vh = Object.freeze({
  id: "basic-rich-text",
  nodes: Object.freeze(fo.nodes.filter((e) => ki.includes(e.key))),
  marks: Object.freeze(fo.marks.filter((e) => vi.includes(e.key))),
  limits: Si,
  textColors: Ti,
  /** Toolbar, slash and shortcut surfaces offer only these interactions. */
  capabilities: Object.freeze([
    "history",
    "history.undo",
    "history.redo",
    "format.bold",
    "format.italic",
    "text-color",
    "list.bullet",
    "list.ordered",
    "block-style.list",
    "block-style.paragraph",
    "insert.link"
  ])
}), ee = (e) => {
  throw new TypeError(`basic-rich-text:${e}`);
}, Lf = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/u, Rf = (e) => {
  for (const t of e) {
    const n = t.codePointAt(0);
    if (n >= 55296 && n <= 57343) return !1;
  }
  return !Lf.test(e);
}, Df = (e, t = 2048) => {
  var r;
  if (typeof e != "string" || !e || [...e].length > t)
    return ee("link-length");
  let n;
  try {
    n = decodeURIComponent(e);
  } catch {
    return ee("link-encoding");
  }
  if (/[\s\u0000-\u001F\u007F\u0085\\]/u.test(n))
    return ee("link-unsafe");
  if (!/^(https?:\/\/|mailto:|tel:)/i.test(e)) return ee("link-protocol");
  let a;
  try {
    a = new URL(e);
  } catch {
    return ee("link-target");
  }
  if (["https:", "http:"].includes(a.protocol)) {
    const o = ((r = e.match(/^https?:\/\/([^/?#]*)/i)) == null ? void 0 : r[1]) ?? "";
    if (!o || !a.hostname || a.username || a.password || /[%@]/u.test(o))
      return ee("link-host");
  } else if (!a.pathname || a.host) return ee("link-target");
  return e;
}, wi = (e) => e.type === "text" ? e.text ?? "" : e.type === "hardBreak" ? `
` : (e.content ?? []).map(wi).join(e.type === "paragraph" ? "" : `
`), bo = (e, t) => {
  const n = [[e, 1]];
  let a = 0;
  for (; n.length; ) {
    const [o, s] = n.pop();
    if (++a > 5e4 && ee("resource-limit"), o && typeof o == "object") {
      s > t.containerDepth && ee("container-depth");
      for (const i of Object.values(o)) n.push([i, s + 1]);
    } else typeof o == "string" && !Rf(o) ? ee("unicode-control") : typeof o == "number" && !Number.isFinite(o) && ee("json-number");
  }
  const r = JSON.stringify(e);
  (!r || new TextEncoder().encode(r).length > t.bytes) && ee("bytes");
}, Th = (e, t = {}) => {
  var l, d, u, m, g;
  if (e === null) return null;
  const n = { ...Si, ...t };
  bo(e, n);
  const a = Cc(e);
  a.issues.some((f) => f.code !== "document-roundtrip-mismatch") && ee(((l = a.issues[0]) == null ? void 0 : l.code) ?? "structure");
  const r = e;
  (Object.keys(r.meta).length !== 1 || r.meta.schemaVersion !== "stable-block-identity/v2") && ee("meta"), (r.assets.length || r.annotations.length) && ee("resources");
  const o = [[r.body.content, 1, 0]];
  let s = 0;
  for (; o.length; ) {
    const [f, b, E] = o.pop();
    ++s > n.nodes && ee("nodes"), b > n.treeDepth && ee("tree-depth"), ki.includes(f.type ?? "") || ee("node-type");
    const _ = E + (["orderedList", "bulletList"].includes(f.type ?? "") ? 1 : 0);
    _ > n.listDepth && ee("list-depth"), f.type === "text" && (!f.text || /[\r\n]/u.test(f.text)) && ee("text"), f.type === "paragraph" && ((d = f.attrs) == null ? void 0 : d.textAlign) !== null && ee("text-align"), f.type === "orderedList" && (((u = f.attrs) == null ? void 0 : u.type) !== null || !Number.isInteger((m = f.attrs) == null ? void 0 : m.start) || f.attrs.start < 1 || f.attrs.start > 1e6) && ee("list-start");
    const k = /* @__PURE__ */ new Set();
    for (const S of f.marks ?? []) {
      if ((!vi.includes(S.type) || k.has(S.type)) && ee("mark-type"), k.add(S.type), S.type === "link") {
        const y = S.attrs;
        (y.target !== "_blank" || y.rel !== "noopener noreferrer nofollow" || y.class !== null || y.title !== null) && ee("link-attributes"), Df(y.href, n.href);
      }
      if (S.type === "textStyle") {
        const y = S.attrs ?? {};
        (y.fontFamily !== null || y.fontSize !== null || !Ti.includes(y.color)) && ee("text-style");
      }
    }
    for (const S of f.content ?? []) o.push([S, b + 1, _]);
  }
  const i = bc(r);
  [...wi(i.body.content)].length > n.characters && ee("characters"), bo(i, n);
  const c = i.body.content.content;
  return c.length === 1 && c[0].type === "paragraph" && !((g = c[0].content) != null && g.length) ? null : i;
}, Bf = "__ZX_TEXT_EDITOR_DEBUG__";
let Pf = 0;
const Ff = () => globalThis[Bf], Ni = (e) => {
  const t = Ff();
  return t === !0 ? !0 : typeof t == "string" ? t === e : Array.isArray(t) ? t.includes(e) : t && typeof t == "object" ? t[e] === !0 : !1;
}, wh = (e, t, n) => {
  if (Ni(e)) {
    if (n === void 0) {
      console.log(`[${e}] ${t}`);
      return;
    }
    console.log(`[${e}] ${t}`, n);
  }
}, Nh = (e, t, n) => {
  if (!Ni(e))
    return null;
  const a = `${e}:${t}#${++Pf}`;
  return n !== void 0 && console.log(`[${e}] ${t}:start`, n), console.time(a), {
    end(r) {
      console.timeEnd(a), r !== void 0 && console.log(`[${e}] ${t}:end`, r);
    }
  };
}, xh = ae.create({
  name: "codeBlockExit",
  addKeyboardShortcuts() {
    return {
      /**
       * Escape key to exit code block
       * Moves cursor to after the code block
       */
      Escape: ({ editor: e }) => {
        if (!e.isActive("codeBlock")) return !1;
        const { state: t } = e, { selection: n } = t, { $from: a } = n;
        let r = a.depth;
        for (; r > 0 && a.node(r).type.name !== "codeBlock"; )
          r--;
        if (r === 0) return !1;
        const o = a.before(r), s = a.node(r), i = o + s.nodeSize, l = t.doc.resolve(i).nodeAfter;
        if ((l == null ? void 0 : l.type.name) === "paragraph" && l.content.size === 0 || l)
          return e.chain().setTextSelection(i + 1).focus().run();
        const d = t.schema.nodes.paragraph;
        if (!d) return !1;
        const u = d.createAndFill();
        if (!u) return !1;
        const m = t.tr.insert(i, u);
        return m.setSelection(vr.create(m.doc, i + 1)), e.view.dispatch(m.scrollIntoView()), !0;
      },
      /**
       * Arrow Down at end of code block to exit
       * Only triggers when cursor is at the very end of the code block content
       */
      ArrowDown: ({ editor: e }) => {
        if (!e.isActive("codeBlock")) return !1;
        const { state: t } = e, { selection: n } = t, { $from: a, empty: r } = n;
        if (!r) return !1;
        let o = a.depth;
        for (; o > 0 && a.node(o).type.name !== "codeBlock"; )
          o--;
        if (o === 0) return !1;
        const s = a.node(o), i = a.start(o), c = i + s.content.size, l = a.pos;
        if (l !== c) return !1;
        const d = s.textContent, u = l - i;
        if (d.slice(u).length > 0) return !1;
        const f = a.before(o) + s.nodeSize;
        if (t.doc.resolve(f).nodeAfter)
          return e.chain().setTextSelection(f + 1).focus().run();
        const _ = t.schema.nodes.paragraph;
        if (!_) return !1;
        const k = _.createAndFill();
        if (!k) return !1;
        const S = t.tr.insert(f, k);
        return S.setSelection(vr.create(S.doc, f + 1)), e.view.dispatch(S.scrollIntoView()), !0;
      }
    };
  }
}), zf = /^(?:localhost|(?:[a-z0-9-]+\.)+(?:[a-z]{2,}|xn--[a-z0-9-]+)|\d{1,3}(?:\.\d{1,3}){3}|\[[0-9a-f:.]+\])$/;
function Hf(e) {
  if (!e || /\s/.test(e)) return !1;
  try {
    const t = new URL(e);
    return ["http:", "https:", "mailto:", "tel:"].includes(t.protocol);
  } catch {
    try {
      return zf.test(new URL(`https://${e}`).hostname);
    } catch {
      return !1;
    }
  }
}
function Ch(e) {
  return e ? /^[a-z][a-z0-9+.-]*:/i.test(e) ? e : `https://${e}` : "";
}
function $f(e) {
  return new Ao({
    key: new Mo("handlePasteLink"),
    props: {
      handlePaste: (t, n, a) => {
        const { state: r } = t, { selection: o } = r, { empty: s } = o;
        if (s)
          return !1;
        const i = a.content.textBetween(0, a.content.size, `
`, `
`).trim();
        if (!i)
          return !1;
        const c = Hf(i) ? i : null;
        return c ? e.editor.chain().setTextSelection({ from: o.from, to: o.to }).setLink({ href: c }).setTextSelection(o.to).command(({ tr: l }) => (l.setStoredMarks([]), !0)).run() : !1;
      }
    }
  });
}
const Ah = $f;
export {
  Cb as $,
  Eh as A,
  _b as B,
  us as C,
  ls as D,
  Sb as E,
  kb as F,
  vb as G,
  fh as H,
  _d as I,
  jo as J,
  kd as K,
  Ah as L,
  $e as M,
  vs as N,
  Ue as O,
  $r as P,
  wd as Q,
  Tb as R,
  rb as S,
  qb as T,
  wb as U,
  Nb as V,
  xb as W,
  rt as X,
  Et as Y,
  Tn as Z,
  Rd as _,
  xh as a,
  ba as a$,
  Dd as a0,
  Ab as a1,
  Mb as a2,
  Ib as a3,
  Ob as a4,
  Lb as a5,
  Rb as a6,
  ea as a7,
  Db as a8,
  Bb as a9,
  kg as aA,
  vg as aB,
  Tg as aC,
  eh as aD,
  Ag as aE,
  Og as aF,
  Lg as aG,
  th as aH,
  Os as aI,
  bg as aJ,
  Qb as aK,
  Jb as aL,
  Bu as aM,
  Pc as aN,
  ab as aO,
  Ln as aP,
  sb as aQ,
  Rl as aR,
  $l as aS,
  db as aT,
  Sa as aU,
  ib as aV,
  cb as aW,
  lb as aX,
  ft as aY,
  Kc as aZ,
  Wc as a_,
  Pb as aa,
  Fb as ab,
  wt as ac,
  zb as ad,
  Qa as ae,
  Hb as af,
  $b as ag,
  Ub as ah,
  cu as ai,
  gu as aj,
  pu as ak,
  Gb as al,
  Cn as am,
  bu as an,
  Kb as ao,
  Vb as ap,
  jb as aq,
  Ia as ar,
  ug as as,
  pg as at,
  ar as au,
  fg as av,
  yg as aw,
  Eg as ax,
  _g as ay,
  Sg as az,
  ya as b,
  tm as b$,
  ob as b0,
  Cr as b1,
  Ar as b2,
  Wt as b3,
  Zc as b4,
  Jc as b5,
  el as b6,
  tl as b7,
  Wa as b8,
  ha as b9,
  _u as bA,
  Su as bB,
  is as bC,
  Wb as bD,
  vu as bE,
  Fs as bF,
  rh as bG,
  ah as bH,
  oh as bI,
  nh as bJ,
  zs as bK,
  sh as bL,
  ch as bM,
  ih as bN,
  Qg as bO,
  mh as bP,
  cf as bQ,
  wf as bR,
  hh as bS,
  Rg as bT,
  Hf as bU,
  $f as bV,
  Ch as bW,
  ph as bX,
  gh as bY,
  wh as bZ,
  bh as b_,
  at as ba,
  rn as bb,
  ml as bc,
  ql as bd,
  ub as be,
  Io as bf,
  Ga as bg,
  yt as bh,
  fa as bi,
  Va as bj,
  dh as bk,
  uh as bl,
  Im as bm,
  Qs as bn,
  lh as bo,
  Dm as bp,
  js as bq,
  Si as br,
  Ti as bs,
  vh as bt,
  Df as bu,
  wi as bv,
  Th as bw,
  Ns as bx,
  os as by,
  Eu as bz,
  jg as c,
  am as c0,
  nm as c1,
  Xb as c2,
  tr as c3,
  Oe as c4,
  un as c5,
  Lu as c6,
  Pn as c7,
  Zb as c8,
  Dg as c9,
  yh as ca,
  Nh as cb,
  ws as d,
  Cf as e,
  xf as f,
  _h as g,
  er as h,
  Yb as i,
  Ya as j,
  mb as k,
  fb as l,
  Yo as m,
  gb as n,
  nd as o,
  kh as p,
  Xa as q,
  rl as r,
  pb as s,
  Jo as t,
  Za as u,
  Sh as v,
  bb as w,
  hb as x,
  yb as y,
  Eb as z
};
//# sourceMappingURL=link-paste-handler-B_hN4OP5.mjs.map
