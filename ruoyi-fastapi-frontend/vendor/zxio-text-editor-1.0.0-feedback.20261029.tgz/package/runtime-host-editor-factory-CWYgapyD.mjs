import { Extension as E } from "@tiptap/core";
import { Editor as a } from "@tiptap/vue-3";
import { bindPackageTextEditorRuntimeHostEditorV2 as m } from "#runtime-host-core-authority";
import { registerPackageRuntimeTargetDocumentAuthorityV2 as f } from "#runtime-target-document-authority";
import { s as y } from "./runtime-extensions-ClrqjOfa.mjs";
const d = (e, t) => Object.prototype.hasOwnProperty.call(e, t), x = (e, t) => {
  const r = Object.getPrototypeOf(e), s = t[0], n = s && typeof s == "object" ? Object.getPrototypeOf(s) : null, o = e.options.extensions;
  return !!((r == null ? void 0 : r.constructor) === a && e.constructor === a && (n == null ? void 0 : n.constructor) === E && Array.isArray(o) && o.length === t.length && o.every(
    (c, i) => c === t[i]
  ));
}, T = (e, t) => {
  if (!e || typeof e != "object" || d(e, "extensions"))
    throw new TypeError("runtime-host-editor-options-extensions-forbidden");
  if (!t || typeof t != "object")
    throw new TypeError("runtime-host-extension-options-invalid");
  const r = t.extensions, s = Array.isArray(r) ? [...r] : [], n = y({
    ...t,
    extensions: s
  });
  if (!Array.isArray(n) || n.length === 0)
    throw new TypeError("runtime-host-extension-assembly-invalid");
  const o = new a({
    ...e,
    extensions: n
  }), c = o.options.extensions.filter(
    (l) => s.includes(l)
  ), i = t.getCurrentDocument, u = x(
    o,
    n
  ) ? m({
    targetEditor: o,
    externalExtensions: c
  }) : null;
  if (!u)
    throw o.destroy(), new TypeError("runtime-host-editor-construction-invalid");
  return typeof i == "function" && f({
    targetEditor: o,
    hostBindingFingerprint: u,
    readCanonicalDocument: i
  }), o;
};
export {
  T as c
};
//# sourceMappingURL=runtime-host-editor-factory-CWYgapyD.mjs.map
