import { E as f } from "./use-text-editor-command-keybindings-FrTE8ei0.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-video-BjZLrdnV.mjs.map
