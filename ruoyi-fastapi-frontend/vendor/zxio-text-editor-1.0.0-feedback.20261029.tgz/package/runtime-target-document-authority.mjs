import { P as F, a as w, b as C, R as p, A as m, v as N } from "./index-HCJsYonJ.mjs";
import { d as u, s as i, c } from "./definition-DiwrtpbT.mjs";
const E = "zx.runtime.target-document-projection.v2", l = new F("zxRuntimeTargetDocumentProjectionV2"), f = (e) => u({ documentFingerprint: i(e.body.content), annotations: b(e).annotations }), s = (e, t, n, r) => u({ current: e, done: [...t], undone: [...n], liveClosure: [...r] }), R = (e) => {
  const t = e.getMeta(p), n = e.getMeta(m), r = t ?? n;
  return !r || !Number.isSafeInteger(r.sequence) ? null : u({ kind: t ? "root" : "appended", sequence: r.sequence, logicalTime: e.time, allowedMetaFingerprint: i({ [t ? p : m]: r }), afterDocumentFingerprint: i(e.doc.toJSON()) });
}, j = new w({ key: l, state: { init: () => null, apply: (e, t) => {
  const n = R(e), r = e.getMeta(E);
  if (r) return s(r.after, [...(t == null ? void 0 : t.done) ?? [], r].slice(-100), [], n ? [n] : []);
  if (t && n) return s(t.current, t.done, t.undone, [...t.liveClosure, n]);
  if (t && h(e)) {
    const a = i(e.doc.toJSON()), o = t.done.at(-1);
    if ((o == null ? void 0 : o.before.documentFingerprint) === a) return s(o.before, t.done.slice(0, -1), [...t.undone, o], t.liveClosure);
    const d = t.undone.at(-1);
    if ((d == null ? void 0 : d.after.documentFingerprint) === a) return s(d.after, [...t.done, d], t.undone.slice(0, -1), t.liveClosure);
  }
  return e.docChanged && !h(e) ? null : t;
} } }), B = (e, t, n) => {
  e.setMeta(E, u({ before: f(t), after: f(n) }));
}, J = (e) => {
  var t;
  return ((t = l.getState(e)) == null ? void 0 : t.liveClosure) ?? [];
}, T = /* @__PURE__ */ new WeakMap(), g = C, h = (e) => g.isHistoryTransaction(e), O = i({ protocol: "zx-runtime-target-document-authority-v2", documentTruth: "document-v2-plus-live-target-state", historyTruth: "prosemirror-history", callerRegistration: !1 }), D = (e) => {
  try {
    const t = e;
    return t.destroyed === !0 || !t.state || typeof t.state != "object" ? null : t.state;
  } catch {
    return null;
  }
}, b = (e) => u(JSON.parse(c(e))), y = (e) => {
  const t = e.targetEditor.deref(), n = t ? D(t) : null;
  if (!t || !n) throw new TypeError("target-binding-invalid");
  const r = b(e.readDocument()), a = l.getState(n), o = a ? u({ ...r, annotations: JSON.parse(c(a.current.annotations)) }) : r;
  if (!N(o).valid || a && a.current.documentFingerprint !== i(n.doc.toJSON()) || c(o.body.content) !== c(n.doc.toJSON())) throw new TypeError("target-document-invalid");
  return o;
}, v = (e) => {
  const t = e.targetEditor.deref(), n = t ? D(t) : null;
  if (!t || !n) throw new TypeError("target-binding-invalid");
  const r = { undoDepth: g.undoDepth(n), redoDepth: g.redoDepth(n) };
  return u({ ...r, fingerprint: i({ domain: "zx-runtime-history-snapshot-v2", value: r }) });
}, P = (e) => {
  if (!e.targetEditor || typeof e.targetEditor != "object" || typeof e.hostBindingFingerprint != "string" || !e.hostBindingFingerprint || typeof e.readCanonicalDocument != "function") throw new TypeError("target-document-authority-registration-invalid");
  T.set(e.targetEditor, { targetEditor: new WeakRef(e.targetEditor), hostBindingFingerprint: e.hostBindingFingerprint, readDocument: e.readCanonicalDocument });
}, x = (e) => {
  const t = T.get(e);
  if (!t || t.targetEditor.deref() !== e) return null;
  try {
    y(t), v(t);
  } catch {
    return null;
  }
  const n = { authorityFingerprint: O, hostBindingFingerprint: t.hostBindingFingerprint };
  return Object.freeze({ targetEditor: t.targetEditor, ...n, bindingFingerprint: i({ domain: "zx-runtime-target-document-binding-v2", value: n }), readCanonicalDocument: () => y(t), readHistoryState: () => v(t) });
};
export {
  j as RUNTIME_TARGET_DOCUMENT_PROJECTION_PLUGIN_V2,
  B as attachRuntimeTargetDocumentProjectionV2,
  x as readRuntimeTargetDocumentBindingV2,
  J as readRuntimeTargetLiveClosureV2,
  P as registerPackageRuntimeTargetDocumentAuthorityV2
};
//# sourceMappingURL=runtime-target-document-authority.mjs.map
