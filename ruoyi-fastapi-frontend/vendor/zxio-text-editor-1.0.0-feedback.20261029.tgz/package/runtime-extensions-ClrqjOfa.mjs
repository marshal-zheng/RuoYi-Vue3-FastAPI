import { Node as Re, mergeAttributes as Oe, nodeInputRule as Oo, Extension as We, defaultBlockAt as jt, getMarkRange as No, markInputRule as $o, textblockTypeInputRule as zo } from "@tiptap/core";
import { Plugin as Ne, PluginKey as De, AllSelection as Fo, NodeSelection as Ho, TextSelection as Xe } from "@tiptap/pm/state";
import { DOMParser as en, DOMSerializer as Vo, Slice as qo } from "@tiptap/pm/model";
import { by as Ln, k as Bt, bR as Wo, bS as Uo, e as Ko, p as Dt, v as Tn, g as Rt, A as Xo, bx as In, au as Sn, ar as Go, av as Zo, bt as Ot, bT as Yo, br as Tt, bw as Jo, bu as Qo, bU as tn, bV as ea, bW as ta, bO as na, bD as An, V as Pn, bE as oa, bk as aa, bX as Mn, bY as Bn, l as ia, Z as sa, n as nn, ag as ra, ai as la, ad as ma, af as ca, ah as Dn, ak as da, al as ua, am as on, ap as an, ao as pa, a5 as fa, a4 as ga, aa as ha, a9 as sn, R as ja, W as va, a8 as ba, a6 as _a, bC as ya, G as wa, F as ka, E as Ca, B as xa, z as Ea, y as La, x as Ta, U as Ia, bZ as Rn, aw as Sa, h as Aa, b_ as Pa, H as Ma, b$ as Ba, c0 as Da, c1 as Ra, c2 as Oa, aQ as Na, be as $a, aO as za, aT as Fa, b0 as Ha, a as Va, S as qa, aD as Wa, aE as Ua, az as Ka, aA as Xa, ay as Ga, as as Za } from "./link-paste-handler-B_hN4OP5.mjs";
import { detectShortcutPlatform as On, createShortcutRuntime as Nn, createActionPort as rn } from "@zxio/keybindings/core";
import { bindShortcutOwner as Ya, useShortcutPresentation as Ja } from "@zxio/keybindings/vue";
import { z as Qa, n as ei, p as ti } from "./actions-Sd62WBGv.mjs";
import { selectAll as ln } from "@tiptap/pm/commands";
import ni from "@tiptap/starter-kit";
import { Placeholder as oi } from "@tiptap/extensions";
import ai from "@tiptap/extension-text-align";
import { Table as ii } from "@tiptap/extension-table";
import si from "@tiptap/extension-typography";
import { TextStyle as ri, FontFamily as li, FontSize as mi } from "@tiptap/extension-text-style";
import { TaskList as ci, TaskItem as di } from "@tiptap/extension-list";
import ui from "@tiptap/extension-underline";
import { render as et, h as Nt, defineComponent as Ce, computed as B, createBlock as ke, openBlock as E, unref as s, withCtx as _e, createElementVNode as _, normalizeClass as u, createVNode as U, toDisplayString as W, createElementBlock as S, Fragment as ye, createCommentVNode as K, ref as A, onMounted as He, normalizeStyle as Pe, withModifiers as N, watch as Le, onUnmounted as ze, withDirectives as tt, renderList as Be, vModelText as _t, onBeforeUpdate as $n, renderSlot as zn, nextTick as Me, toValue as lt, toRef as mn, Teleport as Fn, Transition as Hn, createTextVNode as Ae, withKeys as $e, inject as Vn, shallowRef as Ke, onBeforeUnmount as pi, onScopeDispose as qn, mergeProps as fi, reactive as gi, vShow as cn } from "vue";
import hi from "@tiptap/extension-link";
import { useNamespace as Ee, useLocale as ji, useOverlayZIndex as vi } from "@zxio/zxui/hooks";
import { ZxIcon as te, ZxDialog as bi, ZxButton as Ue } from "@zxio/zxui/core";
import { ZxInput as _i } from "@zxio/zxui/input";
import { offset as yi, shift as wi, flip as Wn, autoUpdate as ki, computePosition as Ci } from "@floating-ui/dom";
import { nodeViewProps as kt, NodeViewWrapper as ot, VueNodeViewRenderer as Ze, VueRenderer as xi, NodeViewContent as Un } from "@tiptap/vue-3";
import Kn from "@tiptap/suggestion";
import Ei from "@tiptap/extension-code-block-lowlight";
import Li from "@tiptap/extension-code";
import { liftTarget as $t, replaceStep as Xn, canSplit as vt, ReplaceAroundStep as dn, canJoin as Gn } from "prosemirror-transform";
import { Slice as yt, Fragment as it } from "prosemirror-model";
import { TextSelection as Ge, Selection as Te, NodeSelection as Fe, AllSelection as Zn } from "prosemirror-state";
import { an as un, k as Yn, i as Ti, l as Ii } from "./delivery-surfaces-C8goSxeE.mjs";
import { ZxSelect as zt } from "@zxio/zxui/select";
import Si from "@tiptap/extension-node-range";
import "@tiptap/extension-drag-handle-vue-3";
import { DecorationSet as Ai, Decoration as Pi } from "@tiptap/pm/view";
import { FileHandler as Mi } from "@tiptap/extension-file-handler";
import { ZxTooltipOrPopover as qe } from "@zxio/zxui/tooltip-or-popover";
import { u as Bi } from "./envelope-CrN5-dS1.mjs";
import { a as Di } from "./runtime-plugin-definitions-DN_cDAJZ.mjs";
import { RUNTIME_TARGET_DOCUMENT_PROJECTION_PLUGIN_V2 as Ri } from "#runtime-target-document-authority";
const Oi = [
  "filename",
  "caption",
  "startLine",
  "wrap",
  "showLineNumbers",
  "collapsed",
  "previewLines",
  "diagnostics"
], Ni = "Type code, or pick a language first", $i = "Add file name", zi = "Add caption", Fi = (e, t = Ln) => {
  const n = e.copy.text.length === 0, a = e.lines.visualLineCount > t.longCodePreviewThreshold, o = e.display.collapsed ? e.display.previewTo : e.lines.visualLineCount, i = e.lines.visualLines.slice(0, o), r = e.lines.lineNumbers.slice(0, o), m = e.copy.mode === "plain";
  return {
    header: {
      languageLabel: Bt(e.attrs.language),
      language: e.attrs.language,
      filename: e.attrs.filename,
      caption: e.attrs.caption,
      canCopyPlain: m,
      copyDisabledReason: m ? null : "Markdown copy is deferred; plain copy is available.",
      moreSettingsFields: Oi
    },
    body: {
      isEmpty: n,
      codePlaceholder: n ? Ni : null,
      filenamePlaceholder: e.attrs.filename ? null : $i,
      captionPlaceholder: e.attrs.caption ? null : zi,
      visualLines: e.lines.visualLines,
      visibleVisualLines: i,
      lineNumbers: e.lines.lineNumbers,
      visibleLineNumbers: r,
      showLineNumbers: e.display.showLineNumbers,
      wrap: e.display.wrap,
      collapsed: e.display.collapsed,
      previewFrom: e.display.previewFrom,
      previewTo: o,
      visualLineCount: e.lines.visualLineCount,
      isLong: a,
      maxBodyHeight: !e.display.collapsed && a ? t.longCodeMaxBodyHeight : null,
      scrollStatePersistence: "ui-only"
    },
    copy: {
      text: e.copy.text,
      mode: e.copy.mode
    },
    diagnostics: e.diagnostics
  };
}, Hi = /^\s*```[\w#+.-]*[\t ]*\n[\s\S]*\n?```\s*$/m, Vi = /(^\s{2,}\S)|(\b(const|let|var|function|class|import|export|return|if|for|while|try|catch)\b)|([{}[\];]|=>)|(^\s*[$#]\s+\S)/u, qi = (e, t = {}) => {
  if (Hi.test(e))
    return {
      kind: "code-block",
      reason: "markdown-fence"
    };
  if (t.explicitCodeBlockContext)
    return {
      kind: "code-block",
      reason: "explicit-context"
    };
  const n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  if (n.length < 2)
    return {
      kind: "preserve-existing-paste",
      reason: "ordinary-text"
    };
  const a = n.filter((r) => r.trim()), o = a.filter((r) => Vi.test(r)), i = /[{}]/.test(e) || /;\s*(?:\n|$)/.test(e) || /^\s{2,}\S/m.test(e);
  return a.length >= 3 && o.length >= 2 && i ? {
    kind: "code-block",
    reason: "classifier"
  } : {
    kind: "preserve-existing-paste",
    reason: "ordinary-text"
  };
}, Jn = (e, t) => {
  var o;
  const n = e ? (o = e.ownerDocument.defaultView) == null ? void 0 : o.getComputedStyle(e).getPropertyValue(`--text-editor-space-${t}`) : void 0, a = Number.parseFloat(n ?? "");
  return Number.isFinite(a) ? a : t * 2;
}, Qn = (e) => yi(({ elements: t }) => Jn(t.floating, e)), Wi = (e) => wi(({ elements: t }) => ({
  padding: Jn(t.floating, e)
})), pn = (e) => {
  const t = typeof e.title == "string" ? e.title : typeof e["data-embed-title"] == "string" ? e["data-embed-title"] : "", n = typeof e.name == "string" ? e.name : typeof e["data-embed-name"] == "string" ? e["data-embed-name"] : "";
  return t || n;
}, Ui = Re.create({
  name: "embed",
  group: "inline",
  inline: !0,
  atom: !0,
  selectable: !0,
  draggable: !1,
  addOptions() {
    return {
      getDocuments: async () => [],
      component: void 0,
      trigger: "[[",
      urlTemplate: (e) => e.url,
      interactive: !1,
      themeOwner: null
    };
  },
  addAttributes() {
    return {
      name: {
        default: null,
        parseHTML: (e) => e.getAttribute("data-embed-name"),
        renderHTML: (e) => e.name ? { "data-embed-name": e.name } : {}
      },
      title: {
        default: null,
        parseHTML: (e) => {
          var t;
          return e.getAttribute("data-embed-title") || ((t = e.textContent) == null ? void 0 : t.replace(/^\[\[|\]\]$/g, ""));
        },
        renderHTML: (e) => e.title ? { "data-embed-title": e.title } : {}
      },
      url: {
        default: null,
        parseHTML: (e) => e.getAttribute("href"),
        renderHTML: (e) => e.url ? { href: e.url } : {}
      },
      icon: {
        default: null,
        parseHTML: (e) => e.getAttribute("data-embed-icon"),
        renderHTML: (e) => e.icon ? { "data-embed-icon": e.icon } : {}
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'a[data-type="embed"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e, node: t }) {
    const n = pn(t.attrs);
    return [
      "a",
      Oe(e, {
        "data-type": "embed",
        class: un("text-editor-embed")
      }),
      `[[${n}]]`
    ];
  },
  renderText({ node: e }) {
    const t = pn(e.attrs);
    return t ? `[[${t}]]` : "";
  },
  addCommands() {
    return {
      insertEmbed: (e) => ({ editor: t, chain: n }) => {
        var i, r;
        const a = (this.options.trigger ?? "[[").length, o = {
          from: Math.max(0, t.state.selection.from - a),
          to: t.state.selection.from
        };
        return n().deleteRange(o).insertContent({
          type: this.name,
          attrs: {
            name: e.name,
            title: e.title,
            url: ((r = (i = this.options).urlTemplate) == null ? void 0 : r.call(i, e)) ?? e.url,
            icon: e.icon
          }
        }).run();
      }
    };
  },
  addProseMirrorPlugins() {
    const e = this.options, t = this.editor;
    return [
      Kn({
        editor: t,
        char: e.trigger ?? "[[",
        allowSpaces: !0,
        startOfLine: !1,
        allowedPrefixes: null,
        command: ({ editor: n, range: a, props: o }) => {
          var r;
          const i = o;
          n.chain().focus().deleteRange(a).insertContent({
            type: this.name,
            attrs: {
              name: i.name,
              title: i.title,
              url: ((r = e.urlTemplate) == null ? void 0 : r.call(e, i)) ?? i.url,
              icon: i.icon
            }
          }).run();
        },
        items: async ({ query: n }) => (await e.getDocuments(n)).slice(0, 10),
        render: () => {
          let n = null, a = null, o = null, i = null, r = 0;
          const m = () => {
            r += 1, o == null || o.remove(), o = null, n && et(null, n), n = null, a = null, i == null || i.release(), i = null;
          }, l = (c) => {
            if (!i || !n || !e.component) return;
            const d = Nt(e.component, {
              ...c,
              ref: (g) => {
                a = g;
              }
            });
            d.appContext = i.appContext, et(d, n);
          };
          return {
            onStart: async (c) => {
              if (!e.component || !e.themeOwner) return;
              m();
              const d = ++r, g = await e.themeOwner.acquirePortal();
              if (d !== r) {
                g.ok && g.value.release();
                return;
              }
              g.ok && (i = g.value, o = i.target.ownerDocument.createElement("div"), n = i.target.ownerDocument.createElement("div"), o.className = un("text-editor-embed-popup"), o.appendChild(n), i.target.appendChild(o), l(c), fn(c, o));
            },
            onUpdate: (c) => {
              l(c), o && fn(c, o);
            },
            onKeyDown: (c) => {
              var d;
              return c.event.key === "Escape" ? (m(), !0) : ((d = a == null ? void 0 : a.onKeyDown) == null ? void 0 : d.call(a, c.event)) ?? !1;
            },
            onExit: () => {
              m();
            }
          };
        }
      })
    ];
  }
});
function fn(e, t) {
  const { clientRect: n } = e;
  if (!n) return;
  const a = n();
  if (!a) return;
  const o = t.ownerDocument, i = o.defaultView, r = (i == null ? void 0 : i.scrollX) || o.documentElement.scrollLeft, m = (i == null ? void 0 : i.scrollY) || o.documentElement.scrollTop;
  t.style.position = "absolute", t.style.left = `${a.left + r}px`, t.style.top = `${a.bottom + m + 8}px`, t.style.zIndex = "100";
}
const Ki = { key: 0 }, Xi = { key: 1 }, Gi = { key: 1 }, Zi = /* @__PURE__ */ Ce({
  __name: "AttachmentNodeView",
  props: kt,
  setup(e) {
    const t = e, n = Ee("text-editor-attachment-node"), a = B(
      () => t.editor.extensionManager.extensions.find(
        (v) => v.name === "attachment"
      )
    ), o = B(() => {
      var L, x;
      const v = (x = (L = a.value) == null ? void 0 : L.options) == null ? void 0 : x.getCurrentDocument;
      return typeof v == "function" ? v() : null;
    }), i = B(() => {
      const v = typeof t.node.attrs.assetId == "string" ? t.node.attrs.assetId : null;
      return !v || !o.value ? null : Bi(o.value.assets, v) ?? null;
    }), r = B(() => Wo(i.value)), m = B(() => Uo(r.value.fileKind)), l = B(() => t.editor.isEditable), c = B(() => [
      n.b(),
      n.is("selected", t.selected),
      t.node.attrs.display === "compact" ? n.m("compact") : "",
      i.value ? "" : n.is("missing", !0)
    ]);
    function d() {
      const v = t.getPos();
      typeof v == "number" && t.editor.commands.setNodeSelection(v);
    }
    function g(v) {
      v.preventDefault(), v.stopPropagation();
    }
    function f(v) {
      g(v), !(!r.value.href || typeof window > "u") && window.open(r.value.href, "_blank", "noopener,noreferrer");
    }
    function p(v) {
      if (g(v), !r.value.href || typeof document > "u")
        return;
      const L = document.createElement("a");
      L.href = r.value.href, L.target = "_blank", L.rel = "noopener noreferrer", L.download = r.value.downloadName, L.click();
    }
    function h(v, L) {
      g(L), t.updateAttributes({ display: v });
    }
    return (v, L) => (E(), ke(s(ot), {
      "data-block-id": v.node.attrs.blockId || void 0
    }, {
      default: _e(() => [
        _("div", {
          class: u(c.value),
          onClick: d
        }, [
          _("div", {
            class: u(s(n).e("surface"))
          }, [
            _("div", {
              class: u(s(n).e("icon"))
            }, [
              U(s(te), { icon: m.value }, null, 8, ["icon"])
            ], 2),
            _("div", {
              class: u(s(n).e("content"))
            }, [
              _("div", {
                class: u(s(n).e("title-row"))
              }, [
                _("span", {
                  class: u(s(n).e("name"))
                }, W(r.value.fileName), 3),
                _("span", {
                  class: u(s(n).e("badge"))
                }, W(r.value.badgeLabel), 3)
              ], 2),
              _("div", {
                class: u(s(n).e("meta"))
              }, [
                i.value ? (E(), S(ye, { key: 0 }, [
                  r.value.mimeType ? (E(), S("span", Ki, W(r.value.mimeType), 1)) : K("", !0),
                  r.value.sizeLabel ? (E(), S("span", Xi, W(r.value.sizeLabel), 1)) : K("", !0)
                ], 64)) : (E(), S("span", Gi, "Missing asset reference"))
              ], 2)
            ], 2),
            _("div", {
              class: u(s(n).e("actions"))
            }, [
              r.value.href ? (E(), S("button", {
                key: 0,
                type: "button",
                class: u(s(n).e("action-btn")),
                title: "Open attachment",
                onClick: f
              }, [
                U(s(te), { icon: "lucide:external-link" })
              ], 2)) : K("", !0),
              r.value.href ? (E(), S("button", {
                key: 1,
                type: "button",
                class: u(s(n).e("action-btn")),
                title: "Download attachment",
                onClick: p
              }, [
                U(s(te), { icon: "lucide:download" })
              ], 2)) : K("", !0),
              v.selected && l.value ? (E(), S(ye, { key: 2 }, [
                _("button", {
                  type: "button",
                  class: u([
                    s(n).e("action-btn"),
                    s(n).is("active", v.node.attrs.display !== "compact")
                  ]),
                  title: "Card display",
                  onClick: L[0] || (L[0] = (x) => h("card", x))
                }, [
                  U(s(te), { icon: "lucide:panel-top" })
                ], 2),
                _("button", {
                  type: "button",
                  class: u([
                    s(n).e("action-btn"),
                    s(n).is("active", v.node.attrs.display === "compact")
                  ]),
                  title: "Compact display",
                  onClick: L[1] || (L[1] = (x) => h("compact", x))
                }, [
                  U(s(te), { icon: "lucide:minus" })
                ], 2)
              ], 64)) : K("", !0)
            ], 2)
          ], 2)
        ], 2)
      ]),
      _: 1
    }, 8, ["data-block-id"]));
  }
}), Yi = Re.create({
  name: "attachment",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addOptions() {
    return {
      getCurrentDocument: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      display: {
        default: "card",
        parseHTML: (e) => e.dataset.display === "compact" ? "compact" : "card",
        renderHTML: (e) => ({
          "data-display": e.display === "compact" ? "compact" : "card"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="attachment"]'
      },
      {
        tag: 'a[data-type="attachment"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(this.options.HTMLAttributes, e, {
        "data-type": "attachment"
      })
    ];
  },
  addNodeView() {
    return Ze(Zi);
  },
  addCommands() {
    return {
      setAttachment: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: {
          assetId: e.assetId,
          display: e.display ?? "card"
        }
      }),
      setAttachmentDisplay: (e) => ({ commands: t }) => t.updateAttributes(this.name, { display: e })
    };
  }
}), Ji = ["src", "title"], Qi = ["title"], es = ["value", "disabled"], ut = 640, ts = /* @__PURE__ */ Ce({
  __name: "IframeNodeView",
  props: kt,
  setup(e) {
    const t = e, n = Ee("text-editor-iframe-node"), a = A(null), o = A(null), i = A(!1), r = A(0), m = A(0), l = A(9 / 16), c = A(!1);
    function d() {
      const y = t.getPos();
      typeof y == "number" && t.editor.commands.setNodeSelection(y);
    }
    function g(y) {
      const P = y.target;
      !(P.closest(`.${n.e("controls")}`) || P.closest(`.${n.e("caption")}`)) && c.value && d();
    }
    const f = B(() => t.node.attrs.fullWidth === !0), p = B(() => {
      if (f.value)
        return {
          width: "100%",
          aspectRatio: `${1 / l.value}`
        };
      const y = t.node.attrs.width || ut, P = t.node.attrs.height || y * l.value;
      return {
        width: `${y}px`,
        height: `${P}px`
      };
    }), h = B(() => f.value ? {
      width: "100%",
      maxWidth: "100%"
    } : {
      width: `${t.node.attrs.width || ut}px`,
      maxWidth: "100%"
    }), v = B(() => [
      n.b(),
      n.is("selected", t.selected),
      n.is("full-width", f.value),
      t.node.attrs.align === "center" ? n.m("center") : "",
      t.node.attrs.align === "right" ? n.m("right") : "",
      t.node.attrs.align === "left" ? n.m("left") : ""
    ]);
    He(() => {
      if (c.value = t.editor.isEditable, t.node.attrs.aspectRatio)
        l.value = t.node.attrs.aspectRatio;
      else if (t.node.attrs.src) {
        const y = Ko(t.node.attrs.src);
        l.value = y.ratio, t.updateAttributes({ aspectRatio: y.ratio });
      }
    }), t.editor.on("update", () => {
      c.value = t.editor.isEditable;
    });
    function L(y) {
      var P;
      if (c.value) {
        if (d(), i.value = !0, r.value = y.clientX, m.value = ((P = o.value) == null ? void 0 : P.offsetWidth) || t.node.attrs.width || ut, t.node.attrs.aspectRatio)
          l.value = t.node.attrs.aspectRatio;
        else {
          const Z = t.node.attrs.width || m.value, se = t.node.attrs.height || Z * l.value;
          Z && se && (l.value = se / Z);
        }
        window.addEventListener("mousemove", x), window.addEventListener("mouseup", M), document.body.style.cursor = "ew-resize";
      }
    }
    function x(y) {
      if (!i.value || !a.value || !o.value) return;
      const Z = t.editor.view.dom.clientWidth, se = y.clientX - r.value;
      let ie = m.value + se;
      ie = Math.max(200, Math.min(ie, Z - 40));
      const q = ie * l.value;
      a.value.style.width = `${ie}px`, a.value.style.height = `${q}px`, o.value.style.width = `${ie}px`;
    }
    function M() {
      if (i.value && (i.value = !1, window.removeEventListener("mousemove", x), window.removeEventListener("mouseup", M), document.body.style.cursor = "", a.value && o.value)) {
        const y = a.value.offsetWidth, P = a.value.offsetHeight;
        t.updateAttributes({
          width: y,
          height: P,
          aspectRatio: l.value
        }), a.value.style.width = "", a.value.style.height = "", o.value.style.width = "";
      }
    }
    function b(y) {
      t.updateAttributes({ align: y });
    }
    function j() {
      if (!f.value)
        t.updateAttributes({ fullWidth: !0 });
      else {
        const P = t.editor.view.dom.clientWidth, Z = Math.min(ut, P - 40), se = Z * l.value;
        t.updateAttributes({ fullWidth: !1, width: Z, height: se });
      }
    }
    function w() {
      const y = t.getPos();
      typeof y == "number" && t.editor.chain().focus().deleteRange({ from: y, to: y + t.node.nodeSize }).run();
    }
    function V(y) {
      y.key === "Enter" ? (y.preventDefault(), F()) : y.key === "Escape" || y.key === "ArrowDown" ? (y.preventDefault(), H()) : y.key === "ArrowUp" ? (y.preventDefault(), ee()) : (y.key === "Delete" || y.key === "Backspace") && (y.preventDefault(), w());
    }
    function z(y) {
      t.editor.commands.focus(), t.editor.chain().setTextSelection(y).scrollIntoView().run();
    }
    function F() {
      const y = t.getPos();
      typeof y == "number" && (t.editor.commands.focus(), t.editor.chain().setTextSelection(y + 1).createParagraphNear().scrollIntoView().run());
    }
    function H() {
      const y = t.getPos();
      typeof y == "number" && z(y + 1);
    }
    function ee() {
      const y = t.getPos();
      typeof y == "number" && z(y - 1);
    }
    return (y, P) => (E(), ke(s(ot), {
      "data-block-id": y.node.attrs.blockId || void 0
    }, {
      default: _e(() => [
        _("div", {
          ref_key: "containerRef",
          ref: o,
          class: u(v.value),
          style: Pe(h.value),
          tabindex: "0",
          onClick: g,
          onKeydown: V
        }, [
          _("div", {
            class: u(s(n).e("wrapper"))
          }, [
            y.node.attrs.src ? (E(), S("iframe", {
              key: 0,
              ref_key: "iframeRef",
              ref: a,
              class: u([
                s(n).e("iframe"),
                s(n).is("disabled", c.value && !y.node.attrs.interactive)
              ]),
              src: y.node.attrs.src,
              style: Pe(p.value),
              title: y.node.attrs.title || "",
              frameborder: "0",
              allowfullscreen: "",
              loading: "lazy",
              referrerpolicy: "no-referrer-when-downgrade",
              sandbox: "allow-scripts allow-same-origin allow-popups allow-forms",
              onClick: N(d, ["stop"])
            }, null, 14, Ji)) : K("", !0),
            c.value && !y.node.attrs.interactive ? (E(), S("div", {
              key: 1,
              class: u(s(n).e("overlay")),
              onClick: N(d, ["stop"])
            }, null, 2)) : K("", !0),
            c.value ? (E(), S("div", {
              key: 2,
              class: u(s(n).e("controls"))
            }, [
              _("div", {
                class: u(s(n).e("align-controls"))
              }, [
                _("button", {
                  class: u([
                    s(n).e("align-btn"),
                    s(n).is("active", y.node.attrs.align === "left")
                  ]),
                  title: "左对齐",
                  onClick: P[0] || (P[0] = N((Z) => b("left"), ["stop"]))
                }, [
                  U(s(te), { icon: "lucide:align-left" })
                ], 2),
                _("button", {
                  class: u([
                    s(n).e("align-btn"),
                    s(n).is("active", y.node.attrs.align === "center")
                  ]),
                  title: "居中",
                  onClick: P[1] || (P[1] = N((Z) => b("center"), ["stop"]))
                }, [
                  U(s(te), { icon: "lucide:align-center" })
                ], 2),
                _("button", {
                  class: u([
                    s(n).e("align-btn"),
                    s(n).is("active", y.node.attrs.align === "right")
                  ]),
                  title: "右对齐",
                  onClick: P[2] || (P[2] = N((Z) => b("right"), ["stop"]))
                }, [
                  U(s(te), { icon: "lucide:align-right" })
                ], 2)
              ], 2),
              _("button", {
                class: u([s(n).e("action-btn"), s(n).is("active", f.value)]),
                title: f.value ? "恢复原始大小" : "全宽显示",
                onClick: N(j, ["stop"])
              }, [
                U(s(te), {
                  icon: f.value ? "lucide:minimize-2" : "lucide:maximize-2"
                }, null, 8, ["icon"])
              ], 10, Qi),
              f.value ? K("", !0) : (E(), S("button", {
                key: 0,
                class: u(s(n).e("resize-handle")),
                title: "调整大小",
                onMousedown: N(L, ["prevent"])
              }, [
                U(s(te), { icon: "lucide:move-diagonal-2" })
              ], 34))
            ], 2)) : K("", !0),
            y.node.attrs.src ? K("", !0) : (E(), S("div", {
              key: 3,
              class: u(s(n).e("loading"))
            }, [
              _("div", {
                class: u(s(n).e("loading-content"))
              }, [
                _("div", {
                  class: u(s(n).e("loading-icon"))
                }, "🔗", 2),
                _("div", {
                  class: u(s(n).e("loading-text"))
                }, "Loading embed...", 2)
              ], 2)
            ], 2))
          ], 2),
          (c.value || y.node.attrs.title) && y.node.attrs.src ? (E(), S("input", {
            key: 0,
            value: y.node.attrs.title,
            class: u(s(n).e("caption")),
            placeholder: "Add caption",
            disabled: !c.value,
            onInput: P[3] || (P[3] = (Z) => t.updateAttributes({
              title: Z.target.value
            })),
            onKeydown: V
          }, null, 42, es)) : K("", !0)
        ], 38)
      ]),
      _: 1
    }, 8, ["data-block-id"]));
  }
}), ns = Re.create({
  name: "iframe",
  group: "block",
  selectable: !0,
  draggable: !0,
  atom: !0,
  addOptions() {
    return {
      allowedDomains: Xo,
      blockedDomains: [],
      themeOwner: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: {
        default: null,
        parseHTML: (e) => e.getAttribute("src"),
        renderHTML: (e) => ({
          src: e.src
        })
      },
      width: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("width");
          return t ? Number.parseInt(t, 10) : null;
        },
        renderHTML: (e) => ({
          width: e.width ? String(e.width) : null
        })
      },
      height: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("height");
          return t ? Number.parseInt(t, 10) : null;
        },
        renderHTML: (e) => ({
          height: e.height ? String(e.height) : null
        })
      },
      aspectRatio: {
        default: 9 / 16,
        // Default 16:9 aspect ratio
        parseHTML: () => null,
        // Don't parse from HTML
        renderHTML: () => ({})
        // Don't render to HTML
      },
      align: {
        default: "center",
        parseHTML: (e) => {
          const t = (e.dataset.align || e.getAttribute("align") || "left").toLowerCase();
          return ["left", "center", "right"].includes(t) ? t : "left";
        },
        renderHTML: (e) => ({
          "data-align": e.align || "center"
        })
      },
      title: {
        default: null,
        parseHTML: (e) => e.getAttribute("title"),
        renderHTML: (e) => ({
          title: e.title
        })
      },
      frameborder: {
        default: "0",
        renderHTML: () => ({
          frameborder: "0"
        })
      },
      allowfullscreen: {
        default: "true",
        renderHTML: () => ({
          allowfullscreen: "true"
        })
      },
      sandbox: {
        default: "allow-scripts allow-same-origin allow-popups allow-forms",
        renderHTML: (e) => ({
          sandbox: e.sandbox
        })
      },
      interactive: {
        default: !1,
        parseHTML: (e) => e.dataset.interactive === "true",
        renderHTML: (e) => ({
          "data-interactive": e.interactive ? "true" : "false"
        })
      },
      fullWidth: {
        default: !1,
        parseHTML: (e) => e.dataset.fullWidth === "true",
        renderHTML: (e) => ({
          "data-full-width": e.fullWidth ? "true" : "false"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "iframe[src]",
        getAttrs: (e) => {
          const t = e.getAttribute("src"), n = e.getAttribute("width"), a = e.getAttribute("height"), o = e.getAttribute("title"), i = e.dataset.align;
          return {
            assetId: e.dataset.assetId ?? null,
            src: t,
            width: n ? Number.parseInt(n, 10) : null,
            height: a ? Number.parseInt(a, 10) : null,
            title: o || null,
            align: i || "center"
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "iframe",
      Oe(this.options.HTMLAttributes, e, {
        loading: "lazy",
        referrerpolicy: "no-referrer-when-downgrade"
      })
    ];
  },
  addNodeView() {
    return Ze(ts);
  },
  addCommands() {
    return {
      setIframeAlign: (e) => ({ commands: t }) => t.updateAttributes(this.name, { align: e }),
      setIframe: (e) => ({ commands: t, editor: n }) => {
        if (!Tn(e.src, this.options))
          return !1;
        const a = Dt(e.src), o = n.view.dom, i = (o == null ? void 0 : o.clientWidth) || 800, r = Rt(
          a,
          i
        ), m = {
          src: a,
          width: e.width || r.width,
          height: e.height || r.height,
          title: e.title,
          align: e.align || "center",
          aspectRatio: r.height / r.width,
          interactive: e.interactive
        };
        return t.insertContent({
          type: this.name,
          attrs: m
        });
      },
      insertIframeURL: (e) => ({ commands: t }) => {
        const n = Dt(e);
        return t.setIframe({ src: n });
      },
      openIframeDialog: () => ({ editor: e }) => {
        const t = new CustomEvent("iframe:open-dialog", {
          detail: { editor: e }
        });
        return e.view.dom.dispatchEvent(t), !0;
      }
    };
  },
  // Add ProseMirror plugin for paste handling
  addProseMirrorPlugins() {
    const e = this;
    return [
      new Ne({
        key: new De("iframe-paste-handler"),
        props: {
          handlePaste: (t, n, a) => {
            var r, m;
            const o = (r = n.clipboardData) == null ? void 0 : r.getData("text/plain"), i = (m = n.clipboardData) == null ? void 0 : m.getData("text/html");
            if (i) {
              const l = gn(i);
              if (l)
                return It(
                  t,
                  e,
                  l.src,
                  l.width,
                  l.height,
                  l.title
                );
            }
            if (o && o.includes("<iframe")) {
              const l = gn(o);
              if (l)
                return It(
                  t,
                  e,
                  l.src,
                  l.width,
                  l.height,
                  l.title
                );
            }
            return o && /^https?:\/\/(?:www\.)?(?:youtube\.com\/watch\?v=[\w-]+|youtu\.be\/[\w-]+|youtube\.com\/embed\/[\w-]+|vimeo\.com\/\d+|player\.vimeo\.com\/video\/\d+|codepen\.io\/[\w-]+\/pen\/[\w-]+|codesandbox\.io\/[\w\/.-]+|figma\.com\/[\w\/.-]+|embed\.figma\.com\/[\w\/.-]+)$/.test(o.trim()) ? It(t, e, o.trim()) : !1;
          }
        }
      })
    ];
  }
});
function gn(e) {
  try {
    const a = new DOMParser().parseFromString(e, "text/html").querySelector("iframe");
    if (!a) {
      const l = e.match(/<iframe[^>]*src=["']([^"']+)["'][^>]*>/i);
      if (l) {
        const c = l[1], d = e.match(/width=["'](\d+)["']/i), g = e.match(/height=["'](\d+)["']/i), f = e.match(/title=["']([^"']+)["']/i);
        return {
          src: c,
          width: d ? Number.parseInt(d[1], 10) : void 0,
          height: g ? Number.parseInt(g[1], 10) : void 0,
          title: f ? f[1] : void 0
        };
      }
      return null;
    }
    const o = a.getAttribute("src");
    if (!o) return null;
    const i = a.getAttribute("width") ? Number.parseInt(a.getAttribute("width"), 10) : void 0, r = a.getAttribute("height") ? Number.parseInt(a.getAttribute("height"), 10) : void 0, m = a.getAttribute("title") || void 0;
    return { src: o, width: i, height: r, title: m };
  } catch {
    return null;
  }
}
function It(e, t, n, a, o, i) {
  if (!confirm(
    `Do you want to embed this content?

URL: ${n}

Click "OK" to create an embed, or "Cancel" to paste as plain text.`
  ) || !Tn(n, t.options))
    return !1;
  const m = Dt(n), l = t.editor.view.dom, c = (l == null ? void 0 : l.clientWidth) || 800, d = a || Rt(m, c).width, g = o || Rt(m, c).height, f = {
    src: m,
    width: d,
    height: g,
    title: i,
    align: "center",
    aspectRatio: g / d
  }, p = e.state.schema.nodes.iframe.create(f), h = e.state.tr.replaceSelectionWith(p);
  return e.dispatch(h), !0;
}
const as = (e) => Array.from(e), eo = (e, t, n = {}) => {
  if (!e)
    return !1;
  const a = as(t);
  return a.length === 0 ? !1 : (Promise.resolve(
    e.intakeFiles({
      source: "picker",
      files: a,
      anchorPos: n.anchorPos,
      context: n.context,
      htmlContent: n.htmlContent
    })
  ).catch((o) => {
    e.emitDiagnostic({
      code: "picker-intake-dispatch-failed",
      message: o instanceof Error ? o.message : "Failed to dispatch picked files.",
      severity: "error",
      stage: "intake",
      cause: o
    });
  }), !0);
}, is = (e) => Array.from(e), to = (e, t, n = {}) => {
  if (!e)
    return !1;
  const a = is(t);
  return a.length === 0 ? !1 : (Promise.resolve(
    e.intakeFiles({
      source: n.source ?? "programmatic",
      files: a,
      anchorPos: n.anchorPos,
      dropPos: n.dropPos,
      context: n.context,
      htmlContent: n.htmlContent
    })
  ).catch((o) => {
    e.emitDiagnostic({
      code: "programmatic-intake-dispatch-failed",
      message: o instanceof Error ? o.message : "Failed to dispatch programmatic files.",
      severity: "error",
      stage: "intake",
      cause: o
    });
  }), !0);
}, ss = ["src", "alt", "width", "height"], rs = ["title"], ls = ["onMousedown"], ms = ["disabled"], cs = /* @__PURE__ */ Ce({
  __name: "ImageNodeView",
  props: kt,
  setup(e) {
    const t = e, n = Ee("text-editor-image-node"), a = A(null), o = A(null), i = A(!1), r = A(0), m = A(0), l = A(0), c = A(0), d = A(1), g = A(!0), f = A(0), p = A(0), h = A(null), v = A(null), L = B(
      () => i.value ? f.value : t.node.attrs.width
    ), x = B(
      () => i.value ? p.value : t.node.attrs.height
    ), M = B(() => {
      const k = {};
      if (L.value && (k.width = `${L.value}px`), i.value) {
        const $ = h.value;
        if ($ === "nw" || $ === "sw") {
          const ue = f.value - l.value;
          k.transform = `translateX(${-ue}px)`;
        }
      }
      return k;
    }), b = ["nw", "ne", "sw", "se"], j = B(() => {
      var ue, he;
      const k = (he = (ue = t.editor) == null ? void 0 : ue.view) == null ? void 0 : he.dom;
      if (!k) return !1;
      const $ = k.clientWidth, ae = t.node.attrs.width;
      return ae && Math.abs(ae - $) < 10;
    });
    function w() {
      var he, ce, fe, we;
      const k = (ce = (he = t.editor) == null ? void 0 : he.view) == null ? void 0 : ce.dom;
      if (!k) return;
      const $ = k.clientWidth, ae = t.node.attrs.width || ((fe = a.value) == null ? void 0 : fe.naturalWidth) || 0, ue = t.node.attrs.height || ((we = a.value) == null ? void 0 : we.naturalHeight) || 0;
      if (j.value && v.value) {
        const O = ue / ae;
        t.updateAttributes({
          width: v.value,
          height: Math.round(v.value * O)
        }), v.value = null;
      } else {
        v.value = ae;
        const O = ue / ae;
        t.updateAttributes({
          width: $,
          height: Math.round($ * O)
        });
      }
    }
    function V() {
      const k = t.getPos();
      typeof k == "number" && t.editor.commands.setNodeSelection(k);
    }
    const z = A(t.node.attrs.alt || ""), F = A(!1), H = B(() => [
      n.b(),
      n.is("selected", t.selected),
      t.node.attrs.align === "center" ? n.m("center") : "",
      t.node.attrs.align === "right" ? n.m("right") : "",
      t.node.attrs.align === "left" ? n.m("left") : ""
    ]);
    function ee(k) {
      k.key === "Escape" && t.selected && (k.preventDefault(), k.stopPropagation(), ie());
    }
    He(() => {
      if (F.value = t.editor.isEditable, a.value) {
        const k = t.node.attrs.width || a.value.naturalWidth, $ = t.node.attrs.height || a.value.naturalHeight;
        k && $ && (d.value = $ / k);
      }
    }), Le(
      () => t.selected,
      (k) => {
        k ? document.addEventListener("keydown", ee) : document.removeEventListener("keydown", ee);
      },
      { immediate: !0 }
    ), ze(() => {
      document.removeEventListener("keydown", ee);
    }), t.editor.on("update", () => {
      F.value = t.editor.isEditable;
    });
    function y(k) {
      const $ = k.target.value;
      z.value = $, t.updateAttributes({ alt: $ });
    }
    function P(k) {
      k.key === "Enter" ? (k.preventDefault(), se()) : (k.key === "Escape" || k.key === "ArrowDown") && (k.preventDefault(), ie()), k.key === "ArrowUp" && (k.preventDefault(), je());
    }
    function Z(k) {
      t.editor.commands.focus(), t.editor.chain().setTextSelection(k).scrollIntoView().run();
    }
    function se() {
      const k = t.getPos();
      typeof k == "number" && (t.editor.commands.focus(), t.editor.chain().setTextSelection(k + 1).createParagraphNear().scrollIntoView().run());
    }
    function ie() {
      const k = t.getPos();
      typeof k == "number" && Z(k + 1);
    }
    function je() {
      const k = t.getPos();
      typeof k == "number" && Z(k - 1);
    }
    function oe(k, $) {
      var he, ce, fe, we;
      if (!F.value) return;
      V(), r.value = k.clientX, m.value = k.clientY, l.value = ((he = a.value) == null ? void 0 : he.offsetWidth) || t.node.attrs.width || 0, c.value = ((ce = a.value) == null ? void 0 : ce.offsetHeight) || t.node.attrs.height || 0, f.value = l.value, p.value = c.value, h.value = $ || "se", g.value = !k.shiftKey;
      const ae = t.node.attrs.width || ((fe = a.value) == null ? void 0 : fe.naturalWidth), ue = t.node.attrs.height || ((we = a.value) == null ? void 0 : we.naturalHeight);
      ae && ue ? d.value = ue / ae : d.value = 1, i.value = !0, window.addEventListener("mousemove", ve), window.addEventListener("mouseup", ge), window.addEventListener("keydown", le), window.addEventListener("keyup", de), document.body.style.cursor = q($ || "se");
    }
    function q(k) {
      switch (k) {
        case "nw":
        case "se":
          return "nwse-resize";
        case "ne":
        case "sw":
          return "nesw-resize";
        default:
          return "se-resize";
      }
    }
    function le(k) {
      k.key === "Shift" && (g.value = !1);
    }
    function de(k) {
      k.key === "Shift" && (g.value = !0);
    }
    function ve(k) {
      if (!i.value || !a.value || !o.value) return;
      k.preventDefault();
      const ae = t.editor.view.dom.clientWidth, ue = k.clientX - r.value, he = k.clientY - m.value;
      let ce = l.value, fe = c.value;
      const we = h.value;
      we === "se" ? (ce = l.value + ue, fe = g.value ? ce * d.value : c.value + he) : we === "sw" ? (ce = l.value - ue, fe = g.value ? ce * d.value : c.value + he) : we === "ne" ? (ce = l.value + ue, fe = g.value ? ce * d.value : c.value - he) : we === "nw" && (ce = l.value - ue, fe = g.value ? ce * d.value : c.value - he), ce = Math.max(50, Math.min(ce, ae)), fe = g.value ? ce * d.value : Math.max(50, fe), f.value = Math.round(ce), p.value = Math.round(fe);
    }
    function ge() {
      i.value && (t.updateAttributes({
        width: f.value,
        height: p.value
      }), i.value = !1, h.value = null, window.removeEventListener("mousemove", ve), window.removeEventListener("mouseup", ge), window.removeEventListener("keydown", le), window.removeEventListener("keyup", de), document.body.style.cursor = "");
    }
    function G(k) {
      t.editor.commands.setImageAlign(k);
    }
    return (k, $) => (E(), ke(s(ot), {
      "data-block-id": k.node.attrs.blockId || void 0
    }, {
      default: _e(() => [
        _("div", {
          ref_key: "containerRef",
          ref: o,
          class: u(H.value),
          style: Pe(M.value)
        }, [
          _("div", {
            class: u(s(n).e("wrapper"))
          }, [
            k.node.attrs.src ? (E(), S("img", {
              key: 0,
              ref_key: "imageRef",
              ref: a,
              class: u(s(n).e("image")),
              src: k.node.attrs.src,
              alt: k.node.attrs.alt || "",
              width: L.value,
              height: x.value,
              onClick: N(V, ["stop"])
            }, null, 10, ss)) : K("", !0),
            i.value ? (E(), S("div", {
              key: 1,
              class: u(s(n).e("size-tooltip"))
            }, W(f.value) + " × " + W(p.value), 3)) : K("", !0),
            k.selected && F.value ? (E(), S("div", {
              key: 2,
              class: u(s(n).e("controls"))
            }, [
              _("div", {
                class: u(s(n).e("align-controls"))
              }, [
                _("button", {
                  class: u([
                    s(n).e("align-btn"),
                    s(n).is("active", k.node.attrs.align === "left")
                  ]),
                  onClick: $[0] || ($[0] = N((ae) => G("left"), ["stop"]))
                }, [
                  U(s(te), { icon: "lucide:align-left" })
                ], 2),
                _("button", {
                  class: u([
                    s(n).e("align-btn"),
                    s(n).is("active", k.node.attrs.align === "center")
                  ]),
                  onClick: $[1] || ($[1] = N((ae) => G("center"), ["stop"]))
                }, [
                  U(s(te), { icon: "lucide:align-center" })
                ], 2),
                _("button", {
                  class: u([
                    s(n).e("align-btn"),
                    s(n).is("active", k.node.attrs.align === "right")
                  ]),
                  onClick: $[2] || ($[2] = N((ae) => G("right"), ["stop"]))
                }, [
                  U(s(te), { icon: "lucide:align-right" })
                ], 2)
              ], 2),
              _("button", {
                class: u([s(n).e("expand-btn"), s(n).is("active", j.value)]),
                title: j.value ? "Restore size" : "Expand to full width",
                onClick: N(w, ["stop"])
              }, [
                U(s(te), {
                  icon: j.value ? "lucide:minimize-2" : "lucide:maximize-2"
                }, null, 8, ["icon"])
              ], 10, rs)
            ], 2)) : K("", !0),
            k.selected && F.value ? (E(), S(ye, { key: 3 }, Be(b, (ae) => _("div", {
              key: ae,
              class: u([s(n).e("corner-handle"), s(n).em("corner-handle", ae)]),
              onMousedown: N((ue) => oe(ue, ae), ["prevent"])
            }, null, 42, ls)), 64)) : K("", !0)
          ], 2),
          F.value || k.node.attrs.alt ? tt((E(), S("input", {
            key: 0,
            "onUpdate:modelValue": $[3] || ($[3] = (ae) => z.value = ae),
            class: u(s(n).e("caption")),
            placeholder: "Add caption",
            disabled: !F.value,
            onChange: y,
            onKeydown: P
          }, null, 42, ms)), [
            [_t, z.value]
          ]) : K("", !0)
        ], 6)
      ]),
      _: 1
    }, 8, ["data-block-id"]));
  }
}), ds = /(?:^|\s)(!\[(.+|:?)]\((\S+)(?:(?:\s+)["'](\S+)["'])?\))$/, us = (e, t, n, a) => {
  e.emitDiagnostic({
    code: t,
    message: n,
    severity: "error",
    stage: "intake",
    cause: a
  });
}, ps = Re.create({
  name: "image",
  group: "block",
  draggable: !0,
  selectable: !0,
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: { default: null },
      alt: { default: null },
      title: { default: null },
      width: { default: null },
      height: { default: null },
      align: {
        default: "left",
        parseHTML: (e) => {
          const t = (e.dataset.align || e.getAttribute("align") || "left").toLowerCase();
          return ["left", "center", "right"].includes(t) ? t : "left";
        },
        renderHTML: (e) => ({
          "data-align": e.align || "left"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "img[src]",
        getAttrs: (e) => {
          if (typeof e == "string") return {};
          const t = e;
          return {
            assetId: t.dataset.assetId ?? null,
            src: t.getAttribute("src"),
            alt: t.getAttribute("alt"),
            title: t.getAttribute("title"),
            width: t.getAttribute("width"),
            height: t.getAttribute("height")
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "img",
      Oe(this.options.HTMLAttributes || {}, e)
    ];
  },
  addNodeView() {
    return Ze(cs);
  },
  addOptions() {
    return {
      filePlatformRuntime: null,
      HTMLAttributes: {}
    };
  },
  addCommands() {
    return {
      setImageAlign: (e) => ({ commands: t }) => t.updateAttributes(this.name, { align: e }),
      setImage: (e) => ({ commands: t, editor: n }) => {
        const a = t.insertContent({
          type: this.name,
          attrs: e
        });
        return a && e.src && fs(n.view, e.src, (o, i) => {
          hn(e.src, n.view, i);
        }), a;
      },
      uploadImage: (e, t = "programmatic") => () => this.options.filePlatformRuntime ? t === "programmatic" || t === "picker" ? to(
        this.options.filePlatformRuntime,
        [e],
        {
          source: t === "picker" ? "picker" : "programmatic",
          context: {
            nodeKind: "image",
            preferredNodeKind: "image"
          }
        }
      ) : (Promise.resolve(
        this.options.filePlatformRuntime.intakeFiles({
          source: t,
          files: [e],
          context: {
            nodeKind: "image",
            preferredNodeKind: "image"
          }
        })
      ).catch((n) => {
        const a = this.options.filePlatformRuntime;
        us(
          a,
          `${t}-image-intake-dispatch-failed`,
          n instanceof Error ? n.message : `Failed to dispatch ${t} image intake.`,
          n
        );
      }), !0) : !1,
      selectAndUploadImage: () => ({ dispatch: e }) => {
        if (!this.options.filePlatformRuntime)
          return !1;
        if (!e)
          return !0;
        const t = document.createElement("input");
        return t.type = "file", t.accept = "image/*", t.onchange = (n) => {
          const a = n.target;
          a.files && a.files.length && eo(
            this.options.filePlatformRuntime,
            a.files,
            {
              context: {
                nodeKind: "image",
                preferredNodeKind: "image"
              }
            }
          );
        }, t.click(), !0;
      }
    };
  },
  addInputRules() {
    return [
      Oo({
        find: ds,
        type: this.type,
        getAttributes: (e) => {
          const [, , t, n, a] = e;
          return { src: n, alt: t, title: a };
        }
      })
    ];
  },
  addProseMirrorPlugins() {
    const e = this;
    return [
      new Ne({
        appendTransaction(t, n, a) {
          const o = [];
          return t.some((i) => i.docChanged) && a.doc.descendants((i, r) => {
            i.type.name === "image" && i.attrs.src && (!i.attrs.width || !i.attrs.height) && o.push({ node: i, pos: r });
          }), o.length === 0 || o.forEach(({ node: i, pos: r }) => {
            const m = e.editor;
            m && hn(i.attrs.src, m.view, r);
          }), null;
        }
      })
    ];
  }
});
function fs(e, t, n) {
  e.state.doc.descendants((a, o) => {
    if (a.type.name === "image" && a.attrs.src === t)
      return n(a, o), !1;
  });
}
function hn(e, t, n) {
  gs(e).then((a) => {
    const o = t.state.doc.nodeAt(n);
    if (!o || o.type.name !== "image")
      return;
    const i = o.attrs;
    if (i.width == null || i.height == null) {
      const r = t.state.tr.setNodeMarkup(n, void 0, {
        ...i,
        width: i.width ?? a.width,
        height: i.height ?? a.height
      });
      t.dispatch(r);
    }
  }).catch(() => {
  });
}
function gs(e) {
  return new Promise((t, n) => {
    const a = new Image();
    a.onload = () => t({
      width: a.naturalWidth,
      height: a.naturalHeight
    }), a.onerror = n, a.src = e;
  });
}
const no = (e) => typeof e == "function" ? e() : e, hs = async (e, t) => {
  var a;
  if ((a = t == null ? void 0 : t.target) != null && a.isConnected)
    return { kind: "theme", lease: t };
  if (t && t.release(), !e || e.state !== "active")
    return { kind: "document" };
  const n = await e.acquirePortal();
  return n.ok ? n.value.target.isConnected ? { kind: "theme", lease: n.value } : (n.value.release(), { kind: "unavailable" }) : { kind: "unavailable" };
}, jn = (e, t) => {
  var a, o;
  if ((o = (a = t.portalLease) == null ? void 0 : a.target) != null && o.isConnected)
    return Promise.resolve({
      kind: "theme",
      lease: t.portalLease
    });
  if (t.portalInFlight)
    return t.portalInFlight;
  const n = hs(e, t.portalLease).then(
    (i) => (t.portalInFlight === n && (t.portalInFlight = null), t.disposed ? (i.kind === "theme" && i.lease !== t.portalLease && i.lease.release(), { kind: "unavailable" }) : i.kind === "theme" ? t.portalLease && t.portalLease !== i.lease && t.portalLease.target.isConnected ? (i.lease.release(), { kind: "theme", lease: t.portalLease }) : (t.portalLease = i.lease, i) : (t.portalLease && !t.portalLease.target.isConnected && (t.portalLease = null), i))
  );
  return t.portalInFlight = n, n;
}, St = (e, t) => {
  const n = t.minQueryLength ?? 0, o = t.initialItems !== void 0 && (e.loading || n > 0 && e.query.length < n) ? no(t.initialItems) ?? [] : e.items, i = typeof t.loading == "function" ? t.loading({
    editor: e.editor,
    query: e.query,
    items: o,
    loading: e.loading
  }) : t.loading ?? e.loading;
  return {
    ...e,
    items: o,
    loading: i
  };
};
function Ct(e) {
  return We.create({
    name: e.name,
    addOptions() {
      var n;
      const t = e.addOptions ? e.addOptions.call(this) : {};
      return {
        themeOwner: e.themeOwner ?? null,
        ...t,
        suggestion: {
          char: e.char,
          pluginKey: e.pluginKey,
          items: ({ query: a, editor: o, signal: i }) => e.items({ query: a, editor: o, signal: i }),
          command: e.command,
          allowSpaces: e.allowSpaces,
          allowToIncludeChar: e.allowToIncludeChar,
          allowedPrefixes: e.allowedPrefixes,
          startOfLine: e.startOfLine,
          decorationTag: e.decorationTag || "span",
          decorationClass: e.decorationClass || "suggestion",
          decorationContent: e.decorationContent,
          decorationEmptyClass: e.decorationEmptyClass,
          minQueryLength: e.minQueryLength,
          debounce: e.debounce,
          initialItems: e.initialItems,
          loading: void 0,
          placement: e.placement,
          // Upstream takes the gap only in pixels, so its offset is zeroed
          // and a scale-derived one runs ahead of flip instead.
          offset: { mainAxis: 0, crossAxis: 0 },
          container: e.container,
          flip: !1,
          floatingUi: {
            ...e.floatingUi,
            middleware: [
              Qn(e.gap ?? 2),
              ...e.flip === !1 ? [] : [Wn()],
              ...((n = e.floatingUi) == null ? void 0 : n.middleware) ?? []
            ]
          },
          dismissOnOutsideClick: e.dismissOnOutsideClick,
          shouldShow: e.shouldShow,
          shouldResetDismissed: e.shouldResetDismissed,
          allow: e.allow,
          findSuggestionMatch: e.findSuggestionMatch
        }
      };
    },
    addStorage() {
      return {
        disposed: !1,
        portalLease: null,
        portalInFlight: null
      };
    },
    onCreate() {
      jn(this.options.themeOwner, this.storage);
    },
    onDestroy() {
      var t;
      this.storage.disposed = !0, this.storage.portalInFlight = null, (t = this.storage.portalLease) == null || t.release(), this.storage.portalLease = null;
    },
    addProseMirrorPlugins() {
      const {
        initialItems: t,
        loading: n,
        render: a,
        ...o
      } = this.options.suggestion, i = this.options.suggestion, r = this.storage;
      return [
        Kn({
          editor: this.editor,
          ...o,
          initialItems: no(t),
          render: () => {
            let m = null, l = null, c = 0, d = null;
            const g = () => {
              const f = m == null ? void 0 : m.element;
              l == null || l(), m && m.destroy(), f instanceof HTMLElement && f.remove(), l = null, m = null;
            };
            return {
              onStart: async (f) => {
                const p = ++c;
                d = f;
                const h = await jn(
                  this.options.themeOwner,
                  r
                );
                if (p !== c || this.editor.isDestroyed || h.kind === "unavailable")
                  return;
                const v = d, L = St(
                  v,
                  i
                );
                m = new xi(e.component, {
                  editor: L.editor,
                  props: L
                }), m.element instanceof HTMLElement && (h.kind === "theme" && h.lease.target.appendChild(m.element), l = L.mount(m.element), d && d !== v && m.updateProps(
                  St(
                    d,
                    i
                  )
                ));
              },
              onUpdate(f) {
                d = f, m == null || m.updateProps(
                  St(f, i)
                );
              },
              onKeyDown(f) {
                return (f.event.key === "Escape" || f.event.key === "Esc") && f.event.stopPropagation(), m && m.ref && typeof m.ref.onKeyDown == "function" ? m.ref.onKeyDown(f) : !1;
              },
              onExit() {
                c += 1, d = null, g();
              }
            };
          }
        })
      ];
    }
  });
}
const js = ["onClick", "onMouseover"], Ft = /* @__PURE__ */ Ce({
  __name: "SuggestionList",
  props: {
    items: {
      type: Array,
      required: !0
    },
    command: {
      type: Function,
      required: !0
    },
    wide: {
      type: Boolean,
      default: !1
    },
    showNoResults: {
      type: Boolean,
      default: !1
    },
    loading: {
      type: Boolean,
      default: !1
    }
  },
  setup(e, { expose: t }) {
    const n = e, a = Ee("text-editor-suggestion"), o = A(0), i = A(null), r = A([]);
    $n(() => {
      r.value = [];
    });
    const m = () => {
      Me(() => {
        const p = r.value[o.value];
        p && p.scrollIntoView({ block: "nearest" });
      });
    }, l = (p) => {
      const h = n.items[p];
      h && n.command(h);
    }, c = ({ event: p }) => n.items.length ? p.key === "ArrowUp" ? (d(), !0) : p.key === "ArrowDown" ? (g(), !0) : p.key === "Enter" ? (f(), !0) : !1 : !1, d = () => {
      o.value = (o.value + n.items.length - 1) % n.items.length, m();
    }, g = () => {
      o.value = (o.value + 1) % n.items.length, m();
    }, f = () => {
      l(o.value);
    };
    return Le(
      () => n.items,
      () => {
        o.value = 0;
      }
    ), t({
      onKeyDown: c
    }), (p, h) => e.items.length || e.loading || e.showNoResults ? (E(), S("div", {
      key: 0,
      ref_key: "container",
      ref: i,
      class: u([s(a).b(), e.wide ? s(a).m("wide") : ""])
    }, [
      e.loading ? (E(), S("div", {
        key: 0,
        class: u(s(a).e("loading")),
        "aria-live": "polite"
      }, " Loading... ", 2)) : K("", !0),
      (E(!0), S(ye, null, Be(e.items, (v, L) => (E(), S("button", {
        key: L,
        ref_for: !0,
        ref: (x) => {
          x && (r.value[L] = x);
        },
        class: u([s(a).e("item"), s(a).is("selected", L === o.value)]),
        onClick: (x) => l(L),
        onMouseover: (x) => o.value = L
      }, [
        zn(p.$slots, "default", {
          item: v,
          index: L
        }, () => [
          _("span", null, W(v.display || v.label || v.title || v.name), 1)
        ])
      ], 42, js))), 128)),
      !e.loading && !e.items.length && e.showNoResults ? (E(), S("div", {
        key: 1,
        class: u(s(a).e("no-results"))
      }, " No results ", 2)) : K("", !0)
    ], 2)) : K("", !0);
  }
});
function vs(e) {
  const t = {
    name: "mention",
    group: "inline",
    inline: !0,
    selectable: !0,
    atom: !0,
    addOptions() {
      return {
        component: void 0
      };
    },
    addAttributes() {
      return {
        id: {
          default: null,
          parseHTML: (n) => n.dataset.id,
          renderHTML: (n) => n.id ? { "data-id": n.id } : {}
        },
        label: {
          default: null,
          parseHTML: (n) => n.dataset.label,
          renderHTML: (n) => n.label ? { "data-label": n.label } : {}
        }
      };
    },
    parseHTML() {
      return [
        {
          tag: 'span.mention[data-type="mention"]',
          getAttrs: (n) => {
            const a = n;
            return {
              id: a.dataset.id,
              label: a.dataset.label
            };
          }
        }
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return [
        "span",
        Oe(n, {
          class: "mention",
          "data-type": "mention"
        }),
        `@${n["data-label"] || n.id || ""}`
      ];
    },
    renderText({ node: n }) {
      return `@${n.attrs.label || n.attrs.id || ""}`;
    }
  };
  return e && (t.addNodeView = () => Ze(e)), Re.create(t);
}
const bs = Ct({
  name: "mentionSuggestion",
  char: "@",
  pluginKey: new De("mentionSuggestion"),
  component: Ft,
  addOptions() {
    return {
      mentions: []
    };
  },
  items: ({ query: e, editor: t }) => {
    const { mentions: n } = t.extensionManager.extensions.find(
      (i) => i.name === "mentionSuggestion"
    ).options;
    return lt(n).filter(
      (i) => i.label.toLowerCase().startsWith(e.toLowerCase())
    ).slice(0, 10).map((i) => ({
      ...i,
      display: i.label
    }));
  },
  command: ({ editor: e, range: t, props: n }) => {
    const a = {
      id: n.id || n.value,
      label: n.label
    };
    e.chain().focus().insertContentAt(t, [
      {
        type: "mention",
        attrs: a
      }
    ]).run();
  },
  placement: "bottom-start",
  gap: 4,
  allowSpaces: !1,
  decorationTag: "span",
  decorationClass: "mention-suggestion-active"
}), _s = We.create({
  name: "mentionExtension",
  addOptions() {
    return {
      mentions: [],
      component: void 0,
      suggestion: {},
      themeOwner: null
    };
  },
  addExtensions() {
    return [
      vs(this.options.component),
      bs.configure({
        mentions: this.options.mentions,
        suggestion: this.options.suggestion,
        themeOwner: this.options.themeOwner ?? null
      })
    ];
  }
});
function ys(e) {
  const {
    targetRef: t,
    zoomLevel: n,
    panThreshold: a = 10,
    onSwipeLeft: o,
    onSwipeRight: i,
    onDoubleTap: r,
    onTap: m,
    onPanStart: l,
    onPanMove: c,
    onPanAnimate: d,
    onPinchStart: g,
    onPinchMove: f,
    onPinchEnd: p
  } = e, h = A(!1), v = A(!1), L = A(!1);
  let x = 0, M = 0, b = 0, j = 0, w = !1, V = null, z = 0, F = 0, H = 0, ee = 0, y = 0;
  function P(q, le) {
    const de = q.clientX - le.clientX, ve = q.clientY - le.clientY;
    return Math.sqrt(de * de + ve * ve);
  }
  function Z(q) {
    var de;
    if (!((de = t.value) != null && de.contains(q.target))) return;
    w = !1;
    const le = Date.now();
    if (q.touches.length === 2)
      v.value = !0, j = P(q.touches[0], q.touches[1]), g == null || g();
    else if (q.touches.length === 1) {
      if (x = q.touches[0].clientX, M = q.touches[0].clientY, ee = x, y = M, H = le, le - b < 300) {
        r == null || r(q), b = 0;
        return;
      }
      b = le;
    }
  }
  function se(q) {
    var de;
    if (!((de = t.value) != null && de.contains(q.target))) return;
    const le = Date.now();
    if (q.touches.length === 2 && v.value) {
      q.preventDefault();
      const ge = P(q.touches[0], q.touches[1]) / j;
      f == null || f(ge);
    } else if (q.touches.length === 1) {
      const ve = q.touches[0].clientX, ge = q.touches[0].clientY, G = ve - x, k = ge - M, $ = le - H;
      $ > 0 && (z = (ve - ee) / $, F = (ge - y) / $), ee = ve, y = ge, H = le, !w && (Math.abs(G) > a || Math.abs(k) > a) && (w = !0, h.value = !0, l == null || l()), w && n.value > 100 && (q.preventDefault(), c == null || c(G, k));
    }
  }
  function ie(q) {
    if (v.value && q.touches.length < 2 && (v.value = !1, p == null || p()), q.touches.length === 0) {
      if (h.value)
        h.value = !1, n.value > 100 && (Math.abs(z) > 0.1 || Math.abs(F) > 0.1) && je();
      else if (!w && !v.value)
        m == null || m(q);
      else if (w && n.value <= 100) {
        const le = ee - x;
        Math.abs(le) > 50 && (le > 0 ? i == null || i() : o == null || o());
      }
      w = !1;
    }
  }
  function je() {
    L.value = !0;
    const q = 0.95, le = 0.01;
    function de() {
      if (z *= q, F *= q, Math.abs(z) < le && Math.abs(F) < le) {
        L.value = !1, V = null;
        return;
      }
      d == null || d(z * 16, F * 16), V = requestAnimationFrame(de);
    }
    V = requestAnimationFrame(de);
  }
  function oe() {
    V !== null && (cancelAnimationFrame(V), V = null), L.value = !1;
  }
  return He(() => {
    const q = t.value;
    q && (q.addEventListener("touchstart", Z, {
      passive: !1
    }), q.addEventListener("touchmove", se, { passive: !1 }), q.addEventListener("touchend", ie));
  }), ze(() => {
    const q = t.value;
    q && (q.removeEventListener("touchstart", Z), q.removeEventListener("touchmove", se), q.removeEventListener("touchend", ie)), oe();
  }), {
    isPanning: h,
    isPinching: v,
    isAnimatingPan: L
  };
}
function ws(e) {
  const { initialIndex: t, imageCount: n, onNavigate: a } = e, o = A(t.value);
  Le(t, (m) => {
    o.value = m;
  });
  function i() {
    n.value <= 1 || (o.value = (o.value + 1) % n.value, a == null || a());
  }
  function r() {
    n.value <= 1 || (o.value = (o.value - 1 + n.value) % n.value, a == null || a());
  }
  return {
    currentIndex: o,
    nextImage: i,
    previousImage: r
  };
}
function ks(e) {
  const {
    containerRef: t,
    isEnabled: n,
    minZoom: a = 25,
    maxZoom: o = 300,
    zoomStep: i = 25
  } = e, r = A(100), m = A({ x: 0, y: 0 }), l = A(!1), c = A({ x: 0, y: 0 }), d = 90, g = 110;
  let f = 0, p = 0, h = 0, v = 0;
  function L() {
    const z = Math.min(o, r.value + i);
    r.value = z;
  }
  function x() {
    const z = Math.max(a, r.value - i);
    r.value = z, z <= 100 && (m.value = { x: 0, y: 0 });
  }
  function M() {
    r.value = 100, m.value = { x: 0, y: 0 };
  }
  function b(z) {
    r.value <= 100 || (l.value = !0, f = z.clientX, p = z.clientY, h = m.value.x, v = m.value.y, document.addEventListener("mousemove", j), document.addEventListener("mouseup", w));
  }
  function j(z) {
    if (!l.value) return;
    const F = z.clientX - f, H = z.clientY - p;
    m.value = {
      x: h + F,
      y: v + H
    };
  }
  function w() {
    l.value = !1, document.removeEventListener("mousemove", j), document.removeEventListener("mouseup", w);
  }
  function V(z) {
    var F;
    n.value && (F = t.value) != null && F.contains(z.target) && (z.preventDefault(), z.deltaY < 0 ? L() : x());
  }
  return He(() => {
    document.addEventListener("wheel", V, { passive: !1 });
  }), ze(() => {
    document.removeEventListener("wheel", V), document.removeEventListener("mousemove", j), document.removeEventListener("mouseup", w);
  }), {
    zoomLevel: r,
    panPosition: m,
    isMousePanning: l,
    initialPanPositionOnGestureStart: c,
    zoomIn: L,
    zoomOut: x,
    resetZoom: M,
    handlePanStart: b,
    snapThresholdLower: d,
    snapThresholdUpper: g
  };
}
const Cs = ["src", "alt"], xs = 3e3, oo = /* @__PURE__ */ Ce({
  name: "ZxTextEditorImageViewer",
  __name: "image-viewer-modal",
  props: {
    show: { type: Boolean },
    images: {},
    initialIndex: {},
    portalBinding: {}
  },
  emits: ["update:show", "terminal-close"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = Ee("text-editor-image-viewer"), i = n.portalBinding.target.ownerDocument, r = A(null), m = A(null), l = A(null), c = A(0), d = A(!1), g = A(100), f = A(!0), p = A(null), {
      zoomLevel: h,
      panPosition: v,
      isMousePanning: L,
      initialPanPositionOnGestureStart: x,
      zoomIn: M,
      zoomOut: b,
      resetZoom: j,
      handlePanStart: w,
      snapThresholdLower: V,
      snapThresholdUpper: z
    } = ks({
      containerRef: r,
      isEnabled: mn(n, "show")
    }), { currentIndex: F, nextImage: H, previousImage: ee } = ws({
      initialIndex: mn(n, "initialIndex"),
      imageCount: B(() => n.images.length),
      onNavigate: j
    }), y = B(() => n.images[F.value]), {
      isPanning: P,
      isPinching: Z,
      isAnimatingPan: se
    } = ys({
      targetRef: r,
      zoomLevel: h,
      panThreshold: 10,
      onSwipeLeft: () => {
        h.value <= 100 && H();
      },
      onSwipeRight: () => {
        h.value <= 100 && ee();
      },
      onDoubleTap: (G) => {
        var k;
        (k = l.value) != null && k.contains(G.target) || (h.value > 100 ? j() : (h.value = 200, v.value = { x: 0, y: 0 }));
      },
      onTap: (G) => {
        G.target === m.value && q();
      },
      onPanStart: () => {
        h.value <= 100 || (x.value = { ...v.value });
      },
      onPanMove: (G, k) => {
        h.value <= 100 || (v.value = {
          x: x.value.x + G,
          y: x.value.y + k
        });
      },
      onPanAnimate: (G, k) => {
        v.value = {
          x: v.value.x + G,
          y: v.value.y + k
        };
      },
      onPinchStart: () => {
        g.value = h.value, x.value = { ...v.value };
      },
      onPinchMove: (G) => {
        const k = g.value * G;
        let $ = Math.max(25, Math.min(300, Math.round(k)));
        $ > V && $ < z && ($ = 100), h.value = $;
      },
      onPinchEnd: () => {
        h.value < 100 && j(), x.value = { x: 0, y: 0 };
      }
    }), ie = B(() => L.value || P.value);
    function je() {
      f.value = !0, p.value && clearTimeout(p.value), p.value = setTimeout(() => {
        !ie.value && !Z.value ? f.value = !1 : je();
      }, xs);
    }
    function oe() {
      (!Z.value || !f.value) && je();
    }
    function q() {
      a("update:show", !1), j(), p.value && (clearTimeout(p.value), p.value = null);
    }
    function le() {
      var ae;
      const G = y.value, k = i.createElement("a");
      k.href = G.src;
      const $ = ((ae = G.alt) == null ? void 0 : ae.replace(/[^a-z0-9]/gi, "_").toLowerCase()) || G.src.split("/").pop() || "download";
      k.download = $.includes(".") ? $ : `${$}.jpg`, i.body.appendChild(k), k.click(), i.body.removeChild(k);
    }
    function de() {
      const G = r.value;
      d.value ? i.exitFullscreen && (i.exitFullscreen(), d.value = !1) : G != null && G.requestFullscreen && (G.requestFullscreen(), d.value = !0);
    }
    function ve() {
      d.value = !!i.fullscreenElement;
    }
    function ge(G) {
      if (n.show)
        switch (oe(), G.key) {
          case "ArrowLeft":
            ie.value || ee(), G.preventDefault();
            break;
          case "ArrowRight":
            ie.value || H(), G.preventDefault();
            break;
          case "+":
          case "=":
            M(), G.preventDefault();
            break;
          case "-":
            b(), G.preventDefault();
            break;
          case "Escape":
            q(), G.preventDefault();
            break;
          case "f":
          case "F":
            de(), G.preventDefault();
            break;
        }
    }
    return Le(
      () => n.show,
      (G) => {
        G ? (f.value = !0, j(), je()) : (p.value && (clearTimeout(p.value), p.value = null), d.value && i.exitFullscreen && i.exitFullscreen());
      }
    ), Le(l, (G) => {
      if (G) {
        const k = () => {
          c.value = G.offsetHeight;
        }, $ = new ResizeObserver(k);
        $.observe(G), k(), ze(() => $.disconnect());
      } else
        c.value = 0;
    }), He(() => {
      i.addEventListener("fullscreenchange", ve), i.addEventListener("keydown", ge);
    }), ze(() => {
      i.removeEventListener("fullscreenchange", ve), i.removeEventListener("keydown", ge), p.value && clearTimeout(p.value), d.value && i.exitFullscreen && i.exitFullscreen();
    }), (G, k) => (E(), ke(Fn, {
      to: n.portalBinding.target
    }, [
      U(Hn, {
        "enter-active-class": s(o).m("enter-active"),
        "leave-active-class": s(o).m("leave-active"),
        "enter-from-class": s(o).m("enter-from"),
        "leave-to-class": s(o).m("leave-to"),
        onAfterLeave: k[11] || (k[11] = ($) => G.$emit("terminal-close")),
        appear: ""
      }, {
        default: _e(() => [
          n.show ? (E(), S("div", {
            key: 0,
            ref_key: "imageContainer",
            ref: r,
            class: u(s(o).b()),
            onMousemove: oe,
            onTouchstart: oe,
            onTouchmove: oe
          }, [
            _("div", {
              ref_key: "backdropElement",
              ref: m,
              class: u(s(o).e("backdrop")),
              onClick: q
            }, null, 2),
            _("div", {
              class: u(s(o).e("image-container"))
            }, [
              _("img", {
                src: y.value.src,
                alt: y.value.alt || "Image preview",
                class: u([
                  s(o).e("image"),
                  s(o).is("zoomed", s(h) > 100),
                  s(o).is("panning", s(L))
                ]),
                style: Pe({
                  transform: `scale(${s(h) / 100}) translate(${s(v).x}px, ${s(v).y}px)`,
                  transition: ie.value || s(Z) || s(se) ? "none" : "transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)"
                }),
                draggable: "false",
                onMousedown: k[0] || (k[0] = //@ts-ignore
                (...$) => s(w) && s(w)(...$))
              }, null, 46, Cs)
            ], 2),
            y.value.alt ? (E(), S("div", {
              key: 0,
              class: u([s(o).e("caption"), s(o).is("hidden", !f.value)])
            }, W(y.value.alt), 3)) : K("", !0),
            _("div", {
              ref_key: "controlsBar",
              ref: l,
              class: u([s(o).e("controls"), s(o).is("hidden", !f.value)]),
              onTouchstart: k[6] || (k[6] = N(() => {
              }, ["stop"])),
              onTouchmove: k[7] || (k[7] = N(() => {
              }, ["stop"])),
              onTouchend: k[8] || (k[8] = N(() => {
              }, ["stop"])),
              onMousedown: k[9] || (k[9] = N(() => {
              }, ["stop"])),
              onWheel: k[10] || (k[10] = N(() => {
              }, ["stop"]))
            }, [
              _("div", {
                class: u(s(o).e("control-group"))
              }, [
                U(s(qe), {
                  content: "Previous image",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u([s(o).e("btn"), s(o).m("left")]),
                      type: "button",
                      onClick: k[1] || (k[1] = N(
                        //@ts-ignore
                        (...$) => s(ee) && s(ee)(...$),
                        ["stop"]
                      ))
                    }, [
                      U(s(te), {
                        icon: "lucide:chevron-left",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                _("span", {
                  class: u(s(o).e("text"))
                }, W(s(F) + 1) + "/" + W(n.images.length), 3),
                U(s(qe), {
                  content: "Next image",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u([s(o).e("btn"), s(o).m("right")]),
                      type: "button",
                      onClick: k[2] || (k[2] = N(
                        //@ts-ignore
                        (...$) => s(H) && s(H)(...$),
                        ["stop"]
                      ))
                    }, [
                      U(s(te), {
                        icon: "lucide:chevron-right",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"])
              ], 2),
              _("div", {
                class: u(s(o).e("control-group"))
              }, [
                U(s(qe), {
                  content: "Zoom out",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u([s(o).e("btn"), s(o).m("left")]),
                      type: "button",
                      onClick: k[3] || (k[3] = N(
                        //@ts-ignore
                        (...$) => s(b) && s(b)(...$),
                        ["stop"]
                      ))
                    }, [
                      U(s(te), {
                        icon: "lucide:minus",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                U(s(qe), {
                  content: "Reset zoom",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u(s(o).e("btn")),
                      type: "button",
                      onClick: k[4] || (k[4] = N(
                        //@ts-ignore
                        (...$) => s(j) && s(j)(...$),
                        ["stop"]
                      ))
                    }, [
                      _("span", {
                        class: u(s(o).e("text"))
                      }, W(s(h)) + "%", 3)
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                U(s(qe), {
                  content: "Zoom in",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u([s(o).e("btn"), s(o).m("right")]),
                      type: "button",
                      onClick: k[5] || (k[5] = N(
                        //@ts-ignore
                        (...$) => s(M) && s(M)(...$),
                        ["stop"]
                      ))
                    }, [
                      U(s(te), {
                        icon: "lucide:plus",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"])
              ], 2),
              _("div", {
                class: u(s(o).e("control-group"))
              }, [
                U(s(qe), {
                  content: "Download image",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u([s(o).e("btn"), s(o).m("left")]),
                      type: "button",
                      onClick: N(le, ["stop"])
                    }, [
                      U(s(te), {
                        icon: "lucide:download",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                U(s(qe), {
                  content: d.value ? "Exit fullscreen" : "Enter fullscreen",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u([s(o).e("btn"), s(o).m("right"), s(o).m("hidden-mobile")]),
                      type: "button",
                      onClick: N(de, ["stop"])
                    }, [
                      U(s(te), {
                        icon: d.value ? "lucide:minimize" : "lucide:maximize",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["icon", "class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["content", "append-to"])
              ], 2),
              _("div", {
                class: u(s(o).e("control-group"))
              }, [
                U(s(qe), {
                  content: "Close",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: _e(() => [
                    _("button", {
                      class: u(s(o).e("btn")),
                      type: "button",
                      onClick: N(q, ["stop"])
                    }, [
                      U(s(te), {
                        icon: "lucide:x",
                        class: u(s(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"])
              ], 2)
            ], 34)
          ], 34)) : K("", !0)
        ]),
        _: 1
      }, 8, ["enter-active-class", "leave-active-class", "enter-from-class", "leave-to-class"])
    ], 8, ["to"]));
  }
}), Es = We.create({
  name: "imageViewer",
  addOptions() {
    return { themeOwner: null };
  },
  addStorage() {
    return { destroyed: !1, disposers: /* @__PURE__ */ new Set() };
  },
  onDestroy() {
    this.storage.destroyed = !0;
    for (const e of [...this.storage.disposers]) e();
    this.storage.disposers.clear();
  },
  addCommands() {
    return {
      openImageViewer: (e) => ({ editor: t }) => {
        const n = [];
        t.state.doc.descendants((o) => (o.type.name === "image" && n.push({
          src: o.attrs.src,
          alt: o.attrs.alt || null
        }), !0));
        const a = n.findIndex((o) => o.src === e);
        return Ls(
          this.options.themeOwner,
          n,
          a,
          (o) => {
            this.storage.destroyed ? o() : this.storage.disposers.add(o);
          },
          (o) => this.storage.disposers.delete(o)
        ), !0;
      }
    };
  },
  addProseMirrorPlugins() {
    const e = this;
    return [
      new Ne({
        key: new De("imageViewer"),
        props: {
          handleClick(t, n, a) {
            var m;
            if (e.editor.isEditable)
              return !1;
            const { state: o } = t, i = o.doc.nodeAt(n);
            if ((i == null ? void 0 : i.type.name) === "image") {
              a.preventDefault();
              const l = i.attrs.src;
              return e.editor.commands.openImageViewer(l), !0;
            }
            const r = (m = t.dom.ownerDocument.defaultView) == null ? void 0 : m.HTMLImageElement;
            if (r && a.target instanceof r) {
              let l = !1;
              if (o.doc.descendants((c, d) => {
                if (c.type.name === "image" && !l) {
                  const g = t.nodeDOM(d);
                  if (g && (g === a.target || g.contains(a.target)))
                    return a.preventDefault(), e.editor.commands.openImageViewer(c.attrs.src), l = !0, !1;
                }
                return !0;
              }), l) return !0;
            }
            return !1;
          }
        }
      })
    ];
  }
});
async function Ls(e, t, n, a, o) {
  if (!e) return;
  const i = await e.acquirePortal();
  if (!i.ok) return;
  const r = i.value, m = r.target.ownerDocument.createElement("div");
  r.target.appendChild(m);
  let l = !1;
  const c = () => {
    l || (l = !0, et(null, m), m.remove(), r.release(), o(c));
  };
  a(c);
  const d = Nt(oo, {
    show: !0,
    images: t,
    initialIndex: n,
    portalBinding: r,
    "onUpdate:show": (g) => {
      !g && !m.isConnected && c();
    },
    onTerminalClose: c
  });
  d.appContext = r.appContext;
  try {
    et(d, m);
  } catch {
    c();
  }
}
const Ts = Ct({
  name: "tagSuggestion",
  char: "#",
  pluginKey: new De("tagSuggestion"),
  component: Ft,
  addOptions() {
    return {
      tags: [],
      suggestion: {}
    };
  },
  items: ({ query: e, editor: t }) => {
    const { tags: n } = t.extensionManager.extensions.find(
      (i) => i.name === "tagSuggestion"
    ).options, a = lt(n), o = a.filter(
      (i) => i.label.toLowerCase().startsWith(e.toLowerCase())
    ).map((i) => ({ ...i, display: i.label }));
    return e.length > 0 && !a.some(
      (i) => i.label.toLowerCase() === e.toLowerCase()
    ) && o.push({
      display: `New tag: "${e}"`,
      label: e,
      isNew: !0
    }), o;
  },
  command: ({ editor: e, range: t, props: n }) => {
    const a = {
      tagLabel: n.label,
      ...n.id && !n.isNew && { tagId: n.id }
    };
    e.chain().focus().insertContentAt(t, [
      {
        type: In.name,
        attrs: a
      },
      {
        type: "text",
        text: " "
      }
    ]).run();
  },
  placement: "bottom-start",
  gap: 4,
  allowSpaces: !1,
  decorationTag: "span",
  decorationClass: "tag-suggestion-active"
});
class At extends Error {
  constructor(t, n) {
    super(n), this.name = "ZxHostAssetUploadError", this.code = t;
  }
}
const Is = (e, t) => e instanceof Error && e.message ? e.message : t, Ss = async ({
  context: e,
  expectedNodeKind: t,
  file: n,
  filePlatformRuntime: a,
  source: o = "programmatic"
}) => {
  if (!a)
    throw new At(
      "file-platform-runtime-missing",
      "The file platform runtime is not available for host uploads."
    );
  try {
    const i = await a.uploadAsset(n, {
      source: o,
      context: e
    });
    if (t && i.nodeKind !== t) {
      const r = new At(
        "host-upload-node-kind-mismatch",
        `Expected host upload to resolve as "${t}" but received "${i.nodeKind}".`
      );
      throw a.emitDiagnostic({
        code: r.code,
        message: r.message,
        severity: "error",
        stage: "asset-pipeline",
        cause: r
      }), r;
    }
    return i;
  } catch (i) {
    throw i instanceof At || a.emitDiagnostic({
      code: "host-upload-failed",
      message: Is(i, "The host asset upload failed."),
      severity: "error",
      stage: "asset-pipeline",
      cause: i
    }), i;
  }
}, rt = new De("assetTaskPlaceholder"), As = (e, t) => {
  const n = e.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? n : Math.max(0, Math.min(t, n));
}, Ps = (e) => ["queued", "reading", "uploading", "processing", "failed"].includes(
  e.status
), pt = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.find().forEach((n) => {
    const a = typeof n.spec.taskId == "string" ? n.spec.taskId : null;
    a && t.set(a, n.from);
  }), t;
}, Pt = (e, t, n) => {
  const a = document.createElement("button");
  a.type = "button", a.textContent = t, a.className = "zx-text-editor-asset-placeholder__action", a.addEventListener("mousedown", (o) => {
    o.preventDefault();
  }), a.addEventListener("click", (o) => {
    o.preventDefault(), o.stopPropagation(), n();
  }), e.append(a);
}, Ms = (e) => {
  switch (e.status) {
    case "queued":
      return "Queued";
    case "reading":
      return "Preparing";
    case "uploading":
      return typeof e.progress == "number" ? `Uploading ${Math.round(e.progress)}%` : "Uploading";
    case "processing":
      return "Processing";
    case "failed":
      return e.errorMessage ?? "Upload failed";
    default:
      return e.status;
  }
}, Bs = (e, t) => {
  const n = document.createElement("div");
  n.className = `zx-text-editor-asset-placeholder is-${e.status}`, n.dataset.assetTaskId = e.id;
  const a = document.createElement("strong");
  a.className = "zx-text-editor-asset-placeholder__title", a.textContent = e.fileName, n.append(a);
  const o = document.createElement("div");
  if (o.className = "zx-text-editor-asset-placeholder__status", o.textContent = Ms(e), n.append(o), e.previewUrl && e.kind === "image") {
    const r = document.createElement("img");
    r.className = "zx-text-editor-asset-placeholder__preview", r.src = e.previewUrl, r.alt = e.fileName, n.append(r);
  }
  if (typeof e.progress == "number" && e.status !== "failed") {
    const r = document.createElement("progress");
    r.className = "zx-text-editor-asset-placeholder__progress", r.max = 100, r.value = Math.max(0, Math.min(e.progress, 100)), n.append(r);
  }
  const i = document.createElement("div");
  return i.className = "zx-text-editor-asset-placeholder__actions", e.status === "failed" ? (Pt(i, "Retry", () => t.retryTask(e.id)), Pt(i, "Remove", () => t.removeTask(e.id))) : Pt(i, "Cancel", () => t.cancelTask(e.id)), n.append(i), n;
}, vn = (e, t, n) => {
  const a = t.getTasks().filter(Ps);
  return Ai.create(
    e,
    a.map(
      (o, i) => Pi.widget(
        As(
          e,
          n.get(o.id) ?? o.anchorPos ?? null
        ),
        () => Bs(o, t),
        {
          key: `${o.id}:${o.status}:${o.progress ?? "none"}:${o.errorCode ?? "ok"}`,
          side: i + 1,
          taskId: o.id
        }
      )
    )
  );
}, Ds = (e, t) => {
  if (!e)
    return null;
  const n = rt.getState(e);
  return (n == null ? void 0 : n.positions.get(t)) ?? null;
}, Rs = ({
  assetPipelineRuntime: e = null
} = {}) => We.create({
  name: "assetTaskPlaceholder",
  addProseMirrorPlugins() {
    return e ? [
      new Ne({
        key: rt,
        state: {
          init: (t, n) => {
            const a = vn(
              n.doc,
              e,
              /* @__PURE__ */ new Map()
            );
            return {
              decorations: a,
              positions: pt(a)
            };
          },
          apply: (t, n) => {
            const a = n.decorations.map(
              t.mapping,
              t.doc
            );
            if (!t.getMeta(
              rt
            ) && !t.docChanged)
              return {
                decorations: a,
                positions: pt(a)
              };
            const i = vn(
              t.doc,
              e,
              pt(a)
            );
            return {
              decorations: i,
              positions: pt(i)
            };
          }
        },
        props: {
          decorations(t) {
            var n;
            return (n = rt.getState(t)) == null ? void 0 : n.decorations;
          }
        },
        view: (t) => {
          e.setTaskPositionResolver(
            (a) => Ds(t.state, a)
          );
          const n = e.subscribe(() => {
            const a = t.state.tr.setMeta(rt, {
              refresh: !0
            }).setMeta("addToHistory", !1);
            t.dispatch(a);
          });
          return {
            destroy: () => {
              e.setTaskPositionResolver(null), n();
            }
          };
        }
      })
    ] : [];
  }
}), Os = ["onDragstart", "onDragover", "onDragleave"], Ns = ["onClick"], $s = ["src", "alt"], zs = ["onClick"], Fs = ["title"], Hs = ["onBlur", "onKeydown"], Vs = ["title"], qs = ["src", "alt"], Ws = ["onClick"], Us = ["title"], Ks = ["onBlur", "onKeydown"], Xs = /* @__PURE__ */ Ce({
  __name: "ImageGroupUploadDialog",
  props: {
    modelValue: {
      type: Boolean,
      required: !0
    },
    files: {
      type: Array,
      required: !0
    },
    editor: {
      type: Object,
      required: !0
    },
    mode: {
      type: String,
      default: "new"
    },
    existingImages: {
      type: Array,
      default: void 0
    },
    initialColumns: {
      type: Number,
      default: void 0
    },
    portalBinding: {
      type: Object,
      required: !0
    }
  },
  emits: ["update:modelValue", "close", "update:files", "save"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = Ee("text-editor-image-group-dialog"), i = B({
      get: () => n.modelValue,
      set: (C) => a("update:modelValue", C)
    }), r = A(!1), m = A(null), l = A(null), c = A(!1), d = A(null), g = A(""), f = A(null), p = A(!1), h = A(4), v = A(0), L = A(0), x = A(0), M = A([]), b = A([]), j = B(() => M.value.some(Boolean)), w = A([]);
    Le(
      () => n.modelValue,
      (C) => {
        if (C && n.mode === "edit") {
          const R = (n.existingImages || []).map(
            se
          ), D = (n.files || []).map(Z);
          w.value = [...R, ...D], n.initialColumns && (h.value = n.initialColumns, c.value = !0);
        } else C && n.mode === "new" && (w.value = (n.files || []).map(Z), h.value = ie(w.value.length), c.value = !0);
      },
      { immediate: !0 }
    ), Le(
      () => n.existingImages,
      (C) => {
        if (n.modelValue && n.mode === "edit") {
          const R = (C || []).map(
            se
          ), D = (n.files || []).map(Z);
          w.value = [...R, ...D];
        }
      },
      { deep: !0 }
    ), Le(
      () => n.files,
      (C) => {
        n.mode === "new" && (w.value = (C || []).map(Z));
      },
      { deep: !0 }
    ), He(() => {
      window.addEventListener("dragover", k), window.addEventListener("drop", y), window.addEventListener("dragleave", $);
    }), ze(() => {
      window.removeEventListener("dragover", k), window.removeEventListener("drop", y), window.removeEventListener("dragleave", $);
    });
    async function V() {
      const C = w.value.filter((Y) => Y.type === "file" && Y.file).map((Y) => Y.file);
      let R = [];
      C.length > 0 && (R = await Q(C));
      const D = /* @__PURE__ */ new Map();
      C.forEach((Y, J) => {
        const me = R[J];
        me != null && me.success && me.file && D.set(Y, {
          src: me.file.src || "",
          alt: me.file.alt || ""
        });
      });
      const X = [];
      for (const Y of w.value)
        if (Y.type === "existing" && Y.existing)
          X.push(Y.existing);
        else if (Y.type === "file" && Y.file) {
          const J = D.get(Y.file);
          J && X.push(J);
        }
      return a("save", {
        images: X,
        columns: h.value
      }), p.value = !1, !0;
    }
    async function z() {
      if (!n.files || n.files.length === 0) return !1;
      const R = (await Q(n.files)).filter((D) => D.success && D.file).map((D) => {
        var X, Y;
        return {
          src: ((X = D.file) == null ? void 0 : X.src) || "",
          alt: ((Y = D.file) == null ? void 0 : Y.alt) || ""
        };
      });
      return R.length > 1 && n.editor.chain().focus().setImageGroup({ images: R, columns: h.value }).run(), p.value = !1, a("close"), !0;
    }
    function F(C) {
      if (w.value.splice(C, 1), n.mode === "new") {
        const R = w.value.filter((D) => D.type === "file" && D.file).map((D) => D.file);
        a("update:files", R);
      }
    }
    function H() {
      const C = document.createElement("input");
      C.type = "file", C.accept = "image/*", C.multiple = !0, C.onchange = (R) => {
        const D = R.target.files;
        D && ee(Array.from(D));
      }, C.click();
    }
    function ee(C) {
      const D = C.filter((J) => J.type.startsWith("image/")).map(Z), X = w.value.filter((J) => J.type === "file" && J.file).map((J) => `${J.file.name}-${J.file.size}`), Y = D.filter(
        (J) => !X.includes(`${J.file.name}-${J.file.size}`)
      );
      if (w.value.push(...Y), n.mode === "new") {
        const J = w.value.filter((me) => me.type === "file" && me.file).map((me) => me.file);
        a("update:files", J);
      }
    }
    function y(C) {
      var D;
      C.preventDefault(), C.stopPropagation();
      const R = Array.from(((D = C.dataTransfer) == null ? void 0 : D.files) || []);
      R.length && ee(R), r.value = !1;
    }
    function P(C) {
      var D;
      C.preventDefault(), C.stopPropagation();
      const R = Array.from(((D = C.dataTransfer) == null ? void 0 : D.files) || []);
      if (R.length)
        ee(R);
      else if (m.value !== null && l.value !== null && m.value !== l.value) {
        const [X] = w.value.splice(m.value, 1);
        if (w.value.splice(l.value, 0, X), n.mode === "new") {
          const Y = w.value.filter((J) => J.type === "file" && J.file).map((J) => J.file);
          a("update:files", Y);
        }
      }
      r.value = !1, m.value = null, l.value = null;
    }
    function Z(C) {
      return {
        type: "file",
        file: C,
        id: `file-${C.name}-${C.size}-${Date.now()}`
      };
    }
    function se(C) {
      return {
        type: "existing",
        existing: C,
        id: `existing-${C.src}-${Date.now()}`
      };
    }
    function ie(C) {
      return C <= 4 ? C : C % 4 === 0 ? 4 : C % 3 === 0 ? 3 : C > 10 ? 4 : 3;
    }
    function je() {
      var R;
      const C = n.editor.extensionManager.extensions.find(
        (D) => D.name === "imageGroup"
      );
      return (R = C == null ? void 0 : C.options) == null ? void 0 : R.filePlatformRuntime;
    }
    function oe(C) {
      const R = URL.createObjectURL(C);
      return ze(() => {
        URL.revokeObjectURL(R);
      }), R;
    }
    function q(C) {
      const R = ["image/heic", "image/heif"], D = [".heic", ".heif"], X = R.includes(C.type), Y = D.some(
        (J) => {
          var me;
          return (me = C.name) == null ? void 0 : me.toLowerCase().endsWith(J);
        }
      );
      return !X && !Y;
    }
    function le(C, R) {
      C.preventDefault(), l.value = R;
    }
    function de(C) {
      m.value = C;
    }
    function ve() {
      m.value = null, l.value = null;
    }
    function ge(C, R) {
      l.value === R && (l.value = null);
    }
    function G(C) {
      return l.value === C && m.value !== null && m.value !== C;
    }
    function k(C) {
      C.preventDefault(), C.dataTransfer && Array.from(C.dataTransfer.types).includes("Files") && (r.value = !0);
    }
    function $(C) {
      (C.target === window || C.relatedTarget === null) && (r.value = !1);
    }
    const ae = B(() => ({
      gridTemplateColumns: `repeat(${h.value || 4}, minmax(0, 1fr))`
    })), ue = B({
      get: () => String(h.value ?? 4),
      set: (C) => {
        h.value = +C;
      }
    }), he = [
      { label: "2 columns", value: "2" },
      { label: "3 columns", value: "3" },
      { label: "4 columns", value: "4" }
    ];
    function ce(C, R) {
      d.value = C, g.value = R, Me(() => {
        f.value && (f.value.focus(), f.value.select());
      });
    }
    function fe(C, R) {
      var Y;
      const [D] = C.split("-"), X = g.value.trim();
      D === "existing" ? (Y = w.value[R]) != null && Y.existing && (w.value[R].existing.alt = X) : D === "file" && w.value[R] && (w.value[R].alt = X), d.value = null, g.value = "";
    }
    function we() {
      d.value = null, g.value = "";
    }
    function O(C, R) {
      d.value === C && fe(C, R);
    }
    async function Q(C) {
      const R = je();
      p.value = !0, x.value = C.length, L.value = 0, v.value = 0, M.value = Array.from({ length: C.length }).fill(
        null
      ), b.value = Array.from({ length: C.length }).fill(
        {
          success: !1
        }
      );
      const D = C.map(async (Y, J) => {
        try {
          const me = await Ss({
            file: Y,
            filePlatformRuntime: R,
            source: "picker",
            context: {
              nodeKind: "imageGroup",
              preferredNodeKind: "image",
              usage: "image-group"
            },
            expectedNodeKind: "image"
          }), Ie = {
            src: me.asset.src,
            alt: me.asset.title || Y.name
          };
          return b.value[J] = { success: !0, file: Ie }, { success: !0, file: Ie };
        } catch (me) {
          const Ie = me;
          return M.value[J] = Ie, b.value[J] = { success: !1, error: Ie }, { success: !1, error: Ie };
        } finally {
          L.value++, v.value = Math.round(
            L.value / x.value * 100
          );
        }
      });
      return await Promise.all(D);
    }
    return (C, R) => (E(), S(ye, null, [
      U(s(bi), {
        modelValue: i.value,
        "onUpdate:modelValue": R[8] || (R[8] = (D) => i.value = D),
        title: n.mode === "edit" ? "Edit Images" : "Upload Images",
        width: "800px",
        "close-on-click-modal": !1,
        "cancel-text": "Cancel",
        "ok-text": n.mode === "edit" ? "Save" : "Upload",
        "ok-disabled": p.value,
        loading: p.value,
        confirm: n.mode === "edit" ? V : z,
        "append-to": n.portalBinding.target,
        onClose: R[9] || (R[9] = (D) => C.$emit("close"))
      }, {
        default: _e(() => [
          _("div", {
            class: u(s(o).e("content"))
          }, [
            _("div", {
              class: u(s(o).e("header"))
            }, [
              U(s(Ue), { onClick: H }, {
                default: _e(() => [
                  U(s(te), { icon: "mdi:image-plus" }),
                  R[10] || (R[10] = Ae(" Add images ", -1))
                ]),
                _: 1
              }),
              U(s(zt), {
                modelValue: ue.value,
                "onUpdate:modelValue": R[0] || (R[0] = (D) => ue.value = D),
                class: u(s(o).e("column-select")),
                size: "small",
                options: he,
                "append-to": n.portalBinding.target,
                onChange: R[1] || (R[1] = (D) => h.value = +D)
              }, null, 8, ["modelValue", "class", "append-to"])
            ], 2),
            w.value && w.value.length ? (E(), S("div", {
              key: 0,
              class: u(s(o).e("grid")),
              style: Pe(ae.value)
            }, [
              (E(!0), S(ye, null, Be(w.value, (D, X) => {
                var Y, J, me, Ie;
                return E(), S("div", {
                  key: D.id,
                  class: u([s(o).e("item"), s(o).is("drop-target", G(X))]),
                  draggable: !0,
                  onDragstart: (pe) => de(X),
                  onDragover: (pe) => le(pe, X),
                  onDrop: R[6] || (R[6] = (pe) => P(pe)),
                  onDragend: ve,
                  onDragleave: (pe) => ge(pe, X)
                }, [
                  _("button", {
                    type: "button",
                    class: u(s(o).e("remove-btn")),
                    "aria-label": "Remove image",
                    onClick: N((pe) => F(X), ["stop"])
                  }, [
                    U(s(te), { icon: "mdi:close" })
                  ], 10, Ns),
                  D.type === "existing" ? (E(), S(ye, { key: 0 }, [
                    _("img", {
                      src: (Y = D.existing) == null ? void 0 : Y.src,
                      alt: ((J = D.existing) == null ? void 0 : J.alt) || "",
                      class: u(s(o).e("image"))
                    }, null, 10, $s),
                    _("div", {
                      class: u([
                        s(o).e("caption-overlay"),
                        s(o).is("editing", d.value === `${D.type}-${X}`)
                      ])
                    }, [
                      d.value !== `${D.type}-${X}` ? (E(), S("div", {
                        key: 0,
                        class: u(s(o).e("caption-text")),
                        onClick: N((pe) => {
                          var Ye;
                          return ce(
                            `${D.type}-${X}`,
                            ((Ye = D.existing) == null ? void 0 : Ye.alt) || ""
                          );
                        }, ["stop"])
                      }, [
                        _("div", {
                          class: u(s(o).e("caption-label")),
                          title: ((me = D.existing) == null ? void 0 : me.alt) || "Click to add caption"
                        }, W(((Ie = D.existing) == null ? void 0 : Ie.alt) || "Add caption..."), 11, Fs)
                      ], 10, zs)) : (E(), S("div", {
                        key: 1,
                        class: u(s(o).e("caption-input-wrapper")),
                        onClick: R[3] || (R[3] = N(() => {
                        }, ["stop"]))
                      }, [
                        tt(_("input", {
                          ref_for: !0,
                          ref: (pe) => f.value = pe,
                          "onUpdate:modelValue": R[2] || (R[2] = (pe) => g.value = pe),
                          class: u(s(o).e("caption-input")),
                          placeholder: "Add caption...",
                          maxlength: "200",
                          onBlur: (pe) => O(`${D.type}-${X}`, X),
                          onKeydown: [
                            $e(N((pe) => fe(`${D.type}-${X}`, X), ["prevent"]), ["enter"]),
                            $e(we, ["escape"])
                          ]
                        }, null, 42, Hs), [
                          [_t, g.value]
                        ])
                      ], 2))
                    ], 2)
                  ], 64)) : D.type === "file" && D.file ? (E(), S(ye, { key: 1 }, [
                    q(D.file) ? D.file.type.startsWith("image/") ? (E(), S(ye, { key: 1 }, [
                      _("img", {
                        src: oe(D.file),
                        class: u(s(o).e("image")),
                        alt: D.alt || ""
                      }, null, 10, qs),
                      _("div", {
                        class: u([
                          s(o).e("caption-overlay"),
                          s(o).is("editing", d.value === `${D.type}-${X}`)
                        ])
                      }, [
                        d.value !== `${D.type}-${X}` ? (E(), S("div", {
                          key: 0,
                          class: u(s(o).e("caption-text")),
                          onClick: N((pe) => ce(`${D.type}-${X}`, D.alt || ""), ["stop"])
                        }, [
                          _("div", {
                            class: u(s(o).e("caption-label")),
                            title: D.alt || "Click to add caption"
                          }, W(D.alt || "Add caption..."), 11, Us)
                        ], 10, Ws)) : (E(), S("div", {
                          key: 1,
                          class: u(s(o).e("caption-input-wrapper")),
                          onClick: R[5] || (R[5] = N(() => {
                          }, ["stop"]))
                        }, [
                          tt(_("input", {
                            "onUpdate:modelValue": R[4] || (R[4] = (pe) => g.value = pe),
                            class: u(s(o).e("caption-input")),
                            placeholder: "Add caption...",
                            maxlength: "200",
                            onBlur: (pe) => O(`${D.type}-${X}`, X),
                            onKeydown: [
                              $e(N((pe) => fe(`${D.type}-${X}`, X), ["prevent"]), ["enter"]),
                              $e(we, ["escape"])
                            ]
                          }, null, 42, Ks), [
                            [_t, g.value]
                          ])
                        ], 2))
                      ], 2)
                    ], 64)) : K("", !0) : (E(), S("div", {
                      key: 0,
                      class: u(s(o).e("unsupported"))
                    }, [
                      _("span", {
                        class: u(s(o).e("unsupported-name")),
                        title: D.file.name
                      }, W(D.file.name), 11, Vs)
                    ], 2))
                  ], 64)) : K("", !0)
                ], 42, Os);
              }), 128))
            ], 6)) : K("", !0),
            w.value && w.value.length ? (E(), S("div", {
              key: 1,
              class: u(s(o).e("help-text"))
            }, " Upload more images by dropping them anywhere in this window. Reorder images by dragging them. Hover over an image to edit caption. ", 2)) : (E(), S("div", {
              key: 2,
              class: u(s(o).e("empty"))
            }, [
              _("div", {
                class: u(s(o).e("dropzone")),
                onClick: H,
                onDragover: R[7] || (R[7] = N(() => {
                }, ["prevent"])),
                onDrop: N(y, ["prevent"])
              }, [
                _("div", {
                  class: u(s(o).e("dropzone-icon"))
                }, [
                  U(s(te), { icon: "mdi:image-plus" })
                ], 2),
                _("div", {
                  class: u(s(o).e("dropzone-text"))
                }, " Drag & drop images here or click to select ", 2)
              ], 34)
            ], 2)),
            p.value ? (E(), S("div", {
              key: 3,
              class: u(s(o).e("progress"))
            }, [
              _("div", {
                class: u(s(o).e("progress-text"))
              }, " Uploading: " + W(L.value) + "/" + W(x.value), 3),
              _("div", {
                class: u(s(o).e("progress-bar"))
              }, [
                _("div", {
                  class: u(s(o).e("progress-fill")),
                  style: Pe({ width: v.value + "%" })
                }, null, 6)
              ], 2),
              j.value ? (E(), S("div", {
                key: 0,
                class: u(s(o).e("progress-error"))
              }, " Some files failed to upload. ", 2)) : K("", !0)
            ], 2)) : K("", !0)
          ], 2)
        ]),
        _: 1
      }, 8, ["modelValue", "title", "ok-text", "ok-disabled", "loading", "confirm", "append-to"]),
      (E(), ke(Fn, {
        to: n.portalBinding.target
      }, [
        U(Hn, { name: "fade" }, {
          default: _e(() => [
            r.value ? (E(), S("div", {
              key: 0,
              class: u(s(o).e("drag-overlay"))
            }, [
              _("div", {
                class: u(s(o).e("drag-overlay-text"))
              }, "Drop images anywhere", 2)
            ], 2)) : K("", !0)
          ]),
          _: 1
        })
      ], 8, ["to"]))
    ], 64));
  }
}), gc = (e) => e.nearestScope && e.nearestScope.state !== "disposed" ? e.nearestScope : e.nearestScopeAvailable ? null : e.app ?? null, ft = (e) => Object.freeze({ ok: !0, value: e, diagnostics: [] }), Qe = (e, t, n = {}) => Object.freeze({
  ok: !1,
  diagnostics: Object.freeze([
    Object.freeze({ code: e, phase: t, details: Object.freeze({ ...n }) })
  ])
}), Gs = (e) => Object.freeze({
  runtimeId: e.runtimeId,
  scopeId: e.scopeId,
  target: e.target,
  appContext: e.appContext,
  get themeId() {
    return e.themeId;
  },
  get variantKey() {
    return e.variantKey;
  }
}), hc = (e, t) => {
  if (!e || !t || e.runtimeId !== t.runtimeId)
    return Qe("EDITOR_THEME_OWNER_RUNTIME_MISMATCH", "create");
  const n = e.resolveFeedbackOwner(t);
  if (!n.ok) return n;
  if (n.value.runtimeId !== e.runtimeId || n.value.scope.runtimeId !== e.runtimeId || n.value.state === "disposed" || n.value.scope.state === "disposed")
    return Qe("EDITOR_THEME_OWNER_INACTIVE", "create");
  const a = e.createFeedback(n.value.scope);
  if (!a.ok) return a;
  const o = n.value.scope, i = n.value.appContext, r = a.value, m = /* @__PURE__ */ new Set();
  let l = "active";
  const c = () => Promise.resolve(Qe("EDITOR_THEME_OWNER_DISPOSED", "feedback")), d = Object.freeze({
    message(...f) {
      return l === "active" ? r.message(...f) : c();
    },
    notification(...f) {
      return l === "active" ? r.notification(...f) : c();
    },
    confirm(...f) {
      return l === "active" ? r.confirm(...f) : c();
    }
  }), g = {
    runtimeId: e.runtimeId,
    scopeId: o.scopeId,
    get state() {
      return l;
    },
    feedback: d,
    async acquirePortal() {
      if (l !== "active")
        return Qe("EDITOR_THEME_OWNER_DISPOSED", "portal");
      const f = await e.acquirePortal(o);
      if (!f.ok) return f;
      const p = f.value;
      if (p.runtimeId !== e.runtimeId || p.scopeId !== o.scopeId || p.appContext !== i)
        return p.release(), Qe("EDITOR_THEME_PORTAL_IDENTITY_MISMATCH", "portal");
      if (l !== "active")
        return p.release(), Qe("EDITOR_THEME_OWNER_DISPOSED", "portal");
      let h = !1;
      const v = Object.freeze({
        runtimeId: p.runtimeId,
        scopeId: p.scopeId,
        target: p.target,
        appContext: p.appContext,
        get themeId() {
          return p.themeId;
        },
        get variantKey() {
          return p.variantKey;
        },
        release() {
          h || (h = !0, m.delete(v), p.release());
        }
      });
      return m.add(v), ft(v);
    },
    dispose() {
      if (l === "disposed") return ft(void 0);
      l = "disposed";
      for (const f of [...m]) f.release();
      return ft(void 0);
    }
  };
  return ft(Object.freeze(g));
}, ao = Symbol.for(
  "@zxio/text-editor/theme-owner"
), jc = (e) => e ?? Vn(ao, null), Zs = (e) => {
  const t = e ?? Vn(ao, null), n = Ke(null), a = Ke([]);
  let o = null, i = 0, r = !0;
  const m = () => {
    i += 1, r = !1, n.value = null, o == null || o.release(), o = null;
  };
  return (async () => {
    if (!t || t.state !== "active") {
      a.value = Object.freeze([
        Object.freeze({
          code: "EDITOR_THEME_OWNER_REQUIRED",
          phase: "portal",
          details: Object.freeze({})
        })
      ]);
      return;
    }
    const c = ++i, d = await t.acquirePortal();
    if (!r || c !== i) {
      d.ok && d.value.release();
      return;
    }
    if (!d.ok) {
      a.value = d.diagnostics;
      return;
    }
    o = d.value, n.value = Gs(d.value), a.value = [];
  })(), pi(m), Object.freeze({
    binding: n,
    diagnostics: a,
    release: m
  });
}, Ys = ["onClick"], Js = ["src", "alt", "onClick"], Qs = ["src", "alt"], er = ["title"], tr = /* @__PURE__ */ Ce({
  __name: "ImageGroupNodeView",
  props: {
    decorations: {},
    selected: { type: Boolean },
    updateAttributes: { type: Function },
    deleteNode: { type: Function },
    node: {},
    view: {},
    getPos: {},
    innerDecorations: {},
    editor: {},
    extension: {},
    HTMLAttributes: {}
  },
  setup(e) {
    var V, z;
    const t = e, n = Ee("text-editor-image-group"), a = (z = (V = t.editor.extensionManager.extensions.find(
      (F) => F.name === "imageGroup"
    )) == null ? void 0 : V.options) == null ? void 0 : z.themeOwner, { binding: o } = Zs(a), i = B(() => {
      var F;
      return ((F = t.node.attrs) == null ? void 0 : F.columns) || 4;
    }), r = B(() => {
      var F;
      return ((F = t.node.content) == null ? void 0 : F.content) || [];
    }), m = B(() => ({
      gridTemplateColumns: `repeat(${i.value}, minmax(0, 1fr))`
    })), l = A(t.editor.isEditable), c = [
      { label: "2 columns", value: "2" },
      { label: "3 columns", value: "3" },
      { label: "4 columns", value: "4" }
    ], d = B({
      get: () => String(i.value),
      set: (F) => t.updateAttributes({ columns: +F })
    }), g = A(!1), f = A(0), p = B(
      () => r.value.map((F) => ({
        src: F.attrs.src,
        alt: F.attrs.alt || ""
      }))
    ), h = A(!1), v = A([]), L = B(
      () => r.value.map((F) => ({
        src: F.attrs.src,
        alt: F.attrs.alt || ""
      }))
    );
    He(() => {
      const F = () => {
        l.value = t.editor.isEditable;
      };
      t.editor.on("update", F), ze(() => {
        t.editor.off("update", F);
      });
    });
    function x() {
      v.value = [], h.value = !0;
    }
    function M() {
      h.value = !1, v.value = [];
    }
    async function b(F) {
      t.editor.commands.command(({ tr: H, state: ee }) => {
        const y = t.getPos();
        if (typeof y == "number") {
          const P = ee.doc.nodeAt(y);
          if (P && P.type.name === "imageGroup") {
            const Z = F.images.map(
              (je) => ee.schema.nodes.image.create({ src: je.src, alt: je.alt })
            ), se = { ...P.attrs, columns: F.columns }, ie = P.type.create(se, Z);
            return H.replaceWith(y, y + P.nodeSize, ie), !0;
          }
        }
        return !1;
      }), h.value = !1;
    }
    function j(F) {
      t.editor.isEditable || (f.value = F, g.value = !0);
    }
    function w(F) {
      const H = r.value.slice();
      H.splice(F, 1), H.length === 0 ? t.editor.commands.deleteNode("imageGroup") : (t.updateAttributes({}), t.editor.commands.command(({ tr: ee, state: y }) => {
        const P = t.getPos();
        if (typeof P == "number") {
          const Z = y.doc.nodeAt(P);
          if (Z && Z.type.name === "imageGroup") {
            const se = H.map(
              (ie) => y.schema.nodes.image.create(ie.attrs)
            );
            return ee.replaceWith(P + 1, P + 1 + Z.content.size, se), !0;
          }
        }
        return !1;
      }));
    }
    return (F, H) => (E(), ke(s(ot), {
      "data-block-id": e.node.attrs.blockId || void 0
    }, {
      default: _e(() => {
        var ee;
        return [
          _("div", {
            class: u(s(n).b())
          }, [
            l.value ? (E(), S("div", {
              key: 0,
              class: u(s(n).e("header"))
            }, [
              U(s(Ue), {
                size: "small",
                onClick: x
              }, {
                default: _e(() => [
                  U(s(te), { icon: "lucide:edit" }),
                  H[3] || (H[3] = Ae(" Edit ", -1))
                ]),
                _: 1
              }),
              U(s(zt), {
                modelValue: d.value,
                "onUpdate:modelValue": H[0] || (H[0] = (y) => d.value = y),
                class: u(s(n).e("column-select")),
                size: "small",
                options: c,
                "append-to": (ee = s(o)) == null ? void 0 : ee.target
              }, null, 8, ["modelValue", "class", "append-to"])
            ], 2)) : K("", !0),
            _("div", {
              class: u(s(n).e("grid")),
              style: Pe(m.value)
            }, [
              (E(!0), S(ye, null, Be(r.value, (y, P) => (E(), S("div", {
                key: y.attrs.src + P,
                class: u(s(n).e("item"))
              }, [
                l.value ? (E(), S("button", {
                  key: 0,
                  type: "button",
                  class: u(s(n).e("remove-btn")),
                  "aria-label": "Remove image",
                  onClick: N((Z) => w(P), ["stop"])
                }, [
                  U(s(te), { icon: "lucide:x" })
                ], 10, Ys)) : K("", !0),
                l.value ? (E(), S("img", {
                  key: 2,
                  src: y.attrs.src,
                  alt: y.attrs.alt || "",
                  class: u(s(n).e("image"))
                }, null, 10, Qs)) : (E(), S("img", {
                  key: 1,
                  src: y.attrs.src,
                  alt: y.attrs.alt || "",
                  class: u([s(n).e("image"), s(n).is("clickable", !0)]),
                  onClick: (Z) => j(P)
                }, null, 10, Js)),
                y.attrs.alt ? (E(), S("div", {
                  key: 3,
                  class: u(s(n).e("caption"))
                }, [
                  _("div", {
                    class: u(s(n).e("caption-text")),
                    title: y.attrs.alt
                  }, W(y.attrs.alt), 11, er)
                ], 2)) : K("", !0)
              ], 2))), 128))
            ], 6),
            g.value && s(o) ? (E(), ke(oo, {
              key: 1,
              show: g.value,
              "onUpdate:show": H[1] || (H[1] = (y) => g.value = y),
              images: p.value,
              "initial-index": f.value,
              "portal-binding": s(o)
            }, null, 8, ["show", "images", "initial-index", "portal-binding"])) : K("", !0),
            h.value && s(o) ? (E(), ke(Xs, {
              key: 2,
              modelValue: h.value,
              "onUpdate:modelValue": H[2] || (H[2] = (y) => h.value = y),
              files: v.value,
              editor: t.editor,
              mode: "edit",
              "existing-images": L.value,
              "initial-columns": i.value,
              "portal-binding": s(o),
              onClose: M,
              onSave: b
            }, null, 8, ["modelValue", "files", "editor", "existing-images", "initial-columns", "portal-binding"])) : K("", !0),
            zn(F.$slots, "default")
          ], 2)
        ];
      }),
      _: 3
    }, 8, ["data-block-id"]));
  }
}), nr = Re.create({
  name: "imageGroup",
  group: "block",
  content: "image+",
  // one or more images
  selectable: !0,
  draggable: !0,
  isolating: !0,
  addOptions() {
    return {
      filePlatformRuntime: null,
      themeOwner: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      columns: {
        default: 4
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="image-group"]',
        getAttrs: (e) => {
          if (typeof e == "string") return {};
          const t = e;
          return {
            columns: t.dataset.columns ? Number(t.dataset.columns) : 4
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e, node: t }) {
    return [
      "div",
      Oe(
        {
          "data-type": "image-group",
          "data-columns": t.attrs.columns
        },
        this.options.HTMLAttributes,
        e
      ),
      0
      // content placeholder for child images
    ];
  },
  addNodeView() {
    return Ze(tr);
  },
  addCommands() {
    return {
      setImageGroup: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: {
          columns: e.columns || 4
        },
        content: e.images.map((n) => ({
          type: "image",
          attrs: n
        }))
      })
    };
  }
}), or = (e, t, n, a) => {
  e.emitDiagnostic({
    code: t,
    message: n,
    severity: "error",
    stage: "intake",
    cause: a
  });
}, ar = Re.create({
  name: "video",
  group: "block",
  selectable: !0,
  draggable: !0,
  atom: !0,
  addOptions() {
    return {
      filePlatformRuntime: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: {
        default: null
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "video"
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "video",
      Oe(this.options.HTMLAttributes, e, {
        controls: ""
      })
    ];
  },
  addCommands() {
    return {
      setVideo: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: e
      }),
      uploadVideo: (e, t = "programmatic") => () => this.options.filePlatformRuntime ? t === "programmatic" || t === "picker" ? to(
        this.options.filePlatformRuntime,
        [e],
        {
          source: t === "picker" ? "picker" : "programmatic",
          context: {
            nodeKind: "video",
            preferredNodeKind: "video"
          }
        }
      ) : (Promise.resolve(
        this.options.filePlatformRuntime.intakeFiles({
          source: t,
          files: [e],
          context: {
            nodeKind: "video",
            preferredNodeKind: "video"
          }
        })
      ).catch((n) => {
        const a = this.options.filePlatformRuntime;
        or(
          a,
          `${t}-video-intake-dispatch-failed`,
          n instanceof Error ? n.message : `Failed to dispatch ${t} video intake.`,
          n
        );
      }), !0) : !1,
      selectAndUploadVideo: () => ({ dispatch: e }) => {
        if (!this.options.filePlatformRuntime)
          return !1;
        if (!e)
          return !0;
        const t = document.createElement("input");
        return t.type = "file", t.accept = "video/*", t.onchange = (n) => {
          const a = n.target;
          a.files && a.files.length && eo(
            this.options.filePlatformRuntime,
            a.files,
            {
              context: {
                nodeKind: "video",
                preferredNodeKind: "video"
              }
            }
          );
        }, t.click(), !0;
      }
    };
  },
  addNodeView() {
    return ({ editor: e, node: t }) => {
      const n = (i, r) => {
        const m = typeof r.attrs.blockId == "string" ? r.attrs.blockId : null;
        if (m) {
          i.dataset.blockId = m;
          return;
        }
        delete i.dataset.blockId;
      }, a = document.createElement("div");
      a.className = `relative aspect-w-16 aspect-h-9${e.isEditable ? " cursor-pointer" : ""}`, n(a, t);
      const o = document.createElement("video");
      if (o.src = t.attrs.src, o.setAttribute("controls", ""), e.isEditable) {
        const i = document.createElement("div");
        i.className = "absolute top-0 right-0 text-xs m-2 bg-surface-gray-6 text-ink-white px-2 py-1 rounded-md", i.innerHTML = "Video", a.append(i);
      }
      return a.append(o), {
        dom: a,
        update: (i) => i.type.name !== this.name ? !1 : (o.src = i.attrs.src, n(a, i), !0)
      };
    };
  }
}), ir = /* @__PURE__ */ Ce({
  name: "ToggleNodeView",
  __name: "ToggleNodeView",
  props: {
    decorations: {},
    selected: { type: Boolean },
    updateAttributes: { type: Function },
    deleteNode: { type: Function },
    node: {},
    view: {},
    getPos: {},
    innerDecorations: {},
    editor: {},
    extension: {},
    HTMLAttributes: {}
  },
  setup(e) {
    const t = e, n = Ee("toggle"), a = A(t.node.attrs.open ?? !1);
    Le(
      () => t.node.attrs.open,
      (i) => {
        typeof i == "boolean" && (a.value = i);
      },
      { immediate: !0 }
    );
    const o = (i) => {
      i.preventDefault(), i.stopPropagation();
      const r = !a.value;
      if (a.value = r, t.updateAttributes({
        open: r
      }), !r) {
        const m = t.getPos();
        if (typeof m != "number") return;
        const { selection: l } = t.editor.state;
        if (!(l.from >= m && l.to <= m + t.node.nodeSize)) return;
        const d = t.node.firstChild;
        if (!d) return;
        const g = m + 1 + d.nodeSize - 1;
        t.editor.chain().focus().setTextSelection(g).run();
      }
    };
    return (i, r) => (E(), ke(s(ot), {
      as: "div",
      class: u([s(n).b(), { [s(n).is("open")]: a.value }]),
      "data-block-id": e.node.attrs.blockId || void 0,
      "data-open": a.value
    }, {
      default: _e(() => [
        _("div", {
          class: u(s(n).e("summary")),
          onClick: o,
          onMousedown: r[0] || (r[0] = N(() => {
          }, ["prevent"]))
        }, [
          _("span", {
            class: u(s(n).e("icon")),
            "aria-hidden": "true"
          }, [
            (E(), S("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              width: "16",
              height: "16",
              viewBox: "0 0 24 24",
              fill: "currentColor",
              class: u([s(n).e("arrow"), { [s(n).is("rotated")]: a.value }])
            }, [...r[1] || (r[1] = [
              _("path", { d: "M8 5.5l7.5 6.5-7.5 6.5z" }, null, -1)
            ])], 2))
          ], 2)
        ], 34),
        _("div", {
          class: u(s(n).e("body"))
        }, [
          U(s(Un), {
            class: u(s(n).e("editor-content"))
          }, null, 8, ["class"])
        ], 2)
      ]),
      _: 1
    }, 8, ["class", "data-block-id", "data-open"]));
  }
}), bn = (e) => e.content.size === 0 ? !0 : e.textContent.replace(/[\s\u200B\uFEFF]/g, "").length === 0, sr = Re.create({
  name: "toggle",
  group: "block",
  content: "toggleSummary toggleContent",
  defining: !0,
  isolating: !0,
  addOptions() {
    return {
      HTMLAttributes: {},
      persist: !0,
      openClassName: "is-open"
    };
  },
  addAttributes() {
    return {
      open: {
        default: !1,
        parseHTML: (e) => e.dataset.open === "true",
        renderHTML: (e) => ({ "data-open": e.open ? "true" : "false" })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(this.options.HTMLAttributes, e, {
        "data-type": "toggle"
      }),
      0
    ];
  },
  addNodeView() {
    return Ze(ir);
  },
  addCommands() {
    return {
      setToggle: () => ({ commands: e }) => e.insertContent({
        type: this.name,
        attrs: { open: !1 },
        content: [
          {
            type: "toggleSummary",
            content: []
          },
          {
            type: "toggleContent",
            content: [{ type: "paragraph" }]
          }
        ]
      }),
      toggleToggleOpen: () => ({ tr: e, state: t, dispatch: n }) => {
        const { selection: a } = t, { $from: o } = a;
        let i = o.depth;
        for (; i > 0; ) {
          const r = o.node(i);
          if (r.type.name === "toggle") {
            if (n) {
              const m = o.before(i), l = !r.attrs.open;
              if (e.setNodeMarkup(m, void 0, {
                ...r.attrs,
                open: l
              }), !l) {
                let c = o.depth;
                for (; c > i && o.node(c).type.name !== "toggleContent"; )
                  c--;
                if (c > i && o.node(c).type.name === "toggleContent") {
                  const d = r.firstChild;
                  if (d) {
                    const g = m + 1 + d.nodeSize - 1;
                    e.setSelection(
                      Ge.create(e.doc, g)
                    );
                  }
                }
              }
              n(e);
            }
            return !0;
          }
          i--;
        }
        return !1;
      },
      unsetToggle: () => ({ tr: e, state: t, dispatch: n }) => {
        const { selection: a } = t, { $from: o } = a;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const r = o.before(i), m = t.doc.nodeAt(r);
        if (!m) return !1;
        const l = t.schema.nodes.paragraph, c = [], d = m.firstChild;
        d && d.content.size > 0 && l && c.push(
          l.create(null, d.content)
        );
        const g = m.childCount > 1 ? m.child(1) : null;
        if (g && g.forEach((f) => {
          c.push(f.copy(f.content));
        }), c.length === 0 && l && c.push(l.create()), n) {
          e.replaceWith(
            r,
            r + m.nodeSize,
            c
          );
          const f = r + 1;
          f <= e.doc.content.size && e.setSelection(
            Ge.create(e.doc, f)
          ), n(e.scrollIntoView());
        }
        return !0;
      }
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-t": () => this.editor.commands.setToggle()
    };
  }
}), rr = Re.create({
  name: "toggleSummary",
  priority: 1e3,
  group: "block",
  content: "inline*",
  defining: !0,
  selectable: !1,
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle-summary"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(e, { "data-type": "toggle-summary" }),
      0
    ];
  },
  addKeyboardShortcuts() {
    return {
      // Enter in summary: move to content or unset if empty
      Enter: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a } = n;
        return a.parent.type.name !== "toggleSummary" ? !1 : bn(a.parent) ? e.commands.command(({ state: o, dispatch: i }) => {
          const { selection: r } = o, { $from: m } = r;
          let l = m.depth;
          for (; l > 0 && m.node(l).type.name !== "toggle"; )
            l--;
          if (l === 0) return !1;
          const c = m.before(l), d = o.doc.nodeAt(c);
          if (!d) return !1;
          const g = o.schema.nodes.paragraph;
          if (!g) return !1;
          const f = o.tr.replaceWith(
            c,
            c + d.nodeSize,
            g.create()
          ), p = c + 1;
          return p <= f.doc.content.size && f.setSelection(Ge.create(f.doc, p)), i && i(f.scrollIntoView()), !0;
        }) : e.commands.command(({ state: o, dispatch: i }) => {
          const { selection: r } = o, { $head: m } = r;
          if (m.parent.type.name !== "toggleSummary") return !1;
          let l = m.depth;
          for (; l > 0 && m.node(l).type.name !== "toggle"; )
            l--;
          if (l === 0) return !1;
          const c = o.tr, d = m.before(l), g = m.node(l), f = g.firstChild, p = g.childCount > 1 ? g.child(1) : null;
          if (!f || !p) return !1;
          const h = g.attrs.open === !0, v = d + g.nodeSize, L = (H) => {
            const ee = o.schema.nodes.paragraph;
            return !!(H && ee && H.type === ee && H.content.size === 0);
          };
          if (!h) {
            const H = c.doc.resolve(v);
            if (L(H.nodeAfter)) {
              const oe = v + H.nodeAfter.nodeSize;
              for (; ; ) {
                const q = c.doc.resolve(oe);
                if (!L(q.nodeAfter)) break;
                c.delete(
                  oe,
                  oe + q.nodeAfter.nodeSize
                );
              }
              return c.setSelection(
                Te.near(c.doc.resolve(v + 1), 1)
              ), i && i(c.scrollIntoView()), !0;
            }
            const ee = l - 1, y = m.node(ee), P = m.indexAfter(l), Z = jt(y.contentMatchAt(P));
            if (!Z || !y.canReplaceWith(P, P, Z))
              return !1;
            const se = Z.createAndFill();
            if (!se) return !1;
            const ie = m.after(l);
            c.replaceWith(ie, ie, se);
            const je = c.doc.resolve(ie);
            return c.setSelection(Te.near(je, 1)), i && i(c.scrollIntoView()), !0;
          }
          const x = p.firstChild, M = o.schema.nodes.paragraph;
          if (x && M && x.type === M && x.content.size === 0) {
            for (; ; ) {
              const y = c.doc.resolve(v);
              if (!L(y.nodeAfter)) break;
              c.delete(
                v,
                v + y.nodeAfter.nodeSize
              );
            }
            const H = d + 1 + f.nodeSize, ee = Ge.near(
              c.doc.resolve(H + 1),
              1
            );
            return c.setSelection(ee), i && i(c.scrollIntoView()), !0;
          }
          const b = o.doc.nodeAt(m.after()) ?? p, j = 0, w = jt(b.contentMatchAt(j));
          if (!w || !b.canReplaceWith(j, j, w)) return !1;
          const V = w.createAndFill();
          if (!V) return !1;
          const z = m.after() + 1;
          for (; ; ) {
            const H = c.doc.resolve(v);
            if (!L(H.nodeAfter)) break;
            c.delete(
              v,
              v + H.nodeAfter.nodeSize
            );
          }
          c.replaceWith(z, z, V);
          const F = c.doc.resolve(z);
          return c.setSelection(Te.near(F, 1)), i && i(c.scrollIntoView()), !0;
        });
      },
      // Mod-Shift-Enter in summary: insert a new default block below the toggle (without changing open state)
      "Mod-Shift-Enter": ({ editor: e }) => e.commands.command(({ state: t, dispatch: n }) => {
        const { selection: a } = t, { $head: o } = a;
        if (o.parent.type.name !== "toggleSummary") return !1;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const r = o.before(i), m = o.node(i), l = r + m.nodeSize, c = t.tr, d = c.doc.resolve(l), g = (M) => {
          const b = t.schema.nodes.paragraph;
          return !!(M && b && M.type === b && M.content.size === 0);
        };
        if (g(d.nodeAfter)) {
          const M = l + d.nodeAfter.nodeSize;
          for (; ; ) {
            const b = c.doc.resolve(M);
            if (!g(b.nodeAfter)) break;
            c.delete(
              M,
              M + b.nodeAfter.nodeSize
            );
          }
          return c.setSelection(
            Te.near(c.doc.resolve(l + 1), 1)
          ), n && n(c.scrollIntoView()), !0;
        }
        const f = o.node(-2), p = o.indexAfter(-1), h = jt(f.contentMatchAt(p));
        if (!h || !f.canReplaceWith(p, p, h)) return !1;
        const v = h.createAndFill();
        if (!v) return !1;
        const L = o.after(-1);
        c.replaceWith(L, L, v);
        const x = c.doc.resolve(L);
        return c.setSelection(Te.near(x, 1)), n && n(c.scrollIntoView()), !0;
      }),
      // Backspace at start of empty summary: unset toggle
      Backspace: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        return !o || a.parent.type.name !== "toggleSummary" || a.parentOffset !== 0 ? !1 : bn(a.parent) ? e.commands.unsetToggle() : !1;
      }
    };
  }
}), lr = Re.create({
  name: "toggleContent",
  priority: 1e3,
  group: "block",
  content: "block+",
  defining: !0,
  selectable: !1,
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle-content"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(e, { "data-type": "toggle-content" }),
      0
    ];
  },
  addKeyboardShortcuts() {
    return {
      // Escape: move focus back to summary (Notion-like "go to parent block")
      Escape: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a } = n;
        let o = a.depth;
        for (; o > 0 && a.node(o).type.name !== "toggleContent"; )
          o--;
        if (o === 0) return !1;
        let i = o;
        for (; i > 0 && a.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const r = a.before(i), l = a.node(i).firstChild;
        if (!l) return !1;
        const c = r + 1 + l.nodeSize - 1;
        return e.chain().setTextSelection(c).focus().run();
      },
      // ArrowUp at the top of the first content block: move to summary end
      ArrowUp: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        if (!o || !a.parent.isTextblock || a.parentOffset !== 0) return !1;
        let i = a.depth;
        for (; i > 0 && a.node(i).type.name !== "toggleContent"; )
          i--;
        if (i === 0) return !1;
        const r = a.before(i), m = a.pos > 0 ? t.doc.resolve(a.pos - 1) : null, l = m ? Te.findFrom(m, -1, !0) : null;
        if (l) {
          let h = l.$from.depth;
          for (; h > 0 && l.$from.node(h).type.name !== "toggleContent"; )
            h--;
          if (h > 0 && l.$from.before(h) === r)
            return !1;
        }
        let c = i;
        for (; c > 0 && a.node(c).type.name !== "toggle"; )
          c--;
        if (c === 0) return !1;
        const d = a.before(c), f = a.node(c).firstChild;
        if (!f) return !1;
        const p = d + 1 + f.nodeSize - 1;
        return e.chain().setTextSelection(p).focus().run();
      },
      // ArrowDown at the end of the last content block: move to the next block after the toggle (create if needed)
      ArrowDown: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        if (!o || !a.parent.isTextblock || a.parentOffset !== a.parent.content.size) return !1;
        let i = a.depth;
        for (; i > 0 && a.node(i).type.name !== "toggleContent"; )
          i--;
        if (i === 0) return !1;
        const r = a.before(i), m = Math.min(a.pos + 1, t.doc.content.size), l = Te.findFrom(
          t.doc.resolve(m),
          1,
          !0
        );
        if (l) {
          let c = l.$from.depth;
          for (; c > 0 && l.$from.node(c).type.name !== "toggleContent"; )
            c--;
          if (c > 0 && l.$from.before(c) === r)
            return !1;
        }
        return e.commands.command(({ state: c, dispatch: d }) => {
          const { selection: g } = c, { $from: f } = g;
          let p = f.depth;
          for (; p > 0 && f.node(p).type.name !== "toggle"; )
            p--;
          if (p === 0) return !1;
          const h = f.before(p), v = f.node(p), L = h + v.nodeSize, x = c.tr, M = x.doc.resolve(L);
          if (M.nodeAfter)
            return x.setSelection(Te.near(M, 1)), d && d(x.scrollIntoView()), !0;
          const j = c.schema.nodes.paragraph, w = j == null ? void 0 : j.createAndFill();
          return !j || !w ? !1 : (x.insert(L, w), x.setSelection(Ge.create(x.doc, L + 1)), d && d(x.scrollIntoView()), !0);
        });
      },
      // Mod-Shift-Enter: insert a new default block below the toggle (works from content too)
      "Mod-Shift-Enter": ({ editor: e }) => e.commands.command(({ state: t, dispatch: n }) => {
        const { selection: a } = t, { $head: o } = a;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const r = o.before(i), m = o.node(i), l = r + m.nodeSize, c = t.tr, d = c.doc.resolve(l), g = (b) => {
          const j = t.schema.nodes.paragraph;
          return !!(b && j && b.type === j && b.content.size === 0);
        };
        if (g(d.nodeAfter)) {
          const b = l + d.nodeAfter.nodeSize;
          for (; ; ) {
            const j = c.doc.resolve(b);
            if (!g(j.nodeAfter)) break;
            c.delete(
              b,
              b + j.nodeAfter.nodeSize
            );
          }
          return c.setSelection(
            Te.near(c.doc.resolve(l + 1), 1)
          ), n && n(c.scrollIntoView()), !0;
        }
        const f = i - 1, p = o.node(f), h = o.indexAfter(i), v = jt(p.contentMatchAt(h));
        if (!v || !p.canReplaceWith(h, h, v)) return !1;
        const L = v.createAndFill();
        if (!L) return !1;
        const x = o.after(i);
        c.replaceWith(x, x, L);
        const M = c.doc.resolve(x);
        return c.setSelection(Te.near(M, 1)), n && n(c.scrollIntoView()), !0;
      }),
      // Backspace in empty first block of content: move to summary
      Backspace: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        if (!o || a.parentOffset !== 0) return !1;
        let i = a.depth;
        for (; i > 0 && a.node(i).type.name !== "toggleContent"; )
          i--;
        if (i === 0) return !1;
        const r = a.node(i), l = a.before(i) + 1;
        if (a.before(a.depth) !== l || a.parent.content.size > 0) return !1;
        if (r.childCount === 1) {
          const d = i - 1, g = a.before(d), f = t.doc.nodeAt(g);
          if (f && f.firstChild) {
            const p = g + 1 + f.firstChild.nodeSize - 1;
            return e.chain().setTextSelection(p).focus().run();
          }
        }
        return !1;
      }
    };
  }
}), mr = ({
  mentions: e,
  suggestions: t,
  themeOwner: n
}) => {
  const a = Array.isArray(e) ? {} : (e == null ? void 0 : e.suggestion) ?? {};
  return _s.configure(
    Array.isArray(e) ? {
      mentions: e,
      suggestion: (t == null ? void 0 : t.mention) ?? {},
      themeOwner: n ?? null
    } : {
      mentions: (e == null ? void 0 : e.mentions) || [],
      component: e == null ? void 0 : e.component,
      suggestion: {
        ...a,
        ...t == null ? void 0 : t.mention
      },
      themeOwner: n ?? null
    }
  );
}, cr = {
  attachment: ({ getCurrentDocument: e }) => Yi.configure({
    getCurrentDocument: e ?? null
  }),
  embed: ({ themeOwner: e }) => Ui.configure({
    getDocuments: async () => [],
    themeOwner: e ?? null
  }),
  iframe: ({ themeOwner: e }) => ns.configure({ themeOwner: e ?? null }),
  image: ({ filePlatformRuntime: e, themeOwner: t }) => [
    ps.configure({
      filePlatformRuntime: e ?? null
    }),
    Es.configure({ themeOwner: t ?? null })
  ],
  imageGroup: ({ filePlatformRuntime: e, themeOwner: t }) => nr.configure({
    filePlatformRuntime: e ?? null,
    themeOwner: t ?? null
  }),
  mention: (e) => mr(e),
  tag: ({ suggestions: e, tags: t, themeOwner: n }) => [
    In,
    Ts.configure({
      suggestion: (e == null ? void 0 : e.tag) ?? {},
      tags: () => t ?? [],
      themeOwner: n ?? null
    })
  ],
  toggle: () => [sr, rr, lr],
  video: ({ filePlatformRuntime: e }) => ar.configure({
    filePlatformRuntime: e ?? null
  })
}, dr = (e = {}, t = Sn) => t.flatMap((n) => {
  const a = cr[n.name];
  return a ? Go(a(e)) : Zo(
    {
      ...e,
      mode: "editor"
    },
    [n]
  );
}), wt = (e) => e.commands, ur = (e) => {
  const t = e;
  return t.$anchorCell !== void 0 && t.$headCell !== void 0 && typeof t.isColSelection == "function" && typeof t.isRowSelection == "function";
}, pr = (e) => {
  const { from: t, to: n } = e.selection;
  return {
    from: Math.min(t, n),
    to: Math.max(t, n)
  };
}, _n = (e) => {
  for (let t = e.depth; t > 0; t -= 1)
    if (e.node(t).isTextblock)
      return t;
  return -1;
}, fr = (e, t, n) => {
  const a = pr(e);
  return a.from === t && a.to === n;
};
function yn(e, t) {
  const { selection: n } = e;
  if (n instanceof Fo || ur(n))
    return !1;
  if (n instanceof Ho) {
    if (n.node.type.name !== "codeBlock")
      return !1;
    const g = n.from + 1, f = n.to - 1;
    return g >= f ? !1 : (t && t(e.tr.setSelection(Xe.create(e.doc, g, f))), !0);
  }
  if (!(n instanceof Xe))
    return !1;
  const { $from: a, $to: o } = n, i = _n(a), r = _n(o);
  if (i < 0 || r < 0)
    return !1;
  if (!(i === r && a.before(i) === o.before(r)))
    return ln(e, t);
  const l = a.node(i), c = a.start(i), d = a.end(i);
  return l.content.size === 0 ? !1 : fr(e, c, d) ? ln(e, t) : (t && t(
    e.tr.setSelection(
      Xe.create(e.doc, c, d)
    )
  ), !0);
}
const Ht = "textEditorShortcutKeymap", gr = (e, t, n = {}) => {
  var p;
  const a = On(
    ((p = t.dom.ownerDocument.defaultView) == null ? void 0 : p.navigator.userAgent) ?? ""
  );
  if (!n.runtime && !a)
    throw new Error(
      "An explicit shortcut runtime is required for an unknown platform"
    );
  const o = n.runtime ? null : Nn({ platform: a }), i = n.runtime ?? o, r = i.createOwner({
    contributions: [Qa],
    kind: "textEditor.editor",
    parent: n.parent,
    focusRequired: !0
  }), m = (h) => (e.on("transaction", h), e.on("update", h), e.on("selectionUpdate", h), e.on("destroy", h), () => {
    e.off("transaction", h), e.off("update", h), e.off("selectionUpdate", h), e.off("destroy", h);
  }), l = () => !e.isDestroyed && !t.isDestroyed, c = i.attachAction(ei, {
    owner: r,
    keyboardArgs: () => {
    },
    port: rn({
      subscribe: m,
      getState: () => {
        const h = wt(e).openLinkEditor;
        return {
          enabled: l() && e.isEditable && typeof h == "function",
          reason: l() ? e.isEditable ? typeof h != "function" ? "link-command-unavailable" : void 0 : "editor-readonly" : "editor-destroyed"
        };
      },
      run: () => wt(e).openLinkEditor()
    })
  }), d = i.attachAction(ti, {
    owner: r,
    keyboardArgs: () => {
    },
    port: rn({
      subscribe: m,
      getState: () => ({
        enabled: l() && yn(t.state),
        reason: "selection-not-progressive"
      }),
      run: () => yn(t.state, t.dispatch.bind(t))
    })
  }), g = Ya(i, r, { roots: [t.dom] });
  let f = !1;
  return {
    runtime: i,
    owner: r,
    editLink: c.forArgs(void 0, {
      bindingId: "textEditor.link.edit"
    }),
    progressiveSelect: d.forArgs(void 0, {
      bindingId: "textEditor.progressiveSelect"
    }),
    dispatch: (h) => g.dispatch(h, "editor"),
    dispose: () => {
      f || (f = !0, g.dispose(), c.dispose(), d.dispose(), r.dispose(), o == null || o.dispose());
    }
  };
}, hr = (e) => {
  var n;
  const t = (n = e == null ? void 0 : e.storage) == null ? void 0 : n[Ht];
  return (t == null ? void 0 : t.owner) ?? null;
}, vc = (e, t) => {
  var a, o;
  const n = (a = e == null ? void 0 : e.storage) == null ? void 0 : a[Ht];
  return t((n == null ? void 0 : n.owner) ?? null), (o = n == null ? void 0 : n.listeners) == null || o.add(t), () => {
    var i;
    (i = n == null ? void 0 : n.listeners) == null || i.delete(t);
  };
}, bt = Ht;
function jr(e = {}) {
  if ([...e.existingExtensionNames ?? []].includes(
    bt
  ))
    throw new Error(
      `[text-editor/shortcuts] Duplicate TipTap extension name: ${bt}`
    );
  return We.create({
    name: bt,
    priority: 1100,
    addStorage: () => ({
      owner: null,
      ownedRuntime: null,
      listeners: /* @__PURE__ */ new Set()
    }),
    onDestroy() {
      var t, n;
      (t = this.storage.owner) == null || t.dispose(), this.storage.owner = null, this.storage.listeners.forEach((a) => a(null)), this.storage.listeners.clear(), (n = this.storage.ownedRuntime) == null || n.dispose(), this.storage.ownedRuntime = null;
    },
    addProseMirrorPlugins() {
      const t = this.editor, n = this.storage;
      return [
        new Ne({
          props: {
            handleKeyDown: (a, o) => {
              var i;
              return ((i = n.owner) == null ? void 0 : i.dispatch(o)) ?? !1;
            }
          },
          view: (a) => {
            var i;
            if (!e.runtime && !n.ownedRuntime) {
              const r = On(
                ((i = a.dom.ownerDocument.defaultView) == null ? void 0 : i.navigator.userAgent) ?? ""
              );
              if (!r)
                throw new Error(
                  "An explicit shortcut runtime is required for an unknown platform"
                );
              n.ownedRuntime = Nn({ platform: r });
            }
            const o = gr(t, a, {
              ...e,
              runtime: e.runtime ?? n.ownedRuntime
            });
            return n.owner = o, n.listeners.forEach((r) => r(o)), {
              destroy: () => {
                o.dispose(), n.owner === o && (n.owner = null, n.listeners.forEach((r) => r(null)));
              }
            };
          }
        })
      ];
    }
  });
}
const vr = /* @__PURE__ */ new Set([
  "doc",
  "paragraph",
  "text",
  "hardBreak",
  "bold",
  "italic",
  "link",
  "textStyle",
  "namedColor",
  "bulletList",
  "orderedList",
  "listItem",
  "undoRedo",
  "history",
  "dropCursor",
  "gapCursor",
  "stableBlockIdentity",
  "stableBlockIdentityEngine",
  "stableBlockDomAttributes",
  "stableBlockIdentityDiagnostics",
  "textEditorSchemaKernelBinding",
  "placeholder",
  "deterministicRuntimeCommitClosure",
  "textEditorTypographyContract",
  // Interaction surfaces stay mounted; the profile boundary filters their items.
  "slashCommands",
  bt
]), br = new RegExp(
  `^color:\\s*var\\(--prose-color-(${Ot.textColors.join(
    "|"
  )})\\);?$`
), io = (e) => {
  const t = typeof e.config.addExtensions == "function", n = e.name === "link" ? { addProseMirrorPlugins: () => [] } : vr.has(e.name) || e.name === "starterKit" ? {} : {
    addKeyboardShortcuts: () => ({}),
    addInputRules: () => [],
    addPasteRules: () => [],
    addProseMirrorPlugins: () => [],
    addNodeView: () => null
  };
  return e.extend({
    ...n,
    ...t ? {
      addExtensions() {
        var a;
        return (((a = this.parent) == null ? void 0 : a.call(this)) ?? []).map(io);
      }
    } : {}
  });
}, _r = (e) => ({
  version: 2,
  body: { format: "json", content: e },
  assets: [],
  annotations: [],
  meta: { schemaVersion: "stable-block-identity/v2" }
}), yr = (e) => {
  const t = JSON.parse(JSON.stringify(e));
  let n = 0;
  const a = (o) => {
    var i;
    o.attrs && "blockId" in o.attrs && (o.attrs.blockId = `blk_probe${++n}`), (i = o.content) == null || i.forEach(a);
  };
  return a(t), _r(t);
};
function wr(e) {
  var o, i;
  const t = new DOMParser().parseFromString(e, "text/html");
  let n = !1;
  t.querySelectorAll("script,style,img,video,audio,iframe,object,embed,input").forEach((r) => {
    n = !0, r.remove();
  }), t.querySelectorAll("table").forEach((r) => {
    const m = t.createElement("div");
    r.querySelectorAll("tr").forEach((l) => {
      const c = t.createElement("p");
      c.textContent = Array.from(l.children).map((d) => d.textContent ?? "").join("	"), m.append(c);
    }), r.replaceWith(...m.childNodes);
  }), t.querySelectorAll("pre").forEach((r) => {
    const m = t.createElement("div");
    (r.textContent ?? "").replace(/\r\n?/g, `
`).split(`
`).forEach((l) => {
      const c = t.createElement("p");
      c.textContent = l, m.append(c);
    }), r.replaceWith(...m.childNodes);
  });
  const a = /* @__PURE__ */ new Set([
    "P",
    "BR",
    "B",
    "STRONG",
    "I",
    "EM",
    "A",
    "OL",
    "UL",
    "LI"
  ]);
  for (const r of Array.from(t.body.querySelectorAll("*")).reverse()) {
    const m = r.tagName === "SPAN" && r.attributes.length === 1 && ((i = br.exec(((o = r.getAttribute("style")) == null ? void 0 : o.trim()) ?? "")) == null ? void 0 : i[1]);
    if (/^H[1-6]$/.test(r.tagName) || r.tagName === "DIV") {
      const l = t.createElement("p");
      l.append(...r.childNodes), r.replaceWith(l);
    } else if (m)
      r.setAttribute("style", `color: var(--prose-color-${m})`);
    else if (!a.has(r.tagName)) r.replaceWith(...r.childNodes);
    else {
      const l = r.getAttribute("href"), c = r.getAttribute("start");
      for (const d of Array.from(r.attributes)) r.removeAttribute(d.name);
      if (r.tagName === "A")
        try {
          r.setAttribute("href", Qo(l)), r.setAttribute("target", "_blank"), r.setAttribute("rel", "noopener noreferrer nofollow");
        } catch {
          r.replaceWith(...r.childNodes);
        }
      r.tagName === "OL" && c && /^\d+$/.test(c) && +c >= 1 && +c <= 1e6 && r.setAttribute("start", c);
    }
  }
  return { html: t.body.innerHTML, dropped: n };
}
const kr = (e) => We.create({
  name: Yo,
  priority: 1e4,
  addStorage: () => ({
    capabilities: new Set(Ot.capabilities),
    textColors: Ot.textColors
  }),
  addProseMirrorPlugins() {
    let t = !1;
    const n = new en(
      this.editor.schema,
      en.fromSchema(this.editor.schema).rules
    ), a = n.parseSlice.bind(n);
    return n.parseSlice = (o, i) => a(o, { ...i, preserveWhitespace: !0 }), [
      new Ne({
        key: new De("basicRichTextAdmission"),
        filterTransaction: (o) => {
          var i;
          if (!o.docChanged) return !0;
          try {
            return Jo(
              yr(o.doc.toJSON()),
              o.getMeta("paste") ? e.limits : {
                ...Tt,
                ...e.limits,
                characters: Number.MAX_SAFE_INTEGER,
                bytes: Number.MAX_SAFE_INTEGER,
                nodes: Number.MAX_SAFE_INTEGER
              }
            ), !0;
          } catch (r) {
            return (i = e.issue) == null || i.call(e, String(r)), !1;
          }
        },
        props: {
          clipboardParser: n,
          clipboardTextParser: (o, i) => {
            const r = document.createElement("div"), m = Vo.fromSchema(this.editor.schema);
            for (const l of o.replace(/\r\n?/g, `
`).split(`
`)) {
              const c = r.appendChild(document.createElement("p"));
              l && c.appendChild(
                m.serializeNode(
                  this.editor.schema.text(l, i.marks())
                )
              );
            }
            return n.parseSlice(r, {
              context: i,
              preserveWhitespace: !0
            });
          },
          transformPastedText: (o) => {
            var i, r;
            return t = new TextEncoder().encode(o).length > (((i = e.limits) == null ? void 0 : i.bytes) ?? Tt.bytes), t ? ((r = e.issue) == null || r.call(e, "粘贴内容超过文档资源限制，未插入"), "") : o;
          },
          transformPastedHTML: (o) => {
            var r, m, l;
            if (t = !1, new TextEncoder().encode(o).length > (((r = e.limits) == null ? void 0 : r.bytes) ?? Tt.bytes))
              return t = !0, (m = e.issue) == null || m.call(e, "粘贴内容超过文档资源限制，未插入"), "";
            const i = wr(o);
            return i.dropped && ((l = e.issue) == null || l.call(e, "已略去不支持的图片或非文字内容")), i.html;
          },
          handlePaste: (o, i) => {
            var r, m;
            return t ? (t = !1, !0) : (r = i.clipboardData) != null && r.files.length ? ((m = e.issue) == null || m.call(e, "备注不支持图片或附件"), !0) : !1;
          },
          handleDrop: (o, i) => {
            var r, m;
            return (r = i.dataTransfer) != null && r.files.length ? ((m = e.issue) == null || m.call(e, "备注不支持图片或附件"), !0) : !1;
          }
        }
      })
    ];
  }
}), Cr = {
  "history.undo": "撤销",
  "history.redo": "重做",
  "style.block": "段落样式",
  "font.family": "字体",
  "font.size": "字号",
  "format.bold": "加粗",
  "format.italic": "斜体",
  "format.underline": "下划线",
  "format.strike": "删除线",
  "text.color": "文字颜色",
  "highlight.color": "底纹颜色",
  "list.bullet": "无序列表",
  "list.ordered": "有序列表",
  "list.task": "任务列表",
  "align.left": "左对齐",
  "align.center": "居中",
  "align.right": "右对齐",
  "align.justify": "两端对齐",
  "block.blockquote": "引用",
  "block.code": "代码块",
  "insert.horizontal-rule": "分割线",
  "insert.link": "链接",
  "insert.image": "图片",
  "insert.video": "视频",
  "insert.iframe": "嵌入网页",
  "table.menu": "表格",
  "ai.ask": "AI",
  "option:ai-custom": "自定义指令…",
  "option:paragraph": "正文",
  "option:heading-1": "标题 1",
  "option:heading-2": "标题 2",
  "option:heading-3": "标题 3",
  "option:heading-4": "标题 4",
  "option:heading-5": "标题 5",
  "option:heading-6": "标题 6",
  "option:bullet-list": "无序列表",
  "option:ordered-list": "有序列表",
  "option:task-list": "任务列表",
  "option:blockquote": "引用",
  "option:code-block": "代码块",
  "option:text-red": "红色",
  "option:text-orange": "橙色",
  "option:text-green": "绿色",
  "option:text-blue": "蓝色",
  "option:text-purple": "紫色",
  "option:text-gray": "灰色",
  "panel:default": "默认",
  "panel:clear-color": "清除颜色",
  "panel:custom": "自定义",
  "panel:more": "更多工具",
  "link:invalid": "请输入有效的链接地址（如 https://example.com）",
  "link:address": "链接地址",
  "link:apply": "应用链接",
  "link:cancel": "取消链接编辑",
  "link:copy": "复制链接",
  "link:edit": "编辑链接",
  "link:remove": "移除链接",
  "codeBlock:collapse": "折叠代码块",
  "codeBlock:expand": "展开代码块",
  "codeBlock:title.placeholder": "未命名代码块",
  "codeBlock:language.placeholder": "选择语言",
  "codeBlock:detect": "识别代码语言",
  "codeBlock:wrap": "切换自动换行",
  "codeBlock:lineNumbers": "切换行号",
  "codeBlock:copy": "复制代码",
  "codeBlock:copyMarkdown": "复制 Markdown",
  "codeBlock:copied": "已复制",
  "codeBlock:copyFailed": "复制失败",
  "codeBlock:copyUnavailable": "复制不可用",
  "codeBlock:settings": "代码块设置",
  "codeBlock:settings.open": "打开代码块设置",
  "codeBlock:settings.filename": "文件名",
  "codeBlock:settings.caption": "说明",
  "codeBlock:settings.startLine": "起始行号",
  "codeBlock:settings.previewLines": "预览行数",
  "codeBlock:settings.previewLines.all": "全部",
  "codeBlock:settings.copyMode": "复制模式",
  "codeBlock:settings.groupId": "Tabs 组",
  "codeBlock:settings.tabLabel": "Tab 标签",
  "codeBlock:settings.highlightLines": "高亮行",
  "codeBlock:settings.highlightLines.placeholder": "例如 1, 3-5",
  "codeBlock:settings.set": "设置",
  "codeBlock:settings.add": "添加",
  "codeBlock:settings.remove": "删除",
  "codeBlock:settings.clear": "清空",
  "codeBlock:settings.wrap": "自动换行",
  "codeBlock:settings.lineNumbers": "显示行号",
  "codeBlock:settings.collapsed": "折叠代码块",
  "codeBlock:suggestion.success": "识别到语言",
  "codeBlock:suggestion.lowConfidence": "无法确定语言",
  "codeBlock:suggestion.empty": "没有可识别的代码",
  "codeBlock:suggestion.unsupported": "识别到的语言不支持高亮",
  "codeBlock:suggestion.unavailable": "语言识别不可用",
  "codeBlock:suggestion.apply": "应用 {language}",
  "codeBlock:suggestion.dismiss": "忽略",
  "codeBlock:caption": "说明",
  "codeBlock:caption.placeholder": "添加说明",
  "codeBlock:filename.placeholder": "添加文件名",
  "codeBlock:placeholder": "输入代码，或先选择语言",
  "codeBlock:collapsed.expand": "展开编辑",
  "codeBlock:collapsed.expandAria": "展开代码块编辑，{summary}",
  "codeBlock:collapsed.summary.partial": "显示前 {visible} 行，共 {total} 行",
  "codeBlock:collapsed.summary.total": "共 {total} 行",
  "codeBlock:fold.expand": "展开第 {line} 行代码区域，显示隐藏的 {hidden} 行",
  "codeBlock:fold.collapse": "折叠第 {line} 行代码区域",
  "codeBlock:fold.hidden": "隐藏 {count} 行",
  "codeBlock:fold.readingView": "折叠代码阅读视图。按 Enter 或 F2 进入编辑",
  "slash-group:recent": "最近使用",
  "slash-group:ai": "AI",
  "slash:ai.ask": "AI 帮写",
  "slash:ai.ask:description": "按你的要求撰写或修改",
  "slash-group:basic": "基础块",
  "slash-group:media": "媒体",
  "slash-group:advanced": "高级",
  "slash:heading-1": "一级标题",
  "slash:heading-1:description": "大号章节标题",
  "slash:heading-2": "二级标题",
  "slash:heading-2:description": "中号章节标题",
  "slash:heading-3": "三级标题",
  "slash:heading-3:description": "小号章节标题",
  "slash:heading-4": "四级标题",
  "slash:heading-4:description": "最小章节标题",
  "slash:bullet-list": "无序列表",
  "slash:bullet-list:description": "用圆点列出要点",
  "slash:ordered-list": "有序列表",
  "slash:ordered-list:description": "按 1、2、3 编号",
  "slash:task-list": "任务列表",
  "slash:task-list:description": "带复选框的清单",
  "slash:toggle-list": "折叠块",
  "slash:toggle-list:description": "可展开收起的内容",
  "slash:blockquote": "引用",
  "slash:blockquote:description": "引用一段文字",
  "slash:horizontal-rule": "分割线",
  "slash:horizontal-rule:description": "插入一条分隔线",
  "slash:image": "图片",
  "slash:image:description": "上传或嵌入图片",
  "slash:video": "视频",
  "slash:video:description": "上传或嵌入视频",
  "slash:code-block": "代码块",
  "slash:code-block:description": "带高亮的代码片段",
  "slash:link": "链接",
  "slash:link:description": "插入网页链接",
  "slash:table": "表格",
  "slash:table:description": "插入 3×3 表格",
  "slash:embed": "嵌入网页",
  "slash:embed:description": "嵌入外部页面",
  "slash:align-left": "左对齐",
  "slash:align-left:description": "段落左对齐",
  "slash:align-center": "居中",
  "slash:align-center:description": "段落居中",
  "slash:align-right": "右对齐",
  "slash:align-right:description": "段落右对齐",
  "slash:align-justify": "两端对齐",
  "slash:align-justify:description": "段落两端对齐"
}, Ve = () => {
  const { lang: e } = ji(), t = B(() => e.value.toLowerCase().startsWith("zh")), n = (o, i) => t.value && o && Cr[o] || i;
  return { text: n, format: (o, i, r) => n(o, i).replace(
    /\{(\w+)\}/g,
    (m, l) => l in r ? String(r[l]) : m
  ) };
}, xr = ["href", "title"], Er = /* @__PURE__ */ Ce({
  name: "ZxTextEditorLinkPopup",
  __name: "link-popup",
  props: {
    href: {}
  },
  emits: ["updateHref", "close"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = Ee("text-editor-link-popup"), { text: i } = Ve(), r = A(null), m = (M) => {
      r.value = M;
    }, l = A(n.href), c = A(n.href === ""), d = A(!1), g = B(() => !d.value || l.value === "" ? !1 : !tn(l.value)), f = B(() => l.value ? i(
      "link:invalid",
      "Please enter a valid URL (e.g., https://example.com)"
    ) : ""), p = () => {
      d.value = !0;
    }, h = () => {
      d.value = !0, (l.value === "" || tn(l.value)) && a("updateHref", l.value);
    }, v = () => {
      n.href ? (c.value = !1, l.value = n.href, d.value = !1) : a("updateHref", "");
    }, L = async () => {
      var M, b;
      c.value = !0, d.value = !1, await Me(), (b = (M = r.value) == null ? void 0 : M.focus) == null || b.call(M);
    }, x = async () => {
      l.value && await navigator.clipboard.writeText(l.value);
    };
    return He(async () => {
      var M, b;
      await Me(), (b = (M = r.value) == null ? void 0 : M.focus) == null || b.call(M);
    }), (M, b) => (E(), S("div", {
      class: u(s(o).b())
    }, [
      _("div", {
        class: u(s(o).e("input-wrapper"))
      }, [
        c.value ? (E(), ke(s(_i), {
          key: 0,
          ref: m,
          modelValue: l.value,
          "onUpdate:modelValue": b[0] || (b[0] = (j) => l.value = j),
          class: u([s(o).e("input"), { "is-error": g.value }]),
          "aria-label": s(i)("link:address", "Link address"),
          placeholder: "https://example.com",
          onKeydown: [
            $e(h, ["enter"]),
            b[1] || (b[1] = $e((j) => a("close"), ["esc"]))
          ],
          onInput: p
        }, null, 8, ["modelValue", "class", "aria-label"])) : (E(), S("a", {
          key: 1,
          class: u(s(o).e("link")),
          href: l.value,
          title: l.value,
          target: "_blank",
          rel: "noopener noreferrer"
        }, W(l.value), 11, xr)),
        g.value ? (E(), S("div", {
          key: 2,
          class: u(s(o).e("error"))
        }, W(f.value), 3)) : K("", !0)
      ], 2),
      _("div", {
        class: u(s(o).e("actions"))
      }, [
        c.value ? (E(), S(ye, { key: 0 }, [
          U(s(Ue), {
            icon: "lucide:check",
            size: "small",
            text: "",
            "aria-label": s(i)("link:apply", "Apply link"),
            disabled: g.value && l.value !== "",
            onClick: h
          }, null, 8, ["aria-label", "disabled"]),
          U(s(Ue), {
            icon: "lucide:x",
            size: "small",
            text: "",
            "aria-label": s(i)("link:cancel", "Cancel link editing"),
            onClick: v
          }, null, 8, ["aria-label"])
        ], 64)) : (E(), S(ye, { key: 1 }, [
          U(s(Ue), {
            icon: "lucide:copy",
            size: "small",
            text: "",
            "aria-label": s(i)("link:copy", "Copy link"),
            onClick: x
          }, null, 8, ["aria-label"]),
          U(s(Ue), {
            icon: "lucide:pencil",
            size: "small",
            text: "",
            "aria-label": s(i)("link:edit", "Edit link"),
            onClick: L
          }, null, 8, ["aria-label"]),
          U(s(Ue), {
            icon: "lucide:link-2-off",
            size: "small",
            text: "",
            "aria-label": s(i)("link:remove", "Remove link"),
            onClick: b[2] || (b[2] = (j) => a("updateHref", ""))
          }, null, 8, ["aria-label"])
        ], 64))
      ], 2)
    ], 2));
  }
});
function Lr(e, t, n) {
  const {
    placement: a = "bottom-start",
    appendTo: o,
    interactive: i = !0,
    onClickOutside: r
  } = n, m = typeof o == "function" ? o() : o, l = m.ownerDocument, c = l.defaultView ?? globalThis, d = l.createElement("div");
  d.style.position = "absolute", d.style.zIndex = "9999", d.style.left = "0", d.style.top = "0", d.appendChild(e), m.appendChild(d);
  let g = t, f = null, p = null;
  const h = {
    getBoundingClientRect: () => g()
  }, v = async () => {
    const { x: w, y: V } = await Ci(h, d, {
      placement: a,
      middleware: [Qn(4), Wn(), Wi(4)]
    });
    Object.assign(d.style, {
      left: `${w}px`,
      top: `${V}px`
    });
  }, L = (w) => {
    d.contains(w.target) || r == null || r();
  }, x = () => {
    if (d.style.display = "block", v(), f = ki(h, d, v, {
      animationFrame: !0
    }), i && r) {
      const w = c.setTimeout(() => {
        p = null, l.addEventListener("mousedown", L);
      }, 0);
      p = () => c.clearTimeout(w);
    }
  }, M = () => {
    d.style.display = "none", f == null || f(), f = null, p == null || p(), p = null, l.removeEventListener("mousedown", L);
  }, b = () => {
    M(), d.remove();
  }, j = (w) => {
    w.getReferenceClientRect && (g = w.getReferenceClientRect, v());
  };
  return x(), {
    show: x,
    hide: M,
    destroy: b,
    setProps: j,
    element: d
  };
}
const gt = /* @__PURE__ */ new WeakMap(), Tr = hi.extend({
  addOptions() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      openOnClick: !1,
      autolink: !0,
      defaultProtocol: "https",
      linkOnPaste: !1,
      themeOwner: null
    };
  },
  addCommands() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      openLinkEditor: () => ({ editor: t }) => {
        var b;
        if (t.isDestroyed || !t.isEditable) return !1;
        const { state: n } = t, { from: a, to: o } = n.selection, { doc: i } = n;
        let r, m, l = !1, c = null;
        if (a === o) {
          const j = n.selection.$from, w = No(j, this.type);
          if (w) {
            r = w;
            const V = i.nodeAt(j.pos);
            V && (m = V.marks.find((z) => z.type === this.type)), t.chain().setTextSelection({ from: w.from, to: w.to }).run(), l = !0;
          } else
            c = a;
        } else
          r = { from: a, to: o }, m = i.resolve(a).marks().find((j) => j.type === this.type);
        if (!r && c === null) return !1;
        const d = (m == null ? void 0 : m.attrs.href) || "", g = (r == null ? void 0 : r.from) ?? a, f = (r == null ? void 0 : r.to) ?? o;
        (b = gt.get(t)) == null || b.abort();
        const p = new AbortController();
        gt.set(t, p);
        const h = () => p.abort(), v = ({
          transaction: j
        }) => {
          (j.docChanged || !t.isEditable) && h();
        }, L = () => {
          (t.isDestroyed || !t.isEditable) && h();
        }, x = () => {
          t.off("transaction", v), t.off("update", L), t.off("destroy", h), p.signal.removeEventListener("abort", x), gt.get(t) === p && gt.delete(t);
        };
        t.on("transaction", v), t.on("update", L), t.on("destroy", h), p.signal.addEventListener("abort", x, { once: !0 });
        const M = () => {
          p.signal.aborted || Ir(
            this.options.themeOwner,
            d,
            t.view.dom,
            p.signal
          ).then((j) => {
            if (p.signal.aborted || t.isDestroyed || !t.isEditable)
              return;
            x();
            const w = ta(j);
            let V = t.chain().focus(null, { scrollIntoView: !1 });
            if (c !== null) {
              w && V.insertContentAt(c, {
                type: "text",
                text: w,
                marks: [{ type: this.name, attrs: { href: w } }]
              }).command(({ tr: z }) => (z.setStoredMarks([]), !0)).run();
              return;
            }
            if (w === "") {
              V.setTextSelection({ from: g, to: f }).unsetLink().command(({ tr: z }) => (z.setStoredMarks([]), !0)).run();
              return;
            }
            V = V.setTextSelection({ from: g, to: f }).setLink({ href: w }).setTextSelection(f).command(({ tr: z }) => (z.setStoredMarks([]), !0)), V.run();
          }).catch(() => {
          }).finally(x);
        };
        return l ? requestAnimationFrame(M) : M(), !0;
      }
    };
  },
  addProseMirrorPlugins() {
    var t;
    const e = ((t = this.parent) == null ? void 0 : t.call(this)) || [];
    return e.push(
      ea({
        editor: this.editor,
        defaultProtocol: this.options.defaultProtocol,
        type: this.type
      }),
      Sr({
        editor: this.editor,
        type: this.type
      }),
      new Ne({
        props: {
          handleClick: (n, a, o) => {
            var i;
            if (this.editor.isEditable) {
              if (!this.editor.isActive("link")) return !1;
              if (o.preventDefault(), o.metaKey) {
                const r = (i = o.target) == null ? void 0 : i.getAttribute("href");
                r && window.open(r, "_blank");
              } else
                wt(this.editor).openLinkEditor();
            }
          }
        }
      })
    ), e;
  }
});
async function Ir(e, t, n, a) {
  var r;
  if (!e) throw new Error("EDITOR_THEME_OWNER_REQUIRED");
  if (a.aborted) throw new Error("Link editing cancelled");
  const o = await e.acquirePortal();
  if (!o.ok) throw new Error((r = o.diagnostics[0]) == null ? void 0 : r.code);
  const i = o.value;
  if (a.aborted)
    throw i.release(), new Error("Link editing cancelled");
  return new Promise((m, l) => {
    const c = i.target.ownerDocument.createElement("div");
    let d;
    const g = i.target.ownerDocument.defaultView, f = g == null ? void 0 : g.getSelection(), p = (g == null ? void 0 : g.requestAnimationFrame.bind(g)) ?? ((j) => (queueMicrotask(() => j(0)), 0));
    if (f && f.rangeCount > 0) {
      const j = f.getRangeAt(0), w = j.getBoundingClientRect(), V = j.collapsed;
      d = () => ({
        width: 0,
        height: w.height,
        top: w.top,
        right: V ? w.left : w.right,
        bottom: w.bottom,
        left: w.left,
        x: w.left,
        y: w.top,
        toJSON: () => ({})
      });
    } else
      d = () => n.getBoundingClientRect();
    let h = null, v = !1, L = !1;
    const x = (j, w) => {
      L || (L = !0, j === "resolve" ? m(w) : l(w));
    }, M = () => {
      v || (v = !0, a.removeEventListener("abort", M), x("reject", "Link editing cancelled or destroyed"), p(() => {
        h == null || h.destroy(), et(null, c), c == null || c.remove(), h = null, i.release();
      }));
    }, b = Nt(Er, {
      href: t,
      onClose: () => {
        x("reject", "Link editing cancelled"), M();
      },
      onUpdateHref: (j) => {
        x("resolve", j), M();
      }
    });
    b.appContext = i.appContext, a.addEventListener("abort", M, { once: !0 });
    try {
      et(b, c), h = Lr(c, d, {
        placement: "top",
        appendTo: i.target,
        interactive: !0,
        onClickOutside: M
      });
    } catch (j) {
      x("reject", j), M();
    }
  });
}
function Sr(e) {
  return new Ne({
    key: new De("clearLinkMarkOnBoundary"),
    appendTransaction: (t, n, a) => {
      if (!e.editor.isEditable)
        return null;
      const { tr: o, doc: i, selection: r, storedMarks: m } = a, { $from: l, empty: c } = r;
      if (!c || !m || m.length === 0)
        return null;
      const d = e.type;
      return !m.some(
        (h) => h.type === d
      ) || l.marks().some(
        (h) => h.type === d
      ) ? null : o.setStoredMarks([]);
    }
  });
}
const Ar = /* @__PURE__ */ Ce({
  __name: "EmojiList",
  props: {
    items: {
      type: Array,
      required: !0
    },
    editor: {
      type: Object,
      required: !0
    },
    range: {
      type: Object,
      required: !0
    },
    command: {
      type: Function,
      required: !0
    },
    loading: {
      type: Boolean,
      default: !1
    }
  },
  setup(e, { expose: t }) {
    const n = e, a = Ee("text-editor-suggestion"), o = A(null), i = (l) => {
      l && n.command(l);
    }, r = (l) => {
      i(l);
    };
    return t({
      onKeyDown: ({ event: l }) => {
        var c;
        return ((c = o.value) == null ? void 0 : c.onKeyDown({ event: l })) ?? !1;
      }
    }), (l, c) => (E(), ke(Ft, {
      ref_key: "suggestionList",
      ref: o,
      items: e.items,
      command: r,
      loading: e.loading
    }, {
      default: _e(({ item: d }) => [
        _("span", {
          class: u(s(a).e("item-icon"))
        }, W(d.emoji), 3),
        _("span", null, W(d.name), 1)
      ]),
      _: 1
    }, 8, ["items", "loading"]));
  }
}), Pr = /* @__PURE__ */ JSON.parse('[{"name":"grinning","emoji":"😀"},{"name":"grimacing","emoji":"😬"},{"name":"grin","emoji":"😁"},{"name":"joy","emoji":"😂"},{"name":"rofl","emoji":"🤣"},{"name":"smiley","emoji":"😃"},{"name":"smile","emoji":"😄"},{"name":"sweat_smile","emoji":"😅"},{"name":"laughing","emoji":"😆"},{"name":"innocent","emoji":"😇"},{"name":"wink","emoji":"😉"},{"name":"blush","emoji":"😊"},{"name":"slightly_smiling_face","emoji":"🙂"},{"name":"upside_down_face","emoji":"🙃"},{"name":"relaxed","emoji":"☺"},{"name":"yum","emoji":"😋"},{"name":"relieved","emoji":"😌"},{"name":"heart_eyes","emoji":"😍"},{"name":"kissing_heart","emoji":"😘"},{"name":"kissing","emoji":"😗"},{"name":"kissing_smiling_eyes","emoji":"😙"},{"name":"kissing_closed_eyes","emoji":"😚"},{"name":"stuck_out_tongue_winking_eye","emoji":"😜"},{"name":"stuck_out_tongue_closed_eyes","emoji":"😝"},{"name":"stuck_out_tongue","emoji":"😛"},{"name":"money_mouth_face","emoji":"🤑"},{"name":"nerd_face","emoji":"🤓"},{"name":"sunglasses","emoji":"😎"},{"name":"clown_face","emoji":"🤡"},{"name":"cowboy_hat_face","emoji":"🤠"},{"name":"hugs","emoji":"🤗"},{"name":"smirk","emoji":"😏"},{"name":"no_mouth","emoji":"😶"},{"name":"neutral_face","emoji":"😐"},{"name":"expressionless","emoji":"😑"},{"name":"unamused","emoji":"😒"},{"name":"roll_eyes","emoji":"🙄"},{"name":"thinking","emoji":"🤔"},{"name":"lying_face","emoji":"🤥"},{"name":"flushed","emoji":"😳"},{"name":"disappointed","emoji":"😞"},{"name":"worried","emoji":"😟"},{"name":"angry","emoji":"😠"},{"name":"rage","emoji":"😡"},{"name":"pensive","emoji":"😔"},{"name":"confused","emoji":"😕"},{"name":"slightly_frowning_face","emoji":"🙁"},{"name":"frowning_face","emoji":"☹"},{"name":"persevere","emoji":"😣"},{"name":"confounded","emoji":"😖"},{"name":"tired_face","emoji":"😫"},{"name":"weary","emoji":"😩"},{"name":"triumph","emoji":"😤"},{"name":"open_mouth","emoji":"😮"},{"name":"scream","emoji":"😱"},{"name":"fearful","emoji":"😨"},{"name":"cold_sweat","emoji":"😰"},{"name":"hushed","emoji":"😯"},{"name":"frowning_with_open_mouth","emoji":"😦"},{"name":"anguished","emoji":"😧"},{"name":"cry","emoji":"😢"},{"name":"disappointed_relieved","emoji":"😥"},{"name":"drooling_face","emoji":"🤤"},{"name":"sleepy","emoji":"😪"},{"name":"sweat","emoji":"😓"},{"name":"sob","emoji":"😭"},{"name":"dizzy_face","emoji":"😵"},{"name":"astonished","emoji":"😲"},{"name":"zipper_mouth_face","emoji":"🤐"},{"name":"nauseated_face","emoji":"🤢"},{"name":"sneezing_face","emoji":"🤧"},{"name":"mask","emoji":"😷"},{"name":"face_with_thermometer","emoji":"🤒"},{"name":"face_with_head_bandage","emoji":"🤕"},{"name":"sleeping","emoji":"😴"},{"name":"zzz","emoji":"💤"},{"name":"poop","emoji":"💩"},{"name":"smiling_imp","emoji":"😈"},{"name":"imp","emoji":"👿"},{"name":"japanese_ogre","emoji":"👹"},{"name":"japanese_goblin","emoji":"👺"},{"name":"skull","emoji":"💀"},{"name":"ghost","emoji":"👻"},{"name":"alien","emoji":"👽"},{"name":"robot","emoji":"🤖"},{"name":"smiley_cat","emoji":"😺"},{"name":"smile_cat","emoji":"😸"},{"name":"joy_cat","emoji":"😹"},{"name":"heart_eyes_cat","emoji":"😻"},{"name":"smirk_cat","emoji":"😼"},{"name":"kissing_cat","emoji":"😽"},{"name":"scream_cat","emoji":"🙀"},{"name":"crying_cat_face","emoji":"😿"},{"name":"pouting_cat","emoji":"😾"},{"name":"raised_hands","emoji":"🙌"},{"name":"clap","emoji":"👏"},{"name":"wave","emoji":"👋"},{"name":"call_me_hand","emoji":"🤙"},{"name":"+1","emoji":"👍"},{"name":"-1","emoji":"👎"},{"name":"facepunch","emoji":"👊"},{"name":"fist","emoji":"✊"},{"name":"fist_left","emoji":"🤛"},{"name":"fist_right","emoji":"🤜"},{"name":"v","emoji":"✌"},{"name":"ok_hand","emoji":"👌"},{"name":"raised_hand","emoji":"✋"},{"name":"raised_back_of_hand","emoji":"🤚"},{"name":"open_hands","emoji":"👐"},{"name":"muscle","emoji":"💪"},{"name":"pray","emoji":"🙏"},{"name":"handshake","emoji":"🤝"},{"name":"point_up","emoji":"☝"},{"name":"point_up_2","emoji":"👆"},{"name":"point_down","emoji":"👇"},{"name":"point_left","emoji":"👈"},{"name":"point_right","emoji":"👉"},{"name":"fu","emoji":"🖕"},{"name":"raised_hand_with_fingers_splayed","emoji":"🖐"},{"name":"metal","emoji":"🤘"},{"name":"crossed_fingers","emoji":"🤞"},{"name":"vulcan_salute","emoji":"🖖"},{"name":"writing_hand","emoji":"✍"},{"name":"selfie","emoji":"🤳"},{"name":"nail_care","emoji":"💅"},{"name":"lips","emoji":"👄"},{"name":"tongue","emoji":"👅"},{"name":"ear","emoji":"👂"},{"name":"nose","emoji":"👃"},{"name":"eye","emoji":"👁"},{"name":"eyes","emoji":"👀"},{"name":"bust_in_silhouette","emoji":"👤"},{"name":"busts_in_silhouette","emoji":"👥"},{"name":"speaking_head","emoji":"🗣"},{"name":"baby","emoji":"👶"},{"name":"boy","emoji":"👦"},{"name":"girl","emoji":"👧"},{"name":"man","emoji":"👨"},{"name":"woman","emoji":"👩"},{"name":"blonde_woman","emoji":"👱‍♀️"},{"name":"blonde_man","emoji":"👱"},{"name":"older_man","emoji":"👴"},{"name":"older_woman","emoji":"👵"},{"name":"man_with_gua_pi_mao","emoji":"👲"},{"name":"woman_with_turban","emoji":"👳‍♀️"},{"name":"man_with_turban","emoji":"👳"},{"name":"policewoman","emoji":"👮‍♀️"},{"name":"policeman","emoji":"👮"},{"name":"construction_worker_woman","emoji":"👷‍♀️"},{"name":"construction_worker_man","emoji":"👷"},{"name":"guardswoman","emoji":"💂‍♀️"},{"name":"guardsman","emoji":"💂"},{"name":"female_detective","emoji":"🕵️‍♀"},{"name":"male_detective","emoji":"🕵"},{"name":"woman_health_worker","emoji":"👩‍⚕️"},{"name":"man_health_worker","emoji":"👨‍⚕️"},{"name":"woman_farmer","emoji":"👩‍🌾"},{"name":"man_farmer","emoji":"👨‍🌾"},{"name":"woman_cook","emoji":"👩‍🍳"},{"name":"man_cook","emoji":"👨‍🍳"},{"name":"woman_student","emoji":"👩‍🎓"},{"name":"man_student","emoji":"👨‍🎓"},{"name":"woman_singer","emoji":"👩‍🎤"},{"name":"man_singer","emoji":"👨‍🎤"},{"name":"woman_teacher","emoji":"👩‍🏫"},{"name":"man_teacher","emoji":"👨‍🏫"},{"name":"woman_factory_worker","emoji":"👩‍🏭"},{"name":"man_factory_worker","emoji":"👨‍🏭"},{"name":"woman_technologist","emoji":"👩‍💻"},{"name":"man_technologist","emoji":"👨‍💻"},{"name":"woman_office_worker","emoji":"👩‍💼"},{"name":"man_office_worker","emoji":"👨‍💼"},{"name":"woman_mechanic","emoji":"👩‍🔧"},{"name":"man_mechanic","emoji":"👨‍🔧"},{"name":"woman_scientist","emoji":"👩‍🔬"},{"name":"man_scientist","emoji":"👨‍🔬"},{"name":"woman_artist","emoji":"👩‍🎨"},{"name":"man_artist","emoji":"👨‍🎨"},{"name":"woman_firefighter","emoji":"👩‍🚒"},{"name":"man_firefighter","emoji":"👨‍🚒"},{"name":"woman_pilot","emoji":"👩‍✈️"},{"name":"man_pilot","emoji":"👨‍✈️"},{"name":"woman_astronaut","emoji":"👩‍🚀"},{"name":"man_astronaut","emoji":"👨‍🚀"},{"name":"woman_judge","emoji":"👩‍⚖️"},{"name":"man_judge","emoji":"👨‍⚖️"},{"name":"mrs_claus","emoji":"🤶"},{"name":"santa","emoji":"🎅"},{"name":"angel","emoji":"👼"},{"name":"pregnant_woman","emoji":"🤰"},{"name":"princess","emoji":"👸"},{"name":"prince","emoji":"🤴"},{"name":"bride_with_veil","emoji":"👰"},{"name":"person_in_tuxedo","emoji":"🤵"},{"name":"running_woman","emoji":"🏃‍♀️"},{"name":"running_man","emoji":"🏃"},{"name":"walking_woman","emoji":"🚶‍♀️"},{"name":"walking_man","emoji":"🚶"},{"name":"dancer","emoji":"💃"},{"name":"man_dancing","emoji":"🕺"},{"name":"dancing_women","emoji":"👯"},{"name":"dancing_men","emoji":"👯‍♂"},{"name":"couple","emoji":"👫"},{"name":"two_men_holding_hands","emoji":"👬"},{"name":"two_women_holding_hands","emoji":"👭"},{"name":"bowing_woman","emoji":"🙇‍♀️"},{"name":"bowing_man","emoji":"🙇"},{"name":"man_facepalming","emoji":"🤦‍♂️"},{"name":"woman_facepalming","emoji":"🤦‍♀️"},{"name":"woman_shrugging","emoji":"🤷‍♀️"},{"name":"man_shrugging","emoji":"🤷‍♂️"},{"name":"tipping_hand_woman","emoji":"💁‍♀️"},{"name":"tipping_hand_man","emoji":"💁‍♂️"},{"name":"no_good_woman","emoji":"🙅‍♀️"},{"name":"no_good_man","emoji":"🙅‍♂️"},{"name":"ok_woman","emoji":"🙆‍♀️"},{"name":"ok_man","emoji":"🙆‍♂️"},{"name":"raising_hand_woman","emoji":"🙋‍♀️"},{"name":"raising_hand_man","emoji":"🙋‍♂️"},{"name":"pouting_woman","emoji":"🙎‍♀️"},{"name":"pouting_man","emoji":"🙎‍♂️"},{"name":"frowning_woman","emoji":"🙍‍♀️"},{"name":"frowning_man","emoji":"🙍‍♂️"},{"name":"haircut_woman","emoji":"💇‍♀️"},{"name":"haircut_man","emoji":"💇‍♂️"},{"name":"massage_woman","emoji":"💆‍♀️"},{"name":"massage_man","emoji":"💆‍♂️"},{"name":"couple_with_heart","emoji":"💑"},{"name":"couple_with_heart_woman_woman","emoji":"👩‍❤️‍👩"},{"name":"couple_with_heart_man_man","emoji":"👨‍❤️‍👨"},{"name":"couplekiss_man_woman","emoji":"💏"},{"name":"couplekiss_woman_woman","emoji":"👩‍❤️‍💋‍👩"},{"name":"couplekiss_man_man","emoji":"👨‍❤️‍💋‍👨"},{"name":"family","emoji":"👪"},{"name":"family_man_woman_girl","emoji":"👨‍👩‍👧"},{"name":"family_man_woman_girl_boy","emoji":"👨‍👩‍👧‍👦"},{"name":"family_man_woman_boy_boy","emoji":"👨‍👩‍👦‍👦"},{"name":"family_man_woman_girl_girl","emoji":"👨‍👩‍👧‍👧"},{"name":"family_woman_woman_boy","emoji":"👩‍👩‍👦"},{"name":"family_woman_woman_girl","emoji":"👩‍👩‍👧"},{"name":"family_woman_woman_girl_boy","emoji":"👩‍👩‍👧‍👦"},{"name":"family_woman_woman_boy_boy","emoji":"👩‍👩‍👦‍👦"},{"name":"family_woman_woman_girl_girl","emoji":"👩‍👩‍👧‍👧"},{"name":"family_man_man_boy","emoji":"👨‍👨‍👦"},{"name":"family_man_man_girl","emoji":"👨‍👨‍👧"},{"name":"family_man_man_girl_boy","emoji":"👨‍👨‍👧‍👦"},{"name":"family_man_man_boy_boy","emoji":"👨‍👨‍👦‍👦"},{"name":"family_man_man_girl_girl","emoji":"👨‍👨‍👧‍👧"},{"name":"family_woman_boy","emoji":"👩‍👦"},{"name":"family_woman_girl","emoji":"👩‍👧"},{"name":"family_woman_girl_boy","emoji":"👩‍👧‍👦"},{"name":"family_woman_boy_boy","emoji":"👩‍👦‍👦"},{"name":"family_woman_girl_girl","emoji":"👩‍👧‍👧"},{"name":"family_man_boy","emoji":"👨‍👦"},{"name":"family_man_girl","emoji":"👨‍👧"},{"name":"family_man_girl_boy","emoji":"👨‍👧‍👦"},{"name":"family_man_boy_boy","emoji":"👨‍👦‍👦"},{"name":"family_man_girl_girl","emoji":"👨‍👧‍👧"},{"name":"womans_clothes","emoji":"👚"},{"name":"tshirt","emoji":"👕"},{"name":"jeans","emoji":"👖"},{"name":"necktie","emoji":"👔"},{"name":"dress","emoji":"👗"},{"name":"bikini","emoji":"👙"},{"name":"kimono","emoji":"👘"},{"name":"lipstick","emoji":"💄"},{"name":"kiss","emoji":"💋"},{"name":"footprints","emoji":"👣"},{"name":"high_heel","emoji":"👠"},{"name":"sandal","emoji":"👡"},{"name":"boot","emoji":"👢"},{"name":"mans_shoe","emoji":"👞"},{"name":"athletic_shoe","emoji":"👟"},{"name":"womans_hat","emoji":"👒"},{"name":"tophat","emoji":"🎩"},{"name":"rescue_worker_helmet","emoji":"⛑"},{"name":"mortar_board","emoji":"🎓"},{"name":"crown","emoji":"👑"},{"name":"school_satchel","emoji":"🎒"},{"name":"pouch","emoji":"👝"},{"name":"purse","emoji":"👛"},{"name":"handbag","emoji":"👜"},{"name":"briefcase","emoji":"💼"},{"name":"eyeglasses","emoji":"👓"},{"name":"dark_sunglasses","emoji":"🕶"},{"name":"ring","emoji":"💍"},{"name":"closed_umbrella","emoji":"🌂"},{"name":"dog","emoji":"🐶"},{"name":"cat","emoji":"🐱"},{"name":"mouse","emoji":"🐭"},{"name":"hamster","emoji":"🐹"},{"name":"rabbit","emoji":"🐰"},{"name":"fox_face","emoji":"🦊"},{"name":"bear","emoji":"🐻"},{"name":"panda_face","emoji":"🐼"},{"name":"koala","emoji":"🐨"},{"name":"tiger","emoji":"🐯"},{"name":"lion","emoji":"🦁"},{"name":"cow","emoji":"🐮"},{"name":"pig","emoji":"🐷"},{"name":"pig_nose","emoji":"🐽"},{"name":"frog","emoji":"🐸"},{"name":"squid","emoji":"🦑"},{"name":"octopus","emoji":"🐙"},{"name":"shrimp","emoji":"🦐"},{"name":"monkey_face","emoji":"🐵"},{"name":"gorilla","emoji":"🦍"},{"name":"see_no_evil","emoji":"🙈"},{"name":"hear_no_evil","emoji":"🙉"},{"name":"speak_no_evil","emoji":"🙊"},{"name":"monkey","emoji":"🐒"},{"name":"chicken","emoji":"🐔"},{"name":"penguin","emoji":"🐧"},{"name":"bird","emoji":"🐦"},{"name":"baby_chick","emoji":"🐤"},{"name":"hatching_chick","emoji":"🐣"},{"name":"hatched_chick","emoji":"🐥"},{"name":"duck","emoji":"🦆"},{"name":"eagle","emoji":"🦅"},{"name":"owl","emoji":"🦉"},{"name":"bat","emoji":"🦇"},{"name":"wolf","emoji":"🐺"},{"name":"boar","emoji":"🐗"},{"name":"horse","emoji":"🐴"},{"name":"unicorn","emoji":"🦄"},{"name":"honeybee","emoji":"🐝"},{"name":"bug","emoji":"🐛"},{"name":"butterfly","emoji":"🦋"},{"name":"snail","emoji":"🐌"},{"name":"lady_beetle","emoji":"🐞"},{"name":"ant","emoji":"🐜"},{"name":"spider","emoji":"🕷"},{"name":"scorpion","emoji":"🦂"},{"name":"crab","emoji":"🦀"},{"name":"snake","emoji":"🐍"},{"name":"lizard","emoji":"🦎"},{"name":"turtle","emoji":"🐢"},{"name":"tropical_fish","emoji":"🐠"},{"name":"fish","emoji":"🐟"},{"name":"blowfish","emoji":"🐡"},{"name":"dolphin","emoji":"🐬"},{"name":"shark","emoji":"🦈"},{"name":"whale","emoji":"🐳"},{"name":"whale2","emoji":"🐋"},{"name":"crocodile","emoji":"🐊"},{"name":"leopard","emoji":"🐆"},{"name":"tiger2","emoji":"🐅"},{"name":"water_buffalo","emoji":"🐃"},{"name":"ox","emoji":"🐂"},{"name":"cow2","emoji":"🐄"},{"name":"deer","emoji":"🦌"},{"name":"dromedary_camel","emoji":"🐪"},{"name":"camel","emoji":"🐫"},{"name":"elephant","emoji":"🐘"},{"name":"rhinoceros","emoji":"🦏"},{"name":"goat","emoji":"🐐"},{"name":"ram","emoji":"🐏"},{"name":"sheep","emoji":"🐑"},{"name":"racehorse","emoji":"🐎"},{"name":"pig2","emoji":"🐖"},{"name":"rat","emoji":"🐀"},{"name":"mouse2","emoji":"🐁"},{"name":"rooster","emoji":"🐓"},{"name":"turkey","emoji":"🦃"},{"name":"dove","emoji":"🕊"},{"name":"dog2","emoji":"🐕"},{"name":"poodle","emoji":"🐩"},{"name":"cat2","emoji":"🐈"},{"name":"rabbit2","emoji":"🐇"},{"name":"chipmunk","emoji":"🐿"},{"name":"paw_prints","emoji":"🐾"},{"name":"dragon","emoji":"🐉"},{"name":"dragon_face","emoji":"🐲"},{"name":"cactus","emoji":"🌵"},{"name":"christmas_tree","emoji":"🎄"},{"name":"evergreen_tree","emoji":"🌲"},{"name":"deciduous_tree","emoji":"🌳"},{"name":"palm_tree","emoji":"🌴"},{"name":"seedling","emoji":"🌱"},{"name":"herb","emoji":"🌿"},{"name":"shamrock","emoji":"☘"},{"name":"four_leaf_clover","emoji":"🍀"},{"name":"bamboo","emoji":"🎍"},{"name":"tanabata_tree","emoji":"🎋"},{"name":"leaves","emoji":"🍃"},{"name":"fallen_leaf","emoji":"🍂"},{"name":"maple_leaf","emoji":"🍁"},{"name":"ear_of_rice","emoji":"🌾"},{"name":"hibiscus","emoji":"🌺"},{"name":"sunflower","emoji":"🌻"},{"name":"rose","emoji":"🌹"},{"name":"wilted_flower","emoji":"🥀"},{"name":"tulip","emoji":"🌷"},{"name":"blossom","emoji":"🌼"},{"name":"cherry_blossom","emoji":"🌸"},{"name":"bouquet","emoji":"💐"},{"name":"mushroom","emoji":"🍄"},{"name":"chestnut","emoji":"🌰"},{"name":"jack_o_lantern","emoji":"🎃"},{"name":"shell","emoji":"🐚"},{"name":"spider_web","emoji":"🕸"},{"name":"earth_americas","emoji":"🌎"},{"name":"earth_africa","emoji":"🌍"},{"name":"earth_asia","emoji":"🌏"},{"name":"full_moon","emoji":"🌕"},{"name":"waning_gibbous_moon","emoji":"🌖"},{"name":"last_quarter_moon","emoji":"🌗"},{"name":"waning_crescent_moon","emoji":"🌘"},{"name":"new_moon","emoji":"🌑"},{"name":"waxing_crescent_moon","emoji":"🌒"},{"name":"first_quarter_moon","emoji":"🌓"},{"name":"waxing_gibbous_moon","emoji":"🌔"},{"name":"new_moon_with_face","emoji":"🌚"},{"name":"full_moon_with_face","emoji":"🌝"},{"name":"first_quarter_moon_with_face","emoji":"🌛"},{"name":"last_quarter_moon_with_face","emoji":"🌜"},{"name":"sun_with_face","emoji":"🌞"},{"name":"crescent_moon","emoji":"🌙"},{"name":"star","emoji":"⭐"},{"name":"star2","emoji":"🌟"},{"name":"dizzy","emoji":"💫"},{"name":"sparkles","emoji":"✨"},{"name":"comet","emoji":"☄"},{"name":"sunny","emoji":"☀"},{"name":"sun_behind_small_cloud","emoji":"🌤"},{"name":"partly_sunny","emoji":"⛅"},{"name":"sun_behind_large_cloud","emoji":"🌥"},{"name":"sun_behind_rain_cloud","emoji":"🌦"},{"name":"cloud","emoji":"☁"},{"name":"cloud_with_rain","emoji":"🌧"},{"name":"cloud_with_lightning_and_rain","emoji":"⛈"},{"name":"cloud_with_lightning","emoji":"🌩"},{"name":"zap","emoji":"⚡"},{"name":"fire","emoji":"🔥"},{"name":"boom","emoji":"💥"},{"name":"snowflake","emoji":"❄"},{"name":"cloud_with_snow","emoji":"🌨"},{"name":"snowman","emoji":"⛄"},{"name":"snowman_with_snow","emoji":"☃"},{"name":"wind_face","emoji":"🌬"},{"name":"dash","emoji":"💨"},{"name":"tornado","emoji":"🌪"},{"name":"fog","emoji":"🌫"},{"name":"open_umbrella","emoji":"☂"},{"name":"umbrella","emoji":"☔"},{"name":"droplet","emoji":"💧"},{"name":"sweat_drops","emoji":"💦"},{"name":"ocean","emoji":"🌊"},{"name":"green_apple","emoji":"🍏"},{"name":"apple","emoji":"🍎"},{"name":"pear","emoji":"🍐"},{"name":"tangerine","emoji":"🍊"},{"name":"lemon","emoji":"🍋"},{"name":"banana","emoji":"🍌"},{"name":"watermelon","emoji":"🍉"},{"name":"grapes","emoji":"🍇"},{"name":"strawberry","emoji":"🍓"},{"name":"melon","emoji":"🍈"},{"name":"cherries","emoji":"🍒"},{"name":"peach","emoji":"🍑"},{"name":"pineapple","emoji":"🍍"},{"name":"kiwi_fruit","emoji":"🥝"},{"name":"avocado","emoji":"🥑"},{"name":"tomato","emoji":"🍅"},{"name":"eggplant","emoji":"🍆"},{"name":"cucumber","emoji":"🥒"},{"name":"carrot","emoji":"🥕"},{"name":"hot_pepper","emoji":"🌶"},{"name":"potato","emoji":"🥔"},{"name":"corn","emoji":"🌽"},{"name":"sweet_potato","emoji":"🍠"},{"name":"peanuts","emoji":"🥜"},{"name":"honey_pot","emoji":"🍯"},{"name":"croissant","emoji":"🥐"},{"name":"bread","emoji":"🍞"},{"name":"baguette_bread","emoji":"🥖"},{"name":"cheese","emoji":"🧀"},{"name":"egg","emoji":"🥚"},{"name":"bacon","emoji":"🥓"},{"name":"pancakes","emoji":"🥞"},{"name":"poultry_leg","emoji":"🍗"},{"name":"meat_on_bone","emoji":"🍖"},{"name":"fried_shrimp","emoji":"🍤"},{"name":"fried_egg","emoji":"🍳"},{"name":"hamburger","emoji":"🍔"},{"name":"fries","emoji":"🍟"},{"name":"stuffed_flatbread","emoji":"🥙"},{"name":"hotdog","emoji":"🌭"},{"name":"pizza","emoji":"🍕"},{"name":"spaghetti","emoji":"🍝"},{"name":"taco","emoji":"🌮"},{"name":"burrito","emoji":"🌯"},{"name":"green_salad","emoji":"🥗"},{"name":"shallow_pan_of_food","emoji":"🥘"},{"name":"ramen","emoji":"🍜"},{"name":"stew","emoji":"🍲"},{"name":"fish_cake","emoji":"🍥"},{"name":"sushi","emoji":"🍣"},{"name":"bento","emoji":"🍱"},{"name":"curry","emoji":"🍛"},{"name":"rice_ball","emoji":"🍙"},{"name":"rice","emoji":"🍚"},{"name":"rice_cracker","emoji":"🍘"},{"name":"oden","emoji":"🍢"},{"name":"dango","emoji":"🍡"},{"name":"shaved_ice","emoji":"🍧"},{"name":"ice_cream","emoji":"🍨"},{"name":"icecream","emoji":"🍦"},{"name":"cake","emoji":"🍰"},{"name":"birthday","emoji":"🎂"},{"name":"custard","emoji":"🍮"},{"name":"candy","emoji":"🍬"},{"name":"lollipop","emoji":"🍭"},{"name":"chocolate_bar","emoji":"🍫"},{"name":"popcorn","emoji":"🍿"},{"name":"doughnut","emoji":"🍩"},{"name":"cookie","emoji":"🍪"},{"name":"milk_glass","emoji":"🥛"},{"name":"beer","emoji":"🍺"},{"name":"beers","emoji":"🍻"},{"name":"clinking_glasses","emoji":"🥂"},{"name":"wine_glass","emoji":"🍷"},{"name":"tumbler_glass","emoji":"🥃"},{"name":"cocktail","emoji":"🍸"},{"name":"tropical_drink","emoji":"🍹"},{"name":"champagne","emoji":"🍾"},{"name":"sake","emoji":"🍶"},{"name":"tea","emoji":"🍵"},{"name":"coffee","emoji":"☕"},{"name":"baby_bottle","emoji":"🍼"},{"name":"spoon","emoji":"🥄"},{"name":"fork_and_knife","emoji":"🍴"},{"name":"plate_with_cutlery","emoji":"🍽"},{"name":"soccer","emoji":"⚽"},{"name":"basketball","emoji":"🏀"},{"name":"football","emoji":"🏈"},{"name":"baseball","emoji":"⚾"},{"name":"tennis","emoji":"🎾"},{"name":"volleyball","emoji":"🏐"},{"name":"rugby_football","emoji":"🏉"},{"name":"8ball","emoji":"🎱"},{"name":"golf","emoji":"⛳"},{"name":"golfing_woman","emoji":"🏌️‍♀"},{"name":"golfing_man","emoji":"🏌"},{"name":"ping_pong","emoji":"🏓"},{"name":"badminton","emoji":"🏸"},{"name":"goal_net","emoji":"🥅"},{"name":"ice_hockey","emoji":"🏒"},{"name":"field_hockey","emoji":"🏑"},{"name":"cricket_bat_and_ball","emoji":"🏏"},{"name":"ski","emoji":"🎿"},{"name":"skier","emoji":"⛷"},{"name":"snowboarder","emoji":"🏂"},{"name":"person_fencing","emoji":"🤺"},{"name":"women_wrestling","emoji":"🤼‍♀"},{"name":"men_wrestling","emoji":"🤼‍♂"},{"name":"woman_cartwheeling","emoji":"🤸‍♀️"},{"name":"man_cartwheeling","emoji":"🤸‍♂️"},{"name":"woman_playing_handball","emoji":"🤾‍♀️"},{"name":"man_playing_handball","emoji":"🤾‍♂️"},{"name":"ice_skate","emoji":"⛸"},{"name":"bow_and_arrow","emoji":"🏹"},{"name":"fishing_pole_and_fish","emoji":"🎣"},{"name":"boxing_glove","emoji":"🥊"},{"name":"martial_arts_uniform","emoji":"🥋"},{"name":"rowing_woman","emoji":"🚣‍♀️"},{"name":"rowing_man","emoji":"🚣"},{"name":"swimming_woman","emoji":"🏊‍♀️"},{"name":"swimming_man","emoji":"🏊"},{"name":"woman_playing_water_polo","emoji":"🤽‍♀️"},{"name":"man_playing_water_polo","emoji":"🤽‍♂️"},{"name":"surfing_woman","emoji":"🏄‍♀️"},{"name":"surfing_man","emoji":"🏄"},{"name":"bath","emoji":"🛀"},{"name":"basketball_woman","emoji":"⛹️‍♀"},{"name":"basketball_man","emoji":"⛹"},{"name":"weight_lifting_woman","emoji":"🏋️‍♀"},{"name":"weight_lifting_man","emoji":"🏋"},{"name":"biking_woman","emoji":"🚴‍♀️"},{"name":"biking_man","emoji":"🚴"},{"name":"mountain_biking_woman","emoji":"🚵‍♀️"},{"name":"mountain_biking_man","emoji":"🚵"},{"name":"horse_racing","emoji":"🏇"},{"name":"business_suit_levitating","emoji":"🕴"},{"name":"trophy","emoji":"🏆"},{"name":"running_shirt_with_sash","emoji":"🎽"},{"name":"medal_sports","emoji":"🏅"},{"name":"medal_military","emoji":"🎖"},{"name":"1st_place_medal","emoji":"🥇"},{"name":"2nd_place_medal","emoji":"🥈"},{"name":"3rd_place_medal","emoji":"🥉"},{"name":"reminder_ribbon","emoji":"🎗"},{"name":"rosette","emoji":"🏵"},{"name":"ticket","emoji":"🎫"},{"name":"tickets","emoji":"🎟"},{"name":"performing_arts","emoji":"🎭"},{"name":"art","emoji":"🎨"},{"name":"circus_tent","emoji":"🎪"},{"name":"woman_juggling","emoji":"🤹‍♀️"},{"name":"man_juggling","emoji":"🤹‍♂️"},{"name":"microphone","emoji":"🎤"},{"name":"headphones","emoji":"🎧"},{"name":"musical_score","emoji":"🎼"},{"name":"musical_keyboard","emoji":"🎹"},{"name":"drum","emoji":"🥁"},{"name":"saxophone","emoji":"🎷"},{"name":"trumpet","emoji":"🎺"},{"name":"guitar","emoji":"🎸"},{"name":"violin","emoji":"🎻"},{"name":"clapper","emoji":"🎬"},{"name":"video_game","emoji":"🎮"},{"name":"space_invader","emoji":"👾"},{"name":"dart","emoji":"🎯"},{"name":"game_die","emoji":"🎲"},{"name":"slot_machine","emoji":"🎰"},{"name":"bowling","emoji":"🎳"},{"name":"red_car","emoji":"🚗"},{"name":"taxi","emoji":"🚕"},{"name":"blue_car","emoji":"🚙"},{"name":"bus","emoji":"🚌"},{"name":"trolleybus","emoji":"🚎"},{"name":"racing_car","emoji":"🏎"},{"name":"police_car","emoji":"🚓"},{"name":"ambulance","emoji":"🚑"},{"name":"fire_engine","emoji":"🚒"},{"name":"minibus","emoji":"🚐"},{"name":"truck","emoji":"🚚"},{"name":"articulated_lorry","emoji":"🚛"},{"name":"tractor","emoji":"🚜"},{"name":"kick_scooter","emoji":"🛴"},{"name":"motorcycle","emoji":"🏍"},{"name":"bike","emoji":"🚲"},{"name":"motor_scooter","emoji":"🛵"},{"name":"rotating_light","emoji":"🚨"},{"name":"oncoming_police_car","emoji":"🚔"},{"name":"oncoming_bus","emoji":"🚍"},{"name":"oncoming_automobile","emoji":"🚘"},{"name":"oncoming_taxi","emoji":"🚖"},{"name":"aerial_tramway","emoji":"🚡"},{"name":"mountain_cableway","emoji":"🚠"},{"name":"suspension_railway","emoji":"🚟"},{"name":"railway_car","emoji":"🚃"},{"name":"train","emoji":"🚋"},{"name":"monorail","emoji":"🚝"},{"name":"bullettrain_side","emoji":"🚄"},{"name":"bullettrain_front","emoji":"🚅"},{"name":"light_rail","emoji":"🚈"},{"name":"mountain_railway","emoji":"🚞"},{"name":"steam_locomotive","emoji":"🚂"},{"name":"train2","emoji":"🚆"},{"name":"metro","emoji":"🚇"},{"name":"tram","emoji":"🚊"},{"name":"station","emoji":"🚉"},{"name":"helicopter","emoji":"🚁"},{"name":"small_airplane","emoji":"🛩"},{"name":"airplane","emoji":"✈"},{"name":"flight_departure","emoji":"🛫"},{"name":"flight_arrival","emoji":"🛬"},{"name":"sailboat","emoji":"⛵"},{"name":"motor_boat","emoji":"🛥"},{"name":"speedboat","emoji":"🚤"},{"name":"ferry","emoji":"⛴"},{"name":"passenger_ship","emoji":"🛳"},{"name":"rocket","emoji":"🚀"},{"name":"artificial_satellite","emoji":"🛰"},{"name":"seat","emoji":"💺"},{"name":"canoe","emoji":"🛶"},{"name":"anchor","emoji":"⚓"},{"name":"construction","emoji":"🚧"},{"name":"fuelpump","emoji":"⛽"},{"name":"busstop","emoji":"🚏"},{"name":"vertical_traffic_light","emoji":"🚦"},{"name":"traffic_light","emoji":"🚥"},{"name":"checkered_flag","emoji":"🏁"},{"name":"ship","emoji":"🚢"},{"name":"ferris_wheel","emoji":"🎡"},{"name":"roller_coaster","emoji":"🎢"},{"name":"carousel_horse","emoji":"🎠"},{"name":"building_construction","emoji":"🏗"},{"name":"foggy","emoji":"🌁"},{"name":"tokyo_tower","emoji":"🗼"},{"name":"factory","emoji":"🏭"},{"name":"fountain","emoji":"⛲"},{"name":"rice_scene","emoji":"🎑"},{"name":"mountain","emoji":"⛰"},{"name":"mountain_snow","emoji":"🏔"},{"name":"mount_fuji","emoji":"🗻"},{"name":"volcano","emoji":"🌋"},{"name":"japan","emoji":"🗾"},{"name":"camping","emoji":"🏕"},{"name":"tent","emoji":"⛺"},{"name":"national_park","emoji":"🏞"},{"name":"motorway","emoji":"🛣"},{"name":"railway_track","emoji":"🛤"},{"name":"sunrise","emoji":"🌅"},{"name":"sunrise_over_mountains","emoji":"🌄"},{"name":"desert","emoji":"🏜"},{"name":"beach_umbrella","emoji":"🏖"},{"name":"desert_island","emoji":"🏝"},{"name":"city_sunrise","emoji":"🌇"},{"name":"city_sunset","emoji":"🌆"},{"name":"cityscape","emoji":"🏙"},{"name":"night_with_stars","emoji":"🌃"},{"name":"bridge_at_night","emoji":"🌉"},{"name":"milky_way","emoji":"🌌"},{"name":"stars","emoji":"🌠"},{"name":"sparkler","emoji":"🎇"},{"name":"fireworks","emoji":"🎆"},{"name":"rainbow","emoji":"🌈"},{"name":"houses","emoji":"🏘"},{"name":"european_castle","emoji":"🏰"},{"name":"japanese_castle","emoji":"🏯"},{"name":"stadium","emoji":"🏟"},{"name":"statue_of_liberty","emoji":"🗽"},{"name":"house","emoji":"🏠"},{"name":"house_with_garden","emoji":"🏡"},{"name":"derelict_house","emoji":"🏚"},{"name":"office","emoji":"🏢"},{"name":"department_store","emoji":"🏬"},{"name":"post_office","emoji":"🏣"},{"name":"european_post_office","emoji":"🏤"},{"name":"hospital","emoji":"🏥"},{"name":"bank","emoji":"🏦"},{"name":"hotel","emoji":"🏨"},{"name":"convenience_store","emoji":"🏪"},{"name":"school","emoji":"🏫"},{"name":"love_hotel","emoji":"🏩"},{"name":"wedding","emoji":"💒"},{"name":"classical_building","emoji":"🏛"},{"name":"church","emoji":"⛪"},{"name":"mosque","emoji":"🕌"},{"name":"synagogue","emoji":"🕍"},{"name":"kaaba","emoji":"🕋"},{"name":"shinto_shrine","emoji":"⛩"},{"name":"watch","emoji":"⌚"},{"name":"iphone","emoji":"📱"},{"name":"calling","emoji":"📲"},{"name":"computer","emoji":"💻"},{"name":"keyboard","emoji":"⌨"},{"name":"desktop_computer","emoji":"🖥"},{"name":"printer","emoji":"🖨"},{"name":"computer_mouse","emoji":"🖱"},{"name":"trackball","emoji":"🖲"},{"name":"joystick","emoji":"🕹"},{"name":"clamp","emoji":"🗜"},{"name":"minidisc","emoji":"💽"},{"name":"floppy_disk","emoji":"💾"},{"name":"cd","emoji":"💿"},{"name":"dvd","emoji":"📀"},{"name":"vhs","emoji":"📼"},{"name":"camera","emoji":"📷"},{"name":"camera_flash","emoji":"📸"},{"name":"video_camera","emoji":"📹"},{"name":"movie_camera","emoji":"🎥"},{"name":"film_projector","emoji":"📽"},{"name":"film_strip","emoji":"🎞"},{"name":"telephone_receiver","emoji":"📞"},{"name":"phone","emoji":"☎"},{"name":"pager","emoji":"📟"},{"name":"fax","emoji":"📠"},{"name":"tv","emoji":"📺"},{"name":"radio","emoji":"📻"},{"name":"studio_microphone","emoji":"🎙"},{"name":"level_slider","emoji":"🎚"},{"name":"control_knobs","emoji":"🎛"},{"name":"stopwatch","emoji":"⏱"},{"name":"timer_clock","emoji":"⏲"},{"name":"alarm_clock","emoji":"⏰"},{"name":"mantelpiece_clock","emoji":"🕰"},{"name":"hourglass_flowing_sand","emoji":"⏳"},{"name":"hourglass","emoji":"⌛"},{"name":"satellite","emoji":"📡"},{"name":"battery","emoji":"🔋"},{"name":"electric_plug","emoji":"🔌"},{"name":"bulb","emoji":"💡"},{"name":"flashlight","emoji":"🔦"},{"name":"candle","emoji":"🕯"},{"name":"wastebasket","emoji":"🗑"},{"name":"oil_drum","emoji":"🛢"},{"name":"money_with_wings","emoji":"💸"},{"name":"dollar","emoji":"💵"},{"name":"yen","emoji":"💴"},{"name":"euro","emoji":"💶"},{"name":"pound","emoji":"💷"},{"name":"moneybag","emoji":"💰"},{"name":"credit_card","emoji":"💳"},{"name":"gem","emoji":"💎"},{"name":"balance_scale","emoji":"⚖"},{"name":"wrench","emoji":"🔧"},{"name":"hammer","emoji":"🔨"},{"name":"hammer_and_pick","emoji":"⚒"},{"name":"hammer_and_wrench","emoji":"🛠"},{"name":"pick","emoji":"⛏"},{"name":"nut_and_bolt","emoji":"🔩"},{"name":"gear","emoji":"⚙"},{"name":"chains","emoji":"⛓"},{"name":"gun","emoji":"🔫"},{"name":"bomb","emoji":"💣"},{"name":"hocho","emoji":"🔪"},{"name":"dagger","emoji":"🗡"},{"name":"crossed_swords","emoji":"⚔"},{"name":"shield","emoji":"🛡"},{"name":"smoking","emoji":"🚬"},{"name":"skull_and_crossbones","emoji":"☠"},{"name":"coffin","emoji":"⚰"},{"name":"funeral_urn","emoji":"⚱"},{"name":"amphora","emoji":"🏺"},{"name":"crystal_ball","emoji":"🔮"},{"name":"prayer_beads","emoji":"📿"},{"name":"barber","emoji":"💈"},{"name":"alembic","emoji":"⚗"},{"name":"telescope","emoji":"🔭"},{"name":"microscope","emoji":"🔬"},{"name":"hole","emoji":"🕳"},{"name":"pill","emoji":"💊"},{"name":"syringe","emoji":"💉"},{"name":"thermometer","emoji":"🌡"},{"name":"label","emoji":"🏷"},{"name":"bookmark","emoji":"🔖"},{"name":"toilet","emoji":"🚽"},{"name":"shower","emoji":"🚿"},{"name":"bathtub","emoji":"🛁"},{"name":"key","emoji":"🔑"},{"name":"old_key","emoji":"🗝"},{"name":"couch_and_lamp","emoji":"🛋"},{"name":"sleeping_bed","emoji":"🛌"},{"name":"bed","emoji":"🛏"},{"name":"door","emoji":"🚪"},{"name":"bellhop_bell","emoji":"🛎"},{"name":"framed_picture","emoji":"🖼"},{"name":"world_map","emoji":"🗺"},{"name":"parasol_on_ground","emoji":"⛱"},{"name":"moyai","emoji":"🗿"},{"name":"shopping","emoji":"🛍"},{"name":"shopping_cart","emoji":"🛒"},{"name":"balloon","emoji":"🎈"},{"name":"flags","emoji":"🎏"},{"name":"ribbon","emoji":"🎀"},{"name":"gift","emoji":"🎁"},{"name":"confetti_ball","emoji":"🎊"},{"name":"tada","emoji":"🎉"},{"name":"dolls","emoji":"🎎"},{"name":"wind_chime","emoji":"🎐"},{"name":"crossed_flags","emoji":"🎌"},{"name":"izakaya_lantern","emoji":"🏮"},{"name":"email","emoji":"✉"},{"name":"envelope_with_arrow","emoji":"📩"},{"name":"incoming_envelope","emoji":"📨"},{"name":"e-mail","emoji":"📧"},{"name":"love_letter","emoji":"💌"},{"name":"postbox","emoji":"📮"},{"name":"mailbox_closed","emoji":"📪"},{"name":"mailbox","emoji":"📫"},{"name":"mailbox_with_mail","emoji":"📬"},{"name":"mailbox_with_no_mail","emoji":"📭"},{"name":"package","emoji":"📦"},{"name":"postal_horn","emoji":"📯"},{"name":"inbox_tray","emoji":"📥"},{"name":"outbox_tray","emoji":"📤"},{"name":"scroll","emoji":"📜"},{"name":"page_with_curl","emoji":"📃"},{"name":"bookmark_tabs","emoji":"📑"},{"name":"bar_chart","emoji":"📊"},{"name":"chart_with_upwards_trend","emoji":"📈"},{"name":"chart_with_downwards_trend","emoji":"📉"},{"name":"page_facing_up","emoji":"📄"},{"name":"date","emoji":"📅"},{"name":"calendar","emoji":"📆"},{"name":"spiral_calendar","emoji":"🗓"},{"name":"card_index","emoji":"📇"},{"name":"card_file_box","emoji":"🗃"},{"name":"ballot_box","emoji":"🗳"},{"name":"file_cabinet","emoji":"🗄"},{"name":"clipboard","emoji":"📋"},{"name":"spiral_notepad","emoji":"🗒"},{"name":"file_folder","emoji":"📁"},{"name":"open_file_folder","emoji":"📂"},{"name":"card_index_dividers","emoji":"🗂"},{"name":"newspaper_roll","emoji":"🗞"},{"name":"newspaper","emoji":"📰"},{"name":"notebook","emoji":"📓"},{"name":"closed_book","emoji":"📕"},{"name":"green_book","emoji":"📗"},{"name":"blue_book","emoji":"📘"},{"name":"orange_book","emoji":"📙"},{"name":"notebook_with_decorative_cover","emoji":"📔"},{"name":"ledger","emoji":"📒"},{"name":"books","emoji":"📚"},{"name":"open_book","emoji":"📖"},{"name":"link","emoji":"🔗"},{"name":"paperclip","emoji":"📎"},{"name":"paperclips","emoji":"🖇"},{"name":"scissors","emoji":"✂"},{"name":"triangular_ruler","emoji":"📐"},{"name":"straight_ruler","emoji":"📏"},{"name":"pushpin","emoji":"📌"},{"name":"round_pushpin","emoji":"📍"},{"name":"triangular_flag_on_post","emoji":"🚩"},{"name":"white_flag","emoji":"🏳"},{"name":"black_flag","emoji":"🏴"},{"name":"rainbow_flag","emoji":"🏳️‍🌈"},{"name":"closed_lock_with_key","emoji":"🔐"},{"name":"lock","emoji":"🔒"},{"name":"unlock","emoji":"🔓"},{"name":"lock_with_ink_pen","emoji":"🔏"},{"name":"pen","emoji":"🖊"},{"name":"fountain_pen","emoji":"🖋"},{"name":"black_nib","emoji":"✒"},{"name":"memo","emoji":"📝"},{"name":"pencil2","emoji":"✏"},{"name":"crayon","emoji":"🖍"},{"name":"paintbrush","emoji":"🖌"},{"name":"mag","emoji":"🔍"},{"name":"mag_right","emoji":"🔎"},{"name":"heart","emoji":"❤"},{"name":"yellow_heart","emoji":"💛"},{"name":"green_heart","emoji":"💚"},{"name":"blue_heart","emoji":"💙"},{"name":"purple_heart","emoji":"💜"},{"name":"black_heart","emoji":"🖤"},{"name":"broken_heart","emoji":"💔"},{"name":"heavy_heart_exclamation","emoji":"❣"},{"name":"two_hearts","emoji":"💕"},{"name":"revolving_hearts","emoji":"💞"},{"name":"heartbeat","emoji":"💓"},{"name":"heartpulse","emoji":"💗"},{"name":"sparkling_heart","emoji":"💖"},{"name":"cupid","emoji":"💘"},{"name":"gift_heart","emoji":"💝"},{"name":"heart_decoration","emoji":"💟"},{"name":"peace_symbol","emoji":"☮"},{"name":"latin_cross","emoji":"✝"},{"name":"star_and_crescent","emoji":"☪"},{"name":"om","emoji":"🕉"},{"name":"wheel_of_dharma","emoji":"☸"},{"name":"star_of_david","emoji":"✡"},{"name":"six_pointed_star","emoji":"🔯"},{"name":"menorah","emoji":"🕎"},{"name":"yin_yang","emoji":"☯"},{"name":"orthodox_cross","emoji":"☦"},{"name":"place_of_worship","emoji":"🛐"},{"name":"ophiuchus","emoji":"⛎"},{"name":"aries","emoji":"♈"},{"name":"taurus","emoji":"♉"},{"name":"gemini","emoji":"♊"},{"name":"cancer","emoji":"♋"},{"name":"leo","emoji":"♌"},{"name":"virgo","emoji":"♍"},{"name":"libra","emoji":"♎"},{"name":"scorpius","emoji":"♏"},{"name":"sagittarius","emoji":"♐"},{"name":"capricorn","emoji":"♑"},{"name":"aquarius","emoji":"♒"},{"name":"pisces","emoji":"♓"},{"name":"id","emoji":"🆔"},{"name":"atom_symbol","emoji":"⚛"},{"name":"u7a7a","emoji":"🈳"},{"name":"u5272","emoji":"🈹"},{"name":"radioactive","emoji":"☢"},{"name":"biohazard","emoji":"☣"},{"name":"mobile_phone_off","emoji":"📴"},{"name":"vibration_mode","emoji":"📳"},{"name":"u6709","emoji":"🈶"},{"name":"u7121","emoji":"🈚"},{"name":"u7533","emoji":"🈸"},{"name":"u55b6","emoji":"🈺"},{"name":"u6708","emoji":"🈷"},{"name":"eight_pointed_black_star","emoji":"✴"},{"name":"vs","emoji":"🆚"},{"name":"accept","emoji":"🉑"},{"name":"white_flower","emoji":"💮"},{"name":"ideograph_advantage","emoji":"🉐"},{"name":"secret","emoji":"㊙"},{"name":"congratulations","emoji":"㊗"},{"name":"u5408","emoji":"🈴"},{"name":"u6e80","emoji":"🈵"},{"name":"u7981","emoji":"🈲"},{"name":"a","emoji":"🅰"},{"name":"b","emoji":"🅱"},{"name":"ab","emoji":"🆎"},{"name":"cl","emoji":"🆑"},{"name":"o2","emoji":"🅾"},{"name":"sos","emoji":"🆘"},{"name":"no_entry","emoji":"⛔"},{"name":"name_badge","emoji":"📛"},{"name":"no_entry_sign","emoji":"🚫"},{"name":"x","emoji":"❌"},{"name":"o","emoji":"⭕"},{"name":"stop_sign","emoji":"🛑"},{"name":"anger","emoji":"💢"},{"name":"hotsprings","emoji":"♨"},{"name":"no_pedestrians","emoji":"🚷"},{"name":"do_not_litter","emoji":"🚯"},{"name":"no_bicycles","emoji":"🚳"},{"name":"non-potable_water","emoji":"🚱"},{"name":"underage","emoji":"🔞"},{"name":"no_mobile_phones","emoji":"📵"},{"name":"exclamation","emoji":"❗"},{"name":"grey_exclamation","emoji":"❕"},{"name":"question","emoji":"❓"},{"name":"grey_question","emoji":"❔"},{"name":"bangbang","emoji":"‼"},{"name":"interrobang","emoji":"⁉"},{"name":"100","emoji":"💯"},{"name":"low_brightness","emoji":"🔅"},{"name":"high_brightness","emoji":"🔆"},{"name":"trident","emoji":"🔱"},{"name":"fleur_de_lis","emoji":"⚜"},{"name":"part_alternation_mark","emoji":"〽"},{"name":"warning","emoji":"⚠"},{"name":"children_crossing","emoji":"🚸"},{"name":"beginner","emoji":"🔰"},{"name":"recycle","emoji":"♻"},{"name":"u6307","emoji":"🈯"},{"name":"chart","emoji":"💹"},{"name":"sparkle","emoji":"❇"},{"name":"eight_spoked_asterisk","emoji":"✳"},{"name":"negative_squared_cross_mark","emoji":"❎"},{"name":"white_check_mark","emoji":"✅"},{"name":"diamond_shape_with_a_dot_inside","emoji":"💠"},{"name":"cyclone","emoji":"🌀"},{"name":"loop","emoji":"➿"},{"name":"globe_with_meridians","emoji":"🌐"},{"name":"m","emoji":"Ⓜ"},{"name":"atm","emoji":"🏧"},{"name":"sa","emoji":"🈂"},{"name":"passport_control","emoji":"🛂"},{"name":"customs","emoji":"🛃"},{"name":"baggage_claim","emoji":"🛄"},{"name":"left_luggage","emoji":"🛅"},{"name":"wheelchair","emoji":"♿"},{"name":"no_smoking","emoji":"🚭"},{"name":"wc","emoji":"🚾"},{"name":"parking","emoji":"🅿"},{"name":"potable_water","emoji":"🚰"},{"name":"mens","emoji":"🚹"},{"name":"womens","emoji":"🚺"},{"name":"baby_symbol","emoji":"🚼"},{"name":"restroom","emoji":"🚻"},{"name":"put_litter_in_its_place","emoji":"🚮"},{"name":"cinema","emoji":"🎦"},{"name":"signal_strength","emoji":"📶"},{"name":"koko","emoji":"🈁"},{"name":"ng","emoji":"🆖"},{"name":"ok","emoji":"🆗"},{"name":"up","emoji":"🆙"},{"name":"cool","emoji":"🆒"},{"name":"new","emoji":"🆕"},{"name":"free","emoji":"🆓"},{"name":"zero","emoji":"0️⃣"},{"name":"one","emoji":"1️⃣"},{"name":"two","emoji":"2️⃣"},{"name":"three","emoji":"3️⃣"},{"name":"four","emoji":"4️⃣"},{"name":"five","emoji":"5️⃣"},{"name":"six","emoji":"6️⃣"},{"name":"seven","emoji":"7️⃣"},{"name":"eight","emoji":"8️⃣"},{"name":"nine","emoji":"9️⃣"},{"name":"keycap_ten","emoji":"🔟"},{"name":"asterisk","emoji":"*️⃣"},{"name":"1234","emoji":"🔢"},{"name":"arrow_forward","emoji":"▶"},{"name":"pause_button","emoji":"⏸"},{"name":"next_track_button","emoji":"⏭"},{"name":"stop_button","emoji":"⏹"},{"name":"record_button","emoji":"⏺"},{"name":"play_or_pause_button","emoji":"⏯"},{"name":"previous_track_button","emoji":"⏮"},{"name":"fast_forward","emoji":"⏩"},{"name":"rewind","emoji":"⏪"},{"name":"twisted_rightwards_arrows","emoji":"🔀"},{"name":"repeat","emoji":"🔁"},{"name":"repeat_one","emoji":"🔂"},{"name":"arrow_backward","emoji":"◀"},{"name":"arrow_up_small","emoji":"🔼"},{"name":"arrow_down_small","emoji":"🔽"},{"name":"arrow_double_up","emoji":"⏫"},{"name":"arrow_double_down","emoji":"⏬"},{"name":"arrow_right","emoji":"➡"},{"name":"arrow_left","emoji":"⬅"},{"name":"arrow_up","emoji":"⬆"},{"name":"arrow_down","emoji":"⬇"},{"name":"arrow_upper_right","emoji":"↗"},{"name":"arrow_lower_right","emoji":"↘"},{"name":"arrow_lower_left","emoji":"↙"},{"name":"arrow_upper_left","emoji":"↖"},{"name":"arrow_up_down","emoji":"↕"},{"name":"left_right_arrow","emoji":"↔"},{"name":"arrows_counterclockwise","emoji":"🔄"},{"name":"arrow_right_hook","emoji":"↪"},{"name":"leftwards_arrow_with_hook","emoji":"↩"},{"name":"arrow_heading_up","emoji":"⤴"},{"name":"arrow_heading_down","emoji":"⤵"},{"name":"hash","emoji":"#️⃣"},{"name":"information_source","emoji":"ℹ"},{"name":"abc","emoji":"🔤"},{"name":"abcd","emoji":"🔡"},{"name":"capital_abcd","emoji":"🔠"},{"name":"symbols","emoji":"🔣"},{"name":"musical_note","emoji":"🎵"},{"name":"notes","emoji":"🎶"},{"name":"wavy_dash","emoji":"〰"},{"name":"curly_loop","emoji":"➰"},{"name":"heavy_check_mark","emoji":"✔"},{"name":"arrows_clockwise","emoji":"🔃"},{"name":"heavy_plus_sign","emoji":"➕"},{"name":"heavy_minus_sign","emoji":"➖"},{"name":"heavy_division_sign","emoji":"➗"},{"name":"heavy_multiplication_x","emoji":"✖"},{"name":"heavy_dollar_sign","emoji":"💲"},{"name":"currency_exchange","emoji":"💱"},{"name":"copyright","emoji":"©"},{"name":"registered","emoji":"®"},{"name":"tm","emoji":"™"},{"name":"end","emoji":"🔚"},{"name":"back","emoji":"🔙"},{"name":"on","emoji":"🔛"},{"name":"top","emoji":"🔝"},{"name":"soon","emoji":"🔜"},{"name":"ballot_box_with_check","emoji":"☑"},{"name":"radio_button","emoji":"🔘"},{"name":"white_circle","emoji":"⚪"},{"name":"black_circle","emoji":"⚫"},{"name":"red_circle","emoji":"🔴"},{"name":"large_blue_circle","emoji":"🔵"},{"name":"small_orange_diamond","emoji":"🔸"},{"name":"small_blue_diamond","emoji":"🔹"},{"name":"large_orange_diamond","emoji":"🔶"},{"name":"large_blue_diamond","emoji":"🔷"},{"name":"small_red_triangle","emoji":"🔺"},{"name":"black_small_square","emoji":"▪"},{"name":"white_small_square","emoji":"▫"},{"name":"black_large_square","emoji":"⬛"},{"name":"white_large_square","emoji":"⬜"},{"name":"small_red_triangle_down","emoji":"🔻"},{"name":"black_medium_square","emoji":"◼"},{"name":"white_medium_square","emoji":"◻"},{"name":"black_medium_small_square","emoji":"◾"},{"name":"white_medium_small_square","emoji":"◽"},{"name":"black_square_button","emoji":"🔲"},{"name":"white_square_button","emoji":"🔳"},{"name":"speaker","emoji":"🔈"},{"name":"sound","emoji":"🔉"},{"name":"loud_sound","emoji":"🔊"},{"name":"mute","emoji":"🔇"},{"name":"mega","emoji":"📣"},{"name":"loudspeaker","emoji":"📢"},{"name":"bell","emoji":"🔔"},{"name":"no_bell","emoji":"🔕"},{"name":"black_joker","emoji":"🃏"},{"name":"mahjong","emoji":"🀄"},{"name":"spades","emoji":"♠"},{"name":"clubs","emoji":"♣"},{"name":"hearts","emoji":"♥"},{"name":"diamonds","emoji":"♦"},{"name":"flower_playing_cards","emoji":"🎴"},{"name":"thought_balloon","emoji":"💭"},{"name":"right_anger_bubble","emoji":"🗯"},{"name":"speech_balloon","emoji":"💬"},{"name":"left_speech_bubble","emoji":"🗨"},{"name":"clock1","emoji":"🕐"},{"name":"clock2","emoji":"🕑"},{"name":"clock3","emoji":"🕒"},{"name":"clock4","emoji":"🕓"},{"name":"clock5","emoji":"🕔"},{"name":"clock6","emoji":"🕕"},{"name":"clock7","emoji":"🕖"},{"name":"clock8","emoji":"🕗"},{"name":"clock9","emoji":"🕘"},{"name":"clock10","emoji":"🕙"},{"name":"clock11","emoji":"🕚"},{"name":"clock12","emoji":"🕛"},{"name":"clock130","emoji":"🕜"},{"name":"clock230","emoji":"🕝"},{"name":"clock330","emoji":"🕞"},{"name":"clock430","emoji":"🕟"},{"name":"clock530","emoji":"🕠"},{"name":"clock630","emoji":"🕡"},{"name":"clock730","emoji":"🕢"},{"name":"clock830","emoji":"🕣"},{"name":"clock930","emoji":"🕤"},{"name":"clock1030","emoji":"🕥"},{"name":"clock1130","emoji":"🕦"},{"name":"clock1230","emoji":"🕧"},{"name":"afghanistan","emoji":"🇦🇫"},{"name":"aland_islands","emoji":"🇦🇽"},{"name":"albania","emoji":"🇦🇱"},{"name":"algeria","emoji":"🇩🇿"},{"name":"american_samoa","emoji":"🇦🇸"},{"name":"andorra","emoji":"🇦🇩"},{"name":"angola","emoji":"🇦🇴"},{"name":"anguilla","emoji":"🇦🇮"},{"name":"antarctica","emoji":"🇦🇶"},{"name":"antigua_barbuda","emoji":"🇦🇬"},{"name":"argentina","emoji":"🇦🇷"},{"name":"armenia","emoji":"🇦🇲"},{"name":"aruba","emoji":"🇦🇼"},{"name":"australia","emoji":"🇦🇺"},{"name":"austria","emoji":"🇦🇹"},{"name":"azerbaijan","emoji":"🇦🇿"},{"name":"bahamas","emoji":"🇧🇸"},{"name":"bahrain","emoji":"🇧🇭"},{"name":"bangladesh","emoji":"🇧🇩"},{"name":"barbados","emoji":"🇧🇧"},{"name":"belarus","emoji":"🇧🇾"},{"name":"belgium","emoji":"🇧🇪"},{"name":"belize","emoji":"🇧🇿"},{"name":"benin","emoji":"🇧🇯"},{"name":"bermuda","emoji":"🇧🇲"},{"name":"bhutan","emoji":"🇧🇹"},{"name":"bolivia","emoji":"🇧🇴"},{"name":"caribbean_netherlands","emoji":"🇧🇶"},{"name":"bosnia_herzegovina","emoji":"🇧🇦"},{"name":"botswana","emoji":"🇧🇼"},{"name":"brazil","emoji":"🇧🇷"},{"name":"british_indian_ocean_territory","emoji":"🇮🇴"},{"name":"british_virgin_islands","emoji":"🇻🇬"},{"name":"brunei","emoji":"🇧🇳"},{"name":"bulgaria","emoji":"🇧🇬"},{"name":"burkina_faso","emoji":"🇧🇫"},{"name":"burundi","emoji":"🇧🇮"},{"name":"cape_verde","emoji":"🇨🇻"},{"name":"cambodia","emoji":"🇰🇭"},{"name":"cameroon","emoji":"🇨🇲"},{"name":"canada","emoji":"🇨🇦"},{"name":"canary_islands","emoji":"🇮🇨"},{"name":"cayman_islands","emoji":"🇰🇾"},{"name":"central_african_republic","emoji":"🇨🇫"},{"name":"chad","emoji":"🇹🇩"},{"name":"chile","emoji":"🇨🇱"},{"name":"cn","emoji":"🇨🇳"},{"name":"christmas_island","emoji":"🇨🇽"},{"name":"cocos_islands","emoji":"🇨🇨"},{"name":"colombia","emoji":"🇨🇴"},{"name":"comoros","emoji":"🇰🇲"},{"name":"congo_brazzaville","emoji":"🇨🇬"},{"name":"congo_kinshasa","emoji":"🇨🇩"},{"name":"cook_islands","emoji":"🇨🇰"},{"name":"costa_rica","emoji":"🇨🇷"},{"name":"croatia","emoji":"🇭🇷"},{"name":"cuba","emoji":"🇨🇺"},{"name":"curacao","emoji":"🇨🇼"},{"name":"cyprus","emoji":"🇨🇾"},{"name":"czech_republic","emoji":"🇨🇿"},{"name":"denmark","emoji":"🇩🇰"},{"name":"djibouti","emoji":"🇩🇯"},{"name":"dominica","emoji":"🇩🇲"},{"name":"dominican_republic","emoji":"🇩🇴"},{"name":"ecuador","emoji":"🇪🇨"},{"name":"egypt","emoji":"🇪🇬"},{"name":"el_salvador","emoji":"🇸🇻"},{"name":"equatorial_guinea","emoji":"🇬🇶"},{"name":"eritrea","emoji":"🇪🇷"},{"name":"estonia","emoji":"🇪🇪"},{"name":"ethiopia","emoji":"🇪🇹"},{"name":"eu","emoji":"🇪🇺"},{"name":"falkland_islands","emoji":"🇫🇰"},{"name":"faroe_islands","emoji":"🇫🇴"},{"name":"fiji","emoji":"🇫🇯"},{"name":"finland","emoji":"🇫🇮"},{"name":"fr","emoji":"🇫🇷"},{"name":"french_guiana","emoji":"🇬🇫"},{"name":"french_polynesia","emoji":"🇵🇫"},{"name":"french_southern_territories","emoji":"🇹🇫"},{"name":"gabon","emoji":"🇬🇦"},{"name":"gambia","emoji":"🇬🇲"},{"name":"georgia","emoji":"🇬🇪"},{"name":"de","emoji":"🇩🇪"},{"name":"ghana","emoji":"🇬🇭"},{"name":"gibraltar","emoji":"🇬🇮"},{"name":"greece","emoji":"🇬🇷"},{"name":"greenland","emoji":"🇬🇱"},{"name":"grenada","emoji":"🇬🇩"},{"name":"guadeloupe","emoji":"🇬🇵"},{"name":"guam","emoji":"🇬🇺"},{"name":"guatemala","emoji":"🇬🇹"},{"name":"guernsey","emoji":"🇬🇬"},{"name":"guinea","emoji":"🇬🇳"},{"name":"guinea_bissau","emoji":"🇬🇼"},{"name":"guyana","emoji":"🇬🇾"},{"name":"haiti","emoji":"🇭🇹"},{"name":"honduras","emoji":"🇭🇳"},{"name":"hong_kong","emoji":"🇭🇰"},{"name":"hungary","emoji":"🇭🇺"},{"name":"iceland","emoji":"🇮🇸"},{"name":"india","emoji":"🇮🇳"},{"name":"indonesia","emoji":"🇮🇩"},{"name":"iran","emoji":"🇮🇷"},{"name":"iraq","emoji":"🇮🇶"},{"name":"ireland","emoji":"🇮🇪"},{"name":"isle_of_man","emoji":"🇮🇲"},{"name":"israel","emoji":"🇮🇱"},{"name":"it","emoji":"🇮🇹"},{"name":"cote_divoire","emoji":"🇨🇮"},{"name":"jamaica","emoji":"🇯🇲"},{"name":"jp","emoji":"🇯🇵"},{"name":"jersey","emoji":"🇯🇪"},{"name":"jordan","emoji":"🇯🇴"},{"name":"kazakhstan","emoji":"🇰🇿"},{"name":"kenya","emoji":"🇰🇪"},{"name":"kiribati","emoji":"🇰🇮"},{"name":"kosovo","emoji":"🇽🇰"},{"name":"kuwait","emoji":"🇰🇼"},{"name":"kyrgyzstan","emoji":"🇰🇬"},{"name":"laos","emoji":"🇱🇦"},{"name":"latvia","emoji":"🇱🇻"},{"name":"lebanon","emoji":"🇱🇧"},{"name":"lesotho","emoji":"🇱🇸"},{"name":"liberia","emoji":"🇱🇷"},{"name":"libya","emoji":"🇱🇾"},{"name":"liechtenstein","emoji":"🇱🇮"},{"name":"lithuania","emoji":"🇱🇹"},{"name":"luxembourg","emoji":"🇱🇺"},{"name":"macau","emoji":"🇲🇴"},{"name":"macedonia","emoji":"🇲🇰"},{"name":"madagascar","emoji":"🇲🇬"},{"name":"malawi","emoji":"🇲🇼"},{"name":"malaysia","emoji":"🇲🇾"},{"name":"maldives","emoji":"🇲🇻"},{"name":"mali","emoji":"🇲🇱"},{"name":"malta","emoji":"🇲🇹"},{"name":"marshall_islands","emoji":"🇲🇭"},{"name":"martinique","emoji":"🇲🇶"},{"name":"mauritania","emoji":"🇲🇷"},{"name":"mauritius","emoji":"🇲🇺"},{"name":"mayotte","emoji":"🇾🇹"},{"name":"mexico","emoji":"🇲🇽"},{"name":"micronesia","emoji":"🇫🇲"},{"name":"moldova","emoji":"🇲🇩"},{"name":"monaco","emoji":"🇲🇨"},{"name":"mongolia","emoji":"🇲🇳"},{"name":"montenegro","emoji":"🇲🇪"},{"name":"montserrat","emoji":"🇲🇸"},{"name":"morocco","emoji":"🇲🇦"},{"name":"mozambique","emoji":"🇲🇿"},{"name":"myanmar","emoji":"🇲🇲"},{"name":"namibia","emoji":"🇳🇦"},{"name":"nauru","emoji":"🇳🇷"},{"name":"nepal","emoji":"🇳🇵"},{"name":"netherlands","emoji":"🇳🇱"},{"name":"new_caledonia","emoji":"🇳🇨"},{"name":"new_zealand","emoji":"🇳🇿"},{"name":"nicaragua","emoji":"🇳🇮"},{"name":"niger","emoji":"🇳🇪"},{"name":"nigeria","emoji":"🇳🇬"},{"name":"niue","emoji":"🇳🇺"},{"name":"norfolk_island","emoji":"🇳🇫"},{"name":"northern_mariana_islands","emoji":"🇲🇵"},{"name":"north_korea","emoji":"🇰🇵"},{"name":"norway","emoji":"🇳🇴"},{"name":"oman","emoji":"🇴🇲"},{"name":"pakistan","emoji":"🇵🇰"},{"name":"palau","emoji":"🇵🇼"},{"name":"palestinian_territories","emoji":"🇵🇸"},{"name":"panama","emoji":"🇵🇦"},{"name":"papua_new_guinea","emoji":"🇵🇬"},{"name":"paraguay","emoji":"🇵🇾"},{"name":"peru","emoji":"🇵🇪"},{"name":"philippines","emoji":"🇵🇭"},{"name":"pitcairn_islands","emoji":"🇵🇳"},{"name":"poland","emoji":"🇵🇱"},{"name":"portugal","emoji":"🇵🇹"},{"name":"puerto_rico","emoji":"🇵🇷"},{"name":"qatar","emoji":"🇶🇦"},{"name":"reunion","emoji":"🇷🇪"},{"name":"romania","emoji":"🇷🇴"},{"name":"ru","emoji":"🇷🇺"},{"name":"rwanda","emoji":"🇷🇼"},{"name":"st_barthelemy","emoji":"🇧🇱"},{"name":"st_helena","emoji":"🇸🇭"},{"name":"st_kitts_nevis","emoji":"🇰🇳"},{"name":"st_lucia","emoji":"🇱🇨"},{"name":"st_pierre_miquelon","emoji":"🇵🇲"},{"name":"st_vincent_grenadines","emoji":"🇻🇨"},{"name":"samoa","emoji":"🇼🇸"},{"name":"san_marino","emoji":"🇸🇲"},{"name":"sao_tome_principe","emoji":"🇸🇹"},{"name":"saudi_arabia","emoji":"🇸🇦"},{"name":"senegal","emoji":"🇸🇳"},{"name":"serbia","emoji":"🇷🇸"},{"name":"seychelles","emoji":"🇸🇨"},{"name":"sierra_leone","emoji":"🇸🇱"},{"name":"singapore","emoji":"🇸🇬"},{"name":"sint_maarten","emoji":"🇸🇽"},{"name":"slovakia","emoji":"🇸🇰"},{"name":"slovenia","emoji":"🇸🇮"},{"name":"solomon_islands","emoji":"🇸🇧"},{"name":"somalia","emoji":"🇸🇴"},{"name":"south_africa","emoji":"🇿🇦"},{"name":"south_georgia_south_sandwich_islands","emoji":"🇬🇸"},{"name":"kr","emoji":"🇰🇷"},{"name":"south_sudan","emoji":"🇸🇸"},{"name":"es","emoji":"🇪🇸"},{"name":"sri_lanka","emoji":"🇱🇰"},{"name":"sudan","emoji":"🇸🇩"},{"name":"suriname","emoji":"🇸🇷"},{"name":"swaziland","emoji":"🇸🇿"},{"name":"sweden","emoji":"🇸🇪"},{"name":"switzerland","emoji":"🇨🇭"},{"name":"syria","emoji":"🇸🇾"},{"name":"taiwan","emoji":"🇹🇼"},{"name":"tajikistan","emoji":"🇹🇯"},{"name":"tanzania","emoji":"🇹🇿"},{"name":"thailand","emoji":"🇹🇭"},{"name":"timor_leste","emoji":"🇹🇱"},{"name":"togo","emoji":"🇹🇬"},{"name":"tokelau","emoji":"🇹🇰"},{"name":"tonga","emoji":"🇹🇴"},{"name":"trinidad_tobago","emoji":"🇹🇹"},{"name":"tunisia","emoji":"🇹🇳"},{"name":"tr","emoji":"🇹🇷"},{"name":"turkmenistan","emoji":"🇹🇲"},{"name":"turks_caicos_islands","emoji":"🇹🇨"},{"name":"tuvalu","emoji":"🇹🇻"},{"name":"uganda","emoji":"🇺🇬"},{"name":"ukraine","emoji":"🇺🇦"},{"name":"united_arab_emirates","emoji":"🇦🇪"},{"name":"uk","emoji":"🇬🇧"},{"name":"us","emoji":"🇺🇸"},{"name":"us_virgin_islands","emoji":"🇻🇮"},{"name":"uruguay","emoji":"🇺🇾"},{"name":"uzbekistan","emoji":"🇺🇿"},{"name":"vanuatu","emoji":"🇻🇺"},{"name":"vatican_city","emoji":"🇻🇦"},{"name":"venezuela","emoji":"🇻🇪"},{"name":"vietnam","emoji":"🇻🇳"},{"name":"wallis_futuna","emoji":"🇼🇫"},{"name":"western_sahara","emoji":"🇪🇭"},{"name":"yemen","emoji":"🇾🇪"},{"name":"zambia","emoji":"🇿🇲"},{"name":"zimbabwe","emoji":"🇿🇼"},{"name":"star_struck","emoji":"🤩"},{"name":"face_with_raised_eyebrow","emoji":"🤨"},{"name":"exploding_head","emoji":"🤯"},{"name":"crazy_face","emoji":"🤪"},{"name":"face_with_symbols_over_mouth","emoji":"🤬"},{"name":"face_vomiting","emoji":"🤮"},{"name":"shushing_face","emoji":"🤫"},{"name":"face_with_hand_over_mouth","emoji":"🤭"},{"name":"face_with_monocle","emoji":"🧐"},{"name":"child","emoji":"🧒"},{"name":"adult","emoji":"🧑"},{"name":"older_adult","emoji":"🧓"},{"name":"woman_with_headscarf","emoji":"🧕"},{"name":"bearded_person","emoji":"🧔"},{"name":"breast_feeding","emoji":"🤱"},{"name":"mage","emoji":"🧙"},{"name":"woman_mage","emoji":"🧙‍♀️"},{"name":"fairy","emoji":"🧚"},{"name":"vampire","emoji":"🧛"},{"name":"merperson","emoji":"🧜"},{"name":"merman","emoji":"🧜‍♂️"},{"name":"elf","emoji":"🧝"},{"name":"genie","emoji":"🧞"},{"name":"woman_genie","emoji":"🧞‍♀"},{"name":"zombie","emoji":"🧟"},{"name":"woman_zombie","emoji":"🧟‍♀"},{"name":"person_in_steamy_room","emoji":"🧖"},{"name":"woman_in_steamy_room","emoji":"🧖‍♀️"},{"name":"person_climbing","emoji":"🧗"},{"name":"woman_climbing","emoji":"🧗‍♀️"},{"name":"person_in_lotus_position","emoji":"🧘"},{"name":"woman_in_lotus_position","emoji":"🧘‍♀️"},{"name":"love_you_gesture","emoji":"🤟"},{"name":"palms_up_together","emoji":"🤲"},{"name":"brain","emoji":"🧠"},{"name":"orange_heart","emoji":"🧡"},{"name":"scarf","emoji":"🧣"},{"name":"gloves","emoji":"🧤"},{"name":"coat","emoji":"🧥"},{"name":"socks","emoji":"🧦"},{"name":"billed_cap","emoji":"🧢"},{"name":"zebra","emoji":"🦓"},{"name":"giraffe","emoji":"🦒"},{"name":"hedgehog","emoji":"🦔"},{"name":"sauropod","emoji":"🦕"},{"name":"t_rex","emoji":"🦖"},{"name":"cricket","emoji":"🦗"},{"name":"coconut","emoji":"🥥"},{"name":"broccoli","emoji":"🥦"},{"name":"pretzel","emoji":"🥨"},{"name":"cut_of_meat","emoji":"🥩"},{"name":"sandwich","emoji":"🥪"},{"name":"bowl_with_spoon","emoji":"🥣"},{"name":"canned_food","emoji":"🥫"},{"name":"dumpling","emoji":"🥟"},{"name":"fortune_cookie","emoji":"🥠"},{"name":"takeout_box","emoji":"🥡"},{"name":"pie","emoji":"🥧"},{"name":"cup_with_straw","emoji":"🥤"},{"name":"chopsticks","emoji":"🥢"},{"name":"flying_saucer","emoji":"🛸"},{"name":"sled","emoji":"🛷"},{"name":"curling_stone","emoji":"🥌"},{"name":"svalbard_and_jan_mayen","emoji":"🇸🇯"},{"name":"st_martin","emoji":"🇲🇫"},{"name":"us_outlying_islands","emoji":"🇺🇲"},{"name":"tristan_da_cunha","emoji":"🇹🇦"},{"name":"heard_and_mc_donald_islands","emoji":"🇭🇲"},{"name":"ceuta_and_melilla","emoji":"🇪🇦"},{"name":"diego_garcia","emoji":"🇩🇬"},{"name":"ascension_island","emoji":"🇦🇨"},{"name":"bouvet_island","emoji":"🇧🇻"},{"name":"clipperton_island","emoji":"🇨🇵"},{"name":"united_nations","emoji":"🇺🇳"},{"name":"smiling_face_with_three_hearts","emoji":"🥰"},{"name":"hot_face","emoji":"🥵"},{"name":"cold_face","emoji":"🥶"},{"name":"partying_face","emoji":"🥳"},{"name":"woozy_face","emoji":"🥴"},{"name":"pleading_face","emoji":"🥺"},{"name":"man_red_haired","emoji":"👨‍🦰"},{"name":"man_curly_haired","emoji":"👨‍🦱"},{"name":"man_white_haired","emoji":"👨‍🦳"},{"name":"man_bald","emoji":"👨‍🦲"},{"name":"woman_red_haired","emoji":"👩‍🦰"},{"name":"woman_curly_haired","emoji":"👩‍🦱"},{"name":"woman_white_haired","emoji":"👩‍🦳"},{"name":"woman_bald","emoji":"👩‍🦲"},{"name":"superhero","emoji":"🦸"},{"name":"man_superhero","emoji":"🦸‍♂️"},{"name":"woman_superhero","emoji":"🦸‍♀️"},{"name":"supervillain","emoji":"🦹"},{"name":"woman_supervillain","emoji":"🦹‍♀️"},{"name":"man_supervillain","emoji":"🦹‍♂️"},{"name":"leg","emoji":"🦵"},{"name":"foot","emoji":"🦶"},{"name":"bone","emoji":"🦴"},{"name":"tooth","emoji":"🦷"},{"name":"goggles","emoji":"🥽"},{"name":"lab_coat","emoji":"🥼"},{"name":"hiking_boot","emoji":"🥾"},{"name":"flat_shoe","emoji":"🥿"},{"name":"raccoon","emoji":"🦝"},{"name":"llama","emoji":"🦙"},{"name":"hippopotamus","emoji":"🦛"},{"name":"kangaroo","emoji":"🦘"},{"name":"badger","emoji":"🦡"},{"name":"swan","emoji":"🦢"},{"name":"peacock","emoji":"🦚"},{"name":"parrot","emoji":"🦜"},{"name":"lobster","emoji":"🦞"},{"name":"mosquito","emoji":"🦟"},{"name":"microbe","emoji":"🦠"},{"name":"mango","emoji":"🥭"},{"name":"leafy_green","emoji":"🥬"},{"name":"bagel","emoji":"🥯"},{"name":"salt","emoji":"🧂"},{"name":"moon_cake","emoji":"🥮"},{"name":"cupcake","emoji":"🧁"},{"name":"compass","emoji":"🧭"},{"name":"brick","emoji":"🧱"},{"name":"skateboard","emoji":"🛹"},{"name":"luggage","emoji":"🧳"},{"name":"firecracker","emoji":"🧨"},{"name":"red_gift_envelope","emoji":"🧧"},{"name":"softball","emoji":"🥎"},{"name":"flying_disc","emoji":"🥏"},{"name":"lacrosse","emoji":"🥍"},{"name":"nazar_amulet","emoji":"🧿"},{"name":"jigsaw","emoji":"🧩"},{"name":"teddy_bear","emoji":"🧸"},{"name":"chess_pawn","emoji":"♟"},{"name":"thread","emoji":"🧵"},{"name":"yarn","emoji":"🧶"},{"name":"abacus","emoji":"🧮"},{"name":"receipt","emoji":"🧾"},{"name":"toolbox","emoji":"🧰"},{"name":"magnet","emoji":"🧲"},{"name":"test_tube","emoji":"🧪"},{"name":"petri_dish","emoji":"🧫"},{"name":"dna","emoji":"🧬"},{"name":"lotion_bottle","emoji":"🧴"},{"name":"safety_pin","emoji":"🧷"},{"name":"broom","emoji":"🧹"},{"name":"basket","emoji":"🧺"},{"name":"roll_of_toilet_paper","emoji":"🧻"},{"name":"soap","emoji":"🧼"},{"name":"sponge","emoji":"🧽"},{"name":"fire_extinguisher","emoji":"🧯"},{"name":"infinity","emoji":"♾"},{"name":"pirate_flag","emoji":"🏴‍☠"},{"name":"waffle","emoji":"🧇"},{"name":"otter","emoji":"🦦"},{"name":"sloth","emoji":"🦥"},{"name":"ice_cube","emoji":"🧊"},{"name":"ringer_planet","emoji":"🪐"},{"name":"flamingo","emoji":"🦩"},{"name":"yawning_face","emoji":"🥱"},{"name":"pinching_hand","emoji":"🤏"},{"name":"service_dog","emoji":"🐕‍🦺"},{"name":"orangutan","emoji":"🦧"},{"name":"auto_rickshaw","emoji":"🛺"},{"name":"parachute","emoji":"🪂"},{"name":"yo-yo","emoji":"🪀"},{"name":"kite","emoji":"🪁"},{"name":"brown_square","emoji":"🟫"},{"name":"purple_square","emoji":"🟪"},{"name":"blue_square","emoji":"🟦"},{"name":"green_square","emoji":"🟩"},{"name":"yellow_square","emoji":"🟨"},{"name":"orange_square","emoji":"🟧"},{"name":"red_square","emoji":"🟥"},{"name":"brown_circle","emoji":"🟤"},{"name":"purple_circle","emoji":"🟣"},{"name":"green_circle","emoji":"🟢"},{"name":"yellow_circle","emoji":"🟡"},{"name":"orange_circle","emoji":"🟠"},{"name":"razor","emoji":"🪒"},{"name":"chair","emoji":"🪑"},{"name":"stethoscope","emoji":"🩺"},{"name":"adhesive_bandage","emoji":"🩹"},{"name":"drop_of_blood","emoji":"🩸"},{"name":"probing_cane","emoji":"🦯"},{"name":"axe","emoji":"🪓"},{"name":"diya_lamp","emoji":"🪔"},{"name":"banjo","emoji":"🪕"},{"name":"ballet_shoes","emoji":"🩰"},{"name":"shorts","emoji":"🩳"},{"name":"briefs","emoji":"🩲"},{"name":"one_piece_swimsuit","emoji":"🩱"},{"name":"sari","emoji":"🥻"},{"name":"safety_vest","emoji":"🦺"},{"name":"diving_mask","emoji":"🤿"},{"name":"motorized_wheelchair","emoji":"🦼"},{"name":"manual_wheelchair","emoji":"🦽"},{"name":"hindu_temple","emoji":"🛕"},{"name":"maté","emoji":"🧉"},{"name":"beverage_box","emoji":"🧃"},{"name":"oyster","emoji":"🦪"},{"name":"butter","emoji":"🧈"},{"name":"falafel","emoji":"🧆"},{"name":"onion","emoji":"🧅"},{"name":"garlic","emoji":"🧄"},{"name":"skunk","emoji":"🦨"},{"name":"guide_dog","emoji":"🦮"},{"name":"people_holding_hands","emoji":"🧑‍🤝‍🧑"},{"name":"woman_in_manual_wheelchair","emoji":"👩‍🦽"},{"name":"man_in_manual_wheelchair","emoji":"👨‍🦽"},{"name":"woman_in_motorized_wheelchair","emoji":"👩‍🦼"},{"name":"man_in_motorized_wheelchair","emoji":"👨‍🦼"},{"name":"woman_with_probing_cane","emoji":"👩‍🦯"},{"name":"man_with_probing_cane","emoji":"👨‍🦯"},{"name":"woman_kneeling","emoji":"🧎‍♀️"},{"name":"man_kneeling","emoji":"🧎‍♂️"},{"name":"man_standing","emoji":"🧍‍♂️"},{"name":"woman_standing","emoji":"🧍‍♀️"},{"name":"deaf_woman","emoji":"🧏‍♀️"},{"name":"deaf_man","emoji":"🧏‍♂️"},{"name":"hear_with_hearing_aid","emoji":"🦻"},{"name":"mechanical_leg","emoji":"🦿"},{"name":"mechanical_arm","emoji":"🦾"},{"name":"white_heart","emoji":"🤍"},{"name":"brown_heart","emoji":"🤎"},{"name":"transgender_flag","emoji":"🏳️‍⚧"},{"name":"smiling_face_with_tear","emoji":"🥲"},{"name":"disguised_face","emoji":"🥸"},{"name":"pinched_fingers","emoji":"🤌"},{"name":"anatomical_heart","emoji":"🫀"},{"name":"lungs","emoji":"🫁"},{"name":"ninja","emoji":"🥷"},{"name":"mx_claus","emoji":"🧑‍🎄"},{"name":"people_hugging","emoji":"🫂"},{"name":"black_cat","emoji":"🐈‍⬛"},{"name":"bison","emoji":"🦬"},{"name":"mammoth","emoji":"🦣"},{"name":"beaver","emoji":"🦫"},{"name":"dodo","emoji":"🦤"},{"name":"feather","emoji":"🪶"},{"name":"seal","emoji":"🦭"},{"name":"beetle","emoji":"🪲"},{"name":"cockroach","emoji":"🪳"},{"name":"fly","emoji":"🪰"},{"name":"worm","emoji":"🪱"},{"name":"potted_plant","emoji":"🪴"},{"name":"blueberries","emoji":"🫐"},{"name":"olive","emoji":"🫒"},{"name":"bell_pepper","emoji":"🫑"},{"name":"flatbread","emoji":"🫓"},{"name":"tamale","emoji":"🫔"},{"name":"fondue","emoji":"🫕"},{"name":"teapot","emoji":"🫖"},{"name":"bubble_tea","emoji":"🧋"},{"name":"rock","emoji":"🪨"},{"name":"wood","emoji":"🪵"},{"name":"hut","emoji":"🛖"},{"name":"pickup_truck","emoji":"🛻"},{"name":"roller_skate","emoji":"🛼"},{"name":"magic_wand","emoji":"🪄"},{"name":"piñata","emoji":"🪅"},{"name":"nesting_dolls","emoji":"🪆"},{"name":"sewing_needle","emoji":"🪡"},{"name":"knot","emoji":"🪢"},{"name":"thong_sandal","emoji":"🩴"},{"name":"military_helmet","emoji":"🪖"},{"name":"accordion","emoji":"🪗"},{"name":"long_drum","emoji":"🪘"},{"name":"coin","emoji":"🪙"},{"name":"boomerang","emoji":"🪃"},{"name":"carpentry_saw","emoji":"🪚"},{"name":"screwdriver","emoji":"🪛"},{"name":"hook","emoji":"🪝"},{"name":"ladder","emoji":"🪜"},{"name":"mirror","emoji":"🪞"},{"name":"window","emoji":"🪟"},{"name":"plunger","emoji":"🪠"},{"name":"mouse_trap","emoji":"🪤"},{"name":"bucket","emoji":"🪣"},{"name":"toothbrush","emoji":"🪥"},{"name":"headstone","emoji":"🪦"},{"name":"placard","emoji":"🪧"},{"name":"transgender_symbol","emoji":"⚧"},{"name":"man_feeding_baby","emoji":"👨‍🍼"},{"name":"person_feeding_baby","emoji":"🧑‍🍼"},{"name":"polar_bear","emoji":"🐻‍❄"},{"name":"melting_face","emoji":"🫠"},{"name":"smiling_face","emoji":"☺"},{"name":"face_with_open_eyes_and_hand_over_mouth","emoji":"🫢"},{"name":"face_with_peeking_eye","emoji":"🫣"},{"name":"saluting_face","emoji":"🫡"},{"name":"dotted_line_face","emoji":"🫥"},{"name":"face_in_clouds","emoji":"😶‍🌫"},{"name":"face_exhaling","emoji":"😮‍💨"},{"name":"face_with_spiral_eyes","emoji":"😵‍💫"},{"name":"face_with_diagonal_mouth","emoji":"🫤"},{"name":"frowning_face","emoji":"☹"},{"name":"face_holding_back_tears","emoji":"🥹"},{"name":"heart_on_fire","emoji":"❤️‍🔥"},{"name":"mending_heart","emoji":"❤️‍🩹"},{"name":"eye_in_speech_bubble","emoji":"👁️‍🗨"},{"name":"rightwards_hand","emoji":"🫱"},{"name":"leftwards_hand","emoji":"🫲"},{"name":"palm_down_hand","emoji":"🫳"},{"name":"palm_up_hand","emoji":"🫴"},{"name":"hand_with_index_finger_and_thumb_crossed","emoji":"🫰"},{"name":"index_pointing_at_the_viewer","emoji":"🫵"},{"name":"heart_hands","emoji":"🫶"},{"name":"biting_lip","emoji":"🫦"},{"name":"man_beard","emoji":"🧔‍♂"},{"name":"woman_beard","emoji":"🧔‍♀"},{"name":"person_red_hair","emoji":"🧑‍🦰"},{"name":"person_curly_hair","emoji":"🧑‍🦱"},{"name":"person_white_hair","emoji":"🧑‍🦳"},{"name":"person_bald","emoji":"🧑‍🦲"},{"name":"man_blond_hair","emoji":"👱‍♂️"},{"name":"person_frowning","emoji":"🙍"},{"name":"person_pouting","emoji":"🙎"},{"name":"person_gesturing_no","emoji":"🙅"},{"name":"person_gesturing_ok","emoji":"🙆"},{"name":"person_tipping_hand","emoji":"💁"},{"name":"person_raising_hand","emoji":"🙋"},{"name":"deaf_person","emoji":"🧏"},{"name":"man_bowing","emoji":"🙇‍♂️"},{"name":"person_facepalming","emoji":"🤦"},{"name":"person_shrugging","emoji":"🤷"},{"name":"health_worker","emoji":"🧑‍⚕️"},{"name":"student","emoji":"🧑‍🎓"},{"name":"teacher","emoji":"🧑‍🏫"},{"name":"judge","emoji":"🧑‍⚖️"},{"name":"farmer","emoji":"🧑‍🌾"},{"name":"cook","emoji":"🧑‍🍳"},{"name":"mechanic","emoji":"🧑‍🔧"},{"name":"factory_worker","emoji":"🧑‍🏭"},{"name":"office_worker","emoji":"🧑‍💼"},{"name":"scientist","emoji":"🧑‍🔬"},{"name":"technologist","emoji":"🧑‍💻"},{"name":"singer","emoji":"🧑‍🎤"},{"name":"artist","emoji":"🧑‍🎨"},{"name":"pilot","emoji":"🧑‍✈️"},{"name":"astronaut","emoji":"🧑‍🚀"},{"name":"firefighter","emoji":"🧑‍🚒"},{"name":"man_police_officer","emoji":"👮‍♂️"},{"name":"man_detective","emoji":"🕵️‍♂️"},{"name":"man_guard","emoji":"💂‍♂️"},{"name":"man_construction_worker","emoji":"👷‍♂️"},{"name":"person_with_crown","emoji":"🫅"},{"name":"man_wearing_turban","emoji":"👳‍♂️"},{"name":"man_in_tuxedo","emoji":"🤵‍♂️"},{"name":"woman_in_tuxedo","emoji":"🤵‍♀️"},{"name":"man_with_veil","emoji":"👰‍♂️"},{"name":"woman_with_veil","emoji":"👰‍♀️"},{"name":"pregnant_man","emoji":"🫃"},{"name":"pregnant_person","emoji":"🫄"},{"name":"woman_feeding_baby","emoji":"👩‍🍼"},{"name":"man_mage","emoji":"🧙‍♂️"},{"name":"man_fairy","emoji":"🧚‍♂️"},{"name":"woman_fairy","emoji":"🧚‍♀️"},{"name":"man_vampire","emoji":"🧛‍♂️"},{"name":"woman_vampire","emoji":"🧛‍♀️"},{"name":"mermaid","emoji":"🧜‍♀️"},{"name":"man_elf","emoji":"🧝‍♂️"},{"name":"woman_elf","emoji":"🧝‍♀️"},{"name":"man_genie","emoji":"🧞‍♂"},{"name":"man_zombie","emoji":"🧟‍♂"},{"name":"troll","emoji":"🧌"},{"name":"person_getting_massage","emoji":"💆"},{"name":"person_getting_haircut","emoji":"💇"},{"name":"man_walking","emoji":"🚶‍♂️"},{"name":"person_standing","emoji":"🧍"},{"name":"person_kneeling","emoji":"🧎"},{"name":"person_with_white_cane","emoji":"🧑‍🦯"},{"name":"person_in_motorized_wheelchair","emoji":"🧑‍🦼"},{"name":"person_in_manual_wheelchair","emoji":"🧑‍🦽"},{"name":"man_running","emoji":"🏃‍♂️"},{"name":"women_with_bunny_ears","emoji":"👯‍♀"},{"name":"man_in_steamy_room","emoji":"🧖‍♂️"},{"name":"man_climbing","emoji":"🧗‍♂️"},{"name":"man_golfing","emoji":"🏌️‍♂️"},{"name":"man_surfing","emoji":"🏄‍♂️"},{"name":"man_rowing_boat","emoji":"🚣‍♂️"},{"name":"man_swimming","emoji":"🏊‍♂️"},{"name":"man_bouncing_ball","emoji":"⛹️‍♂️"},{"name":"man_lifting_weights","emoji":"🏋️‍♂️"},{"name":"man_biking","emoji":"🚴‍♂️"},{"name":"man_mountain_biking","emoji":"🚵‍♂️"},{"name":"person_cartwheeling","emoji":"🤸"},{"name":"people_wrestling","emoji":"🤼"},{"name":"person_playing_water_polo","emoji":"🤽"},{"name":"person_playing_handball","emoji":"🤾"},{"name":"person_juggling","emoji":"🤹"},{"name":"man_in_lotus_position","emoji":"🧘‍♂️"},{"name":"kiss_woman_man","emoji":"👩‍❤️‍💋‍👨"},{"name":"couple_with_heart_woman_man","emoji":"👩‍❤️‍👨"},{"name":"family_man_woman_boy","emoji":"👨‍👩‍👦"},{"name":"red_hair","emoji":"🦰"},{"name":"curly_hair","emoji":"🦱"},{"name":"white_hair","emoji":"🦳"},{"name":"bald","emoji":"🦲"},{"name":"coral","emoji":"🪸"},{"name":"lotus","emoji":"🪷"},{"name":"empty_nest","emoji":"🪹"},{"name":"nest_with_eggs","emoji":"🪺"},{"name":"beans","emoji":"🫘"},{"name":"pouring_liquid","emoji":"🫗"},{"name":"jar","emoji":"🫙"},{"name":"playground_slide","emoji":"🛝"},{"name":"wheel","emoji":"🛞"},{"name":"ring_buoy","emoji":"🛟"},{"name":"hamsa","emoji":"🪬"},{"name":"mirror_ball","emoji":"🪩"},{"name":"low_battery","emoji":"🪫"},{"name":"crutch","emoji":"🩼"},{"name":"xray","emoji":"🩻"},{"name":"elevator","emoji":"🛗"},{"name":"bubbles","emoji":"🫧"},{"name":"identification_card","emoji":"🪪"},{"name":"eject_button","emoji":"⏏"},{"name":"female_sign","emoji":"♀"},{"name":"male_sign","emoji":"♂"},{"name":"heavy_equals_sign","emoji":"🟰"},{"name":"medical_symbol","emoji":"⚕"},{"name":"england","emoji":"🏴󠁧󠁢󠁥󠁮󠁧󠁿"},{"name":"scotland","emoji":"🏴󠁧󠁢󠁳󠁣󠁴󠁿"},{"name":"wales","emoji":"🏴󠁧󠁢󠁷󠁬󠁳󠁿"}]'), Mr = Pr, Br = Ct({
  name: "emoji",
  char: ":",
  pluginKey: new De("emojiSuggestion"),
  items: ({ query: e }) => Mr.filter(
    (t) => t.name.toLowerCase().includes(e.toLowerCase())
  ).sort((t, n) => {
    const a = t.name.toLowerCase(), o = n.name.toLowerCase(), i = e.toLowerCase();
    return a === i && o !== i ? -1 : o === i && a !== i ? 1 : a.startsWith(i) && !o.startsWith(i) ? -1 : o.startsWith(i) && !a.startsWith(i) ? 1 : a.length - o.length;
  }).slice(0, 5),
  command: ({ editor: e, range: t, props: n }) => {
    n && n.emoji ? e.chain().focus().deleteRange(t).insertContent(n.emoji).run() : console.error(
      "Emoji command execution error: emoji property not found on selected item or item is invalid.",
      n
    );
  },
  component: Ar
}), Dr = (e) => {
  const t = Ke(0), n = Ja();
  let a = () => {
  };
  Le(
    () => lt(e.runtime),
    (r) => {
      a(), a = (r == null ? void 0 : r.subscribe(() => {
        t.value++;
      })) ?? (() => {
      }), t.value++;
    },
    { immediate: !0, flush: "sync" }
  ), qn(() => a());
  const o = B(() => {
    var r;
    return t.value, (r = lt(e.runtime)) == null ? void 0 : r.getSnapshot().bindings.find((m) => m.id === e.bindingId);
  }), i = B(() => {
    const r = lt(e.runtime), m = o.value;
    return !r || !(m != null && m.bindingEnabled) ? { label: "", ariaLabel: "" } : n.formatMany(m.configuredShortcut, {
      platform: r.platform
    });
  });
  return {
    view: o,
    text: B(() => i.value.label),
    aria: B(() => i.value.ariaLabel)
  };
}, Rr = ["onClick", "onMouseover"], Or = /* @__PURE__ */ Ce({
  __name: "SlashCommandsList",
  props: {
    items: {
      type: Array,
      required: !0
    },
    editor: {
      type: Object,
      required: !0
    },
    range: {
      type: Object,
      required: !0
    },
    command: {
      type: Function,
      required: !0
    },
    query: String,
    loading: {
      type: Boolean,
      default: !1
    }
  },
  setup(e, { expose: t }) {
    const n = e, a = Ee("text-editor-suggestion"), o = vi(!0), { text: i } = Ve(), r = {
      recent: "Recently used",
      ai: "AI",
      basic: "Basic blocks",
      media: "Media",
      advanced: "Advanced"
    }, m = (x) => {
      var b, j;
      const M = (b = n.items[x]) == null ? void 0 : b.group;
      return !M || M === ((j = n.items[x - 1]) == null ? void 0 : j.group) ? null : i(`slash-group:${M}`, r[M] ?? M);
    }, l = Dr({
      runtime: () => {
        var x;
        return (x = hr(n.editor)) == null ? void 0 : x.runtime;
      },
      bindingId: "textEditor.askAI.open"
    }), c = (x) => x.shortcutBindingId === "textEditor.askAI.open" ? l.text.value : x.shortcut ?? "", d = A(0), g = A(null), f = A([]);
    $n(() => {
      f.value = [];
    });
    const p = (x) => {
      x && n.command(x);
    }, h = () => {
      Me(() => {
        const x = f.value[d.value];
        x && x.scrollIntoView({ block: "nearest" });
      });
    }, v = (x) => {
      const M = n.items[x];
      M && p(M);
    }, L = ({ event: x }) => n.items.length ? x.key === "ArrowUp" ? (d.value = (d.value + n.items.length - 1) % n.items.length, h(), !0) : x.key === "ArrowDown" ? (d.value = (d.value + 1) % n.items.length, h(), !0) : x.key === "Enter" ? (v(d.value), !0) : !1 : !1;
    return Le(
      () => n.items,
      () => {
        d.value = 0;
      }
    ), t({
      onKeyDown: L
    }), (x, M) => n.items.length || n.loading ? (E(), S("div", {
      key: 0,
      ref_key: "container",
      ref: g,
      class: u([s(a).b(), s(a).m("rich")]),
      style: Pe({ zIndex: s(o) })
    }, [
      n.loading ? (E(), S("div", {
        key: 0,
        class: u(s(a).e("loading")),
        "aria-live": "polite"
      }, " Loading... ", 2)) : K("", !0),
      (E(!0), S(ye, null, Be(n.items, (b, j) => (E(), S(ye, { key: j }, [
        m(j) ? (E(), S("div", {
          key: 0,
          class: u(s(a).e("group-title"))
        }, W(m(j)), 3)) : K("", !0),
        _("button", {
          ref_for: !0,
          ref: (w) => {
            w && (f.value[j] = w);
          },
          class: u([s(a).e("item"), s(a).is("selected", j === d.value)]),
          onClick: (w) => v(j),
          onMouseover: (w) => d.value = j
        }, [
          _("span", {
            class: u(s(a).e("item-icon-shell"))
          }, [
            b.icon ? (E(), ke(s(te), {
              key: 0,
              icon: b.icon,
              class: u(s(a).e("item-icon"))
            }, null, 8, ["icon", "class"])) : K("", !0)
          ], 2),
          _("span", {
            class: u(s(a).e("item-body"))
          }, [
            _("span", {
              class: u(s(a).e("item-title"))
            }, W(s(i)(b.id && `slash:${b.id}`, b.title)), 3),
            b.description ? (E(), S("span", {
              key: 0,
              class: u(s(a).e("item-description"))
            }, W(s(i)(b.id && `slash:${b.id}:description`, b.description)), 3)) : K("", !0)
          ], 2),
          c(b) ? (E(), S("kbd", {
            key: 0,
            class: u(s(a).e("shortcut"))
          }, W(c(b)), 3)) : K("", !0)
        ], 42, Rr)
      ], 64))), 128))
    ], 6)) : K("", !0);
  }
}), Nr = (e) => e.trim().toLowerCase(), $r = (e, t) => {
  const n = Nr(t);
  return n ? [
    e.title,
    e.description,
    ...e.aliases ?? [],
    ...e.keywords ?? []
  ].filter((o) => typeof o == "string").map((o) => o.toLowerCase()).some(
    (o) => o.startsWith(n) || o.includes(n) || n.includes(o)
  ) : !0;
}, zr = (e, t, n) => e.filter(
  (a) => (!n || (a.requiredCapabilities ?? []).every(
    (o) => n.has(o)
  )) && $r(a, t)
), Fr = (e) => ({
  id: e.id,
  title: e.title,
  description: e.description,
  icon: e.icon,
  aliases: e.aliases ? [...e.aliases] : void 0,
  keywords: e.keywords ? [...e.keywords] : void 0,
  shortcut: e.shortcut,
  shortcutBindingId: e.shortcutBindingId,
  group: e.group,
  priority: e.priority,
  requiredCapabilities: e.requiredCapabilities,
  command: e.command
}), Hr = (e, t = []) => {
  const n = /* @__PURE__ */ new Map();
  e.forEach((a, o) => {
    const i = `builtin:${a.title}:${o}`;
    n.set(i, { ...a, priority: o });
  });
  for (const a of t)
    n.set(
      `contribution:${a.id}`,
      Fr(a)
    );
  return [...n.values()].sort(
    (a, o) => (a.priority ?? 0) - (o.priority ?? 0)
  );
}, so = "zx-text-editor:slash-recents", ro = 5, Vr = "recent", lo = (e) => e.id ?? e.title, mo = () => {
  var e;
  try {
    const t = (e = globalThis.localStorage) == null ? void 0 : e.getItem(so);
    if (!t) return [];
    const n = JSON.parse(t);
    return Array.isArray(n) ? n.filter((a) => typeof a == "string").slice(0, ro) : [];
  } catch {
    return [];
  }
}, qr = (e) => {
  var t;
  try {
    const n = lo(e), a = [n, ...mo().filter((o) => o !== n)];
    (t = globalThis.localStorage) == null || t.setItem(
      so,
      JSON.stringify(a.slice(0, ro))
    );
  } catch {
  }
}, Wr = (e, t) => {
  if (t.trim()) return [...e];
  const n = mo();
  if (n.length === 0) return [...e];
  const a = new Map(e.map((r) => [lo(r), r])), o = n.map((r) => a.get(r)).filter((r) => r !== void 0);
  if (o.length === 0) return [...e];
  const i = new Set(o);
  return [
    ...o.map((r) => ({ ...r, group: Vr })),
    ...e.filter((r) => !i.has(r))
  ];
}, Ur = new De(
  "slashCommandSuggestion"
), Kr = (e) => {
  var t, n;
  return ((n = (t = e.extensionManager.extensions.find(
    (a) => a.name === "slashCommands"
  )) == null ? void 0 : t.options) == null ? void 0 : n.codeBlockPreferences) ?? null;
}, Xr = (e, t, n) => {
  const a = e.state.doc, o = Math.min(Math.max(t.from, 1), a.content.size);
  let i = null;
  a.descendants((c, d) => {
    if (c.type.name !== "heading" || c.attrs.level !== n)
      return !0;
    const g = d + 1, f = d + Math.max(1, c.nodeSize - 1), p = Math.min(Math.max(o, g), f), h = Math.abs(p - o);
    return (!i || h < i.distance || h === i.distance && d > i.pos) && (i = { distance: h, pos: d, nodeSize: c.nodeSize }), !0;
  });
  const r = i;
  if (!r)
    return null;
  const m = r.pos + 1, l = r.pos + Math.max(1, r.nodeSize - 1);
  return Math.min(Math.max(o, m), l);
}, ht = (e) => ({ editor: t, range: n }) => {
  t.chain().focus().deleteRange(n).setHeading({ level: e }).command(() => {
    const a = Xr(t, n, e);
    if (a === null)
      return !0;
    const o = t.state.tr.setSelection(
      Xe.create(t.state.doc, a)
    );
    return t.view.dispatch(o), !0;
  }).run();
}, Gr = () => [
  // 标题 - 文档结构最基础
  {
    id: "heading-1",
    title: "Heading 1",
    description: "Large section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h1", "title", "标题", "biaoti", "yijibiaoti"],
    icon: "lucide:heading-1",
    command: ht(1)
  },
  {
    id: "heading-2",
    title: "Heading 2",
    description: "Medium section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h2", "标题", "biaoti", "erjibiaoti"],
    icon: "lucide:heading-2",
    command: ht(2)
  },
  {
    id: "heading-3",
    title: "Heading 3",
    description: "Small section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h3", "标题", "biaoti", "sanjibiaoti"],
    icon: "lucide:heading-3",
    command: ht(3)
  },
  {
    id: "heading-4",
    title: "Heading 4",
    description: "Smallest section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h4", "标题", "biaoti"],
    icon: "lucide:heading-4",
    command: ht(4)
  },
  // 列表 - 内容组织高频操作
  {
    id: "bullet-list",
    title: "Bullet List",
    description: "Simple bulleted list",
    group: "basic",
    requiredCapabilities: ["list.bullet"],
    aliases: ["ul", "unordered", "无序列表", "liebiao", "wuxuliebiao"],
    icon: "lucide:list",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleBulletList().run();
    }
  },
  {
    id: "ordered-list",
    title: "Numbered List",
    description: "Ordered list with numbers",
    group: "basic",
    requiredCapabilities: ["list.ordered"],
    aliases: ["ol", "ordered", "有序列表", "youxuliebiao"],
    icon: "lucide:list-ordered",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleOrderedList().run();
    }
  },
  {
    id: "task-list",
    title: "Task List",
    description: "Checklist with checkboxes",
    group: "basic",
    requiredCapabilities: ["list.task"],
    aliases: ["todo", "checkbox", "待办", "daiban", "renwuliebiao"],
    icon: "lucide:list-checks",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleTaskList().run();
    }
  },
  // Toggle (折叠块)
  {
    id: "toggle-list",
    title: "Toggle List",
    description: "Collapsible content block",
    group: "basic",
    requiredCapabilities: ["block-style.toggle"],
    aliases: ["collapse", "fold", "折叠", "zhedie"],
    icon: "lucide:chevron-right",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setToggle().run();
    }
  },
  // 引用与分隔
  {
    id: "blockquote",
    title: "Blockquote",
    description: "Capture a quote",
    group: "basic",
    requiredCapabilities: ["block-style.blockquote"],
    aliases: ["quote", "cite", "引用", "yinyong"],
    icon: "lucide:quote",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleBlockquote().run();
    }
  },
  {
    id: "horizontal-rule",
    title: "Horizontal Rule",
    description: "Visual divider line",
    group: "basic",
    requiredCapabilities: ["insert.horizontal-rule"],
    aliases: ["hr", "divider", "分割线", "fengexian"],
    icon: "lucide:minus",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setHorizontalRule().run();
    }
  },
  // 媒体插入
  {
    id: "image",
    title: "Image",
    description: "Upload or embed an image",
    group: "media",
    requiredCapabilities: ["insert.image"],
    aliases: ["img", "photo", "picture", "图片", "tupian"],
    icon: "lucide:image",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).selectAndUploadImage().run();
    }
  },
  {
    id: "video",
    title: "Video",
    description: "Upload or embed a video",
    group: "media",
    requiredCapabilities: ["insert.video"],
    aliases: ["movie", "视频", "shipin"],
    icon: "lucide:video",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).selectAndUploadVideo().run();
    }
  },
  // 代码
  {
    id: "code-block",
    title: "Code Block",
    description: "Code snippet with highlighting",
    group: "advanced",
    requiredCapabilities: ["block-style.code-block"],
    aliases: ["```", "snippet", "代码", "daima", "daimakuai"],
    icon: "lucide:code",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).insertContent(
        An({
          source: "slash",
          preferences: Kr(e)
        })
      ).run();
    }
  },
  // 链接
  {
    id: "link",
    title: "Link",
    description: "Link to a web page",
    group: "advanced",
    requiredCapabilities: ["insert.link"],
    aliases: ["url", "href", "链接", "lianjie"],
    icon: "lucide:link",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).run(), wt(e).openLinkEditor();
    }
  },
  // 表格
  {
    id: "table",
    title: "Table",
    description: "Insert a 3×3 table",
    group: "advanced",
    requiredCapabilities: ["insert.table"],
    aliases: ["grid", "表格", "biaoge"],
    icon: "lucide:table-2",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).insertTable({ rows: 3, cols: 3, withHeaderRow: !0 }).run();
    }
  },
  // 嵌入 - 相对低频
  {
    id: "embed",
    title: "Embed",
    description: "Embed an external page",
    group: "advanced",
    requiredCapabilities: ["insert.iframe"],
    aliases: ["iframe", "嵌入", "qianru"],
    icon: "lucide:gallery-vertical",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).openIframeDialog().run();
    }
  },
  // 对齐 - 低频格式化，收尾
  {
    id: "align-left",
    title: "Align Left",
    description: "Align block text left",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["left", "左对齐", "zuoduiqi"],
    icon: "lucide:align-left",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("left").run();
    }
  },
  {
    id: "align-center",
    title: "Align Center",
    description: "Center block text",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["center", "居中", "juzhong"],
    icon: "lucide:align-center",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("center").run();
    }
  },
  {
    id: "align-right",
    title: "Align Right",
    description: "Align block text right",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["right", "右对齐", "youduiqi"],
    icon: "lucide:align-right",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("right").run();
    }
  },
  {
    id: "align-justify",
    title: "Align Justify",
    description: "Justify block text",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["justify", "两端对齐", "liangduanduiqi"],
    icon: "lucide:align-justify",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("justify").run();
    }
  }
], Zr = (e, t, n) => Wr(
  zr(
    Hr(
      Gr(),
      (e == null ? void 0 : e.catalogContributions) ?? []
    ),
    t,
    n
  ),
  t
), Yr = Ct({
  name: "slashCommands",
  char: "/",
  pluginKey: Ur,
  addOptions: () => ({
    codeBlockPreferences: null,
    catalogContributions: null
  }),
  items: ({ query: e, editor: t }) => {
    var a;
    const n = (a = t.extensionManager.extensions.find(
      (o) => o.name === "slashCommands"
    )) == null ? void 0 : a.options;
    return Zr(
      n,
      e,
      na(t)
    );
  },
  command: ({ editor: e, range: t, props: n }) => {
    n && typeof n.command == "function" && (qr(n), n.command({ editor: e, range: t }));
  },
  component: Or
});
function Jr(e) {
  return e.split(`
`).filter(
    (a) => (
      // check for inline markdown content like images, links, italic, bold, etc.
      /!\[.*\]\(.*\)/.test(a) || /\[.*\]\(.*\)/.test(a) || /(^|\s)\*.*\*(\s|$)/.test(a) || /(^|\s)_.*_(\s|$)/.test(a) || /(^|\s)\*\*.*\*\*(\s|$)/.test(a) || /(^|\s)__.*__(\s|$)/.test(a) || /(^|\s)~~.*~~(\s|$)/.test(a) || // check for block markdown content like headings, code blocks, lists, etc.
      a.startsWith("![") || a.startsWith("#") || a.startsWith("> ") || a.startsWith("*") || a.startsWith("- ") || a.startsWith("1. ") || a.startsWith("|") || a.startsWith("```") || a.startsWith("`") || a.startsWith("[") || a.startsWith("---")
    )
  ).length > 0;
}
const Qr = (e) => {
  var a;
  const { $from: t } = e.selection;
  let n = t.depth;
  for (; n > 0; ) {
    if (((a = t.node(n).type) == null ? void 0 : a.name) === "codeBlock")
      return !0;
    n -= 1;
  }
  return !1;
}, el = (e) => {
  var t;
  return e ? (t = e.files) != null && t.length ? !0 : Array.from(e.items ?? []).some(
    (n) => n.kind === "file"
  ) : !1;
}, tl = We.create({
  name: "contentPaste",
  addOptions() {
    return {
      enabled: !0,
      filePlatformRuntime: null,
      codeBlockPreferences: null
    };
  },
  addProseMirrorPlugins() {
    return [
      new Ne({
        key: new De("contentPaste"),
        props: {
          handleDOMEvents: {
            copy: (e, t) => {
              var i, r;
              const n = window.getSelection();
              if (!n) return !1;
              const a = document.createElement("div");
              for (let m = 0; m < n.rangeCount; m++)
                a.appendChild(n.getRangeAt(m).cloneContents());
              return a.querySelectorAll("img").forEach((m) => {
                const l = m.getAttribute("src");
                l && l.startsWith("/") && m.setAttribute("src", `${window.location.origin}${l}`);
              }), (i = t.clipboardData) == null || i.setData("text/html", a.innerHTML), (r = t.clipboardData) == null || r.setData("text/plain", n.toString()), t.preventDefault(), !0;
            }
          },
          handlePaste: (e, t, n) => {
            var c, d, g, f;
            if (!this.options.enabled || this.options.filePlatformRuntime && el(t.clipboardData))
              return !1;
            const a = (c = t.clipboardData) == null ? void 0 : c.getData("text/html");
            if (a && /<(?:img|iframe|video)\b/i.test(a) && this.options.filePlatformRuntime)
              return Promise.resolve(
                this.options.filePlatformRuntime.intakeFiles({
                  source: "paste",
                  files: [],
                  htmlContent: a
                })
              ).catch((p) => {
                var h;
                (h = this.options.filePlatformRuntime) == null || h.emitDiagnostic({
                  code: "paste-html-media-intake-dispatch-failed",
                  message: p instanceof Error ? p.message : "Failed to dispatch HTML media paste through unified intake.",
                  severity: "error",
                  stage: "intake",
                  cause: p
                });
              }), !0;
            const o = (d = t.clipboardData) == null ? void 0 : d.getData("text/plain");
            if (!o) return !1;
            if (!Jr(o)) {
              if (Qr(e.state) || qi(o).kind !== "code-block")
                return !1;
              const h = An({
                code: o,
                source: "paste",
                preferences: this.options.codeBlockPreferences
              }), v = e.state.schema.nodeFromJSON(h);
              return (g = h.attrs) != null && g.language || (f = Pn(
                this.editor.storage.codeBlock
              )) == null || f.enqueue(v.textContent), e.dispatch(
                e.state.tr.replaceSelectionWith(v, !1).scrollIntoView()
              ), !0;
            }
            const i = oa(
              aa(o),
              "paste"
            ), r = e.state.schema.nodeFromJSON(i), m = new qo(r.content, 0, 0), l = e.state.tr.replaceSelection(m);
            return e.dispatch(l), !0;
          }
        }
      })
    ];
  }
}), co = (e, t) => e.selection.empty ? !1 : (t && t(e.tr.deleteSelection().scrollIntoView()), !0);
function nl(e, t) {
  let { $cursor: n } = e.selection;
  return !n || (t ? !t.endOfTextblock("backward", e) : n.parentOffset > 0) ? null : n;
}
const ol = (e, t, n) => {
  let a = nl(e, n);
  if (!a)
    return !1;
  let o = uo(a);
  if (!o) {
    let r = a.blockRange(), m = r && $t(r);
    return m == null ? !1 : (t && t(e.tr.lift(r, m).scrollIntoView()), !0);
  }
  let i = o.nodeBefore;
  if (fo(e, o, t, -1))
    return !0;
  if (a.parent.content.size == 0 && (nt(i, "end") || Fe.isSelectable(i)))
    for (let r = a.depth; ; r--) {
      let m = Xn(e.doc, a.before(r), a.after(r), yt.empty);
      if (m && m.slice.size < m.to - m.from) {
        if (t) {
          let l = e.tr.step(m);
          l.setSelection(nt(i, "end") ? Te.findFrom(l.doc.resolve(l.mapping.map(o.pos, -1)), -1) : Fe.create(l.doc, o.pos - i.nodeSize)), t(l.scrollIntoView());
        }
        return !0;
      }
      if (r == 1 || a.node(r - 1).childCount > 1)
        break;
    }
  return i.isAtom && o.depth == a.depth - 1 ? (t && t(e.tr.delete(o.pos - i.nodeSize, o.pos).scrollIntoView()), !0) : !1;
};
function nt(e, t, n = !1) {
  for (let a = e; a; a = t == "start" ? a.firstChild : a.lastChild) {
    if (a.isTextblock)
      return !0;
    if (n && a.childCount != 1)
      return !1;
  }
  return !1;
}
const al = (e, t, n) => {
  let { $head: a, empty: o } = e.selection, i = a;
  if (!o)
    return !1;
  if (a.parent.isTextblock) {
    if (n ? !n.endOfTextblock("backward", e) : a.parentOffset > 0)
      return !1;
    i = uo(a);
  }
  let r = i && i.nodeBefore;
  return !r || !Fe.isSelectable(r) ? !1 : (t && t(e.tr.setSelection(Fe.create(e.doc, i.pos - r.nodeSize)).scrollIntoView()), !0);
};
function uo(e) {
  if (!e.parent.type.spec.isolating)
    for (let t = e.depth - 1; t >= 0; t--) {
      if (e.index(t) > 0)
        return e.doc.resolve(e.before(t + 1));
      if (e.node(t).type.spec.isolating)
        break;
    }
  return null;
}
function il(e, t) {
  let { $cursor: n } = e.selection;
  return !n || (t ? !t.endOfTextblock("forward", e) : n.parentOffset < n.parent.content.size) ? null : n;
}
const sl = (e, t, n) => {
  let a = il(e, n);
  if (!a)
    return !1;
  let o = po(a);
  if (!o)
    return !1;
  let i = o.nodeAfter;
  if (fo(e, o, t, 1))
    return !0;
  if (a.parent.content.size == 0 && (nt(i, "start") || Fe.isSelectable(i))) {
    let r = Xn(e.doc, a.before(), a.after(), yt.empty);
    if (r && r.slice.size < r.to - r.from) {
      if (t) {
        let m = e.tr.step(r);
        m.setSelection(nt(i, "start") ? Te.findFrom(m.doc.resolve(m.mapping.map(o.pos)), 1) : Fe.create(m.doc, m.mapping.map(o.pos))), t(m.scrollIntoView());
      }
      return !0;
    }
  }
  return i.isAtom && o.depth == a.depth - 1 ? (t && t(e.tr.delete(o.pos, o.pos + i.nodeSize).scrollIntoView()), !0) : !1;
}, rl = (e, t, n) => {
  let { $head: a, empty: o } = e.selection, i = a;
  if (!o)
    return !1;
  if (a.parent.isTextblock) {
    if (n ? !n.endOfTextblock("forward", e) : a.parentOffset < a.parent.content.size)
      return !1;
    i = po(a);
  }
  let r = i && i.nodeAfter;
  return !r || !Fe.isSelectable(r) ? !1 : (t && t(e.tr.setSelection(Fe.create(e.doc, i.pos)).scrollIntoView()), !0);
};
function po(e) {
  if (!e.parent.type.spec.isolating)
    for (let t = e.depth - 1; t >= 0; t--) {
      let n = e.node(t);
      if (e.index(t) + 1 < n.childCount)
        return e.doc.resolve(e.after(t + 1));
      if (n.type.spec.isolating)
        break;
    }
  return null;
}
const ll = (e, t) => {
  let { $head: n, $anchor: a } = e.selection;
  return !n.parent.type.spec.code || !n.sameParent(a) ? !1 : (t && t(e.tr.insertText(`
`).scrollIntoView()), !0);
};
function Vt(e) {
  for (let t = 0; t < e.edgeCount; t++) {
    let { type: n } = e.edge(t);
    if (n.isTextblock && !n.hasRequiredAttrs())
      return n;
  }
  return null;
}
const wn = (e, t) => {
  let { $head: n, $anchor: a } = e.selection;
  if (!n.parent.type.spec.code || !n.sameParent(a))
    return !1;
  let o = n.node(-1), i = n.indexAfter(-1), r = Vt(o.contentMatchAt(i));
  if (!r || !o.canReplaceWith(i, i, r))
    return !1;
  if (t) {
    let m = n.after(), l = e.tr.replaceWith(m, m, r.createAndFill());
    l.setSelection(Te.near(l.doc.resolve(m), 1)), t(l.scrollIntoView());
  }
  return !0;
}, ml = (e, t) => {
  let n = e.selection, { $from: a, $to: o } = n;
  if (n instanceof Zn || a.parent.inlineContent || o.parent.inlineContent)
    return !1;
  let i = Vt(o.parent.contentMatchAt(o.indexAfter()));
  if (!i || !i.isTextblock)
    return !1;
  if (t) {
    let r = (!a.parentOffset && o.index() < o.parent.childCount ? a : o).pos, m = e.tr.insert(r, i.createAndFill());
    m.setSelection(Ge.create(m.doc, r + 1)), t(m.scrollIntoView());
  }
  return !0;
}, cl = (e, t) => {
  let { $cursor: n } = e.selection;
  if (!n || n.parent.content.size)
    return !1;
  if (n.depth > 1 && n.after() != n.end(-1)) {
    let i = n.before();
    if (vt(e.doc, i))
      return t && t(e.tr.split(i).scrollIntoView()), !0;
  }
  let a = n.blockRange(), o = a && $t(a);
  return o == null ? !1 : (t && t(e.tr.lift(a, o).scrollIntoView()), !0);
};
function dl(e) {
  return (t, n) => {
    if (t.selection instanceof Fe && t.selection.node.isBlock) {
      let { $from: p } = t.selection;
      return !p.parentOffset || !vt(t.doc, p.pos) ? !1 : (n && n(t.tr.split(p.pos).scrollIntoView()), !0);
    }
    if (!t.selection.$from.depth)
      return !1;
    let a = t.tr;
    !t.selection.empty && (t.selection instanceof Ge || t.selection instanceof Zn) && a.deleteSelection();
    let { $from: o } = a.selection, i = a.steps.length, r = [], m, l, c = !1, d = !1;
    for (let p = o.depth; ; p--)
      if (o.node(p).isBlock) {
        c = o.end(p) == o.pos + (o.depth - p), d = o.start(p) == o.pos - (o.depth - p), l = Vt(o.node(p - 1).contentMatchAt(o.indexAfter(p - 1))), r.unshift(c && l ? { type: l } : null), m = p;
        break;
      } else {
        if (p == 1)
          return !1;
        r.unshift(null);
      }
    let g = o.pos, f = vt(a.doc, g, r.length, r);
    if (f || (r[0] = l ? { type: l } : null, f = vt(a.doc, g, r.length, r)), !f)
      return !1;
    if (a.split(g, r.length, r), !c && d && o.node(m).type != l) {
      let p = a.mapping.slice(i), h = p.map(o.before(m)), v = a.doc.resolve(h);
      l && o.node(m - 1).canReplaceWith(v.index(), v.index() + 1, l) && a.setNodeMarkup(p.map(o.before(m)), l);
    }
    return n && n(a.scrollIntoView()), !0;
  };
}
const ul = dl();
function pl(e, t, n) {
  let a = t.nodeBefore, o = t.nodeAfter, i = t.index();
  return !a || !o || !a.type.compatibleContent(o.type) ? !1 : !a.content.size && t.parent.canReplace(i - 1, i) ? (n && n(e.tr.delete(t.pos - a.nodeSize, t.pos).scrollIntoView()), !0) : !t.parent.canReplace(i, i + 1) || !(o.isTextblock || Gn(e.doc, t.pos)) ? !1 : (n && n(e.tr.join(t.pos).scrollIntoView()), !0);
}
function fo(e, t, n, a) {
  let o = t.nodeBefore, i = t.nodeAfter, r, m, l = o.type.spec.isolating || i.type.spec.isolating;
  if (!l && pl(e, t, n))
    return !0;
  let c = !l && t.parent.canReplace(t.index(), t.index() + 1);
  if (c && (r = (m = o.contentMatchAt(o.childCount)).findWrapping(i.type)) && m.matchType(r[0] || i.type).validEnd) {
    if (n) {
      let p = t.pos + i.nodeSize, h = it.empty;
      for (let x = r.length - 1; x >= 0; x--)
        h = it.from(r[x].create(null, h));
      h = it.from(o.copy(h));
      let v = e.tr.step(new dn(t.pos - 1, p, t.pos, p, new yt(h, 1, 0), r.length, !0)), L = v.doc.resolve(p + 2 * r.length);
      L.nodeAfter && L.nodeAfter.type == o.type && Gn(v.doc, L.pos) && v.join(L.pos), n(v.scrollIntoView());
    }
    return !0;
  }
  let d = i.type.spec.isolating || a > 0 && l ? null : Te.findFrom(t, 1), g = d && d.$from.blockRange(d.$to), f = g && $t(g);
  if (f != null && f >= t.depth)
    return n && n(e.tr.lift(g, f).scrollIntoView()), !0;
  if (c && nt(i, "start", !0) && nt(o, "end")) {
    let p = o, h = [];
    for (; h.push(p), !p.isTextblock; )
      p = p.lastChild;
    let v = i, L = 1;
    for (; !v.isTextblock; v = v.firstChild)
      L++;
    if (p.canReplace(p.childCount, p.childCount, v.content)) {
      if (n) {
        let x = it.empty;
        for (let b = h.length - 1; b >= 0; b--)
          x = it.from(h[b].copy(x));
        let M = e.tr.step(new dn(t.pos - h.length, t.pos + i.nodeSize, t.pos + L, t.pos + i.nodeSize - L, new yt(x, h.length, 0), 0, !0));
        n(M.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function qt(...e) {
  return function(t, n, a) {
    for (let o = 0; o < e.length; o++)
      if (e[o](t, n, a))
        return !0;
    return !1;
  };
}
qt(co, ol, al);
qt(co, sl, rl);
qt(ll, ml, cl, ul);
typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform && os.platform() == "darwin";
const fl = ["aria-label"], gl = ["aria-label"], hl = /* @__PURE__ */ Ce({
  name: "CodeBlockCollapsedProjection",
  __name: "code-block-collapsed-projection",
  props: {
    lines: {},
    lineNumbers: {},
    totalLineCount: {},
    showLineNumbers: { type: Boolean }
  },
  emits: ["request-expand"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = Ee("code-block"), { text: i, format: r } = Ve(), m = B(() => `${n.lines.reduce(
      (g, f, p) => Math.max(g, String(n.lineNumbers[p] ?? p + 1).length),
      1
    )}ch`), l = B(() => {
      const d = Math.max(1, n.totalLineCount), g = Math.min(d, Math.max(1, n.lines.length));
      return g < d ? r(
        "codeBlock:collapsed.summary.partial",
        "Showing {visible} of {total} lines",
        { visible: g, total: d }
      ) : r("codeBlock:collapsed.summary.total", "{total} lines", { total: d });
    }), c = B(
      () => r(
        "codeBlock:collapsed.expandAria",
        "Expand code block to edit, {summary}",
        { summary: l.value }
      )
    );
    return (d, g) => (E(), S("div", {
      class: u(s(o).e("collapsed-projection")),
      contenteditable: "false",
      role: "region",
      "aria-label": l.value,
      "data-zx-code-block-collapsed-projection": "true"
    }, [
      _("div", {
        class: u(s(o).e("collapsed-lines"))
      }, [
        (E(!0), S(ye, null, Be(e.lines, (f, p) => (E(), S("div", {
          key: `${e.lineNumbers[p] ?? p}:${p}`,
          class: u(s(o).e("collapsed-line"))
        }, [
          e.showLineNumbers ? (E(), S("span", {
            key: 0,
            class: u(s(o).e("collapsed-line-number")),
            style: Pe({ width: m.value }),
            "aria-hidden": "true"
          }, W(e.lineNumbers[p] ?? p + 1), 7)) : K("", !0),
          _("code", {
            class: u(s(o).e("collapsed-code"))
          }, W(f), 3)
        ], 2))), 128))
      ], 2),
      _("button", {
        class: u(s(o).e("collapsed-expand")),
        type: "button",
        "aria-label": c.value,
        onMousedown: g[0] || (g[0] = N(() => {
        }, ["prevent"])),
        onClick: g[1] || (g[1] = (f) => a("request-expand"))
      }, [
        _("span", null, W(s(i)("codeBlock:collapsed.expand", "Expand to edit")), 1),
        _("span", {
          class: u(s(o).e("collapsed-summary"))
        }, W(l.value), 3)
      ], 42, gl)
    ], 10, fl));
  }
}), jl = Mn(Bn), vl = (e) => Array.isArray(e) ? e.filter((t) => typeof t == "string") : typeof e == "string" ? e.split(/\s+/).filter(Boolean) : [], kn = (e) => Yn(e).split(`
`).map(
  (t) => t ? [
    {
      text: t,
      classNames: []
    }
  ] : []
), bl = (e, t) => {
  const n = Yn(e), a = Ti(t).id;
  if (!a || a === "plaintext")
    return kn(n);
  let o;
  try {
    o = jl.highlight(
      a,
      n
    );
  } catch {
    return kn(n);
  }
  const i = [[]], r = (l, c) => {
    const d = l.split(`
`);
    d.forEach((g, f) => {
      g && i[i.length - 1].push({ text: g, classNames: c }), f < d.length - 1 && i.push([]);
    });
  }, m = (l, c) => {
    var f, p;
    const d = vl((f = l.properties) == null ? void 0 : f.className), g = d.length ? [.../* @__PURE__ */ new Set([...c, ...d])] : c;
    l.type === "text" && typeof l.value == "string" && r(l.value, g), (p = l.children) == null || p.forEach((h) => m(h, g));
  };
  return m(o, []), i;
}, _l = ["aria-label"], yl = ["data-zx-fold-row-offset"], wl = ["aria-label", "onClick"], kl = /* @__PURE__ */ Ce({
  __name: "code-block-folded-projection",
  props: {
    rows: {},
    code: {},
    language: {}
  },
  emits: ["toggle-fold", "request-edit"],
  setup(e, { emit: t }) {
    const n = Ee("code-block"), { text: a, format: o } = Ve(), i = e, r = t, m = B(
      () => bl(i.code, i.language)
    ), l = B(() => i.rows.map((b) => {
      const w = m.value[b.lineIndex] ?? [], V = w.map((z) => z.text).join("");
      return {
        row: b,
        tokens: V === b.text ? w : [{ text: b.text, classNames: [] }]
      };
    })), c = (b) => {
      var j;
      return ((j = b.target) == null ? void 0 : j.closest("button")) !== null;
    }, d = (b) => {
      var j;
      return ((j = b.target) == null ? void 0 : j.closest(
        '[data-zx-fold-edit-target="true"]'
      )) !== null;
    }, g = (b) => {
      var z;
      const j = b.target, w = j == null ? void 0 : j.closest("[data-zx-fold-row-offset]"), V = Number(w == null ? void 0 : w.dataset.zxFoldRowOffset);
      return Number.isFinite(V) ? V : ((z = i.rows[0]) == null ? void 0 : z.fromOffset) ?? 0;
    }, f = (b, j, w) => {
      b.preventDefault(), r("request-edit", {
        offset: g(b),
        trigger: j,
        pendingEdit: w
      });
    }, p = (b) => {
      c(b) || !d(b) || f(b, "pointer");
    }, h = (b) => {
      if (!c(b)) {
        if (b.key === "Enter" || b.key === "F2") {
          f(b, "keyboard");
          return;
        }
        if (b.key === "Backspace") {
          f(b, "beforeinput", { type: "delete-backward" });
          return;
        }
        if (b.key === "Delete") {
          f(b, "beforeinput", { type: "delete-forward" });
          return;
        }
        b.key.length === 1 && !b.altKey && !b.ctrlKey && !b.metaKey && f(b, "beforeinput", {
          type: "insert-text",
          text: b.key
        });
      }
    }, v = (b) => {
      const j = b;
      if (j.inputType === "deleteContentBackward") {
        f(b, "beforeinput", { type: "delete-backward" });
        return;
      }
      if (j.inputType === "deleteContentForward") {
        f(b, "beforeinput", { type: "delete-forward" });
        return;
      }
      j.inputType === "insertText" && typeof j.data == "string" && f(b, "beforeinput", {
        type: "insert-text",
        text: j.data
      });
    }, L = (b) => {
      var j;
      f(b, "paste", {
        type: "insert-plain-text",
        text: ((j = b.clipboardData) == null ? void 0 : j.getData("text/plain")) ?? "",
        source: "paste"
      });
    }, x = (b) => {
      var j;
      f(b, "drop", {
        type: "insert-plain-text",
        text: ((j = b.dataTransfer) == null ? void 0 : j.getData("text/plain")) ?? "",
        source: "drop"
      });
    }, M = (b) => {
      f(b, "composition");
    };
    return (b, j) => (E(), S("pre", {
      class: u([s(n).e("pre"), s(n).e("folded-pre")]),
      contenteditable: "false",
      role: "region",
      tabindex: "0",
      "aria-label": s(a)(
        "codeBlock:fold.readingView",
        "Folded code reading view. Press Enter or F2 to edit"
      ),
      onPointerdownCapture: p,
      onKeydownCapture: h,
      onBeforeinputCapture: v,
      onPasteCapture: L,
      onDropCapture: x,
      onCompositionstartCapture: M
    }, [
      j[10] || (j[10] = Ae("    ", -1)),
      _("code", {
        class: u([s(n).e("code"), s(n).e("folded-code")])
      }, [
        j[8] || (j[8] = Ae(`
      `, -1)),
        (E(!0), S(ye, null, Be(l.value, (w) => (E(), S("span", {
          key: `projection:${w.row.lineNumber}:${w.row.fromOffset}`,
          class: u([s(n).e("folded-line"), w.row.folded && s(n).is("folded")]),
          "data-zx-fold-row-offset": w.row.fromOffset
        }, [
          j[5] || (j[5] = Ae(`
        
        
        `, -1)),
          _("span", {
            class: u(s(n).e("folded-line-text")),
            "data-zx-fold-edit-target": "true"
          }, [
            (E(!0), S(ye, null, Be(w.tokens, (V, z) => (E(), S("span", {
              key: `${z}:${V.text}:${V.classNames.join(".")}`,
              class: u(V.classNames)
            }, W(V.text), 3))), 128))
          ], 2),
          j[6] || (j[6] = Ae(`
        `, -1)),
          w.row.folded && w.row.rangeKey ? (E(), S("button", {
            key: 0,
            class: u(s(n).e("fold-placeholder")),
            type: "button",
            "aria-label": s(o)(
              "codeBlock:fold.expand",
              "Expand code from line {line}, {hidden} hidden lines",
              { line: w.row.lineNumber, hidden: w.row.hiddenLineCount }
            ),
            "aria-expanded": "false",
            onMousedown: j[0] || (j[0] = N(() => {
            }, ["prevent"])),
            onClick: N((V) => r("toggle-fold", w.row.rangeKey), ["stop"])
          }, [
            j[1] || (j[1] = Ae(`
          `, -1)),
            j[2] || (j[2] = _("span", { "aria-hidden": "true" }, "…", -1)),
            j[3] || (j[3] = Ae(`
          `, -1)),
            _("span", {
              class: u(s(n).e("fold-placeholder-count"))
            }, `
            ` + W(s(o)("codeBlock:fold.hidden", "{count} lines hidden", {
              count: w.row.hiddenLineCount
            })) + `
          `, 3),
            j[4] || (j[4] = Ae(`
        `, -1))
          ], 42, wl)) : K("", !0),
          j[7] || (j[7] = Ae(`
      `, -1))
        ], 10, yl))), 128)),
        j[9] || (j[9] = Ae(`
    `, -1))
      ], 2),
      j[11] || (j[11] = Ae(`
  `, -1))
    ], 42, _l));
  }
}), Cl = ["data-zx-fold-row"], xl = ["aria-label", "aria-expanded", "onClick"], El = /* @__PURE__ */ Ce({
  __name: "code-block-folding-gutter",
  props: {
    mode: {},
    rows: {},
    highlightedLineNumbers: {},
    rowHeights: {}
  },
  emits: ["toggle-fold"],
  setup(e, { emit: t }) {
    const n = Ee("code-block"), { format: a } = Ve(), o = e, i = t, r = (l) => {
      var d;
      const c = (d = o.rowHeights) == null ? void 0 : d[l.lineIndex];
      return typeof c == "number" && c > 0 ? { height: `${c}px` } : void 0;
    }, m = (l) => l.folded ? a(
      "codeBlock:fold.expand",
      "Expand code from line {line}, {hidden} hidden lines",
      { line: l.lineNumber, hidden: l.hiddenLineCount }
    ) : a("codeBlock:fold.collapse", "Collapse code from line {line}", {
      line: l.lineNumber
    });
    return (l, c) => (E(), S("div", {
      class: u([
        s(n).e("gutter"),
        s(n).is("numbers-visible", e.mode !== "folds"),
        s(n).is("folds-visible", e.mode !== "numbers")
      ]),
      contenteditable: "false",
      "aria-hidden": "false"
    }, [
      (E(!0), S(ye, null, Be(e.rows, (d) => (E(), S("span", {
        key: `gutter:${d.lineNumber}:${d.fromOffset}`,
        class: u([
          s(n).e("gutter-row"),
          d.rangeKey && s(n).is("foldable"),
          d.folded && s(n).is("folded"),
          e.highlightedLineNumbers.has(d.lineNumber) && s(n).is("highlighted")
        ]),
        style: Pe(r(d)),
        "data-zx-fold-row": d.lineIndex
      }, [
        e.mode !== "folds" ? (E(), S("span", {
          key: 0,
          class: u(s(n).e("line-number-text"))
        }, W(d.lineNumber), 3)) : K("", !0),
        e.mode !== "numbers" ? (E(), S("span", {
          key: 1,
          class: u(s(n).e("fold-cell"))
        }, [
          d.rangeKey ? (E(), S("button", {
            key: 0,
            class: u(s(n).e("fold-toggle")),
            type: "button",
            "aria-label": m(d),
            "aria-expanded": !d.folded,
            onMousedown: c[0] || (c[0] = N(() => {
            }, ["prevent"])),
            onClick: (g) => i("toggle-fold", d.rangeKey)
          }, [
            U(s(te), {
              icon: d.folded ? "lucide:chevron-right" : "lucide:chevron-down"
            }, null, 8, ["icon"])
          ], 42, xl)) : (E(), S("span", {
            key: 1,
            class: u(s(n).e("fold-spacer"))
          }, null, 2))
        ], 2)) : K("", !0)
      ], 14, Cl))), 128))
    ], 2));
  }
}), Ll = /* @__PURE__ */ Ce({
  __name: "code-block-language-select",
  props: {
    modelValue: {
      type: null,
      required: !0
    },
    languageOptions: {
      type: Array,
      default: void 0
    },
    recentLanguages: {
      type: Array,
      default: () => []
    },
    defaultLanguage: {
      type: null,
      default: null
    }
  },
  emits: ["update:modelValue", "change", "dropdown-visible-change"],
  setup(e, { emit: t }) {
    const n = e, a = t, { text: o } = Ve(), i = B(
      () => n.languageOptions ?? ia(sa, {
        recentLanguages: n.recentLanguages,
        defaultLanguage: n.defaultLanguage
      }).map((c) => ({
        label: c.label,
        value: c.id
      }))
    ), r = B({
      get: () => n.modelValue ?? "plaintext",
      set: (c) => a("update:modelValue", nn(c))
    }), m = (c) => {
      a("change", nn(c));
    }, l = (c) => {
      a("dropdown-visible-change", c);
    };
    return (c, d) => (E(), ke(s(zt), fi({
      modelValue: r.value,
      "onUpdate:modelValue": d[0] || (d[0] = (g) => r.value = g),
      options: i.value,
      size: "small",
      filterable: "",
      placeholder: s(o)("codeBlock:language.placeholder", "Select language"),
      teleported: !1
    }, c.$attrs, {
      onChange: m,
      onVisibleChange: l
    }), null, 16, ["modelValue", "options", "placeholder"]));
  }
}), Tl = ["maxlength", "placeholder", "onKeydown"], Il = /* @__PURE__ */ Ce({
  name: "CodeBlockTitle",
  __name: "code-block-title",
  props: {
    modelValue: {
      type: String,
      required: !0
    },
    maxLength: {
      type: Number,
      default: 50
    },
    placeholder: {
      type: String,
      default: "Untitled code block"
    },
    editable: {
      type: Boolean,
      default: !0
    }
  },
  emits: ["update:modelValue"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = Ee("code-block"), { text: i } = Ve(), r = A(!1), m = A(""), l = A(null), c = B(
      () => i("codeBlock:title.placeholder", n.placeholder)
    ), d = () => {
      n.editable && (m.value = n.modelValue, r.value = !0, Me(() => {
        var p, h;
        (p = l.value) == null || p.focus(), (h = l.value) == null || h.select();
      }));
    }, g = () => {
      const p = m.value.trim();
      a("update:modelValue", p), r.value = !1;
    }, f = () => {
      r.value = !1, m.value = n.modelValue;
    };
    return (p, h) => (E(), S("div", {
      class: u(s(o).e("title-wrapper"))
    }, [
      r.value ? tt((E(), S("input", {
        key: 0,
        ref_key: "inputRef",
        ref: l,
        "onUpdate:modelValue": h[0] || (h[0] = (v) => m.value = v),
        class: u(s(o).e("title-input")),
        type: "text",
        maxlength: e.maxLength,
        placeholder: c.value,
        onMousedown: h[1] || (h[1] = N(() => {
        }, ["stop"])),
        onClick: h[2] || (h[2] = N(() => {
        }, ["stop"])),
        onKeydown: [
          h[3] || (h[3] = N(() => {
          }, ["stop"])),
          $e(N(g, ["prevent"]), ["enter"]),
          $e(N(f, ["prevent"]), ["escape"])
        ],
        onBlur: g
      }, null, 42, Tl)), [
        [_t, m.value]
      ]) : (E(), S("span", {
        key: 1,
        class: u([s(o).e("title"), s(o).is("empty", !e.modelValue)]),
        onMousedown: h[4] || (h[4] = N(() => {
        }, ["stop"])),
        onDblclick: N(d, ["stop"])
      }, W(e.modelValue || c.value), 35))
    ], 2));
  }
}), Sl = ["title", "aria-label", "aria-expanded"], Al = ["disabled", "title", "aria-label"], Pl = ["aria-pressed", "title", "aria-label"], Ml = ["aria-pressed", "title", "aria-label"], Bl = ["disabled", "title", "aria-label"], Dl = ["aria-expanded", "title", "aria-label"], Rl = /* @__PURE__ */ Ce({
  name: "CodeBlockHeader",
  __name: "code-block-header",
  props: {
    language: {},
    languageLabel: {},
    title: {},
    collapsed: { type: Boolean },
    codeContent: {},
    copyContent: {},
    copyMode: {},
    wrap: {},
    showLineNumbers: { type: Boolean },
    canCopyPlain: { type: Boolean },
    canCopyMarkdown: { type: Boolean },
    copyDisabledReason: {},
    settingsOpen: { type: Boolean },
    detectingLanguage: { type: Boolean },
    editable: { type: Boolean },
    recentLanguages: {},
    defaultLanguage: {}
  },
  emits: ["update:language", "update:title", "toggle-collapse", "toggle-wrap", "toggle-line-numbers", "toggle-settings", "copy", "copy-failed", "detect-language", "dropdown-visible-change"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = (b) => {
      a("update:language", b);
    }, i = (b) => {
      a("update:title", b);
    }, r = (b) => {
      a("dropdown-visible-change", b);
    }, m = Ee("code-block"), { text: l } = Ve(), c = A(!1), d = A(!1), g = B(
      () => n.collapsed ? l("codeBlock:expand", "Expand code block") : l("codeBlock:collapse", "Collapse code block")
    ), f = B(() => l("codeBlock:detect", "Detect language")), p = B(() => l("codeBlock:wrap", "Toggle line wrap")), h = B(
      () => l("codeBlock:lineNumbers", "Toggle line numbers")
    ), v = B(() => !n.canCopyPlain && !n.canCopyMarkdown ? n.copyDisabledReason ?? l("codeBlock:copyUnavailable", "Copy unavailable") : c.value ? l("codeBlock:copied", "Copied") : d.value ? l("codeBlock:copyFailed", "Copy failed") : n.copyMode === "markdown" ? l("codeBlock:copyMarkdown", "Copy Markdown") : l("codeBlock:copy", "Copy code")), L = B(() => c.value ? "lucide:check" : d.value ? "lucide:circle-alert" : "lucide:copy"), x = async (b) => {
      var V;
      if ((V = navigator == null ? void 0 : navigator.clipboard) != null && V.writeText) {
        await navigator.clipboard.writeText(b);
        return;
      }
      const j = document.createElement("textarea");
      j.value = b, j.style.position = "fixed", j.style.left = "0", j.style.top = "0", j.style.opacity = "0", j.setAttribute("readonly", "true"), document.body.appendChild(j), j.focus(), j.select();
      const w = document.execCommand("copy");
      if (document.body.removeChild(j), !w) throw new Error("copy failed");
    }, M = async () => {
      if (!(!n.canCopyPlain && !n.canCopyMarkdown))
        try {
          await x(n.copyContent ?? n.codeContent ?? ""), c.value = !0, d.value = !1, a("copy"), window.setTimeout(() => {
            c.value = !1;
          }, 1500);
        } catch {
          d.value = !0, a("copy-failed"), window.setTimeout(() => {
            d.value = !1;
          }, 1500);
        }
    };
    return (b, j) => (E(), S("div", {
      class: u(s(m).e("header")),
      contenteditable: "false"
    }, [
      _("div", {
        class: u(s(m).e("header-left"))
      }, [
        _("button", {
          class: u(s(m).e("collapse-btn")),
          type: "button",
          title: g.value,
          "aria-label": g.value,
          "aria-expanded": !e.collapsed,
          onMousedown: j[0] || (j[0] = N(() => {
          }, ["prevent"])),
          onClick: j[1] || (j[1] = (w) => a("toggle-collapse"))
        }, [
          U(s(te), {
            icon: e.collapsed ? "lucide:chevron-right" : "lucide:chevron-down"
          }, null, 8, ["icon"])
        ], 42, Sl),
        U(Il, {
          "model-value": e.title,
          "max-length": 50,
          editable: e.editable,
          "onUpdate:modelValue": i
        }, null, 8, ["model-value", "editable"])
      ], 2),
      _("div", {
        class: u(s(m).e("header-right"))
      }, [
        e.editable ? (E(), ke(Ll, {
          key: 0,
          "model-value": e.language,
          class: u(s(m).e("select")),
          "recent-languages": e.recentLanguages,
          "default-language": e.defaultLanguage,
          "onUpdate:modelValue": o,
          onDropdownVisibleChange: r
        }, null, 8, ["model-value", "class", "recent-languages", "default-language"])) : (E(), S("span", {
          key: 1,
          class: u(s(m).e("language-label"))
        }, W(e.languageLabel), 3)),
        e.editable ? (E(), S("button", {
          key: 2,
          class: u([s(m).e("action-btn"), e.detectingLanguage && s(m).is("active")]),
          type: "button",
          disabled: e.detectingLanguage,
          title: f.value,
          "aria-label": f.value,
          onMousedown: j[2] || (j[2] = N(() => {
          }, ["prevent"])),
          onClick: j[3] || (j[3] = (w) => a("detect-language"))
        }, [
          U(s(te), { icon: "lucide:wand-sparkles" })
        ], 42, Al)) : K("", !0),
        _("button", {
          class: u([s(m).e("action-btn"), e.wrap === "on" && s(m).is("active")]),
          type: "button",
          "aria-pressed": e.wrap === "on",
          title: p.value,
          "aria-label": p.value,
          onMousedown: j[4] || (j[4] = N(() => {
          }, ["prevent"])),
          onClick: j[5] || (j[5] = (w) => a("toggle-wrap"))
        }, [
          U(s(te), { icon: "lucide:wrap-text" })
        ], 42, Pl),
        e.editable ? (E(), S("button", {
          key: 3,
          class: u([s(m).e("action-btn"), e.showLineNumbers && s(m).is("active")]),
          type: "button",
          "aria-pressed": e.showLineNumbers,
          title: h.value,
          "aria-label": h.value,
          onMousedown: j[6] || (j[6] = N(() => {
          }, ["prevent"])),
          onClick: j[7] || (j[7] = (w) => a("toggle-line-numbers"))
        }, [
          U(s(te), { icon: "lucide:list-ordered" })
        ], 42, Ml)) : K("", !0),
        _("button", {
          class: u([
            s(m).e("action-btn"),
            s(m).is("copied", c.value),
            s(m).is("failed", d.value)
          ]),
          type: "button",
          disabled: !e.canCopyPlain && !e.canCopyMarkdown,
          title: v.value,
          "aria-label": v.value,
          onMousedown: j[8] || (j[8] = N(() => {
          }, ["prevent"])),
          onClick: M
        }, [
          U(s(te), { icon: L.value }, null, 8, ["icon"])
        ], 42, Bl),
        e.editable ? (E(), S("button", {
          key: 4,
          class: u([s(m).e("action-btn"), e.settingsOpen && s(m).is("active")]),
          type: "button",
          "aria-expanded": e.settingsOpen,
          title: s(l)("codeBlock:settings", "Code block settings"),
          "aria-label": s(l)("codeBlock:settings.open", "Open code block settings"),
          onMousedown: j[9] || (j[9] = N(() => {
          }, ["prevent"])),
          onClick: j[10] || (j[10] = (w) => a("toggle-settings"))
        }, [
          U(s(te), { icon: "lucide:settings-2" })
        ], 42, Dl)) : K("", !0)
      ], 2)
    ], 2));
  }
}), Ol = (e, t) => e.length === t.length && e.every((n, a) => {
  const o = t[a];
  return (o == null ? void 0 : o.state) === n.state && o.source === n.source && o.kind === n.kind && o.anchor.startText === n.anchor.startText && o.anchor.endText === n.anchor.endText && o.anchor.span === n.anchor.span && o.anchor.depth === n.anchor.depth;
}), Nl = (e) => ({
  offset: e.offset,
  trigger: e.trigger,
  pendingEdit: e.pendingEdit ? { ...e.pendingEdit } : void 0
}), $l = (e) => {
  var we;
  const t = A(typeof globalThis.IntersectionObserver != "function"), n = A(!1), a = Ke(e.lines.value), o = Ke([]), i = Ke(null), r = Ke(null), m = A(0), l = A(0), c = A(!1), d = A(!1), g = e.resolveFolding ?? ua, f = e.resolveCanonicalLineOffsets ?? Dn;
  let p = 0, h = null, v = null, L = null, x = 0, M = null, b = null;
  const j = () => {
    h == null || h.disconnect(), h = null;
  }, w = () => {
    c.value = !0;
  }, V = (O) => {
    const Q = O.relatedTarget;
    c.value = !!(L && typeof Node < "u" && Q instanceof Node && L.contains(Q));
  }, z = () => {
    L == null || L.removeEventListener("focusin", w), L == null || L.removeEventListener("focusout", V), L = null, c.value = !1;
  }, F = (O) => {
    n.value = (O == null ? void 0 : O.matches) ?? (v == null ? void 0 : v.matches) ?? !1;
  };
  typeof window < "u" && typeof window.matchMedia == "function" && (v = window.matchMedia("(pointer: coarse)"), F(), (we = v.addEventListener) == null || we.call(v, "change", F)), Le(
    e.bodyRef,
    (O) => {
      if (j(), z(), O && (L = O, O.addEventListener("focusin", w), O.addEventListener("focusout", V), c.value = !!(typeof document < "u" && document.activeElement && O.contains(document.activeElement))), typeof globalThis.IntersectionObserver != "function") {
        t.value = !0;
        return;
      }
      if (!O) {
        t.value = !1;
        return;
      }
      t.value = !1, h = new IntersectionObserver((Q) => {
        const C = Q[Q.length - 1];
        C && (t.value = C.isIntersecting);
      }), h.observe(O);
    },
    { immediate: !0 }
  ), Le(
    e.code,
    () => {
      i.value = null, a.value = e.lines.value, l.value += 1;
    },
    { flush: "sync" }
  );
  const H = B(
    () => {
      var O;
      return ((O = e.coarsePointerOverride) == null ? void 0 : O.value) ?? n.value;
    }
  ), ee = B(
    () => e.focused.value || c.value
  ), y = B(
    () => {
      var O;
      return ra(e.wrap.value, (O = e.hostWrap) == null ? void 0 : O.value);
    }
  ), P = B(
    () => t.value && (e.hovered.value || ee.value || H.value || o.value.length > 0)
  ), Z = B(() => {
    var J;
    const O = a.value, Q = e.code.value.length, C = e.language.value, R = y.value, D = e.wrapAlignmentSupported.value, X = (J = e.budget) == null ? void 0 : J.value, Y = {
      lines: O,
      characterCount: Q,
      language: C,
      effectiveWrap: R,
      wrapAlignmentSupported: D,
      budget: X
    };
    return p += 1, {
      key: [
        ma,
        l.value,
        (C == null ? void 0 : C.trim().toLowerCase()) ?? "",
        R,
        ca(X),
        D ? "wrap-supported" : "wrap-unsupported"
      ].join("\0"),
      input: Y,
      decision: la({
        ...Y,
        visible: !0,
        blockCollapsed: !1,
        foldingRequested: !0
      })
    };
  }), se = B(() => (Z.value, p)), ie = B(() => ({
    ...Z.value.input,
    visible: t.value,
    blockCollapsed: e.blockCollapsed.value,
    foldingRequested: P.value
  })), je = B(
    () => f(e.code.value)
  ), oe = B(() => {
    const O = ie.value, Q = Z.value.key, C = i.value;
    if ((C == null ? void 0 : C.key) === Q && C.result.decision.status === "disabled")
      return C.result;
    const R = Z.value.decision, D = R.status !== "enabled" ? R : O.visible ? O.blockCollapsed ? {
      status: "deferred",
      reason: "block-collapsed",
      metrics: R.metrics
    } : O.foldingRequested ? R : {
      status: "deferred",
      reason: "gutter-not-requested",
      metrics: R.metrics
    } : {
      status: "deferred",
      reason: "not-visible",
      metrics: R.metrics
    };
    if (D.status !== "enabled") {
      const Y = da(D);
      return D.status === "disabled" && (i.value = { key: Q, result: Y }), Y;
    }
    if ((C == null ? void 0 : C.key) === Q) return C.result;
    m.value += 1;
    const X = g(O);
    return i.value = { key: Q, result: X }, X;
  }), q = B(
    () => oe.value.decision.status === "enabled" && oe.value.scanStatus === "complete" ? on(o.value, oe.value.ranges) : []
  ), le = B(
    () => q.value.some((O) => O.state === "active")
  ), de = B(
    () => an({
      lines: a.value,
      lineNumbers: e.lineNumbers.value,
      lineOffsets: le.value ? je.value : void 0,
      ranges: oe.value.decision.status === "enabled" ? oe.value.ranges : [],
      activeIntents: q.value
    })
  ), ve = B(
    () => de.value.some((O) => O.folded)
  ), ge = B(() => {
    const O = oe.value;
    if (e.blockCollapsed.value) return "none";
    if (O.decision.status === "disabled" && O.decision.reason === "wrap-unsupported")
      return e.showLineNumbers.value ? "numbers" : "none";
    const Q = O.decision.status === "enabled" && O.ranges.length > 0;
    return e.showLineNumbers.value && Q ? "numbers-and-folds" : e.showLineNumbers.value ? "numbers" : t.value && (Q || O.decision.status === "enabled" || O.decision.status === "deferred" && O.decision.reason === "gutter-not-requested") ? "folds" : "none";
  }), G = () => {
    o.value = [];
  }, k = () => {
    const O = e.canonicalContentRef.value;
    return !!(O && O.style.display !== "none" && O.getAttribute("aria-hidden") !== "true");
  }, $ = async (O, Q) => {
    var C;
    await Me(), !(d.value || Q !== x || !k() || O > e.code.value.length) && ((C = e.restoreCanonicalFocus) == null || C.call(e, O));
  }, ae = () => {
    if (typeof document > "u") return e.focused.value;
    const O = document.activeElement, Q = e.bodyRef.value;
    return !O || O === document.body ? e.focused.value : Q != null && Q.contains(O) ? !0 : Q && O.contains(Q) ? e.focused.value : !1;
  };
  Le(
    oe,
    (O) => {
      var X;
      if (O.decision.status === "enabled" && O.scanStatus === "complete") {
        r.value = O;
        const Y = on(o.value, O.ranges);
        Ol(o.value, Y) || (o.value = Y);
        return;
      }
      if (O.decision.status !== "disabled" || o.value.length === 0)
        return;
      const Q = r.value, R = ((X = (Q ? an({
        lines: a.value,
        lineNumbers: e.lineNumbers.value,
        lineOffsets: je.value,
        ranges: Q.ranges,
        activeIntents: o.value
      }) : []).find((Y) => Y.folded)) == null ? void 0 : X.fromOffset) ?? 0, D = ae();
      if (G(), D && e.restoreCanonicalFocus) {
        const Y = ++x;
        $(R, Y);
      }
    },
    { immediate: !0 }
  );
  const ue = (O) => {
    const Q = oe.value;
    Q.decision.status !== "enabled" || Q.scanStatus !== "complete" || (o.value = pa({
      previous: o.value,
      ranges: Q.ranges,
      rangeKey: O
    }));
  }, he = (O) => {
    if (M) return M;
    const Q = Math.floor(O.offset);
    if (!Number.isFinite(Q) || Q < 0 || Q > e.code.value.length)
      return Promise.resolve("cancelled");
    b = Nl({ ...O, offset: Q });
    const C = ++x;
    M = (async () => (G(), await Me(), d.value || C !== x || Q > e.code.value.length || !k() ? (b = null, "cancelled") : "ready"))();
    const R = () => {
      C === x && (M = null);
    };
    return M.then(R, R), M;
  }, ce = () => {
    const O = b;
    return b = null, O;
  }, fe = () => {
    var O;
    d.value || (d.value = !0, x += 1, b = null, M = null, G(), i.value = null, r.value = null, j(), z(), (O = v == null ? void 0 : v.removeEventListener) == null || O.call(v, "change", F), v = null);
  };
  return qn(fe), {
    decision: B(() => oe.value.decision),
    diagnostics: B(() => oe.value.diagnostics),
    effectiveWrap: y,
    displayedRows: de,
    hasActiveFolds: ve,
    gutterMode: ge,
    visible: t,
    coarsePointer: H,
    focusedWithin: ee,
    resolverCallCount: m,
    staticPolicyEvaluationCount: se,
    toggleFold: ue,
    prepareForLocalEdit: he,
    consumePreparedLocalEdit: ce,
    clearFolds: G,
    cleanup: fe
  };
}, zl = ["aria-label", "onClick"], Fl = ["aria-label"], Hl = ["value", "placeholder"], Vl = ["value", "placeholder"], ql = ["value"], Wl = ["value", "placeholder"], Ul = ["value"], Kl = ["value"], Xl = ["value"], Gl = ["value", "placeholder"], Zl = ["checked"], Yl = ["checked"], Jl = ["checked"], Ql = ["hidden", "aria-hidden", "data-zx-folding-decision", "data-zx-folding-reason"], em = ["hidden", "aria-hidden"], tm = ["value", "placeholder", "disabled"], Cn = 20, nm = 8, om = 1500, am = /* @__PURE__ */ Ce({
  __name: "code-block-component",
  props: kt,
  setup(e) {
    const t = Ee("code-block"), { text: n, format: a } = Ve(), o = e, i = B(() => o.node), r = B(
      () => o.editor.extensionManager.extensions.find(
        (I) => I.name === "codeBlock"
      )
    ), m = B(
      () => {
        var I, T;
        return ((T = (I = r.value) == null ? void 0 : I.options) == null ? void 0 : T.codeBlockPreferences) ?? null;
      }
    ), l = A(!1), c = A(!1), d = A(!1), g = A(!1), f = A(!1), p = A(null), h = A([]), v = A(null), L = A(null), x = A(!1), M = A(null);
    let b = !1, j = 0;
    const w = A(o.editor.isEditable), V = () => {
      const I = o.editor.isEditable;
      I !== w.value && (w.value = I, I || (g.value = !1, p.value = null));
    }, z = gi({ wrap: null, collapsed: null }), F = () => {
      const I = ++j;
      Me(() => {
        !b && I === j && o.editor.view.focus();
      });
    }, H = B(() => i.value.textContent || ""), ee = B(() => {
      const I = i.value.attrs;
      return w.value ? I : {
        ...I,
        ...z.wrap === null ? {} : { wrap: z.wrap },
        ...z.collapsed === null ? {} : { collapsed: z.collapsed }
      };
    }), y = B(
      () => Ii({
        code: H.value,
        attrs: ee.value
      })
    ), P = B(() => Fi(y.value)), Z = B(
      () => P.value.body.filenamePlaceholder ? n(
        "codeBlock:filename.placeholder",
        P.value.body.filenamePlaceholder
      ) : ""
    ), se = B(
      () => P.value.body.captionPlaceholder ? n(
        "codeBlock:caption.placeholder",
        P.value.body.captionPlaceholder
      ) : ""
    ), ie = (I) => {
      const T = o.getPos();
      if (typeof T != "number") return;
      const ne = T + 1, be = ne + H.value.length, re = Math.min(
        be,
        Math.max(ne, ne + Math.floor(I))
      ), xe = o.editor.state.tr.setSelection(
        Xe.create(o.editor.state.doc, re)
      );
      o.editor.view.dispatch(xe), F();
    }, je = A(!1), oe = $l({
      code: H,
      lines: B(() => y.value.lines.visualLines),
      lineNumbers: B(() => y.value.lines.lineNumbers),
      language: B(() => y.value.attrs.language),
      wrap: B(() => y.value.attrs.wrap),
      blockCollapsed: B(() => y.value.attrs.collapsed),
      showLineNumbers: B(() => y.value.attrs.showLineNumbers),
      hovered: l,
      focused: c,
      bodyRef: v,
      canonicalContentRef: L,
      wrapAlignmentSupported: je,
      restoreCanonicalFocus: ie
    }), {
      coarsePointer: q,
      decision: le,
      diagnostics: de,
      displayedRows: ve,
      effectiveWrap: ge,
      focusedWithin: G,
      gutterMode: k,
      hasActiveFolds: $,
      toggleFold: ae
    } = oe, ue = B(
      () => fa(H.value, y.value.attrs)
    ), he = B(
      () => ga({
        mode: y.value.attrs.copyMode,
        scope: "current-tab",
        block: ue.value
      })
    ), ce = B(() => {
      var I;
      return [
        ...P.value.diagnostics,
        ...he.value.diagnostics,
        ...((I = p.value) == null ? void 0 : I.diagnostics) ?? [],
        ...h.value,
        ...de.value
      ];
    }), fe = B(() => {
      var I;
      switch ((I = p.value) == null ? void 0 : I.status) {
        case "success":
          return n("codeBlock:suggestion.success", "Detected language");
        case "low-confidence":
          return n(
            "codeBlock:suggestion.lowConfidence",
            "Language could not be determined"
          );
        case "empty":
          return n("codeBlock:suggestion.empty", "No code to detect");
        case "unsupported":
          return n(
            "codeBlock:suggestion.unsupported",
            "Detected language cannot be highlighted"
          );
        default:
          return n(
            "codeBlock:suggestion.unavailable",
            "Language detection unavailable"
          );
      }
    }), we = B(
      () => ha(y.value.attrs.highlightLines)
    ), O = A(""), Q = B(() => {
      const I = /* @__PURE__ */ new Set();
      return y.value.attrs.highlightLines.forEach((T) => {
        const ne = T.to ?? T.from;
        for (let be = T.from; be <= ne; be += 1)
          I.add(y.value.attrs.startLine + be - 1);
      }), I;
    }), C = (I, T = {}) => {
      if (!w.value) return;
      const ne = o.getPos();
      typeof ne == "number" && (o.editor.commands.updateCodeBlockV2AttrsAt(ne, I), (T.restoreFocus ?? !0) && Me(() => {
        o.editor.commands.focus();
      }));
    }, R = B(() => {
      const I = M.value ?? y.value.display.height, T = {};
      return P.value.body.collapsed ? (T.maxHeight = `calc(${P.value.body.previewTo} * 20px + 16px)`, T.overflow = "hidden", T) : y.value.display.heightMode === "auto" ? (P.value.body.maxBodyHeight && (T.maxHeight = P.value.body.maxBodyHeight, T.overflow = "auto"), T) : typeof I == "number" && Number.isFinite(I) ? (T.height = `${I}px`, T) : (T.maxHeight = P.value.body.maxBodyHeight ?? "320px", T.overflow = "auto", T);
    }), D = B(() => ({
      whiteSpace: ge.value === "on" ? "pre-wrap" : "pre"
    })), X = A(null);
    let Y = !1, J = null;
    const me = () => ge.value === "on" && k.value === "numbers" && !$.value && !P.value.body.collapsed, Ie = () => {
      if (Y = !1, b || !me()) {
        X.value = null;
        return;
      }
      const I = o.getPos(), T = L.value;
      if (typeof I != "number" || !T) {
        X.value = null;
        return;
      }
      const ne = Dn(H.value);
      if (ne.length > om) {
        X.value = null;
        return;
      }
      try {
        const be = I + 1, re = ne.map(
          (Se) => o.editor.view.coordsAtPos(be + Se).top
        ), xe = T.getBoundingClientRect().bottom - nm;
        X.value = re.map((Se, Je) => {
          const dt = Je + 1 < re.length ? re[Je + 1] : xe, at = Math.round((dt - Se) / Cn);
          return Math.max(1, at) * Cn;
        });
      } catch {
        X.value = null;
      }
    }, pe = () => {
      Y || b || (Y = !0, typeof requestAnimationFrame == "function" ? requestAnimationFrame(Ie) : setTimeout(Ie, 16));
    };
    Le(
      [
        ge,
        k,
        $,
        H,
        () => P.value.body.collapsed
      ],
      () => {
        me() ? pe() : X.value = null;
      },
      { flush: "post" }
    );
    const Ye = () => {
      const I = o.getPos();
      if (typeof I != "number") return;
      const { selection: T } = o.editor.state, ne = T.from, be = T.to, re = I, xe = I + o.node.nodeSize;
      c.value = ne >= re && be <= xe, ne > re && be < xe && P.value.body.collapsed && w.value && o.editor.commands.setNodeSelection(I);
    }, Wt = () => {
      V();
    }, go = (I) => {
      C({ language: I });
    }, Ut = (I) => {
      C({ filename: I }, { restoreFocus: !1 });
    }, ho = (I) => {
      Ut(I.target.value);
    }, Kt = (I) => {
      C(
        { caption: I.target.value },
        { restoreFocus: !1 }
      );
    }, Xt = (I) => {
      if (!w.value) {
        z.collapsed = I;
        return;
      }
      const T = { collapsed: I };
      if (I && y.value.attrs.previewLines === null && (T.previewLines = Ln.longCodePreviewLines), C(T), I) {
        const ne = o.getPos();
        typeof ne == "number" && Me(() => o.editor.commands.setNodeSelection(ne));
      }
    }, Gt = () => {
      Xt(!P.value.body.collapsed);
    }, jo = (I) => {
      var dt;
      const T = o.getPos();
      if (typeof T != "number" || !w.value) return;
      const ne = T + 1, be = H.value.length, re = Math.min(be, Math.max(0, I.offset)), xe = ne + re, Se = o.editor.state.tr;
      let Je = xe;
      switch ((dt = I.pendingEdit) == null ? void 0 : dt.type) {
        case "insert-text":
        case "insert-plain-text": {
          const at = I.pendingEdit.text;
          at && (Se.insertText(at, xe, xe), Je += at.length);
          break;
        }
        case "delete-backward":
          re > 0 && (Se.delete(xe - 1, xe), Je -= 1);
          break;
        case "delete-forward":
          re < be && Se.delete(xe, xe + 1);
          break;
      }
      Se.setSelection(
        Xe.create(Se.doc, Je)
      ), o.editor.view.dispatch(Se), F();
    }, vo = async (I) => {
      if (!w.value || await oe.prepareForLocalEdit(I) !== "ready") return;
      const ne = oe.consumePreparedLocalEdit();
      ne && jo(ne);
    }, bo = () => {
      const T = y.value.attrs.wrap === "on" ? "off" : "on";
      if (!w.value) {
        z.wrap = T;
        return;
      }
      C({ wrap: T });
    }, _o = () => {
      C({ showLineNumbers: !y.value.attrs.showLineNumbers });
    }, yo = () => {
      w.value && (g.value = !g.value);
    }, wo = (I) => {
      d.value = I;
    }, ko = (I) => {
      C({
        startLine: Number(I.target.value)
      });
    }, Co = (I) => {
      const T = I.target.value;
      C({ previewLines: T ? Number(T) : null });
    }, xo = (I) => {
      C({
        copyMode: I.target.value
      });
    }, Eo = (I) => {
      const T = I.target.value.trim();
      C({ groupId: T || null }, { restoreFocus: !1 });
    }, Lo = (I) => {
      C(
        { tabLabel: I.target.value },
        { restoreFocus: !1 }
      );
    }, To = (I) => {
      O.value = I.target.value;
    }, Zt = (I, T) => {
      const ne = T === "clear" ? [] : I, be = ba({
        currentRanges: y.value.attrs.highlightLines,
        edit: {
          ranges: ne,
          mode: T
        },
        lineCount: _a(H.value),
        interactive: !0
      });
      h.value = be.diagnostics, be.patch && C(be.patch, { restoreFocus: !1 });
    }, Io = (I, T) => {
      O.value = I.target.value;
      const ne = sn(
        I.target.value
      );
      Zt(ne, T);
    }, ct = (I) => {
      const T = O.value || we.value;
      Zt(sn(T), I);
    }, So = (I) => {
      C({
        wrap: I.target.checked ? "on" : "off"
      });
    }, Ao = (I) => {
      C({
        showLineNumbers: I.target.checked
      });
    }, Po = (I) => {
      Xt(I.target.checked);
    }, Yt = async () => {
      if (!(!w.value || f.value)) {
        f.value = !0, h.value = [];
        try {
          const I = await ja({
            code: H.value,
            currentLanguage: y.value.attrs.language
          });
          b || (p.value = I);
        } finally {
          f.value = !1;
        }
      }
    }, Mo = () => {
      p.value = null;
    }, Bo = (I) => {
      if (!p.value) return;
      const T = va(p.value, I);
      T && (C(T), p.value = null);
    }, Do = () => {
      if (!w.value || y.value.attrs.language !== null) return;
      const I = Pn(
        o.editor.storage.codeBlock
      );
      I != null && I.consume(H.value) && Yt();
    };
    let Jt = 0, xt = 0, Qt = 0;
    const Ro = (I) => {
      if (!w.value) return;
      I.preventDefault(), x.value = !0, Jt = I.clientY;
      const T = v.value;
      xt = (T == null ? void 0 : T.offsetHeight) || 0, Qt = T && Number.parseFloat(window.getComputedStyle(T).minHeight) || 0, M.value = xt, window.addEventListener("mousemove", Et), window.addEventListener("mouseup", Lt), document.body.style.cursor = "ns-resize";
    }, Et = (I) => {
      if (!x.value) return;
      const T = I.clientY - Jt, ne = Math.max(Qt, xt + T);
      M.value = ne;
    }, Lt = () => {
      if (!x.value) return;
      x.value = !1, window.removeEventListener("mousemove", Et), window.removeEventListener("mouseup", Lt), document.body.style.cursor = "";
      const I = M.value;
      M.value = null, typeof I == "number" && Number.isFinite(I) && C({ height: I, heightMode: "fixed" });
    };
    return He(() => {
      V(), Ye(), o.editor.on("selectionUpdate", Ye), o.editor.on("transaction", Wt), Do(), typeof ResizeObserver == "function" && v.value && (J = new ResizeObserver(() => {
        me() && pe();
      }), J.observe(v.value), L.value && J.observe(L.value)), me() && pe();
    }), ze(() => {
      b = !0, j += 1, oe.cleanup(), o.editor.off("selectionUpdate", Ye), o.editor.off("transaction", Wt), J == null || J.disconnect(), J = null, window.removeEventListener("mousemove", Et), window.removeEventListener("mouseup", Lt), document.body.style.cursor = "";
    }), (I, T) => (E(), ke(s(ot), {
      as: "div",
      class: u([
        s(t).b(),
        s(t).is("collapsed", P.value.body.collapsed),
        s(t).is("empty", P.value.body.isEmpty),
        s(t).is("long", P.value.body.isLong),
        s(t).is("hovered", l.value || d.value || g.value),
        s(t).is("focused", s(G)),
        s(t).is("coarse-pointer", s(q)),
        s(t).is("wrap-on", s(ge) === "on"),
        s(t).is("wrap-off", s(ge) === "off"),
        s(t).is("readonly", !w.value)
      ]),
      "data-zx-code-contract-version": y.value.attrs.contractVersion,
      "data-zx-code-language": P.value.header.language || "plaintext",
      onMouseenter: T[21] || (T[21] = (ne) => l.value = !0),
      onMouseleave: T[22] || (T[22] = (ne) => l.value = !1)
    }, {
      default: _e(() => {
        var ne, be;
        return [
          U(Rl, {
            language: P.value.header.language,
            "language-label": P.value.header.languageLabel,
            title: P.value.header.filename,
            collapsed: P.value.body.collapsed,
            "code-content": P.value.copy.text,
            "copy-content": he.value.text,
            "copy-mode": y.value.attrs.copyMode,
            wrap: P.value.body.wrap,
            "show-line-numbers": P.value.body.showLineNumbers,
            "can-copy-plain": P.value.header.canCopyPlain,
            "can-copy-markdown": he.value.status !== "failed",
            "copy-disabled-reason": P.value.header.copyDisabledReason,
            "settings-open": g.value,
            "detecting-language": f.value,
            editable: w.value,
            "recent-languages": ((ne = m.value) == null ? void 0 : ne.recentLanguages) ?? [],
            "default-language": ((be = m.value) == null ? void 0 : be.defaultLanguage) ?? null,
            "onUpdate:language": go,
            "onUpdate:title": Ut,
            onToggleCollapse: Gt,
            onToggleWrap: bo,
            onToggleLineNumbers: _o,
            onToggleSettings: yo,
            onDetectLanguage: Yt,
            onDropdownVisibleChange: wo
          }, null, 8, ["language", "language-label", "title", "collapsed", "code-content", "copy-content", "copy-mode", "wrap", "show-line-numbers", "can-copy-plain", "can-copy-markdown", "copy-disabled-reason", "settings-open", "detecting-language", "editable", "recent-languages", "default-language"]),
          p.value ? (E(), S("div", {
            key: 0,
            class: u(s(t).e("suggestion")),
            contenteditable: "false",
            role: "status",
            "aria-live": "polite",
            "data-zx-code-language-suggestion": "true"
          }, [
            _("span", {
              class: u(s(t).e("suggestion-title"))
            }, W(fe.value), 3),
            p.value.status === "success" ? (E(!0), S(ye, { key: 0 }, Be(p.value.candidates, (re, xe) => (E(), S("button", {
              key: `${re.language}:${xe}`,
              class: u(s(t).e("suggestion-option")),
              type: "button",
              "aria-label": s(a)("codeBlock:suggestion.apply", "Use {language}", {
                language: s(Bt)(re.language)
              }),
              onMousedown: T[0] || (T[0] = N(() => {
              }, ["prevent"])),
              onClick: (Se) => Bo(xe)
            }, [
              _("span", null, W(s(Bt)(re.language)), 1),
              _("span", {
                class: u(s(t).e("suggestion-confidence"))
              }, W(Math.round(re.confidence * 100)) + "% ", 3)
            ], 42, zl))), 128)) : K("", !0),
            _("button", {
              class: u(s(t).e("suggestion-dismiss")),
              type: "button",
              onMousedown: T[1] || (T[1] = N(() => {
              }, ["prevent"])),
              onClick: Mo
            }, W(s(n)("codeBlock:suggestion.dismiss", "Dismiss")), 35)
          ], 2)) : K("", !0),
          g.value && w.value ? (E(), S("div", {
            key: 1,
            class: u(s(t).e("settings")),
            contenteditable: "false",
            role: "dialog",
            "aria-label": s(n)("codeBlock:settings", "Code block settings"),
            onKeydown: T[19] || (T[19] = $e(N((re) => g.value = !1, ["stop", "prevent"]), ["esc"]))
          }, [
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.filename", "File name")), 3),
              _("input", {
                value: y.value.attrs.filename,
                placeholder: Z.value,
                class: u(s(t).e("settings-input")),
                onMousedown: T[2] || (T[2] = N(() => {
                }, ["stop"])),
                onInput: ho
              }, null, 42, Hl)
            ], 2),
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.caption", "Caption")), 3),
              _("input", {
                value: y.value.attrs.caption,
                placeholder: se.value,
                class: u(s(t).e("settings-input")),
                onMousedown: T[3] || (T[3] = N(() => {
                }, ["stop"])),
                onInput: Kt
              }, null, 42, Vl)
            ], 2),
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.startLine", "Start line")), 3),
              _("input", {
                value: y.value.attrs.startLine,
                class: u(s(t).e("settings-input")),
                type: "number",
                min: "1",
                step: "1",
                onMousedown: T[4] || (T[4] = N(() => {
                }, ["stop"])),
                onChange: ko
              }, null, 42, ql)
            ], 2),
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.previewLines", "Preview lines")), 3),
              _("input", {
                value: y.value.attrs.previewLines ?? "",
                class: u(s(t).e("settings-input")),
                type: "number",
                min: "1",
                step: "1",
                placeholder: s(n)("codeBlock:settings.previewLines.all", "All"),
                onMousedown: T[5] || (T[5] = N(() => {
                }, ["stop"])),
                onChange: Co
              }, null, 42, Wl)
            ], 2),
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.copyMode", "Copy mode")), 3),
              _("select", {
                value: y.value.attrs.copyMode,
                class: u([s(t).e("settings-input"), s(t).e("settings-select")]),
                onMousedown: T[6] || (T[6] = N(() => {
                }, ["stop"])),
                onChange: xo
              }, [...T[23] || (T[23] = [
                _("option", { value: "plain" }, "Plain text", -1),
                _("option", { value: "markdown" }, "Markdown", -1)
              ])], 42, Ul)
            ], 2),
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.groupId", "Tabs group")), 3),
              _("input", {
                value: y.value.attrs.groupId ?? "",
                class: u(s(t).e("settings-input")),
                placeholder: "groupId",
                onMousedown: T[7] || (T[7] = N(() => {
                }, ["stop"])),
                onInput: Eo
              }, null, 42, Kl)
            ], 2),
            _("label", {
              class: u(s(t).e("settings-field"))
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.tabLabel", "Tab label")), 3),
              _("input", {
                value: y.value.attrs.tabLabel,
                class: u(s(t).e("settings-input")),
                placeholder: "tabLabel",
                onMousedown: T[8] || (T[8] = N(() => {
                }, ["stop"])),
                onInput: Lo
              }, null, 42, Xl)
            ], 2),
            _("label", {
              class: u([s(t).e("settings-field"), s(t).is("wide")])
            }, [
              _("span", {
                class: u(s(t).e("settings-label"))
              }, W(s(n)("codeBlock:settings.highlightLines", "Highlight lines")), 3),
              _("input", {
                value: we.value,
                class: u(s(t).e("settings-input")),
                placeholder: s(n)("codeBlock:settings.highlightLines.placeholder", "e.g. 1, 3-5"),
                onMousedown: T[9] || (T[9] = N(() => {
                }, ["stop"])),
                onInput: To,
                onChange: T[10] || (T[10] = (re) => Io(re, "replace"))
              }, null, 42, Gl)
            ], 2),
            _("div", {
              class: u([s(t).e("settings-actions"), s(t).is("wide")])
            }, [
              _("button", {
                type: "button",
                onMousedown: T[11] || (T[11] = N(() => {
                }, ["prevent"])),
                onClick: T[12] || (T[12] = (re) => ct("replace"))
              }, W(s(n)("codeBlock:settings.set", "Set")), 33),
              _("button", {
                type: "button",
                onMousedown: T[13] || (T[13] = N(() => {
                }, ["prevent"])),
                onClick: T[14] || (T[14] = (re) => ct("add"))
              }, W(s(n)("codeBlock:settings.add", "Add")), 33),
              _("button", {
                type: "button",
                onMousedown: T[15] || (T[15] = N(() => {
                }, ["prevent"])),
                onClick: T[16] || (T[16] = (re) => ct("remove"))
              }, W(s(n)("codeBlock:settings.remove", "Remove")), 33),
              _("button", {
                type: "button",
                onMousedown: T[17] || (T[17] = N(() => {
                }, ["prevent"])),
                onClick: T[18] || (T[18] = (re) => ct("clear"))
              }, W(s(n)("codeBlock:settings.clear", "Clear")), 33)
            ], 2),
            _("div", {
              class: u(s(t).e("settings-checks"))
            }, [
              _("label", {
                class: u(s(t).e("settings-check"))
              }, [
                _("input", {
                  type: "checkbox",
                  checked: y.value.attrs.wrap === "on",
                  onChange: So
                }, null, 40, Zl),
                _("span", null, W(s(n)("codeBlock:settings.wrap", "Wrap lines")), 1)
              ], 2),
              _("label", {
                class: u(s(t).e("settings-check"))
              }, [
                _("input", {
                  type: "checkbox",
                  checked: y.value.attrs.showLineNumbers,
                  onChange: Ao
                }, null, 40, Yl),
                _("span", null, W(s(n)("codeBlock:settings.lineNumbers", "Show line numbers")), 1)
              ], 2),
              _("label", {
                class: u(s(t).e("settings-check"))
              }, [
                _("input", {
                  type: "checkbox",
                  checked: y.value.attrs.collapsed,
                  onChange: Po
                }, null, 40, Jl),
                _("span", null, W(s(n)("codeBlock:settings.collapsed", "Collapse code block")), 1)
              ], 2)
            ], 2),
            ce.value.length ? (E(), S("div", {
              key: 0,
              class: u(s(t).e("diagnostics"))
            }, [
              (E(!0), S(ye, null, Be(ce.value, (re) => (E(), S("div", {
                key: `${re.code}:${re.path}`,
                class: u(s(t).e("diagnostic"))
              }, W(re.message), 3))), 128))
            ], 2)) : K("", !0)
          ], 42, Fl)) : K("", !0),
          tt(_("div", {
            ref_key: "bodyRef",
            ref: v,
            class: u(s(t).e("body")),
            style: Pe(R.value),
            hidden: P.value.body.collapsed,
            "aria-hidden": P.value.body.collapsed,
            "data-zx-folding-decision": s(le).status,
            "data-zx-folding-reason": s(le).reason
          }, [
            s(k) !== "none" ? (E(), ke(El, {
              key: 0,
              mode: s(k),
              rows: s(ve),
              "highlighted-line-numbers": Q.value,
              "row-heights": X.value,
              onToggleFold: s(ae)
            }, null, 8, ["mode", "rows", "highlighted-line-numbers", "row-heights", "onToggleFold"])) : K("", !0),
            tt(_("pre", {
              ref_key: "canonicalContentRef",
              ref: L,
              class: u(s(t).e("pre")),
              hidden: s($),
              "aria-hidden": s($),
              "data-zx-code-canonical-content": "true"
            }, [
              U(s(Un), {
                as: "code",
                class: u(s(t).e("code")),
                style: Pe(D.value)
              }, null, 8, ["class", "style"])
            ], 10, em), [
              [cn, !s($)]
            ]),
            s($) ? (E(), ke(kl, {
              key: 1,
              rows: s(ve),
              code: H.value,
              language: y.value.attrs.language,
              onToggleFold: s(ae),
              onRequestEdit: vo
            }, null, 8, ["rows", "code", "language", "onToggleFold"])) : K("", !0),
            P.value.body.codePlaceholder ? (E(), S("div", {
              key: 2,
              class: u(s(t).e("empty-state")),
              contenteditable: "false"
            }, [
              _("span", null, W(s(n)("codeBlock:placeholder", P.value.body.codePlaceholder ?? "")), 1),
              _("span", {
                class: u(s(t).e("empty-state-meta"))
              }, W(P.value.header.languageLabel), 3)
            ], 2)) : K("", !0)
          ], 14, Ql), [
            [cn, !P.value.body.collapsed]
          ]),
          P.value.body.collapsed ? (E(), ke(hl, {
            key: 2,
            lines: P.value.body.visibleVisualLines,
            "line-numbers": P.value.body.visibleLineNumbers,
            "total-line-count": P.value.body.visualLineCount,
            "show-line-numbers": P.value.body.showLineNumbers,
            onRequestExpand: Gt
          }, null, 8, ["lines", "line-numbers", "total-line-count", "show-line-numbers"])) : K("", !0),
          w.value || P.value.header.caption ? (E(), S("label", {
            key: 3,
            class: u(s(t).e("caption")),
            contenteditable: "false"
          }, [
            _("span", {
              class: u(s(t).e("caption-label"))
            }, W(s(n)("codeBlock:caption", "Caption")), 3),
            _("input", {
              value: P.value.header.caption,
              class: u(s(t).e("caption-input")),
              placeholder: se.value,
              disabled: !w.value,
              onMousedown: T[20] || (T[20] = N(() => {
              }, ["stop"])),
              onInput: Kt
            }, null, 42, tm)
          ], 2)) : K("", !0),
          !P.value.body.collapsed && w.value ? (E(), S("div", {
            key: 4,
            class: u([
              s(t).e("resize-handle"),
              s(t).is("visible", l.value || s(G))
            ]),
            contenteditable: "false",
            onMousedown: N(Ro, ["prevent"])
          }, [
            _("div", {
              class: u(s(t).e("resize-bar"))
            }, null, 2)
          ], 34)) : K("", !0)
        ];
      }),
      _: 1
    }, 8, ["class", "data-zx-code-contract-version", "data-zx-code-language"]));
  }
}), Mt = " ".repeat(4), im = new RegExp("(?<=^|[^`])`([^`]+)`(?!`)$"), sm = /^(```|~~~)([a-zA-Z0-9#+.-]*)[\s\n]$/;
function xn(e) {
  const { $from: t, from: n, to: a } = e.selection;
  let o = t.depth;
  for (; o > 0 && t.node(o).type.name !== "codeBlock"; ) o--;
  if (o === 0) return null;
  const i = t.node(o), r = t.start(o), m = i.textContent, l = n - r, c = a - r;
  return { start: r, text: m, fromOffset: l, toOffset: c };
}
function En(e, t, n) {
  const a = e.lastIndexOf(`
`, Math.max(0, t - 1)) + 1;
  let o = n;
  o > 0 && e[o - 1] === `
` && o--;
  const i = [a];
  let r = a;
  for (; ; ) {
    const m = e.indexOf(`
`, r);
    if (m === -1 || m >= o) break;
    i.push(m + 1), r = m + 1;
  }
  return i;
}
const rm = Mn(Bn), lm = Ei.extend({
  addOptions() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      codeBlockPreferences: null
    };
  },
  addStorage() {
    return {
      pendingLanguageDetection: Ia()
    };
  },
  addAttributes() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      ...Ta()
    };
  },
  addCommands() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      updateCodeBlockV2Attrs: La(),
      updateCodeBlockV2AttrsAt: Ea(),
      updateCodeBlockV2AttrsById: xa(),
      applyCodeBlockBulkPreview: Ca(),
      applyCodeBlockTabEditPatches: ka(),
      reorderCodeBlockTabById: wa()
    };
  },
  addNodeView() {
    return Ze(am);
  },
  addInputRules() {
    var e;
    return [
      zo({
        find: sm,
        type: this.type,
        getAttributes: (t) => ya({
          language: t[2] || null,
          preferences: this.options.codeBlockPreferences,
          source: "markdown-fence"
        }).attrs
      }),
      ...((e = this.parent) == null ? void 0 : e.call(this)) ?? []
    ];
  },
  addKeyboardShortcuts() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      Tab: () => {
        const { state: t, dispatch: n } = this.editor.view, a = xn(t);
        if (!a) return !1;
        const { start: o, text: i, fromOffset: r, toOffset: m } = a, l = i.slice(r, m).includes(`
`), c = t.tr;
        if (l)
          for (const d of En(i, r, m)) {
            const g = c.mapping.map(o + d);
            c.insertText(Mt, g);
          }
        else
          c.insertText(Mt, t.selection.from);
        return n(c), !0;
      },
      "Shift-Tab": () => {
        const { state: t, dispatch: n } = this.editor.view, a = xn(t);
        if (!a) return !1;
        const { start: o, text: i, fromOffset: r, toOffset: m } = a, l = t.tr;
        for (const c of En(i, r, m)) {
          let d = 0;
          if (i.slice(c, c + 4) === Mt ? d = 4 : i[c] === "	" && (d = 1), d > 0) {
            const g = l.mapping.map(o + c), f = l.mapping.map(o + c + d);
            l.delete(g, f);
          }
        }
        return n(l), !0;
      },
      // Mod-a progressive selection is owned by TextEditorShortcutKeymap
      // (catalog textEditor.progressiveSelect). Do not re-register here.
      "Mod-Enter": () => {
        const { state: t, dispatch: n } = this.editor.view, { selection: a } = t, { $from: o } = a;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "codeBlock"; )
          i--;
        if (i === 0)
          return wn(t, n);
        const r = o.before(i), m = o.node(i), l = r + m.nodeSize, d = t.doc.resolve(l).nodeAfter;
        if ((d == null ? void 0 : d.type.name) === "paragraph" && d.content.size === 0) {
          const g = t.tr.setSelection(
            Xe.create(t.doc, l + 1)
          );
          return n(g.scrollIntoView()), !0;
        }
        return wn(t, n);
      },
      "`": () => {
        const { from: t, to: n } = this.editor.state.selection;
        return t === n ? !1 : this.editor.commands.toggleCode();
      }
    };
  }
}).configure({ lowlight: rm }), mm = Li.extend({
  addKeyboardShortcuts() {
    return {
      "Mod-e": () => this.editor.commands.toggleCode(),
      "`": () => {
        const { from: e, to: t } = this.editor.state.selection;
        return e === t ? !1 : this.editor.commands.toggleCode();
      }
    };
  },
  addInputRules() {
    return [
      $o({
        find: im,
        type: this.type
      })
    ];
  }
}), cm = Si.extend({
  addProseMirrorPlugins() {
    this.options.key == null && (this.options.key = "Mod");
    const e = this.parent;
    return (e == null ? void 0 : e.call(this)) ?? [];
  },
  addKeyboardShortcuts() {
    const e = this.parent, n = { ...(e == null ? void 0 : e.call(this)) ?? {} };
    return delete n["Mod-a"], n;
  }
}), dm = (e) => [e.name, e.type, e.size, e.lastModified].join("::"), um = (e) => {
  var a;
  if ((a = e == null ? void 0 : e.files) != null && a.length)
    return [];
  const t = [], n = /* @__PURE__ */ new Set();
  return Array.from((e == null ? void 0 : e.items) ?? []).forEach((o) => {
    if (o.kind !== "file")
      return;
    const i = o.getAsFile();
    if (!i)
      return;
    const r = dm(i);
    n.has(r) || (n.add(r), t.push(i));
  }), t;
}, pm = (e, t, n) => {
  e && (Rn("text-editor:file-intake", "drop files captured", {
    files: t.map((a) => ({
      name: a.name,
      type: a.type,
      size: a.size
    })),
    dropPos: n
  }), Promise.resolve(
    e.intakeFiles({
      source: "drop",
      files: t,
      dropPos: n,
      anchorPos: n
    })
  ).catch((a) => {
    e.emitDiagnostic({
      code: "drop-intake-dispatch-failed",
      message: a instanceof Error ? a.message : "Failed to dispatch dropped files.",
      severity: "error",
      stage: "intake",
      cause: a
    });
  }));
}, fm = (e, t, n) => {
  e && (Rn("text-editor:file-intake", "paste files captured", {
    files: t.map((a) => ({
      name: a.name,
      type: a.type,
      size: a.size
    })),
    hasHtmlContent: !!n
  }), Promise.resolve(
    e.intakeFiles({
      source: "paste",
      files: t,
      htmlContent: n || void 0
    })
  ).catch((a) => {
    e.emitDiagnostic({
      code: "paste-intake-dispatch-failed",
      message: a instanceof Error ? a.message : "Failed to dispatch pasted files.",
      severity: "error",
      stage: "intake",
      cause: a
    });
  }));
}, gm = Mi.extend({
  addProseMirrorPlugins() {
    var t;
    return [
      ...((t = this.parent) == null ? void 0 : t.call(this)) ?? [],
      new Ne({
        key: new De("fileHandlerClipboardItemFallback"),
        props: {
          handlePaste: (n, a) => {
            var i, r, m;
            const o = um(a.clipboardData);
            return o.length === 0 ? !1 : (a.preventDefault(), a.stopPropagation(), (m = (r = this.options).onPaste) == null || m.call(
              r,
              this.editor,
              o,
              ((i = a.clipboardData) == null ? void 0 : i.getData("text/html")) || void 0
            ), !0);
          }
        }
      })
    ];
  }
}), hm = ({
  filePlatformRuntime: e
}) => gm.configure({
  consumePasteEvent: !0,
  onDrop: (t, n, a) => {
    pm(e, n, a);
  },
  onPaste: (t, n, a) => {
    fm(e, n, a);
  }
}), jm = Object.freeze({
  firstParagraph: "请输入内容...",
  headings: Object.freeze({
    1: "Heading 1",
    2: "Heading 2",
    3: "Heading 3",
    4: "Heading 4",
    5: "Heading 5",
    6: "Heading 6"
  }),
  bulletList: "Bullet List",
  orderedList: "Numbered List",
  taskItem: "To-do",
  blockquote: "Quote",
  codeBlock: "Code",
  toggle: "Toggle heading"
}), vm = (e = {}) => {
  const t = e.base ?? jm, n = e.override ?? null, a = { ...t.headings };
  if (n != null && n.headings)
    for (const o of [1, 2, 3, 4, 5, 6])
      Object.prototype.hasOwnProperty.call(n.headings, o) && (a[o] = n.headings[o]);
  return Object.freeze({
    firstParagraph: n && Object.prototype.hasOwnProperty.call(n, "firstParagraph") ? n.firstParagraph ?? "" : t.firstParagraph,
    headings: Object.freeze(a),
    bulletList: n && Object.prototype.hasOwnProperty.call(n, "bulletList") ? n.bulletList ?? "" : t.bulletList,
    orderedList: n && Object.prototype.hasOwnProperty.call(n, "orderedList") ? n.orderedList ?? "" : t.orderedList,
    taskItem: n && Object.prototype.hasOwnProperty.call(n, "taskItem") ? n.taskItem ?? "" : t.taskItem,
    blockquote: n && Object.prototype.hasOwnProperty.call(n, "blockquote") ? n.blockquote ?? "" : t.blockquote,
    codeBlock: n && Object.prototype.hasOwnProperty.call(n, "codeBlock") ? n.codeBlock ?? "" : t.codeBlock,
    toggle: n && Object.prototype.hasOwnProperty.call(n, "toggle") ? n.toggle ?? "" : t.toggle
  });
}, bm = Sa, _m = We.create({
  name: "deterministicRuntimeCommitClosure",
  addProseMirrorPlugins() {
    return [
      ...Di.map((e) => e.plugin),
      Ri
    ];
  }
}), ym = (e) => !!e, mt = (e) => (e == null ? void 0 : e.name) ?? null, wm = (e, t) => e.some((n) => mt(n) === t), km = (e, t = bm) => e.filter((n) => {
  const a = mt(n);
  return !a || !t.has(a);
}), Cm = (e, t) => e.map((n) => {
  const a = n.options;
  return !a || !Object.prototype.hasOwnProperty.call(a, "themeOwner") ? n : n.configure({ themeOwner: t ?? null });
}), xm = (e) => {
  const t = /* @__PURE__ */ new Map();
  e.forEach((o) => {
    const i = mt(o);
    i && t.set(i, o);
  });
  const n = /* @__PURE__ */ new Set(), a = [];
  return e.forEach((o) => {
    const i = mt(o);
    if (!i) {
      a.push(o);
      return;
    }
    n.has(i) || (n.add(i), a.push(t.get(i) ?? o));
  }), a;
}, Em = new Map(
  Sn.map(
    (e) => [
      e.name,
      e
    ]
  )
), Lm = (e) => {
  const t = [];
  return e.forEach((n) => {
    const a = Em.get(n);
    a && t.push(a);
  }), t;
}, Tm = (e, t) => e.allowExternalOverride && Za(e).some(
  (n) => wm(t, n)
), st = (e, t, n) => dr(
  {
    themeOwner: t.themeOwner,
    filePlatform: t.filePlatform,
    filePlatformRuntime: t.filePlatformRuntime,
    getCurrentDocument: t.getCurrentDocument ?? null,
    mentions: t.mentions,
    suggestions: t.suggestions,
    tags: t.tags
  },
  Lm(e).filter(
    (a) => !Tm(a, n)
  )
), Im = (e) => ({ node: t, editor: n, pos: a }) => {
  var l;
  const { doc: o } = n.state;
  if (a < 0 || a > o.content.size) return "";
  const i = o.resolve(a), r = /* @__PURE__ */ new Set();
  for (let c = i.depth; c > 0; c--)
    r.add(i.node(c).type.name);
  const m = o.firstChild === t || ((l = o.firstChild) == null ? void 0 : l.content.firstChild) === t;
  if (t.type.name === "paragraph") {
    if (r.has("taskItem"))
      return e.taskItem;
    if (r.has("bulletList"))
      return e.bulletList;
    if (r.has("orderedList"))
      return e.orderedList;
  }
  if (t.type.name === "paragraph" && m)
    return e.firstParagraph;
  if (t.type.name === "heading") {
    const c = t.attrs.level ?? 1, d = c >= 1 && c <= 6 ? c : 1;
    return e.headings[d];
  }
  switch (t.type.name) {
    case "blockquote":
      return e.blockquote;
    case "codeBlock":
      return e.codeBlock;
    case "toggle":
      return e.toggle;
    default:
      return "";
  }
}, bc = (e = {}) => {
  var d, g, f, p, h;
  const t = Cm(
    km(e.extensions ?? []),
    e.themeOwner
  ), n = Aa({
    override: e.typography
  }), a = typeof e.placeholder == "string" && e.placeholder ? { firstParagraph: e.placeholder } : null, o = e.placeholderContract || a ? {
    ...e.placeholderContract ?? {},
    ...a ?? {}
  } : e.placeholderContract, i = vm({
    override: o
  }), r = Im(i), m = typeof e.placeholder == "function" ? e.placeholder : null, l = m ? (v) => {
    const L = m(v);
    return typeof L == "string" ? L : r(v);
  } : r, c = Pa(
    xm(
      [
        ni.configure({
          ...Wa(e.starterkitOptions)
        }),
        _m,
        ui,
        Ma.configure(
          Ua(e.starterkitOptions)
        ),
        ii.configure({ ...Ka }),
        ci,
        di.configure({ ...Xa }),
        Ba,
        Da,
        Ra,
        si,
        ai.configure({ types: [...Ga] }),
        ri,
        li,
        mi,
        Oa.configure({
          contract: n
        }),
        e.pages === !1 ? !1 : Na.configure({
          getCurrentDocument: e.getCurrentDocument ?? null,
          ...e.pages ?? {}
        }),
        e.pages === !1 ? !1 : $a,
        e.pages === !1 ? !1 : za,
        e.pagesHeaderFooter !== void 0 && e.pagesHeaderFooter !== !1 && Fa.configure({
          getCurrentDocument: e.getCurrentDocument ?? null,
          editable: e.editable,
          ...e.pagesHeaderFooter ?? {}
        }),
        e.pagesLayout !== void 0 && e.pagesLayout !== !1 && Ha.configure(e.pagesLayout),
        ...st(
          ["comment", "namedColor", "namedHighlight"],
          e,
          t
        ),
        mm,
        lm.configure({
          codeBlockPreferences: e.codeBlockPreferences ?? null
        }),
        Va,
        jr({
          runtime: e.shortcutRuntime,
          parent: e.shortcutParentOwner,
          existingExtensionNames: (e.extensions ?? []).map(
            mt
          )
        }),
        ...st(
          ["attachment", "image", "imageGroup", "video", "iframe"],
          e,
          t
        ),
        Tr.configure({
          openOnClick: !1,
          themeOwner: e.themeOwner ?? null
        }),
        Rs({
          assetPipelineRuntime: e.assetPipelineRuntime ?? null
        }),
        hm({
          filePlatformRuntime: e.filePlatformRuntime ?? null
        }),
        oi.configure({
          // - placeholder (string) is merged into the contract as firstParagraph.
          // - placeholder (function) can override per-node behavior and falls back
          //   to the contract-driven placeholder when it returns a non-string value.
          placeholder: l,
          // Apply placeholders to nested blocks (e.g. paragraphs inside lists),
          // to match Notion-style list placeholders.
          includeChildren: !0
        }),
        ...st(
          ["mention"],
          e,
          t
        ),
        Br.configure({
          suggestion: ((d = e.suggestions) == null ? void 0 : d.emoji) ?? {},
          themeOwner: e.themeOwner ?? null
        }),
        Yr.configure({
          suggestion: ((g = e.suggestions) == null ? void 0 : g.slash) ?? {},
          codeBlockPreferences: e.codeBlockPreferences ?? null,
          catalogContributions: e.slashCatalogContributions ?? null,
          themeOwner: e.themeOwner ?? null
        }),
        ...st(
          ["tag", "embed"],
          e,
          t
        ),
        // Unified drop/paste file adapters own File[] intake. ContentPaste keeps
        // markdown and HTML bridging until intent classification fully lands.
        tl.configure({
          enabled: !0,
          filePlatformRuntime: e.filePlatformRuntime,
          codeBlockPreferences: e.codeBlockPreferences ?? null
        }),
        ...st(
          ["toggle"],
          e,
          t
        ),
        e.dragHandle && cm.configure({
          key: null,
          depth: 0
        }),
        qa.configure({
          types: (f = e.stableBlockIdentity) == null ? void 0 : f.types,
          generateId: (p = e.stableBlockIdentity) == null ? void 0 : p.generateId,
          filterRemoteTransactions: (h = e.stableBlockIdentity) == null ? void 0 : h.filterRemoteTransactions
        }),
        ...t
      ].filter(
        (v) => ym(v)
      )
    )
  );
  return e.contentProfile === "basic-rich-text" ? [...c.map(io), kr({ limits: e.contentLimits, issue: e.onContentIssue })] : c;
};
export {
  Wi as $,
  vc as A,
  gc as B,
  tl as C,
  hc as D,
  Ui as E,
  ao as F,
  jc as G,
  Zs as H,
  ps as I,
  am as J,
  Rl as K,
  Tr as L,
  _s as M,
  Ll as N,
  Il as O,
  oo as P,
  Ct as Q,
  sr as R,
  Yr as S,
  Ts as T,
  rr as U,
  ar as V,
  lr as W,
  Jn as X,
  Qn as Y,
  At as Z,
  Er as _,
  mm as a,
  Dr as a0,
  Ve as a1,
  Xs as a2,
  lm as b,
  Es as c,
  ns as d,
  nr as e,
  Br as f,
  zr as g,
  Hr as h,
  Fr as i,
  Fi as j,
  qi as k,
  dr as l,
  $r as m,
  bm as n,
  mt as o,
  wm as p,
  km as q,
  Zr as r,
  bc as s,
  rt as t,
  Ss as u,
  Ds as v,
  Rs as w,
  Ht as x,
  gr as y,
  hr as z
};
//# sourceMappingURL=runtime-extensions-ClrqjOfa.mjs.map
