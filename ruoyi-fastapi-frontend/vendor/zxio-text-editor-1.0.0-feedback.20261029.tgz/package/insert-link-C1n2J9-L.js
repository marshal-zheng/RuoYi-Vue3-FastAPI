"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const e=require("./use-text-editor-command-keybindings-BPNtaKwu.js");exports.default=e._sfc_main$7;
//# sourceMappingURL=insert-link-C1n2J9-L.js.map
