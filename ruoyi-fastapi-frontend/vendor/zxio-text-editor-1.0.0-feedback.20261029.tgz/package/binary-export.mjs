import { Q as D, S as _ } from "./orchestrator-BvYb3ovo.mjs";
import { a8 as d, _ as P, a5 as T, a7 as C, a6 as f, a2 as n, W as p, Y as x, X as F, U as X, aa as i, ab as u, a0 as B, a1 as I, a4 as O, V as L, a9 as R, $ as N, a3 as Z } from "./orchestrator-BvYb3ovo.mjs";
const r = async (a, e, o = {}) => {
  const t = await D(a, {
    ...o,
    request: {
      ...o.request ?? {},
      format: e
    }
  });
  return o.waitForCompletion === !0 && t.state !== "completed" && t.state !== "failed" ? _(t.id, {
    jobStore: o.jobStore,
    ...o.poll ?? {}
  }) : t;
}, E = (a, e = {}) => r(a, "pdf", e), l = (a, e = {}) => r(a, "docx", e);
export {
  d as ZX_DEFAULT_DOCX_CAPABILITY_PROFILE,
  P as ZX_DEFAULT_PDF_CAPABILITY_PROFILE,
  T as ZX_DOCX_ADAPTER_ID,
  C as ZX_DOCX_DEFAULT_BACKEND_CONSTRAINTS,
  f as ZX_DOCX_DEFAULT_BACKEND_ID,
  n as ZX_DOCX_PACKAGE_MODEL_VERSION,
  p as ZX_PDF_ADAPTER_ID,
  x as ZX_PDF_DEFAULT_BACKEND_CONSTRAINTS,
  F as ZX_PDF_DEFAULT_BACKEND_ID,
  X as ZX_PDF_RENDER_MODEL_VERSION,
  i as createDefaultDocxBackendDescriptor,
  u as createDefaultDocxExportBackend,
  B as createDefaultPdfBackendDescriptor,
  I as createDefaultPdfExportBackend,
  l as exportBundleToDocx,
  E as exportBundleToPdf,
  O as lowerToDocxPackageModel,
  L as lowerToPdfRenderModel,
  R as resolveDocxCapabilityProfile,
  N as resolvePdfCapabilityProfile,
  Z as toDocxRunModel
};
//# sourceMappingURL=binary-export.mjs.map
