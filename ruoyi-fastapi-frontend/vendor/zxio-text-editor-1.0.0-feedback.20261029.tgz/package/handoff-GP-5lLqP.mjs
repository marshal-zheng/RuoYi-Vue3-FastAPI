import { d as g, s as I, c as F, a as We, b as so, f as Zt } from "./agent-integration-DlCa6aQV.mjs";
function te(e) {
  this.content = e;
}
te.prototype = {
  constructor: te,
  find: function(e) {
    for (var t = 0; t < this.content.length; t += 2)
      if (this.content[t] === e) return t;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(e) {
    var t = this.find(e);
    return t == -1 ? void 0 : this.content[t + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(e, t, n) {
    var r = n && n != e ? this.remove(n) : this, i = r.find(e), o = r.content.slice();
    return i == -1 ? o.push(n || e, t) : (o[i + 1] = t, n && (o[i] = n)), new te(o);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(e) {
    var t = this.find(e);
    if (t == -1) return this;
    var n = this.content.slice();
    return n.splice(t, 2), new te(n);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(e, t) {
    return new te([e, t].concat(this.remove(e).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(e, t) {
    var n = this.remove(e).content.slice();
    return n.push(e, t), new te(n);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(e, t, n) {
    var r = this.remove(t), i = r.content.slice(), o = r.find(e);
    return i.splice(o == -1 ? i.length : o, 0, t, n), new te(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(e) {
    for (var t = 0; t < this.content.length; t += 2)
      e(this.content[t], this.content[t + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(e) {
    return e = te.from(e), e.size ? new te(e.content.concat(this.subtract(e).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(e) {
    return e = te.from(e), e.size ? new te(this.subtract(e).content.concat(e.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(e) {
    var t = this;
    e = te.from(e);
    for (var n = 0; n < e.content.length; n += 2)
      t = t.remove(e.content[n]);
    return t;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var e = {};
    return this.forEach(function(t, n) {
      e[t] = n;
    }), e;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
te.from = function(e) {
  if (e instanceof te) return e;
  var t = [];
  if (e) for (var n in e) t.push(n, e[n]);
  return new te(t);
};
function ao(e, t, n) {
  for (let r = 0; ; r++) {
    if (r == e.childCount || r == t.childCount)
      return e.childCount == t.childCount ? null : n;
    let i = e.child(r), o = t.child(r);
    if (i == o) {
      n += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(o))
      return n;
    if (i.isText && i.text != o.text) {
      let s = i.text, a = o.text, c = 0;
      for (; s[c] == a[c]; c++)
        n++;
      return c && c < s.length && c < a.length && po(s.charCodeAt(c - 1)) && lo(s.charCodeAt(c)) && n--, n;
    }
    if (i.content.size || o.content.size) {
      let s = ao(i.content, o.content, n + 1);
      if (s != null)
        return s;
    }
    n += i.nodeSize;
  }
}
function co(e, t, n, r) {
  for (let i = e.childCount, o = t.childCount; ; ) {
    if (i == 0 || o == 0)
      return i == o ? null : { a: n, b: r };
    let s = e.child(--i), a = t.child(--o), c = s.nodeSize;
    if (s == a) {
      n -= c, r -= c;
      continue;
    }
    if (!s.sameMarkup(a))
      return { a: n, b: r };
    if (s.isText && s.text != a.text) {
      let l = s.text, p = a.text, d = l.length, f = p.length;
      for (; d > 0 && f > 0 && l[d - 1] == p[f - 1]; )
        d--, f--, n--, r--;
      return d && f && d < l.length && po(l.charCodeAt(d - 1)) && lo(l.charCodeAt(d)) && (n++, r++), { a: n, b: r };
    }
    if (s.content.size || a.content.size) {
      let l = co(s.content, a.content, n - 1, r - 1);
      if (l)
        return l;
    }
    n -= c, r -= c;
  }
}
function lo(e) {
  return e >= 56320 && e < 57344;
}
function po(e) {
  return e >= 55296 && e < 56320;
}
class O {
  /**
  @internal
  */
  constructor(t, n) {
    if (this.content = t, this.size = n || 0, n == null)
      for (let r = 0; r < t.length; r++)
        this.size += t[r].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(t, n, r, i = 0, o) {
    for (let s = 0, a = 0; a < n; s++) {
      let c = this.content[s], l = a + c.nodeSize;
      if (l > t && r(c, i + a, o || null, s) !== !1 && c.content.size) {
        let p = a + 1;
        c.nodesBetween(Math.max(0, t - p), Math.min(c.content.size, n - p), r, i + p);
      }
      a = l;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(t) {
    this.nodesBetween(0, this.size, t);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(t, n, r, i) {
    let o = "", s = !0;
    return this.nodesBetween(t, n, (a, c) => {
      let l = a.isText ? a.text.slice(Math.max(t, c) - c, n - c) : a.isLeaf ? i ? typeof i == "function" ? i(a) : i : a.type.spec.leafText ? a.type.spec.leafText(a) : "" : "";
      a.isBlock && (a.isLeaf && l || a.isTextblock) && r && (s ? s = !1 : o += r), o += l;
    }, 0), o;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(t) {
    if (!t.size)
      return this;
    if (!this.size)
      return t;
    let n = this.lastChild, r = t.firstChild, i = this.content.slice(), o = 0;
    for (n.isText && n.sameMarkup(r) && (i[i.length - 1] = n.withText(n.text + r.text), o = 1); o < t.content.length; o++)
      i.push(t.content[o]);
    return new O(i, this.size + t.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(t, n = this.size) {
    if (t == 0 && n == this.size)
      return this;
    let r = [], i = 0;
    if (n > t)
      for (let o = 0, s = 0; s < n; o++) {
        let a = this.content[o], c = s + a.nodeSize;
        c > t && ((s < t || c > n) && (a.isText ? a = a.cut(Math.max(0, t - s), Math.min(a.text.length, n - s)) : a = a.cut(Math.max(0, t - s - 1), Math.min(a.content.size, n - s - 1))), r.push(a), i += a.nodeSize), s = c;
      }
    return new O(r, i);
  }
  /**
  @internal
  */
  cutByIndex(t, n) {
    return t == n ? O.empty : t == 0 && n == this.content.length ? this : new O(this.content.slice(t, n));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(t, n) {
    let r = this.content[t];
    if (r == n)
      return this;
    let i = this.content.slice(), o = this.size + n.nodeSize - r.nodeSize;
    return i[t] = n, new O(i, o);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(t) {
    return new O([t].concat(this.content), this.size + t.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(t) {
    return new O(this.content.concat(t), this.size + t.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(t) {
    if (this.content.length != t.content.length)
      return !1;
    for (let n = 0; n < this.content.length; n++)
      if (!this.content[n].eq(t.content[n]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(t) {
    let n = this.content[t];
    if (!n)
      throw new RangeError("Index " + t + " out of range for " + this);
    return n;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(t) {
    return this.content[t] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(t) {
    for (let n = 0, r = 0; n < this.content.length; n++) {
      let i = this.content[n];
      t(i, r, n), r += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(t, n = 0) {
    return ao(this, t, n);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(t, n = this.size, r = t.size) {
    return co(this, t, n, r);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(t) {
    if (t == 0)
      return ln(0, t);
    if (t == this.size)
      return ln(this.content.length, t);
    if (t > this.size || t < 0)
      throw new RangeError(`Position ${t} outside of fragment (${this})`);
    for (let n = 0, r = 0; ; n++) {
      let i = this.child(n), o = r + i.nodeSize;
      if (o >= t)
        return o == t ? ln(n + 1, o) : ln(n, r);
      r = o;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((t) => t.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(t, n) {
    if (!n)
      return O.empty;
    if (!Array.isArray(n))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return O.fromArray(n.map(t.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(t) {
    if (!t.length)
      return O.empty;
    let n, r = 0;
    for (let i = 0; i < t.length; i++) {
      let o = t[i];
      r += o.nodeSize, i && o.isText && t[i - 1].sameMarkup(o) ? (n || (n = t.slice(0, i)), n[n.length - 1] = o.withText(n[n.length - 1].text + o.text)) : n && n.push(o);
    }
    return new O(n || t, r);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(t) {
    if (!t)
      return O.empty;
    if (t instanceof O)
      return t;
    if (Array.isArray(t))
      return this.fromArray(t);
    if (t.attrs)
      return new O([t], t.nodeSize);
    throw new RangeError("Can not convert " + t + " to a Fragment" + (t.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
O.empty = new O([], 0);
const tr = { index: 0, offset: 0 };
function ln(e, t) {
  return tr.index = e, tr.offset = t, tr;
}
function xn(e, t) {
  if (e === t)
    return !0;
  if (!(e && typeof e == "object") || !(t && typeof t == "object"))
    return !1;
  let n = Array.isArray(e);
  if (Array.isArray(t) != n)
    return !1;
  if (n) {
    if (e.length != t.length)
      return !1;
    for (let r = 0; r < e.length; r++)
      if (!xn(e[r], t[r]))
        return !1;
  } else {
    for (let r in e)
      if (!(r in t) || !xn(e[r], t[r]))
        return !1;
    for (let r in t)
      if (!(r in e))
        return !1;
  }
  return !0;
}
class K {
  /**
  @internal
  */
  constructor(t, n) {
    this.type = t, this.attrs = n;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(t) {
    let n, r = !1;
    for (let i = 0; i < t.length; i++) {
      let o = t[i];
      if (this.eq(o))
        return t;
      if (this.type.excludes(o.type))
        n || (n = t.slice(0, i));
      else {
        if (o.type.excludes(this.type))
          return t;
        !r && o.type.rank > this.type.rank && (n || (n = t.slice(0, i)), n.push(this), r = !0), n && n.push(o);
      }
    }
    return n || (n = t.slice()), r || n.push(this), n;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(t) {
    for (let n = 0; n < t.length; n++)
      if (this.eq(t[n]))
        return t.slice(0, n).concat(t.slice(n + 1));
    return t;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(t) {
    for (let n = 0; n < t.length; n++)
      if (this.eq(t[n]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(t) {
    return this == t || this.type == t.type && xn(this.attrs, t.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let t = { type: this.type.name };
    for (let n in this.attrs) {
      t.attrs = this.attrs;
      break;
    }
    return t;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(t, n) {
    if (!n)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let r = t.marks[n.type];
    if (!r)
      throw new RangeError(`There is no mark type ${n.type} in this schema`);
    return r.create(n.attrs);
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(t, n) {
    if (t == n)
      return !0;
    if (t.length != n.length)
      return !1;
    for (let r = 0; r < t.length; r++)
      if (!t[r].eq(n[r]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(t) {
    if (!t || Array.isArray(t) && t.length == 0)
      return K.none;
    if (t instanceof K)
      return [t];
    let n = t.slice();
    return n.sort((r, i) => r.type.rank - i.type.rank), n;
  }
}
K.none = [];
class Yt extends Error {
}
class A {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(t, n, r) {
    this.content = t, this.openStart = n, this.openEnd = r;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(t, n) {
    let r = uo(this.content, t + this.openStart, n, this.openStart + 1, this.openEnd + 1);
    return r && new A(r, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(t, n) {
    return new A(fo(this.content, t + this.openStart, n + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(t) {
    return this.content.eq(t.content) && this.openStart == t.openStart && this.openEnd == t.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let t = { content: this.content.toJSON() };
    return this.openStart > 0 && (t.openStart = this.openStart), this.openEnd > 0 && (t.openEnd = this.openEnd), t;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(t, n) {
    if (!n)
      return A.empty;
    let r = n.openStart || 0, i = n.openEnd || 0;
    if (typeof r != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new A(O.fromJSON(t, n.content), r, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(t, n = !0) {
    let r = 0, i = 0;
    for (let o = t.firstChild; o && !o.isLeaf && (n || !o.type.spec.isolating); o = o.firstChild)
      r++;
    for (let o = t.lastChild; o && !o.isLeaf && (n || !o.type.spec.isolating); o = o.lastChild)
      i++;
    return new A(t, r, i);
  }
}
A.empty = new A(O.empty, 0, 0);
function fo(e, t, n) {
  let { index: r, offset: i } = e.findIndex(t), o = e.maybeChild(r), { index: s, offset: a } = e.findIndex(n);
  if (i == t || o.isText) {
    if (a != n && !e.child(s).isText)
      throw new RangeError("Removing non-flat range");
    return e.cut(0, t).append(e.cut(n));
  }
  if (r != s)
    throw new RangeError("Removing non-flat range");
  return e.replaceChild(r, o.copy(fo(o.content, t - i - 1, n - i - 1)));
}
function uo(e, t, n, r, i, o) {
  let { index: s, offset: a } = e.findIndex(t), c = e.maybeChild(s);
  if (a == t || c.isText)
    return o && r <= 0 && i <= 0 && !o.canReplace(s, s, n) ? null : e.cut(0, t).append(n).append(e.cut(t));
  let l = uo(c.content, t - a - 1, n, s == 0 ? r - 1 : 0, s == e.childCount - 1 ? i - 1 : 0, c);
  return l && e.replaceChild(s, c.copy(l));
}
function na(e, t, n) {
  if (n.openStart > e.depth)
    throw new Yt("Inserted content deeper than insertion position");
  if (e.depth - n.openStart != t.depth - n.openEnd)
    throw new Yt("Inconsistent open depths");
  return ho(e, t, n, 0);
}
function ho(e, t, n, r) {
  let i = e.index(r), o = e.node(r);
  if (i == t.index(r) && r < e.depth - n.openStart) {
    let s = ho(e, t, n, r + 1);
    return o.copy(o.content.replaceChild(i, s));
  } else if (n.content.size)
    if (!n.openStart && !n.openEnd && e.depth == r && t.depth == r) {
      let s = e.parent, a = s.content;
      return ut(s, a.cut(0, e.parentOffset).append(n.content).append(a.cut(t.parentOffset)));
    } else {
      let { start: s, end: a } = ra(n, e);
      return ut(o, go(e, s, a, t, r));
    }
  else return ut(o, kn(e, t, r));
}
function mo(e, t) {
  if (!t.type.compatibleContent(e.type))
    throw new Yt("Cannot join " + t.type.name + " onto " + e.type.name);
}
function kr(e, t, n) {
  let r = e.node(n);
  return mo(r, t.node(n)), r;
}
function ft(e, t) {
  let n = t.length - 1;
  n >= 0 && e.isText && e.sameMarkup(t[n]) ? t[n] = e.withText(t[n].text + e.text) : t.push(e);
}
function Wt(e, t, n, r) {
  let i = (t || e).node(n), o = 0, s = t ? t.index(n) : i.childCount;
  e && (o = e.index(n), e.depth > n ? o++ : e.textOffset && (ft(e.nodeAfter, r), o++));
  for (let a = o; a < s; a++)
    ft(i.child(a), r);
  t && t.depth == n && t.textOffset && ft(t.nodeBefore, r);
}
function ut(e, t) {
  if (!e.type.validContent(t))
    throw new Yt("Invalid content for node " + e.type.name);
  return e.copy(t);
}
function go(e, t, n, r, i) {
  let o = e.depth > i && kr(e, t, i + 1), s = r.depth > i && kr(n, r, i + 1), a = [];
  return Wt(null, e, i, a), o && s && t.index(i) == n.index(i) ? (mo(o, s), ft(ut(o, go(e, t, n, r, i + 1)), a)) : (o && ft(ut(o, kn(e, t, i + 1)), a), Wt(t, n, i, a), s && ft(ut(s, kn(n, r, i + 1)), a)), Wt(r, null, i, a), new O(a);
}
function kn(e, t, n) {
  let r = [];
  if (Wt(null, e, n, r), e.depth > n) {
    let i = kr(e, t, n + 1);
    ft(ut(i, kn(e, t, n + 1)), r);
  }
  return Wt(t, null, n, r), new O(r);
}
function ra(e, t) {
  let n = t.depth - e.openStart, i = t.node(n).copy(e.content);
  for (let o = n - 1; o >= 0; o--)
    i = t.node(o).copy(O.from(i));
  return {
    start: i.resolveNoCache(e.openStart + n),
    end: i.resolveNoCache(i.content.size - e.openEnd - n)
  };
}
class Qt {
  /**
  @internal
  */
  constructor(t, n, r) {
    this.pos = t, this.path = n, this.parentOffset = r, this.depth = n.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(t) {
    return t == null ? this.depth : t < 0 ? this.depth + t : t;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(t) {
    return this.path[this.resolveDepth(t) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(t) {
    return this.path[this.resolveDepth(t) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(t) {
    return t = this.resolveDepth(t), this.index(t) + (t == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(t) {
    return t = this.resolveDepth(t), t == 0 ? 0 : this.path[t * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(t) {
    return t = this.resolveDepth(t), this.start(t) + this.node(t).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(t) {
    if (t = this.resolveDepth(t), !t)
      throw new RangeError("There is no position before the top-level node");
    return t == this.depth + 1 ? this.pos : this.path[t * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(t) {
    if (t = this.resolveDepth(t), !t)
      throw new RangeError("There is no position after the top-level node");
    return t == this.depth + 1 ? this.pos : this.path[t * 3 - 1] + this.path[t * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let t = this.parent, n = this.index(this.depth);
    if (n == t.childCount)
      return null;
    let r = this.pos - this.path[this.path.length - 1], i = t.child(n);
    return r ? t.child(n).cut(r) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let t = this.index(this.depth), n = this.pos - this.path[this.path.length - 1];
    return n ? this.parent.child(t).cut(0, n) : t == 0 ? null : this.parent.child(t - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(t, n) {
    n = this.resolveDepth(n);
    let r = this.path[n * 3], i = n == 0 ? 0 : this.path[n * 3 - 1] + 1;
    for (let o = 0; o < t; o++)
      i += r.child(o).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let t = this.parent, n = this.index();
    if (t.content.size == 0)
      return K.none;
    if (this.textOffset)
      return t.child(n).marks;
    let r = t.maybeChild(n - 1), i = t.maybeChild(n);
    if (!r) {
      let a = r;
      r = i, i = a;
    }
    let o = r.marks;
    for (var s = 0; s < o.length; s++)
      o[s].type.spec.inclusive === !1 && (!i || !o[s].isInSet(i.marks)) && (o = o[s--].removeFromSet(o));
    return o;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(t) {
    let n = this.parent.maybeChild(this.index());
    if (!n || !n.isInline)
      return null;
    let r = n.marks, i = t.parent.maybeChild(t.index());
    for (var o = 0; o < r.length; o++)
      r[o].type.spec.inclusive === !1 && (!i || !r[o].isInSet(i.marks)) && (r = r[o--].removeFromSet(r));
    return r;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(t) {
    for (let n = this.depth; n > 0; n--)
      if (this.start(n) <= t && this.end(n) >= t)
        return n;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(t = this, n) {
    if (t.pos < this.pos)
      return t.blockRange(this);
    for (let r = this.depth - (this.parent.inlineContent || this.pos == t.pos ? 1 : 0); r >= 0; r--)
      if (t.pos <= this.end(r) && (!n || n(this.node(r))))
        return new sa(this, t, r);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(t) {
    return this.pos - this.parentOffset == t.pos - t.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(t) {
    return t.pos > this.pos ? t : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(t) {
    return t.pos < this.pos ? t : this;
  }
  /**
  @internal
  */
  toString() {
    let t = "";
    for (let n = 1; n <= this.depth; n++)
      t += (t ? "/" : "") + this.node(n).type.name + "_" + this.index(n - 1);
    return t + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(t, n) {
    if (!(n >= 0 && n <= t.content.size))
      throw new RangeError("Position " + n + " out of range");
    let r = [], i = 0, o = n;
    for (let s = t; ; ) {
      let { index: a, offset: c } = s.content.findIndex(o), l = o - c;
      if (r.push(s, a, i + c), !l || (s = s.child(a), s.isText))
        break;
      o = l - 1, i += c + 1;
    }
    return new Qt(n, r, o);
  }
  /**
  @internal
  */
  static resolveCached(t, n) {
    let r = di.get(t);
    if (r)
      for (let o = 0; o < r.elts.length; o++) {
        let s = r.elts[o];
        if (s.pos == n)
          return s;
      }
    else
      di.set(t, r = new ia());
    let i = r.elts[r.i] = Qt.resolve(t, n);
    return r.i = (r.i + 1) % oa, i;
  }
}
class ia {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const oa = 12, di = /* @__PURE__ */ new WeakMap();
class sa {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(t, n, r) {
    this.$from = t, this.$to = n, this.depth = r;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const aa = /* @__PURE__ */ Object.create(null);
class je {
  /**
  @internal
  */
  constructor(t, n, r, i = K.none) {
    this.type = t, this.attrs = n, this.marks = i, this.content = r || O.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(t) {
    return this.content.child(t);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(t) {
    return this.content.maybeChild(t);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(t) {
    this.content.forEach(t);
  }
  /**
  Invoke a callback for all descendant nodes recursively overlapping
  the given two positions that are relative to start of this
  node's content. This includes all ancestors of the nodes
  containing the two positions. The callback is invoked with the
  node, its position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(t, n, r, i = 0) {
    this.content.nodesBetween(t, n, r, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(t) {
    this.nodesBetween(0, this.content.size, t);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(t, n, r, i) {
    return this.content.textBetween(t, n, r, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(t) {
    return this == t || this.sameMarkup(t) && this.content.eq(t.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(t) {
    return this.hasMarkup(t.type, t.attrs, t.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(t, n, r) {
    return this.type == t && xn(this.attrs, n || t.defaultAttrs || aa) && K.sameSet(this.marks, r || K.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(t = null) {
    return t == this.content ? this : new je(this.type, this.attrs, t, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(t) {
    return t == this.marks ? this : new je(this.type, this.attrs, this.content, t);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(t, n = this.content.size) {
    return t == 0 && n == this.content.size ? this : this.copy(this.content.cut(t, n));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(t, n = this.content.size, r = !1) {
    if (t == n)
      return A.empty;
    let i = this.resolve(t), o = this.resolve(n), s = r ? 0 : i.sharedDepth(n), a = i.start(s), l = i.node(s).content.cut(i.pos - a, o.pos - a);
    return new A(l, i.depth - s, o.depth - s);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(t, n, r) {
    return na(this.resolve(t), this.resolve(n), r);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(t) {
    for (let n = this; ; ) {
      let { index: r, offset: i } = n.content.findIndex(t);
      if (n = n.maybeChild(r), !n)
        return null;
      if (i == t || n.isText)
        return n;
      t -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(t) {
    let { index: n, offset: r } = this.content.findIndex(t);
    return { node: this.content.maybeChild(n), index: n, offset: r };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(t) {
    if (t == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: n, offset: r } = this.content.findIndex(t);
    if (r < t)
      return { node: this.content.child(n), index: n, offset: r };
    let i = this.content.child(n - 1);
    return { node: i, index: n - 1, offset: r - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(t) {
    return Qt.resolveCached(this, t);
  }
  /**
  @internal
  */
  resolveNoCache(t) {
    return Qt.resolve(this, t);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(t, n, r) {
    let i = !1;
    return n > t && this.nodesBetween(t, n, (o) => (r.isInSet(o.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let t = this.type.name;
    return this.content.size && (t += "(" + this.content.toStringInner() + ")"), yo(this.marks, t);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(t) {
    let n = this.type.contentMatch.matchFragment(this.content, 0, t);
    if (!n)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return n;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(t, n, r = O.empty, i = 0, o = r.childCount) {
    let s = this.contentMatchAt(t).matchFragment(r, i, o), a = s && s.matchFragment(this.content, n);
    if (!a || !a.validEnd)
      return !1;
    for (let c = i; c < o; c++)
      if (!this.type.allowsMarks(r.child(c).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(t, n, r, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let o = this.contentMatchAt(t).matchType(r), s = o && o.matchFragment(this.content, n);
    return s ? s.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(t) {
    return t.content.size ? this.canReplace(this.childCount, this.childCount, t.content) : this.type.compatibleContent(t.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), pi(this.type.attrs, this.attrs, "node", this.type.name);
    let t = K.none;
    for (let n = 0; n < this.marks.length; n++) {
      let r = this.marks[n];
      pi(r.type.attrs, r.attrs, "mark", r.type.name), t = r.addToSet(t);
    }
    if (!K.sameSet(t, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((n) => n.type.name)}`);
    this.content.forEach((n) => n.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let t = { type: this.type.name };
    for (let n in this.attrs) {
      t.attrs = this.attrs;
      break;
    }
    return this.content.size && (t.content = this.content.toJSON()), this.marks.length && (t.marks = this.marks.map((n) => n.toJSON())), t;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(t, n) {
    if (!n)
      throw new RangeError("Invalid input for Node.fromJSON");
    let r;
    if (n.marks) {
      if (!Array.isArray(n.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      r = n.marks.map(t.markFromJSON);
    }
    if (n.type == "text") {
      if (typeof n.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return t.text(n.text, r);
    }
    let i = O.fromJSON(t, n.content);
    return t.nodeType(n.type).create(n.attrs, i, r);
  }
}
je.prototype.text = void 0;
class In extends je {
  /**
  @internal
  */
  constructor(t, n, r, i) {
    if (super(t, n, null, i), !r)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = r;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : yo(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(t, n) {
    return this.text.slice(t, n);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(t) {
    return t == this.marks ? this : new In(this.type, this.attrs, this.text, t);
  }
  withText(t) {
    return t == this.text ? this : new In(this.type, this.attrs, t, this.marks);
  }
  cut(t = 0, n = this.text.length) {
    return t == 0 && n == this.text.length ? this : this.withText(this.text.slice(t, n));
  }
  eq(t) {
    return this.sameMarkup(t) && this.text == t.text;
  }
  toJSON() {
    let t = super.toJSON();
    return t.text = this.text, t;
  }
}
function yo(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    t = e[n].type.name + "(" + t + ")";
  return t;
}
function pi(e, t, n, r) {
  for (let i in t)
    if (!(i in e))
      throw new RangeError(`Unsupported attribute ${i} for ${n} of type ${r}`);
  for (let i in e)
    e[i].validate && e[i].validate(t[i]);
}
class yt {
  /**
  @internal
  */
  constructor(t) {
    this.validEnd = t, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(t, n) {
    let r = new ca(t, n);
    if (r.next == null)
      return yt.empty;
    let i = bo(r);
    r.next && r.err("Unexpected trailing text");
    let o = ma(ha(i));
    return ga(o, r), o;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(t) {
    for (let n = 0; n < this.next.length; n++)
      if (this.next[n].type == t)
        return this.next[n].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(t, n = 0, r = t.childCount) {
    let i = this;
    for (let o = n; i && o < r; o++)
      i = i.matchType(t.child(o).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let t = 0; t < this.next.length; t++) {
      let { type: n } = this.next[t];
      if (!(n.isText || n.hasRequiredAttrs()))
        return n;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(t) {
    for (let n = 0; n < this.next.length; n++)
      for (let r = 0; r < t.next.length; r++)
        if (this.next[n].type == t.next[r].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(t, n = !1, r = 0) {
    let i = [this];
    function o(s, a) {
      let c = s.matchFragment(t, r);
      if (c && (!n || c.validEnd))
        return O.from(a.map((l) => l.createAndFill()));
      for (let l = 0; l < s.next.length; l++) {
        let { type: p, next: d } = s.next[l];
        if (!(p.isText || p.hasRequiredAttrs()) && i.indexOf(d) == -1) {
          i.push(d);
          let f = o(d, a.concat(p));
          if (f)
            return f;
        }
      }
      return null;
    }
    return o(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(t) {
    for (let r = 0; r < this.wrapCache.length; r += 2)
      if (this.wrapCache[r] == t)
        return this.wrapCache[r + 1];
    let n = this.computeWrapping(t);
    return this.wrapCache.push(t, n), n;
  }
  /**
  @internal
  */
  computeWrapping(t) {
    let n = /* @__PURE__ */ Object.create(null), r = [{ match: this, type: null, via: null }];
    for (; r.length; ) {
      let i = r.shift(), o = i.match;
      if (o.matchType(t)) {
        let s = [];
        for (let a = i; a.type; a = a.via)
          s.push(a.type);
        return s.reverse();
      }
      for (let s = 0; s < o.next.length; s++) {
        let { type: a, next: c } = o.next[s];
        !a.isLeaf && !a.hasRequiredAttrs() && !(a.name in n) && (!i.type || c.validEnd) && (r.push({ match: a.contentMatch, type: a, via: i }), n[a.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(t) {
    if (t >= this.next.length)
      throw new RangeError(`There's no ${t}th edge in this content match`);
    return this.next[t];
  }
  /**
  @internal
  */
  toString() {
    let t = [];
    function n(r) {
      t.push(r);
      for (let i = 0; i < r.next.length; i++)
        t.indexOf(r.next[i].next) == -1 && n(r.next[i].next);
    }
    return n(this), t.map((r, i) => {
      let o = i + (r.validEnd ? "*" : " ") + " ";
      for (let s = 0; s < r.next.length; s++)
        o += (s ? ", " : "") + r.next[s].type.name + "->" + t.indexOf(r.next[s].next);
      return o;
    }).join(`
`);
  }
}
yt.empty = new yt(!0);
class ca {
  constructor(t, n) {
    this.string = t, this.nodeTypes = n, this.inline = null, this.pos = 0, this.tokens = t.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(t) {
    return this.next == t && (this.pos++ || !0);
  }
  err(t) {
    throw new SyntaxError(t + " (in content expression '" + this.string + "')");
  }
}
function bo(e) {
  let t = [];
  do
    t.push(la(e));
  while (e.eat("|"));
  return t.length == 1 ? t[0] : { type: "choice", exprs: t };
}
function la(e) {
  let t = [];
  do
    t.push(da(e));
  while (e.next && e.next != ")" && e.next != "|");
  return t.length == 1 ? t[0] : { type: "seq", exprs: t };
}
function da(e) {
  let t = ua(e);
  for (; ; )
    if (e.eat("+"))
      t = { type: "plus", expr: t };
    else if (e.eat("*"))
      t = { type: "star", expr: t };
    else if (e.eat("?"))
      t = { type: "opt", expr: t };
    else if (e.eat("{"))
      t = pa(e, t);
    else
      break;
  return t;
}
function fi(e) {
  /\D/.test(e.next) && e.err("Expected number, got '" + e.next + "'");
  let t = Number(e.next);
  return e.pos++, t;
}
function pa(e, t) {
  let n = fi(e), r = n;
  return e.eat(",") && (e.next != "}" ? r = fi(e) : r = -1), e.eat("}") || e.err("Unclosed braced range"), { type: "range", min: n, max: r, expr: t };
}
function fa(e, t) {
  let n = e.nodeTypes, r = n[t];
  if (r)
    return [r];
  let i = [];
  for (let o in n) {
    let s = n[o];
    s.isInGroup(t) && i.push(s);
  }
  return i.length == 0 && e.err("No node type or group '" + t + "' found"), i;
}
function ua(e) {
  if (e.eat("(")) {
    let t = bo(e);
    return e.eat(")") || e.err("Missing closing paren"), t;
  } else if (/\W/.test(e.next))
    e.err("Unexpected token '" + e.next + "'");
  else {
    let t = fa(e, e.next).map((n) => (e.inline == null ? e.inline = n.isInline : e.inline != n.isInline && e.err("Mixing inline and block content"), { type: "name", value: n }));
    return e.pos++, t.length == 1 ? t[0] : { type: "choice", exprs: t };
  }
}
function ha(e) {
  let t = [[]];
  return i(o(e, 0), n()), t;
  function n() {
    return t.push([]) - 1;
  }
  function r(s, a, c) {
    let l = { term: c, to: a };
    return t[s].push(l), l;
  }
  function i(s, a) {
    s.forEach((c) => c.to = a);
  }
  function o(s, a) {
    if (s.type == "choice")
      return s.exprs.reduce((c, l) => c.concat(o(l, a)), []);
    if (s.type == "seq")
      for (let c = 0; ; c++) {
        let l = o(s.exprs[c], a);
        if (c == s.exprs.length - 1)
          return l;
        i(l, a = n());
      }
    else if (s.type == "star") {
      let c = n();
      return r(a, c), i(o(s.expr, c), c), [r(c)];
    } else if (s.type == "plus") {
      let c = n();
      return i(o(s.expr, a), c), i(o(s.expr, c), c), [r(c)];
    } else {
      if (s.type == "opt")
        return [r(a)].concat(o(s.expr, a));
      if (s.type == "range") {
        let c = a;
        for (let l = 0; l < s.min; l++) {
          let p = n();
          i(o(s.expr, c), p), c = p;
        }
        if (s.max == -1)
          i(o(s.expr, c), c);
        else
          for (let l = s.min; l < s.max; l++) {
            let p = n();
            r(c, p), i(o(s.expr, c), p), c = p;
          }
        return [r(c)];
      } else {
        if (s.type == "name")
          return [r(a, void 0, s.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function xo(e, t) {
  return t - e;
}
function ui(e, t) {
  let n = [];
  return r(t), n.sort(xo);
  function r(i) {
    let o = e[i];
    if (o.length == 1 && !o[0].term)
      return r(o[0].to);
    n.push(i);
    for (let s = 0; s < o.length; s++) {
      let { term: a, to: c } = o[s];
      !a && n.indexOf(c) == -1 && r(c);
    }
  }
}
function ma(e) {
  let t = /* @__PURE__ */ Object.create(null);
  return n(ui(e, 0));
  function n(r) {
    let i = [];
    r.forEach((s) => {
      e[s].forEach(({ term: a, to: c }) => {
        if (!a)
          return;
        let l;
        for (let p = 0; p < i.length; p++)
          i[p][0] == a && (l = i[p][1]);
        ui(e, c).forEach((p) => {
          l || i.push([a, l = []]), l.indexOf(p) == -1 && l.push(p);
        });
      });
    });
    let o = t[r.join(",")] = new yt(r.indexOf(e.length - 1) > -1);
    for (let s = 0; s < i.length; s++) {
      let a = i[s][1].sort(xo);
      o.next.push({ type: i[s][0], next: t[a.join(",")] || n(a) });
    }
    return o;
  }
}
function ga(e, t) {
  for (let n = 0, r = [e]; n < r.length; n++) {
    let i = r[n], o = !i.validEnd, s = [];
    for (let a = 0; a < i.next.length; a++) {
      let { type: c, next: l } = i.next[a];
      s.push(c.name), o && !(c.isText || c.hasRequiredAttrs()) && (o = !1), r.indexOf(l) == -1 && r.push(l);
    }
    o && t.err("Only non-generatable nodes (" + s.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function ko(e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let n in e) {
    let r = e[n];
    if (!r.hasDefault)
      return null;
    t[n] = r.default;
  }
  return t;
}
function Io(e, t) {
  let n = /* @__PURE__ */ Object.create(null);
  for (let r in e) {
    let i = e[r], o = t && t[r];
    if (o === void 0)
      if (i.hasDefault)
        o = i.default;
      else
        throw new RangeError("No value supplied for attribute " + r);
    else i.validate && i.validate(o);
    n[r] = o;
  }
  return n;
}
function vo(e, t) {
  let n = /* @__PURE__ */ Object.create(null);
  if (t)
    for (let r in t)
      n[r] = new ba(e, r, t[r]);
  return n;
}
class vn {
  /**
  @internal
  */
  constructor(t, n, r) {
    this.name = t, this.schema = n, this.spec = r, this.markSet = null, this.groups = r.group ? r.group.split(" ") : [], this.attrs = vo(t, r.attrs), this.defaultAttrs = ko(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(r.inline || t == "text"), this.isText = t == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == yt.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(t) {
    return this.groups.indexOf(t) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let t in this.attrs)
      if (this.attrs[t].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(t) {
    return this == t || this.contentMatch.compatible(t.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(t) {
    return !t && this.defaultAttrs ? this.defaultAttrs : Io(this.attrs, t);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(t = null, n, r) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new je(this, this.computeAttrs(t), O.from(n), K.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(t = null, n, r) {
    return n = O.from(n), this.checkContent(n), new je(this, this.computeAttrs(t), n, K.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(t = null, n, r) {
    if (t = this.computeAttrs(t), n = O.from(n), n.size) {
      let s = this.contentMatch.fillBefore(n);
      if (!s)
        return null;
      n = s.append(n);
    }
    let i = this.contentMatch.matchFragment(n), o = i && i.fillBefore(O.empty, !0);
    return o ? new je(this, t, n.append(o), K.setFrom(r)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(t) {
    let n = this.contentMatch.matchFragment(t);
    if (!n || !n.validEnd)
      return !1;
    for (let r = 0; r < t.childCount; r++)
      if (!this.allowsMarks(t.child(r).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(t) {
    if (!this.validContent(t))
      throw new RangeError(`Invalid content for node ${this.name}: ${t.toString().slice(0, 50)}`);
  }
  /**
  @internal no longer useful, but called by old prosemirror-view versions
  */
  checkAttrs(t) {
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(t) {
    return this.markSet == null || this.markSet.indexOf(t) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(t) {
    if (this.markSet == null)
      return !0;
    for (let n = 0; n < t.length; n++)
      if (!this.allowsMarkType(t[n].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(t) {
    if (this.markSet == null)
      return t;
    let n;
    for (let r = 0; r < t.length; r++)
      this.allowsMarkType(t[r].type) ? n && n.push(t[r]) : n || (n = t.slice(0, r));
    return n ? n.length ? n : K.none : t;
  }
  /**
  @internal
  */
  static compile(t, n) {
    let r = /* @__PURE__ */ Object.create(null);
    t.forEach((o, s) => r[o] = new vn(o, n, s));
    let i = n.spec.topNode || "doc";
    if (!r[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!r.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let o in r.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return r;
  }
}
function ya(e, t, n) {
  let r = n.split("|");
  return (i) => {
    let o = i === null ? "null" : typeof i;
    if (r.indexOf(o) < 0)
      throw new RangeError(`Expected value of type ${r} for attribute ${t} on type ${e}, got ${o}`);
  };
}
class ba {
  constructor(t, n, r) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(r, "default"), this.default = r.default, this.validate = typeof r.validate == "string" ? ya(t, n, r.validate) : r.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class $n {
  /**
  @internal
  */
  constructor(t, n, r, i) {
    this.name = t, this.rank = n, this.schema = r, this.spec = i, this.attrs = vo(t, i.attrs), this.excluded = null;
    let o = ko(this.attrs);
    this.instance = o ? new K(this, o) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(t = null) {
    return !t && this.instance ? this.instance : new K(this, Io(this.attrs, t));
  }
  /**
  @internal
  */
  static compile(t, n) {
    let r = /* @__PURE__ */ Object.create(null), i = 0;
    return t.forEach((o, s) => r[o] = new $n(o, i++, n, s)), r;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(t) {
    for (var n = 0; n < t.length; n++)
      t[n].type == this && (t = t.slice(0, n).concat(t.slice(n + 1)), n--);
    return t;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(t) {
    for (let n = 0; n < t.length; n++)
      if (t[n].type == this)
        return t[n];
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(t) {
    return this.excluded.indexOf(t) > -1;
  }
}
class xa {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(t) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let n = this.spec = {};
    for (let i in t)
      n[i] = t[i];
    n.nodes = te.from(t.nodes), n.marks = te.from(t.marks || {}), this.nodes = vn.compile(this.spec.nodes, this), this.marks = $n.compile(this.spec.marks, this);
    let r = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let o = this.nodes[i], s = o.spec.content || "", a = o.spec.marks;
      if (o.contentMatch = r[s] || (r[s] = yt.parse(s, this.nodes)), o.inlineContent = o.contentMatch.inlineContent, o.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!o.isInline || !o.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = o;
      }
      o.markSet = a == "_" ? null : a ? hi(this, a.split(" ")) : a == "" || !o.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let o = this.marks[i], s = o.spec.excludes;
      o.excluded = s == null ? [o] : s == "" ? [] : hi(this, s.split(" "));
    }
    this.nodeFromJSON = (i) => je.fromJSON(this, i), this.markFromJSON = (i) => K.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(t, n = null, r, i) {
    if (typeof t == "string")
      t = this.nodeType(t);
    else if (t instanceof vn) {
      if (t.schema != this)
        throw new RangeError("Node type from different schema used (" + t.name + ")");
    } else throw new RangeError("Invalid node type: " + t);
    return t.createChecked(n, r, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(t, n) {
    let r = this.nodes.text;
    return new In(r, r.defaultAttrs, t, K.setFrom(n));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(t, n) {
    return typeof t == "string" && (t = this.marks[t]), t.create(n);
  }
  /**
  @internal
  */
  nodeType(t) {
    let n = this.nodes[t];
    if (!n)
      throw new RangeError("Unknown node type: " + t);
    return n;
  }
}
function hi(e, t) {
  let n = [];
  for (let r = 0; r < t.length; r++) {
    let i = t[r], o = e.marks[i], s = o;
    if (o)
      n.push(o);
    else
      for (let a in e.marks) {
        let c = e.marks[a];
        (i == "_" || c.spec.group && c.spec.group.split(" ").indexOf(i) > -1) && n.push(s = c);
      }
    if (!s)
      throw new SyntaxError("Unknown mark type: '" + t[r] + "'");
  }
  return n;
}
const wo = 65535, So = Math.pow(2, 16);
function ka(e, t) {
  return e + t * So;
}
function mi(e) {
  return e & wo;
}
function Ia(e) {
  return (e - (e & wo)) / So;
}
const Oo = 1, Ao = 2, gn = 4, Ro = 8;
class Ir {
  /**
  @internal
  */
  constructor(t, n, r) {
    this.pos = t, this.delInfo = n, this.recover = r;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & Ro) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (Oo | gn)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (Ao | gn)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & gn) > 0;
  }
}
class be {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(t, n = !1) {
    if (this.ranges = t, this.inverted = n, !t.length && be.empty)
      return be.empty;
  }
  /**
  @internal
  */
  recover(t) {
    let n = 0, r = mi(t);
    if (!this.inverted)
      for (let i = 0; i < r; i++)
        n += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[r * 3] + n + Ia(t);
  }
  mapResult(t, n = 1) {
    return this._map(t, n, !1);
  }
  map(t, n = 1) {
    return this._map(t, n, !0);
  }
  /**
  @internal
  */
  _map(t, n, r) {
    let i = 0, o = this.inverted ? 2 : 1, s = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let c = this.ranges[a] - (this.inverted ? i : 0);
      if (c > t)
        break;
      let l = this.ranges[a + o], p = this.ranges[a + s], d = c + l;
      if (t <= d) {
        let f = l ? t == c ? -1 : t == d ? 1 : n : n, u = c + i + (f < 0 ? 0 : p);
        if (r)
          return u;
        let m = t == (n < 0 ? c : d) ? null : ka(a / 3, t - c), h = 0;
        return l && (h |= t == c ? Ao : t == d ? Oo : gn, (n < 0 ? t != c : t != d) && (h |= Ro)), new Ir(u, h, m);
      }
      i += p - l;
    }
    return r ? t + i : new Ir(t + i, 0, null);
  }
  /**
  @internal
  */
  touches(t, n) {
    let r = 0, i = mi(n), o = this.inverted ? 2 : 1, s = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let c = this.ranges[a] - (this.inverted ? r : 0);
      if (c > t)
        break;
      let l = this.ranges[a + o], p = c + l;
      if (t <= p && a == i * 3)
        return !0;
      r += this.ranges[a + s] - l;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(t) {
    let n = this.inverted ? 2 : 1, r = this.inverted ? 1 : 2;
    for (let i = 0, o = 0; i < this.ranges.length; i += 3) {
      let s = this.ranges[i], a = s - (this.inverted ? o : 0), c = s + (this.inverted ? 0 : o), l = this.ranges[i + n], p = this.ranges[i + r];
      t(a, a + l, c, c + p), o += p - l;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new be(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(t) {
    return t == 0 ? be.empty : new be(t < 0 ? [0, -t, 0] : [0, 0, t]);
  }
}
be.empty = new be([]);
class zt {
  /**
  Create a new mapping with the given position maps.
  */
  constructor(t, n, r = 0, i = t ? t.length : 0) {
    this.mirror = n, this.from = r, this.to = i, this._maps = t || [], this.ownData = !(t || n);
  }
  /**
  The step maps in this mapping.
  */
  get maps() {
    return this._maps;
  }
  /**
  Create a mapping that maps only through a part of this one.
  */
  slice(t = 0, n = this.maps.length) {
    return new zt(this._maps, this.mirror, t, n);
  }
  /**
  Add a step map to the end of this mapping. If `mirrors` is
  given, it should be the index of the step map that is the mirror
  image of this one.
  */
  appendMap(t, n) {
    this.ownData || (this._maps = this._maps.slice(), this.mirror = this.mirror && this.mirror.slice(), this.ownData = !0), this.to = this._maps.push(t), n != null && this.setMirror(this._maps.length - 1, n);
  }
  /**
  Add all the step maps in a given mapping to this one (preserving
  mirroring information).
  */
  appendMapping(t) {
    for (let n = 0, r = this._maps.length; n < t._maps.length; n++) {
      let i = t.getMirror(n);
      this.appendMap(t._maps[n], i != null && i < n ? r + i : void 0);
    }
  }
  /**
  Finds the offset of the step map that mirrors the map at the
  given offset, in this mapping (as per the second argument to
  `appendMap`).
  */
  getMirror(t) {
    if (this.mirror) {
      for (let n = 0; n < this.mirror.length; n++)
        if (this.mirror[n] == t)
          return this.mirror[n + (n % 2 ? -1 : 1)];
    }
  }
  /**
  @internal
  */
  setMirror(t, n) {
    this.mirror || (this.mirror = []), this.mirror.push(t, n);
  }
  /**
  Append the inverse of the given mapping to this one.
  */
  appendMappingInverted(t) {
    for (let n = t.maps.length - 1, r = this._maps.length + t._maps.length; n >= 0; n--) {
      let i = t.getMirror(n);
      this.appendMap(t._maps[n].invert(), i != null && i > n ? r - i - 1 : void 0);
    }
  }
  /**
  Create an inverted version of this mapping.
  */
  invert() {
    let t = new zt();
    return t.appendMappingInverted(this), t;
  }
  /**
  Map a position through this mapping.
  */
  map(t, n = 1) {
    if (this.mirror)
      return this._map(t, n, !0);
    for (let r = this.from; r < this.to; r++)
      t = this._maps[r].map(t, n);
    return t;
  }
  /**
  Map a position through this mapping, returning a mapping
  result.
  */
  mapResult(t, n = 1) {
    return this._map(t, n, !1);
  }
  /**
  @internal
  */
  _map(t, n, r) {
    let i = 0;
    for (let o = this.from; o < this.to; o++) {
      let s = this._maps[o], a = s.mapResult(t, n);
      if (a.recover != null) {
        let c = this.getMirror(o);
        if (c != null && c > o && c < this.to) {
          o = c, t = this._maps[c].recover(a.recover);
          continue;
        }
      }
      i |= a.delInfo, t = a.pos;
    }
    return r ? t : new Ir(t, i, null);
  }
}
const nr = /* @__PURE__ */ Object.create(null);
class Z {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return be.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(t) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(t, n) {
    if (!n || !n.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let r = nr[n.stepType];
    if (!r)
      throw new RangeError(`No step type ${n.stepType} defined`);
    return r.fromJSON(t, n);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(t, n) {
    if (t in nr)
      throw new RangeError("Duplicate use of step JSON ID " + t);
    return nr[t] = n, n.prototype.jsonID = t, n;
  }
}
class X {
  /**
  @internal
  */
  constructor(t, n) {
    this.doc = t, this.failed = n;
  }
  /**
  Create a successful step result.
  */
  static ok(t) {
    return new X(t, null);
  }
  /**
  Create a failed step result.
  */
  static fail(t) {
    return new X(null, t);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(t, n, r, i) {
    try {
      return X.ok(t.replace(n, r, i));
    } catch (o) {
      if (o instanceof Yt)
        return X.fail(o.message);
      throw o;
    }
  }
}
function Lr(e, t, n) {
  let r = [];
  for (let i = 0; i < e.childCount; i++) {
    let o = e.child(i);
    o.content.size && (o = o.copy(Lr(o.content, t, o))), o.isInline && (o = t(o, n, i)), r.push(o);
  }
  return O.fromArray(r);
}
class _e extends Z {
  /**
  Create a mark step.
  */
  constructor(t, n, r) {
    super(), this.from = t, this.to = n, this.mark = r;
  }
  apply(t) {
    let n = t.slice(this.from, this.to), r = t.resolve(this.from), i = r.node(r.sharedDepth(this.to)), o = new A(Lr(n.content, (s, a) => !s.isAtom || !a.type.allowsMarkType(this.mark.type) ? s : s.mark(this.mark.addToSet(s.marks)), i), n.openStart, n.openEnd);
    return X.fromReplace(t, this.from, this.to, o);
  }
  invert(t) {
    let n = [];
    return t.nodesBetween(this.from, this.to, (r, i) => {
      if (r.isInline && r.isAtom) {
        let o = this.mark.addToSet(r.marks);
        if (!K.sameSet(o, r.marks)) {
          let s = Math.max(this.from, i), a = Math.min(this.to, i + r.nodeSize);
          wn(Je, s, a, this.mark, n);
          for (let c of r.marks)
            c.isInSet(o) || wn(_e, s, a, c, n);
        }
      }
    }), n.length == 1 ? n[0] : new ht(n);
  }
  map(t) {
    let n = t.map(this.from, 1), r = t.map(this.to, -1);
    return n >= r ? null : new _e(n, r, this.mark);
  }
  merge(t) {
    return t instanceof _e && t.mark.eq(this.mark) && this.from <= t.to && this.to >= t.from ? new _e(Math.min(this.from, t.from), Math.max(this.to, t.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new _e(n.from, n.to, t.markFromJSON(n.mark));
  }
}
Z.jsonID("addMark", _e);
class Je extends Z {
  /**
  Create a mark-removing step.
  */
  constructor(t, n, r) {
    super(), this.from = t, this.to = n, this.mark = r;
  }
  apply(t) {
    let n = t.slice(this.from, this.to), r = new A(Lr(n.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), t), n.openStart, n.openEnd);
    return X.fromReplace(t, this.from, this.to, r);
  }
  invert(t) {
    let n = [];
    return t.nodesBetween(this.from, this.to, (r, i) => {
      r.isInline && r.isAtom && this.mark.isInSet(r.marks) && wn(_e, Math.max(this.from, i), Math.min(this.to, i + r.nodeSize), this.mark, n);
    }), n.length == 1 ? n[0] : new ht(n);
  }
  map(t) {
    let n = t.map(this.from, 1), r = t.map(this.to, -1);
    return n >= r ? null : new Je(n, r, this.mark);
  }
  merge(t) {
    return t instanceof Je && t.mark.eq(this.mark) && this.from <= t.to && this.to >= t.from ? new Je(Math.min(this.from, t.from), Math.max(this.to, t.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new Je(n.from, n.to, t.markFromJSON(n.mark));
  }
}
Z.jsonID("removeMark", Je);
function wn(e, t, n, r, i) {
  let o = i.length ? i[i.length - 1] : null;
  o && o instanceof e && o.to == t && o.mark.eq(r) ? i[i.length - 1] = new e(o.from, n, r) : i.push(new e(t, n, r));
}
class ht extends Z {
  constructor(t) {
    super(), this.steps = t;
  }
  apply(t) {
    for (let n of this.steps) {
      let r = n.apply(t);
      if (!r.doc)
        return r;
      t = r.doc;
    }
    return new X(t, null);
  }
  invert(t) {
    return new ht(this.steps.map((n) => n.invert(t)));
  }
  map(t) {
    let n = [];
    for (let r of this.steps) {
      let i = r.map(t);
      i && n.push(i);
    }
    return n.length ? new ht(n) : null;
  }
  toJSON() {
    return { stepType: "markSet", steps: this.steps.map((t) => t.toJSON()) };
  }
  static fromJSON(t, n) {
    if (!Array.isArray(n.steps) || !n.steps.every((r) => r.stepType == "addMark" || r.stepType == "removeMark"))
      throw new RangeError("Invalid JSON for MarkSetStep");
    return new ht(n.steps.map((r) => Z.fromJSON(t, r)));
  }
}
Z.jsonID("markSet", ht);
class it extends Z {
  /**
  Create a node mark step.
  */
  constructor(t, n) {
    super(), this.pos = t, this.mark = n;
  }
  apply(t) {
    let n = t.nodeAt(this.pos);
    if (!n)
      return X.fail("No node at mark step's position");
    let r = n.type.create(n.attrs, null, this.mark.addToSet(n.marks));
    return X.fromReplace(t, this.pos, this.pos + 1, new A(O.from(r), 0, n.isLeaf ? 0 : 1));
  }
  invert(t) {
    let n = t.nodeAt(this.pos);
    if (n) {
      let r = this.mark.addToSet(n.marks);
      if (r.length == n.marks.length) {
        for (let i = 0; i < n.marks.length; i++)
          if (!n.marks[i].isInSet(r))
            return new it(this.pos, n.marks[i]);
        return new it(this.pos, this.mark);
      }
    }
    return new bt(this.pos, this.mark);
  }
  map(t) {
    let n = t.mapResult(this.pos, 1);
    return n.deletedAfter ? null : new it(n.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new it(n.pos, t.markFromJSON(n.mark));
  }
}
Z.jsonID("addNodeMark", it);
class bt extends Z {
  /**
  Create a mark-removing step.
  */
  constructor(t, n) {
    super(), this.pos = t, this.mark = n;
  }
  apply(t) {
    let n = t.nodeAt(this.pos);
    if (!n)
      return X.fail("No node at mark step's position");
    let r = n.type.create(n.attrs, null, this.mark.removeFromSet(n.marks));
    return X.fromReplace(t, this.pos, this.pos + 1, new A(O.from(r), 0, n.isLeaf ? 0 : 1));
  }
  invert(t) {
    let n = t.nodeAt(this.pos);
    return !n || !this.mark.isInSet(n.marks) ? this : new it(this.pos, this.mark);
  }
  map(t) {
    let n = t.mapResult(this.pos, 1);
    return n.deletedAfter ? null : new bt(n.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new bt(n.pos, t.markFromJSON(n.mark));
  }
}
Z.jsonID("removeNodeMark", bt);
class Y extends Z {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(t, n, r, i = !1) {
    super(), this.from = t, this.to = n, this.slice = r, this.structure = i;
  }
  apply(t) {
    return this.structure && vr(t, this.from, this.to) ? X.fail("Structure replace would overwrite content") : X.fromReplace(t, this.from, this.to, this.slice);
  }
  getMap() {
    return new be([this.from, this.to - this.from, this.slice.size]);
  }
  invert(t) {
    return new Y(this.from, this.from + this.slice.size, t.slice(this.from, this.to));
  }
  map(t) {
    let n = t.mapResult(this.to, -1), r = this.from == this.to && Y.MAP_BIAS < 0 ? n : t.mapResult(this.from, 1);
    return r.deletedAcross && n.deletedAcross ? null : new Y(r.pos, Math.max(r.pos, n.pos), this.slice, this.structure);
  }
  merge(t) {
    if (!(t instanceof Y) || t.structure || this.structure)
      return null;
    if (this.from + this.slice.size == t.from && !this.slice.openEnd && !t.slice.openStart) {
      let n = this.slice.size + t.slice.size == 0 ? A.empty : new A(this.slice.content.append(t.slice.content), this.slice.openStart, t.slice.openEnd);
      return new Y(this.from, this.to + (t.to - t.from), n, this.structure);
    } else if (t.to == this.from && !this.slice.openStart && !t.slice.openEnd) {
      let n = this.slice.size + t.slice.size == 0 ? A.empty : new A(t.slice.content.append(this.slice.content), t.slice.openStart, this.slice.openEnd);
      return new Y(t.from, this.to, n, this.structure);
    } else
      return null;
  }
  toJSON() {
    let t = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (t.slice = this.slice.toJSON()), this.structure && (t.structure = !0), t;
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new Y(n.from, n.to, A.fromJSON(t, n.slice), !!n.structure);
  }
}
Y.MAP_BIAS = 1;
Z.jsonID("replace", Y);
class Ee extends Z {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(t, n, r, i, o, s, a = !1) {
    super(), this.from = t, this.to = n, this.gapFrom = r, this.gapTo = i, this.slice = o, this.insert = s, this.structure = a;
  }
  apply(t) {
    if (this.structure && (vr(t, this.from, this.gapFrom) || vr(t, this.gapTo, this.to)))
      return X.fail("Structure gap-replace would overwrite content");
    let n = t.slice(this.gapFrom, this.gapTo);
    if (n.openStart || n.openEnd)
      return X.fail("Gap is not a flat range");
    let r = this.slice.insertAt(this.insert, n.content);
    return r ? X.fromReplace(t, this.from, this.to, r) : X.fail("Content does not fit in gap");
  }
  getMap() {
    return new be([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(t) {
    let n = this.gapTo - this.gapFrom;
    return new Ee(this.from, this.from + this.slice.size + n, this.from + this.insert, this.from + this.insert + n, t.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(t) {
    let n = t.mapResult(this.from, 1), r = t.mapResult(this.to, -1), i = this.from == this.gapFrom ? n.pos : t.map(this.gapFrom, -1), o = this.to == this.gapTo ? r.pos : t.map(this.gapTo, 1);
    return n.deletedAcross && r.deletedAcross || i < n.pos || o > r.pos ? null : new Ee(n.pos, r.pos, i, o, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let t = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (t.slice = this.slice.toJSON()), this.structure && (t.structure = !0), t;
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number" || typeof n.gapFrom != "number" || typeof n.gapTo != "number" || typeof n.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new Ee(n.from, n.to, n.gapFrom, n.gapTo, A.fromJSON(t, n.slice), n.insert, !!n.structure);
  }
}
Z.jsonID("replaceAround", Ee);
function vr(e, t, n) {
  let r = e.resolve(t), i = n - t, o = r.depth;
  for (; i > 0 && o > 0 && r.indexAfter(o) == r.node(o).childCount; )
    o--, i--;
  if (i > 0) {
    let s = r.node(o).maybeChild(r.indexAfter(o));
    for (; i > 0; ) {
      if (!s || s.isLeaf)
        return !0;
      s = s.firstChild, i--;
    }
  }
  return !1;
}
function va(e, t, n, r) {
  let i = [];
  e.doc.nodesBetween(t, n, (o, s, a) => {
    if (!o.isInline)
      return;
    let c = o.marks;
    if (!r.isInSet(c) && a.type.allowsMarkType(r.type)) {
      let l = Math.max(s, t), p = Math.min(s + o.nodeSize, n);
      wn(_e, l, p, r, i);
    }
  }), i.forEach((o) => e.step(o));
}
function wa(e, t, n, r) {
  let i = [], o = 0;
  e.doc.nodesBetween(t, n, (s, a) => {
    if (!s.isInline || !s.isAtom)
      return;
    o++;
    let c = null;
    if (r instanceof $n) {
      let l = s.marks, p;
      for (; p = r.isInSet(l); )
        (c || (c = [])).push(p), l = p.removeFromSet(l);
    } else r ? r.isInSet(s.marks) && (c = [r]) : c = s.marks;
    if (c && c.length) {
      let l = Math.min(a + s.nodeSize, n);
      for (let p = 0; p < c.length; p++) {
        let d = c[p], f;
        for (let u = 0; u < i.length; u++) {
          let m = i[u];
          m.step == o - 1 && d.eq(i[u].style) && (f = m);
        }
        f ? (f.to = l, f.step = o) : i.push({ style: d, from: Math.max(a, t), to: l, step: o });
      }
    }
  }), i.forEach((s) => e.step(new Je(s.from, s.to, s.style)));
}
function qr(e, t, n, r = n.contentMatch, i = !0) {
  let o = e.doc.nodeAt(t), s = [], a = t + 1;
  for (let c = 0; c < o.childCount; c++) {
    let l = o.child(c), p = a + l.nodeSize, d = r.matchType(l.type);
    if (!d)
      s.push(new Y(a, p, A.empty));
    else {
      r = d;
      for (let f = 0; f < l.marks.length; f++)
        n.allowsMarkType(l.marks[f].type) || e.step(new Je(a, p, l.marks[f]));
      if (i && l.isText && n.whitespace != "pre") {
        let f, u = /\r?\n|\r/g, m;
        for (; f = u.exec(l.text); )
          m || (m = new A(O.from(n.schema.text(" ", n.allowedMarks(l.marks))), 0, 0)), s.push(new Y(a + f.index, a + f.index + f[0].length, m));
      }
    }
    a = p;
  }
  if (!r.validEnd) {
    let c = r.fillBefore(O.empty, !0);
    e.replace(a, a, new A(c, 0, 0));
  }
  for (let c = s.length - 1; c >= 0; c--)
    e.step(s[c]);
}
function Sa(e, t, n) {
  let { $from: r, $to: i, depth: o } = t, s = r.before(o + 1), a = i.after(o + 1), c = s, l = a, p = O.empty, d = 0;
  for (let m = o, h = !1; m > n; m--)
    h || r.index(m) > 0 ? (h = !0, p = O.from(r.node(m).copy(p)), d++) : c--;
  let f = O.empty, u = 0;
  for (let m = o, h = !1; m > n; m--)
    h || i.after(m + 1) < i.end(m) ? (h = !0, f = O.from(i.node(m).copy(f)), u++) : l++;
  e.step(new Ee(c, l, s, a, new A(p.append(f), d, u), p.size - d, !0));
}
function Oa(e, t, n) {
  let r = O.empty;
  for (let s = n.length - 1; s >= 0; s--) {
    if (r.size) {
      let a = n[s].type.contentMatch.matchFragment(r);
      if (!a || !a.validEnd)
        throw new RangeError("Wrapper type given to Transform.wrap does not form valid content of its parent wrapper");
    }
    r = O.from(n[s].type.create(n[s].attrs, r));
  }
  let i = t.start, o = t.end;
  e.step(new Ee(i, o, i, o, new A(r, 0, 0), n.length, !0));
}
function Aa(e, t, n, r, i) {
  if (!r.isTextblock)
    throw new RangeError("Type given to setBlockType should be a textblock");
  let o = e.steps.length;
  e.doc.nodesBetween(t, n, (s, a) => {
    let c = typeof i == "function" ? i(s) : i;
    if (s.isTextblock && !s.hasMarkup(r, c) && Ra(e.doc, e.mapping.slice(o).map(a), r)) {
      let l = null;
      if (r.schema.linebreakReplacement) {
        let u = r.whitespace == "pre", m = !!r.contentMatch.matchType(r.schema.linebreakReplacement);
        u && !m ? l = !1 : !u && m && (l = !0);
      }
      l === !1 && To(e, s, a, o), qr(e, e.mapping.slice(o).map(a, 1), r, void 0, l === null);
      let p = e.mapping.slice(o), d = p.map(a, 1), f = p.map(a + s.nodeSize, 1);
      return e.step(new Ee(d, f, d + 1, f - 1, new A(O.from(r.create(c, null, s.marks)), 0, 0), 1, !0)), l === !0 && Eo(e, s, a, o), !1;
    }
  });
}
function Eo(e, t, n, r) {
  t.forEach((i, o) => {
    if (i.isText) {
      let s, a = /\r?\n|\r/g;
      for (; s = a.exec(i.text); ) {
        let c = e.mapping.slice(r).map(n + 1 + o + s.index);
        e.replaceWith(c, c + 1, t.type.schema.linebreakReplacement.create());
      }
    }
  });
}
function To(e, t, n, r) {
  t.forEach((i, o) => {
    if (i.type == i.type.schema.linebreakReplacement) {
      let s = e.mapping.slice(r).map(n + 1 + o);
      e.replaceWith(s, s + 1, t.type.schema.text(`
`));
    }
  });
}
function Ra(e, t, n) {
  let r = e.resolve(t), i = r.index();
  return r.parent.canReplaceWith(i, i + 1, n);
}
function Ea(e, t, n, r, i) {
  let o = e.doc.nodeAt(t);
  if (!o)
    throw new RangeError("No node at given position");
  n || (n = o.type);
  let s = n.create(r, null, i || o.marks);
  if (o.isLeaf)
    return e.replaceWith(t, t + o.nodeSize, s);
  if (!n.validContent(o.content))
    throw new RangeError("Invalid content for node type " + n.name);
  e.step(new Ee(t, t + o.nodeSize, t + 1, t + o.nodeSize - 1, new A(O.from(s), 0, 0), 1, !0));
}
function Ta(e, t, n = 1, r) {
  let i = e.doc.resolve(t), o = O.empty, s = O.empty;
  for (let a = i.depth, c = i.depth - n, l = n - 1; a > c; a--, l--) {
    o = O.from(i.node(a).copy(o));
    let p = r && r[l];
    s = O.from(p ? p.type.create(p.attrs, s) : i.node(a).copy(s));
  }
  e.step(new Y(t, t, new A(o.append(s), n, n), !0));
}
function Fa(e, t, n) {
  let r = null, { linebreakReplacement: i } = e.doc.type.schema, o = e.doc.resolve(t - n), s = o.node().type;
  if (i && s.inlineContent) {
    let p = s.whitespace == "pre", d = !!s.contentMatch.matchType(i);
    p && !d ? r = !1 : !p && d && (r = !0);
  }
  let a = e.steps.length;
  if (r === !1) {
    let p = e.doc.resolve(t + n);
    To(e, p.node(), p.before(), a);
  }
  s.inlineContent && qr(e, t + n - 1, s, o.node().contentMatchAt(o.index()), r == null);
  let c = e.mapping.slice(a), l = c.map(t - n);
  if (e.step(new Y(l, c.map(t + n, -1), A.empty, !0)), r === !0) {
    let p = e.doc.resolve(l);
    Eo(e, p.node(), p.before(), e.steps.length);
  }
  return e;
}
function Ca(e, t, n) {
  let r = e.resolve(t);
  if (r.parent.canReplaceWith(r.index(), r.index(), n))
    return t;
  if (r.parentOffset == 0)
    for (let i = r.depth - 1; i >= 0; i--) {
      let o = r.index(i);
      if (r.node(i).canReplaceWith(o, o, n))
        return r.before(i + 1);
      if (o > 0)
        return null;
    }
  if (r.parentOffset == r.parent.content.size)
    for (let i = r.depth - 1; i >= 0; i--) {
      let o = r.indexAfter(i);
      if (r.node(i).canReplaceWith(o, o, n))
        return r.after(i + 1);
      if (o < r.node(i).childCount)
        return null;
    }
  return null;
}
function Na(e, t, n = t, r = A.empty) {
  if (t == n && !r.size)
    return null;
  let i = e.resolve(t), o = e.resolve(n);
  return Fo(i, o, r) ? new Y(t, n, r) : new Ma(i, o, r).fit();
}
function Fo(e, t, n) {
  return !n.openStart && !n.openEnd && e.start() == t.start() && e.parent.canReplace(e.index(), t.index(), n.content);
}
class Ma {
  constructor(t, n, r) {
    this.$from = t, this.$to = n, this.unplaced = r, this.frontier = [], this.placed = O.empty;
    for (let i = 0; i <= t.depth; i++) {
      let o = t.node(i);
      this.frontier.push({
        type: o.type,
        match: o.contentMatchAt(t.indexAfter(i))
      });
    }
    for (let i = t.depth; i > 0; i--)
      this.placed = O.from(t.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size; ) {
      let l = this.findFittable();
      l ? this.placeNodes(l) : this.openMore() || this.dropNode();
    }
    let t = this.mustMoveInline(), n = this.placed.size - this.depth - this.$from.depth, r = this.$from, i = this.close(t < 0 ? this.$to : r.doc.resolve(t));
    if (!i)
      return null;
    let o = this.placed, s = r.depth, a = i.depth;
    for (; s && a && o.childCount == 1; )
      o = o.firstChild.content, s--, a--;
    let c = new A(o, s, a);
    return t > -1 ? new Ee(r.pos, t, this.$to.pos, this.$to.end(), c, n) : c.size || r.pos != this.$to.pos ? new Y(r.pos, i.pos, c) : null;
  }
  // Find a position on the start spine of `this.unplaced` that has
  // content that can be moved somewhere on the frontier. Returns two
  // depths, one for the slice and one for the frontier.
  findFittable() {
    let t = this.unplaced.openStart;
    for (let n = this.unplaced.content, r = 0, i = this.unplaced.openEnd; r < t; r++) {
      let o = n.firstChild;
      if (n.childCount > 1 && (i = 0), o.type.spec.isolating && i <= r) {
        t = r;
        break;
      }
      n = o.content;
    }
    for (let n = 1; n <= 2; n++)
      for (let r = n == 1 ? t : this.unplaced.openStart; r >= 0; r--) {
        let i, o = null;
        r ? (o = gi(this.unplaced.content, r - 1).firstChild, i = o.content) : i = this.unplaced.content;
        let s = i.firstChild;
        for (let a = this.depth; a >= 0; a--) {
          let { type: c, match: l } = this.frontier[a], p, d = null;
          if (n == 1 && (s ? l.matchType(s.type) || (d = l.fillBefore(O.from(s), !1)) : o && c.compatibleContent(o.type)))
            return { sliceDepth: r, frontierDepth: a, parent: o, inject: d };
          if (n == 2 && s && (p = l.findWrapping(s.type)))
            return { sliceDepth: r, frontierDepth: a, parent: o, wrap: p };
          if (o && l.matchType(o.type))
            break;
        }
      }
  }
  openMore() {
    let { content: t, openStart: n, openEnd: r } = this.unplaced;
    return yi(t, -1) <= n ? !1 : (this.unplaced.size > 1 && yi(t, 1) > r && r++, this.unplaced = new A(t, n + 1, r), !0);
  }
  dropNode() {
    let { content: t, openStart: n, openEnd: r } = this.unplaced, i = gi(t, n);
    if (i.childCount <= 1 && n > 0) {
      let o = t.size - n <= n + i.size;
      this.unplaced = new A(qt(t, n - 1, 1), n - 1, o ? n - 1 : r);
    } else
      this.unplaced = new A(qt(t, n, 1), n, r);
  }
  // Move content from the unplaced slice at `sliceDepth` to the
  // frontier node at `frontierDepth`. Close that frontier node when
  // applicable.
  placeNodes({ sliceDepth: t, frontierDepth: n, parent: r, inject: i, wrap: o }) {
    for (; this.depth > n; )
      this.closeFrontierNode();
    if (o)
      for (let h = 0; h < o.length; h++)
        this.openFrontierNode(o[h]);
    let s = this.unplaced, a = r ? r.content : s.content, c = s.openStart - t, l = 0, p = [], { match: d, type: f } = this.frontier[n];
    if (i) {
      for (let h = 0; h < i.childCount; h++)
        p.push(i.child(h));
      d = d.matchFragment(i);
    }
    let u = a.size + t - (s.content.size - s.openEnd);
    for (; l < a.childCount; ) {
      let h = a.child(l), y = d.matchType(h.type);
      if (!y)
        break;
      l++, (l > 1 || c == 0 || h.content.size) && (d = y, p.push(Co(h.mark(f.allowedMarks(h.marks)), l == 1 ? c : 0, l == a.childCount ? u : -1)));
    }
    let m = l == a.childCount;
    m || (u = -1), this.placed = Kt(this.placed, n, O.from(p)), this.frontier[n].match = d, m && u < 0 && r && r.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
    for (let h = 0, y = a; h < u; h++) {
      let x = y.lastChild;
      this.frontier.push({ type: x.type, match: x.contentMatchAt(x.childCount) }), y = x.content;
    }
    this.unplaced = m ? t == 0 ? A.empty : new A(qt(s.content, t - 1, 1), t - 1, u < 0 ? s.openEnd : t - 1) : new A(qt(s.content, t, l), s.openStart, s.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock)
      return -1;
    let t = this.frontier[this.depth], n;
    if (!t.type.isTextblock || !rr(this.$to, this.$to.depth, t.type, t.match, !1) || this.$to.depth == this.depth && (n = this.findCloseLevel(this.$to)) && n.depth == this.depth)
      return -1;
    let { depth: r } = this.$to, i = this.$to.after(r);
    for (; r > 1 && i == this.$to.end(--r); )
      ++i;
    return i;
  }
  findCloseLevel(t) {
    e: for (let n = Math.min(this.depth, t.depth); n >= 0; n--) {
      let { match: r, type: i } = this.frontier[n], o = n < t.depth && t.end(n + 1) == t.pos + (t.depth - (n + 1)), s = rr(t, n, i, r, o);
      if (s) {
        for (let a = n - 1; a >= 0; a--) {
          let { match: c, type: l } = this.frontier[a], p = rr(t, a, l, c, !0);
          if (!p || p.childCount)
            continue e;
        }
        return { depth: n, fit: s, move: o ? t.doc.resolve(t.after(n + 1)) : t };
      }
    }
  }
  close(t) {
    let n = this.findCloseLevel(t);
    if (!n)
      return null;
    for (; this.depth > n.depth; )
      this.closeFrontierNode();
    n.fit.childCount && (this.placed = Kt(this.placed, n.depth, n.fit)), t = n.move;
    for (let r = n.depth + 1; r <= t.depth; r++) {
      let i = t.node(r), o = i.type.contentMatch.fillBefore(i.content, !0, t.index(r));
      this.openFrontierNode(i.type, i.attrs, o);
    }
    return t;
  }
  openFrontierNode(t, n = null, r) {
    let i = this.frontier[this.depth];
    i.match = i.match.matchType(t), this.placed = Kt(this.placed, this.depth, O.from(t.create(n, r))), this.frontier.push({ type: t, match: t.contentMatch });
  }
  closeFrontierNode() {
    let n = this.frontier.pop().match.fillBefore(O.empty, !0);
    n.childCount && (this.placed = Kt(this.placed, this.frontier.length, n));
  }
}
function qt(e, t, n) {
  return t == 0 ? e.cutByIndex(n, e.childCount) : e.replaceChild(0, e.firstChild.copy(qt(e.firstChild.content, t - 1, n)));
}
function Kt(e, t, n) {
  return t == 0 ? e.append(n) : e.replaceChild(e.childCount - 1, e.lastChild.copy(Kt(e.lastChild.content, t - 1, n)));
}
function gi(e, t) {
  for (let n = 0; n < t; n++)
    e = e.firstChild.content;
  return e;
}
function Co(e, t, n) {
  if (t <= 0)
    return e;
  let r = e.content;
  return t > 1 && (r = r.replaceChild(0, Co(r.firstChild, t - 1, r.childCount == 1 ? n - 1 : 0))), t > 0 && (r = e.type.contentMatch.fillBefore(r).append(r), n <= 0 && (r = r.append(e.type.contentMatch.matchFragment(r).fillBefore(O.empty, !0)))), e.copy(r);
}
function rr(e, t, n, r, i) {
  let o = e.node(t), s = i ? e.indexAfter(t) : e.index(t);
  if (s == o.childCount && !n.compatibleContent(o.type))
    return null;
  let a = r.fillBefore(o.content, !0, s);
  return a && !Pa(n, o.content, s) ? a : null;
}
function Pa(e, t, n) {
  for (let r = n; r < t.childCount; r++)
    if (!e.allowsMarks(t.child(r).marks))
      return !0;
  return !1;
}
function za(e) {
  return e.spec.defining || e.spec.definingForContent;
}
function yi(e, t) {
  for (let n = 0; ; n++) {
    let r = t < 0 ? e.firstChild : e.lastChild;
    if (!r || r.isAtom)
      return n;
    e = r.content;
  }
}
function ja(e, t, n, r) {
  if (!r.size)
    return e.deleteRange(t, n);
  let i = e.doc.resolve(t), o = e.doc.resolve(n);
  if (Fo(i, o, r))
    return e.step(new Y(t, n, r));
  let s = Mo(i, o);
  s[s.length - 1] == 0 && s.pop();
  let a = -(i.depth + 1);
  s.unshift(a);
  for (let f = i.depth, u = i.pos - 1; f > 0; f--, u--) {
    let m = i.node(f).type.spec;
    if (m.defining || m.definingAsContext || m.isolating)
      break;
    s.indexOf(f) > -1 ? a = f : i.before(f) == u && s.splice(1, 0, -f);
  }
  let c = s.indexOf(a), l = [], p = r.openStart;
  for (let f = r.content, u = 0; ; u++) {
    let m = f.firstChild;
    if (l.push(m), u == r.openStart)
      break;
    f = m.content;
  }
  for (let f = p - 1; f >= 0; f--) {
    let u = l[f], m = za(u.type);
    if (m && !u.sameMarkup(i.node(Math.abs(a) - 1)))
      p = f;
    else if (m || !u.type.isTextblock)
      break;
  }
  for (let f = r.openStart; f >= 0; f--) {
    let u = (f + p + 1) % (r.openStart + 1), m = l[u];
    if (m)
      for (let h = 0; h < s.length; h++) {
        let y = s[(h + c) % s.length], x = !0;
        y < 0 && (x = !1, y = -y);
        let k = i.node(y - 1), w = i.index(y - 1);
        if (k.canReplaceWith(w, w, m.type, m.marks))
          return e.replace(i.before(y), x ? o.after(y) : n, new A(No(r.content, 0, r.openStart, u), u, r.openEnd));
      }
  }
  let d = e.steps.length;
  for (let f = s.length - 1; f >= 0 && (e.replace(t, n, r), !(e.steps.length > d)); f--) {
    let u = s[f];
    u < 0 || (t = i.before(u), n = o.after(u));
  }
}
function No(e, t, n, r, i) {
  if (t < n) {
    let o = e.firstChild;
    e = e.replaceChild(0, o.copy(No(o.content, t + 1, n, r, o)));
  }
  if (t > r) {
    let o = i.contentMatchAt(0), s = o.fillBefore(e).append(e);
    e = s.append(o.matchFragment(s).fillBefore(O.empty, !0));
  }
  return e;
}
function Da(e, t, n, r) {
  if (!r.isInline && t == n && e.doc.resolve(t).parent.content.size) {
    let i = Ca(e.doc, t, r.type);
    i != null && (t = n = i);
  }
  e.replaceRange(t, n, new A(O.from(r), 0, 0));
}
function $a(e, t, n) {
  let r = e.doc.resolve(t), i = e.doc.resolve(n);
  if (r.parent.isTextblock && i.parent.isTextblock && r.start() != i.start() && r.parentOffset == 0 && i.parentOffset == 0) {
    let s = r.sharedDepth(n), a = !1;
    for (let c = r.depth; c > s; c--)
      r.node(c).type.spec.isolating && (a = !0);
    for (let c = i.depth; c > s; c--)
      i.node(c).type.spec.isolating && (a = !0);
    if (!a) {
      for (let c = r.depth; c > 0 && t == r.start(c); c--)
        t = r.before(c);
      for (let c = i.depth; c > 0 && n == i.start(c); c--)
        n = i.before(c);
      r = e.doc.resolve(t), i = e.doc.resolve(n);
    }
  }
  let o = Mo(r, i);
  for (let s = 0; s < o.length; s++) {
    let a = o[s], c = s == o.length - 1;
    if (c && a == 0 || r.node(a).type.contentMatch.validEnd)
      return e.delete(r.start(a), i.end(a));
    if (a > 0 && (c || r.node(a - 1).canReplace(r.index(a - 1), i.indexAfter(a - 1))))
      return e.delete(r.before(a), i.after(a));
  }
  for (let s = 1; s <= r.depth && s <= i.depth; s++)
    if (t - r.start(s) == r.depth - s && n > r.end(s) && i.end(s) - n != i.depth - s && r.start(s - 1) == i.start(s - 1) && r.node(s - 1).canReplace(r.index(s - 1), i.index(s - 1)))
      return e.delete(r.before(s), n);
  e.delete(t, n);
}
function Mo(e, t) {
  let n = [], r = Math.min(e.depth, t.depth);
  for (let i = r; i >= 0; i--) {
    let o = e.start(i);
    if (o < e.pos - (e.depth - i) || t.end(i) > t.pos + (t.depth - i) || e.node(i).type.spec.isolating || t.node(i).type.spec.isolating)
      break;
    (o == t.start(i) || i == e.depth && i == t.depth && e.parent.inlineContent && t.parent.inlineContent && i && t.start(i - 1) == o - 1) && n.push(i);
  }
  return n;
}
class Ct extends Z {
  /**
  Construct an attribute step.
  */
  constructor(t, n, r) {
    super(), this.pos = t, this.attr = n, this.value = r;
  }
  apply(t) {
    let n = t.nodeAt(this.pos);
    if (!n)
      return X.fail("No node at attribute step's position");
    let r = /* @__PURE__ */ Object.create(null);
    for (let o in n.attrs)
      r[o] = n.attrs[o];
    r[this.attr] = this.value;
    let i = n.type.create(r, null, n.marks);
    return X.fromReplace(t, this.pos, this.pos + 1, new A(O.from(i), 0, n.isLeaf ? 0 : 1));
  }
  getMap() {
    return be.empty;
  }
  invert(t) {
    return new Ct(this.pos, this.attr, t.nodeAt(this.pos).attrs[this.attr]);
  }
  map(t) {
    let n = t.mapResult(this.pos, 1);
    return n.deletedAfter ? null : new Ct(n.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(t, n) {
    if (typeof n.pos != "number" || typeof n.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new Ct(n.pos, n.attr, n.value);
  }
}
Z.jsonID("attr", Ct);
class en extends Z {
  /**
  Construct an attribute step.
  */
  constructor(t, n) {
    super(), this.attr = t, this.value = n;
  }
  apply(t) {
    let n = /* @__PURE__ */ Object.create(null);
    for (let i in t.attrs)
      n[i] = t.attrs[i];
    n[this.attr] = this.value;
    let r = t.type.create(n, t.content, t.marks);
    return X.ok(r);
  }
  getMap() {
    return be.empty;
  }
  invert(t) {
    return new en(this.attr, t.attrs[this.attr]);
  }
  map(t) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(t, n) {
    if (typeof n.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new en(n.attr, n.value);
  }
}
Z.jsonID("docAttr", en);
let jt = class extends Error {
};
jt = function e(t) {
  let n = Error.call(this, t);
  return n.__proto__ = e.prototype, n;
};
jt.prototype = Object.create(Error.prototype);
jt.prototype.constructor = jt;
jt.prototype.name = "TransformError";
class Ba {
  /**
  Create a transform that starts with the given document.
  */
  constructor(t) {
    this.doc = t, this.steps = [], this.docs = [], this.mapping = new zt();
  }
  /**
  The starting document.
  */
  get before() {
    return this.docs.length ? this.docs[0] : this.doc;
  }
  /**
  Apply a new step in this transform, saving the result. Throws an
  error when the step fails.
  */
  step(t) {
    let n = this.maybeStep(t);
    if (n.failed)
      throw new jt(n.failed);
    return this;
  }
  /**
  Try to apply a step in this transformation, ignoring it if it
  fails. Returns the step result.
  */
  maybeStep(t) {
    let n = t.apply(this.doc);
    return n.failed || this.addStep(t, n.doc), n;
  }
  /**
  True when the document has been changed (when there are any
  steps).
  */
  get docChanged() {
    return this.steps.length > 0;
  }
  /**
  Return a single range, in post-transform document positions,
  that covers all content changed by this transform. Returns null
  if no replacements are made. Note that this will ignore changes
  that add/remove marks without replacing the underlying content.
  */
  changedRange() {
    let t = 1e9, n = -1e9;
    for (let r = 0; r < this.mapping.maps.length; r++) {
      let i = this.mapping.maps[r];
      r && (t = i.map(t, 1), n = i.map(n, -1)), i.forEach((o, s, a, c) => {
        t = Math.min(t, a), n = Math.max(n, c);
      });
    }
    return t == 1e9 ? null : { from: t, to: n };
  }
  /**
  @internal
  */
  addStep(t, n) {
    this.docs.push(this.doc), this.steps.push(t), this.mapping.appendMap(t.getMap()), this.doc = n;
  }
  /**
  Replace the part of the document between `from` and `to` with the
  given `slice`.
  */
  replace(t, n = t, r = A.empty) {
    let i = Na(this.doc, t, n, r);
    return i && this.step(i), this;
  }
  /**
  Replace the given range with the given content, which may be a
  fragment, node, or array of nodes.
  */
  replaceWith(t, n, r) {
    return this.replace(t, n, new A(O.from(r), 0, 0));
  }
  /**
  Delete the content between the given positions.
  */
  delete(t, n) {
    return this.replace(t, n, A.empty);
  }
  /**
  Insert the given content at the given position.
  */
  insert(t, n) {
    return this.replaceWith(t, t, n);
  }
  /**
  Replace a range of the document with a given slice, using
  `from`, `to`, and the slice's
  [`openStart`](https://prosemirror.net/docs/ref/#model.Slice.openStart) property as hints, rather
  than fixed start and end points. This method may grow the
  replaced area or close open nodes in the slice in order to get a
  fit that is more in line with WYSIWYG expectations, by dropping
  fully covered parent nodes of the replaced region when they are
  marked [non-defining as
  context](https://prosemirror.net/docs/ref/#model.NodeSpec.definingAsContext), or including an
  open parent node from the slice that _is_ marked as [defining
  its content](https://prosemirror.net/docs/ref/#model.NodeSpec.definingForContent).
  
  This is the method, for example, to handle paste. The similar
  [`replace`](https://prosemirror.net/docs/ref/#transform.Transform.replace) method is a more
  primitive tool which will _not_ move the start and end of its given
  range, and is useful in situations where you need more precise
  control over what happens.
  */
  replaceRange(t, n, r) {
    return ja(this, t, n, r), this;
  }
  /**
  Replace the given range with a node, but use `from` and `to` as
  hints, rather than precise positions. When from and to are the same
  and are at the start or end of a parent node in which the given
  node doesn't fit, this method may _move_ them out towards a parent
  that does allow the given node to be placed. When the given range
  completely covers a parent node, this method may completely replace
  that parent node.
  */
  replaceRangeWith(t, n, r) {
    return Da(this, t, n, r), this;
  }
  /**
  Delete the given range, expanding it to cover fully covered
  parent nodes until a valid replace is found.
  */
  deleteRange(t, n) {
    return $a(this, t, n), this;
  }
  /**
  Split the content in the given range off from its parent, if there
  is sibling content before or after it, and move it up the tree to
  the depth specified by `target`. You'll probably want to use
  [`liftTarget`](https://prosemirror.net/docs/ref/#transform.liftTarget) to compute `target`, to make
  sure the lift is valid.
  */
  lift(t, n) {
    return Sa(this, t, n), this;
  }
  /**
  Join the blocks around the given position. If depth is 2, their
  last and first siblings are also joined, and so on.
  */
  join(t, n = 1) {
    return Fa(this, t, n), this;
  }
  /**
  Wrap the given [range](https://prosemirror.net/docs/ref/#model.NodeRange) in the given set of wrappers.
  The wrappers are assumed to be valid in this position, and should
  probably be computed with [`findWrapping`](https://prosemirror.net/docs/ref/#transform.findWrapping).
  */
  wrap(t, n) {
    return Oa(this, t, n), this;
  }
  /**
  Set the type of all textblocks (partly) between `from` and `to` to
  the given node type with the given attributes.
  */
  setBlockType(t, n = t, r, i = null) {
    return Aa(this, t, n, r, i), this;
  }
  /**
  Change the type, attributes, and/or marks of the node at `pos`.
  When `type` isn't given, the existing node type is preserved,
  */
  setNodeMarkup(t, n, r = null, i) {
    return Ea(this, t, n, r, i), this;
  }
  /**
  Set a single attribute on a given node to a new value.
  The `pos` addresses the document content. Use `setDocAttribute`
  to set attributes on the document itself.
  */
  setNodeAttribute(t, n, r) {
    return this.step(new Ct(t, n, r)), this;
  }
  /**
  Set a single attribute on the document to a new value.
  */
  setDocAttribute(t, n) {
    return this.step(new en(t, n)), this;
  }
  /**
  Add a mark to the node at position `pos`.
  */
  addNodeMark(t, n) {
    return this.step(new it(t, n)), this;
  }
  /**
  Remove a mark (or all marks of the given type) from the node at
  position `pos`.
  */
  removeNodeMark(t, n) {
    let r = this.doc.nodeAt(t);
    if (!r)
      throw new RangeError("No node at position " + t);
    if (n instanceof K)
      n.isInSet(r.marks) && this.step(new bt(t, n));
    else {
      let i = r.marks, o, s = [];
      for (; o = n.isInSet(i); )
        s.push(new bt(t, o)), i = o.removeFromSet(i);
      for (let a = s.length - 1; a >= 0; a--)
        this.step(s[a]);
    }
    return this;
  }
  /**
  Split the node at the given position, and optionally, if `depth` is
  greater than one, any number of nodes above that. By default, the
  parts split off will inherit the node type of the original node.
  This can be changed by passing an array of types and attributes to
  use after the split (with the outermost nodes coming first).
  */
  split(t, n = 1, r) {
    return Ta(this, t, n, r), this;
  }
  /**
  Add the given mark to the inline content between `from` and `to`.
  */
  addMark(t, n, r) {
    return va(this, t, n, r), this;
  }
  /**
  Remove marks from inline nodes between `from` and `to`. When
  `mark` is a single mark, remove precisely that mark. When it is
  a mark type, remove all marks of that type. When it is null,
  remove all marks of any type.
  */
  removeMark(t, n, r) {
    return wa(this, t, n, r), this;
  }
  /**
  Removes all marks and nodes from the content of the node at
  `pos` that don't match the given new parent node type. Accepts
  an optional starting [content match](https://prosemirror.net/docs/ref/#model.ContentMatch) as
  third argument.
  */
  clearIncompatible(t, n, r) {
    return qr(this, t, n, r), this;
  }
}
const ir = /* @__PURE__ */ Object.create(null);
class H {
  /**
  Initialize a selection with the head and anchor and ranges. If no
  ranges are given, constructs a single range across `$anchor` and
  `$head`.
  */
  constructor(t, n, r) {
    this.$anchor = t, this.$head = n, this.ranges = r || [new _a(t.min(n), t.max(n))];
  }
  /**
  The selection's anchor, as an unresolved position.
  */
  get anchor() {
    return this.$anchor.pos;
  }
  /**
  The selection's head.
  */
  get head() {
    return this.$head.pos;
  }
  /**
  The lower bound of the selection's main range.
  */
  get from() {
    return this.$from.pos;
  }
  /**
  The upper bound of the selection's main range.
  */
  get to() {
    return this.$to.pos;
  }
  /**
  The resolved lower  bound of the selection's main range.
  */
  get $from() {
    return this.ranges[0].$from;
  }
  /**
  The resolved upper bound of the selection's main range.
  */
  get $to() {
    return this.ranges[0].$to;
  }
  /**
  Indicates whether the selection contains any content.
  */
  get empty() {
    let t = this.ranges;
    for (let n = 0; n < t.length; n++)
      if (t[n].$from.pos != t[n].$to.pos)
        return !1;
    return !0;
  }
  /**
  Get the content of this selection as a slice.
  */
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  /**
  Replace the selection with a slice or, if no slice is given,
  delete the selection. Will append to the given transaction.
  */
  replace(t, n = A.empty) {
    let r = n.content.lastChild, i = null;
    for (let a = 0; a < n.openEnd; a++)
      i = r, r = r.lastChild;
    let o = t.steps.length, s = this.ranges;
    for (let a = 0; a < s.length; a++) {
      let { $from: c, $to: l } = s[a], p = t.mapping.slice(o);
      t.replaceRange(p.map(c.pos), p.map(l.pos), a ? A.empty : n), a == 0 && ki(t, o, (r ? r.isInline : i && i.isTextblock) ? -1 : 1);
    }
  }
  /**
  Replace the selection with the given node, appending the changes
  to the given transaction.
  */
  replaceWith(t, n) {
    let r = t.steps.length, i = this.ranges;
    for (let o = 0; o < i.length; o++) {
      let { $from: s, $to: a } = i[o], c = t.mapping.slice(r), l = c.map(s.pos), p = c.map(a.pos);
      o ? t.deleteRange(l, p) : (t.replaceRangeWith(l, p, n), ki(t, r, n.isInline ? -1 : 1));
    }
  }
  /**
  Find a valid cursor or leaf node selection starting at the given
  position and searching back if `dir` is negative, and forward if
  positive. When `textOnly` is true, only consider cursor
  selections. Will return null when no valid selection position is
  found.
  */
  static findFrom(t, n, r = !1) {
    let i = t.parent.inlineContent ? new ze(t) : Et(t.node(0), t.parent, t.pos, t.index(), n, r);
    if (i)
      return i;
    for (let o = t.depth - 1; o >= 0; o--) {
      let s = n < 0 ? Et(t.node(0), t.node(o), t.before(o + 1), t.index(o), n, r) : Et(t.node(0), t.node(o), t.after(o + 1), t.index(o) + 1, n, r);
      if (s)
        return s;
    }
    return null;
  }
  /**
  Find a valid cursor or leaf node selection near the given
  position. Searches forward first by default, but if `bias` is
  negative, it will search backwards first.
  */
  static near(t, n = 1) {
    return this.findFrom(t, n) || this.findFrom(t, -n) || new He(t.node(0));
  }
  /**
  Find the cursor or leaf node selection closest to the start of
  the given document. Will return an
  [`AllSelection`](https://prosemirror.net/docs/ref/#state.AllSelection) if no valid position
  exists.
  */
  static atStart(t) {
    return Et(t, t, 0, 0, 1) || new He(t);
  }
  /**
  Find the cursor or leaf node selection closest to the end of the
  given document.
  */
  static atEnd(t) {
    return Et(t, t, t.content.size, t.childCount, -1) || new He(t);
  }
  /**
  Deserialize the JSON representation of a selection. Must be
  implemented for custom classes (as a static class method).
  */
  static fromJSON(t, n) {
    if (!n || !n.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let r = ir[n.type];
    if (!r)
      throw new RangeError(`No selection type ${n.type} defined`);
    return r.fromJSON(t, n);
  }
  /**
  To be able to deserialize selections from JSON, custom selection
  classes must register themselves with an ID string, so that they
  can be disambiguated. Try to pick something that's unlikely to
  clash with classes from other modules.
  */
  static jsonID(t, n) {
    if (t in ir)
      throw new RangeError("Duplicate use of selection JSON ID " + t);
    return ir[t] = n, n.prototype.jsonID = t, n;
  }
  /**
  Get a [bookmark](https://prosemirror.net/docs/ref/#state.SelectionBookmark) for this selection,
  which is a value that can be mapped without having access to a
  current document, and later resolved to a real selection for a
  given document again. (This is used mostly by the history to
  track and restore old selections.) The default implementation of
  this method just converts the selection to a text selection and
  returns the bookmark for that.
  */
  getBookmark() {
    return ze.between(this.$anchor, this.$head).getBookmark();
  }
}
H.prototype.visible = !0;
class _a {
  /**
  Create a range.
  */
  constructor(t, n) {
    this.$from = t, this.$to = n;
  }
}
let bi = !1;
function xi(e) {
  !bi && !e.parent.inlineContent && (bi = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + e.parent.type.name + ")"));
}
class ze extends H {
  /**
  Construct a text selection between the given points.
  */
  constructor(t, n = t) {
    xi(t), xi(n), super(t, n);
  }
  /**
  Returns a resolved position if this is a cursor selection (an
  empty text selection), and null otherwise.
  */
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(t, n) {
    let r = t.resolve(n.map(this.head));
    if (!r.parent.inlineContent)
      return H.near(r);
    let i = t.resolve(n.map(this.anchor));
    return new ze(i.parent.inlineContent ? i : r, r);
  }
  replace(t, n = A.empty) {
    if (super.replace(t, n), n == A.empty) {
      let r = this.$from.marksAcross(this.$to);
      r && t.ensureMarks(r);
    }
  }
  eq(t) {
    return t instanceof ze && t.anchor == this.anchor && t.head == this.head;
  }
  getBookmark() {
    return new Bn(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.anchor != "number" || typeof n.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new ze(t.resolve(n.anchor), t.resolve(n.head));
  }
  /**
  Create a text selection from non-resolved positions.
  */
  static create(t, n, r = n) {
    let i = t.resolve(n);
    return new this(i, r == n ? i : t.resolve(r));
  }
  /**
  Return a text selection that spans the given positions or, if
  they aren't text positions, find a text selection near them.
  `bias` determines whether the method searches forward (default)
  or backwards (negative number) first. Will fall back to calling
  [`Selection.near`](https://prosemirror.net/docs/ref/#state.Selection^near) when the document
  doesn't contain a valid text position.
  */
  static between(t, n, r) {
    let i = t.pos - n.pos;
    if ((!r || i) && (r = i >= 0 ? 1 : -1), !n.parent.inlineContent) {
      let o = H.findFrom(n, r, !0) || H.findFrom(n, -r, !0);
      if (o)
        n = o.$head;
      else
        return H.near(n, r);
    }
    return t.parent.inlineContent || (i == 0 ? t = n : (t = (H.findFrom(t, -r, !0) || H.findFrom(t, r, !0)).$anchor, t.pos < n.pos != i < 0 && (t = n))), new ze(t, n);
  }
}
H.jsonID("text", ze);
class Bn {
  constructor(t, n) {
    this.anchor = t, this.head = n;
  }
  map(t) {
    return new Bn(t.map(this.anchor), t.map(this.head));
  }
  resolve(t) {
    return ze.between(t.resolve(this.anchor), t.resolve(this.head));
  }
}
class Ae extends H {
  /**
  Create a node selection. Does not verify the validity of its
  argument.
  */
  constructor(t) {
    let n = t.nodeAfter, r = t.node(0).resolve(t.pos + n.nodeSize);
    super(t, r), this.node = n;
  }
  map(t, n) {
    let { deleted: r, pos: i } = n.mapResult(this.anchor), o = t.resolve(i);
    return r ? H.near(o) : new Ae(o);
  }
  content() {
    return new A(O.from(this.node), 0, 0);
  }
  eq(t) {
    return t instanceof Ae && t.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new Kr(this.anchor);
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new Ae(t.resolve(n.anchor));
  }
  /**
  Create a node selection from non-resolved positions.
  */
  static create(t, n) {
    return new Ae(t.resolve(n));
  }
  /**
  Determines whether the given node may be selected as a node
  selection.
  */
  static isSelectable(t) {
    return !t.isText && t.type.spec.selectable !== !1;
  }
}
Ae.prototype.visible = !1;
H.jsonID("node", Ae);
class Kr {
  constructor(t) {
    this.anchor = t;
  }
  map(t) {
    let { deleted: n, pos: r } = t.mapResult(this.anchor);
    return n ? new Bn(r, r) : new Kr(r);
  }
  resolve(t) {
    let n = t.resolve(this.anchor), r = n.nodeAfter;
    return r && Ae.isSelectable(r) ? new Ae(n) : H.near(n);
  }
}
class He extends H {
  /**
  Create an all-selection over the given document.
  */
  constructor(t) {
    super(t.resolve(0), t.resolve(t.content.size));
  }
  replace(t, n = A.empty) {
    if (n == A.empty) {
      t.delete(0, t.doc.content.size);
      let r = H.atStart(t.doc);
      r.eq(t.selection) || t.setSelection(r);
    } else
      super.replace(t, n);
  }
  toJSON() {
    return { type: "all" };
  }
  /**
  @internal
  */
  static fromJSON(t) {
    return new He(t);
  }
  map(t) {
    return new He(t);
  }
  eq(t) {
    return t instanceof He;
  }
  getBookmark() {
    return Va;
  }
}
H.jsonID("all", He);
const Va = {
  map() {
    return this;
  },
  resolve(e) {
    return new He(e);
  }
};
function Et(e, t, n, r, i, o = !1) {
  if (t.inlineContent)
    return ze.create(e, n);
  for (let s = r - (i > 0 ? 0 : 1); i > 0 ? s < t.childCount : s >= 0; s += i) {
    let a = t.child(s);
    if (a.isAtom) {
      if (!o && Ae.isSelectable(a))
        return Ae.create(e, n - (i < 0 ? a.nodeSize : 0));
    } else {
      let c = Et(e, a, n + i, i < 0 ? a.childCount : 0, i, o);
      if (c)
        return c;
    }
    n += a.nodeSize * i;
  }
  return null;
}
function ki(e, t, n) {
  let r = e.steps.length - 1;
  if (r < t)
    return;
  let i = e.steps[r];
  if (!(i instanceof Y || i instanceof Ee))
    return;
  let o = e.mapping.maps[r], s;
  o.forEach((a, c, l, p) => {
    s == null && (s = p);
  }), e.setSelection(H.near(e.doc.resolve(s), n));
}
const Ii = 1, dn = 2, vi = 4;
class Po extends Ba {
  /**
  @internal
  */
  constructor(t) {
    super(t.doc), this.curSelectionFor = 0, this.updated = 0, this.meta = /* @__PURE__ */ Object.create(null), this.time = Date.now(), this.curSelection = t.selection, this.storedMarks = t.storedMarks;
  }
  /**
  The transaction's current selection. This defaults to the editor
  selection [mapped](https://prosemirror.net/docs/ref/#state.Selection.map) through the steps in the
  transaction, but can be overwritten with
  [`setSelection`](https://prosemirror.net/docs/ref/#state.Transaction.setSelection).
  */
  get selection() {
    return this.curSelectionFor < this.steps.length && (this.curSelection = this.curSelection.map(this.doc, this.mapping.slice(this.curSelectionFor)), this.curSelectionFor = this.steps.length), this.curSelection;
  }
  /**
  Update the transaction's current selection. Will determine the
  selection that the editor gets when the transaction is applied.
  */
  setSelection(t) {
    if (t.$from.doc != this.doc)
      throw new RangeError("Selection passed to setSelection must point at the current document");
    return this.curSelection = t, this.curSelectionFor = this.steps.length, this.updated = (this.updated | Ii) & ~dn, this.storedMarks = null, this;
  }
  /**
  Whether the selection was explicitly updated by this transaction.
  */
  get selectionSet() {
    return (this.updated & Ii) > 0;
  }
  /**
  Set the current stored marks.
  */
  setStoredMarks(t) {
    return this.storedMarks = t, this.updated |= dn, this;
  }
  /**
  Make sure the current stored marks or, if that is null, the marks
  at the selection, match the given set of marks. Does nothing if
  this is already the case.
  */
  ensureMarks(t) {
    return K.sameSet(this.storedMarks || this.selection.$from.marks(), t) || this.setStoredMarks(t), this;
  }
  /**
  Add a mark to the set of stored marks.
  */
  addStoredMark(t) {
    return this.ensureMarks(t.addToSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Remove a mark or mark type from the set of stored marks.
  */
  removeStoredMark(t) {
    return this.ensureMarks(t.removeFromSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Whether the stored marks were explicitly set for this transaction.
  */
  get storedMarksSet() {
    return (this.updated & dn) > 0;
  }
  /**
  @internal
  */
  addStep(t, n) {
    super.addStep(t, n), this.updated = this.updated & ~dn, this.storedMarks = null;
  }
  /**
  Update the timestamp for the transaction.
  */
  setTime(t) {
    return this.time = t, this;
  }
  /**
  Replace the current selection with the given slice.
  */
  replaceSelection(t) {
    return this.selection.replace(this, t), this;
  }
  /**
  Replace the selection with the given node. When `inheritMarks` is
  true and the content is inline, it inherits the marks from the
  place where it is inserted.
  */
  replaceSelectionWith(t, n = !0) {
    let r = this.selection;
    return n && (t = t.mark(this.storedMarks || (r.empty ? r.$from.marks() : r.$from.marksAcross(r.$to) || K.none))), r.replaceWith(this, t), this;
  }
  /**
  Delete the selection.
  */
  deleteSelection() {
    return this.selection.replace(this), this;
  }
  /**
  Replace the given range, or the selection if no range is given,
  with a text node containing the given string.
  */
  insertText(t, n, r) {
    let i = this.doc.type.schema;
    if (n == null)
      return t ? this.replaceSelectionWith(i.text(t), !0) : this.deleteSelection();
    {
      if (r == null && (r = n), !t)
        return this.deleteRange(n, r);
      let o = this.storedMarks;
      if (!o) {
        let s = this.doc.resolve(n);
        o = r == n ? s.marks() : s.marksAcross(this.doc.resolve(r));
      }
      return this.replaceRangeWith(n, r, i.text(t, o)), !this.selection.empty && this.selection.to == n + t.length && this.setSelection(H.near(this.selection.$to)), this;
    }
  }
  /**
  Store a metadata property in this transaction, keyed either by
  name or by plugin.
  */
  setMeta(t, n) {
    return this.meta[typeof t == "string" ? t : t.key] = n, this;
  }
  /**
  Retrieve a metadata property for a given name or plugin.
  */
  getMeta(t) {
    return this.meta[typeof t == "string" ? t : t.key];
  }
  /**
  Returns true if this transaction doesn't contain any metadata,
  and can thus safely be extended.
  */
  get isGeneric() {
    for (let t in this.meta)
      return !1;
    return !0;
  }
  /**
  Indicate that the editor should scroll the selection into view
  when updated to the state produced by this transaction.
  */
  scrollIntoView() {
    return this.updated |= vi, this;
  }
  /**
  True when this transaction has had `scrollIntoView` called on it.
  */
  get scrolledIntoView() {
    return (this.updated & vi) > 0;
  }
}
function wi(e, t) {
  return !t || !e ? e : e.bind(t);
}
class Jt {
  constructor(t, n, r) {
    this.name = t, this.init = wi(n.init, r), this.apply = wi(n.apply, r);
  }
}
const La = [
  new Jt("doc", {
    init(e) {
      return e.doc || e.schema.topNodeType.createAndFill();
    },
    apply(e) {
      return e.doc;
    }
  }),
  new Jt("selection", {
    init(e, t) {
      return e.selection || H.atStart(t.doc);
    },
    apply(e) {
      return e.selection;
    }
  }),
  new Jt("storedMarks", {
    init(e) {
      return e.storedMarks || null;
    },
    apply(e, t, n, r) {
      return r.selection.$cursor ? e.storedMarks : null;
    }
  }),
  new Jt("scrollToSelection", {
    init() {
      return 0;
    },
    apply(e, t) {
      return e.scrolledIntoView ? t + 1 : t;
    }
  })
];
class or {
  constructor(t, n) {
    this.schema = t, this.plugins = [], this.pluginsByKey = /* @__PURE__ */ Object.create(null), this.fields = La.slice(), n && n.forEach((r) => {
      if (this.pluginsByKey[r.key])
        throw new RangeError("Adding different instances of a keyed plugin (" + r.key + ")");
      this.plugins.push(r), this.pluginsByKey[r.key] = r, r.spec.state && this.fields.push(new Jt(r.key, r.spec.state, r));
    });
  }
}
class dt {
  /**
  @internal
  */
  constructor(t) {
    this.config = t;
  }
  /**
  The schema of the state's document.
  */
  get schema() {
    return this.config.schema;
  }
  /**
  The plugins that are active in this state.
  */
  get plugins() {
    return this.config.plugins;
  }
  /**
  Apply the given transaction to produce a new state.
  */
  apply(t) {
    return this.applyTransaction(t).state;
  }
  /**
  @internal
  */
  filterTransaction(t, n = -1) {
    for (let r = 0; r < this.config.plugins.length; r++)
      if (r != n) {
        let i = this.config.plugins[r];
        if (i.spec.filterTransaction && !i.spec.filterTransaction.call(i, t, this))
          return !1;
      }
    return !0;
  }
  /**
  Verbose variant of [`apply`](https://prosemirror.net/docs/ref/#state.EditorState.apply) that
  returns the precise transactions that were applied (which might
  be influenced by the [transaction
  hooks](https://prosemirror.net/docs/ref/#state.PluginSpec.filterTransaction) of
  plugins) along with the new state.
  */
  applyTransaction(t) {
    if (!this.filterTransaction(t))
      return { state: this, transactions: [] };
    let n = [t], r = this.applyInner(t), i = null;
    for (; ; ) {
      let o = !1;
      for (let s = 0; s < this.config.plugins.length; s++) {
        let a = this.config.plugins[s];
        if (a.spec.appendTransaction) {
          let c = i ? i[s].n : 0, l = i ? i[s].state : this, p = c < n.length && a.spec.appendTransaction.call(a, c ? n.slice(c) : n, l, r);
          if (p && r.filterTransaction(p, s)) {
            if (p.setMeta("appendedTransaction", t), !i) {
              i = [];
              for (let d = 0; d < this.config.plugins.length; d++)
                i.push(d < s ? { state: r, n: n.length } : { state: this, n: 0 });
            }
            n.push(p), r = r.applyInner(p), o = !0;
          }
          i && (i[s] = { state: r, n: n.length });
        }
      }
      if (!o)
        return { state: r, transactions: n };
    }
  }
  /**
  @internal
  */
  applyInner(t) {
    if (!t.before.eq(this.doc))
      throw new RangeError("Applying a mismatched transaction");
    let n = new dt(this.config), r = this.config.fields;
    for (let i = 0; i < r.length; i++) {
      let o = r[i];
      n[o.name] = o.apply(t, this[o.name], this, n);
    }
    return n;
  }
  /**
  Accessor that constructs and returns a new [transaction](https://prosemirror.net/docs/ref/#state.Transaction) from this state.
  */
  get tr() {
    return new Po(this);
  }
  /**
  Create a new state.
  */
  static create(t) {
    let n = new or(t.doc ? t.doc.type.schema : t.schema, t.plugins), r = new dt(n);
    for (let i = 0; i < n.fields.length; i++)
      r[n.fields[i].name] = n.fields[i].init(t, r);
    return r;
  }
  /**
  Create a new state based on this one, but with an adjusted set
  of active plugins. State fields that exist in both sets of
  plugins are kept unchanged. Those that no longer exist are
  dropped, and those that are new are initialized using their
  [`init`](https://prosemirror.net/docs/ref/#state.StateField.init) method, passing in the new
  configuration object..
  */
  reconfigure(t) {
    let n = new or(this.schema, t.plugins), r = n.fields, i = new dt(n);
    for (let o = 0; o < r.length; o++) {
      let s = r[o].name;
      i[s] = this.hasOwnProperty(s) ? this[s] : r[o].init(t, i);
    }
    return i;
  }
  /**
  Serialize this state to JSON. If you want to serialize the state
  of plugins, pass an object mapping property names to use in the
  resulting JSON object to plugin objects. The argument may also be
  a string or number, in which case it is ignored, to support the
  way `JSON.stringify` calls `toString` methods.
  */
  toJSON(t) {
    let n = { doc: this.doc.toJSON(), selection: this.selection.toJSON() };
    if (this.storedMarks && (n.storedMarks = this.storedMarks.map((r) => r.toJSON())), t && typeof t == "object")
      for (let r in t) {
        if (r == "doc" || r == "selection")
          throw new RangeError("The JSON fields `doc` and `selection` are reserved");
        let i = t[r], o = i.spec.state;
        o && o.toJSON && (n[r] = o.toJSON.call(i, this[i.key]));
      }
    return n;
  }
  /**
  Deserialize a JSON representation of a state. `config` should
  have at least a `schema` field, and should contain array of
  plugins to initialize the state with. `pluginFields` can be used
  to deserialize the state of plugins, by associating plugin
  instances with the property names they use in the JSON object.
  */
  static fromJSON(t, n, r) {
    if (!n)
      throw new RangeError("Invalid input for EditorState.fromJSON");
    if (!t.schema)
      throw new RangeError("Required config field 'schema' missing");
    let i = new or(t.schema, t.plugins), o = new dt(i);
    return i.fields.forEach((s) => {
      if (s.name == "doc")
        o.doc = je.fromJSON(t.schema, n.doc);
      else if (s.name == "selection")
        o.selection = H.fromJSON(o.doc, n.selection);
      else if (s.name == "storedMarks")
        n.storedMarks && (o.storedMarks = n.storedMarks.map(t.schema.markFromJSON));
      else {
        if (r)
          for (let a in r) {
            let c = r[a], l = c.spec.state;
            if (c.key == s.name && l && l.fromJSON && Object.prototype.hasOwnProperty.call(n, a)) {
              o[s.name] = l.fromJSON.call(c, t, n[a], o);
              return;
            }
          }
        o[s.name] = s.init(t, o);
      }
    }), o;
  }
}
function zo(e, t, n) {
  for (let r in e) {
    let i = e[r];
    i instanceof Function ? i = i.bind(t) : r == "handleDOMEvents" && (i = zo(i, t, {})), n[r] = i;
  }
  return n;
}
class jo {
  /**
  Create a plugin.
  */
  constructor(t) {
    this.spec = t, this.props = {}, t.props && zo(t.props, this, this.props), this.key = t.key ? t.key.key : Do("plugin");
  }
  /**
  Extract the plugin's state field from an editor state.
  */
  getState(t) {
    return t[this.key];
  }
}
const sr = /* @__PURE__ */ Object.create(null);
function Do(e) {
  return e in sr ? e + "$" + ++sr[e] : (sr[e] = 0, e + "$");
}
class $o {
  /**
  Create a plugin key.
  */
  constructor(t = "key") {
    this.key = Do(t);
  }
  /**
  Get the active plugin with this key, if any, from an editor
  state.
  */
  get(t) {
    return t.config.pluginsByKey[this.key];
  }
  /**
  Get the plugin's state from an editor state.
  */
  getState(t) {
    return t[this.key];
  }
}
const qa = (e) => {
  throw new RangeError(`Schema attribute must satisfy ${e}.`);
}, Te = (e, t, n) => ({
  id: e,
  version: "1.0.0",
  semantic: t,
  validate: (r) => n(r) || qa(t)
}), Ka = (e) => {
  try {
    return F(e), !0;
  } catch {
    return !1;
  }
}, Bo = [
  Te(
    "zx.schema-validator.canonical-value",
    "canonical JSON value",
    Ka
  ),
  Te(
    "zx.schema-validator.nullable-string",
    "string or null",
    (e) => e === null || typeof e == "string"
  ),
  Te(
    "zx.schema-validator.string",
    "string",
    (e) => typeof e == "string"
  ),
  Te(
    "zx.schema-validator.boolean",
    "boolean",
    (e) => typeof e == "boolean"
  ),
  Te(
    "zx.schema-validator.nullable-boolean",
    "boolean or null",
    (e) => e === null || typeof e == "boolean"
  ),
  Te(
    "zx.schema-validator.integer",
    "integer",
    (e) => Number.isInteger(e)
  ),
  Te(
    "zx.schema-validator.positive-integer",
    "positive integer",
    (e) => Number.isInteger(e) && e > 0
  ),
  Te(
    "zx.schema-validator.nullable-positive-number",
    "positive finite number or null",
    (e) => e === null || typeof e == "number" && Number.isFinite(e) && e > 0
  ),
  Te(
    "zx.schema-validator.nullable-integer",
    "integer or null",
    (e) => e === null || Number.isInteger(e)
  ),
  Te(
    "zx.schema-validator.nullable-integer-array",
    "integer array or null",
    (e) => e === null || Array.isArray(e) && e.every(Number.isInteger)
  )
], Ja = new Map(Bo.map((e) => [e.id, e])), Jr = g(
  Bo.map(({ id: e, version: t, semantic: n }) => ({
    id: e,
    version: t,
    fingerprint: I({ id: e, version: t, semantic: n })
  }))
), Ua = (e) => {
  const t = Jr.find(
    (n) => n.id === e
  );
  if (!t)
    throw new TypeError(`Unknown package schema validator "${e}".`);
  return t;
}, Ha = (e) => {
  const t = Ja.get(e.id), n = Jr.find(
    (r) => r.id === e.id
  );
  if (!t || !n || n.version !== e.version || n.fingerprint !== e.fingerprint)
    throw new TypeError(`Unresolvable package schema validator "${e.id}".`);
  return t.validate;
}, v = (e, t, n) => ({
  name: e,
  default: t,
  validator: Ua(n)
}), D = (e, t) => ({
  kind: "node",
  joinKey: `node:${t.key}`,
  order: e,
  attrs: t.attrs ?? [],
  ...t
}), De = (e, t) => ({
  kind: "mark",
  joinKey: `mark:${t.key}`,
  order: e,
  attrs: t.attrs ?? [],
  ...t
}), $ = {
  marks: null,
  inline: !1,
  atom: !1,
  isolating: !1,
  defining: !1,
  selectable: !0,
  draggable: !1,
  code: !1,
  whitespace: null,
  linebreakReplacement: !1
}, G = () => v("blockId", null, "zx.schema-validator.nullable-string"), Si = () => v("textAlign", null, "zx.schema-validator.nullable-string"), Wa = {
  contractVersion: "platform-default",
  language: "platform-default",
  detectedLanguage: "platform-default",
  filename: "platform-default",
  caption: "platform-default",
  showLineNumbers: "platform-default",
  startLine: "platform-default",
  wrap: "platform-default",
  collapsed: "platform-default",
  previewLines: "platform-default",
  heightMode: "platform-default",
  height: "platform-default",
  theme: "platform-default",
  highlightLines: "platform-default",
  copyMode: "platform-default",
  variant: "platform-default",
  groupId: "platform-default",
  tabLabel: "platform-default"
}, Xa = [
  D(0, {
    ...$,
    key: "paragraph",
    content: "inline*",
    group: "block",
    attrs: [Si(), G()]
  }),
  D(1, {
    ...$,
    key: "toggleSummary",
    content: "inline*",
    group: "block",
    defining: !0,
    selectable: !1,
    attrs: [G()]
  }),
  D(2, {
    ...$,
    key: "toggleContent",
    content: "block+",
    group: "block",
    defining: !0,
    selectable: !1,
    attrs: [G()]
  }),
  D(3, {
    ...$,
    key: "blockquote",
    content: "block+",
    group: "block",
    defining: !0,
    attrs: [G()]
  }),
  D(4, {
    ...$,
    key: "bulletList",
    content: "listItem+",
    group: "block list",
    attrs: [G()]
  }),
  D(5, { ...$, key: "doc", content: "block+", group: null }),
  D(6, {
    ...$,
    key: "hardBreak",
    content: null,
    group: "inline",
    inline: !0,
    selectable: !1,
    linebreakReplacement: !0
  }),
  D(7, {
    ...$,
    key: "horizontalRule",
    content: null,
    group: "block",
    attrs: [G()]
  }),
  D(8, {
    ...$,
    key: "listItem",
    content: "paragraph block*",
    group: null,
    defining: !0,
    attrs: [G()]
  }),
  D(9, {
    ...$,
    key: "orderedList",
    content: "listItem+",
    group: "block list",
    attrs: [
      G(),
      v("start", 1, "zx.schema-validator.positive-integer"),
      v("type", null, "zx.schema-validator.nullable-string")
    ]
  }),
  D(10, { ...$, key: "text", content: null, group: "inline" }),
  D(11, {
    ...$,
    key: "heading",
    content: "inline*",
    group: "block",
    defining: !0,
    attrs: [
      Si(),
      G(),
      v("level", 1, "zx.schema-validator.positive-integer")
    ]
  }),
  D(12, {
    ...$,
    key: "table",
    content: "tableRow+",
    group: "block",
    isolating: !0,
    attrs: [G()]
  }),
  D(13, {
    ...$,
    key: "taskList",
    content: "taskItem+",
    group: "block list",
    attrs: [G()]
  }),
  D(14, {
    ...$,
    key: "taskItem",
    content: "paragraph block*",
    group: null,
    defining: !0,
    attrs: [G(), v("checked", !1, "zx.schema-validator.boolean")]
  }),
  D(15, {
    ...$,
    key: "tableRow",
    content: "(tableCell | tableHeader)*",
    group: null,
    attrs: [v("rowId", null, "zx.schema-validator.nullable-string")]
  }),
  D(16, {
    ...$,
    key: "tableHeader",
    content: "block+",
    group: null,
    isolating: !0,
    attrs: [
      v("cellId", null, "zx.schema-validator.nullable-string"),
      v("colspan", 1, "zx.schema-validator.positive-integer"),
      v("rowspan", 1, "zx.schema-validator.positive-integer"),
      v("colwidth", null, "zx.schema-validator.nullable-integer-array"),
      v("align", null, "zx.schema-validator.nullable-string")
    ]
  }),
  D(17, {
    ...$,
    key: "tableCell",
    content: "block+",
    group: null,
    isolating: !0,
    attrs: [
      v("cellId", null, "zx.schema-validator.nullable-string"),
      v("colspan", 1, "zx.schema-validator.positive-integer"),
      v("rowspan", 1, "zx.schema-validator.positive-integer"),
      v("colwidth", null, "zx.schema-validator.nullable-integer-array"),
      v("align", null, "zx.schema-validator.nullable-string")
    ]
  }),
  D(18, {
    ...$,
    key: "pageBreak",
    content: null,
    group: "block",
    atom: !0,
    isolating: !0,
    attrs: [G(), v("id", null, "zx.schema-validator.nullable-string")]
  }),
  D(19, {
    ...$,
    key: "codeBlock",
    content: "text*",
    group: "block",
    marks: "",
    defining: !0,
    code: !0,
    whitespace: "pre",
    attrs: [
      G(),
      v("language", null, "zx.schema-validator.nullable-string"),
      v("contractVersion", "zx-code-block/v2", "zx.schema-validator.string"),
      v("detectedLanguage", null, "zx.schema-validator.nullable-string"),
      v("filename", "", "zx.schema-validator.string"),
      v("caption", "", "zx.schema-validator.string"),
      v("showLineNumbers", !0, "zx.schema-validator.boolean"),
      v("startLine", 1, "zx.schema-validator.positive-integer"),
      v("wrap", "inherit", "zx.schema-validator.string"),
      v("collapsed", !1, "zx.schema-validator.boolean"),
      v("previewLines", null, "zx.schema-validator.nullable-integer"),
      v("heightMode", "max", "zx.schema-validator.string"),
      v("height", null, "zx.schema-validator.nullable-positive-number"),
      v("theme", null, "zx.schema-validator.nullable-string"),
      v("highlightLines", [], "zx.schema-validator.canonical-value"),
      v("copyMode", "plain", "zx.schema-validator.string"),
      v("variant", "code", "zx.schema-validator.string"),
      v("groupId", null, "zx.schema-validator.nullable-string"),
      v("tabLabel", "", "zx.schema-validator.string"),
      v(
        "defaultSource",
        Wa,
        "zx.schema-validator.canonical-value"
      )
    ]
  }),
  D(20, {
    ...$,
    key: "attachment",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      G(),
      ...[
        "assetId",
        "display",
        "href",
        "fileName",
        "title",
        "mimeType",
        "fileSize",
        "sizeLabel",
        "fileKind",
        "badgeLabel",
        "downloadName"
      ].map(
        (e) => v(
          e,
          e === "display" ? "card" : null,
          e === "display" ? "zx.schema-validator.string" : e === "fileSize" ? "zx.schema-validator.canonical-value" : "zx.schema-validator.nullable-string"
        )
      )
    ]
  }),
  D(21, {
    ...$,
    key: "embed",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: ["assetId", "name", "title", "url", "icon"].map(
      (e) => v(e, null, "zx.schema-validator.nullable-string")
    )
  }),
  D(22, {
    ...$,
    key: "iframe",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      G(),
      v("assetId", null, "zx.schema-validator.nullable-string"),
      v("src", null, "zx.schema-validator.nullable-string"),
      v("width", null, "zx.schema-validator.canonical-value"),
      v("height", null, "zx.schema-validator.canonical-value"),
      v("aspectRatio", 0.5625, "zx.schema-validator.canonical-value"),
      v("align", "center", "zx.schema-validator.string"),
      v("title", null, "zx.schema-validator.nullable-string"),
      v("frameborder", "0", "zx.schema-validator.string"),
      v("allowfullscreen", "true", "zx.schema-validator.string"),
      v(
        "sandbox",
        "allow-scripts allow-same-origin allow-popups allow-forms",
        "zx.schema-validator.string"
      ),
      v("interactive", !1, "zx.schema-validator.boolean"),
      v("fullWidth", !1, "zx.schema-validator.boolean")
    ]
  }),
  D(23, {
    ...$,
    key: "image",
    content: null,
    group: "block",
    draggable: !0,
    attrs: [
      G(),
      ...["assetId", "src", "alt", "title"].map(
        (e) => v(e, null, "zx.schema-validator.nullable-string")
      ),
      v("width", null, "zx.schema-validator.canonical-value"),
      v("height", null, "zx.schema-validator.canonical-value"),
      v("align", "left", "zx.schema-validator.string")
    ]
  }),
  D(24, {
    ...$,
    key: "imageGroup",
    content: "image+",
    group: "block",
    isolating: !0,
    draggable: !0,
    attrs: [
      G(),
      v("columns", 4, "zx.schema-validator.positive-integer")
    ]
  }),
  D(25, {
    ...$,
    key: "mention",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: [
      v("id", null, "zx.schema-validator.nullable-string"),
      v("label", null, "zx.schema-validator.nullable-string")
    ]
  }),
  D(26, {
    ...$,
    key: "tagItem",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: [
      v("tagId", null, "zx.schema-validator.nullable-string"),
      v("tagLabel", "tag", "zx.schema-validator.string")
    ]
  }),
  D(27, {
    ...$,
    key: "toggle",
    content: "toggleSummary toggleContent",
    group: "block",
    isolating: !0,
    defining: !0,
    attrs: [G(), v("open", !1, "zx.schema-validator.boolean")]
  }),
  D(28, {
    ...$,
    key: "video",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      G(),
      v("assetId", null, "zx.schema-validator.nullable-string"),
      v("src", null, "zx.schema-validator.nullable-string")
    ]
  })
], $e = {
  group: null,
  excludes: null,
  inclusive: !0,
  spanning: !0,
  code: !1
}, Ga = [
  De(0, {
    ...$e,
    key: "link",
    attrs: [
      v("href", null, "zx.schema-validator.nullable-string"),
      v("target", "_blank", "zx.schema-validator.nullable-string"),
      v(
        "rel",
        "noopener noreferrer nofollow",
        "zx.schema-validator.nullable-string"
      ),
      v("class", null, "zx.schema-validator.nullable-string"),
      v("title", null, "zx.schema-validator.nullable-string")
    ]
  }),
  De(1, {
    ...$e,
    key: "textStyle",
    attrs: [
      v("fontFamily", null, "zx.schema-validator.nullable-string"),
      v("fontSize", null, "zx.schema-validator.nullable-string"),
      v("color", null, "zx.schema-validator.nullable-string")
    ]
  }),
  De(2, { ...$e, key: "bold" }),
  De(3, { ...$e, key: "italic" }),
  De(4, { ...$e, key: "strike" }),
  De(5, { ...$e, key: "underline" }),
  De(6, { ...$e, key: "code", code: !0, excludes: "_" }),
  De(7, {
    ...$e,
    key: "comment",
    attrs: [
      v("commentId", null, "zx.schema-validator.nullable-string"),
      v("resolved", !1, "zx.schema-validator.boolean")
    ]
  }),
  De(8, {
    ...$e,
    key: "namedHighlight",
    inclusive: !1,
    attrs: [v("color", null, "zx.schema-validator.nullable-string")]
  })
], pn = (e, t, n) => {
  const r = `zx.text-editor.authority.${e}`;
  return {
    id: r,
    version: n,
    fingerprint: I({ id: r, version: n, owner: t }),
    authority: e,
    owner: t
  };
}, Za = [
  pn("document-v2", "src/document/types.ts", "2.0.0"),
  pn("schema-kernel", "src/core/schema-kernel/definition.ts", "1.0.0"),
  pn("ai-capability", "src/core/ai-extension-capabilities.ts", "1.0.0"),
  pn("render-registry", "src/core/extension-descriptors.ts", "1.0.0")
], Oi = {
  schemaKernelId: "zx.text-editor.schema-kernel",
  schemaKernelVersion: "1.0.0",
  topNode: "doc",
  authorities: Za,
  validators: Jr,
  nodes: Xa,
  marks: Ga
}, Ie = g({
  ...Oi,
  schemaKernelFingerprint: I(Oi)
}), Sn = (e) => e.length === 0 ? void 0 : Object.fromEntries(
  e.map((t) => [
    t.name,
    {
      default: t.default,
      validate: Ha(t.validator)
    }
  ])
), Ya = (e) => ({
  ...e.content !== null ? { content: e.content } : {},
  ...e.group !== null ? { group: e.group } : {},
  ...e.marks !== null ? { marks: e.marks } : {},
  ...e.inline ? { inline: !0 } : {},
  ...e.atom ? { atom: !0 } : {},
  ...e.isolating ? { isolating: !0 } : {},
  ...e.defining ? { defining: !0 } : {},
  ...e.selectable ? {} : { selectable: !1 },
  ...e.draggable ? { draggable: !0 } : {},
  ...e.code ? { code: !0 } : {},
  ...e.whitespace !== null ? { whitespace: e.whitespace } : {},
  ...e.linebreakReplacement ? { linebreakReplacement: !0 } : {},
  ...Sn(e.attrs) ? { attrs: Sn(e.attrs) } : {}
}), Qa = (e) => ({
  ...e.group !== null ? { group: e.group } : {},
  ...e.excludes !== null ? { excludes: e.excludes } : {},
  ...e.inclusive ? {} : { inclusive: !1 },
  ...e.spanning ? {} : { spanning: !1 },
  ...Sn(e.attrs) ? { attrs: Sn(e.attrs) } : {},
  ...e.code ? { code: !0 } : {}
}), ec = new xa({
  topNode: Ie.topNode,
  nodes: Object.fromEntries(
    Ie.nodes.map((e) => [
      e.key,
      Ya(e)
    ])
  ),
  marks: Object.fromEntries(
    Ie.marks.map((e) => [
      e.key,
      Qa(e)
    ])
  )
}), Ur = () => ec, Ai = (e, t) => {
  if (t <= 0 || t >= e.length) return !1;
  const n = e.charCodeAt(t - 1), r = e.charCodeAt(t);
  return n >= 55296 && n <= 56319 && r >= 56320 && r <= 57343;
}, tc = (e, t, n) => {
  const r = [...e].sort((p, d) => p.order - d.order), i = new Map(
    r.map((p, d) => [p.blockId, d])
  );
  if (i.size !== r.length || new Set(r.map((p) => p.order)).size !== r.length)
    return null;
  const o = i.get(t.blockId), s = i.get(n.blockId);
  if (o === void 0 || s === void 0 || o > s)
    return null;
  const a = r[o], c = r[s];
  return !Number.isInteger(t.offset) || !Number.isInteger(n.offset) || t.offset < 0 || n.offset < 0 || t.offset > a.text.length || n.offset > c.text.length || Ai(a.text, t.offset) || Ai(c.text, n.offset) || o === s && t.offset >= n.offset ? null : {
    quote: o === s ? a.text.slice(t.offset, n.offset) : r.slice(o, s + 1).map((p, d, f) => {
      const u = d === 0 ? t.offset : 0, m = d === f.length - 1 ? n.offset : p.text.length;
      return p.text.slice(u, m);
    }).join(`
`),
    before: a.text.slice(0, t.offset),
    after: c.text.slice(n.offset)
  };
}, On = g({
  maxBytes: 2e6,
  maxDepth: 128,
  maxArrayEntries: 5e4,
  maxObjectKeys: 1024,
  maxTotalObjectKeys: 3e5,
  maxComponents: 256,
  maxDependencies: 1024,
  maxNodes: 5e4,
  maxMarks: 2e5,
  maxPlugins: 128,
  maxSteps: 1e4,
  maxReaderEntries: 64
}), ar = {
  id: "zx.text-editor.execution-resource-profile",
  version: "1.0.0",
  limits: On
};
g({
  id: ar.id,
  version: ar.version,
  fingerprint: I(ar),
  dependencies: []
});
const _o = (e) => We(e, On), nc = /^[a-z][a-z0-9]*_[a-z0-9]+$/, rc = "blockId", An = (e) => typeof e == "string" && e.length > 3 && e.length <= 64 && nc.test(e), Vo = new Set(
  Ie.nodes.filter((e) => e.attrs.some((t) => t.name === "blockId")).map((e) => e.key)
), yn = (e) => !!e && typeof e == "object" && !Array.isArray(e), ic = (e) => e.length === 0 ? "$.body.content" : `$.body.content.${e.map((t) => `content[${t}]`).join(".")}`, Lo = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : Array.isArray(e.content) ? e.content.reduce(
  (t, n) => t + (yn(n) ? Lo(n) : 0),
  0
) : 0, oc = (e) => {
  _o(e);
  const t = [], n = [], r = [], i = /* @__PURE__ */ new Set();
  let o = 0;
  const s = (a, c) => {
    const l = typeof a.type == "string" ? a.type : "unknown", p = ic(c);
    if (Vo.has(l)) {
      const d = yn(a.attrs) ? a.attrs : {}, f = typeof d.blockId == "string" ? d.blockId : null, u = f ? An(f) ? i.has(f) ? "duplicate-block-id" : null : "invalid-block-id" : "missing-block-id";
      if (u)
        t.push({ code: u, path: p, nodeType: l, blockId: f });
      else if (f) {
        i.add(f);
        const { content: m, ...h } = a;
        n.push({
          blockId: f,
          nodeType: l,
          path: p,
          order: o++,
          utf16TextLength: Lo(a),
          nodeFingerprint: I(h),
          subtreeFingerprint: I(a)
        }), r.push({
          blockId: f,
          path: p,
          nodeType: l,
          documentAttrs: { blockId: f },
          renderAttrs: {
            dataBlockId: f,
            domId: l === "heading" ? f : null
          }
        });
      }
    }
    Array.isArray(a.content) && a.content.forEach((d, f) => {
      yn(d) && s(d, [...c, f]);
    });
  };
  return yn(e) && s(e, []), g({
    valid: t.length === 0,
    issues: t,
    index: n,
    attrSynchronization: r,
    canonicalFingerprint: I({ index: n, attrSynchronization: r })
  });
}, sc = () => g([...Vo]), ac = 2, cc = "stable-block-identity/v2", cr = {
  id: "zx.text-editor.document-v2-verifier",
  version: "2.1.0",
  schemaKernel: {
    id: Ie.schemaKernelId,
    version: Ie.schemaKernelVersion,
    fingerprint: Ie.schemaKernelFingerprint
  },
  pipeline: [
    "bounded-canonical-input",
    "exact-envelope-shape",
    "exact-node-mark-shape",
    "prosemirror-node-from-json",
    "stable-identity",
    "annotation-utf16-cross-block-lf-quote-context",
    "exact-asset-recursive-pages-header-footer-binary-export-meta-contract",
    "full-envelope-canonical-roundtrip"
  ],
  diagnosticAggregation: "continue-safe-independent-checks-after-exact-structural-admission"
}, lc = g({
  id: cr.id,
  version: cr.version,
  fingerprint: I(cr)
}), T = (e) => !!e && typeof e == "object" && !Array.isArray(e), P = (e, t, n = []) => {
  const r = Object.keys(e), i = /* @__PURE__ */ new Set([...t, ...n]);
  return t.every((o) => Object.hasOwn(e, o)) && r.every((o) => i.has(o));
}, R = (e, t, n, r = {}) => ({ code: e, path: t, message: n, ...r }), dc = (e) => e.reduce(
  (t, n) => (t[n.code] = (t[n.code] ?? 0) + 1, t),
  {}
), _t = (e, t) => g({
  valid: e.length === 0,
  issueCount: e.length,
  issues: [...e],
  unresolvedAnnotations: e.filter(
    (n) => n.code === "annotation-unresolved"
  ).length,
  headingIdentityViolations: e.filter(
    (n) => n.code === "heading-identity-uninferable"
  ).length,
  counts: dc(e),
  documentFingerprint: t,
  verifier: lc
}), pc = new Map(
  Ie.nodes.map((e) => [
    e.key,
    e
  ])
), fc = new Map(
  Ie.marks.map((e) => [
    e.key,
    e
  ])
), uc = (e, t, n) => {
  if (!T(e) || !P(e, ["type"], ["attrs"])) {
    n.push(R("document-shape-invalid", t, "Mark shape is invalid."));
    return;
  }
  const r = typeof e.type == "string" ? fc.get(e.type) : void 0;
  if (!r) {
    n.push(
      R("document-schema-invalid", `${t}.type`, "Unknown mark type.")
    );
    return;
  }
  const i = r.attrs.map((o) => o.name);
  if (i.length === 0) {
    Object.hasOwn(e, "attrs") && n.push(
      R(
        "document-shape-invalid",
        `${t}.attrs`,
        "Mark has no attributes."
      )
    );
    return;
  }
  (!T(e.attrs) || !P(e.attrs, i)) && n.push(
    R(
      "document-shape-invalid",
      `${t}.attrs`,
      "Mark attributes are not exact."
    )
  );
}, qo = (e, t, n, r) => {
  if (r.nodes += 1, r.nodes > On.maxNodes) {
    n.push(
      R(
        "document-resource-limit-exceeded",
        t,
        "Document node count exceeds the package limit.",
        { count: r.nodes }
      )
    );
    return;
  }
  if (!T(e)) {
    n.push(
      R("document-shape-invalid", t, "Node must be an object.")
    );
    return;
  }
  const i = typeof e.type == "string" ? e.type : null, o = i ? pc.get(i) : void 0;
  if (!o) {
    n.push(
      R("document-schema-invalid", `${t}.type`, "Unknown node type.")
    );
    return;
  }
  const s = i === "text", a = s ? ["type", "text", "marks"] : ["type", "attrs", "content", "marks"];
  (!Object.hasOwn(e, "type") || Object.keys(e).some((l) => !a.includes(l))) && n.push(
    R("document-shape-invalid", t, "Node properties are not exact.")
  ), s ? (typeof e.text != "string" || e.text.length === 0) && n.push(
    R(
      "document-shape-invalid",
      `${t}.text`,
      "Text must be non-empty."
    )
  ) : Object.hasOwn(e, "text") && n.push(
    R(
      "document-shape-invalid",
      `${t}.text`,
      "Only text nodes may contain text."
    )
  );
  const c = o.attrs.map((l) => l.name);
  c.length > 0 ? (!T(e.attrs) || !P(e.attrs, c)) && n.push(
    R(
      "document-shape-invalid",
      `${t}.attrs`,
      "Node attributes are not exact."
    )
  ) : Object.hasOwn(e, "attrs") && n.push(
    R(
      "document-shape-invalid",
      `${t}.attrs`,
      "Node has no attributes."
    )
  ), Object.hasOwn(e, "marks") && (Array.isArray(e.marks) ? (r.marks += e.marks.length, r.marks > On.maxMarks ? n.push(
    R(
      "document-resource-limit-exceeded",
      `${t}.marks`,
      "Document mark count exceeds the package limit.",
      { count: r.marks }
    )
  ) : e.marks.forEach(
    (l, p) => uc(l, `${t}.marks[${p}]`, n)
  )) : n.push(
    R(
      "document-shape-invalid",
      `${t}.marks`,
      "Marks must be an array."
    )
  )), Object.hasOwn(e, "content") && (Array.isArray(e.content) ? e.content.forEach(
    (l, p) => qo(l, `${t}.content[${p}]`, n, r)
  ) : n.push(
    R(
      "document-shape-invalid",
      `${t}.content`,
      "Content must be an array."
    )
  ));
}, hc = (e, t, n, r) => {
  if (!T(e) || !P(
    e,
    ["id", "type", "src"],
    ["title", "mimeType", "meta"]
  ) || typeof e.id != "string" || !e.id || !["image", "video", "embed", "file"].includes(String(e.type)) || typeof e.src != "string" || Object.hasOwn(e, "title") && typeof e.title != "string" || Object.hasOwn(e, "mimeType") && typeof e.mimeType != "string") {
    r.push(
      R("asset-contract-invalid", t, "Asset contract is invalid.")
    );
    return;
  }
  n.has(e.id) && r.push(
    R("asset-contract-invalid", `${t}.id`, "Asset id is duplicated.")
  ), n.add(e.id), Object.hasOwn(e, "meta") && (!T(e.meta) || Object.values(e.meta).some(
    (i) => !["string", "number", "boolean"].includes(typeof i)
  )) && r.push(
    R(
      "asset-contract-invalid",
      `${t}.meta`,
      "Asset metadata is invalid."
    )
  );
}, st = (e) => typeof e == "string" && e.length > 0, wr = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0, Rn = (e) => typeof e == "number" && Number.isFinite(e) && e > 0, Ko = (e) => T(e) && P(e, ["top", "right", "bottom", "left"]) && ["top", "right", "bottom", "left"].every(
  (t) => wr(e[t])
), En = (e) => T(e) && P(
  e,
  [],
  ["sectionBreak", "pageBreakBefore", "headerFooterRole", "pageNumbering"]
) && (!Object.hasOwn(e, "sectionBreak") || ["document-start", "continuous", "next-page"].includes(
  String(e.sectionBreak)
)) && (!Object.hasOwn(e, "pageBreakBefore") || typeof e.pageBreakBefore == "boolean") && (!Object.hasOwn(e, "headerFooterRole") || ["default", "first-page", "none"].includes(
  String(e.headerFooterRole)
)) && (!Object.hasOwn(e, "pageNumbering") || ["inherit", "restart-1", "hidden"].includes(String(e.pageNumbering))), mc = (e) => T(e) && P(e, ["id"], ["label", "width", "height"]) && st(e.id) && (!Object.hasOwn(e, "label") || typeof e.label == "string") && (!Object.hasOwn(e, "width") || Rn(e.width)) && (!Object.hasOwn(e, "height") || Rn(e.height)), Ri = (e, t) => {
  if (!T(e)) return !1;
  const n = ["pageFormat", "orientation", "margins"];
  return P(e, t ? [] : n, t ? n : []) ? (!Object.hasOwn(e, "pageFormat") || mc(e.pageFormat)) && (!Object.hasOwn(e, "orientation") || e.orientation === "portrait" || e.orientation === "landscape") && (!Object.hasOwn(e, "margins") || Ko(e.margins)) : !1;
}, gc = /* @__PURE__ */ new Set([
  "bold",
  "italic",
  "underline",
  "strike",
  "code",
  "link"
]), yc = /* @__PURE__ */ new Set([
  "http:",
  "https:",
  "mailto:",
  "tel:"
]), bc = (e) => {
  if (typeof e != "string" || e.length === 0 || e !== e.trim())
    return !1;
  try {
    const t = new URL(e, "https://zx.local");
    return yc.has(t.protocol) || t.protocol === "https:" && !/^[a-z][a-z0-9+.-]*:/i.test(e);
  } catch {
    return !1;
  }
}, xc = (e) => !T(e) || typeof e.type != "string" || !gc.has(e.type) ? !1 : e.type !== "link" ? P(e, ["type"]) : P(e, ["type", "attrs"]) && T(e.attrs) && P(e.attrs, ["href"]) && bc(e.attrs.href), kc = (e) => !T(e) || typeof e.type != "string" ? !1 : e.type === "hardBreak" ? P(e, ["type"]) : e.type === "text" && P(e, ["type", "text"], ["marks"]) && typeof e.text == "string" && (!Object.hasOwn(e, "marks") || Array.isArray(e.marks) && e.marks.every(xc)), Ic = (e) => T(e) && e.type === "doc" && P(e, ["type"], ["content"]) && (!Object.hasOwn(e, "content") || Array.isArray(e.content) && e.content.every(
  (t) => T(t) && t.type === "paragraph" && P(t, ["type"], ["content"]) && (!Object.hasOwn(t, "content") || Array.isArray(t.content) && t.content.every(kc))
)), vc = (e) => T(e) && (e.state === "empty" && P(e, ["state"]) || e.state === "content" && P(e, ["state", "content"]) && Ic(e.content)), wc = ["default", "firstPage", "oddPage", "evenPage"], fn = (e) => T(e) && P(e, [], wc) && Object.values(e).every(vc), Sc = (e) => !T(e) || !P(
  e,
  ["version", "differentFirstPage", "differentOddEven"],
  ["headerTopMargin", "footerBottomMargin", "header", "footer", "sections"]
) || e.version !== 1 || typeof e.differentFirstPage != "boolean" || typeof e.differentOddEven != "boolean" || Object.hasOwn(e, "headerTopMargin") && !wr(e.headerTopMargin) || Object.hasOwn(e, "footerBottomMargin") && !wr(e.footerBottomMargin) || Object.hasOwn(e, "header") && !fn(e.header) || Object.hasOwn(e, "footer") && !fn(e.footer) || Object.hasOwn(e, "sections") && !Array.isArray(e.sections) ? !1 : !Array.isArray(e.sections) || e.sections.every(
  (t) => T(t) && P(
    t,
    ["sectionId"],
    [
      "startBlockId",
      "differentFirstPage",
      "differentOddEven",
      "header",
      "footer"
    ]
  ) && st(t.sectionId) && (!Object.hasOwn(t, "startBlockId") || st(t.startBlockId)) && (!Object.hasOwn(t, "differentFirstPage") || typeof t.differentFirstPage == "boolean") && (!Object.hasOwn(t, "differentOddEven") || typeof t.differentOddEven == "boolean") && (!Object.hasOwn(t, "header") || fn(t.header)) && (!Object.hasOwn(t, "footer") || fn(t.footer))
), Oc = (e) => {
  if (!T(e) || !P(
    e,
    ["version", "defaults"],
    ["sections", "headerFooter"]
  ) || e.version !== 1 || !T(e.defaults) || !P(e.defaults, ["page"], ["intent"]) || !Ri(e.defaults.page, !1) || Object.hasOwn(e.defaults, "intent") && !En(e.defaults.intent) || Object.hasOwn(e, "headerFooter") && !Sc(e.headerFooter) || Object.hasOwn(e, "sections") && !Array.isArray(e.sections))
    return !1;
  const t = /* @__PURE__ */ new Set();
  return !Array.isArray(e.sections) || e.sections.every((n) => !T(n) || !P(n, ["id", "startBlockId"], ["page", "intent"]) || !st(n.id) || t.has(n.id) || !st(n.startBlockId) || Object.hasOwn(n, "page") && !Ri(n.page, !0) || Object.hasOwn(n, "intent") && !En(n.intent) ? !1 : (t.add(n.id), !0));
}, Ei = (e) => T(e) && P(
  e,
  [],
  ["size", "label", "width", "height", "orientation", "margins"]
) && (!Object.hasOwn(e, "size") || st(e.size)) && (!Object.hasOwn(e, "label") || typeof e.label == "string") && (!Object.hasOwn(e, "width") || Rn(e.width)) && (!Object.hasOwn(e, "height") || Rn(e.height)) && (!Object.hasOwn(e, "orientation") || e.orientation === "portrait" || e.orientation === "landscape") && (!Object.hasOwn(e, "margins") || Ko(e.margins)), Ac = (e) => {
  if (!T(e) || !P(e, [], ["defaults", "sections"]) || Object.hasOwn(e, "defaults") && (!T(e.defaults) || !P(e.defaults, [], ["page", "intent"]) || Object.hasOwn(e.defaults, "page") && !Ei(e.defaults.page) || Object.hasOwn(e.defaults, "intent") && !En(e.defaults.intent)) || Object.hasOwn(e, "sections") && !Array.isArray(e.sections))
    return !1;
  const t = /* @__PURE__ */ new Set();
  return !Array.isArray(e.sections) || e.sections.every((n) => !T(n) || !P(n, ["id", "startBlockId"], ["page", "intent"]) || !st(n.id) || t.has(n.id) || !st(n.startBlockId) || Object.hasOwn(n, "page") && !Ei(n.page) || Object.hasOwn(n, "intent") && !En(n.intent) ? !1 : (t.add(n.id), !0));
}, Rc = (e, t) => {
  if (!T(e) || !P(
    e,
    [],
    [
      "title",
      "author",
      "createdAt",
      "updatedAt",
      "source",
      "schemaVersion",
      "pages",
      "binaryExport"
    ]
  )) {
    t.push(
      R(
        "meta-contract-invalid",
        "$.meta",
        "Document metadata shape is invalid."
      )
    );
    return;
  }
  ["title", "author", "createdAt", "updatedAt", "schemaVersion"].forEach(
    (n) => {
      Object.hasOwn(e, n) && typeof e[n] != "string" && t.push(
        R(
          "meta-contract-invalid",
          `$.meta.${n}`,
          "Metadata field must be a string."
        )
      );
    }
  ), Object.hasOwn(e, "source") && e.source !== "editor" && e.source !== "import" && t.push(
    R(
      "meta-contract-invalid",
      "$.meta.source",
      "Metadata source is invalid."
    )
  ), ["pages", "binaryExport"].forEach((n) => {
    const r = n === "pages" ? Oc(e[n]) : Ac(e[n]);
    Object.hasOwn(e, n) && !r && t.push(
      R(
        "meta-contract-invalid",
        `$.meta.${n}`,
        "Metadata contract field must be an object."
      )
    );
  });
}, Ec = (e, t, n) => {
  const r = /* @__PURE__ */ new Map();
  t.forEach((a) => {
    T(a) && typeof a.id == "string" && r.set(a.id, a);
  });
  const i = /* @__PURE__ */ new Set(), o = {
    attachment: "file",
    embed: "embed",
    iframe: "embed",
    image: "image",
    video: "video"
  }, s = (a, c) => {
    const l = T(a.attrs) ? a.attrs : null, p = typeof a.type == "string" ? a.type : "", d = typeof l?.assetId == "string" ? l.assetId : null;
    if (d) {
      const f = r.get(d);
      if (!f || f.type !== o[p])
        n.push(
          R(
            "asset-contract-invalid",
            `${c}.attrs.assetId`,
            "Asset reference is unresolved or has the wrong type."
          )
        );
      else {
        i.add(d);
        const u = typeof l?.src == "string" ? l.src : typeof l?.url == "string" ? l.url : null;
        u !== null && u !== f.src && n.push(
          R(
            "asset-contract-invalid",
            `${c}.attrs.assetId`,
            "Asset reference source does not match the asset table."
          )
        );
      }
    }
    Array.isArray(a.content) && a.content.forEach((f, u) => {
      T(f) && s(f, `${c}.content[${u}]`);
    });
  };
  T(e) && s(e, "$.body.content"), t.forEach((a, c) => {
    T(a) && typeof a.id == "string" && a.type !== "file" && !i.has(a.id) && n.push(
      R(
        "asset-contract-invalid",
        `$.assets[${c}].id`,
        "Non-file asset is not referenced by the document."
      )
    );
  });
}, Tc = (e) => {
  const t = /* @__PURE__ */ new Map(), n = (i) => typeof i.text == "string" ? i.text : i.type === "hardBreak" ? `
` : Array.isArray(i.content) ? i.content.map((o) => T(o) ? n(o) : "").join("") : "", r = (i) => {
    const o = T(i.attrs) ? i.attrs : null;
    typeof o?.blockId == "string" && t.set(o.blockId, n(i)), Array.isArray(i.content) && i.content.forEach((s) => T(s) && r(s));
  };
  return T(e) && r(e), t;
}, Fc = (e, t, n, r) => {
  const i = new Map(t.map((c) => [c.blockId, c])), o = Tc(n), s = t.map((c) => ({
    blockId: c.blockId,
    order: c.order,
    text: o.get(c.blockId) ?? ""
  })), a = /* @__PURE__ */ new Set();
  e.forEach((c, l) => {
    const p = `$.annotations[${l}]`;
    if (!T(c) || !P(c, ["id", "type", "anchor", "resolved", "payload"]) || typeof c.id != "string" || !c.id || c.type !== "comment" || typeof c.resolved != "boolean" || !T(c.anchor) || !P(
      c.anchor,
      ["start", "end"],
      ["quote", "beforeQuote", "afterQuote"]
    ) || !T(c.payload) || !P(c.payload, ["threadId", "comments"]) || typeof c.payload.threadId != "string" || !Array.isArray(c.payload.comments)) {
      r.push(
        R(
          "annotation-contract-invalid",
          p,
          "Annotation contract is invalid."
        )
      );
      return;
    }
    a.has(c.id) && r.push(
      R(
        "annotation-contract-invalid",
        `${p}.id`,
        "Annotation id is duplicated."
      )
    ), a.add(c.id), c.payload.comments.forEach((k, w) => {
      (!T(k) || !P(
        k,
        ["id", "content", "createdAt"],
        ["authorId", "updatedAt"]
      ) || ["id", "content", "createdAt"].some(
        (S) => typeof k[S] != "string"
      ) || Object.hasOwn(k, "authorId") && typeof k.authorId != "string" || Object.hasOwn(k, "updatedAt") && typeof k.updatedAt != "string") && r.push(
        R(
          "annotation-contract-invalid",
          `${p}.payload.comments[${w}]`,
          "Annotation comment is invalid."
        )
      );
    });
    const d = c.anchor, f = (k) => T(k) && P(k, ["blockId", "offset"]) && typeof k.blockId == "string" && Number.isInteger(k.offset) && k.offset >= 0 ? { blockId: k.blockId, offset: k.offset } : null, u = f(d.start), m = f(d.end), h = u ? i.get(u.blockId) : void 0, y = m ? i.get(m.blockId) : void 0;
    if (!u || !m || !h || !y || u.offset > h.utf16TextLength || m.offset > y.utf16TextLength || h.order > y.order || u.blockId === m.blockId && u.offset >= m.offset) {
      r.push(
        R(
          "annotation-unresolved",
          `${p}.anchor`,
          "Annotation anchor is unresolved.",
          {
            annotationId: c.id,
            blockId: u?.blockId ?? m?.blockId ?? null
          }
        )
      );
      return;
    }
    ["quote", "beforeQuote", "afterQuote"].forEach((k) => {
      Object.hasOwn(d, k) && typeof d[k] != "string" && r.push(
        R(
          "annotation-contract-invalid",
          `${p}.anchor.${k}`,
          "Quote context must be a string."
        )
      );
    });
    const x = tc(
      s,
      u,
      m
    );
    if (!x) {
      r.push(
        R(
          "annotation-unresolved",
          `${p}.anchor`,
          "Annotation text projection is unresolved.",
          {
            annotationId: c.id,
            blockId: u.blockId
          }
        )
      );
      return;
    }
    typeof d.quote == "string" && d.quote !== x.quote && r.push(
      R(
        "annotation-quote-mismatch",
        `${p}.anchor.quote`,
        "Annotation quote does not match UTF-16 range."
      )
    ), typeof d.beforeQuote == "string" && !x.before.endsWith(d.beforeQuote) && r.push(
      R(
        "annotation-quote-mismatch",
        `${p}.anchor.beforeQuote`,
        "Annotation leading context does not match."
      )
    ), typeof d.afterQuote == "string" && !x.after.startsWith(d.afterQuote) && r.push(
      R(
        "annotation-quote-mismatch",
        `${p}.anchor.afterQuote`,
        "Annotation trailing context does not match."
      )
    );
  });
}, Jo = (e) => {
  let t;
  try {
    t = _o(e).canonical;
  } catch (c) {
    const l = c instanceof Error && c.name === "ZxCanonicalJSONResourceError";
    return _t(
      [
        R(
          l ? "document-resource-limit-exceeded" : "document-content-invalid",
          "$",
          l ? "Document exceeds package resource limits." : "Document is not canonical JSON."
        )
      ],
      null
    );
  }
  const n = [];
  if (!T(e) || !P(e, ["version", "body", "annotations", "assets", "meta"]))
    return _t(
      [
        R(
          "document-shape-invalid",
          "$",
          "Document v2 envelope is not exact."
        )
      ],
      null
    );
  if (e.version !== ac && n.push(
    R(
      "document-version-mismatch",
      "$.version",
      "Document version is unsupported."
    )
  ), !T(e.body) || !P(e.body, ["format", "content"]) ? n.push(
    R("document-shape-invalid", "$.body", "Document body is not exact.")
  ) : (e.body.format !== "json" && n.push(
    R(
      "document-format-mismatch",
      "$.body.format",
      "Document body format must be json."
    )
  ), T(e.body.content) ? qo(e.body.content, "$.body.content", n, {
    nodes: 0,
    marks: 0
  }) : n.push(
    R(
      "document-content-invalid",
      "$.body.content",
      "Document body content must be a node object."
    )
  )), Array.isArray(e.annotations) || n.push(
    R(
      "document-shape-invalid",
      "$.annotations",
      "Annotations must be an array."
    )
  ), !Array.isArray(e.assets))
    n.push(
      R("document-shape-invalid", "$.assets", "Assets must be an array.")
    );
  else {
    const c = /* @__PURE__ */ new Set();
    e.assets.forEach(
      (l, p) => hc(l, `$.assets[${p}]`, c, n)
    );
  }
  Rc(e.meta, n), T(e.meta) && e.meta.schemaVersion !== cc && n.push(
    R(
      "document-schema-version-mismatch",
      "$.meta.schemaVersion",
      "Document schema version is unsupported."
    )
  );
  const r = /* @__PURE__ */ new Set([
    "document-content-invalid",
    "document-resource-limit-exceeded",
    "document-schema-invalid",
    "document-shape-invalid"
  ]);
  if (!T(e.body) || n.some((c) => r.has(c.code)))
    return _t(n, null);
  let i;
  try {
    const c = Ur().nodeFromJSON(e.body.content);
    c.check(), i = c.toJSON();
  } catch {
    return _t(
      [
        ...n,
        R(
          "document-schema-invalid",
          "$.body.content",
          "Document does not satisfy the exact schema kernel."
        )
      ],
      null
    );
  }
  const o = oc(i);
  o.issues.forEach((c) => {
    n.push(
      R(c.code, c.path, "Stable block identity is invalid.", {
        blockId: c.blockId
      })
    ), c.nodeType === "heading" && n.push(
      R(
        "heading-identity-uninferable",
        c.path,
        "Heading identity cannot be inferred.",
        {
          blockId: c.blockId
        }
      )
    );
  }), Array.isArray(e.assets) && Ec(i, e.assets, n), Array.isArray(e.annotations) && Fc(
    e.annotations,
    o.index,
    i,
    n
  );
  const s = {
    version: 2,
    body: { format: "json", content: i },
    annotations: e.annotations,
    assets: e.assets,
    meta: e.meta
  };
  return F(s) !== t && n.push(
    R(
      "document-roundtrip-mismatch",
      "$",
      "Full document envelope is not canonical round-trip equivalent."
    )
  ), _t(
    n,
    n.length === 0 ? I(s) : null
  );
}, Tn = Jo;
g({
  maxBytes: 1048576,
  maxDepth: 64,
  maxKeys: 16384,
  maxArrayEntries: 32768,
  maxStringBytes: 524288,
  maxNodes: 65536
});
class ye extends TypeError {
  constructor(t) {
    super(`Production input rejected: ${t}`), this.name = "ProductionInputPreflightError", this.reason = t;
  }
}
const Cc = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]), Ti = (e) => new TextEncoder().encode(e).length, Fi = g({
  "operation-protocol-v2": {
    maxBytes: 12e5,
    maxDepth: 64,
    maxKeys: 16e3,
    maxArrayEntries: 8192,
    maxStringBytes: 5e5,
    maxNodes: 24193,
    maxObjectKeys: 16e3
  }
}), Nc = [
  [12e6, 160, 12e4, 96, 5e5],
  [4e6, 96, 3e4, 64, 16e4],
  [2e6, 64, 8e3, 48, 8e4],
  [4e6, 96, 3e4, 96, 18e4],
  [512 * 1024, 40, 8192, 256, 32768],
  [2e6, 128, 3e5, 3e5, 3e5],
  [12e5, 64, 8192, 16e3, 16e3],
  [512e3, 48, 4096, 12e3, 12e3],
  [1e6, 48, 4096, 12e3, 12e3],
  [256e3, 32, 4096, 8e3, 8e3],
  [512e3, 32, 4096, 8e3, 8e3],
  [1e6, 12, 128, 128, 128],
  [12e5, 12, 128, 128, 128],
  [64e3, 16, 64, 256, 256],
  [128e3, 16, 64, 256, 256],
  [256e3, 32, 2048, 8e3, 8e3],
  [512e3, 32, 2048, 8e3, 8e3]
], Mc = (e) => [
  e.maxBytes,
  e.maxDepth,
  e.maxArrayEntries,
  e.maxObjectKeys,
  e.maxTotalObjectKeys
].join(":"), Pc = new Set(
  Nc.map((e) => e.join(":"))
), ct = (e, t, n) => {
  if (e > t) throw new ye(n);
}, Uo = (e, t) => {
  const n = [{ value: e, depth: 0, ancestors: /* @__PURE__ */ new Set() }];
  let r = 0, i = 0, o = 0, s = 0, a = 0, c = 0;
  for (; n.length > 0; ) {
    const l = n.pop();
    c += 1, i = Math.max(i, l.depth), ct(c, t.maxNodes, "limit-nodes"), ct(i, t.maxDepth, "limit-depth");
    const p = l.value;
    if (p === null)
      r += 4;
    else if (typeof p == "string") {
      const d = Ti(p);
      a += d, r += d + 2;
    } else if (typeof p == "number") {
      if (!Number.isFinite(p) || Object.is(p, -0))
        throw new ye("invalid-number");
      r += String(p).length;
    } else if (typeof p == "boolean")
      r += p ? 4 : 5;
    else {
      if (typeof p != "object")
        throw new ye("unsupported-value");
      {
        if (l.ancestors.has(p))
          throw new ye("cycle-or-alias");
        const d = new Set(l.ancestors);
        d.add(p);
        const f = Array.isArray(p), u = Object.getPrototypeOf(p);
        if (f && u !== Array.prototype || !f && u !== Object.prototype && u !== null)
          throw new ye("unknown-object");
        const m = Reflect.ownKeys(p);
        if (m.some((y) => typeof y == "symbol"))
          throw new ye("symbol-key");
        const h = m;
        if (f) {
          const y = p;
          if (h.length !== y.length + 1 || !h.includes("length"))
            throw new ye("array-shape");
          s += y.length, r += 2 + Math.max(0, y.length - 1);
          for (let x = y.length - 1; x >= 0; x -= 1) {
            const k = Object.getOwnPropertyDescriptor(
              y,
              String(x)
            );
            if (!k || !k.enumerable || !("value" in k))
              throw new ye("accessor-property");
            n.push({
              value: k.value,
              depth: l.depth + 1,
              ancestors: d
            });
          }
        } else {
          ct(h.length, t.maxObjectKeys, "limit-keys"), o += h.length, r += 2 + Math.max(0, h.length - 1);
          for (let y = h.length - 1; y >= 0; y -= 1) {
            const x = h[y];
            if (Cc.has(x))
              throw new ye("forbidden-key");
            const k = Object.getOwnPropertyDescriptor(p, x);
            if (!k || !("value" in k))
              throw new ye("accessor-property");
            if (!k.enumerable)
              throw new ye("non-enumerable-property");
            const w = Ti(x);
            a += w, r += w + 3, n.push({
              value: k.value,
              depth: l.depth + 1,
              ancestors: d
            });
          }
        }
      }
    }
    ct(r, t.maxBytes, "limit-bytes"), ct(o, t.maxKeys, "limit-keys"), ct(s, t.maxArrayEntries, "limit-array-entries"), ct(a, t.maxStringBytes, "limit-string-bytes");
  }
  return g({
    kind: "zx.ai.production.input-preflight.v1",
    accepted: !0,
    bytes: r,
    depth: i,
    keys: o,
    arrayEntries: s,
    stringBytes: a,
    nodes: c
  });
}, zc = (e, t) => {
  if (!Object.hasOwn(Fi, t))
    throw new ye("limit-profile-expanded");
  return Uo(
    e,
    Fi[t]
  );
}, rn = (e, t) => {
  if (t === null || typeof t != "object" || Array.isArray(t) || JSON.stringify(Object.keys(t).sort()) !== JSON.stringify(
    [
      "maxArrayEntries",
      "maxBytes",
      "maxDepth",
      "maxObjectKeys",
      "maxTotalObjectKeys"
    ].sort()
  ) || !Pc.has(
    Mc(t)
  ))
    throw new ye("limit-profile-expanded");
  return Uo(e, {
    maxBytes: t.maxBytes,
    maxDepth: t.maxDepth,
    maxKeys: t.maxTotalObjectKeys,
    maxArrayEntries: t.maxArrayEntries,
    maxStringBytes: t.maxBytes,
    maxNodes: t.maxTotalObjectKeys + t.maxArrayEntries + 1,
    maxObjectKeys: t.maxObjectKeys
  });
}, Hr = (e, t, n, r, i, o, s, a) => {
  const c = a.map(({ id: p, version: d, fingerprint: f }) => ({
    id: p,
    version: d,
    fingerprint: f
  })), l = {
    id: `npm:${e}`,
    version: n,
    packageName: e,
    runtimeSpecifier: t,
    resolvedVersion: n,
    lockIntegrity: r,
    apiContractFingerprint: o,
    implementationFingerprint: s,
    admittedSemverRanges: i,
    dependencies: c
  };
  return g({
    ...l,
    fingerprint: I(l)
  });
}, Xt = Hr(
  "prosemirror-model",
  "prosemirror-model",
  "1.25.12",
  "sha512-Ue2gTmXMa7EhpLNhC7J+h4+ykD8ha12K6rrZFFKKJHBForfIStw5gJ6Zrf1mqqAa9NmpmEB4wp9bKmA4eUVjWg==",
  ["1.25.12"],
  "sha256:b11a34cfd6b9d74ce796ea9ffe402a981a0e68845ea2da0d86b3ca65777dd2a7",
  "sha256:979f44e6c7f63ce3a20b66dc2ef9e4c96ac2cbc32360f47375d4c88baf9ed181",
  []
), bn = Hr(
  "prosemirror-transform",
  "prosemirror-transform",
  "1.12.2",
  "sha512-PE/aY0HEY4zczvmqrilgkUK/WautF0chvMqkmM/iN5/aPHvwrCWaQZjS6CIZp+K84YrvPFqrL+YArrfJX8xX7g==",
  ["1.12.2"],
  "sha256:e22fd8974004c6c9f083de095535028e31068296fefbb6f2a3da17c90c761e7b",
  "sha256:4d055cb15558c06a1ad444823f11893e4380b22b45ae211338b1c4ba7904bd15",
  [Xt]
), lr = Hr(
  "prosemirror-state",
  "prosemirror-state",
  "1.4.4",
  "sha512-6jiYHH2CIGbCfnxdHbXZ12gySFY/fz/ulZE333G6bPqIZ4F+TXo9ifiR86nAHpWnfoNjOb3o5ESi7J8Uz1jXHw==",
  ["1.4.4"],
  "sha256:02ab5dbcaa58da1d58c46c7cdfa7f94792c5ccf0fc7c0622ef33755fe415366c",
  "sha256:d4bd4e98520abd0bb0150436d84a3832d856aa59636ea23a59409d35929730a3",
  [Xt, bn]
), jc = "sha256:0f7fc1f7430fefe0b1ccc5ba8e990af1b046cad870d99101086abc9db0fd9821", Wr = "sha256:77ed9078085af3da6d102aaa1c16e6f998fbedb3d226a2204c4b622496bde58b", Dc = "sha256:e6fc6653d657b76d4149b5915a6def219f762a0424dd0b63ec36748dc7080c5b", $c = "sha256:32bb9030b7493187b58d3dca8fd86e8110dbc033823432ba9dd9f0ad4f17bcd2", Bc = "sha256:b9bf851be76aa150ea2eef03c7680d17430f72cd2a3a8ee9c24f58494b8a16c7", _c = "sha256:d8187e3c902a4c69f415d23bb30429d5d07792460725deaf280d69e1527ea26d", Vc = "sha256:b5a72d72f64d097b9f9eee2e84ddc5b7717b91778face3b9b099231029f1a76b", Lc = "sha256:018ea543dfae0643519b6d31ee79c82e2fa75a6e48a6f10152f4c431dcc760fa", qc = g({
  contract: "sha256:776126dfe7cefc1a8978d14db6512816ecee31b667a065c95c95a1ffa3ea9b97",
  freshRootMaterializer: "sha256:27aa30c682919e8b2ed9835f00346a562e33383b2e9ec96e97650f9cd4347ed9",
  coordinator: "sha256:a51e47ec34afc6c9d6e13857b98e6bfc59a6abf207a875e07496be3d8bc18540",
  postDispatchProof: "sha256:67a632e9d12e13b21a36e75640c819f15a3fef294a76c7273b9c873ba6baad88",
  synchronousWriteGuard: "sha256:a9838b16f257c3c48f62619fd39c685850c45655a80a69fd90276681b8a14a39",
  targetDocumentAuthority: "sha256:43c0fd79317a46d841e10a612882223024dbfd4f568f724cfdab0b47d79b2948"
}), M = (e, t) => ({
  kind: e,
  id: t.id,
  version: t.version,
  fingerprint: t.fingerprint
}), fe = (e, t, n, r, i = []) => {
  const o = { kind: e, id: t, version: n, semantics: r, dependencies: i };
  return g({
    kind: e,
    id: t,
    version: n,
    fingerprint: I({
      domain: `zx-runtime-component:${e}:v2`,
      projection: o
    }),
    dependencies: i
  });
}, _n = fe(
  "execution-closure",
  "npm:prosemirror-model",
  Xt.resolvedVersion,
  {
    packageFingerprint: Xt.fingerprint,
    implementationFingerprint: Xt.implementationFingerprint
  }
), Xr = fe(
  "execution-closure",
  "npm:prosemirror-transform",
  bn.resolvedVersion,
  {
    packageFingerprint: bn.fingerprint,
    implementationFingerprint: bn.implementationFingerprint
  },
  [M("execution-closure", _n)]
), Ho = fe(
  "execution-closure",
  "npm:prosemirror-state",
  lr.resolvedVersion,
  {
    packageFingerprint: lr.fingerprint,
    apiFingerprint: lr.apiContractFingerprint,
    stateSourceFingerprint: "sha256:081d675bbeaa6598c17f45be84a84011c5e083b66f9c6282be0304a5f38f7f44",
    transactionSourceFingerprint: "sha256:fbab5b3d17fc510152167b387e15dcf360c086ed78dcb2751cecae7938d01a83",
    adapterSourceFingerprint: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
    adapter: "prosemirror-state-adapter-v2"
  },
  [
    M("execution-closure", _n),
    M("execution-closure", Xr)
  ]
), It = fe(
  "schema-semantics",
  "zx.text-editor.schema-semantics",
  "2.0.0",
  {
    owner: "schema-kernel",
    documentAuthority: "document-v2",
    schemaKernelFingerprint: Ie.schemaKernelFingerprint,
    marks: Ie.marks.map((e) => ({
      key: e.key,
      order: e.order,
      inclusive: e.inclusive,
      excludes: e.excludes,
      attrs: e.attrs
    }))
  }
), Kc = g([
  "text.replace",
  "block.insert",
  "block.replace",
  "block.delete",
  "node.apply"
]), $t = fe(
  "operation-protocol",
  "zx.text-editor.ai-mutation-plan",
  "2.0.0",
  {
    owner: "S2",
    protocolVersion: 2,
    offsetEncoding: "utf-16",
    registryBinding: "exact-fingerprint",
    v1Policy: "audit-only-no-live-converter",
    operations: Kc
  },
  [M("schema-semantics", It)]
), Wo = fe(
  "execution-closure",
  "zx.text-editor.operation-compiler-adapter",
  "2.0.0",
  {
    sourceFingerprint: "sha256:8c21f384c9e08bc7f8df660b30df12dfcdf50ba160f62ed65a2fc29c7366ea07",
    preconditionCatalogSourceFingerprint: "sha256:b45d0a4de04b2953f37742ffb24975486579cb376f2a2ace32a10f556755dbab",
    livePlanCertificationSourceFingerprint: "sha256:15f33030db66e1b01e760f3d5c0300f9d4055025453bb36c6b41883112c4ee3c",
    s2ProjectionSourceFingerprints: {
      conformance: "sha256:6d2b3df732ff1904443fafd079cb78bf0a88a48738b4eb0aadaab3093f25c3ca",
      manifest: "sha256:2bd78a70c5e5e988cd819b85317c5ca2561be21ea0ad5a9e582bf9c066e085c7",
      operationTargets: "sha256:62244a3ffc1c06c7e967bec417a752704113a448a14fb35b082884363f543e09",
      scope: "sha256:f020e82aa2356b73b1b8b4181059bb27cbd1f2f8c0dc4d5bd7b8946289264800",
      semanticTree: "sha256:365c438f6aa59e6dc483ef93c237867a17c42a8be1b44231000028fb32113c20",
      validatedBlockIndex: "sha256:36acbbe5c100368075d72d6ced1a765cf035564ee99d0b1b42f2f4fdae33a745"
    },
    rootTransactionCount: 1,
    operationOrder: "plan-order",
    spanProjection: "operation-index-step-half-open-v2",
    complexNode: {
      registry: "exact-fingerprint",
      adapterCompiler: "exact-component-ref",
      runner: "hard-terminable-isolate-required",
      fallback: "forbidden",
      resourceProfile: "manifest-bound"
    }
  },
  [
    M("schema-semantics", It),
    M("operation-protocol", $t)
  ]
), ae = (e, t, n, r) => fe(
  "execution-closure",
  `zx.text-editor.runtime-plugin.${e}.${t}`,
  "2.0.0",
  n,
  r
), Xo = ae(
  "stable-index",
  "factory",
  { owner: "package-exact", instanceKey: "stable-index-v2" },
  [M("schema-semantics", It)]
), Vn = ae(
  "stable-index",
  "config",
  { key: "zxRuntimeStableIndexV2", order: 0 },
  [M("execution-closure", Xo)]
), Go = ae(
  "stable-index",
  "state-init",
  { projection: "ordered-document-block-ids-v2" },
  [M("execution-closure", Vn)]
), Zo = ae(
  "stable-index",
  "state-apply",
  { projection: "docChanged-reproject-otherwise-identity" },
  [M("execution-closure", Go)]
), Yo = ae(
  "stable-index",
  "projector",
  { output: "blockIds+fingerprint", canonical: !0 },
  [M("execution-closure", Zo)]
), Jc = ae(
  "stable-index",
  "filter",
  {
    accepts: "host-and-runtime-transactions",
    runtimeTargetAdmission: "package-write-guard-plus-root/appended-meta"
  },
  [M("execution-closure", Vn)]
), Uc = ae(
  "stable-index",
  "append",
  { behavior: "none" },
  [M("execution-closure", Vn)]
), Hc = ae(
  "stable-index",
  "effect",
  { behavior: "none" },
  [M("execution-closure", Yo)]
), tn = g({
  factory: Xo,
  config: Vn,
  stateInit: Go,
  stateApply: Zo,
  projector: Yo,
  filter: Jc,
  append: Uc,
  effect: Hc
}), on = fe(
  "execution-closure",
  "zx.text-editor.runtime-plugin.stable-index",
  "2.0.0",
  {
    instanceKey: "stable-index-v2",
    order: 0,
    componentRefs: tn,
    conformanceReceipt: "runtime-plugin-stable-index-v2-receipt-1",
    implementationSourceFingerprint: Wr
  },
  Object.values(tn).map(
    (e) => M("execution-closure", e)
  )
), Qo = ae(
  "trace-seal",
  "factory",
  { owner: "package-exact", instanceKey: "trace-seal-v2" },
  [M("execution-closure", on)]
), Ln = ae(
  "trace-seal",
  "config",
  { key: "zxRuntimeTraceSealV2", order: 1 },
  [M("execution-closure", Qo)]
), es = ae(
  "trace-seal",
  "state-init",
  { projection: "transaction-count-zero-v2" },
  [M("execution-closure", Ln)]
), ts = ae(
  "trace-seal",
  "state-apply",
  { projection: "runtime-transaction-count-increment-v2" },
  [M("execution-closure", es)]
), ns = ae(
  "trace-seal",
  "projector",
  { output: "transactionCount+fingerprint", canonical: !0 },
  [M("execution-closure", ts)]
), Wc = ae(
  "trace-seal",
  "filter",
  {
    accepts: "host-and-runtime-transactions",
    runtimeTargetAdmission: "package-write-guard-plus-root/appended-meta"
  },
  [M("execution-closure", Ln)]
), Xc = ae(
  "trace-seal",
  "append",
  { behavior: "single-logical-transaction-after-root-v2" },
  [M("execution-closure", Ln)]
), Gc = ae(
  "trace-seal",
  "effect",
  { behavior: "bounded-observational-trace-sealed-v2" },
  [M("execution-closure", ns)]
), pt = g({
  factory: Qo,
  config: Ln,
  stateInit: es,
  stateApply: ts,
  projector: ns,
  filter: Wc,
  append: Xc,
  effect: Gc
}), sn = fe(
  "execution-closure",
  "zx.text-editor.runtime-plugin.trace-seal",
  "2.0.0",
  {
    instanceKey: "trace-seal-v2",
    order: 1,
    componentRefs: pt,
    conformanceReceipt: "runtime-plugin-trace-seal-v2-receipt-1",
    implementationSourceFingerprint: Wr
  },
  [
    M("execution-closure", on),
    ...Object.values(pt).map(
      (e) => M("execution-closure", e)
    )
  ]
), Gr = fe(
  "execution-closure",
  "zx.text-editor.runtime-observational.audit-label",
  "1.0.0",
  {
    owner: "S2B-observability",
    executionReachability: "none",
    behavior: "canonical-receipt-label-only",
    implementationSourceFingerprint: $c,
    sourceReachabilityClosure: {
      semanticComponentDependencies: [],
      reachableAuthorities: ["observations"],
      unreachableAuthorities: [
        "document",
        "selection",
        "stored-marks",
        "semantic-plugin-state",
        "effects",
        "annotations",
        "lifecycle"
      ]
    },
    conformanceReceipt: "runtime-observational-audit-label-non-interference-receipt-1"
  }
), vt = fe(
  "execution-closure",
  "zx.text-editor.deterministic-execution-closure",
  "2.0.0",
  {
    owner: "S2B",
    adapter: "prosemirror-state-adapter-v2",
    filterOrder: "manifest-plugin-order",
    appendSeenSemantics: "prosemirror-state-1.4.4",
    plugins: ["stable-index-v2", "trace-seal-v2"],
    pluginOrderSignificant: !0,
    watchdog: "host-non-replayable-abort-only",
    implementationSourceFingerprints: {
      stateAdapter: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
      fixedPointDriver: "sha256:abce518d9a3d1206cd96e9f5c9aa0b9b9085c2f8b52c0e7f7b928c733b9257ba",
      pluginClosure: Wr,
      pluginConformance: Dc,
      executionTrace: "sha256:8dee1b14039e315dc231d6f201c805128e3fd9ce9447dad2367a7884b3511fc1",
      hostAdmission: "sha256:2df4555636e903ebacb7fe29ffe354abe751216f134456bdba6cebdc8465374d",
      hostCompositionAuthority: Bc,
      hostCompositionRegistry: _c,
      hostCompositionState: Vc,
      editorRuntimeAssembly: Lc,
      targetCommit: qc,
      orchestrator: "sha256:f1e502f884fca6e64183c09cb114dff670000fe8a9d5eaa9ab3580790196f1e9",
      resolver: "sha256:38359a64831ddca47317ae78b1d8e68e8db62fc94b8f0b7de0f9d21ecf37f8c4"
    }
  },
  [
    M("operation-protocol", $t),
    M("execution-closure", Wo),
    M("execution-closure", _n),
    M("execution-closure", Xr),
    M("execution-closure", Ho),
    M("execution-closure", on),
    M("execution-closure", sn)
  ]
), an = fe(
  "mapping-policy",
  "zx.text-editor.mapping-policy",
  "2.0.0",
  {
    projection: "block-pm-utf16-v2",
    composition: "root-first-all-step-maps",
    annotationBoundary: { startAssoc: 1, endAssoc: -1, expanding: !1 },
    deletionFlags: [
      "deleted",
      "deletedBefore",
      "deletedAfter",
      "deletedAcross"
    ],
    invalidation: "fail-closed",
    context: ["quote", "beforeQuote", "afterQuote"],
    textReplaceMarks: {
      collapsed: "$pos.marks()",
      range: "$from.marksAcross($to) ?? []",
      deletion: [],
      selectionAndStoredMarks: "forbidden"
    },
    implementationSourceFingerprints: {
      mapping: "sha256:fd5888ea31b7eb6029d7d09d21467e9d9a36099b08cbec89bbeb7f843fda13c3",
      marks: "sha256:8be5e04ae8b43eff89322f668bd61a3e5d499bb8a7d70d34234af45b34a8e3a2"
    }
  },
  [
    M("schema-semantics", It),
    M("operation-protocol", $t),
    M("execution-closure", vt)
  ]
), qn = fe(
  "transaction-policy",
  "zx.text-editor.transaction-policy",
  "2.0.0",
  {
    logicalTime: "zero-based-global-sequence-v1",
    rootMeta: ["zx.runtime.root.v2"],
    appendedMeta: ["zx.runtime.appended.v2"],
    forbiddenMeta: [
      "uiEvent",
      "pointer",
      "composition",
      "history",
      "yjs",
      "provider",
      "caller",
      "PluginKey"
    ],
    selectionMutation: "forbidden",
    storedMarksMutation: "forbidden",
    implementationSourceFingerprint: "sha256:7e4a8909db08d8a8e3f56af4ecca53b23e6ef2e54b09f8040e538f561d02875f"
  },
  [M("execution-closure", vt)]
), nt = g({
  inputBytes: 2e6,
  inputDepth: 128,
  inputKeys: 3e5,
  documentNodes: 5e4,
  documentMarks: 2e5,
  documentBlocks: 2e4,
  annotations: 2e4,
  planOperations: 1e4,
  executionPlugins: 16,
  rootSteps: 1e4,
  steps: 2e4,
  transactions: 256,
  filterCalls: 2048,
  appendCalls: 2048,
  appendRounds: 256,
  mappingMaps: 2e4,
  mappingRanges: 12e4,
  mappingBytes: 4e6,
  mappingMirrors: 2e4,
  mappingMirrorBytes: 1e6,
  metaBytes: 1e6,
  traceBytes: 8e6,
  pluginStateBytes: 2e6,
  safeDiagnosticCount: 16,
  safeDiagnosticBytes: 16384
}), Kn = fe(
  "resource-profile",
  "zx.text-editor.deterministic-resource-profile",
  "2.0.0",
  {
    algorithm: "pre-debit-counts-and-canonical-utf8-bytes-v1",
    limits: nt,
    implementationSourceFingerprint: "sha256:74442b20a3f316728b6ee2db517e43a65d79cd68fa028026e3bdc432f483f3fb"
  },
  [
    M("execution-closure", vt),
    M("mapping-policy", an),
    M("transaction-policy", qn)
  ]
), rs = fe(
  "derived-view-profile",
  "zx.text-editor.derived-view.runtime-summary",
  "1.0.0",
  {
    owner: "proposal-view-authority",
    output: ["transactionCount", "stepCount", "annotationCount"],
    diffAlgorithm: null,
    hunkIdentity: null,
    maxInputBytes: 8e6,
    maxOutputBytes: 16384,
    implementationSourceFingerprint: "sha256:eebeca1ca662a97ef3190f83b82bb07c3349360bd8fb5ccd1e2d396bd0a81232"
  }
), Zc = [
  It,
  $t,
  vt,
  an,
  qn,
  Kn
], Yc = [
  sn,
  Gr
], is = [rs], Qc = I({
  domain: "zx-runtime-execution-semantics:v2",
  components: Zc
}), el = I({
  domain: "zx-runtime-observational-profile:v2",
  components: Yc
}), tl = I({
  domain: "zx-runtime-derived-view-profile:v2",
  components: is
}), Sr = {
  kind: "zx-text-editor-runtime-manifest-v2",
  version: "2.0.0",
  schemaSemantics: It,
  operationProtocol: $t,
  executionClosure: vt,
  mappingPolicy: an,
  transactionPolicy: qn,
  resourceProfile: Kn,
  derivedViewProfiles: is,
  fingerprints: {
    executionSemanticsFingerprint: Qc,
    observationalProfileFingerprint: el,
    derivedViewFingerprint: tl
  }
}, os = I({
  domain: "zx-runtime-manifest:v2",
  manifest: Sr
}), Ce = g({
  ...Sr,
  fingerprints: {
    ...Sr.fingerprints,
    runtimeManifestFingerprint: os
  }
}), Nt = g({
  kind: Ce.kind,
  version: Ce.version,
  fingerprint: os
}), Ci = g([
  It,
  $t,
  Wo,
  _n,
  Xr,
  Ho,
  ...Object.values(tn),
  on,
  ...Object.values(pt),
  sn,
  Gr,
  vt,
  an,
  qn,
  Kn,
  rs
]), nl = () => Ce, rl = {
  inputBytes: "input-bytes-budget-exceeded",
  inputDepth: "input-depth-budget-exceeded",
  inputKeys: "input-keys-budget-exceeded",
  documentNodes: "document-node-budget-exceeded",
  documentMarks: "document-mark-budget-exceeded",
  documentBlocks: "document-block-budget-exceeded",
  annotations: "annotation-budget-exceeded",
  planOperations: "plan-operation-budget-exceeded",
  executionPlugins: "execution-plugin-budget-exceeded",
  rootSteps: "root-step-budget-exceeded",
  steps: "step-budget-exceeded",
  transactions: "transaction-budget-exceeded",
  filterCalls: "filter-call-budget-exceeded",
  appendCalls: "append-call-budget-exceeded",
  appendRounds: "append-round-budget-exceeded",
  mappingMaps: "mapping-map-budget-exceeded",
  mappingRanges: "mapping-range-budget-exceeded",
  mappingBytes: "mapping-byte-budget-exceeded",
  mappingMirrors: "mapping-mirror-budget-exceeded",
  mappingMirrorBytes: "mapping-mirror-byte-budget-exceeded",
  metaBytes: "meta-byte-budget-exceeded",
  traceBytes: "trace-byte-budget-exceeded",
  pluginStateBytes: "plugin-state-byte-budget-exceeded",
  safeDiagnosticCount: "safe-diagnostic-count-budget-exceeded",
  safeDiagnosticBytes: "safe-diagnostic-byte-budget-exceeded"
}, il = () => Object.fromEntries(
  Object.keys(nt).map((e) => [e, 0])
);
class Or extends Error {
  constructor(t, n, r, i) {
    const o = rl[t];
    super(`${o}:${i}`), this.name = "RuntimeResourceExceededV2Error", this.code = o, this.diagnostic = g({
      code: o,
      stage: t.startsWith("input") || t.startsWith("document") || t === "annotations" || t === "planOperations" || t === "executionPlugins" ? "stage-1" : "stage-2",
      path: i,
      profileId: Kn.id,
      counter: t,
      current: n,
      limit: r
    });
  }
}
const ol = (e = nt) => {
  const t = il(), n = (i, o, s = `$.resources.${i}`) => {
    if (!Number.isSafeInteger(o) || o < 0)
      throw new TypeError(
        `Invalid deterministic resource count for ${i}.`
      );
    const a = e[i];
    if (o > a)
      throw new Or(i, o, a, s);
    t[i] = o;
  }, r = (i) => {
    const o = { ...t };
    i.forEach(({ counter: s, amount: a, path: c }) => {
      if (!Number.isSafeInteger(a) || a < 0)
        throw new TypeError(
          `Invalid deterministic resource debit for ${s}.`
        );
      const l = o[s] + a, p = e[s];
      if (l > p)
        throw new Or(
          s,
          l,
          p,
          c ?? `$.resources.${s}`
        );
      o[s] = l;
    }), Object.assign(t, o);
  };
  return {
    limits: e,
    debit(i, o = 1, s = `$.resources.${i}`) {
      r([{ counter: i, amount: o, path: s }]);
    },
    reserve: r,
    set: n,
    snapshot: () => g({ ...t })
  };
}, sl = (e) => {
  let t = 0, n = 0;
  const r = (i, o) => {
    if (t = Math.max(t, o), !i || typeof i != "object") return;
    if (Array.isArray(i)) {
      i.forEach((c) => r(c, o + 1));
      return;
    }
    const s = i, a = Object.keys(s);
    n += a.length, a.forEach((c) => r(s[c], o + 1));
  };
  return r(e, 1), { depth: t, keys: n };
}, al = (e) => {
  let t = 0, n = 0, r = 0;
  const i = (o) => {
    t += 1, n += o.marks?.length ?? 0, typeof o.attrs?.blockId == "string" && (r += 1), o.content?.forEach(i);
  };
  return i(e), { nodes: t, marks: n, blocks: r };
}, cl = (e, t, n, r, i) => {
  const o = F(t), s = sl(t), a = al(n.body.content);
  e.set("inputBytes", new TextEncoder().encode(o).byteLength, "$"), e.set("inputDepth", s.depth, "$"), e.set("inputKeys", s.keys, "$"), e.set(
    "documentNodes",
    a.nodes,
    "$.baseDocument.body.content"
  ), e.set(
    "documentMarks",
    a.marks,
    "$.baseDocument.body.content"
  ), e.set(
    "documentBlocks",
    a.blocks,
    "$.baseDocument.body.content"
  ), e.set(
    "annotations",
    n.annotations.length,
    "$.baseDocument.annotations"
  ), e.set("planOperations", r.steps.length, "$.plan.steps"), e.set(
    "executionPlugins",
    i,
    "$.runtime.executionClosure"
  );
}, ot = (e) => new TextEncoder().encode(F(e)).byteLength, ll = (e, t, n = {}) => {
  const r = {
    code: t,
    stage: n.stage ?? "execution",
    path: n.path ?? "$",
    ...n.profileId ? { profileId: n.profileId } : {},
    ...n.componentId ? { componentId: n.componentId } : {},
    ...n.operationIndex !== void 0 ? { operationIndex: n.operationIndex } : {},
    ...n.sequence !== void 0 ? { sequence: n.sequence } : {},
    ...n.pluginInstanceId ? { pluginInstanceId: n.pluginInstanceId } : {},
    ...n.counter ? { counter: n.counter } : {},
    ...n.current !== void 0 ? { current: n.current } : {},
    ...n.limit !== void 0 ? { limit: n.limit } : {},
    ...n.fingerprintPrefix ? { fingerprintPrefix: n.fingerprintPrefix } : {}
  };
  return e.reserve([
    {
      counter: "safeDiagnosticCount",
      amount: 1,
      path: "$.diagnostic"
    },
    {
      counter: "safeDiagnosticBytes",
      amount: ot(r),
      path: "$.diagnostic"
    }
  ]), g(r);
}, dl = (e, t) => g(
  Object.fromEntries(
    Object.keys(e).map((n) => [
      n,
      e[n] - t[n]
    ])
  )
), pl = (e, t) => {
  const n = ot({
    version: "runtime-execution-trace-v2",
    ...e,
    resources: t.snapshot(),
    fingerprint: "sha256:".padEnd(71, "0")
  }) + 512;
  t.debit("traceBytes", n, "$.trace");
  const r = {
    version: "runtime-execution-trace-v2",
    executionId: e.executionId,
    manifest: e.manifest,
    entries: e.entries,
    mapping: e.mapping,
    resources: t.snapshot(),
    resultFingerprint: e.resultFingerprint
  };
  return g({
    ...r,
    fingerprint: I(r)
  });
}, Zr = (e) => e.config, fl = (e, t, n, r = -1) => {
  const i = Zr(e).plugins;
  for (const [o, s] of i.entries()) {
    if (o === r) continue;
    const a = s.spec.filterTransaction;
    if (a && (n.debit("filterCalls", 1, `$.driver.filter[${o}]`), !a.call(s, t, e)))
      return !1;
  }
  return !0;
}, ul = (e, t, n, r) => {
  if (!t.before.eq(e.doc))
    throw new RangeError("transaction-attribution-invalid");
  r > 0 && n.debit(
    "pluginStateBytes",
    r,
    "$.driver.pluginState.reservation"
  ), n.debit("transactions", 1, "$.driver.transactions");
  const i = Zr(e), o = dt, s = new o(i);
  for (const a of i.fields)
    s[a.name] = a.apply(
      t,
      e[a.name],
      e,
      s
    );
  return s;
}, hl = (e) => Zr(e).plugins, xt = "zx.runtime.root.v2", Xe = "zx.runtime.appended.v2", Yr = (e) => e.meta, ml = (e) => {
  if (Object.keys(Yr(e)).length !== 0)
    throw new TypeError("transaction-meta-invalid");
}, Fn = (e, t) => {
  const n = Object.keys(e).sort(), r = [...t].sort();
  return n.length === r.length && n.every((i, o) => i === r[o]);
}, mt = (e) => Number.isSafeInteger(e) && e >= 0, gl = (e) => Array.isArray(e) && e.every((t, n) => {
  if (!t || typeof t != "object" || Array.isArray(t)) return !1;
  const r = t;
  return !Fn(r, ["operationIndex", "stepStart", "stepEnd"]) && (!Fn(r, [
    "operationIndex",
    "stepStart",
    "stepEnd",
    "noOpReason"
  ]) || r.noOpReason !== "already-equal") ? !1 : r.operationIndex === n && mt(r.stepStart) && mt(r.stepEnd) && r.stepEnd >= r.stepStart;
}), yl = (e) => Array.isArray(e) && e.every(
  (t, n) => mt(t) && (n === 0 || t > e[n - 1])
), ss = (e, t) => {
  if (!mt(t))
    throw new TypeError("transaction-time-invalid");
  const n = Object.create(Po.prototype), r = n;
  return r.doc = e.doc, r.steps = [], r.docs = [], r.mapping = new zt(), r.time = t, r.curSelection = e.selection, r.curSelectionFor = 0, r.updated = 0, r.meta = /* @__PURE__ */ Object.create(null), r.storedMarks = e.storedMarks, n;
}, bl = (e, t, n) => Fn(e, [
  "protocol",
  "executionId",
  "sequence",
  "compilerRef",
  "operationSpans"
]) && e.protocol === "zx-runtime-root-meta-v2" && e.executionId === n && e.sequence === t && e.compilerRef === "zx.text-editor.operation-compiler-adapter-v2@2.0.0" && gl(e.operationSpans), xl = (e, t, n) => {
  if (!Fn(e, [
    "protocol",
    "rootExecutionId",
    "sequence",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || e.protocol !== "zx-runtime-appended-meta-v2" || e.rootExecutionId !== n || e.sequence !== t || typeof e.pluginInstanceId != "string" || e.pluginInstanceId.length === 0 || !mt(e.pluginOrder) || !yl(e.operationIndexes) || !Array.isArray(e.visibleTransactionRange) || e.visibleTransactionRange.length !== 2)
    return !1;
  const [r, i] = e.visibleTransactionRange;
  return mt(r) && mt(i) && r <= i && i < t;
}, as = (e) => ss(e, 0), cs = (e, t, n) => (ml(e), e.setMeta(
  xt,
  g({
    protocol: "zx-runtime-root-meta-v2",
    executionId: t,
    sequence: 0,
    compilerRef: "zx.text-editor.operation-compiler-adapter-v2@2.0.0",
    operationSpans: n
  })
), e), Qr = (e, t) => {
  if (e.time !== t.sequence)
    throw new TypeError("transaction-time-invalid");
  const n = g({
    protocol: "zx-runtime-appended-meta-v2",
    rootExecutionId: t.executionId,
    sequence: t.sequence,
    pluginInstanceId: t.pluginInstanceId,
    pluginOrder: t.pluginOrder,
    visibleTransactionRange: t.visibleTransactionRange,
    operationIndexes: t.operationIndexes
  }), r = Yr(e);
  if (Object.keys(r).length) {
    if (Object.keys(r).length === 1 && F(r[Xe]) === F(n))
      return e;
    throw new TypeError("transaction-meta-invalid");
  }
  return e.setMeta(Xe, n), e;
}, kl = (e, t, n, r) => {
  const i = Yr(e), o = Object.keys(i), s = t === "root" ? xt : Xe;
  if (e.time !== n)
    throw new TypeError("transaction-time-invalid");
  if (o.length !== 1 || o[0] !== s)
    throw new TypeError("transaction-meta-invalid");
  const a = i[s];
  if (F(a), !a || typeof a != "object" || Array.isArray(a))
    throw new TypeError("transaction-meta-invalid");
  const c = a;
  if (t === "root" && !bl(c, n, r) || t === "appended" && !xl(c, n, r))
    throw new TypeError("transaction-attribution-invalid");
  if (e.selectionSet || e.storedMarksSet)
    throw new TypeError("transaction-attribution-invalid");
  return g({ [s]: a });
}, Il = (e, t) => {
  if (t === "root") {
    const r = e.getMeta(xt);
    return g({
      owner: "operation-compiler",
      pluginInstanceId: null,
      pluginOrder: null,
      visibleTransactionRange: [0, 0],
      operationIndexes: r.operationSpans.map((i) => i.operationIndex)
    });
  }
  const n = e.getMeta(Xe);
  return g({
    owner: "certified-plugin",
    pluginInstanceId: n.pluginInstanceId,
    pluginOrder: n.pluginOrder,
    visibleTransactionRange: n.visibleTransactionRange,
    operationIndexes: n.operationIndexes
  });
}, Ar = (e) => {
  const t = [];
  e.descendants((r) => {
    typeof r.attrs.blockId == "string" && t.push(r.attrs.blockId);
  });
  const n = { blockIds: t };
  return g({ ...n, fingerprint: I(n) });
}, ls = (e) => {
  const t = (e?.transactionCount ?? 0) + 1;
  return g({
    transactionCount: t,
    fingerprint: I({ transactionCount: t })
  });
}, Rr = new $o(
  "zxRuntimeStableIndexV2"
), Er = new $o("zxRuntimeTraceSealV2"), vl = (e) => !!(e.getMeta(xt) || e.getMeta(Xe)), ds = () => !0, wl = new jo({
  key: Rr,
  state: {
    init: (e, t) => Ar(t.doc),
    apply: (e, t) => e.docChanged ? Ar(e.doc) : t
  },
  // The certified plugins are also installed in the genuine editor. Host
  // transactions must remain usable; Runtime admission is enforced by the
  // target write guard and the root/appended metadata, not by globally
  // blocking unrelated editor transactions.
  filterTransaction: ds
}), Sl = new jo({
  key: Er,
  state: {
    init: () => g({
      transactionCount: 0,
      fingerprint: I({ transactionCount: 0 })
    }),
    apply: (e, t) => vl(e) ? ls(t) : t
  },
  filterTransaction: ds,
  appendTransaction: (e, t, n) => {
    const r = e.find(
      (l) => !!l.getMeta(xt)
    ), i = e.some(
      (l) => !!l.getMeta(Xe)
    ), o = e.at(-1)?.time, s = r?.getMeta(xt);
    if (!r || i || !Number.isSafeInteger(o) || typeof s?.executionId != "string" || !Array.isArray(s.operationSpans))
      return null;
    const a = s.operationSpans.map(
      (l) => l.operationIndex
    );
    if (a.some((l, p) => l !== p))
      return null;
    const c = o + 1;
    return Qr(
      ss(n, c),
      {
        executionId: s.executionId,
        sequence: c,
        pluginInstanceId: "trace-seal-v2",
        pluginOrder: 1,
        visibleTransactionRange: [0, e.length - 1],
        operationIndexes: a
      }
    );
  }
}), at = g([
  {
    order: 0,
    instanceId: "stable-index-v2",
    componentRef: on,
    componentRefs: tn,
    plugin: wl,
    projectorRef: tn.projector,
    project: (e) => Rr.getState(e) ?? null,
    projectAfterApply: (e, t) => t.docChanged ? Ar(t.doc) : Rr.getState(e) ?? null,
    effectRef: null,
    effect: () => [],
    conformanceReceiptRef: "runtime-plugin-stable-index-v2-receipt-1"
  },
  {
    order: 1,
    instanceId: "trace-seal-v2",
    componentRef: sn,
    componentRefs: pt,
    plugin: Sl,
    projectorRef: pt.projector,
    project: (e) => Er.getState(e) ?? null,
    projectAfterApply: (e) => ls(Er.getState(e)),
    effectRef: pt.effect,
    effect: (e) => e.getMeta(Xe) ? g([
      {
        effectRef: pt.effect,
        kind: "observational",
        fingerprint: I({
          effect: "trace-sealed",
          sequence: e.time
        })
      }
    ]) : [],
    conformanceReceiptRef: "runtime-plugin-trace-seal-v2-receipt-1"
  }
]);
class Ve extends Error {
  constructor(t, n) {
    super(`${t}:${n}`), this.code = t, this.path = n, this.name = "RuntimeDriverFailureV2Error";
  }
}
const Ni = (e) => I(e.doc.toJSON()), Ol = (e) => [
  ...new Set(
    e.flatMap((t) => {
      const n = t.getMeta("zx.runtime.root.v2"), r = t.getMeta("zx.runtime.appended.v2");
      return n ? n.operationSpans.map((i) => i.operationIndex) : r?.operationIndexes ?? [];
    })
  )
].sort((t, n) => t - n), Al = (e) => e.steps.map((t) => {
  const n = t.toJSON(), i = t.getMap().ranges;
  return g({
    json: n,
    fingerprint: I(n),
    mapFingerprint: I({ ranges: i })
  });
}), Rl = (e, t, n) => e.map((r) => {
  const i = r.project(t), o = r.project(n);
  return g({
    pluginInstanceId: r.instanceId,
    projectorRef: r.projectorRef,
    beforeFingerprint: I(i),
    afterFingerprint: I(o),
    value: o
  });
}), El = (e, t, n) => e.map((r) => {
  const i = r.project(t), o = r.projectAfterApply(t, n);
  return g({
    pluginInstanceId: r.instanceId,
    projectorRef: r.projectorRef,
    beforeFingerprint: I(i),
    afterFingerprint: I(o),
    value: o
  });
}), dr = (e, t) => ({
  document: e.doc.toJSON(),
  selection: e.selection.toJSON(),
  storedMarks: e.storedMarks?.map((n) => n.toJSON()) ?? null,
  pluginStateFingerprint: t
}), pr = (e, t) => I(
  e.map((n) => ({
    pluginInstanceId: n.pluginInstanceId,
    fingerprint: t === "before" ? n.beforeFingerprint : n.afterFingerprint
  }))
), Tl = (e) => {
  const t = e.getMeta("zx.runtime.root.v2"), n = e.getMeta("zx.runtime.appended.v2");
  return {
    kind: t ? "root" : "appended",
    producer: n && typeof n.pluginInstanceId == "string" ? n.pluginInstanceId : null,
    steps: e.steps.map((r) => r.toJSON()),
    before: e.before.toJSON(),
    after: e.doc.toJSON()
  };
}, Mi = (e, t, n) => {
  const {
    state: r,
    transaction: i,
    kind: o,
    sequence: s,
    executionId: a,
    spans: c,
    producerIndex: l
  } = e, p = n.snapshot();
  if (!i.before.eq(r.doc))
    throw new Ve(
      "transaction-attribution-invalid",
      "$.driver.before"
    );
  let d;
  try {
    d = kl(
      i,
      o,
      s,
      a
    );
  } catch (S) {
    const b = S instanceof Error && S.message === "transaction-time-invalid" ? "transaction-time-invalid" : S instanceof Error && S.message === "transaction-attribution-invalid" ? "transaction-attribution-invalid" : "transaction-meta-invalid";
    throw new Ve(b, "$.driver.meta");
  }
  if (n.debit("metaBytes", ot(d), "$.driver.meta"), o === "root" && n.debit("rootSteps", i.steps.length, "$.driver.root.steps"), n.debit("steps", i.steps.length, "$.driver.steps"), !fl(r, i, n, l))
    throw new Ve(
      "transaction-filter-rejected",
      "$.driver.filter"
    );
  const f = El(
    t,
    r,
    i
  ), u = f.reduce(
    (S, b) => S + ot(b),
    0
  ), m = n.snapshot().pluginStateBytes, h = ul(
    r,
    i,
    n,
    u
  );
  if (!h.doc.eq(i.doc))
    throw new Ve(
      "transaction-attribution-invalid",
      "$.driver.after"
    );
  const y = Rl(t, r, h), x = y.reduce(
    (S, b) => S + ot(b),
    0
  );
  if (x > u || I(y) !== I(f))
    throw new Ve(
      "plugin-conformance-missing",
      "$.driver.pluginState.reservation"
    );
  n.set(
    "pluginStateBytes",
    m + x,
    "$.driver.pluginState"
  );
  const k = t.flatMap(
    (S) => S.effect(i)
  ), w = {
    kind: o,
    sequence: s,
    logicalTime: i.time,
    rootExecutionId: a,
    sourceAttribution: Il(i, o),
    operationSpans: c,
    steps: Al(i),
    allowedMeta: d,
    beforeDocumentFingerprint: Ni(r),
    afterDocumentFingerprint: Ni(h),
    selectionAndStoredMarksProof: {
      selectionSet: !1,
      storedMarksSet: !1
    },
    pluginState: y,
    safeEffects: k,
    resourceDelta: dl(n.snapshot(), p)
  };
  return {
    state: h,
    entry: g({
      ...w,
      fingerprint: I(w)
    })
  };
}, Fl = (e, t, n, r, i, o = at) => {
  const s = hl(e);
  if (s.length !== o.length || s.some((h, y) => h !== o[y].plugin))
    throw new Ve(
      "plugin-conformance-missing",
      "$.driver.plugins"
    );
  const a = Mi(
    {
      state: e,
      transaction: t,
      kind: "root",
      sequence: 0,
      executionId: r,
      spans: n,
      producerIndex: -1
    },
    o,
    i
  );
  let c = a.state, l = pr(
    a.entry.pluginState,
    "after"
  );
  const p = pr(
    a.entry.pluginState,
    "before"
  ), d = [t], f = [a.entry], u = o.map(() => ({
    state: e,
    n: 0,
    pluginStateFingerprint: p
  })), m = /* @__PURE__ */ new Set();
  for (; ; ) {
    i.debit("appendRounds", 1, "$.driver.append.round");
    let h = !1;
    for (let y = 0; y < o.length; y += 1) {
      const x = o[y], k = x.plugin.spec.appendTransaction, w = u[y].n;
      if (!k || w >= d.length) {
        u[y] = {
          state: c,
          n: d.length,
          pluginStateFingerprint: l
        };
        continue;
      }
      const S = d.slice(w), b = I({
        pluginInstanceId: x.instanceId,
        currentState: dr(
          c,
          l
        ),
        oldState: dr(
          u[y].state,
          u[y].pluginStateFingerprint
        ),
        orderedSeenStates: u.map(
          (wt) => dr(wt.state, wt.pluginStateFingerprint)
        ),
        visibleTransactions: S.map(Tl)
      });
      if (m.has(b))
        throw new Ve(
          "append-fixed-point-cycle",
          "$.driver.append"
        );
      m.add(b), i.debit("appendCalls", 1, `$.driver.append[${y}]`);
      const E = k.call(
        x.plugin,
        S,
        u[y].state,
        c
      );
      if (u[y] = {
        state: c,
        n: d.length,
        pluginStateFingerprint: l
      }, !E) continue;
      const V = d.length, xe = Ol(S), oe = {
        executionId: r,
        sequence: V,
        pluginInstanceId: x.instanceId,
        pluginOrder: x.order,
        visibleTransactionRange: [w, d.length - 1],
        operationIndexes: xe
      }, Ge = E.getMeta(Xe);
      if (Ge) {
        const wt = {
          protocol: "zx-runtime-appended-meta-v2",
          rootExecutionId: r,
          sequence: V,
          pluginInstanceId: x.instanceId,
          pluginOrder: x.order,
          visibleTransactionRange: oe.visibleTransactionRange,
          operationIndexes: xe
        };
        if (F(Ge) !== F(wt))
          throw new Ve(
            "transaction-attribution-invalid",
            "$.driver.append.meta"
          );
      } else
        Qr(E, oe);
      const ve = Mi(
        {
          state: c,
          transaction: E,
          kind: "appended",
          sequence: V,
          executionId: r,
          spans: [],
          producerIndex: y
        },
        o,
        i
      );
      d.push(E), f.push(ve.entry), c = ve.state, l = pr(
        ve.entry.pluginState,
        "after"
      ), h = !0, u[y] = {
        state: c,
        n: d.length,
        pluginStateFingerprint: l
      };
    }
    if (!h && u.every(
      (y) => y.n === d.length && y.state === c
    ))
      return {
        state: c,
        transactions: d,
        entries: g(f),
        pluginState: f.at(-1)?.pluginState ?? []
      };
  }
};
class ps extends TypeError {
  constructor(t) {
    super(`mark-policy-violation:${t}`), this.path = t, this.name = "RuntimeMarkPolicyV2Error";
  }
}
const Cl = (e, t) => [...e].sort((n, r) => {
  const i = (t.get(n.type.name) ?? Number.MAX_SAFE_INTEGER) - (t.get(r.type.name) ?? Number.MAX_SAFE_INTEGER);
  if (i !== 0) return i;
  const o = F(n.attrs), s = F(r.attrs);
  return o < s ? -1 : o > s ? 1 : 0;
}), Nl = (e, t) => {
  if (e.parent !== t.parent || !e.parent.inlineContent)
    throw new ps("$.plan.text.replace.target");
}, Ml = (e, t, n, r) => {
  const i = e.resolve(t), o = e.resolve(n);
  if (Nl(i, o), r.length === 0) return [];
  const s = t === n ? i.marks() : i.marksAcross(o) ?? [], a = new Map(
    Object.keys(e.type.schema.marks).map((l, p) => [l, p])
  ), c = Cl(s, a);
  return c.forEach((l) => {
    if (!e.type.schema.marks[l.type.name])
      throw new ps("$.plan.text.replace.marks");
  }), c;
}, Pl = (e, t) => {
  if (t <= 0 || t >= e.length) return !1;
  const n = e.charCodeAt(t - 1), r = e.charCodeAt(t);
  return n >= 55296 && n <= 56319 && r >= 56320 && r <= 57343;
}, B = (e, t, n, r, i, o, s = []) => ({
  supported: !0,
  semanticName: e,
  description: t,
  addressability: n,
  readableAttrs: s,
  content: r,
  risk: i,
  stream: o
}), Fe = (e, t, n, r, i, o, s = []) => ({
  supported: !0,
  semanticName: e,
  description: t,
  addressability: n,
  readableAttrs: s,
  content: r,
  risk: i,
  stream: o
}), ue = (e) => g(e), zl = g({
  builtinNodes: ue({
    nodes: {
      blockquote: B(
        "Block quote",
        "A quoted block.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      bulletList: B(
        "Bullet list",
        "An unordered list.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      codeBlock: B(
        "Code block",
        "A preformatted code block.",
        "block",
        "text",
        "textual",
        "atomic",
        ["language"]
      ),
      doc: B(
        "Document",
        "The canonical document root.",
        "none",
        "block",
        "read-only",
        "none"
      ),
      hardBreak: B(
        "Hard break",
        "An explicit line break.",
        "nearest-block",
        "none",
        "textual",
        "incremental"
      ),
      heading: B(
        "Heading",
        "A section heading.",
        "block",
        "inline",
        "textual",
        "incremental",
        ["level", "textAlign"]
      ),
      horizontalRule: B(
        "Horizontal rule",
        "A thematic divider.",
        "block",
        "none",
        "structural",
        "atomic"
      ),
      listItem: B(
        "List item",
        "A structured list item.",
        "block",
        "mixed",
        "structural",
        "atomic"
      ),
      orderedList: B(
        "Ordered list",
        "An ordered list.",
        "block",
        "block",
        "structural",
        "atomic",
        ["start"]
      ),
      pageBreak: B(
        "Page break",
        "A pagination boundary.",
        "block",
        "none",
        "structural",
        "atomic"
      ),
      paragraph: B(
        "Paragraph",
        "A paragraph of inline content.",
        "block",
        "inline",
        "textual",
        "incremental",
        ["textAlign"]
      ),
      table: B(
        "Table",
        "A table containing rows and cells.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      tableCell: B(
        "Table cell",
        "A non-header table cell.",
        "nearest-block",
        "mixed",
        "structural",
        "atomic",
        ["cellId"]
      ),
      tableHeader: B(
        "Table header",
        "A table header cell.",
        "nearest-block",
        "mixed",
        "structural",
        "atomic",
        ["cellId"]
      ),
      tableRow: B(
        "Table row",
        "A row within a table.",
        "nearest-block",
        "block",
        "structural",
        "atomic",
        ["rowId"]
      ),
      taskItem: B(
        "Task item",
        "A checkable list item.",
        "block",
        "mixed",
        "structural",
        "atomic",
        ["checked"]
      ),
      taskList: B(
        "Task list",
        "A list of task items.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      text: B(
        "Text",
        "Canonical inline text.",
        "nearest-block",
        "text",
        "textual",
        "incremental"
      )
    },
    marks: {}
  }),
  builtinMarks: ue({
    nodes: {},
    marks: {
      bold: Fe(
        "Bold",
        "Strong emphasis.",
        "block-range",
        "text",
        "textual",
        "incremental"
      ),
      code: Fe(
        "Inline code",
        "Inline code semantics.",
        "block-range",
        "text",
        "textual",
        "atomic"
      ),
      italic: Fe(
        "Italic",
        "Emphasized text.",
        "block-range",
        "text",
        "textual",
        "incremental"
      ),
      link: Fe(
        "Link",
        "A hyperlink on a block-local range.",
        "block-range",
        "text",
        "external-resource",
        "atomic",
        ["href", "rel", "target"]
      ),
      strike: Fe(
        "Strikethrough",
        "Struck text styling.",
        "block-range",
        "text",
        "textual",
        "incremental"
      ),
      textStyle: Fe(
        "Text style",
        "Allowlisted text style attrs.",
        "block-range",
        "text",
        "textual",
        "atomic",
        ["color", "fontFamily", "fontSize"]
      ),
      underline: Fe(
        "Underline",
        "Underlined text styling.",
        "block-range",
        "text",
        "textual",
        "incremental"
      )
    }
  }),
  attachment: ue({
    nodes: {
      attachment: B(
        "Attachment",
        "An asset attachment.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "display"]
      )
    },
    marks: {}
  }),
  comment: ue({
    nodes: {},
    marks: {
      comment: Fe(
        "Comment anchor",
        "A comment annotation anchor.",
        "block-range",
        "text",
        "sensitive",
        "none",
        ["commentId", "resolved"]
      )
    }
  }),
  embed: ue({
    nodes: {
      embed: B(
        "Embed",
        "An external resource embed.",
        "nearest-block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "name", "title", "url"]
      )
    },
    marks: {}
  }),
  iframe: ue({
    nodes: {
      iframe: B(
        "Embedded frame",
        "An embedded frame.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "title", "width", "height", "aspectRatio"]
      )
    },
    marks: {}
  }),
  image: ue({
    nodes: {
      image: B(
        "Image",
        "An image with descriptive metadata.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "alt", "title", "width", "height", "align"]
      )
    },
    marks: {}
  }),
  imageGroup: ue({
    nodes: {
      imageGroup: B(
        "Image group",
        "A group of image blocks.",
        "block",
        "block",
        "structural",
        "atomic",
        ["columns"]
      )
    },
    marks: {}
  }),
  mention: ue({
    nodes: {
      mention: B(
        "Mention",
        "An inline mention reference.",
        "nearest-block",
        "none",
        "sensitive",
        "atomic",
        ["id", "label"]
      )
    },
    marks: {}
  }),
  namedColor: ue({
    nodes: {},
    marks: {
      namedColor: Fe(
        "Named text color",
        "A named foreground color.",
        "block-range",
        "text",
        "textual",
        "atomic",
        ["color"]
      )
    }
  }),
  namedHighlight: ue({
    nodes: {},
    marks: {
      namedHighlight: Fe(
        "Named highlight",
        "A named highlight color.",
        "block-range",
        "text",
        "textual",
        "atomic",
        ["color"]
      )
    }
  }),
  tag: ue({
    nodes: {
      tagItem: B(
        "Tag",
        "An inline tag reference.",
        "nearest-block",
        "none",
        "sensitive",
        "atomic",
        ["tagId", "tagLabel"]
      )
    },
    marks: {}
  }),
  toggle: ue({
    nodes: {
      toggle: B(
        "Toggle",
        "A collapsible container.",
        "block",
        "block",
        "structural",
        "atomic",
        ["open"]
      ),
      toggleSummary: B(
        "Toggle summary",
        "A toggle summary.",
        "block",
        "mixed",
        "structural",
        "atomic"
      ),
      toggleContent: B(
        "Toggle content",
        "A toggle content container.",
        "block",
        "block",
        "structural",
        "atomic"
      )
    },
    marks: {}
  }),
  video: ue({
    nodes: {
      video: B(
        "Video",
        "A video resource.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "controls"]
      )
    },
    marks: {}
  })
}), jl = {
  builtinNodes: [
    "blockId",
    "cellId",
    "checked",
    "language",
    "level",
    "rowId",
    "start",
    "textAlign"
  ],
  builtinMarks: ["color", "fontFamily", "fontSize", "href", "rel", "target"],
  attachment: ["assetId", "display"],
  comment: ["commentId", "resolved"],
  embed: ["assetId", "name", "title", "url", "icon"],
  iframe: [
    "assetId",
    "src",
    "width",
    "height",
    "aspectRatio",
    "align",
    "title",
    "interactive",
    "fullWidth"
  ],
  image: [
    "assetId",
    "src",
    "alt",
    "title",
    "width",
    "height",
    "align",
    "loading"
  ],
  imageGroup: ["columns"],
  mention: ["id", "label"],
  namedColor: ["color"],
  namedHighlight: ["color"],
  tag: ["tagId", "tagLabel"],
  toggle: ["open"],
  video: ["assetId", "src", "controls"]
}, Dl = /* @__PURE__ */ new WeakMap(), $l = (e, t) => {
  const n = g({
    name: e,
    attrs: jl[e],
    nodes: Object.keys(t.nodes),
    marks: Object.keys(t.marks),
    ai: t
  }), r = new Proxy(n, {
    get(i, o, s) {
      return Reflect.has(i, o) ? Reflect.get(i, o, s) : Dl.get(r)?.[o];
    }
  });
  return r;
}, Jn = g(
  Object.entries(zl).map(
    ([e, t]) => $l(e, t)
  )
), Pi = (e) => F({
  code: e.code,
  descriptor: e.descriptor ?? "",
  kind: e.kind ?? "",
  type: e.type ?? "",
  blockId: e.blockId ?? "",
  attr: e.attr ?? "",
  inputIndex: e.inputIndex ?? -1
}), Bl = (e) => [...e].sort(
  (t, n) => Pi(t).localeCompare(Pi(n))
), _l = (e) => g({
  valid: !e.some((t) => t.severity === "error"),
  issues: Bl(e)
});
class fs extends Error {
  constructor(t) {
    super(
      t.issues[0]?.message ?? "AI semantic contract validation failed."
    ), this.name = "ZxAISemanticContractError", this.report = g(t);
  }
}
const Le = (e) => {
  throw new fs(_l(e));
}, Vl = /* @__PURE__ */ new Set(["block", "nearest-block", "none"]), Ll = /* @__PURE__ */ new Set(["block-range", "none"]), ql = /* @__PURE__ */ new Set(["none", "text", "inline", "block", "mixed"]), Kl = /* @__PURE__ */ new Set([
  "read-only",
  "textual",
  "structural",
  "external-resource",
  "sensitive"
]), Jl = /* @__PURE__ */ new Set(["incremental", "atomic", "none"]), Ul = /* @__PURE__ */ new Set([
  "external-resource-restricted",
  "not-addressable",
  "requires-specialized-operation",
  "sensitive-content",
  "unsafe-projection"
]), Hl = new Set(
  sc()
), Ut = (e) => typeof e == "string" && e.trim().length > 0, fr = (e = []) => [...new Set(e)].sort(), us = (e) => [...e].sort((t, n) => t.name.localeCompare(n.name)).map((t) => ({
  name: t.name,
  attrs: fr(t.attrs),
  nodes: fr(t.nodes),
  marks: fr(t.marks),
  ai: {
    nodes: Object.fromEntries(
      Object.entries(t.ai.nodes).sort(
        ([n], [r]) => n.localeCompare(r)
      )
    ),
    marks: Object.fromEntries(
      Object.entries(t.ai.marks).sort(
        ([n], [r]) => n.localeCompare(r)
      )
    )
  }
})), zi = (e, t, n, r, i) => {
  const o = new Set(r), s = new Set(Object.keys(i));
  r.forEach((a) => {
    s.has(a) || e.push({
      code: "ai-capability-missing",
      severity: "error",
      message: `Descriptor "${t.name}" is missing an AI ${n} capability for "${a}".`,
      descriptor: t.name,
      kind: n,
      type: a
    });
  }), s.forEach((a) => {
    o.has(a) || e.push({
      code: "ai-capability-orphan",
      severity: "error",
      message: `Descriptor "${t.name}" has an orphan AI ${n} capability for "${a}".`,
      descriptor: t.name,
      kind: n,
      type: a
    });
  });
}, ji = (e, t, n, r, i) => {
  const o = (c, l) => e.push({
    code: "ai-capability-invalid",
    severity: "error",
    message: c,
    descriptor: t.name,
    kind: n,
    type: r,
    attr: l
  });
  if (!i || typeof i != "object") {
    o(`AI ${n} capability "${r}" must be an object.`);
    return;
  }
  if (i.supported === !1) {
    Ul.has(i.reasonCode) || o(`Unsupported AI ${n} "${r}" has an invalid reason code.`), Ut(i.description) || o(`Unsupported AI ${n} "${r}" requires a description.`);
    return;
  }
  if (i.supported !== !0) {
    o(
      `AI ${n} capability "${r}" requires an explicit supported state.`
    );
    return;
  }
  if (Ut(i.semanticName) || o(`Supported AI ${n} "${r}" requires a semanticName.`), Ut(i.description) || o(`Supported AI ${n} "${r}" requires a description.`), (n === "node" ? Vl : Ll).has(i.addressability) || o(`Supported AI ${n} "${r}" has invalid addressability.`), ql.has(i.content) || o(`Supported AI ${n} "${r}" has invalid content projection.`), Kl.has(i.risk) || o(`Supported AI ${n} "${r}" has invalid risk.`), Jl.has(i.stream) || o(`Supported AI ${n} "${r}" has invalid stream policy.`), !Array.isArray(i.readableAttrs)) {
    o(`Supported AI ${n} "${r}" requires readableAttrs.`);
    return;
  }
  const s = new Set(t.attrs ?? []), a = /* @__PURE__ */ new Set();
  i.readableAttrs.forEach((c) => {
    if (!Ut(c) || a.has(c)) {
      o(
        `Supported AI ${n} "${r}" has an invalid readable attr.`,
        c
      );
      return;
    }
    a.add(c), s.has(c) || e.push({
      code: "ai-readable-attr-outside-descriptor",
      severity: "error",
      message: `AI ${n} "${r}" exposes attr "${c}" outside descriptor "${t.name}".`,
      descriptor: t.name,
      kind: n,
      type: r,
      attr: c
    });
  }), n === "node" && r === "doc" && i.addressability === "block" && o("The document root cannot claim stable block addressability."), n === "node" && i.addressability === "block" && !Hl.has(r) && !s.has("blockId") && o(
    `Addressable AI node "${r}" must participate in stable block identity.`,
    "blockId"
  );
}, Wl = (e = Jn) => {
  const t = [], n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
  e.forEach((s) => {
    (!Ut(s.name) || n.has(s.name)) && t.push({
      code: "ai-descriptor-ownership-conflict",
      severity: "error",
      message: `AI descriptor name "${s.name}" is invalid or duplicated.`,
      descriptor: s.name
    }), n.add(s.name);
    const a = s.nodes ?? [], c = s.marks ?? [], l = s.ai;
    if (!l || typeof l != "object" || !l.nodes || !l.marks) {
      t.push({
        code: "ai-capability-missing",
        severity: "error",
        message: `Descriptor "${s.name}" requires explicit ai.nodes and ai.marks maps.`,
        descriptor: s.name
      });
      return;
    }
    zi(t, s, "node", a, l.nodes), zi(t, s, "mark", c, l.marks), a.forEach((p) => {
      const d = r.get(p);
      d ? t.push({
        code: "ai-descriptor-ownership-conflict",
        severity: "error",
        message: `AI node "${p}" is owned by both "${d}" and "${s.name}".`,
        descriptor: s.name,
        kind: "node",
        type: p
      }) : r.set(p, s.name);
    }), c.forEach((p) => {
      const d = i.get(p);
      d ? t.push({
        code: "ai-descriptor-ownership-conflict",
        severity: "error",
        message: `AI mark "${p}" is owned by both "${d}" and "${s.name}".`,
        descriptor: s.name,
        kind: "mark",
        type: p
      }) : i.set(p, s.name);
    }), Object.entries(l.nodes).forEach(
      ([p, d]) => ji(t, s, "node", p, d)
    ), Object.entries(l.marks).forEach(
      ([p, d]) => ji(t, s, "mark", p, d)
    );
  });
  let o = "";
  try {
    o = F(
      us(e)
    );
  } catch {
    t.push({
      code: "ai-capability-invalid",
      severity: "error",
      message: "Descriptor AI capability metadata must be canonicalizable."
    });
  }
  return g({
    valid: t.length === 0,
    issues: [...t].sort(
      (s, a) => F(s).localeCompare(F(a))
    ),
    descriptors: [...n].sort(),
    nodeTypes: [...r.keys()].sort(),
    markTypes: [...i.keys()].sort(),
    capabilityCanonicalForm: o
  });
}, Xl = (e = Jn) => {
  const t = Wl(e);
  if (!t.valid)
    throw new fs(t);
  return t;
}, Gl = (e = Jn) => us(e), Zl = (e) => Array.from(e, (t) => t.toString(16).padStart(2, "0")).join(""), Yl = async (e) => {
  const t = globalThis.crypto?.subtle;
  t || Le([
    {
      code: "crypto-unavailable",
      severity: "error",
      message: "Web Crypto subtle.digest is required for AI semantic fingerprints."
    }
  ]);
  const n = await t.digest("SHA-256", so(e));
  return `sha256:${Zl(new Uint8Array(n))}`;
}, Ql = (e, t, n) => Le([
  {
    code: e,
    severity: "error",
    message: t,
    descriptor: n?.descriptor,
    kind: n?.kind,
    type: n?.type,
    blockId: n?.blockId,
    attr: n?.attr
  }
]), ei = (e, t, n, r) => r, Di = (e, t) => ei(e?.node, t, /* @__PURE__ */ new Set(["include", "omit"]), {
  action: "include"
}), ed = (e, t) => ei(
  e?.attr,
  t,
  /* @__PURE__ */ new Set(["include", "omit", "replace"]),
  { action: "include" }
), td = (e, t) => {
  const n = ei(
    e?.text,
    t,
    /* @__PURE__ */ new Set(["include", "omit", "replace"]),
    { action: "include" }
  );
  return n.action === "replace" && typeof n.value != "string" && Ql(
    "policy-decision-invalid",
    "AI text policy replacement must be a string.",
    t
  ), n;
}, un = (e) => ({
  code: "scope-access-denied",
  severity: "info",
  message: e.attr ? `Policy omitted attr "${e.attr}" from AI semantic output.` : `Policy omitted ${e.kind} "${e.type}" from AI semantic output.`,
  descriptor: e.descriptor,
  kind: e.kind,
  type: e.type,
  blockId: e.blockId,
  ...e.attr ? { attr: e.attr } : {}
}), ur = (e, t) => e.descriptor.localeCompare(t.descriptor) || e.kind.localeCompare(t.kind) || e.type.localeCompare(t.type), nd = (e) => {
  const t = [], n = [], r = [];
  return e.forEach((i) => {
    Object.entries(i.ai.nodes).forEach(([o, s]) => {
      if (!s.supported) {
        r.push({
          descriptor: i.name,
          kind: "node",
          type: o,
          supported: !1,
          reasonCode: s.reasonCode,
          description: s.description
        });
        return;
      }
      t.push({
        descriptor: i.name,
        kind: "node",
        type: o,
        semanticName: s.semanticName,
        description: s.description,
        addressability: s.addressability,
        readableAttrs: [...s.readableAttrs].sort(),
        content: s.content,
        risk: s.risk,
        stream: s.stream
      });
    }), Object.entries(i.ai.marks).forEach(([o, s]) => {
      if (!s.supported) {
        r.push({
          descriptor: i.name,
          kind: "mark",
          type: o,
          supported: !1,
          reasonCode: s.reasonCode,
          description: s.description
        });
        return;
      }
      n.push({
        descriptor: i.name,
        kind: "mark",
        type: o,
        semanticName: s.semanticName,
        description: s.description,
        addressability: s.addressability,
        readableAttrs: [...s.readableAttrs].sort(),
        content: s.content,
        risk: s.risk,
        stream: s.stream
      });
    });
  }), t.sort(ur), n.sort(ur), r.sort(ur), { nodes: t, marks: n, unsupported: r };
}, rd = (e, t) => (Xl(e), g({
  contractVersion: 1,
  descriptorFingerprint: t,
  ...nd(e)
})), id = (e) => g({
  admittedNodes: new Map(e.nodes.map((t) => [t.type, t])),
  admittedMarks: new Map(e.marks.map((t) => [t.type, t])),
  deniedNodes: /* @__PURE__ */ new Set(),
  deniedMarks: /* @__PURE__ */ new Set(),
  readableAttrs: new Map(
    [...e.nodes, ...e.marks].map((t) => [
      `${t.kind}:${t.type}`,
      new Set(t.readableAttrs)
    ])
  )
}), od = {
  "protocol-envelope-invalid": {
    phase: "protocol",
    message: "The operation envelope is not valid protocol JSON."
  },
  "protocol-version-unsupported": {
    phase: "protocol",
    message: "The operation protocol version is not supported."
  },
  "operation-kind-unsupported": {
    phase: "shape",
    message: "The operation kind is not supported."
  },
  "operation-shape-invalid": {
    phase: "shape",
    message: "The operation does not match its exact protocol shape."
  },
  "snapshot-precondition-failed": {
    phase: "source",
    message: "The source snapshot fingerprint does not match."
  },
  "revision-precondition-failed": {
    phase: "source",
    message: "The source document revision does not match."
  },
  "descriptor-precondition-failed": {
    phase: "source",
    message: "The source descriptor fingerprint does not match."
  },
  "operation-target-not-found": {
    phase: "address",
    message: "The addressed block does not exist in the snapshot."
  },
  "operation-target-not-operable": {
    phase: "address",
    message: "The addressed block is not operable in this snapshot."
  },
  "operation-address-invalid": {
    phase: "address",
    message: "The operation address is invalid."
  },
  "operation-range-invalid": {
    phase: "address",
    message: "The text range is not an exposed UTF-16 block range."
  },
  "operation-precondition-block-mismatch": {
    phase: "precondition",
    message: "The operation precondition addresses a different block."
  },
  "operation-type-precondition-failed": {
    phase: "precondition",
    message: "The block type precondition does not match."
  },
  "operation-content-precondition-failed": {
    phase: "precondition",
    message: "The block content precondition does not match."
  },
  "operation-capability-denied": {
    phase: "capability",
    message: "The manifest capability does not permit this operation."
  },
  "operation-payload-invalid": {
    phase: "payload",
    message: "The canonical block payload is invalid."
  },
  "operation-block-id-invalid": {
    phase: "payload",
    message: "The payload blockId is invalid."
  },
  "operation-block-id-conflict": {
    phase: "payload",
    message: "The payload blockId conflicts with the snapshot."
  },
  "operation-batch-conflict": {
    phase: "batch",
    message: "The operation batch contains an implicit dependency or conflict."
  },
  "complex-node-validation-failed": {
    phase: "capability",
    message: "The complex-node operation failed closed validation."
  },
  "internal-validation-failed": {
    phase: "internal",
    message: "The operation could not be validated safely."
  }
}, N = (e, t = {}) => g({
  code: e,
  severity: "error",
  ...od[e],
  ...t.operationIndex === void 0 ? {} : { operationIndex: t.operationIndex },
  ...t.kind === void 0 ? {} : { kind: t.kind },
  ...t.blockId === void 0 ? {} : { blockId: t.blockId },
  ...t.nodeType === void 0 ? {} : { nodeType: t.nodeType },
  ...t.complexCode === void 0 ? {} : { complexCode: t.complexCode },
  ...t.recovery === void 0 ? {} : { recovery: t.recovery }
}), sd = (e) => F({
  code: e.code,
  phase: e.phase,
  operationIndex: e.operationIndex ?? -1,
  kind: e.kind ?? "",
  blockId: e.blockId ?? "",
  nodeType: e.nodeType ?? "",
  complexCode: e.complexCode ?? "",
  recovery: e.recovery ?? ""
}), Tt = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((n) => {
    const r = sd(n);
    t.has(r) || t.set(r, n);
  }), g(
    [...t.entries()].sort(([n], [r]) => n.localeCompare(r)).map(([, n]) => n)
  );
}, Tr = (e) => !!(e && Object.prototype.hasOwnProperty.call(e, "startOffset") && Object.prototype.hasOwnProperty.call(e, "endOffset")), hs = (e, t) => {
  e.forEach((n) => {
    t(n), hs(n.children, t);
  });
}, ad = (e, t) => {
  const n = [], r = (i, o = !1) => {
    !o && i.address && !Tr(i.address) && i.address.blockId !== t || (Tr(i.address) && i.address.blockId === t && typeof i.text == "string" ? n.push({
      kind: "text",
      startOffset: i.address.startOffset,
      endOffset: i.address.endOffset,
      text: i.text
    }) : i.type === "hardBreak" && i.relation?.ancestorBlockId === t && n.push({ kind: "hard-break" }), i.children.forEach((s) => r(s)));
  };
  return r(e, !0), n;
}, cd = (e, t) => {
  const n = ad(e, t);
  if (n.length === 0)
    return g([{ startOffset: 0, endOffset: 0, text: "" }]);
  const r = [];
  if (n.forEach((o, s) => {
    if (o.kind === "text") {
      if (!Number.isInteger(o.startOffset) || !Number.isInteger(o.endOffset) || o.startOffset < 0 || o.endOffset < o.startOffset || o.text.length !== o.endOffset - o.startOffset)
        return;
      r.push(o);
      return;
    }
    const a = [...n].slice(0, s).map((u, m) => ({ entry: u, entryIndex: m })).reverse().find(({ entry: u }) => u.kind === "text")?.entryIndex, c = n.slice(s + 1).findIndex((u) => u.kind === "text"), l = c < 0 ? -1 : s + 1 + c, p = a === void 0 ? null : n[a], d = l < 0 ? null : n[l], f = p ? p.endOffset + (s - a - 1) : d ? d.startOffset - (l - s) : s;
    !Number.isInteger(f) || f < 0 || r.push({
      startOffset: f,
      endOffset: f + 1,
      text: `
`
    });
  }), r.length !== n.length || r.some(
    (o) => o.text.length !== o.endOffset - o.startOffset
  ))
    return null;
  r.sort(
    (o, s) => o.startOffset - s.startOffset || o.endOffset - s.endOffset
  );
  const i = [];
  for (const o of r) {
    const s = i.at(-1);
    if (!s) {
      i.push({ ...o });
      continue;
    }
    if (o.startOffset < s.endOffset) return null;
    if (o.startOffset === s.endOffset) {
      s.endOffset = o.endOffset, s.text += o.text;
      continue;
    }
    i.push({ ...o });
  }
  return g(i);
}, ms = (e) => {
  const t = /* @__PURE__ */ new Set(), n = [];
  hs(e.nodes, (r) => {
    n.push(r), r.address?.blockId && t.add(r.address.blockId);
  });
  try {
    if (new Set(e.operableBlockIds).size !== e.operableBlockIds.length)
      return {
        valid: !1,
        targets: null,
        observedBlockIds: t,
        diagnostics: Tt([
          N("internal-validation-failed")
        ])
      };
    const r = new Set(
      e.manifest.nodes.filter((o) => o.addressability === "block").map((o) => o.type)
    ), i = /* @__PURE__ */ new Map();
    for (const o of e.operableBlockIds) {
      const s = n.filter(
        (l) => l.operability === "operable" && l.address?.blockId === o && !Tr(l.address) && r.has(l.type)
      );
      if (s.length !== 1)
        return {
          valid: !1,
          targets: null,
          observedBlockIds: t,
          diagnostics: Tt([
            N("internal-validation-failed")
          ])
        };
      const a = s[0], c = cd(a, o);
      if (!c)
        return {
          valid: !1,
          targets: null,
          observedBlockIds: t,
          diagnostics: Tt([
            N("internal-validation-failed")
          ])
        };
      i.set(o, {
        blockId: o,
        type: a.type,
        node: a,
        intervals: c
      });
    }
    return {
      valid: !0,
      targets: i,
      observedBlockIds: t,
      diagnostics: []
    };
  } catch {
    return {
      valid: !1,
      targets: null,
      observedBlockIds: t,
      diagnostics: Tt([
        N("internal-validation-failed")
      ])
    };
  }
}, ld = async (e) => {
  const t = ms(e);
  if (!t.valid) return t;
  try {
    const n = /* @__PURE__ */ new Map();
    for (const [r, i] of t.targets)
      n.set(r, {
        ...i,
        contentFingerprint: await Yl(i.node)
      });
    return {
      valid: !0,
      targets: n,
      observedBlockIds: t.observedBlockIds,
      diagnostics: []
    };
  } catch {
    return {
      valid: !1,
      targets: null,
      observedBlockIds: t.observedBlockIds,
      diagnostics: Tt([
        N("internal-validation-failed")
      ])
    };
  }
}, dd = (e, t, n) => e.intervals.find(
  (r) => t >= r.startOffset && n <= r.endOffset
) ?? null, $i = (e, t) => {
  const n = t - e.startOffset;
  if (n <= 0 || n >= e.text.length) return !1;
  const r = e.text.charCodeAt(n - 1), i = e.text.charCodeAt(n);
  return r >= 55296 && r <= 56319 && i >= 56320 && i <= 57343;
}, pd = (e, t, n, r, i) => {
  const o = [...n.values()].sort(
    (s, a) => s.order - a.order
  );
  {
    const s = (c) => {
      let l = n.get(c) ?? null;
      for (; l; ) {
        if (!r.admittedNodes.has(l.nodeType)) return !1;
        l = l.parentBlockId ? n.get(l.parentBlockId) ?? null : null;
      }
      return !0;
    }, a = o.filter((c) => s(c.blockId)).map((c) => c.blockId);
    return {
      normalized: { kind: "document" },
      selection: null,
      contentBlockIds: new Set(a),
      contextBlockIds: /* @__PURE__ */ new Set(),
      operableBlockIds: a
    };
  }
}, fd = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((n) => {
    n.textSegments.forEach(
      (r) => t.set(r.node, { blockId: n.blockId, segment: r })
    );
  }), t;
}, ud = (e, t, n) => {
  if (!n.selection) return { start: 0, end: t };
  const { selection: r } = n;
  return r.collapsed ? { start: r.start.offset, end: r.start.offset } : {
    start: e === r.start.blockId ? r.start.offset : 0,
    end: e === r.end.blockId ? r.end.offset : t
  };
}, hd = (e, t, n, r, i) => {
  const o = [], s = fd(t), a = /* @__PURE__ */ new Map(), c = (u) => {
    const m = typeof u.attrs?.blockId == "string" ? u.attrs.blockId : null;
    return m && (r.contentBlockIds.has(m) || r.contextBlockIds.has(m)) ? !0 : (u.content ?? []).some(c);
  }, l = (u, m, h, y, x, k) => {
    const w = n.readableAttrs.get(`${h}:${y}`) ?? /* @__PURE__ */ new Set(), S = {};
    return [...w].sort().forEach((b) => {
      if (!k || !Object.prototype.hasOwnProperty.call(k, b)) return;
      const E = ed(i, {
        value: k[b]
      });
      if (E.action === "omit") {
        o.push(
          un({
            descriptor: m,
            type: y,
            kind: h,
            blockId: x,
            attr: b
          })
        );
        return;
      }
      S[b] = E.action === "replace" ? E.value : k[b];
      try {
        F(S[b]);
      } catch {
        Le([
          {
            code: "policy-result-not-canonical",
            severity: "error",
            message: "Projected AI attribute is not canonicalizable.",
            descriptor: m,
            kind: h,
            type: y,
            blockId: x,
            attr: b
          }
        ]);
      }
    }), S;
  }, p = (u, m, h, y) => {
    const x = [];
    return u.forEach((k) => {
      const w = k.type ?? "unknown", S = n.admittedMarks.get(w);
      if (!S) {
        if (n.deniedMarks.has(w)) return;
        Le([
          {
            code: "unknown-document-mark",
            severity: "error",
            message: `Mark "${w}" is unknown, unsupported or denied by policy.`,
            kind: "mark",
            type: w,
            blockId: m
          }
        ]);
      }
      const b = S;
      if (Di(i, {
        descriptor: b.descriptor
      }).action === "omit") {
        o.push(
          un({
            descriptor: b.descriptor,
            kind: "mark",
            type: w,
            blockId: m
          })
        );
        return;
      }
      x.push({
        type: w,
        semanticName: b.semanticName,
        attrs: l(
          k,
          b.descriptor,
          "mark",
          w,
          m,
          k.attrs
        ),
        address: b.addressability === "block-range" ? { blockId: m, startOffset: h, endOffset: y } : null
      });
    }), x.sort((k, w) => k.type.localeCompare(w.type));
  }, d = (u, m, h, y) => {
    const x = u.type ?? "unknown", k = n.admittedNodes.get(x);
    if (!k) {
      if (n.deniedNodes.has(x))
        return m === "shell" && c(u) && Le([
          {
            code: "scope-access-denied",
            severity: "error",
            message: "Policy denied an ancestor required by the requested scope.",
            kind: "node",
            type: x,
            blockId: typeof u.attrs?.blockId == "string" ? u.attrs.blockId : null
          }
        ]), null;
      if (m === "shell" && !c(u))
        return null;
      Le([
        {
          code: "unknown-document-node",
          severity: "error",
          message: `Node "${x}" is unknown, unsupported or denied by policy.`,
          kind: "node",
          type: x,
          blockId: typeof u.attrs?.blockId == "string" ? u.attrs.blockId : null
        }
      ]);
    }
    const w = k, S = w.addressability === "block" && typeof u.attrs?.blockId == "string" ? u.attrs.blockId : null;
    let b = m;
    if (S)
      if (r.contentBlockIds.has(S)) b = "content";
      else if (r.contextBlockIds.has(S)) b = "shell";
      else return null;
    let E = a.get(u);
    if (E || (E = Di(i, {
      descriptor: w.descriptor
    }).action, a.set(u, E)), E === "omit")
      return r.normalized.kind !== "document" && (S && (r.contentBlockIds.has(S) || r.contextBlockIds.has(S)) || c(u)) && Le([
        {
          code: "scope-access-denied",
          severity: "error",
          message: "Policy denied a node required by the requested scope.",
          descriptor: w.descriptor,
          kind: "node",
          type: x,
          blockId: S
        }
      ]), o.push(
        un({
          descriptor: w.descriptor,
          kind: "node",
          type: x,
          blockId: S ?? h
        })
      ), null;
    const V = S ?? h, xe = (u.content ?? []).map(
      (Bt, cn) => d(Bt, b, V, cn)
    ).filter((Bt) => !!Bt), oe = s.get(u);
    let Ge, ve = null;
    if (typeof u.text == "string" && oe && b === "content") {
      const Bt = t.get(oe.blockId), cn = ud(
        oe.blockId,
        Bt.textLength,
        r
      ), Yn = Math.max(oe.segment.startOffset, cn.start), Qn = Math.min(oe.segment.endOffset, cn.end);
      if (Qn <= Yn) return null;
      const ci = Yn - oe.segment.startOffset, li = Qn - oe.segment.startOffset, er = td(i, {
        descriptor: w.descriptor,
        type: x,
        blockId: oe.blockId,
        value: u.text.slice(ci, li)
      });
      if (er.action === "omit")
        return o.push(
          un({
            descriptor: w.descriptor,
            kind: "node",
            type: x,
            blockId: oe.blockId
          })
        ), null;
      Ge = er.action === "replace" ? er.value : u.text.slice(ci, li), ve = { blockId: oe.blockId, startOffset: Yn, endOffset: Qn };
    }
    if (b === "shell" && xe.length === 0 && !S) return null;
    const wt = l(
      u,
      w.descriptor,
      "node",
      x,
      S ?? h,
      u.attrs
    ), Qs = b === "content" && ve ? p(
      u.marks ?? [],
      ve.blockId,
      ve.startOffset,
      ve.endOffset
    ) : [], ea = b === "content" && S ? { blockId: S } : ve, ta = S ? null : {
      addressable: !1,
      ancestorBlockId: b === "content" && h ? h : null,
      role: x,
      ordinal: y,
      persistence: "snapshot-local"
    };
    return {
      type: x,
      semanticName: w.semanticName,
      operability: b === "content" && (S && r.operableBlockIds.includes(S)) || b === "content" && ve ? "operable" : "context-only",
      address: ea,
      relation: ta,
      attrs: wt,
      ...Ge !== void 0 ? { text: Ge } : {},
      marks: Qs,
      children: xe
    };
  }, f = d(
    e,
    r.normalized.kind === "document" ? "content" : "shell",
    null,
    0
  );
  return {
    nodes: f ? [f] : [],
    diagnostics: o
  };
}, md = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : 0, Fr = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : e.content ? e.content.reduce(
  (t, n) => t + Fr(n),
  2
) : 1, gd = (e, t, n) => {
  const r = [], i = [], o = /* @__PURE__ */ new Set();
  let s = 0;
  const a = (c, l, p) => {
    const d = c.type ?? "unknown";
    let f = null;
    if (t.has(d)) {
      const y = c.attrs?.[rc], x = typeof y == "string" ? y : null;
      x ? An(x) ? o.has(x) ? r.push({
        code: "duplicate-block-id",
        severity: "error",
        message: `Addressable node "${d}" has a duplicate blockId.`,
        type: d,
        kind: "node",
        blockId: x
      }) : (o.add(x), f = {
        blockId: x,
        nodeType: d,
        node: c,
        order: s++,
        pos: l,
        nodeSize: Fr(c),
        textLength: 0,
        textSegments: [],
        parentBlockId: p.at(-1)?.blockId ?? null
      }, i.push(f)) : r.push({
        code: "invalid-block-id",
        severity: "error",
        message: `Addressable node "${d}" has an invalid blockId.`,
        type: d,
        kind: "node",
        blockId: x
      }) : r.push({
        code: "missing-block-id",
        severity: "error",
        message: `Addressable node "${d}" is missing blockId.`,
        type: d,
        kind: "node",
        blockId: null
      });
    }
    const u = f ? [...p, f] : p, m = md(c);
    m > 0 && u.forEach((y) => {
      const x = y.textLength;
      y.textLength += m, y.textSegments.push({
        node: c,
        from: l,
        to: l + m,
        startOffset: x,
        endOffset: y.textLength
      });
    });
    let h = c.type === "doc" ? l : l + 1;
    c.content?.forEach((y) => {
      a(y, h, u), h += Fr(y);
    });
  };
  return a(e, 0, []), r.length > 0 && Le(r), new Map(i.map((c) => [c.blockId, c]));
}, yd = (e, t) => gd(
  e,
  t
), bd = (e, t) => {
  const n = Tn(e);
  return n.valid || Le(
    n.issues.map((r) => ({
      code: r.code === "missing-block-id" || r.code === "invalid-block-id" || r.code === "duplicate-block-id" ? r.code : r.code === "document-schema-invalid" ? "unknown-document-node" : r.code === "document-version-mismatch" ? "document-version-unsupported" : "document-format-invalid",
      severity: "error",
      message: r.code === "document-version-mismatch" ? "AI semantic snapshots require document version 2." : r.code === "document-schema-invalid" ? "Canonical document v2 contains an unknown schema node or mark." : r.code === "missing-block-id" || r.code === "invalid-block-id" || r.code === "duplicate-block-id" ? `Canonical document v2 contains ${r.code}.` : "Canonical document v2 verification failed.",
      blockId: r.blockId
    }))
  ), yd(
    e.body.content,
    t
  );
}, xd = (e) => {
  const t = Jn, n = new Set(
    t.flatMap(
      (p) => Object.entries(p.ai.nodes).filter(
        ([, d]) => d.supported && d.addressability === "block"
      ).map(([d]) => d)
    )
  ), r = bd(e, n), i = rd(
    t,
    I(Gl(t))
  ), o = id(i), s = pd(
    {},
    e.body.content,
    r,
    o
  ), a = hd(
    e.body.content,
    r,
    o,
    s
  ), c = {
    manifest: i,
    nodes: a.nodes,
    operableBlockIds: s.operableBlockIds
  }, l = ms(c);
  if (!l.valid) throw new TypeError("plan-invalid");
  return new Map(
    [...l.targets].map(([p, d]) => [
      p,
      {
        blockId: p,
        type: d.type,
        contentFingerprint: I(d.node)
      }
    ])
  );
}, pe = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, he = (e, t, n = []) => {
  const r = Object.keys(e);
  return t.every((i) => Object.hasOwn(e, i)) && r.every((i) => t.includes(i) || n.includes(i));
}, re = (e) => typeof e == "string" && e.length > 0 && e.length <= 160 && /^[A-Za-z0-9][A-Za-z0-9._:/-]*$/.test(e), ie = (e) => typeof e == "string" && /^sha256:[a-f0-9]{64}$/.test(e), ee = (e, t) => I({ domain: `zx-ai-complex-node:${e}:v1`, value: t }), gs = (e) => so(e), Cr = (e) => F(e), Nr = (e, t, n = t.maxPayloadBytes) => {
  rn(e, {
    maxBytes: n,
    maxDepth: t.maxDepth,
    maxArrayEntries: t.maxArrayLength,
    maxObjectKeys: t.maxKeys,
    maxTotalObjectKeys: t.maxKeys
  }), We(e, {
    maxBytes: n,
    maxDepth: t.maxDepth,
    maxArrayEntries: t.maxArrayLength,
    maxObjectKeys: t.maxKeys,
    maxTotalObjectKeys: t.maxKeys
  });
  let r = 0, i = 0, o = 0, s = 0, a = 0, c = 0, l = 0, p = 0, d = 0, f = 0, u = 0;
  const m = /* @__PURE__ */ new Set(), h = (x, k) => {
    if (u += 1, typeof x == "string") {
      r = Math.max(r, x.length), l += x.length, p += x.length === 0 ? 0 : x.split(`
`).length;
      return;
    }
    if (!x || typeof x != "object") return;
    if (Array.isArray(x)) {
      x.forEach((E) => h(E, k));
      return;
    }
    const w = x, S = w.type, b = S === "bulletList" || S === "orderedList" || S === "taskList" ? k + 1 : k;
    if (S === "tableCell" || S === "tableHeader") {
      i += 1;
      const E = pe(w.attrs) ? w.attrs : {};
      o = Math.max(o, Number(E.rowspan ?? 1)), s = Math.max(s, Number(E.colspan ?? 1));
    }
    if ((S === "listItem" || S === "taskItem") && (a += 1, c = Math.max(c, b)), typeof w.assetId == "string" && m.add(w.assetId), pe(w.attrs)) {
      const E = w.attrs;
      typeof E.assetId == "string" && m.add(E.assetId), f += new TextEncoder().encode(
        F(E)
      ).byteLength;
    }
    Object.entries(w).forEach(([E, V]) => {
      r = Math.max(r, E.length), h(V, b);
    });
  };
  if (h(e, 0), d = m.size, r > t.maxStringLength)
    throw new RangeError("complex-string-limit-exceeded");
  const y = t.nodeBudget;
  if (y.kind === "table" && (i > y.maxCells || o > y.maxRowSpan || s > y.maxColSpan) || y.kind === "list" && (a > y.maxItems || c > y.maxDepth) || y.kind === "code" && (l > y.maxChars || p > y.maxLines) || y.kind === "media" && (d > y.maxResources || f > y.maxAttrBytes) || y.kind === "custom" && u > y.maxComplexity)
    throw new RangeError("complex-node-budget-exceeded");
}, kd = {
  "complex-registry-invalid": "install-adapter",
  "complex-adapter-not-found": "install-adapter",
  "complex-adapter-fingerprint-mismatch": "install-adapter",
  "complex-operation-unsupported": "reject",
  "complex-payload-invalid": "reject",
  "complex-limit-exceeded": "reject",
  "complex-address-invalid": "regenerate",
  "complex-anchor-lost": "regenerate",
  "complex-target-ambiguous": "resolve-conflict",
  "complex-target-drifted": "regenerate",
  "complex-capability-drifted": "regenerate",
  "complex-schema-invalid": "reject",
  "complex-plan-nondeterministic": "reject",
  "complex-diff-unavailable": "replan",
  "complex-resource-not-staged": "reauthorize",
  "complex-resource-policy-denied": "reject",
  "complex-resource-receipt-invalid": "reauthorize",
  "complex-resource-host-failed": "reauthorize",
  "complex-custom-admission-denied": "install-adapter",
  "complex-collaboration-conflict": "resolve-conflict",
  "complex-runner-timeout": "replan",
  "complex-runner-cancelled": "replan",
  "complex-runner-malformed": "reject",
  "complex-unsupported-host": "reject"
}, _ = (e, t, n, r = {}) => g({
  code: e,
  stage: t,
  path: n.slice(0, 240),
  recovery: kd[e],
  ...r.count === void 0 ? {} : { count: r.count },
  ...r.fingerprintPrefix === void 0 ? {} : { fingerprintPrefix: r.fingerprintPrefix.slice(0, 20) }
}), qe = (e, t, n) => g({
  valid: !1,
  value: null,
  diagnostics: [_(e, t, n)]
}), ys = /* @__PURE__ */ new Set([
  "row",
  "cell",
  "list-item",
  "code-text",
  "media",
  "custom"
]), Id = (e) => !pe(e) || !he(e, [
  "blockId",
  "localType",
  "localId",
  "semanticOffset",
  "affinity",
  "anchor"
]) || !re(e.blockId) || !ys.has(String(e.localType)) || !re(e.localId) || !Number.isSafeInteger(e.semanticOffset) || e.semanticOffset < 0 || e.affinity !== "forward" && e.affinity !== "backward" || !pe(e.anchor) || !he(e.anchor, [
  "kind",
  "blockId",
  "semanticOffset",
  "affinity",
  "relativePosition",
  "capabilityFingerprint",
  "fingerprint"
]) || e.anchor.kind !== "selection-endpoint" && e.anchor.kind !== "block-boundary" || !re(e.anchor.blockId) || !Number.isSafeInteger(e.anchor.semanticOffset) || e.anchor.semanticOffset < 0 || e.anchor.affinity !== "left" && e.anchor.affinity !== "right" || !pe(e.anchor.relativePosition) || !he(e.anchor.relativePosition, [
  "encoding",
  "value",
  "byteLength",
  "fingerprint"
]) || e.anchor.relativePosition.encoding !== "base64url" || typeof e.anchor.relativePosition.value != "string" || !Number.isSafeInteger(e.anchor.relativePosition.byteLength) || !ie(e.anchor.relativePosition.fingerprint) || !ie(e.anchor.capabilityFingerprint) || !ie(e.anchor.fingerprint) ? null : e, vd = (e) => {
  if (!pe(e) || !he(e, [
    "localId",
    "nodeTypeFingerprint",
    "contentFingerprint",
    "depth",
    "parentIds",
    "previousSiblingId",
    "nextSiblingId",
    "fingerprint"
  ]) || !re(e.localId) || !ie(e.nodeTypeFingerprint) || !ie(e.contentFingerprint) || !Number.isSafeInteger(e.depth) || e.depth < 0 || !Array.isArray(e.parentIds) || !e.parentIds.every(re) || e.previousSiblingId !== null && !re(e.previousSiblingId) || e.nextSiblingId !== null && !re(e.nextSiblingId))
    return null;
  const { fingerprint: t, ...n } = e;
  return ie(t) && t === ee("local-structure", n) ? e : null;
}, wd = (e, t) => {
  let n = null;
  const r = (o, s, a) => {
    if (n) return;
    const c = o.content ?? [];
    c.forEach((l, p) => {
      if (n) return;
      const d = typeof l.attrs?.blockId == "string" ? l.attrs.blockId : null;
      if (l.type === "listItem" && d === t) {
        const m = c.map(
          (h) => h.type === "listItem" && typeof h.attrs?.blockId == "string" ? h.attrs.blockId : null
        );
        n = {
          localId: t,
          nodeTypeFingerprint: ee(
            "node-type",
            l.type
          ),
          contentFingerprint: ee("node-content", l),
          depth: a,
          parentIds: s,
          previousSiblingId: m[p - 1] ?? null,
          nextSiblingId: m[p + 1] ?? null
        };
        return;
      }
      const f = d ? [...s, d] : s, u = l.type === "bulletList" || l.type === "orderedList" ? a + 1 : a;
      r(l, f, u);
    });
  };
  if (r(e, [], 0), !n) return null;
  const i = n;
  return g({
    ...i,
    fingerprint: ee("local-structure", i)
  });
}, ti = (e) => {
  if (!pe(e) || typeof e.kind != "string")
    return qe("complex-address-invalid", "address", "$.target");
  if (e.kind === "stable-local") {
    if (!he(
      e,
      ["kind", "blockId", "localType", "localId"],
      ["relativeText", "structure"]
    ) || !re(e.blockId) || !ys.has(String(e.localType)) || !re(e.localId))
      return qe(
        "complex-address-invalid",
        "address",
        "$.target"
      );
    const t = Object.hasOwn(e, "relativeText") ? Id(e.relativeText) : void 0, n = Object.hasOwn(e, "structure") ? vd(e.structure) : void 0;
    return Object.hasOwn(e, "relativeText") && !t ? qe(
      "complex-address-invalid",
      "address",
      "$.target.relativeText"
    ) : Object.hasOwn(e, "structure") && !n ? qe(
      "complex-address-invalid",
      "address",
      "$.target.structure"
    ) : g({
      valid: !0,
      value: {
        kind: "stable-local",
        blockId: e.blockId,
        localType: e.localType,
        localId: e.localId,
        ...t ? { relativeText: t } : {},
        ...n ? { structure: n } : {}
      },
      diagnostics: []
    });
  }
  return e.kind !== "validated-path" || !he(e, [
    "kind",
    "blockId",
    "path",
    "ancestorFingerprint",
    "nodeTypeFingerprint",
    "contentFingerprint",
    "shapeFingerprint",
    "sourceSnapshotFingerprint"
  ]) || !re(e.blockId) || !Array.isArray(e.path) || e.path.length === 0 || e.path.length > 64 || !e.path.every(
    (t) => Number.isSafeInteger(t) && t >= 0
  ) || ![
    e.ancestorFingerprint,
    e.nodeTypeFingerprint,
    e.contentFingerprint,
    e.shapeFingerprint,
    e.sourceSnapshotFingerprint
  ].every(ie) ? qe("complex-address-invalid", "address", "$.target") : g({
    valid: !0,
    value: e,
    diagnostics: []
  });
}, Sd = (e) => {
  const t = ti(e);
  if (!t.valid) throw new TypeError("complex-address-invalid");
  return gs(t.value);
}, bs = (e) => ee(
  "address",
  new TextDecoder().decode(Sd(e))
), Od = (e) => {
  if (e.address.kind !== "stable-local" || !e.address.relativeText)
    return g({
      status: "failure",
      diagnostic: _(
        "complex-address-invalid",
        "address",
        "$.target.relativeText"
      )
    });
  const t = e.address.relativeText, n = e.resolveAnchor();
  return !n || t.blockId !== e.expectedBlockId || t.localId !== e.expectedLocalId || n.blockId !== t.blockId || n.localId !== t.localId || n.semanticOffset !== t.semanticOffset ? g({
    status: "failure",
    diagnostic: _(
      "complex-anchor-lost",
      "collaboration",
      "$.target.relativeText"
    )
  }) : t.anchor.capabilityFingerprint !== e.currentCapabilityFingerprint ? g({
    status: "failure",
    diagnostic: _(
      "complex-capability-drifted",
      "collaboration",
      "$.target.relativeText.anchor.capabilityFingerprint"
    )
  }) : g({
    status: "surviving",
    semanticOffset: n.semanticOffset,
    fingerprint: ee("resolved-text-address", {
      address: e.address,
      resolved: n
    })
  });
}, xs = (e) => !pe(e) || !he(e, [
  "descriptor",
  "descriptorFingerprint",
  "nodeType",
  "adapterId",
  "adapterVersion",
  "adapterFingerprint"
]) || !re(e.descriptor) || !ie(e.descriptorFingerprint) || !re(e.nodeType) || !re(e.adapterId) || !re(e.adapterVersion) || !ie(e.adapterFingerprint) ? qe(
  "complex-adapter-fingerprint-mismatch",
  "decode",
  "$.adapter"
) : g({
  valid: !0,
  value: e,
  diagnostics: []
}), ks = (e) => !pe(e) || !he(e, [
  "addressFingerprint",
  "blockId",
  "nodeType",
  "contentFingerprint",
  "shapeFingerprint",
  "capabilityFingerprint"
]) || !ie(e.addressFingerprint) || !re(e.blockId) || !re(e.nodeType) || !ie(e.contentFingerprint) || !ie(e.shapeFingerprint) || !ie(e.capabilityFingerprint) ? qe(
  "complex-payload-invalid",
  "precondition",
  "$.preconditions"
) : g({
  valid: !0,
  value: e,
  diagnostics: []
}), Ad = (e, t) => {
  try {
    Nr(e, t);
  } catch {
    return qe(
      "complex-limit-exceeded",
      "decode",
      "$.operation"
    );
  }
  if (!pe(e) || !he(e, [
    "kind",
    "adapter",
    "target",
    "preconditions",
    "operation",
    "payload"
  ]) || e.kind !== "node.apply" || !re(e.operation))
    return qe(
      "complex-payload-invalid",
      "decode",
      "$.operation"
    );
  const n = xs(e.adapter), r = ti(e.target), i = ks(e.preconditions);
  return !n.valid || !r.valid || !i.valid ? g({
    valid: !1,
    value: null,
    diagnostics: [
      ...n.diagnostics,
      ...r.diagnostics,
      ...i.diagnostics
    ]
  }) : g({
    valid: !0,
    value: {
      kind: "node.apply",
      adapter: n.value,
      target: r.value,
      preconditions: i.value,
      operation: e.operation,
      payload: e.payload
    },
    diagnostics: []
  });
}, Is = /* @__PURE__ */ new WeakMap(), Rd = (e, t) => {
  Is.set(e, { registry: t });
}, Ed = (e) => Is.get(e) ?? null, vs = 2, Bi = /* @__PURE__ */ new Set([
  "read-only",
  "external-resource",
  "sensitive"
]), Ne = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, Cn = (e, t) => Object.keys(e).every((n) => t.includes(n)), _i = (e) => {
  try {
    F(e);
  } catch {
    return !1;
  }
  const t = (r) => r === void 0 || Array.isArray(r) && r.every(
    (i) => Ne(i) && Cn(i, ["type", "attrs"]) && typeof i.type == "string" && i.type.trim().length > 0 && (i.attrs === void 0 || Ne(i.attrs))
  ), n = (r) => !Ne(r) || !Cn(r, ["type", "attrs", "content", "marks", "text"]) || typeof r.type != "string" || r.type.trim().length === 0 || r.attrs !== void 0 && !Ne(r.attrs) || r.text !== void 0 && typeof r.text != "string" || !t(r.marks) ? !1 : r.content === void 0 || Array.isArray(r.content) && r.content.every((i) => n(i));
  return n(e);
}, Vi = (e) => {
  const t = {
    operationIndex: e.operationIndex,
    kind: e.kind
  }, n = [], r = new Map(
    e.manifest.nodes.map((u) => [u.type, u])
  ), i = new Map(
    e.manifest.marks.map((u) => [u.type, u])
  ), o = () => n.push(
    N("operation-payload-invalid", t)
  ), s = (u, m, h) => {
    if (u === void 0)
      return h ? null : {};
    if (!Ne(u))
      return o(), null;
    const y = new Set(m);
    return h && y.add("blockId"), Object.keys(u).some((x) => !y.has(x)) ? (o(), null) : u;
  }, a = (u) => {
    if (u === void 0) return !0;
    if (!Array.isArray(u))
      return o(), !1;
    let m = !0;
    return u.forEach((h) => {
      if (!Ne(h) || !Cn(h, ["type", "attrs"]) || typeof h.type != "string") {
        o(), m = !1;
        return;
      }
      const y = i.get(h.type);
      if (!y || Bi.has(y.risk) || y.stream === "none") {
        n.push(
          N("operation-capability-denied", {
            ...t,
            nodeType: h.type
          })
        ), m = !1;
        return;
      }
      s(h.attrs, y.readableAttrs, !1) || (m = !1);
    }), m;
  }, c = (u, m) => {
    if (!Ne(u) || !Cn(u, ["type", "attrs", "content", "marks", "text"]) || typeof u.type != "string" || u.type.trim().length === 0)
      return o(), !1;
    const h = r.get(u.type);
    if (!h)
      return n.push(
        N("operation-capability-denied", {
          ...t,
          nodeType: u.type
        })
      ), !1;
    if (m && h.addressability !== "block" || !m && h.addressability === "block" || h.content === "block" || h.content === "mixed" || Bi.has(h.risk) || h.stream === "none")
      return n.push(
        N("operation-capability-denied", {
          ...t,
          nodeType: u.type
        })
      ), !1;
    let y = !0;
    return s(u.attrs, h.readableAttrs, m) || (y = !1), u.type === "text" ? ((typeof u.text != "string" || u.content !== void 0 || u.attrs !== void 0) && (o(), y = !1), a(u.marks) || (y = !1), y) : ((u.text !== void 0 || u.marks !== void 0) && (o(), y = !1), h.content === "none" && u.content !== void 0 ? (o(), y = !1) : u.content !== void 0 && (Array.isArray(u.content) ? u.content.forEach((k) => {
      if (h.content === "text" && (!Ne(k) || k.type !== "text")) {
        o(), y = !1;
        return;
      }
      c(k, !1) || (y = !1);
    }) : (o(), y = !1)), y);
  }, l = c(e.payload, !0), p = Ne(e.payload) ? e.payload : null, f = (p && Ne(p.attrs) ? p.attrs : null)?.blockId;
  if (An(f) ? e.expectedBlockId !== void 0 && f !== e.expectedBlockId ? n.push(
    N("operation-block-id-conflict", {
      ...t,
      blockId: f
    })
  ) : e.expectedBlockId === void 0 && e.observedBlockIds.has(f) && n.push(
    N("operation-block-id-conflict", {
      ...t,
      blockId: f
    })
  ) : n.push(
    N("operation-block-id-invalid", t)
  ), !l || n.length > 0 || !An(f))
    return { valid: !1, block: null, blockId: null, diagnostics: n };
  try {
    return { valid: !0, block: JSON.parse(
      F(e.payload)
    ), blockId: f, diagnostics: [] };
  } catch {
    return {
      valid: !1,
      block: null,
      blockId: null,
      diagnostics: [
        N("operation-payload-invalid", t)
      ]
    };
  }
}, Td = /* @__PURE__ */ new Set([
  "text.replace",
  "block.insert",
  "block.replace",
  "block.delete",
  "node.apply"
]), Fd = {
  maxPayloadBytes: 12e5,
  maxDepth: 64,
  maxKeys: 16e3,
  maxArrayLength: 8192,
  maxStringLength: 5e5,
  maxDiagnostics: 8,
  maxOutputBytes: 12e5,
  timeoutMs: 2e3,
  nodeBudget: { kind: "custom", maxComplexity: 1e5 }
}, Li = /* @__PURE__ */ new Set([
  "read-only",
  "external-resource",
  "sensitive"
]), Me = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, Se = (e, t, n = []) => {
  const r = Object.keys(e);
  return t.every(
    (i) => Object.prototype.hasOwnProperty.call(e, i)
  ) && r.every((i) => t.includes(i) || n.includes(i));
}, ke = (e) => typeof e == "string" && e.trim().length > 0, hn = (e) => !Me(e) || !Se(e, ["blockId", "type", "contentFingerprint"]) || !ke(e.blockId) || !ke(e.type) || !ke(e.contentFingerprint) ? null : {
  blockId: e.blockId,
  type: e.type,
  contentFingerprint: e.contentFingerprint
}, Cd = (e, t, n) => {
  if (!Me(e) || typeof e.kind != "string")
    return n.push(
      N("operation-kind-unsupported", {
        operationIndex: t
      })
    ), null;
  if (!Td.has(e.kind))
    return n.push(
      N("operation-kind-unsupported", {
        operationIndex: t
      })
    ), null;
  const r = e.kind, i = { operationIndex: t, kind: r }, o = () => (n.push(
    N("operation-shape-invalid", i)
  ), null);
  if (r === "node.apply") {
    const a = Ad(
      e,
      Fd
    );
    return a.valid ? a.value : o();
  }
  if (r === "text.replace") {
    if (!Se(e, ["kind", "target", "precondition", "text"]) || !Me(e.target) || !Se(e.target, ["blockId", "startOffset", "endOffset"]) || !ke(e.target.blockId) || typeof e.text != "string")
      return o();
    const a = hn(e.precondition);
    return a ? !Number.isInteger(e.target.startOffset) || !Number.isInteger(e.target.endOffset) || e.target.startOffset < 0 || e.target.endOffset < e.target.startOffset ? (n.push(
      N("operation-address-invalid", {
        ...i,
        blockId: e.target.blockId
      })
    ), null) : {
      kind: r,
      target: {
        blockId: e.target.blockId,
        startOffset: e.target.startOffset,
        endOffset: e.target.endOffset
      },
      precondition: a,
      text: e.text
    } : o();
  }
  if (r === "block.insert") {
    if (!Se(e, ["kind", "reference", "precondition", "block"]) || !Me(e.reference) || !Se(e.reference, ["blockId", "side"]) || !ke(e.reference.blockId) || e.reference.side !== "before" && e.reference.side !== "after" || !_i(e.block))
      return o();
    const a = hn(e.precondition);
    return a ? {
      kind: r,
      reference: {
        blockId: e.reference.blockId,
        side: e.reference.side
      },
      precondition: a,
      block: e.block
    } : o();
  }
  if (r === "block.replace") {
    if (!Se(e, ["kind", "target", "precondition", "block"]) || !Me(e.target) || !Se(e.target, ["blockId"]) || !ke(e.target.blockId) || !_i(e.block))
      return o();
    const a = hn(e.precondition);
    return a ? {
      kind: r,
      target: { blockId: e.target.blockId },
      precondition: a,
      block: e.block
    } : o();
  }
  if (!Se(e, ["kind", "target", "precondition"]) || !Me(e.target) || !Se(e.target, ["blockId"]) || !ke(e.target.blockId))
    return o();
  const s = hn(e.precondition);
  return s ? {
    kind: "block.delete",
    target: { blockId: e.target.blockId },
    precondition: s
  } : o();
}, ws = (e, t) => {
  try {
    zc(e, "operation-protocol-v2");
  } catch {
    return t.push(N("protocol-envelope-invalid")), null;
  }
  if (!Me(e) || !Se(e, ["protocolVersion", "source", "operations"]) || (e.protocolVersion !== vs && t.push(
    N("protocol-version-unsupported")
  ), !Me(e.source) || !Se(e.source, [
    "snapshotFingerprint",
    "documentRevision",
    "descriptorFingerprint",
    "registryFingerprint"
  ]) || !ke(e.source.snapshotFingerprint) || !ke(e.source.documentRevision) || !ke(e.source.descriptorFingerprint) || !ke(e.source.registryFingerprint) || !Array.isArray(e.operations) || e.operations.length === 0))
    return t.push(N("protocol-envelope-invalid")), null;
  const n = e.operations.map(
    (r, i) => Cd(r, i, t)
  );
  return t.length > 0 || n.some((r) => !r) ? null : {
    source: {
      snapshotFingerprint: e.source.snapshotFingerprint,
      documentRevision: e.source.documentRevision,
      descriptorFingerprint: e.source.descriptorFingerprint,
      registryFingerprint: e.source.registryFingerprint
    },
    operations: n
  };
}, Nd = (e) => {
  const t = [];
  return ws(e, t) !== null && t.length === 0;
}, St = (e) => g({
  valid: !1,
  diagnostics: Tt(e),
  plan: null
}), hr = (e) => e.kind === "block.insert" ? e.reference.blockId : e.target.blockId, qi = (e, t, n, r) => {
  const i = n.nodes.find((o) => o.type === e.type);
  if (!i || i.addressability !== "block") return !1;
  if (t.kind === "text.replace")
    return (i.content === "text" || i.content === "inline") && i.risk === "textual" && i.stream !== "none";
  if (t.kind === "node.apply") {
    const o = r?.registry.entries.find(
      (s) => s.adapter.adapterFingerprint === t.adapter.adapterFingerprint && s.adapter.adapterId === t.adapter.adapterId && s.adapter.nodeType === t.adapter.nodeType && s.adapter.descriptor === t.adapter.descriptor
    );
    return !!(o && e.type === t.adapter.nodeType && i.descriptor === t.adapter.descriptor && (!Li.has(i.risk) || i.risk === "external-resource" && o.family === "media") && o.operations.some(
      (s) => s.name === t.operation
    ));
  }
  return t.kind === "block.delete" || t.kind === "block.replace" ? !Li.has(i.risk) : !0;
}, Md = async (e) => {
  try {
    const t = [], n = ws(e.envelope, t);
    if (!n || (n.source.snapshotFingerprint !== e.snapshot.fingerprint && t.push(
      N("snapshot-precondition-failed")
    ), n.source.documentRevision !== e.snapshot.documentRevision && t.push(
      N("revision-precondition-failed")
    ), n.source.descriptorFingerprint !== e.snapshot.descriptorFingerprint && t.push(
      N("descriptor-precondition-failed")
    ), t.length > 0)) return St(t);
    if (n.operations.some(
      (p) => p.kind === "node.apply"
    ) && (!e.complex || n.source.registryFingerprint !== e.complex.registry.fingerprint))
      return t.push(
        N("complex-node-validation-failed", {
          complexCode: "complex-capability-drifted",
          recovery: "regenerate"
        })
      ), St(t);
    const i = await ld(e.snapshot);
    if (!i.valid) return St(i.diagnostics);
    const o = [], s = /* @__PURE__ */ new Map();
    for (const [p, d] of n.operations.entries())
      d.kind !== "block.insert" || !Me(d.block) || !Me(d.block.attrs) || !ke(d.block.attrs.blockId) || s.set(p, d.block.attrs.blockId);
    for (const [p, d] of n.operations.entries()) {
      const f = hr(d), u = { operationIndex: p, kind: d.kind, blockId: f }, m = t.length, h = i.targets.get(f);
      if (!h) {
        t.push(
          N(
            i.observedBlockIds.has(f) ? "operation-target-not-operable" : "operation-target-not-found",
            u
          )
        );
        continue;
      }
      if (d.kind === "node.apply") {
        const y = e.complex;
        if (!y) {
          t.push(
            N("complex-node-validation-failed", {
              ...u,
              complexCode: "complex-unsupported-host",
              recovery: "install-adapter"
            })
          );
          continue;
        }
        if (!qi(
          h,
          d,
          e.snapshot.manifest,
          y
        )) {
          t.push(
            N("operation-capability-denied", {
              ...u,
              nodeType: h.type
            })
          );
          continue;
        }
        const x = await Kp(
          y.registry
        ).validateAndPlan(
          {
            document: y.document,
            sourceSnapshotFingerprint: n.source.snapshotFingerprint,
            sourceDocumentRevision: n.source.documentRevision,
            sourceDescriptorFingerprint: n.source.descriptorFingerprint,
            sourceRegistryFingerprint: n.source.registryFingerprint,
            operation: d,
            operationIndex: p,
            resourceProfileFingerprint: y.resourceProfileFingerprint,
            addressResolution: y.addressResolution,
            resourceAdmission: y.resourceAdmissions?.[p]
          },
          y.runner
        );
        x.valid ? t.length === m && o.push(x.step) : x.diagnostics.forEach(
          (k) => t.push(
            N("complex-node-validation-failed", {
              ...u,
              complexCode: k.code,
              recovery: k.recovery
            })
          )
        );
        continue;
      }
      if (d.precondition.blockId !== f && t.push(
        N(
          "operation-precondition-block-mismatch",
          u
        )
      ), d.precondition.type !== h.type && t.push(
        N("operation-type-precondition-failed", {
          ...u,
          nodeType: h.type
        })
      ), d.precondition.contentFingerprint !== h.contentFingerprint && t.push(
        N(
          "operation-content-precondition-failed",
          u
        )
      ), qi(
        h,
        d,
        e.snapshot.manifest,
        e.complex
      ) || t.push(
        N("operation-capability-denied", {
          ...u,
          nodeType: h.type
        })
      ), d.kind === "text.replace") {
        const y = dd(
          h,
          d.target.startOffset,
          d.target.endOffset
        );
        (!y || $i(y, d.target.startOffset) || $i(y, d.target.endOffset)) && t.push(
          N("operation-range-invalid", u)
        ), t.length === m && o.push({ operationIndex: p, ...d });
        continue;
      }
      if (d.kind === "block.insert") {
        e.snapshot.scope.kind !== "document" && t.push(
          N("operation-capability-denied", u)
        );
        const y = Vi({
          payload: d.block,
          manifest: e.snapshot.manifest,
          operationIndex: p,
          kind: d.kind,
          observedBlockIds: i.observedBlockIds
        });
        t.push(...y.diagnostics), t.length === m && y.valid && o.push({ operationIndex: p, ...d, block: y.block });
        continue;
      }
      if (d.kind === "block.replace") {
        const y = Vi({
          payload: d.block,
          manifest: e.snapshot.manifest,
          operationIndex: p,
          kind: d.kind,
          expectedBlockId: f,
          observedBlockIds: i.observedBlockIds
        });
        t.push(...y.diagnostics), t.length === m && y.valid && o.push({ operationIndex: p, ...d, block: y.block });
        continue;
      }
      t.length === m && o.push({ operationIndex: p, ...d });
    }
    const a = /* @__PURE__ */ new Set();
    n.operations.forEach((p, d) => {
      const f = hr(p);
      a.has(f) && t.push(
        N("operation-batch-conflict", {
          operationIndex: d,
          kind: p.kind,
          blockId: f
        })
      ), a.add(f);
    });
    const c = /* @__PURE__ */ new Set();
    if (s.forEach((p, d) => {
      const f = n.operations[d];
      c.has(p) && t.push(
        N("operation-batch-conflict", {
          operationIndex: d,
          kind: f.kind,
          blockId: p
        })
      ), c.add(p);
    }), n.operations.forEach((p, d) => {
      const f = hr(p);
      c.has(f) && t.push(
        N("operation-batch-conflict", {
          operationIndex: d,
          kind: p.kind,
          blockId: f
        })
      );
    }), t.length > 0 || o.length !== n.operations.length)
      return St(t);
    const l = g({
      protocolVersion: vs,
      offsetEncoding: "utf-16",
      source: n.source,
      steps: o
    });
    return o.some((p) => p.kind === "node.apply") && Rd(l, e.complex.registry), g({
      valid: !0,
      diagnostics: [],
      plan: l
    });
  } catch {
    return St([
      N("internal-validation-failed")
    ]);
  }
}, Pd = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, mr = /^[A-Za-z0-9_.:-]{1,160}$/, Ue = (e) => {
  const t = {
    code: e.code,
    stage: e.stage,
    path: Pd.test(e.path) ? e.path.slice(0, 240) : "$",
    ...Number.isSafeInteger(e.count) && e.count >= 0 ? { count: Math.min(e.count, 1e6) } : {},
    ...typeof e.fingerprint == "string" ? { fingerprintPrefix: Zt(e.fingerprint) } : {},
    ...e.operationRef && mr.test(e.operationRef) ? { operationRef: e.operationRef } : {},
    ...e.blockRef && mr.test(e.blockRef) ? { blockRef: e.blockRef } : {},
    ...e.hunkRef && mr.test(e.hunkRef) ? { hunkRef: e.hunkRef } : {}
  };
  return g(t);
}, Gt = g({
  maxBytes: 12e6,
  maxDepth: 160,
  maxArrayEntries: 12e4,
  maxObjectKeys: 96,
  maxTotalObjectKeys: 5e5
}), Un = g({
  maxInputBytes: 12e6,
  maxOutputBytes: 2e6,
  maxHunks: 5e3
}), Mr = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), C = (e, t, n = []) => Mr(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), z = (e) => typeof e == "string" && e.trim().length > 0, ne = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, W = (e, t) => I({ domain: e, value: t }), Dt = (e) => {
  const { fingerprint: t, ...n } = e;
  return n;
}, ni = (e) => {
  rn(e, Gt);
  const { canonical: t } = We(
    e,
    Gt
  );
  return g(JSON.parse(t));
}, L = (e, t) => {
  try {
    return F(e) === F(t);
  } catch {
    return !1;
  }
}, ri = (e, t = /* @__PURE__ */ new Set()) => !e || typeof e != "object" || t.has(e) ? !0 : Object.isFrozen(e) ? (t.add(e), Object.values(e).every((n) => ri(n, t))) : !1, Ss = (e) => new TextEncoder().encode(F(e)).byteLength, Os = (e) => [...new Set(e)].sort(), Pr = (e) => {
  const t = [], n = /* @__PURE__ */ new Map(), r = (i, o) => {
    if (!i || typeof i != "object" || Array.isArray(i)) return;
    const s = i, a = s.attrs, c = a && typeof a == "object" && !Array.isArray(a) && typeof a.blockId == "string" ? a.blockId : null, l = c ? [...o, c] : [...o];
    if (c) {
      const p = {
        id: c,
        node: s,
        fingerprint: I(s),
        ancestors: [...o],
        descendants: [],
        ordinal: t.length
      };
      t.push(p), n.set(c, p), o.forEach(
        (d) => n.get(d)?.descendants.push(c)
      );
    }
    Array.isArray(s.content) && s.content.forEach((p) => r(p, l));
  };
  return r(e.body.content, []), t;
}, As = (e, t = []) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return t;
  const n = e;
  return n.attrs && typeof n.attrs == "object" && !Array.isArray(n.attrs) && typeof n.attrs.blockId == "string" && t.push(n.attrs.blockId), Array.isArray(n.content) && n.content.forEach((r) => As(r, t)), t;
}, zd = (e) => {
  const t = "target" in e ? [e.target.blockId] : [], n = "reference" in e ? [e.reference.blockId] : [], r = "block" in e ? As(e.block) : [];
  return Os([...t, ...n, ...r]);
}, Ki = (e, t) => {
  const n = new Map(t.map((i) => [i.id, i])), r = new Set(e);
  return e.forEach((i) => {
    const o = n.get(i);
    o?.ancestors.forEach((s) => r.add(s)), o?.descendants.forEach((s) => r.add(s));
  }), [...r].sort();
}, jd = (e, t) => {
  const n = new Map(
    Pr(e).map((r) => [r.id, r.fingerprint])
  );
  return W(
    "zx-ai-proposal-targets:v1",
    t.map((r) => ({
      operationIndex: r.operationIndex,
      blocks: r.blockIds.map((i) => ({
        blockId: i,
        fingerprint: n.get(i) ?? null
      }))
    }))
  );
}, Dd = (e, t, n) => {
  const r = new Map(
    n.mapping.annotations.map((i) => [
      i.annotationId,
      i
    ])
  );
  return r.size !== t.annotations.length || r.size !== e.annotations.length || e.annotations.some((i) => !r.has(i.id)) ? !1 : t.annotations.every((i) => {
    const o = r.get(i.id);
    return !!(o && i.anchor.start.blockId === o.start.mapped.blockId && i.anchor.start.offset === o.start.mapped.offset && i.anchor.end.blockId === o.end.mapped.blockId && i.anchor.end.offset === o.end.mapped.offset && (i.anchor.quote ?? "") === o.quote && (i.anchor.beforeQuote ?? "") === o.beforeQuote && (i.anchor.afterQuote ?? "") === o.afterQuote);
  });
}, lt = (e, t) => ({
  valid: !1,
  diagnostic: Ue({
    code: t,
    stage: "effect-proof",
    path: e
  })
}), $d = (e) => {
  const t = Pr(e.base), n = Pr(e.runtime.resultDocument), r = new Map(t.map((b) => [b.id, b])), i = new Map(n.map((b) => [b.id, b])), o = e.plan.steps.map((b) => {
    const E = zd(b);
    return {
      operationIndex: b.operationIndex,
      baseBlockIds: Ki(
        E.filter((V) => r.has(V)),
        t
      ),
      resultBlockIds: Ki(
        E.filter((V) => i.has(V)),
        n
      )
    };
  }), s = new Set(
    o.flatMap((b) => b.baseBlockIds)
  ), a = new Set(
    o.flatMap((b) => b.resultBlockIds)
  ), c = new Map(
    o.map((b) => [b.operationIndex, b])
  ), l = e.runtime.trace.entries.map((b) => {
    const E = Os(
      b.sourceAttribution.operationIndexes.flatMap((V) => {
        const xe = c.get(V);
        return xe ? [...xe.baseBlockIds, ...xe.resultBlockIds] : [];
      })
    );
    return {
      sequence: b.sequence,
      kind: b.kind,
      owner: b.sourceAttribution.owner,
      pluginInstanceId: b.sourceAttribution.pluginInstanceId,
      operationIndexes: b.sourceAttribution.operationIndexes,
      visibleTransactionRange: b.sourceAttribution.visibleTransactionRange,
      documentChanged: b.beforeDocumentFingerprint !== b.afterDocumentFingerprint,
      attributedBlockIds: E,
      safeEffectFingerprints: b.safeEffects.map(
        (V) => V.fingerprint
      )
    };
  });
  if (l.some(
    (b) => b.kind === "appended" && b.documentChanged && b.attributedBlockIds.length === 0
  ))
    return lt(
      "$.runtimeOutcome.trace.entries",
      "proposal-effect-proof-invalid"
    );
  const p = t.filter((b) => !i.has(b.id)), d = n.filter((b) => !r.has(b.id));
  if (p.some((b) => !s.has(b.id)) || d.some((b) => !a.has(b.id)))
    return lt(
      "$.runtimeOutcome.resultDocument.body",
      "proposal-document-drift"
    );
  const f = t.filter(
    (b) => !s.has(b.id) && i.has(b.id)
  );
  if (f.some(
    (b) => i.get(b.id)?.fingerprint !== b.fingerprint
  ))
    return lt("$.effectProof.untouched", "proposal-document-drift");
  const u = f.map((b) => b.id), m = new Set(u), h = n.filter((b) => m.has(b.id)).map((b) => b.id);
  if (!L(u, h))
    return lt("$.effectProof.relativeOrder", "proposal-document-drift");
  if (!L(e.base.assets, e.runtime.resultDocument.assets) || !L(e.base.meta, e.runtime.resultDocument.meta))
    return lt("$.runtimeOutcome.resultDocument", "proposal-document-drift");
  if (!Dd(
    e.base,
    e.runtime.resultDocument,
    e.runtime
  ))
    return lt(
      "$.runtimeOutcome.mapping.annotations",
      "proposal-effect-proof-invalid"
    );
  const y = f.map((b) => ({
    blockId: b.id,
    fingerprint: b.fingerprint
  })), x = new Map(
    e.runtime.resultDocument.annotations.map((b) => [
      b.id,
      b
    ])
  ), k = e.base.annotations.filter((b) => {
    const E = x.get(b.id);
    return !!(E && !s.has(b.anchor.start.blockId) && !s.has(b.anchor.end.blockId) && !a.has(E.anchor.start.blockId) && !a.has(E.anchor.end.blockId));
  });
  if (k.some(
    (b) => !L(b, x.get(b.id))
  ))
    return lt(
      "$.runtimeOutcome.resultDocument.annotations",
      "proposal-document-drift"
    );
  const w = k.map(
    (b) => ({
      annotationId: b.id,
      fingerprint: I(b)
    })
  ), S = {
    kind: "zx-ai-proposal-effect-proof-v1",
    version: "1.0.0",
    operationScopes: o,
    traceAttribution: l,
    untouchedBlockFingerprints: y,
    untouchedAnnotationFingerprints: w,
    untouchedProjectionFingerprint: W(
      "zx-ai-proposal-untouched-projection:v1",
      y
    ),
    relativeOrderFingerprint: W(
      "zx-ai-proposal-relative-order:v1",
      h
    ),
    annotationProjectionFingerprint: W(
      "zx-ai-proposal-annotation-projection:v1",
      e.runtime.mapping.annotations
    ),
    assetsMetaUnchanged: !0
  };
  return {
    valid: !0,
    proof: {
      ...S,
      fingerprint: W(
        "zx-ai-proposal-effect-proof:v1",
        S
      )
    }
  };
}, zr = /* @__PURE__ */ new Map(), Hn = (e) => W("zx-ai-proposal-lifecycle:v1", {
  proposalId: e.proposalId,
  revision: e.revision,
  status: e.status
}), Rs = (e) => !C(e, ["proposalId", "revision", "status", "fingerprint"]) || !z(e.proposalId) || !ne(e.revision) || !["active", "committed", "discarded"].includes(String(e.status)) || typeof e.fingerprint != "string" ? !1 : e.fingerprint === Hn({
  proposalId: e.proposalId,
  revision: e.revision,
  status: e.status
}), Bd = (e) => {
  if (!C(e, ["proposalId", "revision"]) || !z(e.proposalId) || !ne(e.revision))
    throw new TypeError("proposal-lifecycle-input-invalid");
  const t = {
    proposalId: e.proposalId,
    revision: e.revision,
    status: "active"
  }, n = g({
    ...t,
    fingerprint: Hn(t)
  });
  return zr.has(n.proposalId) || zr.set(n.proposalId, n), n;
}, _d = (e) => Rs(e) && zr.get(e.proposalId)?.fingerprint === e.fingerprint, Vt = {
  kind: "derived-view-profile",
  id: "zx.ai.proposal-rich-diff",
  version: "1.0.0",
  dependencies: [],
  algorithm: "operation-bound-structural-diff-v1",
  limits: Un
}, Mt = g({
  kind: Vt.kind,
  id: Vt.id,
  version: Vt.version,
  dependencies: Vt.dependencies,
  fingerprint: W(
    "zx-ai-proposal-rich-diff-profile:v1",
    Vt
  )
});
g({
  owner: "S4-versioned-review-policy",
  hunkPartialAccept: !1,
  operationPartialAccept: !1,
  hunkPartialReject: !1,
  operationPartialReject: !1,
  wholeProposalAcceptWithoutIndependentWholeReview: !1,
  allowedWithoutIndependentWholeReview: ["reject", "regenerate"]
});
const Lt = (e, t, n) => g({
  status: "unavailable",
  profileRef: Mt,
  sourceBinding: e,
  reason: t,
  safeDiagnostic: {
    code: n,
    stage: "proposal-rich-diff",
    path: "$.proposal.richDiff",
    componentId: Mt.id
  }
}), Ji = (e, t) => {
  let n = null;
  const r = (i) => {
    if (n || !i || typeof i != "object" || Array.isArray(i))
      return;
    const o = i;
    if (o.attrs && typeof o.attrs == "object" && !Array.isArray(o.attrs) && o.attrs.blockId === t) {
      n = o;
      return;
    }
    Array.isArray(o.content) && o.content.forEach(r);
  };
  return r(e), n;
}, jr = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return "";
  const t = e;
  return (typeof t.text == "string" ? t.text : "") + (Array.isArray(t.content) ? t.content.map(jr).join("") : "");
}, Ui = (e) => {
  const t = [], n = (r) => {
    if (!r || typeof r != "object" || Array.isArray(r)) return;
    const i = r;
    Array.isArray(i.marks) && t.push(i.marks), Array.isArray(i.content) && i.content.forEach(n);
  };
  return n(e), t;
}, Hi = (e) => !!(e && typeof e.type == "string" && [
  "table",
  "tableRow",
  "tableCell",
  "codeBlock",
  "image",
  "video"
].includes(e.type)), Vd = (e) => {
  switch (e) {
    case "text":
      return "Text content changed";
    case "mark":
      return "Inline formatting changed";
    case "node-type":
      return "Block type changed";
    case "node-attrs":
      return "Allowed block attributes changed";
    case "block-insert":
      return "Block inserted";
    case "block-delete":
      return "Block deleted";
    case "block-replace":
      return "Block replaced";
    case "complex-summary":
      return "Complex block changed";
  }
}, Ld = (e, t, n) => {
  if (e === "text.replace") return ["text"];
  if (e === "block.insert") return ["block-insert"];
  if (e === "block.delete") return ["block-delete"];
  if (Hi(t) || Hi(n))
    return ["complex-summary"];
  const r = [];
  return t?.type !== n?.type && r.push("node-type"), L(t?.attrs ?? null, n?.attrs ?? null) || r.push("node-attrs"), L(Ui(t), Ui(n)) || r.push("mark"), jr(t) !== jr(n) && r.push("text"), r.length > 0 ? r : ["block-replace"];
}, qd = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return null;
  const t = e.attrs;
  return t && typeof t == "object" && !Array.isArray(t) ? t.blockId ?? null : null;
}, Kd = (e) => ("target" in e ? e.target.blockId : null) ?? ("block" in e ? qd(e.block) : null) ?? ("reference" in e ? e.reference.blockId : null) ?? `operation-${e.operationIndex}`, Jd = (e) => Number.isSafeInteger(e) && e >= 0 && e <= Un.maxHunks, Ud = (e) => Ss(e) <= Un.maxOutputBytes, Hd = (e) => {
  const t = g({
    executionSemanticsFingerprint: e?.runtimeExecution?.runtime?.executionSemanticsFingerprint ?? "sha256:unavailable",
    resultFingerprint: e?.runtimeExecution?.resultFingerprint ?? "sha256:unavailable",
    traceFingerprint: e?.runtimeExecution?.trace?.fingerprint ?? "sha256:unavailable"
  });
  try {
    if (!e || e.kind !== "zx-ai-proposal-artifact-v1" || e.runtimeExecution.status !== "success" || !ri(e) || !L(
      e.runtimeExecution.runtime.manifestRef,
      Nt
    ) || !L(
      e.descriptor.runtimeManifestRef,
      e.runtimeExecution.runtime.manifestRef
    ) || e.runtimeExecution.resultFingerprint !== I(e.runtimeExecution.resultDocument) || e.runtimeExecution.trace.resultFingerprint !== e.runtimeExecution.resultFingerprint || e.runtimeExecution.trace.fingerprint !== I(
      Dt(e.runtimeExecution.trace)
    ) || !L(
      e.runtimeExecution.trace.mapping,
      e.runtimeExecution.mapping
    ) || !L(
      e.runtimeExecution.trace.resources,
      e.runtimeExecution.resources
    ) || e.journal.sourceBinding.traceFingerprint !== e.runtimeExecution.trace.fingerprint)
      return Lt(
        t,
        "unsupported-runtime",
        "runtime-component-unsupported"
      );
    if (Ss(e) > Un.maxInputBytes)
      return Lt(
        t,
        "resource-limit-exceeded",
        "trace-byte-budget-exceeded"
      );
    const n = [];
    if (e.operationProjection.forEach((p) => {
      const d = e.base.plan.steps[p.operationIndex], f = Kd(d), u = Ji(e.base.document.body.content, f), m = Ji(
        e.runtimeExecution.resultDocument.body.content,
        f
      );
      Ld(d.kind, u, m).forEach((h, y) => {
        const k = {
          id: W("zx-ai-proposal-rich-diff-hunk-id:v1", {
            profile: Mt.fingerprint,
            sourceBinding: t,
            proposal: e.identity,
            operationIndex: p.operationIndex,
            blockId: f,
            kind: h,
            ordinal: y
          }),
          operationIndex: p.operationIndex,
          blockId: f,
          kind: h,
          ordinal: y,
          beforeFingerprint: u ? W("zx-ai-proposal-diff-before:v1", u) : null,
          afterFingerprint: m ? W("zx-ai-proposal-diff-after:v1", m) : null,
          summary: Vd(h)
        };
        n.push({
          ...k,
          fingerprint: W(
            "zx-ai-proposal-rich-diff-hunk:v1",
            k
          )
        });
      });
    }), !Jd(n.length))
      return Lt(
        t,
        "resource-limit-exceeded",
        "trace-byte-budget-exceeded"
      );
    const r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
    n.forEach((p) => {
      const d = r.get(p.operationIndex) ?? [];
      d.push(p.id), r.set(p.operationIndex, d);
      const f = i.get(p.blockId) ?? [];
      f.push(p.id), i.set(p.blockId, f);
    });
    const o = [...r.entries()].sort(([p], [d]) => p - d).map(([p, d]) => ({ operationIndex: p, hunkIds: d })), s = [...i.entries()].sort(([p], [d]) => p.localeCompare(d)).map(([p, d]) => ({ blockId: p, hunkIds: d })), a = {
      kind: "zx-ai-proposal-rich-diff-v1",
      version: "1.0.0",
      profileRef: Mt,
      sourceBinding: t,
      hunks: n,
      operationToHunks: o,
      blockToHunks: s
    }, c = {
      ...a,
      fingerprint: W(
        "zx-ai-proposal-rich-diff:v1",
        a
      )
    }, l = {
      status: "available",
      profileRef: Mt,
      sourceBinding: t,
      value: c
    };
    return Ud(l) ? g({
      ...l,
      fingerprint: W(
        "zx-ai-proposal-rich-diff-outcome:v1",
        l
      )
    }) : Lt(
      t,
      "resource-limit-exceeded",
      "trace-byte-budget-exceeded"
    );
  } catch {
    return Lt(
      t,
      "derivation-failed",
      "runtime-fingerprint-mismatch"
    );
  }
}, Wi = [
  "inputBytes",
  "inputDepth",
  "inputKeys",
  "documentNodes",
  "documentMarks",
  "documentBlocks",
  "annotations",
  "planOperations",
  "executionPlugins",
  "rootSteps",
  "steps",
  "transactions",
  "filterCalls",
  "appendCalls",
  "appendRounds",
  "mappingMaps",
  "mappingRanges",
  "mappingBytes",
  "mappingMirrors",
  "mappingMirrorBytes",
  "metaBytes",
  "traceBytes",
  "pluginStateBytes",
  "safeDiagnosticCount",
  "safeDiagnosticBytes"
], Nn = (e) => C(e, ["kind", "id", "version", "fingerprint"]) && [
  "schema-semantics",
  "operation-protocol",
  "execution-closure",
  "mapping-policy",
  "transaction-policy",
  "resource-profile",
  "derived-view-profile"
].includes(String(e.kind)) && z(e.id) && z(e.version) && z(e.fingerprint), Wn = (e) => C(e, [
  "kind",
  "id",
  "version",
  "fingerprint",
  "dependencies"
]) && Nn({
  kind: e.kind,
  id: e.id,
  version: e.version,
  fingerprint: e.fingerprint
}) && Array.isArray(e.dependencies) && e.dependencies.every(Nn), Es = (e) => C(e, Wi) && Wi.every((t) => ne(e[t])), Ts = (e) => C(e, [
  "pluginInstanceId",
  "projectorRef",
  "beforeFingerprint",
  "afterFingerprint",
  "value"
]) && z(e.pluginInstanceId) && (Nn(e.projectorRef) || Wn(e.projectorRef)) && z(e.beforeFingerprint) && z(e.afterFingerprint) && e.afterFingerprint === I(e.value), Xi = (e) => C(e, [
  "original",
  "mapped",
  "assoc",
  "deleted",
  "deletedBefore",
  "deletedAfter",
  "deletedAcross",
  "fingerprint"
]) && C(e.original, ["blockId", "offset"]) && C(e.mapped, ["blockId", "offset"]) && z(e.original.blockId) && z(e.mapped.blockId) && ne(e.original.offset) && ne(e.mapped.offset) && (e.assoc === 1 || e.assoc === -1) && ["deleted", "deletedBefore", "deletedAfter", "deletedAcross"].every(
  (t) => typeof e[t] == "boolean"
) && e.fingerprint === I(Dt(e)), Wd = (e) => !C(e, [
  "policyRef",
  "mapOrder",
  "mapRangeCounts",
  "mirrorPairs",
  "annotations",
  "fingerprint"
]) || !Wn(e.policyRef) || !Array.isArray(e.mapOrder) || !e.mapOrder.every(z) || !Array.isArray(e.mapRangeCounts) || !e.mapRangeCounts.every(ne) || e.mapOrder.length !== e.mapRangeCounts.length || !Array.isArray(e.mirrorPairs) || !e.mirrorPairs.every(
  (n) => Array.isArray(n) && n.length === 2 && ne(n[0]) && ne(n[1])
) || !Array.isArray(e.annotations) ? !1 : e.annotations.every(
  (n) => C(n, [
    "annotationId",
    "status",
    "start",
    "end",
    "quote",
    "beforeQuote",
    "afterQuote",
    "fingerprint"
  ]) && z(n.annotationId) && n.status === "mapped" && Xi(n.start) && Xi(n.end) && typeof n.quote == "string" && typeof n.beforeQuote == "string" && typeof n.afterQuote == "string" && n.fingerprint === I(Dt(n))
) && e.fingerprint === I(Dt(e)), Xd = (e, t) => {
  if (!C(e, [
    "kind",
    "sequence",
    "logicalTime",
    "rootExecutionId",
    "sourceAttribution",
    "operationSpans",
    "steps",
    "allowedMeta",
    "beforeDocumentFingerprint",
    "afterDocumentFingerprint",
    "selectionAndStoredMarksProof",
    "pluginState",
    "safeEffects",
    "resourceDelta",
    "fingerprint"
  ]) || e.kind !== "root" && e.kind !== "appended" || !ne(e.sequence) || !ne(e.logicalTime) || !z(e.rootExecutionId) || !C(e.sourceAttribution, [
    "owner",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || !["operation-compiler", "certified-plugin"].includes(
    String(e.sourceAttribution.owner)
  ) || !Array.isArray(e.sourceAttribution.visibleTransactionRange) || e.sourceAttribution.visibleTransactionRange.length !== 2 || !e.sourceAttribution.visibleTransactionRange.every(ne) || !Array.isArray(e.sourceAttribution.operationIndexes) || !e.sourceAttribution.operationIndexes.every(ne) || !Array.isArray(e.operationSpans) || !e.operationSpans.every(
    (s) => C(
      s,
      ["operationIndex", "stepStart", "stepEnd"],
      ["noOpReason"]
    ) && ne(s.operationIndex) && ne(s.stepStart) && ne(s.stepEnd) && s.stepStart <= s.stepEnd && (!Object.hasOwn(s, "noOpReason") || s.noOpReason === "already-equal")
  ) || !Array.isArray(e.steps) || !e.steps.every(
    (s) => C(s, ["json", "fingerprint", "mapFingerprint"]) && Mr(s.json) && s.fingerprint === I(s.json) && z(s.mapFingerprint) && t.has(s.mapFingerprint)
  ) || !Mr(e.allowedMeta) || !z(e.beforeDocumentFingerprint) || !z(e.afterDocumentFingerprint) || !C(e.selectionAndStoredMarksProof, [
    "selectionSet",
    "storedMarksSet"
  ]) || e.selectionAndStoredMarksProof.selectionSet !== !1 || e.selectionAndStoredMarksProof.storedMarksSet !== !1 || !Array.isArray(e.pluginState) || !e.pluginState.every(Ts) || !Array.isArray(e.safeEffects) || !e.safeEffects.every(
    (s) => C(s, ["effectRef", "kind", "fingerprint"]) && (Nn(s.effectRef) || Wn(s.effectRef)) && s.kind === "observational" && z(s.fingerprint)
  ) || !Es(e.resourceDelta))
    return !1;
  const n = e.sourceAttribution, r = n.visibleTransactionRange, i = e.allowedMeta["zx.runtime.root.v2"], o = e.allowedMeta["zx.runtime.appended.v2"];
  return e.kind === "root" && (n.owner !== "operation-compiler" || n.pluginInstanceId !== null || n.pluginOrder !== null || !L(n.visibleTransactionRange, [0, 0]) || !L(
    n.operationIndexes,
    e.operationSpans.map(
      (s) => s.operationIndex
    )
  ) || !C(e.allowedMeta, ["zx.runtime.root.v2"]) || !C(i, [
    "protocol",
    "executionId",
    "sequence",
    "compilerRef",
    "operationSpans"
  ]) || i.protocol !== "zx-runtime-root-meta-v2" || i.executionId !== e.rootExecutionId || i.sequence !== e.sequence || !z(i.compilerRef) || !L(i.operationSpans, e.operationSpans)) || e.kind === "appended" && (n.owner !== "certified-plugin" || !z(n.pluginInstanceId) || !ne(n.pluginOrder) || e.operationSpans.length !== 0 || r[0] > r[1] || r[1] >= e.sequence || !C(e.allowedMeta, ["zx.runtime.appended.v2"]) || !C(o, [
    "protocol",
    "rootExecutionId",
    "sequence",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || o.protocol !== "zx-runtime-appended-meta-v2" || o.rootExecutionId !== e.rootExecutionId || o.sequence !== e.sequence || o.pluginInstanceId !== n.pluginInstanceId || o.pluginOrder !== n.pluginOrder || !L(
    o.visibleTransactionRange,
    n.visibleTransactionRange
  ) || !L(o.operationIndexes, n.operationIndexes)) ? !1 : e.fingerprint === I(
    Dt(
      e
    )
  );
}, gr = (e) => {
  const t = "target" in e ? [e.target.blockId] : [], n = "reference" in e ? [e.reference.blockId] : [], r = "block" in e && e.block && typeof e.block == "object" && typeof e.block.attrs?.blockId == "string" ? [e.block.attrs.blockId] : [];
  return [.../* @__PURE__ */ new Set([...t, ...n, ...r])].sort();
}, Gd = (e, t) => {
  const n = t.operationSpans, r = e.steps.map((c) => c.operationIndex), i = n.map((c) => c.operationIndex);
  if (new Set(r).size !== r.length || r.some((c, l) => c !== l) || !L(r, i))
    return null;
  let o = 0;
  const s = [], a = /* @__PURE__ */ new Map();
  e.steps.forEach((c) => {
    const l = gr(c), p = e.steps.slice(0, c.operationIndex).filter(
      (d) => gr(d).some((f) => l.includes(f))
    ).map((d) => d.operationIndex);
    a.set(c.operationIndex, p);
  });
  for (const [c, l] of n.entries()) {
    const p = e.steps[c], d = l.stepStart, f = l.stepEnd;
    if (d !== o || f > t.steps.length)
      return null;
    o = f, s.push({
      operationIndex: p.operationIndex,
      kind: p.kind,
      blockIds: gr(p),
      stepStart: d,
      stepEnd: f,
      ...l.noOpReason === "already-equal" ? { noOpReason: "already-equal" } : {},
      intentDigest: I({
        domain: "zx-ai-proposal-operation-intent:v1",
        step: p
      }),
      dependencyOperationIndexes: a.get(p.operationIndex) ?? []
    });
  }
  return o !== t.steps.length ? null : s;
}, Ot = (e, t, n) => ({
  valid: !1,
  diagnostic: Ue({ code: e, stage: t, path: n })
}), Zd = (e, t, n, r) => {
  const i = nl();
  if (!ri(r))
    return Ot(
      "proposal-runtime-outcome-invalid",
      "runtime",
      "$.runtimeOutcome"
    );
  if (!C(r, [
    "status",
    "runtime",
    "resultDocument",
    "resultFingerprint",
    "trace",
    "mapping",
    "pluginState",
    "resources",
    "replayEligibility"
  ]) || r.status !== "success" || r.replayEligibility !== "exact-runtime-only" || !C(r.runtime, [
    "manifestRef",
    "executionSemanticsFingerprint",
    "observationalProfileFingerprint",
    "derivedViewFingerprint",
    "adapterRef",
    "conformanceReceiptRefs",
    "conformanceEnvironmentReceiptRefs"
  ]) || !L(r.runtime.manifestRef, e) || e.fingerprint !== i.fingerprints.runtimeManifestFingerprint || r.runtime.executionSemanticsFingerprint !== i.fingerprints.executionSemanticsFingerprint || r.runtime.observationalProfileFingerprint !== i.fingerprints.observationalProfileFingerprint || r.runtime.derivedViewFingerprint !== i.fingerprints.derivedViewFingerprint || !L(
    r.runtime.adapterRef,
    i.executionClosure
  ) || !Wn(r.runtime.adapterRef) || !Array.isArray(r.runtime.conformanceReceiptRefs) || r.runtime.conformanceReceiptRefs.length === 0 || !r.runtime.conformanceReceiptRefs.every(z) || !Array.isArray(r.runtime.conformanceEnvironmentReceiptRefs) || r.runtime.conformanceEnvironmentReceiptRefs.length === 0 || !r.runtime.conformanceEnvironmentReceiptRefs.every(
    (d) => C(d, [
      "environment",
      "adapterExecutionIdentity",
      "matrixRowFingerprint"
    ]) && z(d.environment) && z(d.adapterExecutionIdentity) && z(d.matrixRowFingerprint)
  ) || !Tn(r.resultDocument).valid || r.resultFingerprint !== I(r.resultDocument) || !Es(r.resources) || !Array.isArray(r.pluginState) || !r.pluginState.every(Ts))
    return Ot(
      "proposal-runtime-binding-mismatch",
      "runtime",
      "$.runtimeOutcome"
    );
  if (!C(r.trace, [
    "version",
    "executionId",
    "manifest",
    "entries",
    "mapping",
    "resources",
    "resultFingerprint",
    "fingerprint"
  ]) || r.trace.version !== "runtime-execution-trace-v2" || !z(r.trace.executionId) || !C(r.trace.manifest, [
    "runtimeManifestFingerprint",
    "executionSemanticsFingerprint",
    "observationalProfileFingerprint",
    "derivedViewFingerprint"
  ]) || r.trace.manifest.runtimeManifestFingerprint !== e.fingerprint || r.trace.manifest.executionSemanticsFingerprint !== r.runtime.executionSemanticsFingerprint || r.trace.manifest.observationalProfileFingerprint !== r.runtime.observationalProfileFingerprint || r.trace.manifest.derivedViewFingerprint !== r.runtime.derivedViewFingerprint || r.trace.resultFingerprint !== r.resultFingerprint || !Wd(r.mapping) || !L(r.trace.mapping, r.mapping) || !L(r.trace.resources, r.resources) || r.trace.fingerprint !== I(Dt(r.trace)) || !Array.isArray(r.trace.entries) || r.trace.entries.length === 0)
    return Ot("proposal-trace-invalid", "trace", "$.runtimeOutcome.trace");
  const o = new Set(r.mapping.mapOrder), s = r.trace.entries, a = s.flatMap(
    (d) => d.steps.map((f) => f.mapFingerprint)
  ), c = s.every((d, f) => {
    if (d.pluginState.length === 0) return !1;
    if (f === 0) return !0;
    const u = s[f - 1].pluginState;
    return d.pluginState.length === u.length && d.pluginState.every(
      (m, h) => m.pluginInstanceId === u[h].pluginInstanceId && m.projectorRef.fingerprint === u[h].projectorRef.fingerprint && m.beforeFingerprint === u[h].afterFingerprint
    );
  });
  if (!s.every((d) => Xd(d, o)) || !c || s[0].beforeDocumentFingerprint !== I(t.body.content) || s.at(-1)?.afterDocumentFingerprint !== I(r.resultDocument.body.content) || !L(a, r.mapping.mapOrder) || !L(r.pluginState, s.at(-1)?.pluginState) || r.resources.transactions !== s.length || r.resources.rootSteps !== s[0].steps.length || r.resources.steps !== a.length || r.resources.mappingMaps !== r.mapping.mapOrder.length || r.resources.mappingRanges !== r.mapping.mapRangeCounts.reduce(
    (d, f) => d + f,
    0
  ) || r.resources.mappingMirrors !== r.mapping.mirrorPairs.length || r.resources.planOperations !== n.steps.length || r.resources.executionPlugins !== r.pluginState.length || s.some(
    (d, f) => d.sequence !== f || d.logicalTime !== f || d.rootExecutionId !== r.trace.executionId
  ) || s[0].kind !== "root" || s.slice(1).some((d) => d.kind !== "appended") || s.some(
    (d, f) => f > 0 && d.beforeDocumentFingerprint !== s[f - 1].afterDocumentFingerprint
  ))
    return Ot(
      "proposal-trace-invalid",
      "trace",
      "$.runtimeOutcome.trace.entries"
    );
  const l = n.steps.map((d) => d.operationIndex);
  if (s.some((d) => {
    const f = d.sourceAttribution.operationIndexes;
    return f.some((u) => !l.includes(u)) || f.some(
      (u, m) => m > 0 && f[m - 1] >= u
    );
  }))
    return Ot(
      "proposal-operation-projection-invalid",
      "trace",
      "$.runtimeOutcome.trace.entries"
    );
  const p = Gd(
    n,
    s[0]
  );
  return p ? { valid: !0, operationProjection: p } : Ot(
    "proposal-operation-projection-invalid",
    "trace",
    "$.runtimeOutcome.trace.entries[0].operationSpans"
  );
}, Yd = (e) => C(e, ["proposalId", "variantId"], ["parentVariantId"]) && z(e.proposalId) && z(e.variantId) && (!Object.hasOwn(e, "parentVariantId") || z(e.parentVariantId)), Qd = (e) => C(e, ["sourceId", "sequence", "refs"], ["timestamp"]) && z(e.sourceId) && ne(e.sequence) && (!Object.hasOwn(e, "timestamp") || z(e.timestamp)) && Array.isArray(e.refs) && e.refs.every(
  (t) => C(t, ["id", "type"]) && z(t.id) && ["entity", "activity", "agent", "plan"].includes(String(t.type))
), ep = (e) => C(e, ["kind", "version", "fingerprint"]) && e.kind === "zx-text-editor-runtime-manifest-v2" && e.version === "2.0.0" && z(e.fingerprint), tp = (e) => C(e, ["protocol"], ["intentRef"]) && e.protocol === "zx-runtime-execution-context-v1" && (!Object.hasOwn(e, "intentRef") || C(e.intentRef, ["id", "version", "fingerprint"]) && z(e.intentRef.id) && z(e.intentRef.version) && z(e.intentRef.fingerprint)), np = (e) => !!(e && typeof e == "object" && !Array.isArray(e) && Array.isArray(e.steps) && e.steps.some(
  (t) => !!(t && typeof t == "object" && !Array.isArray(t)) && (t.kind === "block.move" || Object.keys(t).some(
    (n) => ["move", "moveOnly", "moveMetadata", "moveKind"].includes(n)
  ))
)), rp = (e) => C(e, [
  "runtime",
  "baseDocument",
  "plan",
  "identity",
  "lifecycle",
  "provenance",
  "runtimeContext"
]) && ep(e.runtime) && Yd(e.identity) && Rs(e.lifecycle) && e.lifecycle.status === "active" && e.lifecycle.proposalId === e.identity.proposalId && Qd(e.provenance) && tp(e.runtimeContext) && !!(e.baseDocument && typeof e.baseDocument == "object") && !!(e.plan && typeof e.plan == "object"), ip = (e) => {
  const t = {
    kind: "zx-ai-proposal-artifact-descriptor-v1",
    version: "1.0.0",
    envelopeRef: "zx-ai-proposal-artifact-v1",
    codecRef: "zx-ai-proposal-canonical-codec-v1",
    effectProofRef: "zx-ai-proposal-effect-proof-v1",
    richDiffProfileRef: Mt,
    semanticRecipeSchemaRef: "zx-ai-proposal-semantic-recipe-v1",
    lifecycleSchemaRef: "zx-ai-proposal-lifecycle-receipt-v1",
    runtimeManifestRef: e,
    runtimeTraceContractRef: "runtime-execution-trace-v2",
    forbiddenAuthorities: [
      "operation-compiler",
      "plugin-closure",
      "mapping-policy",
      "resource-ledger",
      "transaction-semantics"
    ]
  };
  return g({
    ...t,
    fingerprint: W(
      "zx-ai-proposal-artifact-descriptor:v1",
      t
    )
  });
}, Fs = /* @__PURE__ */ new WeakSet(), op = (e) => typeof e == "object" && e !== null && Fs.has(e), Cs = (e, t) => {
  try {
    const n = Zd(
      e.runtime,
      e.baseDocument,
      e.plan,
      t
    );
    if (!n.valid) return n;
    const r = $d({
      base: e.baseDocument,
      plan: e.plan,
      runtime: t
    });
    if (!r.valid) return r;
    const i = W(
      "zx-ai-proposal-identity:v1",
      e.identity
    ), o = W(
      "zx-ai-proposal-base-document:v1",
      e.baseDocument
    ), s = W("zx-ai-proposal-plan:v1", e.plan), a = W("zx-ai-proposal-input:v1", {
      runtime: e.runtime,
      baseFingerprint: o,
      planDigest: s,
      identity: e.identity,
      lifecycle: e.lifecycle,
      provenance: e.provenance,
      runtimeContext: e.runtimeContext
    }), c = {
      kind: "zx-ai-proposal-journal-v1",
      version: "1.0.0",
      sourceBinding: {
        executionSemanticsFingerprint: t.runtime.executionSemanticsFingerprint,
        resultFingerprint: t.resultFingerprint,
        traceFingerprint: t.trace.fingerprint
      },
      trace: t.trace,
      proposalIdentityFingerprint: i,
      baseFingerprint: o,
      planDigest: s,
      lifecycleRevision: e.lifecycle.revision
    }, l = {
      ...c,
      fingerprint: W(
        "zx-ai-proposal-journal:v1",
        c
      )
    }, p = {
      document: e.baseDocument,
      fingerprint: o,
      documentRevision: e.plan.source.documentRevision,
      annotationFingerprint: W(
        "zx-ai-proposal-annotations:v1",
        e.baseDocument.annotations
      ),
      targetFingerprint: jd(
        e.baseDocument,
        n.operationProjection
      ),
      plan: e.plan,
      planDigest: s,
      runtimeContext: e.runtimeContext,
      inputDigest: a
    }, d = {
      kind: "zx-ai-proposal-artifact-v1",
      version: "1.0.0",
      identity: e.identity,
      provenance: e.provenance,
      lifecycle: e.lifecycle,
      base: p,
      runtimeExecution: t,
      operationProjection: n.operationProjection,
      journal: l,
      effectProof: r.proof,
      descriptor: ip(e.runtime)
    }, f = g(d), u = Hd(f), m = W(
      "zx-ai-proposal-artifact-core:v1",
      f
    ), h = ni({
      ...f,
      richDiff: u,
      fingerprint: m
    }), y = g({
      ...h,
      // Keep the live S2 plan capability across S3/S4. Serialized proposal
      // artifacts retain identical bytes but intentionally lose execution
      // authority and must be regenerated before another live commit.
      base: { ...h.base, plan: e.plan },
      runtimeExecution: t
    });
    return Fs.add(y), {
      valid: !0,
      proposal: y
    };
  } catch {
    return {
      valid: !1,
      diagnostic: Ue({
        code: "proposal-artifact-invalid",
        stage: "artifact",
        path: "$.proposal"
      })
    };
  }
}, sp = (e) => {
  if (!rp(e))
    return g({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: Ue({
        code: "proposal-input-invalid",
        stage: "input",
        path: "$"
      })
    });
  if (np(e.plan))
    return g({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: Ue({
        code: "block-move-unsupported",
        stage: "input",
        path: "$.plan"
      })
    });
  let t;
  try {
    t = { ...ni(e), plan: e.plan };
  } catch {
    return g({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: Ue({
        code: "proposal-input-invalid",
        stage: "input",
        path: "$"
      })
    });
  }
  if (t.plan.source.documentRevision !== I(t.baseDocument))
    return g({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: Ue({
        code: "proposal-input-invalid",
        stage: "input",
        path: "$.plan.source.documentRevision"
      })
    });
  const n = xf({
    runtime: t.runtime,
    baseDocument: t.baseDocument,
    plan: t.plan,
    context: t.runtimeContext
  });
  return ap(t, n);
}, ap = (e, t) => {
  if (t.status === "failure")
    return g({
      status: "runtime-failure",
      runtimeOutcome: t,
      proposal: null
    });
  if (t.status === "safety-abort")
    return g({
      status: "safety-abort",
      runtimeOutcome: t,
      proposal: null
    });
  const n = Cs(e, t);
  return n.valid ? g({
    status: "success",
    runtimeOutcome: t,
    proposal: n.proposal
  }) : g({
    status: "proposal-failure",
    runtimeOutcome: t,
    proposal: null,
    diagnostic: n.diagnostic
  });
}, cp = () => g({
  status: "proposal-runtime-unsupported",
  proposal: null,
  diagnostic: Ue({
    code: "proposal-runtime-unsupported",
    stage: "artifact",
    path: "$.version"
  })
}), Ze = (e = "$") => g({
  status: "proposal-artifact-invalid",
  proposal: null,
  diagnostic: Ue({
    code: "proposal-artifact-invalid",
    stage: "artifact",
    path: e
  })
}), lp = (e) => C(e, [
  "kind",
  "version",
  "identity",
  "provenance",
  "lifecycle",
  "base",
  "runtimeExecution",
  "operationProjection",
  "journal",
  "effectProof",
  "richDiff",
  "descriptor",
  "fingerprint"
]) && C(
  e.identity,
  ["proposalId", "variantId"],
  ["parentVariantId"]
) && C(
  e.provenance,
  ["sourceId", "sequence", "refs"],
  ["timestamp"]
) && C(e.lifecycle, [
  "proposalId",
  "revision",
  "status",
  "fingerprint"
]) && C(e.base, [
  "document",
  "fingerprint",
  "documentRevision",
  "annotationFingerprint",
  "targetFingerprint",
  "plan",
  "planDigest",
  "runtimeContext",
  "inputDigest"
]) && Array.isArray(e.operationProjection) && e.operationProjection.every(
  (t) => C(
    t,
    [
      "operationIndex",
      "kind",
      "blockIds",
      "stepStart",
      "stepEnd",
      "intentDigest",
      "dependencyOperationIndexes"
    ],
    ["noOpReason"]
  )
) && C(e.journal, [
  "kind",
  "version",
  "sourceBinding",
  "trace",
  "proposalIdentityFingerprint",
  "baseFingerprint",
  "planDigest",
  "lifecycleRevision",
  "fingerprint"
]) && C(e.effectProof, [
  "kind",
  "version",
  "operationScopes",
  "traceAttribution",
  "untouchedBlockFingerprints",
  "untouchedAnnotationFingerprints",
  "untouchedProjectionFingerprint",
  "relativeOrderFingerprint",
  "annotationProjectionFingerprint",
  "assetsMetaUnchanged",
  "fingerprint"
]) && C(e.descriptor, [
  "kind",
  "version",
  "envelopeRef",
  "codecRef",
  "effectProofRef",
  "richDiffProfileRef",
  "semanticRecipeSchemaRef",
  "lifecycleSchemaRef",
  "runtimeManifestRef",
  "runtimeTraceContractRef",
  "forbiddenAuthorities",
  "fingerprint"
]), Ns = (e) => {
  if (op(e))
    return g({
      status: "success",
      proposal: e,
      cacheStatus: "exact"
    });
  let t = e;
  try {
    if (typeof e == "string" && (new TextEncoder().encode(e).byteLength > Gt.maxBytes || (t = JSON.parse(e), We(t, Gt).canonical !== e)))
      return Ze("$");
    We(t, Gt);
  } catch {
    return Ze("$");
  }
  if (!t || typeof t != "object" || Array.isArray(t))
    return Ze("$");
  const n = t;
  if (n.kind !== "zx-ai-proposal-artifact-v1" || n.version !== "1.0.0")
    return cp();
  if (!lp(t)) return Ze("$");
  const r = ni(t);
  if (r.runtimeExecution.status !== "success")
    return Ze("$.runtimeExecution");
  const i = Cs(
    {
      runtime: r.descriptor.runtimeManifestRef,
      baseDocument: r.base.document,
      plan: r.base.plan,
      identity: r.identity,
      lifecycle: r.lifecycle,
      provenance: r.provenance,
      runtimeContext: r.base.runtimeContext
    },
    r.runtimeExecution
  );
  if (!i.valid) return Ze(i.diagnostic.path);
  const o = i.proposal, s = {
    ...r,
    richDiff: o.richDiff
  };
  if (!L(s, o))
    return Ze("$.fingerprint");
  const a = L(r.richDiff, o.richDiff) ? "exact" : "rich-diff-rebuilt";
  return g({
    status: "success",
    proposal: o,
    cacheStatus: a
  });
}, Gi = /* @__PURE__ */ new Map(), dp = /* @__PURE__ */ new Map(), pp = (e) => e.identity.reviewId, fp = (e) => {
  const t = pp(e), n = Gi.get(t);
  return n ? n.revision === e.revision && n.fingerprint === e.fingerprint && n.status === e.status && n.reservation === null : (Gi.set(t, {
    revision: e.revision,
    fingerprint: e.fingerprint,
    status: e.status,
    reservation: null
  }), dp.set(t, e), !0);
}, j = g({
  maxBytes: 4e6,
  maxDepth: 96,
  maxArrayEntries: 3e4,
  maxObjectKeys: 64,
  maxTotalObjectKeys: 16e4,
  // Count limits remain independently reachable below the 4 MB envelope
  // ceiling, so their limit boundary is observable rather than shadowed by
  // the byte budget.
  maxItems: 512,
  maxDecisionEntries: 512,
  maxAuditEntries: 1024,
  maxNavigationPageSize: 100,
  maxDiagnosticCount: 32,
  maxSummaryLength: 240
});
g({
  items: j.maxItems,
  decisions: j.maxDecisionEntries,
  "audit-entries": j.maxAuditEntries,
  "navigation-page": j.maxNavigationPageSize,
  diagnostics: j.maxDiagnosticCount
});
const Mn = g({
  maxBytes: j.maxBytes,
  maxDepth: j.maxDepth,
  maxArrayEntries: j.maxArrayEntries,
  maxObjectKeys: j.maxObjectKeys,
  maxTotalObjectKeys: j.maxTotalObjectKeys
}), up = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), me = (e, t, n = []) => up(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), q = (e) => typeof e == "string" && e.trim().length > 0, Re = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, ge = (e, t) => I({ domain: e, value: t }), Ft = (e) => {
  rn(e, Mn);
  const { canonical: t } = We(
    e,
    Mn
  );
  return g(JSON.parse(t));
}, Dr = (e, t) => {
  try {
    return F(e) === F(t);
  } catch {
    return !1;
  }
}, hp = (e) => new TextEncoder().encode(F(e)).byteLength, $r = (e, t = /* @__PURE__ */ new Set()) => !e || typeof e != "object" || t.has(e) ? !0 : Object.isFrozen(e) ? (t.add(e), Object.values(e).every(
  (n) => $r(n, t)
)) : !1, mp = (e) => {
  const { fingerprint: t, ...n } = e;
  return n;
}, gp = (e) => [...new Set(e)].sort((t, n) => t - n), yp = (e) => e.slice(0, j.maxSummaryLength), bp = (e) => {
  if (!e.length) return null;
  const t = new Set(e.map((i) => i.operationIndex));
  if (t.size !== e.length || e.some(
    (i, o) => i.operationIndex !== o || !i.intentDigest || i.dependencyOperationIndexes.some(
      (s, a, c) => !t.has(s) || s === i.operationIndex || s >= i.operationIndex || a > 0 && s <= c[a - 1]
    )
  ))
    return null;
  const n = e.map(
    (i) => g([...i.dependencyOperationIndexes])
  ), r = e.map(() => []);
  return n.forEach((i, o) => {
    i.forEach((s) => r[s].push(o));
  }), g({
    operationIndexes: e.map((i) => i.operationIndex),
    dependencies: n,
    reverseDependencies: r.map(gp),
    fingerprintProjection: e.map((i) => ({
      operationIndex: i.operationIndex,
      intentDigest: i.intentDigest,
      dependencies: [...i.dependencyOperationIndexes]
    }))
  });
}, xp = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, kp = /^[A-Za-z0-9_.:-]{1,160}$/, Xn = (e) => {
  const t = (n) => n && kp.test(n) ? Zt(
    I({ domain: "zx-ai-review-safe-ref:v1", value: n })
  ) : void 0;
  return g({
    code: e.code,
    stage: e.stage,
    path: xp.test(e.path) ? e.path.slice(0, 240) : "$",
    ...Number.isSafeInteger(e.count) && e.count >= 0 ? { count: Math.min(e.count, 1e6) } : {},
    ...typeof e.fingerprint == "string" ? { fingerprintPrefix: Zt(e.fingerprint) } : {},
    ...t(e.reviewRef) ? { reviewRef: t(e.reviewRef) } : {},
    ...t(e.proposalRef) ? { proposalRef: t(e.proposalRef) } : {},
    ...t(e.operationRef) ? { operationRef: t(e.operationRef) } : {},
    ...t(e.blockRef) ? { blockRef: t(e.blockRef) } : {},
    ...t(e.hunkRef) ? { hunkRef: t(e.hunkRef) } : {}
  });
}, Ye = (e) => ({
  valid: !1,
  diagnostic: Xn({
    code: "review-item-index-invalid",
    stage: "items",
    path: e
  })
}), Ip = (e, t, n) => {
  const r = e.operationProjection[t], i = new Map(
    r.blockIds.map((c, l) => [c, l])
  ), o = [...n].sort(
    (c, l) => (i.get(c.blockId) ?? Number.MAX_SAFE_INTEGER) - (i.get(l.blockId) ?? Number.MAX_SAFE_INTEGER) || c.ordinal - l.ordinal || c.id.localeCompare(l.id)
  ), s = e.effectProof.traceAttribution.filter(
    (c) => c.kind === "appended" && c.operationIndexes.includes(t)
  ).map((c) => {
    const l = {
      sequence: c.sequence,
      pluginInstanceId: c.pluginInstanceId ?? "package-runtime",
      documentChanged: c.documentChanged,
      blockRefs: [...c.attributedBlockIds],
      safeEffectFingerprints: [...c.safeEffectFingerprints]
    };
    return g({
      ...l,
      fingerprint: ge(
        "zx-ai-review-appended-attribution:v1",
        l
      )
    });
  }), a = {
    operationIndex: t,
    operationKind: r.kind,
    operationIntentDigest: r.intentDigest,
    decisionKey: ge("zx-ai-review-decision-key:v1", {
      proposalFingerprint: e.fingerprint,
      operationIndex: t,
      operationIntentDigest: r.intentDigest
    }),
    dependencyOperationIndexes: [...r.dependencyOperationIndexes],
    blockRefs: [...r.blockIds],
    hunkRefs: o.map((c) => ({
      hunkId: c.id,
      ordinal: c.ordinal,
      kind: c.kind,
      fingerprint: c.fingerprint
    })),
    appendedAttributionRefs: s,
    summary: yp(
      o.length ? o.map((c) => c.summary).join(" | ") : "already-equal"
    ),
    noOpReason: r.noOpReason ?? null
  };
  return g({
    itemId: ge("zx-ai-review-item-id:v1", {
      policy: "zx.ai.review-policy@1.0.0",
      proposalFingerprint: e.fingerprint,
      operationIndex: t,
      operationIntentDigest: r.intentDigest,
      hunkFingerprints: o.map((c) => c.fingerprint)
    }),
    ...a,
    fingerprint: ge("zx-ai-review-item:v1", a)
  });
}, vp = (e) => {
  if (e.richDiff.status === "unavailable")
    return g({
      valid: !0,
      capability: "coarse-review-unavailable",
      items: []
    });
  const t = e.richDiff.value;
  if (!Dr(t.sourceBinding, e.richDiff.sourceBinding))
    return Ye("$.proposal.richDiff.sourceBinding");
  const n = new Map(t.hunks.map((a) => [a.id, a]));
  if (n.size !== t.hunks.length)
    return Ye("$.proposal.richDiff.hunks");
  const r = new Map(
    t.operationToHunks.map((a) => [a.operationIndex, a.hunkIds])
  );
  if (r.size !== t.operationToHunks.length || t.operationToHunks.some(
    (a, c, l) => !e.operationProjection[a.operationIndex] || c > 0 && a.operationIndex <= l[c - 1].operationIndex || new Set(a.hunkIds).size !== a.hunkIds.length
  ))
    return Ye("$.proposal.richDiff.operationToHunks");
  const i = /* @__PURE__ */ new Set(), o = [];
  for (const a of e.operationProjection) {
    const c = r.get(a.operationIndex) ?? [], l = [];
    for (const d of c) {
      const f = n.get(d);
      if (!f || i.has(d) || f.operationIndex !== a.operationIndex)
        return Ye("$.proposal.richDiff.hunks");
      i.add(d), l.push(f);
    }
    if (!l.length && a.noOpReason !== "already-equal")
      return Ye(
        `$.proposal.operationProjection[${a.operationIndex}]`
      );
    const p = e.effectProof.traceAttribution.filter(
      (d) => d.kind === "appended" && d.operationIndexes.includes(a.operationIndex)
    );
    if (l.length > j.maxNavigationPageSize || a.blockIds.length > j.maxNavigationPageSize || p.length > j.maxNavigationPageSize || p.some(
      (d) => d.attributedBlockIds.length > j.maxNavigationPageSize || d.safeEffectFingerprints.length > j.maxNavigationPageSize
    ))
      return Ye(
        `$.proposal.operationProjection[${a.operationIndex}]`
      );
    o.push(Ip(e, a.operationIndex, l));
  }
  if (i.size !== t.hunks.length || o.length > j.maxItems)
    return Ye("$.proposal.richDiff.hunks");
  const s = /* @__PURE__ */ new Map();
  return t.hunks.forEach((a) => {
    const c = s.get(a.blockId) ?? [];
    c.push(a.id), s.set(a.blockId, c);
  }), t.blockToHunks.length !== s.size || t.blockToHunks.some(
    (a) => !s.has(a.blockId) || !Dr(a.hunkIds, s.get(a.blockId))
  ) ? Ye("$.proposal.richDiff.blockToHunks") : g({ valid: !0, capability: "fine-review", items: o });
}, Zi = {
  id: "zx.ai.review-policy",
  version: "1.0.0",
  hunkExecutable: !1,
  partialDecisionDispatch: !1,
  fineDiffUnavailableAllowed: ["reject-all", "regenerate"],
  wholeAcceptRequiresFineReview: !0,
  independentWholeReviewSurface: "not-provided-v1",
  limits: j
}, yr = g({
  ...Zi,
  fingerprint: ge(
    "zx-ai-review-policy:v1",
    Zi
  )
}), Ms = g({
  id: yr.id,
  version: yr.version,
  fingerprint: yr.fingerprint
}), Ps = (e) => me(e, ["id", "version", "fingerprint"]) && Dr(e, Ms), zs = /* @__PURE__ */ new WeakSet(), js = (e) => ge("zx-ai-review-sidecar:v1", e), wp = (e) => {
  const t = Ft({
    ...e,
    fingerprint: js(e)
  });
  return zs.add(t), t;
}, At = (e = "$") => g({
  status: "review-sidecar-invalid",
  sidecar: null,
  diagnostic: Xn({
    code: "review-sidecar-invalid",
    stage: "codec",
    path: e
  })
}), Sp = () => g({
  status: "review-runtime-unsupported",
  sidecar: null,
  diagnostic: Xn({
    code: "review-runtime-unsupported",
    stage: "codec",
    path: "$.version"
  })
}), Op = (e) => me(e, [
  "itemId",
  "operationIndex",
  "operationKind",
  "operationIntentDigest",
  "decisionKey",
  "dependencyOperationIndexes",
  "blockRefs",
  "hunkRefs",
  "appendedAttributionRefs",
  "summary",
  "noOpReason",
  "fingerprint"
]) && q(e.itemId) && Re(e.operationIndex) && q(e.operationKind) && q(e.operationIntentDigest) && q(e.decisionKey) && Array.isArray(e.dependencyOperationIndexes) && e.dependencyOperationIndexes.every(Re) && Array.isArray(e.blockRefs) && e.blockRefs.length <= j.maxNavigationPageSize && e.blockRefs.every(q) && Array.isArray(e.hunkRefs) && e.hunkRefs.length <= j.maxNavigationPageSize && e.hunkRefs.every(
  (t) => me(t, ["hunkId", "ordinal", "kind", "fingerprint"]) && q(t.hunkId) && Re(t.ordinal) && q(t.kind) && q(t.fingerprint)
) && Array.isArray(e.appendedAttributionRefs) && e.appendedAttributionRefs.length <= j.maxNavigationPageSize && e.appendedAttributionRefs.every(
  (t) => me(t, [
    "sequence",
    "pluginInstanceId",
    "documentChanged",
    "blockRefs",
    "safeEffectFingerprints",
    "fingerprint"
  ]) && Re(t.sequence) && q(t.pluginInstanceId) && typeof t.documentChanged == "boolean" && Array.isArray(t.blockRefs) && t.blockRefs.length <= j.maxNavigationPageSize && t.blockRefs.every(q) && Array.isArray(t.safeEffectFingerprints) && t.safeEffectFingerprints.length <= j.maxNavigationPageSize && t.safeEffectFingerprints.every(q) && q(t.fingerprint) && t.fingerprint === ge("zx-ai-review-appended-attribution:v1", {
    sequence: t.sequence,
    pluginInstanceId: t.pluginInstanceId,
    documentChanged: t.documentChanged,
    blockRefs: t.blockRefs,
    safeEffectFingerprints: t.safeEffectFingerprints
  })
) && typeof e.summary == "string" && e.summary.length <= j.maxSummaryLength && (e.noOpReason === null || e.noOpReason === "already-equal") && q(e.fingerprint), Ap = (e) => me(e, [
  "operationIndex",
  "operationIntentDigest",
  "dependencyOperationIndexes",
  "state",
  "decidedAtRevision",
  "fingerprint"
]) && Re(e.operationIndex) && q(e.operationIntentDigest) && Array.isArray(e.dependencyOperationIndexes) && e.dependencyOperationIndexes.every(Re) && ["undecided", "accepted", "rejected", "regeneration-required"].includes(
  e.state
) && (e.decidedAtRevision === null || Re(e.decidedAtRevision)) && q(e.fingerprint), Rp = (e) => me(e, [
  "sequence",
  "kind",
  "commandId",
  "previousSidecarFingerprint",
  "operationIndexes",
  "fingerprint"
]) && Re(e.sequence) && q(e.kind) && (e.commandId === null || q(e.commandId)) && (e.previousSidecarFingerprint === null || q(e.previousSidecarFingerprint)) && Array.isArray(e.operationIndexes) && e.operationIndexes.every(Re) && q(e.fingerprint), Ep = (e) => me(e, [
  "kind",
  "version",
  "identity",
  "proposalBinding",
  "policyRef",
  "profileRef",
  "revision",
  "status",
  "capability",
  "items",
  "decisions",
  "auditEntries",
  "fingerprint"
]) && me(e.identity, ["reviewId"]) && q(e.identity.reviewId) && me(e.proposalBinding, [
  "proposalId",
  "variantId",
  "proposalFingerprint",
  "operationCount",
  "operationProjectionFingerprint",
  "lifecycleRevision",
  "lifecycleFingerprint",
  "baseFingerprint",
  "documentRevision",
  "annotationFingerprint",
  "targetFingerprint",
  "planDigest",
  "resultFingerprint",
  "traceFingerprint",
  "mappingFingerprint",
  "effectFingerprint",
  "richDiffStatus",
  "richDiffSourceBinding",
  "richDiffUnavailableReason",
  "richDiffFingerprint"
]) && Re(e.proposalBinding.operationCount) && e.proposalBinding.operationCount > 0 && q(e.proposalBinding.operationProjectionFingerprint) && me(e.proposalBinding.richDiffSourceBinding, [
  "executionSemanticsFingerprint",
  "resultFingerprint",
  "traceFingerprint"
]) && ["available", "unavailable"].includes(
  String(e.proposalBinding.richDiffStatus)
) && (e.proposalBinding.richDiffUnavailableReason === null || [
  "profile-not-installed",
  "unsupported-runtime",
  "resource-limit-exceeded",
  "derivation-failed"
].includes(String(e.proposalBinding.richDiffUnavailableReason))) && Ps(e.policyRef) && me(e.profileRef, [
  "kind",
  "id",
  "version",
  "fingerprint",
  "dependencies"
]) && Re(e.revision) && [
  "active",
  "committed",
  "accepted-no-change",
  "rejected",
  "superseded",
  "invalidated"
].includes(e.status) && ["fine-review", "coarse-review-unavailable"].includes(
  e.capability
) && Array.isArray(e.items) && e.items.length <= j.maxItems && e.items.every(Op) && Array.isArray(e.decisions) && e.decisions.length <= j.maxDecisionEntries && e.decisions.every(Ap) && Array.isArray(e.auditEntries) && e.auditEntries.length <= j.maxAuditEntries && e.auditEntries.every(Rp) && q(e.fingerprint), Tp = (e) => {
  if (typeof e == "object" && e !== null && zs.has(e))
    return g({
      status: "success",
      sidecar: e
    });
  let t = e;
  try {
    if (typeof e == "string" && (new TextEncoder().encode(e).byteLength > j.maxBytes || (t = JSON.parse(e), We(t, Mn).canonical !== e)))
      return At("$");
    We(t, Mn);
  } catch {
    return At("$");
  }
  if (!t || typeof t != "object" || Array.isArray(t))
    return At("$");
  const n = t;
  if (n.kind !== "zx-ai-review-sidecar-v1" || n.version !== "1.0.0")
    return Sp();
  if (!Ep(t)) return At("$");
  const r = Ft(t);
  return r.capability === "fine-review" && (r.items.length !== r.decisions.length || r.items.length !== r.proposalBinding.operationCount) || r.capability === "coarse-review-unavailable" && r.items.length !== 0 || r.decisions.length !== r.proposalBinding.operationCount || r.items.some(
    (i, o) => i.operationIndex !== o || r.decisions[o]?.operationIndex !== o || r.decisions[o]?.operationIntentDigest !== i.operationIntentDigest || i.fingerprint !== ge("zx-ai-review-item:v1", {
      operationIndex: i.operationIndex,
      operationKind: i.operationKind,
      operationIntentDigest: i.operationIntentDigest,
      decisionKey: i.decisionKey,
      dependencyOperationIndexes: i.dependencyOperationIndexes,
      blockRefs: i.blockRefs,
      hunkRefs: i.hunkRefs,
      appendedAttributionRefs: i.appendedAttributionRefs,
      summary: i.summary,
      noOpReason: i.noOpReason
    })
  ) || r.decisions.some(
    (i, o) => i.operationIndex !== o || i.fingerprint !== ge("zx-ai-review-operation-decision:v1", {
      operationIndex: i.operationIndex,
      operationIntentDigest: i.operationIntentDigest,
      dependencyOperationIndexes: i.dependencyOperationIndexes,
      state: i.state,
      decidedAtRevision: i.decidedAtRevision
    })
  ) || r.auditEntries.some(
    (i, o) => i.sequence !== o || i.fingerprint !== ge("zx-ai-review-audit-entry:v1", {
      sequence: i.sequence,
      kind: i.kind,
      commandId: i.commandId,
      previousSidecarFingerprint: i.previousSidecarFingerprint,
      operationIndexes: i.operationIndexes
    })
  ) || js(mp(r)) !== r.fingerprint ? At("$.fingerprint") : g({ status: "success", sidecar: r });
}, Fp = (e) => {
  const t = e.lifecycle;
  return me(t, [
    "proposalId",
    "revision",
    "status",
    "fingerprint"
  ]) && t.status === "active" && _d(t) && t.proposalId === e.proposal.identity.proposalId && t.fingerprint === Hn({
    proposalId: t.proposalId,
    revision: t.revision,
    status: t.status
  }) && t.revision === e.proposal.lifecycle.revision && t.fingerprint === e.proposal.lifecycle.fingerprint;
}, Cp = (e, t = "undecided", n = null) => {
  const r = {
    operationIndex: e.operationIndex,
    operationIntentDigest: e.intentDigest,
    dependencyOperationIndexes: [...e.dependencyOperationIndexes],
    state: t,
    decidedAtRevision: n
  };
  return g({
    ...r,
    fingerprint: ge(
      "zx-ai-review-operation-decision:v1",
      r
    )
  });
}, Np = (e) => {
  const t = {
    sequence: e.sequence,
    kind: e.kind,
    commandId: e.commandId,
    previousSidecarFingerprint: e.previousSidecarFingerprint,
    operationIndexes: [...e.operationIndexes]
  };
  return g({
    ...t,
    fingerprint: ge(
      "zx-ai-review-audit-entry:v1",
      t
    )
  });
}, Qe = (e, t) => g({
  status: "failure",
  sidecar: null,
  diagnostic: Xn({
    code: e,
    stage: e === "review-dependency-invalid" ? "decision" : "sidecar",
    path: t
  })
}), Mp = (e) => {
  if (!me(e, [
    "identity",
    "policyRef",
    "proposal",
    "lifecycle"
  ]) || !me(e.identity, ["reviewId"]) || !q(e.identity.reviewId))
    return Qe("review-input-invalid", "$");
  if (!Ps(e.policyRef))
    return Qe("review-policy-invalid", "$.policyRef");
  if (!$r(e.proposal) || !$r(e.lifecycle))
    return Qe("review-proposal-invalid", "$.proposal");
  const t = Ns(e.proposal);
  if (t.status !== "success" || t.cacheStatus !== "exact")
    return Qe("review-proposal-invalid", "$.proposal");
  if (!Fp(e))
    return Qe("review-lifecycle-invalid", "$.lifecycle");
  const n = bp(t.proposal.operationProjection);
  if (!n)
    return Qe("review-dependency-invalid", "$.proposal.operationProjection");
  const r = vp(t.proposal);
  if (!r.valid)
    return g({
      status: "failure",
      sidecar: null,
      diagnostic: r.diagnostic
    });
  const i = {
    proposalId: t.proposal.identity.proposalId,
    variantId: t.proposal.identity.variantId,
    proposalFingerprint: t.proposal.fingerprint,
    operationCount: t.proposal.operationProjection.length,
    operationProjectionFingerprint: ge(
      "zx-ai-review-operation-projection:v1",
      t.proposal.operationProjection
    ),
    lifecycleRevision: e.lifecycle.revision,
    lifecycleFingerprint: e.lifecycle.fingerprint,
    baseFingerprint: t.proposal.base.fingerprint,
    documentRevision: t.proposal.base.documentRevision,
    annotationFingerprint: t.proposal.base.annotationFingerprint,
    targetFingerprint: t.proposal.base.targetFingerprint,
    planDigest: t.proposal.base.planDigest,
    resultFingerprint: t.proposal.runtimeExecution.resultFingerprint,
    traceFingerprint: t.proposal.runtimeExecution.trace.fingerprint,
    mappingFingerprint: t.proposal.runtimeExecution.mapping.fingerprint,
    effectFingerprint: t.proposal.effectProof.fingerprint,
    richDiffStatus: t.proposal.richDiff.status,
    richDiffSourceBinding: Ft(
      t.proposal.richDiff.sourceBinding
    ),
    richDiffUnavailableReason: t.proposal.richDiff.status === "unavailable" ? t.proposal.richDiff.reason : null,
    richDiffFingerprint: ge(
      "zx-ai-review-rich-diff-binding:v1",
      t.proposal.richDiff
    )
  }, o = Np({
    sequence: 0,
    kind: "sidecar-created",
    commandId: null,
    previousSidecarFingerprint: null,
    operationIndexes: n.operationIndexes
  }), s = wp({
    kind: "zx-ai-review-sidecar-v1",
    version: "1.0.0",
    identity: Ft(e.identity),
    proposalBinding: g(i),
    policyRef: Ft(e.policyRef),
    profileRef: Ft(t.proposal.richDiff.profileRef),
    revision: 0,
    status: "active",
    capability: r.capability,
    items: r.items,
    decisions: t.proposal.operationProjection.map(
      (a) => Cp(a)
    ),
    auditEntries: [o]
  });
  return s.items.length > j.maxItems || s.decisions.length > j.maxDecisionEntries || hp(s) > j.maxBytes ? Qe("review-budget-exceeded", "$") : fp(s) ? g({ status: "active", sidecar: s }) : Qe("review-input-invalid", "$.identity.reviewId");
}, Pp = /* @__PURE__ */ new WeakMap(), Yi = (e) => `${e.id}\0${e.version}\0${e.fingerprint}`, zp = (e, t) => Yi(e) === Yi(t), jp = (e) => {
  const { fingerprint: t, ...n } = e;
  return e.contractVersion === 1 && ie(e.schemaFingerprint) && ie(e.descriptorFingerprint) && Array.isArray(e.entries) && e.fingerprint === ee("registry", n);
}, Ds = (e, t) => Pp.get(e)?.get(`${t.descriptor}\0${t.nodeType}\0${t.adapterId}`) ?? null, Dp = (e, t) => {
  const n = e.entries.find(
    (s) => F(s.adapter) === F(t.adapter)
  ), r = n?.operations.find(
    (s) => s.name === t.operation
  ), i = n ? Ds(e, {
    descriptor: n.adapter.descriptor,
    nodeType: n.adapter.nodeType,
    adapterId: n.adapter.adapterId
  }) : null, o = i?.operations[t.operation];
  return !n || !r || !i || i.fingerprint !== n.adapter.adapterFingerprint || !o || !zp(r.compiler, o.compiler) ? null : g({ entry: n, operation: r });
}, $s = (e) => ee("runtime-resource-profile-binding", {
  runtimeResourceProfileFingerprint: e.runtimeResourceProfileFingerprint,
  registryFingerprint: e.registryFingerprint,
  adapter: e.adapter,
  operation: e.operation
}), ii = (e, t) => {
  if (e.attrs?.blockId === t) return e;
  for (const n of e.content ?? []) {
    const r = ii(n, t);
    if (r) return r;
  }
  return null;
}, nn = (e) => ee("node-content", e), Bs = (e) => ({
  type: e.type ?? null,
  attrs: Object.keys(e.attrs ?? {}).sort(),
  content: (e.content ?? []).map(Bs),
  textLength: typeof e.text == "string" ? e.text.length : null,
  marks: (e.marks ?? []).map((t) => t.type ?? null)
}), Br = (e) => ee("node-shape", Bs(e)), oi = (e, t) => {
  const n = e.operations.find(
    (r) => r.name === t
  );
  if (!n) throw new TypeError("complex-operation-unsupported");
  return ee("capability", {
    adapter: e.adapter,
    family: e.family,
    address: e.address,
    operation: n
  });
}, $p = (e, t) => {
  let n = e;
  for (const r of t) {
    if (!n) return null;
    n = n.content?.[r];
  }
  return n ?? null;
}, Bp = (e, t, n) => {
  let r = 0;
  const i = (o) => {
    o.attrs?.[t] === n && (r += 1), o.content?.forEach(i);
  };
  return i(e), r;
}, _p = (e, t, n) => {
  let r = 0;
  const i = (s) => s.attrs?.blockId === t ? (r += 1, n) : s.content ? { ...s, content: s.content.map(i) } : s, o = i(e.body.content);
  return {
    matched: r,
    document: {
      ...e,
      body: { ...e.body, content: o }
    }
  };
}, J = (e) => g({ valid: !1, step: null, diagnostics: e }), Vp = (e, t) => {
  if (e.status !== "success" || e.canonicalOutput.byteLength > t)
    return null;
  try {
    const n = JSON.parse(new TextDecoder().decode(e.canonicalOutput));
    if (!pe(n) || typeof n.valid != "boolean" || !Array.isArray(n.diagnostics))
      return null;
    if (n.valid === !1)
      return he(n, ["valid", "plan", "diagnostics"]) && n.plan === null ? n : null;
    if (!he(n, ["valid", "plan", "diagnostics"]) || n.diagnostics.length !== 0 || !pe(n.plan) || !he(n.plan, [
      "contractVersion",
      "nodeFamily",
      "operation",
      "atomicity",
      "effect",
      "targetFingerprint",
      "resultFingerprint",
      "assetsMetaUnchanged"
    ]) || n.plan.contractVersion !== 1 || !["table", "list", "code", "media", "custom"].includes(
      String(n.plan.nodeFamily)
    ) || typeof n.plan.operation != "string" || !["whole-operation", "declared-parts"].includes(
      String(n.plan.atomicity)
    ) || !ie(n.plan.targetFingerprint) || !ie(n.plan.resultFingerprint) || typeof n.plan.assetsMetaUnchanged != "boolean" || !pe(n.plan.effect))
      return null;
    const r = n.plan.effect;
    return r.kind === "replace-block" && he(r, ["kind", "blockId", "node"]) && typeof r.blockId == "string" && pe(r.node) || r.kind === "replace-text" && he(r, [
      "kind",
      "blockId",
      "startOffset",
      "endOffset",
      "text"
    ]) && typeof r.blockId == "string" && Number.isSafeInteger(r.startOffset) && Number.isSafeInteger(r.endOffset) && r.startOffset >= 0 && r.endOffset >= r.startOffset && typeof r.text == "string" ? n : null;
  } catch {
    return null;
  }
}, Lp = (e) => _(
  e.status === "timeout" ? "complex-runner-timeout" : e.status === "cancelled" ? "complex-runner-cancelled" : e.status === "over-limit" ? "complex-limit-exceeded" : "complex-runner-malformed",
  "validation",
  "$.runner"
), qp = (e, t, n, r, i) => {
  const o = e.operation;
  if (e.sourceRegistryFingerprint !== t.fingerprint || e.sourceDescriptorFingerprint !== t.descriptorFingerprint || o.adapter.descriptorFingerprint !== t.descriptorFingerprint || o.target.blockId !== o.preconditions.blockId || o.preconditions.addressFingerprint !== bs(o.target) || o.preconditions.capabilityFingerprint !== oi(i, o.operation))
    return _(
      "complex-capability-drifted",
      "precondition",
      "$.bindings"
    );
  if (r.type !== o.preconditions.nodeType || nn(r) !== o.preconditions.contentFingerprint || Br(r) !== o.preconditions.shapeFingerprint)
    return _(
      "complex-target-drifted",
      "precondition",
      "$.target"
    );
  if (o.target.kind === "validated-path") {
    if (o.target.ancestorFingerprint !== ee("node-ancestor", n) || o.target.nodeTypeFingerprint !== ee("node-type", r.type ?? null) || o.target.contentFingerprint !== nn(r) || o.target.shapeFingerprint !== Br(r))
      return _(
        "complex-target-drifted",
        "precondition",
        "$.target.path"
      );
  } else {
    const s = o.target.localType === "row" ? "rowId" : o.target.localType === "cell" ? "cellId" : o.target.localType === "media" ? "assetId" : "blockId", a = o.target.localType === "code-text" ? o.target.blockId : o.target.localId;
    if (Bp(n, s, a) !== 1)
      return _(
        "complex-target-ambiguous",
        "address",
        "$.target.localId"
      );
    if (o.target.localType === "list-item" && (!o.target.structure || Cr(o.target.structure) !== Cr(
      wd(n, a)
    )))
      return _(
        "complex-target-drifted",
        "precondition",
        "$.target.structure"
      );
  }
  return o.target.kind === "validated-path" && o.target.sourceSnapshotFingerprint !== e.sourceSnapshotFingerprint ? _(
    "complex-target-drifted",
    "precondition",
    "$.target.sourceSnapshotFingerprint"
  ) : null;
}, Kp = (e) => {
  if (!jp(e))
    throw new TypeError("complex-registry-invalid");
  return g({
    registry: e,
    async validateAndPlan(t, n) {
      if (!n || n.isolated !== !0)
        return J([
          _(
            "complex-unsupported-host",
            "validation",
            "$.runner"
          )
        ]);
      const r = Ds(e, {
        descriptor: t.operation.adapter.descriptor,
        nodeType: t.operation.adapter.nodeType,
        adapterId: t.operation.adapter.adapterId
      });
      if (!r)
        return J([
          _(
            "complex-adapter-not-found",
            "registry",
            "$.operation.adapter"
          )
        ]);
      if (r.version !== t.operation.adapter.adapterVersion || r.fingerprint !== t.operation.adapter.adapterFingerprint)
        return J([
          _(
            "complex-adapter-fingerprint-mismatch",
            "registry",
            "$.operation.adapter"
          )
        ]);
      const i = r.operations[t.operation.operation];
      if (!i)
        return J([
          _(
            "complex-operation-unsupported",
            "registry",
            "$.operation.operation"
          )
        ]);
      if (t.operation.target.kind === "validated-path" && (i.stream === "incremental" || i.collaboration === "stable-rebase"))
        return J([
          _(
            "complex-capability-drifted",
            "precondition",
            "$.operation.target.kind"
          )
        ]);
      const o = e.entries.find(
        (k) => k.adapter.adapterFingerprint === r.fingerprint
      );
      if (t.operation.target.kind === "stable-local" && !o.address.stableLocalTypes.includes(
        t.operation.target.localType
      ) || t.operation.target.kind === "validated-path" && !o.address.validatedPathFallback)
        return J([
          _(
            "complex-address-invalid",
            "address",
            "$.operation.target"
          )
        ]);
      const s = ii(
        t.document.body.content,
        t.operation.target.blockId
      );
      if (!s)
        return J([
          _(
            "complex-target-drifted",
            "precondition",
            "$.operation.target.blockId"
          )
        ]);
      const a = t.operation.target.kind === "validated-path" ? $p(s, t.operation.target.path) : s;
      if (!a)
        return J([
          _(
            "complex-target-drifted",
            "address",
            "$.operation.target.path"
          )
        ]);
      const c = qp(
        t,
        e,
        s,
        a,
        o
      );
      if (c) return J([c]);
      if (t.operation.target.kind === "stable-local" && i.stream === "incremental") {
        const k = t.operation.target, w = k.relativeText;
        if (!w || !t.addressResolution)
          return J([
            _(
              "complex-address-invalid",
              "address",
              "$.operation.target.relativeText"
            )
          ]);
        const S = Od({
          address: k,
          expectedBlockId: k.blockId,
          expectedLocalId: k.localId,
          currentCapabilityFingerprint: oi(
            o,
            t.operation.operation
          ),
          resolveAnchor: () => t.addressResolution.resolveRelativeText(w)
        });
        if (S.status === "failure")
          return J([S.diagnostic]);
      }
      let l;
      try {
        Nr(t.operation.payload, i.limits), l = i.decodePayload(t.operation.payload);
      } catch {
        return J([
          _(
            "complex-limit-exceeded",
            "decode",
            "$.operation.payload"
          )
        ]);
      }
      if (!l.valid) return J(l.diagnostics);
      if (r.family === "media") {
        const k = pe(l.value) ? l.value : null, w = typeof k?.assetId == "string" ? k.assetId : typeof a.attrs?.assetId == "string" ? a.attrs.assetId : null, S = w ? t.document.assets.find((E) => E.id === w) : null;
        if (!w || !S || !t.resourceAdmission)
          return J([
            _(
              "complex-resource-not-staged",
              "resource",
              "$.resourceAdmission"
            )
          ]);
        const b = await t.resourceAdmission.port.verify({
          receipt: t.resourceAdmission.receipt,
          expectedPhase: t.resourceAdmission.phase,
          expectedDocumentRevision: t.sourceDocumentRevision,
          expectedAssetId: w,
          expectedAssetFingerprint: ee("asset", S),
          expectedPrincipalFingerprint: t.resourceAdmission.principalFingerprint,
          expectedAdapterFingerprint: r.fingerprint,
          expectedPolicyFingerprint: t.resourceAdmission.policyFingerprint,
          logicalTime: t.resourceAdmission.logicalTime
        });
        if (b.status !== "verified")
          return J([
            _(
              b.status === "unavailable" ? "complex-resource-host-failed" : "complex-resource-receipt-invalid",
              "resource",
              "$.resourceAdmission.receipt"
            )
          ]);
      }
      const p = ee("execution-id", {
        operationIndex: t.operationIndex,
        adapter: t.operation.adapter,
        payload: l.value,
        target: t.operation.target
      }), d = $s({
        runtimeResourceProfileFingerprint: t.resourceProfileFingerprint,
        registryFingerprint: e.fingerprint,
        adapter: o.adapter,
        operation: o.operations.find(
          (k) => k.name === t.operation.operation
        )
      }), f = {
        action: "validate",
        adapter: t.operation.adapter,
        operation: t.operation.operation,
        input: {
          document: t.document,
          target: a,
          address: t.operation.target,
          preconditions: t.operation.preconditions,
          payload: l.value,
          operation: t.operation.operation
        }
      }, u = await n.run({
        executionId: p,
        component: i.compiler,
        canonicalInput: gs(f),
        resourceProfileFingerprint: d,
        timeoutMs: i.limits.timeoutMs,
        maxOutputBytes: i.limits.maxOutputBytes
      }), m = Vp(
        u,
        i.limits.maxOutputBytes
      );
      if (!m)
        return n.terminate(p), J([Lp(u)]);
      if (!m.valid) return J(m.diagnostics);
      const h = m.plan;
      try {
        Nr(
          h,
          i.limits,
          i.limits.maxOutputBytes
        );
      } catch {
        return J([
          _(
            "complex-limit-exceeded",
            "compile",
            "$.plan"
          )
        ]);
      }
      if (h.operation !== t.operation.operation || h.nodeFamily !== r.family || h.targetFingerprint !== nn(a) || h.effect.blockId !== t.operation.target.blockId || h.effect.kind === "replace-block" && (h.effect.node.attrs?.blockId !== t.operation.target.blockId || h.resultFingerprint !== nn(h.effect.node)) || r.family === "media" && h.assetsMetaUnchanged !== !0)
        return J([
          _(
            "complex-plan-nondeterministic",
            "compile",
            "$.plan"
          )
        ]);
      if (h.effect.kind === "replace-block") {
        const k = _p(
          t.document,
          t.operation.target.blockId,
          h.effect.node
        ), w = Jo(
          k.document
        );
        if (k.matched !== 1 || !w.valid)
          return J([
            _(
              "complex-schema-invalid",
              "compile",
              "$.plan.effect.node"
            )
          ]);
      }
      const y = ee(
        "plan-fragment",
        h
      ), x = g({
        operationIndex: t.operationIndex,
        protocolVersion: 2,
        kind: "node.apply",
        adapter: t.operation.adapter,
        target: t.operation.target,
        preconditions: t.operation.preconditions,
        operation: t.operation.operation,
        payload: l.value,
        payloadFingerprint: I(l.value),
        planFragment: h,
        planFragmentFingerprint: y,
        compiler: i.compiler,
        resourceProfileFingerprint: d
      });
      try {
        Cr(x);
      } catch {
        return J([
          _(
            "complex-runner-malformed",
            "compile",
            "$.step"
          )
        ]);
      }
      return g({ valid: !0, step: x, diagnostics: [] });
    }
  });
}, Gn = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.descendants((n, r) => {
    const i = typeof n.attrs.blockId == "string" ? n.attrs.blockId : null;
    if (!i) return;
    if (t.has(i)) throw new TypeError("document-invalid");
    const o = [];
    let s = "";
    n.descendants((a, c) => {
      if (typeof a.attrs.blockId == "string" ? a.attrs.blockId : null) return !1;
      if (a.isText) {
        const p = a.text ?? "";
        return o.push({
          from: r + 1 + c,
          to: r + 1 + c + p.length,
          startOffset: s.length,
          endOffset: s.length + p.length,
          text: p
        }), s += p, !1;
      }
      if (a.type.name === "hardBreak")
        return o.push({
          from: r + 1 + c,
          to: r + 2 + c,
          startOffset: s.length,
          endOffset: s.length + 1,
          text: `
`
        }), s += `
`, !1;
    }), t.set(
      i,
      g({
        blockId: i,
        type: n.type.name,
        pos: r,
        nodeSize: n.nodeSize,
        text: s,
        textSegments: o,
        nodeJSON: n.toJSON()
      })
    );
  }), t;
}, Pn = (e, t) => {
  if (!Number.isInteger(t) || t < 0 || t > e.text.length)
    throw new RangeError("operation-compile-failed");
  if (Pl(e.text, t))
    throw new RangeError("mark-policy-violation");
  if (e.textSegments.length === 0) return e.pos + 1;
  if (t === e.text.length) return e.textSegments.at(-1).to;
  const n = e.textSegments.find(
    (r) => t >= r.startOffset && t < r.endOffset
  );
  if (!n) throw new RangeError("operation-compile-failed");
  return n.from + (t - n.startOffset);
}, le = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), se = (e, t) => {
  const n = Object.keys(e).sort(), r = [...t].sort();
  return n.length === r.length && n.every((i, o) => i === r[o]);
}, Q = (e) => typeof e == "string" && e.length > 0, Jp = (e) => le(e) && se(e, ["blockId", "type", "contentFingerprint"]) && Q(e.blockId) && Q(e.type) && Q(e.contentFingerprint), Up = (e) => le(e) && Object.keys(e).every((t) => ["type", "attrs"].includes(t)) && Q(e.type) && (e.attrs === void 0 || le(e.attrs)), zn = (e) => le(e) && Object.keys(e).every(
  (t) => ["type", "attrs", "content", "marks", "text"].includes(t)
) && Q(e.type) && (e.attrs === void 0 || le(e.attrs)) && (e.text === void 0 || typeof e.text == "string") && (e.marks === void 0 || Array.isArray(e.marks) && e.marks.every(Up)) && (e.content === void 0 || Array.isArray(e.content) && e.content.every(zn)), gt = (e) => typeof e == "string" && /^sha256:[0-9a-f]{64}$/.test(e), Hp = (e) => le(e) && se(e, [
  "id",
  "version",
  "fingerprint",
  "kind",
  "planContractVersion"
]) && Q(e.id) && Q(e.version) && gt(e.fingerprint) && e.kind === "complex-node-compiler" && e.planContractVersion === 1, Wp = (e) => {
  if (!le(e) || !se(e, [
    "contractVersion",
    "nodeFamily",
    "operation",
    "atomicity",
    "effect",
    "targetFingerprint",
    "resultFingerprint",
    "assetsMetaUnchanged"
  ]) || e.contractVersion !== 1 || !["table", "list", "code", "media", "custom"].includes(
    String(e.nodeFamily)
  ) || !Q(e.operation) || !["whole-operation", "declared-parts"].includes(String(e.atomicity)) || !gt(e.targetFingerprint) || !gt(e.resultFingerprint) || typeof e.assetsMetaUnchanged != "boolean" || !le(e.effect))
    return !1;
  const t = e.effect;
  return t.kind === "replace-block" && se(t, ["kind", "blockId", "node"]) && Q(t.blockId) && zn(t.node) || t.kind === "replace-text" && se(t, [
    "kind",
    "blockId",
    "startOffset",
    "endOffset",
    "text"
  ]) && Q(t.blockId) && Number.isSafeInteger(t.startOffset) && Number.isSafeInteger(t.endOffset) && t.startOffset >= 0 && t.endOffset >= t.startOffset && typeof t.text == "string";
}, Xp = (e) => {
  if (!se(e, [
    "operationIndex",
    "protocolVersion",
    "kind",
    "adapter",
    "target",
    "preconditions",
    "operation",
    "payload",
    "payloadFingerprint",
    "planFragment",
    "planFragmentFingerprint",
    "compiler",
    "resourceProfileFingerprint"
  ]) || e.protocolVersion !== 2 || e.kind !== "node.apply" || !xs(e.adapter).valid || !ti(e.target).valid || !ks(e.preconditions).valid || !Q(e.operation) || e.payloadFingerprint !== I(e.payload) || !gt(e.payloadFingerprint) || !Wp(e.planFragment) || !gt(e.planFragmentFingerprint) || e.planFragmentFingerprint !== ee("plan-fragment", e.planFragment) || !Hp(e.compiler) || !gt(e.resourceProfileFingerprint))
    return !1;
  const t = e.planFragment, n = e.preconditions, r = e.target, i = t.effect;
  return t.operation === e.operation && i.blockId === r.blockId && n.blockId === r.blockId;
}, Gp = (e, t) => !le(e) || e.operationIndex !== t ? !1 : e.kind === "node.apply" ? Xp(e) : Jp(e.precondition) ? e.kind === "text.replace" ? !se(e, [
  "operationIndex",
  "kind",
  "target",
  "precondition",
  "text"
]) || !le(e.target) || !se(e.target, ["blockId", "startOffset", "endOffset"]) || !Q(e.target.blockId) || !Number.isSafeInteger(e.target.startOffset) || !Number.isSafeInteger(e.target.endOffset) || e.target.startOffset < 0 || e.target.endOffset < e.target.startOffset ? !1 : typeof e.text == "string" : e.kind === "block.insert" ? se(e, [
  "operationIndex",
  "kind",
  "reference",
  "precondition",
  "block"
]) && le(e.reference) && se(e.reference, ["blockId", "side"]) && Q(e.reference.blockId) && (e.reference.side === "before" || e.reference.side === "after") && zn(e.block) : e.kind === "block.replace" ? se(e, [
  "operationIndex",
  "kind",
  "target",
  "precondition",
  "block"
]) && le(e.target) && se(e.target, ["blockId"]) && Q(e.target.blockId) && zn(e.block) : e.kind === "block.delete" && se(e, ["operationIndex", "kind", "target", "precondition"]) && le(e.target) && se(e.target, ["blockId"]) && Q(e.target.blockId) : !1, si = (e) => le(e) && se(e, [
  "protocolVersion",
  "offsetEncoding",
  "source",
  "steps"
]) && e.protocolVersion === 2 && e.offsetEncoding === "utf-16" && le(e.source) && se(e.source, [
  "snapshotFingerprint",
  "documentRevision",
  "descriptorFingerprint",
  "registryFingerprint"
]) && Q(e.source.snapshotFingerprint) && Q(e.source.documentRevision) && Q(e.source.descriptorFingerprint) && gt(e.source.registryFingerprint) && Array.isArray(e.steps) && e.steps.every(Gp), Zp = (e, t, n) => {
  const r = t.steps.filter(
    (s) => s.kind === "node.apply"
  );
  if (r.length === 0) return;
  const o = Ed(t)?.registry;
  if (!o || o.fingerprint !== t.source.registryFingerprint || o.descriptorFingerprint !== t.source.descriptorFingerprint || o.schemaFingerprint !== Ie.schemaKernelFingerprint)
    throw new TypeError("plan-invalid");
  r.forEach((s) => {
    const a = Dp(o, {
      adapter: s.adapter,
      operation: s.operation
    });
    if (!a) throw new TypeError("plan-invalid");
    const c = ii(
      e.body.content,
      s.target.blockId
    );
    let l = c;
    if (c && s.target.kind === "validated-path")
      for (const f of s.target.path)
        l = l?.content?.[f] ?? null;
    const p = $s({
      runtimeResourceProfileFingerprint: n,
      registryFingerprint: o.fingerprint,
      adapter: a.entry.adapter,
      operation: a.operation
    });
    if (!(s.target.kind === "validated-path" ? a.entry.address.validatedPathFallback === !0 && a.operation.stream !== "incremental" && a.operation.collaboration === "exact-snapshot" : a.entry.address.stableLocalTypes.includes(
      s.target.localType
    )) || !l || s.payloadFingerprint !== I(s.payload) || s.target.kind === "stable-local" && a.entry.adapter.nodeType !== s.preconditions.nodeType || s.preconditions.addressFingerprint !== bs(s.target) || s.preconditions.capabilityFingerprint !== oi(a.entry, s.operation) || F(s.compiler) !== F(a.operation.compiler) || s.planFragment.nodeFamily !== a.entry.family || s.resourceProfileFingerprint !== p || new TextEncoder().encode(F(s.planFragment)).byteLength > a.operation.limits.maxOutputBytes)
      throw new TypeError("plan-invalid");
  });
}, Yp = (e, t, n) => {
  const r = _s(t, n), i = r.blockId, o = e.get(i);
  if (!o || (n.kind === "node.apply" ? n.target.kind === "stable-local" ? n.preconditions.nodeType !== o.type || n.preconditions.contentFingerprint !== nn(o.nodeJSON) || n.preconditions.shapeFingerprint !== Br(o.nodeJSON) : n.target.ancestorFingerprint !== ee("node-ancestor", o.nodeJSON) : n.precondition.type !== o.type) || o.type !== r.type)
    throw new TypeError("plan-invalid");
  return o;
}, _s = (e, t) => {
  const n = t.kind === "block.insert" ? t.reference.blockId : t.target.blockId, r = e.get(n);
  if (t.kind === "node.apply") {
    if (!r || t.preconditions.blockId !== n)
      throw new TypeError("plan-invalid");
    return r;
  }
  const i = t.precondition;
  if (!r || i.blockId !== n || i.type !== r.type || i.contentFingerprint !== r.contentFingerprint)
    throw new TypeError("plan-invalid");
  return r;
}, Qp = (e, t, n) => {
  if (!si(t) || t.source.documentRevision !== I(e))
    throw new TypeError("plan-invalid");
  Zp(
    e,
    t,
    n
  );
  const r = xd(e);
  return t.steps.forEach((i) => _s(r, i)), r;
}, ef = (e, t, n, r, i) => {
  if (!si(n) || n.source.documentRevision !== I(t))
    throw new TypeError("plan-invalid");
  const o = as(e), s = [];
  return n.steps.forEach((a) => {
    const c = o.steps.length, l = Gn(o.doc), p = Yp(l, i, a), d = a.kind === "text.replace" ? { ...a.target, text: a.text } : a.kind === "node.apply" && a.planFragment.effect.kind === "replace-text" ? a.planFragment.effect : null, f = a.kind === "block.replace" ? { node: a.block } : a.kind === "node.apply" && a.planFragment.effect.kind === "replace-block" ? a.planFragment.effect : null;
    if (d) {
      const { startOffset: u, endOffset: m, text: h } = d;
      if (m > p.text.length)
        throw new RangeError("operation-compile-failed");
      if (p.text.slice(u, m) === h) {
        s.push({
          operationIndex: a.operationIndex,
          stepStart: c,
          stepEnd: c,
          noOpReason: "already-equal"
        });
        return;
      }
      const x = Pn(p, u), k = Pn(p, m), w = Ml(o.doc, x, k, h);
      h.length === 0 ? o.delete(x, k) : o.replaceWith(
        x,
        k,
        o.doc.type.schema.text(h, w)
      );
    } else if (a.kind === "block.insert") {
      const u = o.doc.type.schema.nodeFromJSON(a.block);
      if (!u.isBlock || u.type === o.doc.type || F(u.toJSON()) !== F(a.block))
        throw new RangeError("operation-compile-failed");
      const m = typeof u.attrs.blockId == "string" ? u.attrs.blockId : null;
      if (!m || l.has(m))
        throw new RangeError("operation-compile-failed");
      const h = a.reference.side === "before" ? p.pos : p.pos + p.nodeSize;
      o.insert(h, u);
    } else if (f) {
      const u = f.node, m = o.doc.type.schema.nodeFromJSON(u);
      if (!m.isBlock || m.type === o.doc.type || F(m.toJSON()) !== F(u))
        throw new RangeError("operation-compile-failed");
      const h = typeof m.attrs.blockId == "string" ? m.attrs.blockId : null;
      if (!h || h !== p.blockId && l.has(h))
        throw new RangeError("operation-compile-failed");
      o.replaceWith(p.pos, p.pos + p.nodeSize, m);
    } else if (a.kind === "block.delete")
      o.delete(p.pos, p.pos + p.nodeSize);
    else
      throw new TypeError("plan-invalid");
    s.push({
      operationIndex: a.operationIndex,
      stepStart: c,
      stepEnd: o.steps.length
    });
  }), {
    transaction: cs(o, r, s),
    operationSpans: g(s)
  };
};
class Ht extends RangeError {
  constructor(t, n) {
    super(`annotation-invalidated:${n}`), this.annotationId = t, this.reason = n, this.name = "RuntimeAnnotationInvalidatedV2Error";
  }
}
const Qi = (e, t) => {
  const r = [...Gn(e).values()].filter(
    (i) => t >= i.pos && t <= i.pos + i.nodeSize
  ).sort((i, o) => i.nodeSize - o.nodeSize)[0];
  if (!r) return null;
  if (r.textSegments.length === 0)
    return { blockId: r.blockId, offset: 0 };
  if (t <= r.textSegments[0].from)
    return { blockId: r.blockId, offset: 0 };
  if (t >= r.textSegments.at(-1).to)
    return { blockId: r.blockId, offset: r.text.length };
  for (const i of r.textSegments)
    if (t >= i.from && t <= i.to)
      return {
        blockId: r.blockId,
        offset: i.startOffset + Math.min(
          t - i.from,
          i.endOffset - i.startOffset
        )
      };
  return null;
}, tf = (e) => {
  const t = [...Gn(e).values()].sort(
    (i, o) => i.pos - o.pos
  ), n = /* @__PURE__ */ new Map();
  let r = "";
  return t.forEach((i, o) => {
    n.set(i.blockId, r.length), r += i.text, o < t.length - 1 && (r += `
`);
  }), { value: r, starts: n, entries: t };
}, eo = (e, t, n, r) => {
  const i = {
    original: e,
    mapped: t,
    assoc: n,
    deleted: r.deleted,
    deletedBefore: r.deletedBefore,
    deletedAfter: r.deletedAfter,
    deletedAcross: r.deletedAcross
  };
  return g({
    ...i,
    fingerprint: I(i)
  });
}, nf = (e, t, n, r) => {
  const i = Gn(t), o = i.get(e.anchor.start.blockId), s = i.get(e.anchor.end.blockId);
  if (!o || !s)
    throw new Ht(
      e.id,
      "unresolved-original-boundary"
    );
  const a = Pn(
    o,
    e.anchor.start.offset
  ), c = Pn(
    s,
    e.anchor.end.offset
  ), l = r.mapResult(a, 1), p = r.mapResult(c, -1), d = Qi(n, l.pos), f = Qi(n, p.pos);
  if (!d || !f)
    throw new Ht(
      e.id,
      "unresolved-mapped-boundary"
    );
  const u = tf(n), m = u.starts.get(d.blockId), h = u.starts.get(f.blockId);
  if (m === void 0 || h === void 0)
    throw new Ht(
      e.id,
      "non-addressable-content"
    );
  const y = m + d.offset, x = h + f.offset;
  if (x <= y || x > u.value.length)
    throw new Ht(
      e.id,
      "collapsed-or-inverted-range"
    );
  const k = u.value.slice(y, x), w = u.value.slice(
    Math.max(0, y - 32),
    y
  ), S = u.value.slice(x, x + 32), b = eo(
    e.anchor.start,
    d,
    1,
    l
  ), E = eo(e.anchor.end, f, -1, p), V = {
    annotationId: e.id,
    status: "mapped",
    start: b,
    end: E,
    quote: k,
    beforeQuote: w,
    afterQuote: S
  };
  return {
    annotation: g({
      ...e,
      anchor: {
        start: d,
        end: f,
        quote: k,
        beforeQuote: w,
        afterQuote: S
      }
    }),
    evidence: g({
      ...V,
      fingerprint: I(V)
    })
  };
}, rf = (e, t, n, r, i) => {
  const o = new zt(), s = [], a = [], c = [];
  r.forEach((f, u) => {
    const m = o.maps.length;
    f.mapping.maps.forEach((h, y) => {
      const x = h.ranges, k = I({ ranges: x }), w = x.length / 3, S = ot(x);
      i.debit(
        "mappingMaps",
        1,
        `$.mapping[${u}][${y}]`
      ), i.debit(
        "mappingRanges",
        w,
        `$.mapping[${u}][${y}].ranges`
      ), i.debit(
        "mappingBytes",
        S,
        `$.mapping[${u}][${y}].bytes`
      );
      const b = f.mapping.getMirror(y), E = b !== void 0 && b < y ? m + b : void 0;
      if (E !== void 0) {
        const V = [E, o.maps.length];
        i.debit(
          "mappingMirrors",
          1,
          `$.mapping[${u}][${y}].mirror`
        ), i.debit(
          "mappingMirrorBytes",
          ot(V),
          `$.mapping[${u}][${y}].mirrorBytes`
        ), c.push(V);
      }
      o.appendMap(h, E), s.push(k), a.push(w);
    });
  });
  const l = e.annotations.map(
    (f) => nf(f, t, n, o)
  ), p = g({
    ...e,
    body: { format: "json", content: n.toJSON() },
    annotations: l.map((f) => f.annotation)
  }), d = {
    policyRef: an,
    mapOrder: s,
    mapRangeCounts: a,
    mirrorPairs: c,
    annotations: l.map((f) => f.evidence)
  };
  return g({
    resultDocument: p,
    projection: {
      ...d,
      fingerprint: I(d)
    }
  });
}, of = [
  "dateClock",
  "performanceClock",
  "random",
  "locale",
  "timezone",
  "io",
  "network",
  "storage",
  "dom",
  "timer"
], to = (e, t) => {
  let n = e;
  for (; n && !Object.prototype.hasOwnProperty.call(n, t); )
    n = Object.getPrototypeOf(n);
  return n;
}, sf = (e, t) => {
  const n = {
    dateClock: 0,
    performanceClock: 0,
    random: 0,
    locale: 0,
    timezone: 0,
    io: 0,
    network: 0,
    storage: 0,
    dom: 0,
    timer: 0
  }, r = [], i = [], o = (l, p) => {
    throw n[l] += 1, new TypeError(`plugin-conformance-forbidden-capability:${p}`);
  }, s = (l, p, d, f) => {
    const u = to(l, p);
    if (!u) return;
    const m = Object.getOwnPropertyDescriptor(u, p);
    !m || !m.configurable && !m.writable || (Object.defineProperty(u, p, {
      configurable: m.configurable,
      enumerable: m.enumerable,
      writable: m.writable ?? !1,
      value: () => o(d, f)
    }), i.push(f), r.push(() => Object.defineProperty(u, p, m)));
  }, a = (l, p) => {
    const d = Object.getOwnPropertyDescriptor(globalThis, l);
    d && !d.configurable || (Object.defineProperty(globalThis, l, {
      configurable: !0,
      enumerable: d?.enumerable ?? !1,
      get: () => o(p, l)
    }), i.push(l), r.push(() => {
      d ? Object.defineProperty(globalThis, l, d) : delete globalThis[l];
    }));
  }, c = (l, p, d, f, u) => {
    const m = to(l, p);
    if (!m) return;
    const h = Object.getOwnPropertyDescriptor(m, p);
    !h || !h.configurable && !h.writable || (Object.defineProperty(m, p, {
      configurable: h.configurable,
      enumerable: h.enumerable,
      writable: h.writable ?? !1,
      value(...y) {
        return n[d] += 1, u.apply(this, y);
      }
    }), i.push(f), r.push(() => Object.defineProperty(m, p, h)));
  };
  try {
    if (e.locale) {
      const d = e.locale, f = String.prototype.localeCompare;
      c(
        String.prototype,
        "localeCompare",
        "locale",
        `String.localeCompare[${d}]`,
        function(u, m, h) {
          return f.call(
            String(this),
            String(u),
            m ?? d,
            h
          );
        }
      );
    }
    if (e.timezoneOffsetMinutes !== void 0) {
      const d = e.timezoneOffsetMinutes;
      c(
        Date.prototype,
        "getTimezoneOffset",
        "timezone",
        `Date.getTimezoneOffset[${d}]`,
        () => d
      );
    }
    for (const d of e.traps)
      d === "dateClock" ? s(Date, "now", d, "Date.now") : d === "performanceClock" && typeof performance == "object" ? s(performance, "now", d, "performance.now") : d === "random" ? s(Math, "random", d, "Math.random") : d === "locale" ? (s(Intl, "DateTimeFormat", d, "Intl.DateTimeFormat"), s(
        String.prototype,
        "localeCompare",
        d,
        "String.localeCompare"
      )) : d === "timezone" ? s(
        Date.prototype,
        "getTimezoneOffset",
        d,
        "Date.getTimezoneOffset"
      ) : d === "network" ? (a("fetch", d), a("WebSocket", d)) : d === "storage" ? (a("localStorage", d), a("sessionStorage", d)) : d === "dom" ? a("document", d) : d === "timer" ? (a("setTimeout", d), a("setInterval", d)) : d === "io" && (a("XMLHttpRequest", d), a("FileReader", d));
    const l = t(), p = of.reduce(
      (d, f) => d + n[f],
      0
    );
    return {
      value: l,
      forbiddenTrapCounters: Object.freeze({ ...n }),
      forbiddenTrapCalls: p,
      guardedCapabilities: Object.freeze([...i].sort())
    };
  } finally {
    for (const l of r.reverse()) l();
  }
}, ai = g([
  "baseline",
  "throwing-date-clock",
  "throwing-performance-clock",
  "locale-en",
  "locale-zh",
  "timezone-utc",
  "timezone-asia-shanghai",
  "poisoned-random",
  "io-network-storage-dom-timer-traps"
]), af = g({
  publicReceiptType: "ResolvedRuntimeReceiptV2",
  requiredFields: [
    "conformanceReceiptRefs",
    "conformanceEnvironmentReceiptRefs",
    "environment",
    "adapterExecutionIdentity",
    "matrixRowFingerprint"
  ]
}), et = (e) => {
  const t = ["root"], n = e.plugins.map(() => 0), r = /* @__PURE__ */ new Set();
  let i = 0, o = "fixed-point", s = !1;
  for (; ; ) {
    let c = !1;
    for (const [l, p] of e.plugins.entries()) {
      if (n[l] >= t.length) continue;
      const d = t.slice(n[l]), f = I({
        plugin: p.id,
        visible: d,
        transactions: t,
        seen: n
      });
      if (r.has(f)) {
        o = "cycle-detected", s = !0;
        break;
      }
      r.add(f), i += 1, n[l] = t.length;
      const u = p.append(d, t);
      if (u) {
        if (t.includes(u)) {
          o = "cycle-detected", s = !0;
          break;
        }
        if (e.filter && !e.filter(u)) {
          o = "filter-rejected", s = !0;
          break;
        }
        if (t.length >= (e.maxTransactions ?? 16)) {
          o = "budget-exceeded", s = !0;
          break;
        }
        t.push(u), n[l] = t.length, c = !0;
      }
    }
    if (s || !c && n.every((l) => l === t.length)) break;
  }
  const a = {
    fixture: e.id,
    status: o,
    transactions: t,
    hookCalls: i
  };
  return g({
    ...a,
    outcomeFingerprint: I(a)
  });
}, _r = g([
  et({ id: "no-op", plugins: [] }),
  et({
    id: "single-append",
    plugins: [
      {
        id: "a",
        append: (e) => e.includes("root") ? "a1" : null
      }
    ]
  }),
  et({
    id: "multi-plugin-chain",
    plugins: [
      {
        id: "a",
        append: (e) => e.includes("root") ? "a1" : null
      },
      {
        id: "b",
        append: (e) => e.includes("a1") ? "b1" : null
      }
    ]
  }),
  et({
    id: "same-plugin-repeat",
    plugins: [
      {
        id: "repeat-a",
        append: (e, t) => (e.includes("root") || e.some((n) => n.startsWith("pulse-"))) && t.filter((n) => n.startsWith("repeat-")).length < 3 ? `repeat-${t.length}` : null
      },
      {
        id: "pulse-b",
        append: (e, t) => e.some((n) => n.startsWith("repeat-")) && t.filter((n) => n.startsWith("pulse-")).length < 2 ? `pulse-${t.length}` : null
      }
    ]
  }),
  et({
    id: "filter-reject",
    plugins: [{ id: "reject", append: () => "rejected" }],
    filter: () => !1
  }),
  et({
    id: "cycle-a-b-a",
    plugins: [
      {
        id: "cycle-a",
        append: (e) => e.includes("root") || e.includes("b") ? "a" : null
      },
      {
        id: "cycle-b",
        append: (e) => e.includes("a") ? "b" : null
      }
    ],
    maxTransactions: 8
  }),
  et({
    id: "monotonic-runaway",
    plugins: [
      {
        id: "runaway-a",
        append: (e, t) => e.includes("root") || e.some((n) => n.startsWith("b")) ? `a${t.length}` : null
      },
      {
        id: "runaway-b",
        append: (e, t) => e.some((n) => n.startsWith("a")) ? `b${t.length}` : null
      }
    ],
    maxTransactions: 4
  }),
  et({
    id: "fixed-point",
    plugins: [
      {
        id: "fixed",
        append: (e, t) => t.length === 1 ? "fixed" : null
      }
    ]
  })
]), Rt = (e, t, n) => {
  const r = {
    doc: e,
    selection: H.atStart(e),
    storedMarks: null
  };
  return t && (r[t] = n), r;
}, no = (e) => e?.steps.map((t) => t.toJSON()) ?? [], cf = (e) => {
  const t = Ur(), n = t.node("doc", null, [
    t.node("paragraph", { textAlign: null, blockId: "p_conformance" }, [
      t.text("a")
    ])
  ]), r = Rt(n), i = e.plugin.spec.state;
  if (!i) throw new TypeError("plugin-conformance-missing");
  const o = e.plugin.key, s = i.init({ schema: t }, r), a = Rt(n, o, s), c = as(a).insertText("x", 2);
  cs(c, "runtime-plugin-conformance-v2", [
    { operationIndex: 0, stepStart: 0, stepEnd: 1 }
  ]);
  const l = Rt(
    c.doc,
    o,
    s
  ), p = e.plugin.spec.filterTransaction?.(c, a) ?? !0, d = e.projectAfterApply(a, c), f = i.apply(
    c,
    s,
    a,
    l
  ), u = Rt(c.doc, o, f), m = e.plugin.spec.appendTransaction?.(
    [c],
    a,
    u
  ) ?? null;
  let h = f, y = u, x = null;
  if (m) {
    Qr(m, {
      executionId: "runtime-plugin-conformance-v2",
      sequence: 1,
      pluginInstanceId: e.instanceId,
      pluginOrder: e.order,
      visibleTransactionRange: [0, 0],
      operationIndexes: [0]
    }), x = e.projectAfterApply(u, m);
    const Ge = Rt(
      m.doc,
      o,
      f
    );
    h = i.apply(
      m,
      f,
      u,
      Ge
    ), y = Rt(
      m.doc,
      o,
      h
    );
  }
  const k = e.project(y), w = e.effect(m ?? c), S = {
    rootFilterAccepted: p,
    appendReturned: m !== null
  }, b = {
    root: no(c),
    appended: no(m)
  }, E = {
    root: c.getMeta(xt) ?? null,
    appended: m?.getMeta(Xe) ?? null
  }, V = {
    initialized: s,
    afterRoot: f,
    afterAppend: h,
    projected: k,
    anticipatedRoot: d,
    anticipatedAppend: x
  }, xe = [
    { phase: "state-init", fingerprint: I(s) },
    {
      phase: "filter-root",
      fingerprint: I(p)
    },
    { phase: "state-apply-root", fingerprint: I(f) },
    {
      phase: "append-return",
      fingerprint: I(m !== null)
    },
    {
      phase: "state-apply-appended",
      fingerprint: I(h)
    },
    { phase: "project", fingerprint: I(k) },
    { phase: "effect", fingerprint: I(w) }
  ], oe = {
    pluginInstanceId: e.instanceId,
    pluginOrder: e.order,
    returnProjection: S,
    stepsProjection: b,
    metaProjection: E,
    stateProjection: V,
    effectProjection: w,
    traceProjection: xe,
    returnFingerprint: I(S),
    stepsFingerprint: I(b),
    metaFingerprint: I(E),
    stateProjectionFingerprint: I(V),
    traceFingerprint: I(xe)
  };
  return g({
    ...oe,
    outcomeFingerprint: I(oe)
  });
}, Be = g({
  kind: "environment-harness",
  id: "zx.text-editor.runtime-conformance.environment-harness",
  version: "2.0.0",
  implementationSourceFingerprint: jc
}), Vs = g([
  {
    environment: "baseline",
    adapterRef: Be,
    configuration: { ambient: "baseline" },
    traps: []
  },
  {
    environment: "throwing-date-clock",
    adapterRef: Be,
    configuration: { dateClock: "throw-on-read" },
    traps: ["dateClock"]
  },
  {
    environment: "throwing-performance-clock",
    adapterRef: Be,
    configuration: { performanceClock: "throw-on-read" },
    traps: ["performanceClock"]
  },
  {
    environment: "locale-en",
    adapterRef: Be,
    configuration: { locale: "en", localeAccess: "configured-default" },
    traps: [],
    locale: "en"
  },
  {
    environment: "locale-zh",
    adapterRef: Be,
    configuration: { locale: "zh", localeAccess: "configured-default" },
    traps: [],
    locale: "zh"
  },
  {
    environment: "timezone-utc",
    adapterRef: Be,
    configuration: { timezone: "UTC", offsetMinutes: 0 },
    traps: [],
    timezoneOffsetMinutes: 0
  },
  {
    environment: "timezone-asia-shanghai",
    adapterRef: Be,
    configuration: {
      timezone: "Asia/Shanghai",
      offsetMinutes: -480
    },
    traps: [],
    timezoneOffsetMinutes: -480
  },
  {
    environment: "poisoned-random",
    adapterRef: Be,
    configuration: { random: "throw-on-read" },
    traps: ["random"]
  },
  {
    environment: "io-network-storage-dom-timer-traps",
    adapterRef: Be,
    configuration: { ambientCapabilities: "throw-on-read" },
    traps: ["io", "network", "storage", "dom", "timer"]
  }
]);
if (F(
  Vs.map((e) => e.environment)
) !== F(ai))
  throw new TypeError("plugin-conformance-environment-registry-drift");
const Ls = () => {
  const e = Vs.map((r) => {
    const i = I({
      adapterRef: r.adapterRef,
      configuration: r.configuration,
      traps: r.traps
    }), o = sf(
      {
        traps: r.traps,
        ...r.locale ? { locale: r.locale } : {},
        ...r.timezoneOffsetMinutes !== void 0 ? { timezoneOffsetMinutes: r.timezoneOffsetMinutes } : {}
      },
      () => at.map(cf)
    ), s = I({
      adapterRef: r.adapterRef,
      environmentConfigurationFingerprint: i,
      guardedCapabilities: o.guardedCapabilities,
      forbiddenTrapCounters: o.forbiddenTrapCounters,
      pluginOutcomeFingerprints: o.value.map(
        (c) => c.outcomeFingerprint
      )
    }), a = {
      environment: r.environment,
      adapterRef: r.adapterRef,
      environmentConfigurationFingerprint: i,
      adapterExecutionIdentity: s,
      guardedCapabilities: o.guardedCapabilities,
      pluginOutcomes: o.value,
      forbiddenTrapCounters: o.forbiddenTrapCounters,
      forbiddenTrapCalls: o.forbiddenTrapCalls
    };
    return g({
      ...a,
      outcomeFingerprint: I(a)
    });
  }), t = e.reduce(
    (r, i) => r + i.forbiddenTrapCalls,
    0
  ), n = {
    environmentOutcomes: e,
    fixtureOutcomes: _r,
    forbiddenTrapCalls: t
  };
  return g({
    ...n,
    outcomeFingerprint: I(n)
  });
}, qs = Ls(), Ks = (e) => {
  const t = e.environmentOutcomes[0];
  if (e.forbiddenTrapCalls !== 0 || e.environmentOutcomes.length !== ai.length || !t || e.fixtureOutcomes.length !== _r.length || F(e.fixtureOutcomes) !== F(_r) || e.environmentOutcomes.some(
    (n) => n.pluginOutcomes.length !== at.length || n.forbiddenTrapCalls !== 0 || Object.values(n.forbiddenTrapCounters).some((r) => r !== 0) || n.pluginOutcomes.some(
      (r, i) => r.outcomeFingerprint !== t.pluginOutcomes[i].outcomeFingerprint
    )
  ))
    throw new TypeError("plugin-conformance-missing");
};
Ks(qs);
const Js = (e, t) => {
  const n = t.environmentOutcomes.map((i) => ({
    environment: i.environment,
    adapterRef: i.adapterRef,
    environmentConfigurationFingerprint: i.environmentConfigurationFingerprint,
    adapterExecutionIdentity: i.adapterExecutionIdentity,
    guardedCapabilities: i.guardedCapabilities,
    observedOutcome: i.pluginOutcomes[e.order],
    forbiddenTrapCounters: i.forbiddenTrapCounters,
    forbiddenTrapCalls: i.forbiddenTrapCalls,
    matrixRowFingerprint: i.outcomeFingerprint
  })), r = {
    receiptRef: e.conformanceReceiptRef,
    pluginInstanceId: e.instanceId,
    pluginOrder: e.order,
    componentFingerprint: e.componentRef.fingerprint,
    componentRefs: e.componentRefs,
    adapterFingerprint: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
    fixtureCorpusFingerprint: I({
      fixtures: t.fixtureOutcomes
    }),
    fixtureOutcomes: t.fixtureOutcomes,
    declarationContractFingerprint: I(
      af
    ),
    forbiddenTrapCalls: t.forbiddenTrapCalls,
    environments: ai,
    environmentOutcomes: n,
    verificationAlgorithm: "recompute-independent-environment-matrix-rows-v3",
    status: "certified"
  };
  return g({
    ...r,
    outcomeFingerprint: I(r)
  });
}, lf = g(
  at.map(
    (e) => Js(e, qs)
  )
), df = (e, t) => e.kind === t.kind && e.id === t.id && e.version === t.version && e.fingerprint === t.fingerprint, pf = (e = lf) => {
  if (e.length !== at.length)
    throw new TypeError("plugin-conformance-missing");
  const t = Ls();
  Ks(t);
  for (const [n, r] of at.entries()) {
    const i = e[n], o = Js(r, t), s = Object.values(r.componentRefs), a = r.componentRef.dependencies;
    if (F(i) !== F(o) || i.status !== "certified" || i.forbiddenTrapCalls !== 0 || i.environmentOutcomes.length !== t.environmentOutcomes.length || i.environmentOutcomes.some(
      (c) => c.forbiddenTrapCalls !== 0 || Object.values(c.forbiddenTrapCounters).some((l) => l !== 0)
    ) || i.pluginOrder !== n || s.some(
      (c) => !a.some(
        (l) => df(l, c)
      )
    ))
      throw new TypeError("plugin-conformance-missing");
  }
  return e;
};
g({
  synchronousHookInterruption: "not-supported-in-same-isolate",
  permittedMitigation: "package-owned-certified-code-only",
  hostTerminationOutcome: "safety-watchdog-abort",
  replayableSuccessAllowed: !1
});
const ff = [
  "kind",
  "version",
  "schemaSemantics",
  "operationProtocol",
  "executionClosure",
  "mappingPolicy",
  "transactionPolicy",
  "resourceProfile",
  "derivedViewProfiles",
  "fingerprints"
], uf = [
  "kind",
  "id",
  "version",
  "fingerprint",
  "dependencies"
], jn = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), Dn = (e, t) => {
  const n = Object.keys(e).sort(), r = [...t].sort();
  return n.length === r.length && n.every((i, o) => i === r[o]);
}, ce = (e, t, n) => g({
  code: e,
  stage: "manifest",
  path: t,
  ...n ? { componentId: n } : {}
}), we = (e) => `${e.kind}:${e.id}`, ro = (e) => jn(e) && Dn(e, uf) && typeof e.kind == "string" && typeof e.id == "string" && typeof e.version == "string" && typeof e.fingerprint == "string" && Array.isArray(e.dependencies) && e.dependencies.every(
  (t) => jn(t) && Dn(t, ["kind", "id", "version", "fingerprint"]) && typeof t.kind == "string" && typeof t.id == "string" && typeof t.version == "string" && typeof t.fingerprint == "string"
), hf = (e) => {
  const t = [
    e.schemaSemantics,
    e.operationProtocol,
    e.executionClosure,
    e.mappingPolicy,
    e.transactionPolicy,
    e.resourceProfile
  ], n = I({
    domain: "zx-runtime-execution-semantics:v2",
    components: t
  }), r = I({
    domain: "zx-runtime-observational-profile:v2",
    components: [
      sn,
      Gr
    ]
  }), i = I({
    domain: "zx-runtime-derived-view-profile:v2",
    components: e.derivedViewProfiles
  }), o = {
    kind: e.kind,
    version: e.version,
    schemaSemantics: e.schemaSemantics,
    operationProtocol: e.operationProtocol,
    executionClosure: e.executionClosure,
    mappingPolicy: e.mappingPolicy,
    transactionPolicy: e.transactionPolicy,
    resourceProfile: e.resourceProfile,
    derivedViewProfiles: e.derivedViewProfiles,
    fingerprints: {
      executionSemanticsFingerprint: n,
      observationalProfileFingerprint: r,
      derivedViewFingerprint: i
    }
  };
  return g({
    ...o.fingerprints,
    runtimeManifestFingerprint: I({
      domain: "zx-runtime-manifest:v2",
      manifest: o
    })
  });
}, mf = (e) => {
  try {
    F(e);
  } catch {
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce("runtime-manifest-invalid", "$")
    };
  }
  if (!jn(e) || !Dn(e, ff))
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce("runtime-manifest-invalid", "$")
    };
  if (e.kind !== "zx-text-editor-runtime-manifest-v2" || e.version !== "2.0.0")
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce("runtime-component-unsupported", "$.version")
    };
  const t = [
    e.schemaSemantics,
    e.operationProtocol,
    e.executionClosure,
    e.mappingPolicy,
    e.transactionPolicy,
    e.resourceProfile
  ];
  if (!t.every(ro) || !Array.isArray(e.derivedViewProfiles) || !e.derivedViewProfiles.every(ro))
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce("runtime-manifest-invalid", "$.components")
    };
  if (!jn(e.fingerprints) || !Dn(e.fingerprints, [
    "runtimeManifestFingerprint",
    "executionSemanticsFingerprint",
    "observationalProfileFingerprint",
    "derivedViewFingerprint"
  ]))
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce("runtime-manifest-invalid", "$.fingerprints")
    };
  const n = [
    ...t,
    ...e.derivedViewProfiles
  ], r = [
    Ce.schemaSemantics,
    Ce.operationProtocol,
    Ce.executionClosure,
    Ce.mappingPolicy,
    Ce.transactionPolicy,
    Ce.resourceProfile
  ], i = t.find(
    (f, u) => we(f) !== we(r[u])
  );
  if (i)
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce(
        "runtime-component-unsupported",
        "$.components",
        i.id
      )
    };
  const o = n.find(
    (f, u) => n.findIndex((m) => we(m) === we(f)) !== u
  );
  if (o)
    return {
      valid: !1,
      manifest: null,
      diagnostic: ce(
        "runtime-manifest-invalid",
        "$.components",
        o.id
      )
    };
  const s = new Map(
    Ci.map((f) => [we(f), f])
  );
  n.forEach((f) => s.set(we(f), f));
  const a = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = (f) => {
    const u = we(f);
    if (a.has(u))
      return ce("runtime-manifest-invalid", "$.dependencies", f.id);
    if (c.has(u)) return null;
    a.add(u);
    const m = Ci.find(
      (h) => we(h) === u && h.version === f.version
    );
    if (!m)
      return ce(
        "runtime-component-unsupported",
        "$.components",
        f.id
      );
    if (m && m.fingerprint !== f.fingerprint)
      return ce(
        "runtime-fingerprint-mismatch",
        "$.components",
        f.id
      );
    if (m) {
      const h = f.dependencies.map(we), y = m.dependencies.map(we);
      if (h.length !== y.length || h.some(
        (x, k) => x !== y[k]
      ))
        return ce(
          "runtime-manifest-invalid",
          "$.dependencies.order",
          f.id
        );
    }
    for (const h of f.dependencies) {
      const y = s.get(we(h));
      if (!y)
        return ce(
          "runtime-component-unsupported",
          "$.dependencies",
          h.id
        );
      if (y.version !== h.version || y.fingerprint !== h.fingerprint)
        return ce(
          "runtime-fingerprint-mismatch",
          "$.dependencies",
          h.id
        );
      const x = l(y);
      if (x) return x;
    }
    return a.delete(u), c.add(u), null;
  };
  for (const f of n) {
    const u = l(f);
    if (u) return { valid: !1, manifest: null, diagnostic: u };
  }
  const p = e, d = hf(p);
  for (const f of Object.keys(d))
    if (p.fingerprints[f] !== d[f])
      return {
        valid: !1,
        manifest: null,
        diagnostic: ce(
          "runtime-fingerprint-mismatch",
          `$.fingerprints.${f}`
        )
      };
  return { valid: !0, manifest: g(p), diagnostic: null };
}, gf = (e) => {
  const t = mf(
    Ce
  );
  return t.valid ? e.kind !== Nt.kind || e.version !== Nt.version || e.fingerprint !== Nt.fingerprint ? {
    status: "failure",
    diagnostic: ce("runtime-fingerprint-mismatch", "$.runtime")
  } : { status: "resolved", manifest: t.manifest } : { status: "failure", diagnostic: t.diagnostic };
}, mn = (e, t, n = []) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const r = Object.keys(e);
  return t.every((i) => r.includes(i)) && r.every((i) => t.includes(i) || n.includes(i));
}, yf = (e) => mn(e, ["runtime", "baseDocument", "plan", "context"]) && mn(e.runtime, ["kind", "version", "fingerprint"]) && e.runtime.kind === "zx-text-editor-runtime-manifest-v2" && e.runtime.version === "2.0.0" && typeof e.runtime.fingerprint == "string" && mn(e.context, ["protocol"], ["intentRef"]) && e.context.protocol === "zx-runtime-execution-context-v1" && (!e.context.intentRef || mn(e.context.intentRef, ["id", "version", "fingerprint"]) && typeof e.context.intentRef.id == "string" && typeof e.context.intentRef.version == "string" && typeof e.context.intentRef.fingerprint == "string") && si(e.plan), Ke = (e, t, n = {}) => g({
  status: "failure",
  code: t,
  diagnostic: ll(e, t, n),
  resultDocument: null,
  trace: null,
  replayEligibility: "none"
}), bf = (e, t) => {
  if (e instanceof Or)
    return Ke(t, e.code, e.diagnostic);
  if (e instanceof Ve)
    return Ke(t, e.code, {
      stage: "driver",
      path: e.path
    });
  if (e instanceof Ht)
    return Ke(t, "annotation-invalidated", {
      stage: "mapping",
      path: "$.baseDocument.annotations",
      fingerprintPrefix: I(e.annotationId).slice(0, 20)
    });
  const n = e instanceof Error ? e.message : "", r = n.includes("mark-policy-violation") ? "mark-policy-violation" : n.includes("plan-invalid") ? "plan-invalid" : n.includes("operation-compile-failed") ? "operation-compile-failed" : n.includes("transaction-time-invalid") ? "transaction-time-invalid" : n.includes("transaction-meta-invalid") ? "transaction-meta-invalid" : n.includes("transaction-attribution-invalid") ? "transaction-attribution-invalid" : "runtime-internal-failure";
  return Ke(t, r);
}, xf = (e) => {
  const t = ol();
  try {
    rn(e, {
      maxBytes: nt.inputBytes,
      maxDepth: nt.inputDepth,
      maxArrayEntries: nt.inputKeys,
      maxObjectKeys: nt.inputKeys,
      maxTotalObjectKeys: nt.inputKeys
    });
  } catch {
    return Ke(t, "plan-invalid", {
      stage: "stage-1",
      path: "$"
    });
  }
  if (!yf(e)) return Ke(t, "plan-invalid");
  const n = gf(e.runtime);
  if (n.status === "failure")
    return Ke(
      t,
      n.diagnostic.code,
      n.diagnostic
    );
  const r = Tn(e.baseDocument);
  if (!r.valid)
    return Ke(t, "document-invalid", {
      stage: "stage-1",
      path: r.issues[0]?.path ?? "$.baseDocument"
    });
  try {
    cl(
      t,
      e,
      e.baseDocument,
      e.plan,
      at.length
    );
    const i = Qp(
      e.baseDocument,
      e.plan,
      n.manifest.resourceProfile.fingerprint
    ), o = pf(), a = Ur().nodeFromJSON(e.baseDocument.body.content), c = dt.create({
      doc: a,
      plugins: at.map(
        (k) => k.plugin
      )
    }), l = I({
      domain: "zx-runtime-execution-id:v2",
      runtime: e.runtime,
      baseDocument: e.baseDocument,
      plan: e.plan,
      context: e.context
    }), p = ef(
      c,
      e.baseDocument,
      e.plan,
      l,
      i
    ), d = Fl(
      c,
      p.transaction,
      p.operationSpans,
      l,
      t
    ), f = rf(
      e.baseDocument,
      a,
      d.state.doc,
      d.transactions,
      t
    ), u = Tn(f.resultDocument);
    if (!u.valid)
      return Ke(t, "document-invalid", {
        stage: "serialization",
        path: u.issues[0]?.path ?? "$.resultDocument"
      });
    const m = I(f.resultDocument), h = {
      manifestRef: Nt,
      executionSemanticsFingerprint: n.manifest.fingerprints.executionSemanticsFingerprint,
      observationalProfileFingerprint: n.manifest.fingerprints.observationalProfileFingerprint,
      derivedViewFingerprint: n.manifest.fingerprints.derivedViewFingerprint,
      adapterRef: vt,
      conformanceReceiptRefs: o.map(
        (k) => k.outcomeFingerprint
      ),
      conformanceEnvironmentReceiptRefs: o[0]?.environmentOutcomes.map((k, w) => ({
        environment: k.environment,
        adapterExecutionIdentity: k.adapterExecutionIdentity,
        matrixRowFingerprint: I({
          environment: k.environment,
          adapterExecutionIdentity: k.adapterExecutionIdentity,
          pluginRows: o.map(
            (S) => S.environmentOutcomes[w].matrixRowFingerprint
          )
        })
      })) ?? []
    };
    t.debit(
      "traceBytes",
      ot(h),
      "$.receipt"
    );
    const y = pl(
      {
        executionId: l,
        manifest: n.manifest.fingerprints,
        entries: d.entries,
        mapping: f.projection,
        resultFingerprint: m
      },
      t
    ), x = {
      status: "success",
      runtime: h,
      resultDocument: f.resultDocument,
      resultFingerprint: m,
      trace: y,
      mapping: f.projection,
      pluginState: d.pluginState,
      resources: t.snapshot(),
      replayEligibility: "exact-runtime-only"
    };
    return g(x);
  } catch (i) {
    return bf(i, t);
  }
}, Us = "1.0.0", de = g({
  maxBytes: 2e6,
  maxDepth: 64,
  maxArrayEntries: 8e3,
  maxObjectKeys: 48,
  maxTotalObjectKeys: 8e4,
  maxRequests: 32,
  maxAttempts: 64,
  maxEventsPerAttempt: 2048,
  maxChunkBytes: 4096,
  maxProjectionTextBytes: 64e3,
  maxProjectionSegments: 256,
  maxToolSummaries: 64,
  maxAuditEntries: 2048,
  maxCheckpointBytes: 512e3,
  maxDiagnostics: 32,
  maxRetries: 3,
  maxHandoffs: 32,
  maxIdLength: 160,
  maxDiagnosticPathLength: 240,
  maxLogicalDuration: 86400
}), br = g({
  id: "zx.ai.session-policy",
  version: Us,
  limits: de,
  retryableTerminalReasons: [
    "transport-failed",
    "transport-disconnected",
    "resource-exceeded",
    "malformed"
  ],
  resumeCapability: "resume:same-attempt-checkpoint-v1",
  oneActiveRequest: !0
});
g({
  id: br.id,
  version: br.version,
  fingerprint: I({
    domain: "zx-ai-session/v1/policy",
    value: br
  })
});
const io = g({
  maxBytes: de.maxBytes,
  maxDepth: de.maxDepth,
  maxArrayEntries: de.maxArrayEntries,
  maxObjectKeys: de.maxObjectKeys,
  maxTotalObjectKeys: de.maxTotalObjectKeys
}), kf = /* @__PURE__ */ new Set([
  "editor",
  "view",
  "state",
  "transaction",
  "dispatch",
  "abortController",
  "signal",
  "socket",
  "websocket",
  "fetch",
  "client",
  "sdk",
  "apiKey",
  "secret",
  "token",
  "password",
  "callback",
  "onChunk",
  "onFinish"
]), Hs = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), kt = (e, t, n = []) => Hs(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), If = (e) => typeof e == "string" && e.trim().length > 0, Pt = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, Oe = (e) => typeof e == "string" && e.length > 0 && e.length <= de.maxIdLength && /^[A-Za-z0-9_.:-]+$/.test(e), oo = (e) => typeof e == "string" && e.length > 7 && e.length <= de.maxIdLength * 2 && /^sha256:[A-Za-z0-9_.:-]+$/.test(e), Zn = (e, t) => I({ domain: e, value: t }), Ws = (e) => {
  rn(e, io);
  const { canonical: t } = We(
    e,
    io
  );
  return g(JSON.parse(t));
}, vf = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, xr = /^[A-Za-z0-9_.:-]{1,160}$/, U = (e) => {
  const t = (n) => n && xr.test(n) ? Zt(
    I({ domain: "zx-ai-session-safe-ref:v1", value: n })
  ) : void 0;
  return g({
    code: e.code,
    stage: e.stage,
    path: vf.test(e.path) ? e.path.slice(0, de.maxDiagnosticPathLength) : "$",
    ...Number.isSafeInteger(e.count) && e.count >= 0 ? { count: Math.min(e.count, 1e6) } : {},
    ...typeof e.fingerprint == "string" ? { fingerprintPrefix: Zt(e.fingerprint) } : {},
    ...t(e.sessionRef) ? { sessionRef: t(e.sessionRef) } : {},
    ...t(e.requestRef) ? { requestRef: t(e.requestRef) } : {},
    ...t(e.attemptRef) ? { attemptRef: t(e.attemptRef) } : {},
    ...e.capability && xr.test(e.capability) ? { capability: e.capability.slice(0, 160) } : {},
    ...e.terminalReason && xr.test(e.terminalReason) ? { terminalReason: e.terminalReason.slice(0, 160) } : {}
  });
}, Vr = (e, t, n, r) => {
  if (e == null) return null;
  if (typeof e == "function")
    return U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (typeof e != "object") return null;
  if (r > de.maxDepth || n.active.has(e))
    return U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (n.active.add(e), typeof e.nodeType == "number" || typeof globalThis.Element == "function") {
    const o = globalThis.Element;
    if (o && e instanceof o)
      return U({
        code: "session-input-invalid",
        stage: "contract",
        path: t
      });
  }
  if (typeof AbortController < "u" && e instanceof AbortController)
    return U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (typeof AbortSignal < "u" && e instanceof AbortSignal)
    return U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)
    return U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (Array.isArray(e)) {
    if (n.totalArrayEntries += e.length, e.length > de.maxArrayEntries || n.totalArrayEntries > de.maxArrayEntries)
      return U({
        code: "session-resource-exceeded",
        stage: "contract",
        path: t,
        count: n.totalArrayEntries
      });
    for (const [o, s] of e.entries()) {
      const a = Vr(
        s,
        `${t}[${o}]`,
        n,
        r + 1
      );
      if (a)
        return n.active.delete(e), a;
    }
    return n.active.delete(e), null;
  }
  if (!Hs(e))
    return n.active.delete(e), U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  const i = Object.entries(e);
  if (n.totalKeys += i.length, i.length > de.maxObjectKeys || n.totalKeys > de.maxTotalObjectKeys)
    return U({
      code: "session-resource-exceeded",
      stage: "contract",
      path: t,
      count: n.totalKeys
    });
  for (const [o, s] of i) {
    if (kf.has(o) || o === "__proto__" || o === "constructor" || o === "prototype")
      return n.active.delete(e), U({
        code: "session-input-invalid",
        stage: "contract",
        path: `${t}.${o}`
      });
    const a = Vr(
      s,
      `${t}.${o}`,
      n,
      r + 1
    );
    if (a)
      return n.active.delete(e), a;
  }
  return n.active.delete(e), null;
}, wf = (e, t = "$") => {
  try {
    return Vr(
      e,
      t,
      { active: /* @__PURE__ */ new Set(), totalKeys: 0, totalArrayEntries: 0 },
      0
    );
  } catch {
    return U({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  }
};
g({
  "transport-failed": [
    "network",
    "provider-unavailable",
    "rate-limited",
    "auth-failed",
    "quota-exceeded",
    "request-rejected",
    "internal"
  ],
  "transport-disconnected": ["network"],
  "resource-exceeded": ["context-overflow", "output-truncated"],
  "safety-abort": ["content-filtered"],
  malformed: ["empty-output", "protocol"]
});
const Sf = (e) => Zn("zx-ai-session/v1/sealed-content", {
  kind: e.kind,
  ...e.kind === "operation-envelope" ? { operationEnvelope: e.operationEnvelope } : {},
  ...e.kind === "message-only" ? { messageDigest: e.messageDigest } : {}
}), Pe = (e, t = "session-input-invalid", n = "contract") => ({
  ok: !1,
  diagnostic: U({ code: t, stage: n, path: e })
}), rt = (e) => If(e) && e.length <= de.maxIdLength * 2, Xs = /* @__PURE__ */ new Set([
  "message-only",
  "operation-envelope",
  "no-change"
]), Of = /* @__PURE__ */ new Set([
  "message-only",
  "no-change",
  "awaiting-review",
  "handoff-failure"
]), Gs = (e) => Zn("zx-ai-session/v1/handoff-receipt", e), Af = (e, t = "$") => {
  if (!kt(
    e,
    [
      "kind",
      "version",
      "handoffId",
      "effectId",
      "sourceRevision",
      "sourceSessionFingerprint",
      "sessionId",
      "requestId",
      "attemptId",
      "resultKind",
      "sealedResultFingerprint",
      "outcome",
      "fingerprint"
    ],
    [
      "proposalId",
      "proposalFingerprint",
      "reviewId",
      "reviewFingerprint",
      "lifecycleFingerprint"
    ]
  ) || e.kind !== "zx-ai-session-handoff-receipt-v1" || e.version !== Us || !Oe(e.handoffId) || !rt(e.effectId) || !Pt(e.sourceRevision) || !rt(e.sourceSessionFingerprint) || !Oe(e.sessionId) || !Oe(e.requestId) || !Oe(e.attemptId) || !Xs.has(String(e.resultKind)) || !rt(e.sealedResultFingerprint) || !Of.has(String(e.outcome)) || !rt(e.fingerprint))
    return Pe(t, "session-handoff-failure", "handoff");
  for (const o of [
    "proposalId",
    "proposalFingerprint",
    "reviewId",
    "reviewFingerprint",
    "lifecycleFingerprint"
  ])
    if (Object.hasOwn(e, o) && (o.endsWith("Id") ? !Oe(e[o]) : !rt(e[o])))
      return Pe(`${t}.${o}`, "session-handoff-failure", "handoff");
  if (e.outcome !== "awaiting-review" || e.resultKind !== "operation-envelope" || !e.proposalId || !e.proposalFingerprint || !e.reviewId || !e.reviewFingerprint || !e.lifecycleFingerprint)
    return Pe(`${t}.outcome`, "session-handoff-failure", "handoff");
  const { fingerprint: n, ...r } = e, i = Gs(
    r
  );
  return e.fingerprint !== i ? Pe(`${t}.fingerprint`, "session-handoff-failure", "handoff") : {
    ok: !0,
    value: Ws({
      ...r,
      fingerprint: i
    })
  };
}, Rf = (e, t = "$") => {
  if (!kt(
    e,
    ["kind", "contentDigest", "resourceTotals", "fingerprint"],
    ["operationEnvelope", "messageDigest"]
  ) || !Xs.has(String(e.kind)) || !rt(e.contentDigest) || !rt(e.fingerprint) || !kt(e.resourceTotals, [
    "eventCount",
    "textBytes",
    "toolSummaryCount"
  ]) || !Pt(e.resourceTotals.eventCount) || !Pt(e.resourceTotals.textBytes) || !Pt(e.resourceTotals.toolSummaryCount) || e.kind === "operation-envelope" !== Object.hasOwn(e, "operationEnvelope") || e.kind === "message-only" !== Object.hasOwn(e, "messageDigest") || e.messageDigest !== void 0 && !rt(e.messageDigest) || e.kind === "operation-envelope" && !Nd(e.operationEnvelope))
    return Pe(t, "session-malformed", "identity");
  const n = Sf({
    kind: e.kind,
    ...e.kind === "operation-envelope" ? { operationEnvelope: e.operationEnvelope } : {},
    ...e.kind === "message-only" ? { messageDigest: e.messageDigest } : {}
  });
  if (e.contentDigest !== n)
    return Pe(`${t}.contentDigest`, "session-identity-invalid", "identity");
  const { fingerprint: r, ...i } = e, o = Zn(
    "zx-ai-session/v1/sealed-result",
    i
  );
  return e.fingerprint !== o ? Pe(`${t}.fingerprint`, "session-identity-invalid", "identity") : {
    ok: !0,
    value: Ws(e)
  };
}, Ef = (e, t = "$") => {
  try {
    return Rf(e, t);
  } catch {
    return Pe(t, "session-malformed", "identity");
  }
}, Zs = /* @__PURE__ */ new WeakSet(), Tf = (e) => g({
  ...e,
  fingerprint: Gs(e)
}), Ys = (e) => Zn("zx-ai-session/v1/review-artifact-transfer", e), tt = (e) => g({
  status: "failure",
  diagnostic: U({
    code: "session-handoff-failure",
    stage: "handoff",
    path: e
  })
}), Ff = (e) => {
  if (typeof e == "object" && e !== null && Zs.has(e))
    return g({
      status: "success",
      transfer: e
    });
  if (!kt(e, [
    "kind",
    "version",
    "receipt",
    "proposal",
    "lifecycle",
    "sidecar",
    "fingerprint"
  ]) || e.kind !== "zx-ai-session-review-artifact-transfer-v1" || e.version !== "1.0.0" || !oo(e.fingerprint))
    return tt("$");
  const t = Af(e.receipt, "$.receipt");
  if (!t.ok) return tt(t.diagnostic.path);
  const n = Ns(e.proposal);
  if (n.status !== "success")
    return tt("$.proposal");
  const r = Tp(e.sidecar);
  if (r.status !== "success")
    return tt("$.sidecar");
  if (!kt(e.lifecycle, [
    "proposalId",
    "revision",
    "status",
    "fingerprint"
  ]) || !Oe(e.lifecycle.proposalId) || !Pt(e.lifecycle.revision) || !["active", "committed", "discarded"].includes(
    String(e.lifecycle.status)
  ) || !oo(e.lifecycle.fingerprint))
    return tt("$.lifecycle");
  const i = g({
    proposalId: e.lifecycle.proposalId,
    revision: e.lifecycle.revision,
    status: e.lifecycle.status,
    fingerprint: e.lifecycle.fingerprint
  });
  if (i.fingerprint !== Hn({
    proposalId: i.proposalId,
    revision: i.revision,
    status: i.status
  }))
    return tt("$.lifecycle.fingerprint");
  const o = t.value, s = n.proposal, a = r.sidecar;
  if (o.outcome !== "awaiting-review" || o.proposalId !== s.identity.proposalId || o.proposalFingerprint !== s.fingerprint || o.lifecycleFingerprint !== i.fingerprint || i.proposalId !== s.identity.proposalId || i.fingerprint !== s.lifecycle.fingerprint || o.reviewId !== a.identity.reviewId || o.reviewFingerprint !== a.fingerprint || a.proposalBinding.proposalId !== s.identity.proposalId || a.proposalBinding.variantId !== s.identity.variantId || a.proposalBinding.proposalFingerprint !== s.fingerprint || a.proposalBinding.lifecycleFingerprint !== i.fingerprint || s.provenance.sourceId !== o.sessionId || s.provenance.refs[0]?.id !== o.requestId || s.provenance.refs[0]?.type !== "plan" || s.provenance.refs[1]?.id !== o.attemptId || s.provenance.refs[1]?.type !== "activity")
    return tt("$.receipt");
  const c = Ys({
    receiptFingerprint: o.fingerprint,
    proposalFingerprint: s.fingerprint,
    lifecycleFingerprint: i.fingerprint,
    sidecarFingerprint: a.fingerprint
  });
  return e.fingerprint !== c ? tt("$.fingerprint") : g({
    status: "success",
    transfer: {
      kind: "zx-ai-session-review-artifact-transfer-v1",
      version: "1.0.0",
      receipt: o,
      proposal: s,
      lifecycle: i,
      sidecar: a,
      fingerprint: c
    }
  });
}, Cf = (e) => {
  const t = {
    kind: "zx-ai-session-review-artifact-transfer-v1",
    version: "1.0.0",
    ...e,
    fingerprint: Ys({
      receiptFingerprint: e.receipt.fingerprint,
      proposalFingerprint: e.proposal.fingerprint,
      lifecycleFingerprint: e.lifecycle.fingerprint,
      sidecarFingerprint: e.sidecar.fingerprint
    })
  }, n = Ff(t);
  if (n.status !== "success")
    throw new TypeError("session-review-artifact-transfer-invalid");
  return Zs.add(n.transfer), n.transfer;
}, Mf = async (e, t = {}) => {
  const n = wf(e, "$");
  if (n || !kt(
    e,
    ["sealedResult"],
    [
      "effect",
      "snapshot",
      "baseDocument",
      "proposalId",
      "variantId",
      "reviewId",
      "documentSentinel"
    ]
  ))
    return g({
      status: "handoff-failure",
      diagnostic: n ?? U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$"
      })
    });
  const r = Ef(
    e.sealedResult,
    "$.sealedResult"
  );
  if (!r.ok)
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: r.diagnostic.path
      })
    });
  const i = r.value;
  if (i.kind === "message-only")
    return g({ status: "message-only" });
  if (i.kind === "no-change")
    return g({ status: "no-change" });
  const { effect: o } = e;
  if (!kt(o, [
    "effectId",
    "kind",
    "sessionId",
    "requestId",
    "attemptId",
    "sourceRevision",
    "sourceFingerprint",
    "idempotencyKey",
    "sealedResultFingerprint",
    "resultKind"
  ]) || o.kind !== "proposal-handoff" || !Oe(o.effectId) || !Oe(o.sessionId) || !Oe(o.requestId) || !Oe(o.attemptId) || !Pt(o.sourceRevision) || typeof o.sourceFingerprint != "string" || !Oe(o.idempotencyKey) || o.idempotencyKey !== o.effectId || o.resultKind !== "operation-envelope" || o.sealedResultFingerprint !== i.fingerprint)
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.effect"
      })
    });
  if (!e.snapshot || !e.baseDocument)
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.snapshot"
      })
    });
  await t.yieldControl?.();
  const s = e.documentSentinel, a = await Md({
    snapshot: e.snapshot,
    envelope: i.operationEnvelope,
    complex: t.complex
  });
  if (!a.valid || !a.plan)
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.validateAIOperationEnvelope",
        count: a.diagnostics.length
      })
    });
  await t.yieldControl?.();
  const c = e.proposalId ?? `proposal:${o.requestId}`, l = e.variantId ?? `variant:${o.attemptId}`, p = Bd({
    proposalId: c,
    revision: 0
  }), d = sp({
    runtime: Nt,
    baseDocument: e.baseDocument,
    plan: a.plan,
    identity: { proposalId: c, variantId: l },
    lifecycle: p,
    provenance: {
      sourceId: o.sessionId,
      sequence: 1,
      refs: [
        { id: o.requestId, type: "plan" },
        { id: o.attemptId, type: "activity" }
      ]
    },
    runtimeContext: { protocol: "zx-runtime-execution-context-v1" }
  });
  if (d.status !== "success") {
    const h = d.status === "runtime-failure" || d.status === "safety-abort" ? d.runtimeOutcome?.diagnostic?.path ?? d.runtimeOutcome?.code : d.diagnostic?.path ?? d.status;
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: typeof h == "string" && h.length > 0 ? h.startsWith("$.") ? `$.executeAIProposal${h.slice(1)}` : `$.executeAIProposal/${h}` : "$.executeAIProposal"
      })
    });
  }
  await t.yieldControl?.();
  const f = e.reviewId ?? `review:${o.requestId}`, u = Mp({
    identity: { reviewId: f },
    policyRef: Ms,
    proposal: d.proposal,
    lifecycle: d.proposal.lifecycle
  });
  if (u.status !== "active")
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.createAIReviewSidecar"
      })
    });
  if (await t.yieldControl?.(), e.documentSentinel !== void 0 && JSON.stringify(e.documentSentinel) !== JSON.stringify(s))
    return g({
      status: "handoff-failure",
      diagnostic: U({
        code: "session-safety-abort",
        stage: "handoff",
        path: "$.documentSentinel"
      })
    });
  const m = Tf({
    kind: "zx-ai-session-handoff-receipt-v1",
    version: "1.0.0",
    handoffId: `handoff:${o.effectId}`,
    effectId: o.effectId,
    sourceRevision: o.sourceRevision,
    sourceSessionFingerprint: o.sourceFingerprint,
    sessionId: o.sessionId,
    requestId: o.requestId,
    attemptId: o.attemptId,
    resultKind: "operation-envelope",
    sealedResultFingerprint: i.fingerprint,
    proposalId: d.proposal.identity.proposalId,
    proposalFingerprint: d.proposal.fingerprint,
    reviewId: u.sidecar.identity.reviewId,
    reviewFingerprint: u.sidecar.fingerprint,
    lifecycleFingerprint: d.proposal.lifecycle.fingerprint,
    outcome: "awaiting-review"
  });
  return g({
    status: "awaiting-review",
    receipt: m,
    transfer: Cf({
      receipt: m,
      proposal: d.proposal,
      lifecycle: d.proposal.lifecycle,
      sidecar: u.sidecar
    })
  });
};
export {
  Tf as bindHandoff,
  Cf as bindReviewArtifactTransfer,
  Mf as executeAISessionProposalHandoff,
  Ff as readAISessionReviewArtifactTransfer
};
//# sourceMappingURL=handoff-GP-5lLqP.mjs.map
