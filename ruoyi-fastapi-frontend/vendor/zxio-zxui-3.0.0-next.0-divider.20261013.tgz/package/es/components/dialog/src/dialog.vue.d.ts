declare const _default: Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("packages/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("@zxio/zxui").DialogConfirm;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noContentPadding: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly headerPadding: string;
    readonly bodyPadding: string;
    readonly footerPadding: string;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("packages/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("@zxio/zxui").DialogConfirm;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noContentPadding: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly headerPadding: string;
    readonly bodyPadding: string;
    readonly footerPadding: string;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("packages/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("@zxio/zxui").DialogConfirm;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noContentPadding: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly headerPadding: string;
    readonly bodyPadding: string;
    readonly footerPadding: string;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("packages/zxui/theme-provider/index.js").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("@zxio/zxui").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly beforeClose: import("@zxio/zxui").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("@zxio/zxui").DialogConfirm;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("@zxio/zxui").DialogDirtyGuard) | (() => boolean | import("@zxio/zxui").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (((new (...args: any[]) => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[]) | (() => import("@zxio/zxui").DialogConfirm | import("@zxio/zxui").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("@zxio/zxui").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noContentPadding: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly headerPadding: string;
    readonly bodyPadding: string;
    readonly footerPadding: string;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: import("@zxio/zxui").DialogSlots;
} };
export default _default;
