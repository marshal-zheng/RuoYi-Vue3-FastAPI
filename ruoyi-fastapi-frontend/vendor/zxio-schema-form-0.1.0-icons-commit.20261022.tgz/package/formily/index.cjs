"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const NumberTextInput_vue_vue_type_script_setup_true_lang = require("../NumberTextInput.vue_vue_type_script_setup_true_lang-D2uieC0d.js");
const vue = require("vue");
const vue$1 = require("@formily/vue");
const input = require("@zxio/zxui/input");
const inputNumber = require("@zxio/zxui/input-number");
const elementPlus = require("element-plus");
const select = require("@zxio/zxui/select");
const tagsInput = require("@zxio/zxui/tags-input");
const core = require("@zxio/zxui/core");
const index = require("../index-BupWnDag.js");
const core$1 = require("@formily/core");
const reactive = require("@formily/reactive");
const validator = require("@formily/validator");
const _sfc_main$2 = /* @__PURE__ */ vue.defineComponent({
  __name: "RadioOptions",
  props: {
    modelValue: { type: [String, Number, Boolean] },
    options: { type: [Array, Function] },
    disabled: { type: Boolean }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const resolved = vue.computed(
      () => typeof props.options === "function" ? props.options() : props.options ?? []
    );
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(elementPlus.ElRadioGroup), {
        "model-value": __props.modelValue,
        disabled: __props.disabled,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", $event))
      }, {
        default: vue.withCtx(() => [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(resolved.value, (option) => {
            return vue.openBlock(), vue.createBlock(vue.unref(elementPlus.ElRadio), {
              key: `${typeof option.value}:${option.value}`,
              value: option.value,
              disabled: option.disabled
            }, {
              default: vue.withCtx(() => [
                vue.createTextVNode(vue.toDisplayString(option.label), 1)
              ]),
              _: 2
            }, 1032, ["value", "disabled"]);
          }), 128))
        ]),
        _: 1
      }, 8, ["model-value", "disabled"]);
    };
  }
});
function createZxuiBindings$1() {
  return {
    ZxInput: vue.markRaw(input.ZxInput),
    ZxInputNumber: vue.markRaw(inputNumber.ZxInputNumber),
    ZxRadioGroup: vue.markRaw(_sfc_main$2),
    ZxSelect: vue.markRaw(select.ZxSelect),
    ZxTagsInput: vue.markRaw(tagsInput.ZxTagsInput)
  };
}
function createZxuiDefinitionPolicy$1() {
  return {
    ZxInput: {
      props: ["placeholder", "aria-label", "type", "rows", "maxlength"]
    },
    ZxInputNumber: {
      props: [
        "min",
        "max",
        "step",
        "precision",
        "controlsPosition",
        "aria-label"
      ]
    },
    ZxRadioGroup: {
      props: ["options", "disabled", "aria-label"]
    },
    ZxSelect: {
      props: [
        "clearable",
        "filterable",
        "remote",
        "valueOnClear",
        "aria-label",
        "options"
      ]
    },
    ZxTagsInput: {
      props: ["placeholder", "maxCount"]
    }
  };
}
const _hoisted_1$1 = { class: "schema-form__number-field" };
const _hoisted_2$1 = ["data-controls-position"];
const _hoisted_3$1 = ["data-severity"];
const _sfc_main$1 = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "NumberField",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    min: {},
    max: {},
    step: { default: 1 },
    precision: {},
    stepStrictly: { type: Boolean },
    disabledScientific: { type: Boolean },
    controls: { type: Boolean, default: true },
    controlsPosition: {},
    messages: {}
  },
  emits: ["update:modelValue", "edit-state", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const attrs = vue.useAttrs();
    const messagesId = `schema-number-${vue.useId()}`;
    const input2 = vue.useTemplateRef("input");
    const text = vue.ref(props.modelValue == null ? "" : String(props.modelValue));
    const parsed = vue.computed(() => NumberTextInput_vue_vue_type_script_setup_true_lang.parseNumberText(text.value));
    const blocking = vue.computed(
      () => parsed.value.status === "invalid" || props.disabledScientific && /e/i.test(text.value) ? [{ severity: "error", message: "请输入完整、有效的数字" }] : []
    );
    const visibleMessages = vue.computed(() => [
      ...blocking.value,
      ...props.messages ?? []
    ]);
    const describedBy = vue.computed(
      () => [attrs["aria-describedby"], visibleMessages.value.length ? messagesId : ""].filter(Boolean).join(" ") || void 0
    );
    function report() {
      emit("edit-state", { blocking: blocking.value });
    }
    function edit(value) {
      text.value = value.text;
      if (!blocking.value.length && parsed.value.status !== "invalid")
        emit(
          "update:modelValue",
          parsed.value.status === "empty" ? null : parsed.value.value
        );
      report();
    }
    vue.watch(
      () => props.modelValue,
      (value) => {
        if (parsed.value.status === "valid" && parsed.value.value === value || parsed.value.status === "empty" && value == null)
          return;
        text.value = value == null ? "" : String(value);
        report();
      }
    );
    function increment(direction) {
      var _a, _b;
      if (props.disabled || props.readonly) return;
      let value = (parsed.value.status === "valid" ? parsed.value.value : props.modelValue ?? 0) + direction * props.step;
      if (props.stepStrictly) value = Math.round(value / props.step) * props.step;
      const precision = props.precision ?? Math.max(
        ((_a = String(props.step).split(".")[1]) == null ? void 0 : _a.length) ?? 0,
        ((_b = String(props.modelValue ?? 0).split(".")[1]) == null ? void 0 : _b.length) ?? 0
      );
      value = Number(value.toFixed(Math.min(100, precision)));
      if (props.min !== void 0) value = Math.max(props.min, value);
      if (props.max !== void 0) value = Math.min(props.max, value);
      edit({ text: String(value) });
    }
    __expose({
      focus: () => {
        var _a;
        return (_a = input2.value) == null ? void 0 : _a.focus();
      },
      validate: () => {
        report();
        return !blocking.value.length;
      },
      captureEdit: () => text.value,
      restoreEdit(draft) {
        if (typeof draft === "string") {
          text.value = draft;
          report();
        }
      }
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", _hoisted_1$1, [
        vue.createElementVNode("div", {
          class: "schema-form__number",
          "data-controls-position": __props.controlsPosition
        }, [
          __props.controls ? (vue.openBlock(), vue.createBlock(vue.unref(core.ZxButton), {
            key: 0,
            disabled: __props.disabled || __props.readonly || __props.modelValue != null && __props.min != null && __props.modelValue <= __props.min,
            "aria-label": "减少",
            onClick: _cache[0] || (_cache[0] = ($event) => increment(-1))
          }, {
            default: vue.withCtx(() => [..._cache[6] || (_cache[6] = [
              vue.createTextVNode("−", -1)
            ])]),
            _: 1
          }, 8, ["disabled"])) : vue.createCommentVNode("", true),
          vue.createVNode(vue.unref(NumberTextInput_vue_vue_type_script_setup_true_lang._sfc_main$1), vue.mergeProps({
            ref_key: "input",
            ref: input2
          }, _ctx.$attrs, {
            text: text.value,
            disabled: __props.disabled,
            readonly: __props.readonly,
            role: "spinbutton",
            "aria-valuemin": __props.min,
            "aria-valuemax": __props.max,
            "aria-valuenow": parsed.value.status === "valid" ? parsed.value.value : void 0,
            "aria-invalid": visibleMessages.value.some((message) => message.severity === "error") || void 0,
            "aria-describedby": describedBy.value,
            onKeydown: [
              _cache[1] || (_cache[1] = vue.withKeys(vue.withModifiers(($event) => increment(1), ["prevent"]), ["up"])),
              _cache[2] || (_cache[2] = vue.withKeys(vue.withModifiers(($event) => increment(-1), ["prevent"]), ["down"]))
            ],
            onEdit: edit,
            onFocus: _cache[3] || (_cache[3] = ($event) => emit("focus", $event)),
            onBlur: _cache[4] || (_cache[4] = ($event) => emit("blur", $event))
          }), null, 16, ["text", "disabled", "readonly", "aria-valuemin", "aria-valuemax", "aria-valuenow", "aria-invalid", "aria-describedby"]),
          __props.controls ? (vue.openBlock(), vue.createBlock(vue.unref(core.ZxButton), {
            key: 1,
            disabled: __props.disabled || __props.readonly || __props.modelValue != null && __props.max != null && __props.modelValue >= __props.max,
            "aria-label": "增加",
            onClick: _cache[5] || (_cache[5] = ($event) => increment(1))
          }, {
            default: vue.withCtx(() => [..._cache[7] || (_cache[7] = [
              vue.createTextVNode("+", -1)
            ])]),
            _: 1
          }, 8, ["disabled"])) : vue.createCommentVNode("", true)
        ], 8, _hoisted_2$1),
        visibleMessages.value.length ? (vue.openBlock(), vue.createElementBlock("ul", {
          key: 0,
          id: messagesId,
          class: "zx-schema-field__messages",
          "aria-live": "polite"
        }, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(visibleMessages.value, (message, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: index2,
              "data-severity": message.severity
            }, vue.toDisplayString(message.message), 9, _hoisted_3$1);
          }), 128))
        ])) : vue.createCommentVNode("", true)
      ]);
    };
  }
});
function createZxuiBindings() {
  return {
    ...createZxuiBindings$1(),
    ZxInputNumber: {
      component: vue.markRaw(_sfc_main$1),
      composite: true,
      group: false
    }
  };
}
function createZxuiDefinitionPolicy() {
  const policy = createZxuiDefinitionPolicy$1();
  policy.ZxInputNumber.props = [...policy.ZxInputNumber.props, "controls"];
  return policy;
}
function createBindings(runtime, bindings, disabled = () => false) {
  const result = {
    ZxSection: vue.defineComponent({
      inheritAttrs: false,
      setup(_, { attrs, slots }) {
        const field = vue$1.useField();
        return () => {
          var _a;
          return vue.h(
            "fieldset",
            { ...attrs, class: ["schema-form__section", attrs.class] },
            [vue.h("legend", String(field.value.title ?? "")), (_a = slots.default) == null ? void 0 : _a.call(slots)]
          );
        };
      }
    }),
    ZxArray: vue.defineComponent({
      name: "ZxSchemaArray",
      inheritAttrs: false,
      setup() {
        const field = vue$1.useField();
        const schema = vue$1.useFieldSchema();
        const root = vue.shallowRef();
        const port = runtime.register(field.value, {
          focus: () => {
            var _a, _b;
            return (_b = (_a = root.value) == null ? void 0 : _a.querySelector("input,select,textarea,button")) == null ? void 0 : _b.focus();
          }
        });
        vue.onBeforeUnmount(port.dispose);
        return () => {
          runtime.version.value;
          const keys2 = runtime.arrayKeys(field.value);
          const model = field.value;
          return vue.h(
            NumberTextInput_vue_vue_type_script_setup_true_lang._sfc_main,
            {
              label: model.title ?? "",
              group: true,
              required: model.required,
              messages: (runtime.feedback.value.get(model) ?? []).map(
                (issue) => ({
                  message: issue.message,
                  severity: issue.severity ?? "error"
                })
              )
            },
            {
              default: ({
                controlProps
              }) => vue.h(
                "div",
                { ...controlProps, ref: root, class: "schema-form__array" },
                (field.value.value ?? []).map(
                  (_, index2) => vue.h(vue$1.RecursionField, {
                    key: keys2[index2],
                    schema: schema.value.items,
                    name: index2,
                    basePath: field.value.address
                  })
                )
              )
            }
          );
        };
      }
    }),
    ZxField: vue.defineComponent({
      inheritAttrs: false,
      setup(_, { slots }) {
        const field = vue$1.useField();
        const structural = !field.value.componentType;
        const root = vue.shallowRef();
        const port = structural ? runtime.register(field.value, {
          focus: () => {
            var _a, _b;
            return (_b = (_a = root.value) == null ? void 0 : _a.querySelector("input,select,textarea,button")) == null ? void 0 : _b.focus();
          }
        }) : void 0;
        vue.onBeforeUnmount(() => port == null ? void 0 : port.dispose());
        return () => {
          var _a;
          if (!structural) return (_a = slots.default) == null ? void 0 : _a.call(slots);
          runtime.version.value;
          const model = field.value;
          return vue.h(
            NumberTextInput_vue_vue_type_script_setup_true_lang._sfc_main,
            {
              label: model.title ?? "",
              group: true,
              required: model.required,
              messages: (runtime.feedback.value.get(model) ?? []).map(
                (issue) => ({
                  message: issue.message,
                  severity: issue.severity ?? "error"
                })
              )
            },
            {
              default: ({
                controlProps
              }) => {
                var _a2;
                return vue.h("div", { ...controlProps, ref: root }, (_a2 = slots.default) == null ? void 0 : _a2.call(slots));
              }
            }
          );
        };
      }
    })
  };
  for (const [name, binding] of Object.entries(bindings)) {
    const composite = "composite" in binding && binding.composite === true;
    const group = composite && (!("group" in binding) || binding.group !== false);
    const component = vue.toRaw(
      composite ? binding.component : binding
    );
    result[name] = vue.markRaw(
      vue.defineComponent({
        name: `Schema${name}`,
        inheritAttrs: false,
        props: { value: { type: null }, disabled: Boolean, readOnly: Boolean },
        // Declaring these consumes Formily's injected callbacks. Never emit them:
        // ReactiveField would invoke native onInput/onBlur and race our tickets.
        emits: ["change", "focus", "blur"],
        setup(props, { attrs, slots }) {
          const field = vue$1.useField();
          const child = vue.shallowRef();
          const seenEvents = /* @__PURE__ */ new WeakSet();
          const interaction = (type, event) => {
            if (event && seenEvents.has(event)) return;
            if (event) seenEvents.add(event);
            runtime.event(field.value, type);
            const callback = field.value.componentProps[type === "focus" ? "onFocus" : "onBlur"];
            if (typeof callback === "function") callback(event);
          };
          let port;
          const mount = (value) => {
            if (child.value === value) return;
            port == null ? void 0 : port.dispose();
            child.value = value;
            if (value)
              port = runtime.register(
                field.value,
                {
                  focus: (path) => {
                    var _a, _b;
                    return (_b = (_a = child.value) == null ? void 0 : _a.focus) == null ? void 0 : _b.call(_a, path);
                  },
                  ...composite ? {
                    captureEdit: () => {
                      var _a, _b;
                      return ((_b = (_a = child.value) == null ? void 0 : _a.captureEdit) == null ? void 0 : _b.call(_a)) ?? null;
                    },
                    restoreEdit: (draft) => {
                      var _a, _b;
                      return (_b = (_a = child.value) == null ? void 0 : _a.restoreEdit) == null ? void 0 : _b.call(_a, draft);
                    },
                    validate: () => {
                      var _a, _b;
                      return ((_b = (_a = child.value) == null ? void 0 : _a.validate) == null ? void 0 : _b.call(_a)) ?? true;
                    }
                  } : {}
                },
                composite
              );
            port == null ? void 0 : port.restore();
          };
          vue.onBeforeUnmount(() => port == null ? void 0 : port.dispose());
          return () => {
            runtime.version.value;
            const model = field.value;
            const messages = (runtime.feedback.value.get(model) ?? []).map((issue) => {
              var _a;
              return {
                severity: issue.severity ?? "error",
                message: issue.message,
                ...((_a = issue.path) == null ? void 0 : _a.length) ? { path: issue.path.slice(model.path.toArr().length) } : {}
              };
            });
            return vue.h(
              NumberTextInput_vue_vue_type_script_setup_true_lang._sfc_main,
              {
                ...model.decoratorProps,
                label: model.title ?? "",
                description: model.description ? String(model.description) : void 0,
                required: model.required,
                messages: composite ? [] : messages,
                group
              },
              {
                default: ({
                  controlProps
                }) => vue.h(
                  component,
                  {
                    ...attrs,
                    ...controlProps,
                    ref: mount,
                    modelValue: props.value,
                    disabled: props.disabled || disabled(),
                    readonly: props.readOnly,
                    ...composite ? { messages } : {},
                    "onUpdate:modelValue": (value) => {
                      runtime.event(model, "change", value);
                      const callback = model.componentProps.onChange;
                      if (typeof callback === "function") callback(value);
                    },
                    onFocus: (event) => interaction("focus", event),
                    onBlur: (event) => interaction("blur", event),
                    "onEdit-state": (state) => port == null ? void 0 : port.report(state)
                  },
                  slots
                )
              }
            );
          };
        }
      })
    );
  }
  return result;
}
function awaitSignal(work, signal) {
  return new Promise((resolve, reject) => {
    const abort = () => reject(new Error("表单已更新，请重新提交"));
    const cleanup = () => signal.removeEventListener("abort", abort);
    work.then(
      (value) => {
        cleanup();
        resolve(value);
      },
      (error) => {
        cleanup();
        reject(error);
      }
    );
    if (signal.aborted) abort();
    else signal.addEventListener("abort", abort, { once: true });
  });
}
const unsafe = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
function validPath(path) {
  return Array.isArray(path) && path.every(
    (part) => typeof part === "string" ? !unsafe.has(part) : Number.isInteger(part) && part >= 0
  );
}
function readPath(value, path) {
  let current = value;
  for (const part of path) {
    if (!current || typeof current !== "object" || !Object.hasOwn(current, part))
      return void 0;
    current = current[part];
  }
  return current;
}
function anchorPath(path, submitted, keys2) {
  return path.map((part, index$1) => {
    var _a;
    if (typeof part === "string") return part;
    const arrayPath = path.slice(0, index$1);
    const rows = readPath(submitted, arrayPath);
    const key = (_a = keys2.find((item) => index.equal(item.path, arrayPath))) == null ? void 0 : _a.key;
    if (!Array.isArray(rows)) return { index: part, unsafe: true };
    if (!key) return { index: part, snapshot: index.copy(rows) };
    const value = readPath(rows[part], [key]);
    if (typeof value !== "string" && typeof value !== "number" || rows.filter((row) => readPath(row, [key]) === value).length !== 1)
      return { index: part, unsafe: true };
    return { index: part, key, value };
  });
}
function resolvePath(anchor, current) {
  const path = [];
  for (const part of anchor) {
    if (typeof part === "string") {
      path.push(part);
      continue;
    }
    const rows = readPath(current, path);
    if (!Array.isArray(rows) || part.unsafe) return {};
    if (!part.key) {
      if (!index.equal(rows, part.snapshot)) return {};
      path.push(part.index);
      continue;
    }
    const matches = rows.flatMap(
      (row, index2) => readPath(row, [part.key]) === part.value ? [index2] : []
    );
    if (!matches.length) return { deleted: true };
    if (matches.length !== 1) return {};
    path.push(matches[0]);
  }
  return { path };
}
function dataPath(path, values) {
  const result = [];
  let parent = values;
  for (const part of path) {
    const normalized = Array.isArray(parent) && /^(0|[1-9]\d*)$/.test(String(part)) ? Number(part) : part;
    result.push(normalized);
    parent = readPath(parent, [normalized]);
  }
  return result;
}
function cloneConfig(input2) {
  if (Array.isArray(input2)) return input2.map(cloneConfig);
  if (input2 instanceof RegExp) return new RegExp(input2.source, input2.flags);
  if (input2 && typeof input2 === "object") {
    if (Object.getPrototypeOf(input2) !== Object.prototype)
      throw new Error("Configuration must contain plain objects");
    return Object.fromEntries(
      Object.entries(input2).map(([key, value]) => {
        if (["__proto__", "prototype", "constructor"].includes(key))
          throw new Error("Unsafe configuration key");
        return [key, cloneConfig(value)];
      })
    );
  }
  return input2;
}
function immutable(input2, fail) {
  const seen = /* @__PURE__ */ new WeakMap();
  const visit = (value) => {
    if (!value || typeof value !== "object") return value;
    if (seen.has(value)) return seen.get(value);
    const deny = () => {
      const message = "Read-only submission configuration/input was mutated";
      fail(message);
      throw new Error(message);
    };
    const proxy = new Proxy(value, {
      get(target, key, receiver) {
        if (target instanceof RegExp) {
          if (key === "compile") return deny;
          const result = Reflect.get(target, key, target);
          return typeof result === "function" ? result.bind(new RegExp(target.source, target.flags)) : result;
        }
        return visit(Reflect.get(target, key, receiver));
      },
      set: deny,
      deleteProperty: deny,
      defineProperty: deny,
      setPrototypeOf: deny
    });
    seen.set(value, proxy);
    return proxy;
  };
  return visit(input2);
}
function createErrorLedger(ports, keys2) {
  const sources = vue.shallowRef(/* @__PURE__ */ new Map());
  function locate(path) {
    if (!path) return void 0;
    return ports.fields().filter((field) => {
      const prefix = dataPath(field.path.toArr(), ports.read());
      return ports.visible(field) && prefix.length <= path.length && prefix.every((part, index2) => part === path[index2]) && (prefix.length === path.length || ports.composite(field));
    }).sort((a, b) => b.path.length - a.path.length)[0];
  }
  const resolved = vue.computed(() => {
    ports.version();
    const values = ports.read();
    return [...sources.value].flatMap(
      ([code, entries]) => entries.flatMap((entry) => {
        var _a;
        const result = entry.anchor ? resolvePath(entry.anchor, values) : {};
        if (result.deleted) return [];
        const fallback = !result.path && entry.model && ports.fields().includes(entry.model) && ((_a = entry.anchor) == null ? void 0 : _a.some(
          (part) => typeof part !== "string" && part.snapshot
        )) && !entry.anchor.some((part) => typeof part !== "string" && part.unsafe) ? dataPath(entry.model.path.toArr(), values) : void 0;
        const issue = {
          ...entry.issue,
          path: result.path ?? fallback
        };
        const anyField = result.path && ports.fields().filter(
          (field) => dataPath(field.path.toArr(), ports.read()).every(
            (part, index2) => {
              var _a2;
              return part === ((_a2 = result.path) == null ? void 0 : _a2[index2]);
            }
          )
        ).sort((a, b) => b.path.length - a.path.length)[0];
        if (anyField && !ports.active(anyField)) return [];
        return [{ code, issue, field: locate(issue.path) }];
      })
    );
  });
  const messages = (field) => resolved.value.filter((entry) => entry.field === field).map(({ issue }) => issue);
  const formIssues = vue.computed(
    () => resolved.value.filter((entry) => !entry.field).map(({ issue }) => issue)
  );
  function project() {
    for (const field of ports.fields()) {
      for (const code of [
        "SessionValidation",
        "SessionDomain",
        "SessionServer",
        "SessionDerivation"
      ]) {
        const issues = resolved.value.filter(
          (entry) => entry.field === field && entry.code.startsWith(code)
        ).map((entry) => entry.issue);
        for (const severity of ["error", "warning", "info"])
          field.setFeedback({
            code,
            type: severity === "info" ? "success" : severity,
            messages: issues.filter((issue) => (issue.severity ?? "error") === severity).map((issue) => issue.message)
          });
      }
    }
  }
  function set(code, issues, submitted = ports.read()) {
    const entries = issues.map((issue) => {
      var _a;
      if (typeof issue.message !== "string" || issue.path && !validPath(issue.path))
        throw new TypeError("Invalid field issue");
      const path = ((_a = issue.path) == null ? void 0 : _a.length) ? [...issue.path] : void 0;
      return {
        issue: { ...issue, path },
        anchor: path ? anchorPath(path, submitted, keys2) : void 0,
        value: path ? readPath(submitted, path) : void 0,
        model: path ? ports.fields().find(
          (field) => index.equal(dataPath(field.path.toArr(), ports.read()), path)
        ) : void 0
      };
    });
    sources.value = new Map(sources.value).set(code, entries);
    project();
    ports.changed();
  }
  function changed() {
    const values = ports.read();
    sources.value = new Map(
      [...sources.value].map(([code, entries]) => [
        code,
        code.startsWith("SessionDomain") ? [] : entries.filter((entry) => {
          if (!entry.anchor) return false;
          const result = resolvePath(entry.anchor, values);
          const fallback = !result.path && entry.model && ports.fields().includes(entry.model) && entry.anchor.some(
            (part) => typeof part !== "string" && part.snapshot
          ) && !entry.anchor.some(
            (part) => typeof part !== "string" && part.unsafe
          ) ? dataPath(entry.model.path.toArr(), values) : void 0;
          const path = result.path ?? fallback;
          return !result.deleted && (!path || index.equal(entry.value, readPath(values, path)));
        })
      ])
    );
    project();
  }
  return {
    messages,
    formIssues,
    project,
    set,
    changed,
    clear: () => {
      sources.value = /* @__PURE__ */ new Map();
      project();
      ports.changed();
    },
    clearValidation(identity) {
      const prefix = `SessionValidation:${identity}:`;
      sources.value = new Map(
        [...sources.value].filter(([code]) => !code.startsWith(prefix))
      );
      project();
      ports.changed();
    },
    clearField(field) {
      const prefix = dataPath(field.path.toArr(), ports.read());
      sources.value = new Map(
        [...sources.value].map(([code, entries]) => [
          code,
          entries.filter(
            (entry) => !entry.issue.path || !prefix.every((part, index2) => {
              var _a;
              return part === ((_a = entry.issue.path) == null ? void 0 : _a[index2]);
            })
          )
        ])
      );
      project();
      ports.changed();
    }
  };
}
function createResources(signal) {
  const version = vue.shallowRef(0);
  const tasks = /* @__PURE__ */ new Map();
  const bridges = /* @__PURE__ */ new Map();
  const retired = /* @__PURE__ */ new WeakSet();
  const scopeIds = /* @__PURE__ */ new WeakMap();
  let nextScope = 0;
  const identity = (key, scope) => {
    if (typeof scope === "object" && !scopeIds.has(scope))
      scopeIds.set(scope, ++nextScope);
    return `${typeof scope === "object" ? scopeIds.get(scope) : scope}\0${key}`;
  };
  const notify = () => {
    version.value++;
  };
  const active = (task) => !signal.aborted && !task.controller.signal.aborted && task.applicable() && tasks.get(identity(task.key, task.scope)) === task;
  function start(task) {
    tasks.set(identity(task.key, task.scope), task);
    notify();
    let work;
    try {
      work = Promise.resolve(
        task.load(index.copy(task.input), task.controller.signal)
      );
    } catch (error) {
      work = Promise.reject(error);
    }
    work.then(
      (value) => {
        if (!active(task)) return;
        try {
          task.value = index.copy(value);
          if (!retired.has(task.runtime)) task.commit(index.copy(value));
          if (!active(task)) return;
          task.state = "success";
        } catch (error) {
          if (!active(task)) return;
          task.state = "error";
          task.error = error instanceof Error ? error.message : "资源投影失败";
        }
      },
      (error) => {
        if (!active(task)) return;
        task.state = "error";
        task.error = error instanceof Error ? error.message : "资源读取失败";
      }
    ).finally(() => {
      if (tasks.get(identity(task.key, task.scope)) === task) notify();
    });
  }
  function runLatest(runtime, key, captured, load, commit, options = {}, applicable = () => true) {
    if (signal.aborted || retired.has(runtime)) return;
    const scope = options.scope ?? "edit";
    const input2 = index.copy(captured);
    const id = identity(key, scope);
    const previous = tasks.get(id);
    if (previous && index.equal(previous.input, input2)) {
      const changedRuntime = previous.runtime !== runtime;
      const changedBlocking = previous.blocking !== !!options.blocking;
      previous.blocking = !!options.blocking;
      previous.applicable = applicable;
      previous.load = load;
      previous.runtime = runtime;
      previous.commit = commit;
      if (changedBlocking) notify();
      if (changedRuntime && previous.state === "success")
        previous.commit(index.copy(previous.value));
      return;
    }
    if (previous) {
      previous.state = "superseded";
      previous.controller.abort();
    }
    start({
      key,
      scope,
      input: input2,
      runtime,
      applicable,
      load,
      commit,
      controller: new AbortController(),
      state: "pending",
      blocking: !!options.blocking
    });
  }
  function retry(key, scope = "edit") {
    const previous = tasks.get(identity(key, scope));
    if (!previous || previous.state === "pending" || signal.aborted) return;
    start({
      ...previous,
      controller: new AbortController(),
      state: "pending",
      error: void 0
    });
  }
  function cancel(key, scope = "edit", applicable = true) {
    const task = tasks.get(identity(key, scope));
    if (!task) return;
    task.state = "cancelled";
    task.controller.abort();
    if (!applicable) tasks.delete(identity(key, scope));
    notify();
  }
  function bindResource(runtime, source, project, applicable = () => true) {
    const stop = vue.watch(
      source,
      (value) => {
        if (!signal.aborted && applicable()) project(value);
      },
      { immediate: true, flush: "sync", deep: true }
    );
    let set = bridges.get(runtime);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      bridges.set(runtime, set);
    }
    const bridge = {
      stop,
      applicable,
      refresh() {
        if (!signal.aborted && applicable()) project(source());
      }
    };
    set.add(bridge);
    return () => {
      stop();
      set == null ? void 0 : set.delete(bridge);
    };
  }
  function retire(runtime) {
    var _a;
    retired.add(runtime);
    (_a = bridges.get(runtime)) == null ? void 0 : _a.forEach((bridge) => bridge.stop());
    bridges.delete(runtime);
    for (const task of tasks.values())
      if (task.runtime === runtime && task.scope !== "record")
        cancel(task.key, task.scope, false);
  }
  const pending = () => {
    version.value;
    return [...tasks.values()].some(
      (task) => task.applicable() && task.state === "pending"
    );
  };
  const issues = () => {
    version.value;
    return [...tasks.values()].filter(
      (task) => task.applicable() && task.blocking && task.state !== "success"
    ).map((task) => ({
      message: task.error ?? (task.state === "pending" ? "请等待必要资源完成" : "必要资源未就绪，请重试")
    }));
  };
  const dispose = () => {
    for (const task of tasks.values()) task.controller.abort();
    for (const set of bridges.values()) set.forEach((bridge) => bridge.stop());
    tasks.clear();
    bridges.clear();
    notify();
  };
  signal.addEventListener("abort", dispose, { once: true });
  return {
    version,
    runLatest,
    retry,
    cancel,
    bindResource,
    refresh(runtime) {
      var _a;
      (_a = bridges.get(runtime)) == null ? void 0 : _a.forEach((bridge) => bridge.refresh());
    },
    prune(runtime) {
      var _a;
      (_a = bridges.get(runtime)) == null ? void 0 : _a.forEach((bridge) => {
        var _a2;
        if (!bridge.applicable()) {
          bridge.stop();
          (_a2 = bridges.get(runtime)) == null ? void 0 : _a2.delete(bridge);
        }
      });
      for (const task of tasks.values())
        if (task.runtime === runtime && !task.applicable())
          cancel(task.key, task.scope, false);
    },
    retire,
    pending,
    requiredPending: () => {
      version.value;
      return [...tasks.values()].some(
        (task) => task.blocking && task.state === "pending" && task.applicable()
      );
    },
    issues,
    feedback: () => {
      version.value;
      return [...tasks.values()].filter(
        (task) => task.applicable() && task.state !== "success" && (task.blocking || task.state === "error")
      ).map((task) => ({
        severity: task.blocking ? "error" : "warning",
        message: task.error ?? (task.state === "pending" ? "请等待必要资源完成" : "必要资源未就绪，请重试")
      }));
    },
    dispose,
    states: () => [...tasks.values()].map(({ key, scope, state, error }) => ({
      key,
      scope,
      state,
      error
    }))
  };
}
const operations = /* @__PURE__ */ new Set([
  "push",
  "pop",
  "insert",
  "remove",
  "shift",
  "unshift",
  "move",
  "moveUp",
  "moveDown"
]);
function createArrays(ports) {
  const arrays = /* @__PURE__ */ new WeakSet();
  const objectKeys = /* @__PURE__ */ new WeakMap();
  const modelKeys = /* @__PURE__ */ new WeakMap();
  const pendingKeys = /* @__PURE__ */ new Map();
  let nextKey = 0;
  function install(field) {
    if (arrays.has(field)) return;
    arrays.add(field);
    field.onInput = () => ports.validate(field).then(() => {
    });
  }
  const keyFor = (field) => {
    var _a;
    return (_a = ports.keys.find(
      (rule) => index.equal(rule.path, dataPath(field.path.toArr(), ports.form.values))
    )) == null ? void 0 : _a.key;
  };
  function uniqueIds(rows, key) {
    const ids = rows.map((row) => readPath(row, [key]));
    return ids.every(
      (id) => typeof id === "string" || typeof id === "number" && Number.isFinite(id)
    ) && new Set(ids).size === ids.length ? ids : void 0;
  }
  function renderKeys(field) {
    const rows = field.value ?? [];
    const declared = keyFor(field);
    const ids = declared && uniqueIds(rows, declared);
    return rows.map((row, index2) => {
      if (ids) return `${typeof ids[index2]}:${ids[index2]}`;
      if (row && typeof row === "object") {
        if (!objectKeys.has(row)) objectKeys.set(row, `object:${++nextKey}`);
        return objectKeys.get(row);
      }
      const address = field.address.concat(index2).toString();
      const model = ports.form.query(address).take();
      if (model && modelKeys.has(model)) return modelKeys.get(model);
      let pending = pendingKeys.get(address);
      if (!pending || pending.model && (ports.form.query(address).take() !== pending.model || pending.model.address.toString() !== address)) {
        pending = { key: `item:${++nextKey}` };
        pendingKeys.set(address, pending);
      }
      if (model) {
        pending.model = model;
        modelKeys.set(model, pending.key);
      }
      return pending.key;
    });
  }
  function invoke(field, method, args) {
    return ports.transaction(() => {
      var _a;
      const length = ((_a = field.value) == null ? void 0 : _a.length) ?? 0;
      const index$1 = (value, end = false) => {
        if (!Number.isInteger(value) || Number(value) < 0 || Number(value) >= length + (end ? 1 : 0))
          throw new Error("Invalid array operation index");
      };
      if (method === "insert") index$1(args[0], true);
      if (["remove", "moveUp", "moveDown"].includes(method)) index$1(args[0]);
      if (method === "move") {
        index$1(args[0]);
        index$1(args[1]);
      }
      const isolated = ["push", "unshift"].includes(method) ? args.map(index.copy) : method === "insert" ? [args[0], ...args.slice(1).map(index.copy)] : args;
      return field[method].apply(field, isolated);
    });
  }
  function align(field, next) {
    const previous = field.value ?? [];
    if (index.equal(previous, next)) return;
    const key = keyFor(field);
    const before = key && uniqueIds(previous, key);
    const after = key && uniqueIds(next, key);
    if (!before || !after) {
      ports.form.clearFormGraph(`${field.address}.*`, false);
      return;
    }
    const ids = [...before];
    for (let index2 = ids.length - 1; index2 >= 0; index2--)
      if (!after.includes(ids[index2])) {
        invoke(field, "remove", [index2]);
        ids.splice(index2, 1);
      }
    after.forEach((id, target) => {
      const from = ids.indexOf(id);
      if (from < 0) {
        invoke(field, "insert", [target, next[target]]);
        ids.splice(target, 0, id);
      } else if (from !== target) {
        invoke(field, "move", [from, target]);
        ids.splice(target, 0, ids.splice(from, 1)[0]);
      }
    });
  }
  function alignValues(next) {
    const models = ports.form.query("*").map().filter((field) => arrays.has(field));
    models.sort((left, right) => left.path.length - right.path.length);
    for (const field of models) {
      const rows = readPath(next, field.path.toArr());
      if (Array.isArray(rows)) align(field, rows);
    }
  }
  return {
    install,
    renderKeys,
    alignValues,
    align,
    operation(field, key) {
      return arrays.has(field) && operations.has(String(key)) ? (...args) => invoke(field, String(key), args) : void 0;
    }
  };
}
function createModelBoundary(ports) {
  const { form, arrays: arrayTools, transaction, deny } = ports;
  const proxies = /* @__PURE__ */ new WeakMap();
  const fieldView = (field) => {
    const cached = proxies.get(field);
    if (cached) return cached;
    const proxy = new Proxy(field, {
      get(target, key) {
        if (key === "form") return formView;
        if (key === "getState")
          return (getter) => getter ? getter(fieldView(target)) : target.getState();
        if (key === "setState")
          return (setter) => transaction(
            () => safeView(
              target.setState(
                typeof setter === "function" ? () => setter(fieldView(target)) : cloneConfig(setter)
              )
            )
          );
        if (["parent", "arrayParent", "objectParent"].includes(String(key))) {
          const parent = Reflect.get(target, key, target);
          return parent ? fieldView(parent) : parent;
        }
        if ([
          "validate",
          "submit",
          "onInput",
          "onFocus",
          "onBlur",
          "modify",
          "inject",
          "destroy",
          "addEffects",
          "setEffects",
          "setComponent",
          "setDecorator"
        ].includes(String(key)))
          return () => deny(String(key));
        if (key === "setValue" && core$1.isDataField(target))
          return (value2) => transaction(() => {
            const isolated = value2 === void 0 ? void 0 : index.copy(value2);
            if (core$1.isArrayField(target) && Array.isArray(isolated))
              arrayTools.align(target, isolated);
            target.setValue(isolated);
          });
        if (key === "query")
          return (pattern) => queryView(target.query(pattern));
        const operation = arrayTools.operation(target, key);
        if (operation) return operation;
        const value = Reflect.get(target, key, target);
        return typeof value === "function" ? value.bind(target) : value;
      },
      set(target, key, value) {
        if (["componentType", "decoratorType"].includes(String(key)))
          return deny(`dynamic ${String(key)}; use replaceSchema`);
        return Reflect.set(target, key, value, target);
      }
    });
    proxies.set(field, proxy);
    proxies.set(proxy, field);
    return proxy;
  };
  const queryView = (query) => new Proxy(query, {
    get(target, key) {
      if (key === "form") return formView;
      if (key === "get")
        return (name) => {
          const field = target.take();
          return field && Reflect.get(fieldView(field), name);
        };
      if (key === "getIn")
        return (...args) => {
          const value2 = target.getIn(...args);
          if (typeof value2 === "function")
            return () => deny("Query.getIn function");
          return safeView(value2);
        };
      if (key === "take")
        return (fn) => {
          const field = target.take();
          return field && (fn ? fn(fieldView(field)) : fieldView(field));
        };
      if (key === "map")
        return (fn) => target.map(
          (field) => fn ? fn(fieldView(field)) : fieldView(field)
        );
      if (key === "forEach")
        return (fn) => target.forEach((field) => fn(fieldView(field)));
      if (key === "reduce")
        return (fn, initial) => target.reduce((acc, field) => fn(acc, fieldView(field)), initial);
      const value = Reflect.get(target, key, target);
      return typeof value === "function" ? value.bind(target) : value;
    }
  });
  const formView = new Proxy(form, {
    get(target, key) {
      if (key === "graph") return deny("graph; use guarded schema and values");
      if (key === "fields") return fieldsView;
      if (key === "getState" || key === "getFormState")
        return (getter) => getter ? getter(formView) : target.getState();
      if (key === "getFieldState")
        return (pattern, getter) => target.getFieldState(
          pattern,
          (field) => getter ? getter(fieldView(field)) : field.getState()
        );
      if (key === "setState" || key === "setFormState")
        return (setter) => transaction(
          () => safeView(
            target.setState(
              typeof setter === "function" ? () => setter(formView) : cloneConfig(setter)
            )
          )
        );
      if (/^(create|addEffects|setEffects|setFieldState|setFormGraph|validate|submit|reset|onInit|onMount|onUnmount|notify)/.test(
        String(key)
      ))
        return () => deny(String(key));
      if (key === "setValuesIn")
        return (path, value2) => transaction(() => {
          const isolated = value2 === void 0 ? void 0 : index.copy(value2);
          const field = target.query(path).take();
          if (field && Array.isArray(isolated) && core$1.isArrayField(field))
            arrayTools.align(
              field,
              isolated
            );
          target.setValuesIn(path, isolated);
        });
      if (key === "setValues")
        return (values, strategy) => transaction(() => {
          const isolated = index.copy(values);
          arrayTools.alignValues(isolated);
          target.setValues(isolated, strategy);
        });
      if (key === "query")
        return (pattern) => queryView(target.query(pattern));
      const value = Reflect.get(target, key, target);
      return typeof value === "function" ? value.bind(target) : value;
    }
  });
  const fieldsView = new Proxy(form.fields, {
    get(target, key) {
      const value = Reflect.get(target, key);
      return core$1.isGeneralField(value) ? fieldView(value) : value;
    },
    set() {
      return deny("fields registration");
    },
    deleteProperty() {
      return deny("fields registration");
    },
    defineProperty() {
      return deny("fields registration");
    }
  });
  function safeView(value) {
    if (value === form) return formView;
    if (value === form.fields) return fieldsView;
    if (core$1.isGeneralField(value)) return fieldView(value);
    if (core$1.isQuery(value)) return queryView(value);
    return value;
  }
  const rawField = (field) => proxies.get(field) && ports.isCompiled(proxies.get(field)) ? proxies.get(field) : field;
  return { fieldView, formView, rawField };
}
function createRuntime(options) {
  const version = vue.shallowRef(0);
  const faults = vue.shallowRef([]);
  const form = core$1.createForm({ initialValues: index.copy(options.initial) });
  const record = new AbortController();
  const recordSignal = options.recordSignal ?? record.signal;
  const resources = options.resourceHost ?? createResources(recordSignal);
  const resourceOwner = {};
  const configs = /* @__PURE__ */ new Map();
  const controls = /* @__PURE__ */ new Map();
  const tokens = /* @__PURE__ */ new Map();
  const disposers = [];
  let alive = true;
  let mounted = false;
  let configWrite = 0;
  let initializing = 0;
  let calls = 0;
  let reactionCount = 0;
  let depth = 0;
  let deriving = 0;
  let origin;
  let valueRevision = 0;
  let configRevision = 0;
  let editRevision = 0;
  let controlsGeneration = 0;
  let replace;
  const fault = (message, field) => reactive.untracked(() => {
    if (!alive) return;
    const path = field == null ? void 0 : field.path.toArr();
    if (!faults.value.some(
      (issue) => issue.message === message && index.equal(issue.path, path)
    ))
      faults.value = [...faults.value, { message, ...path ? { path } : {} }];
    version.value++;
  });
  const changed = () => reactive.untracked(() => {
    if (alive) version.value++;
  });
  const liveFields = () => [...configs.keys()].filter(
    (field) => !field.destroyed && form.query(field.address).take() === field
  );
  const ledger = createErrorLedger(
    {
      read: () => read(),
      fields: liveFields,
      visible: (field) => {
        var _a;
        return field.display === "visible" && ((_a = controls.get(field)) == null ? void 0 : _a.mounted) === true;
      },
      composite: (field) => {
        var _a;
        return ((_a = controls.get(field)) == null ? void 0 : _a.composite) ?? false;
      },
      active: (field) => {
        var _a;
        return ((_a = configs.get(field)) == null ? void 0 : _a.validationActive) !== false;
      },
      version: () => version.value,
      changed
    },
    options.arrayKeys ?? []
  );
  const feedback = vue.computed(
    () => new Map(liveFields().map((field) => [field, ledger.messages(field)]))
  );
  const activeControls = () => [...controls].filter(
    ([field]) => {
      var _a;
      return liveFields().includes(field) && ((_a = configs.get(field)) == null ? void 0 : _a.validationActive) !== false;
    }
  );
  const ticket = () => `${valueRevision}/${configRevision}/${editRevision}/${controlsGeneration}`;
  const current = (stamp) => alive && stamp === ticket();
  const failWrite = (message) => fault(message);
  const read = () => {
    version.value;
    return reactive.untracked(() => index.copy(JSON.parse(JSON.stringify(form.values))));
  };
  const observeValues = () => reactive.observe(
    form.values,
    () => {
      valueRevision++;
      changed();
    },
    true
  );
  let stopValues = observeValues();
  disposers.push(
    () => stopValues(),
    reactive.observe(form, (change) => {
      if (["pattern", "display"].includes(String(change.key))) {
        configRevision++;
        changed();
      }
      if (change.key === "values") {
        stopValues();
        stopValues = observeValues();
        valueRevision++;
        changed();
      }
    })
  );
  const transaction = (work, source) => {
    const previousOrigin = origin;
    origin = source ?? previousOrigin ?? (deriving ? "reaction" : "edit");
    if (!alive) throw new Error("Disposed form runtime");
    if (!depth && !deriving) calls = 0;
    depth++;
    try {
      return reactive.batch(work);
    } finally {
      depth--;
      changed();
      origin = previousOrigin;
    }
  };
  const arrayTools = createArrays({
    form,
    keys: options.arrayKeys ?? [],
    transaction,
    validate: (field) => validateField(field, "onInput")
  });
  const validationIds = /* @__PURE__ */ new WeakMap();
  let nextValidationId = 0;
  const validationId = (field) => {
    if (!validationIds.has(field)) validationIds.set(field, ++nextValidationId);
    return String(validationIds.get(field));
  };
  const deny = (name) => {
    fault(`Unsupported native registration/validation entry: ${name}`);
    throw new Error(`Use the schema/session boundary instead of ${name}`);
  };
  const { fieldView, formView, rawField } = createModelBoundary({
    form,
    arrays: arrayTools,
    transaction,
    deny,
    isCompiled: (field) => configs.has(field)
  });
  function configure(input2, patch) {
    const field = rawField(input2);
    if (field.form !== form || !configs.has(field))
      return deny("configure foreign/uncompiled field");
    transaction(
      () => reactive.untracked(() => {
        configRevision++;
        const previous = configs.get(field);
        const next = { ...previous, ...cloneConfig(patch) };
        const descriptions = validator.parseValidatorDescriptions(next.validator ?? []);
        if (patch.required !== void 0 || previous.required !== void 0) {
          next.validator = descriptions.map((rule) => ({
            ...rule,
            required: void 0
          }));
          if (next.required)
            next.validator.unshift({ required: true });
        }
        const protectedConfig = immutable(
          cloneConfig(next),
          (message) => fault(message, field)
        );
        configs.set(field, protectedConfig);
        configWrite++;
        try {
          field.setValidator(protectedConfig.validator ?? []);
          field.setDataSource(protectedConfig.dataSource ?? []);
          field.componentProps = protectedConfig.componentProps ?? {};
        } finally {
          configWrite--;
        }
        tokens.set(field, (tokens.get(field) ?? 0) + 1);
        if (patch.validationActive === false || patch.validator !== void 0 || patch.required !== void 0)
          ledger.clearValidation(validationId(field));
      }),
      deriving ? "reaction" : "config"
    );
  }
  const compiledFields = /* @__PURE__ */ new WeakSet();
  const observedLayouts = /* @__PURE__ */ new WeakSet();
  function initialize(field, config, array = false) {
    compiledFields.add(field);
    if (!core$1.isDataField(field) && !observedLayouts.has(field)) {
      observedLayouts.add(field);
      disposers.push(
        reactive.observe(field, (change) => {
          if (["selfDisplay", "selfPattern"].includes(String(change.key))) {
            configRevision++;
            changed();
          }
        })
      );
    }
    if (!core$1.isDataField(field) || configs.has(field)) return;
    configs.set(field, {});
    if (array) arrayTools.install(field);
    initializing++;
    try {
      configure(field, config);
    } finally {
      initializing--;
    }
    disposers.push(
      reactive.observe(field, (change) => {
        const key = String(change.key);
        if ([
          "validator",
          "dataSource",
          "componentProps",
          "componentType",
          "decoratorType"
        ].includes(key)) {
          if (!configWrite)
            fault(`Configuration bypass: ${key}; use configure`, field);
        }
        if (["selfDisplay", "selfPattern"].includes(key)) {
          configRevision++;
          changed();
        }
      })
    );
  }
  function guard(fn) {
    reactionCount++;
    return (field) => {
      if (!alive || faults.value.length) return;
      calls++;
      if (calls > (options.reactionBudget ?? Math.max(1e4, reactionCount * 100))) {
        fault("Reaction activity budget exhausted", field);
        return;
      }
      deriving++;
      try {
        const result = fn(fieldView(field));
        if (result && typeof result.then === "function") {
          fault(
            "A synchronous reaction returned a thenable; use runLatest",
            field
          );
          Promise.resolve(result).catch(() => {
          });
        }
      } catch (error) {
        fault(error instanceof Error ? error.message : "Reaction failed", field);
      } finally {
        deriving--;
      }
    };
  }
  function compile(node) {
    var _a, _b;
    const checkStrings = (value, seen = /* @__PURE__ */ new WeakSet()) => {
      if (typeof value === "string" && value.includes("{{"))
        throw new Error(
          "String expressions are outside the trusted TypeScript schema profile"
        );
      if (!value || typeof value !== "object" || seen.has(value)) return;
      seen.add(value);
      for (const item of Object.values(value)) checkStrings(item, seen);
    };
    checkStrings(node);
    const next = { ...node };
    const decorator = node["x-decorator"];
    if (decorator && options.components && (typeof decorator !== "string" || !options.components.includes(decorator)))
      throw new Error(`Unregistered schema decorator: ${String(decorator)}`);
    const component = node["x-component"];
    if (component && options.components && (typeof component !== "string" || !options.components.includes(component)))
      throw new Error(`Unregistered schema component: ${String(component)}`);
    const reactions = node["x-reactions"];
    if (reactions !== void 0 && (Array.isArray(reactions) ? reactions : [reactions]).some(
      (fn) => typeof fn !== "function"
    ))
      throw new Error("Only native TypeScript function reactions are supported");
    const config = {
      ...node.required !== void 0 ? { required: !!node.required } : {},
      validator: node["x-validator"] ?? [],
      componentProps: node["x-component-props"] ?? {},
      dataSource: Array.isArray((_a = node["x-component-props"]) == null ? void 0 : _a.options) ? (_b = node["x-component-props"]) == null ? void 0 : _b.options : [],
      validationActive: true
    };
    delete next.required;
    delete next["x-validator"];
    if (node.type !== "void") delete next["x-component-props"];
    next["x-reactions"] = [
      (field) => reactive.untracked(() => initialize(field, config, node.type === "array")),
      ...reactions ? (Array.isArray(reactions) ? reactions : [reactions]).map(
        (fn) => guard(fn)
      ) : []
    ];
    if (node.properties)
      next.properties = Object.fromEntries(
        Object.entries(node.properties).map(([key, child]) => {
          if (["__proto__", "constructor", "prototype"].includes(key))
            throw new Error("Unsafe schema path");
          return [key, compile(child)];
        })
      );
    if (node.items)
      next.items = Array.isArray(node.items) ? node.items.map(compile) : compile(node.items);
    return next;
  }
  function states() {
    return liveFields().map((field) => {
      var _a, _b, _c, _d;
      return {
        path: dataPath(field.path.toArr(), form.values),
        address: field.address.toString(),
        required: field.required,
        display: field.display,
        pattern: field.pattern,
        validator: cloneConfig(((_a = configs.get(field)) == null ? void 0 : _a.validator) ?? []),
        dataSource: cloneConfig(((_b = configs.get(field)) == null ? void 0 : _b.dataSource) ?? []),
        componentProps: cloneConfig(((_c = configs.get(field)) == null ? void 0 : _c.componentProps) ?? {}),
        validationActive: ((_d = configs.get(field)) == null ? void 0 : _d.validationActive) !== false
      };
    });
  }
  function assert() {
    var _a;
    if (!alive || faults.value.length) return false;
    if (form.query("*").map().some((field) => !compiledFields.has(field))) {
      fault("Uncompiled field registration bypassed the schema boundary");
      return false;
    }
    if (reactionCount && !options.assertSettled) {
      fault("A schema with reactions requires assertSettled");
      return false;
    }
    const stamp = ticket();
    try {
      const issues = ((_a = options.assertSettled) == null ? void 0 : _a.call(
        options,
        immutable(read(), failWrite),
        immutable(states(), failWrite)
      )) ?? [];
      if (!Array.isArray(issues)) {
        if (issues && typeof issues.then === "function")
          Promise.resolve(issues).catch(() => {
          });
        throw new Error("assertSettled must synchronously return issues");
      }
      if (!current(stamp))
        throw new Error("assertSettled changed its save domain");
      assertionIssues.value = issues.map((issue) => ({
        ...issue,
        path: issue.path && [...issue.path]
      }));
      return !issues.length;
    } catch (error) {
      fault(error instanceof Error ? error.message : "assertSettled failed");
      return false;
    }
  }
  const assertionIssues = vue.shallowRef([]);
  async function validateField(field, triggerType, captured) {
    var _a, _b;
    if (!alive || ((_a = configs.get(field)) == null ? void 0 : _a.validationActive) === false) return true;
    const rules = (captured == null ? void 0 : captured.rules) ?? cloneConfig(((_b = configs.get(field)) == null ? void 0 : _b.validator) ?? []);
    const groups = /* @__PURE__ */ new Map();
    for (const description of validator.parseValidatorDescriptions(rules)) {
      const trigger = description.triggerType ?? "onInput";
      if (triggerType && trigger !== triggerType) continue;
      groups.set(trigger, [
        ...groups.get(trigger) ?? [],
        description
      ]);
    }
    if (!groups.size) return true;
    const token = (tokens.get(field) ?? 0) + 1;
    tokens.set(field, token);
    const stamp = (captured == null ? void 0 : captured.stamp) ?? ticket();
    const value = captured ? captured.value : cloneConfig(field.value);
    const results = await Promise.all(
      [...groups].map(async ([trigger, selected]) => {
        let issues;
        try {
          const result = await validator.validate(value, selected, {
            context: { field: fieldView(field), form: formView }
          });
          issues = [
            ...(result.error ?? []).map((message) => ({
              path: dataPath(field.path.toArr(), form.values),
              message,
              severity: "error"
            })),
            ...(result.warning ?? []).map((message) => ({
              path: dataPath(field.path.toArr(), form.values),
              message,
              severity: "warning"
            })),
            ...(result.success ?? []).map((message) => ({
              path: dataPath(field.path.toArr(), form.values),
              message,
              severity: "info"
            }))
          ];
        } catch (error) {
          issues = [
            {
              path: dataPath(field.path.toArr(), form.values),
              message: error instanceof Error ? error.message : "Validation failed"
            }
          ];
        }
        return { trigger, issues };
      })
    );
    if (!current(stamp) || tokens.get(field) !== token) return false;
    for (const { trigger, issues } of results)
      ledger.set(`SessionValidation:${validationId(field)}:${trigger}`, issues);
    return !results.some(
      (result) => result.issues.some((issue) => (issue.severity ?? "error") === "error")
    );
  }
  async function validate() {
    var _a, _b;
    if (!assert()) return false;
    const stamp = ticket();
    const values = read();
    const captured = [...configs].filter(
      ([field, config]) => liveFields().includes(field) && config.validationActive !== false
    ).map(([field]) => {
      var _a2;
      return {
        field,
        value: cloneConfig(field.value),
        rules: cloneConfig(((_a2 = configs.get(field)) == null ? void 0 : _a2.validator) ?? [])
      };
    });
    for (const [, item] of activeControls().filter(
      ([, item2]) => item2.mounted
    )) {
      if (await ((_b = (_a = item.control).validate) == null ? void 0 : _b.call(_a)) === false || !current(stamp))
        return false;
    }
    if (activeControls().some(([, item]) => {
      var _a2;
      return (_a2 = item.state.blocking) == null ? void 0 : _a2.length;
    }))
      return false;
    const results = await Promise.all(
      captured.map(
        ({ field, value, rules }) => validateField(field, void 0, { value, rules, stamp })
      )
    );
    return current(stamp) && results.every(Boolean) && assert() && index.equal(values, read());
  }
  function register(field, control, composite = false) {
    const previous = controls.get(field);
    const item = {
      control,
      state: (previous == null ? void 0 : previous.state) ?? { pending: false, blocking: [] },
      composite,
      mounted: true,
      draft: previous == null ? void 0 : previous.draft
    };
    transaction(() => {
      controls.set(field, item);
      controlsGeneration++;
      changed();
    }, "control");
    return {
      restore() {
        var _a;
        if (item.draft !== void 0) (_a = control.restoreEdit) == null ? void 0 : _a.call(control, item.draft);
      },
      report(state) {
        if (!alive || controls.get(field) !== item) return;
        const normalized = {
          pending: !!state.pending,
          blocking: cloneConfig(state.blocking ?? [])
        };
        if (index.equal(item.state, normalized)) return;
        item.state = normalized;
        editRevision++;
        changed();
      },
      dispose() {
        if (!alive || controls.get(field) !== item) return;
        transaction(() => {
          var _a;
          if (field.display !== "visible" && !field.destroyed) {
            item.draft = (_a = control.captureEdit) == null ? void 0 : _a.call(control);
            item.mounted = false;
          } else controls.delete(field);
          controlsGeneration++;
          resources.prune(resourceOwner);
          changed();
        }, "control");
      }
    };
  }
  const context = {
    form: formView,
    read,
    signal: () => recordSignal,
    bindResource(source, project, settings) {
      if (!alive) return () => {
      };
      const scope = (settings == null ? void 0 : settings.scope) && typeof settings.scope === "object" ? rawField(settings.scope) : void 0;
      return resources.bindResource(
        resourceOwner,
        source,
        (value) => transaction(() => {
          try {
            const result = project(value);
            if (result && typeof result.then === "function") {
              Promise.resolve(result).catch(() => {
              });
              fault("Resource projections must be synchronous");
            }
          } catch (error) {
            fault(
              error instanceof Error ? error.message : "Resource projection failed"
            );
          }
        }, "config"),
        () => {
          var _a;
          return !scope || !scope.destroyed && form.query(scope.address).take() === scope && ((_a = configs.get(scope)) == null ? void 0 : _a.validationActive) !== false;
        }
      );
    },
    runLatest(key, input2, load, commit, settings) {
      if (!alive) return;
      const scope = (settings == null ? void 0 : settings.scope) && typeof settings.scope === "object" ? rawField(settings.scope) : settings == null ? void 0 : settings.scope;
      resources.runLatest(
        resourceOwner,
        key,
        input2,
        load,
        (value) => transaction(() => {
          const before = valueRevision;
          const result = commit(value);
          if (result && typeof result.then === "function") {
            Promise.resolve(result).catch(() => {
            });
            fault("Task commits must be synchronous");
          }
          if (!(settings == null ? void 0 : settings.blocking) && before !== valueRevision)
            fault("A non-blocking task changed submission values");
        }, "config"),
        { ...settings, scope },
        () => {
          var _a;
          return typeof scope !== "object" || !scope.destroyed && form.query(scope.address).take() === scope && ((_a = configs.get(scope)) == null ? void 0 : _a.validationActive) !== false;
        }
      );
    },
    retryLatest: (key, scope) => {
      if (alive)
        resources.retry(
          key,
          typeof scope === "object" ? rawField(scope) : scope
        );
    },
    cancelLatest: (key, scope, applicable) => {
      if (alive)
        resources.cancel(
          key,
          typeof scope === "object" ? rawField(scope) : scope,
          applicable
        );
    },
    configure,
    replaceSchema(schema) {
      if (!alive) return;
      if (!replace) return deny("replaceSchema before attachment");
      const compiled = compile(schema);
      replace(schema);
      transaction(() => {
        form.clearFormGraph("*", false);
        resources.prune(resourceOwner);
        configs.clear();
        controls.clear();
        configRevision++;
        controlsGeneration++;
        ledger.clear();
        schemaRef.value = compiled;
        schemaSerial.value++;
      });
    }
  };
  const schemaSerial = vue.shallowRef(0);
  const schemaRef = vue.shallowRef(compile(options.createSchema(context)));
  return {
    form,
    get schema() {
      return schemaRef.value;
    },
    get schemaSerial() {
      return schemaSerial.value;
    },
    context,
    version,
    faults,
    feedback,
    ledger,
    resources,
    flushResources: () => resources.refresh(resourceOwner),
    assertionIssues,
    controls,
    activeControls,
    arrayKeys: arrayTools.renderKeys,
    get initializing() {
      return initializing > 0;
    },
    get mutating() {
      return depth > 0 || deriving > 0;
    },
    get deriving() {
      return !!deriving;
    },
    get origin() {
      return origin ?? (deriving ? "reaction" : mounted ? "edit" : "initialization");
    },
    replaceCanonical(values) {
      return transaction(
        () => form.setValues(index.copy(values), "overwrite"),
        "authority"
      );
    },
    read,
    ticket,
    current,
    transaction,
    configure,
    assert,
    states,
    validate,
    validateField,
    register,
    setValues(patch) {
      return transaction(() => {
        const isolated = index.copy(patch);
        arrayTools.alignValues({ ...read(), ...isolated });
        form.setValues(isolated, "shallowMerge");
        resources.prune(resourceOwner);
      });
    },
    event(field, type, value) {
      if (!alive) return Promise.resolve(false);
      transaction(() => {
        if (type === "change") {
          const isolated = value === void 0 ? void 0 : index.copy(value);
          if (Array.isArray(isolated))
            arrayTools.align(
              field,
              isolated
            );
          field.setValue(isolated);
        } else field.setState({ active: type === "focus", visited: true });
      }, "edit");
      return validateField(
        field,
        type === "change" ? "onInput" : type === "blur" ? "onBlur" : "onFocus"
      );
    },
    mount() {
      mounted = true;
    },
    attachReplace(callback) {
      replace = callback;
    },
    dispose() {
      if (!alive) return;
      alive = false;
      resources.retire(resourceOwner);
      record.abort();
      disposers.forEach((dispose) => dispose());
      form.onUnmount();
    }
  };
}
function createFormSession(options) {
  const seed = index.copy(options.initial);
  const record = new AbortController();
  const resources = createResources(record.signal);
  let alive = true;
  let epoch = 0;
  let nextAttempt = 0;
  const lifecycle = vue.shallowRef({
    baseline: void 0,
    ready: false,
    pending: false,
    phase: "initializing",
    status: "初始化中",
    reconciliationRequired: false
  });
  function member(key2) {
    return vue.computed({
      get: () => lifecycle.value[key2],
      set: (value) => {
        lifecycle.value = { ...lifecycle.value, [key2]: value };
      }
    });
  }
  const baseline = member("baseline");
  let attempt;
  let accepting;
  let resultLock;
  let stopRuntime;
  let ledgerRefreshQueued = false;
  let managedPreparation;
  const editedPreparations = /* @__PURE__ */ new WeakSet();
  const runtime = vue.shallowRef();
  const ready = member("ready");
  const pending = member("pending");
  const phase = member("phase");
  const status = member("status");
  const issues = vue.shallowRef([]);
  const reconciliationRequired = member("reconciliationRequired");
  const key = vue.shallowRef(0);
  function uncertain(owner, reason) {
    var _a;
    if (!alive || resultLock && resultLock !== owner) return;
    resultLock = owner;
    reconciliationRequired.value = true;
    phase.value = "uncertain";
    status.value = reason;
    (_a = options.reconcileRequired) == null ? void 0 : _a.call(options, { reason });
  }
  function cancel(reason = "表单已更新，请重新提交") {
    const owner = attempt;
    if (!owner) return;
    if (owner.dispatched) uncertain(owner, "保存结果需重新载入核对");
    owner.controller.abort(reason);
    if (attempt !== owner) return;
    attempt = void 0;
    lifecycle.value = {
      ...lifecycle.value,
      pending: false,
      ...!reconciliationRequired.value ? { phase: "idle", status: reason } : {}
    };
  }
  const enabled = () => {
    var _a;
    return ((_a = options.enabled) == null ? void 0 : _a.call(options)) !== false;
  };
  function owns(owner) {
    return alive && attempt === owner && owner.epoch === epoch && runtime.value === owner.runtime;
  }
  function active(owner) {
    return owns(owner) && !owner.controller.signal.aborted && owner.runtime.current(owner.stamp) && enabled();
  }
  function build(values, owner, schema) {
    var _a;
    stopRuntime == null ? void 0 : stopRuntime();
    (_a = runtime.value) == null ? void 0 : _a.dispose();
    const buildingEpoch = ++epoch;
    ready.value = false;
    if (!alive || epoch !== buildingEpoch) return void 0;
    const next = createRuntime({
      initial: index.copy(values),
      resourceHost: resources,
      recordSignal: record.signal,
      createSchema: options.createSchema,
      assertSettled: options.assertSettled,
      arrayKeys: options.arrayKeys,
      components: options.components
    });
    if (!alive || epoch !== buildingEpoch) {
      next.dispose();
      return void 0;
    }
    if (owner) {
      owner.runtime = next;
      owner.epoch = epoch;
      owner.stamp = next.ticket();
    }
    stopRuntime = vue.watch(
      () => {
        next.version.value;
        return next.ticket();
      },
      (stamp) => {
        if (managedPreparation === next && next.origin === "edit")
          editedPreparations.add(next);
        if (accepting && owns(accepting) && next.origin !== "edit") {
          accepting.stamp = stamp;
        } else if ((attempt == null ? void 0 : attempt.preparing) && (next.origin === "control" || next.origin === "initialization" || next.initializing || next.origin === "reaction"))
          attempt.stamp = stamp;
        else if (attempt) cancel();
        if (next.origin === "edit") {
          issues.value = [];
          if (!ledgerRefreshQueued) {
            ledgerRefreshQueued = true;
            queueMicrotask(() => {
              ledgerRefreshQueued = false;
              if (alive && runtime.value === next) next.ledger.changed();
            });
          }
        } else next.ledger.project();
      },
      { flush: "sync" }
    );
    next.attachReplace(() => {
      if (!alive || runtime.value !== next) return;
      cancel("表单结构已更新");
      ready.value = false;
      vue.nextTick().then(() => {
        if (alive && runtime.value === next) ready.value = next.assert();
      });
    });
    runtime.value = next;
    if (!alive || epoch !== buildingEpoch || runtime.value !== next)
      return void 0;
    key.value++;
    return next;
  }
  const read = () => runtime.value.read();
  const dirty = vue.computed(
    () => baseline.value === void 0 || !index.equal(read(), baseline.value)
  );
  const fieldPending = vue.computed(() => {
    runtime.value.version.value;
    return resources.pending() || runtime.value.activeControls().some(([, item]) => item.state.pending);
  });
  const blocked = vue.computed(() => {
    const model = runtime.value;
    model.version.value;
    return !!resources.issues().length || !ready.value || reconciliationRequired.value || !!model.faults.value.length || !!model.assertionIssues.value.length || model.activeControls().some(([, item]) => {
      var _a;
      return (_a = item.state.blocking) == null ? void 0 : _a.length;
    });
  });
  const formIssues = vue.computed(() => [
    ...resources.feedback(),
    ...runtime.value.ledger.formIssues.value,
    ...runtime.value.faults.value,
    ...runtime.value.assertionIssues.value,
    ...runtime.value.activeControls().flatMap(([, item]) => item.state.blocking ?? []).map((message) => ({ message: message.message }))
  ]);
  function focus(path) {
    const model = runtime.value;
    const values = model.read();
    const candidates = [...model.controls].filter(
      ([field, item]) => item.mounted && field.display === "visible"
    );
    const visibleError = () => candidates.find(
      ([field, item]) => {
        var _a, _b;
        return ((_a = model.feedback.value.get(field)) == null ? void 0 : _a.some((issue) => (issue.severity ?? "error") === "error")) || ((_b = item.state.blocking) == null ? void 0 : _b.length);
      }
    );
    const match = (path ? candidates.filter(
      ([field, item]) => (field.path.length === path.length || item.composite) && dataPath(field.path.toArr(), values).every(
        (segment, index2) => segment === path[index2]
      )
    ).sort((a, b) => b[0].path.length - a[0].path.length)[0] : void 0) ?? visibleError();
    match == null ? void 0 : match[1].control.focus(
      path && dataPath(match[0].path.toArr(), values).every(
        (segment, index2) => segment === path[index2]
      ) ? path.slice(match[0].path.length) : void 0
    );
  }
  function initialize() {
    if (!alive || ready.value) return false;
    const model = runtime.value;
    if (managedPreparation === model) return false;
    model.flushResources();
    if (resources.issues().length) {
      phase.value = "initializing";
      status.value = "等待必要资源";
      return false;
    }
    if (!model.assert()) {
      phase.value = "blocked";
      status.value = "初始化未满足提交约束";
      return false;
    }
    lifecycle.value = {
      ...lifecycle.value,
      // Resource completion can restore readiness after failed authority. Only
      // the first initialization may establish a baseline here; later authority
      // and save acceptance own explicit baseline transactions.
      baseline: baseline.value ?? model.read(),
      ready: true,
      phase: reconciliationRequired.value ? "uncertain" : "idle",
      status: reconciliationRequired.value ? "保存结果需重新载入核对" : "已载入"
    };
    return true;
  }
  function setValues(patch) {
    if (!alive) return false;
    const model = runtime.value;
    const before = model.read();
    const next = index.copy(patch);
    if (Object.entries(next).every(
      ([key2, value]) => index.equal(before[key2], value)
    ))
      return false;
    if (managedPreparation === model) editedPreparations.add(model);
    cancel();
    model.setValues(next);
    model.assert();
    return true;
  }
  async function settleBuilt(model, signal, commit) {
    await vue.nextTick();
    if (!alive || runtime.value !== model || (signal == null ? void 0 : signal.aborted)) return false;
    model.flushResources();
    if (resources.requiredPending()) {
      await new Promise((resolve) => {
        let stop;
        const finish = () => {
          stop == null ? void 0 : stop();
          signal == null ? void 0 : signal.removeEventListener("abort", finish);
          resolve();
        };
        const check = () => {
          if (!alive || runtime.value !== model || !resources.requiredPending() || (signal == null ? void 0 : signal.aborted))
            finish();
        };
        stop = vue.watch([resources.version, () => runtime.value], check, {
          flush: "sync"
        });
        signal == null ? void 0 : signal.addEventListener("abort", finish, { once: true });
        check();
      });
    }
    const valid = alive && runtime.value === model && !(signal == null ? void 0 : signal.aborted) && !resources.issues().length && model.assert() && !editedPreparations.has(model);
    if (alive && runtime.value === model && !(signal == null ? void 0 : signal.aborted)) commit == null ? void 0 : commit(valid);
    return valid;
  }
  async function replaceValues(values, mode) {
    if (!alive) return false;
    cancel();
    const previousBaseline = baseline.value;
    const next = build(values);
    if (!next || runtime.value !== next) return false;
    managedPreparation = next;
    if (!await settleBuilt(next)) {
      if (managedPreparation === next) managedPreparation = void 0;
      if (runtime.value === next && editedPreparations.has(next) && !resources.issues().length) {
        lifecycle.value = {
          ...lifecycle.value,
          ready: next.assert(),
          phase: reconciliationRequired.value ? "uncertain" : "idle",
          status: "权威回填已因新编辑取消"
        };
      }
      return false;
    }
    if (managedPreparation === next) managedPreparation = void 0;
    lifecycle.value = {
      ...lifecycle.value,
      baseline: mode === "authority" ? next.read() : previousBaseline,
      ready: true,
      phase: reconciliationRequired.value ? "uncertain" : "idle"
    };
    return true;
  }
  function reset() {
    if (!alive) return;
    cancel("已恢复保存基线");
    const previousBaseline = baseline.value;
    const next = build(previousBaseline ?? seed);
    if (!next || runtime.value !== next) return;
    managedPreparation = next;
    settleBuilt(next, void 0, (valid) => {
      if (!next || runtime.value !== next) return;
      if (managedPreparation === next) managedPreparation = void 0;
      lifecycle.value = {
        ...lifecycle.value,
        baseline: previousBaseline ?? (valid ? next.read() : void 0),
        ready: valid,
        phase: valid ? reconciliationRequired.value ? "uncertain" : "idle" : "blocked",
        status: valid ? reconciliationRequired.value ? "保存结果需重新载入核对" : "已恢复保存基线" : "基线初始化失败"
      };
    }).catch((error) => {
      if (alive && runtime.value === next)
        lifecycle.value = {
          ...lifecycle.value,
          ready: false,
          phase: "blocked",
          status: error instanceof Error ? error.message : "基线初始化失败"
        };
    });
  }
  async function reconcile(values) {
    if (!await replaceValues(values, "authority")) return false;
    resultLock = void 0;
    reconciliationRequired.value = false;
    phase.value = "idle";
    status.value = "已核对服务端记录";
    return true;
  }
  async function run(saving) {
    var _a, _b, _c, _d;
    if (!alive || pending.value || !ready.value || reconciliationRequired.value || !enabled() || saving && !options.save)
      return false;
    const model = runtime.value;
    model.flushResources();
    const owner = {
      id: ++nextAttempt,
      runtime: model,
      stamp: model.ticket(),
      epoch,
      controller: new AbortController(),
      dispatched: false
    };
    let focusWanted = false;
    let focusPath;
    const requestFocus = (path) => {
      focusWanted = true;
      focusPath = path;
    };
    attempt = owner;
    pending.value = true;
    const check = () => !resources.issues().length && active(owner) && owner.runtime.assert() && !owner.runtime.activeControls().some(([, item]) => {
      var _a2;
      return (_a2 = item.state.blocking) == null ? void 0 : _a2.length;
    });
    try {
      if (!active(owner)) return false;
      phase.value = "validating";
      if (!active(owner)) return false;
      status.value = "校验中";
      if (!active(owner)) return false;
      issues.value = [];
      owner.preparing = true;
      await vue.nextTick();
      owner.preparing = false;
      if (owns(owner)) owner.stamp = model.ticket();
      if (!check()) {
        if (active(owner)) requestFocus();
        return false;
      }
      const snapshot = model.read();
      if (!await awaitSignal(model.validate(), owner.controller.signal) || !check()) {
        if (active(owner)) requestFocus();
        return false;
      }
      const joint = await awaitSignal(
        Promise.resolve(
          ((_a = options.validate) == null ? void 0 : _a.call(options, index.copy(snapshot), owner.controller.signal)) ?? []
        ),
        owner.controller.signal
      );
      if (!check()) return false;
      if (joint.length) {
        model.ledger.set("SessionDomain", joint, snapshot);
        issues.value = joint;
        phase.value = "invalid";
        status.value = "请检查表单中的错误";
        requestFocus(
          (_b = joint.find((issue) => (issue.severity ?? "error") === "error")) == null ? void 0 : _b.path
        );
        return false;
      }
      if (!saving) {
        phase.value = "idle";
        status.value = "校验通过";
        return true;
      }
      phase.value = "saving";
      if (!check()) return false;
      status.value = "保存中";
      if (!check()) return false;
      owner.dispatched = true;
      const work = Promise.resolve(
        options.save(index.copy(snapshot), owner.controller.signal)
      );
      work.then(
        (result2) => {
          if (!result2.ok && result2.outcome !== "unknown" && resultLock === owner && alive) {
            resultLock = void 0;
            reconciliationRequired.value = false;
          }
        },
        () => {
        }
      );
      const result = await awaitSignal(work, owner.controller.signal);
      if (!active(owner)) return false;
      if (!result.ok) {
        if (result.outcome === "unknown")
          uncertain(owner, "保存结果需重新载入核对");
        else {
          model.ledger.set("SessionServer", result.issues, snapshot);
          issues.value = result.issues;
          phase.value = "invalid";
          status.value = "保存被拒绝，请纠正后重试";
          requestFocus(
            (_c = result.issues.find(
              (issue) => (issue.severity ?? "error") === "error"
            )) == null ? void 0 : _c.path
          );
        }
        return false;
      }
      accepting = owner;
      const authoritative = result.values ?? snapshot;
      if (!index.equal(authoritative, snapshot)) build(authoritative, owner);
      if (!await settleBuilt(owner.runtime, owner.controller.signal) || !check()) {
        uncertain(owner, "已保存，当前显示需重新载入核对");
        return false;
      }
      owner.runtime.ledger.clear();
      if (!check()) {
        uncertain(owner, "已保存，当前显示需重新载入核对");
        return false;
      }
      const committed = owner.runtime.read();
      accepting = void 0;
      attempt = void 0;
      lifecycle.value = {
        baseline: index.copy(committed),
        ready: true,
        pending: false,
        phase: "saved",
        status: "已保存",
        reconciliationRequired: false
      };
      (_d = options.saved) == null ? void 0 : _d.call(options, committed);
      return true;
    } catch (error) {
      if (owner.dispatched && alive) uncertain(owner, "保存结果需重新载入核对");
      else if (owns(owner) && !owner.controller.signal.aborted) {
        phase.value = "invalid";
        status.value = error instanceof Error ? error.message : "校验失败";
        issues.value = [{ message: status.value }];
        owner.runtime.ledger.set("SessionDomain", issues.value);
      }
      return false;
    } finally {
      if (accepting === owner) accepting = void 0;
      if (attempt === owner) {
        if (owner.dispatched && !active(owner) && alive)
          uncertain(owner, "保存结果需重新载入核对");
        const wasWorking = phase.value === "validating" || phase.value === "saving";
        const nextPhase = wasWorking ? blocked.value ? "blocked" : "invalid" : phase.value;
        const nextStatus = wasWorking ? "表单已更新或包含错误，请重新提交" : status.value;
        attempt = void 0;
        lifecycle.value = {
          ...lifecycle.value,
          pending: false,
          phase: nextPhase,
          status: nextStatus
        };
      }
      if (focusWanted) {
        await vue.nextTick();
        if (alive && !attempt && runtime.value === owner.runtime && !pending.value)
          focus(focusPath);
      }
    }
  }
  build(seed);
  const stopResources = vue.watch(
    resources.version,
    () => {
      if (!ready.value && !pending.value && !resources.issues().length)
        vue.nextTick().then(initialize);
    },
    { flush: "sync" }
  );
  return {
    runtime,
    key: vue.readonly(key),
    ready: vue.readonly(ready),
    dirty,
    pending: vue.readonly(pending),
    phase: vue.readonly(phase),
    status: vue.readonly(status),
    issues: vue.readonly(issues),
    formIssues,
    fieldPending,
    blocked,
    reconciliationRequired: vue.readonly(reconciliationRequired),
    read,
    setValues,
    replaceValues,
    reset,
    reconcile,
    focus,
    initialize,
    async rebind(components) {
      cancel("字段控件已替换");
      options.components = components;
      const values = read();
      const next = build(values);
      if (!next || runtime.value !== next) return;
      managedPreparation = next;
      await settleBuilt(next, void 0, (valid) => {
        if (managedPreparation === next) managedPreparation = void 0;
        lifecycle.value = {
          ...lifecycle.value,
          ready: valid,
          phase: reconciliationRequired.value ? "uncertain" : valid ? "idle" : "blocked"
        };
      });
    },
    validate: () => run(false),
    submit: () => run(true),
    cancel,
    dispose() {
      var _a;
      if (!alive) return;
      cancel();
      alive = false;
      stopResources();
      record.abort();
      stopRuntime == null ? void 0 : stopRuntime();
      (_a = runtime.value) == null ? void 0 : _a.dispose();
    }
  };
}
const _hoisted_1 = ["data-label-position"];
const _hoisted_2 = ["aria-busy"];
const _hoisted_3 = {
  key: 0,
  class: "schema-form__uncertain",
  role: "alert"
};
const _hoisted_4 = {
  key: 1,
  class: "schema-form__errors",
  role: "alert"
};
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxSchemaForm", inheritAttrs: false },
  __name: "SchemaForm",
  props: {
    initial: {},
    createSchema: {},
    assertSettled: {},
    save: {},
    validate: {},
    bindings: {},
    disabled: { type: Boolean },
    arrayKeys: {},
    columns: { default: 1 },
    labelPosition: { default: "top" },
    labelWidth: {}
  },
  emits: ["saved", "reconcile-required"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const registeredBindings = vue.shallowRef({
      ...createZxuiBindings(),
      ...props.bindings
    });
    const session = createFormSession({
      components: [
        ...Object.keys(registeredBindings.value),
        "ZxSection",
        "ZxArray",
        "ZxField"
      ],
      initial: props.initial,
      createSchema: props.createSchema,
      assertSettled: props.assertSettled,
      arrayKeys: props.arrayKeys,
      save: props.save,
      validate: props.validate,
      enabled: () => !props.disabled,
      saved: (values) => emit("saved", values),
      reconcileRequired: (event) => emit("reconcile-required", event)
    });
    const Engine = vue.computed(() => {
      const runtime = session.runtime.value;
      const { SchemaField } = vue$1.createSchemaField({
        components: createBindings(
          runtime,
          registeredBindings.value,
          () => !!props.disabled || session.pending.value
        )
      });
      return vue.markRaw(
        vue.defineComponent({
          setup() {
            vue.onMounted(() => runtime.mount());
            return () => vue.h(
              vue$1.FormProvider,
              { form: runtime.form },
              {
                default: () => vue.h(SchemaField, {
                  key: runtime.schemaSerial,
                  schema: runtime.schema
                })
              }
            );
          }
        })
      );
    });
    vue.watch(
      () => props.bindings,
      (bindings) => {
        registeredBindings.value = { ...createZxuiBindings(), ...bindings };
        session.rebind([
          ...Object.keys(registeredBindings.value),
          "ZxSection",
          "ZxArray",
          "ZxField"
        ]);
      }
    );
    vue.onMounted(session.initialize);
    vue.onBeforeUnmount(session.dispose);
    const messages = vue.computed(() => session.formIssues.value);
    __expose({
      read: session.read,
      setValues: session.setValues,
      replaceValues: session.replaceValues,
      validate: session.validate,
      submit: session.submit,
      reset: session.reset,
      reconcile: session.reconcile,
      focus: session.focus,
      ready: session.ready,
      dirty: session.dirty,
      pending: session.pending,
      fieldPending: session.fieldPending,
      blocked: session.blocked,
      reconciliationRequired: session.reconciliationRequired,
      phase: session.phase,
      status: session.status
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("section", vue.mergeProps(_ctx.$attrs, {
        class: ["schema-form", `schema-form--columns-${__props.columns}`],
        "data-label-position": __props.labelPosition,
        style: {
          "--schema-label-width": typeof __props.labelWidth === "number" ? `${__props.labelWidth}px` : __props.labelWidth
        }
      }), [
        vue.createElementVNode("form", {
          class: "schema-form__grid",
          novalidate: "",
          "aria-busy": vue.unref(session).pending.value || void 0,
          onSubmit: _cache[0] || (_cache[0] = vue.withModifiers(($event) => vue.unref(session).submit(), ["prevent"]))
        }, [
          (vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(Engine.value), {
            key: vue.unref(session).key.value
          }))
        ], 40, _hoisted_2),
        vue.unref(session).reconciliationRequired.value ? (vue.openBlock(), vue.createElementBlock("p", _hoisted_3, vue.toDisplayString(vue.unref(session).status.value), 1)) : vue.createCommentVNode("", true),
        messages.value.length ? (vue.openBlock(), vue.createElementBlock("ul", _hoisted_4, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(messages.value, (issue, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", { key: index2 }, vue.toDisplayString(issue.message), 1);
          }), 128))
        ])) : vue.createCommentVNode("", true),
        vue.renderSlot(_ctx.$slots, "diagnostics", {
          status: vue.unref(session).status.value,
          ready: vue.unref(session).ready.value,
          dirty: vue.unref(session).dirty.value,
          pending: vue.unref(session).pending.value,
          fieldPending: vue.unref(session).fieldPending.value,
          blocked: vue.unref(session).blocked.value,
          phase: vue.unref(session).phase.value,
          reconciliationRequired: vue.unref(session).reconciliationRequired.value
        })
      ], 16, _hoisted_1);
    };
  }
});
function keys(value, allowed) {
  for (const key of Object.keys(value))
    if (!allowed.includes(key))
      throw new Error(`Unsupported definition key: ${key}`);
}
function prop(name, value) {
  if (["placeholder", "aria-label"].includes(name))
    return typeof value === "string";
  if (name === "type")
    return typeof value === "string" && [
      "text",
      "textarea",
      "password",
      "email",
      "url",
      "tel",
      "search",
      "number"
    ].includes(value);
  if (name === "controlsPosition") return value === "" || value === "right";
  if (["clearable", "filterable", "remote", "disabled", "controls"].includes(name))
    return typeof value === "boolean";
  if (name === "valueOnClear")
    return value === null || typeof value === "string" || typeof value === "number" && Number.isFinite(value);
  if ([
    "min",
    "max",
    "step",
    "precision",
    "rows",
    "maxlength",
    "maxCount"
  ].includes(name)) {
    if (typeof value !== "number" || !Number.isFinite(value)) return false;
    if (name === "step") return value > 0;
    if (["min", "max"].includes(name)) return true;
    return Number.isInteger(value) && value >= (name === "rows" ? 1 : 0) && value <= (name === "precision" ? 20 : name === "rows" ? 100 : 1e5);
  }
  if (name === "options")
    return Array.isArray(value) && value.length <= 200 && value.every((item) => {
      if (!index.record(item) || Object.keys(item).some(
        (key) => !["label", "value", "disabled"].includes(key)
      ))
        return false;
      return typeof item.label === "string" && ["string", "number", "boolean"].includes(typeof item.value) && (typeof item.value !== "number" || Number.isFinite(item.value)) && (item.disabled === void 0 || typeof item.disabled === "boolean");
    });
  return false;
}
function validation(input2) {
  if (!Array.isArray(input2))
    throw new Error("Expected validator description array");
  return input2.map((description) => {
    if (!index.record(description)) throw new Error("Invalid validation rule");
    keys(description, [
      "required",
      "valueType",
      "min",
      "max",
      "message",
      "triggerType"
    ]);
    if (description.required !== void 0 && typeof description.required !== "boolean")
      throw new Error("Invalid required");
    if (description.valueType !== void 0 && !["string", "number", "array"].includes(String(description.valueType)))
      throw new Error("Invalid valueType");
    if (description.triggerType !== void 0 && !["onInput", "onBlur"].includes(String(description.triggerType)))
      throw new Error("Invalid triggerType");
    if (description.message !== void 0 && typeof description.message !== "string")
      throw new Error("Invalid validation message");
    for (const bound of ["min", "max"])
      if (description[bound] !== void 0 && (typeof description[bound] !== "number" || !Number.isFinite(description[bound]) || Number(description[bound]) < 0))
        throw new Error("Invalid validation bound");
    if (typeof description.min === "number" && typeof description.max === "number" && description.min > description.max)
      throw new Error("Invalid validation range");
    const { valueType, min, max, message, required, triggerType } = description;
    return {
      ...required !== void 0 ? { required } : {},
      ...triggerType ? { triggerType } : {},
      message,
      validator(value) {
        if (value === void 0 || value === null || value === "") return "";
        const invalid = () => typeof message === "string" ? message : "字段值类型或范围不符合定义";
        if (valueType === "number" && (typeof value !== "number" || !Number.isFinite(value)))
          return invalid();
        if (valueType === "string" && typeof value !== "string")
          return invalid();
        if (valueType === "array" && !Array.isArray(value)) return invalid();
        const size = typeof value === "number" ? value : typeof value === "string" || Array.isArray(value) ? value.length : void 0;
        if ((min !== void 0 || max !== void 0) && (size === void 0 || typeof min === "number" && size < min || typeof max === "number" && size > max))
          return invalid();
        return "";
      }
    };
  });
}
function parseDefinition(text, policy) {
  if (text.length > 1e5) throw new Error("Definition exceeds supported size");
  const value = JSON.parse(text);
  index.safeJson(value);
  if (!index.record(value)) throw new Error("Expected definition object");
  keys(value, ["id", "revision", "engine", "contract", "schema"]);
  if (typeof value.id !== "string" || !value.id || value.id.length > 120 || !Number.isSafeInteger(value.revision) || Number(value.revision) < 1 || value.engine !== "formily@2.3.7" || value.contract !== "zxui-schema-form-v2")
    throw new Error("Unsupported definition identity/version");
  let count = 0;
  const fields = /* @__PURE__ */ new Set();
  function node(input2, depth = 0, root = false) {
    var _a, _b;
    if (++count > 200 || depth > 16)
      throw new Error("Definition exceeds schema node/depth limit");
    if (!index.record(input2)) throw new Error("Invalid schema node");
    keys(input2, [
      "type",
      "title",
      "properties",
      "x-component",
      "x-component-props",
      "x-decorator",
      "required",
      "x-validator"
    ]);
    if (!["object", "void", "string", "number", "array"].includes(
      String(input2.type)
    ) || root && input2.type !== "object")
      throw new Error("Invalid schema type");
    if (input2.title !== void 0 && typeof input2.title !== "string")
      throw new Error("Invalid title");
    if (input2.required !== void 0 && typeof input2.required !== "boolean")
      throw new Error("Invalid required");
    if (input2["x-decorator"] !== void 0 && input2["x-decorator"] !== "ZxField")
      throw new Error("Unknown decorator");
    const component = input2["x-component"];
    if (component !== void 0 && (typeof component !== "string" || !Object.hasOwn(policy, component)))
      throw new Error("Unknown component");
    if (!root && input2.type !== "void" && component === void 0)
      throw new Error("A data field requires a registered component");
    const result = { type: input2.type };
    if (input2.title !== void 0) result.title = input2.title;
    if (input2.required !== void 0)
      result.required = input2.required;
    if (component !== void 0) result["x-component"] = component;
    if (input2["x-decorator"] !== void 0) result["x-decorator"] = "ZxField";
    if (input2["x-component-props"] !== void 0) {
      const props = input2["x-component-props"];
      if (!index.record(props) || typeof component !== "string")
        throw new Error("Invalid component props");
      keys(props, policy[component].props);
      for (const [name, v] of Object.entries(props))
        if (!(((_b = (_a = policy[component].validators) == null ? void 0 : _a[name]) == null ? void 0 : _b.call(_a, v)) ?? prop(name, v)))
          throw new Error(`Invalid component prop: ${name}`);
      result["x-component-props"] = props;
    }
    if (input2["x-validator"] !== void 0)
      result["x-validator"] = validation(input2["x-validator"]);
    if (input2.properties !== void 0) {
      if (!root && input2.type !== "void" || !index.record(input2.properties))
        throw new Error(
          "Only root object/void layout may contain JSON properties"
        );
      result.properties = Object.fromEntries(
        Object.entries(input2.properties).map(([name, child]) => {
          if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || Object.hasOwn(Object.prototype, name) || name === "prototype")
            throw new Error("Unsafe field path");
          if (index.record(child) && child.type !== "void") {
            if (fields.has(name)) throw new Error("Duplicate flat data path");
            fields.add(name);
          }
          return [name, node(child, depth + 1)];
        })
      );
    }
    return result;
  }
  return {
    id: value.id,
    revision: Number(value.revision),
    engine: "formily@2.3.7",
    contract: "zxui-schema-form-v2",
    schema: node(value.schema, 0, true)
  };
}
exports.ZxSchemaForm = _sfc_main;
exports.createZxuiBindings = createZxuiBindings;
exports.createZxuiDefinitionPolicy = createZxuiDefinitionPolicy;
exports.parseDefinition = parseDefinition;
