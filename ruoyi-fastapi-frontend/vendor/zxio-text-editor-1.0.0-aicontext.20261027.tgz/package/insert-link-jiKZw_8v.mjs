import { G as f } from "./use-text-editor-command-keybindings-CBbgIoWy.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-link-jiKZw_8v.mjs.map
