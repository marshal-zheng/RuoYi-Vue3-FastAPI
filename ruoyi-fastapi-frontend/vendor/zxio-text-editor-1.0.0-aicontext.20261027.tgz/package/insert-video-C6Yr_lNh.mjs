import { E as f } from "./use-text-editor-command-keybindings-CBbgIoWy.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-video-C6Yr_lNh.mjs.map
