# @zxio/theme-pap-olive

PAP Olive is a People's Armed Police 07-series 深橄榄绿 Theme v4 package.
Gold piping (双黄线) is the glow seed that distinguishes it from Army pine.

Run `pnpm -C packages/theme-pap-olive build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
