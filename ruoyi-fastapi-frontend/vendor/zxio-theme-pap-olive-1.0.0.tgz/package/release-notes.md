# Release notes

## 1.0.0

- Add the PAP Olive Theme v4 package with 162 deterministic variants.
- Anchor chrome to a screen-safe reconstruction of PAP 07 深橄榄绿.
  Gold piping is the glow material at 0.45 intensity so it reads as
  service piping rather than a neon frame.
