import type { GridListRequestState } from './props';
import type { GridListLoadOptions } from './use-grid-request';
declare function clearTableSelection(): void;
declare function renderTableEmpty(): import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>;
declare var __VLS_1: {
    mode: "request";
    status: GridListRequestState;
    data: import("./props").GridListDisplayState;
    loading: boolean;
    search: (options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>;
    reset: (options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>;
    reload: (options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>;
    draft: import("@zxio/zxui").GridListDraft;
    setDraft: (value: Readonly<import("@zxio/zxui").GridListDraft>, options?: {
        replace?: boolean;
    }) => void;
    applied: import("@zxio/zxui").GridListApplied | null;
    dirty: boolean;
    requery: (change: import("./use-grid-request").GridListRequery, options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>;
} | {
    mode: "controlled";
    status: GridListRequestState;
    data: import("./props").GridListControlledState<any>;
    loading: boolean;
    reload(): void;
}, __VLS_3: {
    loading: boolean;
    refreshing: boolean;
    error: unknown;
    paused: boolean;
    domain: "ready" | "switched" | "unavailable";
    cancelled: boolean;
    hasData: boolean;
    retry: () => void;
}, __VLS_5: {
    loading: boolean;
    refreshing: boolean;
    error: unknown;
    paused: boolean;
    domain: "ready" | "switched" | "unavailable";
    cancelled: boolean;
    hasData: boolean;
    retry: () => void;
}, __VLS_15: {
    mode: "request";
    status: GridListRequestState;
    grid: import("./props").GridListDisplayState;
    loading: boolean;
    hasData: boolean;
    isEmpty: boolean;
    emptySlot: ((...args: unknown[]) => import("vue").VNodeChild) | undefined;
    renderEmpty: import("@zxio/zxui").ZxGridListRequestInstance["renderTableEmpty"];
    reload: (options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>;
    applied: import("@zxio/zxui").GridListApplied | null;
    requery: (change: import("./use-grid-request").GridListRequery, options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>;
} | {
    loading: boolean;
    status: GridListRequestState;
    hasData: boolean;
    isEmpty: boolean;
    emptySlot: ((...args: unknown[]) => import("vue").VNodeChild) | undefined;
    renderEmpty: import("@zxio/zxui").ZxGridListRequestInstance["renderTableEmpty"];
    mode: "controlled";
    grid: import("./props").GridListControlledState<any>;
    reload(): void;
}, __VLS_17: {
    mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    reload: (options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion> | undefined;
    error: null;
    isError: boolean;
}, __VLS_22: {}, __VLS_32: {
    pager: Readonly<import("./props").GridListPagerState>;
};
type __VLS_Slots = {} & {
    form?: (props: typeof __VLS_1) => any;
} & {
    error?: (props: typeof __VLS_3) => any;
} & {
    status?: (props: typeof __VLS_5) => any;
} & {
    table?: (props: typeof __VLS_15) => any;
} & {
    empty?: (props: typeof __VLS_17) => any;
} & {
    emptyImage?: (props: typeof __VLS_22) => any;
} & {
    pagination?: (props: typeof __VLS_32) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly mode: import("@zxio/shared").EpPropFinalized<StringConstructor, "request" | "controlled", unknown, "request", boolean>;
    readonly loadData: {
        readonly type: import("vue").PropType<import("@zxio/zxui").GridListQueryLoader>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly queryRecordLimit: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 128, boolean>;
    readonly queryContext: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListQueryContext) | (() => import("@zxio/zxui").GridListQueryContext) | {
        (): import("@zxio/zxui").GridListQueryContext;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListQueryContext) | (() => import("@zxio/zxui").GridListQueryContext) | {
        (): import("@zxio/zxui").GridListQueryContext;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly queryResultMetadata: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListQueryMetadataResolver) | (() => import("@zxio/zxui").GridListQueryMetadataResolver) | {
        (): import("@zxio/zxui").GridListQueryMetadataResolver;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListQueryMetadataResolver) | (() => import("@zxio/zxui").GridListQueryMetadataResolver) | {
        (): import("@zxio/zxui").GridListQueryMetadataResolver;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly rows: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => readonly any[]) | (() => readonly any[]) | {
        (): readonly any[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => readonly any[]) | (() => readonly any[]) | {
        (): readonly any[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly pagination: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | {
        (): Readonly<import("./props").GridListPagerState> | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | {
        (): Readonly<import("./props").GridListPagerState> | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly status: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListControlledStatus>) | (() => Readonly<import("./props").GridListControlledStatus>) | {
        (): Readonly<import("./props").GridListControlledStatus>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Readonly<import("./props").GridListControlledStatus>) | (() => Readonly<import("./props").GridListControlledStatus>) | {
        (): Readonly<import("./props").GridListControlledStatus>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly defaults: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListDefaults) | (() => import("@zxio/zxui").GridListDefaults) | {
        (): import("@zxio/zxui").GridListDefaults;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListDefaults) | (() => import("@zxio/zxui").GridListDefaults) | {
        (): import("@zxio/zxui").GridListDefaults;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    readonly queryValidator: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListQueryValidator) | (() => import("@zxio/zxui").GridListQueryValidator) | {
        (): import("@zxio/zxui").GridListQueryValidator;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListQueryValidator) | (() => import("@zxio/zxui").GridListQueryValidator) | {
        (): import("@zxio/zxui").GridListQueryValidator;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly draftHold: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean) | (() => () => boolean) | {
        (): () => boolean;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean) | (() => () => boolean) | {
        (): () => boolean;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly maxSortItems: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly showPagination: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pageSizes: import("@zxio/shared").EpPropFinalized<ArrayConstructor, unknown, unknown, () => number[], boolean>;
    readonly paginationLayout: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "total, sizes, prev, pager, next, jumper", boolean>;
    readonly small: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly paginationBackground: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadOnMounted: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly queryTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (q: any) => any, boolean>;
    readonly paramsTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (p: any) => any, boolean>;
    readonly autoRefresh: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | {
        (): boolean | import("./props").GridListAutoRefreshConfig;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | {
        (): boolean | import("./props").GridListAutoRefreshConfig;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, false, boolean>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly syncUrlState: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly urlStateKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "_state", boolean>;
    readonly pageFrom0: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly debounceDelay: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 300, boolean>;
    readonly defaultPageSize: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly emptyDescription: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly emptyImage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly emptyImageSize: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly showRefreshButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showTableBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>, {
    reload: (options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion> | undefined;
    mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    state: import("vue").ComputedRef<{
        readonly list: readonly any[];
        readonly loading: boolean;
        readonly error: Readonly<unknown>;
        readonly lastLoadTime: number | null;
        readonly silent: boolean;
        readonly displayed: {
            readonly logicalInput: {
                readonly query: {
                    readonly [x: string]: any;
                };
                readonly pager: {
                    readonly page: number;
                    readonly size: number;
                } | null;
                readonly sort: readonly {
                    readonly field: string;
                    readonly order: "asc" | "desc";
                }[];
            } | null;
            readonly sort: readonly {
                readonly field: string;
                readonly order: "asc" | "desc";
            }[];
            readonly resultRef: import("@zxio/zxui").QueryResultRef;
            readonly resultRevision: number;
            readonly requestRef: import("@zxio/zxui").QueryRequestRef | null;
            readonly condition: {
                readonly [x: string]: Readonly<unknown>;
            };
            readonly pagination: {
                readonly [x: string]: Readonly<unknown>;
            } | null;
            readonly rows: readonly Readonly<unknown>[];
            readonly provenance: "request-result" | "host-result";
            readonly server?: {
                readonly completeness: "complete" | "partial" | "unknown";
                readonly source: string;
                readonly scope: string;
                readonly snapshotVersion?: string | undefined;
            } | null | undefined;
        } | null;
        readonly domain: "ready" | "switched" | "unavailable";
        readonly cancelled: boolean;
    } | {
        readonly list: readonly any[];
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        } | null;
        readonly loading: boolean;
        readonly error: {} | null;
        readonly lastLoadTime: null;
        readonly silent: boolean;
        readonly domain: "ready" | "unavailable" | "switched";
        readonly cancelled: boolean;
    }>;
    clearTableSelection: typeof clearTableSelection;
    renderTableEmpty: typeof renderTableEmpty;
    draft?: import("@zxio/zxui").GridListDraft | undefined;
    applied?: import("vue").ComputedRef<Readonly<{
        query: import("@zxio/zxui").QuerySafeObject;
        pager: import("@zxio/zxui").GridListPager | null;
        sort: readonly import("@zxio/zxui").GridListSortItem[];
    }> | null> | undefined;
    dirty?: import("vue").ComputedRef<boolean> | undefined;
    displayed?: import("vue").ComputedRef<import("@zxio/zxui").GridListQueryDisplayed | null> | undefined;
    setDraft?: ((value: Readonly<import("@zxio/zxui").GridListDraft>, options?: {
        replace?: boolean;
    }) => void) | undefined;
    search?: ((options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>) | undefined;
    reset?: ((options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>) | undefined;
    requery?: ((change: import("./use-grid-request").GridListRequery, options?: GridListLoadOptions) => Promise<import("@zxio/zxui").GridListQueryCompletion>) | undefined;
    queryOwner?: import("@zxio/zxui").GridListQueryOwner | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: any) => void;
    reload: () => void;
    "page-change": (_page: import("./props").GridListPageChange) => void;
    beforeLoad: (params: any) => void;
    dataLoaded: (data: any) => void;
    loadError: (error: any) => void;
    selectionCleared: () => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly mode: import("@zxio/shared").EpPropFinalized<StringConstructor, "request" | "controlled", unknown, "request", boolean>;
    readonly loadData: {
        readonly type: import("vue").PropType<import("@zxio/zxui").GridListQueryLoader>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly queryRecordLimit: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 128, boolean>;
    readonly queryContext: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListQueryContext) | (() => import("@zxio/zxui").GridListQueryContext) | {
        (): import("@zxio/zxui").GridListQueryContext;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListQueryContext) | (() => import("@zxio/zxui").GridListQueryContext) | {
        (): import("@zxio/zxui").GridListQueryContext;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly queryResultMetadata: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListQueryMetadataResolver) | (() => import("@zxio/zxui").GridListQueryMetadataResolver) | {
        (): import("@zxio/zxui").GridListQueryMetadataResolver;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListQueryMetadataResolver) | (() => import("@zxio/zxui").GridListQueryMetadataResolver) | {
        (): import("@zxio/zxui").GridListQueryMetadataResolver;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly rows: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => readonly any[]) | (() => readonly any[]) | {
        (): readonly any[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => readonly any[]) | (() => readonly any[]) | {
        (): readonly any[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly pagination: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | {
        (): Readonly<import("./props").GridListPagerState> | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | {
        (): Readonly<import("./props").GridListPagerState> | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly status: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListControlledStatus>) | (() => Readonly<import("./props").GridListControlledStatus>) | {
        (): Readonly<import("./props").GridListControlledStatus>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Readonly<import("./props").GridListControlledStatus>) | (() => Readonly<import("./props").GridListControlledStatus>) | {
        (): Readonly<import("./props").GridListControlledStatus>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly defaults: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListDefaults) | (() => import("@zxio/zxui").GridListDefaults) | {
        (): import("@zxio/zxui").GridListDefaults;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListDefaults) | (() => import("@zxio/zxui").GridListDefaults) | {
        (): import("@zxio/zxui").GridListDefaults;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    readonly queryValidator: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").GridListQueryValidator) | (() => import("@zxio/zxui").GridListQueryValidator) | {
        (): import("@zxio/zxui").GridListQueryValidator;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").GridListQueryValidator) | (() => import("@zxio/zxui").GridListQueryValidator) | {
        (): import("@zxio/zxui").GridListQueryValidator;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly draftHold: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean) | (() => () => boolean) | {
        (): () => boolean;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean) | (() => () => boolean) | {
        (): () => boolean;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly maxSortItems: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly showPagination: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pageSizes: import("@zxio/shared").EpPropFinalized<ArrayConstructor, unknown, unknown, () => number[], boolean>;
    readonly paginationLayout: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "total, sizes, prev, pager, next, jumper", boolean>;
    readonly small: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly paginationBackground: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadOnMounted: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly queryTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (q: any) => any, boolean>;
    readonly paramsTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (p: any) => any, boolean>;
    readonly autoRefresh: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | {
        (): boolean | import("./props").GridListAutoRefreshConfig;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | {
        (): boolean | import("./props").GridListAutoRefreshConfig;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, false, boolean>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly syncUrlState: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly urlStateKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "_state", boolean>;
    readonly pageFrom0: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly debounceDelay: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 300, boolean>;
    readonly defaultPageSize: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly emptyDescription: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly emptyImage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly emptyImageSize: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly showRefreshButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showTableBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((value: any) => any) | undefined;
    onReload?: (() => any) | undefined;
    "onPage-change"?: ((_page: import("./props").GridListPageChange) => any) | undefined;
    onBeforeLoad?: ((params: any) => any) | undefined;
    onDataLoaded?: ((data: any) => any) | undefined;
    onLoadError?: ((error: any) => any) | undefined;
    onSelectionCleared?: (() => any) | undefined;
}>, {
    readonly small: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    readonly status: Readonly<import("./props").GridListControlledStatus>;
    readonly rows: readonly any[];
    readonly pagination: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | {
        (): Readonly<import("./props").GridListPagerState> | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | {
        (): Readonly<import("./props").GridListPagerState> | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly queryRecordLimit: number;
    readonly queryContext: import("@zxio/zxui").GridListQueryContext;
    readonly queryResultMetadata: import("@zxio/zxui").GridListQueryMetadataResolver;
    readonly defaults: import("@zxio/zxui").GridListDefaults;
    readonly queryValidator: import("@zxio/zxui").GridListQueryValidator;
    readonly draftHold: () => boolean;
    readonly maxSortItems: number;
    readonly showPagination: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly pageSizes: unknown[];
    readonly paginationLayout: string;
    readonly paginationBackground: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadOnMounted: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly queryTransform: Function;
    readonly paramsTransform: Function;
    readonly autoRefresh: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | {
        (): boolean | import("./props").GridListAutoRefreshConfig;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | {
        (): boolean | import("./props").GridListAutoRefreshConfig;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly syncUrlState: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly urlStateKey: string;
    readonly pageFrom0: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounceDelay: number;
    readonly defaultPageSize: number;
    readonly emptyDescription: string;
    readonly emptyImage: string;
    readonly emptyImageSize: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly showRefreshButton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showTableBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
