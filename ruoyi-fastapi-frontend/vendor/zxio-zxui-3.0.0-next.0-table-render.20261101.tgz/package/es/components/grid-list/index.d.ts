import { type SFCWithInstall } from '@zxio/shared';
import { zxGridListEmits, zxGridListProps } from './src/props';
import type { SFCWithSlots } from '../_shared/component-slots';
import type { GridListSlots } from './src/slots';
import type { ZxGridListControlledInstance, ZxGridListPublicInstance, ZxGridListRequestInstance } from './src/instance';
import type { GridListPublicProps } from './src/props';
type Component = SFCWithSlots<typeof zxGridListProps, typeof zxGridListEmits, GridListSlots, ZxGridListRequestInstance>;
type OriginalInstance = InstanceType<Component>;
type PublicComponent = Omit<Component, 'props'> & {
    new (): Omit<OriginalInstance, '$props' | '$slots' | '$emit' | keyof ZxGridListRequestInstance | keyof ZxGridListControlledInstance> & ZxGridListPublicInstance & {
        $props: Omit<OriginalInstance['$props'], keyof GridListPublicProps> & GridListPublicProps;
        $slots: GridListSlots;
        $emit: OriginalInstance['$emit'];
    };
};
export declare const ZxGridList: SFCWithInstall<PublicComponent>;
export default ZxGridList;
export * from './src/props';
export type { ZxGridListInstance, ZxGridListControlledInstance, ZxGridListRequestInstance, ZxGridListPublicInstance, } from './src/instance';
export type { GridListSlots, GridListEmptySlot, GridListRequestFormSlot, GridListRequestTableSlot, GridListFormSlot, GridListTableSlot, GridListControlledFormSlot, GridListControlledTableSlot, } from './src/slots';
export * from './src/query-contracts';
export { createGridListQueryAccess } from './src/query-access';
export { resolveGridListRequeryInput } from './src/query-input';
export type { GridListLoadOptions, GridListRequery, } from './src/use-grid-request';
