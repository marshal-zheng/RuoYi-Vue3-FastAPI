declare const _default: __ZXUI_WithSlots<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        visible: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => import("@zxio/zxui").DrawerPlacement) | {
            (): import("@zxio/zxui").DrawerPlacement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => import("@zxio/zxui").DrawerPlacement) | {
            (): import("@zxio/zxui").DrawerPlacement;
            new (): any;
            readonly prototype: any;
        }) | null)[], string, unknown, string, boolean>;
        size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        mode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMode, unknown, string, boolean>;
        pushTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        mobileFallback: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMobileFallback, unknown, string, boolean>;
        resizable: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, boolean, boolean>;
        selectable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("@zxio/zxui").DrawerMessages>) | (() => Partial<import("@zxio/zxui").DrawerMessages>) | {
            (): Partial<import("@zxio/zxui").DrawerMessages>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<import("@zxio/zxui").DrawerMessages>) | (() => Partial<import("@zxio/zxui").DrawerMessages>) | {
            (): Partial<import("@zxio/zxui").DrawerMessages>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        lockScroll: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DrawerDescriptionItem[]) | (() => import("@zxio/zxui").DrawerDescriptionItem[]) | {
            (): import("@zxio/zxui").DrawerDescriptionItem[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DrawerDescriptionItem[]) | (() => import("@zxio/zxui").DrawerDescriptionItem[]) | {
            (): import("@zxio/zxui").DrawerDescriptionItem[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        okText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        cancelText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        saveContinueText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | (() => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | {
            (): (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | (() => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | {
            (): (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, boolean, boolean>;
        handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
            (): string[][];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
            (): string[][];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
            (): (step: number) => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
            (): (step: number) => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        prevText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        nextText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        submitText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
            (): import("@zxio/constants").FooterButtonConfig[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
            (): import("@zxio/constants").FooterButtonConfig[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
            (): "left" | "center" | "right";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
            (): "left" | "center" | "right";
            new (): any;
            readonly prototype: any;
        }) | null)[], string, unknown, string, boolean>;
        beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
            (): () => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
            (): () => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
            (): (success: boolean) => void;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
            (): (success: boolean) => void;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        disableUserSelect: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        disabledWidthDrag: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        showHandleBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        }) | null)[], "none" | "auto", unknown, undefined, boolean>;
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
        onCancel?: (() => any) | undefined;
        onPrev?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
        onNext?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
        onContinue?: (() => any) | undefined;
        onClose?: (() => any) | undefined;
        onResize?: ((payload: import("@zxio/zxui").DrawerResizePayload) => any) | undefined;
        onBack?: (() => any) | undefined;
        onOpen?: (() => any) | undefined;
        onConfirm?: ((_result?: any) => any) | undefined;
        onClosed?: (() => any) | undefined;
        "onUpdate:visible"?: ((val: boolean) => any) | undefined;
        onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
        onSaveSuccess?: ((_data?: any) => any) | undefined;
        onSaveError?: ((_error: any) => any) | undefined;
        onButtonClick?: ((_buttonKey: string) => any) | undefined;
        "onUpdate:currentStep"?: ((val: number) => any) | undefined;
        "onUpdate:current-step"?: ((val: number) => any) | undefined;
        "onFullscreen-change"?: ((val: boolean) => any) | undefined;
        onOpened?: (() => any) | undefined;
        "onDirty-change"?: ((val: boolean) => any) | undefined;
        "onConfirm-error"?: ((_error?: any) => any) | undefined;
    }>, {
        open: () => void;
        close: () => Promise<void>;
        toggleFullScreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
        resetForm: () => void;
        scrollToFirstError: () => void;
        resize: (size: number) => void;
        resetSize: () => Promise<void> | undefined;
        isFullScreen: Readonly<import("vue").Ref<boolean, boolean>>;
        confirmLoading: import("vue").ComputedRef<boolean>;
        isDirty: import("vue").ComputedRef<boolean>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        "update:modelValue": (val: boolean) => void;
        cancel: () => void;
        prev: (params: import("@zxio/constants").StepEventParams) => void;
        next: (params: import("@zxio/constants").StepEventParams) => void;
        continue: () => void;
        close: () => void;
        resize: (payload: import("@zxio/zxui").DrawerResizePayload) => void;
        back: () => void;
        open: () => void;
        confirm: (_result?: any) => void;
        closed: () => void;
        "update:visible": (val: boolean) => void;
        saveStart: (_done: () => void, _fail: (error?: any) => void) => void;
        saveSuccess: (_data?: any) => void;
        saveError: (_error: any) => void;
        buttonClick: (_buttonKey: string) => void;
        "update:currentStep": (val: number) => void;
        "update:current-step": (val: number) => void;
        "fullscreen-change": (val: boolean) => void;
        opened: () => void;
        "dirty-change": (val: boolean) => void;
        "confirm-error": (_error?: any) => void;
    }, import("vue").PublicProps, {
        footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        title: string;
        size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        mode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMode, unknown>;
        loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        debounce: number;
        modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        throttle: number;
        draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        appendTo: import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
        placement: string;
        locale: Partial<import("@zxio/zxui").DrawerMessages>;
        visible: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        lockScroll: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        confirm: (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
        paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        cancelText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        currentStep: number;
        totalSteps: number;
        prevText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        nextText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        submitText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        buttons: import("@zxio/constants").FooterButtonConfig[];
        buttonAlign: string;
        beforeSave: () => boolean | Promise<boolean>;
        afterSave: (success: boolean) => void;
        formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loadingText: string;
        destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        subtitle: string;
        showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        stepFields: string[][];
        validateStep: (step: number) => boolean | Promise<boolean>;
        titleTag: string;
        titleTagColor: string;
        descriptions: import("@zxio/zxui").DrawerDescriptionItem[];
        showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        loadingBackground: string;
        okText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        saveContinueText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        formModel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        scrollErrorOffset: number;
        bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        }) | null)[], "none" | "auto", unknown>;
        pushTarget: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        mobileFallback: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMobileFallback, unknown>;
        resizable: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        selectable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        disableUserSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        disabledWidthDrag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showHandleBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        visible: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => import("@zxio/zxui").DrawerPlacement) | {
            (): import("@zxio/zxui").DrawerPlacement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => import("@zxio/zxui").DrawerPlacement) | {
            (): import("@zxio/zxui").DrawerPlacement;
            new (): any;
            readonly prototype: any;
        }) | null)[], string, unknown, string, boolean>;
        size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        mode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMode, unknown, string, boolean>;
        pushTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        mobileFallback: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMobileFallback, unknown, string, boolean>;
        resizable: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, boolean, boolean>;
        selectable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("@zxio/zxui").DrawerMessages>) | (() => Partial<import("@zxio/zxui").DrawerMessages>) | {
            (): Partial<import("@zxio/zxui").DrawerMessages>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Partial<import("@zxio/zxui").DrawerMessages>) | (() => Partial<import("@zxio/zxui").DrawerMessages>) | {
            (): Partial<import("@zxio/zxui").DrawerMessages>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        lockScroll: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DrawerDescriptionItem[]) | (() => import("@zxio/zxui").DrawerDescriptionItem[]) | {
            (): import("@zxio/zxui").DrawerDescriptionItem[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/zxui").DrawerDescriptionItem[]) | (() => import("@zxio/zxui").DrawerDescriptionItem[]) | {
            (): import("@zxio/zxui").DrawerDescriptionItem[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, string, boolean>;
        loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        okText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        cancelText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        saveContinueText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | (() => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | {
            (): (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | (() => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | {
            (): (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, boolean, boolean>;
        handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, null, boolean>;
        autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget) | {
            (): import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
            (): string[][];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
            (): string[][];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
            (): (step: number) => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
            (): (step: number) => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        prevText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        nextText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        submitText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
        buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
            (): import("@zxio/constants").FooterButtonConfig[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
            (): import("@zxio/constants").FooterButtonConfig[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
            (): "left" | "center" | "right";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
            (): "left" | "center" | "right";
            new (): any;
            readonly prototype: any;
        }) | null)[], string, unknown, string, boolean>;
        beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
            (): () => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
            (): () => boolean | Promise<boolean>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
            (): (success: boolean) => void;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
            (): (success: boolean) => void;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        disableUserSelect: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        disabledWidthDrag: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        showHandleBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        }) | null)[], "none" | "auto", unknown, undefined, boolean>;
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
        onCancel?: (() => any) | undefined;
        onPrev?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
        onNext?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
        onContinue?: (() => any) | undefined;
        onClose?: (() => any) | undefined;
        onResize?: ((payload: import("@zxio/zxui").DrawerResizePayload) => any) | undefined;
        onBack?: (() => any) | undefined;
        onOpen?: (() => any) | undefined;
        onConfirm?: ((_result?: any) => any) | undefined;
        onClosed?: (() => any) | undefined;
        "onUpdate:visible"?: ((val: boolean) => any) | undefined;
        onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
        onSaveSuccess?: ((_data?: any) => any) | undefined;
        onSaveError?: ((_error: any) => any) | undefined;
        onButtonClick?: ((_buttonKey: string) => any) | undefined;
        "onUpdate:currentStep"?: ((val: number) => any) | undefined;
        "onUpdate:current-step"?: ((val: number) => any) | undefined;
        "onFullscreen-change"?: ((val: boolean) => any) | undefined;
        onOpened?: (() => any) | undefined;
        "onDirty-change"?: ((val: boolean) => any) | undefined;
        "onConfirm-error"?: ((_error?: any) => any) | undefined;
    }>, {
        open: () => void;
        close: () => Promise<void>;
        toggleFullScreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
        resetForm: () => void;
        scrollToFirstError: () => void;
        resize: (size: number) => void;
        resetSize: () => Promise<void> | undefined;
        isFullScreen: Readonly<import("vue").Ref<boolean, boolean>>;
        confirmLoading: import("vue").ComputedRef<boolean>;
        isDirty: import("vue").ComputedRef<boolean>;
    }, {}, {}, {}, {
        footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        title: string;
        size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        mode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
            (): import("@zxio/zxui").DrawerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMode, unknown>;
        loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        debounce: number;
        modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        throttle: number;
        draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        appendTo: import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
        placement: string;
        locale: Partial<import("@zxio/zxui").DrawerMessages>;
        visible: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
            (): import("@zxio/zxui").ZxOverlayPadding;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        lockScroll: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        confirm: (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
        paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
            (): import("@zxio/zxui").ZxOverlayLength;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        cancelText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        currentStep: number;
        totalSteps: number;
        prevText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        nextText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        submitText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        buttons: import("@zxio/constants").FooterButtonConfig[];
        buttonAlign: string;
        beforeSave: () => boolean | Promise<boolean>;
        afterSave: (success: boolean) => void;
        formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => {
            $: import("vue").ComponentInternalInstance;
            $data: {};
            $props: {
                readonly model?: Record<string, any> | undefined;
                readonly rules?: import("element-plus").FormRules | undefined;
                readonly labelPosition?: ("left" | "right" | "top") | undefined;
                readonly requireAsteriskPosition?: ("left" | "right") | undefined;
                readonly labelWidth?: (string | number) | undefined;
                readonly labelSuffix?: string | undefined;
                readonly inline?: boolean | undefined;
                readonly inlineMessage?: boolean | undefined;
                readonly statusIcon?: boolean | undefined;
                readonly showMessage?: boolean | undefined;
                readonly validateOnRuleChange?: boolean | undefined;
                readonly hideRequiredAsterisk?: boolean | undefined;
                readonly scrollToError?: boolean | undefined;
                readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
                readonly size?: import("element-plus").ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
            $attrs: import("vue").Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import("vue").Slot<any> | undefined;
            }>;
            $root: import("vue").ComponentPublicInstance | null;
            $parent: import("vue").ComponentPublicInstance | null;
            $host: Element | null;
            $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            $el: any;
            $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
                onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
            }>, {
                validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
                resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
                scrollToField: (prop: import("element-plus").FormItemProp) => void;
                getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
                fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
                setInitialValues: (initModel: Record<string, any>) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
            }, string, {
                labelWidth: string | number;
                labelPosition: "left" | "right" | "top";
                requireAsteriskPosition: "left" | "right";
                labelSuffix: string;
                showMessage: boolean;
                validateOnRuleChange: boolean;
                scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import("vue").nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
        } & Readonly<{
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        } & {} & import("vue").ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | (() => import("element-plus").FormInstance | null) | {
            (): import("element-plus").FormInstance | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loadingText: string;
        destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        subtitle: string;
        showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
            (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        stepFields: string[][];
        validateStep: (step: number) => boolean | Promise<boolean>;
        titleTag: string;
        titleTagColor: string;
        descriptions: import("@zxio/zxui").DrawerDescriptionItem[];
        showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
            (): "spin" | "skeleton";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        loadingBackground: string;
        okText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        saveContinueText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
        okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
            (): (() => unknown) | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        formModel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => object) | (() => object | null) | {
            (): object | null;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        scrollErrorOffset: number;
        bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
            (): import("@zxio/zxui").ZxOverlayBodyScroll;
            new (): any;
            readonly prototype: any;
        }) | null)[], "none" | "auto", unknown>;
        pushTarget: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
            (): string | HTMLElement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        mobileFallback: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
            (): import("@zxio/zxui").DrawerMobileFallback;
            new (): any;
            readonly prototype: any;
        }) | null)[], import("@zxio/zxui").DrawerMobileFallback, unknown>;
        resizable: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
            (): boolean | import("@zxio/zxui").DrawerResizableOptions;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        selectable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        disableUserSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        disabledWidthDrag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showHandleBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    visible: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => import("@zxio/zxui").DrawerPlacement) | {
        (): import("@zxio/zxui").DrawerPlacement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom") | (() => import("@zxio/zxui").DrawerPlacement) | {
        (): import("@zxio/zxui").DrawerPlacement;
        new (): any;
        readonly prototype: any;
    }) | null)[], string, unknown, string, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    mode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
        (): import("@zxio/zxui").DrawerMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
        (): import("@zxio/zxui").DrawerMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], import("@zxio/zxui").DrawerMode, unknown, string, boolean>;
    pushTarget: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
        (): string | HTMLElement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
        (): string | HTMLElement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    mobileFallback: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
        (): import("@zxio/zxui").DrawerMobileFallback;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
        (): import("@zxio/zxui").DrawerMobileFallback;
        new (): any;
        readonly prototype: any;
    }) | null)[], import("@zxio/zxui").DrawerMobileFallback, unknown, string, boolean>;
    resizable: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
        (): boolean | import("@zxio/zxui").DrawerResizableOptions;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
        (): boolean | import("@zxio/zxui").DrawerResizableOptions;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, boolean, boolean>;
    selectable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("@zxio/zxui").DrawerMessages>) | (() => Partial<import("@zxio/zxui").DrawerMessages>) | {
        (): Partial<import("@zxio/zxui").DrawerMessages>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<import("@zxio/zxui").DrawerMessages>) | (() => Partial<import("@zxio/zxui").DrawerMessages>) | {
        (): Partial<import("@zxio/zxui").DrawerMessages>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    lockScroll: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/zxui").DrawerDescriptionItem[]) | (() => import("@zxio/zxui").DrawerDescriptionItem[]) | {
        (): import("@zxio/zxui").DrawerDescriptionItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/zxui").DrawerDescriptionItem[]) | (() => import("@zxio/zxui").DrawerDescriptionItem[]) | {
        (): import("@zxio/zxui").DrawerDescriptionItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
    loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
    okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    okText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    cancelText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    saveContinueText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | (() => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | {
        (): (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | (() => (context: import("@zxio/zxui").DrawerConfirmContext) => unknown) | {
        (): (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
        (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
        (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, boolean, boolean>;
    handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => object) | (() => object | null) | {
        (): object | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => object) | (() => object | null) | {
        (): object | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget) | {
        (): import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget) | {
        (): import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
        (): string[][];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
        (): string[][];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    prevText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    nextText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    submitText: import("@zxio/shared").EpPropFinalized<(ObjectConstructor | StringConstructor)[], unknown, unknown, string, boolean>;
    buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
        (): import("@zxio/constants").FooterButtonConfig[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("@zxio/constants").FooterButtonConfig[]) | (() => import("@zxio/constants").FooterButtonConfig[]) | {
        (): import("@zxio/constants").FooterButtonConfig[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    }) | null)[], string, unknown, string, boolean>;
    beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
    debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
    disableUserSelect: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    disabledWidthDrag: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    showHandleBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
        (): import("@zxio/zxui").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
        (): import("@zxio/zxui").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
        (): import("@zxio/zxui").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
        (): import("@zxio/zxui").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    }) | null)[], "none" | "auto", unknown, undefined, boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
    onCancel?: (() => any) | undefined;
    onPrev?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
    onNext?: ((params: import("@zxio/constants").StepEventParams) => any) | undefined;
    onContinue?: (() => any) | undefined;
    onClose?: (() => any) | undefined;
    onResize?: ((payload: import("@zxio/zxui").DrawerResizePayload) => any) | undefined;
    onBack?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
    onConfirm?: ((_result?: any) => any) | undefined;
    onClosed?: (() => any) | undefined;
    "onUpdate:visible"?: ((val: boolean) => any) | undefined;
    onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
    onSaveSuccess?: ((_data?: any) => any) | undefined;
    onSaveError?: ((_error: any) => any) | undefined;
    onButtonClick?: ((_buttonKey: string) => any) | undefined;
    "onUpdate:currentStep"?: ((val: number) => any) | undefined;
    "onUpdate:current-step"?: ((val: number) => any) | undefined;
    "onFullscreen-change"?: ((val: boolean) => any) | undefined;
    onOpened?: (() => any) | undefined;
    "onDirty-change"?: ((val: boolean) => any) | undefined;
    "onConfirm-error"?: ((_error?: any) => any) | undefined;
}>, {
    open: () => void;
    close: () => Promise<void>;
    toggleFullScreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    resize: (size: number) => void;
    resetSize: () => Promise<void> | undefined;
    isFullScreen: Readonly<import("vue").Ref<boolean, boolean>>;
    confirmLoading: import("vue").ComputedRef<boolean>;
    isDirty: import("vue").ComputedRef<boolean>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (val: boolean) => void;
    cancel: () => void;
    prev: (params: import("@zxio/constants").StepEventParams) => void;
    next: (params: import("@zxio/constants").StepEventParams) => void;
    continue: () => void;
    close: () => void;
    resize: (payload: import("@zxio/zxui").DrawerResizePayload) => void;
    back: () => void;
    open: () => void;
    confirm: (_result?: any) => void;
    closed: () => void;
    "update:visible": (val: boolean) => void;
    saveStart: (_done: () => void, _fail: (error?: any) => void) => void;
    saveSuccess: (_data?: any) => void;
    saveError: (_error: any) => void;
    buttonClick: (_buttonKey: string) => void;
    "update:currentStep": (val: number) => void;
    "update:current-step": (val: number) => void;
    "fullscreen-change": (val: boolean) => void;
    opened: () => void;
    "dirty-change": (val: boolean) => void;
    "confirm-error": (_error?: any) => void;
}, string, {
    footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    title: string;
    size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    mode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
        (): import("@zxio/zxui").DrawerMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "push" | "modal" | "inline") | (() => import("@zxio/zxui").DrawerMode) | {
        (): import("@zxio/zxui").DrawerMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], import("@zxio/zxui").DrawerMode, unknown>;
    loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    debounce: number;
    modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    throttle: number;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    appendTo: import("@zxio/zxui/theme-provider").ThemeRequiredPortalTarget;
    placement: string;
    locale: Partial<import("@zxio/zxui").DrawerMessages>;
    visible: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("@zxio/zxui").ZxOverlayInsets) | (() => import("@zxio/zxui").ZxOverlayPadding) | {
        (): import("@zxio/zxui").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    lockScroll: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    confirm: (context: import("@zxio/zxui").DrawerConfirmContext) => unknown;
    paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
        (): import("@zxio/zxui").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => import("@zxio/zxui").ZxOverlayLength) | {
        (): import("@zxio/zxui").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    cancelText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    currentStep: number;
    totalSteps: number;
    prevText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    nextText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    submitText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    buttons: import("@zxio/constants").FooterButtonConfig[];
    buttonAlign: string;
    beforeSave: () => boolean | Promise<boolean>;
    afterSave: (success: boolean) => void;
    formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loadingText: string;
    destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    subtitle: string;
    showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
        (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerDirtyGuard) | (() => boolean | import("@zxio/zxui").DrawerDirtyGuard) | {
        (): boolean | import("@zxio/zxui").DrawerDirtyGuard;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    stepFields: string[][];
    validateStep: (step: number) => boolean | Promise<boolean>;
    titleTag: string;
    titleTagColor: string;
    descriptions: import("@zxio/zxui").DrawerDescriptionItem[];
    showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    loadingBackground: string;
    okText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    saveContinueText: import("@zxio/shared").EpPropMergeType<(ObjectConstructor | StringConstructor)[], unknown, unknown>;
    okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    formModel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => object) | (() => object | null) | {
        (): object | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => object) | (() => object | null) | {
        (): object | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    scrollErrorOffset: number;
    bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
        (): import("@zxio/zxui").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "auto") | (() => import("@zxio/zxui").ZxOverlayBodyScroll) | {
        (): import("@zxio/zxui").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    }) | null)[], "none" | "auto", unknown>;
    pushTarget: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
        (): string | HTMLElement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | {
        (): string | HTMLElement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    mobileFallback: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
        (): import("@zxio/zxui").DrawerMobileFallback;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "full" | "bottom-sheet") | (() => import("@zxio/zxui").DrawerMobileFallback) | {
        (): import("@zxio/zxui").DrawerMobileFallback;
        new (): any;
        readonly prototype: any;
    }) | null)[], import("@zxio/zxui").DrawerMobileFallback, unknown>;
    resizable: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
        (): boolean | import("@zxio/zxui").DrawerResizableOptions;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("@zxio/zxui").DrawerResizableOptions) | (() => boolean | import("@zxio/zxui").DrawerResizableOptions) | {
        (): boolean | import("@zxio/zxui").DrawerResizableOptions;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    selectable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    disableUserSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    disabledWidthDrag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showHandleBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
    $slots: import("./slots.js").DrawerSlots;
}>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
