import { SFCWithInstall } from '@zxio/shared';
import { default as Chart } from './src/chart.vue';
export declare const ZxChart: SFCWithInstall<typeof Chart>;
export default ZxChart;
export * from './src/chart';
export * from './src/theme';
