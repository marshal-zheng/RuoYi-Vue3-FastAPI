export type ChartThemeSha256 = `sha256:${string}`;
export interface ChartManifestIdentity {
    readonly packageName: string;
    readonly packageVersion: string;
    readonly themeId: string;
    readonly contractVersion: '4.0.0';
    readonly sourceContentHash: ChartThemeSha256;
    readonly contractContentHash: ChartThemeSha256;
    readonly typeRegistryContentHash: ChartThemeSha256;
    readonly sourceSchemaVersion?: 4;
    readonly resolvedSchemaVersion?: 1;
    readonly compilerName?: string;
    readonly compilerVersion?: string;
}
export interface ChartVariantIdentity {
    readonly variantKey: string;
    readonly resolvedContentHash: ChartThemeSha256;
    readonly coreCssSha256: ChartThemeSha256;
    readonly elementPlusResolvedCssSha256: ChartThemeSha256;
}
export interface ChartThemeProjectionIdentity {
    readonly manifestIdentity: ChartManifestIdentity;
    readonly variantIdentity: ChartVariantIdentity;
}
export interface ChartThemeProjection extends ChartThemeProjectionIdentity {
    readonly color: Readonly<{
        readonly surface: string;
        readonly text: string;
        readonly mutedText: string;
        readonly focus: string;
        readonly accent: string;
    }>;
    readonly status: Readonly<{
        readonly success: string;
        readonly warning: string;
        readonly danger: string;
        readonly info: string;
    }>;
    readonly palette: readonly string[];
    readonly grid: Readonly<{
        readonly line: string;
        readonly axis: string;
    }>;
    readonly overlayShadow: string;
    readonly motionDurationMs: number;
    readonly radiusPx: number;
}
export type ChartThemeProjectionDiagnosticCode = 'CHART_THEME_PROJECTION_INVALID' | 'CHART_THEME_PROJECTION_IDENTITY_MISMATCH';
export interface ChartThemeProjectionDiagnostic {
    readonly code: ChartThemeProjectionDiagnosticCode;
    readonly path: string;
    readonly reason: string;
}
export type ChartThemeProjectionResult = Readonly<{
    ok: true;
    value: ChartThemeProjection;
    diagnostics: readonly [];
}> | Readonly<{
    ok: false;
    diagnostics: readonly [ChartThemeProjectionDiagnostic];
}>;
export interface ChartEChartsTheme {
    readonly color: readonly string[];
    readonly backgroundColor: string;
    readonly animationDurationUpdate: number;
    readonly textStyle: Readonly<{
        color: string;
    }>;
    readonly title: Readonly<{
        textStyle: Readonly<{
            color: string;
        }>;
        subtextStyle: Readonly<{
            color: string;
        }>;
    }>;
    readonly legend: Readonly<{
        textStyle: Readonly<{
            color: string;
        }>;
        inactiveColor: string;
    }>;
    readonly categoryAxis: Readonly<Record<string, unknown>>;
    readonly valueAxis: Readonly<Record<string, unknown>>;
    readonly timeAxis: Readonly<Record<string, unknown>>;
    readonly tooltip: Readonly<Record<string, unknown>>;
    readonly gauge: Readonly<Record<string, unknown>>;
}
/**
 * Validates, copies and freezes a serialization-safe projection. The optional
 * expected identity lets a host reject a projection that was assembled from a
 * different manifest, Variant or exact CSS artifact set.
 */
export declare function createChartThemeProjection(input: unknown, expectedIdentity?: ChartThemeProjectionIdentity): ChartThemeProjectionResult;
/** A collision-resistant runtime key over every manifest/Variant artifact fact. */
export declare function chartThemeProjectionIdentityKey(projection: ChartThemeProjection): string;
/** Builds an ECharts theme exclusively from an already validated projection. */
export declare function createChartEChartsTheme(projection: ChartThemeProjection): ChartEChartsTheme;
