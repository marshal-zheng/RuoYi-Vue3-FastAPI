import { ChartThemeProjection } from './theme';
import { ExtractPropTypes, PropType } from 'vue';
import { EpPropFinalized } from '@zxio/shared';
export type ChartOptionsInput = Record<string, any> | Promise<Record<string, any>> | (() => Record<string, any> | Promise<Record<string, any>>);
export declare const zxChartProps: {
    readonly options: EpPropFinalized<any, unknown, unknown, () => {}, boolean>;
    readonly transform: EpPropFinalized<any, unknown, unknown, () => never[], boolean>;
    readonly isEmpty: EpPropFinalized<any, unknown, unknown, undefined, boolean>;
    readonly enableRetry: EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadingText: EpPropFinalized<StringConstructor, unknown, unknown, "加载中...", boolean>;
    readonly emptyText: EpPropFinalized<StringConstructor, unknown, unknown, "暂无数据", boolean>;
    readonly errorText: EpPropFinalized<StringConstructor, unknown, unknown, "加载失败", boolean>;
    readonly width: EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly height: EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly autoResize: EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly themeMode: EpPropFinalized<(new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral") | (((new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral")) | null)[], "projection" | "neutral", unknown, "projection", boolean>;
    readonly themeProjection: {
        readonly type: PropType<ChartThemeProjection>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
};
export declare const zxChartEmits: {
    ready: () => boolean;
    click: (_payload: any) => boolean;
    loading: (loading: boolean) => boolean;
    error: (_error: any) => boolean;
    empty: (empty: boolean) => boolean;
    refreshed: (_options: any) => boolean;
};
export type ZxChartProps = ExtractPropTypes<typeof zxChartProps>;
export type ZxChartEmits = typeof zxChartEmits;
