export const en = {
  lang: 'en',
  toolbar: {
    modeGroup: 'Dashboard mode',
    edit: 'Edit',
    preview: 'Preview',
    view: 'View',
    historyGroup: 'History',
    undo: 'Undo',
    redo: 'Redo',
    discard: 'Discard changes',
    unsaved: 'Unsaved changes',
    save: 'Save',
    export: 'Export',
  },
  palette: {
    search: 'Search widgets',
    empty: 'No widgets available',
  },
  drawer: {
    close: 'Close editor',
    fallback: 'No editor configured',
  },
  panel: {
    actionsLabel: 'Panel actions',
    more: 'More actions',
    unresolved: 'Unresolved widget: {widget}',
    copySuffix: '{title} Copy',
  },
  actions: {
    maximize: 'Maximize',
    restore: 'Restore',
    refresh: 'Refresh',
    inspect: 'Edit panel',
    duplicate: 'Duplicate',
    remove: 'Remove',
    lock: 'Lock',
    unlock: 'Unlock',
    hide: 'Hide',
    show: 'Show',
  },
  widget: {
    loading: 'Loading widget...',
    loadError: 'Unable to load widget.',
  },
  severity: {
    info: 'Info',
    warn: 'Warning',
    error: 'Error',
  },
  issues: {
    grid_below_min: 'Panel "{panelId}" is smaller than the widget minimum.',
    grid_above_max: 'Panel "{panelId}" exceeds the widget maximum.',
    unknown_chrome_variant:
      'Unknown dashboard chromeVariant "{value}", falling back to "silent".',
    unresolved_widget:
      'No dashboard panel renderer was resolved for widget "{widget}".',
    unresolved_widget_registry: 'Widget "{widget}" is not registered.',
    drop_ignored: 'Drop was ignored because dashboard grid drop is disabled.',
    invalid_drop_position:
      'Drop layout item did not contain a valid grid position.',
    invalid_layout_item: 'Invalid layout item for panel "{panelId}".',
    duplicate_layout_item:
      'Duplicate layout item for panel "{panelId}" was ignored.',
    unknown_layout_panel: 'Layout item references unknown panel "{panelId}".',
    missing_layout_item: 'Missing layout item for panel "{panelId}".',
    header_mode_conflict:
      'panelChrome.headerMode and panelChrome.showHeader are both set; headerMode takes precedence.',
    invalid_drag_payload:
      'Dashboard designer ignored a drop payload that did not contain a widget key.',
    authoring_disabled:
      'Dashboard designer ignored {request} because mode "{mode}" is not editable.',
  },
}
