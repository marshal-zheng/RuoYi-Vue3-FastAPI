import type { DashboardLocale } from './types'

export const zhCn: DashboardLocale = {
  lang: 'zh-CN',
  toolbar: {
    modeGroup: '仪表盘模式',
    edit: '编辑',
    preview: '预览',
    view: '查看',
    historyGroup: '历史',
    undo: '撤销',
    redo: '重做',
    discard: '放弃更改',
    unsaved: '有未保存的更改',
    save: '保存',
    export: '导出',
  },
  palette: {
    search: '搜索组件',
    empty: '暂无可用组件',
  },
  drawer: {
    close: '关闭编辑器',
    fallback: '未配置编辑器',
  },
  panel: {
    actionsLabel: '面板操作',
    more: '更多操作',
    unresolved: '未解析的组件：{widget}',
    copySuffix: '{title} 副本',
  },
  actions: {
    maximize: '最大化',
    restore: '还原',
    refresh: '刷新',
    inspect: '编辑面板',
    duplicate: '复制',
    remove: '删除',
    lock: '锁定',
    unlock: '解锁',
    hide: '隐藏',
    show: '显示',
  },
  widget: {
    loading: '正在加载组件...',
    loadError: '组件加载失败。',
  },
  severity: {
    info: '提示',
    warn: '警告',
    error: '错误',
  },
  issues: {
    grid_below_min: '面板“{panelId}”小于组件允许的最小尺寸。',
    grid_above_max: '面板“{panelId}”超过组件允许的最大尺寸。',
    unknown_chrome_variant:
      '未知的 dashboard chromeVariant "{value}"，已回退为 "silent"。',
    unresolved_widget: '组件 "{widget}" 没有解析到面板渲染器。',
    unresolved_widget_registry: '组件 "{widget}" 未注册。',
    drop_ignored: '网格已禁用拖放，本次拖放被忽略。',
    invalid_drop_position: '拖放的布局项没有有效的网格位置。',
    invalid_layout_item: '面板 "{panelId}" 的布局项无效。',
    duplicate_layout_item: '面板 "{panelId}" 的布局项重复，已忽略。',
    unknown_layout_panel: '布局项引用了不存在的面板 "{panelId}"。',
    missing_layout_item: '面板 "{panelId}" 缺少布局项。',
    header_mode_conflict:
      'panelChrome.headerMode 与 panelChrome.showHeader 同时设置，以 headerMode 为准。',
    invalid_drag_payload: '拖放数据缺少 widget key，设计器已忽略本次拖放。',
    authoring_disabled: '当前模式 "{mode}" 不可编辑，设计器已忽略 {request}。',
  },
}
