export { createDashboardWidgets } from './src/plugin'
export {
  readTimeSeriesChartConfig,
  validateTimeSeriesChartConfig,
} from './src/time-series-config'
export type { TimeSeriesChartConfig } from './src/time-series-config'
export type {
  DashboardWidgetsOptions,
  DashboardWidgetsLocale,
  DashboardMetricData,
  DashboardTimeSeriesData,
  DashboardBarData,
  DashboardTableData,
  DashboardStatusData,
} from './src/types'
