# @zxio/dashboard-widgets

Eight opt-in widgets for `@zxio/dashboard`. The dashboard core does not install or
depend on this pack. The host owns fetching, refresh scheduling, persistence and
navigation. This package renders JSON data and uses public `@zxio/chart` and
`@zxio/zxui/list-view` APIs.

## Install and register

Install this package plus its peers `vue`, `@zxio/dashboard`, `@zxio/chart` and
`@zxio/zxui`. Chart also requires `echarts` and `vue-echarts`; the host's ZXUI setup
supplies Element Plus and the active theme. Like dashboard, this is a source package:
the consuming Vue/Vite toolchain compiles its TypeScript and lazy Vue components.

```ts
import { createDashboardRegistry } from '@zxio/dashboard/widget'
import { createDashboardWidgets } from '@zxio/dashboard-widgets'
import { useZxChartThemeProjection } from '@zxio/zxui/theme-host/precompiled'
import '@zxio/dashboard/style'
import '@zxio/dashboard-widgets/style'

// In setup(), under the host's ZxThemeProvider. Base theme/ZXUI styles are host-owned.
const projection = useZxChartThemeProjection()
const registry = createDashboardRegistry()
const result = registry.use(
  createDashboardWidgets({
    locale: 'zh-CN', // 'en' by default; controls titles, settings and widget copy
    themeProjection: () =>
      projection.value.ok ? projection.value.value : undefined,
    allowEmbedUrl: (url) => url.startsWith('/reports/'), // optional additional policy
  })
)
if (!result.ok)
  throw new Error(result.issues.map((issue) => issue.message).join('\n'))
```

Pass `registry` to `ZxDashboardDesigner` or use
`createDashboardPanelContentResolver(registry)` with `ZxDashboardRenderer`.
The projection may be a value, ref or getter. Keep it reactive to follow theme,
mode and variant changes. Missing projection displays a localized pending state;
charts never silently fall back to an unrelated theme. No theme implementation is
stored in the dashboard document. Non-chart content inherits host semantic tokens.
Embedded sites own their internal theme.

Metadata language is selected when the plugin is created. To change it, recreate the
registry/plugin (or register with `override: true`), and update any host-owned saved
panel titles separately. Panel data and params are never mutated by these widgets.

## Data and settings

Every widget has `settings`, `minGrid`, `defaultGrid`, `thumbnail` and localized
metadata. Registration uses existing dashboard validation. Missing data is valid;
invalid supplied data is reported at save/export and rendered as an explicit fallback.
Numbers must be finite; numeric strings are not coerced. `0` is a real value.

| Widget key        | `panel.data`                                                               | `panel.params`                                               |
| ----------------- | -------------------------------------------------------------------------- | ------------------------------------------------------------ |
| `zx.stat`         | number or `{ value: number }`                                              | `label`, `unit`, `decimals` (integer 0–6)                    |
| `zx.gauge`        | number or `{ value: number }`                                              | `min` (0), `max` (100, greater than min), `unit`, `decimals` |
| `zx.time-series`  | `{ series: [{ name, points: [[epochMs, valueOrNull]] }] }`                 | nested `chart` (see below), `smooth` (false)                 |
| `zx.bar`          | `{ categories: string[], series: [{ name, values: (number \| null)[] }] }` | `legend` (true), `horizontal` (false)                        |
| `zx.table`        | `{ columns: [{ key, label }], rows: object[] }`                            | `showHeader` (true)                                          |
| `zx.text`         | string, or omitted to use configured content                               | `content`, `format` (`markdown` or `plain`)                  |
| `zx.iframe`       | unused                                                                     | `url`                                                        |
| `zx.status-light` | `{ state: 'ok' \| 'warn' \| 'error' \| 'offline', label?: string }`        | `label` (caption)                                            |

Time-series `params.chart` is a bounded presentation object, not arbitrary ECharts options:

```ts
{
  title: { show: true, text: 'CPU trend' },
  legend: { show: true, position: 'top' }, // top | bottom
  xAxis: { show: true },
  yAxis: { mode: 'fixed', min: 0, max: 100, name: '%' } // auto | fixed
}
```

Absent sections use defaults: hidden/empty title, visible top legend/time axis,
automatic value range, retained bounds 0–100 and empty axis name. Fixed bounds must
be finite with min < max. Automatic mode ignores the retained bounds when rendering.
Hidden title/legend settings remain JSON values; hiding does not erase them. Use
`readTimeSeriesChartConfig(params)` for normalized editor values and
`validateTimeSeriesChartConfig(params)` for the same validation as widget save/export.
Only documented properties reach ECharts; unrelated JSON siblings stay with the host.
The prior time-series top-level `legend` editor is replaced by `chart.legend.show`;
the bar widget continues to use its existing boolean `legend` setting.

Time-series timestamps are UTC epoch milliseconds; supplied order is preserved and
null values create gaps. Bar series must match the category count. Tables display
plain text (objects as JSON), have unique safe column keys, and reuse ListView's
virtual rows for larger inputs. Domain-specific row actions remain a custom widget.
Dashboard panel thresholds and links work unchanged around these contents; the host
maps domain status into status-light data. Gauge values outside bounds retain their
actual numeric label; the visual arc is bounded by ECharts.

Markdown uses markdown-it with raw HTML and image loading disabled. Unsafe link
protocols are rejected by the parser. Plain text remains escaped. No expression,
template or arbitrary chart-option evaluation is supported.

Embeds allow HTTP(S) or root-relative URLs, reject protocol-relative/executable URLs
and embedded credentials, and use `sandbox="allow-scripts"`, `no-referrer` and native
lazy loading. Saved settings cannot lift sandbox restrictions. The optional
`allowEmbedUrl` host policy can deny additional destinations; policy errors deny the
embed. Authentication, CSP/frame-ancestors and permission decisions belong to the
host/embedded server. A blocked/missing URL displays a localized message.

## Development

```sh
pnpm -C packages/dashboard-widgets test
pnpm -C packages/dashboard-widgets typecheck
```

Docs demonstration: `docs/examples/dashboard/widgets.vue`. Acceptance is recorded in
the roadmap Task 10 report; tests that stub ECharts only verify adapter inputs and do
not replace real Chrome rendering/resize/theme checks.
