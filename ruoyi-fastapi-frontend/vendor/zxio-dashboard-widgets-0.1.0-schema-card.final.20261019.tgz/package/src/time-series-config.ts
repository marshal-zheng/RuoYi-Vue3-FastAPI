import { isRecord } from './data'

import type { DashboardReadonlyJsonObject } from '@zxio/dashboard/schema'

export interface TimeSeriesChartConfig {
  title: { show: boolean; text: string }
  legend: { show: boolean; position: 'top' | 'bottom' }
  xAxis: { show: boolean }
  yAxis: { mode: 'auto' | 'fixed'; min: number; max: number; name: string }
}

/** A bounded presentation contract, never an arbitrary ECharts options pass-through. */
export function readTimeSeriesChartConfig(
  params?: DashboardReadonlyJsonObject
): TimeSeriesChartConfig {
  const chart = isRecord(params?.chart) ? params.chart : {}
  const part = (key: string) => (isRecord(chart[key]) ? chart[key] : {})
  const title = part('title')
  const legend = part('legend')
  const xAxis = part('xAxis')
  const yAxis = part('yAxis')
  return {
    title: {
      show: title.show === true,
      text: typeof title.text === 'string' ? title.text : '',
    },
    legend: {
      show: legend.show !== false,
      position: legend.position === 'bottom' ? 'bottom' : 'top',
    },
    xAxis: { show: xAxis.show !== false },
    yAxis: {
      mode: yAxis.mode === 'fixed' ? 'fixed' : 'auto',
      min: typeof yAxis.min === 'number' ? yAxis.min : 0,
      max: typeof yAxis.max === 'number' ? yAxis.max : 100,
      name: typeof yAxis.name === 'string' ? yAxis.name : '',
    },
  }
}

export function validateTimeSeriesChartConfig(
  params?: DashboardReadonlyJsonObject
): { path: string; message: string }[] {
  const issues: { path: string; message: string }[] = []
  const fail = (path: string, message: string) =>
    issues.push({ path: `/params/chart${path}`, message })
  const chart = params?.chart
  if (chart === undefined) return issues
  if (!isRecord(chart)) {
    fail('', 'Chart settings must be an object')
    return issues
  }
  const checks = {
    title: { show: 'boolean', text: 'string' },
    legend: { show: 'boolean', position: ['top', 'bottom'] },
    xAxis: { show: 'boolean' },
    yAxis: {
      mode: ['auto', 'fixed'],
      min: 'number',
      max: 'number',
      name: 'string',
    },
  }
  for (const [section, fields] of Object.entries(checks)) {
    const value = chart[section]
    if (value === undefined) continue
    if (!isRecord(value)) {
      fail(`/${section}`, `${section} must be an object`)
      continue
    }
    for (const [key, type] of Object.entries(fields)) {
      const entry = value[key]
      if (entry === undefined) continue
      const valid = Array.isArray(type)
        ? type.includes(entry as string)
        : typeof entry === type && (type !== 'number' || Number.isFinite(entry))
      if (!valid) fail(`/${section}/${key}`, `Invalid ${section}.${key}`)
    }
  }
  const config = readTimeSeriesChartConfig(params)
  if (config.yAxis.mode === 'fixed' && config.yAxis.min >= config.yAxis.max)
    fail('/yAxis/max', 'Maximum must exceed minimum')
  return issues
}
