import { isBarData, isTimeSeries, paramNumber, readMetric } from './data'
import {
  readTimeSeriesChartConfig,
  validateTimeSeriesChartConfig,
} from './time-series-config'

import type { DashboardWidgetReadonlyPanel } from '@zxio/dashboard/widget'

export type WidgetChartKind = 'gauge' | 'time-series' | 'bar'

/** Returns fresh options: ECharts may normalize/mutate inputs; panel data is readonly. */
export function createWidgetChartOptions(
  panel: DashboardWidgetReadonlyPanel,
  kind: WidgetChartKind
) {
  const data = panel.data
  if (kind === 'gauge') {
    const value = readMetric(data)
    const min = paramNumber(panel, 'min', 0)
    const max = paramNumber(panel, 'max', 100)
    if (value === undefined || max <= min) return undefined
    return {
      animation: false,
      series: [
        {
          type: 'gauge',
          min,
          max,
          radius: '88%',
          center: ['50%', '58%'],
          startAngle: 210,
          endAngle: -30,
          progress: { show: true, width: 12 },
          axisLine: { lineStyle: { width: 12, opacity: 0.2 } },
          axisTick: { show: false },
          splitLine: { show: false },
          axisLabel: { show: false },
          pointer: { length: '55%', width: 4 },
          title: { show: false },
          detail: { show: false },
          data: [{ value }],
        },
      ],
    }
  }
  const common = {
    animation: false,
    useUTC: true,
    tooltip: { trigger: 'axis', renderMode: 'richText' },
    legend: { show: panel.params?.legend !== false, top: 0, type: 'scroll' },
    grid: {
      left: 12,
      right: 16,
      top: panel.params?.legend === false ? 12 : 32,
      bottom: 12,
      containLabel: true,
    },
  }
  if (kind === 'time-series' && isTimeSeries(data)) {
    if (validateTimeSeriesChartConfig(panel.params).length) return undefined
    const config = readTimeSeriesChartConfig(panel.params)
    const titleHeight = config.title.show ? 32 : 0
    const legendTop = config.legend.show && config.legend.position === 'top'
    const legendBottom =
      config.legend.show && config.legend.position === 'bottom'
    return {
      ...common,
      title: {
        show: config.title.show,
        text: config.title.text,
        left: 'center',
        top: 0,
      },
      legend: {
        show: config.legend.show,
        type: 'scroll',
        top: legendBottom ? undefined : titleHeight,
        bottom: legendBottom ? 0 : undefined,
      },
      grid: {
        ...common.grid,
        top: titleHeight + (legendTop ? 32 : 12),
        bottom: legendBottom ? 40 : 12,
      },
      xAxis: { type: 'time', show: config.xAxis.show },
      yAxis: {
        type: 'value',
        name: config.yAxis.name,
        min: config.yAxis.mode === 'fixed' ? config.yAxis.min : undefined,
        max: config.yAxis.mode === 'fixed' ? config.yAxis.max : undefined,
      },
      series: data.series.map((series) => ({
        name: series.name,
        type: 'line',
        showSymbol: series.points.length === 1,
        smooth: panel.params?.smooth === true,
        connectNulls: false,
        data: series.points.map((point) => [...point]),
      })),
    }
  }
  if (kind === 'bar' && isBarData(data)) {
    const category = { type: 'category', data: [...data.categories] }
    const numeric = { type: 'value' }
    const horizontal = panel.params?.horizontal === true
    return {
      ...common,
      xAxis: horizontal ? numeric : category,
      yAxis: horizontal ? category : numeric,
      series: data.series.map((series) => ({
        name: series.name,
        type: 'bar',
        data: [...series.values],
        barMaxWidth: 40,
      })),
    }
  }
  return undefined
}
