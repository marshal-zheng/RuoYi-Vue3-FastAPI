# @zxio/http

通用 HTTP 请求库，基于 Axios 封装，支持插件化扩展、自定义通知、Token 管理等。

## 快速开始

### 基础使用

```typescript
import { createHttpClient } from '@zxio/http'

// 创建客户端
const http = createHttpClient({
  axiosConfig: {
    baseURL: '/api',
    timeout: 10000,
  },
})

// 发起请求
const data = await http.get({ url: '/users' })
const user = await http.post({ url: '/users', data: { name: 'John' } })
```

### 配置 Token

```typescript
const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  tokenProvider: {
    getToken: () => localStorage.getItem('token') || '',
  },
})

// 请求会自动携带 Authorization header
const data = await http.get({ url: '/profile' })
```

### 自定义成功判定

```typescript
const http = createHttpClient({
  successCodes: [200, 0], // 支持多个成功码
  successResolver: ({ response }) => {
    const { code, data, msg } = response.data
    return {
      ok: code === 0,
      data,
      message: msg,
      code,
      raw: response.data,
    }
  },
})
```

### 集成 Element Plus 通知

```typescript
import { ElMessage, ElMessageBox } from 'element-plus'
import { createHttpClient } from '@zxio/http'

const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  notifier: {
    message(type, content) {
      ElMessage[type](content)
    },
    modal(type, { title, content }) {
      ElMessageBox.alert(content, title, { type })
    },
  },
})
```

### 使用 Grid List 插件

```typescript
import { createHttpClient, createGridListPlugin } from '@zxio/http'

const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  plugins: [createGridListPlugin()],
})

// 发送请求
await http.post({
  url: '/users',
  data: {
    pager: { page: 1, size: 20 },
    query: { name: 'John' },
  },
})

// 自动转换为
// { page: 1, size: 20, name: 'John' }

// 响应自动补充 pager
// { list: [...], total: 100 } → { list: [...], pager: { page: 1, size: 20, total: 100 } }
```

### 自定义插件

```typescript
const loggerPlugin = {
  name: 'logger',
  setup(client) {
    client.extendTransforms({
      async beforeRequest(config) {
        console.log('Request:', config.url)
        return config
      },
      async afterResponse(response) {
        console.log('Response:', response.status)
        return response
      },
    })
  },
}

const http = createHttpClient({
  plugins: [loggerPlugin],
})
```

### 文件上传

```typescript
const http = createHttpClient({ axiosConfig: { baseURL: '/api' } })

await http.upload(
  { url: '/upload' },
  {
    file: fileObject,
    name: 'avatar', // 自定义字段名
    data: { userId: 123 }, // 额外参数
  }
)
```

### 请求选项

每个请求可覆盖全局配置：

```typescript
// 不显示成功提示
await http.post({ url: '/users', data }, { successMessageMode: 'none' })

// 错误使用弹窗
await http.get({ url: '/critical' }, { errorMessageMode: 'modal' })

// 不携带 token
await http.get({ url: '/public' }, { withToken: false })

// 自定义提示消息
await http.post(
  { url: '/users', data },
  {
    successNotice: { message: '创建成功！' },
    errorNotice: { message: '创建失败，请重试' },
  }
)
```

### 请求重试

失败自动重试，支持指数退避：

```typescript
import { createHttpClient, exponentialBackoff } from '@zxio/http'

const http = createHttpClient({
  retry: {
    count: 3, // 最多重试 3 次
    delay: exponentialBackoff, // 指数退避: 1s, 2s, 4s...
  },
})

// 单次请求禁用重试
await http.get({ url: '/api/data' }, { retry: false })
```

### 请求去重

相同请求复用同一个 Promise：

```typescript
const http = createHttpClient({
  deduplication: true,
})

// 这两个请求只会发送一次
const [r1, r2] = await Promise.all([
  http.get({ url: '/api/user/1' }),
  http.get({ url: '/api/user/1' }),
])
```

### 超时控制

不同请求类型使用不同超时：

```typescript
const http = createHttpClient({
  timeout: {
    default: 10000, // 普通请求 10s
    upload: 60000, // 上传 60s
    download: 60000, // 下载 60s
  },
})
```

### 错误类型

细分错误类型，便于精确处理：

```typescript
import {
  NetworkError,
  TimeoutError,
  ValidationError,
  ServerError,
} from '@zxio/http'

try {
  await http.get({ url: '/api/data' })
} catch (e) {
  if (e instanceof NetworkError) console.log('网络不可用')
  if (e instanceof TimeoutError) console.log('请求超时')
  if (e instanceof ValidationError) console.log('参数错误:', e.status)
  if (e instanceof ServerError) console.log('服务器错误:', e.status)
}
```

### 并发控制

限制最大并发数，支持优先级：

```typescript
import { createHttpClient, createConcurrencyPlugin } from '@zxio/http'

const http = createHttpClient({
  plugins: [createConcurrencyPlugin({ maxConcurrent: 6 })],
})

// 高优先级请求优先执行
await http.get({ url: '/api/important' }, { priority: 10 })
```

### 类型安全 API

定义 API 端点，获得完整类型推导：

```typescript
import { createHttpClient, createTypedAPI } from '@zxio/http'

const api = createTypedAPI(http, {
  getUser: { method: 'GET', url: '/api/users/:id' },
  createUser: { method: 'POST', url: '/api/users' },
})

const user = await api.getUser({ id: 1 })
```

### 增强日志

结构化日志输出：

```typescript
import { createHttpClient, createEnhancedLogger } from '@zxio/http'

const http = createHttpClient({
  logger: createEnhancedLogger({
    enabled: true,
    level: 'debug',
    format: 'pretty', // pretty | json
  }),
})
```

## API

### createHttpClient(config)

创建 HTTP 客户端实例。

**参数：**

- `axiosConfig` - Axios 配置对象
- `tokenProvider` - Token 提供器
  - `getToken(): string | Promise<string>` - 获取 token
  - `applyToken?(config, token, options)` - 自定义 token 应用方式
  - `onAuthError?(error)` - 401 错误回调
- `notifier` - 通知适配器
  - `message(type, content)` - 消息通知
  - `modal(type, { title, content })` - 弹窗通知
- `successResolver` - 自定义成功判定
- `successCodes` - 成功状态码数组
- `requestOptions` - 默认请求选项
- `plugins` - 插件数组
- `logger` - 日志记录器

### 请求方法

- `http.get(config, options)` - GET 请求
- `http.post(config, options)` - POST 请求
- `http.put(config, options)` - PUT 请求
- `http.delete(config, options)` - DELETE 请求
- `http.upload(config, uploadOption)` - 文件上传
- `http.request(config, options)` - 通用请求

### 插件

- `createGridListPlugin(options)` - Grid List 数据转换插件

## 类型定义

```typescript
interface HttpClientConfig {
  axiosConfig?: AxiosRequestConfig
  tokenProvider?: HttpTokenProvider
  notifier?: HttpNotifier
  successResolver?: SuccessResolver
  successCodes?: Array<string | number>
  requestOptions?: RequestOptions
  plugins?: HttpPlugin[]
  logger?: HttpClientLogger
}

interface RequestOptions {
  withToken?: boolean
  successMessageMode?: 'auto' | 'message' | 'modal' | 'none'
  errorMessageMode?: 'message' | 'modal' | 'none'
  showSuccessMessage?: boolean
  showErrorMessage?: boolean
  isTransformResponse?: boolean
  isReturnNativeResponse?: boolean
  joinParamsToUrl?: boolean
  joinTime?: boolean
  ignoreCancelToken?: boolean
  successNotice?: { title?: string; message?: string }
  errorNotice?: { title?: string; message?: string }
  context?: Record<string, unknown>
}
```
