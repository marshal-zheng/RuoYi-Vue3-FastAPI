import type { RequestOptions } from './types.js';
/** Marks requests whose cancellation, retries and error feedback belong to a command owner. */
export declare const COMMAND_REQUEST_CONTEXT_KEY = "@zxio/http/command-request";
export type CommandRequestContext = Readonly<{
    signal: AbortSignal;
    options: RequestOptions;
}>;
/** Compose ordinary HTTP call arguments without creating a client or mutating options. */
export declare function commandRequest(signal: AbortSignal, options?: RequestOptions): CommandRequestContext;
/** Let a business HTTP bridge transfer ordinary command error feedback to its consumer. */
export declare function isCommandRequest(options?: RequestOptions): boolean;
