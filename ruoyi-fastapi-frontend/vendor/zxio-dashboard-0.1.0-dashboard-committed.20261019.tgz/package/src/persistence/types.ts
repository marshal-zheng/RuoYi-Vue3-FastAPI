import type { DashboardDocument } from '../schema'

export interface DashboardStoredDocument {
  document: DashboardDocument
  /** Monotonic, positive server-assigned revision. */
  revision: number
  updatedAt?: string
}

export type DashboardPersistenceWriteResult =
  | { status: 'saved'; snapshot: DashboardStoredDocument }
  | { status: 'conflict'; remote: DashboardStoredDocument | null }

export type DashboardPersistenceRemoveResult =
  | { status: 'removed' }
  | { status: 'conflict'; remote: DashboardStoredDocument | null }

export interface DashboardPersistenceAdapter {
  load: (key: string) => Promise<DashboardStoredDocument | null>
  save: (
    key: string,
    document: DashboardDocument,
    expectedRevision: number | null
  ) => Promise<DashboardPersistenceWriteResult>
  remove: (
    key: string,
    expectedRevision: number
  ) => Promise<DashboardPersistenceRemoveResult>
  /** Notification only; this controller reloads through the same adapter. */
  subscribe?: (key: string, invalidate: () => void) => () => void
}

export type DashboardConflictStrategy = 'manual' | 'newer-wins' | 'keep-local'

export interface DashboardPersistenceState {
  document: DashboardDocument | null
  saved: DashboardStoredDocument | null
  dirty: boolean
  pending: 'load' | 'save' | 'remove' | null
  conflict: { remote: DashboardStoredDocument | null } | null
  error: unknown
}

export interface DashboardPersistenceOptions {
  key: string
  adapter: DashboardPersistenceAdapter
  initialDocument?: DashboardDocument
  conflictStrategy?: DashboardConflictStrategy
}

export interface DashboardPersistence {
  getState: () => DashboardPersistenceState
  setDocument: (document: DashboardDocument) => void
  load: () => Promise<void>
  /** An explicit candidate stays outside the live document until a successful save. */
  save: (
    candidate?: DashboardDocument
  ) => Promise<DashboardPersistenceWriteResult>
  remove: () => Promise<DashboardPersistenceRemoveResult>
  /** Resolves the observed conflict; keeping local never writes automatically. */
  resolveConflict: (choice: 'remote' | 'local') => void
  subscribe: (
    listener: (state: DashboardPersistenceState) => void
  ) => () => void
  dispose: () => void
}
