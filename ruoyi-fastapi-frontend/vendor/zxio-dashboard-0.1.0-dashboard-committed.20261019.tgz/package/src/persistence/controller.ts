import { exportDashboardDocument } from '../import-export'
import { cloneDashboardJson } from '../schema'

import type { DashboardDocument } from '../schema'
import type {
  DashboardPersistence,
  DashboardPersistenceOptions,
  DashboardPersistenceState,
  DashboardStoredDocument,
} from './types'

function documentCopy(document: DashboardDocument): DashboardDocument {
  const result = exportDashboardDocument(document)
  if (!result.document)
    throw new Error('Invalid dashboard persistence document')
  return result.document
}

function storedCopy(value: DashboardStoredDocument | null) {
  if (value === null) return null
  if (!Number.isSafeInteger(value.revision) || value.revision < 1)
    throw new Error('Invalid dashboard persistence revision')
  return { ...value, document: documentCopy(value.document) }
}

// Key order is not an edit. Arrays (notably panel order) retain their order.
function signature(value: unknown): string {
  return JSON.stringify(value, (_key, entry) => {
    if (entry && typeof entry === 'object' && !Array.isArray(entry))
      return Object.fromEntries(
        Object.keys(entry)
          .sort()
          .map((key) => [key, entry[key]])
      )
    return entry
  })
}

/** A revision/baseline boundary, independent of Vue, transport and undo history. */
export function createDashboardPersistence(
  options: DashboardPersistenceOptions
): DashboardPersistence {
  if (!options.key.trim())
    throw new Error('A dashboard persistence key is required')
  const { adapter, key } = options
  let document = options.initialDocument
    ? documentCopy(options.initialDocument)
    : null
  let saved: DashboardStoredDocument | null = null
  let conflict: DashboardPersistenceState['conflict'] = null
  let pending: DashboardPersistenceState['pending'] = null
  let error: unknown = null
  let disposed = false
  let invalidated = false
  let localEpoch = 0
  const listeners = new Set<(state: DashboardPersistenceState) => void>()
  const dirty = () => signature(document) !== signature(saved?.document ?? null)
  const active = () => {
    if (disposed) throw new Error('Dashboard persistence is disposed')
  }
  const getState = (): DashboardPersistenceState => ({
    document: document === null ? null : cloneDashboardJson(document),
    saved: saved === null ? null : cloneDashboardJson(saved),
    dirty: dirty(),
    pending,
    conflict: conflict === null ? null : cloneDashboardJson(conflict),
    error,
  })
  const notify = () => {
    if (!disposed)
      listeners.forEach((listener) => {
        try {
          listener(getState())
        } catch (cause) {
          // Observers must not interrupt the transaction or strand pending state.
          console.error('[dashboard] Persistence subscriber failed', cause)
        }
      })
  }

  function resolveConflict(choice: 'remote' | 'local') {
    active()
    if (!conflict) return
    saved = conflict.remote
    if (choice === 'remote') {
      document = saved ? documentCopy(saved.document) : null
      localEpoch++
    }
    conflict = null
    notify()
  }

  function receiveConflict(remote: DashboardStoredDocument | null) {
    conflict = { remote: storedCopy(remote) }
    const strategy = options.conflictStrategy ?? 'manual'
    if (strategy !== 'manual')
      resolveConflict(strategy === 'newer-wins' ? 'remote' : 'local')
  }

  async function run<T>(
    operation: NonNullable<DashboardPersistenceState['pending']>,
    work: () => Promise<T>
  ): Promise<T> {
    active()
    if (pending)
      throw new Error('Dashboard persistence operation is already pending')
    pending = operation
    error = null
    notify()
    try {
      return await work()
    } catch (cause) {
      if (!disposed) error = cause
      throw cause
    } finally {
      pending = null
      notify()
      if (invalidated && !disposed) {
        invalidated = false
        load().catch(() => {
          // The failed refresh is observable through state.error.
        })
      }
    }
  }

  async function load() {
    return run('load', async () => {
      const remote = storedCopy(await adapter.load(key))
      if (disposed) return
      if (
        signature(remote?.document ?? null) ===
          signature(saved?.document ?? null) &&
        remote?.revision === saved?.revision
      )
        return
      if (saved && remote && remote.revision < saved.revision) return
      if (dirty() && (saved !== null || localEpoch > 0)) receiveConflict(remote)
      else {
        saved = remote
        document = remote ? documentCopy(remote.document) : null
        conflict = null
      }
    })
  }

  const unsubscribe = adapter.subscribe?.(key, () => {
    if (disposed) return
    if (pending) invalidated = true
    else
      load().catch(() => {
        // The failed refresh is observable through state.error.
      })
  })

  return {
    getState,
    setDocument(next) {
      active()
      document = documentCopy(next)
      localEpoch++
      notify()
    },
    load,
    save(candidate) {
      return run('save', async () => {
        const next = candidate ?? document
        if (!next) throw new Error('No dashboard document to save')
        if (conflict)
          throw new Error('Resolve the dashboard conflict before saving')
        const captured = documentCopy(next)
        const epoch = localEpoch
        const expected = saved?.revision ?? null
        const result = await adapter.save(key, captured, expected)
        if (disposed) return result
        if (result.status === 'conflict') receiveConflict(result.remote)
        else {
          const snapshot = storedCopy(result.snapshot)!
          if (snapshot.revision <= (expected ?? 0))
            throw new Error('Saved dashboard revision did not advance')
          saved = snapshot
          if (epoch === localEpoch) document = documentCopy(snapshot.document)
          conflict = null
        }
        return cloneDashboardJson(result)
      })
    },
    remove() {
      return run('remove', async () => {
        if (!saved) throw new Error('No stored dashboard to remove')
        if (conflict)
          throw new Error('Resolve the dashboard conflict before removing')
        const epoch = localEpoch
        const result = await adapter.remove(key, saved.revision)
        if (disposed) return result
        if (result.status === 'conflict') receiveConflict(result.remote)
        else {
          saved = null
          if (epoch === localEpoch) document = null
          conflict = null
        }
        return cloneDashboardJson(result)
      })
    },
    resolveConflict,
    subscribe(listener) {
      active()
      listeners.add(listener)
      listener(getState())
      return () => listeners.delete(listener)
    },
    dispose() {
      if (disposed) return
      disposed = true
      unsubscribe?.()
      listeners.clear()
    },
  }
}
