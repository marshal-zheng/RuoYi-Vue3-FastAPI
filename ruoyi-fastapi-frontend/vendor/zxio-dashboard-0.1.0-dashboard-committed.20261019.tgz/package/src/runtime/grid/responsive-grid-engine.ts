import { defineComponent, h } from 'vue'
import { EditorGridLayout } from '@zxio/vue-grid-layout/editor'
import { useResponsiveGridLayoutModel } from '@zxio/vue-grid-layout/responsive'

import type { Component, PropType } from 'vue'
import type {
  LayoutsMap,
  ResponsiveGridLayoutModelProps,
} from '@zxio/vue-grid-layout/responsive'

/**
 * Reuse the engine's responsive projection with a single, ordinary editor.
 * A responsive controller sharing the model's layout ref bypasses the inner
 * grid's layoutChange bridge for keyboard commands. Dashboard owns history,
 * so it needs one editor and one writeback path for every input method.
 */
const DashboardResponsiveGridEngine = defineComponent({
  name: 'DashboardResponsiveGridEngine',
  inheritAttrs: false,
  props: {
    width: { type: Number, default: 1200 },
    breakpoint: String,
    breakpoints: {
      type: Object as PropType<Record<string, number>>,
      required: true,
    },
    cols: { type: Object as PropType<Record<string, number>>, required: true },
    layouts: { type: Object as PropType<LayoutsMap>, required: true },
    compactType: {
      type: String as PropType<'vertical' | 'horizontal' | null>,
      default: 'vertical',
    },
    margin: {
      type: Array as unknown as PropType<[number, number]>,
      default: () => [20, 20],
    },
    containerPadding: {
      type: Array as unknown as PropType<[number, number]>,
      default: () => [0, 0],
    },
    allowOverlap: { type: Boolean, default: false },
    verticalCompact: { type: Boolean, default: true },
  },
  emits: ['layoutChange', 'update:layouts', 'breakpointChange', 'widthChange'],
  setup(props, { slots, attrs, emit }) {
    const model = useResponsiveGridLayoutModel({
      props: props as ResponsiveGridLayoutModelProps,
      slots,
      emit,
    })
    return () =>
      h(
        EditorGridLayout as Component,
        {
          ...attrs,
          width: props.width,
          cols: model.state.cols,
          modelValue: model.state.layout,
          margin: props.margin,
          containerPadding: props.containerPadding,
          compactType: props.compactType,
          allowOverlap: props.allowOverlap,
          onLayoutChange: model.onLayoutChange,
        },
        slots
      )
  },
})

export default DashboardResponsiveGridEngine
