<template>
  <div
    ref="rootRef"
    class="zx-dashboard-grid"
    :class="[
      `zx-dashboard-grid--${runtimeMode}`,
      {
        'is-interacting': interactiveActive,
        'is-layout-editable': canEditLayout,
        'is-layout-draggable': isGridDraggable,
        'is-layout-resizable': isGridResizable,
        'is-layout-droppable': isGridDroppable,
      },
    ]"
    :data-dashboard-mode="runtimeMode"
    :data-dashboard-breakpoint="breakpoint"
    :data-dashboard-layout-editable="String(canEditLayout)"
    :data-dashboard-draggable="String(isGridDraggable)"
    :data-dashboard-resizable="String(isGridResizable)"
    :data-dashboard-droppable="String(isGridDroppable)"
    :style="gridSurfaceStyle"
  >
    <component
      :is="
        responsive ? ResponsiveDashboardGridLayout : DefaultDashboardGridLayout
      "
      :key="gridInstanceKey"
      v-model="engineLayout"
      class="zx-dashboard-grid__layout"
      :cols="responsive ? breakpointColumns : resolvedGrid.columns"
      :breakpoint="responsive ? breakpoint : undefined"
      :breakpoints="responsive ? DASHBOARD_BREAKPOINTS : undefined"
      :layouts="responsive ? engineLayouts : undefined"
      :row-height="resolvedGrid.rowHeight"
      :margin="resolvedGrid.margin"
      :container-padding="resolvedGrid.containerPadding"
      :compact-type="resolvedGrid.compactType"
      :draggable-handle="resolvedGrid.draggableHandle"
      :is-draggable="isGridDraggable"
      :is-resizable="isGridResizable"
      :is-droppable="isGridDroppable"
      :measure-before-mount="resolvedGrid.measureBeforeMount"
      :use-c-s-s-transforms="resolvedGrid.useCssTransforms"
      :direction="resolvedGrid.direction"
      :drag-activation-delay="resolvedGrid.dragActivationDelay"
      :editor="gridEditor"
      :persistence="false"
      @layout-change="handleLayoutChange"
      @drag-start="handleDragStart"
      @drag-stop="handleDragStop"
      @resize-start="handleResizeStart"
      @resize-stop="handleResizeStop"
      @drop="handleDrop"
      @drop-drag-over="handleDropDragOver"
    >
      <div
        v-for="panel in panels"
        :key="panel.id"
        class="zx-dashboard-grid__item"
        :data-panel-id="panel.id"
      >
        <slot :panel="panel" :mode="runtimeMode">
          <div class="zx-dashboard-grid__item-fallback">
            {{ panel.title || panel.id }}
          </div>
        </slot>
      </div>
    </component>
  </div>
</template>

<script setup lang="ts">
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import {
  DefaultDashboardGridLayout,
  ResponsiveDashboardGridLayout,
  createDashboardGridEditor,
  isDashboardSectionRowCommand,
  readGridInteraction,
} from '../grid/vue-grid-layout-adapter'
import {
  adoptUnknownDashboardLayoutItems,
  createDashboardEditorClipboard,
  isDashboardEditorHostCommand,
  resolveDashboardGridEditorCommand,
} from '../grid/editor-clipboard'
import {
  applyDashboardGridLayout,
  buildDashboardGridLayout,
} from '../grid/layout-adapter'
import {
  compactDashboardGridItemOptions,
  resolveDashboardGridItemOptions,
} from '../grid/panel-layout'
import { readDashboardDropPayload } from '../grid/drag-mime'
import { resolveDashboardRuntimeMode } from '../mode'
import { DASHBOARD_BREAKPOINTS } from '../../schema'
import {
  projectDashboardPanels,
  useDashboardResponsiveGrid,
  writeDashboardBreakpointPanels,
} from '../grid/responsive'
import {
  formatDashboardCopy,
  formatDashboardIssueMessage,
  useDashboardLocale,
} from '../../locale'

import type { DashboardGridPosition, DashboardPanel } from '../../schema'
import type { PropType } from 'vue'
import type {
  DashboardEditorCommandRequestEvent,
  DashboardGridItemOptions,
  DashboardGridLayoutItem,
  DashboardGridOptions,
  DashboardLayoutInteractionEvent,
  DashboardPanelAddRequestEvent,
  DashboardRuntimeIssue,
  DashboardRuntimeMode,
} from '../types'

const DEFAULT_GRID_OPTIONS = {
  columns: 24,
  rowHeight: 30,
  margin: [20, 20] as const,
  containerPadding: [0, 0] as const,
  compactType: 'vertical' as const,
  draggableHandle: '.zx-dashboard-panel__drag-handle',
  isDraggable: true,
  isResizable: true,
  isDroppable: false,
  useCssTransforms: true,
  measureBeforeMount: true,
  direction: 'auto' as const,
  // A short hold on touch / coarse pointers keeps page scrolling from
  // starting a drag; mouse and pen stay immediate.
  dragActivationDelay: { touch: 300, coarse: 300 },
  defaultDropSize: { w: 12, h: 8 },
}

const props = defineProps({
  panels: {
    type: Array as PropType<DashboardPanel[]>,
    default: () => [],
  },
  mode: String as PropType<DashboardRuntimeMode>,
  grid: Object as PropType<DashboardGridOptions>,
  readonly: Boolean,
  editable: Boolean,
  layoutOnlyMode: Boolean,
})

const emit = defineEmits<{
  (event: 'update:panels', panels: DashboardPanel[]): void
  (
    event: 'layout-change',
    payload: {
      type: 'layout-change'
      mode: DashboardRuntimeMode
      source: 'grid'
      panels: DashboardPanel[]
      changes: ReturnType<typeof applyDashboardGridLayout>['changes']
    }
  ): void
  (event: 'drag-start', payload: DashboardLayoutInteractionEvent): void
  (event: 'drag-stop', payload: DashboardLayoutInteractionEvent): void
  (event: 'resize-start', payload: DashboardLayoutInteractionEvent): void
  (event: 'resize-stop', payload: DashboardLayoutInteractionEvent): void
  (event: 'panel-add-request', payload: DashboardPanelAddRequestEvent): void
  (
    event: 'editor-command-request',
    payload: DashboardEditorCommandRequestEvent
  ): void
  (event: 'runtime-issue', payload: DashboardRuntimeIssue): void
}>()

const locale = useDashboardLocale()
const rootRef = ref<HTMLElement>()
const { breakpoint, projecting } = useDashboardResponsiveGrid(rootRef)
const responsive = computed(
  () =>
    breakpoint.value === 'xs' ||
    breakpoint.value === 'xxs' ||
    props.panels.some((panel) => panel.layouts !== undefined)
)
const breakpointColumns = computed(() =>
  Object.fromEntries(
    Object.keys(DASHBOARD_BREAKPOINTS).map((key) => [
      key,
      resolvedGrid.value.columns,
    ])
  )
)
const projectedPanels = computed(() =>
  projectDashboardPanels(
    props.panels,
    breakpoint.value,
    resolvedGrid.value.columns
  )
)
const engineLayouts = computed(() =>
  Object.fromEntries(
    Object.keys(DASHBOARD_BREAKPOINTS).map((key) => [
      key,
      buildEngineLayout(
        projectDashboardPanels(
          props.panels,
          key as typeof breakpoint.value,
          resolvedGrid.value.columns
        )
      ),
    ])
  )
)
const engineLayout = ref<DashboardGridLayoutItem[]>([])
const interacting = ref(false)
const endingInteraction = ref(false)
const responsiveCommand = ref(false)
const editorClipboard = createDashboardEditorClipboard()
const formatCopyTitle = (title: string) =>
  formatDashboardCopy(locale.value.panel.copySuffix, { title })
const pendingAddedPanelIds = new Set<string>()
// Set when a paste is allowed before its geometry is known; the next layout
// change may then adopt unknown items as clones of the clipboard panels.
let pasteAwaitingLayout = false

const runtimeMode = computed(() =>
  resolveDashboardRuntimeMode({
    mode: props.mode,
    editable: props.editable,
    layoutOnlyMode: props.layoutOnlyMode,
  })
)

const resolvedGrid = computed(() => ({
  ...DEFAULT_GRID_OPTIONS,
  ...(props.grid ?? {}),
}))

const showInteractionFeedback = computed(
  () => runtimeMode.value !== 'view' && props.readonly !== true
)

const interactiveActive = computed(
  () => interacting.value && showInteractionFeedback.value
)

const gridSurfaceStyle = computed(() => ({
  '--zx-dashboard-grid-cols': String(resolvedGrid.value.columns),
  '--zx-dashboard-grid-row-height': `${resolvedGrid.value.rowHeight}px`,
}))

const canEditLayout = computed(
  () => runtimeMode.value !== 'view' && props.readonly !== true
)
const isGridDraggable = computed(
  () => canEditLayout.value && resolvedGrid.value.isDraggable !== false
)
const isGridResizable = computed(
  () => canEditLayout.value && resolvedGrid.value.isResizable !== false
)
const isGridDroppable = computed(
  () => canEditLayout.value && resolvedGrid.value.isDroppable === true
)
const gridEditor = computed(() =>
  createDashboardGridEditor({
    enabled: canEditLayout.value,
    columns: resolvedGrid.value.columns,
    compactType: resolvedGrid.value.compactType,
    beforeCommand: handleEditorBeforeCommand,
    clipboard: editorClipboard.adapter,
  })
)
// The grid library reads `editor` once at setup: remount the engine whenever
// the editor configuration changes so view / readonly never keep edit commands.
const gridInstanceKey = computed(
  () =>
    `${breakpoint.value}:${
      canEditLayout.value
        ? `edit:${resolvedGrid.value.columns}:${resolvedGrid.value.compactType}`
        : 'view'
    }`
)

watch(
  () => projectedPanels.value,
  (panels) => {
    responsiveCommand.value = false
    engineLayout.value = buildEngineLayout(panels)
    for (const panelId of [...pendingAddedPanelIds]) {
      if (panels.some((panel: DashboardPanel) => panel.id === panelId)) {
        pendingAddedPanelIds.delete(panelId)
      }
    }
  },
  { immediate: true, deep: true }
)

onBeforeUnmount(() => {
  engineLayout.value = []
})

function buildEngineLayout(panels: readonly DashboardPanel[]) {
  return buildDashboardGridLayout(panels, {
    getItemOptions: resolveItemOptions,
  })
}

/**
 * Engine item options: `panel.metadata.layout` (size bounds, `locked` →
 * `static`) under the host's `grid.getItemOptions`, so a host can always
 * tighten or override what the document carries.
 */
function resolveItemOptions(panel: DashboardPanel): DashboardGridItemOptions {
  return {
    ...resolveDashboardGridItemOptions(panel),
    ...compactDashboardGridItemOptions(
      resolvedGrid.value.getItemOptions?.(panel) ?? {}
    ),
  }
}

function handleEditorBeforeCommand(context: {
  command: { type: string; payload?: unknown; source?: string }
  source?: string
  targetIds: string[]
  preview?: { layoutPatches?: unknown[] }
}) {
  if (isDashboardSectionRowCommand(context.command.type))
    return {
      status: 'block' as const,
      reason: 'before-command-blocked' as const,
    }
  // A stale editor (captured before a mode switch remounted the engine) must
  // not mutate a view / readonly dashboard.
  if (!canEditLayout.value || projecting.value) {
    return { status: 'block' as const, reason: 'mode-readonly' as const }
  }

  const result = resolveDashboardGridEditorCommand({
    panels: props.panels,
    clipboardSourceIds: editorClipboard.sourceIds(),
    commandType: context.command.type,
    commandSource: context.command.source ?? context.source,
    targetIds: context.targetIds,
    payload: context.command.payload,
    layoutPatches: context.preview?.layoutPatches,
    formatCopyTitle,
  })

  if (result.status === 'block') {
    return {
      status: 'block' as const,
      reason: 'before-command-blocked' as const,
    }
  }

  // The host runs delete / undo / redo / save / discard on its own model; the
  // engine's command is cancelled so its geometry history stays untouched.
  if (result.status === 'request') {
    if (isDashboardEditorHostCommand(context.command.type)) {
      emit('editor-command-request', {
        type: 'editor-command-request',
        mode: runtimeMode.value,
        source: 'grid',
        command: context.command.type,
        targetIds: [...context.targetIds],
      })
    }
    return { status: 'cancel' as const }
  }

  if (result.status === 'allow') {
    // The engine may commit after an async command guard. Keep its geometry
    // intent until the corresponding layout arrives, rather than one Vue tick.
    responsiveCommand.value =
      Boolean(context.preview?.layoutPatches?.length) ||
      context.command.type === 'paste'
    if (context.command.type === 'paste') pasteAwaitingLayout = true
    return { status: 'allow' as const }
  }

  if (result.panels) commitPanels(result.panels)
  return { status: 'cancel' as const }
}

function handleLayoutChange(layout: DashboardGridLayoutItem[]) {
  // View / readonly dashboards never write layout back into `panels`.
  if (
    !canEditLayout.value ||
    projecting.value ||
    (responsive.value &&
      !interacting.value &&
      !endingInteraction.value &&
      !responsiveCommand.value)
  ) {
    pasteAwaitingLayout = false
    return
  }
  responsiveCommand.value = false

  const adopted = pasteAwaitingLayout
    ? adoptUnknownDashboardLayoutItems({
        panels: props.panels,
        layout,
        sourceIds: editorClipboard.sourceIds(),
        ignoreIds: pendingAddedPanelIds,
        formatCopyTitle,
      })
    : null
  pasteAwaitingLayout = false
  const panels = adopted?.panels ?? props.panels
  if (adopted) rememberAddedPanelIds(props.panels, adopted.panels)

  const result = applyDashboardGridLayout(
    projectDashboardPanels(
      panels,
      breakpoint.value,
      resolvedGrid.value.columns
    ),
    layout
  )
  result.panels = writeDashboardBreakpointPanels(
    panels,
    result.panels,
    breakpoint.value,
    resolvedGrid.value.columns
  )

  if (adopted || result.changes.length > 0) {
    emit('update:panels', result.panels)
    emit('layout-change', {
      type: 'layout-change',
      mode: runtimeMode.value,
      source: 'grid',
      panels: result.panels,
      changes: result.changes,
    })
  }

  const issues = result.issues.filter(
    (issue) =>
      issue.code !== 'unknown_layout_panel' ||
      !pendingAddedPanelIds.has(issue.panelId ?? '')
  )
  issues.forEach((issue) => {
    // The engine briefly commits its default drop placeholder before `drop`
    // lets the host create a real panel. Still resync it below, but this is not
    // an orphaned document panel and should not become a user-facing warning.
    if (
      isGridDroppable.value &&
      issue.code === 'unknown_layout_panel' &&
      issue.panelId === '__dropping-elem__'
    )
      return
    emit('runtime-issue', localizeIssue(issue))
  })

  // An orphan or missing engine item has no `panels` counterpart: put the
  // engine back on the model instead of leaving the two out of sync.
  if (
    issues.some(
      (issue) =>
        issue.code === 'unknown_layout_panel' ||
        issue.code === 'missing_layout_item'
    )
  ) {
    engineLayout.value = buildEngineLayout(result.panels)
  }
}

function commitPanels(panels: DashboardPanel[]) {
  rememberAddedPanelIds(props.panels, panels)
  emit('update:panels', panels)
}

function localizeIssue(issue: DashboardRuntimeIssue): DashboardRuntimeIssue {
  const message = formatDashboardIssueMessage(locale.value, issue.code, {
    panelId: issue.panelId,
  })
  return message === undefined ? issue : { ...issue, message }
}

function rememberAddedPanelIds(
  previous: readonly DashboardPanel[],
  next: readonly DashboardPanel[]
) {
  const knownIds = new Set(previous.map((panel) => panel.id))
  next.forEach((panel) => {
    if (!knownIds.has(panel.id)) pendingAddedPanelIds.add(panel.id)
  })
}

function handleDragStart(payload: unknown) {
  beginInteraction()
  emitInteractionEvent('drag-start', payload)
}

function handleDragStop(payload: unknown) {
  emitInteractionEvent('drag-stop', payload)
  endInteraction()
}

function handleResizeStart(payload: unknown) {
  beginInteraction()
  emitInteractionEvent('resize-start', payload)
}

function handleResizeStop(payload: unknown) {
  emitInteractionEvent('resize-stop', payload)
  endInteraction()
}

function beginInteraction() {
  if (!showInteractionFeedback.value) return
  interacting.value = true
}

function endInteraction() {
  interacting.value = false
  endingInteraction.value = true
  nextTick(() => {
    endingInteraction.value = false
  })
}

function handleDrop(
  _layout: DashboardGridLayoutItem[] | undefined,
  nativeEvent: DragEvent | undefined,
  layoutItem: DashboardGridLayoutItem | undefined
) {
  if (!isGridDroppable.value || !layoutItem) {
    emit('runtime-issue', {
      severity: 'info',
      code: 'drop_ignored',
      message: locale.value.issues.drop_ignored,
    })
    return
  }

  const gridPos = layoutItemToGridPosition(layoutItem)
  if (!gridPos) {
    emit('runtime-issue', {
      severity: 'error',
      code: 'invalid_layout_item',
      message: locale.value.issues.invalid_drop_position,
    })
    return
  }

  emit('panel-add-request', {
    type: 'panel-add-request',
    mode: runtimeMode.value,
    source: 'grid',
    nativeEvent,
    gridPos,
    raw: readDropRaw(nativeEvent),
  })
  // The engine committed the drop placeholder; the host adds the real panel.
  engineLayout.value = buildEngineLayout(props.panels)
}

function handleDropDragOver(nativeEvent: DragEvent) {
  if (!isGridDroppable.value) return false

  const raw = readDropRaw(nativeEvent)
  const result = resolvedGrid.value.dropDragOver?.({
    mode: runtimeMode.value,
    nativeEvent,
    raw,
  })

  if (result === false) return false
  if (result) return result

  return resolvedGrid.value.defaultDropSize
}

function emitInteractionEvent(
  type: DashboardLayoutInteractionEvent['type'],
  rawPayload: unknown
) {
  const { item, event } = readGridInteraction(rawPayload)
  if (!item) return

  const gridPos = layoutItemToGridPosition(item)
  if (!gridPos) return

  const panel = props.panels.find(
    (candidate: DashboardPanel) => candidate.id === item.i
  )
  const payload: DashboardLayoutInteractionEvent = {
    type,
    mode: runtimeMode.value,
    source: 'grid',
    panelId: item.i,
    panel,
    gridPos,
    nativeEvent: event,
  }

  if (type === 'drag-start') emit('drag-start', payload)
  else if (type === 'drag-stop') emit('drag-stop', payload)
  else if (type === 'resize-start') emit('resize-start', payload)
  else emit('resize-stop', payload)
}

function layoutItemToGridPosition(
  item: DashboardGridLayoutItem
): DashboardGridPosition | null {
  if (
    !Number.isInteger(item.x) ||
    !Number.isInteger(item.y) ||
    !Number.isInteger(item.w) ||
    !Number.isInteger(item.h) ||
    item.x < 0 ||
    item.y < 0 ||
    item.w <= 0 ||
    item.h <= 0
  ) {
    return null
  }

  return {
    x: item.x,
    y: item.y,
    w: item.w,
    h: item.h,
  }
}

/** Typed dashboard payload first, then JSON, then plain text. */
function readDropRaw(event: DragEvent | undefined): unknown {
  return readDashboardDropPayload(event?.dataTransfer)
}
</script>
