<script lang="ts">
import {
  type Component,
  type DeepReadonly,
  type PropType,
  computed,
  defineComponent,
  h,
  nextTick,
  readonly,
  ref,
  toRaw,
  watch,
} from 'vue'
import ZxDashboardRenderer from '../../runtime/components/dashboard-renderer.vue'
import { createDashboardPanelAction } from '../../runtime/actions'
import {
  compactDashboardGridItemOptions,
  patchDashboardPanelLayoutMetadata,
  readDashboardPanelLayoutMetadata,
} from '../../runtime/grid/panel-layout'
import {
  hasDashboardPanelDragType,
  readDashboardDropTypes,
} from '../../runtime/grid/drag-mime'
import {
  formatDashboardCopy,
  provideDashboardLocale,
  useDashboardLocale,
} from '../../locale'
import {
  createDashboardPanelContentResolver,
  resolveDashboardWidgetGridConstraints,
} from '../../widget'
import { provideDashboardDesignerContext } from '../context/dashboard-designer-context'
import {
  createDashboardDesignerPanel,
  createDefaultDashboardDesignerPanelId,
  resolveDashboardDesignerPanelSize,
} from '../panel-factory'
import { buildDashboardDesignerPalette } from '../palette'
import { useDashboardDesignerPalettePreferences } from '../palette-preferences'
import {
  clonePanels,
  createDashboardDesignerLayoutMutation,
  createDashboardDesignerPanelAddMutation,
  createDashboardDesignerPanelDuplicateMutation,
  createDashboardDesignerPanelPatchMutation,
  createDashboardDesignerPanelRemoveMutation,
} from '../panel-mutations'
import {
  createDashboardDesignerExportRequest,
  createDashboardDesignerSaveRequest,
} from '../validation'
import {
  hasBlockingDashboardDesignerIssues,
  toDashboardDesignerIssue,
} from '../issues'
import {
  endDashboardDesignerDrag,
  parseDashboardDesignerDragPayload,
  readDashboardDesignerActiveDrag,
} from '../drag'
import {
  dashboardLayoutPanelPeers,
  reconcileDashboardLayout,
} from '../../runtime/grid/grouping'
import { createDashboardDesignerHistory } from '../history'
import {
  DASHBOARD_DESIGNER_CAPTURED_KEY_ACTIONS,
  isDashboardEditableKeyTarget,
  resolveDashboardDesignerKeyAction,
} from '../keymap'
import {
  useControlledDashboardDesignerMode,
  useControlledDashboardDesignerSelection,
} from '../state'
import ZxDashboardDesignerDrawer from './dashboard-designer-drawer.vue'
import ZxDashboardDesignerIssues from './dashboard-designer-issues.vue'
import ZxDashboardDesignerPalette from './dashboard-designer-palette.vue'
import ZxDashboardDesignerToolbar from './dashboard-designer-toolbar.vue'

import type {
  DashboardDocument,
  DashboardLayout,
  DashboardPanel,
} from '../../schema'
import type { DashboardLocaleSource } from '../../locale'
import type {
  DashboardChromeVariant,
  DashboardEditorCommandRequestEvent,
  DashboardGridItemOptions,
  DashboardGridOptions,
  DashboardLayoutChangeEvent,
  DashboardPanelActionDefinition,
  DashboardPanelActionEvent,
  DashboardPanelAddRequestEvent,
  DashboardPanelChromeOptions,
  DashboardPanelLayoutMetadata,
  DashboardPanelUpdateRequestEvent,
  DashboardReadonlyDocument,
  DashboardRuntimeIssue,
} from '../../runtime'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetRegistry,
  DashboardWidgetResolverOptions,
  DashboardWidgetVariantDefinition,
} from '../../widget'
import type {
  DashboardDesignerCreatePanelId,
  DashboardDesignerEvent,
  DashboardDesignerEventSource,
  DashboardDesignerHistoryAction,
  DashboardDesignerHistoryChangeEvent,
  DashboardDesignerIssue,
  DashboardDesignerMode,
  DashboardDesignerPaletteItem,
  DashboardDesignerPalettePreferences,
  DashboardDesignerPanelMutationEvent,
} from '../types'

/** Popups own their Escape; the designer only deselects outside them. */
const KEYBOARD_POPUP_SELECTOR = [
  '[role="menu"]',
  '[role="menuitem"]',
  '[role="listbox"]',
  '[role="option"]',
  '[role="dialog"]',
  '[aria-modal="true"]',
].join(', ')

export default defineComponent({
  name: 'ZxDashboardDesigner',
  props: {
    document: Object as PropType<DashboardDocument>,
    panels: Array as PropType<DashboardPanel[]>,
    registry: {
      type: Object as PropType<DashboardWidgetRegistry>,
      required: true,
    },
    mode: String as PropType<DashboardDesignerMode>,
    selectedPanelId: String,
    palettePreferences: Object as PropType<DashboardDesignerPalettePreferences>,
    grid: Object as PropType<DashboardGridOptions>,
    panelChrome: Object as PropType<DashboardPanelChromeOptions>,
    chromeVariant: String as PropType<DashboardChromeVariant>,
    locale: {
      type: [String, Object] as PropType<DashboardLocaleSource>,
      default: undefined,
    },
    createPanelId: Function as PropType<DashboardDesignerCreatePanelId>,
    defaultPanelSize: Object as PropType<
      Pick<DashboardPanel['gridPos'], 'w' | 'h'>
    >,
    showPalette: {
      type: Boolean,
      default: true,
    },
    showDrawer: {
      type: Boolean,
      default: true,
    },
    resolverOptions: Object as PropType<DashboardWidgetResolverOptions>,
    historyLimit: Number,
  },
  emits: [
    'update:panels',
    'update:document',
    'update:layout',
    'update:selectedPanelId',
    'update:mode',
    'update:dirty',
    'update:palettePreferences',
    'history-change',
    'grouping-change',
    'designer-event',
    'designer-issue',
    'panel-add-request',
    'panel-remove-request',
    'panel-duplicate-request',
    'panel-patch-request',
    'layout-change',
    'save-request',
    'export-request',
  ],
  setup(props, { emit, slots, expose }) {
    let lastPublishedDocument: DashboardDocument | undefined
    const rootRef = ref<HTMLElement>()
    const paletteSearch = ref('')
    const palettePreferences = useDashboardDesignerPalettePreferences({
      get value() {
        return props.palettePreferences
      },
      onChange: (value) => emit('update:palettePreferences', value),
    })
    const issues = ref<DashboardDesignerIssue[]>([])
    const lastLayoutSignature = ref<string>()
    const reportedRendererIssueKeys = new Set<string>()
    const parentLocale = useDashboardLocale()
    const locale = provideDashboardLocale(
      () => props.locale ?? parentLocale.value
    )

    const resolvedPanels = computed<DashboardPanel[]>(
      () => props.panels ?? props.document?.panels ?? []
    )
    const readonlyPanels = computed<readonly DeepReadonly<DashboardPanel>[]>(
      () =>
        readonly<object>(
          resolvedPanels.value
        ) as unknown as readonly DeepReadonly<DashboardPanel>[]
    )
    const readonlyDocument = computed<DashboardReadonlyDocument | undefined>(
      () => {
        const document = props.document
        return document
          ? (readonly<object>(document) as DashboardReadonlyDocument)
          : undefined
      }
    )
    const modeState = useControlledDashboardDesignerMode({
      get mode() {
        return props.mode
      },
      onUpdateMode: (mode) => emit('update:mode', mode),
    })
    const selectionState = useControlledDashboardDesignerSelection({
      get selectedPanelId() {
        return props.selectedPanelId
      },
      onUpdateSelectedPanelId: (panelId) =>
        emit('update:selectedPanelId', panelId),
    })
    const isEditMode = computed(() => modeState.mode.value === 'edit')
    const history = createDashboardDesignerHistory({
      current: () => resolvedPanels.value,
      currentLayout: () => props.document?.layout,
      limit: props.historyLimit,
    })
    const paletteGroups = computed(() =>
      buildDashboardDesignerPalette(props.registry)
    )
    const selectedPanel = computed(() =>
      resolvedPanels.value.find(
        (panel: DashboardPanel) =>
          panel.id === selectionState.selectedPanelId.value
      )
    )
    const selectedWidget = computed(() => {
      const panel = selectedPanel.value
      if (!panel) return undefined
      return resolveWidget(panel.widget, panel.variant)
    })
    const resolver = computed(() =>
      createDashboardPanelContentResolver(props.registry, {
        ...(props.resolverOptions ?? {}),
        onIssue: (issue) => {
          props.resolverOptions?.onIssue?.(issue)
          reportRendererIssueOnce(toDashboardDesignerIssue(issue, 'renderer'))
        },
      })
    )
    const mergedGrid = computed<DashboardGridOptions>(() => {
      const edit = isEditMode.value
      const hostGrid = props.grid ?? {}
      return {
        ...hostGrid,
        isDraggable: edit && hostGrid.isDraggable !== false,
        isResizable: edit && hostGrid.isResizable !== false,
        isDroppable: edit && hostGrid.isDroppable !== false,
        defaultDropSize: props.defaultPanelSize ?? hostGrid.defaultDropSize,
        // Widget `minGrid` / `maxGrid` and the panel's own layout metadata
        // become engine bounds; the host hook still has the last word.
        getItemOptions: (panel) => ({
          ...resolveWidgetItemOptions(panel),
          ...compactDashboardGridItemOptions(
            hostGrid.getItemOptions?.(panel) ?? {}
          ),
        }),
        dropDragOver: (event) => {
          const payload = resolveDragPayload(event.raw)
          if (!payload) {
            // Browsers withhold the data during dragover (protected mode); the
            // typed MIME on `types` still proves the drag is a designer one.
            const types = readDashboardDropTypes(
              event.nativeEvent?.dataTransfer
            )
            if (!hasDashboardPanelDragType(types)) return false
            return hostGrid.dropDragOver?.(event) ?? props.defaultPanelSize
          }
          const resolved = resolveWidget(payload.widget, payload.variant)
          if (!resolved?.definition) return false
          return (
            hostGrid.dropDragOver?.(event) ??
            resolveDashboardDesignerPanelSize({
              definition: resolved.definition,
              variant: resolved.variant,
              defaultPanelSize: props.defaultPanelSize,
              columns: hostGrid.columns,
            })
          )
        },
      }
    })
    // Built-in actions follow the host's own list; a host declaration of the
    // same `type` replaces the built-in one. Preview / view keep the view-level
    // actions only (each action filters itself by `visibleIn`).
    const mergedPanelChrome = computed<DashboardPanelChromeOptions>(() => {
      const chrome = props.panelChrome ?? {}
      const hostActions: DashboardPanelActionDefinition[] = chrome.actions ?? []
      const hostTypes = new Set(hostActions.map((action) => action.type))
      const builtinTypes = isEditMode.value
        ? ([
            'maximize',
            'inspect',
            'duplicate',
            'lock',
            'hide',
            'remove',
          ] as const)
        : (['maximize'] as const)
      const builtins = builtinTypes
        .filter((type) => !hostTypes.has(type))
        .map((type) => createDashboardPanelAction(type))

      return {
        ...chrome,
        actions: [...hostActions, ...builtins],
        // A widget with `lockable: false` never offers lock / unlock.
        getPanelActions: (
          panel: DashboardPanel,
          actions: readonly DashboardPanelActionDefinition[]
        ): DashboardPanelActionDefinition[] => {
          const adjusted: DashboardPanelActionDefinition[] =
            chrome.getPanelActions
              ? chrome.getPanelActions(panel, actions)
              : [...actions]
          if (isWidgetLockable(panel)) return adjusted
          return adjusted.filter(
            (action: DashboardPanelActionDefinition) =>
              action.type !== 'lock' && action.type !== 'unlock'
          )
        },
      }
    })

    const context = provideDashboardDesignerContext({
      mode: modeState.mode,
      rendererMode: modeState.rendererMode,
      document: readonlyDocument,
      panels: readonlyPanels,
      registry: props.registry,
      selectedPanelId: selectionState.selectedPanelId,
      selectPanel: (panelId, source = 'designer') =>
        selectPanel(panelId, source),
      requestPanelPatch: (panelId, patch, source = 'editor') =>
        requestPanelPatch(panelId, patch, source),
      requestSave: (command = 'context') => requestSave(command, 'designer'),
      requestExport: (options) => requestExport(options, 'designer'),
      reportDesignerIssue,
      canUndo: history.canUndo,
      canRedo: history.canRedo,
      dirty: history.dirty,
      undo: (source = 'designer') => undo(source),
      redo: (source = 'designer') => redo(source),
      discard: (source = 'designer') => discard(source),
      markSaved,
    })

    watch(history.dirty, (value) => emit('update:dirty', value), {
      immediate: true,
    })
    // A different document (by uid, else by identity) starts a fresh history.
    watch(
      () => props.document?.uid ?? props.document,
      () => {
        if (toRaw(props.document) !== lastPublishedDocument) resetHistory()
      }
    )

    expose({
      undo,
      redo,
      discard,
      markSaved,
      resetHistory,
      canUndo: history.canUndo,
      canRedo: history.canRedo,
      dirty: history.dirty,
    })

    function reportDesignerIssue(issue: DashboardDesignerIssue): void {
      issues.value = [...issues.value, issue]
      emit('designer-issue', issue)
    }

    function selectPanel(
      panelId: string | undefined,
      _source: DashboardDesignerEventSource = 'designer'
    ): void {
      selectionState.selectPanel(panelId)
    }

    function requestPanelPatch(
      panelId: string,
      patch: Partial<Omit<DashboardPanel, 'id'>>,
      source: DashboardDesignerEventSource = 'editor'
    ): void {
      if (!isEditMode.value) {
        reportAuthoringDisabledIssue('panel-patch-request', source, panelId)
        return
      }

      const mutation = createDashboardDesignerPanelPatchMutation({
        panels: resolvedPanels.value,
        panelId,
        patch,
        mode: modeState.mode.value,
        source,
      })
      if (mutation) emitMutation(mutation)
    }

    function handlePaletteAdd(item: DashboardDesignerPaletteItem): void {
      requestPanelAdd(
        {
          widget: item.widget,
          variant: item.variant,
        },
        'palette',
        item.defaultGrid
      )
    }

    function handleRendererPanelAddRequest(
      event: DashboardPanelAddRequestEvent
    ): void {
      const payload = resolveDragPayload(event.raw)
      if (!payload) {
        reportDesignerIssue({
          severity: 'warn',
          code: 'invalid_drag_payload',
          message: locale.value.issues.invalid_drag_payload,
          source: 'grid',
        })
        return
      }
      requestPanelAdd(payload, 'grid', event.gridPos, event.containerId)
      endDashboardDesignerDrag()
    }

    function requestPanelAdd(
      payload: { widget: string; variant?: string },
      source: DashboardDesignerEventSource,
      gridPos?: Partial<DashboardPanel['gridPos']>,
      containerId?: string
    ): void {
      if (!isEditMode.value) {
        reportAuthoringDisabledIssue('panel-add-request', source)
        return
      }

      const resolved = resolveWidget(payload.widget, payload.variant)
      if (!resolved?.definition) {
        reportDesignerIssue({
          severity: 'error',
          code: 'unresolved_widget',
          message: formatDashboardCopy(
            locale.value.issues.unresolved_widget_registry,
            { widget: payload.widget }
          ),
          widget: payload.widget,
          variant: payload.variant,
          source,
        })
        return
      }

      const result = createDashboardDesignerPanel({
        definition: resolved.definition,
        variant: resolved.variant,
        gridPos,
        existingPanels: resolvedPanels.value,
        placementPanels: dashboardLayoutPanelPeers(
          resolvedPanels.value,
          props.document?.layout,
          { containerId }
        ),
        defaultPanelSize: props.defaultPanelSize,
        columns: props.grid?.columns,
        createPanelId: props.createPanelId,
      })

      result.issues.forEach(reportDesignerIssue)
      if (!result.ok || !result.panel) return

      const mutation = createDashboardDesignerPanelAddMutation({
        panels: resolvedPanels.value,
        panel: result.panel,
        mode: modeState.mode.value,
        source,
      })
      emitMutation(mutation, containerId)
      palettePreferences.recordRecent(payload.widget, payload.variant)
      selectPanel(result.panel.id, source)
    }

    function handlePanelAction(event: DashboardPanelActionEvent): void {
      if (!isEditMode.value) return

      if (event.action === 'inspect' || event.action === 'dashboard:inspect') {
        selectPanel(event.panelId, event.source as DashboardDesignerEventSource)
        return
      }

      const layoutPatch = resolveLayoutStatePatch(event.action)
      if (layoutPatch) {
        const panel = resolvedPanels.value.find(
          (candidate: DashboardPanel) => candidate.id === event.panelId
        )
        if (!panel) return
        requestPanelPatch(
          event.panelId,
          { metadata: patchDashboardPanelLayoutMetadata(panel, layoutPatch) },
          event.source as DashboardDesignerEventSource
        )
        return
      }

      if (event.action === 'remove' || event.action === 'dashboard:remove') {
        removePanels([event.panelId], event.source)
        return
      }

      if (
        event.action === 'duplicate' ||
        event.action === 'dashboard:duplicate'
      ) {
        duplicatePanel(event.panelId, event.source)
      }
    }

    /** Removes several panels as one undo step (the engine's multi-select delete). */
    function removePanels(
      panelIds: readonly string[],
      source: DashboardDesignerEventSource
    ): void {
      if (!isEditMode.value) {
        reportAuthoringDisabledIssue('panel-remove-request', source)
        return
      }

      const batch = panelIds.length > 1
      if (batch) history.beginBatch('remove')
      // Props only catch up after the parent re-renders; chain on the last result.
      let panels: readonly DashboardPanel[] = resolvedPanels.value
      for (const panelId of panelIds) {
        const mutation = createDashboardDesignerPanelRemoveMutation({
          panels,
          panelId,
          mode: modeState.mode.value,
          source,
        })
        if (!mutation) continue
        panels = mutation.panels
        emitMutation(mutation)
      }
      if (batch) history.endBatch()
      restoreFocus()

      const selectedId = selectionState.selectedPanelId.value
      if (selectedId && panelIds.includes(selectedId)) {
        selectPanel(undefined, source)
      }
    }

    function duplicatePanel(
      panelId: string,
      source: DashboardDesignerEventSource
    ): void {
      if (!isEditMode.value) {
        reportAuthoringDisabledIssue('panel-duplicate-request', source, panelId)
        return
      }

      const panel = resolvedPanels.value.find(
        (candidate: DashboardPanel) => candidate.id === panelId
      )
      if (!panel) return
      const nextPanelId =
        props.createPanelId?.({
          widget: panel.widget,
          variant: panel.variant,
          existingPanels: resolvedPanels.value,
        }) ??
        createDefaultDashboardDesignerPanelId({
          widget: panel.widget,
          variant: panel.variant,
          existingPanels: resolvedPanels.value,
        })
      const mutation = createDashboardDesignerPanelDuplicateMutation({
        panels: resolvedPanels.value,
        panelId,
        nextPanelId,
        mode: modeState.mode.value,
        source,
        layout: props.document?.layout,
        columns: props.grid?.columns,
        formatCopyTitle: (title) =>
          formatDashboardCopy(locale.value.panel.copySuffix, { title }),
      })
      if (mutation) {
        emitMutation(mutation)
        selectPanel(mutation.panel.id, source)
      }
    }

    /**
     * Engine commands the host owns (see `editor-command-request`). The engine
     * passes the ids it had selected; with none, the designer selection applies.
     */
    function handleEditorCommandRequest(
      event: DashboardEditorCommandRequestEvent
    ): void {
      switch (event.command) {
        case 'delete': {
          const selectedId = selectionState.selectedPanelId.value
          const panelIds =
            event.targetIds.length > 0
              ? event.targetIds
              : selectedId
              ? [selectedId]
              : []
          if (panelIds.length > 0) removePanels(panelIds, 'grid')
          return
        }
        case 'undo':
          undo('grid')
          return
        case 'redo':
          redo('grid')
          return
        case 'discard':
          discard('grid')
          return
        case 'save':
          requestSave('save', 'grid')
      }
    }

    function undo(source: DashboardDesignerEventSource = 'designer'): boolean {
      if (!isEditMode.value) return false
      const entry = history.undo()
      if (!entry) return false
      applyHistoryPanels('undo', entry.before, source, entry.beforeLayout)
      return true
    }

    function redo(source: DashboardDesignerEventSource = 'designer'): boolean {
      if (!isEditMode.value) return false
      const entry = history.redo()
      if (!entry) return false
      applyHistoryPanels('redo', entry.after, source, entry.afterLayout)
      return true
    }

    /** Puts the last saved snapshot back and clears the history. */
    function discard(
      source: DashboardDesignerEventSource = 'designer'
    ): boolean {
      if (!isEditMode.value || !history.dirty.value) return false
      const saved = history.savedPanels()
      const layout = history.savedLayout()
      history.reset(saved, layout)
      applyHistoryPanels('discard', saved, source, layout)
      return true
    }

    function markSaved(
      panels?: readonly DashboardPanel[],
      layout?: DashboardLayout
    ): void {
      if (arguments.length > 1) history.markSaved(panels, layout)
      else history.markSaved(panels)
      emitHistoryChange('saved', 'designer')
    }

    function resetHistory(panels?: readonly DashboardPanel[]): void {
      history.reset(panels)
      emitHistoryChange('reset', 'designer')
    }

    function applyHistoryPanels(
      action: DashboardDesignerHistoryAction,
      panels: readonly DashboardPanel[],
      source: DashboardDesignerEventSource,
      layout?: DashboardLayout
    ): void {
      const previousPanels = clonePanels(resolvedPanels.value)
      const next = clonePanels(panels)
      // The engine echoes the applied layout back; that echo is not a change.
      lastLayoutSignature.value = layoutSignature(next)
      publishDocument(next, layout)

      const selectedId = selectionState.selectedPanelId.value
      if (selectedId && !next.some((panel) => panel.id === selectedId)) {
        selectPanel(undefined, source)
      }
      emitHistoryChange(action, source, {
        panels: next,
        previousPanels,
        layout,
      })
    }

    /**
     * `history-change` always reports the stacks; it joins `designer-event`
     * only when it changes the document (undo / redo / discard), since a push
     * is already represented there by its mutation event.
     */
    function emitHistoryChange(
      action: DashboardDesignerHistoryAction,
      source: DashboardDesignerEventSource,
      detail: {
        panels?: DashboardPanel[]
        previousPanels?: DashboardPanel[]
        current?: readonly DashboardPanel[]
        layout?: DashboardLayout
        previousLayout?: DashboardLayout
      } = {}
    ): void {
      const current = detail.panels ?? detail.current
      const event: DashboardDesignerHistoryChangeEvent = {
        type: 'history-change',
        mode: modeState.mode.value,
        source,
        action,
        canUndo: history.canUndo.value,
        canRedo: history.canRedo.value,
        dirty: current
          ? history.isDirty(current, detail.layout)
          : history.dirty.value,
      }
      if (detail.panels) {
        event.panels = detail.panels
        event.previousPanels = detail.previousPanels
        event.layout = detail.layout
        event.previousLayout = detail.previousLayout
      }
      emit('history-change', event)
      if (detail.panels) emit('designer-event', event)
    }

    function beginGridInteraction(): void {
      history.beginBatch('grid-interaction')
    }

    function endGridInteraction(): void {
      history.endBatch()
    }

    /**
     * Keys the designer claims before the grid engine sees them: history and
     * save (the engine would otherwise run its own geometry-only history), and
     * Escape to deselect (which the engine may also consume).
     */
    function handleRootKeydownCapture(event: KeyboardEvent): void {
      if (!isEditMode.value) return
      const action = resolveDashboardDesignerKeyAction(event)
      // Real keyboard layout mutations must not merge with the previous engine
      // echo, including immediately after load or undo. The engine may stop
      // propagation; close the batch after its synchronous command has flushed.
      if (
        event.target instanceof Element &&
        event.target.closest('.zx-dashboard-grid') &&
        !isDashboardEditableKeyTarget(event.target) &&
        !isKeyboardPopupTarget(event.target) &&
        (event.key.startsWith('Arrow') ||
          action === 'duplicate' ||
          ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'v'))
      ) {
        history.beginBatch('grid-keyboard')
        nextTick(() => history.endBatch())
      }
      if (!action) return
      const editable = isDashboardEditableKeyTarget(event.target)

      if (action === 'deselect') {
        if (
          editable ||
          isKeyboardPopupTarget(event.target) ||
          rootRef.value?.querySelector('.zx-dashboard-panel.is-menu-open')
        )
          return
        if (selectionState.selectedPanelId.value === undefined) return
        selectPanel(undefined, 'keyboard')
        restoreFocus()
        return
      }

      if (!DASHBOARD_DESIGNER_CAPTURED_KEY_ACTIONS.has(action)) return
      // Text inputs keep their own undo / redo; save is global.
      if (action !== 'save' && editable) return
      event.preventDefault()
      event.stopPropagation()
      if (action === 'undo') undo('keyboard')
      else if (action === 'redo') redo('keyboard')
      else if (action === 'duplicate') {
        const panelId = selectionState.selectedPanelId.value
        if (panelId) duplicatePanel(panelId, 'keyboard')
      } else requestSave('save', 'keyboard')
    }

    /**
     * Delete / duplicate for the designer selection when the key was not taken
     * by the grid engine (focus on the toolbar, drawer or the designer itself).
     */
    function handleRootKeydown(event: KeyboardEvent): void {
      if (!isEditMode.value || event.defaultPrevented) return
      if (isDashboardEditableKeyTarget(event.target)) return
      const action = resolveDashboardDesignerKeyAction(event)
      if (action !== 'delete' && action !== 'duplicate') return
      const panelId = selectionState.selectedPanelId.value
      if (!panelId) return

      event.preventDefault()
      if (action === 'delete') removePanels([panelId], 'keyboard')
      else duplicatePanel(panelId, 'keyboard')
      restoreFocus()
    }

    function isKeyboardPopupTarget(target: EventTarget | null): boolean {
      return (
        target instanceof Element &&
        target.closest(KEYBOARD_POPUP_SELECTOR) !== null
      )
    }

    /** Keeps keyboard focus inside the designer when the focused element went away. */
    function restoreFocus(): void {
      nextTick(() => {
        const root = rootRef.value
        const active = globalThis.document?.activeElement
        if (
          !root ||
          (active &&
            active !== globalThis.document.body &&
            root.contains(active))
        ) {
          return
        }
        root.focus({ preventScroll: true })
      })
    }

    function handlePanelUpdateRequest(
      event: DashboardPanelUpdateRequestEvent
    ): void {
      requestPanelPatch(event.panelId, event.patch, event.source)
    }

    function handleRendererPanelsUpdate(
      panels: DashboardPanel[],
      origin?: { containerId: string }
    ): void {
      if (!isEditMode.value) {
        reportAuthoringDisabledIssue('layout-change', 'grid')
        return
      }

      const signature = layoutSignature(panels)
      if (lastLayoutSignature.value === signature) return
      lastLayoutSignature.value = signature
      const mutation = createDashboardDesignerLayoutMutation({
        previousPanels: resolvedPanels.value,
        panels,
        mode: modeState.mode.value,
        source: 'grid',
      })
      emitMutation(mutation, origin?.containerId)
    }

    function handleLayoutChange(event: DashboardLayoutChangeEvent): void {
      if (!isEditMode.value) {
        reportAuthoringDisabledIssue('layout-change', event.source)
        return
      }

      const signature = layoutSignature(event.panels)
      if (lastLayoutSignature.value === signature) return
      lastLayoutSignature.value = signature
      emitMutation({
        type: 'layout-change',
        mode: modeState.mode.value,
        source: event.source,
        previousPanels: clonePanels(resolvedPanels.value),
        panels: clonePanels(event.panels),
        changes: event.changes,
      })
    }

    function handleRuntimeIssue(issue: DashboardRuntimeIssue): void {
      reportRendererIssueOnce(toDashboardDesignerIssue(issue, 'renderer'))
    }

    function requestSave(
      command = 'save',
      source: DashboardDesignerEventSource = 'toolbar'
    ): void {
      const event = createDashboardDesignerSaveRequest({
        document: props.document,
        panels: resolvedPanels.value,
        registry: props.registry,
        mode: modeState.mode.value,
        source,
        command,
      })
      issues.value = event.issues
      emit('save-request', event)
      emit('designer-event', event)
      if (hasBlockingDashboardDesignerIssues(event.issues)) {
        event.issues.forEach((issue) => emit('designer-issue', issue))
      }
    }

    function requestExport(
      options?: Parameters<
        typeof createDashboardDesignerExportRequest
      >[0]['options'],
      source: DashboardDesignerEventSource = 'toolbar'
    ): void {
      const event = createDashboardDesignerExportRequest({
        document: props.document,
        panels: resolvedPanels.value,
        registry: props.registry,
        mode: modeState.mode.value,
        source,
        command: 'export',
        options,
      })
      issues.value = event.issues
      emit('export-request', event)
      emit('designer-event', event)
      if (hasBlockingDashboardDesignerIssues(event.issues)) {
        event.issues.forEach((issue) => emit('designer-issue', issue))
      }
    }

    function publishDocument(
      panels: DashboardPanel[],
      layout?: DashboardLayout
    ): void {
      emit('update:panels', panels)
      emit('update:layout', layout)
      if (props.document) {
        const { layout: _previousLayout, ...base } = props.document
        lastPublishedDocument = {
          ...base,
          panels,
          ...(layout ? { layout } : {}),
        }
        emit('update:document', lastPublishedDocument)
      }
    }

    function handleGroupingUpdate(layout: DashboardLayout): void {
      if (!isEditMode.value) return
      const panels = resolvedPanels.value
      const recorded = history.push({
        type: 'grouping-change',
        source: 'designer',
        before: panels,
        after: panels,
        beforeLayout: props.document?.layout,
        afterLayout: layout,
      })
      const event = {
        type: 'grouping-change' as const,
        mode: modeState.mode.value,
        source: 'designer' as const,
        layout,
        previousLayout: props.document?.layout,
        panels,
      }
      emit('grouping-change', event)
      emit('designer-event', event)
      publishDocument(panels, layout)
      if (recorded)
        emitHistoryChange('push', 'designer', { current: panels, layout })
    }

    function emitMutation(
      event: DashboardDesignerPanelMutationEvent,
      containerId?: string
    ): void {
      const layout = reconcileDashboardLayout(
        props.document?.layout,
        event.panels,
        {
          containerId,
          sourcePanelId:
            event.type === 'panel-duplicate-request'
              ? event.panelId
              : undefined,
        }
      )
      emit(event.type, event)
      emit('designer-event', event as DashboardDesignerEvent)
      publishDocument(event.panels, layout)
      const recorded = history.push({
        type: event.type,
        source: event.source,
        before: event.previousPanels,
        after: event.panels,
        beforeLayout: props.document?.layout,
        afterLayout: layout,
      })
      if (recorded) {
        emitHistoryChange('push', event.source, {
          current: event.panels,
          layout,
        })
      }
    }

    function resolveWidget(
      widget: string,
      variantName?: string
    ):
      | {
          definition: DashboardWidgetDefinition
          variant?: DashboardWidgetVariantDefinition
        }
      | undefined {
      const definition = props.registry.get(widget)
      if (!definition) return undefined
      const variant = variantName
        ? definition.variants?.find(
            (item: DashboardWidgetVariantDefinition) =>
              item.name === variantName
          )
        : undefined
      return {
        definition,
        variant,
      }
    }

    /** Drop data on the event, else the drag the palette started on this page. */
    function resolveDragPayload(raw: unknown) {
      return (
        parseDashboardDesignerDragPayload(raw) ??
        readDashboardDesignerActiveDrag()
      )
    }

    /** `lock` / `unlock` / `hide` / `show` map onto `panel.metadata.layout`. */
    function resolveLayoutStatePatch(
      action: string
    ): DashboardPanelLayoutMetadata | undefined {
      const type = action.startsWith('dashboard:')
        ? action.slice('dashboard:'.length)
        : action
      switch (type) {
        case 'lock':
          return { locked: true }
        case 'unlock':
          return { locked: undefined }
        case 'hide':
          return { hidden: true }
        case 'show':
          return { hidden: undefined }
        default:
          return undefined
      }
    }

    function isWidgetLockable(panel: DashboardPanel): boolean {
      const resolved = resolveWidget(panel.widget, panel.variant)
      return (
        resolved?.variant?.lockable ?? resolved?.definition.lockable ?? true
      )
    }

    /**
     * Engine bounds of one panel: the widget `minGrid` / `maxGrid` and the
     * panel's `metadata.layout` bounds combine, the tighter one winning.
     */
    function resolveWidgetItemOptions(
      panel: DashboardPanel
    ): DashboardGridItemOptions {
      const resolved = resolveWidget(panel.widget, panel.variant)
      const layout = readDashboardPanelLayoutMetadata(panel)
      const { min, max } = resolveDashboardWidgetGridConstraints(
        resolved?.definition,
        resolved?.variant
      )
      return compactDashboardGridItemOptions({
        minW: tighterMin(min.w, layout.minW),
        minH: tighterMin(min.h, layout.minH),
        maxW: tighterMax(max.w, layout.maxW),
        maxH: tighterMax(max.h, layout.maxH),
      })
    }

    function handleCanvasPanelEvent(event: Event): void {
      if (!isEditMode.value) return

      const target = event.target
      if (!(target instanceof HTMLElement)) return
      const panelElement = target.closest<HTMLElement>('[data-panel-id]')
      const panelId = panelElement?.dataset.panelId
      if (panelId) selectPanel(panelId, 'renderer')
    }

    function reportAuthoringDisabledIssue(
      requestType: DashboardDesignerPanelMutationEvent['type'],
      source: DashboardDesignerEventSource,
      panelId?: string
    ): void {
      reportDesignerIssue({
        severity: 'info',
        code: 'authoring_disabled',
        message: formatDashboardCopy(locale.value.issues.authoring_disabled, {
          request: requestType,
          mode: modeState.mode.value,
        }),
        panelId,
        source,
      })
    }

    function reportRendererIssueOnce(issue: DashboardDesignerIssue): void {
      const key = [
        issue.severity,
        issue.code,
        issue.panelId,
        issue.widget,
        issue.variant,
        issue.path,
        issue.message,
      ].join('|')

      if (reportedRendererIssueKeys.has(key)) return
      reportedRendererIssueKeys.add(key)
      scheduleDesignerDiagnostic(() => reportDesignerIssue(issue))
    }

    function tighterMin(a?: number, b?: number): number | undefined {
      if (a === undefined) return b
      if (b === undefined) return a
      return Math.max(a, b)
    }

    function tighterMax(a?: number, b?: number): number | undefined {
      if (a === undefined) return b
      if (b === undefined) return a
      return Math.min(a, b)
    }

    function layoutSignature(panels: readonly DashboardPanel[]): string {
      return panels
        .map(
          (panel) =>
            `${panel.id}:${panel.gridPos.x}:${panel.gridPos.y}:${
              panel.gridPos.w
            }:${panel.gridPos.h}:${JSON.stringify(panel.layouts ?? {})}`
        )
        .join('|')
    }

    return () => {
      const showPalette = props.showPalette !== false && isEditMode.value
      const showDrawer =
        props.showDrawer !== false && isEditMode.value && selectedPanel.value
      const showInspector = Boolean(
        showDrawer || issues.value.length || slots.issues
      )
      const selected = selectedPanel.value
      const selectedResolved = selectedWidget.value
      const readonlySelected = selected
        ? toRuntimeReadonly(selected)
        : undefined
      const readonlyDefinition = selectedResolved?.definition
        ? toRuntimeReadonly(selectedResolved.definition)
        : undefined
      const readonlyVariant = selectedResolved?.variant
        ? toRuntimeReadonly(selectedResolved.variant)
        : undefined
      const selectedEditor = (selectedResolved?.variant?.editor ??
        selectedResolved?.definition.editor) as Component | undefined

      return h(
        'section',
        {
          ref: rootRef,
          class: [
            'zx-dashboard-designer',
            `zx-dashboard-designer--${modeState.mode.value}`,
          ],
          // Programmatic focus target so shortcuts keep working after a
          // focused element (drawer, removed panel) goes away.
          tabindex: -1,
          'data-dashboard-designer-mode': modeState.mode.value,
          'data-dashboard-chrome': props.chromeVariant ?? 'silent',
          'data-zx-surface': 'canvas',
          onKeydownCapture: handleRootKeydownCapture,
          onKeydown: handleRootKeydown,
        },
        [
          h(ZxDashboardDesignerToolbar, {
            mode: modeState.mode.value,
            canUndo: history.canUndo.value,
            canRedo: history.canRedo.value,
            dirty: history.dirty.value,
            'onUpdate:mode': modeState.setMode,
            onUndo: () => undo('toolbar'),
            onRedo: () => redo('toolbar'),
            onDiscard: () => discard('toolbar'),
            onSave: () => requestSave('toolbar', 'toolbar'),
            onExport: () => requestExport({ pretty: true }, 'toolbar'),
          }),
          h(
            'div',
            {
              class: [
                'zx-dashboard-designer__body',
                { 'has-palette': showPalette, 'has-inspector': showInspector },
              ],
            },
            [
              showPalette
                ? h(
                    ZxDashboardDesignerPalette,
                    {
                      groups: paletteGroups.value,
                      search: paletteSearch.value,
                      preferences: palettePreferences.value.value,
                      onToggleFavorite: palettePreferences.toggleFavorite,
                      'onUpdate:search': (value: string) => {
                        paletteSearch.value = value
                      },
                      onAdd: handlePaletteAdd,
                    },
                    {
                      empty: () => slots['palette-empty']?.(),
                    }
                  )
                : null,
              h(
                'main',
                {
                  class: 'zx-dashboard-designer__canvas',
                  onClickCapture: handleCanvasPanelEvent,
                  onFocusin: handleCanvasPanelEvent,
                },
                h(
                  ZxDashboardRenderer,
                  {
                    document: props.document,
                    'onUpdate:layout': handleGroupingUpdate,
                    panels: resolvedPanels.value,
                    mode: modeState.rendererMode.value,
                    grid: mergedGrid.value,
                    panelChrome: mergedPanelChrome.value,
                    chromeVariant: props.chromeVariant,
                    selectedPanelId: selectionState.selectedPanelId.value,
                    resolvePanelContent: resolver.value,
                    'onUpdate:panels': handleRendererPanelsUpdate,
                    onLayoutChange: handleLayoutChange,
                    onDragStart: beginGridInteraction,
                    onDragStop: endGridInteraction,
                    onResizeStart: beginGridInteraction,
                    onResizeStop: endGridInteraction,
                    onPanelAddRequest: handleRendererPanelAddRequest,
                    onPanelAction: handlePanelAction,
                    onPanelUpdateRequest: handlePanelUpdateRequest,
                    onEditorCommandRequest: handleEditorCommandRequest,
                    onRuntimeIssue: handleRuntimeIssue,
                    onWidgetEvent: (event: unknown) =>
                      emit('designer-event', event),
                  },
                  {
                    empty: slots.empty,
                    unresolved: slots.unresolved,
                  }
                )
              ),
              showInspector
                ? h('aside', { class: 'zx-dashboard-designer__inspector' }, [
                    slots.issues
                      ? slots.issues({ issues: issues.value, context })
                      : h(ZxDashboardDesignerIssues, { issues: issues.value }),
                    showDrawer
                      ? slots.drawer
                        ? slots.drawer({
                            panel: readonlySelected,
                            definition: readonlyDefinition,
                            variant: readonlyVariant,
                            context,
                            requestPanelPatch: (
                              patch: Partial<Omit<DashboardPanel, 'id'>>
                            ) =>
                              selected &&
                              requestPanelPatch(selected.id, patch, 'editor'),
                          })
                        : h(
                            ZxDashboardDesignerDrawer,
                            {
                              panel: readonlySelected,
                              definition: readonlyDefinition,
                              variant: readonlyVariant,
                              editor: selectedEditor,
                              requestPanelPatch: (
                                patch: Partial<Omit<DashboardPanel, 'id'>>
                              ) =>
                                requestPanelPatch(
                                  selected!.id,
                                  patch,
                                  'editor'
                                ),
                              onClose: () => selectPanel(undefined, 'drawer'),
                            },
                            {
                              editor: slots.editor,
                              fallback: slots['editor-fallback'],
                            }
                          )
                      : null,
                  ])
                : null,
            ]
          ),
        ]
      )
    }
  },
})

function scheduleDesignerDiagnostic(callback: () => void): void {
  if (typeof globalThis.queueMicrotask === 'function') {
    globalThis.queueMicrotask(callback)
    return
  }

  Promise.resolve().then(callback)
}

function toRuntimeReadonly<T extends object>(value: T): Readonly<T> {
  return readonly(value as Record<string, unknown>) as unknown as Readonly<T>
}
</script>
