import type {
  DASHBOARD_BREAKPOINTS,
  DASHBOARD_SCHEMA_VERSION,
} from './constants'

export type DashboardJsonPrimitive = string | number | boolean | null

export type DashboardJsonValue =
  | DashboardJsonPrimitive
  | DashboardJsonObject
  | DashboardJsonValue[]

export interface DashboardJsonObject {
  [key: string]: DashboardJsonValue
}

export type DashboardReadonlyJsonValue =
  | DashboardJsonPrimitive
  | DashboardReadonlyJsonObject
  | readonly DashboardReadonlyJsonValue[]

export interface DashboardReadonlyJsonObject {
  readonly [key: string]: DashboardReadonlyJsonValue
}

export interface DashboardDocument {
  schemaVersion: typeof DASHBOARD_SCHEMA_VERSION
  uid?: string
  title?: string
  description?: string
  panels: DashboardPanel[]
  layout?: DashboardLayout
  pluginVersions?: Record<string, string>
  references?: DashboardReference[]
  meta?: DashboardJsonObject
}

export interface DashboardPanel {
  id: string
  widget: string
  variant?: string
  title?: string
  description?: string
  gridPos: DashboardGridPosition
  layouts?: Partial<Record<DashboardBreakpoint, DashboardGridPosition>>
  params?: DashboardJsonObject
  data?: DashboardJsonValue
  metadata?: DashboardJsonObject
  references?: string[]
}

export interface DashboardGridPosition {
  x: number
  y: number
  w: number
  h: number
}

export type DashboardBreakpoint = keyof typeof DASHBOARD_BREAKPOINTS

export interface DashboardGridContainer {
  type: 'grid'
  children: string[]
}

export interface DashboardRow {
  id: string
  title: string
  collapsed?: boolean
  children: string[]
}

export interface DashboardRowsContainer {
  type: 'rows'
  children: DashboardRow[]
}

export interface DashboardTab {
  id: string
  title: string
  children: DashboardGridContainer | DashboardRowsContainer
}

/** Tabs can contain grids or rows; recursive grids/tabs are intentionally unsupported. */
export interface DashboardTabsContainer {
  type: 'tabs'
  children: DashboardTab[]
}

export type DashboardLayout =
  | DashboardGridContainer
  | DashboardRowsContainer
  | DashboardTabsContainer

export interface DashboardReference {
  id: string
  type: string
  name: string
  target?: string | DashboardJsonObject
  metadata?: DashboardJsonObject
}
