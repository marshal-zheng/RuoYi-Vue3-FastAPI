import {
  DASHBOARD_DANGEROUS_KEYS,
  DASHBOARD_GRID_POSITION_FIELDS,
} from './constants'

import type { DashboardGridPosition, DashboardJsonObject } from './types'
import type { DashboardSchemaIssue } from '../validation/issues'

export interface DashboardJsonValidationOptions {
  phase?: 'authoring' | 'import' | 'export'
}

export interface DashboardGridPositionGuardResult {
  value?: DashboardGridPosition
  issues: DashboardSchemaIssue[]
}

export function isDashboardPlainObject(
  value: unknown
): value is Record<string, unknown> {
  if (Object.prototype.toString.call(value) !== '[object Object]') {
    return false
  }

  const prototype = Object.getPrototypeOf(value)
  return prototype === Object.prototype || prototype === null
}

export function isDashboardJsonObject(
  value: unknown
): value is DashboardJsonObject {
  return isDashboardPlainObject(value)
}

export function cloneDashboardJson<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

export function joinDashboardJsonPointer(
  basePath: string,
  segment: string | number
): string {
  const normalizedBase = basePath === '/' ? '' : basePath
  const escaped = String(segment).replace(/~/g, '~0').replace(/\//g, '~1')
  return `${normalizedBase}/${escaped}`
}

export function hasDashboardDangerousKey(key: string): boolean {
  return (DASHBOARD_DANGEROUS_KEYS as readonly string[]).includes(key)
}

export function isDashboardImportLikeWidgetKey(value: string): boolean {
  const widget = value.trim()

  if (!widget) return false

  return (
    widget.endsWith('.vue') ||
    /\.vue([?#].*)?$/i.test(widget) ||
    widget.startsWith('./') ||
    widget.startsWith('../') ||
    widget.startsWith('/') ||
    widget.startsWith('@/') ||
    widget.includes('\\') ||
    widget.includes('/') ||
    widget.includes('**') ||
    widget.includes('*') ||
    /^import\s*\(/.test(widget) ||
    widget.includes('import.meta.glob') ||
    /^[a-z][a-z0-9+.-]*:\/\//i.test(widget) ||
    /^[a-z][a-z0-9+.-]*:/i.test(widget)
  )
}

export function collectDashboardJsonIssues(
  value: unknown,
  path = '',
  options: DashboardJsonValidationOptions = {},
  seen = new WeakSet<object>()
): DashboardSchemaIssue[] {
  const issues: DashboardSchemaIssue[] = []
  const normalizedPath = path || ''
  const phase = options.phase ?? 'authoring'
  const dangerousKeySeverity = phase === 'authoring' ? 'warn' : 'error'

  if (
    value === null ||
    typeof value === 'string' ||
    typeof value === 'boolean'
  ) {
    return issues
  }

  if (typeof value === 'number') {
    if (!Number.isFinite(value)) {
      issues.push({
        severity: 'error',
        code: 'non_serializable_value',
        message: 'JSON number values must be finite.',
        path: normalizedPath,
      })
    }
    return issues
  }

  if (typeof value === 'bigint' || typeof value === 'symbol') {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: `${typeof value} values cannot be represented in dashboard JSON.`,
      path: normalizedPath,
    })
    return issues
  }

  if (typeof value === 'function') {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: 'Functions cannot be persisted in dashboard JSON.',
      path: normalizedPath,
    })
    return issues
  }

  if (typeof value !== 'object') {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: 'Only JSON primitives, arrays, and plain objects are supported.',
      path: normalizedPath,
    })
    return issues
  }

  if (isDashboardDomNode(value)) {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: 'DOM nodes cannot be persisted in dashboard JSON.',
      path: normalizedPath,
    })
    return issues
  }

  if (seen.has(value)) {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: 'Circular references cannot be persisted in dashboard JSON.',
      path: normalizedPath,
    })
    return issues
  }
  seen.add(value)

  if (Array.isArray(value)) {
    value.forEach((item, index) => {
      issues.push(
        ...collectDashboardJsonIssues(
          item,
          joinDashboardJsonPointer(normalizedPath, index),
          options,
          seen
        )
      )
    })
    seen.delete(value)
    return issues
  }

  if (!isDashboardPlainObject(value)) {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message:
        'Class instances and objects with custom prototypes cannot be persisted in dashboard JSON.',
      path: normalizedPath,
    })
    return issues
  }

  if (isDashboardVueComponentLike(value)) {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message:
        'Vue component definitions cannot be persisted in dashboard JSON.',
      path: normalizedPath,
    })
  }

  for (const key of Object.getOwnPropertyNames(value)) {
    const childPath = joinDashboardJsonPointer(normalizedPath, key)
    if (hasDashboardDangerousKey(key)) {
      issues.push({
        severity: dangerousKeySeverity,
        code: 'dangerous_key',
        message: `Key "${key}" is not allowed in dashboard JSON.`,
        path: childPath,
        suggestion: 'Move extension data under a safe metadata key.',
      })
    }

    issues.push(
      ...collectDashboardJsonIssues(
        (value as Record<string, unknown>)[key],
        childPath,
        options,
        seen
      )
    )
  }

  seen.delete(value)
  return issues
}

export function validateDashboardGridPositionInput(
  input: unknown,
  path: string
): DashboardGridPositionGuardResult {
  const issues: DashboardSchemaIssue[] = []

  if (!isDashboardPlainObject(input)) {
    return {
      issues: [
        {
          severity: 'error',
          code: 'invalid_grid_position',
          message: 'gridPos must be a plain object with x, y, w, and h.',
          path,
        },
      ],
    }
  }

  for (const field of DASHBOARD_GRID_POSITION_FIELDS) {
    const value = input[field]
    const valid =
      typeof value === 'number' &&
      Number.isInteger(value) &&
      (field === 'x' || field === 'y' ? value >= 0 : value > 0)

    if (!valid) {
      issues.push({
        severity: 'error',
        code: 'invalid_grid_position',
        message:
          field === 'x' || field === 'y'
            ? `${field} must be a non-negative integer.`
            : `${field} must be a positive integer.`,
        path: joinDashboardJsonPointer(path, field),
      })
    }
  }

  for (const key of Object.keys(input)) {
    if (!(DASHBOARD_GRID_POSITION_FIELDS as readonly string[]).includes(key)) {
      issues.push({
        severity: 'error',
        code: 'invalid_grid_position',
        message: `gridPos cannot include layout-engine field "${key}".`,
        path: joinDashboardJsonPointer(path, key),
        suggestion: 'Move layout-engine private data into runtime metadata.',
      })
    }
  }

  if (issues.length > 0) {
    return { issues }
  }

  return {
    value: {
      x: input.x as number,
      y: input.y as number,
      w: input.w as number,
      h: input.h as number,
    },
    issues,
  }
}

function isDashboardDomNode(value: object): boolean {
  if (typeof Node !== 'undefined' && value instanceof Node) return true

  return (
    'nodeType' in value &&
    typeof (value as { nodeType?: unknown }).nodeType === 'number' &&
    'nodeName' in value &&
    typeof (value as { nodeName?: unknown }).nodeName === 'string'
  )
}

function isDashboardVueComponentLike(value: Record<string, unknown>): boolean {
  return (
    '__vccOpts' in value ||
    '__asyncLoader' in value ||
    '__v_isVNode' in value ||
    (typeof value.template === 'string' &&
      ('setup' in value ||
        'render' in value ||
        'props' in value ||
        'emits' in value))
  )
}
