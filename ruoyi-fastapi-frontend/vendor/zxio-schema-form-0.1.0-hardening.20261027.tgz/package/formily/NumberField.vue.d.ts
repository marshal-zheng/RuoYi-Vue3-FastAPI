import { FieldEditState, FieldMessage } from '../fields/types';
import { Json } from '../types';
type __VLS_Props = {
    modelValue?: number | null;
    disabled?: boolean;
    readonly?: boolean;
    min?: number;
    max?: number;
    step?: number;
    precision?: number;
    stepStrictly?: boolean;
    disabledScientific?: boolean;
    controls?: boolean;
    controlsPosition?: '' | 'right';
    messages?: readonly FieldMessage[];
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit: () => {
        text: string;
        composition: string[];
    };
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    blur: (value: FocusEvent) => any;
    focus: (value: FocusEvent) => any;
    "update:modelValue": (value: number | null) => any;
    "edit-state": (state: FieldEditState) => any;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: number | null) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    step: number;
    controls: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    input: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            id: string;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            min: number;
            max: number;
            tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
            readonly: boolean;
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
            step: number;
            stepStrictly: boolean;
            controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
            align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
            disabledScientific: boolean;
        }> & Omit<{
            readonly min: number;
            readonly max: number;
            readonly tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly readonly: boolean;
            readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
            readonly step: number;
            readonly stepStrictly: boolean;
            readonly controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
            readonly align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
            readonly disabledScientific: boolean;
            readonly name?: string | undefined;
            readonly size?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never> | undefined;
            readonly id?: string | undefined;
            readonly text?: string | undefined;
            readonly placeholder?: string | undefined;
            readonly disabled?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
            readonly inputmode?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
            readonly ariaLabel?: string | undefined;
            readonly modelValue?: number | null | undefined;
            readonly precision?: number | undefined;
            readonly onBlur?: ((e: FocusEvent) => any) | undefined;
            readonly onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
            readonly onFocus?: ((e: FocusEvent) => any) | undefined;
            readonly onInput?: ((val: number | null | undefined) => any) | undefined;
            readonly "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
            readonly "onUpdate:text"?: ((value: string) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific">;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        } & {
            componentRef: ({
                $: import('vue').ComponentInternalInstance;
                $data: {};
                $props: Partial<{
                    id: string;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    min: number;
                    max: number;
                    tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly: boolean;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                    step: number;
                    stepStrictly: boolean;
                    controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                    align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                    disabledScientific: boolean;
                    nativeAttrs: Record<string, unknown>;
                }> & Omit<{
                    readonly min: number;
                    readonly max: number;
                    readonly tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly readonly: boolean;
                    readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                    readonly step: number;
                    readonly stepStrictly: boolean;
                    readonly controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                    readonly align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                    readonly disabledScientific: boolean;
                    readonly nativeAttrs: Record<string, unknown>;
                    readonly name?: string | undefined;
                    readonly size?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never> | undefined;
                    readonly id?: string | undefined;
                    readonly text?: string | undefined;
                    readonly placeholder?: string | undefined;
                    readonly disabled?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
                    readonly inputmode?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly ariaLabel?: string | undefined;
                    readonly modelValue?: number | null | undefined;
                    readonly precision?: number | undefined;
                    readonly onBlur?: ((e: FocusEvent) => any) | undefined;
                    readonly onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                    readonly onFocus?: ((e: FocusEvent) => any) | undefined;
                    readonly onInput?: ((val: number | null | undefined) => any) | undefined;
                    readonly "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                    readonly "onUpdate:text"?: ((value: string) => any) | undefined;
                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific" | "nativeAttrs">;
                $attrs: import('vue').Attrs;
                $refs: {
                    [x: string]: unknown;
                } & {
                    input: ({
                        $: import('vue').ComponentInternalInstance;
                        $data: {};
                        $props: {
                            readonly id?: string | undefined;
                            readonly size?: import('element-plus').ComponentSize | undefined;
                            readonly disabled?: boolean | undefined;
                            readonly modelValue?: string | number | null | undefined;
                            readonly modelModifiers?: import('element-plus').InputModelModifiers | undefined;
                            readonly maxlength?: (string | number) | undefined;
                            readonly minlength?: (string | number) | undefined;
                            readonly type?: import('element-plus').InputType | undefined;
                            readonly resize?: ("none" | "both" | "horizontal" | "vertical") | undefined;
                            readonly autosize?: import('element-plus').InputAutoSize | undefined;
                            readonly autocomplete?: string | undefined;
                            readonly formatter?: ((value: string) => string) | undefined;
                            readonly parser?: ((value: string) => string) | undefined;
                            readonly placeholder?: string | undefined;
                            readonly form?: string | undefined;
                            readonly readonly?: boolean | undefined;
                            readonly clearable?: boolean | undefined;
                            readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                            readonly showPassword?: boolean | undefined;
                            readonly showWordLimit?: boolean | undefined;
                            readonly wordLimitPosition?: ("inside" | "outside") | undefined;
                            readonly suffixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                            readonly prefixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                            readonly containerRole?: string | undefined;
                            readonly tabindex?: (string | number) | undefined;
                            readonly validateEvent?: boolean | undefined;
                            readonly inputStyle?: import('vue').StyleValue;
                            readonly autofocus?: boolean | undefined;
                            readonly rows?: number | undefined;
                            readonly ariaLabel?: string | undefined;
                            readonly inputmode?: import('vue').HTMLAttributes["inputmode"];
                            readonly name?: string | undefined;
                            readonly countGraphemes?: ((value: string) => number) | undefined;
                            readonly onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                            readonly "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                            readonly onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                            readonly onInput?: ((value: string) => any) | undefined;
                            readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                            readonly onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                            readonly onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                            readonly onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                            readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                            readonly onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                            readonly onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                            readonly onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
                        $attrs: import('vue').Attrs;
                        $refs: {
                            [x: string]: unknown;
                        };
                        $slots: Readonly<{
                            [name: string]: import('vue').Slot<any> | undefined;
                        }>;
                        $root: import('vue').ComponentPublicInstance | null;
                        $parent: import('vue').ComponentPublicInstance | null;
                        $host: Element | null;
                        $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: string, evt?: Event | undefined) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "input", value: string) => void) & ((event: "keydown", evt: Event | KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear", evt: MouseEvent | undefined) => void) & ((event: "update:modelValue", value: string) => void);
                        $el: any;
                        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').InputProps> & Readonly<{
                            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                            onInput?: ((value: string) => any) | undefined;
                            onBlur?: ((evt: FocusEvent) => any) | undefined;
                            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                            onFocus?: ((evt: FocusEvent) => any) | undefined;
                            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                        }>, {
                            input: import('vue').ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
                            textarea: import('vue').ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
                            ref: import('vue').ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
                            textareaStyle: import('vue').ComputedRef<import('vue').StyleValue>;
                            autosize: import('vue').Ref<import('element-plus').InputAutoSize | undefined, import('element-plus').InputAutoSize | undefined>;
                            isComposing: import('vue').Ref<boolean, boolean>;
                            passwordVisible: import('vue').Ref<boolean, boolean>;
                            focus: () => void | undefined;
                            blur: () => void | undefined;
                            select: () => void;
                            clear: (evt?: MouseEvent) => void;
                            resizeTextarea: () => void;
                        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                            clear: (evt: MouseEvent | undefined) => void;
                            "update:modelValue": (value: string) => void;
                            change: (value: string, evt?: Event | undefined) => void;
                            input: (value: string) => void;
                            blur: (evt: FocusEvent) => void;
                            compositionend: (evt: CompositionEvent) => void;
                            compositionstart: (evt: CompositionEvent) => void;
                            compositionupdate: (evt: CompositionEvent) => void;
                            focus: (evt: FocusEvent) => void;
                            keydown: (evt: Event | KeyboardEvent) => void;
                            mouseenter: (evt: MouseEvent) => void;
                            mouseleave: (evt: MouseEvent) => void;
                        }, string, {
                            type: import('element-plus').InputType;
                            disabled: boolean;
                            modelValue: string | number | null;
                            validateEvent: boolean;
                            modelModifiers: import('element-plus').InputModelModifiers;
                            autocomplete: string;
                            clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                            wordLimitPosition: "inside" | "outside";
                            tabindex: string | number;
                            inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                            rows: number;
                        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                            beforeCreate?: (() => void) | (() => void)[];
                            created?: (() => void) | (() => void)[];
                            beforeMount?: (() => void) | (() => void)[];
                            mounted?: (() => void) | (() => void)[];
                            beforeUpdate?: (() => void) | (() => void)[];
                            updated?: (() => void) | (() => void)[];
                            activated?: (() => void) | (() => void)[];
                            deactivated?: (() => void) | (() => void)[];
                            beforeDestroy?: (() => void) | (() => void)[];
                            beforeUnmount?: (() => void) | (() => void)[];
                            destroyed?: (() => void) | (() => void)[];
                            unmounted?: (() => void) | (() => void)[];
                            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                        };
                        $forceUpdate: () => void;
                        $nextTick: typeof import('vue').nextTick;
                        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
                    } & Readonly<{
                        type: import('element-plus').InputType;
                        disabled: boolean;
                        modelValue: string | number | null;
                        validateEvent: boolean;
                        modelModifiers: import('element-plus').InputModelModifiers;
                        autocomplete: string;
                        clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                        wordLimitPosition: "inside" | "outside";
                        tabindex: string | number;
                        inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                        rows: number;
                    }> & Omit<Readonly<import('element-plus').InputProps> & Readonly<{
                        onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                        onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                        onInput?: ((value: string) => any) | undefined;
                        onBlur?: ((evt: FocusEvent) => any) | undefined;
                        onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                        onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                        onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                        onFocus?: ((evt: FocusEvent) => any) | undefined;
                        onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                        onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                        onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                    }>, "blur" | "focus" | "input" | "select" | "type" | "clear" | "textarea" | "ref" | "disabled" | "tabindex" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "clearIcon" | "wordLimitPosition" | "validateEvent" | "inputStyle" | "rows" | "textareaStyle" | "isComposing" | "passwordVisible" | "resizeTextarea"> & {
                        input: HTMLInputElement | undefined;
                        textarea: HTMLTextAreaElement | undefined;
                        ref: HTMLInputElement | HTMLTextAreaElement | undefined;
                        textareaStyle: import('vue').StyleValue;
                        autosize: import('element-plus').InputAutoSize | undefined;
                        isComposing: boolean;
                        passwordVisible: boolean;
                        focus: () => void | undefined;
                        blur: () => void | undefined;
                        select: () => void;
                        clear: (evt?: MouseEvent) => void;
                        resizeTextarea: () => void;
                    } & {} & import('vue').ComponentCustomProperties & {} & {
                        $slots: {
                            prepend?: (props: {}) => any;
                        } & {
                            prefix?: (props: {}) => any;
                        } & {
                            suffix?: (props: {}) => any;
                        } & {
                            'password-icon'?: (props: {
                                visible: boolean;
                            }) => any;
                        } & {
                            append?: (props: {}) => any;
                        };
                    }) | null;
                };
                $slots: Readonly<{
                    [name: string]: import('vue').Slot<any> | undefined;
                }>;
                $root: import('vue').ComponentPublicInstance | null;
                $parent: import('vue').ComponentPublicInstance | null;
                $host: Element | null;
                $emit: ((event: "blur", e: FocusEvent) => void) & ((event: "change", value: number | null | undefined, oldValue: number | null | undefined) => void) & ((event: "focus", e: FocusEvent) => void) & ((event: "input", val: number | null | undefined) => void) & ((event: "update:modelValue", value: number | null | undefined) => void) & ((event: "update:text", value: string) => void);
                $el: any;
                $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
                    nativeAttrs: {
                        type: import('vue').PropType<Record<string, unknown>>;
                        default: () => {};
                    };
                    tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "", boolean>;
                    tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "right", boolean>;
                    tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "hover", boolean>;
                    id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                    step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
                    stepStrictly: BooleanConstructor;
                    max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                    min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                    readonly: BooleanConstructor;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                    size: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
                    valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
                    name: StringConstructor;
                    placeholder: StringConstructor;
                    precision: {
                        readonly type: import('vue').PropType<number>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    ariaLabel: StringConstructor;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
                    align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
                    disabledScientific: BooleanConstructor;
                    modelValue: {
                        type: import('vue').PropType<number | null>;
                        required: false;
                        validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    text: StringConstructor;
                }>> & Readonly<{
                    onBlur?: ((e: FocusEvent) => any) | undefined;
                    onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                    onFocus?: ((e: FocusEvent) => any) | undefined;
                    onInput?: ((val: number | null | undefined) => any) | undefined;
                    "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                    "onUpdate:text"?: ((value: string) => any) | undefined;
                }>, {
                    focus: () => void | undefined;
                    blur: () => void | undefined;
                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                    blur: (e: FocusEvent) => void;
                    change: (value: number | null | undefined, oldValue: number | null | undefined) => void;
                    focus: (e: FocusEvent) => void;
                    input: (val: number | null | undefined) => void;
                    "update:modelValue": (value: number | null | undefined) => void;
                    "update:text": (value: string) => void;
                }, string, {
                    id: string;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    min: number;
                    max: number;
                    tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly: boolean;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                    step: number;
                    stepStrictly: boolean;
                    controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                    align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                    disabledScientific: boolean;
                    nativeAttrs: Record<string, unknown>;
                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import('vue').nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
            } & Readonly<{
                id: string;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                min: number;
                max: number;
                tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                readonly: boolean;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                step: number;
                stepStrictly: boolean;
                controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                disabledScientific: boolean;
                nativeAttrs: Record<string, unknown>;
            }> & Omit<Readonly<import('vue').ExtractPropTypes<{
                nativeAttrs: {
                    type: import('vue').PropType<Record<string, unknown>>;
                    default: () => {};
                };
                tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "", boolean>;
                tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "right", boolean>;
                tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "hover", boolean>;
                id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
                stepStrictly: BooleanConstructor;
                max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                readonly: BooleanConstructor;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
                name: StringConstructor;
                placeholder: StringConstructor;
                precision: {
                    readonly type: import('vue').PropType<number>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                ariaLabel: StringConstructor;
                inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
                align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
                disabledScientific: BooleanConstructor;
                modelValue: {
                    type: import('vue').PropType<number | null>;
                    required: false;
                    validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                text: StringConstructor;
            }>> & Readonly<{
                onBlur?: ((e: FocusEvent) => any) | undefined;
                onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                onFocus?: ((e: FocusEvent) => any) | undefined;
                onInput?: ((val: number | null | undefined) => any) | undefined;
                "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                "onUpdate:text"?: ((value: string) => any) | undefined;
            }>, "blur" | "focus" | ("id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific" | "nativeAttrs")> & {
                focus: () => void | undefined;
                blur: () => void | undefined;
            } & {} & import('vue').ComponentCustomProperties & {} & {
                $slots: Readonly<{
                    prefix?(props?: Record<string, unknown>): unknown;
                    suffix?(props?: Record<string, unknown>): unknown;
                    'increase-icon'?(props?: Record<string, unknown>): unknown;
                    'decrease-icon'?(props?: Record<string, unknown>): unknown;
                }> & {
                    prefix?(props?: Record<string, unknown>): unknown;
                    suffix?(props?: Record<string, unknown>): unknown;
                    'increase-icon'?(props?: Record<string, unknown>): unknown;
                    'decrease-icon'?(props?: Record<string, unknown>): unknown;
                };
            }) | null;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "blur", e: FocusEvent) => void) & ((event: "change", value: number | null | undefined, oldValue: number | null | undefined) => void) & ((event: "focus", e: FocusEvent) => void) & ((event: "input", val: number | null | undefined) => void) & ((event: "update:modelValue", value: number | null | undefined) => void) & ((event: "update:text", value: string) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
            tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "", boolean>;
            tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "right", boolean>;
            tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "hover", boolean>;
            id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
            stepStrictly: BooleanConstructor;
            max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            readonly: BooleanConstructor;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            size: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
            name: StringConstructor;
            placeholder: StringConstructor;
            precision: {
                readonly type: import('vue').PropType<number>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            ariaLabel: StringConstructor;
            inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
            align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
            disabledScientific: BooleanConstructor;
            modelValue: {
                type: import('vue').PropType<number | null>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            text: StringConstructor;
        }>> & Readonly<{
            onBlur?: ((e: FocusEvent) => any) | undefined;
            onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
            onFocus?: ((e: FocusEvent) => any) | undefined;
            onInput?: ((val: number | null | undefined) => any) | undefined;
            "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
            "onUpdate:text"?: ((value: string) => any) | undefined;
        }>, {
            focus: () => void | undefined;
            blur: () => void | undefined;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            blur: (e: FocusEvent) => void;
            change: (value: number | null | undefined, oldValue: number | null | undefined) => void;
            focus: (e: FocusEvent) => void;
            input: (val: number | null | undefined) => void;
            "update:modelValue": (value: number | null | undefined) => void;
            "update:text": (value: string) => void;
        }, string, {
            id: string;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            min: number;
            max: number;
            tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                (): string | import('@zxio/components/input').InputTooltipConfig;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                (): import('@zxio/utils/dist/es').Placement;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                (): import('@zxio/components/input').InputTooltipTrigger;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
            readonly: boolean;
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
            step: number;
            stepStrictly: boolean;
            controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
            align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
            disabledScientific: boolean;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        id: string;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        min: number;
        max: number;
        tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
            (): string | import('@zxio/components/input').InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
            (): string | import('@zxio/components/input').InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
            (): import('@zxio/utils/dist/es').Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
            (): import('@zxio/utils/dist/es').Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
            (): import('@zxio/components/input').InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
            (): import('@zxio/components/input').InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
        readonly: boolean;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
        step: number;
        stepStrictly: boolean;
        controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
        align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
        disabledScientific: boolean;
    }> & Omit<Readonly<import('vue').ExtractPropTypes<{
        tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
            (): string | import('@zxio/components/input').InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
            (): string | import('@zxio/components/input').InputTooltipConfig;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
            (): import('@zxio/utils/dist/es').Placement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
            (): import('@zxio/utils/dist/es').Placement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "right", boolean>;
        tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
            (): import('@zxio/components/input').InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
            (): import('@zxio/components/input').InputTooltipTrigger;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "hover", boolean>;
        id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
        stepStrictly: BooleanConstructor;
        max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        readonly: BooleanConstructor;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
        name: StringConstructor;
        placeholder: StringConstructor;
        precision: {
            readonly type: import('vue').PropType<number>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        ariaLabel: StringConstructor;
        inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
        align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
        disabledScientific: BooleanConstructor;
        modelValue: {
            type: import('vue').PropType<number | null>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        text: StringConstructor;
    }>> & Readonly<{
        onBlur?: ((e: FocusEvent) => any) | undefined;
        onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
        onFocus?: ((e: FocusEvent) => any) | undefined;
        onInput?: ((val: number | null | undefined) => any) | undefined;
        "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
        "onUpdate:text"?: ((value: string) => any) | undefined;
    }>, "blur" | "focus" | ("id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific")> & {
        focus: () => void | undefined;
        blur: () => void | undefined;
    } & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: Readonly<{
            prefix?(props: Record<string, unknown>): unknown;
            suffix?(props: Record<string, unknown>): unknown;
            'increase-icon'?(props: Record<string, unknown>): unknown;
            'decrease-icon'?(props: Record<string, unknown>): unknown;
        }> & {
            prefix?(props: Record<string, unknown>): unknown;
            suffix?(props: Record<string, unknown>): unknown;
            'increase-icon'?(props: Record<string, unknown>): unknown;
            'decrease-icon'?(props: Record<string, unknown>): unknown;
        };
    }) | null;
}, any>;
export default _default;
