# @zxio/theme-compiler

Deterministic, filesystem-free compilation of validated ZXIO Theme v4 sources.
Core compilation uses the public `@zxio/tokens/kernel` entrypoint. Business
extensions use `@zxio/tokens/extensions` and the shared CSS codec. Filesystem
writes are available solely through explicit writer APIs.

## Vite theme delivery

`@zxio/theme-compiler/vite` exports `themeDeploymentPlugin` for Vite 5 and 6.
Install this package as a development dependency and declare your theme packages
in the application. Share one theme catalog between this plugin and the Host:

```ts
import { defineConfig } from 'vite'
import { themeDeploymentPlugin } from '@zxio/theme-compiler/vite'

export default defineConfig({
  plugins: [
    themeDeploymentPlugin({
      packages: [{ packageName: '@zxio/theme-default', themeId: 'default' }],
    }),
  ],
})
```

Import `virtual:zxui-theme-deployment` in the application. Its default export is
`ThemeDeploymentOutput` from `@zxio/theme-compiler/deployment`, containing
`registrations` and `deployment`. Declare that virtual module with the public
type in an ambient `.d.ts` file. Pass registrations to the Host and deployment
to `createThemeDeploymentResolver`, with `new URL(import.meta.env.BASE_URL,
document.baseURI).href` as `baseURL`. Import `@zxio/zxui/style` separately.

Options `virtualId`, `assetDirectory`, and `resolveFrom` override the virtual
module name, application-relative output directory, and package resolution
anchor. `workspaceRoot` explicitly selects a local ZXUI checkout's theme
packages; it does not configure component source aliases or compile themes.
All manifest/CSS reads still resolve public package exports. A `themeId`
assertion rejects a mismatched application catalog before assets are published.

Development serves original CSS bytes ahead of Vite transforms, watches public
manifest updates and atomic directory replacements, and retains the last valid
map/assets on failure. Production emits verified assets into Vite's bundle.
Each plugin instance owns a temporary directory; it does not write application
`public/`. Server shutdown (including middleware mode) closes native watchers.
The virtual module uses lossless string, object-shape and digest interning. It
restores the same `ThemeDeploymentOutput` without an external decoder; CSS
bytes, hashes and SRI do not change. Specialized pipelines can share
`themeDataModule` from `@zxio/theme-compiler/deployment` (also exported by `/vite`).
Remove a previous integration's owned public theme assets when migrating; stale
public files are otherwise still copied by Vite. The plugin does not delete
files owned by the application. Package export-map changes require a server
restart, as with ordinary Node package resolution.

`resolveThemeAssetRequest` shares base-path and filesystem-boundary handling
with specialized integrations such as the docs SSR/catalog pipeline. It only
returns public CSS/JSON files within the selected output directory.

## Local component source integration

Combine the separate public source resolver with theme asset delivery:

```ts
import {
  themeDeploymentPlugin,
  zxuiSourcePlugin,
} from '@zxio/theme-compiler/vite'

const workspaceRoot = '/absolute/path/to/zxui'
const plugins = [
  zxuiSourcePlugin({ workspaceRoot }),
  themeDeploymentPlugin({ workspaceRoot, packages: themePackages }),
]
```

Prepare the checkout with `bash setup.sh` and `pnpm build:theme`. The source
plugin resolves exact public component/style exports and owns internal aliases,
Vue deduplication, dependency optimization exclusions and dev-server filesystem
access. Independent features such as chart continue using installed packages.
The root structural-style entries resolve to their owning `theme-chalk/src/structural.css`,
so edits hot reload without updating the generated mirror. Applications own only
the environment switch and absolute checkout path. Disable
the source plugin to restore installed-package resolution; verify both builds.
Restart Vite after export-map changes and explicitly compile changed theme seeds.
The plugin neither installs dependencies nor generates themes.

`@zxio/theme-compiler/extensions` exports `compileThemeExtensions({ package,
modules, coreContract, dependencies?, cssAdapters? })`. It returns an immutable
`{ manifest, files }` bundle with one theme-neutral CSS file, ESM/CJS token refs
and TypeScript declarations. The default encoder is `themeExtensionCssEncoder`.
Dependency manifests must be supplied explicitly during compilation and Host
registration; generated manifests contain exact dependency locks.

`writeThemeExtensionBundle({ directory, bundle, dependencies? })` writes a new
release directory atomically. Repeating the same release is a no-op. Existing
modified or unrelated output is preserved and rejected; use a new versioned
release directory for changed output. Generated `refs.d.ts` should be exposed
by the business package's `exports.types` alongside `refs.mjs` and `refs.cjs`.

Adapter ranges support exact versions, `^`, `~`, comparator sets, `||` and `*`.
Prereleases require an explicit prerelease comparator for the same version.
No adapter is required for ordinary business tokens. Optional CSS adapters map
public scalar token refs to an explicit third-party custom-property prefix and
only match an explicitly bound target whose required modules are enabled.

### Editing the Vite tooling in the same checkout

The ordinary `/vite` entry uses published JavaScript. To also run the compiler
plugin source during linked development, use the explicit `/vite/source` facet
with the checkout's `tsx` loader. No global loader or private source path is needed:

```ts
import { createRequire } from 'node:module'
import { resolve } from 'node:path'

const requireCheckout = createRequire(resolve(workspaceRoot, 'package.json'))
const { require: requireSource } = requireCheckout('tsx/cjs/api')
const { themeDeploymentPlugin, zxuiSourcePlugin } = requireSource(
  '@zxio/theme-compiler/vite/source',
  requireCheckout.resolve('@zxio/theme-compiler/package.json')
)
```

Use these two functions exactly as above. `tsx` is a development dependency in
the prepared checkout. Disable the local switch to use `/vite` normally; never
import `/vite/source` into browser application code. Restart Vite after changing
Node-side plugin source or exports; component/structural CSS edits still use HMR.
Existing compiled theme assets remain necessary, and theme seed edits still need
the explicit theme compilation workflow.
