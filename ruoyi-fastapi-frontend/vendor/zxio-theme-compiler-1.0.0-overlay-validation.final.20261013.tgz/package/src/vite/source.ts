import { existsSync, readFileSync, realpathSync } from 'node:fs'
import { isAbsolute, resolve } from 'node:path'
import { searchForWorkspaceRoot } from 'vite'

import type { Alias, Plugin } from 'vite'

export interface ZxuiSourcePluginOptions {
  /** Absolute path to a prepared ZXUI source checkout (run its setup/build:theme first). */
  readonly workspaceRoot: string
  /** Optional chart and Tailwind packages resolved through their public source exports. */
  readonly featurePackages?: readonly ('@zxio/chart' | '@zxio/theme-tailwind')[]
}

const escape = (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

function importTarget(target: unknown): string | undefined {
  if (typeof target === 'string') return target
  if (!target || typeof target !== 'object') return undefined
  const entry = target as Record<string, unknown>
  return importTarget(entry.source ?? entry.import ?? entry.default)
}

/** Library-owned source resolution; standalone features opt in through public exports. */
export function zxuiSourcePlugin(options: ZxuiSourcePluginOptions): Plugin {
  if (!isAbsolute(options.workspaceRoot))
    throw new Error('[zxui-source] workspaceRoot must be an absolute path')
  const root = realpathSync(options.workspaceRoot)
  const packages = resolve(root, 'packages')
  const manifestPath = resolve(packages, 'zxui/package.json')
  if (!existsSync(manifestPath))
    throw new Error('[zxui-source] Expected a prepared ZXUI source checkout')
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
  if (manifest.name !== '@zxio/zxui')
    throw new Error('[zxui-source] Unexpected UI package identity')
  const alias: Alias[] = []
  // Exact public exports include nontrivial leaves such as button/style/css -> style-css.ts.
  for (const [subpath, target] of Object.entries(manifest.exports)) {
    const file = importTarget(target)
    if (!file || subpath.includes('*') || !file.startsWith('./')) continue
    if (/^\.\/(?:es|lib|dist)(?:\/|$)/.test(file)) continue
    const replacement =
      subpath === './style' || subpath === './style.css'
        ? resolve(packages, 'theme-chalk/src/structural.css')
        : resolve(packages, 'zxui', file)
    if (!existsSync(replacement))
      throw new Error(`[zxui-source] Missing public source export: ${subpath}`)
    const id = `@zxio/zxui${subpath === '.' ? '' : subpath.slice(1)}`
    alias.push({ find: new RegExp(`^${escape(id)}$`), replacement })
  }
  for (const packageName of new Set(options.featurePackages ?? [])) {
    if (!['@zxio/chart', '@zxio/theme-tailwind'].includes(packageName))
      throw new Error(
        `[zxui-source] Unsupported feature package: ${packageName}`
      )
    const featureRoot = resolve(packages, packageName.slice('@zxio/'.length))
    const featureManifestPath = resolve(featureRoot, 'package.json')
    if (!existsSync(featureManifestPath))
      throw new Error(`[zxui-source] Missing feature package: ${packageName}`)
    const featureManifest = JSON.parse(
      readFileSync(featureManifestPath, 'utf8')
    )
    if (featureManifest.name !== packageName)
      throw new Error(
        `[zxui-source] Unexpected feature package identity: ${packageName}`
      )
    for (const [subpath, target] of Object.entries(featureManifest.exports)) {
      const file = importTarget(target)
      if (!file || subpath.includes('*') || !file.startsWith('./')) continue
      if (/^\.\/(?:es|lib|dist)(?:\/|$)/.test(file)) continue
      const replacement = resolve(featureRoot, file)
      if (!existsSync(replacement))
        throw new Error(
          `[zxui-source] Missing feature source export: ${packageName}/${subpath}`
        )
      const id = `${packageName}${subpath === '.' ? '' : subpath.slice(1)}`
      alias.push({ find: new RegExp(`^${escape(id)}$`), replacement })
    }
  }
  const internals = [
    'components',
    'constants',
    'hooks',
    'shared',
    'types',
    'utils',
  ]
  for (const name of internals) {
    const replacement = resolve(packages, name)
    if (!existsSync(resolve(replacement, 'index.ts')))
      throw new Error(`[zxui-source] Missing workspace source: ${name}`)
    alias.push(
      {
        find: new RegExp(`^@zxio/${name}$`),
        replacement: `${replacement}/index.ts`,
      },
      {
        find: new RegExp(`^@zxio/${name}/(.+)$`),
        replacement: `${replacement}/$1`,
      }
    )
  }
  for (const [id, file] of Object.entries({
    '@zxio/theme-consumer': 'theme-consumer/src/index.ts',
    '@zxio/theme-consumer/vue': 'theme-consumer/src/vue/index.ts',
    '@zxio/theme-css-codec': 'theme-css-codec/src/index.ts',
    '@zxio/theme-compiler/extensions': 'theme-compiler/src/extensions/index.ts',
    '@zxio/tokens/kernel': 'tokens/src/kernel/index.ts',
    '@zxio/tokens/extensions': 'tokens/src/extensions/index.ts',
    '@zxio/tokens/display': 'tokens/src/display/index.ts',
    '@zxio/tokens/semantic-contract': 'tokens/src/semantic-contract/index.ts',
  })) {
    const replacement = resolve(packages, file)
    if (!existsSync(replacement))
      throw new Error(`[zxui-source] Missing workspace source: ${id}`)
    alias.push({ find: new RegExp(`^${escape(id)}$`), replacement })
  }
  alias.push({
    find: /^@zxio\/theme-chalk\/(.+\.css)$/,
    replacement: `${packages}/theme-chalk/dist/$1`,
  })
  return {
    name: 'zxui-source',
    config(config) {
      return {
        resolve: {
          alias,
          dedupe: [
            'vue',
            'element-plus',
            '@vue/runtime-core',
            '@vue/runtime-dom',
            '@vue/reactivity',
            '@vue/shared',
            ...(options.featurePackages?.includes('@zxio/chart')
              ? ['echarts', 'vue-echarts']
              : []),
          ],
        },
        optimizeDeps: {
          exclude: [
            '@zxio/zxui',
            ...internals.map((name) => `@zxio/${name}`),
            '@zxio/theme-chalk',
            '@zxio/theme-consumer',
            '@zxio/theme-css-codec',
            '@zxio/tokens',
            '@zxio/keybindings',
            ...(options.featurePackages ?? []),
          ],
        },
        server: {
          fs: {
            allow: [
              ...(config.server?.fs?.allow ?? [
                searchForWorkspaceRoot(config.root ?? process.cwd()),
              ]),
              root,
            ],
          },
        },
      }
    },
  }
}
