# Release notes

## 2026-10-16 Focus visibility

- Increase the seed focus-ring opacity to keep the normal-contrast canvas
  outline at or above 3:1 in both light and dark mode.
- Regenerate all theme artifacts from source; public names and theme identity
  stay unchanged.

## 1.0.0

- Add the Factory Blue Theme v4 package (`industrial-blue`) with 162 deterministic
  variants. It carries the original industrial cobalt seeds that
  `@zxio/theme-factory-blue` shipped before its 2026-09-10 Steel Blue recolor.
- Use public elevation and material roles for tonal depth, inset glow, and
  colored panel shadows.
