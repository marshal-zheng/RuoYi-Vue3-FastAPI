# @zxio/theme-defense-green

The defense-green package is authored exclusively as a ZXIO Theme v4 source in
`src/theme.ts`. Its published surface contains only deterministic files under
`generated/`, with the same manifest, Variant, typegen, Element Plus, and DTCG
contract as `@zxio/theme-default`.

Run `pnpm -C packages/theme-defense-green build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
