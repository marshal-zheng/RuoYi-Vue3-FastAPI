# @zxio/theme-defense-green Release Notes

Version: `1.0.0`

## Affected Components

- `@zxio/zxui@1.0.18`
- `@zxio/drive@1.0.0`
- `@zxio/text-editor@1.0.0`

## Theme Profile

- Enterprise defense palette anchored to standardized military greens: the
  light accent sits between US Army Green (#4B5320) and RAL 6003 Olivgrün, the
  dark canvas is UK Deep Bronze Green (BS 381C 224) lifted to a screen-safe
  lightness, and the dark accent is Camouflage Green (#78866B) brightened into
  a sage that carries dark label text.
- Light mode is olive paper with Army Green chrome; borders and quiet fills are
  mixed from the brand so hairlines read olive instead of grey.
- Dark mode is the primary expression: matte command-console layering with
  wider canvas → body → elevated steps (about 1.5x and 1.9x relative
  luminance), bone-white text, and lifted signal colors so tags and alerts stay
  at or above 4.5:1.
- 2026-09-09 recolor: the previous dark canvas (#0B100B) and olive accent
  (#4F6142) were replaced because the canvas sat near black, panels separated
  by less than 1.1:1, and the accent reached only 2.9:1 on the canvas.

## Upgrade Impact

- Variable-only theme package; no structure-style payload.
- Public contract is generated from `src/theme.ts` through `pnpm theme:build`.
- Runtime consumers install the generated `dist/` package artifacts; repository-local generated files remain an implementation detail for authoring and validation.
- `theme.manifest.json` records `validatedAgainst.elementPlus = 2.13.0` as the
  current verified Element Plus baseline for the green theme matrix.
- `--zx-transition-all` and `--el-transition-all` are removed from the formal
  contract and bridge. Use explicit-property motion tokens such as
  `--zx-transition-opacity`, `--zx-transition-transform`, and
  `--zx-transition-interactive`.
- Defense-green shape now flows through semantic radius role tokens instead of
  isolated component pixels.
- Success, warning, selected, placeholder, and disabled colors are tuned to pass
  state-color delta and UI chrome contrast checks in light and dark.

## Theme Mental Model

- business apps switch themes, they do not compose themes
- components add deltas, they do not rebuild global theme structure
- Element Plus consumes the bridge; it is not the theme source of truth
- recommended business entry is `themeId + mode + scope` through `ZxConfigProvider`
