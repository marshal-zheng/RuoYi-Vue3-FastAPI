# @zxio/theme-tech-blue

Tech Blue is a product-grade blue Theme v4 package authored exclusively as a
seed source in `src/theme.ts`. It is a palette-only skin: neutral slate grounds,
a single saturated action blue in the family used by leading enterprise design
systems, flat shadow depth, and no glow material.

Run `pnpm -C packages/theme-tech-blue build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
