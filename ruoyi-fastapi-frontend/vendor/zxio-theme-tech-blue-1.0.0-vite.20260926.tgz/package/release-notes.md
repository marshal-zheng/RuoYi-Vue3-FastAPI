# Release notes

## 1.0.0

- Add the Tech Blue Theme v4 package with 162 deterministic variants.
- Palette only: slate neutrals, one saturated action blue, flat shadow depth,
  no glow or brand-tinted material.
