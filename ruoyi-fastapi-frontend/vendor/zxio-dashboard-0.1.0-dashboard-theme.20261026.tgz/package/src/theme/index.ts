/** Optional compiled theme data; does not load the grid runtime or styles. */
export { themeBundle as dashboardThemeBundle } from '@zxio/vue-grid-layout/theme'
