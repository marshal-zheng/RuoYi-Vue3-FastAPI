const deepFreeze = (value) => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const key of Object.keys(value)) deepFreeze(value[key])
    Object.freeze(value)
  }
  return value
}

const themeId = "industrial-blue"

const axisDeclarations = deepFreeze({
  "contrast": {
    "default": "normal",
    "supported": [
      "normal",
      "high",
      "forced-colors"
    ]
  },
  "density": {
    "default": "default",
    "supported": [
      "compact",
      "default",
      "comfortable"
    ]
  },
  "mode": {
    "default": "light",
    "supported": [
      "light",
      "dark"
    ]
  },
  "motion": {
    "default": "full",
    "supported": [
      "full",
      "reduced",
      "none"
    ]
  },
  "radius": {
    "default": "default",
    "supported": [
      "sharp",
      "default",
      "rounded"
    ]
  }
})

const variantKeys = deepFreeze([
  "mode-light__density-compact__contrast-normal__motion-full__radius-sharp",
  "mode-light__density-compact__contrast-normal__motion-full__radius-default",
  "mode-light__density-compact__contrast-normal__motion-full__radius-rounded",
  "mode-light__density-compact__contrast-normal__motion-reduced__radius-sharp",
  "mode-light__density-compact__contrast-normal__motion-reduced__radius-default",
  "mode-light__density-compact__contrast-normal__motion-reduced__radius-rounded",
  "mode-light__density-compact__contrast-normal__motion-none__radius-sharp",
  "mode-light__density-compact__contrast-normal__motion-none__radius-default",
  "mode-light__density-compact__contrast-normal__motion-none__radius-rounded",
  "mode-light__density-compact__contrast-high__motion-full__radius-sharp",
  "mode-light__density-compact__contrast-high__motion-full__radius-default",
  "mode-light__density-compact__contrast-high__motion-full__radius-rounded",
  "mode-light__density-compact__contrast-high__motion-reduced__radius-sharp",
  "mode-light__density-compact__contrast-high__motion-reduced__radius-default",
  "mode-light__density-compact__contrast-high__motion-reduced__radius-rounded",
  "mode-light__density-compact__contrast-high__motion-none__radius-sharp",
  "mode-light__density-compact__contrast-high__motion-none__radius-default",
  "mode-light__density-compact__contrast-high__motion-none__radius-rounded",
  "mode-light__density-compact__contrast-forced-colors__motion-full__radius-sharp",
  "mode-light__density-compact__contrast-forced-colors__motion-full__radius-default",
  "mode-light__density-compact__contrast-forced-colors__motion-full__radius-rounded",
  "mode-light__density-compact__contrast-forced-colors__motion-reduced__radius-sharp",
  "mode-light__density-compact__contrast-forced-colors__motion-reduced__radius-default",
  "mode-light__density-compact__contrast-forced-colors__motion-reduced__radius-rounded",
  "mode-light__density-compact__contrast-forced-colors__motion-none__radius-sharp",
  "mode-light__density-compact__contrast-forced-colors__motion-none__radius-default",
  "mode-light__density-compact__contrast-forced-colors__motion-none__radius-rounded",
  "mode-light__density-default__contrast-normal__motion-full__radius-sharp",
  "mode-light__density-default__contrast-normal__motion-full__radius-default",
  "mode-light__density-default__contrast-normal__motion-full__radius-rounded",
  "mode-light__density-default__contrast-normal__motion-reduced__radius-sharp",
  "mode-light__density-default__contrast-normal__motion-reduced__radius-default",
  "mode-light__density-default__contrast-normal__motion-reduced__radius-rounded",
  "mode-light__density-default__contrast-normal__motion-none__radius-sharp",
  "mode-light__density-default__contrast-normal__motion-none__radius-default",
  "mode-light__density-default__contrast-normal__motion-none__radius-rounded",
  "mode-light__density-default__contrast-high__motion-full__radius-sharp",
  "mode-light__density-default__contrast-high__motion-full__radius-default",
  "mode-light__density-default__contrast-high__motion-full__radius-rounded",
  "mode-light__density-default__contrast-high__motion-reduced__radius-sharp",
  "mode-light__density-default__contrast-high__motion-reduced__radius-default",
  "mode-light__density-default__contrast-high__motion-reduced__radius-rounded",
  "mode-light__density-default__contrast-high__motion-none__radius-sharp",
  "mode-light__density-default__contrast-high__motion-none__radius-default",
  "mode-light__density-default__contrast-high__motion-none__radius-rounded",
  "mode-light__density-default__contrast-forced-colors__motion-full__radius-sharp",
  "mode-light__density-default__contrast-forced-colors__motion-full__radius-default",
  "mode-light__density-default__contrast-forced-colors__motion-full__radius-rounded",
  "mode-light__density-default__contrast-forced-colors__motion-reduced__radius-sharp",
  "mode-light__density-default__contrast-forced-colors__motion-reduced__radius-default",
  "mode-light__density-default__contrast-forced-colors__motion-reduced__radius-rounded",
  "mode-light__density-default__contrast-forced-colors__motion-none__radius-sharp",
  "mode-light__density-default__contrast-forced-colors__motion-none__radius-default",
  "mode-light__density-default__contrast-forced-colors__motion-none__radius-rounded",
  "mode-light__density-comfortable__contrast-normal__motion-full__radius-sharp",
  "mode-light__density-comfortable__contrast-normal__motion-full__radius-default",
  "mode-light__density-comfortable__contrast-normal__motion-full__radius-rounded",
  "mode-light__density-comfortable__contrast-normal__motion-reduced__radius-sharp",
  "mode-light__density-comfortable__contrast-normal__motion-reduced__radius-default",
  "mode-light__density-comfortable__contrast-normal__motion-reduced__radius-rounded",
  "mode-light__density-comfortable__contrast-normal__motion-none__radius-sharp",
  "mode-light__density-comfortable__contrast-normal__motion-none__radius-default",
  "mode-light__density-comfortable__contrast-normal__motion-none__radius-rounded",
  "mode-light__density-comfortable__contrast-high__motion-full__radius-sharp",
  "mode-light__density-comfortable__contrast-high__motion-full__radius-default",
  "mode-light__density-comfortable__contrast-high__motion-full__radius-rounded",
  "mode-light__density-comfortable__contrast-high__motion-reduced__radius-sharp",
  "mode-light__density-comfortable__contrast-high__motion-reduced__radius-default",
  "mode-light__density-comfortable__contrast-high__motion-reduced__radius-rounded",
  "mode-light__density-comfortable__contrast-high__motion-none__radius-sharp",
  "mode-light__density-comfortable__contrast-high__motion-none__radius-default",
  "mode-light__density-comfortable__contrast-high__motion-none__radius-rounded",
  "mode-light__density-comfortable__contrast-forced-colors__motion-full__radius-sharp",
  "mode-light__density-comfortable__contrast-forced-colors__motion-full__radius-default",
  "mode-light__density-comfortable__contrast-forced-colors__motion-full__radius-rounded",
  "mode-light__density-comfortable__contrast-forced-colors__motion-reduced__radius-sharp",
  "mode-light__density-comfortable__contrast-forced-colors__motion-reduced__radius-default",
  "mode-light__density-comfortable__contrast-forced-colors__motion-reduced__radius-rounded",
  "mode-light__density-comfortable__contrast-forced-colors__motion-none__radius-sharp",
  "mode-light__density-comfortable__contrast-forced-colors__motion-none__radius-default",
  "mode-light__density-comfortable__contrast-forced-colors__motion-none__radius-rounded",
  "mode-dark__density-compact__contrast-normal__motion-full__radius-sharp",
  "mode-dark__density-compact__contrast-normal__motion-full__radius-default",
  "mode-dark__density-compact__contrast-normal__motion-full__radius-rounded",
  "mode-dark__density-compact__contrast-normal__motion-reduced__radius-sharp",
  "mode-dark__density-compact__contrast-normal__motion-reduced__radius-default",
  "mode-dark__density-compact__contrast-normal__motion-reduced__radius-rounded",
  "mode-dark__density-compact__contrast-normal__motion-none__radius-sharp",
  "mode-dark__density-compact__contrast-normal__motion-none__radius-default",
  "mode-dark__density-compact__contrast-normal__motion-none__radius-rounded",
  "mode-dark__density-compact__contrast-high__motion-full__radius-sharp",
  "mode-dark__density-compact__contrast-high__motion-full__radius-default",
  "mode-dark__density-compact__contrast-high__motion-full__radius-rounded",
  "mode-dark__density-compact__contrast-high__motion-reduced__radius-sharp",
  "mode-dark__density-compact__contrast-high__motion-reduced__radius-default",
  "mode-dark__density-compact__contrast-high__motion-reduced__radius-rounded",
  "mode-dark__density-compact__contrast-high__motion-none__radius-sharp",
  "mode-dark__density-compact__contrast-high__motion-none__radius-default",
  "mode-dark__density-compact__contrast-high__motion-none__radius-rounded",
  "mode-dark__density-compact__contrast-forced-colors__motion-full__radius-sharp",
  "mode-dark__density-compact__contrast-forced-colors__motion-full__radius-default",
  "mode-dark__density-compact__contrast-forced-colors__motion-full__radius-rounded",
  "mode-dark__density-compact__contrast-forced-colors__motion-reduced__radius-sharp",
  "mode-dark__density-compact__contrast-forced-colors__motion-reduced__radius-default",
  "mode-dark__density-compact__contrast-forced-colors__motion-reduced__radius-rounded",
  "mode-dark__density-compact__contrast-forced-colors__motion-none__radius-sharp",
  "mode-dark__density-compact__contrast-forced-colors__motion-none__radius-default",
  "mode-dark__density-compact__contrast-forced-colors__motion-none__radius-rounded",
  "mode-dark__density-default__contrast-normal__motion-full__radius-sharp",
  "mode-dark__density-default__contrast-normal__motion-full__radius-default",
  "mode-dark__density-default__contrast-normal__motion-full__radius-rounded",
  "mode-dark__density-default__contrast-normal__motion-reduced__radius-sharp",
  "mode-dark__density-default__contrast-normal__motion-reduced__radius-default",
  "mode-dark__density-default__contrast-normal__motion-reduced__radius-rounded",
  "mode-dark__density-default__contrast-normal__motion-none__radius-sharp",
  "mode-dark__density-default__contrast-normal__motion-none__radius-default",
  "mode-dark__density-default__contrast-normal__motion-none__radius-rounded",
  "mode-dark__density-default__contrast-high__motion-full__radius-sharp",
  "mode-dark__density-default__contrast-high__motion-full__radius-default",
  "mode-dark__density-default__contrast-high__motion-full__radius-rounded",
  "mode-dark__density-default__contrast-high__motion-reduced__radius-sharp",
  "mode-dark__density-default__contrast-high__motion-reduced__radius-default",
  "mode-dark__density-default__contrast-high__motion-reduced__radius-rounded",
  "mode-dark__density-default__contrast-high__motion-none__radius-sharp",
  "mode-dark__density-default__contrast-high__motion-none__radius-default",
  "mode-dark__density-default__contrast-high__motion-none__radius-rounded",
  "mode-dark__density-default__contrast-forced-colors__motion-full__radius-sharp",
  "mode-dark__density-default__contrast-forced-colors__motion-full__radius-default",
  "mode-dark__density-default__contrast-forced-colors__motion-full__radius-rounded",
  "mode-dark__density-default__contrast-forced-colors__motion-reduced__radius-sharp",
  "mode-dark__density-default__contrast-forced-colors__motion-reduced__radius-default",
  "mode-dark__density-default__contrast-forced-colors__motion-reduced__radius-rounded",
  "mode-dark__density-default__contrast-forced-colors__motion-none__radius-sharp",
  "mode-dark__density-default__contrast-forced-colors__motion-none__radius-default",
  "mode-dark__density-default__contrast-forced-colors__motion-none__radius-rounded",
  "mode-dark__density-comfortable__contrast-normal__motion-full__radius-sharp",
  "mode-dark__density-comfortable__contrast-normal__motion-full__radius-default",
  "mode-dark__density-comfortable__contrast-normal__motion-full__radius-rounded",
  "mode-dark__density-comfortable__contrast-normal__motion-reduced__radius-sharp",
  "mode-dark__density-comfortable__contrast-normal__motion-reduced__radius-default",
  "mode-dark__density-comfortable__contrast-normal__motion-reduced__radius-rounded",
  "mode-dark__density-comfortable__contrast-normal__motion-none__radius-sharp",
  "mode-dark__density-comfortable__contrast-normal__motion-none__radius-default",
  "mode-dark__density-comfortable__contrast-normal__motion-none__radius-rounded",
  "mode-dark__density-comfortable__contrast-high__motion-full__radius-sharp",
  "mode-dark__density-comfortable__contrast-high__motion-full__radius-default",
  "mode-dark__density-comfortable__contrast-high__motion-full__radius-rounded",
  "mode-dark__density-comfortable__contrast-high__motion-reduced__radius-sharp",
  "mode-dark__density-comfortable__contrast-high__motion-reduced__radius-default",
  "mode-dark__density-comfortable__contrast-high__motion-reduced__radius-rounded",
  "mode-dark__density-comfortable__contrast-high__motion-none__radius-sharp",
  "mode-dark__density-comfortable__contrast-high__motion-none__radius-default",
  "mode-dark__density-comfortable__contrast-high__motion-none__radius-rounded",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-full__radius-sharp",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-full__radius-default",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-full__radius-rounded",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-reduced__radius-sharp",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-reduced__radius-default",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-reduced__radius-rounded",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-none__radius-sharp",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-none__radius-default",
  "mode-dark__density-comfortable__contrast-forced-colors__motion-none__radius-rounded"
])

const publicTokensByPath = deepFreeze({
  "semantic.accent.base": {
    "cssVariable": "--zx-semantic-accent-base",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.base",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.fill-active": {
    "cssVariable": "--zx-semantic-accent-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.fill-hover": {
    "cssVariable": "--zx-semantic-accent-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.on-fill": {
    "cssVariable": "--zx-semantic-accent-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.on-fill-active": {
    "cssVariable": "--zx-semantic-accent-on-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.on-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.on-fill-disabled": {
    "cssVariable": "--zx-semantic-accent-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.on-fill-hover": {
    "cssVariable": "--zx-semantic-accent-on-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.on-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.on-surface": {
    "cssVariable": "--zx-semantic-accent-on-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.on-surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.shade-2": {
    "cssVariable": "--zx-semantic-accent-shade-2",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.shade-2",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.subtle": {
    "cssVariable": "--zx-semantic-accent-subtle",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.subtle",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.tint-3": {
    "cssVariable": "--zx-semantic-accent-tint-3",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.tint-3",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.tint-5": {
    "cssVariable": "--zx-semantic-accent-tint-5",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.tint-5",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.tint-7": {
    "cssVariable": "--zx-semantic-accent-tint-7",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.tint-7",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.tint-8": {
    "cssVariable": "--zx-semantic-accent-tint-8",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.tint-8",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.accent.tint-9": {
    "cssVariable": "--zx-semantic-accent-tint-9",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.accent.tint-9",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.danger.fill": {
    "cssVariable": "--zx-semantic-action-danger-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.danger.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.danger.fill-active": {
    "cssVariable": "--zx-semantic-action-danger-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.danger.fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.danger.fill-disabled": {
    "cssVariable": "--zx-semantic-action-danger-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.danger.fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.danger.fill-hover": {
    "cssVariable": "--zx-semantic-action-danger-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.danger.fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.danger.on-fill": {
    "cssVariable": "--zx-semantic-action-danger-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.danger.on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.danger.on-fill-disabled": {
    "cssVariable": "--zx-semantic-action-danger-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.danger.on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.focus-ring": {
    "cssVariable": "--zx-semantic-action-focus-ring",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.action.focus-ring",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.info.fill": {
    "cssVariable": "--zx-semantic-action-info-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.info.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.info.fill-active": {
    "cssVariable": "--zx-semantic-action-info-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.info.fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.info.fill-disabled": {
    "cssVariable": "--zx-semantic-action-info-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.info.fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.info.fill-hover": {
    "cssVariable": "--zx-semantic-action-info-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.info.fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.info.on-fill": {
    "cssVariable": "--zx-semantic-action-info-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.info.on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.info.on-fill-disabled": {
    "cssVariable": "--zx-semantic-action-info-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.info.on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.primary.fill": {
    "cssVariable": "--zx-semantic-action-primary-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.primary.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.primary.fill-active": {
    "cssVariable": "--zx-semantic-action-primary-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.primary.fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.primary.fill-disabled": {
    "cssVariable": "--zx-semantic-action-primary-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.primary.fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.primary.fill-hover": {
    "cssVariable": "--zx-semantic-action-primary-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.primary.fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.primary.on-fill": {
    "cssVariable": "--zx-semantic-action-primary-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.primary.on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.primary.on-fill-disabled": {
    "cssVariable": "--zx-semantic-action-primary-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.primary.on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.success.fill": {
    "cssVariable": "--zx-semantic-action-success-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.success.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.success.fill-active": {
    "cssVariable": "--zx-semantic-action-success-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.success.fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.success.fill-disabled": {
    "cssVariable": "--zx-semantic-action-success-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.success.fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.success.fill-hover": {
    "cssVariable": "--zx-semantic-action-success-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.success.fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.success.on-fill": {
    "cssVariable": "--zx-semantic-action-success-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.success.on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.success.on-fill-disabled": {
    "cssVariable": "--zx-semantic-action-success-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.success.on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.warning.fill": {
    "cssVariable": "--zx-semantic-action-warning-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.warning.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.warning.fill-active": {
    "cssVariable": "--zx-semantic-action-warning-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.warning.fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.warning.fill-disabled": {
    "cssVariable": "--zx-semantic-action-warning-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.warning.fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.warning.fill-hover": {
    "cssVariable": "--zx-semantic-action-warning-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.warning.fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.warning.on-fill": {
    "cssVariable": "--zx-semantic-action-warning-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.warning.on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.action.warning.on-fill-disabled": {
    "cssVariable": "--zx-semantic-action-warning-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.action.warning.on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.border.control": {
    "cssVariable": "--zx-semantic-border-control",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.border.control",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.border.current-tint": {
    "cssVariable": "--zx-semantic-border-current-tint",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.border.current-tint",
    "typeId": "number",
    "typeMetadata": {
      "typeId": "number"
    }
  },
  "semantic.border.default": {
    "cssVariable": "--zx-semantic-border-default",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.border.default",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.border.strong": {
    "cssVariable": "--zx-semantic-border-strong",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.border.strong",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.border.subtle": {
    "cssVariable": "--zx-semantic-border-subtle",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.border.subtle",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.blocking.border": {
    "cssVariable": "--zx-semantic-elevation-blocking-border",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.blocking.border",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.blocking.shadow": {
    "cssVariable": "--zx-semantic-elevation-blocking-shadow",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.blocking.shadow",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.elevation.blocking.surface": {
    "cssVariable": "--zx-semantic-elevation-blocking-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.blocking.surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.flat.border": {
    "cssVariable": "--zx-semantic-elevation-flat-border",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.flat.border",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.flat.shadow": {
    "cssVariable": "--zx-semantic-elevation-flat-shadow",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.flat.shadow",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.elevation.flat.surface": {
    "cssVariable": "--zx-semantic-elevation-flat-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.flat.surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.overlay.border": {
    "cssVariable": "--zx-semantic-elevation-overlay-border",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.overlay.border",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.overlay.shadow": {
    "cssVariable": "--zx-semantic-elevation-overlay-shadow",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.overlay.shadow",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.elevation.overlay.surface": {
    "cssVariable": "--zx-semantic-elevation-overlay-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.overlay.surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.raised.border": {
    "cssVariable": "--zx-semantic-elevation-raised-border",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.raised.border",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.elevation.raised.shadow": {
    "cssVariable": "--zx-semantic-elevation-raised-shadow",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.raised.shadow",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.elevation.raised.surface": {
    "cssVariable": "--zx-semantic-elevation-raised-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.elevation.raised.surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.accent-active": {
    "cssVariable": "--zx-semantic-fill-accent-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.accent-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.accent-hover": {
    "cssVariable": "--zx-semantic-fill-accent-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.accent-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.active": {
    "cssVariable": "--zx-semantic-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.current-tint": {
    "cssVariable": "--zx-semantic-fill-current-tint",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.current-tint",
    "typeId": "number",
    "typeMetadata": {
      "typeId": "number"
    }
  },
  "semantic.fill.hover": {
    "cssVariable": "--zx-semantic-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.scrollbar-thumb": {
    "cssVariable": "--zx-semantic-fill-scrollbar-thumb",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.scrollbar-thumb",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.scrollbar-thumb-hover": {
    "cssVariable": "--zx-semantic-fill-scrollbar-thumb-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.scrollbar-thumb-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.scrollbar-track": {
    "cssVariable": "--zx-semantic-fill-scrollbar-track",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.scrollbar-track",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.selected": {
    "cssVariable": "--zx-semantic-fill-selected",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.selected",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.selected-hover": {
    "cssVariable": "--zx-semantic-fill-selected-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.selected-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.status-subtle": {
    "cssVariable": "--zx-semantic-fill-status-subtle",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.status-subtle",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.fill.subtle": {
    "cssVariable": "--zx-semantic-fill-subtle",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.fill.subtle",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.material.brand-shadow.blocking": {
    "cssVariable": "--zx-semantic-material-brand-shadow-blocking",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.brand-shadow.blocking",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.brand-shadow.overlay": {
    "cssVariable": "--zx-semantic-material-brand-shadow-overlay",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.brand-shadow.overlay",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.brand-shadow.raised": {
    "cssVariable": "--zx-semantic-material-brand-shadow-raised",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.brand-shadow.raised",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.cutout-ring": {
    "cssVariable": "--zx-semantic-material-cutout-ring",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.cutout-ring",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.focus-ring": {
    "cssVariable": "--zx-semantic-material-focus-ring",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.focus-ring",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.focus-ring-transition": {
    "cssVariable": "--zx-semantic-material-focus-ring-transition",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.focus-ring-transition",
    "typeId": "transition",
    "typeMetadata": {
      "typeId": "transition"
    }
  },
  "semantic.material.inner-glow": {
    "cssVariable": "--zx-semantic-material-inner-glow",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.inner-glow",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.inner-stroke": {
    "cssVariable": "--zx-semantic-material-inner-stroke",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.inner-stroke",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.inner-stroke-accent": {
    "cssVariable": "--zx-semantic-material-inner-stroke-accent",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.inner-stroke-accent",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.inner-stroke-danger": {
    "cssVariable": "--zx-semantic-material-inner-stroke-danger",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.inner-stroke-danger",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.material.tonal-gradient": {
    "cssVariable": "--zx-semantic-material-tonal-gradient",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.tonal-gradient",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.material.tonal-tint": {
    "cssVariable": "--zx-semantic-material-tonal-tint",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.material.tonal-tint",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.motion.duration": {
    "cssVariable": "--zx-semantic-motion-duration",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.motion.duration",
    "typeId": "duration",
    "typeMetadata": {
      "typeId": "duration"
    }
  },
  "semantic.motion.duration-fast": {
    "cssVariable": "--zx-semantic-motion-duration-fast",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.motion.duration-fast",
    "typeId": "duration",
    "typeMetadata": {
      "typeId": "duration"
    }
  },
  "semantic.overlay.mask": {
    "cssVariable": "--zx-semantic-overlay-mask",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.overlay.mask",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.overlay.modal": {
    "cssVariable": "--zx-semantic-overlay-modal",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.overlay.modal",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.radius.control": {
    "cssVariable": "--zx-semantic-radius-control",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.radius.control",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.radius.surface": {
    "cssVariable": "--zx-semantic-radius-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.radius.surface",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.spacing.control-y": {
    "cssVariable": "--zx-semantic-spacing-control-y",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.spacing.control-y",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.status.danger": {
    "cssVariable": "--zx-semantic-status-danger",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-fill-active": {
    "cssVariable": "--zx-semantic-status-danger-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-fill-hover": {
    "cssVariable": "--zx-semantic-status-danger-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-on-fill": {
    "cssVariable": "--zx-semantic-status-danger-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-on-fill-active": {
    "cssVariable": "--zx-semantic-status-danger-on-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-on-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-on-fill-disabled": {
    "cssVariable": "--zx-semantic-status-danger-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-on-fill-hover": {
    "cssVariable": "--zx-semantic-status-danger-on-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-on-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-on-surface": {
    "cssVariable": "--zx-semantic-status-danger-on-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-on-surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-shade-2": {
    "cssVariable": "--zx-semantic-status-danger-shade-2",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-shade-2",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-tint-3": {
    "cssVariable": "--zx-semantic-status-danger-tint-3",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-tint-3",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-tint-5": {
    "cssVariable": "--zx-semantic-status-danger-tint-5",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-tint-5",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-tint-7": {
    "cssVariable": "--zx-semantic-status-danger-tint-7",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-tint-7",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-tint-8": {
    "cssVariable": "--zx-semantic-status-danger-tint-8",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-tint-8",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.danger-tint-9": {
    "cssVariable": "--zx-semantic-status-danger-tint-9",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.danger-tint-9",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info": {
    "cssVariable": "--zx-semantic-status-info",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-fill-active": {
    "cssVariable": "--zx-semantic-status-info-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-fill-hover": {
    "cssVariable": "--zx-semantic-status-info-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-on-fill": {
    "cssVariable": "--zx-semantic-status-info-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-on-fill-active": {
    "cssVariable": "--zx-semantic-status-info-on-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-on-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-on-fill-disabled": {
    "cssVariable": "--zx-semantic-status-info-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-on-fill-hover": {
    "cssVariable": "--zx-semantic-status-info-on-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-on-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-on-surface": {
    "cssVariable": "--zx-semantic-status-info-on-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-on-surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-shade-2": {
    "cssVariable": "--zx-semantic-status-info-shade-2",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-shade-2",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-tint-3": {
    "cssVariable": "--zx-semantic-status-info-tint-3",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-tint-3",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-tint-5": {
    "cssVariable": "--zx-semantic-status-info-tint-5",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-tint-5",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-tint-7": {
    "cssVariable": "--zx-semantic-status-info-tint-7",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-tint-7",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-tint-8": {
    "cssVariable": "--zx-semantic-status-info-tint-8",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-tint-8",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.info-tint-9": {
    "cssVariable": "--zx-semantic-status-info-tint-9",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.info-tint-9",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success": {
    "cssVariable": "--zx-semantic-status-success",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-fill-active": {
    "cssVariable": "--zx-semantic-status-success-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-fill-hover": {
    "cssVariable": "--zx-semantic-status-success-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-on-fill": {
    "cssVariable": "--zx-semantic-status-success-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-on-fill-active": {
    "cssVariable": "--zx-semantic-status-success-on-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-on-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-on-fill-disabled": {
    "cssVariable": "--zx-semantic-status-success-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-on-fill-hover": {
    "cssVariable": "--zx-semantic-status-success-on-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-on-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-on-surface": {
    "cssVariable": "--zx-semantic-status-success-on-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-on-surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-shade-2": {
    "cssVariable": "--zx-semantic-status-success-shade-2",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-shade-2",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-tint-3": {
    "cssVariable": "--zx-semantic-status-success-tint-3",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-tint-3",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-tint-5": {
    "cssVariable": "--zx-semantic-status-success-tint-5",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-tint-5",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-tint-7": {
    "cssVariable": "--zx-semantic-status-success-tint-7",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-tint-7",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-tint-8": {
    "cssVariable": "--zx-semantic-status-success-tint-8",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-tint-8",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.success-tint-9": {
    "cssVariable": "--zx-semantic-status-success-tint-9",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.success-tint-9",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning": {
    "cssVariable": "--zx-semantic-status-warning",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-fill-active": {
    "cssVariable": "--zx-semantic-status-warning-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-fill-hover": {
    "cssVariable": "--zx-semantic-status-warning-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-on-fill": {
    "cssVariable": "--zx-semantic-status-warning-on-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-on-fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-on-fill-active": {
    "cssVariable": "--zx-semantic-status-warning-on-fill-active",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-on-fill-active",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-on-fill-disabled": {
    "cssVariable": "--zx-semantic-status-warning-on-fill-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-on-fill-disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-on-fill-hover": {
    "cssVariable": "--zx-semantic-status-warning-on-fill-hover",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-on-fill-hover",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-on-surface": {
    "cssVariable": "--zx-semantic-status-warning-on-surface",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-on-surface",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-shade-2": {
    "cssVariable": "--zx-semantic-status-warning-shade-2",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-shade-2",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-tint-3": {
    "cssVariable": "--zx-semantic-status-warning-tint-3",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-tint-3",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-tint-5": {
    "cssVariable": "--zx-semantic-status-warning-tint-5",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-tint-5",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-tint-7": {
    "cssVariable": "--zx-semantic-status-warning-tint-7",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-tint-7",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-tint-8": {
    "cssVariable": "--zx-semantic-status-warning-tint-8",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-tint-8",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.status.warning-tint-9": {
    "cssVariable": "--zx-semantic-status-warning-tint-9",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.status.warning-tint-9",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.stroke.default": {
    "cssVariable": "--zx-semantic-stroke-default",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.stroke.default",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.stroke.focus": {
    "cssVariable": "--zx-semantic-stroke-focus",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.stroke.focus",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.stroke.focus-inline": {
    "cssVariable": "--zx-semantic-stroke-focus-inline",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.stroke.focus-inline",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.stroke.strong": {
    "cssVariable": "--zx-semantic-stroke-strong",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.stroke.strong",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.stroke.subtle": {
    "cssVariable": "--zx-semantic-stroke-subtle",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.stroke.subtle",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.blocking.depth": {
    "cssVariable": "--zx-semantic-surface-blocking-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.blocking.edge": {
    "cssVariable": "--zx-semantic-surface-blocking-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.blocking.fill": {
    "cssVariable": "--zx-semantic-surface-blocking-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.blocking.highlight": {
    "cssVariable": "--zx-semantic-surface-blocking-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.blocking.inner": {
    "cssVariable": "--zx-semantic-surface-blocking-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.blocking.on-text": {
    "cssVariable": "--zx-semantic-surface-blocking-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.blocking.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-blocking-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.blocking.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.body": {
    "cssVariable": "--zx-semantic-surface-body",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.body",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.brand.depth": {
    "cssVariable": "--zx-semantic-surface-brand-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.brand.edge": {
    "cssVariable": "--zx-semantic-surface-brand-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.brand.fill": {
    "cssVariable": "--zx-semantic-surface-brand-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.brand.highlight": {
    "cssVariable": "--zx-semantic-surface-brand-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.brand.inner": {
    "cssVariable": "--zx-semantic-surface-brand-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.brand.on-text": {
    "cssVariable": "--zx-semantic-surface-brand-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.brand.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-brand-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.brand.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.canvas.depth": {
    "cssVariable": "--zx-semantic-surface-canvas-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.canvas.edge": {
    "cssVariable": "--zx-semantic-surface-canvas-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.canvas.fill": {
    "cssVariable": "--zx-semantic-surface-canvas-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.canvas.highlight": {
    "cssVariable": "--zx-semantic-surface-canvas-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.canvas.inner": {
    "cssVariable": "--zx-semantic-surface-canvas-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.canvas.on-text": {
    "cssVariable": "--zx-semantic-surface-canvas-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.canvas.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-canvas-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.canvas.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.card.depth": {
    "cssVariable": "--zx-semantic-surface-card-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.card.edge": {
    "cssVariable": "--zx-semantic-surface-card-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.card.fill": {
    "cssVariable": "--zx-semantic-surface-card-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.card.highlight": {
    "cssVariable": "--zx-semantic-surface-card-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.card.inner": {
    "cssVariable": "--zx-semantic-surface-card-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.card.on-text": {
    "cssVariable": "--zx-semantic-surface-card-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.card.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-card-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.card.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.elevated": {
    "cssVariable": "--zx-semantic-surface-elevated",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.surface.elevated",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.field.depth": {
    "cssVariable": "--zx-semantic-surface-field-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.field.edge": {
    "cssVariable": "--zx-semantic-surface-field-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.field.fill": {
    "cssVariable": "--zx-semantic-surface-field-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.field.highlight": {
    "cssVariable": "--zx-semantic-surface-field-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.field.inner": {
    "cssVariable": "--zx-semantic-surface-field-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.field.on-text": {
    "cssVariable": "--zx-semantic-surface-field-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.field.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-field-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.field.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.header.depth": {
    "cssVariable": "--zx-semantic-surface-header-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.header.edge": {
    "cssVariable": "--zx-semantic-surface-header-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.header.fill": {
    "cssVariable": "--zx-semantic-surface-header-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.header.highlight": {
    "cssVariable": "--zx-semantic-surface-header-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.header.inner": {
    "cssVariable": "--zx-semantic-surface-header-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.header.on-text": {
    "cssVariable": "--zx-semantic-surface-header-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.header.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-header-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.header.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.overlay.depth": {
    "cssVariable": "--zx-semantic-surface-overlay-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.overlay.edge": {
    "cssVariable": "--zx-semantic-surface-overlay-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.overlay.fill": {
    "cssVariable": "--zx-semantic-surface-overlay-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.overlay.highlight": {
    "cssVariable": "--zx-semantic-surface-overlay-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.overlay.inner": {
    "cssVariable": "--zx-semantic-surface-overlay-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.overlay.on-text": {
    "cssVariable": "--zx-semantic-surface-overlay-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.overlay.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-overlay-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.overlay.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.page": {
    "cssVariable": "--zx-semantic-surface-page",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.surface.page",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.panel.depth": {
    "cssVariable": "--zx-semantic-surface-panel-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.panel.edge": {
    "cssVariable": "--zx-semantic-surface-panel-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.panel.fill": {
    "cssVariable": "--zx-semantic-surface-panel-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.panel.highlight": {
    "cssVariable": "--zx-semantic-surface-panel-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.panel.inner": {
    "cssVariable": "--zx-semantic-surface-panel-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.panel.on-text": {
    "cssVariable": "--zx-semantic-surface-panel-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.panel.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-panel-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.panel.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.selected.depth": {
    "cssVariable": "--zx-semantic-surface-selected-depth",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.depth",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.selected.edge": {
    "cssVariable": "--zx-semantic-surface-selected-edge",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.edge",
    "typeId": "border",
    "typeMetadata": {
      "typeId": "border"
    }
  },
  "semantic.surface.selected.fill": {
    "cssVariable": "--zx-semantic-surface-selected-fill",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.fill",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.selected.highlight": {
    "cssVariable": "--zx-semantic-surface-selected-highlight",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.highlight",
    "typeId": "gradient",
    "typeMetadata": {
      "typeId": "gradient"
    }
  },
  "semantic.surface.selected.inner": {
    "cssVariable": "--zx-semantic-surface-selected-inner",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.inner",
    "typeId": "shadow",
    "typeMetadata": {
      "typeId": "shadow"
    }
  },
  "semantic.surface.selected.on-text": {
    "cssVariable": "--zx-semantic-surface-selected-on-text",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.on-text",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.surface.selected.on-text-secondary": {
    "cssVariable": "--zx-semantic-surface-selected-on-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.surface.selected.on-text-secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.text.disabled": {
    "cssVariable": "--zx-semantic-text-disabled",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.text.disabled",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.text.primary": {
    "cssVariable": "--zx-semantic-text-primary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.text.primary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.text.secondary": {
    "cssVariable": "--zx-semantic-text-secondary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "stable",
    "path": "semantic.text.secondary",
    "typeId": "color",
    "typeMetadata": {
      "typeId": "color"
    }
  },
  "semantic.typography.family": {
    "cssVariable": "--zx-semantic-typography-family",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.family",
    "typeId": "font-family",
    "typeMetadata": {
      "typeId": "font-family"
    }
  },
  "semantic.typography.line-height-base": {
    "cssVariable": "--zx-semantic-typography-line-height-base",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.line-height-base",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.size-base": {
    "cssVariable": "--zx-semantic-typography-size-base",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.size-base",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.size-extra-large": {
    "cssVariable": "--zx-semantic-typography-size-extra-large",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.size-extra-large",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.size-extra-small": {
    "cssVariable": "--zx-semantic-typography-size-extra-small",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.size-extra-small",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.size-large": {
    "cssVariable": "--zx-semantic-typography-size-large",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.size-large",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.size-medium": {
    "cssVariable": "--zx-semantic-typography-size-medium",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.size-medium",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.size-small": {
    "cssVariable": "--zx-semantic-typography-size-small",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.size-small",
    "typeId": "dimension",
    "typeMetadata": {
      "typeId": "dimension"
    }
  },
  "semantic.typography.weight-primary": {
    "cssVariable": "--zx-semantic-typography-weight-primary",
    "fields": {},
    "layer": "semantic",
    "lifecycle": "experimental",
    "path": "semantic.typography.weight-primary",
    "typeId": "font-weight",
    "typeMetadata": {
      "typeId": "font-weight"
    }
  }
})

export { axisDeclarations, publicTokensByPath, themeId, variantKeys }
