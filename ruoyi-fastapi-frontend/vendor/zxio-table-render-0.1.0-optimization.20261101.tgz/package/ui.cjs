"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const vue = require("vue");
const elementPlus = require("element-plus");
const gridList = require("@zxio/zxui/grid-list");
const listToolbar = require("@zxio/zxui/list-toolbar");
const moreAction = require("@zxio/zxui/more-action");
const button = require("@zxio/zxui/button");
const tooltipOrPopover = require("@zxio/zxui/tooltip-or-popover");
const columnState = require("./column-state-DMHr6VPq.js");
const schemaForm = require("@zxio/schema-form");
const fields = require("@zxio/schema-form/fields");
const input = require("@zxio/zxui/input");
const search = require("@zxio/zxui/search");
const select = require("@zxio/zxui/select");
const tag = require("@zxio/zxui/tag");
const themeProvider = require("@zxio/zxui/theme-provider");
const hooks = require("@zxio/zxui/hooks");
const _hoisted_1$5 = ["data-filter-key"];
const _hoisted_2$3 = ["id"];
const _sfc_main$5 = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "SearchField",
  props: {
    field: {},
    value: {},
    placement: {},
    error: {},
    resetEpoch: {},
    locale: {},
    options: {}
  },
  emits: ["commit", "pending", "confirm"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const id = `zx-table-filter-${vue.useId()}`;
    const logicalUi = vue.computed(
      () => props.field.fromLogical ? props.field.fromLogical(props.value) : props.value
    );
    const dateModel = vue.computed(
      () => logicalUi.value
    );
    const numberText = vue.shallowRef("");
    let lastNumber;
    vue.watch(
      [logicalUi, () => props.resetEpoch],
      ([value], previous) => {
        if (!previous || previous[1] !== props.resetEpoch || !schemaForm.equal(value, lastNumber))
          numberText.value = value == null ? "" : String(value);
        lastNumber = value;
      },
      { immediate: true }
    );
    function editNumber(edit) {
      numberText.value = edit.text;
      const parsed = fields.parseNumberText(edit.text);
      emit("pending", parsed.status === "invalid");
      if (parsed.status === "invalid") return;
      lastNumber = parsed.status === "valid" ? parsed.value : void 0;
      emit("commit", lastNumber);
    }
    function commit(value) {
      emit("pending", false);
      emit("commit", value);
    }
    const attrs = vue.computed(() => ({
      id,
      "aria-label": props.field.label,
      "aria-invalid": !!props.error,
      "aria-describedby": props.error ? `${id}-error` : void 0
    }));
    const state = vue.computed(() => props.options.state(props.field.options));
    const choices = vue.computed(
      () => props.field.control === "boolean" ? [
        { value: true, label: props.locale.yes },
        { value: false, label: props.locale.no }
      ] : state.value.options
    );
    const encode = (value) => value === void 0 ? void 0 : JSON.stringify(value);
    const selectOptions = vue.computed(
      () => choices.value.map((option) => ({ ...option, value: encode(option.value) }))
    );
    const selected = vue.computed(
      () => props.field.control === "multi-select" ? Array.isArray(logicalUi.value) ? logicalUi.value.map(encode) : [] : encode(logicalUi.value)
    );
    function select$1(value) {
      try {
        const decode = (token) => token === "" || token == null ? void 0 : JSON.parse(String(token));
        commit(Array.isArray(value) ? value.map(decode) : decode(value));
      } catch {
        emit("pending", true);
      }
    }
    function dateChanged(value) {
      if (props.field.control === "date-range" && Array.isArray(value) && value.some((part) => !part)) {
        emit("pending", true);
        return;
      }
      commit(value == null ? void 0 : value);
    }
    function calendarChanged(value) {
      if (props.field.control === "date-range")
        emit("pending", Array.isArray(value) && value.filter(Boolean).length === 1);
    }
    function dateEditing(state2) {
      var _a;
      emit("pending", !!state2.commitPending || !!((_a = state2.blocking) == null ? void 0 : _a.length));
    }
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        class: vue.normalizeClass(["zx-table-render__field", { "zx-table-render__field--range": __props.field.control === "date-range" }]),
        "data-filter-key": __props.field.key
      }, [
        vue.createElementVNode("label", {
          for: id,
          class: "zx-table-render__field-label"
        }, vue.toDisplayString(__props.field.label), 1),
        __props.placement === "keyword" ? (vue.openBlock(), vue.createBlock(vue.unref(search.ZxSearch), {
          key: 0,
          "input-attrs": attrs.value,
          "model-value": String(logicalUi.value ?? ""),
          placeholder: __props.field.placeholder ?? __props.field.label,
          "show-search-button": false,
          "onUpdate:modelValue": commit,
          onSearch: _cache[0] || (_cache[0] = ($event) => emit("confirm"))
        }, null, 8, ["input-attrs", "model-value", "placeholder"])) : __props.field.control === "text" ? (vue.openBlock(), vue.createBlock(vue.unref(input.ZxInput), vue.mergeProps({ key: 1 }, attrs.value, {
          "model-value": String(logicalUi.value ?? ""),
          placeholder: __props.field.placeholder,
          clearable: "",
          "onUpdate:modelValue": commit,
          onKeyup: _cache[1] || (_cache[1] = vue.withKeys(($event) => emit("confirm"), ["enter"]))
        }), null, 16, ["model-value", "placeholder"])) : __props.field.control === "number" ? (vue.openBlock(), vue.createBlock(vue.unref(fields.ZxNumberTextInput), vue.mergeProps({ key: 2 }, attrs.value, {
          text: numberText.value,
          placeholder: __props.field.placeholder,
          onEdit: editNumber,
          onKeyup: _cache[2] || (_cache[2] = vue.withKeys(($event) => emit("confirm"), ["enter"]))
        }), null, 16, ["text", "placeholder"])) : ["select", "multi-select", "boolean"].includes(String(__props.field.control)) ? (vue.openBlock(), vue.createBlock(vue.unref(select.ZxSelect), vue.mergeProps({ key: 3 }, attrs.value, {
          "model-value": selected.value,
          options: selectOptions.value,
          multiple: __props.field.control === "multi-select",
          placeholder: __props.field.placeholder ?? __props.locale.all,
          loading: state.value.status === "loading",
          error: state.value.status === "error" ? __props.locale.dictionaryUnavailable : void 0,
          clearable: "",
          "onUpdate:modelValue": select$1,
          onRetry: _cache[3] || (_cache[3] = ($event) => __props.field.options && __props.options.retry(__props.field.options))
        }), null, 16, ["model-value", "options", "multiple", "placeholder", "loading", "error"])) : __props.field.control === "date" || __props.field.control === "date-range" ? (vue.openBlock(), vue.createBlock(vue.unref(fields.ZxDateInput), vue.mergeProps({ key: __props.resetEpoch }, attrs.value, {
          style: { "width": "100%" },
          "model-value": dateModel.value,
          type: __props.field.control === "date" ? "date" : "daterange",
          "value-format": "YYYY-MM-DD",
          placeholder: __props.field.placeholder,
          clearable: "",
          "onUpdate:modelValue": dateChanged,
          onCalendarChange: calendarChanged,
          onEditState: dateEditing
        }), null, 16, ["model-value", "type", "placeholder"])) : vue.renderSlot(_ctx.$slots, "custom", {
          logicalValue: __props.value,
          value: logicalUi.value,
          commit,
          setPending: (value) => emit("pending", value),
          controlAttrs: attrs.value
        }, void 0, void 0, 5),
        __props.error ? (vue.openBlock(), vue.createElementBlock("span", {
          key: 6,
          id: `${id}-error`,
          class: "zx-table-render__field-error"
        }, vue.toDisplayString(__props.error), 9, _hoisted_2$3)) : vue.createCommentVNode("", true)
      ], 10, _hoisted_1$5);
    };
  }
});
const _hoisted_1$4 = ["onKeydown"];
const _hoisted_2$2 = ["id"];
const _hoisted_3$2 = { class: "zx-table-render__search-buttons" };
const _hoisted_4$2 = {
  key: 1,
  role: "alert",
  class: "zx-table-render__field-error"
};
const _hoisted_5$2 = {
  key: 2,
  class: "zx-table-render__dirty"
};
const _hoisted_6$2 = { role: "status" };
const _sfc_main$4 = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "SearchPanel",
  props: {
    search: {},
    options: {},
    locale: {},
    placement: {}
  },
  setup(__props) {
    const props = __props;
    const open = vue.shallowRef(false);
    const panel = vue.shallowRef();
    const trigger = vue.shallowRef();
    const panelId = `zx-table-filters-${vue.useId()}`;
    const visibleFields = vue.computed(
      () => props.search.located.filter(
        (entry) => entry.placement === (props.placement === "inline" ? "inline" : "keyword")
      )
    );
    const moreFields = vue.computed(
      () => props.search.located.filter((entry) => entry.placement === "more")
    );
    function error(field) {
      var _a;
      const issue = props.search.issues.value.find(
        (issue2) => issue2.path[0] === "query" && issue2.path[1] === field.key
      );
      return issue ? ((_a = field.messages) == null ? void 0 : _a[issue.code]) ?? (issue.code === "incomplete-input" ? props.locale.incomplete : props.locale.invalid) : void 0;
    }
    const generalError = vue.computed(
      () => props.search.issues.value.some(
        (issue) => issue.path[0] === "sort" || issue.path.length === 1
      )
    );
    async function show() {
      var _a, _b;
      open.value = true;
      await vue.nextTick();
      (_b = (_a = panel.value) == null ? void 0 : _a.querySelector('input,button,[tabindex="0"]')) == null ? void 0 : _b.focus();
    }
    function close() {
      var _a, _b;
      open.value = false;
      (_b = (_a = trigger.value) == null ? void 0 : _a.$el) == null ? void 0 : _b.focus();
    }
    async function apply() {
      await props.search.search();
      if (props.search.issues.value.length === 0) close();
    }
    const appliedLabels = vue.computed(
      () => props.search.located.filter(
        ({ field }) => {
          var _a;
          return Object.hasOwn(((_a = props.search.applied.value) == null ? void 0 : _a.query) ?? {}, field.key);
        }
      ).map(({ field }) => {
        var _a;
        const value = (_a = props.search.applied.value) == null ? void 0 : _a.query[field.key];
        const options = props.options.state(field.options).options;
        const label = (item) => {
          var _a2;
          return ((_a2 = columnState.optionFor(item, options)) == null ? void 0 : _a2.label) ?? columnState.textValue(item);
        };
        return {
          key: field.key,
          label: field.label,
          value: Array.isArray(value) ? value.map(label).join(", ") : label(value)
        };
      })
    );
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        class: vue.normalizeClass(
          __props.placement === "inline" ? "zx-table-render__filters" : "zx-table-render__search"
        )
      }, [
        (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(visibleFields.value, (entry) => {
          return vue.openBlock(), vue.createBlock(_sfc_main$5, {
            key: entry.field.key,
            field: entry.field,
            placement: entry.placement,
            value: __props.search.draft.value[entry.field.key],
            error: error(entry.field),
            "reset-epoch": __props.search.resetEpoch.value,
            options: __props.options,
            locale: __props.locale,
            onCommit: ($event) => __props.search.commit(entry.field, $event),
            onPending: ($event) => __props.search.setPending(entry.field.key, $event),
            onConfirm: __props.search.search
          }, {
            custom: vue.withCtx((context) => [
              vue.renderSlot(_ctx.$slots, `search-${entry.field.key}`, vue.mergeProps({ ref_for: true }, context))
            ]),
            _: 2
          }, 1032, ["field", "placement", "value", "error", "reset-epoch", "options", "locale", "onCommit", "onPending", "onConfirm"]);
        }), 128)),
        __props.placement === "search" ? (vue.openBlock(), vue.createElementBlock(vue.Fragment, { key: 0 }, [
          moreFields.value.length ? (vue.openBlock(), vue.createBlock(vue.unref(tooltipOrPopover.ZxTooltipOrPopover), {
            key: 0,
            variant: "popover",
            role: "dialog",
            "aria-label": __props.locale.more,
            trigger: "click",
            visible: open.value,
            placement: "bottom-end",
            width: 360,
            "popper-style": { maxWidth: "calc(100vw - 24px)" },
            persistent: ""
          }, {
            reference: vue.withCtx(() => [
              vue.createVNode(vue.unref(button.ZxButton), {
                ref_key: "trigger",
                ref: trigger,
                onClick: _cache[0] || (_cache[0] = ($event) => open.value ? close() : show())
              }, {
                default: vue.withCtx(() => [
                  vue.createTextVNode(vue.toDisplayString(__props.locale.more), 1)
                ]),
                _: 1
              }, 512)
            ]),
            content: vue.withCtx(() => [
              vue.createElementVNode("div", {
                id: panelId,
                ref_key: "panel",
                ref: panel,
                class: "zx-table-render__more",
                onKeydown: vue.withKeys(vue.withModifiers(close, ["stop", "prevent"]), ["esc"])
              }, [
                vue.createElementVNode("h2", {
                  id: `${panelId}-title`,
                  class: "zx-table-render__more-title"
                }, vue.toDisplayString(__props.locale.more), 9, _hoisted_2$2),
                (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(moreFields.value, (entry) => {
                  return vue.openBlock(), vue.createBlock(_sfc_main$5, {
                    key: entry.field.key,
                    field: entry.field,
                    placement: "more",
                    value: __props.search.draft.value[entry.field.key],
                    error: error(entry.field),
                    "reset-epoch": __props.search.resetEpoch.value,
                    options: __props.options,
                    locale: __props.locale,
                    onCommit: ($event) => __props.search.commit(entry.field, $event),
                    onPending: ($event) => __props.search.setPending(entry.field.key, $event),
                    onConfirm: apply
                  }, {
                    custom: vue.withCtx((context) => [
                      vue.renderSlot(_ctx.$slots, `search-${entry.field.key}`, vue.mergeProps({ ref_for: true }, context))
                    ]),
                    _: 2
                  }, 1032, ["field", "value", "error", "reset-epoch", "options", "locale", "onCommit", "onPending"]);
                }), 128)),
                vue.createElementVNode("div", _hoisted_3$2, [
                  vue.createVNode(vue.unref(button.ZxButton), {
                    type: "primary",
                    onClick: apply
                  }, {
                    default: vue.withCtx(() => [
                      vue.createTextVNode(vue.toDisplayString(__props.locale.apply), 1)
                    ]),
                    _: 1
                  }),
                  vue.createVNode(vue.unref(button.ZxButton), { onClick: close }, {
                    default: vue.withCtx(() => [
                      vue.createTextVNode(vue.toDisplayString(__props.locale.close), 1)
                    ]),
                    _: 1
                  })
                ])
              ], 40, _hoisted_1$4)
            ]),
            _: 3
          }, 8, ["aria-label", "visible"])) : vue.createCommentVNode("", true),
          vue.createVNode(vue.unref(button.ZxButton), {
            type: "primary",
            onClick: __props.search.search
          }, {
            default: vue.withCtx(() => [
              vue.createTextVNode(vue.toDisplayString(__props.locale.search), 1)
            ]),
            _: 1
          }, 8, ["onClick"]),
          vue.createVNode(vue.unref(button.ZxButton), {
            onClick: __props.search.reset
          }, {
            default: vue.withCtx(() => [
              vue.createTextVNode(vue.toDisplayString(__props.locale.reset), 1)
            ]),
            _: 1
          }, 8, ["onClick"]),
          generalError.value ? (vue.openBlock(), vue.createElementBlock("span", _hoisted_4$2, vue.toDisplayString(__props.locale.invalid), 1)) : vue.createCommentVNode("", true),
          __props.search.dirty.value ? (vue.openBlock(), vue.createElementBlock("details", _hoisted_5$2, [
            vue.createElementVNode("summary", null, [
              vue.createElementVNode("span", _hoisted_6$2, vue.toDisplayString(__props.locale.dirty), 1)
            ]),
            vue.createElementVNode("div", null, vue.toDisplayString(__props.locale.applied), 1),
            vue.createElementVNode("dl", null, [
              (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(appliedLabels.value, (field) => {
                return vue.openBlock(), vue.createElementBlock(vue.Fragment, {
                  key: field.key
                }, [
                  vue.createElementVNode("dt", null, vue.toDisplayString(field.label), 1),
                  vue.createElementVNode("dd", null, vue.toDisplayString(field.value), 1)
                ], 64);
              }), 128))
            ])
          ])) : vue.createCommentVNode("", true)
        ], 64)) : vue.createCommentVNode("", true)
      ], 2);
    };
  }
});
const _hoisted_1$3 = ["aria-label"];
const _sfc_main$3 = /* @__PURE__ */ vue.defineComponent({
  __name: "RowActions",
  props: {
    row: {},
    actions: {},
    limit: {},
    label: {}
  },
  setup(__props) {
    const props = __props;
    const groups = vue.computed(() => {
      const all = props.actions.rowActions(props.row);
      const inline = all.filter((action) => !action.overflow).slice(0, props.limit);
      const overflow = all.filter((action) => !inline.includes(action)).map((action) => ({
        label: action.label,
        eventTag: action.id,
        disabled: action.disabled,
        danger: action.tone === "danger",
        icon: action.icon
      }));
      return { inline, overflow };
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        class: "zx-table-render__row-actions",
        role: "group",
        "aria-label": __props.label
      }, [
        (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(groups.value.inline, (action) => {
          return vue.openBlock(), vue.createBlock(vue.unref(button.ZxButton), {
            key: action.id,
            link: "",
            type: action.tone,
            icon: action.icon,
            loading: action.loading,
            disabled: action.disabled,
            "data-zx-action-id": action.id,
            onClick: ($event) => __props.actions.run(action.id, __props.row)
          }, {
            default: vue.withCtx(() => [
              vue.createTextVNode(vue.toDisplayString(action.label), 1)
            ]),
            _: 2
          }, 1032, ["type", "icon", "loading", "disabled", "data-zx-action-id", "onClick"]);
        }), 128)),
        groups.value.overflow.length ? (vue.openBlock(), vue.createBlock(vue.unref(moreAction.ZxMoreAction), {
          key: 0,
          list: groups.value.overflow,
          trigger: "click",
          onSelect: _cache[0] || (_cache[0] = ($event) => $event.eventTag && __props.actions.run($event.eventTag, __props.row))
        }, {
          default: vue.withCtx(() => [
            vue.createVNode(vue.unref(button.ZxButton), {
              link: "",
              "aria-label": __props.label
            }, {
              default: vue.withCtx(() => [
                vue.createTextVNode(vue.toDisplayString(__props.label), 1)
              ]),
              _: 1
            }, 8, ["aria-label"])
          ]),
          _: 1
        }, 8, ["list"])) : vue.createCommentVNode("", true)
      ], 8, _hoisted_1$3);
    };
  }
});
const TableCell = ({ column, row, index, options, locale }, { slots }) => {
  if (index < 0) return null;
  const value = "value" in column && column.value ? column.value(row) : columnState.readColumnValue(row, "prop" in column ? column.prop : void 0);
  const context = { row, column, value, index };
  if (slots.default) return slots.default(context);
  if ("render" in column && column.render) return column.render(context);
  const state = column.type === "enum" ? options.state(column.options) : void 0;
  const option = state && columnState.optionFor(value, state.options);
  const text = column.type === "boolean" && !column.labels ? value === true ? locale.yes : value === false ? locale.no : columnState.formatColumnValue(column, value) : columnState.formatColumnValue(column, value, state == null ? void 0 : state.options);
  const content = column.type === "enum" && column.tag && option ? vue.h(
    tag.ZxTag,
    { type: option.tone === "default" ? void 0 : option.tone },
    () => text
  ) : vue.h("span", text);
  return state && state.status !== "loaded" ? [
    content,
    vue.h(
      "span",
      { class: "zx-table-render__sr-only" },
      locale.dictionaryUnavailable
    )
  ] : content;
};
TableCell.props = ["column", "row", "index", "options", "locale"];
TableCell.inheritAttrs = false;
TableCell.displayName = "TableCell";
const _hoisted_1$2 = ["aria-label", "checked", "disabled", "indeterminate"];
const _sfc_main$2 = /* @__PURE__ */ vue.defineComponent({
  __name: "StateCheckbox",
  props: {
    checked: { type: Boolean },
    label: {},
    disabled: { type: Boolean },
    indeterminate: { type: Boolean }
  },
  emits: ["change"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const input2 = vue.shallowRef();
    async function changed(event) {
      emit("change", event.target.checked);
      await vue.nextTick();
      if (input2.value) input2.value.checked = props.checked;
    }
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("input", {
        ref_key: "input",
        ref: input2,
        type: "checkbox",
        "aria-label": __props.label,
        checked: __props.checked,
        disabled: __props.disabled,
        indeterminate: __props.indeterminate,
        onClick: _cache[0] || (_cache[0] = vue.withModifiers(() => {
        }, ["stop"])),
        onChange: changed
      }, null, 40, _hoisted_1$2);
    };
  }
});
const _hoisted_1$1 = ["onKeydown"];
const _hoisted_2$1 = { class: "zx-table-render__more-title" };
const _hoisted_3$1 = ["aria-label", "min", "max", "value", "onChange"];
const _hoisted_4$1 = ["aria-label", "value", "onChange"];
const _hoisted_5$1 = { value: "" };
const _hoisted_6$1 = { value: "left" };
const _hoisted_7 = { value: "right" };
const _hoisted_8 = ["aria-label", "aria-disabled", "onClick"];
const _hoisted_9 = ["aria-label", "aria-disabled", "onClick"];
const _hoisted_10 = { class: "zx-table-render__search-buttons" };
const _sfc_main$1 = /* @__PURE__ */ vue.defineComponent({
  __name: "ColumnSettings",
  props: {
    columns: {},
    state: {},
    locale: {}
  },
  emits: ["patch", "move", "reset"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const open = vue.shallowRef(false);
    const panel = vue.shallowRef();
    const trigger = vue.shallowRef();
    const label = (key) => {
      var _a;
      return ((_a = props.columns.find((column) => column.key === key)) == null ? void 0 : _a.label) ?? key;
    };
    const required = (key) => {
      var _a;
      return ((_a = props.columns.find((column) => column.key === key)) == null ? void 0 : _a.hideable) === false;
    };
    const widthBounds = (key) => columnState.columnWidthBounds(props.columns.find((column) => column.key === key));
    async function show() {
      var _a, _b;
      open.value = true;
      await vue.nextTick();
      (_b = (_a = panel.value) == null ? void 0 : _a.querySelector("input,button")) == null ? void 0 : _b.focus();
    }
    function close() {
      var _a, _b;
      open.value = false;
      (_b = (_a = trigger.value) == null ? void 0 : _a.$el) == null ? void 0 : _b.focus();
    }
    async function fixedChanged(key, event) {
      var _a;
      const input2 = event.target;
      emit("patch", key, {
        fixed: input2.value || null
      });
      await vue.nextTick();
      input2.value = ((_a = props.state.columns.find((entry) => entry.key === key)) == null ? void 0 : _a.fixed) ?? "";
    }
    async function widthChanged(key, event) {
      var _a;
      const input2 = event.target;
      emit("patch", key, {
        width: input2.value === "" ? void 0 : Number(input2.value)
      });
      await vue.nextTick();
      input2.value = String(
        ((_a = props.state.columns.find((entry) => entry.key === key)) == null ? void 0 : _a.width) ?? ""
      );
    }
    async function move(key, offset, event) {
      const button2 = event.currentTarget;
      const index = props.state.columns.findIndex((entry) => entry.key === key);
      if (index + offset < 0 || index + offset >= props.state.columns.length) return;
      emit("move", key, offset);
      await vue.nextTick();
      button2.focus();
    }
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(tooltipOrPopover.ZxTooltipOrPopover), {
        variant: "popover",
        role: "dialog",
        "aria-label": __props.locale.columns,
        trigger: "click",
        visible: open.value,
        placement: "bottom-end",
        width: 420,
        "popper-style": { maxWidth: "calc(100vw - 24px)" }
      }, {
        reference: vue.withCtx(() => [
          vue.createVNode(vue.unref(button.ZxButton), {
            ref_key: "trigger",
            ref: trigger,
            "aria-expanded": open.value,
            onClick: _cache[0] || (_cache[0] = ($event) => open.value ? close() : show())
          }, {
            default: vue.withCtx(() => [
              vue.createTextVNode(vue.toDisplayString(__props.locale.columns), 1)
            ]),
            _: 1
          }, 8, ["aria-expanded"])
        ]),
        content: vue.withCtx(() => [
          vue.createElementVNode("div", {
            ref_key: "panel",
            ref: panel,
            class: "zx-table-render__columns",
            onKeydown: vue.withKeys(vue.withModifiers(close, ["stop", "prevent"]), ["esc"])
          }, [
            vue.createElementVNode("h2", _hoisted_2$1, vue.toDisplayString(__props.locale.columns), 1),
            (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(__props.state.columns, (entry, index) => {
              return vue.openBlock(), vue.createElementBlock("div", {
                key: entry.key,
                class: "zx-table-render__column-setting"
              }, [
                vue.createElementVNode("label", null, [
                  vue.createVNode(_sfc_main$2, {
                    label: label(entry.key),
                    checked: entry.visible !== false,
                    disabled: required(entry.key),
                    onChange: ($event) => emit("patch", entry.key, { visible: $event })
                  }, null, 8, ["label", "checked", "disabled", "onChange"]),
                  vue.createTextVNode(vue.toDisplayString(label(entry.key)), 1)
                ]),
                vue.createElementVNode("input", {
                  type: "number",
                  "aria-label": `${label(entry.key)} ${__props.locale.width}`,
                  min: widthBounds(entry.key).min,
                  max: widthBounds(entry.key).max,
                  value: entry.width,
                  onChange: ($event) => widthChanged(entry.key, $event)
                }, null, 40, _hoisted_3$1),
                vue.createElementVNode("select", {
                  "aria-label": `${label(entry.key)} ${__props.locale.pin}`,
                  value: entry.fixed ?? "",
                  onChange: ($event) => fixedChanged(entry.key, $event)
                }, [
                  vue.createElementVNode("option", _hoisted_5$1, vue.toDisplayString(__props.locale.unpinned), 1),
                  vue.createElementVNode("option", _hoisted_6$1, vue.toDisplayString(__props.locale.left), 1),
                  vue.createElementVNode("option", _hoisted_7, vue.toDisplayString(__props.locale.right), 1)
                ], 40, _hoisted_4$1),
                vue.createElementVNode("button", {
                  type: "button",
                  "aria-label": `${__props.locale.moveUp} ${label(entry.key)} (${index + 1}/${__props.state.columns.length})`,
                  "aria-disabled": index === 0,
                  onClick: ($event) => move(entry.key, -1, $event)
                }, " ↑ ", 8, _hoisted_8),
                vue.createElementVNode("button", {
                  type: "button",
                  "aria-label": `${__props.locale.moveDown} ${label(entry.key)} (${index + 1}/${__props.state.columns.length})`,
                  "aria-disabled": index === __props.state.columns.length - 1,
                  onClick: ($event) => move(entry.key, 1, $event)
                }, " ↓ ", 8, _hoisted_9)
              ]);
            }), 128)),
            vue.createElementVNode("div", _hoisted_10, [
              vue.createVNode(vue.unref(button.ZxButton), {
                onClick: _cache[1] || (_cache[1] = ($event) => emit("reset"))
              }, {
                default: vue.withCtx(() => [
                  vue.createTextVNode(vue.toDisplayString(__props.locale.resetColumns), 1)
                ]),
                _: 1
              }),
              vue.createVNode(vue.unref(button.ZxButton), { onClick: close }, {
                default: vue.withCtx(() => [
                  vue.createTextVNode(vue.toDisplayString(__props.locale.close), 1)
                ]),
                _: 1
              })
            ])
          ], 40, _hoisted_1$1)
        ]),
        _: 1
      }, 8, ["aria-label", "visible"]);
    };
  }
});
function locateSearchFields(definition) {
  let inlineCount = 0;
  return (definition.search ?? []).map((field) => {
    var _a;
    const standardInline = typeof field.control === "string" && !["text", "number"].includes(field.control);
    let placement = field.placement ?? (standardInline ? "inline" : "more");
    if (placement === "inline" && inlineCount++ >= (((_a = definition.layout) == null ? void 0 : _a.inlineLimit) ?? 3))
      placement = "more";
    const trigger = placement === "more" ? "confirm" : field.trigger ?? (standardInline ? "change" : "confirm");
    return { field, placement, trigger };
  });
}
function useSearch(options) {
  var _a;
  let alive = true;
  vue.onScopeDispose(() => {
    alive = false;
  });
  const defaults = {
    query: columnState.defaultQuery(options.definition),
    sort: ((_a = options.definition.sort) == null ? void 0 : _a.default) ?? []
  };
  const validator = columnState.buildQueryValidator(options.definition);
  const pending = vue.reactive(/* @__PURE__ */ new Set());
  const resetEpoch = vue.shallowRef(0);
  const issues = vue.shallowRef([]);
  const located = locateSearchFields(options.definition);
  const draft = vue.computed(() => {
    const grid = options.grid();
    return (grid == null ? void 0 : grid.mode) === "request" ? grid.draft : options.query();
  });
  const applied = vue.computed(() => {
    const grid = options.grid();
    return (grid == null ? void 0 : grid.mode) === "request" ? grid.applied && { ...grid.applied, domainKey: options.domainKey() } : options.applied();
  });
  const controlledRevision = vue.shallowRef(0);
  if (!options.definition.request)
    vue.watch(options.query, () => controlledRevision.value++, {
      deep: true,
      flush: "sync"
    });
  const dirty = vue.computed(() => {
    if (!options.definition.request && !applied.value) return false;
    if (pending.size) return true;
    const grid = options.grid();
    if ((grid == null ? void 0 : grid.mode) === "request") return grid.dirty;
    vue.unref(controlledRevision);
    try {
      return applied.value !== null && !schemaForm.equal(columnState.normalizeQuery(draft.value), applied.value.query);
    } catch {
      return true;
    }
  });
  const draftHold = () => pending.size > 0;
  function setDraft(value, config) {
    const next = columnState.normalizeQuery(
      (config == null ? void 0 : config.replace) ? value : { ...draft.value, ...value }
    );
    const grid = options.grid();
    if ((grid == null ? void 0 : grid.mode) === "request") grid.setDraft(next, { replace: true });
    else if (!options.definition.request) options.update(next);
  }
  function rejected(errors) {
    issues.value = errors;
    return { kind: "not-started", reason: "invalid-input", issues: errors };
  }
  async function submit(type, explicit) {
    var _a2;
    if (explicit && pending.size)
      return rejected(
        [...pending].slice(0, 32).map((key) => ({ path: ["query", key], code: "incomplete-input" }))
      );
    let query;
    try {
      query = type === "reset" ? defaults.query : columnState.normalizeQuery(draft.value);
    } catch {
      return rejected([{ path: ["query"], code: "invalid-input" }]);
    }
    const sort = type === "reset" ? defaults.sort : ((_a2 = applied.value) == null ? void 0 : _a2.sort) ?? defaults.sort;
    const errors = validator({ query, sort });
    if (errors) return rejected(errors);
    issues.value = [];
    const grid = options.grid();
    if ((grid == null ? void 0 : grid.mode) === "request") {
      const result2 = await grid[type]();
      if (result2.kind === "not-started") issues.value = result2.issues ?? [];
      return result2;
    }
    if (options.definition.request)
      return { kind: "not-started", reason: "not-ready" };
    const result = options.intent(type, query);
    if (type === "reset" && result.kind === "intent-emitted")
      options.update(defaults.query);
    return result;
  }
  function clearEditing() {
    pending.clear();
    issues.value = [];
    resetEpoch.value++;
  }
  async function reset() {
    clearEditing();
    return submit("reset", true);
  }
  async function commit(field, ui) {
    var _a2;
    const epoch = resetEpoch.value;
    try {
      const value = field.toLogical ? field.toLogical(ui) : ui;
      setDraft({ [field.key]: value });
      pending.delete(field.key);
      issues.value = issues.value.filter((issue) => issue.path[1] !== field.key);
    } catch {
      pending.add(field.key);
      return rejected([{ path: ["query", field.key], code: "invalid-value" }]);
    }
    if (((_a2 = located.find((entry) => entry.field.key === field.key)) == null ? void 0 : _a2.trigger) === "change") {
      await vue.nextTick();
      if (!alive || epoch !== resetEpoch.value)
        return { kind: "not-started", reason: "domain-changed" };
      return submit("search", false);
    }
  }
  return {
    defaults,
    validator,
    draft,
    applied,
    dirty,
    issues,
    pending,
    resetEpoch,
    located,
    draftHold,
    setDraft,
    commit,
    reset,
    clearEditing,
    setPending(key, value) {
      if (value) pending.add(key);
      else pending.delete(key);
    },
    search: () => submit("search", true)
  };
}
function useOptions(definition, domain) {
  const store = columnState.createOptionsStore();
  const current = vue.shallowRef(store);
  const unsubscribe = store.subscribe(() => vue.triggerRef(current));
  const sources = [
    ...(definition.search ?? []).map((field) => field.options),
    ...definition.columns.map(
      (column) => column.type === "enum" ? column.options : void 0
    )
  ].filter((source) => source !== void 0);
  const remotes = /* @__PURE__ */ new Map();
  for (const source of sources) {
    store.get(source);
    if (!Array.isArray(source))
      remotes.set(source.key, source);
  }
  const snapshot = (source) => {
    var _a;
    if (!domain.ready()) return { kind: "unavailable" };
    try {
      const params = (_a = source.params) == null ? void 0 : _a.call(source);
      return {
        kind: "ready",
        identity: {
          domainKey: domain.key(),
          epoch: domain.epoch(),
          ...params === void 0 ? {} : { params: schemaForm.copy(params) }
        }
      };
    } catch {
      return { kind: "invalid" };
    }
  };
  function load(source, value, force = false) {
    if (value.kind === "ready") return store.load(source, value.identity, force);
    if (value.kind === "invalid")
      return Promise.resolve(store.fail(source, "invalid-params"));
    store.invalidate(source);
    return Promise.resolve({ kind: "obsolete", sourceKey: source.key });
  }
  for (const source of remotes.values()) {
    vue.watch(
      () => snapshot(source),
      (value) => {
        load(source, value);
      },
      { immediate: true, flush: "sync", deep: true }
    );
  }
  vue.onScopeDispose(() => {
    unsubscribe();
    store.dispose();
  });
  const failed = vue.computed(
    () => [...remotes.values()].filter(
      (source) => current.value.get(source).status === "error"
    )
  );
  return {
    failed,
    retryFailed: () => Promise.all(
      failed.value.map((source) => load(source, snapshot(source), true))
    ),
    state(source) {
      return source ? current.value.get(source) : { status: "loaded", options: [] };
    },
    retry(source) {
      if (Array.isArray(source) || !domain.ready() || store.get(source).status !== "error")
        return;
      return load(source, snapshot(source), true);
    },
    refresh(sourceKey) {
      return Promise.all(
        [...remotes.values()].filter(
          (source) => sourceKey === void 0 || source.key === sourceKey
        ).map((source) => load(source, snapshot(source), true))
      );
    }
  };
}
function encodeRowKey(key) {
  return typeof key === "number" ? `n:${key === 0 ? 0 : key}` : `s:${key}`;
}
function useRowIdentity(options) {
  const fallback = /* @__PURE__ */ new WeakMap();
  let sequence = 0;
  function rowKey(row) {
    try {
      const value = typeof options.rowKey === "function" ? options.rowKey(row) : columnState.readColumnValue(row, options.rowKey);
      return typeof value === "string" || typeof value === "number" && Number.isFinite(value) ? value : void 0;
    } catch {
      return void 0;
    }
  }
  const index = vue.computed(() => {
    const rows = [];
    const positions = /* @__PURE__ */ new WeakMap();
    const byKey = /* @__PURE__ */ new Map();
    const seen = /* @__PURE__ */ new Set();
    const duplicates = /* @__PURE__ */ new Set();
    let invalid = false;
    let unsafeStructure = false;
    function visit(list) {
      for (const row of list) {
        if (!row || typeof row !== "object" || seen.has(row)) {
          invalid = true;
          unsafeStructure = true;
          continue;
        }
        seen.add(row);
        rows.push(row);
        positions.set(vue.toRaw(row), rows.length);
        const key = rowKey(row);
        if (key === void 0) {
          if (options.required()) invalid = true;
        } else if (byKey.has(key)) {
          duplicates.add(key);
          invalid = true;
        } else byKey.set(key, row);
        const children = options.children ? columnState.readColumnValue(row, options.children) : void 0;
        if (children !== void 0) {
          if (Array.isArray(children)) visit(children);
          else invalid = true;
        }
      }
    }
    visit(options.rows());
    return {
      rows,
      positions,
      byKey,
      invalid,
      unsafeStructure,
      duplicates: [...duplicates]
    };
  });
  vue.watch(
    index,
    (value) => {
      if (value.invalid)
        options.error({
          code: value.duplicates.length ? "duplicate-row-key" : "invalid-row-identity",
          keys: value.duplicates
        });
    },
    { immediate: true, flush: "sync" }
  );
  function tableKey(row) {
    const key = rowKey(row);
    if (key !== void 0 && !index.value.invalid) return encodeRowKey(key);
    if (!fallback.has(row)) fallback.set(row, `invalid:${++sequence}`);
    return fallback.get(row);
  }
  return { index, rowKey, tableKey };
}
let scopeSequence = 0;
function createScopeRef() {
  return `table-scope:${++scopeSequence}`;
}
function useSelection(options) {
  const controlled = options.state() !== void 0;
  const local = vue.shallowRef([]);
  const scopeRef = vue.shallowRef(createScopeRef());
  let initialized = false;
  let condition = null;
  let domain = options.domain();
  let session = options.scopeKey();
  let defaultsAvailable = true;
  let alive = true;
  let restoring = false;
  let revision = 0;
  const byKey = vue.computed(
    () => new Map(options.rows().map((row) => [options.rowKey(row), row]))
  );
  const raw = vue.computed(
    () => {
      var _a;
      return controlled ? ((_a = options.state()) == null ? void 0 : _a.scopeRef) === scopeRef.value ? options.state().keys : [] : local.value;
    }
  );
  function normalize(keys2) {
    if (!options.enabled || options.invalid() || options.scope === "explicit" && !options.scopeKey() || options.scope === "page" && !options.displayed())
      return [];
    return [...new Set(keys2)].filter((key) => {
      if (typeof key !== "string" && !(typeof key === "number" && Number.isFinite(key)))
        return false;
      const row = byKey.value.get(key);
      return row ? options.selectable(row) : options.scope === "explicit";
    });
  }
  const keys = vue.computed(() => normalize(raw.value));
  const selection = vue.computed(
    () => Object.freeze({
      scope: options.scope,
      scopeRef: scopeRef.value,
      keys: Object.freeze(keys.value),
      loadedRows: Object.freeze(
        keys.value.flatMap((key) => {
          const row = byKey.value.get(key);
          return row ? [row] : [];
        })
      ),
      missingKeys: Object.freeze(
        keys.value.filter((key) => !byKey.value.has(key))
      )
    })
  );
  function publish(next, force = false) {
    const value = Object.freeze({
      scopeRef: scopeRef.value,
      keys: Object.freeze(normalize(next))
    });
    if (!force && schemaForm.equal(value.keys, raw.value)) return;
    if (!controlled) local.value = value.keys;
    options.update(value);
  }
  vue.watch(
    [options.domain, options.scopeKey],
    ([nextDomain, nextSession]) => {
      if (nextDomain === domain && (options.scope !== "explicit" || nextSession === session))
        return;
      domain = nextDomain;
      session = nextSession;
      condition = null;
      defaultsAvailable = false;
      scopeRef.value = createScopeRef();
      publish([], true);
    },
    { flush: "sync" }
  );
  vue.watch(
    [
      options.domain,
      options.scopeKey,
      () => {
        var _a;
        return ((_a = options.displayed()) == null ? void 0 : _a.input) ?? null;
      }
    ],
    ([nextDomain, nextSession, input2]) => {
      const domainChanged = nextDomain !== domain;
      const sessionChanged = nextSession !== session;
      const changed = !initialized || domainChanged || (options.scope === "explicit" ? sessionChanged : !schemaForm.equal(condition, input2));
      if (!changed) return;
      if (initialized) scopeRef.value = createScopeRef();
      if (domainChanged || sessionChanged) defaultsAvailable = false;
      domain = nextDomain;
      session = nextSession;
      condition = schemaForm.copy(input2);
      initialized = true;
      const canApply = options.scope === "explicit" || input2 !== null;
      const initial = !controlled && defaultsAvailable && canApply ? options.defaults : [];
      if (canApply) defaultsAvailable = false;
      publish(initial, true);
    },
    { immediate: true, flush: "post" }
  );
  vue.watch(
    [raw, byKey, () => keys.value],
    () => {
      if (!schemaForm.equal(keys.value, raw.value)) publish(keys.value);
    },
    { flush: "sync" }
  );
  vue.watch(selection, (value) => options.change(value), { flush: "post" });
  vue.watch(
    [keys, byKey, options.table, options.domain],
    async () => {
      const turn = ++revision;
      await vue.nextTick();
      if (!alive || turn !== revision) return;
      restoring = true;
      try {
        const table = options.table();
        table == null ? void 0 : table.clearSelection();
        for (const key of keys.value) {
          const row = byKey.value.get(key);
          if (row) table == null ? void 0 : table.toggleRowSelection(row, true, false);
        }
      } finally {
        restoring = false;
      }
    },
    { immediate: true, flush: "post" }
  );
  function toggle(row, checked) {
    if (restoring || options.invalid() || !options.selectable(row)) return;
    const key = options.rowKey(row);
    if (key === void 0) return;
    const next = new Set(keys.value);
    if (checked) next.add(key);
    else next.delete(key);
    publish([...next]);
  }
  function toggleAll(checked) {
    if (restoring) return;
    const next = new Set(keys.value);
    for (const row of options.rows()) {
      const key = options.rowKey(row);
      if (key === void 0 || !options.selectable(row)) continue;
      if (checked) next.add(key);
      else next.delete(key);
    }
    publish([...next]);
  }
  vue.onScopeDispose(() => {
    alive = false;
    revision++;
  });
  return {
    selection,
    toggle,
    toggleAll,
    checked: (row) => keys.value.includes(options.rowKey(row)),
    clear: () => publish([]),
    setKeys: (keys2) => publish(keys2),
    select: (selection2, row) => toggle(row, selection2.includes(row)),
    selectAll: (selection2) => toggleAll(selection2.length > 0)
  };
}
function useExpansion(options) {
  const controlled = options.state() !== void 0;
  const local = vue.shallowRef([]);
  const scopeRef = vue.shallowRef(createScopeRef());
  let initialized = false;
  let domain = options.domain();
  let condition = null;
  let restoring = false;
  let alive = true;
  let revision = 0;
  vue.onScopeDispose(() => {
    alive = false;
    revision++;
  });
  const available = vue.computed(
    () => new Set(options.expandable().map(options.rowKey))
  );
  const raw = vue.computed(
    () => {
      var _a;
      return controlled ? ((_a = options.state()) == null ? void 0 : _a.scopeRef) === scopeRef.value ? options.state().keys : [] : local.value;
    }
  );
  const normalize = (keys2) => options.enabled && !options.invalid() && options.displayed() ? [...new Set(keys2)].filter((key) => available.value.has(key)) : [];
  const keys = vue.computed(() => normalize(raw.value));
  function publish(value, force = false) {
    const next = Object.freeze({
      scopeRef: scopeRef.value,
      keys: Object.freeze(normalize(value))
    });
    if (!force && schemaForm.equal(next.keys, raw.value)) return;
    if (!controlled) local.value = next.keys;
    options.update(next);
  }
  vue.watch(
    options.domain,
    (next) => {
      if (next === domain) return;
      domain = next;
      condition = null;
      scopeRef.value = createScopeRef();
      publish([], true);
    },
    { flush: "sync" }
  );
  vue.watch(
    [options.domain, () => {
      var _a;
      return ((_a = options.displayed()) == null ? void 0 : _a.input) ?? null;
    }],
    ([nextDomain, input2]) => {
      if (initialized && domain === nextDomain && schemaForm.equal(condition, input2))
        return;
      if (initialized) scopeRef.value = createScopeRef();
      domain = nextDomain;
      condition = schemaForm.copy(input2);
      initialized = true;
      const defaults = input2 ? options.defaultAll ? [...available.value].filter(
        (key) => key !== void 0
      ) : options.defaults : [];
      publish(defaults, true);
    },
    { immediate: true, flush: "post" }
  );
  vue.watch(
    [raw, available, keys],
    () => {
      if (!schemaForm.equal(keys.value, raw.value)) publish(keys.value);
    },
    { flush: "sync" }
  );
  async function restore() {
    var _a;
    const turn = ++revision;
    await vue.nextTick();
    if (!alive || turn !== revision) return;
    restoring = true;
    try {
      for (const row of options.expandable())
        (_a = options.table()) == null ? void 0 : _a.toggleRowExpansion(row, keys.value.includes(options.rowKey(row)));
    } finally {
      restoring = false;
    }
  }
  vue.watch([keys, available, options.table, options.domain], restore, {
    immediate: true,
    flush: "post"
  });
  return {
    keys,
    encoded: vue.computed(() => keys.value.map(encodeRowKey)),
    setKeys: (value) => publish(value),
    toggle(row, expanded) {
      if (restoring) return;
      const key = options.rowKey(row);
      if (key === void 0) return;
      publish(
        expanded ? [...keys.value, key] : keys.value.filter((value) => value !== key)
      );
      restore();
    }
  };
}
function useColumns(options) {
  const controlled = options.state() !== void 0;
  const defaults = columnState.reconcileColumnState(options.columns, options.defaults);
  const local = vue.shallowRef(defaults);
  const state = vue.computed(
    () => columnState.reconcileColumnState(
      options.columns,
      controlled ? options.state() : local.value
    )
  );
  function set(next) {
    const value = columnState.reconcileColumnState(options.columns, next);
    if (schemaForm.equal(value, state.value)) return;
    if (!controlled) local.value = value;
    options.update(value);
  }
  vue.watch(
    options.domain,
    () => {
      if (!controlled) set(defaults);
    },
    { flush: "sync" }
  );
  const columns = vue.computed(() => {
    const map = new Map(options.columns.map((column) => [column.key, column]));
    const ordered = state.value.columns.filter((entry) => entry.visible).map((entry) => ({
      ...map.get(entry.key),
      ...entry,
      width: entry.width ?? map.get(entry.key).width,
      fixed: entry.fixed ?? void 0
    }));
    return [
      ...ordered.filter((column) => column.fixed === "left"),
      ...ordered.filter((column) => !column.fixed),
      ...ordered.filter((column) => column.fixed === "right")
    ];
  });
  return {
    state,
    columns,
    set,
    reset: () => set(columnState.reconcileColumnState(options.columns)),
    patch(key, patch) {
      set({
        version: 1,
        columns: state.value.columns.map(
          (entry) => entry.key === key ? { ...entry, ...patch } : entry
        )
      });
    },
    move(key, offset) {
      const entries = [...state.value.columns];
      const from = entries.findIndex((entry2) => entry2.key === key);
      const to = from + offset;
      if (from < 0 || to < 0 || to >= entries.length) return;
      const [entry] = entries.splice(from, 1);
      entries.splice(to, 0, entry);
      set({ version: 1, columns: entries });
    }
  };
}
function useQueryCommands(options) {
  const initial = () => {
    var _a;
    return {
      query: options.defaults.query,
      pager: options.definition.pagination === false ? null : { page: 1, size: ((_a = options.definition.pagination) == null ? void 0 : _a.pageSize) ?? 10 },
      sort: options.defaults.sort
    };
  };
  function invalid() {
    const issues = [{ path: [], code: "invalid-input" }];
    options.issues(issues);
    return { kind: "not-started", reason: "invalid-input", issues };
  }
  function intent(kind, input2) {
    if (!options.ready()) return { kind: "not-started", reason: "not-ready" };
    try {
      if (options.definition.pagination === false !== (input2.pager === null))
        return invalid();
      const checked = gridList.resolveGridListRequeryInput(
        input2,
        input2.pager ? { page: input2.pager.page, size: input2.pager.size } : {}
      );
      const errors = options.validate({
        query: checked.query,
        sort: checked.sort
      });
      if (errors == null ? void 0 : errors.length) {
        options.issues(errors);
        return { kind: "not-started", reason: "invalid-input", issues: errors };
      }
      const event = Object.freeze({
        kind,
        domainKey: options.domainKey(),
        input: schemaForm.copy({
          query: input2.query,
          pager: input2.pager,
          sort: input2.sort
        })
      });
      options.issues([]);
      options.emit(event);
      return { kind: "intent-emitted", intent: event };
    } catch {
      return invalid();
    }
  }
  return {
    search(kind, query) {
      const base = options.applied() ?? initial();
      return intent(kind, {
        query,
        sort: kind === "reset" ? options.defaults.sort : base.sort,
        pager: base.pager ? { page: 1, size: base.pager.size } : null
      });
    },
    async reload() {
      const grid = options.grid();
      if ((grid == null ? void 0 : grid.mode) === "request") return grid.reload();
      if (options.definition.request)
        return { kind: "not-started", reason: "not-ready" };
      return intent("reload", options.applied() ?? initial());
    },
    async requery(change) {
      const grid = options.grid();
      if ((grid == null ? void 0 : grid.mode) === "request") return grid.requery(change);
      if (options.definition.request)
        return { kind: "not-started", reason: "not-ready" };
      const applied = options.applied();
      if (!applied) return { kind: "not-started", reason: "not-submitted" };
      try {
        return intent("requery", gridList.resolveGridListRequeryInput(applied, change));
      } catch {
        return invalid();
      }
    }
  };
}
function useSort(options) {
  let synchronizing = false;
  let alive = true;
  let revision = 0;
  vue.onScopeDispose(() => {
    alive = false;
    revision++;
  });
  const hasServerSort = options.definition.columns.some(
    (column) => column.sortable === "server"
  );
  function sync() {
    var _a, _b, _c;
    if (!hasServerSort || !options.request && options.applied() === void 0)
      return;
    const first = (_a = options.applied()) == null ? void 0 : _a.sort[0];
    const column = first && options.definition.columns.find(
      (column2) => column2.key === first.field && column2.sortable === "server"
    );
    synchronizing = true;
    try {
      if (column && options.columns().some((item) => item.key === column.key) && "prop" in column && column.prop)
        (_b = options.table()) == null ? void 0 : _b.sort(
          column.prop,
          first.order === "asc" ? "ascending" : "descending"
        );
      else (_c = options.table()) == null ? void 0 : _c.clearSort();
    } finally {
      synchronizing = false;
    }
  }
  vue.watch(
    [options.table, () => {
      var _a;
      return (_a = options.applied()) == null ? void 0 : _a.sort;
    }, options.columns],
    () => {
      const turn = ++revision;
      vue.nextTick().then(() => {
        if (alive && turn === revision) sync();
      });
    },
    { immediate: true, flush: "post" }
  );
  async function change(event) {
    if (synchronizing || !hasServerSort) return;
    const column = options.definition.columns.find(
      (column2) => {
        var _a;
        return column2.key === ((_a = event.column) == null ? void 0 : _a.columnKey) || "prop" in column2 && column2.prop === event.prop;
      }
    );
    if (event.order && (column == null ? void 0 : column.sortable) !== "server") return;
    const sort = event.order && column ? [
      {
        field: column.key,
        order: event.order === "ascending" ? "asc" : "desc"
      }
    ] : [];
    await options.requery({ sort });
    await vue.nextTick();
    if (alive) sync();
  }
  return { change };
}
function useActions(options) {
  const feedback = themeProvider.useThemeFeedback();
  const busy = vue.reactive(/* @__PURE__ */ new Set());
  const rowIdentities = /* @__PURE__ */ new WeakMap();
  let identity = 0;
  let alive = true;
  let controller = new AbortController();
  vue.watch(
    [options.domain, options.ready],
    () => {
      controller.abort();
      controller = new AbortController();
      busy.clear();
    },
    { flush: "sync" }
  );
  vue.onScopeDispose(() => {
    alive = false;
    controller.abort();
    busy.clear();
  });
  function context(captured = false) {
    const turn = options.domain();
    const signal = controller.signal;
    return Object.freeze({
      applied: captured ? schemaForm.copy(options.applied()) : options.applied(),
      signal,
      reload: async () => !alive ? { kind: "not-started", reason: "disposed" } : signal.aborted || options.domain() !== turn ? { kind: "not-started", reason: "domain-changed" } : !options.ready() ? { kind: "not-started", reason: "not-ready" } : options.reload()
    });
  }
  function busyKey(id, row) {
    if (!row) return id;
    const key = options.rowKey(row);
    if (key !== void 0) return JSON.stringify([id, typeof key, key]);
    if (!rowIdentities.has(row)) rowIdentities.set(row, ++identity);
    return JSON.stringify([id, "object", rowIdentities.get(row)]);
  }
  const toolbar = vue.computed(() => {
    var _a, _b;
    const ctx = context();
    const selection = options.selection();
    return [
      ...(((_a = options.definition.actions) == null ? void 0 : _a.toolbar) ?? []).filter((a) => {
        var _a2;
        return ((_a2 = a.visible) == null ? void 0 : _a2.call(a, ctx)) !== false;
      }).map((a) => {
        var _a2;
        return {
          ...a,
          group: "toolbar",
          loading: busy.has(a.id),
          disabled: !options.ready() || busy.has(a.id) || ((_a2 = a.disabled) == null ? void 0 : _a2.call(a, ctx)) === true
        };
      }),
      ...(((_b = options.definition.actions) == null ? void 0 : _b.batch) ?? []).filter((a) => {
        var _a2;
        return ((_a2 = a.visible) == null ? void 0 : _a2.call(a, ctx)) !== false;
      }).map((a) => {
        var _a2;
        return {
          ...a,
          group: "batch",
          loading: busy.has(a.id),
          disabled: !options.ready() || busy.has(a.id) || a.requiresSelection !== false && !selection.keys.length || ((_a2 = a.disabled) == null ? void 0 : _a2.call(a, selection, ctx)) === true
        };
      })
    ];
  });
  function rowActions(row) {
    var _a;
    const ctx = context();
    return (((_a = options.definition.actions) == null ? void 0 : _a.row) ?? []).filter((a) => {
      var _a2;
      return ((_a2 = a.visible) == null ? void 0 : _a2.call(a, row, ctx)) !== false;
    }).map((a) => {
      var _a2;
      return {
        ...a,
        loading: busy.has(busyKey(a.id, row)),
        disabled: !options.ready() || !options.rowValid(row) || busy.has(busyKey(a.id, row)) || ((_a2 = a.disabled) == null ? void 0 : _a2.call(a, row, ctx)) === true
      };
    });
  }
  async function run(id, row) {
    var _a, _b, _c, _d;
    const group = row ? "row" : ((_b = (_a = options.definition.actions) == null ? void 0 : _a.toolbar) == null ? void 0 : _b.some((a) => a.id === id)) ? "toolbar" : "batch";
    const action = (_d = (_c = options.definition.actions) == null ? void 0 : _c[group]) == null ? void 0 : _d.find((a) => a.id === id);
    if (!action || !alive) return;
    const eligible = () => {
      var _a2, _b2, _c2, _d2, _e, _f;
      if (!options.ready()) return false;
      const ctx2 = context();
      if (group === "row") {
        const a2 = action;
        return options.rowValid(row) && ((_a2 = a2.visible) == null ? void 0 : _a2.call(a2, row, ctx2)) !== false && ((_b2 = a2.disabled) == null ? void 0 : _b2.call(a2, row, ctx2)) !== true;
      }
      if (group === "batch") {
        const a2 = action;
        const selected = options.selection();
        return ((_c2 = a2.visible) == null ? void 0 : _c2.call(a2, ctx2)) !== false && (a2.requiresSelection === false || selected.keys.length > 0) && ((_d2 = a2.disabled) == null ? void 0 : _d2.call(a2, selected, ctx2)) !== true;
      }
      const a = action;
      return ((_e = a.visible) == null ? void 0 : _e.call(a, ctx2)) !== false && ((_f = a.disabled) == null ? void 0 : _f.call(a, ctx2)) !== true;
    };
    const key = busyKey(id, row);
    if (busy.has(key) || !eligible()) return;
    const turn = options.domain();
    const publication = options.publication();
    const ctx = context(true);
    const selection = options.selection();
    const targetKey = row ? options.rowKey(row) : void 0;
    busy.add(key);
    function current() {
      if (!alive || ctx.signal.aborted || turn !== options.domain() || !schemaForm.equal(publication, options.publication()))
        return false;
      if (row && targetKey !== void 0 && vue.toRaw(options.row(targetKey)) !== vue.toRaw(row))
        return false;
      if (group === "batch") {
        const now = options.selection();
        if (selection.scopeRef !== now.scopeRef || selection.keys.length !== now.keys.length || selection.keys.some((key2) => !now.keys.includes(key2)) || now.loadedRows.some((row2) => !options.rowValid(row2)))
          return false;
      }
      return eligible();
    }
    try {
      if (action.confirm) {
        if (!feedback.ok)
          throw new Error("TableRender confirmation unavailable");
        const confirm = action.confirm;
        const message = typeof confirm !== "function" ? confirm : group === "row" ? confirm(
          row,
          ctx
        ) : group === "batch" ? confirm(selection, ctx) : confirm(ctx);
        const result = await feedback.value.confirm({
          title: options.locale().confirm,
          message,
          dangerouslyUseHTMLString: false,
          confirmButtonText: options.locale().confirm,
          cancelButtonText: options.locale().cancel
        });
        if (!alive) return;
        if (ctx.signal.aborted) {
          await feedback.value.message({
            type: "info",
            message: options.locale().actionCancelled
          });
          return;
        }
        if (!result.ok) throw new Error("TableRender confirmation unavailable");
        if (result.value !== "confirm") return;
      }
      if (!current()) {
        if (alive && feedback.ok)
          await feedback.value.message({
            type: "info",
            message: options.locale().actionCancelled
          });
        return;
      }
      if (group === "row")
        await action.run(row, ctx);
      else if (group === "batch")
        await action.run(selection, ctx);
      else
        await action.run(ctx);
      if (action.reloadAfter) await ctx.reload();
    } catch (error) {
      if (alive && !ctx.signal.aborted && turn === options.domain())
        options.error({ actionId: id, rowKey: targetKey, error });
    } finally {
      if (alive && !ctx.signal.aborted && turn === options.domain())
        busy.delete(key);
    }
  }
  return { toolbar, rowActions, run };
}
function useDomain(options) {
  const epoch = vue.shallowRef(0);
  const key = vue.shallowRef("");
  const ready = vue.shallowRef(false);
  let initialized = false;
  let alive = true;
  let consumed = -1;
  function publish(version, available, replaced = false) {
    if (initialized && !replaced && key.value === version && ready.value === available)
      return;
    const changed = initialized;
    initialized = true;
    key.value = version;
    ready.value = available;
    if (!changed) return;
    epoch.value++;
    options.invalidate();
    if (!options.request || !available || consumed === epoch.value) return;
    const turn = epoch.value;
    consumed = turn;
    vue.nextTick().then(() => {
      if (alive && turn === epoch.value && ready.value) return options.reset();
    });
  }
  if (options.request) {
    vue.watch(
      options.context,
      (context, previous, cleanup) => {
        const update = (replaced = false) => {
          const current = (context == null ? void 0 : context.capture()) ?? {
            version: "ui-only",
            ready: true
          };
          publish(current.version, current.ready, replaced);
        };
        update(context !== previous && initialized);
        if (context) cleanup(context.subscribe(() => update()));
      },
      { immediate: true, flush: "sync" }
    );
  } else {
    vue.watch(
      options.controlledKey,
      (value) => publish(value ?? "", typeof value === "string" && value.length > 0),
      { immediate: true, flush: "sync" }
    );
  }
  vue.onScopeDispose(() => {
    alive = false;
    epoch.value++;
  });
  return {
    key,
    ready,
    epoch,
    identity: vue.computed(() => `${epoch.value}:${key.value}`)
  };
}
const tableRenderZhCN = Object.freeze({
  search: "查询",
  reset: "重置",
  more: "更多条件",
  apply: "应用",
  close: "关闭",
  dirty: "条件已修改未查询",
  applied: "已应用条件",
  invalid: "请检查输入",
  incomplete: "请完成输入",
  dictionaryUnavailable: "字典未加载",
  yes: "是",
  no: "否",
  all: "全部",
  actions: "操作",
  confirm: "确认",
  cancel: "取消",
  actionCancelled: "列表或操作权限已变化，操作已取消",
  columns: "列设置",
  width: "宽度",
  pin: "固定",
  unpinned: "不固定",
  left: "左侧",
  right: "右侧",
  moveUp: "上移",
  moveDown: "下移",
  resetColumns: "恢复默认列",
  selected: "已选",
  missing: "不在当前加载数据中",
  clearSelection: "清空选择",
  selectRow: "选择行",
  selectAll: "选择全部已加载可选行",
  expand: "展开",
  collapse: "收起",
  hiddenSort: "排序列已隐藏",
  clearSort: "清除排序",
  loadedPageSort: "本地排序仅作用于当前已加载页",
  retryOptions: "重试字典"
});
const tableRenderEn = Object.freeze({
  search: "Search",
  reset: "Reset",
  more: "More filters",
  apply: "Apply",
  close: "Close",
  dirty: "Filters changed, not applied",
  applied: "Applied filters",
  invalid: "Check this value",
  incomplete: "Complete this value",
  dictionaryUnavailable: "Dictionary unavailable",
  yes: "Yes",
  no: "No",
  all: "All",
  actions: "Actions",
  confirm: "Confirm",
  cancel: "Cancel",
  actionCancelled: "The list or permission changed. Action cancelled.",
  columns: "Columns",
  width: "Width",
  pin: "Pin",
  unpinned: "Unpinned",
  left: "Left",
  right: "Right",
  moveUp: "Move up",
  moveDown: "Move down",
  resetColumns: "Reset columns",
  selected: "Selected",
  missing: "not loaded",
  clearSelection: "Clear selection",
  selectRow: "Select row",
  selectAll: "Select all loaded eligible rows",
  expand: "Expand",
  collapse: "Collapse",
  hiddenSort: "Sorted column hidden",
  clearSort: "Clear sort",
  loadedPageSort: "Local sorting applies only to the loaded page",
  retryOptions: "Retry dictionaries"
});
function useTableRenderLocale(overrides) {
  const { lang, t } = hooks.useLocale();
  return vue.computed(() => {
    const fallback = lang.value.toLowerCase().startsWith("zh") ? tableRenderZhCN : tableRenderEn;
    const messages = Object.fromEntries(
      Object.entries(fallback).map(([key, value]) => {
        const path = `zx.tableRender.${key}`;
        const translated = t(path);
        return [key, translated === path ? value : translated];
      })
    );
    return { ...messages, ...overrides() };
  });
}
const _hoisted_1 = ["aria-label"];
const _hoisted_2 = {
  class: "zx-table-render__summary",
  role: "status"
};
const _hoisted_3 = { key: 0 };
const _hoisted_4 = {
  key: 1,
  class: "zx-table-render__summary"
};
const _hoisted_5 = {
  key: 2,
  class: "zx-table-render__summary",
  role: "status"
};
const _hoisted_6 = {
  key: 3,
  class: "zx-table-render__summary",
  role: "status"
};
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxTableRender", inheritAttrs: false },
  __name: "table-render",
  props: {
    definition: {},
    queryContext: {},
    query: {},
    applied: {},
    displayed: {},
    rows: {},
    pagination: {},
    status: {},
    domainKey: {},
    locale: {},
    columnState: {},
    defaultColumnState: {},
    selectionState: {},
    defaultSelectionKeys: {},
    selectionScopeKey: {},
    expandedState: {},
    defaultExpandedKeys: {},
    currentRowKey: {},
    tableProps: {}
  },
  emits: ["update:query", "query-intent", "update:columnState", "update:selectionState", "selection-change", "update:expandedState", "update:currentRowKey", "row-click", "row-dblclick", "configuration-error", "action-error"],
  setup(__props, { expose: __expose, emit: __emit }) {
    var _a, _b, _c, _d;
    const props = __props;
    const emit = __emit;
    const slots = vue.useSlots();
    const definition = props.definition;
    const request = !!definition.request;
    if (!request && (props.domainKey === void 0 || props.applied === void 0 || props.displayed === void 0))
      throw new TypeError(
        "TableRender controlled mode requires domainKey, applied and displayed"
      );
    if (definition.selection && definition.selection.scope === "explicit" && !props.selectionScopeKey)
      throw new TypeError(
        "TableRender explicit selection requires selectionScopeKey"
      );
    vue.watch(
      () => props.definition,
      (next) => {
        if (next !== definition)
          throw new TypeError(
            "TableRender definition changed: remount with a new key"
          );
      }
    );
    const modes = [
      props.columnState !== void 0,
      props.selectionState !== void 0,
      props.expandedState !== void 0
    ];
    vue.watch(
      [() => props.selectionState, () => props.defaultSelectionKeys],
      ([state, defaults]) => {
        if (state !== void 0 && defaults !== void 0)
          throw new TypeError(
            "TableRender controlled selection cannot use defaultSelectionKeys"
          );
      },
      { immediate: true, flush: "sync" }
    );
    vue.watch(
      () => [
        props.columnState !== void 0,
        props.selectionState !== void 0,
        props.expandedState !== void 0
      ],
      (next) => {
        if (next.some((value, index) => value !== modes[index]))
          throw new TypeError(
            "TableRender state ownership changed: remount with a new key"
          );
      }
    );
    const grid = vue.shallowRef();
    const table = vue.shallowRef();
    const locale = useTableRenderLocale(() => props.locale);
    const domain = useDomain({
      request,
      context: () => props.queryContext,
      controlledKey: () => props.domainKey,
      invalidate: () => {
        search2.clearEditing();
        if (request) search2.setDraft(search2.defaults.query, { replace: true });
      },
      reset: () => search2.reset()
    });
    const controlledIssue = vue.computed(() => {
      var _a2;
      if (request || !domain.ready.value) return null;
      if (props.applied && props.applied.domainKey !== domain.key.value || props.displayed && props.displayed.domainKey !== domain.key.value)
        return "controlled-domain-mismatch";
      if (!props.displayed && ((_a2 = props.rows) == null ? void 0 : _a2.length)) return "rows-without-publication";
      return null;
    });
    vue.watch(
      controlledIssue,
      (code) => {
        if (code) emit("configuration-error", { code });
      },
      { immediate: true, flush: "post" }
    );
    const actionsReady = vue.computed(
      () => domain.ready.value && !controlledIssue.value
    );
    const displayed = vue.computed(() => {
      var _a2;
      if (!actionsReady.value) return null;
      if (request) {
        const owner = grid.value;
        const value = (owner == null ? void 0 : owner.mode) === "request" ? owner.displayed : null;
        return (value == null ? void 0 : value.logicalInput) ? {
          domainKey: domain.key.value,
          revision: value.resultRevision,
          input: value.logicalInput
        } : null;
      }
      return ((_a2 = props.displayed) == null ? void 0 : _a2.domainKey) === domain.key.value ? props.displayed : null;
    });
    const search2 = useSearch({
      definition,
      grid: () => grid.value,
      domainKey: () => domain.key.value,
      query: () => props.query ?? {},
      applied: () => {
        var _a2;
        return ((_a2 = props.applied) == null ? void 0 : _a2.domainKey) === domain.key.value ? props.applied : null;
      },
      update: (value) => emit("update:query", value),
      intent: (type, query) => commands.search(type, query)
    });
    const commands = useQueryCommands({
      definition,
      grid: () => grid.value,
      domainKey: () => domain.key.value,
      ready: () => domain.ready.value,
      applied: () => search2.applied.value,
      defaults: search2.defaults,
      validate: search2.validator,
      issues: (value) => {
        search2.issues.value = value;
      },
      emit: (intent) => emit("query-intent", intent)
    });
    const { reload, requery } = commands;
    function pageChanged(pager) {
      var _a2, _b2;
      return requery(
        pager.size === ((_b2 = (_a2 = search2.applied.value) == null ? void 0 : _a2.pager) == null ? void 0 : _b2.size) ? { page: pager.page } : { size: pager.size }
      );
    }
    const dictionaries = useOptions(definition, {
      key: () => domain.key.value,
      epoch: () => domain.identity.value,
      ready: () => domain.ready.value
    });
    const noRows = [];
    const rows = vue.computed(
      () => {
        var _a2;
        return request ? ((_a2 = grid.value) == null ? void 0 : _a2.state.list) ?? noRows : (displayed.value ? props.rows ?? noRows : noRows).slice();
      }
    );
    const identity = useRowIdentity({
      rows: () => rows.value,
      rowKey: definition.rowKey,
      children: (_a = definition.tree) == null ? void 0 : _a.children,
      required: () => {
        var _a2, _b2;
        return !!definition.selection || !!definition.tree || !!((_b2 = (_a2 = definition.actions) == null ? void 0 : _a2.row) == null ? void 0 : _b2.some((action) => action.confirm)) || props.currentRowKey !== void 0;
      },
      error: (error) => emit("configuration-error", error)
    });
    const selectionDefinition = definition.selection || void 0;
    const selectable = (row) => {
      var _a2;
      return !identity.index.value.invalid && ((_a2 = selectionDefinition == null ? void 0 : selectionDefinition.selectable) == null ? void 0 : _a2.call(selectionDefinition, row)) !== false;
    };
    const selected = useSelection({
      enabled: !!selectionDefinition,
      scope: (selectionDefinition == null ? void 0 : selectionDefinition.scope) ?? "page",
      scopeKey: () => props.selectionScopeKey,
      state: () => props.selectionState,
      defaults: ((_b = props.defaultSelectionKeys) == null ? void 0 : _b.slice()) ?? [],
      rows: () => identity.index.value.rows,
      rowKey: identity.rowKey,
      selectable,
      invalid: () => identity.index.value.invalid,
      displayed: () => displayed.value,
      domain: () => domain.identity.value,
      table: () => table.value,
      update: (value) => {
        if (selectionDefinition) emit("update:selectionState", value);
      },
      change: (value) => {
        if (selectionDefinition) emit("selection-change", value);
      }
    });
    const expandable = vue.computed(
      () => definition.tree ? identity.index.value.rows.filter((row) => {
        const children = columnState.readColumnValue(row, definition.tree.children);
        return Array.isArray(children) && children.length > 0;
      }) : []
    );
    const expansion = useExpansion({
      enabled: !!definition.tree,
      table: () => table.value,
      state: () => props.expandedState,
      defaults: ((_c = props.defaultExpandedKeys) == null ? void 0 : _c.slice()) ?? [],
      defaultAll: ((_d = definition.tree) == null ? void 0 : _d.defaultExpandAll) ?? false,
      domain: () => domain.identity.value,
      displayed: () => displayed.value,
      expandable: () => expandable.value,
      rowKey: identity.rowKey,
      invalid: () => identity.index.value.invalid,
      update: (value) => {
        if (definition.tree) emit("update:expandedState", value);
      }
    });
    const view = useColumns({
      columns: definition.columns,
      state: () => props.columnState,
      defaults: props.defaultColumnState,
      domain: () => domain.identity.value,
      update: (value) => emit("update:columnState", value)
    });
    const columns = vue.computed(
      () => {
        var _a2, _b2;
        return ((_b2 = (_a2 = definition.actions) == null ? void 0 : _a2.row) == null ? void 0 : _b2.length) && !definition.columns.some((column) => column.type === "actions") ? [
          ...view.columns.value,
          {
            key: "__table_actions",
            type: "actions",
            label: locale.value.actions,
            fixed: "right",
            minWidth: 160
          }
        ] : view.columns.value;
      }
    );
    const sorting = useSort({
      definition,
      table: () => table.value,
      applied: () => search2.applied.value,
      request,
      requery,
      columns: () => columns.value
    });
    const loadedPageSort = definition.columns.some(
      (column) => column.localSortScope === "loaded-page"
    );
    const hiddenSort = vue.computed(
      () => {
        var _a2;
        return ((_a2 = search2.applied.value) == null ? void 0 : _a2.sort.filter(
          (item) => !columns.value.some((column) => column.key === item.field)
        )) ?? [];
      }
    );
    const actions = useActions({
      definition,
      ready: () => actionsReady.value,
      applied: () => search2.applied.value,
      selection: () => selected.selection.value,
      rowKey: identity.rowKey,
      domain: () => domain.identity.value,
      publication: () => displayed.value,
      row: (key) => identity.index.value.byKey.get(key),
      selectable,
      rowValid: () => !identity.index.value.invalid,
      reload,
      locale: () => locale.value,
      error: (error) => emit("action-error", { ...error, actionId: error.actionId })
    });
    const tableProps = vue.computed(() => {
      var _a2;
      const value = props.tableProps ?? {};
      if (((_a2 = definition.layout) == null ? void 0 : _a2.fill) && (value.height !== void 0 || value.maxHeight !== void 0))
        throw new TypeError(
          "TableRender fill cannot be combined with height/maxHeight"
        );
      return {
        size: value.size,
        border: value.border,
        stripe: value.stripe,
        height: value.height,
        maxHeight: value.maxHeight,
        showHeader: value.showHeader ?? true,
        rowClassName: value.rowClassName,
        cellClassName: value.cellClassName
      };
    });
    const gridProps = vue.computed(() => {
      var _a2;
      const common = {
        showPagination: definition.pagination !== false,
        fill: (_a2 = definition.layout) == null ? void 0 : _a2.fill,
        pageSizes: definition.pagination && definition.pagination.pageSizes ? [...definition.pagination.pageSizes] : void 0
      };
      return request ? {
        ...common,
        mode: "request",
        loadData: async (params, context) => {
          const result = await definition.request(params, context);
          if (!result || !Array.isArray(result.list) || definition.pagination !== false && (!result.pager || !Number.isSafeInteger(result.pager.total) || result.pager.total < 0))
            throw new TypeError(
              "TableRender request requires list and pager.total"
            );
          if (result.pager && (result.pager.page !== void 0 && (!Number.isSafeInteger(result.pager.page) || result.pager.page < 1) || result.pager.size !== void 0 && (!Number.isSafeInteger(result.pager.size) || result.pager.size < 1)))
            throw new TypeError("TableRender invalid result pager");
          return result;
        },
        queryContext: props.queryContext,
        defaults: search2.defaults,
        queryValidator: search2.validator,
        draftHold: search2.draftHold,
        paramsTransform: definition.transform,
        defaultPageSize: definition.pagination ? definition.pagination.pageSize : void 0
      } : {
        ...common,
        mode: "controlled",
        rows: rows.value,
        pagination: displayed.value ? props.pagination ?? null : null,
        status: !actionsReady.value ? { domain: "switched" } : props.status
      };
    });
    const regionContext = vue.computed(() => ({
      draft: search2.draft.value,
      dirty: search2.dirty.value,
      columnState: api.columnState,
      commands: {
        setDraft: api.setDraft,
        search: api.search,
        reset: api.reset,
        reload,
        requery: api.requery,
        clearSelection: api.clearSelection,
        setSelectionKeys: api.setSelectionKeys,
        setExpandedKeys: api.setExpandedKeys,
        setColumnState: api.setColumnState,
        resetColumns: api.resetColumns,
        refreshOptions: api.refreshOptions
      },
      selection: selected.selection.value,
      applied: search2.applied.value,
      displayed: displayed.value
    }));
    const eligibleRows = vue.computed(
      () => identity.index.value.rows.filter(selectable)
    );
    const checkedCount = vue.computed(
      () => eligibleRows.value.filter(selected.checked).length
    );
    function searchSlot(field) {
      const name = `search-${field.key}`;
      return slots[name] ? name : typeof field.control === "object" ? field.control.slot : name;
    }
    function cellSlot(column) {
      const name = `cell-${column.key}`;
      return slots[name] ? name : column.type === "custom" ? column.slot ?? name : name;
    }
    function headerSlot(column) {
      const name = `header-${column.key}`;
      return slots[name] ? name : column.headerSlot ?? name;
    }
    const RenderHeader = (header) => {
      var _a2, _b2;
      return (_b2 = (_a2 = header.column).headerRender) == null ? void 0 : _b2.call(_a2, header);
    };
    function indexValue(column, row, index) {
      var _a2;
      if (definition.tree) return identity.index.value.positions.get(vue.toRaw(row));
      const pager = (_a2 = displayed.value) == null ? void 0 : _a2.input.pager;
      return index + 1 + (column.type === "index" && column.indexScope === "pagination" && pager ? (pager.page - 1) * pager.size : 0);
    }
    function rowClicked(row, column, event) {
      var _a2;
      emit("row-click", row, column, event);
      if (props.currentRowKey !== void 0 && !identity.index.value.invalid)
        emit("update:currentRowKey", identity.rowKey(row) ?? null);
      restoreCurrentRow();
      if ((selectionDefinition == null ? void 0 : selectionDefinition.rowClick) && !((_a2 = event.target) == null ? void 0 : _a2.closest(
        'button,a,input,select,textarea,[role="button"],[role="checkbox"],[contenteditable],.el-table__expand-icon'
      )))
        selected.toggle(row, !selected.checked(row));
    }
    let alive = true;
    let currentRevision = 0;
    async function restoreCurrentRow() {
      var _a2;
      const turn = ++currentRevision;
      await vue.nextTick();
      if (!alive || turn !== currentRevision || props.currentRowKey === void 0)
        return;
      (_a2 = table.value) == null ? void 0 : _a2.setCurrentRow(
        identity.index.value.invalid || props.currentRowKey === null ? void 0 : identity.index.value.byKey.get(props.currentRowKey)
      );
    }
    vue.watch(
      [
        () => props.currentRowKey,
        identity.index,
        () => domain.identity.value,
        table
      ],
      restoreCurrentRow,
      { immediate: true, flush: "post" }
    );
    vue.onScopeDispose(() => {
      alive = false;
      currentRevision++;
    });
    const api = {
      get mode() {
        return request ? "request" : "controlled";
      },
      get queryOwner() {
        var _a2;
        return ((_a2 = grid.value) == null ? void 0 : _a2.mode) === "request" ? grid.value.queryOwner : void 0;
      },
      get draft() {
        return search2.draft.value;
      },
      get applied() {
        return search2.applied.value;
      },
      get displayed() {
        return displayed.value;
      },
      get dirty() {
        return search2.dirty.value;
      },
      get selection() {
        return selected.selection.value;
      },
      get columnState() {
        return view.state.value;
      },
      get expandedKeys() {
        return expansion.keys.value;
      },
      setDraft: (value, options) => search2.setDraft(value, options),
      search: search2.search,
      reset: search2.reset,
      reload,
      requery,
      clearSelection: selected.clear,
      setSelectionKeys: selected.setKeys,
      setExpandedKeys: expansion.setKeys,
      setColumnState: view.set,
      resetColumns: view.reset,
      refreshOptions: dictionaries.refresh
    };
    __expose(api);
    return (_ctx, _cache) => {
      var _a2;
      return vue.openBlock(), vue.createElementBlock("div", vue.mergeProps(_ctx.$attrs, {
        class: ["zx-table-render", { "zx-table-render--fill": (_a2 = vue.unref(definition).layout) == null ? void 0 : _a2.fill }],
        role: "region",
        "aria-label": vue.unref(definition).title
      }), [
        vue.createVNode(vue.unref(gridList.ZxGridList), vue.mergeProps({
          ref_key: "grid",
          ref: grid
        }, gridProps.value, {
          onPageChange: pageChanged,
          onReload: vue.unref(reload)
        }), {
          form: vue.withCtx(() => [
            vue.createVNode(vue.unref(listToolbar.ZxListToolbar), { class: "zx-table-render__toolbar" }, {
              actions: vue.withCtx(() => [
                vue.createVNode(vue.unref(moreAction.ZxActionBar), {
                  actions: vue.unref(actions).toolbar.value,
                  label: vue.unref(locale).actions,
                  onAction: _cache[0] || (_cache[0] = ($event) => vue.unref(actions).run($event.id))
                }, null, 8, ["actions", "label"]),
                vue.renderSlot(_ctx.$slots, "toolbar-extra", vue.normalizeProps(vue.guardReactiveProps(regionContext.value)))
              ]),
              filters: vue.withCtx(() => [
                vue.createVNode(_sfc_main$4, {
                  search: vue.unref(search2),
                  options: vue.unref(dictionaries),
                  locale: vue.unref(locale),
                  placement: "inline"
                }, vue.createSlots({ _: 2 }, [
                  vue.renderList(vue.unref(search2).located, (field) => {
                    return {
                      name: `search-${field.field.key}`,
                      fn: vue.withCtx((context) => [
                        vue.renderSlot(_ctx.$slots, searchSlot(field.field), vue.normalizeProps(vue.guardReactiveProps(context)))
                      ])
                    };
                  })
                ]), 1032, ["search", "options", "locale"])
              ]),
              search: vue.withCtx(() => [
                vue.createVNode(_sfc_main$4, {
                  search: vue.unref(search2),
                  options: vue.unref(dictionaries),
                  locale: vue.unref(locale),
                  placement: "search"
                }, vue.createSlots({ _: 2 }, [
                  vue.renderList(vue.unref(search2).located, (field) => {
                    return {
                      name: `search-${field.field.key}`,
                      fn: vue.withCtx((context) => [
                        vue.renderSlot(_ctx.$slots, searchSlot(field.field), vue.normalizeProps(vue.guardReactiveProps(context)))
                      ])
                    };
                  })
                ]), 1032, ["search", "options", "locale"]),
                vue.createVNode(_sfc_main$1, {
                  columns: vue.unref(definition).columns,
                  state: vue.unref(view).state.value,
                  locale: vue.unref(locale),
                  onPatch: vue.unref(view).patch,
                  onMove: vue.unref(view).move,
                  onReset: vue.unref(view).reset
                }, null, 8, ["columns", "state", "locale", "onPatch", "onMove", "onReset"])
              ]),
              _: 3
            }),
            vue.unref(definition).selection ? vue.renderSlot(_ctx.$slots, "selection-summary", vue.normalizeProps(vue.guardReactiveProps(regionContext.value)), () => [
              vue.createElementVNode("div", _hoisted_2, [
                vue.createTextVNode(vue.toDisplayString(vue.unref(locale).selected) + " " + vue.toDisplayString(vue.unref(selected).selection.value.keys.length), 1),
                vue.unref(selected).selection.value.missingKeys.length ? (vue.openBlock(), vue.createElementBlock("span", _hoisted_3, " · " + vue.toDisplayString(vue.unref(selected).selection.value.missingKeys.length) + " " + vue.toDisplayString(vue.unref(locale).missing), 1)) : vue.createCommentVNode("", true),
                vue.unref(selected).selection.value.keys.length ? (vue.openBlock(), vue.createElementBlock("button", {
                  key: 1,
                  type: "button",
                  onClick: _cache[1] || (_cache[1] = //@ts-ignore
                  (...args) => vue.unref(selected).clear && vue.unref(selected).clear(...args))
                }, vue.toDisplayString(vue.unref(locale).clearSelection), 1)) : vue.createCommentVNode("", true)
              ])
            ], void 0, 0) : vue.createCommentVNode("", true),
            vue.unref(loadedPageSort) ? (vue.openBlock(), vue.createElementBlock("div", _hoisted_4, vue.toDisplayString(vue.unref(locale).loadedPageSort), 1)) : vue.createCommentVNode("", true),
            vue.unref(dictionaries).failed.value.length ? (vue.openBlock(), vue.createElementBlock("div", _hoisted_5, [
              vue.createTextVNode(vue.toDisplayString(vue.unref(locale).dictionaryUnavailable) + " ", 1),
              vue.createElementVNode("button", {
                type: "button",
                onClick: _cache[2] || (_cache[2] = //@ts-ignore
                (...args) => vue.unref(dictionaries).retryFailed && vue.unref(dictionaries).retryFailed(...args))
              }, vue.toDisplayString(vue.unref(locale).retryOptions), 1)
            ])) : vue.createCommentVNode("", true),
            hiddenSort.value.length ? (vue.openBlock(), vue.createElementBlock("div", _hoisted_6, [
              vue.createTextVNode(vue.toDisplayString(vue.unref(locale).hiddenSort) + ": " + vue.toDisplayString(hiddenSort.value.map((item) => `${item.field} ${item.order}`).join(", ")) + " ", 1),
              vue.createElementVNode("button", {
                type: "button",
                onClick: _cache[3] || (_cache[3] = ($event) => vue.unref(requery)({ sort: [] }))
              }, vue.toDisplayString(vue.unref(locale).clearSort), 1)
            ])) : vue.createCommentVNode("", true)
          ]),
          table: vue.withCtx(({ renderEmpty }) => {
            var _a3;
            return [
              vue.renderSlot(_ctx.$slots, "before-table", vue.normalizeProps(vue.guardReactiveProps(regionContext.value))),
              vue.createVNode(vue.unref(elementPlus.ElTable), vue.mergeProps({
                ref_key: "table",
                ref: table
              }, tableProps.value, {
                data: vue.unref(identity).index.value.unsafeStructure ? [] : rows.value,
                "row-key": vue.unref(identity).tableKey,
                "tree-props": {
                  children: ((_a3 = vue.unref(definition).tree) == null ? void 0 : _a3.children) ?? "__no_children",
                  checkStrictly: true
                },
                "expand-row-keys": vue.unref(expansion).encoded.value,
                "highlight-current-row": __props.currentRowKey !== void 0,
                onSelect: vue.unref(selected).select,
                onSelectAll: vue.unref(selected).selectAll,
                onSortChange: vue.unref(sorting).change,
                onExpandChange: _cache[4] || (_cache[4] = (row, expanded) => typeof expanded === "boolean" && vue.unref(expansion).toggle(row, expanded)),
                onRowClick: rowClicked,
                onRowDblclick: _cache[5] || (_cache[5] = (row, column, event) => emit("row-dblclick", row, column, event)),
                onHeaderDragend: _cache[6] || (_cache[6] = (width, _old, column) => tableProps.value.border && vue.unref(view).patch(column.columnKey, { width }))
              }), {
                empty: vue.withCtx(() => [
                  vue.renderSlot(_ctx.$slots, "empty", vue.normalizeProps(vue.guardReactiveProps(regionContext.value)), () => [
                    (vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(renderEmpty)))
                  ])
                ]),
                default: vue.withCtx(() => [
                  vue.unref(definition).selection ? (vue.openBlock(), vue.createBlock(vue.unref(elementPlus.ElTableColumn), {
                    key: 0,
                    "column-key": "__table_selection",
                    width: vue.unref(definition).tree ? 96 : 48,
                    resizable: false
                  }, {
                    header: vue.withCtx(() => [
                      vue.createVNode(_sfc_main$2, {
                        label: vue.unref(locale).selectAll,
                        disabled: !eligibleRows.value.length || vue.unref(identity).index.value.invalid,
                        checked: eligibleRows.value.length > 0 && checkedCount.value === eligibleRows.value.length,
                        indeterminate: checkedCount.value > 0 && checkedCount.value < eligibleRows.value.length,
                        onChange: vue.unref(selected).toggleAll
                      }, null, 8, ["label", "disabled", "checked", "indeterminate", "onChange"])
                    ]),
                    default: vue.withCtx(({ row }) => [
                      vue.createVNode(_sfc_main$2, {
                        label: `${vue.unref(locale).selectRow} ${vue.unref(identity).rowKey(row) ?? ""}`,
                        checked: vue.unref(selected).checked(row),
                        disabled: !selectable(row),
                        onChange: ($event) => vue.unref(selected).toggle(row, $event)
                      }, null, 8, ["label", "checked", "disabled", "onChange"])
                    ]),
                    _: 1
                  }, 8, ["width"])) : vue.createCommentVNode("", true),
                  (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(columns.value, (column, index) => {
                    return vue.openBlock(), vue.createBlock(vue.unref(elementPlus.ElTableColumn), {
                      key: column.key,
                      "column-key": column.key,
                      prop: "prop" in column ? column.prop : void 0,
                      label: column.label,
                      width: column.width,
                      "min-width": column.minWidth,
                      align: column.align,
                      fixed: column.fixed,
                      "show-overflow-tooltip": column.overflow === "tooltip",
                      "class-name": column.overflow === "wrap" ? "zx-table-render__wrap" : void 0,
                      sortable: column.sortable === "server" ? "custom" : column.sortable === "local"
                    }, vue.createSlots({
                      default: vue.withCtx(({ row, $index }) => {
                        var _a4;
                        return [
                          column.type === "actions" ? (vue.openBlock(), vue.createBlock(_sfc_main$3, {
                            key: 0,
                            row,
                            actions: vue.unref(actions),
                            limit: ((_a4 = vue.unref(definition).layout) == null ? void 0 : _a4.rowActionLimit) ?? 3,
                            label: vue.unref(locale).actions
                          }, null, 8, ["row", "actions", "limit", "label"])) : column.type === "index" ? (vue.openBlock(), vue.createElementBlock(vue.Fragment, { key: 1 }, [
                            vue.createTextVNode(vue.toDisplayString(indexValue(column, row, $index)), 1)
                          ], 64)) : (vue.openBlock(), vue.createBlock(vue.unref(TableCell), {
                            key: 2,
                            column,
                            row,
                            index: $index,
                            options: vue.unref(dictionaries),
                            locale: vue.unref(locale)
                          }, vue.createSlots({ _: 2 }, [
                            _ctx.$slots[cellSlot(column)] ? {
                              name: "default",
                              fn: vue.withCtx((context) => [
                                vue.renderSlot(_ctx.$slots, cellSlot(column), vue.mergeProps({ ref_for: true }, context))
                              ]),
                              key: "0"
                            } : void 0
                          ]), 1032, ["column", "row", "index", "options", "locale"]))
                        ];
                      }),
                      _: 2
                    }, [
                      column.headerRender || _ctx.$slots[headerSlot(column)] ? {
                        name: "header",
                        fn: vue.withCtx(() => [
                          vue.renderSlot(_ctx.$slots, headerSlot(column), {
                            column,
                            index
                          }, () => [
                            vue.createVNode(RenderHeader, {
                              column,
                              index
                            }, null, 8, ["column", "index"])
                          ])
                        ]),
                        key: "0"
                      } : void 0
                    ]), 1032, ["column-key", "prop", "label", "width", "min-width", "align", "fixed", "show-overflow-tooltip", "class-name", "sortable"]);
                  }), 128))
                ]),
                _: 2
              }, 1040, ["data", "row-key", "tree-props", "expand-row-keys", "highlight-current-row", "onSelect", "onSelectAll", "onSortChange"]),
              vue.renderSlot(_ctx.$slots, "after-table", vue.normalizeProps(vue.guardReactiveProps(regionContext.value)))
            ];
          }),
          _: 3
        }, 16, ["onReload"])
      ], 16, _hoisted_1);
    };
  }
});
const ZxTableRender = _sfc_main;
exports.ZxTableRender = ZxTableRender;
exports.tableRenderEn = tableRenderEn;
exports.tableRenderZhCN = tableRenderZhCN;
