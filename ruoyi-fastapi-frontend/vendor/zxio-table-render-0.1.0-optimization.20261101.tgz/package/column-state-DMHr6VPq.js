"use strict";
const schemaForm = require("@zxio/schema-form");
const unsafeKeys = /* @__PURE__ */ new Set(["__proto__", "prototype", "constructor"]);
function definitionError(path, code) {
  throw new TypeError(`TableRender ${path}: ${code}`);
}
function object(value, path) {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.getPrototypeOf(value) !== Object.prototype)
    definitionError(path, "expected-object");
  if (Reflect.ownKeys(value).some(
    (key2) => typeof key2 !== "string" || unsafeKeys.has(key2) || !("value" in Object.getOwnPropertyDescriptor(value, key2))
  ))
    definitionError(path, "invalid-property");
  return value;
}
function text(value, path) {
  if (typeof value !== "string" || !value.trim())
    definitionError(path, "expected-text");
}
function key(value, path) {
  if (typeof value !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(value) || unsafeKeys.has(value))
    definitionError(path, "invalid-key");
}
function list(value, path) {
  if (!Array.isArray(value) || Object.keys(value).length !== value.length)
    definitionError(path, "expected-array");
  return value;
}
function positive(value, path) {
  if (!Number.isSafeInteger(value) || value < 1)
    definitionError(path, "expected-positive-integer");
}
function optionalChoice(value, choices, path) {
  if (value !== void 0 && !choices.includes(value))
    definitionError(path, "invalid-choice");
}
function validateOptions(value, path = "options") {
  const seen = [];
  list(value, path).forEach((item, index) => {
    const option = object(item, `${path}[${index}]`);
    if (!schemaForm.isValueShape({ type: "enum", values: [option.value] }))
      definitionError(`${path}[${index}].value`, "invalid-json");
    text(option.label, `${path}[${index}].label`);
    optionalChoice(
      option.tone,
      ["default", "primary", "success", "warning", "danger", "info"],
      `${path}[${index}].tone`
    );
    if (seen.some((value2) => schemaForm.equal(value2, option.value)))
      definitionError(`${path}[${index}].value`, "duplicate-value");
    seen.push(option.value);
  });
}
function validateDefinition(input) {
  var _a;
  const definition = object(input, "definition");
  key(definition.key, "key");
  text(definition.title, "title");
  const providers = /* @__PURE__ */ new Map();
  function options(value, path) {
    if (Array.isArray(value)) return validateOptions(value, path);
    const provider = object(value, path);
    key(provider.key, `${path}.key`);
    if (typeof provider.load !== "function")
      definitionError(`${path}.load`, "expected-loader");
    if (provider.params !== void 0 && typeof provider.params !== "function")
      definitionError(`${path}.params`, "expected-function");
    const previous = providers.get(provider.key);
    if (previous && !Array.isArray(previous) && (previous.load !== provider.load || previous.params !== provider.params))
      definitionError(`${path}.key`, "conflicting-loader");
    providers.set(provider.key, provider);
  }
  const fields = /* @__PURE__ */ new Set();
  let keywords = 0;
  for (const [index, entry] of list(
    definition.search ?? [],
    "search"
  ).entries()) {
    const path = `search[${index}]`;
    const field = object(entry, path);
    key(field.key, `${path}.key`);
    if (fields.has(field.key)) definitionError(`${path}.key`, "duplicate-key");
    fields.add(field.key);
    text(field.label, `${path}.label`);
    if (typeof field.control === "string")
      optionalChoice(
        field.control,
        [
          "text",
          "number",
          "select",
          "multi-select",
          "date",
          "date-range",
          "boolean"
        ],
        `${path}.control`
      );
    else
      text(
        object(field.control, `${path}.control`).slot,
        `${path}.control.slot`
      );
    optionalChoice(
      field.placement,
      ["keyword", "inline", "more"],
      `${path}.placement`
    );
    optionalChoice(field.trigger, ["change", "confirm"], `${path}.trigger`);
    if (field.placement === "keyword") {
      if (++keywords > 1 || field.control !== "text")
        definitionError(`${path}.placement`, "invalid-keyword");
    }
    if (field.shape !== void 0 && !schemaForm.isValueShape(field.shape))
      definitionError(`${path}.shape`, "invalid-shape");
    if (field.default !== void 0 && !schemaForm.isValueShape({ type: "enum", values: [field.default] }))
      definitionError(`${path}.default`, "invalid-json");
    if (field.options !== void 0) options(field.options, `${path}.options`);
    for (const name of ["toLogical", "fromLogical", "validate"])
      if (field[name] !== void 0 && typeof field[name] !== "function")
        definitionError(`${path}.${name}`, "expected-function");
  }
  const columns = /* @__PURE__ */ new Set();
  const server = /* @__PURE__ */ new Set();
  let local = false;
  for (const [index, entry] of list(definition.columns, "columns").entries()) {
    const path = `columns[${index}]`;
    const column = object(entry, path);
    key(column.key, `${path}.key`);
    if (columns.has(column.key)) definitionError(`${path}.key`, "duplicate-key");
    columns.add(column.key);
    text(column.label, `${path}.label`);
    optionalChoice(
      column.type,
      [
        "text",
        "number",
        "date",
        "datetime",
        "enum",
        "boolean",
        "custom",
        "actions",
        "index"
      ],
      `${path}.type`
    );
    if (!["custom", "actions", "index"].includes(column.type) || column.prop !== void 0) {
      text(column.prop, `${path}.prop`);
      const parts = column.prop.split(".");
      if (parts.length > 4 || parts.some((part) => !part || unsafeKeys.has(part)))
        definitionError(`${path}.prop`, "invalid-path");
    }
    optionalChoice(column.sortable, ["local", "server"], `${path}.sortable`);
    if (column.sortable && (!column.prop || column.type === "actions"))
      definitionError(`${path}.sortable`, "missing-prop");
    if (column.sortable === "server") server.add(column.key);
    if (column.sortable === "local") {
      local = true;
      if (definition.tree)
        definitionError(`${path}.sortable`, "tree-local-sort-unsupported");
      if (column.localSortScope !== (definition.pagination === false ? "all-loaded" : "loaded-page"))
        definitionError(
          `${path}.localSortScope`,
          "explicit-sort-scope-required"
        );
    }
    if (column.precision !== void 0 && (!Number.isInteger(column.precision) || column.precision < 0 || column.precision > 20))
      definitionError(`${path}.precision`, "invalid-precision");
    for (const hook of ["render", "headerRender", "value"]) {
      if (column[hook] !== void 0 && typeof column[hook] !== "function")
        definitionError(`${path}.${hook}`, "expected-function");
    }
    optionalChoice(
      column.indexScope,
      ["page", "pagination"],
      `${path}.indexScope`
    );
    if (column.type === "enum") options(column.options, `${path}.options`);
  }
  if (local && server.size) definitionError("columns", "mixed-sort-modes");
  if (definition.rowKey !== void 0 && typeof definition.rowKey !== "function") {
    key(definition.rowKey, "rowKey");
    const parts = definition.rowKey.split(".");
    if (parts.length > 4 || parts.some((part) => !part || unsafeKeys.has(part)))
      definitionError("rowKey", "invalid-path");
  }
  if (definition.tree) {
    key(object(definition.tree, "tree").children, "tree.children");
    if (!definition.rowKey) definitionError("rowKey", "required-for-tree");
  }
  if (definition.selection !== void 0 && definition.selection !== false) {
    if (object(definition.selection, "selection").mode !== "multiple")
      definitionError("selection.mode", "invalid-selection");
    if (!definition.rowKey) definitionError("rowKey", "required-for-selection");
    optionalChoice(
      definition.selection.scope,
      ["page", "explicit"],
      "selection.scope"
    );
    if (definition.selection.selectable !== void 0 && typeof definition.selection.selectable !== "function")
      definitionError("selection.selectable", "expected-function");
  }
  if (definition.sort !== void 0) object(definition.sort, "sort");
  const sort = list(((_a = definition.sort) == null ? void 0 : _a.default) ?? [], "sort.default");
  if (sort.length > 1) definitionError("sort.default", "single-sort-required");
  sort.forEach((item, index) => {
    const entry = object(item, `sort.default[${index}]`);
    if (!server.has(entry.field))
      definitionError(`sort.default[${index}].field`, "not-server-sortable");
    if (!["asc", "desc"].includes(entry.order))
      definitionError(`sort.default[${index}].order`, "invalid-order");
  });
  if (definition.pagination !== void 0 && definition.pagination !== false) {
    const pager = object(definition.pagination, "pagination");
    if (pager.pageSize !== void 0)
      positive(pager.pageSize, "pagination.pageSize");
    if (pager.pageSizes !== void 0)
      list(pager.pageSizes, "pagination.pageSizes").forEach(
        (size, index) => positive(size, `pagination.pageSizes[${index}]`)
      );
  }
  if (definition.layout !== void 0) {
    const layout = object(definition.layout, "layout");
    for (const name of ["inlineLimit", "rowActionLimit"])
      if (layout[name] !== void 0 && (!Number.isSafeInteger(layout[name]) || layout[name] < 0))
        definitionError(`layout.${name}`, "invalid-limit");
  }
  const actions = definition.actions === void 0 ? {} : object(definition.actions, "actions");
  const ids = /* @__PURE__ */ new Set();
  for (const group of ["toolbar", "batch", "row"]) {
    for (const [index, item] of list(
      actions[group] ?? [],
      `actions.${group}`
    ).entries()) {
      const path = `actions.${group}[${index}]`;
      const action = object(item, path);
      key(action.id, `${path}.id`);
      if (ids.has(action.id)) definitionError(`${path}.id`, "duplicate-id");
      ids.add(action.id);
      text(action.label, `${path}.label`);
      if (typeof action.run !== "function")
        definitionError(`${path}.run`, "expected-function");
    }
  }
}
function readColumnValue(row, prop) {
  if (!prop) return void 0;
  let value = row;
  for (const key2 of prop.split(".")) {
    if (!value || typeof value !== "object" || !Object.hasOwn(value, key2))
      return void 0;
    value = value[key2];
  }
  return value;
}
function textValue(value, empty = "—") {
  if (value === null || value === void 0 || value === "") return empty;
  if (typeof value !== "object") return String(value);
  try {
    return JSON.stringify(value) ?? empty;
  } catch {
    return empty;
  }
}
function optionFor(value, options = []) {
  return options.find((option) => schemaForm.equal(option.value, value));
}
function formatColumnValue(column, value, options) {
  var _a;
  if (value === null || value === void 0 || value === "") return "—";
  if (column.type === "enum")
    return ((_a = optionFor(
      value,
      options ?? (Array.isArray(column.options) ? column.options : [])
    )) == null ? void 0 : _a.label) ?? textValue(value);
  if (column.type === "boolean") {
    const labels = column.labels ?? ["否", "是"];
    return value === false ? labels[0] : value === true ? labels[1] : textValue(value);
  }
  if (column.type === "number") {
    const number = typeof value === "number" ? value : typeof value === "string" && value.trim() ? Number(value) : Number.NaN;
    if (!Number.isFinite(number)) return textValue(value);
    return `${column.precision === void 0 ? number : number.toFixed(column.precision)}${column.unit ?? ""}`;
  }
  if (column.type === "date" || column.type === "datetime") {
    const date = value instanceof Date ? value : typeof value === "string" || typeof value === "number" ? new Date(value) : new Date(Number.NaN);
    if (!Number.isFinite(date.getTime())) return textValue(value);
    const pad = (part) => String(part).padStart(2, "0");
    const parts = {
      YYYY: String(date.getFullYear()),
      MM: pad(date.getMonth() + 1),
      DD: pad(date.getDate()),
      HH: pad(date.getHours()),
      mm: pad(date.getMinutes()),
      ss: pad(date.getSeconds())
    };
    return (column.format ?? (column.type === "date" ? "YYYY-MM-DD" : "YYYY-MM-DD HH:mm:ss")).replace(/YYYY|MM|DD|HH|mm|ss/g, (key2) => parts[key2]);
  }
  return textValue(value);
}
const idle = Object.freeze({
  status: "idle",
  options: Object.freeze([])
});
function createOptionsStore() {
  const entries = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Set();
  let disposed = false;
  const emit = () => {
    for (const listener of [...listeners]) listener();
  };
  function entry(source) {
    let current = entries.get(source.key);
    if (current && (current.source.load !== source.load || current.source.params !== source.params))
      throw new TypeError(
        `TableRender options.${source.key}: conflicting-source`
      );
    if (!current) {
      current = { source, state: idle };
      entries.set(source.key, current);
    }
    return current;
  }
  function invalidate(current) {
    var _a, _b;
    (_a = current.obsolete) == null ? void 0 : _a.call(current);
    (_b = current.controller) == null ? void 0 : _b.abort();
    current.obsolete = void 0;
    current.controller = void 0;
    current.pending = void 0;
    current.identity = void 0;
    current.state = idle;
  }
  function get(source) {
    if (disposed) return idle;
    if (Array.isArray(source)) return { status: "loaded", options: source };
    return entry(source).state;
  }
  function load(source, identity, force = false) {
    if (Array.isArray(source))
      return Promise.resolve({ kind: "loaded", sourceKey: "" });
    const remote = source;
    if (disposed)
      return Promise.resolve({ kind: "obsolete", sourceKey: remote.key });
    const current = entry(remote);
    if (!force && schemaForm.equal(current.identity, identity)) {
      if (current.pending) return current.pending;
      if (current.state.status === "loaded")
        return Promise.resolve({ kind: "loaded", sourceKey: remote.key });
      if (current.state.status === "error")
        return Promise.resolve({
          kind: "failed",
          sourceKey: remote.key,
          code: current.state.error
        });
    }
    invalidate(current);
    current.identity = {
      domainKey: identity.domainKey,
      epoch: identity.epoch,
      ...identity.params === void 0 ? {} : { params: schemaForm.copy(identity.params) }
    };
    const controller = new AbortController();
    current.controller = controller;
    current.state = Object.freeze({ status: "loading", options: idle.options });
    const snapshot = current.identity;
    let settle;
    const pending = new Promise((resolve) => {
      settle = resolve;
    });
    current.pending = pending;
    current.obsolete = () => settle({ kind: "obsolete", sourceKey: remote.key });
    Promise.resolve().then(() => {
      if (controller.signal.aborted) return [];
      return remote.load({
        params: snapshot.params,
        domainKey: snapshot.domainKey,
        signal: controller.signal
      });
    }).then((value) => {
      if (disposed || controller.signal.aborted || current.controller !== controller)
        return;
      validateOptions(value);
      current.state = Object.freeze({
        status: "loaded",
        options: Object.freeze(
          value.map(
            (item) => Object.freeze({ ...item, value: schemaForm.copy(item.value) })
          )
        )
      });
      settle({ kind: "loaded", sourceKey: remote.key });
    }).catch(() => {
      if (disposed || controller.signal.aborted || current.controller !== controller)
        return;
      current.state = Object.freeze({
        status: "error",
        error: "load-failed",
        options: idle.options
      });
      settle({ kind: "failed", sourceKey: remote.key, code: "load-failed" });
    }).finally(() => {
      if (disposed || current.controller !== controller) return;
      current.pending = void 0;
      current.controller = void 0;
      current.obsolete = void 0;
      emit();
    });
    emit();
    return pending;
  }
  return {
    get,
    load,
    fail(source, code) {
      if (Array.isArray(source)) return { kind: "loaded", sourceKey: "" };
      const remote = source;
      if (disposed) return { kind: "obsolete", sourceKey: remote.key };
      const current = entry(remote);
      invalidate(current);
      current.state = Object.freeze({
        status: "error",
        error: code,
        options: idle.options
      });
      emit();
      return { kind: "failed", sourceKey: remote.key, code };
    },
    invalidate(source) {
      if (source && Array.isArray(source)) return;
      const targets = source ? [entry(source)] : [...entries.values()];
      targets.forEach(invalidate);
      emit();
    },
    subscribe(listener) {
      if (disposed) return () => {
      };
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      entries.forEach(invalidate);
      listeners.clear();
      entries.clear();
    }
  };
}
function normalizeQuery(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.getPrototypeOf(input) !== Object.prototype)
    throw new TypeError("invalid-query");
  const result = {};
  for (const key2 of Reflect.ownKeys(input)) {
    const descriptor = Object.getOwnPropertyDescriptor(input, key2);
    if (typeof key2 !== "string" || !("value" in descriptor) || !descriptor.enumerable || ["__proto__", "constructor", "prototype"].includes(key2))
      throw new TypeError("invalid-query");
    const value = descriptor.value;
    if (value === void 0 || value === "" || Array.isArray(value) && value.length === 0)
      continue;
    result[key2] = value;
  }
  if (!schemaForm.isValueShape({ type: "enum", values: [result] }))
    throw new TypeError("invalid-query");
  return schemaForm.copy(result);
}
function defaultQuery(definition) {
  return normalizeQuery(
    Object.fromEntries(
      (definition.search ?? []).map((field) => [field.key, field.default])
    )
  );
}
function boundedIssues(value) {
  return schemaForm.isValueShape({ type: "enum", values: [value] }) && Array.isArray(value) && value.length <= 32 && value.every(
    (issue) => issue && Object.keys(issue).every((key2) => key2 === "path" || key2 === "code") && typeof issue.code === "string" && /^[a-z0-9-]{1,64}$/.test(issue.code) && Array.isArray(issue.path) && issue.path.length > 0 && issue.path.length <= 8 && ["query", "sort"].includes(issue.path[0]) && issue.path.every(
      (part) => typeof part === "string" ? part.length <= 128 : Number.isSafeInteger(part) && part >= 0
    )
  );
}
function buildQueryValidator(definition) {
  const server = new Set(
    definition.columns.filter((column) => column.sortable === "server").map((column) => column.key)
  );
  return (input) => {
    var _a;
    const issues = [];
    try {
      const query = normalizeQuery(input.query);
      for (const field of definition.search ?? []) {
        if (!Object.hasOwn(query, field.key)) continue;
        const value = query[field.key];
        if (field.shape && !schemaForm.matchesValueShape(value, field.shape))
          issues.push({ path: ["query", field.key], code: "invalid-value" });
        else if (field.validate) {
          const code = field.validate(value);
          if (code !== null) issues.push({ path: ["query", field.key], code });
        }
      }
      if (!Array.isArray(input.sort) || input.sort.length > 1)
        issues.push({ path: ["sort"], code: "invalid-sort" });
      else
        input.sort.forEach((sort, index) => {
          if (!server.has(sort.field))
            issues.push({
              path: ["sort", index, "field"],
              code: "invalid-sort"
            });
          if (sort.order !== "asc" && sort.order !== "desc")
            issues.push({
              path: ["sort", index, "order"],
              code: "invalid-sort"
            });
        });
      const cross = ((_a = definition.validate) == null ? void 0 : _a.call(definition, {
        query,
        sort: input.sort
      })) ?? [];
      if (!boundedIssues(cross)) throw new TypeError("invalid-validation");
      issues.push(...cross);
      if (!boundedIssues(issues)) throw new TypeError("invalid-validation");
      return issues.length ? issues : null;
    } catch {
      return [{ path: ["query"], code: "invalid-input" }];
    }
  };
}
function columnWidthBounds(column) {
  const configured = Number.parseFloat(String(column.minWidth));
  const min = Number.isFinite(configured) ? Math.max(48, Math.ceil(configured)) : 48;
  return { min, max: Math.max(1200, min) };
}
function columnWidth(column, value) {
  const { min, max } = columnWidthBounds(column);
  return typeof value === "number" && Number.isFinite(value) ? Math.round(Math.max(min, Math.min(max, value))) : void 0;
}
function reconcileColumnState(columns, state) {
  const source = new Map(columns.map((column) => [column.key, column]));
  const used = /* @__PURE__ */ new Set();
  const entries = [];
  if ((state == null ? void 0 : state.version) === 1 && Array.isArray(state.columns)) {
    for (const entry of state.columns) {
      if (!entry || used.has(entry.key) || !source.has(entry.key)) continue;
      const column = source.get(entry.key);
      used.add(entry.key);
      entries.push({
        key: entry.key,
        visible: column.hideable === false || entry.visible !== false,
        width: columnWidth(
          column,
          entry.width ?? (typeof column.width === "number" ? column.width : void 0)
        ),
        fixed: entry.fixed === null || entry.fixed === "left" || entry.fixed === "right" ? entry.fixed : column.fixed ?? null
      });
    }
  }
  for (const column of columns)
    if (!used.has(column.key))
      entries.push({
        key: column.key,
        visible: true,
        width: columnWidth(
          column,
          typeof column.width === "number" ? column.width : void 0
        ),
        fixed: column.fixed ?? null
      });
  const data = columns.filter(
    (column) => !("type" in column && ["actions", "index"].includes(String(column.type)))
  );
  if (data.length && !entries.some(
    (entry) => entry.visible && data.some((column) => column.key === entry.key)
  )) {
    const index = entries.findIndex((entry) => entry.key === data[0].key);
    entries[index] = { ...entries[index], visible: true };
  }
  return Object.freeze({
    version: 1,
    columns: Object.freeze(entries.map((entry) => Object.freeze(entry)))
  });
}
exports.buildQueryValidator = buildQueryValidator;
exports.columnWidthBounds = columnWidthBounds;
exports.createOptionsStore = createOptionsStore;
exports.defaultQuery = defaultQuery;
exports.formatColumnValue = formatColumnValue;
exports.normalizeQuery = normalizeQuery;
exports.optionFor = optionFor;
exports.readColumnValue = readColumnValue;
exports.reconcileColumnState = reconcileColumnState;
exports.textValue = textValue;
exports.validateDefinition = validateDefinition;
