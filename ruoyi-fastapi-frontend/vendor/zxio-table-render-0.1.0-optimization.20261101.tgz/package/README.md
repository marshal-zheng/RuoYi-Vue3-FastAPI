# @zxio/table-render

Typed declarative lists built on the public ZXUI GridList query owner. A definition describes search fields, columns and local business actions. GridList owns requests, applied conditions and displayed results.

Import theme variables first, then `@zxio/zxui/style`, then `@zxio/table-render/style`. Mount inside the host's `ZxThemeProvider`; dropdowns and confirmations use its portal and feedback facilities.

## Public entries

| Entry                      | Purpose                                                                                          |
| -------------------------- | ------------------------------------------------------------------------------------------------ |
| `@zxio/table-render`       | Core definitions and Vue UI                                                                      |
| `@zxio/table-render/core`  | Pure definitions, formatting, validation and explicit raw-field mapping; Node-compatible ESM/CJS |
| `@zxio/table-render/ui`    | `ZxTableRender`, locale data and component types                                                 |
| `@zxio/table-render/agent` | Optional ESM-only official Page Agent adapter builders and Vue lifecycle wiring                  |
| `@zxio/table-render/style` | Feature styles, also exported as `/style.css`                                                    |

The host installs Vue, Element Plus, `@zxio/zxui` and `@zxio/schema-form`. Only Agent consumers need `@zxio/page-agent`. Core runtime imports only the pure SchemaForm root; ordinary UI does not load Page Agent, Zod or Formily.

## Definition and component

```ts
import { defineTableRender } from '@zxio/table-render/core'

interface Device {
  id: number
  name: string
  status: string
}
interface DeviceQuery {
  name?: string
  status?: string
}

export const devices = defineTableRender<Device, DeviceQuery>()({
  key: 'devices',
  title: 'Devices',
  rowKey: 'id',
  search: [
    {
      key: 'name',
      label: 'Name',
      control: 'text',
      placement: 'keyword',
      shape: { type: 'string', maxLength: 100 },
    },
  ],
  columns: [
    { key: 'name', label: 'Name', prop: 'name', sortable: 'server' },
    { key: 'status', label: 'Status', prop: 'status' },
  ],
  request: async ({ query, pager, sort }, { signal }) => {
    // Map logical query/pager/sort through the application's HTTP client.
    return deviceService.list({ query, pager, sort, signal })
  },
})
```

```vue
<script setup lang="ts">
import { ZxTableRender } from '@zxio/table-render/ui'
import '@zxio/zxui/style'
import '@zxio/table-render/style'
import { devices } from './devices'
</script>

<template>
  <ZxTableRender :definition="devices">
    <template #cell-name="{ row }">{{ row.name }}</template>
  </ZxTableRender>
</template>
```

Definitions are immutable snapshots. Use a new Vue `key` to replace a mounted definition. The curried row/query types survive component and slot inference without runtime metadata.

## Query and selection ownership

- `setDraft()` edits filters. `search()` applies them from the first page. Incomplete number/date/custom input stays local and blocks explicit search.
- `reset()` clears editing buffers and applies definition defaults while preserving the current page size. Invalid defaults do not start a request.
- `reload()` repeats applied conditions. `requery({ page, size, sort })` derives from applied conditions; it never submits unsent draft edits.
- New/failed/cancelled requests retain displayed rows and their current-page selection. A different successfully displayed condition clears selection; same-condition success keeps only identities still on the page. Domain invalidation clears immediately.
- Omitting `request` selects controlled mode. The Host owns `query`, `applied`, `displayed`, `rows`, `pagination`, `status` and `domainKey`; TableRender emits one validated `query-intent` containing kind, domainKey and the complete input. domainKey, applied and displayed are required; use null for missing applied/displayed. Without an applied query it makes no dirty/applied claim. Displayed metadata includes the successful revision and logical input; stale-domain metadata is never rendered.

`TableRenderInstance` exposes mode, optional queryOwner, draft, applied, dirty, selection, setDraft/search/reset/reload/requery and clearSelection. Actions receive captured applied input, an abort signal and a domain-bound reload, never draft filters. Confirmation rechecks target/publication/permission; old completions cannot refresh a new domain. They remain local business commands.

## Agent ownership

Host code creates and releases `GridListQueryAccess` using its own policy. `tableRenderPolicyFields(definition, { query, row })` maps only explicitly selected raw paths and grants no authority. Query fields need a static `ValueShape`; dictionary options and visible columns never grant access. `support` is always explicit.

The Vue helper accepts Host-owned access leases. It releases each lease after Page Agent unregisters the binding and its selected run becomes idle. To narrow policy or change the domain: invalidate, change the Host policy/domain, then rebind. A Host lifetime abort cannot be rebound.

## Verification

Run the package's `test`, `typecheck`, `build` and `check:imports` scripts. After building its public peers, `check:packed` installs their real tarballs in a fresh directory outside the repository. It checks pure Node core evaluation, ordinary UI without optional Agent/Formily/Zod, runtime/declaration import boundaries, and NodeNext/Bundler consumer types before and after installing Agent. Agent declarations use `.d.mts` to match the ESM-only runtime.

Consumer type tests run with `skipLibCheck`; an additional pass disables it and rejects every diagnostic in this package's declarations. Diagnostics belonging to installed peer declarations are retained separately in the report, not represented as a clean check of all dependency declarations. The gate neither opens a browser nor calls a model.

## View state and migration

ElTable remains the rendering engine. Column state is a versioned ordered snapshot, normalized by `reconcileColumnState`; local defaults and controlled state have separate ownership. The Host owns optional persistence. `createTableColumnHelper<Row>()` preserves accessor/computed cell value types, including optional nested paths.

Selection exposes `scope`, `scopeRef`, `keys`, `loadedRows` and `missingKeys`. Explicit cross-page selection requires a business `selectionScopeKey`; it never fetches or selects an entire remote query. Controlled selection/expansion requires the current scopeRef received from the update event. Ignored or delayed snapshots from old scopes cannot restore stale IDs. Static trees share the identity index; numeric/string keys stay distinct.

Dynamic options now load with `{ params, domainKey, signal }`; `params` is a reactive getter. Only the current identity is cached. `refreshOptions()` returns loaded/failed/obsolete results. Typed requests must return `TableResult<Row>`; paginated requests require pager.total. Query methods return terminal/not-started in request mode and intent-emitted/not-started in controlled mode.

Migrate old query events to `query-intent`, selection.rows to selection.loadedRows (or keys for cross-page commands), and load(signal) to load(context). Controlled Hosts publish displayed metadata atomically with rows. Local sorting requires an explicit loaded-page/all-loaded scope. A changed definition or state ownership mode requires a remount.

See the Chinese TableRender documentation and optimization workbench for full public API examples. Browser accessibility and production performance evidence are separate acceptance gates; package tests do not establish those results.

Action confirmation callbacks have the same target arguments as `run`: toolbar `(ctx)`, row `(row, ctx)`, batch `(selection, ctx)`. Static strings remain supported. Toolbar and batch pending states display loading feedback throughout confirmation and execution. Custom cell rendering is never invoked for ElTableColumn structural probes.
