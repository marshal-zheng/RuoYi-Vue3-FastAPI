import { strictSortSchema, createGridListAgentTarget } from "@zxio/page-agent/adapters/grid-list";
import { strictQuerySchema } from "@zxio/page-agent/adapters/value-shape";
import { shallowRef, watch, onScopeDispose } from "vue";
import { usePageAgentTarget } from "@zxio/page-agent/vue";
function keys(value, path) {
  if (!Array.isArray(value) || value.some((key) => typeof key !== "string") || new Set(value).size !== value.length)
    throw new TypeError(`TableRender agent.${path}: invalid-fields`);
  return value;
}
function tableRenderAgentTargetOptions(options) {
  const snapshot = options.owner.capture();
  if (snapshot.kind === "unavailable" && snapshot.reason === "context-missing")
    throw new TypeError("TableRender agent: context-missing");
  if (!options.support || ["operationLookup", "submit", "reload", "cancel"].some(
    (key) => typeof options.support[key] !== "boolean"
  ))
    throw new TypeError("TableRender agent.support: explicit-support-required");
  const queryFields = keys(options.queryFields, "queryFields");
  const sortFields = keys(options.sortFields ?? [], "sortFields");
  const fields = new Map(
    (options.definition.search ?? []).map((field) => [field.key, field])
  );
  const serverFields = new Set(
    options.definition.columns.filter((column) => column.sortable === "server").map((column) => column.key)
  );
  const shapes = Object.fromEntries(
    queryFields.map((key) => {
      var _a;
      const shape = (_a = fields.get(key)) == null ? void 0 : _a.shape;
      if (!shape)
        throw new TypeError(
          `TableRender agent.queryFields.${key}: static-shape-required`
        );
      return [key, shape];
    })
  );
  for (const key of sortFields)
    if (!serverFields.has(key))
      throw new TypeError(
        `TableRender agent.sortFields.${key}: not-server-sortable`
      );
  const policy = options.policy.capture();
  if (Object.keys(policy.submitFields ?? {}).some(
    (key) => !queryFields.includes(key)
  ))
    throw new TypeError("TableRender agent.queryFields: policy-fields-missing");
  if (Object.keys(policy.sortFields ?? {}).some(
    (key) => !sortFields.includes(key)
  ))
    throw new TypeError("TableRender agent.sortFields: policy-fields-missing");
  return {
    key: options.key ?? options.definition.key,
    title: options.title ?? options.definition.title,
    lifetime: options.lifetime,
    limits: options.limits,
    access: options.access,
    support: options.support,
    ...queryFields.length ? { querySchema: strictQuerySchema(shapes) } : {},
    ...sortFields.length ? { sortSchema: strictSortSchema(sortFields, policy.maxSortItems ?? 1) } : {}
  };
}
function createTableRenderAgentTarget(options) {
  return createGridListAgentTarget(tableRenderAgentTargetOptions(options));
}
function useTableRenderAgentTarget(options) {
  const spec = shallowRef();
  const leases = /* @__PURE__ */ new WeakMap();
  let disposed = false;
  function rebind() {
    var _a, _b;
    const owner = ((_a = options.owner) == null ? void 0 : _a.value) ?? ((_b = options.table.value) == null ? void 0 : _b.queryOwner);
    if (disposed || options.lifetime.aborted || !owner) {
      spec.value = void 0;
      return;
    }
    const captured = { ...options.options };
    spec.value = {
      create(lifetime) {
        const lease = options.createAccess(owner);
        let released = false;
        const release = () => {
          if (released) return;
          released = true;
          lease.release();
        };
        try {
          const binding = createTableRenderAgentTarget({
            ...captured,
            owner,
            access: lease.access,
            lifetime: AbortSignal.any([lifetime, options.lifetime])
          });
          leases.set(binding, release);
          return binding;
        } catch (error) {
          release();
          throw error;
        }
      },
      released(binding) {
        const release = leases.get(binding);
        leases.delete(binding);
        release == null ? void 0 : release();
      }
    };
  }
  watch(
    [
      options.table,
      () => {
        var _a;
        return (_a = options.table.value) == null ? void 0 : _a.queryOwner;
      },
      () => {
        var _a;
        return (_a = options.owner) == null ? void 0 : _a.value;
      }
    ],
    rebind,
    { immediate: true, flush: "sync" }
  );
  const target = usePageAgentTarget({ session: options.session, spec });
  function abort() {
    target.invalidate();
    spec.value = void 0;
  }
  options.lifetime.addEventListener("abort", abort, { once: true });
  onScopeDispose(() => {
    disposed = true;
    options.lifetime.removeEventListener("abort", abort);
  });
  return { ...target, rebind };
}
export {
  createTableRenderAgentTarget,
  tableRenderAgentTargetOptions,
  useTableRenderAgentTarget
};
