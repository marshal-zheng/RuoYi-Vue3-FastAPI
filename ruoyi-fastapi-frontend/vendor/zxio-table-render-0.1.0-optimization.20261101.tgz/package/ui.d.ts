import type { TableRenderComponent } from './src/ui/contracts';
export declare const ZxTableRender: TableRenderComponent;
export { tableRenderEn, tableRenderZhCN } from './src/ui/locale';
export type { ZxTableRenderProps, ZxTableRenderEmits, TableRenderInstance, TableRenderSlots, SearchSlotContext, TableRenderLocale, TableApplied, TableRenderTableProps, TableRegionContext, } from './src/ui/contracts';
