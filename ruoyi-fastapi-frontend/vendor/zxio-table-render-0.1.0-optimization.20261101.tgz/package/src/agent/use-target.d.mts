import type { Ref, ShallowRef } from 'vue';
import type { PageAgentSession } from '@zxio/page-agent';
import type { GridListQueryAccess, GridListQueryOwner } from '@zxio/zxui/grid-list';
import type { TableRenderDefinition } from '../core/types.js';
import type { TableRenderInstance } from '../ui/contracts.js';
import type { TableRenderAgentOptions } from './target.mjs';
export interface UseTableRenderAgentTargetOptions<D extends TableRenderDefinition<any, any>> {
    readonly session: Readonly<ShallowRef<PageAgentSession | undefined>>;
    readonly table: Readonly<Ref<TableRenderInstance<D, any, any> | undefined>>;
    readonly owner?: Readonly<Ref<GridListQueryOwner | undefined>>;
    readonly lifetime: AbortSignal;
    readonly createAccess: (owner: GridListQueryOwner) => {
        access: GridListQueryAccess;
        release(): void;
    };
    readonly options: Omit<TableRenderAgentOptions<D>, 'owner' | 'access' | 'lifetime'>;
}
/** Page Agent owns registration and waits for retiring runs before releasing access. */
export declare function useTableRenderAgentTarget<D extends TableRenderDefinition<any, any>>(options: UseTableRenderAgentTargetOptions<D>): {
    rebind: () => void;
    targetRef: Readonly<ShallowRef<import("@zxio/page-agent").TargetRef | undefined>>;
    status: Readonly<ShallowRef<import("@zxio/page-agent/vue").PageAgentTargetStatus>>;
    error: Readonly<ShallowRef<"register-failed" | undefined>>;
    invalidate(): void;
    settled: () => Promise<void>;
};
