import type { PageAgentLimits } from '@zxio/page-agent';
import type { GridListAgentSupport, GridListAgentTargetOptions } from '@zxio/page-agent/adapters/grid-list';
import type { GridListQueryAccess, GridListQueryOwner, GridListQueryPolicy } from '@zxio/zxui/grid-list';
import type { ServerSortKey, ShapedSearchKey, TableRenderDefinition } from '../core/types.js';
export interface TableRenderAgentOptions<D extends TableRenderDefinition<any, any>> {
    readonly definition: D;
    readonly owner: GridListQueryOwner;
    readonly access: GridListQueryAccess;
    readonly policy: GridListQueryPolicy;
    readonly support: GridListAgentSupport;
    readonly queryFields: readonly ShapedSearchKey<D>[];
    readonly sortFields?: readonly ServerSortKey<D>[];
    readonly lifetime: AbortSignal;
    readonly limits?: Pick<Partial<PageAgentLimits>, 'maxToolOutputBytes'>;
    readonly key?: string;
    readonly title?: string;
}
/** Borrows Host authority; UI visibility, callbacks and dictionary loaders grant nothing. */
export declare function tableRenderAgentTargetOptions<D extends TableRenderDefinition<any, any>>(options: TableRenderAgentOptions<D>): GridListAgentTargetOptions;
export declare function createTableRenderAgentTarget<D extends TableRenderDefinition<any, any>>(options: TableRenderAgentOptions<D>): import("@zxio/page-agent").PageTargetBinding;
