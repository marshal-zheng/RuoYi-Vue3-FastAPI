import type { Column, TableOption } from './types';
export declare function readColumnValue(row: unknown, prop: string | undefined): unknown;
export declare function textValue(value: unknown, empty?: string): string;
export declare function optionFor(value: unknown, options?: readonly TableOption[]): TableOption<import("@zxio/schema-form").Json> | undefined;
/** Pure presentation only: neither formatters nor dictionary labels alter raw rows. */
export declare function formatColumnValue<Row extends object>(column: Column<Row>, value: unknown, options?: readonly TableOption[]): string;
