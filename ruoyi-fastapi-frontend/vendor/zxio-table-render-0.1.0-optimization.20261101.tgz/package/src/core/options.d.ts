import type { Json, OptionsCompletion, OptionsSource, TableOption } from './types';
export interface OptionsState {
    readonly status: 'idle' | 'loading' | 'loaded' | 'error';
    readonly options: readonly TableOption[];
    readonly error?: 'load-failed' | 'invalid-params';
}
export interface OptionsIdentity {
    readonly domainKey: string;
    readonly epoch: string | number;
    readonly params?: Json;
}
/** One current identity per declared source. No historical parameter/result cache. */
export declare function createOptionsStore(): {
    get: (source: OptionsSource) => OptionsState;
    load: (source: OptionsSource, identity: OptionsIdentity, force?: boolean) => Promise<OptionsCompletion>;
    fail(source: OptionsSource, code: "invalid-params"): OptionsCompletion;
    invalidate(source?: OptionsSource): void;
    subscribe(listener: () => void): () => void;
    dispose(): void;
};
