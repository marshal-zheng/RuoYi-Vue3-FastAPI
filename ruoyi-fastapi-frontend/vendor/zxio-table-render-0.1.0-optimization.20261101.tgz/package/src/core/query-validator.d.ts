import type { GridListQueryValidator } from '@zxio/zxui/grid-list';
import type { Json, QueryShape, TableRenderDefinition } from './types';
/** Root-key absence is the canonical representation of an empty UI filter. */
export declare function normalizeQuery(input: unknown): Readonly<Record<string, Json>>;
export declare function defaultQuery<Row extends object, Q extends QueryShape<Q>>(definition: TableRenderDefinition<Row, Q>): Readonly<Record<string, Json>>;
export declare function buildQueryValidator<Row extends object, Q extends QueryShape<Q>>(definition: TableRenderDefinition<Row, Q>): GridListQueryValidator;
