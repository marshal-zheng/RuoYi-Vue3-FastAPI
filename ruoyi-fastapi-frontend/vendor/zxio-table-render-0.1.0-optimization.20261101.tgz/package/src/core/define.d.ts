import type { CheckDefinition, LogicalQuery, Pager, QueryShape, TableQueryInput, TableRenderDefinition, TableRenderTypeInfo } from './types';
export declare function defineTableRender<Row extends object, Q extends QueryShape<Q> = LogicalQuery, Params extends {
    pager: Pager | null;
} = TableQueryInput<Q>>(): <const D extends TableRenderDefinition<Row, Q, Params> & (TableQueryInput<Q> extends Params ? unknown : {
    readonly transform: (input: TableQueryInput<Q>) => Params;
})>(definition: D, ..._check: D extends {
    sort: unknown;
} ? D extends CheckDefinition<D> ? [] : [invalidDefaultSort: never] : []) => Readonly<D> & TableRenderTypeInfo<Row, Q>;
