import type { RowFieldKey, SearchKey } from './types';
/** Maps explicitly selected raw paths. This does not create submit/read/action authorization. */
export declare function tableRenderPolicyFields<D extends {
    readonly search?: readonly {
        readonly key: string;
    }[];
    readonly columns: readonly {
        readonly key: string;
        readonly prop?: string;
    }[];
}, const Q extends readonly SearchKey<D>[], const R extends readonly RowFieldKey<D>[]>(definition: D, selection: {
    readonly query: Q;
    readonly row: R;
}): Readonly<{
    query: Readonly<{ readonly [K in Q[number]]: readonly ["query", K]; }>;
    condition: Readonly<{ readonly [K in Q[number]]: readonly ["query", K]; }>;
    row: Readonly<{ readonly [K_1 in R[number]]: readonly string[]; }>;
}>;
