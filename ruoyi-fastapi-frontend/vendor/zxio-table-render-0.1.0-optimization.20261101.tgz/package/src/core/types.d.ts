import type { Component, VNodeChild } from 'vue';
import type { Json, ValueShape } from '@zxio/schema-form';
import type { GridListQueryAttemptContext, GridListQueryCompletion, GridListQueryIssue } from '@zxio/zxui/grid-list';
import type { ZxToolbarAction } from '@zxio/zxui/more-action';
export type { Json, ValueShape, GridListQueryIssue };
export type LogicalQuery = Readonly<Record<string, Json | undefined>>;
export type JsonInput<T> = T extends (...args: any[]) => any ? never : T extends null | boolean | string | number | undefined ? T : T extends readonly (infer V)[] ? readonly JsonInput<V>[] : T extends object ? {
    [K in keyof T]: JsonInput<T[K]>;
} : never;
export type QueryShape<Q> = {
    [K in keyof Q]: JsonInput<Q[K]>;
};
declare const definitionTypes: unique symbol;
/** Type-only identity preserves the curried Row/Query parameters for Vue inference. */
export interface TableRenderTypeInfo<Row extends object, Q> {
    readonly [definitionTypes]?: {
        readonly row: Row;
        readonly query: Q;
    };
}
export type TableRenderRow<D> = D extends TableRenderTypeInfo<infer Row, any> ? Row : object;
export type TableRenderQuery<D> = D extends TableRenderTypeInfo<object, infer Q> ? Q : LogicalQuery;
export type RowKeyValue = string | number;
export type KeysOfType<T, V> = {
    [K in keyof T]-?: T[K] extends V ? K : never;
}[keyof T] & string;
/** Own object paths; arrays are values, and traversal stops after four keys. */
export type PathOf<T, Depth extends unknown[] = []> = Depth['length'] extends 4 ? never : T extends readonly unknown[] | Date | ((...args: any[]) => any) ? never : T extends object ? {
    [K in keyof T & string]: K | (PathOf<NonNullable<T[K]>, [
        ...Depth,
        0
    ]> extends infer P extends string ? `${K}.${P}` : never);
}[keyof T & string] : never;
export type PathValue<T, P extends string> = T extends null | undefined ? undefined : P extends `${infer K}.${infer Rest}` ? K extends keyof T ? PathValue<T[K], Rest> : never : P extends keyof T ? T[P] : never;
export type RowIdentityPath<Row> = {
    [P in PathOf<Row>]: PathValue<Row, P> extends RowKeyValue ? P : never;
}[PathOf<Row>];
export interface Pager {
    readonly page: number;
    readonly size: number;
}
export interface SortItem<F extends string = string> {
    readonly field: F;
    readonly order: 'asc' | 'desc';
}
export interface TableQueryInput<Q, S extends string = string> {
    readonly query: Partial<Q>;
    readonly pager: Pager | null;
    readonly sort: readonly SortItem<S>[];
}
export interface TableApplied<Q> extends TableQueryInput<Q> {
    readonly domainKey: string;
}
export interface TableDisplayed<Q> {
    readonly domainKey: string;
    readonly revision: string | number;
    readonly input: Readonly<TableQueryInput<Q>>;
}
export interface TableResult<Row> {
    readonly list: readonly Row[];
    readonly pager?: {
        readonly total: number;
        readonly page?: number;
        readonly size?: number;
    };
}
export type TableRequest<Row, Params> = (params: Readonly<Params>, context: GridListQueryAttemptContext) => TableResult<Row> | Promise<TableResult<Row>>;
export interface TableQueryIntent<Q> {
    readonly kind: 'search' | 'reset' | 'reload' | 'requery';
    readonly domainKey: string;
    readonly input: Readonly<TableQueryInput<Q>>;
}
export type TableCommandResult<Q> = GridListQueryCompletion | {
    readonly kind: 'intent-emitted';
    readonly intent: TableQueryIntent<Q>;
};
export interface TableOption<V extends Json = Json> {
    readonly value: V;
    readonly label: string;
    readonly tone?: 'default' | 'primary' | 'success' | 'warning' | 'danger' | 'info';
}
export interface OptionsLoadContext<P extends Json = Json> {
    readonly params: P | undefined;
    readonly domainKey: string;
    readonly signal: AbortSignal;
}
export type OptionsSource<V extends Json = Json, P extends Json = Json> = readonly TableOption<V>[] | {
    readonly key: string;
    readonly params?: () => P;
    readonly load: {
        load(context: OptionsLoadContext<P>): Promise<readonly TableOption<V>[]>;
    }['load'];
};
export type OptionsCompletion = {
    readonly kind: 'loaded';
    readonly sourceKey: string;
} | {
    readonly kind: 'failed';
    readonly sourceKey: string;
    readonly code: string;
} | {
    readonly kind: 'obsolete';
    readonly sourceKey: string;
};
export type SearchControl = 'text' | 'number' | 'select' | 'multi-select' | 'date' | 'date-range' | 'boolean';
export interface SearchField<Q extends QueryShape<Q>, K extends keyof Q & string = keyof Q & string> {
    readonly key: K;
    readonly label: string;
    readonly control: SearchControl | {
        readonly slot: string;
    };
    readonly placement?: 'keyword' | 'inline' | 'more';
    readonly trigger?: 'change' | 'confirm';
    readonly options?: OptionsSource;
    readonly shape?: ValueShape;
    readonly default?: Q[K];
    readonly placeholder?: string;
    readonly toLogical?: (ui: unknown) => Q[K] | undefined;
    readonly fromLogical?: (logical: Q[K] | undefined) => unknown;
    readonly validate?: (value: Q[K]) => string | null;
    readonly messages?: Readonly<Record<string, string>>;
}
export type SearchFields<Q extends QueryShape<Q>> = {
    [K in keyof Q & string]: SearchField<Q, K>;
}[keyof Q & string];
export interface ColumnBase {
    readonly key: string;
    readonly label: string;
    readonly width?: number | string;
    readonly minWidth?: number | string;
    readonly align?: 'left' | 'center' | 'right';
    readonly fixed?: 'left' | 'right';
    readonly overflow?: 'tooltip' | 'wrap';
    readonly sortable?: 'server' | 'local';
    readonly localSortScope?: 'loaded-page' | 'all-loaded';
    readonly hideable?: boolean;
    readonly headerSlot?: string;
    readonly headerRender?: (header: {
        column: ColumnBase;
        index: number;
    }) => VNodeChild;
}
export interface CellContext<Row extends object, Value = unknown> {
    readonly row: Row;
    readonly column: ColumnBase;
    readonly value: Value;
    readonly index: number;
}
export type ColumnPresentation = {
    readonly type?: 'text';
} | {
    readonly type: 'number';
    readonly precision?: number;
    readonly unit?: string;
} | {
    readonly type: 'date' | 'datetime';
    readonly format?: string;
} | {
    readonly type: 'enum';
    readonly options: OptionsSource;
    readonly tag?: boolean;
} | {
    readonly type: 'boolean';
    readonly labels?: readonly [falseLabel: string, trueLabel: string];
} | {
    readonly type: 'custom';
    readonly slot?: string;
};
export type PathColumn<Row extends object, P extends PathOf<Row>> = ColumnBase & ColumnPresentation & {
    readonly prop: P;
    readonly render?: (cell: CellContext<Row, PathValue<Row, P>>) => VNodeChild;
};
export type Column<Row extends object> = {
    [P in PathOf<Row>]: PathColumn<Row, P>;
}[PathOf<Row>] | (ColumnBase & {
    readonly type: 'custom';
    readonly prop?: undefined;
    readonly slot?: string;
    readonly value?: (row: Row) => unknown;
    readonly render?: {
        render(cell: CellContext<Row>): VNodeChild;
    }['render'];
}) | (ColumnBase & {
    readonly type: 'actions';
}) | (ColumnBase & {
    readonly type: 'index';
    readonly indexScope?: 'page' | 'pagination';
});
export type ColumnValue<Row, C> = C extends {
    value: (...args: never[]) => infer V;
} ? V : C extends {
    prop: infer P extends string;
} ? PathValue<Row, P> : undefined;
export interface TableColumnState<K extends string = string> {
    readonly version: 1;
    readonly columns: readonly {
        readonly key: K;
        readonly visible?: boolean;
        readonly width?: number;
        readonly fixed?: 'left' | 'right' | null;
    }[];
}
export interface TableScopedKeys {
    readonly scopeRef: string;
    readonly keys: readonly RowKeyValue[];
}
export interface TableSelectionOptions<Row> {
    readonly mode: 'multiple';
    readonly scope?: 'page' | 'explicit';
    readonly selectable?: (row: Row) => boolean;
    readonly rowClick?: boolean;
}
export interface Selection<Row> {
    readonly scope: 'page' | 'explicit';
    readonly scopeRef: string;
    readonly keys: readonly RowKeyValue[];
    readonly loadedRows: readonly Row[];
    readonly missingKeys: readonly RowKeyValue[];
}
export interface ActionContext<Q> {
    readonly applied: Readonly<TableApplied<Q>> | null;
    readonly signal: AbortSignal;
    readonly reload: () => Promise<TableCommandResult<Q>>;
}
export interface ActionBase {
    readonly id: string;
    readonly label: string;
    readonly icon?: string | Component;
    readonly tone?: ZxToolbarAction['tone'];
    readonly variant?: ZxToolbarAction['variant'];
    readonly reloadAfter?: boolean;
}
export interface TableActions<Row, Q> {
    readonly toolbar?: readonly (ActionBase & {
        readonly confirm?: string | ((ctx: ActionContext<Q>) => string);
        visible?(ctx: ActionContext<Q>): boolean;
        disabled?(ctx: ActionContext<Q>): boolean;
        run(ctx: ActionContext<Q>): unknown;
    })[];
    readonly batch?: readonly (ActionBase & {
        readonly confirm?: string | ((selection: Selection<Row>, ctx: ActionContext<Q>) => string);
        readonly requiresSelection?: boolean;
        visible?(ctx: ActionContext<Q>): boolean;
        disabled?(selection: Selection<Row>, ctx: ActionContext<Q>): boolean;
        run(selection: Selection<Row>, ctx: ActionContext<Q>): unknown;
    })[];
    readonly row?: readonly (ActionBase & {
        readonly confirm?: string | ((row: Row, ctx: ActionContext<Q>) => string);
        readonly overflow?: boolean;
        visible?(row: Row, ctx: ActionContext<Q>): boolean;
        disabled?(row: Row, ctx: ActionContext<Q>): boolean;
        run(row: Row, ctx: ActionContext<Q>): unknown;
    })[];
}
export interface TableRenderDefinition<Row extends object, Q extends QueryShape<Q>, Params extends {
    pager: Pager | null;
} = TableQueryInput<Q>> {
    readonly key: string;
    readonly title: string;
    readonly rowKey?: RowIdentityPath<Row> | ((row: Row) => RowKeyValue);
    readonly search?: readonly SearchFields<Q>[];
    readonly columns: readonly Column<Row>[];
    readonly actions?: TableActions<Row, Q>;
    readonly selection?: false | TableSelectionOptions<Row>;
    readonly tree?: {
        readonly children: KeysOfType<Row, readonly Row[] | undefined>;
        readonly defaultExpandAll?: boolean;
    };
    readonly sort?: {
        readonly default?: readonly SortItem[];
    };
    readonly pagination?: false | {
        readonly pageSize?: number;
        readonly pageSizes?: readonly number[];
    };
    readonly layout?: {
        readonly fill?: boolean;
        readonly inlineLimit?: number;
        readonly rowActionLimit?: number;
    };
    readonly request?: TableRequest<Row, Params>;
    readonly transform?: (input: TableQueryInput<Q>) => Params;
    readonly validate?: (input: {
        query: Partial<Q>;
        sort: readonly SortItem[];
    }) => readonly GridListQueryIssue[];
}
export type ColumnKey<D> = D extends {
    columns: readonly (infer C)[];
} ? C extends {
    key: infer K extends string;
} ? K : never : never;
export type ServerSortKey<D> = D extends {
    columns: readonly (infer C)[];
} ? C extends {
    key: infer K extends string;
    sortable: 'server';
} ? K : never : never;
export type SearchKey<D> = D extends {
    search: readonly (infer F)[];
} ? F extends {
    key: infer K extends string;
} ? K : never : never;
export type ShapedSearchKey<D> = D extends {
    search: readonly (infer F)[];
} ? F extends {
    key: infer K extends string;
    shape: ValueShape;
} ? K : never : never;
export type RowFieldKey<D> = D extends {
    columns: readonly (infer C)[];
} ? C extends {
    key: infer K extends string;
    prop: string;
} ? K : never : never;
export type ActionsOf<D, G extends 'toolbar' | 'batch' | 'row'> = D extends {
    actions: {
        [P in G]?: readonly (infer A)[];
    };
} ? A : never;
export type ActionId<D> = ActionsOf<D, 'toolbar'> | ActionsOf<D, 'batch'> | ActionsOf<D, 'row'> extends infer A ? A extends {
    id: infer I extends string;
} ? I : never : never;
export type CheckDefinition<D> = {
    readonly sort?: {
        readonly default?: readonly SortItem<ServerSortKey<D>>[];
    };
};
