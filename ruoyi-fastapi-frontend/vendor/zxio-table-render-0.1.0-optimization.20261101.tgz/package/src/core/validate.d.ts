import type { TableOption } from './types';
export declare function definitionError(path: string, code: string): never;
export declare function validateOptions(value: unknown, path?: string): asserts value is readonly TableOption[];
export declare function validateDefinition(input: unknown): void;
