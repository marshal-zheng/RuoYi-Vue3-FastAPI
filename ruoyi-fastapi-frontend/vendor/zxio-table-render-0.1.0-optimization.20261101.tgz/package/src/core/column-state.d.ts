import type { ColumnBase, TableColumnState } from './types';
export declare function columnWidthBounds(column: ColumnBase): {
    min: number;
    max: number;
};
export declare function columnWidth(column: ColumnBase, value: unknown): number | undefined;
/** Stored order is authoritative; new definition columns append in default order. */
export declare function reconcileColumnState<const C extends ColumnBase>(columns: readonly C[], state?: TableColumnState | null): TableColumnState<C['key']>;
