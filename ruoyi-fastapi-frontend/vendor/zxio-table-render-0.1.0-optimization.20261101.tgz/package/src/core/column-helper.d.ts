import type { VNodeChild } from 'vue';
import type { CellContext, ColumnBase, PathColumn, PathOf } from './types';
/** Compile-time inference only. The renderer still consumes ordinary columns. */
export declare function createTableColumnHelper<Row extends object>(): {
    accessor<const P extends PathOf<Row>, const O extends Omit<PathColumn<Row, P>, "prop">>(prop: P, options: O): O & {
        readonly prop: P;
    };
    computed<Value, const K extends string>(options: ColumnBase & {
        readonly key: K;
        readonly value: (row: Row) => Value;
        readonly render?: (cell: CellContext<Row, NoInfer<Value>>) => VNodeChild;
    }): {
        type: "custom";
        key: K;
        label: string;
        width?: number | string;
        minWidth?: number | string;
        align?: "left" | "center" | "right";
        fixed?: "left" | "right";
        overflow?: "tooltip" | "wrap";
        sortable?: "server" | "local";
        localSortScope?: "loaded-page" | "all-loaded";
        hideable?: boolean;
        headerSlot?: string;
        headerRender?: (header: {
            column: ColumnBase;
            index: number;
        }) => VNodeChild;
        value: (row: Row) => Value;
        render?: (cell: CellContext<Row, NoInfer<Value>>) => VNodeChild;
    };
};
