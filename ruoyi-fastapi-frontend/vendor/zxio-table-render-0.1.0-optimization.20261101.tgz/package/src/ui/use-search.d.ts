import type { GridListQueryIssue, ZxGridListInstance } from '@zxio/zxui/grid-list';
import type { AnyDefinition, TableApplied } from './contracts';
import type { LogicalQuery, SearchFields, TableCommandResult } from '../core/types';
export declare function locateSearchFields(definition: AnyDefinition): {
    readonly field: import("../core/types").SearchField<any, string>;
    readonly placement: "keyword" | "inline" | "more";
    readonly trigger: "change" | "confirm";
}[];
export declare function useSearch(options: {
    definition: AnyDefinition;
    grid: () => ZxGridListInstance | undefined;
    query: () => LogicalQuery;
    applied: () => TableApplied<any> | null;
    update: (query: LogicalQuery) => void;
    intent: (type: 'search' | 'reset', query: LogicalQuery) => TableCommandResult<any>;
    domainKey: () => string;
}): {
    defaults: {
        query: Readonly<Record<string, import("@zxio/schema-form").Json>>;
        sort: readonly import("../core/types").SortItem<string>[];
    };
    validator: import("@zxio/zxui/grid-list").GridListQueryValidator;
    draft: import("vue").ComputedRef<Readonly<Record<string, import("@zxio/schema-form").Json | undefined>>>;
    applied: import("vue").ComputedRef<TableApplied<any> | null>;
    dirty: import("vue").ComputedRef<boolean>;
    issues: import("vue").ShallowRef<readonly GridListQueryIssue[], readonly GridListQueryIssue[]>;
    pending: import("vue").Reactive<Set<string>>;
    resetEpoch: import("vue").ShallowRef<number, number>;
    located: {
        readonly field: import("../core/types").SearchField<any, string>;
        readonly placement: "keyword" | "inline" | "more";
        readonly trigger: "change" | "confirm";
    }[];
    draftHold: () => boolean;
    setDraft: (value: LogicalQuery, config?: {
        replace?: boolean;
    }) => void;
    commit: (field: SearchFields<any>, ui: unknown) => Promise<{
        readonly kind: "terminal";
        readonly operation: import("@zxio/zxui/grid-list").GridListQueryTerminalOperation;
    } | {
        readonly kind: "not-started";
        readonly reason: string;
        readonly issues?: readonly GridListQueryIssue[];
    } | {
        readonly kind: "intent-emitted";
        readonly intent: import("../core/types").TableQueryIntent<any>;
    } | {
        kind: string;
        reason: string;
    } | undefined>;
    reset: () => Promise<TableCommandResult<any>>;
    clearEditing: () => void;
    setPending(key: string, value: boolean): void;
    search: () => Promise<TableCommandResult<any>>;
};
export type TableSearch = ReturnType<typeof useSearch>;
