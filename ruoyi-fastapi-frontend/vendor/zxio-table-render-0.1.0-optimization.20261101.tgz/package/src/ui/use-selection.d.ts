import type { RowKeyValue, Selection, TableDisplayed, TableScopedKeys } from '../core/types';
export interface SelectionTable<Row> {
    clearSelection(): void;
    toggleRowSelection(row: Row, selected?: boolean, ignoreSelectable?: boolean): void;
}
export declare function useSelection<Row extends object>(options: {
    enabled: boolean;
    scope: 'page' | 'explicit';
    scopeKey: () => string | undefined;
    state: () => TableScopedKeys | null | undefined;
    defaults: readonly RowKeyValue[];
    rows: () => readonly Row[];
    rowKey: (row: Row) => RowKeyValue | undefined;
    selectable: (row: Row) => boolean;
    invalid: () => boolean;
    displayed: () => TableDisplayed<any> | null;
    domain: () => string;
    table: () => SelectionTable<Row> | undefined;
    update: (value: TableScopedKeys) => void;
    change: (value: Selection<Row>) => void;
}): {
    selection: import("vue").ComputedRef<Selection<Row>>;
    toggle: (row: Row, checked: boolean) => void;
    toggleAll: (checked: boolean) => void;
    checked: (row: Row) => boolean;
    clear: () => void;
    setKeys: (keys: readonly RowKeyValue[]) => void;
    select: (selection: Row[], row: Row) => void;
    selectAll: (selection: Row[]) => void;
};
