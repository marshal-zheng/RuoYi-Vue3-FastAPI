import type { TableColumnCtx } from 'element-plus';
import type { ActionId, ColumnKey, TableColumnState, TableRenderDefinition, TableRenderQuery, TableRenderRow } from '../core/types';
import type { TableRenderBaseProps, TableRenderInstance, TableRenderSlots } from './contracts';
declare const _default: <D extends TableRenderDefinition<any, any, any>>(__VLS_props: NonNullable<Awaited<typeof __VLS_setup>>["props"], __VLS_ctx?: __VLS_PrettifyLocal<Pick<NonNullable<Awaited<typeof __VLS_setup>>, "attrs" | "emit" | "slots">>, __VLS_expose?: NonNullable<Awaited<typeof __VLS_setup>>["expose"], __VLS_setup?: Promise<{
    props: __VLS_PrettifyLocal<Pick<Partial<{}> & Omit<{
        readonly "onUpdate:query"?: ((value: Partial<TableRenderQuery<D>>) => any) | undefined;
        readonly "onQuery-intent"?: ((intent: import("../core/types").TableQueryIntent<TableRenderQuery<D>>) => any) | undefined;
        readonly "onUpdate:columnState"?: ((value: TableColumnState<ColumnKey<D>>) => any) | undefined;
        readonly "onUpdate:selectionState"?: ((value: import("../core/types").TableScopedKeys) => any) | undefined;
        readonly "onSelection-change"?: ((value: import("../core/types").Selection<TableRenderRow<D>>) => any) | undefined;
        readonly "onUpdate:expandedState"?: ((value: import("../core/types").TableScopedKeys) => any) | undefined;
        readonly "onUpdate:currentRowKey"?: ((value: import("../core/types").RowKeyValue | null) => any) | undefined;
        readonly "onRow-click"?: ((row: TableRenderRow<D>, column: TableColumnCtx<TableRenderRow<D>> | null, event: MouseEvent) => any) | undefined;
        readonly "onRow-dblclick"?: ((row: TableRenderRow<D>, column: TableColumnCtx<TableRenderRow<D>> | null, event: MouseEvent) => any) | undefined;
        readonly "onConfiguration-error"?: ((error: {
            code: string;
            keys?: readonly import("../core/types").RowKeyValue[];
        }) => any) | undefined;
        readonly "onAction-error"?: ((error: {
            actionId: ActionId<D>;
            rowKey?: import("../core/types").RowKeyValue;
            error: unknown;
        }) => any) | undefined;
    } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never>, "onUpdate:query" | "onQuery-intent" | "onUpdate:columnState" | "onUpdate:selectionState" | "onSelection-change" | "onUpdate:expandedState" | "onUpdate:currentRowKey" | "onRow-click" | "onRow-dblclick" | "onConfiguration-error" | "onAction-error"> & TableRenderBaseProps<D> & Partial<{}>> & import("vue").PublicProps;
    expose(exposed: import("vue").ShallowUnwrapRef<TableRenderInstance<D, TableRenderRow<D>, TableRenderQuery<D>>>): void;
    attrs: any;
    slots: TableRenderSlots<D, TableRenderRow<D>>;
    emit: ((evt: "update:query", value: Partial<TableRenderQuery<D>>) => void) & ((evt: "query-intent", intent: import("../core/types").TableQueryIntent<TableRenderQuery<D>>) => void) & ((evt: "update:columnState", value: TableColumnState<ColumnKey<D>>) => void) & ((evt: "update:selectionState", value: import("../core/types").TableScopedKeys) => void) & ((evt: "selection-change", value: import("../core/types").Selection<TableRenderRow<D>>) => void) & ((evt: "update:expandedState", value: import("../core/types").TableScopedKeys) => void) & ((evt: "update:currentRowKey", value: import("../core/types").RowKeyValue | null) => void) & ((evt: "row-click", row: TableRenderRow<D>, column: TableColumnCtx<TableRenderRow<D>> | null, event: MouseEvent) => void) & ((evt: "row-dblclick", row: TableRenderRow<D>, column: TableColumnCtx<TableRenderRow<D>> | null, event: MouseEvent) => void) & ((evt: "configuration-error", error: {
        code: string;
        keys?: readonly import("../core/types").RowKeyValue[];
    }) => void) & ((evt: "action-error", error: {
        actionId: ActionId<D>;
        rowKey?: import("../core/types").RowKeyValue;
        error: unknown;
    }) => void);
}>) => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}> & {
    __ctx?: Awaited<typeof __VLS_setup>;
};
export default _default;
type __VLS_PrettifyLocal<T> = {
    [K in keyof T]: T[K];
} & {};
