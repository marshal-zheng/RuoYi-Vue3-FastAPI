import type { RowKeyValue, TableDisplayed, TableScopedKeys } from '../core/types';
export declare function useExpansion<Row extends object>(options: {
    enabled: boolean;
    table: () => {
        toggleRowExpansion(row: Row, expanded: boolean): void;
    } | undefined;
    state: () => TableScopedKeys | null | undefined;
    defaults: readonly RowKeyValue[];
    defaultAll: boolean;
    domain: () => string;
    displayed: () => TableDisplayed<any> | null;
    expandable: () => readonly Row[];
    rowKey: (row: Row) => RowKeyValue | undefined;
    invalid: () => boolean;
    update: (value: TableScopedKeys) => void;
}): {
    keys: import("vue").ComputedRef<RowKeyValue[]>;
    encoded: import("vue").ComputedRef<string[]>;
    setKeys: (value: readonly RowKeyValue[]) => void;
    toggle(row: Row, expanded: boolean): void;
};
