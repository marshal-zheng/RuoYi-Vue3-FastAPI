import type { Column, TableColumnState } from '../core/types';
export declare function useColumns<Row extends object>(options: {
    columns: readonly Column<Row>[];
    state: () => TableColumnState | undefined;
    defaults?: TableColumnState;
    domain: () => string;
    update: (state: TableColumnState) => void;
}): {
    state: import("vue").ComputedRef<TableColumnState<Column<Row>["key"]>>;
    columns: import("vue").ComputedRef<(({ [P_1 in Row extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : Row extends object ? { [K in keyof Row & string]: K | ((NonNullable<Row[K]> extends infer T ? T extends NonNullable<Row[K]> ? T extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : T extends object ? { [K_1 in keyof T & string]: K_1 | ((NonNullable<T[K_1]> extends infer T_1 ? T_1 extends NonNullable<T[K_1]> ? T_1 extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : T_1 extends object ? { [K_2 in keyof T_1 & string]: K_2 | ((NonNullable<T_1[K_2]> extends infer T_2 ? T_2 extends NonNullable<T_1[K_2]> ? T_2 extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : T_2 extends object ? { [K_3 in keyof T_2 & string]: K_3; }[keyof T_2 & string] : never : never : never) extends infer P extends string ? `${K_2}.${P}` : never); }[keyof T_1 & string] : never : never : never) extends infer P extends string ? `${K_1}.${P}` : never); }[keyof T & string] : never : never : never) extends infer P extends string ? `${K}.${P}` : never); }[keyof Row & string] : never]: import("../core/types").PathColumn<Row, P_1>; }[Row extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : Row extends object ? { [K in keyof Row & string]: K | ((NonNullable<Row[K]> extends infer T ? T extends NonNullable<Row[K]> ? T extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : T extends object ? { [K_1 in keyof T & string]: K_1 | ((NonNullable<T[K_1]> extends infer T_1 ? T_1 extends NonNullable<T[K_1]> ? T_1 extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : T_1 extends object ? { [K_2 in keyof T_1 & string]: K_2 | ((NonNullable<T_1[K_2]> extends infer T_2 ? T_2 extends NonNullable<T_1[K_2]> ? T_2 extends Date | readonly unknown[] | ((...args: any[]) => any) ? never : T_2 extends object ? { [K_3 in keyof T_2 & string]: K_3; }[keyof T_2 & string] : never : never : never) extends infer P extends string ? `${K_2}.${P}` : never); }[keyof T_1 & string] : never : never : never) extends infer P extends string ? `${K_1}.${P}` : never); }[keyof T & string] : never : never : never) extends infer P extends string ? `${K}.${P}` : never); }[keyof Row & string] : never] & {
        width: string | number | undefined;
        fixed: "left" | "right" | undefined;
        key: Column<Row>["key"];
        visible?: boolean;
    }) | {
        width: string | number | undefined;
        fixed: "left" | "right" | undefined;
        key: Column<Row>["key"];
        visible?: boolean;
        label: string;
        minWidth?: number | string;
        align?: "left" | "center" | "right";
        overflow?: "tooltip" | "wrap";
        sortable?: "server" | "local";
        localSortScope?: "loaded-page" | "all-loaded";
        hideable?: boolean;
        headerSlot?: string;
        headerRender?: (header: {
            column: import("../core/types").ColumnBase;
            index: number;
        }) => import("vue").VNodeChild;
        type: "actions";
    } | {
        width: string | number | undefined;
        fixed: "left" | "right" | undefined;
        key: Column<Row>["key"];
        visible?: boolean;
        label: string;
        minWidth?: number | string;
        align?: "left" | "center" | "right";
        overflow?: "tooltip" | "wrap";
        sortable?: "server" | "local";
        localSortScope?: "loaded-page" | "all-loaded";
        hideable?: boolean;
        headerSlot?: string;
        headerRender?: (header: {
            column: import("../core/types").ColumnBase;
            index: number;
        }) => import("vue").VNodeChild;
        type: "index";
        indexScope?: "page" | "pagination";
    } | {
        width: string | number | undefined;
        fixed: "left" | "right" | undefined;
        key: Column<Row>["key"];
        visible?: boolean;
        label: string;
        minWidth?: number | string;
        align?: "left" | "center" | "right";
        overflow?: "tooltip" | "wrap";
        sortable?: "server" | "local";
        localSortScope?: "loaded-page" | "all-loaded";
        hideable?: boolean;
        headerSlot?: string;
        headerRender?: (header: {
            column: import("../core/types").ColumnBase;
            index: number;
        }) => import("vue").VNodeChild;
        type: "custom";
        prop?: undefined;
        slot?: string;
        value?: ((row: Row) => unknown) | undefined;
        render?: ((cell: import("../core/types").CellContext<Row, unknown>) => import("vue").VNodeChild) | undefined;
    })[]>;
    set: (next: TableColumnState) => void;
    reset: () => void;
    patch(key: string, patch: Omit<TableColumnState["columns"][number], "key">): void;
    move(key: string, offset: number): void;
};
