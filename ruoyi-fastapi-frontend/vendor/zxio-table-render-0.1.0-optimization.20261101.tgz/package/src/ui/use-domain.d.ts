import type { GridListQueryContext } from '@zxio/zxui/grid-list';
/** An instance epoch fences deferred UI work; the Host remains the query owner. */
export declare function useDomain(options: {
    request: boolean;
    context: () => GridListQueryContext | undefined;
    controlledKey: () => string | undefined;
    invalidate: () => void;
    reset: () => Promise<unknown>;
}): {
    key: import("vue").ShallowRef<string, string>;
    ready: import("vue").ShallowRef<boolean, boolean>;
    epoch: import("vue").ShallowRef<number, number>;
    identity: import("vue").ComputedRef<string>;
};
