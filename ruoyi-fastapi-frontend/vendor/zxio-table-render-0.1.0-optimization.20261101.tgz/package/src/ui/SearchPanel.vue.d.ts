import type { TableSearch } from './use-search';
import type { TableOptions } from './use-options';
import type { SearchSlotContext, TableRenderLocale } from './contracts';
type __VLS_Props = {
    search: TableSearch;
    options: TableOptions;
    locale: TableRenderLocale;
    placement: 'inline' | 'search';
};
type __VLS_Slots = {
    [key: string]: (context: SearchSlotContext) => unknown;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
