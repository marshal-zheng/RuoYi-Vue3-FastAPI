import type { AnyDefinition } from './contracts';
import type { OptionsCompletion, OptionsSource, TableOption } from '../core/types';
export declare function useOptions(definition: AnyDefinition, domain: {
    key: () => string;
    epoch: () => string;
    ready: () => boolean;
}): {
    failed: import("vue").ComputedRef<{
        readonly key: string;
        readonly params?: (() => import("@zxio/schema-form").Json) | undefined;
        readonly load: (context: import("../core/types").OptionsLoadContext<import("@zxio/schema-form").Json>) => Promise<readonly TableOption<import("@zxio/schema-form").Json>[]>;
    }[]>;
    retryFailed: () => Promise<OptionsCompletion[]>;
    state(source: OptionsSource | undefined): import("../core/options").OptionsState;
    retry(source: OptionsSource): Promise<OptionsCompletion> | undefined;
    refresh(sourceKey?: string): Promise<OptionsCompletion[]>;
};
export type TableOptions = ReturnType<typeof useOptions>;
