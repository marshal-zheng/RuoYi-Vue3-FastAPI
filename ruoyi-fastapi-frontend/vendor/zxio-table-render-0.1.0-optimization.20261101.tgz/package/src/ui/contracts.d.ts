import type { PublicProps, VNode, VNodeChild } from 'vue';
import type { TableColumnCtx, TableProps } from 'element-plus';
import type { GridListControlledStatus, GridListQueryContext, GridListQueryOwner } from '@zxio/zxui/grid-list';
import type { ActionId, CellContext, ColumnBase, ColumnKey, ColumnValue, OptionsCompletion, Pager, RowKeyValue, SearchKey, Selection, ServerSortKey, SortItem, TableApplied, TableColumnState, TableCommandResult, TableDisplayed, TableQueryIntent, TableRenderDefinition, TableRenderQuery, TableRenderRow, TableScopedKeys } from '../core/types';
export type { TableApplied } from '../core/types';
export type AnyDefinition = TableRenderDefinition<any, any, any>;
export interface TableRenderLocale {
    search: string;
    reset: string;
    more: string;
    apply: string;
    close: string;
    dirty: string;
    applied: string;
    invalid: string;
    incomplete: string;
    dictionaryUnavailable: string;
    yes: string;
    no: string;
    all: string;
    actions: string;
    confirm: string;
    cancel: string;
    actionCancelled: string;
    columns: string;
    width: string;
    pin: string;
    unpinned: string;
    left: string;
    right: string;
    moveUp: string;
    moveDown: string;
    resetColumns: string;
    selected: string;
    missing: string;
    clearSelection: string;
    selectRow: string;
    selectAll: string;
    expand: string;
    collapse: string;
    hiddenSort: string;
    clearSort: string;
    loadedPageSort: string;
    retryOptions: string;
}
export type TableRenderTableProps<Row extends object> = Pick<TableProps<Row>, 'size' | 'border' | 'stripe' | 'height' | 'maxHeight' | 'showHeader' | 'rowClassName' | 'cellClassName'>;
export interface TableRenderBaseProps<D extends AnyDefinition> {
    definition: D;
    queryContext?: GridListQueryContext;
    query?: Partial<TableRenderQuery<D>>;
    applied?: TableApplied<TableRenderQuery<D>> | null;
    displayed?: TableDisplayed<TableRenderQuery<D>> | null;
    rows?: readonly TableRenderRow<D>[];
    pagination?: Pager & {
        total: number;
    };
    status?: GridListControlledStatus;
    domainKey?: string;
    locale?: Partial<TableRenderLocale>;
    columnState?: TableColumnState<ColumnKey<D>>;
    defaultColumnState?: TableColumnState<ColumnKey<D>>;
    selectionState?: TableScopedKeys | null;
    defaultSelectionKeys?: readonly RowKeyValue[];
    selectionScopeKey?: string;
    expandedState?: TableScopedKeys | null;
    defaultExpandedKeys?: readonly RowKeyValue[];
    currentRowKey?: RowKeyValue | null;
    tableProps?: Partial<TableRenderTableProps<TableRenderRow<D>>>;
}
export type ZxTableRenderProps<D extends AnyDefinition> = Omit<TableRenderBaseProps<D>, 'selectionState' | 'defaultSelectionKeys'> & ({
    selectionState?: undefined;
    defaultSelectionKeys?: readonly RowKeyValue[];
} | {
    selectionState: TableScopedKeys | null;
    defaultSelectionKeys?: never;
}) & (D extends {
    selection: {
        scope: 'explicit';
    };
} ? {
    selectionScopeKey: string;
} : object) & (D extends {
    request: NonNullable<AnyDefinition['request']>;
} ? object : {
    domainKey: string;
    applied: TableApplied<TableRenderQuery<D>> | null;
    displayed: TableDisplayed<TableRenderQuery<D>> | null;
});
export interface ZxTableRenderEmits<D, Q> {
    'update:query': [value: Partial<Q>];
    'query-intent': [intent: TableQueryIntent<Q>];
    'update:columnState': [value: TableColumnState<ColumnKey<D>>];
    'update:selectionState': [value: TableScopedKeys];
    'selection-change': [value: Selection<TableRenderRow<D>>];
    'update:expandedState': [value: TableScopedKeys];
    'update:currentRowKey': [value: RowKeyValue | null];
    'row-click': [
        row: TableRenderRow<D>,
        column: TableColumnCtx<TableRenderRow<D>> | null,
        event: MouseEvent
    ];
    'row-dblclick': [
        row: TableRenderRow<D>,
        column: TableColumnCtx<TableRenderRow<D>> | null,
        event: MouseEvent
    ];
    'configuration-error': [
        error: {
            code: string;
            keys?: readonly RowKeyValue[];
        }
    ];
    'action-error': [
        error: {
            actionId: ActionId<D>;
            rowKey?: RowKeyValue;
            error: unknown;
        }
    ];
}
export interface TableRenderInstance<D, Row, Q> {
    readonly mode: 'request' | 'controlled';
    readonly queryOwner: GridListQueryOwner | undefined;
    readonly draft: Partial<Q>;
    readonly applied: TableApplied<Q> | null;
    readonly displayed: TableDisplayed<Q> | null;
    readonly dirty: boolean;
    readonly selection: Selection<Row>;
    readonly columnState: TableColumnState<ColumnKey<D>>;
    readonly expandedKeys: readonly RowKeyValue[];
    setDraft(value: Partial<Q>, options?: {
        replace?: boolean;
    }): void;
    search(): Promise<TableCommandResult<Q>>;
    reset(): Promise<TableCommandResult<Q>>;
    reload(): Promise<TableCommandResult<Q>>;
    requery(change: {
        page?: number;
        size?: number;
        sort?: readonly SortItem<ServerSortKey<D>>[];
    }): Promise<TableCommandResult<Q>>;
    clearSelection(): void;
    setSelectionKeys(keys: readonly RowKeyValue[]): void;
    setExpandedKeys(keys: readonly RowKeyValue[]): void;
    setColumnState(state: TableColumnState<ColumnKey<D>>): void;
    resetColumns(): void;
    refreshOptions(sourceKey?: string): Promise<OptionsCompletion[]>;
}
export interface SearchSlotContext<Value = unknown> {
    value: unknown;
    logicalValue: Value | undefined;
    commit(ui: unknown): void;
    setPending(pending: boolean): void;
    controlAttrs: {
        id: string;
        'aria-label': string;
        'aria-invalid': boolean;
        'aria-describedby'?: string;
    };
}
type Columns<D> = D extends {
    columns: readonly (infer C)[];
} ? C : never;
type Fields<D> = D extends {
    search: readonly (infer F)[];
} ? F : never;
type DeclaredSearchValue<D, S extends string> = Extract<Fields<D>, {
    control: {
        slot: S;
    };
}> extends {
    key: infer K;
} ? K extends keyof TableRenderQuery<D> ? TableRenderQuery<D>[K] : unknown : unknown;
type DeclaredSearchSlot<D> = D extends {
    search: readonly (infer F)[];
} ? F extends {
    control: {
        slot: infer S extends string;
    };
} ? S : never : never;
type DeclaredColumnSlot<D, P extends 'slot' | 'headerSlot'> = Columns<D> extends infer C ? C extends {
    [K in P]: infer S extends string;
} ? S : never : never;
export interface TableRegionContext<Row, Q, D = AnyDefinition> {
    readonly draft: Partial<Q>;
    readonly dirty: boolean;
    readonly columnState: TableColumnState<ColumnKey<D>>;
    readonly commands: Pick<TableRenderInstance<D, Row, Q>, 'setDraft' | 'search' | 'reset' | 'reload' | 'requery' | 'clearSelection' | 'setSelectionKeys' | 'setExpandedKeys' | 'setColumnState' | 'resetColumns' | 'refreshOptions'>;
    readonly selection: Selection<Row>;
    readonly applied: TableApplied<Q> | null;
    readonly displayed: TableDisplayed<Q> | null;
}
export type TableRenderSlots<D, Row extends object> = {
    [K in SearchKey<D> as `search-${K}`]?: (context: SearchSlotContext<K extends keyof TableRenderQuery<D> ? TableRenderQuery<D>[K] : unknown>) => VNodeChild;
} & {
    [K in ColumnKey<D> as `cell-${K}`]?: (context: CellContext<Row, ColumnValue<Row, Extract<Columns<D>, {
        key: K;
    }>>>) => VNodeChild;
} & {
    [K in ColumnKey<D> as `header-${K}`]?: (context: {
        column: Extract<Columns<D>, {
            key: K;
        }>;
        index: number;
    }) => VNodeChild;
} & {
    [K in DeclaredSearchSlot<D>]?: (context: SearchSlotContext<DeclaredSearchValue<D, K>>) => VNodeChild;
} & {
    [K in DeclaredColumnSlot<D, 'slot'>]?: (context: CellContext<Row, ColumnValue<Row, Extract<Columns<D>, {
        slot: K;
    }>>>) => VNodeChild;
} & {
    [K in DeclaredColumnSlot<D, 'headerSlot'>]?: (context: {
        column: ColumnBase;
        index: number;
    }) => VNodeChild;
} & {
    [K in 'toolbar-extra' | 'selection-summary' | 'before-table' | 'after-table' | 'empty']?: (context: TableRegionContext<Row, TableRenderQuery<D>, D>) => VNodeChild;
};
/** Public signature adds the owner discriminant without adding a runtime wrapper. */
type ComponentEvents<D> = ZxTableRenderEmits<D, TableRenderQuery<D>>;
type ComponentProps<D extends AnyDefinition> = ZxTableRenderProps<D> & PublicProps & {
    [K in keyof ComponentEvents<D> as `on${Capitalize<K>}`]?: (...args: ComponentEvents<D>[K]) => void;
};
type ComponentContext<D extends AnyDefinition> = {
    props: ComponentProps<D>;
    attrs: Record<string, unknown>;
    slots: TableRenderSlots<D, TableRenderRow<D>>;
    emit: <K extends keyof ComponentEvents<D>>(event: K, ...args: ComponentEvents<D>[K]) => void;
    expose: (value: TableRenderInstance<D, TableRenderRow<D>, TableRenderQuery<D>>) => void;
};
export type TableRenderComponent = <D extends AnyDefinition>(props: ComponentProps<D>, context?: Pick<ComponentContext<D>, 'attrs' | 'slots' | 'emit'>, expose?: ComponentContext<D>['expose']) => VNode & {
    __ctx?: ComponentContext<D>;
};
