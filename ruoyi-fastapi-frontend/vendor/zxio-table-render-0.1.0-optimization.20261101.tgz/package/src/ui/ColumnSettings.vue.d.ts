import type { ColumnBase, TableColumnState } from '../core/types';
import type { TableRenderLocale } from './contracts';
type __VLS_Props = {
    columns: readonly ColumnBase[];
    state: TableColumnState;
    locale: TableRenderLocale;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    reset: () => any;
    patch: (key: string, value: Omit<{
        readonly key: string;
        readonly visible?: boolean;
        readonly width?: number;
        readonly fixed?: "left" | "right" | null;
    }, "key">) => any;
    move: (key: string, offset: number) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onReset?: (() => any) | undefined;
    onPatch?: ((key: string, value: Omit<{
        readonly key: string;
        readonly visible?: boolean;
        readonly width?: number;
        readonly fixed?: "left" | "right" | null;
    }, "key">) => any) | undefined;
    onMove?: ((key: string, offset: number) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
