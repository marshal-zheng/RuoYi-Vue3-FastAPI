import type { FunctionalComponent } from 'vue';
import type { CellContext, Column } from '../core/types';
import type { TableOptions } from './use-options';
import type { TableRenderLocale } from './contracts';
interface Props {
    column: Column<any>;
    row: object;
    index: number;
    options: TableOptions;
    locale: TableRenderLocale;
}
declare const TableCell: FunctionalComponent<Props, Record<never, never>, {
    default?: (context: CellContext<any>) => unknown;
}>;
export default TableCell;
