import type { GridListQueryIssue, GridListQueryValidator, ZxGridListInstance } from '@zxio/zxui/grid-list';
import type { AnyDefinition } from './contracts';
import type { LogicalQuery, SortItem, TableApplied, TableCommandResult, TableQueryIntent } from '../core/types';
export declare function useQueryCommands(options: {
    definition: AnyDefinition;
    grid: () => ZxGridListInstance | undefined;
    domainKey: () => string;
    ready: () => boolean;
    applied: () => TableApplied<any> | null;
    defaults: {
        query: LogicalQuery;
        sort: readonly SortItem[];
    };
    validate: GridListQueryValidator;
    issues: (issues: readonly GridListQueryIssue[]) => void;
    emit: (intent: TableQueryIntent<any>) => void;
}): {
    search(kind: "search" | "reset", query: LogicalQuery): TableCommandResult<any>;
    reload(): Promise<TableCommandResult<any>>;
    requery(change: {
        page?: number;
        size?: number;
        sort?: readonly SortItem[];
    }): Promise<TableCommandResult<any>>;
};
