import type { RowKeyValue } from '../core/types';
export declare function encodeRowKey(key: RowKeyValue): string;
export declare function useRowIdentity<Row extends object>(options: {
    rows: () => readonly Row[];
    rowKey?: string | ((row: Row) => RowKeyValue);
    children?: string;
    required: () => boolean;
    error: (error: {
        code: string;
        keys?: readonly RowKeyValue[];
    }) => void;
}): {
    index: import("vue").ComputedRef<{
        rows: Row[];
        positions: WeakMap<object, number>;
        byKey: Map<RowKeyValue, Row>;
        invalid: boolean;
        unsafeStructure: boolean;
        duplicates: RowKeyValue[];
    }>;
    rowKey: (row: Row) => RowKeyValue | undefined;
    tableKey: (row: Row) => string;
};
export declare function createScopeRef(): string;
