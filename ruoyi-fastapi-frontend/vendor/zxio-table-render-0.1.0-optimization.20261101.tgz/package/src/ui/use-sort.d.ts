import type { AnyDefinition, TableApplied } from './contracts';
import type { SortItem } from '../core/types';
export interface SortTable {
    sort(prop: string, order: 'ascending' | 'descending'): void;
    clearSort(): void;
}
export declare function useSort(options: {
    definition: AnyDefinition;
    table: () => SortTable | undefined;
    applied: () => TableApplied<any> | null | undefined;
    request: boolean;
    columns: () => readonly {
        key: string;
    }[];
    requery: (change: {
        sort: readonly SortItem[];
    }) => Promise<unknown>;
}): {
    change: (event: {
        column?: {
            columnKey?: string;
        };
        prop?: string | null;
        order?: "ascending" | "descending" | null;
    }) => Promise<void>;
};
