import type { ZxToolbarAction } from '@zxio/zxui/more-action';
import type { ActionContext, RowKeyValue, Selection, TableCommandResult } from '../core/types';
import type { AnyDefinition, TableApplied, TableRenderLocale } from './contracts';
export declare function useActions(options: {
    definition: AnyDefinition;
    ready: () => boolean;
    applied: () => TableApplied<any> | null;
    selection: () => Selection<any>;
    reload: () => Promise<TableCommandResult<any>>;
    rowKey: (row: any) => RowKeyValue | undefined;
    domain: () => string;
    publication: () => unknown;
    row: (key: RowKeyValue) => object | undefined;
    selectable: (row: any) => boolean;
    rowValid: (row: any) => boolean;
    locale: () => TableRenderLocale;
    error: (error: {
        actionId: string;
        rowKey?: RowKeyValue;
        error: unknown;
    }) => void;
}): {
    toolbar: import("vue").ComputedRef<readonly ZxToolbarAction[]>;
    rowActions: (row: object) => {
        loading: boolean;
        disabled: boolean;
        id: string;
        label: string;
        icon?: string | import("vue").Component;
        tone?: ZxToolbarAction["tone"];
        variant?: ZxToolbarAction["variant"];
        reloadAfter?: boolean;
        confirm?: string | ((row: any, ctx: ActionContext<any>) => string) | undefined;
        overflow?: boolean;
        visible?(row: any, ctx: ActionContext<any>): boolean;
        run(row: any, ctx: ActionContext<any>): unknown;
    }[];
    run: (id: string, row?: object) => Promise<void>;
};
export type TableActionRunner = ReturnType<typeof useActions>;
