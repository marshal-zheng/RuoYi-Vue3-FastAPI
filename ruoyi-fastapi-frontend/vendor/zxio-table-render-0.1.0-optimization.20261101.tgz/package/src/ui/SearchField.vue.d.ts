import type { SearchFields } from '../core/types';
import type { SearchSlotContext, TableRenderLocale } from './contracts';
import type { TableOptions } from './use-options';
type __VLS_Props = {
    field: SearchFields<any>;
    value: unknown;
    placement: 'keyword' | 'inline' | 'more';
    error?: string;
    resetEpoch: number;
    locale: TableRenderLocale;
    options: TableOptions;
};
type __VLS_Slots = {
    custom?: (context: SearchSlotContext) => unknown;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    confirm: () => any;
    commit: (value: unknown) => any;
    pending: (value: boolean) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onConfirm?: (() => any) | undefined;
    onCommit?: ((value: unknown) => any) | undefined;
    onPending?: ((value: boolean) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
