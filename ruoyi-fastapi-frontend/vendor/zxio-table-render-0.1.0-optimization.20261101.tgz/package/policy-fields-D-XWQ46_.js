"use strict";
const columnState = require("./column-state-DMHr6VPq.js");
function defineTableRender() {
  return (definition, ..._check) => {
    columnState.validateDefinition(definition);
    return freezeDefinition(definition);
  };
}
function freezeDefinition(value, copies = /* @__PURE__ */ new Map()) {
  if (!value || typeof value !== "object") return value;
  if (!Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype)
    return value;
  if (copies.has(value)) return copies.get(value);
  const output = Array.isArray(value) ? [] : {};
  copies.set(value, output);
  for (const key of Object.keys(value))
    output[key] = freezeDefinition(
      value[key],
      copies
    );
  return Object.freeze(output);
}
function createTableColumnHelper() {
  return {
    accessor(prop, options) {
      return { ...options, prop };
    },
    computed(options) {
      return { ...options, type: "custom" };
    }
  };
}
function tableRenderPolicyFields(definition, selection) {
  const fields = new Set((definition.search ?? []).map((field) => field.key));
  const columns = new Map(
    definition.columns.map((column) => [column.key, column])
  );
  const query = Object.fromEntries(
    selection.query.map((key) => {
      if (!fields.has(key))
        throw new TypeError(`TableRender policy.query.${key}: unknown-field`);
      return [key, Object.freeze(["query", key])];
    })
  );
  const row = Object.fromEntries(
    selection.row.map((key) => {
      var _a;
      const prop = (_a = columns.get(key)) == null ? void 0 : _a.prop;
      if (!prop)
        throw new TypeError(`TableRender policy.row.${key}: no-raw-path`);
      return [key, Object.freeze(prop.split("."))];
    })
  );
  return Object.freeze({
    query: Object.freeze(query),
    condition: Object.freeze({ ...query }),
    row: Object.freeze(row)
  });
}
exports.createTableColumnHelper = createTableColumnHelper;
exports.defineTableRender = defineTableRender;
exports.tableRenderPolicyFields = tableRenderPolicyFields;
