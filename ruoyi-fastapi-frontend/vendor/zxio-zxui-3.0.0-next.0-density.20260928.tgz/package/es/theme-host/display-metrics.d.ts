import type { ZxDisplayProfile, ZxDisplayScale } from '@zxio/tokens/display';
import type { ValidatedThemeExtensionBundleV1 } from '@zxio/tokens/extensions';
import type { ThemeRuntime } from '../theme-runtime/runtime';
import type { ThemeScopeIdentity } from '../theme-runtime/composition-contract';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
export interface ZxDisplayMetricsSnapshot {
    readonly scopeId: string;
    readonly effectiveRevision: number;
    readonly layoutRevision: number;
    readonly profile: ZxDisplayProfile;
    readonly scale: ZxDisplayScale;
    readonly pixels: Readonly<Record<string, number>>;
}
interface MetricDescriptor {
    readonly variable: string;
    readonly moduleId?: string;
}
export declare function measureDisplayCssPixels(probe: HTMLElement, variable: string): number;
/** Reads used CSS lengths, rather than treating rem/calc custom properties as pixels. */
export declare function createDisplayMetricsService(runtime: ThemeRuntime, bundles: readonly ValidatedThemeExtensionBundleV1[], registry?: ReadonlyMap<string, MetricDescriptor>): Readonly<{
    reference(scope: ThemeScopeIdentity, id: string): ThemeRuntimeResult<string>;
    snapshot: (scope: ThemeScopeIdentity, ids: readonly string[]) => ThemeRuntimeResult<ZxDisplayMetricsSnapshot>;
    subscribe(scope: ThemeScopeIdentity, ids: readonly string[], listener: (snapshot: ZxDisplayMetricsSnapshot) => void): ThemeRuntimeResult<() => void>;
    dispose(): void;
}>;
export type ZxDisplayMetricsService = ReturnType<typeof createDisplayMetricsService>;
export declare function createDisplayMetricRegistry(bundles: readonly ValidatedThemeExtensionBundleV1[]): ReadonlyMap<string, MetricDescriptor>;
export {};
