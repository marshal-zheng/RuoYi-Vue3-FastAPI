import type { ZxDisplayMetricsSnapshot } from './display-metrics';
import type { ThemeLayoutPort } from '../theme-runtime/layout-contract';
import type { ThemeScopeIdentity } from '../theme-runtime/composition-contract';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
/** A proposed CSS measurement; layoutRevision exists only after a commit. */
export type ZxDisplayLayoutCandidate = Omit<ZxDisplayMetricsSnapshot, 'layoutRevision'>;
export interface ZxDisplayLayoutParticipant {
    readonly id: string;
    readonly metrics: readonly string[];
    prepare(next: ZxDisplayLayoutCandidate, signal: AbortSignal): Promise<{
        commit(): void | Promise<void>;
        rollback(): void | Promise<void>;
        dispose(): void;
    }>;
}
/** Host-owned staging for JS geometry that must move with theme CSS. */
export declare function createDisplayLayoutCoordinator(metrics: ReadonlyMap<string, {
    readonly variable: string;
    readonly moduleId?: string;
}>, runtimeId: string): Readonly<{
    port: ThemeLayoutPort;
    register(scope: ThemeScopeIdentity, region: HTMLElement, participant: ZxDisplayLayoutParticipant): ThemeRuntimeResult<() => void>;
    dispose(): void;
}>;
export type ZxDisplayLayoutCoordinator = ReturnType<typeof createDisplayLayoutCoordinator>;
