import type { IconCategory, IconMeta, IconSearchPlacement, IconSelectStorage, IconSource, IconTabMode } from './props';
type __VLS_Props = {
    modelValue?: string;
    sources?: IconSource[];
    iconifyCollections?: string[];
    customIcons?: IconMeta[];
    tabMode?: IconTabMode;
    searchPlacement?: IconSearchPlacement;
    showTabs?: boolean;
    categories?: IconCategory[];
    recentKey?: string;
    recentKeyPrefix?: string;
    recentStorage?: IconSelectStorage;
    recentScope?: 'global' | 'source' | 'category' | 'custom';
    recentScopeKey?: string;
    recentScopeResolver?: (icon: IconMeta) => string;
    recentSaveStrategy?: 'select' | 'confirm' | 'close';
    confirmText?: string;
    columns?: number;
    itemHeight?: number;
    panelHeight?: number;
    searchable?: boolean;
    showRecent?: boolean;
    showFooter?: boolean;
    recentMax?: number;
    allowModeSwitch?: boolean;
    panelMode?: 'popover' | 'dialog';
};
/**
 * 重置滚动位置
 */
declare function resetScroll(): void;
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focusSearch: () => void;
    resetScroll: typeof resetScroll;
    setSearchValue: (value: string) => void;
    clearSearchValue: () => void;
    commitRecent: () => void;
    filteredCount: import("vue").ComputedRef<number>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    select: (iconName: string) => any;
    close: () => any;
    confirm: () => any;
    "switch-mode": () => any;
    "count-change": (count: number) => any;
    "recent-change": (icons: string[], scopeKey: string) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onSelect?: ((iconName: string) => any) | undefined;
    onClose?: (() => any) | undefined;
    onConfirm?: (() => any) | undefined;
    "onSwitch-mode"?: (() => any) | undefined;
    "onCount-change"?: ((count: number) => any) | undefined;
    "onRecent-change"?: ((icons: string[], scopeKey: string) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
