export declare const ZxMoreAction: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    list: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./src/props").ActionItem[]) | (() => import("./src/props").ActionItem[]) | {
        (): import("./src/props").ActionItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./src/props").ActionItem[]) | (() => import("./src/props").ActionItem[]) | {
        (): import("./src/props").ActionItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    trigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, import("./src/props").TriggerType, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    dropdownRef: import("vue").Ref<import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly trigger: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
            readonly default: "hover";
        };
        readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
        readonly virtualTriggering: BooleanConstructor;
        readonly virtualRef: {
            readonly type: import("vue").PropType<import("element-plus").Measurable>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly effect: {
            readonly default: "light";
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
        };
        readonly type: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
        readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly id: StringConstructor;
        readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly splitButton: BooleanConstructor;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
        readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: BooleanConstructor;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
        readonly buttonProps: {
            readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & Readonly<{
        onClick?: ((...args: any[]) => any) | undefined;
        onCommand?: ((...args: any[]) => any) | undefined;
        "onVisible-change"?: ((...args: any[]) => any) | undefined;
    }>, {
        t: import("element-plus").Translator;
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        scrollbar: import("vue").Ref<null, null>;
        wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
        dropdownTriggerKls: import("vue").ComputedRef<string[]>;
        dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        triggerId: import("vue").ComputedRef<string>;
        currentTabId: import("vue").Ref<string | null, string | null>;
        handleCurrentTabIdChange: (id: string) => void;
        handlerMainButtonClick: (event: MouseEvent) => void;
        handleClose: () => void;
        handleOpen: () => void;
        handleBeforeShowTooltip: () => void;
        handleShowTooltip: (event?: Event) => void;
        handleBeforeHideTooltip: () => void;
        popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
        contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
        triggeringElementRef: import("vue").Ref<any, any>;
        referenceElementRef: import("vue").Ref<any, any>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "visible-change" | "command")[], import("vue").PublicProps, {
        readonly disabled: boolean;
        readonly size: string;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
        readonly popperStyle: import("vue").StyleValue;
        readonly virtualTriggering: boolean;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
        readonly popperOptions: Partial<import("element-plus").Options>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
        readonly triggerKeys: string[];
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTimeout: number;
        readonly hideTimeout: number;
        readonly splitButton: boolean;
    }, true, {}, {}, {
        ElButton: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                click: (evt: MouseEvent) => void;
            }, import("vue").PublicProps, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, string, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
            setPropsDefaults: (defaults: {
                readonly size?: "" | "default" | "large" | "small" | (() => "" | "default" | "large" | "small") | undefined;
                readonly disabled?: boolean | (() => boolean) | undefined;
                readonly type?: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger" | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | undefined;
                readonly icon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                readonly nativeType?: "button" | "reset" | "submit" | (() => "button" | "reset" | "submit") | undefined;
                readonly loading?: boolean | (() => boolean) | undefined;
                readonly loadingIcon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                readonly plain?: boolean | (() => boolean) | undefined;
                readonly text?: boolean | (() => boolean) | undefined;
                readonly link?: boolean | (() => boolean) | undefined;
                readonly bg?: boolean | (() => boolean) | undefined;
                readonly autofocus?: boolean | (() => boolean) | undefined;
                readonly round?: boolean | (() => boolean) | undefined;
                readonly circle?: boolean | (() => boolean) | undefined;
                readonly dashed?: boolean | (() => boolean) | undefined;
                readonly color?: string | (() => string) | undefined;
                readonly dark?: boolean | (() => boolean) | undefined;
                readonly autoInsertSpace?: boolean | (() => boolean) | undefined;
                readonly tag?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (string | import("vue").Component | undefined) & {}) | undefined;
            }) => void;
        } & {
            ButtonGroup: __ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>;
        }, {
            $slots: {
                loading?: (props: {}) => any;
            } & {
                icon?: (props: {}) => any;
            } & {
                default?: (props: {}) => any;
            };
        }>;
        ElButtonGroup: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>;
        ElScrollbar: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                scroll: (args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => void;
                "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
            }, import("vue").PublicProps, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
            onScroll?: ((args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => any) | undefined;
            "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
        }>, {
            wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
            update: () => void;
            scrollTo: {
                (xCord: number, yCord?: number): void;
                (options: ScrollToOptions): void;
            };
            setScrollTop: (value: number) => void;
            setScrollLeft: (value: number) => void;
            handleScroll: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            scroll: (args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => void;
            "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
        }, string, {
            height: number | string;
            tag: keyof HTMLElementTagNameMap | (string & {});
            tabindex: number | string;
            maxHeight: number | string;
            distance: number;
            wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            minSize: number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>>;
        ElTooltip: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                hide: (...args: any[]) => void;
                show: (...args: any[]) => void;
                open: (...args: any[]) => void;
                close: (...args: any[]) => void;
                "update:visible": (...args: any[]) => void;
                "before-show": (...args: any[]) => void;
                "before-hide": (...args: any[]) => void;
            }, import("vue").PublicProps, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
            onHide?: ((...args: any[]) => any) | undefined;
            onShow?: ((...args: any[]) => any) | undefined;
            onOpen?: ((...args: any[]) => any) | undefined;
            onClose?: ((...args: any[]) => any) | undefined;
            "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
            "onBefore-show"?: ((...args: any[]) => any) | undefined;
            "onBefore-hide"?: ((...args: any[]) => any) | undefined;
        }>, {
            popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
            contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
            isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
            updatePopper: () => void;
            onOpen: (event?: Event, delay?: number) => void;
            onClose: (event?: Event, delay?: number) => void;
            hide: (event?: Event) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            hide: (...args: any[]) => void;
            show: (...args: any[]) => void;
            open: (...args: any[]) => void;
            close: (...args: any[]) => void;
            "update:visible": (...args: any[]) => void;
            "before-show": (...args: any[]) => void;
            "before-hide": (...args: any[]) => void;
        }, string, {
            visible: boolean | null;
            style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            content: string;
            role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
            offset: number;
            teleported: boolean;
            effect: import("element-plus").PopperEffect;
            enterable: boolean;
            pure: boolean;
            focusOnShow: boolean;
            trapping: boolean;
            popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            stopPopperMouseEvent: boolean;
            virtualTriggering: boolean;
            loop: boolean;
            boundariesPadding: number;
            gpuAcceleration: boolean;
            placement: import("element-plus").Placement;
            popperOptions: Partial<import("element-plus").Options>;
            strategy: "absolute" | "fixed";
            arrowOffset: number;
            showArrow: boolean;
            showAfter: number;
            hideAfter: number;
            autoClose: number;
            trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
            triggerKeys: string[];
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            } & {
                content?: (props: {}) => any;
            };
        }>>;
        ElRovingFocusGroup: import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {
            ElFocusGroupCollection: {
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, {}>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
                name: string;
                setup(): void;
            };
            ElRovingFocusGroupImpl: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
                style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                currentTabId: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultCurrentTabId: StringConstructor;
                loop: BooleanConstructor;
                dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                orientation: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                onBlur: FunctionConstructor;
                onFocus: FunctionConstructor;
                onMousedown: FunctionConstructor;
            }>, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("currentTabIdChange" | "entryFocus")[], "currentTabIdChange" | "entryFocus", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
                style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                currentTabId: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultCurrentTabId: StringConstructor;
                loop: BooleanConstructor;
                dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                orientation: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                onBlur: FunctionConstructor;
                onFocus: FunctionConstructor;
                onMousedown: FunctionConstructor;
            }>> & Readonly<{
                onCurrentTabIdChange?: ((...args: any[]) => any) | undefined;
                onEntryFocus?: ((...args: any[]) => any) | undefined;
            }>, {
                style: import("vue").StyleValue;
                loop: boolean;
                dir: string;
            }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElOnlyChild: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>>;
        ArrowDown: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    } & import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly trigger: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
            readonly default: "hover";
        };
        readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
        readonly virtualTriggering: BooleanConstructor;
        readonly virtualRef: {
            readonly type: import("vue").PropType<import("element-plus").Measurable>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly effect: {
            readonly default: "light";
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
        };
        readonly type: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
        readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly id: StringConstructor;
        readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly splitButton: BooleanConstructor;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
        readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: BooleanConstructor;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
        readonly buttonProps: {
            readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & Readonly<{
        onClick?: ((...args: any[]) => any) | undefined;
        onCommand?: ((...args: any[]) => any) | undefined;
        "onVisible-change"?: ((...args: any[]) => any) | undefined;
    }>, {
        t: import("element-plus").Translator;
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        scrollbar: import("vue").Ref<null, null>;
        wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
        dropdownTriggerKls: import("vue").ComputedRef<string[]>;
        dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        triggerId: import("vue").ComputedRef<string>;
        currentTabId: import("vue").Ref<string | null, string | null>;
        handleCurrentTabIdChange: (id: string) => void;
        handlerMainButtonClick: (event: MouseEvent) => void;
        handleClose: () => void;
        handleOpen: () => void;
        handleBeforeShowTooltip: () => void;
        handleShowTooltip: (event?: Event) => void;
        handleBeforeHideTooltip: () => void;
        popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
        contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
        triggeringElementRef: import("vue").Ref<any, any>;
        referenceElementRef: import("vue").Ref<any, any>;
    }, {}, {}, {}, {
        readonly disabled: boolean;
        readonly size: string;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
        readonly popperStyle: import("vue").StyleValue;
        readonly virtualTriggering: boolean;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
        readonly popperOptions: Partial<import("element-plus").Options>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
        readonly triggerKeys: string[];
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTimeout: number;
        readonly hideTimeout: number;
        readonly splitButton: boolean;
    }> | undefined, import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly trigger: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
            readonly default: "hover";
        };
        readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
        readonly virtualTriggering: BooleanConstructor;
        readonly virtualRef: {
            readonly type: import("vue").PropType<import("element-plus").Measurable>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly effect: {
            readonly default: "light";
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
        };
        readonly type: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
        readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly id: StringConstructor;
        readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly splitButton: BooleanConstructor;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
        readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: BooleanConstructor;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
        readonly buttonProps: {
            readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & Readonly<{
        onClick?: ((...args: any[]) => any) | undefined;
        onCommand?: ((...args: any[]) => any) | undefined;
        "onVisible-change"?: ((...args: any[]) => any) | undefined;
    }>, {
        t: import("element-plus").Translator;
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        scrollbar: import("vue").Ref<null, null>;
        wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
        dropdownTriggerKls: import("vue").ComputedRef<string[]>;
        dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        triggerId: import("vue").ComputedRef<string>;
        currentTabId: import("vue").Ref<string | null, string | null>;
        handleCurrentTabIdChange: (id: string) => void;
        handlerMainButtonClick: (event: MouseEvent) => void;
        handleClose: () => void;
        handleOpen: () => void;
        handleBeforeShowTooltip: () => void;
        handleShowTooltip: (event?: Event) => void;
        handleBeforeHideTooltip: () => void;
        popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
        contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
        triggeringElementRef: import("vue").Ref<any, any>;
        referenceElementRef: import("vue").Ref<any, any>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "visible-change" | "command")[], import("vue").PublicProps, {
        readonly disabled: boolean;
        readonly size: string;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
        readonly popperStyle: import("vue").StyleValue;
        readonly virtualTriggering: boolean;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
        readonly popperOptions: Partial<import("element-plus").Options>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
        readonly triggerKeys: string[];
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTimeout: number;
        readonly hideTimeout: number;
        readonly splitButton: boolean;
    }, true, {}, {}, {
        ElButton: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                click: (evt: MouseEvent) => void;
            }, import("vue").PublicProps, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, string, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
            setPropsDefaults: (defaults: {
                readonly size?: "" | "default" | "large" | "small" | (() => "" | "default" | "large" | "small") | undefined;
                readonly disabled?: boolean | (() => boolean) | undefined;
                readonly type?: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger" | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | undefined;
                readonly icon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                readonly nativeType?: "button" | "reset" | "submit" | (() => "button" | "reset" | "submit") | undefined;
                readonly loading?: boolean | (() => boolean) | undefined;
                readonly loadingIcon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                readonly plain?: boolean | (() => boolean) | undefined;
                readonly text?: boolean | (() => boolean) | undefined;
                readonly link?: boolean | (() => boolean) | undefined;
                readonly bg?: boolean | (() => boolean) | undefined;
                readonly autofocus?: boolean | (() => boolean) | undefined;
                readonly round?: boolean | (() => boolean) | undefined;
                readonly circle?: boolean | (() => boolean) | undefined;
                readonly dashed?: boolean | (() => boolean) | undefined;
                readonly color?: string | (() => string) | undefined;
                readonly dark?: boolean | (() => boolean) | undefined;
                readonly autoInsertSpace?: boolean | (() => boolean) | undefined;
                readonly tag?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (string | import("vue").Component | undefined) & {}) | undefined;
            }) => void;
        } & {
            ButtonGroup: __ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>;
        }, {
            $slots: {
                loading?: (props: {}) => any;
            } & {
                icon?: (props: {}) => any;
            } & {
                default?: (props: {}) => any;
            };
        }>;
        ElButtonGroup: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>;
        ElScrollbar: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                scroll: (args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => void;
                "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
            }, import("vue").PublicProps, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
            onScroll?: ((args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => any) | undefined;
            "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
        }>, {
            wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
            update: () => void;
            scrollTo: {
                (xCord: number, yCord?: number): void;
                (options: ScrollToOptions): void;
            };
            setScrollTop: (value: number) => void;
            setScrollLeft: (value: number) => void;
            handleScroll: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            scroll: (args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => void;
            "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
        }, string, {
            height: number | string;
            tag: keyof HTMLElementTagNameMap | (string & {});
            tabindex: number | string;
            maxHeight: number | string;
            distance: number;
            wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            minSize: number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>>;
        ElTooltip: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                hide: (...args: any[]) => void;
                show: (...args: any[]) => void;
                open: (...args: any[]) => void;
                close: (...args: any[]) => void;
                "update:visible": (...args: any[]) => void;
                "before-show": (...args: any[]) => void;
                "before-hide": (...args: any[]) => void;
            }, import("vue").PublicProps, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
            onHide?: ((...args: any[]) => any) | undefined;
            onShow?: ((...args: any[]) => any) | undefined;
            onOpen?: ((...args: any[]) => any) | undefined;
            onClose?: ((...args: any[]) => any) | undefined;
            "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
            "onBefore-show"?: ((...args: any[]) => any) | undefined;
            "onBefore-hide"?: ((...args: any[]) => any) | undefined;
        }>, {
            popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
            contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
            isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
            updatePopper: () => void;
            onOpen: (event?: Event, delay?: number) => void;
            onClose: (event?: Event, delay?: number) => void;
            hide: (event?: Event) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            hide: (...args: any[]) => void;
            show: (...args: any[]) => void;
            open: (...args: any[]) => void;
            close: (...args: any[]) => void;
            "update:visible": (...args: any[]) => void;
            "before-show": (...args: any[]) => void;
            "before-hide": (...args: any[]) => void;
        }, string, {
            visible: boolean | null;
            style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            content: string;
            role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
            offset: number;
            teleported: boolean;
            effect: import("element-plus").PopperEffect;
            enterable: boolean;
            pure: boolean;
            focusOnShow: boolean;
            trapping: boolean;
            popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            stopPopperMouseEvent: boolean;
            virtualTriggering: boolean;
            loop: boolean;
            boundariesPadding: number;
            gpuAcceleration: boolean;
            placement: import("element-plus").Placement;
            popperOptions: Partial<import("element-plus").Options>;
            strategy: "absolute" | "fixed";
            arrowOffset: number;
            showArrow: boolean;
            showAfter: number;
            hideAfter: number;
            autoClose: number;
            trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
            triggerKeys: string[];
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            } & {
                content?: (props: {}) => any;
            };
        }>>;
        ElRovingFocusGroup: import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {
            ElFocusGroupCollection: {
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, {}>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
                name: string;
                setup(): void;
            };
            ElRovingFocusGroupImpl: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
                style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                currentTabId: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultCurrentTabId: StringConstructor;
                loop: BooleanConstructor;
                dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                orientation: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                onBlur: FunctionConstructor;
                onFocus: FunctionConstructor;
                onMousedown: FunctionConstructor;
            }>, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("currentTabIdChange" | "entryFocus")[], "currentTabIdChange" | "entryFocus", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
                style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                currentTabId: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultCurrentTabId: StringConstructor;
                loop: BooleanConstructor;
                dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                orientation: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                onBlur: FunctionConstructor;
                onFocus: FunctionConstructor;
                onMousedown: FunctionConstructor;
            }>> & Readonly<{
                onCurrentTabIdChange?: ((...args: any[]) => any) | undefined;
                onEntryFocus?: ((...args: any[]) => any) | undefined;
            }>, {
                style: import("vue").StyleValue;
                loop: boolean;
                dir: string;
            }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElOnlyChild: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>>;
        ArrowDown: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    } & import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly trigger: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
            readonly default: "hover";
        };
        readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
        readonly virtualTriggering: BooleanConstructor;
        readonly virtualRef: {
            readonly type: import("vue").PropType<import("element-plus").Measurable>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly effect: {
            readonly default: "light";
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
        };
        readonly type: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
        readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly id: StringConstructor;
        readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly splitButton: BooleanConstructor;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
        readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: BooleanConstructor;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
        readonly buttonProps: {
            readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & Readonly<{
        onClick?: ((...args: any[]) => any) | undefined;
        onCommand?: ((...args: any[]) => any) | undefined;
        "onVisible-change"?: ((...args: any[]) => any) | undefined;
    }>, {
        t: import("element-plus").Translator;
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        scrollbar: import("vue").Ref<null, null>;
        wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
        dropdownTriggerKls: import("vue").ComputedRef<string[]>;
        dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        triggerId: import("vue").ComputedRef<string>;
        currentTabId: import("vue").Ref<string | null, string | null>;
        handleCurrentTabIdChange: (id: string) => void;
        handlerMainButtonClick: (event: MouseEvent) => void;
        handleClose: () => void;
        handleOpen: () => void;
        handleBeforeShowTooltip: () => void;
        handleShowTooltip: (event?: Event) => void;
        handleBeforeHideTooltip: () => void;
        popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
        contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
        triggeringElementRef: import("vue").Ref<any, any>;
        referenceElementRef: import("vue").Ref<any, any>;
    }, {}, {}, {}, {
        readonly disabled: boolean;
        readonly size: string;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
        readonly popperStyle: import("vue").StyleValue;
        readonly virtualTriggering: boolean;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
        readonly popperOptions: Partial<import("element-plus").Options>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
        readonly triggerKeys: string[];
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTimeout: number;
        readonly hideTimeout: number;
        readonly splitButton: boolean;
    }> | undefined>;
    nativeTriggers: import("vue").ComputedRef<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>>;
    handleTriggerFocus: () => void;
    handleTriggerBlur: (event: FocusEvent) => void;
    portalTarget: import("vue").ComputedRef<HTMLElement | undefined>;
    dropdownVisible: import("vue").Ref<boolean, boolean>;
    popperOptions: import("vue").ComputedRef<Partial<import("@popperjs/core/index.js").Options>>;
    handleSelect: (command: string) => void;
    handleVisibleChange: (visible: boolean) => void;
    shouldShowDivider: (index: number) => boolean;
    MoreFilled: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (_item: import("./src/props").ActionItem) => boolean;
    close: () => boolean;
    open: () => boolean;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    list: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./src/props").ActionItem[]) | (() => import("./src/props").ActionItem[]) | {
        (): import("./src/props").ActionItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./src/props").ActionItem[]) | (() => import("./src/props").ActionItem[]) | {
        (): import("./src/props").ActionItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    trigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, import("./src/props").TriggerType, boolean>;
    size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, string, boolean>;
}>> & Readonly<{
    onSelect?: ((_item: import("./src/props").ActionItem) => any) | undefined;
    onClose?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
}>, {
    list: import("./src/props").ActionItem[];
    size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | {
        (): "small" | "default" | "large" | "medium";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    trigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | {
        (): import("./src/props").TriggerType | import("./src/props").TriggerType[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
}, {}, {
    ElDropdown: {
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly trigger: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                readonly __epPropKey: true;
                readonly default: "hover";
            };
            readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
            readonly virtualTriggering: BooleanConstructor;
            readonly virtualRef: {
                readonly type: import("vue").PropType<import("element-plus").Measurable>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly effect: {
                readonly default: "light";
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                readonly __epPropKey: true;
            };
            readonly type: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
            readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
            readonly id: StringConstructor;
            readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly splitButton: BooleanConstructor;
            readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
            readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
            readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
            readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | null)[], unknown, unknown, undefined, boolean>;
            readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: BooleanConstructor;
            readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
            readonly buttonProps: {
                readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly appendTo: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        }>> & Readonly<{
            onClick?: ((...args: any[]) => any) | undefined;
            onCommand?: ((...args: any[]) => any) | undefined;
            "onVisible-change"?: ((...args: any[]) => any) | undefined;
        }>, {
            t: import("element-plus").Translator;
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            scrollbar: import("vue").Ref<null, null>;
            wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
            dropdownTriggerKls: import("vue").ComputedRef<string[]>;
            dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            triggerId: import("vue").ComputedRef<string>;
            currentTabId: import("vue").Ref<string | null, string | null>;
            handleCurrentTabIdChange: (id: string) => void;
            handlerMainButtonClick: (event: MouseEvent) => void;
            handleClose: () => void;
            handleOpen: () => void;
            handleBeforeShowTooltip: () => void;
            handleShowTooltip: (event?: Event) => void;
            handleBeforeHideTooltip: () => void;
            popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
            contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
            triggeringElementRef: import("vue").Ref<any, any>;
            referenceElementRef: import("vue").Ref<any, any>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "visible-change" | "command")[], import("vue").PublicProps, {
            readonly disabled: boolean;
            readonly size: string;
            readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
            readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
            readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
            readonly popperStyle: import("vue").StyleValue;
            readonly virtualTriggering: boolean;
            readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
            readonly popperOptions: Partial<import("element-plus").Options>;
            readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
            readonly triggerKeys: string[];
            readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
            readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showTimeout: number;
            readonly hideTimeout: number;
            readonly splitButton: boolean;
        }, true, {}, {}, {
            ElButton: __ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ButtonProps> & Readonly<{
                    onClick?: ((evt: MouseEvent) => any) | undefined;
                }>, {
                    ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                    size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                    type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                    disabled: import("vue").ComputedRef<boolean>;
                    shouldAddSpace: import("vue").ComputedRef<boolean>;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    click: (evt: MouseEvent) => void;
                }, import("vue").PublicProps, {
                    type: import("element-plus").ButtonType;
                    text: boolean;
                    disabled: boolean;
                    round: boolean;
                    dashed: boolean;
                    tag: string | import("vue").Component;
                    nativeType: import("element-plus").ButtonNativeType;
                    loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                    plain: boolean;
                    autoInsertSpace: boolean;
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus").ButtonProps> & Readonly<{
                    onClick?: ((evt: MouseEvent) => any) | undefined;
                }>, {
                    ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                    size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                    type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                    disabled: import("vue").ComputedRef<boolean>;
                    shouldAddSpace: import("vue").ComputedRef<boolean>;
                }, {}, {}, {}, {
                    type: import("element-plus").ButtonType;
                    text: boolean;
                    disabled: boolean;
                    round: boolean;
                    dashed: boolean;
                    tag: string | import("vue").Component;
                    nativeType: import("element-plus").ButtonNativeType;
                    loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                    plain: boolean;
                    autoInsertSpace: boolean;
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                click: (evt: MouseEvent) => void;
            }, string, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
                setPropsDefaults: (defaults: {
                    readonly size?: "" | "default" | "large" | "small" | (() => "" | "default" | "large" | "small") | undefined;
                    readonly disabled?: boolean | (() => boolean) | undefined;
                    readonly type?: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger" | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | undefined;
                    readonly icon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                        new (...args: any[]): any;
                        __isFragment?: never;
                        __isTeleport?: never;
                        __isSuspense?: never;
                    } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                    readonly nativeType?: "button" | "reset" | "submit" | (() => "button" | "reset" | "submit") | undefined;
                    readonly loading?: boolean | (() => boolean) | undefined;
                    readonly loadingIcon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                        new (...args: any[]): any;
                        __isFragment?: never;
                        __isTeleport?: never;
                        __isSuspense?: never;
                    } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                    readonly plain?: boolean | (() => boolean) | undefined;
                    readonly text?: boolean | (() => boolean) | undefined;
                    readonly link?: boolean | (() => boolean) | undefined;
                    readonly bg?: boolean | (() => boolean) | undefined;
                    readonly autofocus?: boolean | (() => boolean) | undefined;
                    readonly round?: boolean | (() => boolean) | undefined;
                    readonly circle?: boolean | (() => boolean) | undefined;
                    readonly dashed?: boolean | (() => boolean) | undefined;
                    readonly color?: string | (() => string) | undefined;
                    readonly dark?: boolean | (() => boolean) | undefined;
                    readonly autoInsertSpace?: boolean | (() => boolean) | undefined;
                    readonly tag?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                        new (...args: any[]): any;
                        __isFragment?: never;
                        __isTeleport?: never;
                        __isSuspense?: never;
                    } | (() => (string | import("vue").Component | undefined) & {}) | undefined;
                }) => void;
            } & {
                ButtonGroup: __ZXUI_WithSlots<{
                    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                        type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                        direction: "horizontal" | "vertical";
                    }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                        P: {};
                        B: {};
                        D: {};
                        C: {};
                        M: {};
                        Defaults: {};
                    }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                        type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                        direction: "horizontal" | "vertical";
                    }>;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                }>;
            }, {
                $slots: {
                    loading?: (props: {}) => any;
                } & {
                    icon?: (props: {}) => any;
                } & {
                    default?: (props: {}) => any;
                };
            }>;
            ElButtonGroup: __ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>;
            ElScrollbar: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                    onScroll?: ((args_0: {
                        scrollTop: number;
                        scrollLeft: number;
                    }) => any) | undefined;
                    "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
                }>, {
                    wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                    update: () => void;
                    scrollTo: {
                        (xCord: number, yCord?: number): void;
                        (options: ScrollToOptions): void;
                    };
                    setScrollTop: (value: number) => void;
                    setScrollLeft: (value: number) => void;
                    handleScroll: () => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    scroll: (args_0: {
                        scrollTop: number;
                        scrollLeft: number;
                    }) => void;
                    "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
                }, import("vue").PublicProps, {
                    height: number | string;
                    tag: keyof HTMLElementTagNameMap | (string & {});
                    tabindex: number | string;
                    maxHeight: number | string;
                    distance: number;
                    wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                    viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                    viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    minSize: number;
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                    onScroll?: ((args_0: {
                        scrollTop: number;
                        scrollLeft: number;
                    }) => any) | undefined;
                    "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
                }>, {
                    wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                    update: () => void;
                    scrollTo: {
                        (xCord: number, yCord?: number): void;
                        (options: ScrollToOptions): void;
                    };
                    setScrollTop: (value: number) => void;
                    setScrollLeft: (value: number) => void;
                    handleScroll: () => void;
                }, {}, {}, {}, {
                    height: number | string;
                    tag: keyof HTMLElementTagNameMap | (string & {});
                    tabindex: number | string;
                    maxHeight: number | string;
                    distance: number;
                    wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                    viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                    viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    minSize: number;
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                scroll: (args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => void;
                "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
            }, string, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>>;
            ElTooltip: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                    onHide?: ((...args: any[]) => any) | undefined;
                    onShow?: ((...args: any[]) => any) | undefined;
                    onOpen?: ((...args: any[]) => any) | undefined;
                    onClose?: ((...args: any[]) => any) | undefined;
                    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                    "onBefore-show"?: ((...args: any[]) => any) | undefined;
                    "onBefore-hide"?: ((...args: any[]) => any) | undefined;
                }>, {
                    popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                    contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                    isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                    updatePopper: () => void;
                    onOpen: (event?: Event, delay?: number) => void;
                    onClose: (event?: Event, delay?: number) => void;
                    hide: (event?: Event) => void;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    hide: (...args: any[]) => void;
                    show: (...args: any[]) => void;
                    open: (...args: any[]) => void;
                    close: (...args: any[]) => void;
                    "update:visible": (...args: any[]) => void;
                    "before-show": (...args: any[]) => void;
                    "before-hide": (...args: any[]) => void;
                }, import("vue").PublicProps, {
                    visible: boolean | null;
                    style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    content: string;
                    role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                    offset: number;
                    teleported: boolean;
                    effect: import("element-plus").PopperEffect;
                    enterable: boolean;
                    pure: boolean;
                    focusOnShow: boolean;
                    trapping: boolean;
                    popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                    popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    stopPopperMouseEvent: boolean;
                    virtualTriggering: boolean;
                    loop: boolean;
                    boundariesPadding: number;
                    gpuAcceleration: boolean;
                    placement: import("element-plus").Placement;
                    popperOptions: Partial<import("element-plus").Options>;
                    strategy: "absolute" | "fixed";
                    arrowOffset: number;
                    showArrow: boolean;
                    showAfter: number;
                    hideAfter: number;
                    autoClose: number;
                    trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                    triggerKeys: string[];
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                    onHide?: ((...args: any[]) => any) | undefined;
                    onShow?: ((...args: any[]) => any) | undefined;
                    onOpen?: ((...args: any[]) => any) | undefined;
                    onClose?: ((...args: any[]) => any) | undefined;
                    "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                    "onBefore-show"?: ((...args: any[]) => any) | undefined;
                    "onBefore-hide"?: ((...args: any[]) => any) | undefined;
                }>, {
                    popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                    contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                    isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                    updatePopper: () => void;
                    onOpen: (event?: Event, delay?: number) => void;
                    onClose: (event?: Event, delay?: number) => void;
                    hide: (event?: Event) => void;
                }, {}, {}, {}, {
                    visible: boolean | null;
                    style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    content: string;
                    role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                    offset: number;
                    teleported: boolean;
                    effect: import("element-plus").PopperEffect;
                    enterable: boolean;
                    pure: boolean;
                    focusOnShow: boolean;
                    trapping: boolean;
                    popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                    popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                    stopPopperMouseEvent: boolean;
                    virtualTriggering: boolean;
                    loop: boolean;
                    boundariesPadding: number;
                    gpuAcceleration: boolean;
                    placement: import("element-plus").Placement;
                    popperOptions: Partial<import("element-plus").Options>;
                    strategy: "absolute" | "fixed";
                    arrowOffset: number;
                    showArrow: boolean;
                    showAfter: number;
                    hideAfter: number;
                    autoClose: number;
                    trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                    triggerKeys: string[];
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                hide: (...args: any[]) => void;
                show: (...args: any[]) => void;
                open: (...args: any[]) => void;
                close: (...args: any[]) => void;
                "update:visible": (...args: any[]) => void;
                "before-show": (...args: any[]) => void;
                "before-hide": (...args: any[]) => void;
            }, string, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                } & {
                    content?: (props: {}) => any;
                };
            }>>;
            ElRovingFocusGroup: import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {
                ElFocusGroupCollection: {
                    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                        P: {};
                        B: {};
                        D: {};
                        C: {};
                        M: {};
                        Defaults: {};
                    }, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, {}>;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
                    name: string;
                    setup(): void;
                };
                ElRovingFocusGroupImpl: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
                    style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                    currentTabId: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    defaultCurrentTabId: StringConstructor;
                    loop: BooleanConstructor;
                    dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                    orientation: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    onBlur: FunctionConstructor;
                    onFocus: FunctionConstructor;
                    onMousedown: FunctionConstructor;
                }>, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("currentTabIdChange" | "entryFocus")[], "currentTabIdChange" | "entryFocus", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
                    style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                    currentTabId: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    defaultCurrentTabId: StringConstructor;
                    loop: BooleanConstructor;
                    dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                    orientation: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    onBlur: FunctionConstructor;
                    onFocus: FunctionConstructor;
                    onMousedown: FunctionConstructor;
                }>> & Readonly<{
                    onCurrentTabIdChange?: ((...args: any[]) => any) | undefined;
                    onEntryFocus?: ((...args: any[]) => any) | undefined;
                }>, {
                    style: import("vue").StyleValue;
                    loop: boolean;
                    dir: string;
                }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
            }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
            ElOnlyChild: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
                [key: string]: any;
            }> | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
            ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>>;
            ArrowDown: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        } & import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly trigger: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                readonly __epPropKey: true;
                readonly default: "hover";
            };
            readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
            readonly virtualTriggering: BooleanConstructor;
            readonly virtualRef: {
                readonly type: import("vue").PropType<import("element-plus").Measurable>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly effect: {
                readonly default: "light";
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                readonly __epPropKey: true;
            };
            readonly type: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
            readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
            readonly id: StringConstructor;
            readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly splitButton: BooleanConstructor;
            readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
            readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
            readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
            readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | ((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | null)[], unknown, unknown, undefined, boolean>;
            readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: BooleanConstructor;
            readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
            readonly buttonProps: {
                readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly appendTo: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        }>> & Readonly<{
            onClick?: ((...args: any[]) => any) | undefined;
            onCommand?: ((...args: any[]) => any) | undefined;
            "onVisible-change"?: ((...args: any[]) => any) | undefined;
        }>, {
            t: import("element-plus").Translator;
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            scrollbar: import("vue").Ref<null, null>;
            wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
            dropdownTriggerKls: import("vue").ComputedRef<string[]>;
            dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            triggerId: import("vue").ComputedRef<string>;
            currentTabId: import("vue").Ref<string | null, string | null>;
            handleCurrentTabIdChange: (id: string) => void;
            handlerMainButtonClick: (event: MouseEvent) => void;
            handleClose: () => void;
            handleOpen: () => void;
            handleBeforeShowTooltip: () => void;
            handleShowTooltip: (event?: Event) => void;
            handleBeforeHideTooltip: () => void;
            popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
            contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
            triggeringElementRef: import("vue").Ref<any, any>;
            referenceElementRef: import("vue").Ref<any, any>;
        }, {}, {}, {}, {
            readonly disabled: boolean;
            readonly size: string;
            readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
            readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
            readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
            readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
            readonly popperStyle: import("vue").StyleValue;
            readonly virtualTriggering: boolean;
            readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
            readonly popperOptions: Partial<import("element-plus").Options>;
            readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
            readonly triggerKeys: string[];
            readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
            readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showTimeout: number;
            readonly hideTimeout: number;
            readonly splitButton: boolean;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly trigger: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
            readonly default: "hover";
        };
        readonly triggerKeys: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | (((new (...args: any[]) => string[]) | (() => string[])) | null)[], unknown, unknown, () => string[], boolean>;
        readonly virtualTriggering: BooleanConstructor;
        readonly virtualRef: {
            readonly type: import("vue").PropType<import("element-plus").Measurable>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly effect: {
            readonly default: "light";
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
        };
        readonly type: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger")) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown, "bottom", boolean>;
        readonly popperOptions: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | (((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly id: StringConstructor;
        readonly size: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly splitButton: BooleanConstructor;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly hideTimeout: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, "", boolean>;
        readonly popperClass: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | (() => import("element-plus/es/utils/typescript.mjs").ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: BooleanConstructor;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown, "menu", boolean>;
        readonly buttonProps: {
            readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & Readonly<{
        onClick?: ((...args: any[]) => any) | undefined;
        onCommand?: ((...args: any[]) => any) | undefined;
        "onVisible-change"?: ((...args: any[]) => any) | undefined;
    }>, {
        t: import("element-plus").Translator;
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        scrollbar: import("vue").Ref<null, null>;
        wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
        dropdownTriggerKls: import("vue").ComputedRef<string[]>;
        dropdownSize: import("vue").ComputedRef<"" | "default" | "large" | "small">;
        triggerId: import("vue").ComputedRef<string>;
        currentTabId: import("vue").Ref<string | null, string | null>;
        handleCurrentTabIdChange: (id: string) => void;
        handlerMainButtonClick: (event: MouseEvent) => void;
        handleClose: () => void;
        handleOpen: () => void;
        handleBeforeShowTooltip: () => void;
        handleShowTooltip: (event?: Event) => void;
        handleBeforeHideTooltip: () => void;
        popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined, import("element-plus").TooltipInstance | undefined>;
        contentRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
        triggeringElementRef: import("vue").Ref<any, any>;
        referenceElementRef: import("vue").Ref<any, any>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "visible-change" | "command")[], "click" | "visible-change" | "command", {
        readonly disabled: boolean;
        readonly size: string;
        readonly role: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree", unknown>;
        readonly teleported: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly effect: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | (((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect)) | null)[], unknown, unknown>;
        readonly tabindex: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly popperClass: import("element-plus/es/utils/typescript.mjs").ClassValue;
        readonly popperStyle: import("vue").StyleValue;
        readonly virtualTriggering: boolean;
        readonly loop: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement)) | null)[], unknown, unknown>;
        readonly popperOptions: Partial<import("element-plus").Options>;
        readonly showArrow: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly persistent: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<"click" | "contextmenu" | "hover">;
        readonly triggerKeys: string[];
        readonly maxHeight: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        readonly hideOnClick: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTimeout: number;
        readonly hideTimeout: number;
        readonly splitButton: boolean;
    }, {}, string, {}, {
        ElButton: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                click: (evt: MouseEvent) => void;
            }, import("vue").PublicProps, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").ButtonProps> & Readonly<{
                onClick?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
                size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
                type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
                disabled: import("vue").ComputedRef<boolean>;
                shouldAddSpace: import("vue").ComputedRef<boolean>;
            }, {}, {}, {}, {
                type: import("element-plus").ButtonType;
                text: boolean;
                disabled: boolean;
                round: boolean;
                dashed: boolean;
                tag: string | import("vue").Component;
                nativeType: import("element-plus").ButtonNativeType;
                loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
                plain: boolean;
                autoInsertSpace: boolean;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ButtonProps> & Readonly<{
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }>, {
            ref: import("vue").Ref<HTMLButtonElement | undefined, HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "default" | "large" | "small">;
            type: import("vue").ComputedRef<"default" | "" | "text" | "info" | "primary" | "success" | "warning" | "danger">;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, string, {
            type: import("element-plus").ButtonType;
            text: boolean;
            disabled: boolean;
            round: boolean;
            dashed: boolean;
            tag: string | import("vue").Component;
            nativeType: import("element-plus").ButtonNativeType;
            loadingIcon: import("element-plus/es/utils/vue/icon.mjs").IconPropType;
            plain: boolean;
            autoInsertSpace: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
            setPropsDefaults: (defaults: {
                readonly size?: "" | "default" | "large" | "small" | (() => "" | "default" | "large" | "small") | undefined;
                readonly disabled?: boolean | (() => boolean) | undefined;
                readonly type?: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger" | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | undefined;
                readonly icon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                readonly nativeType?: "button" | "reset" | "submit" | (() => "button" | "reset" | "submit") | undefined;
                readonly loading?: boolean | (() => boolean) | undefined;
                readonly loadingIcon?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (import("element-plus/es/utils/vue/icon.mjs").IconPropType | undefined) & {}) | undefined;
                readonly plain?: boolean | (() => boolean) | undefined;
                readonly text?: boolean | (() => boolean) | undefined;
                readonly link?: boolean | (() => boolean) | undefined;
                readonly bg?: boolean | (() => boolean) | undefined;
                readonly autofocus?: boolean | (() => boolean) | undefined;
                readonly round?: boolean | (() => boolean) | undefined;
                readonly circle?: boolean | (() => boolean) | undefined;
                readonly dashed?: boolean | (() => boolean) | undefined;
                readonly color?: string | (() => string) | undefined;
                readonly dark?: boolean | (() => boolean) | undefined;
                readonly autoInsertSpace?: boolean | (() => boolean) | undefined;
                readonly tag?: string | import("vue").FunctionalComponent<any, {}, any, {}> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | (() => (string | import("vue").Component | undefined) & {}) | undefined;
            }) => void;
        } & {
            ButtonGroup: __ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                    type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                    direction: "horizontal" | "vertical";
                }>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>;
        }, {
            $slots: {
                loading?: (props: {}) => any;
            } & {
                icon?: (props: {}) => any;
            } & {
                default?: (props: {}) => any;
            };
        }>;
        ElButtonGroup: __ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
                type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
                direction: "horizontal" | "vertical";
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>;
        ElScrollbar: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                scroll: (args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => void;
                "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
            }, import("vue").PublicProps, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").ScrollbarProps> & Readonly<{
                onScroll?: ((args_0: {
                    scrollTop: number;
                    scrollLeft: number;
                }) => any) | undefined;
                "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
            }>, {
                wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
                update: () => void;
                scrollTo: {
                    (xCord: number, yCord?: number): void;
                    (options: ScrollToOptions): void;
                };
                setScrollTop: (value: number) => void;
                setScrollLeft: (value: number) => void;
                handleScroll: () => void;
            }, {}, {}, {}, {
                height: number | string;
                tag: keyof HTMLElementTagNameMap | (string & {});
                tabindex: number | string;
                maxHeight: number | string;
                distance: number;
                wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                minSize: number;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").ScrollbarProps> & Readonly<{
            onScroll?: ((args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => any) | undefined;
            "onEnd-reached"?: ((direction: import("element-plus").ScrollbarDirection) => any) | undefined;
        }>, {
            wrapRef: import("vue").Ref<HTMLDivElement | undefined, HTMLDivElement | undefined>;
            update: () => void;
            scrollTo: {
                (xCord: number, yCord?: number): void;
                (options: ScrollToOptions): void;
            };
            setScrollTop: (value: number) => void;
            setScrollLeft: (value: number) => void;
            handleScroll: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            scroll: (args_0: {
                scrollTop: number;
                scrollLeft: number;
            }) => void;
            "end-reached": (direction: import("element-plus").ScrollbarDirection) => void;
        }, string, {
            height: number | string;
            tag: keyof HTMLElementTagNameMap | (string & {});
            tabindex: number | string;
            maxHeight: number | string;
            distance: number;
            wrapStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            wrapClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            viewClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            viewStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            minSize: number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>>;
        ElTooltip: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                hide: (...args: any[]) => void;
                show: (...args: any[]) => void;
                open: (...args: any[]) => void;
                close: (...args: any[]) => void;
                "update:visible": (...args: any[]) => void;
                "before-show": (...args: any[]) => void;
                "before-hide": (...args: any[]) => void;
            }, import("vue").PublicProps, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").UseTooltipProps> & Readonly<{
                onHide?: ((...args: any[]) => any) | undefined;
                onShow?: ((...args: any[]) => any) | undefined;
                onOpen?: ((...args: any[]) => any) | undefined;
                onClose?: ((...args: any[]) => any) | undefined;
                "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
                "onBefore-show"?: ((...args: any[]) => any) | undefined;
                "onBefore-hide"?: ((...args: any[]) => any) | undefined;
            }>, {
                popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
                contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
                isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
                updatePopper: () => void;
                onOpen: (event?: Event, delay?: number) => void;
                onClose: (event?: Event, delay?: number) => void;
                hide: (event?: Event) => void;
            }, {}, {}, {}, {
                visible: boolean | null;
                style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                content: string;
                role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
                offset: number;
                teleported: boolean;
                effect: import("element-plus").PopperEffect;
                enterable: boolean;
                pure: boolean;
                focusOnShow: boolean;
                trapping: boolean;
                popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
                popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
                stopPopperMouseEvent: boolean;
                virtualTriggering: boolean;
                loop: boolean;
                boundariesPadding: number;
                gpuAcceleration: boolean;
                placement: import("element-plus").Placement;
                popperOptions: Partial<import("element-plus").Options>;
                strategy: "absolute" | "fixed";
                arrowOffset: number;
                showArrow: boolean;
                showAfter: number;
                hideAfter: number;
                autoClose: number;
                trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
                triggerKeys: string[];
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").UseTooltipProps> & Readonly<{
            onHide?: ((...args: any[]) => any) | undefined;
            onShow?: ((...args: any[]) => any) | undefined;
            onOpen?: ((...args: any[]) => any) | undefined;
            onClose?: ((...args: any[]) => any) | undefined;
            "onUpdate:visible"?: ((...args: any[]) => any) | undefined;
            "onBefore-show"?: ((...args: any[]) => any) | undefined;
            "onBefore-hide"?: ((...args: any[]) => any) | undefined;
        }>, {
            popperRef: import("vue").Ref<import("element-plus").PopperInstance | undefined, import("element-plus").PopperInstance | undefined>;
            contentRef: import("vue").Ref<import("element-plus").TooltipContentInstance | undefined, import("element-plus").TooltipContentInstance | undefined>;
            isFocusInsideContent: (event?: FocusEvent) => boolean | undefined;
            updatePopper: () => void;
            onOpen: (event?: Event, delay?: number) => void;
            onClose: (event?: Event, delay?: number) => void;
            hide: (event?: Event) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            hide: (...args: any[]) => void;
            show: (...args: any[]) => void;
            open: (...args: any[]) => void;
            close: (...args: any[]) => void;
            "update:visible": (...args: any[]) => void;
            "before-show": (...args: any[]) => void;
            "before-hide": (...args: any[]) => void;
        }, string, {
            visible: boolean | null;
            style: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            content: string;
            role: "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree";
            offset: number;
            teleported: boolean;
            effect: import("element-plus").PopperEffect;
            enterable: boolean;
            pure: boolean;
            focusOnShow: boolean;
            trapping: boolean;
            popperClass: string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[] | null;
            popperStyle: string | false | import("vue").CSSProperties | import("vue").StyleValue[] | null;
            stopPopperMouseEvent: boolean;
            virtualTriggering: boolean;
            loop: boolean;
            boundariesPadding: number;
            gpuAcceleration: boolean;
            placement: import("element-plus").Placement;
            popperOptions: Partial<import("element-plus").Options>;
            strategy: "absolute" | "fixed";
            arrowOffset: number;
            showArrow: boolean;
            showAfter: number;
            hideAfter: number;
            autoClose: number;
            trigger: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").TooltipTriggerType>;
            triggerKeys: string[];
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            } & {
                content?: (props: {}) => any;
            };
        }>>;
        ElRovingFocusGroup: import("vue").DefineComponent<{}, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {
            ElFocusGroupCollection: {
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, {}>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
                name: string;
                setup(): void;
            };
            ElRovingFocusGroupImpl: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
                style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                currentTabId: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultCurrentTabId: StringConstructor;
                loop: BooleanConstructor;
                dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                orientation: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                onBlur: FunctionConstructor;
                onFocus: FunctionConstructor;
                onMousedown: FunctionConstructor;
            }>, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("currentTabIdChange" | "entryFocus")[], "currentTabIdChange" | "entryFocus", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
                style: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | (((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                currentTabId: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => string | null) | (((new (...args: any[]) => string) | (() => string | null)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultCurrentTabId: StringConstructor;
                loop: BooleanConstructor;
                dir: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<StringConstructor, string, unknown, string, boolean>;
                orientation: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined) | (((new (...args: any[]) => "horizontal" | "vertical") | (() => "horizontal" | "vertical" | undefined)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                onBlur: FunctionConstructor;
                onFocus: FunctionConstructor;
                onMousedown: FunctionConstructor;
            }>> & Readonly<{
                onCurrentTabIdChange?: ((...args: any[]) => any) | undefined;
                onEntryFocus?: ((...args: any[]) => any) | undefined;
            }>, {
                style: import("vue").StyleValue;
                loop: boolean;
                dir: string;
            }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElOnlyChild: import("vue").DefineComponent<{}, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                default?: (props: {}) => any;
            };
        }>>;
        ArrowDown: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    } & import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        setPropsDefaults: (defaults: {
            readonly disabled?: boolean | (() => boolean) | undefined;
            readonly size?: string | (() => string) | undefined;
            readonly role?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<StringConstructor, "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree", unknown> | (() => "dialog" | "menu" | "grid" | "tooltip" | "listbox" | "group" | "navigation" | "tree") | undefined;
            readonly teleported?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown> | (() => boolean) | undefined;
            readonly effect?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | ((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | null)[], unknown, unknown> | (() => string) | undefined;
            readonly tabindex?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number) | null)[], unknown, unknown> | (() => string | number) | undefined;
            readonly popperClass?: string | false | (() => string | false | Record<string, any> | import("element-plus/es/utils/typescript.mjs").ClassValue[]) | null | undefined;
            readonly popperStyle?: string | false | (() => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | null | undefined;
            readonly virtualTriggering?: boolean | (() => boolean) | undefined;
            readonly loop?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown> | (() => boolean) | undefined;
            readonly placement?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | ((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | null)[], unknown, unknown> | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end" | "auto" | "auto-start" | "auto-end") | undefined;
            readonly popperOptions?: (() => Partial<import("element-plus").Options>) | undefined;
            readonly showArrow?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown> | (() => boolean) | undefined;
            readonly persistent?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown> | (() => boolean) | undefined;
            readonly trigger?: "click" | "contextmenu" | "hover" | (() => "click" | "contextmenu" | "hover" | ("click" | "contextmenu" | "hover")[]) | undefined;
            readonly triggerKeys?: (() => string[]) | undefined;
            readonly maxHeight?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number) | null)[], unknown, unknown> | (() => string | number) | undefined;
            readonly hideOnClick?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<BooleanConstructor, unknown, unknown> | (() => boolean) | undefined;
            readonly showTimeout?: number | (() => number) | undefined;
            readonly hideTimeout?: number | (() => number) | undefined;
            readonly splitButton?: boolean | (() => boolean) | undefined;
            readonly id?: string | (() => string) | undefined;
            readonly type?: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | ((new (...args: any[]) => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | (() => "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger") | null)[], unknown, unknown> | (() => "" | "default" | "primary" | "success" | "warning" | "info" | "danger" | "text") | undefined;
            readonly appendTo?: string | (() => string | HTMLElement) | undefined;
            readonly virtualRef?: (() => import("element-plus").Measurable) | undefined;
            readonly buttonProps?: (() => Partial<import("element-plus").ButtonProps>) | undefined;
        }) => void;
    } & {
        DropdownItem: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
            readonly disabled: BooleanConstructor;
            readonly divided: BooleanConstructor;
            readonly textValue: StringConstructor;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>, {
            handleClick: (event: PointerEvent) => void;
            handlePointerMove: (event: PointerEvent) => void;
            handlePointerLeave: (event: PointerEvent) => void;
            propsAndAttrs: import("vue").ComputedRef<{
                disabled: boolean;
                command: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
                divided: boolean;
                icon: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
                textValue: string | undefined;
                onClick: ((...args: any[]) => any) | undefined;
                onPointerleave: ((...args: any[]) => any) | undefined;
                onPointermove: ((...args: any[]) => any) | undefined;
            }>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "pointerleave" | "pointermove")[], "click" | "pointerleave" | "pointermove", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
            readonly disabled: BooleanConstructor;
            readonly divided: BooleanConstructor;
            readonly textValue: StringConstructor;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>> & Readonly<{
            onClick?: ((...args: any[]) => any) | undefined;
            onPointerleave?: ((...args: any[]) => any) | undefined;
            onPointermove?: ((...args: any[]) => any) | undefined;
        }>, {
            readonly disabled: boolean;
            readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
            readonly divided: boolean;
        }, {}, {
            ElRovingFocusItem: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
                focusable: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                active: BooleanConstructor;
            }>, {
                id: import("vue").Ref<string, string>;
                handleKeydown: (event: Event) => void;
                handleFocus: (event: Event) => void;
                handleMousedown: (event: Event) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "keydown" | "mousedown")[], "focus" | "keydown" | "mousedown", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
                focusable: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                active: BooleanConstructor;
            }>> & Readonly<{
                onFocus?: ((...args: any[]) => any) | undefined;
                onKeydown?: ((...args: any[]) => any) | undefined;
                onMousedown?: ((...args: any[]) => any) | undefined;
            }>, {
                active: boolean;
                focusable: boolean;
            }, {}, {
                ElRovingFocusCollectionItem: {
                    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                        P: {};
                        B: {};
                        D: {};
                        C: {};
                        M: {};
                        Defaults: {};
                    }, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, {}>;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
                    name: string;
                    setup(_: unknown, { attrs }: import("vue").SetupContext): void;
                };
            }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
            ElDropdownItemImpl: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
                readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
                readonly disabled: BooleanConstructor;
                readonly divided: BooleanConstructor;
                readonly textValue: StringConstructor;
                readonly icon: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
            }>, {
                ns: {
                    namespace: import("vue").ComputedRef<string>;
                    b: (blockSuffix?: string) => string;
                    e: (element?: string) => string;
                    m: (modifier?: string) => string;
                    be: (blockSuffix?: string, element?: string) => string;
                    em: (element?: string, modifier?: string) => string;
                    bm: (blockSuffix?: string, modifier?: string) => string;
                    bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                    is: {
                        (name: string, state: boolean | undefined): string;
                        (name: string): string;
                    };
                    cssVar: (object: Record<string, string>) => Record<string, string>;
                    cssVarName: (name: string) => string;
                    cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                    cssVarBlockName: (name: string) => string;
                };
                itemRef: (el: Element | import("vue").ComponentPublicInstance | null) => void;
                dataset: {
                    "data-el-collection-item": string;
                };
                role: import("vue").ComputedRef<string>;
                tabIndex: import("vue").Ref<number, number>;
                handleFocus: (e: Event) => void;
                handleKeydown: (event: KeyboardEvent) => void;
                handleMousedown: (e: Event) => void;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "pointerleave" | "pointermove" | "clickimpl")[], "click" | "pointerleave" | "pointermove" | "clickimpl", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
                readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
                readonly disabled: BooleanConstructor;
                readonly divided: BooleanConstructor;
                readonly textValue: StringConstructor;
                readonly icon: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
            }>> & Readonly<{
                onClick?: ((...args: any[]) => any) | undefined;
                onPointerleave?: ((...args: any[]) => any) | undefined;
                onPointermove?: ((...args: any[]) => any) | undefined;
                onClickimpl?: ((...args: any[]) => any) | undefined;
            }>, {
                readonly disabled: boolean;
                readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
                readonly divided: boolean;
            }, {}, {
                ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
                    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                        P: {};
                        B: {};
                        D: {};
                        C: {};
                        M: {};
                        Defaults: {};
                    }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                }>>;
            }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        DropdownMenu: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            onKeydown: {
                readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>, {
            size: import("vue").ComputedRef<string> | undefined;
            rovingFocusGroupRootStyle: import("vue").Ref<import("vue").StyleValue, import("vue").StyleValue>;
            dropdownKls: import("vue").ComputedRef<string[]>;
            role: import("vue").ComputedRef<"listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree" | undefined>;
            triggerId: import("vue").ComputedRef<string>;
            dropdownListWrapperRef: (el: Element | import("vue").ComponentPublicInstance | null) => void;
            handleKeydown: (event: KeyboardEvent) => void;
            onBlur: (e: Event) => void;
            handleFocus: (e: FocusEvent) => void;
            onMousedown: (e: Event) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            onKeydown: {
                readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    ElDropdownMenu: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
        onKeydown: {
            readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>, {
        size: import("vue").ComputedRef<string> | undefined;
        rovingFocusGroupRootStyle: import("vue").Ref<import("vue").StyleValue, import("vue").StyleValue>;
        dropdownKls: import("vue").ComputedRef<string[]>;
        role: import("vue").ComputedRef<"listbox" | "grid" | "menu" | "tooltip" | "dialog" | "group" | "navigation" | "tree" | undefined>;
        triggerId: import("vue").ComputedRef<string>;
        dropdownListWrapperRef: (el: Element | import("vue").ComponentPublicInstance | null) => void;
        handleKeydown: (event: KeyboardEvent) => void;
        onBlur: (e: Event) => void;
        handleFocus: (e: FocusEvent) => void;
        onMousedown: (e: Event) => void;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
        onKeydown: {
            readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
    ElDropdownItem: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
        readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
        readonly disabled: BooleanConstructor;
        readonly divided: BooleanConstructor;
        readonly textValue: StringConstructor;
        readonly icon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>, {
        handleClick: (event: PointerEvent) => void;
        handlePointerMove: (event: PointerEvent) => void;
        handlePointerLeave: (event: PointerEvent) => void;
        propsAndAttrs: import("vue").ComputedRef<{
            disabled: boolean;
            command: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
            divided: boolean;
            icon: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
            textValue: string | undefined;
            onClick: ((...args: any[]) => any) | undefined;
            onPointerleave: ((...args: any[]) => any) | undefined;
            onPointermove: ((...args: any[]) => any) | undefined;
        }>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "pointerleave" | "pointermove")[], "click" | "pointerleave" | "pointermove", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
        readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
        readonly disabled: BooleanConstructor;
        readonly divided: BooleanConstructor;
        readonly textValue: StringConstructor;
        readonly icon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & Readonly<{
        onClick?: ((...args: any[]) => any) | undefined;
        onPointerleave?: ((...args: any[]) => any) | undefined;
        onPointermove?: ((...args: any[]) => any) | undefined;
    }>, {
        readonly disabled: boolean;
        readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
        readonly divided: boolean;
    }, {}, {
        ElRovingFocusItem: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            focusable: {
                type: BooleanConstructor;
                default: boolean;
            };
            active: BooleanConstructor;
        }>, {
            id: import("vue").Ref<string, string>;
            handleKeydown: (event: Event) => void;
            handleFocus: (event: Event) => void;
            handleMousedown: (event: Event) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("focus" | "keydown" | "mousedown")[], "focus" | "keydown" | "mousedown", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            focusable: {
                type: BooleanConstructor;
                default: boolean;
            };
            active: BooleanConstructor;
        }>> & Readonly<{
            onFocus?: ((...args: any[]) => any) | undefined;
            onKeydown?: ((...args: any[]) => any) | undefined;
            onMousedown?: ((...args: any[]) => any) | undefined;
        }>, {
            active: boolean;
            focusable: boolean;
        }, {}, {
            ElRovingFocusCollectionItem: {
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, {}>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & {
                name: string;
                setup(_: unknown, { attrs }: import("vue").SetupContext): void;
            };
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        ElDropdownItemImpl: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
            readonly disabled: BooleanConstructor;
            readonly divided: BooleanConstructor;
            readonly textValue: StringConstructor;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            itemRef: (el: Element | import("vue").ComponentPublicInstance | null) => void;
            dataset: {
                "data-el-collection-item": string;
            };
            role: import("vue").ComputedRef<string>;
            tabIndex: import("vue").Ref<number, number>;
            handleFocus: (e: Event) => void;
            handleKeydown: (event: KeyboardEvent) => void;
            handleMousedown: (e: Event) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "pointerleave" | "pointermove" | "clickimpl")[], "click" | "pointerleave" | "pointermove" | "clickimpl", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
            readonly disabled: BooleanConstructor;
            readonly divided: BooleanConstructor;
            readonly textValue: StringConstructor;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>> & Readonly<{
            onClick?: ((...args: any[]) => any) | undefined;
            onPointerleave?: ((...args: any[]) => any) | undefined;
            onPointermove?: ((...args: any[]) => any) | undefined;
            onClickimpl?: ((...args: any[]) => any) | undefined;
        }>, {
            readonly disabled: boolean;
            readonly command: import("element-plus/es/utils/vue/props/types.mjs").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
            readonly divided: boolean;
        }, {}, {
            ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
                new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                    P: {};
                    B: {};
                    D: {};
                    C: {};
                    M: {};
                    Defaults: {};
                }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
                $slots: {
                    default?: (props: {}) => any;
                };
            }>>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
    ElIcon: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {}, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, {}>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus").IconProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        };
    }>>;
    ZxButton: __ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "", boolean>;
            readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => {}, boolean>;
        }>> & Readonly<{
            onSuccess?: (() => any) | undefined;
            onError?: ((error: Error) => any) | undefined;
            onStartLoading?: (() => any) | undefined;
            onEndLoading?: (() => any) | undefined;
        }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            success: () => void;
            error: (error: Error) => void;
            startLoading: () => void;
            endLoading: () => void;
        }, import("vue").PublicProps, {
            readonly debounce: number;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly throttle: number;
            readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly iconRight: string;
            readonly iconRightProps: Record<string, any>;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
            readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, "", boolean>;
            readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
                (): Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown, () => {}, boolean>;
        }>> & Readonly<{
            onSuccess?: (() => any) | undefined;
            onError?: ((error: Error) => any) | undefined;
            onStartLoading?: (() => any) | undefined;
            onEndLoading?: (() => any) | undefined;
        }>, {}, {}, {}, {}, {
            readonly debounce: number;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
                (): string | Record<string, any>;
                new (): any;
                readonly prototype: any;
            }) | null)[], unknown, unknown>;
            readonly throttle: number;
            readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly iconRight: string;
            readonly iconRightProps: Record<string, any>;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        success: () => void;
        error: (error: Error) => void;
        startLoading: () => void;
        endLoading: () => void;
    }, string, {
        readonly debounce: number;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        } & {
            loading?: (props: {}) => any;
        } & {
            'tooltip-content'?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        } & {
            loading?: (props: {}) => any;
        };
    }>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export declare const ZxActionBar: import("@zxio/shared").SFCWithInstall<__ZXUI_WithSlots<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<readonly import("./src/toolbar-actions").ZxToolbarAction[]>;
            required: true;
        };
        label: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        action: (action: import("./src/toolbar-actions").ZxToolbarAction) => any;
    }, import("vue").PublicProps, {
        label: string;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        actions: {
            type: import("vue").PropType<readonly import("./src/toolbar-actions").ZxToolbarAction[]>;
            required: true;
        };
        label: {
            type: StringConstructor;
            default: string;
        };
    }>> & Readonly<{
        onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
    }>, {}, {}, {}, {}, {
        label: string;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    actions: {
        type: import("vue").PropType<readonly import("./src/toolbar-actions").ZxToolbarAction[]>;
        required: true;
    };
    label: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: import("./src/toolbar-actions").ZxToolbarAction) => any;
}, string, {
    label: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
    $slots: {
        action?: (props: {
            action: import("./src/toolbar-actions").ZxToolbarAction;
        }) => any;
    };
}>> & Record<string, any>;
export default ZxMoreAction;
export * from './src/props';
export * from './src/instance';
export type { ZxToolbarAction } from './src/toolbar-actions';
export type { ButtonVariant } from '@zxio/constants/form-modal';

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
