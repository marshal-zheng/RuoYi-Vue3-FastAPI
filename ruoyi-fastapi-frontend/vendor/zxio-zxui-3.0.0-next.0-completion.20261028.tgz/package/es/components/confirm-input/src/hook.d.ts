import type { ThemeFeedback } from '../../theme-provider';
import type { ConfirmInputTranslator } from './locale';
export declare function useFormValidation(props: any, t: ConfirmInputTranslator): {
    form: {
        value: string;
    };
    localValid: import("vue").Ref<boolean, boolean>;
    validating: import("vue").Ref<boolean, boolean>;
    attempted: import("vue").Ref<boolean, boolean>;
    revision: import("vue").Ref<number, number>;
    isMatch: (value?: string) => Promise<boolean>;
    errorText: import("vue").ComputedRef<string>;
    validationError: import("vue").ComputedRef<string>;
    normalizedPattern: import("vue").ComputedRef<RegExp | null>;
};
export declare function useDialogState(props: any, emit: any): {
    visible: import("vue").Ref<any, any>;
    session: import("vue").Ref<number, number>;
    handleOpen: () => void;
    handleClose: () => void;
    handleCancel: () => void;
    markConfirmed: () => void;
};
export declare function useConfirmAction(props: any, emit: any, formValidation: any, dialogState: any, feedback: ThemeFeedback | null, t: ConfirmInputTranslator): {
    internalLoading: import("vue").Ref<boolean, boolean>;
    isLoading: import("vue").ComputedRef<any>;
    isExecuting: import("vue").Ref<boolean, boolean>;
    confirmDisabled: import("vue").ComputedRef<any>;
    tryConfirm: (_formRef?: any) => Promise<unknown>;
};
export declare function useFormReset(form: any, formRef: any, inputRef: any, props: any): {
    resetForm: () => void;
    focusInput: () => void;
    handleDialogOpen: () => void;
};
export declare function useKeyboardEvents(): {
    handleEnterKey: (event: Event, confirmCallback: any) => void;
    handleEscapeKey: (event: KeyboardEvent, cancelCallback: any) => void;
};
export declare function useZxConfirmInput(props: any, emit: any, feedback: ThemeFeedback | null, t: ConfirmInputTranslator): {
    handleEnterKey: (event: Event, confirmCallback: any) => void;
    handleEscapeKey: (event: KeyboardEvent, cancelCallback: any) => void;
    resetForm: () => void;
    focusInput: () => void;
    handleDialogOpen: () => void;
    internalLoading: import("vue").Ref<boolean, boolean>;
    isLoading: import("vue").ComputedRef<any>;
    isExecuting: import("vue").Ref<boolean, boolean>;
    confirmDisabled: import("vue").ComputedRef<any>;
    tryConfirm: (_formRef?: any) => Promise<unknown>;
    handleOpen: () => void;
    handleOpenAutoFocus: () => void;
    visible: import("vue").Ref<any, any>;
    session: import("vue").Ref<number, number>;
    handleClose: () => void;
    handleCancel: () => void;
    markConfirmed: () => void;
    form: {
        value: string;
    };
    localValid: import("vue").Ref<boolean, boolean>;
    validating: import("vue").Ref<boolean, boolean>;
    attempted: import("vue").Ref<boolean, boolean>;
    revision: import("vue").Ref<number, number>;
    isMatch: (value?: string) => Promise<boolean>;
    errorText: import("vue").ComputedRef<string>;
    validationError: import("vue").ComputedRef<string>;
    normalizedPattern: import("vue").ComputedRef<RegExp | null>;
    formRef: import("vue").Ref<null, null>;
    inputRef: import("vue").Ref<null, null>;
};
