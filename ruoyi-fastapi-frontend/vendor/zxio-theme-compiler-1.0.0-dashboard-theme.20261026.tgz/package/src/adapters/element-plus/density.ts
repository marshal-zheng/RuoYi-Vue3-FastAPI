import { elementPlusSizeOffsets } from '@zxio/tokens/display'

/**
 * Preserve Element Plus's size resolution; project ZXUI's final metrics.
 * At the default 8px control-y rhythm these are 28 / 36 / 44px.
 * Compact (6px) and comfortable (10px) move each size by -4px / +4px.
 * Scoped display overrides consume the same offsets from @zxio/tokens/display.
 */
export const elementPlusControlSizeOffsets = {
  '--el-component-size': elementPlusSizeOffsets.default,
  '--el-component-size-large': elementPlusSizeOffsets.large,
  '--el-component-size-small': elementPlusSizeOffsets.small,
} as const

export function elementPlusDensityValue(
  source: string,
  target: string,
  value: string
): string {
  if (source !== 'semantic.spacing.control-y') return value
  const offset =
    elementPlusControlSizeOffsets[
      target as keyof typeof elementPlusControlSizeOffsets
    ]
  return offset === undefined ? value : `calc(${value} * 2 + ${offset}px)`
}
