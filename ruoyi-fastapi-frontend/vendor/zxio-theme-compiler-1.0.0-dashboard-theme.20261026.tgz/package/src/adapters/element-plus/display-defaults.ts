import type { ElementPlusDisplayDefault } from './model'

// Baselines are the locked EP 2.14.7 defaults. Only defaults multiply the
// effective control factor; an inline/public --el-* override remains raw CSS.
export const elementPlusDisplayDefaults = [
  {
    target: '--el-calendar-cell-width',
    value: { kind: 'scaled-px', px: 85 },
  },
  {
    target: '--el-date-editor-daterange-width',
    value: { kind: 'scaled-px', px: 350 },
  },
  {
    target: '--el-date-editor-datetimerange-width',
    value: { kind: 'scaled-px', px: 400 },
  },
  {
    target: '--el-date-editor-monthrange-width',
    value: { kind: 'scaled-px', px: 300 },
  },
  {
    target: '--el-date-editor-quarterrange-width',
    value: { kind: 'scaled-px', px: 300 },
  },
  { target: '--el-date-editor-width', value: { kind: 'scaled-px', px: 220 } },
  {
    target: '--el-messagebox-error-font-size',
    value: {
      kind: 'variable',
      variable: '--el-font-size-extra-small',
      factor: 1,
    },
  },
  {
    target: '--el-messagebox-padding-primary',
    value: {
      kind: 'variable',
      variable: '--zx-semantic-spacing-control-y',
      factor: 1.5,
    },
  },
  { target: '--el-messagebox-width', value: { kind: 'scaled-px', px: 420 } },
  {
    target: '--el-transfer-filter-height',
    value: { kind: 'variable', variable: '--el-component-size', factor: 1 },
  },
  { target: '--el-transfer-item-height', value: { kind: 'scaled-px', px: 30 } },
  {
    target: '--el-transfer-panel-body-height',
    value: { kind: 'scaled-px', px: 278 },
  },
  {
    target: '--el-transfer-panel-footer-height',
    value: { kind: 'scaled-px', px: 40 },
  },
  {
    target: '--el-transfer-panel-header-height',
    value: { kind: 'scaled-px', px: 40 },
  },
  {
    target: '--el-transfer-panel-width',
    value: { kind: 'scaled-px', px: 200 },
  },
] as const satisfies readonly ElementPlusDisplayDefault[]

export function elementPlusDisplayDefaultValue(
  value: ElementPlusDisplayDefault['value']
): string {
  if (value.kind === 'scaled-px')
    return `calc(${value.px}px * var(--zx-display-control-factor))`
  return value.factor === 1
    ? `var(${value.variable})`
    : `calc(var(${value.variable}) * ${value.factor})`
}

export function validElementPlusDisplayDefaultValue(
  value: ElementPlusDisplayDefault['value']
): boolean {
  if (!value || typeof value !== 'object') return false
  if (value.kind === 'scaled-px')
    return Number.isFinite(value.px) && value.px > 0
  return (
    value.kind === 'variable' &&
    [
      '--el-component-size',
      '--el-font-size-extra-small',
      '--zx-semantic-spacing-control-y',
    ].includes(value.variable) &&
    Number.isFinite(value.factor) &&
    value.factor > 0
  )
}
