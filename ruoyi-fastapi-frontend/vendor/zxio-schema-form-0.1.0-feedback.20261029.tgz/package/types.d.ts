import type { Component } from 'vue';
export type Json = null | boolean | number | string | Json[] | {
    [key: string]: Json;
};
export type Values = Record<string, Json>;
/** Composite fields opt into messages, edit-state, validation and focus adaptation. */
export interface CompositeBinding {
    component: Component;
    composite: boolean;
    editObservation?: 'canonical' | 'raw-sequence';
    /** Composite validate honors FieldValidationContext before feedback writes. */
    validationOwnership?: 'managed';
    /** Use an ordinary label for a scalar editor with transient edit state. A
     * group receives path-scoped messages for its inner controls; the field
     * presents field-level feedback either way. */
    group?: boolean;
    /** The control renders its own blocking messages, for example because it is
     * also used outside schema forms. The field then presents only canonical
     * feedback, and hides it while the control reports field-level blocking. */
    presentsBlocking?: boolean;
    /** Opt into projecting the field dataSource onto this component prop. */
    dataSourceProp?: string;
}
export type Binding = Component | CompositeBinding;
export type Bindings = Record<string, Binding>;
