# @zxio/theme-consumer

根入口提供框架无关的消费 ABI；`/vue` 为 Vue 3.5 提供作用域消费绑定。Host/Provider 拥有主题，库只能释放自身资源。
