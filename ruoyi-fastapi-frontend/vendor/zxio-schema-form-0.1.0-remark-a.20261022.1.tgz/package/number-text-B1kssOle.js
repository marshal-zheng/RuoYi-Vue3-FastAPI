"use strict";
const vue = require("vue");
const elementPlus = require("element-plus");
const fieldLayoutKey = Symbol("schema-field-layout");
const _hoisted_1 = ["id"];
const _hoisted_2 = {
  key: 0,
  "aria-hidden": "true",
  class: "zx-schema-field__required"
};
const _hoisted_3 = ["id"];
const _hoisted_4 = { class: "zx-schema-field__control" };
const _hoisted_5 = ["id"];
const _hoisted_6 = ["id"];
const _hoisted_7 = ["data-severity"];
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxField", inheritAttrs: false },
  __name: "Field",
  props: {
    label: {},
    description: {},
    required: { type: Boolean },
    group: { type: Boolean },
    messages: {},
    invalid: { type: Boolean },
    reserveFeedback: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const id = `zx-field-${vue.useId()}`;
    const layout = vue.inject(fieldLayoutKey, void 0);
    const controlProps = vue.computed(() => {
      var _a, _b;
      return {
        id,
        "aria-required": !props.group && props.required || void 0,
        "aria-labelledby": props.label ? `${id}-label` : void 0,
        "aria-invalid": props.invalid || ((_a = props.messages) == null ? void 0 : _a.some((item) => item.severity === "error")) || void 0,
        "aria-describedby": [
          props.description ? `${id}-help` : "",
          ((_b = props.messages) == null ? void 0 : _b.length) ? `${id}-messages` : ""
        ].filter(Boolean).join(" ") || void 0
      };
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(__props.group ? "fieldset" : "div"), vue.mergeProps(_ctx.$attrs, { class: "zx-schema-field" }), {
        default: vue.withCtx(() => {
          var _a, _b, _c, _d;
          return [
            __props.group ? (vue.openBlock(), vue.createElementBlock("legend", {
              key: 0,
              id: `${id}-label`,
              class: "zx-schema-field__label"
            }, [
              vue.createTextVNode(vue.toDisplayString(__props.label), 1),
              __props.required ? (vue.openBlock(), vue.createElementBlock("span", _hoisted_2, " *")) : vue.createCommentVNode("", true)
            ], 8, _hoisted_1)) : vue.createCommentVNode("", true),
            vue.createVNode(vue.unref(elementPlus.ElFormItem), {
              label: __props.group ? void 0 : __props.label,
              for: __props.group ? void 0 : id,
              "label-position": __props.group ? "top" : ((_a = vue.unref(layout)) == null ? void 0 : _a.labelPosition) ?? "top",
              "label-width": __props.group ? void 0 : (_b = vue.unref(layout)) == null ? void 0 : _b.labelWidth,
              required: !__props.group && __props.required,
              error: (_d = (_c = __props.messages) == null ? void 0 : _c.find((item) => item.severity === "error")) == null ? void 0 : _d.message,
              "show-message": false,
              class: vue.normalizeClass({
                "zx-schema-field--own-feedback": !__props.reserveFeedback,
                "is-error": __props.invalid
              })
            }, vue.createSlots({
              default: vue.withCtx(() => {
                var _a2;
                return [
                  vue.createElementVNode("div", _hoisted_4, [
                    vue.renderSlot(_ctx.$slots, "default", { controlProps: controlProps.value })
                  ]),
                  __props.description ? (vue.openBlock(), vue.createElementBlock("small", {
                    key: 0,
                    id: `${id}-help`,
                    class: "zx-schema-field__help"
                  }, vue.toDisplayString(__props.description), 9, _hoisted_5)) : vue.createCommentVNode("", true),
                  ((_a2 = __props.messages) == null ? void 0 : _a2.length) ? (vue.openBlock(), vue.createElementBlock("ul", {
                    key: 1,
                    id: `${id}-messages`,
                    class: "el-form-item__error zx-schema-field__messages",
                    "aria-live": "polite"
                  }, [
                    (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(__props.messages, (item, index) => {
                      return vue.openBlock(), vue.createElementBlock("li", {
                        key: index,
                        "data-severity": item.severity
                      }, vue.toDisplayString(item.message), 9, _hoisted_7);
                    }), 128))
                  ], 8, _hoisted_6)) : vue.createCommentVNode("", true)
                ];
              }),
              _: 2
            }, [
              !__props.group ? {
                name: "label",
                fn: vue.withCtx(() => [
                  vue.createElementVNode("span", {
                    id: `${id}-label`,
                    class: "zx-schema-field__label"
                  }, vue.toDisplayString(__props.label), 9, _hoisted_3)
                ]),
                key: "0"
              } : void 0
            ]), 1032, ["label", "for", "label-position", "label-width", "required", "error", "class"])
          ];
        }),
        _: 3
      }, 16);
    };
  }
});
function parseNumberText(text) {
  const value = text.trim();
  if (!value) return { status: "empty" };
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value))
    return { status: "invalid" };
  const number = Number(value);
  return Number.isFinite(number) ? { status: "valid", value: number } : { status: "invalid" };
}
exports._sfc_main = _sfc_main;
exports.fieldLayoutKey = fieldLayoutKey;
exports.parseNumberText = parseNumberText;
