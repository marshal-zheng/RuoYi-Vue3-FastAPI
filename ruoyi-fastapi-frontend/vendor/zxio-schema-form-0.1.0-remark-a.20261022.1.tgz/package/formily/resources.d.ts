import { FieldIssue } from './types';
import { Field } from '@formily/core';
export type ResourceScope = 'record' | 'edit' | Field;
export type TaskState = 'pending' | 'success' | 'error' | 'cancelled' | 'superseded';
export interface ResourceOptions {
    scope?: ResourceScope;
    blocking?: boolean;
}
/** A lifecycle registry, with no dependency graph and no reaction scheduler. */
export declare function createResources(signal: AbortSignal): {
    version: import('vue').ShallowRef<number, number>;
    runLatest: <I, R>(runtime: object, key: string, captured: I, load: (input: I, signal: AbortSignal) => Promise<R>, commit: (value: R) => void, options?: ResourceOptions, applicable?: () => boolean) => void;
    retry: (key: string, scope?: ResourceScope) => void;
    cancel: (key: string, scope?: ResourceScope, applicable?: boolean) => void;
    bindResource: <V>(runtime: object, source: () => V, project: (value: V) => void, applicable?: () => boolean) => () => void;
    refresh(runtime: object): void;
    prune(runtime: object): void;
    retire: (runtime: object) => void;
    pending: () => boolean;
    requiredPending: () => boolean;
    issues: () => FieldIssue[];
    feedback: () => FieldIssue[];
    dispose: () => void;
    states: () => {
        key: string;
        scope: ResourceScope;
        state: TaskState;
        error: string | undefined;
    }[];
};
export type Resources = ReturnType<typeof createResources>;
