# 公共契约参考

入口分工、安装和示例见[README](../../README.md)。原生类型与会话定义见 [formily/types.ts](../../formily/types.d.ts)，受控控件类型见 [fields/types.ts](../../fields/types.d.ts)。

## ZxField 展示契约

`label/description/required/messages` 定义可访问名称、说明和反馈；`group` 使用 fieldset/legend。`reserveFeedback` 默认 true，复合控件自己布局反馈时关闭外层空占位；`invalid` 用于同步这类控件的错误外观。默认 slot 接收 `controlProps`，绑定到真实控件。展示复用 ElFormItem 与 ZXUI 全局反馈样式，不持有 model、rules 或提交方法。布局与复合反馈归属见 [受控字段](controlled-fields.md#运行与验证)。

## ZxSchemaForm props

| 属性                     | 契约                                                                    |
| ------------------------ | ----------------------------------------------------------------------- |
| initial: T               | 当前记录完整 JSON seed；换记录 key 重挂                                 |
| createSchema(context)    | 原生 ISchema；每个 runtime 创建，reset/authority 重建时重新调用         |
| assertSettled            | 同步只读保存域不变量；有 reactions 时必需，覆盖派生值和提交相关动态状态 |
| validate(values, signal) | 复合与字段通过后的整记录规则，返回 issues                               |
| save(values, signal)     | Promise SaveResult；一次 attempt 最多一次派发                           |
| bindings                 | 公共控件/显式复合登记；替换使旧控件身份失效                             |
| arrayKeys                | 完整数组替换与错误锚定的业务 key                                        |
| columns                  | 1/2/3；纯布局                                                           |
| labelPosition/labelWidth | top/left/right 及宽度；宽度默认 120px                                    |
| disabled                 | 禁用整个入口，不等同权限校验                                            |

## 公开实例与事件

read() 返回隔离响应式 JSON 快照；setValues(Partial<T>) 顶层合并；replaceValues(T, edit/authority) 完整替换；reset() 恢复当前记录最近有效 baseline，无 baseline 时重试 seed。reconcile(T) 接受业务重新读取的完整 authority 并解除未知结果锁，仍须成功稳定。validate() 可无 save 使用，submit() 没有 save 时返回 false。

focus(path?) 定位首个可见错误。ready、dirty、pending、fieldPending、blocked、phase、status、reconciliationRequired 只读。diagnostics slot 提供相同状态。saved(values) 只在成功接受 baseline 后发出；reconcile-required 提示业务执行读取。

## 作者 context

form 是原生 Form 公共视图，values 唯一可写；query 返回原生模型公共视图。只允许编译后的模型，关闭 create\*/effects/graph/native validate/onInput 等旁路。configure 提交不可变的 required/validator/dataSource/componentProps/validationActive 配置；replaceSchema 编译动态 schema；bindResource 桥接 Vue；runLatest/retryLatest/cancelLatest 管理异步。禁止依赖私有 scheduler/Tracker，禁止把只读 read 当依赖跟踪源。

字段 required/display/pattern/validator/options 等状态进入提交票据，ABA 也失效。直接修改配置嵌套引用会诊断阻断；替换 component/decorator 使用 replaceSchema。

## 复合字段契约

bindings 中 `{ component, composite: true, group?: boolean }`。接收 modelValue/disabled/messages 和真实 ARIA，发 update:modelValue 与 edit-state 完整快照。pending 是活动，blocking 是阻断，两者独立。暴露 focus、可选 validate 和 captureEdit/restoreEdit；临时隐藏保留 raw，reset/authority/换记录废弃旧 raw。详见[复合字段](composite-fields.md)。

## 保证边界

受管任务/同步派生/明确断言共同定义 settled；不以延迟时间猜测完成。可信 JS 的数学正确性、服务端权限和网络写入原子性不是库自动证明的内容。未知写入保持锁定等待读取核对，不能重发试探。
