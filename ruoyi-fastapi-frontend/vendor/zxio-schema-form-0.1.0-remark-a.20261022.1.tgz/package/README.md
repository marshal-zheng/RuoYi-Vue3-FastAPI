# @zxio/schema-form

共享受控字段与可选 Formily 编辑会话。一个保存域使用一个原生 Form，values 是唯一可写 canonical；DAG、Dashboard 可只复用字段，继续拥有自己的 draft/history/preview。

| 入口                          | 内容                                                          | 引擎依赖           |
| ----------------------------- | ------------------------------------------------------------- | ------------------ |
| `@zxio/schema-form`           | JSON 类型、copy/equal 等值工具                                | 无                 |
| `@zxio/schema-form/fields`    | ZxField、数字/JSON 文本输入、raw/ARIA 契约                    | 无                 |
| `@zxio/schema-form/formily`   | ZxSchemaForm、原生 Schema/Field/Form 类型、会话与安全定义导入 | 官方 Formily 2.3.7 |
| `@zxio/schema-form/style.css` | 本包样式                                                      | 无                 |

宿主安装 Vue `^3.5.0`、Element Plus `^2.13.0`、`@zxio/zxui ^3.0.0-next.0`，提供 ZXUI 公共主题和样式。仅 `/formily` 消费者显式安装 `@formily/core`、`@formily/vue`、`@formily/reactive`、`@formily/validator`，四包均精确 `2.3.7`。无需全局注册 Element Plus 或安装另一套 Formily UI。包提供 ESM/CJS/声明，所有宿主依赖 external；本包尚未发布 npm。

```vue
<script setup lang="ts">
import { ZxSchemaForm } from '@zxio/schema-form/formily'
import type { Save, SchemaProperties } from '@zxio/schema-form/formily'
import '@zxio/schema-form/style.css'
type RecordValue = { name: string }
const initial: RecordValue = { name: '' }
const properties: SchemaProperties<RecordValue> = {
  name: {
    type: 'string',
    title: '名称',
    required: true,
    'x-component': 'ZxInput',
  },
}
const createSchema = () => ({ type: 'object', properties })
const save: Save<RecordValue> = async (values, signal) => {
  const authoritative = await service.save(values, signal)
  return { ok: true, values: authoritative }
}
</script>
<template>
  <ZxSchemaForm :initial="initial" :create-schema="createSchema" :save="save" />
</template>
```

示例中的 `service` 由业务提供。换记录应更换组件 key；完整回填使用 `replaceValues(value, 'authority')`，结果未知后的确认读取使用 `reconcile(value)`。initial 是当前记录 seed，不是双向 model。

含 function reactions 的保存域必须提供同步只读 `assertSettled(values, states)`，核验所有派生值及提交相关动态状态。它检查不变量，不重跑求解。缺失/异常/thenable/修改只读输入或超出诊断预算都会阻止保存。任意可信 TS 的数学正确性由业务断言和反例测试保障。

已发出写请求后，异常、取消、未知结果或成功回填失败进入待核对状态；编辑/reset 不解锁。业务读取已保存记录后调用 reconcile，避免重复创建。校验和权限仍由服务端执行。

## 作者指南

- [普通 CRUD 与保存生命周期](docs/authoring/crud.md)
- [跨分区联动与异步资源](docs/authoring/form-sections.md)
- [受控字段与已有 owner](docs/authoring/controlled-fields.md)
- [复合字段、上传与 raw](docs/authoring/composite-fields.md)
- [数组身份与错误](docs/authoring/nested-errors.md)
- [安全 JSON v2 profile](docs/authoring/json-import.md)
- [公共契约参考](docs/authoring/reference.md)

构建通过 `scripts/copy-examples.mjs` 复制实际演练的复合 SFC 和文档，校验安装后的相对链接。修改源文件后运行包 build，不手改 dist。
