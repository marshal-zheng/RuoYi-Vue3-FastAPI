type Value = string | number | boolean;
interface Option {
    label: string;
    value: Value;
    disabled?: boolean;
}
type __VLS_Props = {
    modelValue?: Value;
    options?: Option[] | (() => Option[]);
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus(): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: Value | undefined) => void;
    blur: (event: FocusEvent) => void;
    focus: (event: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((event: FocusEvent) => any) | undefined;
    onFocus?: ((event: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: Value | undefined) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    group: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly disabled: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly fill: string;
            readonly id: string;
            readonly type: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "button" | "radio", unknown>;
            readonly props: import('element-plus').radioOptionProp;
            readonly name: string;
            readonly modelValue: import('element-plus/es/utils/index.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor, BooleanConstructor], unknown, unknown>;
            readonly validateEvent: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly textColor: string;
        }> & Omit<{
            readonly fill: string;
            readonly props: import('element-plus').radioOptionProp;
            readonly type: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "button" | "radio", unknown>;
            readonly validateEvent: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly textColor: string;
            readonly name?: string | undefined;
            readonly size?: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never> | undefined;
            readonly id?: string | undefined;
            readonly disabled?: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
            readonly ariaLabel?: string | undefined;
            readonly modelValue?: import('element-plus/es/utils/index.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor, BooleanConstructor], unknown, unknown> | undefined;
            readonly options?: import('element-plus').radioOption[] | undefined;
            "onUpdate:modelValue"?: ((val: string | number | boolean | undefined) => any) | undefined;
            onChange?: ((val: string | number | boolean | undefined) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "name" | "fill" | "props" | "type" | "id" | "disabled" | "modelValue" | "validateEvent" | "textColor">;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "change", val: string | number | boolean | undefined) => void) & ((event: "update:modelValue", val: string | number | boolean | undefined) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
            readonly ariaLabel: StringConstructor;
            readonly id: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            readonly size: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly modelValue: import('element-plus/es/utils/index.mjs').EpPropFinalized<readonly [StringConstructor, NumberConstructor, BooleanConstructor], unknown, unknown, undefined, boolean>;
            readonly fill: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly textColor: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly name: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
            readonly validateEvent: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly options: {
                readonly type: import('vue').PropType<import('element-plus').radioOption[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly props: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').radioOptionProp) | (() => import('element-plus').radioOptionProp) | ((new (...args: any[]) => import('element-plus').radioOptionProp) | (() => import('element-plus').radioOptionProp))[], unknown, unknown, () => Required<import('element-plus').radioOptionProp>, boolean>;
            readonly type: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, "button" | "radio", unknown, "radio", boolean>;
        }>> & {
            "onUpdate:modelValue"?: ((val: string | number | boolean | undefined) => any) | undefined;
            onChange?: ((val: string | number | boolean | undefined) => any) | undefined;
        }, unknown, unknown, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (val: string | number | boolean | undefined) => void;
            change: (val: string | number | boolean | undefined) => void;
        }, string, {
            readonly disabled: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly fill: string;
            readonly id: string;
            readonly type: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "button" | "radio", unknown>;
            readonly props: import('element-plus').radioOptionProp;
            readonly name: string;
            readonly modelValue: import('element-plus/es/utils/index.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor, BooleanConstructor], unknown, unknown>;
            readonly validateEvent: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly textColor: string;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        readonly disabled: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly fill: string;
        readonly id: string;
        readonly type: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "button" | "radio", unknown>;
        readonly props: import('element-plus').radioOptionProp;
        readonly name: string;
        readonly modelValue: import('element-plus/es/utils/index.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor, BooleanConstructor], unknown, unknown>;
        readonly validateEvent: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly textColor: string;
    }> & Omit<Readonly<import('vue').ExtractPropTypes<{
        readonly ariaLabel: StringConstructor;
        readonly id: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly modelValue: import('element-plus/es/utils/index.mjs').EpPropFinalized<readonly [StringConstructor, NumberConstructor, BooleanConstructor], unknown, unknown, undefined, boolean>;
        readonly fill: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly textColor: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly name: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly validateEvent: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly options: {
            readonly type: import('vue').PropType<import('element-plus').radioOption[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly props: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').radioOptionProp) | (() => import('element-plus').radioOptionProp) | ((new (...args: any[]) => import('element-plus').radioOptionProp) | (() => import('element-plus').radioOptionProp))[], unknown, unknown, () => Required<import('element-plus').radioOptionProp>, boolean>;
        readonly type: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, "button" | "radio", unknown, "radio", boolean>;
    }>> & {
        "onUpdate:modelValue"?: ((val: string | number | boolean | undefined) => any) | undefined;
        onChange?: ((val: string | number | boolean | undefined) => any) | undefined;
    }, "name" | "fill" | "props" | "type" | "id" | "disabled" | "modelValue" | "validateEvent" | "textColor"> & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | null;
}, any>;
export default _default;
