"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const numberText = require("../number-text-B1kssOle.js");
const vue = require("vue");
const input = require("@zxio/zxui/input");
const index = require("../index-BupWnDag.js");
const _sfc_main$1 = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxNumberTextInput", inheritAttrs: false },
  __name: "NumberTextInput",
  props: {
    text: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["edit"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const input$1 = vue.shallowRef();
    function setInput(value) {
      input$1.value = value;
    }
    function edit(text) {
      emit("edit", { text, badInput: numberText.parseNumberText(text).status === "invalid" });
    }
    __expose({ focus: () => {
      var _a;
      return (_a = input$1.value) == null ? void 0 : _a.focus();
    } });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(input.ZxInput), vue.mergeProps({ ref: setInput }, _ctx.$attrs, {
        type: "text",
        inputmode: "decimal",
        "model-value": __props.text,
        disabled: __props.disabled,
        readonly: __props.readonly,
        "onUpdate:modelValue": edit
      }), null, 16, ["model-value", "disabled", "readonly"]);
    };
  }
});
function parseJsonText(text) {
  if (!text.trim()) return { status: "empty" };
  try {
    const value = JSON.parse(text);
    index.safeJson(value, "$", false);
    return { status: "valid", value };
  } catch {
    return { status: "invalid" };
  }
}
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxJsonTextInput", inheritAttrs: false },
  __name: "JsonTextInput",
  props: {
    text: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["edit"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const input$1 = vue.shallowRef();
    function setInput(value) {
      input$1.value = value;
    }
    function edit(text) {
      emit("edit", { text, badInput: parseJsonText(text).status === "invalid" });
    }
    __expose({ focus: () => {
      var _a;
      return (_a = input$1.value) == null ? void 0 : _a.focus();
    } });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(input.ZxInput), vue.mergeProps({ ref: setInput }, _ctx.$attrs, {
        type: "textarea",
        "model-value": __props.text,
        disabled: __props.disabled,
        readonly: __props.readonly,
        "onUpdate:modelValue": edit
      }), null, 16, ["model-value", "disabled", "readonly"]);
    };
  }
});
exports.ZxField = numberText._sfc_main;
exports.parseNumberText = numberText.parseNumberText;
exports.ZxJsonTextInput = _sfc_main;
exports.ZxNumberTextInput = _sfc_main$1;
exports.parseJsonText = parseJsonText;
