# @zxio/theme-tailwind

Theme-neutral Tailwind CSS contract artifacts generated only from the validated
ZXIO public token contract and an explicit mapping table.

- `@zxio/theme-tailwind/v4.css` supplies Tailwind 4 `@theme inline` aliases.
- `@zxio/theme-tailwind/preset-v3` supplies the equivalent Tailwind 3 preset.
- `@zxio/theme-tailwind/manifest.json` exposes mapping, tested-version,
  coverage, artifact-hash, and adapter-contract identity.

No resolved theme value or mode selector is encoded here. Both built-in themes
reference the same adapter contract hash.
