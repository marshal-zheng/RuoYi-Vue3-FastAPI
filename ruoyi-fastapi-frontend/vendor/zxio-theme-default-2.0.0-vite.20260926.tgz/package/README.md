# @zxio/theme-default

The canonical default ZXIO Theme v4 source lives in `src/theme.ts`. Published
consumers receive only the deterministic compiler output under `generated/`:

- `theme.css` and scoped per-Variant CSS
- `theme.manifest.json`
- manifest-derived typegen runtime/declarations
- Element Plus aliases and per-Variant resolved CSS
- DTCG 2025.10 token sets and Variant index

Run `pnpm -C packages/theme-default build` only when intentionally refreshing
the generated owner set. Normal tests and checks are repository-readonly.
