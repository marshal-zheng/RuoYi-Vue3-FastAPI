"use strict";
const vue = require("vue");
const elementPlus = require("element-plus");
const datePicker = require("@zxio/zxui/date-picker");
const themeProvider = require("@zxio/zxui/theme-provider");
const index = require("./index-BupWnDag.js");
const upload = require("@zxio/zxui/upload");
const button = require("@zxio/zxui/button");
const hooks = require("@zxio/zxui/hooks");
const fieldLayoutKey = Symbol("schema-field-layout");
const _hoisted_1$2 = ["id"];
const _hoisted_2$1 = {
  key: 0,
  "aria-hidden": "true",
  class: "zx-schema-field__required"
};
const _hoisted_3$1 = ["id"];
const _hoisted_4 = { class: "zx-schema-field__control" };
const _hoisted_5 = ["id"];
const _hoisted_6 = ["id"];
const _hoisted_7 = ["data-severity"];
const _sfc_main$2 = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxField", inheritAttrs: false },
  __name: "Field",
  props: {
    label: {},
    description: {},
    required: { type: Boolean },
    group: { type: Boolean },
    messages: {},
    invalid: { type: Boolean },
    reserveFeedback: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const id = `zx-field-${vue.useId()}`;
    const layout = vue.inject(fieldLayoutKey, void 0);
    const controlProps = vue.computed(() => {
      var _a, _b;
      return {
        id,
        "aria-required": !props.group && props.required || void 0,
        "aria-labelledby": props.label ? `${id}-label` : void 0,
        "aria-invalid": props.invalid || ((_a = props.messages) == null ? void 0 : _a.some((item) => item.severity === "error")) || void 0,
        "aria-describedby": [
          props.description ? `${id}-help` : "",
          ((_b = props.messages) == null ? void 0 : _b.length) ? `${id}-messages` : ""
        ].filter(Boolean).join(" ") || void 0
      };
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(__props.group ? "fieldset" : "div"), vue.mergeProps(_ctx.$attrs, { class: "zx-schema-field" }), {
        default: vue.withCtx(() => {
          var _a, _b, _c, _d;
          return [
            __props.group ? (vue.openBlock(), vue.createElementBlock("legend", {
              key: 0,
              id: `${id}-label`,
              class: "zx-schema-field__label"
            }, [
              vue.createTextVNode(vue.toDisplayString(__props.label), 1),
              __props.required ? (vue.openBlock(), vue.createElementBlock("span", _hoisted_2$1, " *")) : vue.createCommentVNode("", true)
            ], 8, _hoisted_1$2)) : vue.createCommentVNode("", true),
            vue.createVNode(vue.unref(elementPlus.ElFormItem), {
              label: __props.group ? void 0 : __props.label,
              for: __props.group ? void 0 : id,
              "label-position": __props.group ? "top" : ((_a = vue.unref(layout)) == null ? void 0 : _a.labelPosition) ?? "top",
              "label-width": __props.group ? void 0 : (_b = vue.unref(layout)) == null ? void 0 : _b.labelWidth,
              required: !__props.group && __props.required,
              error: (_d = (_c = __props.messages) == null ? void 0 : _c.find((item) => item.severity === "error")) == null ? void 0 : _d.message,
              "show-message": false,
              class: vue.normalizeClass({
                "zx-schema-field--own-feedback": !__props.reserveFeedback,
                "is-error": __props.invalid
              })
            }, vue.createSlots({
              default: vue.withCtx(() => {
                var _a2;
                return [
                  vue.createElementVNode("div", _hoisted_4, [
                    vue.renderSlot(_ctx.$slots, "default", { controlProps: controlProps.value })
                  ]),
                  __props.description ? (vue.openBlock(), vue.createElementBlock("small", {
                    key: 0,
                    id: `${id}-help`,
                    class: "zx-schema-field__help"
                  }, vue.toDisplayString(__props.description), 9, _hoisted_5)) : vue.createCommentVNode("", true),
                  ((_a2 = __props.messages) == null ? void 0 : _a2.length) ? (vue.openBlock(), vue.createElementBlock("ul", {
                    key: 1,
                    id: `${id}-messages`,
                    class: "el-form-item__error zx-schema-field__messages",
                    "aria-live": "polite"
                  }, [
                    (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(__props.messages, (item, index2) => {
                      return vue.openBlock(), vue.createElementBlock("li", {
                        key: index2,
                        "data-severity": item.severity
                      }, vue.toDisplayString(item.message), 9, _hoisted_7);
                    }), 128))
                  ], 8, _hoisted_6)) : vue.createCommentVNode("", true)
                ];
              }),
              _: 2
            }, [
              !__props.group ? {
                name: "label",
                fn: vue.withCtx(() => [
                  vue.createElementVNode("span", {
                    id: `${id}-label`,
                    class: "zx-schema-field__label"
                  }, vue.toDisplayString(__props.label), 9, _hoisted_3$1)
                ]),
                key: "0"
              } : void 0
            ]), 1032, ["label", "for", "label-position", "label-width", "required", "error", "class"])
          ];
        }),
        _: 3
      }, 16);
    };
  }
});
function parseNumberText(text) {
  const value = text.trim();
  if (!value) return { status: "empty" };
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value))
    return { status: "invalid" };
  const number = Number(value);
  return Number.isFinite(number) ? { status: "valid", value: number } : { status: "invalid" };
}
const messages = {
  en: {
    initializing: "Initializing",
    updated: "The form has changed. Please submit again.",
    reconcileRequired: "Reload the server record to verify the save result.",
    structureUpdated: "The form structure has changed.",
    waitingResources: "Waiting for required resources",
    initializationBlocked: "Initialization does not satisfy the submission constraints.",
    loaded: "Loaded",
    authorityCancelled: "New edits cancelled the authoritative update.",
    baselineRestored: "Saved baseline restored",
    baselineFailed: "Baseline initialization failed.",
    reconciled: "Server record verified",
    validating: "Validating",
    checkErrors: "Please check the form errors.",
    valid: "Validation passed",
    saving: "Saving",
    saveRejected: "Save rejected. Correct the errors and try again.",
    savedReconcile: "Saved. Reload the server record to verify the displayed values.",
    saved: "Saved",
    validationFailed: "Validation failed.",
    updatedOrInvalid: "The form has changed or contains errors. Please submit again.",
    conditionalReconcile: "The host must verify the conditional edit result.",
    bindingReplaced: "Field controls have changed.",
    completeInput: "Please complete the input.",
    completeNumber: "Please enter a complete, valid number.",
    completeDate: "Please enter a complete, valid date or time.",
    dateNotAccepted: "The form did not accept the date value.",
    chooseAttachments: "Choose attachments",
    uploadPending: "Uploading. Please wait or cancel.",
    uploadCancelled: "Upload cancelled. Select the file again or remove it.",
    attachmentLimit: "Select at most {limit} attachments. Remove this selection.",
    uploadReadonly: "The field is read only. Select the file again or remove it.",
    attachmentDuplicate: "Duplicate attachment identifier. Remove this selection.",
    attachmentNotAccepted: "The form did not accept the attachment.",
    uploadFailed: "Upload failed. Select the file again or remove it.",
    fileTooLarge: "The file is too large. Select another file or remove it.",
    fileTypeUnsupported: "Unsupported file type. Select another file or remove it.",
    attachments: "Attachments",
    remove: "Remove",
    removeNamed: "Remove {name}",
    cancelUpload: "Cancel upload",
    cancelUploadNamed: "Cancel upload {name}",
    resourceProjectionFailed: "Resource projection failed.",
    resourceReadFailed: "Resource loading failed.",
    resourcePending: "Please wait for required resources.",
    resourceNotReady: "Required resources are not ready. Please retry.",
    definitionInvalid: "The field value does not match the defined type or range.",
    invalid: "This field is invalid",
    required: "The field value is required",
    pattern: "This field is invalid",
    number: "The field value is not a number",
    integer: "The field value is not an integer",
    whitespace: "This field cannot contain only whitespace.",
    len: "The length or number of entries must be {len}",
    min: "The length or number of entries must be at least {min}",
    max: "The length or number of entries must be at most {max}",
    minLength: "The length or number of entries must be at least {minLength}",
    maxLength: "The length or number of entries must be at most {maxLength}",
    minItems: "The length or number of entries must be at least {minItems}",
    maxItems: "The length or number of entries must be at most {maxItems}",
    maximum: "The field value cannot be greater than {maximum}",
    minimum: "The field value cannot be less than {minimum}",
    exclusiveMaximum: "The field value must be less than {exclusiveMaximum}",
    exclusiveMinimum: "The field value must be greater than {exclusiveMinimum}",
    enum: "The field value must be one of {enum}",
    const: "The field value must be equal to {const}",
    multipleOf: "The field value must be divisible by {multipleOf}",
    maxProperties: "The number of field properties cannot exceed {maxProperties}",
    minProperties: "The number of field properties must be at least {minProperties}",
    uniqueItems: "Array elements must be unique",
    url: "The field value is not a valid URL format",
    email: "The field value is not a valid email format",
    ipv6: "The field value is not a valid IPv6 format",
    ipv4: "The field value is not a valid IPv4 format",
    idcard: "The field value is not a valid ID card format",
    qq: "The field value is not a valid QQ number format",
    phone: "The field value is not a valid phone number format",
    money: "The field value is not a valid currency format",
    zh: "The field value is not a valid Chinese text format",
    date: "The field value is not a valid date format",
    zip: "The field value is not a valid postal code format"
  },
  zh: {
    initializing: "初始化中",
    updated: "表单已更新，请重新提交",
    reconcileRequired: "保存结果需重新载入核对",
    structureUpdated: "表单结构已更新",
    waitingResources: "等待必要资源",
    initializationBlocked: "初始化未满足提交约束",
    loaded: "已载入",
    authorityCancelled: "权威回填已因新编辑取消",
    baselineRestored: "已恢复保存基线",
    baselineFailed: "基线初始化失败",
    reconciled: "已核对服务端记录",
    validating: "校验中",
    checkErrors: "请检查表单中的错误",
    valid: "校验通过",
    saving: "保存中",
    saveRejected: "保存被拒绝，请纠正后重试",
    savedReconcile: "已保存，当前显示需重新载入核对",
    saved: "已保存",
    validationFailed: "校验失败",
    updatedOrInvalid: "表单已更新或包含错误，请重新提交",
    conditionalReconcile: "条件编辑结果需 Host 核对",
    bindingReplaced: "字段控件已替换",
    completeInput: "请完成输入",
    completeNumber: "请输入完整、有效的数字",
    completeDate: "请完成有效的日期/时间输入",
    dateNotAccepted: "日期结果未被表单接受",
    chooseAttachments: "选择附件",
    uploadPending: "上传中，请等待或取消",
    uploadCancelled: "上传已取消，请重新选择或移除",
    attachmentLimit: "最多选择 {limit} 个附件，请移除本次选择",
    uploadReadonly: "字段已只读，请重新选择或移除",
    attachmentDuplicate: "附件标识重复，请移除本次选择",
    attachmentNotAccepted: "附件结果未被表单接受",
    uploadFailed: "上传失败，请重新选择或移除",
    fileTooLarge: "文件过大，请重新选择或移除",
    fileTypeUnsupported: "文件类型不支持，请重新选择或移除",
    attachments: "附件",
    remove: "移除",
    removeNamed: "移除 {name}",
    cancelUpload: "取消上传",
    cancelUploadNamed: "取消上传 {name}",
    resourceProjectionFailed: "资源投影失败",
    resourceReadFailed: "资源读取失败",
    resourcePending: "请等待必要资源完成",
    resourceNotReady: "必要资源未就绪，请重试",
    definitionInvalid: "字段值类型或范围不符合定义",
    invalid: "该字段不是一个合法的字段",
    required: "该字段是必填字段",
    pattern: "该字段不是一个合法的字段",
    number: "该字段不是合法的数字",
    integer: "该字段不是合法的整型数字",
    whitespace: "不能为纯空白字符串",
    len: "长度或条目数必须为{len}",
    min: "长度或条目数不能小于{min}",
    max: "长度或条目数不能大于{max}",
    minLength: "长度或条目数不能小于{minLength}",
    maxLength: "长度或条目数不能大于{maxLength}",
    minItems: "长度或条目数不能小于{minItems}",
    maxItems: "长度或条目数不能大于{maxItems}",
    maximum: "数值不能大于{maximum}",
    minimum: "数值不能小于{minimum}",
    exclusiveMaximum: "数值必须小于{exclusiveMaximum}",
    exclusiveMinimum: "数值必须大于{exclusiveMinimum}",
    enum: "字段值必须为{enum}其中一个",
    const: "字段值必须等于{const}",
    multipleOf: "字段值必须能被{multipleOf}整除",
    maxProperties: "字段属性数量不能大于{maxProperties}",
    minProperties: "字段属性数量不能小于{minProperties}",
    uniqueItems: "数组元素不唯一",
    url: "该字段不是有效的网址格式",
    email: "该字段不是有效的邮箱格式",
    ipv6: "该字段不是有效的IPv6格式",
    ipv4: "该字段不是有效的IPv4格式",
    idcard: "该字段不是有效的身份证格式",
    qq: "该字段不是有效的QQ号格式",
    phone: "该字段不是有效的手机号格式",
    money: "该字段不是有效的货币格式",
    zh: "该字段不是有效的中文字符串格式",
    date: "该字段不是有效的日期格式",
    zip: "该字段不是有效的邮编格式"
  }
};
const interpolate = (message, options) => message.replace(/\{(\w+)\}/g, (_, key) => `${(options == null ? void 0 : options[key]) ?? `{${key}}`}`);
const defaultSchemaLocale = {
  t: (key, options) => interpolate(messages.en[key], options),
  source: () => void 0
};
function useSchemaLocale() {
  const { lang, locale, t: translate } = hooks.useLocale();
  const t = (key, options) => {
    const path = `zx.schemaForm.${key}`;
    const translated = translate(path, options);
    if (translated !== path) return translated;
    return interpolate(
      messages[lang.value.toLowerCase().startsWith("zh") ? "zh" : "en"][key],
      options
    );
  };
  return { lang, t, source: () => locale.value };
}
const resolver = Symbol("schema-form-localized-message");
function localizedMessage(value, message) {
  return { ...value, message: message(), [resolver]: message };
}
function resolveMessage(value) {
  const message = value[resolver];
  return message ? { ...value, message: message() } : value;
}
const resolveText = (value) => typeof value === "function" ? value() : value;
const validatorDefaults = /* @__PURE__ */ new WeakMap();
function withValidatorMessage(validator, key) {
  if (key) validatorDefaults.set(validator, key);
  return validator;
}
const validatorMessageKey = (validator) => validator && validatorDefaults.get(validator);
function schemaLocaleKey(value) {
  return Object.hasOwn(messages.en, value) ? value : void 0;
}
function inheritMessageSource(source, target) {
  const message = source[resolver];
  return message ? { ...target, [resolver]: message } : target;
}
function useInputComposition() {
  const pending = vue.shallowRef(/* @__PURE__ */ new Set());
  let active;
  const has = (key = "value") => pending.value.has(key);
  function observe(event, key = "value") {
    const next = new Set(pending.value);
    if (event.type === "compositionstart" || event.type === "input" && event.isComposing === true) {
      active = { key, target: event.target };
      next.add(key);
    } else if (event.type === "compositionend") {
      if ((active == null ? void 0 : active.key) === key && active.target === event.target) {
        active = void 0;
        next.delete(key);
      }
    } else if (event.type === "input" && ((active == null ? void 0 : active.key) !== key || active.target !== event.target)) {
      next.delete(key);
    }
    pending.value = next;
  }
  function acceptChange(key = "value") {
    if ((active == null ? void 0 : active.key) === key || !has(key)) return false;
    const next = new Set(pending.value);
    next.delete(key);
    pending.value = next;
    return true;
  }
  function restore(keys) {
    active = void 0;
    pending.value = new Set(
      Array.isArray(keys) ? keys.filter((key) => typeof key === "string") : []
    );
  }
  function prune(keys) {
    const keep = new Set(keys);
    if (active && !keep.has(active.key)) active = void 0;
    const next = new Set([...pending.value].filter((key) => keep.has(key)));
    if (next.size === pending.value.size) return false;
    pending.value = next;
    return true;
  }
  return {
    blocked: vue.computed(() => pending.value.size > 0),
    keys: vue.computed(() => [...pending.value]),
    has,
    observe,
    acceptChange,
    restore,
    prune
  };
}
const dateDisplayFormat = (type) => type.startsWith("time") ? "HH:mm:ss" : type.startsWith("datetime") ? "YYYY-MM-DD HH:mm:ss" : type.startsWith("month") ? "YYYY-MM" : type.startsWith("year") ? "YYYY" : "YYYY-MM-DD";
const dateIsRange = (type) => type.endsWith("range");
const dateIsMultiple = (type) => ["dates", "months", "years"].includes(type);
function displayDate(value, format, valueFormat, lang) {
  const values = Array.isArray(value) ? value : value == null ? [] : [value];
  return values.map((part) => elementPlus.dayjs(part, valueFormat, lang).format(format));
}
function parseDateText(text, type, format, valueFormat, lang) {
  const range = dateIsRange(type);
  if (text.every((part) => !part.trim()))
    return { valid: true, value: null };
  const parts = dateIsMultiple(type) ? text[0].split(",").map((part) => part.trim()) : [...text];
  if (range && parts.length !== 2 || parts.some((part) => !part))
    return { valid: false };
  const dates = parts.map((part) => elementPlus.dayjs(part, format, lang, true));
  if (dates.some((part) => !part.isValid()) || range && dates[0].isAfter(dates[1]))
    return { valid: false };
  return {
    valid: true,
    value: range || dateIsMultiple(type) ? dates.map((part) => part.format(valueFormat)) : dates[0].format(valueFormat),
    dates
  };
}
const _hoisted_1$1 = ["data-severity"];
const _sfc_main$1 = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "DateInput",
  props: {
    modelValue: { default: null },
    valueFormat: {},
    format: {},
    type: { default: "date" },
    editable: { type: Boolean, default: true },
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    messages: {}
  },
  emits: ["update:modelValue", "edit-state", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { lang, t } = useSchemaLocale();
    const attrs = vue.useAttrs();
    const root = vue.ref();
    const picker = vue.ref();
    const portal = themeProvider.useRequiredThemePortalBinding();
    const target = vue.computed(
      () => {
        var _a;
        return portal.ok ? (_a = portal.value.binding.value) == null ? void 0 : _a.target : void 0;
      }
    );
    const popperOptions = vue.computed(
      () => themeProvider.createThemePopperOptions(
        attrs.popperOptions
      )
    );
    const messageId = `schema-date-${vue.useId()}`;
    const composition = useInputComposition();
    const raw = vue.ref();
    const notAccepted = vue.ref(false);
    const confirming = vue.ref(false);
    const displayFormat = vue.computed(
      () => props.format || dateDisplayFormat(props.type)
    );
    const editable = vue.computed(
      () => props.type !== "week" && !dateIsMultiple(props.type) && props.editable !== false
    );
    const locked = vue.computed(() => props.disabled || props.readonly || !target.value);
    const multiple = vue.computed(
      () => dateIsRange(props.type) || dateIsMultiple(props.type)
    );
    function assertValue(value2) {
      if (value2 != null && !(multiple.value ? Array.isArray(value2) && value2.every((part) => typeof part === "string") : typeof value2 === "string"))
        throw new Error(
          "Date fields require formatted JSON strings, arrays or null"
        );
    }
    const value = vue.computed(() => {
      if (!props.valueFormat || ["x", "X"].includes(props.valueFormat))
        throw new Error("Date fields require an explicit string valueFormat");
      assertValue(props.modelValue);
      return props.modelValue ?? null;
    });
    function parse() {
      const result = parseDateText(
        raw.value ?? [],
        props.type,
        displayFormat.value,
        props.valueFormat,
        lang.value
      );
      if (result.valid && result.dates) {
        const disabledDate = attrs.disabledDate ?? attrs["disabled-date"];
        const disabledHours = attrs.disabledHours ?? attrs["disabled-hours"];
        const disabledMinutes = attrs.disabledMinutes ?? attrs["disabled-minutes"];
        const disabledSeconds = attrs.disabledSeconds ?? attrs["disabled-seconds"];
        if (result.dates.some((date, index2) => {
          const role = index2 ? "end" : "start";
          return (disabledDate == null ? void 0 : disabledDate(date.toDate())) || (disabledHours == null ? void 0 : disabledHours(role).includes(date.hour())) || (disabledMinutes == null ? void 0 : disabledMinutes(date.hour(), role).includes(date.minute())) || (disabledSeconds == null ? void 0 : disabledSeconds(date.hour(), date.minute(), role).includes(
            date.second()
          ));
        }))
          return { valid: false };
      }
      return result;
    }
    const blocking = vue.computed(
      () => raw.value && (composition.blocked.value || !parse().valid || notAccepted.value) ? [
        localizedMessage(
          { severity: "error", message: "" },
          () => t(notAccepted.value ? "dateNotAccepted" : "completeDate")
        )
      ] : []
    );
    const messages2 = vue.computed(
      () => blocking.value.length ? blocking.value : props.messages ?? []
    );
    const describedBy = vue.computed(
      () => [attrs["aria-describedby"], messages2.value.length ? messageId : void 0].filter(Boolean).join(" ") || void 0
    );
    let editSequence = 0;
    let publication = 0;
    let nativeCommit = false;
    function nativeBoundary(event) {
      if ((event == null ? void 0 : event.type) === "change") event.stopPropagation();
      nativeCommit = true;
      vue.nextTick(() => {
        nativeCommit = false;
        reflect();
      });
    }
    function report() {
      emit("edit-state", {
        editSequence,
        pending: confirming.value,
        commitPending: confirming.value,
        blocking: blocking.value
      });
    }
    function textFor(next) {
      const parts = displayDate(
        next,
        displayFormat.value,
        props.valueFormat,
        lang.value
      );
      return dateIsRange(props.type) ? [parts[0] ?? "", parts[1] ?? ""] : [dateIsMultiple(props.type) ? parts.join(", ") : parts[0] ?? ""];
    }
    const display = () => textFor(value.value);
    function reflect() {
      var _a;
      (_a = root.value) == null ? void 0 : _a.querySelectorAll("input").forEach((input, index2) => {
        var _a2;
        for (const name of [
          "id",
          "aria-label",
          "aria-labelledby",
          "aria-describedby",
          "aria-invalid",
          "aria-required"
        ]) {
          const item = name === "id" && index2 ? void 0 : name === "aria-describedby" ? describedBy.value : name === "aria-invalid" ? messages2.value.some((message) => message.severity === "error") || attrs[name] : attrs[name];
          if (item == null || item === false) input.removeAttribute(name);
          else input.setAttribute(name, String(item));
        }
        if (((_a2 = raw.value) == null ? void 0 : _a2[index2]) !== void 0) input.value = raw.value[index2];
      });
    }
    vue.onBeforeUnmount(() => {
      publication++;
    });
    vue.onMounted(reflect);
    vue.onUpdated(() => vue.nextTick(reflect));
    async function publish(next) {
      const current = ++publication;
      confirming.value = true;
      report();
      if (current !== publication || !raw.value) return;
      emit("update:modelValue", next);
      await vue.nextTick();
      if (current !== publication || !raw.value) return;
      confirming.value = false;
      notAccepted.value = !index.equal(value.value, next);
      if (!notAccepted.value) raw.value = void 0;
      report();
      reflect();
    }
    function nativeEdit(event) {
      var _a;
      const input = event.target;
      const inputs = [...((_a = root.value) == null ? void 0 : _a.querySelectorAll("input")) ?? []];
      const index2 = inputs.indexOf(input);
      if (index2 < 0 || !editable.value || locked.value) return;
      event.stopPropagation();
      publication++;
      confirming.value = false;
      raw.value = raw.value ? [...raw.value] : display();
      raw.value[index2] = input.value;
      composition.observe(event, String(index2));
      notAccepted.value = false;
      editSequence++;
      const parsed = parse();
      if (!composition.blocked.value && parsed.valid) publish(parsed.value);
      else report();
    }
    function update(next) {
      if (locked.value || composition.blocked.value) return;
      const normalized = next === "" || next === void 0 || Array.isArray(next) && !next.length ? null : next;
      assertValue(normalized);
      if (raw.value && (!parse().valid || composition.blocked.value) && nativeCommit) {
        vue.nextTick(reflect);
        return;
      }
      raw.value = textFor(normalized);
      notAccepted.value = false;
      editSequence++;
      publish(normalized);
    }
    function clear() {
      if (locked.value) return;
      raw.value = textFor(null);
      composition.restore([]);
      notAccepted.value = false;
      editSequence++;
      publish(null);
    }
    const controlAttrs = vue.computed(
      () => Object.fromEntries(
        Object.entries(attrs).filter(
          ([key]) => key !== "id" && !key.startsWith("aria-")
        )
      )
    );
    function boundary(event, type) {
      var _a;
      if (!((_a = root.value) == null ? void 0 : _a.contains(event.relatedTarget)))
        emit(type, event);
      if (type === "blur") vue.nextTick(reflect);
    }
    vue.watch(
      () => props.modelValue,
      () => {
        if (!raw.value) return;
        const parsed = parse();
        if (parsed.valid && index.equal(parsed.value, props.modelValue)) {
          notAccepted.value = false;
          report();
          return;
        }
        publication++;
        confirming.value = false;
        raw.value = void 0;
        composition.restore([]);
        notAccepted.value = false;
        report();
      }
    );
    vue.watch(
      () => [props.type, props.valueFormat, props.format],
      () => {
        publication++;
        confirming.value = false;
        raw.value = void 0;
        composition.restore([]);
        notAccepted.value = false;
        report();
      }
    );
    vue.watch(lang, () => {
      report();
      vue.nextTick(reflect);
    });
    vue.watch(target, (next) => {
      var _a;
      if (!next) (_a = picker.value) == null ? void 0 : _a.handleClose();
    });
    __expose({
      focus: () => {
        var _a;
        return (_a = picker.value) == null ? void 0 : _a.focus();
      },
      validate: () => {
        report();
        return !confirming.value && !blocking.value.length;
      },
      captureEdit() {
        publication++;
        confirming.value = false;
        const parsed = parse();
        if (raw.value && parsed.valid && !index.equal(parsed.value, value.value))
          notAccepted.value = true;
        report();
        return raw.value ? {
          text: raw.value,
          composition: composition.keys.value,
          notAccepted: notAccepted.value
        } : null;
      },
      restoreEdit(draft) {
        if (!index.record(draft) || !Array.isArray(draft.text) || !draft.text.every((part) => typeof part === "string"))
          return;
        raw.value = [...draft.text];
        composition.restore(draft.composition);
        const parsed = parse();
        notAccepted.value = parsed.valid && !index.equal(parsed.value, value.value);
        report();
        vue.nextTick(reflect);
      }
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: "schema-form__date-field",
        onChangeCapture: nativeBoundary,
        onKeydownCapture: vue.withKeys(nativeBoundary, ["enter"]),
        onFocusoutCapture: nativeBoundary,
        onInputCapture: nativeEdit,
        onCompositionstartCapture: nativeEdit,
        onCompositionendCapture: nativeEdit,
        onFocusin: _cache[0] || (_cache[0] = ($event) => boundary($event, "focus")),
        onFocusout: _cache[1] || (_cache[1] = ($event) => boundary($event, "blur"))
      }, [
        (vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(__props.type.startsWith("time") ? vue.unref(elementPlus.ElTimePicker) : vue.unref(datePicker.ZxDatePicker)), vue.mergeProps({
          ref_key: "picker",
          ref: picker
        }, controlAttrs.value, {
          "model-value": value.value,
          type: __props.type,
          "is-range": __props.type === "timerange",
          "value-format": __props.valueFormat,
          format: displayFormat.value,
          disabled: locked.value,
          readonly: __props.readonly,
          editable: editable.value,
          "validate-event": false,
          "value-on-clear": null,
          "append-to": target.value,
          teleported: true,
          "popper-options": popperOptions.value,
          "onUpdate:modelValue": update,
          onClear: clear
        }), null, 16, ["model-value", "type", "is-range", "value-format", "format", "disabled", "readonly", "editable", "append-to", "popper-options"])),
        vue.createElementVNode("ul", {
          id: messageId,
          class: "el-form-item__error zx-schema-field__messages",
          "aria-live": "polite"
        }, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(messages2.value, (message, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: index2,
              "data-severity": message.severity
            }, vue.toDisplayString(message.message), 9, _hoisted_1$1);
          }), 128))
        ])
      ], 544);
    };
  }
});
function attachment(value) {
  const result = index.copy(value);
  if (!index.record(result) || !(typeof result.id === "string" && result.id.length > 0 || typeof result.id === "number" && Number.isFinite(result.id)) || typeof result.name !== "string" || !result.name || result.url !== void 0 && typeof result.url !== "string" || Object.keys(result).some(
    (key) => !["id", "name", "url", "metadata"].includes(key)
  ))
    throw new Error("Expected a JSON attachment with id and name");
  return result;
}
const _hoisted_1 = ["aria-label"];
const _hoisted_2 = ["aria-busy"];
const _hoisted_3 = ["data-severity"];
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "AttachmentInput",
  props: {
    modelValue: { default: () => [] },
    upload: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    multiple: { type: Boolean, default: true },
    accept: {},
    maxSize: {},
    limit: {},
    buttonText: {},
    messages: {}
  },
  emits: ["update:modelValue", "edit-state", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { t } = useSchemaLocale();
    const attrs = vue.useAttrs();
    const root = vue.ref();
    const uploader = vue.ref();
    const selected = vue.ref([]);
    const transfers = vue.shallowRef([]);
    const committed = vue.shallowRef(props.modelValue.map(attachment));
    const messageId = `schema-attachments-${vue.useId()}`;
    const seen = /* @__PURE__ */ new WeakSet();
    let sequence = 0;
    let key = 0;
    let alive = true;
    let publication = 0;
    const locked = vue.computed(() => props.disabled || props.readonly);
    const blocking = vue.computed(
      () => transfers.value.map(
        (item) => localizedMessage(
          { severity: "error", message: "" },
          () => `${item.name}: ${t(
            item.controller ? "uploadPending" : item.error ?? "uploadCancelled",
            { limit: props.limit ?? 0 }
          )}`
        )
      )
    );
    const visibleMessages = vue.computed(() => [
      ...blocking.value,
      ...props.messages ?? []
    ]);
    const describedBy = vue.computed(
      () => [
        attrs["aria-describedby"],
        visibleMessages.value.length ? messageId : void 0
      ].filter(Boolean).join(" ") || void 0
    );
    function associateTrigger() {
      var _a, _b;
      const trigger = (_b = (_a = root.value) == null ? void 0 : _a.querySelector('input[type="file"]')) == null ? void 0 : _b.parentElement;
      if (trigger) {
        trigger.setAttribute("role", "presentation");
        trigger.setAttribute("tabindex", "-1");
      }
    }
    vue.onMounted(associateTrigger);
    vue.onUpdated(associateTrigger);
    function report() {
      emit("edit-state", {
        editSequence: sequence,
        pending: transfers.value.some((item) => !!item.controller),
        blocking: blocking.value
      });
    }
    function edited() {
      sequence++;
      report();
    }
    function publish(value) {
      const current = ++publication;
      committed.value = value.map(attachment);
      emit("update:modelValue", committed.value.map(attachment));
      vue.nextTick(() => {
        if (alive && publication === current && !index.equal(props.modelValue, committed.value))
          committed.value = props.modelValue.map(attachment);
      });
    }
    function retire(retain) {
      const previous = transfers.value;
      transfers.value = retain ? previous.map((item) => ({
        key: item.key,
        name: item.name,
        error: item.error ?? "uploadCancelled"
      })) : [];
      previous.forEach((item) => {
        var _a;
        return (_a = item.controller) == null ? void 0 : _a.abort();
      });
      report();
    }
    function fail(name, reason) {
      transfers.value = [...transfers.value, { key: ++key, name, error: reason }];
      edited();
    }
    function start(file) {
      if (locked.value || !alive || seen.has(file)) return;
      seen.add(file);
      if (props.limit !== void 0 && committed.value.length + transfers.value.length >= props.limit) {
        fail(file.name, "attachmentLimit");
        return;
      }
      const controller = new AbortController();
      const transfer = { key: ++key, name: file.name, controller };
      transfers.value = [...transfers.value, transfer];
      edited();
      const active = () => alive && transfers.value.includes(transfer) && !controller.signal.aborted;
      Promise.resolve().then(() => {
        if (!active()) return void 0;
        return props.upload(file, { signal: controller.signal });
      }).then(async (result) => {
        if (!active()) return;
        const asset = attachment(result);
        if (locked.value) throw new Error(t("uploadReadonly"));
        if (committed.value.some((item) => item.id === asset.id))
          throw new Error(t("attachmentDuplicate"));
        publish([...committed.value, asset]);
        await vue.nextTick();
        if (!active()) return;
        if (!props.modelValue.some((item) => index.equal(item, asset)))
          throw new Error(t("attachmentNotAccepted"));
        transfers.value = transfers.value.filter((item) => item !== transfer);
        report();
      }).catch(() => {
        if (!active()) return;
        transfers.value = transfers.value.map(
          (item) => item === transfer ? {
            key: item.key,
            name: item.name,
            error: "uploadFailed"
          } : item
        );
        report();
      });
    }
    function select(files) {
      for (const file of files) if (file.raw) start(file.raw);
      vue.nextTick(() => {
        var _a;
        selected.value = [];
        (_a = uploader.value) == null ? void 0 : _a.clearFiles();
      });
    }
    function removeTransfer(item) {
      var _a;
      if (locked.value) return;
      transfers.value = transfers.value.filter((candidate) => candidate !== item);
      (_a = item.controller) == null ? void 0 : _a.abort();
      edited();
    }
    function removeAsset(index2) {
      if (locked.value) return;
      edited();
      publish(committed.value.filter((_, position) => position !== index2));
    }
    vue.watch(
      () => props.modelValue,
      (value) => {
        const next = value.map(attachment);
        if (index.equal(next, committed.value)) return;
        retire(false);
        committed.value = next;
      }
    );
    vue.onBeforeUnmount(() => {
      alive = false;
      retire(false);
    });
    function boundary(event, type) {
      var _a;
      if (!((_a = root.value) == null ? void 0 : _a.contains(event.relatedTarget)))
        emit(type, event);
    }
    __expose({
      focus: () => {
        var _a, _b;
        return (_b = (_a = root.value) == null ? void 0 : _a.querySelector("button")) == null ? void 0 : _b.focus();
      },
      validate: () => {
        report();
        return !blocking.value.length;
      },
      captureEdit() {
        retire(true);
        return transfers.value.map((item) => ({
          name: item.name,
          error: item.error ?? "uploadCancelled"
        }));
      },
      restoreEdit(draft) {
        if (!Array.isArray(draft)) return;
        transfers.value = draft.filter(
          (item) => index.record(item) && typeof item.name === "string" && typeof item.error === "string"
        ).map((item) => ({
          key: ++key,
          name: item.name,
          error: item.error
        }));
        report();
      }
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: vue.normalizeClass([_ctx.$attrs.class, "zx-schema-attachments"]),
        style: vue.normalizeStyle(_ctx.$attrs.style),
        onFocusin: _cache[2] || (_cache[2] = ($event) => boundary($event, "focus")),
        onFocusout: _cache[3] || (_cache[3] = ($event) => boundary($event, "blur"))
      }, [
        vue.createVNode(vue.unref(upload.ZxUpload), {
          ref_key: "uploader",
          ref: uploader,
          modelValue: selected.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
          disabled: locked.value,
          multiple: __props.multiple,
          accept: __props.accept,
          "max-size": __props.maxSize,
          "auto-upload": false,
          "show-file-list": false,
          "show-tip": false,
          "allow-preview": false,
          "allow-download": false,
          "allow-remove": false,
          onChange: select,
          onReject: _cache[1] || (_cache[1] = ({ file, reason }) => !locked.value && fail(
            file.name,
            reason === "size" ? "fileTooLarge" : "fileTypeUnsupported"
          ))
        }, {
          default: vue.withCtx(() => [
            vue.createVNode(vue.unref(button.ZxButton), {
              id: _ctx.$attrs.id,
              "native-type": "button",
              "enable-loading": false,
              disabled: locked.value,
              "aria-label": _ctx.$attrs["aria-label"],
              "aria-labelledby": _ctx.$attrs["aria-labelledby"],
              "aria-required": _ctx.$attrs["aria-required"],
              "aria-describedby": describedBy.value,
              "aria-invalid": visibleMessages.value.some((message) => message.severity === "error") || void 0
            }, {
              default: vue.withCtx(() => [
                vue.createTextVNode(vue.toDisplayString(__props.buttonText ?? vue.unref(t)("chooseAttachments")), 1)
              ]),
              _: 1
            }, 8, ["id", "disabled", "aria-label", "aria-labelledby", "aria-required", "aria-describedby", "aria-invalid"])
          ]),
          _: 1
        }, 8, ["modelValue", "disabled", "multiple", "accept", "max-size"]),
        vue.createElementVNode("ul", {
          class: "zx-schema-attachments__list",
          "aria-label": vue.unref(t)("attachments")
        }, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(committed.value, (asset, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: asset.id
            }, [
              vue.createElementVNode("span", null, vue.toDisplayString(asset.name), 1),
              vue.createVNode(vue.unref(button.ZxButton), {
                "native-type": "button",
                "enable-loading": false,
                disabled: locked.value,
                "aria-label": vue.unref(t)("removeNamed", { name: asset.name }),
                onClick: ($event) => removeAsset(index2)
              }, {
                default: vue.withCtx(() => [
                  vue.createTextVNode(vue.toDisplayString(vue.unref(t)("remove")), 1)
                ]),
                _: 1
              }, 8, ["disabled", "aria-label", "onClick"])
            ]);
          }), 128)),
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(transfers.value, (item) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: `transfer-${item.key}`,
              "aria-busy": !!item.controller
            }, [
              vue.createElementVNode("span", null, vue.toDisplayString(item.name), 1),
              vue.createVNode(vue.unref(button.ZxButton), {
                "native-type": "button",
                "enable-loading": false,
                disabled: locked.value,
                "aria-label": vue.unref(t)(item.controller ? "cancelUploadNamed" : "removeNamed", {
                  name: item.name
                }),
                onClick: ($event) => removeTransfer(item)
              }, {
                default: vue.withCtx(() => [
                  vue.createTextVNode(vue.toDisplayString(vue.unref(t)(item.controller ? "cancelUpload" : "remove")), 1)
                ]),
                _: 2
              }, 1032, ["disabled", "aria-label", "onClick"])
            ], 8, _hoisted_2);
          }), 128))
        ], 8, _hoisted_1),
        vue.createElementVNode("ul", {
          id: messageId,
          class: "el-form-item__error zx-schema-field__messages",
          "aria-live": "polite"
        }, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(visibleMessages.value, (message, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: index2,
              "data-severity": message.severity
            }, vue.toDisplayString(message.message), 9, _hoisted_3);
          }), 128))
        ])
      ], 38);
    };
  }
});
exports._sfc_main = _sfc_main$2;
exports._sfc_main$1 = _sfc_main$1;
exports._sfc_main$2 = _sfc_main;
exports.defaultSchemaLocale = defaultSchemaLocale;
exports.fieldLayoutKey = fieldLayoutKey;
exports.inheritMessageSource = inheritMessageSource;
exports.localizedMessage = localizedMessage;
exports.parseNumberText = parseNumberText;
exports.resolveMessage = resolveMessage;
exports.resolveText = resolveText;
exports.schemaLocaleKey = schemaLocaleKey;
exports.useInputComposition = useInputComposition;
exports.useSchemaLocale = useSchemaLocale;
exports.validatorMessageKey = validatorMessageKey;
exports.withValidatorMessage = withValidatorMessage;
