import type { ChoiceOption } from './choice-control';
type CheckboxValue = string | number;
type __VLS_Props = {
    modelValue?: CheckboxValue[] | null;
    options?: readonly (Omit<ChoiceOption, 'value'> & {
        value: CheckboxValue;
    })[];
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: CheckboxValue[]) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: CheckboxValue[]) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
