import type { CascaderProps, CascaderValue } from 'element-plus';
import type { ChoiceNode } from './choice-control';
type __VLS_Props = {
    modelValue?: CascaderValue | null;
    options?: readonly ChoiceNode[];
    props?: CascaderProps;
    disabled?: boolean;
    readonly?: boolean;
};
type __VLS_Slots = Record<string, (scope: Record<string, unknown>) => unknown>;
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: CascaderValue | null) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: CascaderValue | null) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
