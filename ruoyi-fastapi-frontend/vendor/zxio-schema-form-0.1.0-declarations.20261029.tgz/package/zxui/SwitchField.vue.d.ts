import type { ChoiceValue } from './choice-control';
type __VLS_Props = {
    modelValue?: ChoiceValue | null;
    activeValue?: ChoiceValue;
    inactiveValue?: ChoiceValue;
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: ChoiceValue) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: ChoiceValue) => any) | undefined;
}>, {
    activeValue: ChoiceValue;
    inactiveValue: ChoiceValue;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
