import type { ChoiceNode, ChoiceValue } from './choice-control';
type __VLS_Props = {
    modelValue?: ChoiceValue | ChoiceValue[] | null;
    data?: readonly ChoiceNode[];
    cacheData?: readonly ChoiceNode[];
    nodeKey?: string;
    valueKey?: string;
    props?: Record<string, unknown>;
    disabled?: boolean;
    readonly?: boolean;
    multiple?: boolean;
};
type __VLS_Slots = Record<string, (scope: Record<string, unknown>) => unknown>;
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: ChoiceValue | ChoiceValue[] | null) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: ChoiceValue | ChoiceValue[] | null) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
