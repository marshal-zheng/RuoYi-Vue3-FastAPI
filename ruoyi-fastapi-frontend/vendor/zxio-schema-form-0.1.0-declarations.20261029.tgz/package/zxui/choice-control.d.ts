import type { Ref } from 'vue';
export type ChoiceValue = string | number | boolean;
export interface ChoiceOption {
    value: ChoiceValue;
    label: string;
    disabled?: boolean;
}
export type ChoiceNode = Record<string, unknown>;
type NativeControl = {
    $el?: HTMLElement;
};
/** EP tree widgets may attach node metadata. Never give them runtime config. */
export declare function useChoiceData<T>(source: () => readonly T[] | undefined): import("vue").ComputedRef<T[]>;
export declare function rejectChoiceOwners(component: string, values: object, names: readonly string[]): void;
/** Native checkbox/switch attrs land on wrappers, not their actual inputs. */
export declare function useChoiceControl(root: Ref<NativeControl | undefined>, attrs: Record<string, unknown>, group?: boolean): {
    forwarded: () => {
        [k: string]: unknown;
    };
    focus(): void;
    interaction(event: FocusEvent): boolean;
};
export {};
