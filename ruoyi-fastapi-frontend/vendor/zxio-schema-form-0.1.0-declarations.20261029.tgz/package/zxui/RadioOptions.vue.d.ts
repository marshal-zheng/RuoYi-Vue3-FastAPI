type Value = string | number | boolean;
interface Option {
    label: string;
    value: Value;
    disabled?: boolean;
}
type __VLS_Props = {
    modelValue?: Value;
    options?: Option[] | (() => Option[]);
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus(): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: Value | undefined) => void;
    blur: (event: FocusEvent) => void;
    focus: (event: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((event: FocusEvent) => any) | undefined;
    onFocus?: ((event: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: Value | undefined) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
