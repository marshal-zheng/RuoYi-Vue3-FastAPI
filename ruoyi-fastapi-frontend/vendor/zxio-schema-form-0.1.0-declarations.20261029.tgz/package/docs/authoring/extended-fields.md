# 选择、日期与附件字段

这些字段由 `@zxio/schema-form/formily` 的默认 bindings 提供。继续使用同一个 Form 和公开会话，不另建值同步层。宿主提供 ZXUI ThemeHost；日期、树和级联浮层使用其 portal。

## 选择字段

`ZxTreeSelect` 接收标准 `value/label/children` 节点，`dataSource` 映射到 `data`；自定义业务键通过控件的 `nodeKey/valueKey` 明确配置。`ZxCascader` 的 `dataSource` 映射到 `options`，默认输出路径数组。`ZxCheckboxGroup` 同样使用 `options` 映射，输出选中值数组。`ZxCheckbox/ZxSwitch` 默认 boolean，也支持明确的 JSON 值映射。

静态 `x-component-props.data/options` 只作为 dataSource seed。异步字典由 `runLatest` 加载，在受管 commit 中调用 `configure(field, { dataSource })`。不支持控件私有 `remote/lazy/load/beforeChange/beforeFilter` 异步路径，避免产生会话无法追踪的待提交状态。

只读通过字段 `pattern: 'readOnly'` 或明确的 `componentProps.readonly` 表达。只读和 disabled 都拒绝控件反向写入；只读不是服务端权限校验。

### 图标选择

`ZxIconSelect` 复用公开图标选择器，保存图标名称字符串，清空输出 `''`；缺省值或 `null` 只投影为空触发器，不在挂载时改写 canonical。支持 input 与 icon 两种 `triggerMode`，字段 label、反馈 ARIA 和焦点指向实际输入或按钮。切换只读/禁用会关闭面板，并拒绝迟到选择结果。

```ts
{
  type: 'string',
  title: '菜单图标',
  'x-component': 'ZxIconSelect',
  'x-component-props': { clearable: true },
}
```

可信 TS 作者可配置公开控件的 `sources/customIcons/categories`、面板模式和 recent 策略；动态选项不映射为 `dataSource`。默认 JSON profile 只开放 `clearable/disabled/placeholder/aria-label`，自定义存储、函数分类与图标源配置仍归宿主代码。

## 日期

```ts
{
  type: 'string',
  title: '计划日期',
  'x-component': 'ZxDatePicker',
  'x-component-props': {
    type: 'date',
    valueFormat: 'YYYY-MM-DD',
    clearable: true,
  },
}
```

`valueFormat` 必须明确且非空，不能使用 `x`/`X` 数字时间戳格式。单选保存字符串，复选或范围保存字符串数组，清空保存 `null`。支持 `date/dates/daterange/month/months/monthrange/year/years/yearrange/week/datetime/datetimerange/time/timerange`。`time/timerange` 复用 Element Plus TimePicker，浮层仍使用公开 ZXUI ThemeHost portal。

普通单值与范围默认允许自由文本，可用 `editable: false` 选择只通过面板输入。`week` 与 `dates/months/years` 保持成熟控件自身的日历选择模式。自由文本按 `format` 严格解析（默认日期 `YYYY-MM-DD`、日期时间 `YYYY-MM-DD HH:mm:ss`、时间 `HH:mm:ss`），按 `valueFormat` 输出；例如 `2026-02-31`、单端未填范围、逆序范围或禁用时刻不会被宽松纠正后提交。

字段独占 raw 文本与 IME 草稿，普通文本编辑经过 Day.js 严格解析，日历/时间面板继续由成熟控件处理。原生控件失焦清空私有草稿不影响字段保留值；错误、尚未结束的 IME 或宿主拒绝接纳的值阻断所有保存入口。等待受控宿主接纳期间报告 `pending/commitPending`；接纳完成只结束该活动，同一 canonical 的异步校验继续有效。隐藏时保留 JSON 草稿，不恢复活跃 DOM composition；reset/authority 退役旧草稿和校验票据。`disabledDate/disabledHours/disabledMinutes/disabledSeconds` 同样约束文本输入，范围回调收到 `start/end` 角色。库不会把这些选项当成服务端权限。

```ts
{
  type: 'array',
  title: '执行时段',
  'x-component': 'ZxDatePicker',
  'x-component-props': {
    type: 'datetimerange',
    format: 'YYYY-MM-DD HH:mm:ss',
    valueFormat: 'YYYY-MM-DD HH:mm:ss',
  },
}
```

## 附件

```ts
{
  type: 'array',
  title: '附件',
  'x-component': 'ZxUpload',
  'x-component-props': {
    upload: async (file: File, { signal }: { signal: AbortSignal }) => {
      const asset = await assetService.upload(file, { signal })
      return { id: asset.id, name: asset.name, url: asset.url }
    },
    accept: '.pdf,.png,.txt',
    maxSize: 5 * 1024 * 1024,
  },
}
```

`assetService` 由业务提供，包含地址、鉴权、DTO、存储和后端取消策略。成功结果的基础结构是 `{ id: string | number, name: string, url?: string, metadata?: Json }`；示例只依赖此结构。`File`、请求句柄、进度和错误对象不能进入 canonical。

`FieldAttachment` 与 `FieldUpload` 从 `@zxio/schema-form/fields` 导入。上传 callback 只允许可信 TypeScript 配置；`ZxUpload` 不在默认 JSON 定义白名单中，外部定义不能指定传输地址或可执行函数。

上传中和保留失败文件时，字段报告 blocking，所有保存入口都必须经过会话。失败不会隐式重试；用户移除后可重新选择。取消会退役当前请求，迟到成功不能写回字段。隐藏取消活动并保留可丢弃的文件名，reset/authority/换记录清除临时草稿；已有成功附件仍由记录值所有。

业务保存和文件上传是两次独立操作。移除记录中的附件不等于删除远端文件；远端孤立文件回收或删除接口由业务决定。AbortSignal 仅表达客户端取消意图，不能证明服务端回滚。

## 验证

文档站的 `schema-form/choices-and-date` 与 `schema-form/attachment-lifecycle` 示例使用这些默认绑定及内存模拟服务。自动回归检查条件必填、只读、保存基线以及上传失败恢复；真实服务接入还需验证后端字段映射、权限、取消和权威读取。

本轮浏览器验收延期。后续在现有文档站检查日期/树/级联浮层、键盘焦点、文件选择，以及 Light/Dark 和主题预设；不将 DOM 模拟结果称为浏览器通过。
