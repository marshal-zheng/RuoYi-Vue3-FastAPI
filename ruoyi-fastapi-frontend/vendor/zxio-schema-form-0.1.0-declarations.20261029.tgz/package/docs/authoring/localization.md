# Locale 与消息归属

Schema Form 通过 ZXUI 已有的 ConfigProvider locale 读取语言。`name` 以 `zh` 开头时使用内置中文，其他语言使用内置英文；未提供 locale 时遵循 ZXUI 的英文缺省。字段控件的日历、时间和上传 UI 继续消费各自现有的语言能力。

```vue
<script setup lang="ts">
import { ref } from 'vue'
import { ZxConfigProvider } from '@zxio/zxui/config-provider'
import { ZxSchemaForm } from '@zxio/schema-form/formily'

const locale = ref({
  name: 'zh-cn',
  zx: {
    schemaForm: {
      required: '请填写此项',
      chooseAttachments: '添加凭证',
      uploadPending: '凭证上传中，请等待或取消',
    },
  },
})
// initial、createSchema 和 save 由当前业务提供。
</script>

<template>
  <ZxConfigProvider :locale="locale">
    <ZxSchemaForm
      :initial="initial"
      :create-schema="createSchema"
      :save="save"
    />
  </ZxConfigProvider>
</template>
```

`zx.schemaForm.<key>` 存在时优先使用业务覆盖，缺少的 key 使用当前语言的内置文案。带变量的消息使用 `{name}`、`{limit}` 等普通占位符。`ZxSchemaForm` 没有独立语言 prop，也不修改 Formily 的全局 locale；两个 Provider 下的表单可以同时使用不同语言。替换 Provider 的 locale 后，已有状态、内置校验反馈、未完成日期/数字/文本输入和上传失败反馈按新语言呈现，编辑值与保存基线不变，不为翻译重新运行业务 validator。

常用覆盖 key：

| 用途         | Key                                                                                                                                            |
| ------------ | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| 会话状态     | `initializing`、`loaded`、`validating`、`valid`、`saving`、`saved`、`checkErrors`、`saveRejected`、`reconcileRequired`                         |
| 规则默认消息 | `required`、`invalid`、`pattern`、`number`、`integer`、`email`、`url`、`minLength`、`maxLength`、`minimum`、`maximum` 等原生规则名             |
| raw 输入     | `completeInput`、`completeNumber`、`completeDate`、`dateNotAccepted`                                                                           |
| 上传         | `chooseAttachments`、`uploadPending`、`uploadCancelled`、`uploadFailed`、`attachmentLimit`（`{limit}`）、`fileTooLarge`、`fileTypeUnsupported` |
| 附件操作     | `attachments`、`remove`、`removeNamed`（`{name}`）、`cancelUpload`、`cancelUploadNamed`（`{name}`）                                            |
| 必要资源     | `resourcePending`、`resourceNotReady`、`resourceReadFailed`、`resourceProjectionFailed`                                                        |

翻译只拥有库提供的默认消息。显式 `x-validator.message`、自定义 validator 返回的字符串/警告、业务 `assertSettled` 与联合校验问题、服务端返回的 `FieldIssue.message` 和 `Error.message` 均保留原样；业务负责其语言与展示内容。即使业务文案恰好与库的默认文案完全相同，也不会按字面重新翻译。`buttonText` 等显式作者文案同样保留。自定义 validator 返回 `false` 且没有显式 message 时，使用库的当前语言缺省校验消息。

库内部 session/resource 的 locale port 用于组合与单测，不是公共作者入口。业务通过公开 ConfigProvider 配置，不导入包内 `src/locale`、运行时内部模块或 Formily 全局 `setValidateLanguage`。单独使用 `/fields` 的组件也继承同一个 Provider。
