# 公共契约参考

入口分工、安装和示例见[README](../../README.md)。原生类型与会话定义见 [formily/types.ts](../../formily/types.d.ts)，受控控件类型见 [fields/types.ts](../../fields/types.d.ts)。

## ZxField 展示契约

`label/description/required/messages` 定义可访问名称、说明和反馈；`group` 使用 fieldset/legend。`reserveFeedback` 默认 true，复合控件自己布局反馈时关闭外层空占位；`invalid` 用于同步这类控件的错误外观。默认 slot 接收 `controlProps`，绑定到真实控件。展示复用 ElFormItem 与 ZXUI 全局反馈样式，不持有 model、rules 或提交方法。布局与复合反馈归属见 [受控字段](controlled-fields.md#运行与验证)。

## ZxSchemaForm props

| 属性                     | 契约                                                                       |
| ------------------------ | -------------------------------------------------------------------------- |
| initial: T               | 当前记录完整 JSON seed；换记录 key 重挂                                    |
| createSchema(context)    | 原生 ISchema；每个 runtime 创建，reset/authority 重建时重新调用            |
| assertSettled            | 同步只读保存域不变量；有 reactions 时必需，覆盖派生值和提交相关动态状态    |
| validate(values, signal) | 复合与字段通过后的整记录规则，返回 issues；仅 error 阻断，空数组清除旧反馈 |
| save(values, signal)     | Promise SaveResult；一次 attempt 最多一次派发                              |
| bindings                 | 公共控件/显式复合登记；替换使旧控件身份失效                                |
| arrayKeys                | 完整数组替换与错误锚定的业务 key                                           |
| columns                  | 1/2/3；纯布局                                                              |
| labelPosition/labelWidth | top/left/right 及宽度；宽度默认 120px                                      |
| disabled                 | 禁用整个入口，不等同权限校验                                               |

## 公开实例与事件

read() 返回隔离响应式 JSON 快照；setValues(Partial<T>) 顶层合并；replaceValues(T, edit/authority) 完整替换；reset() 恢复当前记录最近有效 baseline，无 baseline 时重试 seed。reconcile(T) 接受业务重新读取的完整 authority 并解除未知结果锁，仍须成功稳定。validate() 可无 save 使用，submit() 没有 save 时返回 false。

focus(path?) 定位首个可见错误。ready、dirty、hasUncommittedInput、pending、fieldPending、blocked、phase、status、reconciliationRequired 只读。diagnostics slot 提供相同状态。dirty 只比较 canonical 与保存基线；hasUncommittedInput 聚合控件 blocking 与 commitPending，包括隐藏和 validationActive=false 时保留的未完成输入；fieldPending 表示活动，不能代替前两者。saved(values) 只在成功接受 baseline 后发出；reconcile-required 提示业务执行读取。

## 作者 context

form 是原生 Form 公共视图，values 唯一可写；query 返回原生模型公共视图。只允许编译后的模型，关闭 create\*/effects/graph/native validate/onInput 等旁路。configure 提交不可变的 required/validator/dataSource/componentProps/validationActive 配置；replaceSchema 编译动态 schema；bindResource 桥接 Vue；runLatest/retryLatest/cancelLatest 管理异步。禁止依赖私有 scheduler/Tracker，禁止把只读 read 当依赖跟踪源。

字段 required/display/pattern/validator/options 等状态进入提交票据，ABA 也失效。直接修改配置嵌套引用会诊断阻断；替换 component/decorator 使用 replaceSchema。

字段引用属于其创建时的模型身份。删除、重建或会话退休后，旧字段及其相对 query 的访问会抛出过期引用错误，不能借相同地址写入新字段；该错误不会锁死当前会话。隐藏和保留身份的数组移动不属于退休。异步工作使用 runLatest 的字段 scope 管理生命周期，需要访问新模型时从当前 context 重新 query。

内置选择器以 dataSource 为唯一选项状态。静态 schema 的 x-component-props.options 在创建时作为 dataSource seed；动态字典通过 configure(field, { dataSource: options }) 更新，assertSettled 只需核验 dataSource，不再维护 componentProps.options 的副本。

自定义 binding 可声明 `dataSourceProp: 'options'` 将 dataSource 映射到控件属性。只有声明映射的控件才归一对应属性；未声明的自定义组件继续自行拥有其 options。configure 同时提供 dataSource 和映射属性时以 dataSource 为准。

映射的属性必须是数组，不能再传异步加载函数。远程选项通过 `runLatest` 加载，在受管 commit 中 configure dataSource；加载中、失败和重试仍作为普通 componentProps 传给组件。可参考 [inspection/definition.ts](../../examples/inspection/definition.ts) 的搜索、取消和重试实现。

## 复合字段契约

bindings 中 `{ component, composite: true, group?: boolean }`。接收 modelValue/disabled/messages 和真实 ARIA，发 update:modelValue 与 edit-state 完整快照。pending 是活动；blocking 是未完成或错误；commitPending 是等待受控值被接纳。后二者阻止提交，接纳活动的结束不改变原始 editSequence 或同一值的校验票据。暴露 focus、可选 validate(context: FieldValidationContext) 和 captureEdit/restoreEdit；临时隐藏保留 raw，reset/authority/换记录废弃旧 raw。详见[复合字段](composite-fields.md)。

## 保证边界

受管任务/同步派生/明确断言共同定义 settled；不以延迟时间猜测完成。可信 JS 的数学正确性、服务端权限和网络写入原子性不是库自动证明的内容。未知写入保持锁定等待读取核对，不能重发试探。

## 条件编辑

见[条件编辑契约](conditional-edit.md)：公开六方法、Host 同步策略安装、整域版本、raw 编辑序号、受控数组与写入事实/异步核验。带 raw 的 binding 必须声明 `editObservation: 'raw-sequence'` 并先同步上报 `editSequence`，再发 canonical；没有 raw 的控件才可声明 `canonical`。不支持观测的控件保留人工能力，但不能条件写。

条件编辑还要求 composite binding 声明 `validationOwnership: 'managed'`；异步反馈经 context.commit 提交，参见[受管控件核验](conditional-edit.md#受管控件核验)。

`/fields` 的 `useInputComposition` 共享未确认草稿 key 与当前 DOM 会话的区分；公开使用与隐藏恢复规则见[复合字段](composite-fields.md#保留输入法草稿并允许人工接管)。

## 可选 AI 上下文

在宿主提供 `@zxio/zxui/ai-context` 的 scope 后，原生值字段可声明
`'x-ai-context': { itemId: 'postName' }`。它只引用同一静态定义，不能覆盖 label、sensitivity、kind 或权限；secret 与 never 策略下的 personal 值不读取。

引擎同步维护绑定和整表单修订号，使值、可用性和结构变化令在途捕获/候选失效；宿主仍负责记录/重载实例 key 和外部资源失效。领域格式化用同一 scope 的脚本 getter，避免重复登记同一 item。未配置 AI 不影响表单。完整策略与编辑器接线见 ZXUI 文档站的「AI 字段上下文」指南，仓库源文件为 `docs/zh-CN/component/ai-context.md`。
