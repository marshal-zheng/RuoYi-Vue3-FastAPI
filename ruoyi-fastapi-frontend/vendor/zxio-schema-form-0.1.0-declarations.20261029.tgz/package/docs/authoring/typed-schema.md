# 嵌套 Schema 与路径类型

`SchemaProperties<T>` 递归约束对象的 `properties`、数组的 `items` 和各层的 `default`。`x-reactions` 的字段参数沿用 Formily 原生 Field API，其中 `value`、`inputValue` 和 `setValue` 使用当前字段的领域类型。根值通过 `BusinessContext<T>.form.values` 读取，仍由原生 observable 收集依赖。

```ts
import type {
  BusinessContext,
  FieldIssue,
  SchemaProperties,
  Validate,
} from '@zxio/schema-form/formily'

type Order = {
  customer: { name: string }
  rows: { sku: string; quantity: number }[]
}

function createSchema(context: BusinessContext<Order>) {
  const properties: SchemaProperties<Order> = {
    customer: {
      type: 'object',
      properties: { name: { type: 'string', 'x-component': 'ZxInput' } },
    },
    rows: {
      type: 'array',
      'x-component': 'ZxArray',
      items: {
        type: 'object',
        properties: {
          sku: { type: 'string', 'x-component': 'ZxInput' },
          quantity: {
            type: 'number',
            default: 1,
            'x-component': 'ZxInputNumber',
            'x-reactions': (field) => {
              field.disabled = context.form.values.customer.name === ''
              // field.value is number; setValue('1') is a compile error.
            },
          },
        },
      },
    },
  }
  return { type: 'object', properties }
}

const validate: Validate<Order> = (values) => {
  const issues: FieldIssue<Order>[] = []
  values.rows.forEach((row, index) => {
    if (row.quantity <= 0)
      issues.push({
        path: ['rows', index, 'quantity'],
        message: '数量须大于零',
      })
  })
  return issues
}
```

含 reaction 的保存域仍必须提供完整 `assertSettled`。上例只说明类型和嵌套结构，提交断言应核验禁用状态与实际领域规则。

`FieldPath<T>`、`FieldIssue<T>`、`SaveResult<T>`、`Validate<T>`、`SettledCheck<T>` 与 `SchemaFormInstance<T>.focus` 共用数据路径类型：对象键、数组数字索引及可空/可选嵌套对象均可表达；例如 `['rows', 0, 'quantity']`。它们不接受布局节点 address，也不把 `'0'` 当数字数组索引。省略 issue.path 仍表示表单摘要错误。

路径推导最多八段，避免递归数据模型造成编译器无限展开。动态字典和不带泛型的 `FieldPath` / `FieldIssue` 保留动态路径；服务端未知错误需由业务校验并映射到真实领域路径，不能通过强制断言把不可信路径变为合法字段。

这是可信 TypeScript 作者辅助，不改变运行时 JSON 校验或安全 JSON profile。任意 void 分区、动态 schema、原生 array 专有操作仍可明确使用 `NativeSchema` / 原生字段类型；不要为动态结构伪造静态键，也不要把 TypeScript 类型当作服务端授权。

实现使用 TypeScript 官方的[映射类型](https://www.typescriptlang.org/docs/handbook/2/mapped-types.html)和[条件类型](https://www.typescriptlang.org/docs/handbook/2/conditional-types.html)，没有引入路径解析依赖或另一套表单模型。
