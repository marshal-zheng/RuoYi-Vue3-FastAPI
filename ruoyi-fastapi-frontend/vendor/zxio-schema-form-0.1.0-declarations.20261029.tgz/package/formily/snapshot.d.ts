type Path = readonly (string | number)[];
/**
 * Shared JSON snapshot of the live values, rebuilt only along the paths that
 * changed since the last read. Untouched subtrees keep their identity, so
 * equality checks and baselines short-circuit on references instead of
 * re-walking the whole record. Like the original runtime read, live values are
 * JSON-normalized before validation: optional undefined members disappear,
 * array gaps become null, and toJSON values retain their serialized form.
 *
 * The snapshot is never frozen: authored code receives it through the
 * `immutable` proxy, which cannot wrap frozen targets, and public reads copy.
 * Internal consumers only read it.
 */
export declare function createSnapshot<T extends object>(live: () => object): {
    touch: (path?: Path) => void;
    get: () => T;
    /** Fresh mutable deep copy for public callers. */
    copy: () => T;
    invalidate(): void;
};
export type ValuesSnapshot<T extends object> = ReturnType<typeof createSnapshot<T>>;
export {};
