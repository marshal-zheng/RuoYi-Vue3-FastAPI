import type { CompositeBinding } from '../types';
/**
 * Numeric schema fields retain editable text and expose the composite contract.
 * The declared result keeps adapter component types out of the public surface.
 */
export declare function createZxuiBindings(): Record<string, CompositeBinding>;
export declare function createZxuiDefinitionPolicy(): import("./types").DefinitionPolicy;
