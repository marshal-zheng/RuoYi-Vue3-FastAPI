import type { Component } from 'vue';
import type { Bindings } from '../types';
import type { FormRuntime } from './runtime';
/** Owns exactly one canonical write. Native SchemaField callbacks are consumed. */
export declare function createBindings(runtime: FormRuntime, bindings: Bindings, disabled?: () => boolean): Record<string, Component>;
