import type { ArrayField, Field } from '@formily/core';
import type { FormRuntime } from './runtime';
export declare function parseAIContextReference(value: unknown): {
    itemId: string;
} | undefined;
/** Observe the form engine clock; do not eagerly read context field values. */
export declare function useFormilyAIContext(runtime: FormRuntime): (reference: unknown, field: () => Field | ArrayField) => () => void;
