import type { ConditionalEditApi, ConditionalEditPolicy } from './conditional-types';
import type { Field, FieldDataSource, FieldValidator, Form } from '@formily/core';
import type { ISchema } from '@formily/vue';
import type { FieldPath } from '../fields/types';
import type { Json, Values } from '../types';
import type { ResourceOptions, ResourceScope } from './resources';
export type * from './conditional-types';
export type { FieldPath } from '../fields/types';
export type { ISchema as NativeSchema } from '@formily/vue';
export type { Field, Form, ArrayField, VoidField } from '@formily/core';
type ReadonlyJson = null | boolean | number | string | readonly ReadonlyJson[] | {
    readonly [key: string]: ReadonlyJson;
};
export type DeepReadonly<T> = [Json] extends [T] ? ReadonlyJson : T extends (...args: never[]) => unknown ? T : T extends object ? {
    readonly [K in keyof T]: DeepReadonly<T[K]>;
} : T;
type UntypedFieldIssue = {
    path?: FieldPath;
    message: string;
    severity?: 'error' | 'warning' | 'info';
};
export type FieldIssue<T = unknown> = unknown extends T ? UntypedFieldIssue : Omit<UntypedFieldIssue, 'path'> & {
    path?: FieldPath<T>;
};
export interface FieldConfiguration {
    required?: boolean;
    validator?: FieldValidator;
    dataSource?: FieldDataSource;
    componentProps?: Record<string, unknown>;
    validationActive?: boolean;
}
export interface FieldStateSnapshot {
    path: FieldPath;
    address: string;
    required: boolean;
    display: string;
    pattern: string;
    validator: FieldValidator;
    dataSource: FieldDataSource;
    componentProps: Record<string, unknown>;
    validationActive: boolean;
}
export type SettledCheck<T extends object = Values> = (values: DeepReadonly<T>, states: readonly FieldStateSnapshot[]) => readonly FieldIssue<T>[];
export interface ArrayKey {
    path: FieldPath;
    key: string;
}
export type SaveResult<T extends object = Values> = {
    ok: true;
    values?: T;
} | {
    ok: false;
    issues: readonly FieldIssue<T>[];
    outcome?: 'rejected' | 'unknown';
};
export type Save<T extends object = Values> = (values: T, signal: AbortSignal) => Promise<SaveResult<T>>;
export type Validate<T extends object = Values> = (values: T, signal: AbortSignal) => readonly FieldIssue<T>[] | Promise<readonly FieldIssue<T>[]>;
export type FormPhase = 'initializing' | 'idle' | 'validating' | 'saving' | 'blocked' | 'invalid' | 'saved' | 'error' | 'uncertain';
export interface BusinessContext<T extends object = Values> {
    form: Omit<Form, 'values' | 'initialValues'> & {
        values: T;
        initialValues: T;
    };
    read(): T;
    signal(): AbortSignal;
    configure(field: Field, patch: FieldConfiguration): void;
    replaceSchema(schema: ISchema): void;
    bindResource<V>(source: () => V, project: (value: V) => void, options?: {
        scope?: ResourceScope;
    }): () => void;
    runLatest<I, R>(key: string, input: I, load: (input: I, signal: AbortSignal) => Promise<R>, commit: (value: R) => void, options?: ResourceOptions): void;
    retryLatest(key: string, scope?: ResourceScope): void;
    cancelLatest(key: string, scope?: ResourceScope, applicable?: boolean): void;
}
/** Native Formily field API, with the current data value kept concrete. */
export type SchemaReaction<T> = (field: Field<unknown, unknown, unknown, T>) => unknown;
export type SchemaNode<T> = Omit<ISchema, 'default' | 'properties' | 'items' | 'x-reactions'> & {
    default?: T;
    'x-reactions'?: SchemaReaction<T> | SchemaReaction<T>[];
} & (NonNullable<T> extends readonly (infer Item)[] ? {
    items?: SchemaNode<Item> | SchemaNode<Item>[];
    properties?: never;
} : NonNullable<T> extends object ? {
    properties?: SchemaProperties<NonNullable<T>>;
    items?: never;
} : {
    properties?: never;
    items?: never;
});
export type SchemaProperties<T extends object> = {
    [K in keyof T]?: SchemaNode<T[K]>;
};
export interface SchemaFormInstance<T extends object = Values> extends ConditionalEditApi {
    setConditionalEditPolicy(next: ConditionalEditPolicy | undefined): void;
    read(): T;
    setValues(values: Partial<T>): boolean;
    replaceValues(values: T, mode: 'edit' | 'authority'): Promise<boolean>;
    reconcile(values: T): Promise<boolean>;
    validate(): Promise<boolean>;
    reset(): void;
    submit(): Promise<boolean>;
    focus(path?: FieldPath<T>): void;
    readonly ready: boolean;
    readonly dirty: boolean;
    /** Retained unfinished input, including hidden or validation-inactive fields. */
    readonly hasUncommittedInput: boolean;
    readonly pending: boolean;
    readonly fieldPending: boolean;
    readonly blocked: boolean;
    readonly reconciliationRequired: boolean;
    readonly phase: FormPhase;
    readonly status: string;
}
export interface Definition {
    id: string;
    revision: number;
    engine: 'formily@2.3.7';
    contract: 'zxui-schema-form-v2';
    schema: Omit<ISchema, 'properties'> & {
        properties?: Record<string, ISchema>;
    };
}
export type DefinitionPolicy = Record<string, {
    props: readonly string[];
    validators?: Record<string, (value: Json) => boolean>;
}>;
