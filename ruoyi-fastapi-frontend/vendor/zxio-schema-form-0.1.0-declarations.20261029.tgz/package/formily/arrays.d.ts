import type { ArrayField, Field, Form, GeneralField } from '@formily/core';
import type { ArrayKey } from './types';
/** Public ArrayField operations and keys, without a second array/value owner. */
export declare function createArrays(ports: {
    form: Form;
    keys: readonly ArrayKey[];
    assertCurrent(field: GeneralField): void;
    transaction<R>(work: () => R): R;
    validate(field: Field): Promise<boolean>;
}): {
    install: (field: Field) => void;
    renderKeys: (field: ArrayField) => string[];
    prune(): void;
    alignValues: (next: object) => void;
    align: (field: ArrayField, next: unknown[]) => void;
    operation(field: GeneralField, key: PropertyKey): ((...args: unknown[]) => unknown) | undefined;
};
