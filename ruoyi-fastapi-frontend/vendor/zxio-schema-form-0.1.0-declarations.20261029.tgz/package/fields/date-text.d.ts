import { dayjs } from 'element-plus';
export type DateFieldType = 'date' | 'dates' | 'daterange' | 'datetime' | 'datetimerange' | 'month' | 'months' | 'monthrange' | 'year' | 'years' | 'yearrange' | 'week' | 'time' | 'timerange';
export type DateFieldValue = string | string[] | null;
export declare const dateDisplayFormat: (type: DateFieldType) => "HH:mm:ss" | "YYYY-MM-DD HH:mm:ss" | "YYYY-MM" | "YYYY" | "YYYY-MM-DD";
export declare const dateIsRange: (type: DateFieldType) => boolean;
export declare const dateIsMultiple: (type: DateFieldType) => boolean;
export declare function displayDate(value: DateFieldValue, format: string, valueFormat: string, lang: string): string[];
export declare function parseDateText(text: readonly string[], type: DateFieldType, format: string, valueFormat: string, lang: string): {
    valid: true;
    value: null;
    dates?: undefined;
} | {
    valid: false;
    value?: undefined;
    dates?: undefined;
} | {
    valid: true;
    value: string | string[];
    dates: dayjs.Dayjs[];
};
