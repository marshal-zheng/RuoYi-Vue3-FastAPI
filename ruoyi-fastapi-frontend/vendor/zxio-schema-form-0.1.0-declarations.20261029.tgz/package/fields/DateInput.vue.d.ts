import type { DateFieldType, DateFieldValue } from './date-text';
import type { FieldEditState, FieldMessage } from './types';
import type { Json } from '../types';
type __VLS_Props = {
    modelValue?: DateFieldValue;
    valueFormat: string;
    format?: string;
    type?: DateFieldType;
    editable?: boolean;
    disabled?: boolean;
    readonly?: boolean;
    messages?: readonly FieldMessage[];
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit(): Json;
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: DateFieldValue) => void;
    "edit-state": (state: FieldEditState) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: DateFieldValue) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    type: DateFieldType;
    modelValue: DateFieldValue;
    editable: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
