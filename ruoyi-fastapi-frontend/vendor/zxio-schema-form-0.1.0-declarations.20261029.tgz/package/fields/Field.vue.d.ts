import type { FieldControlAttrs, FieldMessage } from './types';
type __VLS_Props = {
    label: string;
    description?: string;
    required?: boolean;
    /** Use a fieldset/legend for an object, repeated rows or another composite. */
    group?: boolean;
    messages?: readonly FieldMessage[];
    /** Composite-owned raw feedback still drives the shared error appearance. */
    invalid?: boolean;
    /** A composite that renders its own feedback reserves space there instead. */
    reserveFeedback?: boolean;
};
type __VLS_Slots = {
    default(props: {
        controlProps: FieldControlAttrs;
    }): unknown;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {
    reserveFeedback: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
