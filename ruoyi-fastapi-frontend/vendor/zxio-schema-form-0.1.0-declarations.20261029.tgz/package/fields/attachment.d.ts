import type { Json } from '../types';
/** Durable asset identity. Upload transport and server deletion belong to the host. */
export type FieldAttachment = {
    id: string | number;
    name: string;
    url?: string;
    metadata?: Json;
};
export type FieldUpload = (file: File, context: {
    signal: AbortSignal;
}) => Promise<FieldAttachment>;
/** Reject File/Response/Date and malformed results before they enter canonical values. */
export declare function attachment(value: unknown): FieldAttachment;
