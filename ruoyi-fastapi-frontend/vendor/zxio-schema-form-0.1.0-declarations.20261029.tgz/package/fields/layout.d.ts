import type { ComputedRef, InjectionKey } from 'vue';
/** Presentation inheritance only; it carries no model or validation owner. */
export declare const fieldLayoutKey: InjectionKey<ComputedRef<{
    labelPosition: 'left' | 'right' | 'top';
    labelWidth?: string | number;
}>>;
