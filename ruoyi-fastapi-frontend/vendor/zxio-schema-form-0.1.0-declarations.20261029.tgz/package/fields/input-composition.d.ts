import type { Json } from '../types';
/** Retain unfinished input keys, never an active IME session across DOM mounts. */
export declare function useInputComposition(): {
    blocked: import("vue").ComputedRef<boolean>;
    keys: import("vue").ComputedRef<string[]>;
    has: (key?: string) => boolean;
    observe: (event: Event, key?: string) => void;
    acceptChange: (key?: string) => boolean;
    restore: (keys: Json | undefined) => void;
    prune: (keys: readonly string[]) => boolean;
};
