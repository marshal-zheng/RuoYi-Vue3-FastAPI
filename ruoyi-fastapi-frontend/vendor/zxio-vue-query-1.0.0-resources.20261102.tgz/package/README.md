# @zxio/vue-query

Optional resources and Vue bindings over the application's native TanStack QueryClient. Install Vue and `@tanstack/vue-query` (verified with 5.92.5); install `VueQueryPlugin` once. There is no HTTP runtime, UI runtime, second result cache, global business store or automatic resource registration.

- Root / `core`: existing `invalidateQueryGroups` for native Query composition.
- `resources`: `defineRead`, `defineCommand`, `defineResource`, `createDataClient`, `provideDataClient`, `useDataClient`, `useResourceQuery` and typed receipts.
- `ui`: `useResourceView`, `useResourceSelect`, `useResourceList`, `useResourceDetail`, `useResourceCommand`, and the existing `useQuerySelect`.

```ts
import {
  createDataClient,
  defineResource,
  defineRead,
  defineCommand,
  provideDataClient,
} from '@zxio/vue-query/resources'

const data = createDataClient({ queryClient })
provideDataClient(data, app)
data.replaceScope({ key: 'opaque-domain' })
const assets = defineResource({
  name: 'assets',
  reads: {
    detail: defineRead({
      normalize: (id: number) => ({ id }),
      run: (input, { signal }) => api.detail(input.id, signal),
    }),
  },
  commands: (self) => ({
    rename: defineCommand({
      run: renameWithConfirmedOutcome,
      effects: () => [self.all()],
    }),
  }),
})
const result = await data.read(assets, 'detail', 1, { mode: 'fresh', signal })
const receipt = await data.execute(assets, 'rename', { id: 1, name: 'Updated' })
```

Definitions are inert and can be dynamically imported. Names must be unique within a DataClient; one active DataClient owns the resource namespace of a QueryClient. Create both clients per SSR request. Scope keys must contain no credentials. Every replacement increments generation, synchronously hides old results, then cancels/removes only the previous resource prefix. Dispose releases this namespace, never the host QueryClient.

Inputs are normalized, detached and recursively frozen as finite JSON. Object undefined properties are omitted; a no-argument `undefined` input becomes null. Arrays containing undefined, nonfinite numbers, cycles, Date/class objects, functions and BigInt are rejected. Normalize dates to strings. Commands can provide an explicit `snapshot` for non-JSON payloads; the caller owns its detached-copy semantics.

Default reads use `staleTime: 0`, `gcTime: 300000`, `retry: false`; configure shared defaults on DataClient or override per read. Native focus/reconnect policy remains inherited. `fresh` waits for the required fetch, including when stale success data already exists. `cached` explicitly permits stale data. Read results distinguish loaded (cache/network), not-started, failed, paused, cancelled and obsolete. Imperative reads hold native observers until settlement. A local abort releases only that waiter; other observers retain their request. `active` and KeepAlive release UI subscriptions and timers; reactivation uses native freshness and GC.

`data.options(resource, name, input)` is the native Query escape hatch. Its query function still checks scope and enabled before/after execution. Native consumers are responsible for their own observation/presentation UX. Do not override the key or query function in official bindings.

Commands return explicit `succeeded/data`, `rejected/error`, or `unknown/error`. Unclassified exceptions after dispatch mean unknown, never a safe retry. Confirmation captures the input/domain first and rechecks them before sending. There is no automatic write retry. `useResourceCommand` locks one UI instance immediately, including confirmation; independent instances remain independent.

A receipt separates write `kind`, result `applicable`, and `refresh`. Confirmed success remains success even after a scope switch. Effects default to `self.all()`; explicit effects can use `self.read(name)`, `self.read(name, input)` or another resource's handle. The union is cancelled, invalidated and active queries are refreshed once. Refresh always resolves to refreshed/invalidated/paused/failed/obsolete, including effects exceptions. Retry a failed read, never repeat an already confirmed write to repair refresh. HTTP facades can use `commandRequest(signal)` to disable transport retries and duplicate notices, independently of `queryRequest`.

`useResourceView` exposes immediate busy/fetching, disabled/pending/ready/empty/error/paused phases, delayed loading/refreshing (150ms by default), and a separate refreshError. Cached content survives refresh failures. `isEmpty` is domain-defined; timers reset on identity/activation and dispose on unmount. Retry is a read-only action.

`useResourceSelect` takes an option projection, optionKey and optional domain-owned selectedOptions (including by-id label reads). It never writes modelValue or infers invalidity from partial options. `useQuerySelect` continues to accept native Query options and preserve its established immediate native loading behavior; both use the shared select-state projection.

`useResourceList` owns submitted/displayed metadata only for controlled TableRender. Bind its atomic `state` and full `onQueryIntent`; TableRender retains filter drafts, selection and expansion. `project` returns rows, pagination and final logicalInput, including server-corrected page/size. Failed new inputs keep previous rows with previous displayed identity; switching scope clears them synchronously. Request-mode GridList remains its own owner.

`useResourceDetail` requires an explicit snapshot and returns a detached draft plus `isCurrent`. Give that draft to the existing form session. Background refresh never reinitializes it. Check `isCurrent` and receipt.applicable before mapping save outcomes to SchemaForm SaveResult. A close or new open releases only this editor's wait.

See the [Chinese guide and cross-component workbench](../../docs/zh-CN/guide/vue-query.md) and [English native guide](../../docs/en-US/guide/vue-query.md).
