import { provide, inject, shallowRef, computed, toValue, watch, effectScope, onScopeDispose, getCurrentInstance, onDeactivated, onActivated } from "vue";
import { useQuery } from "@tanstack/vue-query";
function snapshotInput(input) {
  const ancestors = /* @__PURE__ */ new Set();
  const visit = (value, root = false) => {
    if (value === void 0 && root) return null;
    if (value === null || typeof value === "string" || typeof value === "boolean")
      return value;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || value === null)
      throw new TypeError("Resource input must be finite JSON.");
    if (ancestors.has(value))
      throw new TypeError("Resource input must not be cyclic.");
    if (!Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new TypeError("Normalize non-JSON resource input before execution.");
    }
    ancestors.add(value);
    const result = Array.isArray(value) ? Array.from(value, (entry) => visit(entry)) : Object.fromEntries(
      Object.entries(value).filter(([, entry]) => entry !== void 0).map(([key, entry]) => [key, visit(entry)])
    );
    ancestors.delete(value);
    return Object.freeze(result);
  };
  return visit(input, true);
}
const dataClientKey = Symbol("zx-data-client");
function provideDataClient(client, app) {
  if (app) app.provide(dataClientKey, client);
  else provide(dataClientKey, client);
}
function useDataClient() {
  const client = inject(dataClientKey, null);
  if (!client)
    throw new Error("Provide the host DataClient before using resources.");
  return client;
}
function useResourceQuery(resource, name, input, config = {}) {
  const client = config.client ?? useDataClient();
  const activated = shallowRef(true);
  const active = computed(
    () => activated.value && toValue(config.active ?? true)
  );
  const prepared = computed(() => {
    try {
      return {
        value: client.prepare(resource, name, toValue(input)),
        error: null
      };
    } catch (error) {
      return { value: null, error };
    }
  });
  const enabled = computed(
    () => {
      var _a;
      return active.value && !!((_a = prepared.value.value) == null ? void 0 : _a.options.enabled);
    }
  );
  const native = shallowRef(null);
  let subscription;
  watch(
    () => {
      var _a, _b;
      return [(_b = (_a = prepared.value.value) == null ? void 0 : _a.identity) == null ? void 0 : _b.hash, enabled.value];
    },
    () => {
      subscription == null ? void 0 : subscription.stop();
      native.value = null;
      if (!enabled.value || !prepared.value.value) return;
      subscription = effectScope();
      native.value = subscription.run(
        () => useQuery(
          prepared.value.value.options,
          client.queryClient
        )
      );
    },
    { immediate: true, flush: "sync" }
  );
  onScopeDispose(() => subscription == null ? void 0 : subscription.stop());
  if (getCurrentInstance()) {
    onDeactivated(() => {
      activated.value = false;
    });
    onActivated(() => {
      activated.value = true;
    });
  }
  const refresh = async () => {
    var _a;
    if (!enabled.value) return;
    await ((_a = native.value) == null ? void 0 : _a.refetch({ cancelRefetch: false }));
  };
  return {
    client,
    enabled,
    identity: computed(
      () => {
        var _a;
        return enabled.value ? ((_a = prepared.value.value) == null ? void 0 : _a.identity) ?? null : null;
      }
    ),
    data: computed(
      () => {
        var _a;
        return enabled.value ? (_a = native.value) == null ? void 0 : _a.data.value : void 0;
      }
    ),
    error: computed(
      () => {
        var _a;
        return prepared.value.error ?? ((_a = native.value) == null ? void 0 : _a.error.value) ?? null;
      }
    ),
    fetching: computed(() => {
      var _a;
      return enabled.value && !!((_a = native.value) == null ? void 0 : _a.isFetching.value);
    }),
    paused: computed(
      () => {
        var _a;
        return enabled.value && ((_a = native.value) == null ? void 0 : _a.fetchStatus.value) === "paused";
      }
    ),
    updatedAt: computed(
      () => {
        var _a;
        return enabled.value ? ((_a = native.value) == null ? void 0 : _a.dataUpdatedAt.value) ?? 0 : 0;
      }
    ),
    refresh,
    ensureFresh: async () => {
      if (enabled.value) await client.read(resource, name, toValue(input));
    }
  };
}
export {
  useResourceQuery as a,
  provideDataClient as p,
  snapshotInput as s,
  useDataClient as u
};
