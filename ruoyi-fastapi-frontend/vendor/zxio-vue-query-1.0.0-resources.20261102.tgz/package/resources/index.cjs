"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const vue$1 = require("vue");
const vueQuery = require("@tanstack/vue-query");
const vue = require("../vue-ug1nTj6g.js");
const invalidation = require("../invalidation-D3eHn6Ib.js");
function defineRead(definition) {
  return Object.freeze({ ...definition });
}
function defineCommand(definition) {
  return Object.freeze({ ...definition });
}
function defineResource(definition) {
  var _a;
  if (!definition.name.trim())
    throw new Error("A resource needs a stable name.");
  const self = {
    all: () => ({ resource, exact: false }),
    read(name, ...args) {
      if (!(name in definition.reads)) throw new Error(`Unknown read: ${name}`);
      return { resource, read: name, input: args[0], exact: args.length > 0 };
    }
  };
  const resource = {
    name: definition.name,
    reads: Object.freeze({ ...definition.reads }),
    commands: Object.freeze(((_a = definition.commands) == null ? void 0 : _a.call(definition, self)) ?? {}),
    ...self
  };
  return Object.freeze(resource);
}
function isResourceKey(key) {
  return key[0] === "zx-resource";
}
const namespaces = /* @__PURE__ */ new WeakMap();
class ResourceUnavailableError extends Error {
  constructor(reason) {
    super(`Resource operation not started: ${reason}`);
    this.reason = reason;
    this.name = "ResourceUnavailableError";
  }
}
function createDataClient(config) {
  const queryClient = config.queryClient;
  const namespace = namespaces.get(queryClient) ?? {
    active: false,
    generation: 0
  };
  if (namespace.active)
    throw new Error("This QueryClient already has an active DataClient.");
  namespace.active = true;
  namespaces.set(queryClient, namespace);
  const scope = vue$1.shallowRef(null);
  const definitions = /* @__PURE__ */ new Map();
  const listeners = /* @__PURE__ */ new Set();
  let disposed = false;
  let activeScope = null;
  const current = (captured) => !disposed && captured !== null && activeScope === captured;
  const register = (resource) => {
    const existing = definitions.get(resource.name);
    if (existing && existing !== resource)
      throw new Error(`Duplicate resource definition: ${resource.name}`);
    definitions.set(resource.name, resource);
  };
  const onScopeChange = (listener) => {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  };
  const replaceScope = (next) => {
    if (disposed) throw new Error("DataClient is disposed.");
    const previous = scope.value;
    activeScope = null;
    for (const listener of [...listeners]) listener();
    activeScope = next ? Object.freeze({ key: next.key, generation: ++namespace.generation }) : null;
    scope.value = activeScope;
    if (previous) {
      const filter = {
        queryKey: ["zx-resource", previous.key, previous.generation]
      };
      queryClient.cancelQueries(filter);
      queryClient.removeQueries(filter);
    }
  };
  function prepare(resource, name, input) {
    register(resource);
    const read2 = resource.reads[name];
    if (!read2) throw new Error(`Unknown resource read: ${name}`);
    const normalized = vue.snapshotInput(
      read2.normalize ? read2.normalize(input) : input
    );
    const captured = scope.value;
    const key = [
      "zx-resource",
      (captured == null ? void 0 : captured.key) ?? "",
      (captured == null ? void 0 : captured.generation) ?? -1,
      resource.name,
      name,
      normalized
    ];
    const allowed = () => current(captured) && (!read2.enabled || read2.enabled(normalized, captured));
    const identity = captured ? Object.freeze({ scope: captured, key, hash: vueQuery.hashKey(key) }) : null;
    const options2 = {
      staleTime: 0,
      gcTime: 3e5,
      retry: false,
      ...config.defaults,
      ...read2.staleTime === void 0 ? {} : { staleTime: read2.staleTime },
      ...read2.gcTime === void 0 ? {} : { gcTime: read2.gcTime },
      ...read2.retry === void 0 ? {} : { retry: read2.retry },
      queryKey: key,
      enabled: allowed(),
      queryFn: async ({
        signal
      }) => {
        if (!current(captured)) throw new ResourceUnavailableError("scope");
        if (!allowed()) throw new ResourceUnavailableError("disabled");
        const result = await read2.run(normalized, {
          scope: captured,
          signal,
          isCurrent: () => current(captured)
        });
        if (!current(captured)) throw new ResourceUnavailableError("scope");
        if (!allowed()) throw new ResourceUnavailableError("disabled");
        return result;
      }
    };
    return { options: options2, identity, allowed, captured };
  }
  function options(resource, name, input) {
    return prepare(resource, name, input).options;
  }
  async function read(resource, name, input, readConfig = {}) {
    var _a;
    if ((_a = readConfig.signal) == null ? void 0 : _a.aborted) return { kind: "cancelled" };
    let prepared;
    try {
      prepared = prepare(resource, name, input);
    } catch (error) {
      return { kind: "failed", error };
    }
    if (!prepared.captured || !current(prepared.captured))
      return { kind: "not-started", reason: "scope" };
    if (!prepared.allowed()) return { kind: "not-started", reason: "disabled" };
    const { identity, options: queryOptions } = prepared;
    const cached = queryClient.getQueryCache().find({ queryKey: queryOptions.queryKey, exact: true });
    if ((cached == null ? void 0 : cached.state.data) !== void 0 && (readConfig.mode === "cached" || !cached.isStaleByTime(queryOptions.staleTime))) {
      return {
        kind: "loaded",
        data: cached.state.data,
        identity,
        source: "cache"
      };
    }
    return new Promise((resolve) => {
      var _a2;
      const observer = new vueQuery.QueryObserver(
        queryClient,
        queryOptions
      );
      const before = observer.getCurrentQuery().state.dataUpdateCount;
      let settled = false;
      let started = false;
      let unsubscribe = () => {
      };
      let unsubscribeScope = () => {
      };
      const finish = (result) => {
        var _a3;
        if (settled) return;
        settled = true;
        unsubscribe();
        observer.destroy();
        unsubscribeScope();
        (_a3 = readConfig.signal) == null ? void 0 : _a3.removeEventListener("abort", cancel);
        resolve(result);
      };
      const cancel = () => finish({ kind: "cancelled" });
      const inspect = () => {
        if (!current(prepared.captured)) return finish({ kind: "obsolete" });
        const result = observer.getCurrentResult();
        const state = observer.getCurrentQuery().state;
        if (result.fetchStatus === "paused") return finish({ kind: "paused" });
        if (result.fetchStatus === "fetching") {
          started = true;
          return;
        }
        if (result.isError)
          return finish({ kind: "failed", error: result.error });
        if (state.dataUpdateCount > before && result.isSuccess) {
          return finish({
            kind: "loaded",
            data: result.data,
            identity,
            source: "network"
          });
        }
        if (started) finish({ kind: "cancelled" });
      };
      unsubscribeScope = onScopeChange(() => finish({ kind: "obsolete" }));
      (_a2 = readConfig.signal) == null ? void 0 : _a2.addEventListener("abort", cancel, { once: true });
      unsubscribe = observer.subscribe(inspect);
      if (settled) unsubscribe();
      else {
        observer.refetch({ cancelRefetch: false }).catch((error) => finish({ kind: "failed", error }));
        inspect();
      }
    });
  }
  async function refreshEffects(captured, effects) {
    try {
      if (!current(captured)) return { kind: "obsolete" };
      const filters = effects().map((effect) => {
        register(effect.resource);
        const prefix = [
          "zx-resource",
          captured.key,
          captured.generation,
          effect.resource.name
        ];
        if (effect.read === void 0) return { queryKey: prefix };
        if (!effect.exact) return { queryKey: [...prefix, effect.read] };
        return {
          queryKey: prepare(effect.resource, effect.read, effect.input).options.queryKey,
          exact: true
        };
      });
      if (!current(captured)) return { kind: "obsolete" };
      const result = await invalidation.invalidateQueryGroupsReport(queryClient, filters);
      return current(captured) ? result : { kind: "obsolete" };
    } catch (error) {
      return { kind: "failed", error };
    }
  }
  async function execute(resource, name, input, executeConfig = {}) {
    var _a, _b, _c, _d;
    register(resource);
    const captured = scope.value;
    const command = resource.commands[name];
    if (!command) throw new Error(`Unknown resource command: ${name}`);
    const base = () => ({
      scope: captured,
      applicable: current(captured),
      refresh: Promise.resolve({ kind: "invalidated" })
    });
    if (!current(captured))
      return { ...base(), kind: "not-started", reason: "scope" };
    let snapshot;
    try {
      snapshot = command.snapshot ? command.snapshot(input) : vue.snapshotInput(input);
    } catch (error) {
      return { ...base(), kind: "not-started", reason: "invalid-input", error };
    }
    const allowed = () => !command.enabled || command.enabled(snapshot, captured);
    try {
      if (!allowed())
        return { ...base(), kind: "not-started", reason: "disabled" };
      if ((_a = executeConfig.signal) == null ? void 0 : _a.aborted)
        return { ...base(), kind: "not-started", reason: "cancelled" };
      if (executeConfig.beforeExecute && !await executeConfig.beforeExecute(snapshot, captured))
        return { ...base(), kind: "not-started", reason: "confirmation" };
      if (!current(captured))
        return { ...base(), kind: "not-started", reason: "scope" };
      if (!allowed())
        return { ...base(), kind: "not-started", reason: "disabled" };
      if ((_b = executeConfig.signal) == null ? void 0 : _b.aborted)
        return { ...base(), kind: "not-started", reason: "cancelled" };
    } catch (error) {
      return { ...base(), kind: "not-started", reason: "confirmation", error };
    }
    const controller = new AbortController();
    const abort = () => controller.abort();
    const offScope = onScopeChange(abort);
    (_c = executeConfig.signal) == null ? void 0 : _c.addEventListener("abort", abort, { once: true });
    try {
      const outcome = await command.run(snapshot, {
        scope: captured,
        signal: controller.signal,
        isCurrent: () => current(captured)
      });
      if (outcome.kind === "succeeded") {
        return {
          ...base(),
          ...outcome,
          refresh: refreshEffects(
            captured,
            () => command.effects ? command.effects({ data: outcome.data, input: snapshot }) : [resource.all()]
          )
        };
      }
      return { ...base(), ...outcome };
    } catch (error) {
      return { ...base(), kind: "unknown", error };
    } finally {
      offScope();
      (_d = executeConfig.signal) == null ? void 0 : _d.removeEventListener("abort", abort);
    }
  }
  return {
    queryClient,
    scope: vue$1.readonly(scope),
    presentationDelay: config.presentationDelay ?? 150,
    options,
    prepare,
    read,
    execute,
    replaceScope,
    isCurrent: current,
    onScopeChange,
    dispose() {
      if (disposed) return;
      replaceScope(null);
      disposed = true;
      listeners.clear();
      definitions.clear();
      namespace.active = false;
    }
  };
}
exports.provideDataClient = vue.provideDataClient;
exports.useDataClient = vue.useDataClient;
exports.useResourceQuery = vue.useResourceQuery;
exports.ResourceUnavailableError = ResourceUnavailableError;
exports.createDataClient = createDataClient;
exports.defineCommand = defineCommand;
exports.defineRead = defineRead;
exports.defineResource = defineResource;
exports.isResourceKey = isResourceKey;
