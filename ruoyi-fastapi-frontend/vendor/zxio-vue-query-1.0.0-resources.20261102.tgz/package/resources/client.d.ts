import { QueryClient } from '@tanstack/vue-query';
import { CommandData, CommandError, CommandInput, CommandMap, DataScope, ReadData, ReadInput, ReadMap, ReadPolicy, Resource } from './definition';
import { CommandReceipt, ExecuteConfig, ReadConfig, ReadIdentity, ReadResult, ResourceKey } from './types';
export declare class ResourceUnavailableError extends Error {
    readonly reason: 'scope' | 'disabled';
    constructor(reason: 'scope' | 'disabled');
}
export interface DataClientConfig {
    queryClient: QueryClient;
    defaults?: ReadPolicy;
    presentationDelay?: number;
}
export declare function createDataClient(config: DataClientConfig): {
    queryClient: QueryClient;
    scope: Readonly<import('vue').Ref<{
        readonly key: string;
        readonly generation: number;
    } | null, {
        readonly key: string;
        readonly generation: number;
    } | null>>;
    presentationDelay: number;
    options: <R extends ReadMap, C extends CommandMap, K extends keyof R & string>(resource: Resource<R, C>, name: K, input: ReadInput<R[K]>) => {
        queryKey: ResourceKey;
        enabled: boolean;
        queryFn: ({ signal, }: {
            signal: AbortSignal;
        }) => Promise<ReadData<R[K]>>;
        retry: false | number;
        gcTime: number;
        staleTime: number;
    };
    prepare: <R extends ReadMap, C extends CommandMap, K extends keyof R & string>(resource: Resource<R, C>, name: K, input: ReadInput<R[K]>) => {
        options: {
            queryKey: ResourceKey;
            enabled: boolean;
            queryFn: ({ signal, }: {
                signal: AbortSignal;
            }) => Promise<ReadData<R[K]>>;
            retry: false | number;
            gcTime: number;
            staleTime: number;
        };
        identity: ReadIdentity | null;
        allowed: () => boolean;
        captured: DataScope | null;
    };
    read: <R extends ReadMap, C extends CommandMap, K extends keyof R & string>(resource: Resource<R, C>, name: K, input: ReadInput<R[K]>, readConfig?: ReadConfig) => Promise<ReadResult<ReadData<R[K]>>>;
    execute: <R extends ReadMap, C extends CommandMap, K extends keyof C & string>(resource: Resource<R, C>, name: K, input: CommandInput<C[K]>, executeConfig?: ExecuteConfig<CommandInput<C[K]>>) => Promise<CommandReceipt<CommandData<C[K]>, CommandError<C[K]>>>;
    replaceScope: (next: {
        key: string;
    } | null) => void;
    isCurrent: (captured: DataScope | null) => boolean;
    onScopeChange: (listener: () => void) => () => void;
    dispose(): void;
};
export type DataClient = ReturnType<typeof createDataClient>;
