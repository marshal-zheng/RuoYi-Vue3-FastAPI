import { QueryKey } from '@tanstack/vue-query';
import { DeepReadonly } from 'vue';
import { CommandOutcome, DataScope } from './definition';
export type ResourceKey = readonly [
    'zx-resource',
    string,
    number,
    string,
    string,
    unknown
];
export interface ReadIdentity {
    readonly scope: DataScope;
    readonly key: ResourceKey;
    readonly hash: string;
}
export type ReadResult<D> = {
    kind: 'loaded';
    data: DeepReadonly<D>;
    identity: ReadIdentity;
    source: 'cache' | 'network';
} | {
    kind: 'not-started';
    reason: 'scope' | 'disabled';
} | {
    kind: 'failed';
    error: unknown;
} | {
    kind: 'paused' | 'cancelled' | 'obsolete';
};
export type RefreshResult = {
    kind: 'refreshed' | 'invalidated' | 'paused' | 'obsolete';
} | {
    kind: 'failed';
    error: unknown;
};
export type CommandReceipt<D, E> = (CommandOutcome<D, E> | {
    kind: 'not-started';
    reason: 'scope' | 'disabled' | 'cancelled' | 'confirmation' | 'invalid-input';
    error?: unknown;
}) & {
    readonly scope: DataScope | null;
    readonly applicable: boolean;
    readonly refresh: Promise<RefreshResult>;
};
export interface ReadConfig {
    mode?: 'fresh' | 'cached';
    signal?: AbortSignal;
}
export interface ExecuteConfig<I> {
    signal?: AbortSignal;
    beforeExecute?: (input: Readonly<I>, scope: DataScope) => boolean | Promise<boolean>;
}
export declare function isResourceKey(key: QueryKey): key is ResourceKey;
