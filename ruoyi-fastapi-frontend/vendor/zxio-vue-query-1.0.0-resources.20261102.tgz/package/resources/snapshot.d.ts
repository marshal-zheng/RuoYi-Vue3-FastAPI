/** Canonical, detached JSON input. Undefined is allowed only at the root or in object fields. */
export declare function snapshotInput<T>(input: T): T;
