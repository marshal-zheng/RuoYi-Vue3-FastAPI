export type ReadonlyInput<T> = unknown extends T ? T : T extends object ? Readonly<T> : T;
export interface DataScope {
    readonly key: string;
    readonly generation: number;
}
export interface ResourceContext {
    readonly scope: DataScope;
    readonly signal: AbortSignal;
    readonly isCurrent: () => boolean;
}
export interface ReadPolicy {
    staleTime?: number;
    gcTime?: number;
    retry?: false | number;
}
export interface ReadDefinition<I, N, D> extends ReadPolicy {
    normalize?: (input: I) => N;
    enabled?: (input: ReadonlyInput<N>, scope: DataScope) => boolean;
    run: (input: N, context: ResourceContext) => D | Promise<D>;
    /** Type-only witness: caller input can differ from normalized execution input. */
    readonly _input?: I;
}
export declare function defineRead<I, N, D>(definition: ReadDefinition<I, N, D> & {
    normalize: (input: I) => N;
}): ReadDefinition<I, N, D>;
export declare function defineRead<I = void, D = unknown>(definition: ReadDefinition<I, I, D>): ReadDefinition<I, I, D>;
export type CommandOutcome<D, E> = {
    kind: 'succeeded';
    data: D;
} | {
    kind: 'rejected';
    error: E;
} | {
    kind: 'unknown';
    error: unknown;
};
export interface ResourceEffect {
    readonly resource: AnyResource;
    readonly read?: string;
    readonly input?: unknown;
    readonly exact: boolean;
}
export interface CommandDefinition<I, D, E> {
    snapshot?: (input: I) => I;
    enabled?: (input: ReadonlyInput<I>, scope: DataScope) => boolean;
    run: (input: I, context: ResourceContext) => CommandOutcome<D, E> | Promise<CommandOutcome<D, E>>;
    effects?: (context: {
        data: D;
        input: ReadonlyInput<I>;
    }) => readonly ResourceEffect[];
}
type SucceededData<O> = O extends {
    kind: 'succeeded';
    data: infer D;
} ? D : never;
type RejectedError<O> = O extends {
    kind: 'rejected';
    error: infer E;
} ? E : never;
export declare function defineCommand<I = void, O extends CommandOutcome<unknown, unknown> = CommandOutcome<never, never>>(definition: Omit<CommandDefinition<I, SucceededData<NoInfer<O>>, RejectedError<NoInfer<O>>>, 'run'> & {
    run: (input: I, context: ResourceContext) => O | Promise<O>;
}): CommandDefinition<I, SucceededData<O>, RejectedError<O>>;
export type AnyRead = ReadDefinition<any, any, any>;
export type AnyCommand = Omit<CommandDefinition<any, any, any>, 'effects'> & {
    effects?: (context: any) => readonly ResourceEffect[];
};
export type ReadMap = Record<string, AnyRead>;
export type CommandMap = Record<string, AnyCommand>;
export type ReadInput<R extends AnyRead> = R extends ReadDefinition<infer I, any, any> ? I : never;
export type ReadData<R extends AnyRead> = R extends ReadDefinition<any, any, infer D> ? D : never;
export type CommandInput<C extends AnyCommand> = Parameters<C['run']>[0];
export type CommandData<C extends AnyCommand> = SucceededData<Awaited<ReturnType<C['run']>>>;
export type CommandError<C extends AnyCommand> = RejectedError<Awaited<ReturnType<C['run']>>>;
export interface ResourceHandle<R extends ReadMap> {
    all: () => ResourceEffect;
    read<K extends keyof R & string>(name: K): ResourceEffect;
    read<K extends keyof R & string>(name: K, input: ReadInput<R[K]>): ResourceEffect;
}
export interface Resource<R extends ReadMap, C extends CommandMap> extends ResourceHandle<R> {
    readonly name: string;
    readonly reads: R;
    readonly commands: C;
}
export type AnyResource = Resource<ReadMap, CommandMap>;
/** Pure definition. The self factory provides typed effects without recursive inference. */
export declare function defineResource<R extends ReadMap, C extends CommandMap = Record<never, never>>(definition: {
    name: string;
    reads: R;
    commands?: (self: ResourceHandle<R>) => C;
}): Resource<R, C>;
export {};
