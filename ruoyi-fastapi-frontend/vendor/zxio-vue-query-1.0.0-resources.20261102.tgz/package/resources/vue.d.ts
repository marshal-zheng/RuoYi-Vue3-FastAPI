import { App, ComputedRef, DeepReadonly, MaybeRefOrGetter } from 'vue';
import { DataClient } from './client';
import { CommandMap, ReadData, ReadInput, ReadMap, Resource } from './definition';
import { ReadIdentity } from './types';
export declare function provideDataClient(client: DataClient, app?: App): void;
export declare function useDataClient(): DataClient;
export interface ResourceQueryConfig {
    client?: DataClient;
    active?: MaybeRefOrGetter<boolean>;
}
export interface ResourceQuery<D> {
    readonly client: DataClient;
    readonly identity: ComputedRef<ReadIdentity | null>;
    readonly data: ComputedRef<DeepReadonly<D> | undefined>;
    readonly error: ComputedRef<unknown>;
    readonly enabled: ComputedRef<boolean>;
    readonly fetching: ComputedRef<boolean>;
    readonly paused: ComputedRef<boolean>;
    readonly updatedAt: ComputedRef<number>;
    readonly refresh: () => Promise<void>;
    readonly ensureFresh: () => Promise<void>;
}
/** Each identity owns a native useQuery subscription, never a second server-data container. */
export declare function useResourceQuery<R extends ReadMap, C extends CommandMap, K extends keyof R & string>(resource: Resource<R, C>, name: K, input: MaybeRefOrGetter<ReadInput<R[K]>>, config?: ResourceQueryConfig): ResourceQuery<ReadData<R[K]>>;
