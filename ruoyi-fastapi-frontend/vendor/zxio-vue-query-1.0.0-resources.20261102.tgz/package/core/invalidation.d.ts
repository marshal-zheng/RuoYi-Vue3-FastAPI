import { matchQuery, QueryClient } from '@tanstack/vue-query';
export type QueryGroupFilter = Parameters<typeof matchQuery>[0];
/**
 * Cancel old reads, then invalidate the union once and refetch active queries.
 * Completion does not imply that every query has fresh data (for example while offline).
 */
export declare function invalidateQueryGroups(client: QueryClient, filters: readonly QueryGroupFilter[]): Promise<void>;
/** Internal report for command receipts; targets and native state remain owned by QueryClient. */
export declare function invalidateQueryGroupsReport(client: QueryClient, filters: readonly QueryGroupFilter[]): Promise<{
    kind: 'refreshed' | 'invalidated' | 'paused';
} | {
    kind: 'failed';
    error: unknown;
}>;
