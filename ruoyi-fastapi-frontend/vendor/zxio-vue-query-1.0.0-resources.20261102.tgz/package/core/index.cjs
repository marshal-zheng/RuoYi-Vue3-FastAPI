"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const invalidation = require("../invalidation-D3eHn6Ib.js");
exports.invalidateQueryGroups = invalidation.invalidateQueryGroups;
