import { i } from "../invalidation-KJGu-FxR.mjs";
export {
  i as invalidateQueryGroups
};
