"use strict";
const vueQuery = require("@tanstack/vue-query");
async function invalidateQueryGroups(client, filters) {
  if (filters.length === 0) return;
  const union = {
    predicate: (query) => filters.some((filter) => vueQuery.matchQuery(filter, query))
  };
  await client.cancelQueries(union);
  await client.invalidateQueries({ ...union, refetchType: "active" });
}
async function invalidateQueryGroupsReport(client, filters) {
  if (!filters.length) return { kind: "invalidated" };
  const union = {
    predicate: (query) => filters.some((filter) => vueQuery.matchQuery(filter, query))
  };
  const targets = client.getQueryCache().findAll(union);
  try {
    await client.cancelQueries(union);
    await client.invalidateQueries(
      { ...union, refetchType: "active" },
      { throwOnError: true }
    );
    const active = targets.filter((query) => query.isActive());
    if (active.some((query) => query.state.fetchStatus === "paused"))
      return { kind: "paused" };
    const failed = active.find((query) => query.state.status === "error");
    if (failed) return { kind: "failed", error: failed.state.error };
    return { kind: active.length ? "refreshed" : "invalidated" };
  } catch (error) {
    return { kind: "failed", error };
  }
}
exports.invalidateQueryGroups = invalidateQueryGroups;
exports.invalidateQueryGroupsReport = invalidateQueryGroupsReport;
