import { DeepReadonly } from 'vue';
import { ResourceQuery } from '../resources';
export declare function useResourceView<D>(query: ResourceQuery<D>, config: {
    isEmpty: (data: DeepReadonly<D>) => boolean;
}): {
    data: import('vue').ComputedRef<DeepReadonly<D> | undefined>;
    identity: import('vue').ComputedRef<import('../resources').ReadIdentity | null>;
    error: import('vue').ComputedRef<unknown>;
    phase: import('vue').ComputedRef<"pending" | "error" | "paused" | "disabled" | "empty" | "ready">;
    busy: import('vue').ComputedRef<boolean>;
    fetching: import('vue').ComputedRef<boolean>;
    paused: import('vue').ComputedRef<boolean>;
    loading: import('vue').ComputedRef<boolean>;
    refreshing: import('vue').ComputedRef<boolean>;
    refreshError: import('vue').ComputedRef<unknown>;
    retry: () => Promise<void>;
};
