import { DeepReadonly } from 'vue';
import { CommandMap, DataClient, ReadData, ReadInput, ReadMap, ReadResult, Resource } from '../resources';
export declare function useResourceDetail<R extends ReadMap, C extends CommandMap, K extends keyof R & string, Draft>(resource: Resource<R, C>, name: K, config: {
    client?: DataClient;
    snapshot: (data: DeepReadonly<ReadData<R[K]>>) => Draft;
}): {
    busy: import('vue').ComputedRef<boolean>;
    result: import('vue').ComputedRef<ReadResult<ReadData<R[K]>> | null>;
    close: () => void;
    loadSnapshot(input: ReadInput<R[K]>): Promise<{
        kind: "not-started";
        reason: "scope" | "disabled";
    } | {
        kind: "failed";
        error: unknown;
    } | {
        kind: "paused" | "cancelled" | "obsolete";
    } | {
        kind: "loaded";
        draft: Draft;
        identity: import('../resources').ReadIdentity;
        isCurrent: () => boolean;
    }>;
};
