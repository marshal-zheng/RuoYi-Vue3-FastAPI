import { CommandInput, CommandMap, CommandReceipt, DataClient, ExecuteConfig, ReadMap, Resource } from '../resources';
export declare function useResourceCommand<R extends ReadMap, C extends CommandMap, K extends keyof C & string>(resource: Resource<R, C>, name: K, config?: ExecuteConfig<CommandInput<C[K]>> & {
    client?: DataClient;
}): {
    busy: import('vue').ComputedRef<boolean>;
    receipt: import('vue').ComputedRef<CommandReceipt<Awaited<ReturnType<C[K]["run"]>> extends infer T ? T extends Awaited<ReturnType<C[K]["run"]>> ? T extends {
        kind: "succeeded";
        data: infer D;
    } ? D : never : never : never, Awaited<ReturnType<C[K]["run"]>> extends infer T_1 ? T_1 extends Awaited<ReturnType<C[K]["run"]>> ? T_1 extends {
        kind: "rejected";
        error: infer E;
    } ? E : never : never : never> | null>;
    run(input: CommandInput<C[K]>): Promise<CommandReceipt<Awaited<ReturnType<C[K]["run"]>> extends infer T_2 ? T_2 extends Awaited<ReturnType<C[K]["run"]>> ? T_2 extends {
        kind: "succeeded";
        data: infer D;
    } ? D : never : never : never, Awaited<ReturnType<C[K]["run"]>> extends infer T_3 ? T_3 extends Awaited<ReturnType<C[K]["run"]>> ? T_3 extends {
        kind: "rejected";
        error: infer E;
    } ? E : never : never : never> | null>;
};
