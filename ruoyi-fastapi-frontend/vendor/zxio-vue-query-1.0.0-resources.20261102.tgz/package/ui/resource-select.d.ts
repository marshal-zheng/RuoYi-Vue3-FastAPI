import { DeepReadonly, MaybeRefOrGetter } from 'vue';
import { SelectOption } from '@zxio/zxui';
import { CommandMap, ReadData, ReadInput, ReadMap, Resource, ResourceQueryConfig } from '../resources';
export declare function useResourceSelect<R extends ReadMap, C extends CommandMap, K extends keyof R & string, O extends SelectOption>(resource: Resource<R, C>, name: K, input: MaybeRefOrGetter<ReadInput<R[K]>>, config: ResourceQueryConfig & {
    options: (data: DeepReadonly<ReadData<R[K]>>) => readonly O[];
    /** Domain-owned selected labels, including independently fetched by-id options. */
    selectedOptions?: MaybeRefOrGetter<readonly O[]>;
    optionKey: (option: O) => string | number;
}): {
    query: import('../resources').ResourceQuery<ReadData<R[K]>>;
    view: {
        data: import('vue').ComputedRef<DeepReadonly<ReadData<R[K]>> | undefined>;
        identity: import('vue').ComputedRef<import('../resources').ReadIdentity | null>;
        error: import('vue').ComputedRef<unknown>;
        phase: import('vue').ComputedRef<"pending" | "error" | "paused" | "disabled" | "empty" | "ready">;
        busy: import('vue').ComputedRef<boolean>;
        fetching: import('vue').ComputedRef<boolean>;
        paused: import('vue').ComputedRef<boolean>;
        loading: import('vue').ComputedRef<boolean>;
        refreshing: import('vue').ComputedRef<boolean>;
        refreshError: import('vue').ComputedRef<unknown>;
        retry: () => Promise<void>;
    };
    selectProps: import('vue').ComputedRef<{
        options: readonly [] | O[];
        loading: boolean;
        refreshing: boolean;
        error: unknown;
        paused: boolean;
    }>;
    selectEvents: {
        'visible-change': (visible: boolean) => void;
        retry: () => void;
    };
    refresh: () => Promise<void>;
    ensureFresh: () => Promise<void>;
};
