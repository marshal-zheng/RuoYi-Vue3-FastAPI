import { getCurrentInstance, ref, computed, toValue, unref, onActivated, onDeactivated, nextTick, shallowRef, watch, onScopeDispose } from "vue";
import { useQueryClient, useQuery, isCancelledError, skipToken } from "@tanstack/vue-query";
import { u as useDataClient, a as useResourceQuery, s as snapshotInput } from "../vue-HRTvQ6lJ.mjs";
const EMPTY_OPTIONS = Object.freeze([]);
function selectState(options, loading, refreshing, error, paused) {
  return {
    options: options ?? EMPTY_OPTIONS,
    loading,
    refreshing,
    error,
    paused
  };
}
function useQuerySelect(options, config = {}) {
  if (!getCurrentInstance()) {
    throw new Error(
      "useQuerySelect must be called synchronously inside setup()."
    );
  }
  const client = config.queryClient ?? useQueryClient();
  const activated = ref(true);
  const active = computed(
    () => activated.value && toValue(config.active ?? true)
  );
  const currentOptions = computed(() => unref(toValue(options)));
  const gatedOptions = computed(
    () => active.value ? currentOptions.value : { ...currentOptions.value, enabled: false }
  );
  const query = useQuery(
    gatedOptions,
    client
  );
  const execute = async (onlyStale) => {
    await nextTick();
    if (!active.value || unref(currentOptions.value.queryFn) === skipToken || !query.isEnabled.value)
      return;
    if (onlyStale && !query.isStale.value) return;
    await query.refetch({ cancelRefetch: false, throwOnError: true });
  };
  const ensureFresh = () => execute(true);
  const refresh = () => execute(false);
  const fromEvent = (action) => {
    action().catch(() => {
    });
  };
  onActivated(() => {
    const wasDeactivated = !activated.value;
    activated.value = true;
    if (wasDeactivated) fromEvent(ensureFresh);
  });
  onDeactivated(() => {
    activated.value = false;
  });
  const selectProps = computed(
    () => selectState(
      query.data.value,
      query.isLoading.value,
      query.isFetching.value && query.data.value !== void 0,
      isCancelledError(query.error.value) ? null : query.error.value,
      query.fetchStatus.value === "paused"
    )
  );
  return {
    query,
    selectProps,
    selectEvents: {
      "visible-change": (visible) => {
        if (visible) fromEvent(ensureFresh);
      },
      retry: () => fromEvent(refresh)
    },
    ensureFresh,
    refresh
  };
}
function useResourceView(query, config) {
  const visible = shallowRef(false);
  let timer;
  const clear = () => {
    clearTimeout(timer);
    timer = void 0;
    visible.value = false;
  };
  watch(
    () => {
      var _a;
      return [(_a = query.identity.value) == null ? void 0 : _a.hash, query.fetching.value];
    },
    () => {
      clear();
      if (query.fetching.value) {
        timer = setTimeout(() => {
          visible.value = true;
        }, query.client.presentationDelay);
      }
    },
    { immediate: true, flush: "sync" }
  );
  onScopeDispose(clear);
  const phase = computed(() => {
    if (!query.enabled.value) return query.error.value ? "error" : "disabled";
    if (query.paused.value) return "paused";
    if (query.data.value !== void 0)
      return config.isEmpty(query.data.value) ? "empty" : "ready";
    if (query.error.value) return "error";
    return "pending";
  });
  return {
    data: query.data,
    identity: query.identity,
    error: query.error,
    phase,
    busy: query.fetching,
    fetching: query.fetching,
    paused: query.paused,
    loading: computed(
      () => visible.value && query.fetching.value && query.data.value === void 0
    ),
    refreshing: computed(
      () => visible.value && query.fetching.value && query.data.value !== void 0
    ),
    refreshError: computed(
      () => query.data.value !== void 0 ? query.error.value : null
    ),
    retry: query.refresh
  };
}
function useResourceCommand(resource, name, config = {}) {
  const client = config.client ?? useDataClient();
  const busy = shallowRef(false);
  const receipt = shallowRef(null);
  let generation = 0;
  let disposed = false;
  const off = client.onScopeChange(() => {
    generation++;
    receipt.value = null;
    busy.value = false;
  });
  onScopeDispose(() => {
    disposed = true;
    generation++;
    off();
  });
  return {
    busy: computed(() => busy.value),
    receipt: computed(() => receipt.value),
    async run(input) {
      if (busy.value || disposed) return null;
      busy.value = true;
      const ownGeneration = generation;
      try {
        const result = await client.execute(resource, name, input, config);
        if (ownGeneration === generation && !disposed && result.applicable)
          receipt.value = result;
        return result;
      } finally {
        if (ownGeneration === generation && !disposed) busy.value = false;
      }
    }
  };
}
function useResourceSelect(resource, name, input, config) {
  const query = useResourceQuery(resource, name, input, config);
  const view = useResourceView(query, {
    isEmpty: (data) => config.options(data).length === 0
  });
  const options = computed(() => {
    const available = query.data.value === void 0 ? [] : config.options(query.data.value);
    const present = new Set(available.map(config.optionKey));
    return [
      ...available,
      ...toValue(config.selectedOptions ?? []).filter(
        (option) => !present.has(config.optionKey(option))
      )
    ];
  });
  return {
    query,
    view,
    selectProps: computed(
      () => selectState(
        options.value,
        view.loading.value,
        view.refreshing.value,
        view.error.value,
        view.paused.value
      )
    ),
    selectEvents: {
      "visible-change": (visible) => {
        if (visible) query.ensureFresh();
      },
      retry: () => {
        query.refresh();
      }
    },
    refresh: query.refresh,
    ensureFresh: query.ensureFresh
  };
}
function validInput(input) {
  return input !== null && typeof input === "object" && input.query !== null && typeof input.query === "object" && !Array.isArray(input.query) && Array.isArray(input.sort) && input.sort.every(
    (item) => item && typeof item.field === "string" && item.field.length > 0 && (item.order === "asc" || item.order === "desc")
  ) && (input.pager === null || input.pager && Number.isInteger(input.pager.page) && input.pager.page > 0 && Number.isInteger(input.pager.size) && input.pager.size > 0);
}
function useResourceList(resource, name, config) {
  const client = config.client ?? useDataClient();
  const submitted = shallowRef(snapshotInput(config.initialInput));
  if (!validInput(submitted.value))
    throw new TypeError("Invalid resource list input.");
  const domainKey = computed(
    () => client.scope.value ? `${client.scope.value.key}:${client.scope.value.generation}` : ""
  );
  const query = useResourceQuery(
    resource,
    name,
    () => config.input(submitted.value),
    { ...config, client }
  );
  const view = useResourceView(query, {
    isEmpty: (data) => config.project(data, submitted.value).rows.length === 0
  });
  let revision = 0;
  const published = shallowRef(null);
  const projectionError = shallowRef(null);
  watch(
    domainKey,
    () => {
      published.value = null;
      projectionError.value = null;
    },
    { flush: "sync" }
  );
  watch(
    [query.data, query.updatedAt, query.fetching, query.identity],
    () => {
      if (!query.identity.value || query.data.value === void 0 || query.fetching.value || query.error.value)
        return;
      try {
        const result = config.project(query.data.value, submitted.value);
        published.value = {
          rows: result.rows,
          pagination: result.pagination,
          displayed: {
            domainKey: domainKey.value,
            revision: ++revision,
            input: snapshotInput(result.logicalInput)
          }
        };
        projectionError.value = null;
      } catch (error) {
        projectionError.value = error;
      }
    },
    { immediate: true, flush: "post" }
  );
  const applied = computed(
    () => client.scope.value ? { domainKey: domainKey.value, ...submitted.value } : null
  );
  const state = computed(() => {
    var _a, _b, _c, _d, _e;
    return {
      query: submitted.value.query,
      applied: applied.value,
      displayed: ((_a = published.value) == null ? void 0 : _a.displayed) ?? null,
      rows: ((_b = published.value) == null ? void 0 : _b.rows) ?? [],
      pagination: ((_c = published.value) == null ? void 0 : _c.pagination) ?? {
        page: ((_d = submitted.value.pager) == null ? void 0 : _d.page) ?? 1,
        size: ((_e = submitted.value.pager) == null ? void 0 : _e.size) ?? 20,
        total: 0
      },
      domainKey: domainKey.value,
      status: {
        loading: view.loading.value && !published.value,
        refreshing: (view.loading.value || view.refreshing.value) && !!published.value,
        error: projectionError.value ?? view.error.value,
        paused: view.paused.value,
        retry: () => {
          query.refresh();
        },
        domain: client.scope.value ? "ready" : "unavailable"
      }
    };
  });
  return {
    query,
    view,
    applied,
    domainKey,
    state,
    displayed: computed(() => state.value.displayed),
    rows: computed(() => state.value.rows),
    pagination: computed(() => state.value.pagination),
    status: computed(() => state.value.status),
    onQueryIntent(intent) {
      var _a, _b;
      if (!client.scope.value || !intent || intent.domainKey !== domainKey.value || !["search", "reset", "reload", "requery"].includes(intent.kind))
        return false;
      try {
        const next = snapshotInput(intent.input);
        if (!validInput(next)) return false;
        const prepared = client.prepare(resource, name, config.input(next));
        if (!prepared.allowed()) return false;
        const same = ((_a = prepared.identity) == null ? void 0 : _a.hash) === ((_b = query.identity.value) == null ? void 0 : _b.hash);
        submitted.value = next;
        if (same) query.refresh();
        return true;
      } catch {
        return false;
      }
    }
  };
}
function useResourceDetail(resource, name, config) {
  const client = config.client ?? useDataClient();
  const busy = shallowRef(false);
  const result = shallowRef(null);
  let generation = 0;
  let waiting;
  const close = () => {
    generation++;
    waiting == null ? void 0 : waiting.abort();
    waiting = void 0;
    busy.value = false;
    result.value = null;
  };
  const off = client.onScopeChange(close);
  onScopeDispose(() => {
    close();
    off();
  });
  return {
    busy: computed(() => busy.value),
    result: computed(() => result.value),
    close,
    async loadSnapshot(input) {
      close();
      const ownGeneration = generation;
      waiting = new AbortController();
      busy.value = true;
      const loaded = await client.read(resource, name, input, {
        signal: waiting.signal
      });
      if (generation !== ownGeneration) return { kind: "obsolete" };
      busy.value = false;
      result.value = loaded;
      if (loaded.kind !== "loaded") return loaded;
      try {
        return {
          kind: "loaded",
          draft: config.snapshot(loaded.data),
          identity: loaded.identity,
          isCurrent: () => generation === ownGeneration && client.isCurrent(loaded.identity.scope)
        };
      } catch (error) {
        return { kind: "failed", error };
      }
    }
  };
}
export {
  useQuerySelect,
  useResourceCommand,
  useResourceDetail,
  useResourceList,
  useResourceSelect,
  useResourceView
};
