import { DeepReadonly } from 'vue';
import { CommandMap, ReadData, ReadInput, ReadMap, Resource, ResourceQueryConfig } from '../resources';
/** Structural public controlled-list contract, checked against TableRender in consumer fixtures. */
export interface ResourceListInput<Q> {
    readonly query: Partial<Q>;
    readonly pager: {
        readonly page: number;
        readonly size: number;
    } | null;
    readonly sort: readonly {
        readonly field: string;
        readonly order: 'asc' | 'desc';
    }[];
}
export interface ResourceListIntent<Q> {
    readonly kind: 'search' | 'reset' | 'reload' | 'requery';
    readonly domainKey: string;
    readonly input: ResourceListInput<Q>;
}
export declare function useResourceList<R extends ReadMap, C extends CommandMap, K extends keyof R & string, Q, Row>(resource: Resource<R, C>, name: K, config: ResourceQueryConfig & {
    initialInput: ResourceListInput<Q>;
    input: (input: ResourceListInput<Q>) => ReadInput<R[K]>;
    project: (data: DeepReadonly<ReadData<R[K]>>, requested: ResourceListInput<Q>) => {
        rows: readonly Row[];
        pagination: {
            page: number;
            size: number;
            total: number;
        };
        logicalInput: ResourceListInput<Q>;
    };
}): {
    query: import('../resources').ResourceQuery<ReadData<R[K]>>;
    view: {
        data: import('vue').ComputedRef<DeepReadonly<ReadData<R[K]>> | undefined>;
        identity: import('vue').ComputedRef<import('../resources').ReadIdentity | null>;
        error: import('vue').ComputedRef<unknown>;
        phase: import('vue').ComputedRef<"pending" | "error" | "paused" | "disabled" | "empty" | "ready">;
        busy: import('vue').ComputedRef<boolean>;
        fetching: import('vue').ComputedRef<boolean>;
        paused: import('vue').ComputedRef<boolean>;
        loading: import('vue').ComputedRef<boolean>;
        refreshing: import('vue').ComputedRef<boolean>;
        refreshError: import('vue').ComputedRef<unknown>;
        retry: () => Promise<void>;
    };
    applied: import('vue').ComputedRef<{
        query: Partial<Q>;
        pager: {
            readonly page: number;
            readonly size: number;
        } | null;
        sort: readonly {
            readonly field: string;
            readonly order: "asc" | "desc";
        }[];
        domainKey: string;
    } | null>;
    domainKey: import('vue').ComputedRef<string>;
    state: import('vue').ComputedRef<{
        query: Partial<Q>;
        applied: {
            query: Partial<Q>;
            pager: {
                readonly page: number;
                readonly size: number;
            } | null;
            sort: readonly {
                readonly field: string;
                readonly order: "asc" | "desc";
            }[];
            domainKey: string;
        } | null;
        displayed: {
            domainKey: string;
            revision: number;
            input: ResourceListInput<Q>;
        } | null;
        rows: readonly Row[];
        pagination: {
            page: number;
            size: number;
            total: number;
        };
        domainKey: string;
        status: {
            loading: boolean;
            refreshing: boolean;
            error: unknown;
            paused: boolean;
            retry: () => void;
            domain: "ready" | "unavailable";
        };
    }>;
    displayed: import('vue').ComputedRef<{
        domainKey: string;
        revision: number;
        input: ResourceListInput<Q>;
    } | null>;
    rows: import('vue').ComputedRef<readonly Row[]>;
    pagination: import('vue').ComputedRef<{
        page: number;
        size: number;
        total: number;
    }>;
    status: import('vue').ComputedRef<{
        loading: boolean;
        refreshing: boolean;
        error: unknown;
        paused: boolean;
        retry: () => void;
        domain: "ready" | "unavailable";
    }>;
    onQueryIntent(intent: ResourceListIntent<Q>): boolean;
};
