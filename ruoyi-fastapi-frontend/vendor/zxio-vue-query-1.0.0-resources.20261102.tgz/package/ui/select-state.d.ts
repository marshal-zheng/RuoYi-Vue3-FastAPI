import { SelectOption } from '@zxio/zxui';
export declare const EMPTY_OPTIONS: readonly [];
/** Shared native/resource select projection; modelValue is deliberately not owned here. */
export declare function selectState<T extends readonly SelectOption[], E>(options: T | undefined, loading: boolean, refreshing: boolean, error: E, paused: boolean): {
    options: readonly [] | T;
    loading: boolean;
    refreshing: boolean;
    error: E;
    paused: boolean;
};
