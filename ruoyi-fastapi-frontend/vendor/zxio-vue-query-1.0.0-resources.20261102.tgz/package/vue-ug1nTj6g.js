"use strict";
const vue = require("vue");
const vueQuery = require("@tanstack/vue-query");
function snapshotInput(input) {
  const ancestors = /* @__PURE__ */ new Set();
  const visit = (value, root = false) => {
    if (value === void 0 && root) return null;
    if (value === null || typeof value === "string" || typeof value === "boolean")
      return value;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || value === null)
      throw new TypeError("Resource input must be finite JSON.");
    if (ancestors.has(value))
      throw new TypeError("Resource input must not be cyclic.");
    if (!Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) {
      throw new TypeError("Normalize non-JSON resource input before execution.");
    }
    ancestors.add(value);
    const result = Array.isArray(value) ? Array.from(value, (entry) => visit(entry)) : Object.fromEntries(
      Object.entries(value).filter(([, entry]) => entry !== void 0).map(([key, entry]) => [key, visit(entry)])
    );
    ancestors.delete(value);
    return Object.freeze(result);
  };
  return visit(input, true);
}
const dataClientKey = Symbol("zx-data-client");
function provideDataClient(client, app) {
  if (app) app.provide(dataClientKey, client);
  else vue.provide(dataClientKey, client);
}
function useDataClient() {
  const client = vue.inject(dataClientKey, null);
  if (!client)
    throw new Error("Provide the host DataClient before using resources.");
  return client;
}
function useResourceQuery(resource, name, input, config = {}) {
  const client = config.client ?? useDataClient();
  const activated = vue.shallowRef(true);
  const active = vue.computed(
    () => activated.value && vue.toValue(config.active ?? true)
  );
  const prepared = vue.computed(() => {
    try {
      return {
        value: client.prepare(resource, name, vue.toValue(input)),
        error: null
      };
    } catch (error) {
      return { value: null, error };
    }
  });
  const enabled = vue.computed(
    () => {
      var _a;
      return active.value && !!((_a = prepared.value.value) == null ? void 0 : _a.options.enabled);
    }
  );
  const native = vue.shallowRef(null);
  let subscription;
  vue.watch(
    () => {
      var _a, _b;
      return [(_b = (_a = prepared.value.value) == null ? void 0 : _a.identity) == null ? void 0 : _b.hash, enabled.value];
    },
    () => {
      subscription == null ? void 0 : subscription.stop();
      native.value = null;
      if (!enabled.value || !prepared.value.value) return;
      subscription = vue.effectScope();
      native.value = subscription.run(
        () => vueQuery.useQuery(
          prepared.value.value.options,
          client.queryClient
        )
      );
    },
    { immediate: true, flush: "sync" }
  );
  vue.onScopeDispose(() => subscription == null ? void 0 : subscription.stop());
  if (vue.getCurrentInstance()) {
    vue.onDeactivated(() => {
      activated.value = false;
    });
    vue.onActivated(() => {
      activated.value = true;
    });
  }
  const refresh = async () => {
    var _a;
    if (!enabled.value) return;
    await ((_a = native.value) == null ? void 0 : _a.refetch({ cancelRefetch: false }));
  };
  return {
    client,
    enabled,
    identity: vue.computed(
      () => {
        var _a;
        return enabled.value ? ((_a = prepared.value.value) == null ? void 0 : _a.identity) ?? null : null;
      }
    ),
    data: vue.computed(
      () => {
        var _a;
        return enabled.value ? (_a = native.value) == null ? void 0 : _a.data.value : void 0;
      }
    ),
    error: vue.computed(
      () => {
        var _a;
        return prepared.value.error ?? ((_a = native.value) == null ? void 0 : _a.error.value) ?? null;
      }
    ),
    fetching: vue.computed(() => {
      var _a;
      return enabled.value && !!((_a = native.value) == null ? void 0 : _a.isFetching.value);
    }),
    paused: vue.computed(
      () => {
        var _a;
        return enabled.value && ((_a = native.value) == null ? void 0 : _a.fetchStatus.value) === "paused";
      }
    ),
    updatedAt: vue.computed(
      () => {
        var _a;
        return enabled.value ? ((_a = native.value) == null ? void 0 : _a.dataUpdatedAt.value) ?? 0 : 0;
      }
    ),
    refresh,
    ensureFresh: async () => {
      if (enabled.value) await client.read(resource, name, vue.toValue(input));
    }
  };
}
exports.provideDataClient = provideDataClient;
exports.snapshotInput = snapshotInput;
exports.useDataClient = useDataClient;
exports.useResourceQuery = useResourceQuery;
