import { CascaderProps, CascaderValue } from 'element-plus';
import { ChoiceNode } from './choice-control';
type __VLS_Props = {
    modelValue?: CascaderValue | null;
    options?: readonly ChoiceNode[];
    props?: CascaderProps;
    disabled?: boolean;
    readonly?: boolean;
};
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: Readonly<Record<string, (scope: Record<string, unknown>) => unknown>> & Record<string, (scope: Record<string, unknown>) => unknown>;
    refs: {
        cascader: ({
            $: import('vue').ComponentInternalInstance;
            $data: {};
            $props: {
                readonly size?: import('element-plus').ComponentSize | undefined;
                readonly placeholder?: string | undefined;
                readonly disabled?: boolean | undefined;
                readonly clearable?: boolean | undefined;
                readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                readonly filterable?: boolean | undefined;
                readonly filterMethod?: ((node: import('element-plus').CascaderNode, keyword: string) => boolean) | undefined;
                readonly separator?: string | undefined;
                readonly showAllLevels?: boolean | undefined;
                readonly collapseTags?: boolean | undefined;
                readonly maxCollapseTags?: number | undefined;
                readonly collapseTagsTooltip?: boolean | undefined;
                readonly maxCollapseTagsTooltipHeight?: (string | number) | undefined;
                readonly debounce?: number | undefined;
                readonly beforeFilter?: ((value: string) => boolean | Promise<any>) | undefined;
                readonly placement?: import('element-plus').Placement | undefined;
                readonly fallbackPlacements?: import('element-plus').Placement[] | undefined;
                readonly popperClass?: import('element-plus/es/utils/typescript.mjs').ClassValue;
                readonly popperStyle?: import('vue').StyleValue;
                readonly teleported?: boolean | undefined;
                readonly effect?: import('element-plus').PopperEffect | undefined;
                readonly tagType?: import('element-plus').TagProps["type"];
                readonly tagEffect?: import('element-plus').TagProps["effect"];
                readonly validateEvent?: boolean | undefined;
                readonly persistent?: boolean | undefined;
                readonly showCheckedStrategy?: ("parent" | "child") | undefined;
                readonly checkOnClickNode?: boolean | undefined;
                readonly showPrefix?: boolean | undefined;
                readonly fitInputWidth?: (boolean | number) | undefined;
                readonly modelValue?: (CascaderValue | null) | undefined;
                readonly options?: import('element-plus').CascaderOption[] | undefined;
                readonly props?: CascaderProps | undefined;
                readonly virtualScroll?: boolean | undefined;
                readonly itemSize?: number | undefined;
                readonly height?: number | undefined;
                readonly emptyValues?: unknown[] | undefined;
                readonly valueOnClear?: (string | number | boolean | Function | null) | undefined;
                readonly onClear?: (() => any) | undefined;
                readonly "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
                readonly onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
                readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                readonly onVisibleChange?: ((val: boolean) => any) | undefined;
                readonly onExpandChange?: ((val: CascaderValue) => any) | undefined;
                readonly onRemoveTag?: ((val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => any) | undefined;
            } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
            $attrs: import('vue').Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import('vue').Slot<any> | undefined;
            }>;
            $root: import('vue').ComponentPublicInstance | null;
            $parent: import('vue').ComponentPublicInstance | null;
            $host: Element | null;
            $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: CascaderValue | null | undefined) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "clear") => void) & ((event: "update:modelValue", value: CascaderValue | null | undefined) => void) & ((event: "removeTag", val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => void) & ((event: "visibleChange", val: boolean) => void) & ((event: "expandChange", val: CascaderValue) => void);
            $el: any;
            $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').CascaderComponentProps> & Readonly<{
                onClear?: (() => any) | undefined;
                "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
                onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
                onBlur?: ((evt: FocusEvent) => any) | undefined;
                onFocus?: ((evt: FocusEvent) => any) | undefined;
                onVisibleChange?: ((val: boolean) => any) | undefined;
                onExpandChange?: ((val: CascaderValue) => any) | undefined;
                onRemoveTag?: ((val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => any) | undefined;
            }>, {
                getCheckedNodes: (leafOnly: boolean) => import('element-plus').CascaderNode[] | undefined;
                cascaderPanelRef: import('vue').Ref<import('element-plus').CascaderPanelInstance | undefined, import('element-plus').CascaderPanelInstance | undefined>;
                togglePopperVisible: (visible?: boolean) => void;
                contentRef: import('vue').ComputedRef<HTMLElement | undefined>;
                presentText: import('vue').ComputedRef<string>;
                focus: () => void;
                blur: () => void;
            }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                clear: () => void;
                "update:modelValue": (value: CascaderValue | null | undefined) => void;
                change: (value: CascaderValue | null | undefined) => void;
                blur: (evt: FocusEvent) => void;
                focus: (evt: FocusEvent) => void;
                visibleChange: (val: boolean) => void;
                expandChange: (val: CascaderValue) => void;
                removeTag: (val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => void;
            }, string, {
                props: CascaderProps;
                disabled: boolean;
                filterMethod: (node: import('element-plus').CascaderNode, keyword: string) => boolean;
                height: number;
                itemSize: number;
                separator: string;
                validateEvent: boolean;
                options: import('element-plus').CascaderOption[];
                valueOnClear: string | number | boolean | Function | null;
                teleported: boolean;
                effect: import('element-plus').PopperEffect;
                clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                popperClass: string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[] | null;
                popperStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                fallbackPlacements: import('element-plus').Placement[];
                placement: import('element-plus').Placement;
                persistent: boolean;
                debounce: number;
                showPrefix: boolean;
                showAllLevels: boolean;
                maxCollapseTags: number;
                beforeFilter: (value: string) => boolean | Promise<any>;
                tagType: "info" | "primary" | "success" | "warning" | "danger";
                tagEffect: "dark" | "light" | "plain";
                showCheckedStrategy: "parent" | "child";
            }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import('vue').nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
        } & Readonly<{
            props: CascaderProps;
            disabled: boolean;
            filterMethod: (node: import('element-plus').CascaderNode, keyword: string) => boolean;
            height: number;
            itemSize: number;
            separator: string;
            validateEvent: boolean;
            options: import('element-plus').CascaderOption[];
            valueOnClear: string | number | boolean | Function | null;
            teleported: boolean;
            effect: import('element-plus').PopperEffect;
            clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
            popperClass: string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[] | null;
            popperStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
            fallbackPlacements: import('element-plus').Placement[];
            placement: import('element-plus').Placement;
            persistent: boolean;
            debounce: number;
            showPrefix: boolean;
            showAllLevels: boolean;
            maxCollapseTags: number;
            beforeFilter: (value: string) => boolean | Promise<any>;
            tagType: "info" | "primary" | "success" | "warning" | "danger";
            tagEffect: "dark" | "light" | "plain";
            showCheckedStrategy: "parent" | "child";
        }> & Omit<Readonly<import('element-plus').CascaderComponentProps> & Readonly<{
            onClear?: (() => any) | undefined;
            "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
            onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onVisibleChange?: ((val: boolean) => any) | undefined;
            onExpandChange?: ((val: CascaderValue) => any) | undefined;
            onRemoveTag?: ((val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => any) | undefined;
        }>, "blur" | "focus" | "props" | "disabled" | "effect" | "debounce" | "clearIcon" | "validateEvent" | "placement" | "separator" | "height" | "valueOnClear" | "persistent" | "popperClass" | "popperStyle" | "fallbackPlacements" | "teleported" | "options" | "contentRef" | "filterMethod" | "maxCollapseTags" | "tagType" | "tagEffect" | "showAllLevels" | "beforeFilter" | "showCheckedStrategy" | "showPrefix" | "itemSize" | "getCheckedNodes" | "cascaderPanelRef" | "togglePopperVisible" | "presentText"> & {
            getCheckedNodes: (leafOnly: boolean) => import('element-plus').CascaderNode[] | undefined;
            cascaderPanelRef: import('element-plus').CascaderPanelInstance | undefined;
            togglePopperVisible: (visible?: boolean) => void;
            contentRef: HTMLElement | undefined;
            presentText: string;
            focus: () => void;
            blur: () => void;
        } & {} & import('vue').ComponentCustomProperties & {} & {
            $slots: {
                prefix?: (props: {}) => any;
            } & {
                tag?: (props: {
                    data: {
                        node?: {
                            readonly uid: number;
                            readonly level: number;
                            readonly value: import('element-plus').CascaderNodeValue;
                            readonly label: string;
                            readonly pathNodes: any[];
                            readonly pathValues: import('element-plus').CascaderNodeValue[];
                            readonly pathLabels: string[];
                            childrenData: {
                                [x: string]: unknown;
                                label?: string | undefined;
                                value?: import('element-plus').CascaderNodeValue | undefined;
                                children?: any[] | undefined;
                                disabled?: boolean | undefined;
                                leaf?: boolean | undefined;
                            }[] | undefined;
                            children: any[];
                            text: string;
                            loaded: boolean;
                            checked: boolean;
                            indeterminate: boolean;
                            loading: boolean;
                            readonly data: {
                                [x: string]: unknown;
                                label?: string | undefined;
                                value?: import('element-plus').CascaderNodeValue | undefined;
                                children?: any[] | undefined;
                                disabled?: boolean | undefined;
                                leaf?: boolean | undefined;
                            };
                            readonly config: {
                                expandTrigger: import('element-plus').ExpandTrigger;
                                multiple: boolean;
                                checkStrictly: boolean;
                                emitPath: boolean;
                                lazy: boolean;
                                lazyLoad: import('element-plus').LazyLoad;
                                value: string;
                                label: string;
                                children: string;
                                disabled: string | import('element-plus').isDisabled;
                                leaf: string | import('element-plus').isLeaf;
                                hoverThreshold: number;
                                checkOnClickNode: boolean;
                                checkOnClickLeaf: boolean;
                                showPrefix: boolean;
                            };
                            readonly parent?: any | undefined;
                            readonly root: boolean;
                            readonly isDisabled: boolean;
                            readonly isLeaf: boolean;
                            readonly valueByOption: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodeValue[];
                            appendChild: (childData: import('element-plus').CascaderOption) => import('element-plus').CascaderNode;
                            calcText: (allLevels: boolean, separator: string) => string;
                            broadcast: (checked: boolean) => void;
                            emit: () => void;
                            onParentCheck: (checked: boolean) => void;
                            onChildCheck: () => void;
                            setCheckState: (checked: boolean) => void;
                            doCheck: (checked: boolean) => void;
                        } | undefined;
                        key: number;
                        text: string;
                        hitState?: boolean | undefined;
                        closable: boolean;
                    }[];
                    deleteTag: (tag: import('element-plus').Tag) => void;
                }) => any;
            } & {
                header?: (props: {}) => any;
            } & {
                empty?: (props: {}) => any;
            } & {
                'suggestion-item'?: (props: {
                    item: {
                        readonly uid: number;
                        readonly level: number;
                        readonly value: import('element-plus').CascaderNodeValue;
                        readonly label: string;
                        readonly pathNodes: any[];
                        readonly pathValues: import('element-plus').CascaderNodeValue[];
                        readonly pathLabels: string[];
                        childrenData: {
                            [x: string]: unknown;
                            label?: string | undefined;
                            value?: import('element-plus').CascaderNodeValue | undefined;
                            children?: any[] | undefined;
                            disabled?: boolean | undefined;
                            leaf?: boolean | undefined;
                        }[] | undefined;
                        children: any[];
                        text: string;
                        loaded: boolean;
                        checked: boolean;
                        indeterminate: boolean;
                        loading: boolean;
                        readonly data: {
                            [x: string]: unknown;
                            label?: string | undefined;
                            value?: import('element-plus').CascaderNodeValue | undefined;
                            children?: any[] | undefined;
                            disabled?: boolean | undefined;
                            leaf?: boolean | undefined;
                        };
                        readonly config: {
                            expandTrigger: import('element-plus').ExpandTrigger;
                            multiple: boolean;
                            checkStrictly: boolean;
                            emitPath: boolean;
                            lazy: boolean;
                            lazyLoad: import('element-plus').LazyLoad;
                            value: string;
                            label: string;
                            children: string;
                            disabled: string | import('element-plus').isDisabled;
                            leaf: string | import('element-plus').isLeaf;
                            hoverThreshold: number;
                            checkOnClickNode: boolean;
                            checkOnClickLeaf: boolean;
                            showPrefix: boolean;
                        };
                        readonly parent?: any | undefined;
                        readonly root: boolean;
                        readonly isDisabled: boolean;
                        readonly isLeaf: boolean;
                        readonly valueByOption: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodeValue[];
                        appendChild: (childData: import('element-plus').CascaderOption) => import('element-plus').CascaderNode;
                        calcText: (allLevels: boolean, separator: string) => string;
                        broadcast: (checked: boolean) => void;
                        emit: () => void;
                        onParentCheck: (checked: boolean) => void;
                        onChildCheck: () => void;
                        setCheckState: (checked: boolean) => void;
                        doCheck: (checked: boolean) => void;
                    };
                }) => any;
            } & {
                empty?: (props: {}) => any;
            } & {
                'suggestion-item'?: (props: {
                    item: any;
                }) => any;
            } & {
                empty?: (props: {}) => any;
            } & {
                footer?: (props: {}) => any;
            };
        }) | null;
    };
    rootEl: any;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: CascaderValue | null) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: CascaderValue | null) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    cascader: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: {
            readonly size?: import('element-plus').ComponentSize | undefined;
            readonly placeholder?: string | undefined;
            readonly disabled?: boolean | undefined;
            readonly clearable?: boolean | undefined;
            readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
            readonly filterable?: boolean | undefined;
            readonly filterMethod?: ((node: import('element-plus').CascaderNode, keyword: string) => boolean) | undefined;
            readonly separator?: string | undefined;
            readonly showAllLevels?: boolean | undefined;
            readonly collapseTags?: boolean | undefined;
            readonly maxCollapseTags?: number | undefined;
            readonly collapseTagsTooltip?: boolean | undefined;
            readonly maxCollapseTagsTooltipHeight?: (string | number) | undefined;
            readonly debounce?: number | undefined;
            readonly beforeFilter?: ((value: string) => boolean | Promise<any>) | undefined;
            readonly placement?: import('element-plus').Placement | undefined;
            readonly fallbackPlacements?: import('element-plus').Placement[] | undefined;
            readonly popperClass?: import('element-plus/es/utils/typescript.mjs').ClassValue;
            readonly popperStyle?: import('vue').StyleValue;
            readonly teleported?: boolean | undefined;
            readonly effect?: import('element-plus').PopperEffect | undefined;
            readonly tagType?: import('element-plus').TagProps["type"];
            readonly tagEffect?: import('element-plus').TagProps["effect"];
            readonly validateEvent?: boolean | undefined;
            readonly persistent?: boolean | undefined;
            readonly showCheckedStrategy?: ("parent" | "child") | undefined;
            readonly checkOnClickNode?: boolean | undefined;
            readonly showPrefix?: boolean | undefined;
            readonly fitInputWidth?: (boolean | number) | undefined;
            readonly modelValue?: (CascaderValue | null) | undefined;
            readonly options?: import('element-plus').CascaderOption[] | undefined;
            readonly props?: CascaderProps | undefined;
            readonly virtualScroll?: boolean | undefined;
            readonly itemSize?: number | undefined;
            readonly height?: number | undefined;
            readonly emptyValues?: unknown[] | undefined;
            readonly valueOnClear?: (string | number | boolean | Function | null) | undefined;
            readonly onClear?: (() => any) | undefined;
            readonly "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
            readonly onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
            readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
            readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
            readonly onVisibleChange?: ((val: boolean) => any) | undefined;
            readonly onExpandChange?: ((val: CascaderValue) => any) | undefined;
            readonly onRemoveTag?: ((val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: CascaderValue | null | undefined) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "clear") => void) & ((event: "update:modelValue", value: CascaderValue | null | undefined) => void) & ((event: "removeTag", val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => void) & ((event: "visibleChange", val: boolean) => void) & ((event: "expandChange", val: CascaderValue) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').CascaderComponentProps> & Readonly<{
            onClear?: (() => any) | undefined;
            "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
            onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onVisibleChange?: ((val: boolean) => any) | undefined;
            onExpandChange?: ((val: CascaderValue) => any) | undefined;
            onRemoveTag?: ((val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => any) | undefined;
        }>, {
            getCheckedNodes: (leafOnly: boolean) => import('element-plus').CascaderNode[] | undefined;
            cascaderPanelRef: import('vue').Ref<import('element-plus').CascaderPanelInstance | undefined, import('element-plus').CascaderPanelInstance | undefined>;
            togglePopperVisible: (visible?: boolean) => void;
            contentRef: import('vue').ComputedRef<HTMLElement | undefined>;
            presentText: import('vue').ComputedRef<string>;
            focus: () => void;
            blur: () => void;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            clear: () => void;
            "update:modelValue": (value: CascaderValue | null | undefined) => void;
            change: (value: CascaderValue | null | undefined) => void;
            blur: (evt: FocusEvent) => void;
            focus: (evt: FocusEvent) => void;
            visibleChange: (val: boolean) => void;
            expandChange: (val: CascaderValue) => void;
            removeTag: (val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => void;
        }, string, {
            props: CascaderProps;
            disabled: boolean;
            filterMethod: (node: import('element-plus').CascaderNode, keyword: string) => boolean;
            height: number;
            itemSize: number;
            separator: string;
            validateEvent: boolean;
            options: import('element-plus').CascaderOption[];
            valueOnClear: string | number | boolean | Function | null;
            teleported: boolean;
            effect: import('element-plus').PopperEffect;
            clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
            popperClass: string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[] | null;
            popperStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
            fallbackPlacements: import('element-plus').Placement[];
            placement: import('element-plus').Placement;
            persistent: boolean;
            debounce: number;
            showPrefix: boolean;
            showAllLevels: boolean;
            maxCollapseTags: number;
            beforeFilter: (value: string) => boolean | Promise<any>;
            tagType: "info" | "primary" | "success" | "warning" | "danger";
            tagEffect: "dark" | "light" | "plain";
            showCheckedStrategy: "parent" | "child";
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        props: CascaderProps;
        disabled: boolean;
        filterMethod: (node: import('element-plus').CascaderNode, keyword: string) => boolean;
        height: number;
        itemSize: number;
        separator: string;
        validateEvent: boolean;
        options: import('element-plus').CascaderOption[];
        valueOnClear: string | number | boolean | Function | null;
        teleported: boolean;
        effect: import('element-plus').PopperEffect;
        clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
        popperClass: string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[] | null;
        popperStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
        fallbackPlacements: import('element-plus').Placement[];
        placement: import('element-plus').Placement;
        persistent: boolean;
        debounce: number;
        showPrefix: boolean;
        showAllLevels: boolean;
        maxCollapseTags: number;
        beforeFilter: (value: string) => boolean | Promise<any>;
        tagType: "info" | "primary" | "success" | "warning" | "danger";
        tagEffect: "dark" | "light" | "plain";
        showCheckedStrategy: "parent" | "child";
    }> & Omit<Readonly<import('element-plus').CascaderComponentProps> & Readonly<{
        onClear?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((value: CascaderValue | null | undefined) => any) | undefined;
        onChange?: ((value: CascaderValue | null | undefined) => any) | undefined;
        onBlur?: ((evt: FocusEvent) => any) | undefined;
        onFocus?: ((evt: FocusEvent) => any) | undefined;
        onVisibleChange?: ((val: boolean) => any) | undefined;
        onExpandChange?: ((val: CascaderValue) => any) | undefined;
        onRemoveTag?: ((val: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodePathValue) => any) | undefined;
    }>, "blur" | "focus" | "props" | "disabled" | "effect" | "debounce" | "clearIcon" | "validateEvent" | "placement" | "separator" | "height" | "valueOnClear" | "persistent" | "popperClass" | "popperStyle" | "fallbackPlacements" | "teleported" | "options" | "contentRef" | "filterMethod" | "maxCollapseTags" | "tagType" | "tagEffect" | "showAllLevels" | "beforeFilter" | "showCheckedStrategy" | "showPrefix" | "itemSize" | "getCheckedNodes" | "cascaderPanelRef" | "togglePopperVisible" | "presentText"> & {
        getCheckedNodes: (leafOnly: boolean) => import('element-plus').CascaderNode[] | undefined;
        cascaderPanelRef: import('element-plus').CascaderPanelInstance | undefined;
        togglePopperVisible: (visible?: boolean) => void;
        contentRef: HTMLElement | undefined;
        presentText: string;
        focus: () => void;
        blur: () => void;
    } & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            prefix?: (props: {}) => any;
        } & {
            tag?: (props: {
                data: {
                    node?: {
                        readonly uid: number;
                        readonly level: number;
                        readonly value: import('element-plus').CascaderNodeValue;
                        readonly label: string;
                        readonly pathNodes: any[];
                        readonly pathValues: import('element-plus').CascaderNodeValue[];
                        readonly pathLabels: string[];
                        childrenData: {
                            [x: string]: unknown;
                            label?: string | undefined;
                            value?: import('element-plus').CascaderNodeValue | undefined;
                            children?: any[] | undefined;
                            disabled?: boolean | undefined;
                            leaf?: boolean | undefined;
                        }[] | undefined;
                        children: any[];
                        text: string;
                        loaded: boolean;
                        checked: boolean;
                        indeterminate: boolean;
                        loading: boolean;
                        readonly data: {
                            [x: string]: unknown;
                            label?: string | undefined;
                            value?: import('element-plus').CascaderNodeValue | undefined;
                            children?: any[] | undefined;
                            disabled?: boolean | undefined;
                            leaf?: boolean | undefined;
                        };
                        readonly config: {
                            expandTrigger: import('element-plus').ExpandTrigger;
                            multiple: boolean;
                            checkStrictly: boolean;
                            emitPath: boolean;
                            lazy: boolean;
                            lazyLoad: import('element-plus').LazyLoad;
                            value: string;
                            label: string;
                            children: string;
                            disabled: string | import('element-plus').isDisabled;
                            leaf: string | import('element-plus').isLeaf;
                            hoverThreshold: number;
                            checkOnClickNode: boolean;
                            checkOnClickLeaf: boolean;
                            showPrefix: boolean;
                        };
                        readonly parent?: any | undefined;
                        readonly root: boolean;
                        readonly isDisabled: boolean;
                        readonly isLeaf: boolean;
                        readonly valueByOption: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodeValue[];
                        appendChild: (childData: import('element-plus').CascaderOption) => import('element-plus').CascaderNode;
                        calcText: (allLevels: boolean, separator: string) => string;
                        broadcast: (checked: boolean) => void;
                        emit: () => void;
                        onParentCheck: (checked: boolean) => void;
                        onChildCheck: () => void;
                        setCheckState: (checked: boolean) => void;
                        doCheck: (checked: boolean) => void;
                    } | undefined;
                    key: number;
                    text: string;
                    hitState?: boolean | undefined;
                    closable: boolean;
                }[];
                deleteTag: (tag: import('element-plus').Tag) => void;
            }) => any;
        } & {
            header?: (props: {}) => any;
        } & {
            empty?: (props: {}) => any;
        } & {
            'suggestion-item'?: (props: {
                item: {
                    readonly uid: number;
                    readonly level: number;
                    readonly value: import('element-plus').CascaderNodeValue;
                    readonly label: string;
                    readonly pathNodes: any[];
                    readonly pathValues: import('element-plus').CascaderNodeValue[];
                    readonly pathLabels: string[];
                    childrenData: {
                        [x: string]: unknown;
                        label?: string | undefined;
                        value?: import('element-plus').CascaderNodeValue | undefined;
                        children?: any[] | undefined;
                        disabled?: boolean | undefined;
                        leaf?: boolean | undefined;
                    }[] | undefined;
                    children: any[];
                    text: string;
                    loaded: boolean;
                    checked: boolean;
                    indeterminate: boolean;
                    loading: boolean;
                    readonly data: {
                        [x: string]: unknown;
                        label?: string | undefined;
                        value?: import('element-plus').CascaderNodeValue | undefined;
                        children?: any[] | undefined;
                        disabled?: boolean | undefined;
                        leaf?: boolean | undefined;
                    };
                    readonly config: {
                        expandTrigger: import('element-plus').ExpandTrigger;
                        multiple: boolean;
                        checkStrictly: boolean;
                        emitPath: boolean;
                        lazy: boolean;
                        lazyLoad: import('element-plus').LazyLoad;
                        value: string;
                        label: string;
                        children: string;
                        disabled: string | import('element-plus').isDisabled;
                        leaf: string | import('element-plus').isLeaf;
                        hoverThreshold: number;
                        checkOnClickNode: boolean;
                        checkOnClickLeaf: boolean;
                        showPrefix: boolean;
                    };
                    readonly parent?: any | undefined;
                    readonly root: boolean;
                    readonly isDisabled: boolean;
                    readonly isLeaf: boolean;
                    readonly valueByOption: import('element-plus').CascaderNodeValue | import('element-plus').CascaderNodeValue[];
                    appendChild: (childData: import('element-plus').CascaderOption) => import('element-plus').CascaderNode;
                    calcText: (allLevels: boolean, separator: string) => string;
                    broadcast: (checked: boolean) => void;
                    emit: () => void;
                    onParentCheck: (checked: boolean) => void;
                    onChildCheck: () => void;
                    setCheckState: (checked: boolean) => void;
                    doCheck: (checked: boolean) => void;
                };
            }) => any;
        } & {
            empty?: (props: {}) => any;
        } & {
            'suggestion-item'?: (props: {
                item: any;
            }) => any;
        } & {
            empty?: (props: {}) => any;
        } & {
            footer?: (props: {}) => any;
        };
    }) | null;
}, any>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
