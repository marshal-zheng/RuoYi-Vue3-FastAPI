import { ChoiceOption } from './choice-control';
type CheckboxValue = string | number;
type __VLS_Props = {
    modelValue?: CheckboxValue[] | null;
    options?: readonly (Omit<ChoiceOption, 'value'> & {
        value: CheckboxValue;
    })[];
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: CheckboxValue[]) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: CheckboxValue[]) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    group: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: {
            readonly modelValue?: import('element-plus').CheckboxGroupValueType | undefined;
            readonly disabled?: boolean | undefined;
            readonly min?: number | undefined;
            readonly max?: number | undefined;
            readonly size?: import('element-plus').ComponentSize | undefined;
            readonly fill?: string | undefined;
            readonly textColor?: string | undefined;
            readonly tag?: string | undefined;
            readonly validateEvent?: boolean | undefined;
            readonly options?: import('element-plus').CheckboxOption[] | undefined;
            readonly props?: {
                value?: string;
                label?: string;
                disabled?: string;
            } | undefined;
            readonly type?: ("checkbox" | "button") | undefined;
            readonly ariaLabel?: string | undefined;
            readonly "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxGroupValueType) => any) | undefined;
            readonly onChange?: ((val: import('element-plus').CheckboxValueType[]) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "change", val: import('element-plus').CheckboxValueType[]) => void) & ((event: "update:modelValue", val: import('element-plus').CheckboxGroupValueType) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').CheckboxGroupProps> & Readonly<{
            "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxGroupValueType) => any) | undefined;
            onChange?: ((val: import('element-plus').CheckboxValueType[]) => any) | undefined;
        }>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (val: import('element-plus').CheckboxGroupValueType) => void;
            change: (val: import('element-plus').CheckboxValueType[]) => void;
        }, string, {
            type: "checkbox" | "button";
            props: {
                value?: string;
                label?: string;
                disabled?: string;
            };
            disabled: boolean;
            modelValue: import('element-plus').CheckboxGroupValueType;
            tag: string;
            validateEvent: boolean;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        type: "checkbox" | "button";
        props: {
            value?: string;
            label?: string;
            disabled?: string;
        };
        disabled: boolean;
        modelValue: import('element-plus').CheckboxGroupValueType;
        tag: string;
        validateEvent: boolean;
    }> & Omit<Readonly<import('element-plus').CheckboxGroupProps> & Readonly<{
        "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxGroupValueType) => any) | undefined;
        onChange?: ((val: import('element-plus').CheckboxValueType[]) => any) | undefined;
    }>, "props" | "type" | "tag" | "disabled" | "modelValue" | "validateEvent"> & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | null;
}, any>;
export default _default;
