import { ChoiceValue } from './choice-control';
type __VLS_Props = {
    modelValue?: ChoiceValue | null;
    trueValue?: string | number;
    falseValue?: string | number;
    disabled?: boolean;
    readonly?: boolean;
};
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: {
        default?(_: {}): any;
    };
    refs: {
        input: ({
            $: import('vue').ComponentInternalInstance;
            $data: {};
            $props: {
                readonly modelValue?: (number | string | boolean) | undefined;
                readonly label?: (string | boolean | number | object) | undefined;
                readonly value?: (string | boolean | number | object) | undefined;
                readonly indeterminate?: boolean | undefined;
                readonly disabled?: boolean | undefined;
                readonly checked?: boolean | undefined;
                readonly name?: string | undefined;
                readonly trueValue?: (string | number) | undefined;
                readonly falseValue?: (string | number) | undefined;
                readonly trueLabel?: (string | number) | undefined;
                readonly falseLabel?: (string | number) | undefined;
                readonly id?: string | undefined;
                readonly border?: boolean | undefined;
                readonly size?: import('element-plus').ComponentSize | undefined;
                readonly tabindex?: (string | number) | undefined;
                readonly validateEvent?: boolean | undefined;
                readonly ariaLabel?: string | undefined;
                readonly ariaControls?: string | undefined;
                readonly "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
                readonly onChange?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
            } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
            $attrs: import('vue').Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import('vue').Slot<any> | undefined;
            }>;
            $root: import('vue').ComponentPublicInstance | null;
            $parent: import('vue').ComponentPublicInstance | null;
            $host: Element | null;
            $emit: ((event: "change", val: import('element-plus').CheckboxValueType) => void) & ((event: "update:modelValue", val: import('element-plus').CheckboxValueType) => void);
            $el: any;
            $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').CheckboxProps> & Readonly<{
                "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
                onChange?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
            }>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                "update:modelValue": (val: import('element-plus').CheckboxValueType) => void;
                change: (val: import('element-plus').CheckboxValueType) => void;
            }, string, {
                id: string;
                label: string | boolean | number | object;
                disabled: boolean;
                name: string;
                modelValue: number | string | boolean;
                validateEvent: boolean;
                value: string | boolean | number | object;
                trueValue: string | number;
                falseValue: string | number;
                trueLabel: string | number;
                falseLabel: string | number;
            }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof import('vue').nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
        } & Readonly<{
            id: string;
            label: string | boolean | number | object;
            disabled: boolean;
            name: string;
            modelValue: number | string | boolean;
            validateEvent: boolean;
            value: string | boolean | number | object;
            trueValue: string | number;
            falseValue: string | number;
            trueLabel: string | number;
            falseLabel: string | number;
        }> & Omit<Readonly<import('element-plus').CheckboxProps> & Readonly<{
            "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
            onChange?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
        }>, "name" | "label" | "id" | "value" | "disabled" | "modelValue" | "validateEvent" | "trueValue" | "falseValue" | "trueLabel" | "falseLabel"> & {} & import('vue').ComponentCustomProperties & {} & {
            $slots: {
                default?: (props: {}) => any;
            };
        }) | null;
    };
    rootEl: any;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: ChoiceValue) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: ChoiceValue) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    input: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: {
            readonly modelValue?: (number | string | boolean) | undefined;
            readonly label?: (string | boolean | number | object) | undefined;
            readonly value?: (string | boolean | number | object) | undefined;
            readonly indeterminate?: boolean | undefined;
            readonly disabled?: boolean | undefined;
            readonly checked?: boolean | undefined;
            readonly name?: string | undefined;
            readonly trueValue?: (string | number) | undefined;
            readonly falseValue?: (string | number) | undefined;
            readonly trueLabel?: (string | number) | undefined;
            readonly falseLabel?: (string | number) | undefined;
            readonly id?: string | undefined;
            readonly border?: boolean | undefined;
            readonly size?: import('element-plus').ComponentSize | undefined;
            readonly tabindex?: (string | number) | undefined;
            readonly validateEvent?: boolean | undefined;
            readonly ariaLabel?: string | undefined;
            readonly ariaControls?: string | undefined;
            readonly "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
            readonly onChange?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "change", val: import('element-plus').CheckboxValueType) => void) & ((event: "update:modelValue", val: import('element-plus').CheckboxValueType) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').CheckboxProps> & Readonly<{
            "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
            onChange?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
        }>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (val: import('element-plus').CheckboxValueType) => void;
            change: (val: import('element-plus').CheckboxValueType) => void;
        }, string, {
            id: string;
            label: string | boolean | number | object;
            disabled: boolean;
            name: string;
            modelValue: number | string | boolean;
            validateEvent: boolean;
            value: string | boolean | number | object;
            trueValue: string | number;
            falseValue: string | number;
            trueLabel: string | number;
            falseLabel: string | number;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        id: string;
        label: string | boolean | number | object;
        disabled: boolean;
        name: string;
        modelValue: number | string | boolean;
        validateEvent: boolean;
        value: string | boolean | number | object;
        trueValue: string | number;
        falseValue: string | number;
        trueLabel: string | number;
        falseLabel: string | number;
    }> & Omit<Readonly<import('element-plus').CheckboxProps> & Readonly<{
        "onUpdate:modelValue"?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
        onChange?: ((val: import('element-plus').CheckboxValueType) => any) | undefined;
    }>, "name" | "label" | "id" | "value" | "disabled" | "modelValue" | "validateEvent" | "trueValue" | "falseValue" | "trueLabel" | "falseLabel"> & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | null;
}, any>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
