import { Json } from '../types';
export declare const booleanProp: (value: Json) => value is boolean;
export declare const textProp: (value: Json) => value is string;
export declare const scalarProp: (value: Json) => boolean;
export declare const choiceKeyProp: (value: Json) => boolean;
export declare const checkboxOptionsProp: (value: Json) => boolean;
/** The JSON profile accepts a bounded standard tree, not executable mappings. */
export declare function treeDataProp(unique: boolean): (value: Json) => boolean;
export declare const cascaderProps: (value: Json) => boolean;
