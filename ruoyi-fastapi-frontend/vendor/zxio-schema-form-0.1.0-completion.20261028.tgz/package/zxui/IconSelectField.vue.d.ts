import { nextTick } from 'vue';
type __VLS_Props = {
    modelValue?: string | null;
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus(): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: string) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    picker: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
        readonly modelValue: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly sources: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconSource[]) | (() => import('@zxio/zxui/icon-select').IconSource[]) | {
            (): import('@zxio/zxui/icon-select').IconSource[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconSource[]) | (() => import('@zxio/zxui/icon-select').IconSource[]) | {
            (): import('@zxio/zxui/icon-select').IconSource[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => string[], boolean>;
        readonly iconifyCollections: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | {
            (): string[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string[]) | (() => string[]) | {
            (): string[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly customIcons: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconMeta[]) | (() => import('@zxio/zxui/icon-select').IconMeta[]) | {
            (): import('@zxio/zxui/icon-select').IconMeta[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconMeta[]) | (() => import('@zxio/zxui/icon-select').IconMeta[]) | {
            (): import('@zxio/zxui/icon-select').IconMeta[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly tabMode: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "source", boolean>;
        readonly showTabs: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly categories: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconCategory[]) | (() => import('@zxio/zxui/icon-select').IconCategory[]) | {
            (): import('@zxio/zxui/icon-select').IconCategory[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconCategory[]) | (() => import('@zxio/zxui/icon-select').IconCategory[]) | {
            (): import('@zxio/zxui/icon-select').IconCategory[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly columns: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
        readonly itemHeight: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 48, boolean>;
        readonly panelHeight: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 280, boolean>;
        readonly panelMode: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "popover", boolean>;
        readonly popoverWidth: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 540, boolean>;
        readonly placement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "bottom-start", boolean>;
        readonly showArrow: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly allowModeSwitch: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly destroyOnClose: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly searchable: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly searchPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "panel", boolean>;
        readonly showRecent: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showFooter: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly recentMax: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
        readonly recentScope: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "global", boolean>;
        readonly recentScopeKey: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly recentScopeResolver: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | (() => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | {
            (): (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | (() => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | {
            (): (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly recentSaveStrategy: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "select", boolean>;
        readonly confirmText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "OK", boolean>;
        readonly recentKey: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "zx-icon-select-recent", boolean>;
        readonly recentKeyPrefix: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly recentStorage: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconSelectStorage) | (() => import('@zxio/zxui/icon-select').IconSelectStorage) | {
            (): import('@zxio/zxui/icon-select').IconSelectStorage;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconSelectStorage) | (() => import('@zxio/zxui/icon-select').IconSelectStorage) | {
            (): import('@zxio/zxui/icon-select').IconSelectStorage;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly triggerMode: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "input", boolean>;
        readonly triggerSize: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 36, boolean>;
        readonly clearable: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly disabled: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly placeholder: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "点击选择图标", boolean>;
    }>> & Readonly<{
        onChange?: ((value: string) => any) | undefined;
        onClear?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        onConfirm?: (() => any) | undefined;
        "onRecent-change"?: ((icons: string[], _scopeKey: string) => any) | undefined;
    }>, {
        open: () => void;
        close: () => void;
    }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
        change: (value: string) => void;
        clear: () => void;
        "update:modelValue": (value: string) => void;
        confirm: () => void;
        "recent-change": (icons: string[], _scopeKey: string) => void;
    }, import('vue').PublicProps, {
        readonly placeholder: string;
        readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly columns: number;
        readonly modelValue: string;
        readonly clearable: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly showArrow: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showFooter: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly destroyOnClose: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly sources: import('@zxio/zxui/icon-select').IconSource[];
        readonly iconifyCollections: string[];
        readonly customIcons: import('@zxio/zxui/icon-select').IconMeta[];
        readonly tabMode: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly showTabs: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly categories: import('@zxio/zxui/icon-select').IconCategory[];
        readonly itemHeight: number;
        readonly panelHeight: number;
        readonly panelMode: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly popoverWidth: number;
        readonly allowModeSwitch: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly searchable: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly searchPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly showRecent: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly recentMax: number;
        readonly recentScope: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly recentScopeKey: string;
        readonly recentScopeResolver: (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
        readonly recentSaveStrategy: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly confirmText: string;
        readonly recentKey: string;
        readonly recentKeyPrefix: string;
        readonly recentStorage: import('@zxio/zxui/icon-select').IconSelectStorage;
        readonly triggerMode: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly triggerSize: number;
    }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {
        panelRef: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<{
            modelValue?: string;
            sources?: import('@zxio/zxui/icon-select').IconSource[];
            iconifyCollections?: string[];
            customIcons?: import('@zxio/zxui/icon-select').IconMeta[];
            tabMode?: import('@zxio/zxui/icon-select').IconTabMode;
            searchPlacement?: import('@zxio/zxui/icon-select').IconSearchPlacement;
            showTabs?: boolean;
            categories?: import('@zxio/zxui/icon-select').IconCategory[];
            recentKey?: string;
            recentKeyPrefix?: string;
            recentStorage?: import('@zxio/zxui/icon-select').IconSelectStorage;
            recentScope?: "global" | "source" | "category" | "custom";
            recentScopeKey?: string;
            recentScopeResolver?: (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
            recentSaveStrategy?: "select" | "confirm" | "close";
            confirmText?: string;
            columns?: number;
            itemHeight?: number;
            panelHeight?: number;
            searchable?: boolean;
            showRecent?: boolean;
            showFooter?: boolean;
            recentMax?: number;
            allowModeSwitch?: boolean;
            panelMode?: "popover" | "dialog";
        }> & Readonly<{
            onClose?: (() => any) | undefined;
            onSelect?: ((iconName: string) => any) | undefined;
            onConfirm?: (() => any) | undefined;
            "onSwitch-mode"?: (() => any) | undefined;
            "onCount-change"?: ((count: number) => any) | undefined;
            "onRecent-change"?: ((icons: string[], scopeKey: string) => any) | undefined;
        }>, {
            focusSearch: () => void;
            resetScroll: () => void;
            setSearchValue: (value: string) => void;
            clearSearchValue: () => void;
            commitRecent: () => void;
            filteredCount: import('vue').ComputedRef<number>;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
            close: () => any;
            select: (iconName: string) => any;
            confirm: () => any;
            "switch-mode": () => any;
            "count-change": (count: number) => any;
            "recent-change": (icons: string[], scopeKey: string) => any;
        }, import('vue').PublicProps, {}, false, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {
            searchInputRef: ({
                $: import('vue').ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly id?: string | undefined;
                    readonly size?: import('element-plus').ComponentSize | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly modelValue?: string | number | null | undefined;
                    readonly modelModifiers?: import('element-plus').InputModelModifiers | undefined;
                    readonly maxlength?: (string | number) | undefined;
                    readonly minlength?: (string | number) | undefined;
                    readonly type?: import('element-plus').InputType | undefined;
                    readonly resize?: ("none" | "both" | "horizontal" | "vertical") | undefined;
                    readonly autosize?: import('element-plus').InputAutoSize | undefined;
                    readonly autocomplete?: string | undefined;
                    readonly formatter?: ((value: string) => string) | undefined;
                    readonly parser?: ((value: string) => string) | undefined;
                    readonly placeholder?: string | undefined;
                    readonly form?: string | undefined;
                    readonly readonly?: boolean | undefined;
                    readonly clearable?: boolean | undefined;
                    readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                    readonly showPassword?: boolean | undefined;
                    readonly showWordLimit?: boolean | undefined;
                    readonly wordLimitPosition?: ("inside" | "outside") | undefined;
                    readonly suffixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                    readonly prefixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                    readonly containerRole?: string | undefined;
                    readonly tabindex?: (string | number) | undefined;
                    readonly validateEvent?: boolean | undefined;
                    readonly inputStyle?: import('vue').StyleValue;
                    readonly autofocus?: boolean | undefined;
                    readonly rows?: number | undefined;
                    readonly ariaLabel?: string | undefined;
                    readonly inputmode?: import('vue').HTMLAttributes["inputmode"];
                    readonly name?: string | undefined;
                    readonly countGraphemes?: ((value: string) => number) | undefined;
                    readonly onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                    readonly "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                    readonly onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                    readonly onInput?: ((value: string) => any) | undefined;
                    readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                    readonly onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                    readonly onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                    readonly onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                    readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                    readonly onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                    readonly onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                    readonly onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
                $attrs: import('vue').Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import('vue').Slot<any> | undefined;
                }>;
                $root: import('vue').ComponentPublicInstance | null;
                $parent: import('vue').ComponentPublicInstance | null;
                $host: Element | null;
                $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: string, evt?: Event | undefined) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "input", value: string) => void) & ((event: "keydown", evt: Event | KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear", evt: MouseEvent | undefined) => void) & ((event: "update:modelValue", value: string) => void);
                $el: any;
                $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').InputProps> & Readonly<{
                    onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                    onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                    onInput?: ((value: string) => any) | undefined;
                    onBlur?: ((evt: FocusEvent) => any) | undefined;
                    onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                    onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                    onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                    onFocus?: ((evt: FocusEvent) => any) | undefined;
                    onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                    onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                    onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                }>, {
                    input: import('vue').ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
                    textarea: import('vue').ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
                    ref: import('vue').ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
                    textareaStyle: import('vue').ComputedRef<import('vue').StyleValue>;
                    autosize: import('vue').Ref<import('element-plus').InputAutoSize | undefined, import('element-plus').InputAutoSize | undefined>;
                    isComposing: import('vue').Ref<boolean, boolean>;
                    passwordVisible: import('vue').Ref<boolean, boolean>;
                    focus: () => void | undefined;
                    blur: () => void | undefined;
                    select: () => void;
                    clear: (evt?: MouseEvent) => void;
                    resizeTextarea: () => void;
                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                    clear: (evt: MouseEvent | undefined) => void;
                    "update:modelValue": (value: string) => void;
                    change: (value: string, evt?: Event | undefined) => void;
                    input: (value: string) => void;
                    blur: (evt: FocusEvent) => void;
                    compositionend: (evt: CompositionEvent) => void;
                    compositionstart: (evt: CompositionEvent) => void;
                    compositionupdate: (evt: CompositionEvent) => void;
                    focus: (evt: FocusEvent) => void;
                    keydown: (evt: Event | KeyboardEvent) => void;
                    mouseenter: (evt: MouseEvent) => void;
                    mouseleave: (evt: MouseEvent) => void;
                }, string, {
                    type: import('element-plus').InputType;
                    disabled: boolean;
                    modelValue: string | number | null;
                    validateEvent: boolean;
                    modelModifiers: import('element-plus').InputModelModifiers;
                    autocomplete: string;
                    clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                    wordLimitPosition: "inside" | "outside";
                    tabindex: string | number;
                    inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                    rows: number;
                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
            } & Readonly<{
                type: import('element-plus').InputType;
                disabled: boolean;
                modelValue: string | number | null;
                validateEvent: boolean;
                modelModifiers: import('element-plus').InputModelModifiers;
                autocomplete: string;
                clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                wordLimitPosition: "inside" | "outside";
                tabindex: string | number;
                inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                rows: number;
            }> & Omit<Readonly<import('element-plus').InputProps> & Readonly<{
                onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                onInput?: ((value: string) => any) | undefined;
                onBlur?: ((evt: FocusEvent) => any) | undefined;
                onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                onFocus?: ((evt: FocusEvent) => any) | undefined;
                onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                onMouseleave?: ((evt: MouseEvent) => any) | undefined;
            }>, "blur" | "focus" | "input" | "select" | "type" | "clear" | "textarea" | "ref" | "disabled" | "tabindex" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "clearIcon" | "wordLimitPosition" | "validateEvent" | "inputStyle" | "rows" | "textareaStyle" | "isComposing" | "passwordVisible" | "resizeTextarea"> & {
                input: HTMLInputElement | undefined;
                textarea: HTMLTextAreaElement | undefined;
                ref: HTMLInputElement | HTMLTextAreaElement | undefined;
                textareaStyle: import('vue').StyleValue;
                autosize: import('element-plus').InputAutoSize | undefined;
                isComposing: boolean;
                passwordVisible: boolean;
                focus: () => void | undefined;
                blur: () => void | undefined;
                select: () => void;
                clear: (evt?: MouseEvent) => void;
                resizeTextarea: () => void;
            } & {} & import('vue').ComponentCustomProperties & {} & {
                $slots: {
                    prepend?: (props: {}) => any;
                } & {
                    prefix?: (props: {}) => any;
                } & {
                    suffix?: (props: {}) => any;
                } & {
                    'password-icon'?: (props: {
                        visible: boolean;
                    }) => any;
                } & {
                    append?: (props: {}) => any;
                };
            }) | null;
            gridContainerRef: HTMLDivElement;
        }, HTMLDivElement, import('vue').ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<{
            modelValue?: string;
            sources?: import('@zxio/zxui/icon-select').IconSource[];
            iconifyCollections?: string[];
            customIcons?: import('@zxio/zxui/icon-select').IconMeta[];
            tabMode?: import('@zxio/zxui/icon-select').IconTabMode;
            searchPlacement?: import('@zxio/zxui/icon-select').IconSearchPlacement;
            showTabs?: boolean;
            categories?: import('@zxio/zxui/icon-select').IconCategory[];
            recentKey?: string;
            recentKeyPrefix?: string;
            recentStorage?: import('@zxio/zxui/icon-select').IconSelectStorage;
            recentScope?: "global" | "source" | "category" | "custom";
            recentScopeKey?: string;
            recentScopeResolver?: (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
            recentSaveStrategy?: "select" | "confirm" | "close";
            confirmText?: string;
            columns?: number;
            itemHeight?: number;
            panelHeight?: number;
            searchable?: boolean;
            showRecent?: boolean;
            showFooter?: boolean;
            recentMax?: number;
            allowModeSwitch?: boolean;
            panelMode?: "popover" | "dialog";
        }> & Readonly<{
            onClose?: (() => any) | undefined;
            onSelect?: ((iconName: string) => any) | undefined;
            onConfirm?: (() => any) | undefined;
            "onSwitch-mode"?: (() => any) | undefined;
            "onCount-change"?: ((count: number) => any) | undefined;
            "onRecent-change"?: ((icons: string[], scopeKey: string) => any) | undefined;
        }>, {
            focusSearch: () => void;
            resetScroll: () => void;
            setSearchValue: (value: string) => void;
            clearSearchValue: () => void;
            commitRecent: () => void;
            filteredCount: import('vue').ComputedRef<number>;
        }, {}, {}, {}, {}> | null;
        dialogSearchInputRef: ({
            $: import('vue').ComponentInternalInstance;
            $data: {};
            $props: {
                readonly id?: string | undefined;
                readonly size?: import('element-plus').ComponentSize | undefined;
                readonly disabled?: boolean | undefined;
                readonly modelValue?: string | number | null | undefined;
                readonly modelModifiers?: import('element-plus').InputModelModifiers | undefined;
                readonly maxlength?: (string | number) | undefined;
                readonly minlength?: (string | number) | undefined;
                readonly type?: import('element-plus').InputType | undefined;
                readonly resize?: ("none" | "both" | "horizontal" | "vertical") | undefined;
                readonly autosize?: import('element-plus').InputAutoSize | undefined;
                readonly autocomplete?: string | undefined;
                readonly formatter?: ((value: string) => string) | undefined;
                readonly parser?: ((value: string) => string) | undefined;
                readonly placeholder?: string | undefined;
                readonly form?: string | undefined;
                readonly readonly?: boolean | undefined;
                readonly clearable?: boolean | undefined;
                readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                readonly showPassword?: boolean | undefined;
                readonly showWordLimit?: boolean | undefined;
                readonly wordLimitPosition?: ("inside" | "outside") | undefined;
                readonly suffixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                readonly prefixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                readonly containerRole?: string | undefined;
                readonly tabindex?: (string | number) | undefined;
                readonly validateEvent?: boolean | undefined;
                readonly inputStyle?: import('vue').StyleValue;
                readonly autofocus?: boolean | undefined;
                readonly rows?: number | undefined;
                readonly ariaLabel?: string | undefined;
                readonly inputmode?: import('vue').HTMLAttributes["inputmode"];
                readonly name?: string | undefined;
                readonly countGraphemes?: ((value: string) => number) | undefined;
                readonly onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                readonly "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                readonly onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                readonly onInput?: ((value: string) => any) | undefined;
                readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                readonly onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                readonly onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                readonly onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                readonly onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                readonly onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                readonly onMouseleave?: ((evt: MouseEvent) => any) | undefined;
            } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
            $attrs: import('vue').Attrs;
            $refs: {
                [x: string]: unknown;
            };
            $slots: Readonly<{
                [name: string]: import('vue').Slot<any> | undefined;
            }>;
            $root: import('vue').ComponentPublicInstance | null;
            $parent: import('vue').ComponentPublicInstance | null;
            $host: Element | null;
            $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: string, evt?: Event | undefined) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "input", value: string) => void) & ((event: "keydown", evt: Event | KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear", evt: MouseEvent | undefined) => void) & ((event: "update:modelValue", value: string) => void);
            $el: any;
            $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').InputProps> & Readonly<{
                onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                onInput?: ((value: string) => any) | undefined;
                onBlur?: ((evt: FocusEvent) => any) | undefined;
                onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                onFocus?: ((evt: FocusEvent) => any) | undefined;
                onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                onMouseleave?: ((evt: MouseEvent) => any) | undefined;
            }>, {
                input: import('vue').ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
                textarea: import('vue').ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
                ref: import('vue').ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
                textareaStyle: import('vue').ComputedRef<import('vue').StyleValue>;
                autosize: import('vue').Ref<import('element-plus').InputAutoSize | undefined, import('element-plus').InputAutoSize | undefined>;
                isComposing: import('vue').Ref<boolean, boolean>;
                passwordVisible: import('vue').Ref<boolean, boolean>;
                focus: () => void | undefined;
                blur: () => void | undefined;
                select: () => void;
                clear: (evt?: MouseEvent) => void;
                resizeTextarea: () => void;
            }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                clear: (evt: MouseEvent | undefined) => void;
                "update:modelValue": (value: string) => void;
                change: (value: string, evt?: Event | undefined) => void;
                input: (value: string) => void;
                blur: (evt: FocusEvent) => void;
                compositionend: (evt: CompositionEvent) => void;
                compositionstart: (evt: CompositionEvent) => void;
                compositionupdate: (evt: CompositionEvent) => void;
                focus: (evt: FocusEvent) => void;
                keydown: (evt: Event | KeyboardEvent) => void;
                mouseenter: (evt: MouseEvent) => void;
                mouseleave: (evt: MouseEvent) => void;
            }, string, {
                type: import('element-plus').InputType;
                disabled: boolean;
                modelValue: string | number | null;
                validateEvent: boolean;
                modelModifiers: import('element-plus').InputModelModifiers;
                autocomplete: string;
                clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                wordLimitPosition: "inside" | "outside";
                tabindex: string | number;
                inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                rows: number;
            }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                beforeCreate?: (() => void) | (() => void)[];
                created?: (() => void) | (() => void)[];
                beforeMount?: (() => void) | (() => void)[];
                mounted?: (() => void) | (() => void)[];
                beforeUpdate?: (() => void) | (() => void)[];
                updated?: (() => void) | (() => void)[];
                activated?: (() => void) | (() => void)[];
                deactivated?: (() => void) | (() => void)[];
                beforeDestroy?: (() => void) | (() => void)[];
                beforeUnmount?: (() => void) | (() => void)[];
                destroyed?: (() => void) | (() => void)[];
                unmounted?: (() => void) | (() => void)[];
                renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
            };
            $forceUpdate: () => void;
            $nextTick: typeof nextTick;
            $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
        } & Readonly<{
            type: import('element-plus').InputType;
            disabled: boolean;
            modelValue: string | number | null;
            validateEvent: boolean;
            modelModifiers: import('element-plus').InputModelModifiers;
            autocomplete: string;
            clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
            wordLimitPosition: "inside" | "outside";
            tabindex: string | number;
            inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
            rows: number;
        }> & Omit<Readonly<import('element-plus').InputProps> & Readonly<{
            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
            onInput?: ((value: string) => any) | undefined;
            onBlur?: ((evt: FocusEvent) => any) | undefined;
            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
            onFocus?: ((evt: FocusEvent) => any) | undefined;
            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
        }>, "blur" | "focus" | "input" | "select" | "type" | "clear" | "textarea" | "ref" | "disabled" | "tabindex" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "clearIcon" | "wordLimitPosition" | "validateEvent" | "inputStyle" | "rows" | "textareaStyle" | "isComposing" | "passwordVisible" | "resizeTextarea"> & {
            input: HTMLInputElement | undefined;
            textarea: HTMLTextAreaElement | undefined;
            ref: HTMLInputElement | HTMLTextAreaElement | undefined;
            textareaStyle: import('vue').StyleValue;
            autosize: import('element-plus').InputAutoSize | undefined;
            isComposing: boolean;
            passwordVisible: boolean;
            focus: () => void | undefined;
            blur: () => void | undefined;
            select: () => void;
            clear: (evt?: MouseEvent) => void;
            resizeTextarea: () => void;
        } & {} & import('vue').ComponentCustomProperties & {} & {
            $slots: {
                prepend?: (props: {}) => any;
            } & {
                prefix?: (props: {}) => any;
            } & {
                suffix?: (props: {}) => any;
            } & {
                'password-icon'?: (props: {
                    visible: boolean;
                }) => any;
            } & {
                append?: (props: {}) => any;
            };
        }) | null;
    }, HTMLDivElement, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import('vue').ExtractPropTypes<{
        readonly modelValue: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly sources: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconSource[]) | (() => import('@zxio/zxui/icon-select').IconSource[]) | {
            (): import('@zxio/zxui/icon-select').IconSource[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconSource[]) | (() => import('@zxio/zxui/icon-select').IconSource[]) | {
            (): import('@zxio/zxui/icon-select').IconSource[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => string[], boolean>;
        readonly iconifyCollections: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | {
            (): string[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string[]) | (() => string[]) | {
            (): string[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly customIcons: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconMeta[]) | (() => import('@zxio/zxui/icon-select').IconMeta[]) | {
            (): import('@zxio/zxui/icon-select').IconMeta[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconMeta[]) | (() => import('@zxio/zxui/icon-select').IconMeta[]) | {
            (): import('@zxio/zxui/icon-select').IconMeta[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly tabMode: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "source", boolean>;
        readonly showTabs: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly categories: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconCategory[]) | (() => import('@zxio/zxui/icon-select').IconCategory[]) | {
            (): import('@zxio/zxui/icon-select').IconCategory[];
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconCategory[]) | (() => import('@zxio/zxui/icon-select').IconCategory[]) | {
            (): import('@zxio/zxui/icon-select').IconCategory[];
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => never[], boolean>;
        readonly columns: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
        readonly itemHeight: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 48, boolean>;
        readonly panelHeight: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 280, boolean>;
        readonly panelMode: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "popover", boolean>;
        readonly popoverWidth: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 540, boolean>;
        readonly placement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "bottom-start", boolean>;
        readonly showArrow: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly allowModeSwitch: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly destroyOnClose: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly searchable: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly searchPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "panel", boolean>;
        readonly showRecent: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showFooter: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly recentMax: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
        readonly recentScope: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "global", boolean>;
        readonly recentScopeKey: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly recentScopeResolver: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | (() => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | {
            (): (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | (() => (icon: import('@zxio/zxui/icon-select').IconMeta) => string) | {
            (): (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly recentSaveStrategy: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "select", boolean>;
        readonly confirmText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "OK", boolean>;
        readonly recentKey: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "zx-icon-select-recent", boolean>;
        readonly recentKeyPrefix: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly recentStorage: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => import('@zxio/zxui/icon-select').IconSelectStorage) | (() => import('@zxio/zxui/icon-select').IconSelectStorage) | {
            (): import('@zxio/zxui/icon-select').IconSelectStorage;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => import('@zxio/zxui/icon-select').IconSelectStorage) | (() => import('@zxio/zxui/icon-select').IconSelectStorage) | {
            (): import('@zxio/zxui/icon-select').IconSelectStorage;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, undefined, boolean>;
        readonly triggerMode: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "input", boolean>;
        readonly triggerSize: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, 36, boolean>;
        readonly clearable: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly disabled: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly placeholder: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "点击选择图标", boolean>;
    }>> & Readonly<{
        onChange?: ((value: string) => any) | undefined;
        onClear?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        onConfirm?: (() => any) | undefined;
        "onRecent-change"?: ((icons: string[], _scopeKey: string) => any) | undefined;
    }>, {
        open: () => void;
        close: () => void;
    }, {}, {}, {}, {
        readonly placeholder: string;
        readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly columns: number;
        readonly modelValue: string;
        readonly clearable: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | {
            (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly showArrow: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showFooter: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly destroyOnClose: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly sources: import('@zxio/zxui/icon-select').IconSource[];
        readonly iconifyCollections: string[];
        readonly customIcons: import('@zxio/zxui/icon-select').IconMeta[];
        readonly tabMode: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').IconTabMode) | {
            (): import('@zxio/zxui/icon-select').IconTabMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly showTabs: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly categories: import('@zxio/zxui/icon-select').IconCategory[];
        readonly itemHeight: number;
        readonly panelHeight: number;
        readonly panelMode: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
            (): "dialog" | "popover";
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly popoverWidth: number;
        readonly allowModeSwitch: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly searchable: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly searchPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "header" | "panel") | (() => import('@zxio/zxui/icon-select').IconSearchPlacement) | {
            (): import('@zxio/zxui/icon-select').IconSearchPlacement;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly showRecent: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly recentMax: number;
        readonly recentScope: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import('@zxio/zxui/icon-select').RecentScope) | {
            (): import('@zxio/zxui/icon-select').RecentScope;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly recentScopeKey: string;
        readonly recentScopeResolver: (icon: import('@zxio/zxui/icon-select').IconMeta) => string;
        readonly recentSaveStrategy: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "close" | "select" | "confirm") | (() => import('@zxio/zxui/icon-select').RecentSaveStrategy) | {
            (): import('@zxio/zxui/icon-select').RecentSaveStrategy;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly confirmText: string;
        readonly recentKey: string;
        readonly recentKeyPrefix: string;
        readonly recentStorage: import('@zxio/zxui/icon-select').IconSelectStorage;
        readonly triggerMode: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => "input" | "icon") | (() => import('@zxio/zxui/icon-select').TriggerMode) | {
            (): import('@zxio/zxui/icon-select').TriggerMode;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly triggerSize: number;
    }> | null;
}, any>;
export default _default;
