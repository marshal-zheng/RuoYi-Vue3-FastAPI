import { ChoiceValue } from './choice-control';
type __VLS_Props = {
    modelValue?: ChoiceValue | null;
    activeValue?: ChoiceValue;
    inactiveValue?: ChoiceValue;
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: ChoiceValue) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: ChoiceValue) => any) | undefined;
}>, {
    activeValue: ChoiceValue;
    inactiveValue: ChoiceValue;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    input: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: {
            readonly modelValue?: (boolean | string | number) | undefined;
            readonly disabled?: boolean | undefined;
            readonly loading?: boolean | undefined;
            readonly size?: import('element-plus').ComponentSize | undefined;
            readonly width?: (string | number) | undefined;
            readonly inlinePrompt?: boolean | undefined;
            readonly inactiveActionIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
            readonly activeActionIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
            readonly activeIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
            readonly inactiveIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
            readonly activeText?: string | undefined;
            readonly inactiveText?: string | undefined;
            readonly activeValue?: (boolean | string | number) | undefined;
            readonly inactiveValue?: (boolean | string | number) | undefined;
            readonly name?: string | undefined;
            readonly validateEvent?: boolean | undefined;
            readonly beforeChange?: (() => Promise<boolean> | boolean) | undefined;
            readonly id?: string | undefined;
            readonly tabindex?: (string | number) | undefined;
            readonly ariaLabel?: string | undefined;
            readonly "onUpdate:modelValue"?: ((val: string | number | boolean) => any) | undefined;
            readonly onChange?: ((val: string | number | boolean) => any) | undefined;
            readonly onInput?: ((val: string | number | boolean) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "change", val: string | number | boolean) => void) & ((event: "input", val: string | number | boolean) => void) & ((event: "update:modelValue", val: string | number | boolean) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').SwitchProps> & Readonly<{
            "onUpdate:modelValue"?: ((val: string | number | boolean) => any) | undefined;
            onChange?: ((val: string | number | boolean) => any) | undefined;
            onInput?: ((val: string | number | boolean) => any) | undefined;
        }>, {
            focus: () => void;
            checked: import('vue').ComputedRef<boolean>;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (val: string | number | boolean) => void;
            change: (val: string | number | boolean) => void;
            input: (val: string | number | boolean) => void;
        }, string, {
            disabled: boolean;
            width: string | number;
            name: string;
            modelValue: boolean | string | number;
            validateEvent: boolean;
            activeText: string;
            inactiveText: string;
            activeValue: boolean | string | number;
            inactiveValue: boolean | string | number;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        disabled: boolean;
        width: string | number;
        name: string;
        modelValue: boolean | string | number;
        validateEvent: boolean;
        activeText: string;
        inactiveText: string;
        activeValue: boolean | string | number;
        inactiveValue: boolean | string | number;
    }> & Omit<Readonly<import('element-plus').SwitchProps> & Readonly<{
        "onUpdate:modelValue"?: ((val: string | number | boolean) => any) | undefined;
        onChange?: ((val: string | number | boolean) => any) | undefined;
        onInput?: ((val: string | number | boolean) => any) | undefined;
    }>, "name" | "focus" | "disabled" | "modelValue" | "validateEvent" | "width" | "checked" | "activeValue" | "inactiveValue" | "activeText" | "inactiveText"> & {
        focus: () => void;
        checked: boolean;
    } & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            inactive?: (props: {}) => any;
        } & {
            inactive?: (props: {}) => any;
        } & {
            active?: (props: {}) => any;
        } & {
            'active-action'?: (props: {}) => any;
        } & {
            'inactive-action'?: (props: {}) => any;
        } & {
            active?: (props: {}) => any;
        };
    }) | null;
}, any>;
export default _default;
