import { ChoiceNode, ChoiceValue } from './choice-control';
type __VLS_Props = {
    modelValue?: ChoiceValue | ChoiceValue[] | null;
    data?: readonly ChoiceNode[];
    cacheData?: readonly ChoiceNode[];
    nodeKey?: string;
    valueKey?: string;
    props?: Record<string, unknown>;
    disabled?: boolean;
    readonly?: boolean;
    multiple?: boolean;
};
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: Readonly<Record<string, (scope: Record<string, unknown>) => unknown>> & Record<string, (scope: Record<string, unknown>) => unknown>;
    refs: {
        tree: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
            cacheData: {
                type: ArrayConstructor;
                default: () => never[];
            };
            data: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData) | (((new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData)) | null)[], unknown, unknown, () => never[], boolean>;
            emptyText: {
                readonly type: import('vue').PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            nodeKey: StringConstructor;
            checkStrictly: BooleanConstructor;
            defaultExpandAll: BooleanConstructor;
            expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            checkOnClickNode: BooleanConstructor;
            checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            checkDescendants: BooleanConstructor;
            autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            defaultCheckedKeys: {
                readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            defaultExpandedKeys: {
                readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            currentNodeKey: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            renderContent: {
                readonly type: import('vue').PropType<import('element-plus').RenderContentFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            showCheckbox: BooleanConstructor;
            draggable: BooleanConstructor;
            allowDrag: {
                readonly type: import('vue').PropType<import('element-plus').AllowDragFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            allowDrop: {
                readonly type: import('vue').PropType<import('element-plus').AllowDropFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            props: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps) | (((new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps)) | null)[], unknown, unknown, () => {
                children: string;
                label: string;
                disabled: string;
            }, boolean>;
            lazy: BooleanConstructor;
            highlightCurrent: BooleanConstructor;
            load: {
                readonly type: import('vue').PropType<import('element-plus').LoadFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            filterNodeMethod: {
                readonly type: import('vue').PropType<import('element-plus').FilterNodeMethodFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            accordion: BooleanConstructor;
            indent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 18, boolean>;
            icon: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            ariaLabel: StringConstructor;
            emptyValues: ArrayConstructor;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
            name: StringConstructor;
            id: StringConstructor;
            modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown, undefined, boolean>;
            autocomplete: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
            automaticDropdown: BooleanConstructor;
            size: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown, string, boolean>;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            clearable: BooleanConstructor;
            filterable: BooleanConstructor;
            allowCreate: BooleanConstructor;
            loading: BooleanConstructor;
            popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, string, boolean>;
            popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
            popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => Partial<import('element-plus').Options>, boolean>;
            remote: BooleanConstructor;
            debounce: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            loadingText: StringConstructor;
            noMatchText: StringConstructor;
            noDataText: StringConstructor;
            remoteMethod: {
                readonly type: import('vue').PropType<(query: string) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            filterMethod: {
                readonly type: import('vue').PropType<(query: string) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            multiple: BooleanConstructor;
            multipleLimit: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            placeholder: {
                readonly type: import('vue').PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            defaultFirstOption: BooleanConstructor;
            reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            valueKey: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
            collapseTags: BooleanConstructor;
            collapseTagsTooltip: BooleanConstructor;
            tagTooltip: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps) | (((new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps)) | null)[], unknown, unknown, () => {}, boolean>;
            maxCollapseTags: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
            fitInputWidth: BooleanConstructor;
            suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
            tagType: {
                default: string;
                type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            tagEffect: {
                default: string;
                type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            remoteShowSuffix: BooleanConstructor;
            showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            offset: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, string, boolean>;
            fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, string[], boolean>;
            tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(StringConstructor | NumberConstructor)[], unknown, unknown, number, boolean>;
            appendTo: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            options: {
                readonly type: import('vue').PropType<Record<string, any>[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>> & Readonly<{}>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, import('vue').PublicProps, {
            props: import('element-plus').TreeOptionProps;
            data: import('element-plus').TreeData;
            loading: boolean;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            lazy: boolean;
            checkStrictly: boolean;
            autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            defaultExpandAll: boolean;
            checkDescendants: boolean;
            multiple: boolean;
            modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown>;
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            filterable: boolean;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
            offset: number;
            teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown>;
            autocomplete: string;
            clearable: boolean;
            clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
            suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
            tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(StringConstructor | NumberConstructor)[], unknown, unknown>;
            popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
            popperStyle: import('vue').StyleValue;
            fallbackPlacements: import('element-plus').Placement[];
            placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
            popperOptions: Partial<import('element-plus').Options>;
            showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            valueKey: string;
            debounce: number;
            fitInputWidth: boolean;
            checkOnClickNode: boolean;
            checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            collapseTags: boolean;
            maxCollapseTags: number;
            collapseTagsTooltip: boolean;
            tagType: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>;
            tagEffect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
            accordion: boolean;
            automaticDropdown: boolean;
            draggable: boolean;
            allowCreate: boolean;
            remote: boolean;
            multipleLimit: number;
            defaultFirstOption: boolean;
            reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            tagTooltip: import('element-plus').TagTooltipProps;
            remoteShowSuffix: boolean;
            indent: number;
            renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            showCheckbox: boolean;
            expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            highlightCurrent: boolean;
            cacheData: unknown[];
        }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import('vue').ExtractPropTypes<{
            cacheData: {
                type: ArrayConstructor;
                default: () => never[];
            };
            data: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData) | (((new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData)) | null)[], unknown, unknown, () => never[], boolean>;
            emptyText: {
                readonly type: import('vue').PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            nodeKey: StringConstructor;
            checkStrictly: BooleanConstructor;
            defaultExpandAll: BooleanConstructor;
            expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            checkOnClickNode: BooleanConstructor;
            checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            checkDescendants: BooleanConstructor;
            autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            defaultCheckedKeys: {
                readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            defaultExpandedKeys: {
                readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            currentNodeKey: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            renderContent: {
                readonly type: import('vue').PropType<import('element-plus').RenderContentFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            showCheckbox: BooleanConstructor;
            draggable: BooleanConstructor;
            allowDrag: {
                readonly type: import('vue').PropType<import('element-plus').AllowDragFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            allowDrop: {
                readonly type: import('vue').PropType<import('element-plus').AllowDropFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            props: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps) | (((new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps)) | null)[], unknown, unknown, () => {
                children: string;
                label: string;
                disabled: string;
            }, boolean>;
            lazy: BooleanConstructor;
            highlightCurrent: BooleanConstructor;
            load: {
                readonly type: import('vue').PropType<import('element-plus').LoadFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            filterNodeMethod: {
                readonly type: import('vue').PropType<import('element-plus').FilterNodeMethodFunction>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            accordion: BooleanConstructor;
            indent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 18, boolean>;
            icon: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            ariaLabel: StringConstructor;
            emptyValues: ArrayConstructor;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
            name: StringConstructor;
            id: StringConstructor;
            modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown, undefined, boolean>;
            autocomplete: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
            automaticDropdown: BooleanConstructor;
            size: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown, string, boolean>;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            clearable: BooleanConstructor;
            filterable: BooleanConstructor;
            allowCreate: BooleanConstructor;
            loading: BooleanConstructor;
            popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, string, boolean>;
            popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
            popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => Partial<import('element-plus').Options>, boolean>;
            remote: BooleanConstructor;
            debounce: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            loadingText: StringConstructor;
            noMatchText: StringConstructor;
            noDataText: StringConstructor;
            remoteMethod: {
                readonly type: import('vue').PropType<(query: string) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            filterMethod: {
                readonly type: import('vue').PropType<(query: string) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            multiple: BooleanConstructor;
            multipleLimit: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            placeholder: {
                readonly type: import('vue').PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            defaultFirstOption: BooleanConstructor;
            reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            valueKey: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
            collapseTags: BooleanConstructor;
            collapseTagsTooltip: BooleanConstructor;
            tagTooltip: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps) | (((new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps)) | null)[], unknown, unknown, () => {}, boolean>;
            maxCollapseTags: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
            fitInputWidth: BooleanConstructor;
            suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
            tagType: {
                default: string;
                type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            tagEffect: {
                default: string;
                type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
                required: false;
                validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            remoteShowSuffix: BooleanConstructor;
            showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
            offset: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, string, boolean>;
            fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, string[], boolean>;
            tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(StringConstructor | NumberConstructor)[], unknown, unknown, number, boolean>;
            appendTo: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            options: {
                readonly type: import('vue').PropType<Record<string, any>[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>> & Readonly<{}>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
            [key: string]: any;
        }>, {}, {}, {}, {
            props: import('element-plus').TreeOptionProps;
            data: import('element-plus').TreeData;
            loading: boolean;
            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            lazy: boolean;
            checkStrictly: boolean;
            autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            defaultExpandAll: boolean;
            checkDescendants: boolean;
            multiple: boolean;
            modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown>;
            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            filterable: boolean;
            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
            offset: number;
            teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown>;
            autocomplete: string;
            clearable: boolean;
            clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
            suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
            tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(StringConstructor | NumberConstructor)[], unknown, unknown>;
            popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
            popperStyle: import('vue').StyleValue;
            fallbackPlacements: import('element-plus').Placement[];
            placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
            popperOptions: Partial<import('element-plus').Options>;
            showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            valueKey: string;
            debounce: number;
            fitInputWidth: boolean;
            checkOnClickNode: boolean;
            checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            collapseTags: boolean;
            maxCollapseTags: number;
            collapseTagsTooltip: boolean;
            tagType: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>;
            tagEffect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
            accordion: boolean;
            automaticDropdown: boolean;
            draggable: boolean;
            allowCreate: boolean;
            remote: boolean;
            multipleLimit: number;
            defaultFirstOption: boolean;
            reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            tagTooltip: import('element-plus').TagTooltipProps;
            remoteShowSuffix: boolean;
            indent: number;
            renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            showCheckbox: boolean;
            expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            highlightCurrent: boolean;
            cacheData: unknown[];
        }> | null;
    };
    rootEl: any;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: ChoiceValue | ChoiceValue[] | null) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: ChoiceValue | ChoiceValue[] | null) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    tree: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
        cacheData: {
            type: ArrayConstructor;
            default: () => never[];
        };
        data: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData) | (((new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData)) | null)[], unknown, unknown, () => never[], boolean>;
        emptyText: {
            readonly type: import('vue').PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        nodeKey: StringConstructor;
        checkStrictly: BooleanConstructor;
        defaultExpandAll: BooleanConstructor;
        expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        checkOnClickNode: BooleanConstructor;
        checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        checkDescendants: BooleanConstructor;
        autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        defaultCheckedKeys: {
            readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        defaultExpandedKeys: {
            readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        currentNodeKey: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        renderContent: {
            readonly type: import('vue').PropType<import('element-plus').RenderContentFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        showCheckbox: BooleanConstructor;
        draggable: BooleanConstructor;
        allowDrag: {
            readonly type: import('vue').PropType<import('element-plus').AllowDragFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        allowDrop: {
            readonly type: import('vue').PropType<import('element-plus').AllowDropFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        props: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps) | (((new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps)) | null)[], unknown, unknown, () => {
            children: string;
            label: string;
            disabled: string;
        }, boolean>;
        lazy: BooleanConstructor;
        highlightCurrent: BooleanConstructor;
        load: {
            readonly type: import('vue').PropType<import('element-plus').LoadFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        filterNodeMethod: {
            readonly type: import('vue').PropType<import('element-plus').FilterNodeMethodFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        accordion: BooleanConstructor;
        indent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 18, boolean>;
        icon: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        ariaLabel: StringConstructor;
        emptyValues: ArrayConstructor;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
        name: StringConstructor;
        id: StringConstructor;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown, undefined, boolean>;
        autocomplete: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        automaticDropdown: BooleanConstructor;
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown, string, boolean>;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        clearable: BooleanConstructor;
        filterable: BooleanConstructor;
        allowCreate: BooleanConstructor;
        loading: BooleanConstructor;
        popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, string, boolean>;
        popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => Partial<import('element-plus').Options>, boolean>;
        remote: BooleanConstructor;
        debounce: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        loadingText: StringConstructor;
        noMatchText: StringConstructor;
        noDataText: StringConstructor;
        remoteMethod: {
            readonly type: import('vue').PropType<(query: string) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        filterMethod: {
            readonly type: import('vue').PropType<(query: string) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        multiple: BooleanConstructor;
        multipleLimit: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        placeholder: {
            readonly type: import('vue').PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        defaultFirstOption: BooleanConstructor;
        reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        valueKey: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        collapseTags: BooleanConstructor;
        collapseTagsTooltip: BooleanConstructor;
        tagTooltip: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps) | (((new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps)) | null)[], unknown, unknown, () => {}, boolean>;
        maxCollapseTags: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        fitInputWidth: BooleanConstructor;
        suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        tagType: {
            default: string;
            type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        tagEffect: {
            default: string;
            type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        remoteShowSuffix: BooleanConstructor;
        showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        offset: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, string, boolean>;
        fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, string[], boolean>;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(StringConstructor | NumberConstructor)[], unknown, unknown, number, boolean>;
        appendTo: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        options: {
            readonly type: import('vue').PropType<Record<string, any>[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & Readonly<{}>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, import('vue').PublicProps, {
        props: import('element-plus').TreeOptionProps;
        data: import('element-plus').TreeData;
        loading: boolean;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        lazy: boolean;
        checkStrictly: boolean;
        autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        defaultExpandAll: boolean;
        checkDescendants: boolean;
        multiple: boolean;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown>;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        filterable: boolean;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
        offset: number;
        teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown>;
        autocomplete: string;
        clearable: boolean;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(StringConstructor | NumberConstructor)[], unknown, unknown>;
        popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
        popperStyle: import('vue').StyleValue;
        fallbackPlacements: import('element-plus').Placement[];
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
        popperOptions: Partial<import('element-plus').Options>;
        showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        valueKey: string;
        debounce: number;
        fitInputWidth: boolean;
        checkOnClickNode: boolean;
        checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        collapseTags: boolean;
        maxCollapseTags: number;
        collapseTagsTooltip: boolean;
        tagType: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>;
        tagEffect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
        accordion: boolean;
        automaticDropdown: boolean;
        draggable: boolean;
        allowCreate: boolean;
        remote: boolean;
        multipleLimit: number;
        defaultFirstOption: boolean;
        reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        tagTooltip: import('element-plus').TagTooltipProps;
        remoteShowSuffix: boolean;
        indent: number;
        renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showCheckbox: boolean;
        expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        highlightCurrent: boolean;
        cacheData: unknown[];
    }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import('vue').ExtractPropTypes<{
        cacheData: {
            type: ArrayConstructor;
            default: () => never[];
        };
        data: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData) | (((new (...args: any[]) => import('element-plus').TreeData) | (() => import('element-plus').TreeData)) | null)[], unknown, unknown, () => never[], boolean>;
        emptyText: {
            readonly type: import('vue').PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        nodeKey: StringConstructor;
        checkStrictly: BooleanConstructor;
        defaultExpandAll: BooleanConstructor;
        expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        checkOnClickNode: BooleanConstructor;
        checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        checkDescendants: BooleanConstructor;
        autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        defaultCheckedKeys: {
            readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        defaultExpandedKeys: {
            readonly type: import('vue').PropType<import('element-plus').TreeKey[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        currentNodeKey: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        renderContent: {
            readonly type: import('vue').PropType<import('element-plus').RenderContentFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        showCheckbox: BooleanConstructor;
        draggable: BooleanConstructor;
        allowDrag: {
            readonly type: import('vue').PropType<import('element-plus').AllowDragFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        allowDrop: {
            readonly type: import('vue').PropType<import('element-plus').AllowDropFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        props: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps) | (((new (...args: any[]) => import('element-plus').TreeOptionProps) | (() => import('element-plus').TreeOptionProps)) | null)[], unknown, unknown, () => {
            children: string;
            label: string;
            disabled: string;
        }, boolean>;
        lazy: BooleanConstructor;
        highlightCurrent: BooleanConstructor;
        load: {
            readonly type: import('vue').PropType<import('element-plus').LoadFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        filterNodeMethod: {
            readonly type: import('vue').PropType<import('element-plus').FilterNodeMethodFunction>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        accordion: BooleanConstructor;
        indent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 18, boolean>;
        icon: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        ariaLabel: StringConstructor;
        emptyValues: ArrayConstructor;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
        name: StringConstructor;
        id: StringConstructor;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown, undefined, boolean>;
        autocomplete: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        automaticDropdown: BooleanConstructor;
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown, string, boolean>;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        clearable: BooleanConstructor;
        filterable: BooleanConstructor;
        allowCreate: BooleanConstructor;
        loading: BooleanConstructor;
        popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, string, boolean>;
        popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => Partial<import('element-plus').Options>, boolean>;
        remote: BooleanConstructor;
        debounce: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        loadingText: StringConstructor;
        noMatchText: StringConstructor;
        noDataText: StringConstructor;
        remoteMethod: {
            readonly type: import('vue').PropType<(query: string) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        filterMethod: {
            readonly type: import('vue').PropType<(query: string) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        multiple: BooleanConstructor;
        multipleLimit: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        placeholder: {
            readonly type: import('vue').PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        defaultFirstOption: BooleanConstructor;
        reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        valueKey: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, string, boolean>;
        collapseTags: BooleanConstructor;
        collapseTagsTooltip: BooleanConstructor;
        tagTooltip: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps) | (((new (...args: any[]) => import('element-plus').TagTooltipProps) | (() => import('element-plus').TagTooltipProps)) | null)[], unknown, unknown, () => {}, boolean>;
        maxCollapseTags: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        fitInputWidth: BooleanConstructor;
        suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        tagType: {
            default: string;
            type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        tagEffect: {
            default: string;
            type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>>;
            required: false;
            validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        remoteShowSuffix: BooleanConstructor;
        showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, boolean, boolean>;
        offset: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, string, boolean>;
        fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, string[], boolean>;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(StringConstructor | NumberConstructor)[], unknown, unknown, number, boolean>;
        appendTo: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | (((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        options: {
            readonly type: import('vue').PropType<Record<string, any>[]>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & Readonly<{}>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        props: import('element-plus').TreeOptionProps;
        data: import('element-plus').TreeData;
        loading: boolean;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        lazy: boolean;
        checkStrictly: boolean;
        autoExpandParent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        defaultExpandAll: boolean;
        checkDescendants: boolean;
        multiple: boolean;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null) | (((new (...args: any[]) => string | number | boolean | Record<string, any> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[]) | (() => import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown> | import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(BooleanConstructor | StringConstructor | ObjectConstructor | NumberConstructor)[], unknown, unknown>[] | null)) | null)[], unknown, unknown>;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        filterable: boolean;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
        offset: number;
        teleported: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        effect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').PopperEffect) | (((new (...args: any[]) => string) | (() => import('element-plus').PopperEffect)) | null)[], unknown, unknown>;
        autocomplete: string;
        clearable: boolean;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        suffixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(StringConstructor | NumberConstructor)[], unknown, unknown>;
        popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
        popperStyle: import('vue').StyleValue;
        fallbackPlacements: import('element-plus').Placement[];
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
        popperOptions: Partial<import('element-plus').Options>;
        showArrow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        persistent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        valueKey: string;
        debounce: number;
        fitInputWidth: boolean;
        checkOnClickNode: boolean;
        checkOnClickLeaf: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        collapseTags: boolean;
        maxCollapseTags: number;
        collapseTagsTooltip: boolean;
        tagType: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "info" | "primary" | "success" | "warning" | "danger", unknown>;
        tagEffect: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "dark" | "light" | "plain", unknown>;
        accordion: boolean;
        automaticDropdown: boolean;
        draggable: boolean;
        allowCreate: boolean;
        remote: boolean;
        multipleLimit: number;
        defaultFirstOption: boolean;
        reserveKeyword: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        tagTooltip: import('element-plus').TagTooltipProps;
        remoteShowSuffix: boolean;
        indent: number;
        renderAfterExpand: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showCheckbox: boolean;
        expandOnClickNode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        highlightCurrent: boolean;
        cacheData: unknown[];
    }> | null;
}, any>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
