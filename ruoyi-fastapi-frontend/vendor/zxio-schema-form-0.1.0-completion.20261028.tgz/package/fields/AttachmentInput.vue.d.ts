import { nextTick } from 'vue';
import { FieldAttachment, FieldUpload } from './attachment';
import { FieldEditState, FieldMessage } from './types';
import { Json } from '../types';
type __VLS_Props = {
    modelValue?: FieldAttachment[];
    upload: FieldUpload;
    disabled?: boolean;
    readonly?: boolean;
    multiple?: boolean;
    accept?: string;
    maxSize?: number;
    limit?: number;
    buttonText?: string;
    messages?: readonly FieldMessage[];
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit(): Json;
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: FieldAttachment[]) => void;
    "edit-state": (state: FieldEditState) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: FieldAttachment[]) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    modelValue: FieldAttachment[];
    multiple: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    root: HTMLDivElement;
    uploader: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly name: string;
            readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly size: string;
            readonly data: Record<string, any>;
            readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly headers: Record<string, any>;
            readonly modelValue: unknown[];
            readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly action: string;
            readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly accept: string;
            readonly maxSize: number;
            readonly listType: string;
            readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly mainText: string;
            readonly subText: string;
            readonly buttonText: string;
            readonly tipText: string;
            readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        }> & Omit<{
            readonly name: string;
            readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly size: string;
            readonly data: Record<string, any>;
            readonly headers: Record<string, any>;
            readonly modelValue: unknown[];
            readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly action: string;
            readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly accept: string;
            readonly maxSize: number;
            readonly listType: string;
            readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly mainText: string;
            readonly subText: string;
            readonly buttonText: string;
            readonly tipText: string;
            readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly disabled?: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
            readonly limit?: number | undefined;
            readonly beforeUpload?: Function | undefined;
            readonly beforeRemove?: Function | undefined;
            readonly onError?: ((err: any) => any) | undefined;
            readonly onRemove?: ((file: any) => any) | undefined;
            readonly onChange?: ((val: any) => any) | undefined;
            readonly onProgress?: ((e: any) => any) | undefined;
            readonly onSuccess?: ((res: any) => any) | undefined;
            readonly "onUpdate:modelValue"?: ((val: any) => any) | undefined;
            readonly onReject?: ((rejection: import('@zxio/zxui/upload').UploadRejection) => any) | undefined;
            readonly onPreview?: ((file: any) => any) | undefined;
            readonly onExceed?: ((files: any) => any) | undefined;
            readonly onDownload?: ((file: any) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "name" | "drag" | "size" | "data" | "disabled" | "headers" | "modelValue" | "multiple" | "action" | "withCredentials" | "accept" | "maxSize" | "listType" | "showFileList" | "customFileList" | "mainText" | "subText" | "buttonText" | "tipText" | "showSubText" | "showTip" | "autoUpload" | "allowPreview" | "allowDownload" | "allowRemove">;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        } & {
            uploadRef: ({
                $: import('vue').ComponentInternalInstance;
                $data: {};
                $props: {
                    readonly beforeUpload?: import('element-plus').UploadHooks["beforeUpload"] | undefined;
                    readonly beforeRemove?: import('element-plus').UploadHooks["beforeRemove"] | undefined;
                    readonly onRemove?: import('element-plus').UploadHooks["onRemove"] | undefined;
                    readonly onChange?: import('element-plus').UploadHooks["onChange"] | undefined;
                    readonly onPreview?: import('element-plus').UploadHooks["onPreview"] | undefined;
                    readonly onSuccess?: import('element-plus').UploadHooks["onSuccess"] | undefined;
                    readonly onProgress?: import('element-plus').UploadHooks["onProgress"] | undefined;
                    readonly onError?: import('element-plus').UploadHooks["onError"] | undefined;
                    readonly onExceed?: import('element-plus').UploadHooks["onExceed"] | undefined;
                    readonly crossorigin?: import('element-plus').Crossorigin | undefined;
                    readonly action?: string | undefined;
                    readonly headers?: (Headers | Record<string, any>) | undefined;
                    readonly method?: string | undefined;
                    readonly data?: (import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData> | ((rawFile: import('element-plus').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | undefined;
                    readonly multiple?: boolean | undefined;
                    readonly name?: string | undefined;
                    readonly drag?: boolean | undefined;
                    readonly withCredentials?: boolean | undefined;
                    readonly showFileList?: boolean | undefined;
                    readonly accept?: string | undefined;
                    readonly fileList?: import('element-plus').UploadUserFile[] | undefined;
                    readonly autoUpload?: boolean | undefined;
                    readonly listType?: import('element-plus').ListType | undefined;
                    readonly httpRequest?: import('element-plus').UploadRequestHandler | undefined;
                    readonly disabled?: boolean | undefined;
                    readonly limit?: number | undefined;
                    readonly directory?: boolean | undefined;
                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
                $attrs: import('vue').Attrs;
                $refs: {
                    [x: string]: unknown;
                };
                $slots: Readonly<{
                    [name: string]: import('vue').Slot<any> | undefined;
                }>;
                $root: import('vue').ComponentPublicInstance | null;
                $parent: import('vue').ComponentPublicInstance | null;
                $host: Element | null;
                $emit: (event: string, ...args: any[]) => void;
                $el: any;
                $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').UploadProps> & Readonly<{}>, {
                    abort: (file?: import('element-plus').UploadFile) => void;
                    submit: () => void;
                    clearFiles: (states?: import('element-plus').UploadStatus[]) => void;
                    handleStart: (rawFile: import('element-plus').UploadRawFile) => void;
                    handleRemove: (file: import('element-plus').UploadFile | import('element-plus').UploadRawFile) => void;
                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, {
                    data: import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData> | ((rawFile: import('element-plus').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>);
                    disabled: boolean;
                    name: string;
                    onChange: import('element-plus').UploadHooks["onChange"];
                    onProgress: import('element-plus').UploadHooks["onProgress"];
                    onError: import('element-plus').UploadHooks["onError"];
                    beforeUpload: import('element-plus').UploadHooks["beforeUpload"];
                    onRemove: import('element-plus').UploadHooks["onRemove"];
                    onPreview: import('element-plus').UploadHooks["onPreview"];
                    onSuccess: import('element-plus').UploadHooks["onSuccess"];
                    onExceed: import('element-plus').UploadHooks["onExceed"];
                    action: string;
                    method: string;
                    showFileList: boolean;
                    accept: string;
                    fileList: import('element-plus').UploadUserFile[];
                    autoUpload: boolean;
                    listType: import('element-plus').ListType;
                    httpRequest: import('element-plus').UploadRequestHandler;
                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
            } & Readonly<{
                data: import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData> | ((rawFile: import('element-plus').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>);
                disabled: boolean;
                name: string;
                onChange: import('element-plus').UploadHooks["onChange"];
                onProgress: import('element-plus').UploadHooks["onProgress"];
                onError: import('element-plus').UploadHooks["onError"];
                beforeUpload: import('element-plus').UploadHooks["beforeUpload"];
                onRemove: import('element-plus').UploadHooks["onRemove"];
                onPreview: import('element-plus').UploadHooks["onPreview"];
                onSuccess: import('element-plus').UploadHooks["onSuccess"];
                onExceed: import('element-plus').UploadHooks["onExceed"];
                action: string;
                method: string;
                showFileList: boolean;
                accept: string;
                fileList: import('element-plus').UploadUserFile[];
                autoUpload: boolean;
                listType: import('element-plus').ListType;
                httpRequest: import('element-plus').UploadRequestHandler;
            }> & Omit<Readonly<import('element-plus').UploadProps> & Readonly<{}>, "name" | "abort" | "submit" | "data" | "onChange" | "onError" | "onProgress" | "disabled" | "action" | "onSuccess" | "accept" | "listType" | "showFileList" | "autoUpload" | "beforeUpload" | "onRemove" | "onPreview" | "onExceed" | "method" | "fileList" | "httpRequest" | "clearFiles" | "handleStart" | "handleRemove"> & {
                abort: (file?: import('element-plus').UploadFile) => void;
                submit: () => void;
                clearFiles: (states?: import('element-plus').UploadStatus[]) => void;
                handleStart: (rawFile: import('element-plus').UploadRawFile) => void;
                handleRemove: (file: import('element-plus').UploadFile | import('element-plus').UploadRawFile) => void;
            } & {} & import('vue').ComponentCustomProperties & {} & {
                $slots: {
                    file?: (props: {
                        file: import('element-plus').UploadFile;
                        index: number;
                    }) => any;
                } & {
                    trigger?: (props: {}) => any;
                } & {
                    default?: (props: {}) => any;
                } & {
                    trigger?: (props: {}) => any;
                } & {
                    default?: (props: {}) => any;
                } & {
                    default?: (props: {}) => any;
                } & {
                    tip?: (props: {}) => any;
                } & {
                    file?: (props: {
                        file: import('element-plus').UploadFile;
                        index: number;
                    }) => any;
                };
            }) | null;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "error", err: any) => void) & ((event: "remove", file: any) => void) & ((event: "change", val: any) => void) & ((event: "progress", e: any) => void) & ((event: "success", res: any) => void) & ((event: "update:modelValue", val: any) => void) & ((event: "reject", rejection: import('@zxio/zxui/upload').UploadRejection) => void) & ((event: "preview", file: any) => void) & ((event: "exceed", files: any) => void) & ((event: "download", file: any) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
            readonly modelValue: import('@zxio/shared').EpPropFinalized<ArrayConstructor, unknown, unknown, () => any[], boolean>;
            readonly action: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly headers: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
            readonly data: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
            readonly name: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "file", boolean>;
            readonly withCredentials: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly multiple: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly accept: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "*", boolean>;
            readonly limit: {
                readonly type: import('vue').PropType<number>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly maxSize: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
            readonly listType: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "text", boolean>;
            readonly drag: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly showFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly customFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            readonly mainText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly subText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly buttonText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly tipText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly showSubText: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly showTip: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly autoUpload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly disabled: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly allowPreview: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly allowDownload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly allowRemove: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly beforeUpload: {
                readonly type: import('vue').PropType<Function>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly beforeRemove: {
                readonly type: import('vue').PropType<Function>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly size: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "default", boolean>;
        }>> & Readonly<{
            onError?: ((err: any) => any) | undefined;
            onRemove?: ((file: any) => any) | undefined;
            onChange?: ((val: any) => any) | undefined;
            onProgress?: ((e: any) => any) | undefined;
            onSuccess?: ((res: any) => any) | undefined;
            "onUpdate:modelValue"?: ((val: any) => any) | undefined;
            onReject?: ((rejection: import('@zxio/zxui/upload').UploadRejection) => any) | undefined;
            onPreview?: ((file: any) => any) | undefined;
            onExceed?: ((files: any) => any) | undefined;
            onDownload?: ((file: any) => any) | undefined;
        }>, {
            submit: () => void | undefined;
            abort: (file?: import('element-plus').UploadFile) => void | undefined;
            clearFiles: () => void | undefined;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            error: (err: any) => void;
            remove: (file: any) => void;
            change: (val: any) => void;
            progress: (e: any) => void;
            success: (res: any) => void;
            "update:modelValue": (val: any) => void;
            reject: (rejection: import('@zxio/zxui/upload').UploadRejection) => void;
            preview: (file: any) => void;
            exceed: (files: any) => void;
            download: (file: any) => void;
        }, string, {
            readonly name: string;
            readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly size: string;
            readonly data: Record<string, any>;
            readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly headers: Record<string, any>;
            readonly modelValue: unknown[];
            readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly action: string;
            readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly accept: string;
            readonly maxSize: number;
            readonly listType: string;
            readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly mainText: string;
            readonly subText: string;
            readonly buttonText: string;
            readonly tipText: string;
            readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        readonly name: string;
        readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly size: string;
        readonly data: Record<string, any>;
        readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly headers: Record<string, any>;
        readonly modelValue: unknown[];
        readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly action: string;
        readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly accept: string;
        readonly maxSize: number;
        readonly listType: string;
        readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly mainText: string;
        readonly subText: string;
        readonly buttonText: string;
        readonly tipText: string;
        readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
    }> & Omit<Readonly<import('vue').ExtractPropTypes<{
        readonly modelValue: import('@zxio/shared').EpPropFinalized<ArrayConstructor, unknown, unknown, () => any[], boolean>;
        readonly action: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly headers: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
        readonly data: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
        readonly name: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "file", boolean>;
        readonly withCredentials: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly multiple: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly accept: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "*", boolean>;
        readonly limit: {
            readonly type: import('vue').PropType<number>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly maxSize: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
        readonly listType: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "text", boolean>;
        readonly drag: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly showFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly customFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly mainText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly subText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly buttonText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly tipText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly showSubText: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTip: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly autoUpload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly disabled: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly allowPreview: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly allowDownload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly allowRemove: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly beforeUpload: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly beforeRemove: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly size: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "default", boolean>;
    }>> & Readonly<{
        onError?: ((err: any) => any) | undefined;
        onRemove?: ((file: any) => any) | undefined;
        onChange?: ((val: any) => any) | undefined;
        onProgress?: ((e: any) => any) | undefined;
        onSuccess?: ((res: any) => any) | undefined;
        "onUpdate:modelValue"?: ((val: any) => any) | undefined;
        onReject?: ((rejection: import('@zxio/zxui/upload').UploadRejection) => any) | undefined;
        onPreview?: ((file: any) => any) | undefined;
        onExceed?: ((files: any) => any) | undefined;
        onDownload?: ((file: any) => any) | undefined;
    }>, "abort" | "submit" | "clearFiles" | ("name" | "drag" | "size" | "data" | "disabled" | "headers" | "modelValue" | "multiple" | "action" | "withCredentials" | "accept" | "maxSize" | "listType" | "showFileList" | "customFileList" | "mainText" | "subText" | "buttonText" | "tipText" | "showSubText" | "showTip" | "autoUpload" | "allowPreview" | "allowDownload" | "allowRemove")> & {
        submit: () => void | undefined;
        abort: (file?: import('element-plus').UploadFile) => void | undefined;
        clearFiles: () => void | undefined;
    } & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            default?(_: {}): any;
            trigger?(_: {}): any;
            file?(_: {
                file: import('element-plus').UploadFile;
                index: number;
            }): any;
            tip?(_: {}): any;
        };
    }) | null;
}, any>;
export default _default;
