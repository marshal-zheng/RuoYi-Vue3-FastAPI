import { DatePickerProps } from 'element-plus';
import { DateFieldType, DateFieldValue } from './date-text';
import { FieldEditState, FieldMessage } from './types';
import { Json } from '../types';
type __VLS_Props = {
    modelValue?: DateFieldValue;
    valueFormat: string;
    format?: string;
    type?: DateFieldType;
    editable?: boolean;
    disabled?: boolean;
    readonly?: boolean;
    messages?: readonly FieldMessage[];
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit(): Json;
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: DateFieldValue) => void;
    "edit-state": (state: FieldEditState) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: DateFieldValue) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    type: DateFieldType;
    modelValue: DateFieldValue;
    editable: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    root: HTMLDivElement;
    picker: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
        readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | (((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType)) | null)[], unknown, unknown, "date", boolean>;
        readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showWeekNumber: BooleanConstructor;
        readonly ariaLabel: StringConstructor;
        readonly emptyValues: ArrayConstructor;
        readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabledDate: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly cellClassName: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
        readonly arrowControl: BooleanConstructor;
        readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly unlinkPanels: BooleanConstructor;
        readonly singlePanel: BooleanConstructor;
        readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
        readonly fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
        readonly disabledHours: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabledMinutes: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabledSeconds: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly id: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly name: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly format: StringConstructor;
        readonly valueFormat: StringConstructor;
        readonly dateFormat: StringConstructor;
        readonly timeFormat: StringConstructor;
        readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
        readonly size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly readonly: BooleanConstructor;
        readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
        readonly rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
        readonly startPlaceholder: StringConstructor;
        readonly endPlaceholder: StringConstructor;
        readonly defaultValue: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly defaultTime: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly isRange: BooleanConstructor;
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((_value: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>) => any) | undefined;
    }>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
        'update:modelValue': (_value: DatePickerProps["modelValue"]) => true;
    }, import('vue').PublicProps, {
        readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | ((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | null)[], unknown, unknown>;
        readonly placeholder: string;
        readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number) | null)[], unknown, unknown>;
        readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>;
        readonly readonly: boolean;
        readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
        readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
        readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | ((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | null)[], import('element-plus').Placement, unknown>;
        readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | null)[], unknown, unknown>;
        readonly popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
        readonly popperStyle: import('vue').StyleValue;
        readonly fallbackPlacements: import('element-plus').Placement[];
        readonly popperOptions: Partial<import('element-plus').Options>;
        readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showWeekNumber: boolean;
        readonly shortcuts: unknown[];
        readonly arrowControl: boolean;
        readonly unlinkPanels: boolean;
        readonly singlePanel: boolean;
        readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly rangeSeparator: string;
        readonly isRange: boolean;
    }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import('vue').ExtractPropTypes<{
        readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | (((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType)) | null)[], unknown, unknown, "date", boolean>;
        readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showWeekNumber: BooleanConstructor;
        readonly ariaLabel: StringConstructor;
        readonly emptyValues: ArrayConstructor;
        readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabledDate: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly cellClassName: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
        readonly arrowControl: BooleanConstructor;
        readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly unlinkPanels: BooleanConstructor;
        readonly singlePanel: BooleanConstructor;
        readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
        readonly fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
        readonly disabledHours: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabledMinutes: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabledSeconds: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly id: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly name: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        readonly format: StringConstructor;
        readonly valueFormat: StringConstructor;
        readonly dateFormat: StringConstructor;
        readonly timeFormat: StringConstructor;
        readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
        readonly size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly readonly: BooleanConstructor;
        readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
        readonly rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
        readonly startPlaceholder: StringConstructor;
        readonly endPlaceholder: StringConstructor;
        readonly defaultValue: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly defaultTime: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly isRange: BooleanConstructor;
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((_value: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>) => any) | undefined;
    }>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
        [key: string]: any;
    }>, {}, {}, {}, {
        readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | ((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | null)[], unknown, unknown>;
        readonly placeholder: string;
        readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number) | null)[], unknown, unknown>;
        readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>;
        readonly readonly: boolean;
        readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
        readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
        readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | ((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | null)[], import('element-plus').Placement, unknown>;
        readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | null)[], unknown, unknown>;
        readonly popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
        readonly popperStyle: import('vue').StyleValue;
        readonly fallbackPlacements: import('element-plus').Placement[];
        readonly popperOptions: Partial<import('element-plus').Options>;
        readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showWeekNumber: boolean;
        readonly shortcuts: unknown[];
        readonly arrowControl: boolean;
        readonly unlinkPanels: boolean;
        readonly singlePanel: boolean;
        readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly rangeSeparator: string;
        readonly isRange: boolean;
    }> | import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
        isRange: BooleanConstructor;
        showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        showWeekNumber: BooleanConstructor;
        ariaLabel: StringConstructor;
        emptyValues: ArrayConstructor;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
        disabledDate: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        cellClassName: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
        arrowControl: BooleanConstructor;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        unlinkPanels: BooleanConstructor;
        singlePanel: BooleanConstructor;
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
        fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
        disabledHours: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        disabledMinutes: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        disabledSeconds: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        id: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        name: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        format: StringConstructor;
        valueFormat: StringConstructor;
        dateFormat: StringConstructor;
        timeFormat: StringConstructor;
        type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly: BooleanConstructor;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
        rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
        startPlaceholder: StringConstructor;
        endPlaceholder: StringConstructor;
        defaultValue: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        defaultTime: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, "update:modelValue"[], import('vue').PublicProps, {
        type: string;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown>;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        placeholder: string;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
        readonly: boolean;
        clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
        popperStyle: import('vue').StyleValue;
        fallbackPlacements: import('element-plus').Placement[];
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
        popperOptions: Partial<import('element-plus').Options>;
        automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        rangeSeparator: string;
        shortcuts: unknown[];
        showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showWeekNumber: boolean;
        arrowControl: boolean;
        unlinkPanels: boolean;
        singlePanel: boolean;
        isRange: boolean;
    }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import('vue').ExtractPropTypes<{
        isRange: BooleanConstructor;
        showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        showWeekNumber: BooleanConstructor;
        ariaLabel: StringConstructor;
        emptyValues: ArrayConstructor;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
        disabledDate: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        cellClassName: {
            readonly type: import('vue').PropType<Function>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
        arrowControl: BooleanConstructor;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        unlinkPanels: BooleanConstructor;
        singlePanel: BooleanConstructor;
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
        fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
        disabledHours: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        disabledMinutes: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        disabledSeconds: {
            readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        id: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        name: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
        popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
        format: StringConstructor;
        valueFormat: StringConstructor;
        dateFormat: StringConstructor;
        timeFormat: StringConstructor;
        type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
        editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly: BooleanConstructor;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
        rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
        startPlaceholder: StringConstructor;
        endPlaceholder: StringConstructor;
        defaultValue: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        defaultTime: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & Readonly<{
        "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
        type: string;
        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown>;
        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        placeholder: string;
        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
        readonly: boolean;
        clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
        tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
        popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
        popperStyle: import('vue').StyleValue;
        fallbackPlacements: import('element-plus').Placement[];
        placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
        popperOptions: Partial<import('element-plus').Options>;
        automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        rangeSeparator: string;
        shortcuts: unknown[];
        showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        showWeekNumber: boolean;
        arrowControl: boolean;
        unlinkPanels: boolean;
        singlePanel: boolean;
        isRange: boolean;
    }> | null;
}, any>;
export default _default;
