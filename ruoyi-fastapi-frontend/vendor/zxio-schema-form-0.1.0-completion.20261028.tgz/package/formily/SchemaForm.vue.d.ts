import { Bindings, Values } from '../types';
import { ISchema } from '@formily/vue';
import { ArrayKey, BusinessContext, ConditionalEditPolicy, FieldPath, FormPhase, Save, SettledCheck, Validate } from './types';
declare const _default: <T extends object = Values>(__VLS_props: NonNullable<Awaited<typeof __VLS_setup>>["props"], __VLS_ctx?: __VLS_PrettifyLocal<Pick<NonNullable<Awaited<typeof __VLS_setup>>, "attrs" | "emit" | "slots">>, __VLS_expose?: NonNullable<Awaited<typeof __VLS_setup>>["expose"], __VLS_setup?: Promise<{
    props: __VLS_PrettifyLocal<Pick<Partial<{}> & Omit<{
        readonly onSaved?: ((values: T) => any) | undefined;
        readonly "onReconcile-required"?: ((event: {
            reason: string;
        }) => any) | undefined;
    } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, never>, "onSaved" | "onReconcile-required"> & {
        initial: T;
        initialConditionalEditPolicy?: ConditionalEditPolicy;
        createSchema(context: BusinessContext<T>): ISchema;
        assertSettled?: SettledCheck<T>;
        save?: Save<T>;
        validate?: Validate<T>;
        bindings?: Bindings;
        disabled?: boolean;
        arrayKeys?: readonly ArrayKey[];
        columns?: 1 | 2 | 3;
        labelPosition?: "left" | "right" | "top";
        labelWidth?: string | number;
    } & Partial<{}>> & import('vue').PublicProps;
    expose(exposed: import('vue').ShallowUnwrapRef<{
        readSnapshot: () => import('./conditional-types').SnapshotResult;
        prepareEdit: (changes: readonly import('./conditional-types').ConditionalChange[], options: {
            observationRef: string;
        }) => import('./conditional-types').PrepareResult;
        applyPrepared: (candidateRef: string, options?: {
            signal?: AbortSignal;
            credential?: unknown;
        } | undefined) => import('./conditional-types').ApplyResult;
        discardPrepared: (candidateRef: string) => import('./conditional-types').DiscardResult;
        getOperation: (operationRef: string) => import('./conditional-types').OperationResult;
        waitOperation: (operationRef: string, options?: {
            signal?: AbortSignal;
            timeoutMs?: number;
        } | undefined) => Promise<{
            status: "available";
            operation: import('./conditional-types').OperationView;
        } | {
            status: "unavailable";
            reason: string;
        } | {
            status: "timed-out" | "wait-cancelled";
            operationRef: string;
            latest?: import('./conditional-types').OperationView;
        }>;
        setConditionalEditPolicy: (next: ConditionalEditPolicy | undefined) => void;
        read: () => T;
        setValues: (patch: Partial<T>) => boolean;
        replaceValues: (values: T, mode: "edit" | "authority") => Promise<boolean>;
        validate: () => Promise<boolean>;
        submit: () => Promise<boolean>;
        reset: () => void;
        reconcile: (values: T) => Promise<boolean>;
        focus: (path?: FieldPath<T>) => void;
        ready: Readonly<import('vue').Ref<boolean, boolean>>;
        dirty: import('vue').ComputedRef<boolean>;
        hasUncommittedInput: import('vue').ComputedRef<boolean>;
        pending: Readonly<import('vue').Ref<boolean, boolean>>;
        fieldPending: import('vue').ComputedRef<boolean>;
        blocked: import('vue').ComputedRef<boolean>;
        reconciliationRequired: Readonly<import('vue').Ref<boolean, boolean>>;
        phase: Readonly<import('vue').Ref<FormPhase, FormPhase>>;
        status: Readonly<import('vue').Ref<string, string>>;
    }>): void;
    attrs: any;
    slots: Readonly<{
        diagnostics(props: {
            status: string;
            ready: boolean;
            dirty: boolean;
            hasUncommittedInput: boolean;
            pending: boolean;
            fieldPending: boolean;
            blocked: boolean;
            phase: FormPhase;
            reconciliationRequired: boolean;
        }): unknown;
    }> & {
        diagnostics(props: {
            status: string;
            ready: boolean;
            dirty: boolean;
            hasUncommittedInput: boolean;
            pending: boolean;
            fieldPending: boolean;
            blocked: boolean;
            phase: FormPhase;
            reconciliationRequired: boolean;
        }): unknown;
    };
    emit: {
        (e: "saved", values: T): void;
        (e: "reconcile-required", event: {
            reason: string;
        }): void;
    };
}>) => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
    [key: string]: any;
}> & {
    __ctx?: Awaited<typeof __VLS_setup>;
};
export default _default;
type __VLS_PrettifyLocal<T> = {
    [K in keyof T]: T[K];
} & {};
