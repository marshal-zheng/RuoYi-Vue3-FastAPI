import { SchemaLocale } from '../locale';
import { Field, FieldValidator, Form, GeneralField } from '@formily/core';
import { FieldControl, FieldEditState } from '../fields/types';
import { Json } from '../types';
import { FieldConfiguration, FieldIssue } from './types';
/** A mounted or temporarily hidden control bound to one data field. */
export interface Control {
    control: FieldControl;
    state: FieldEditState;
    composite: boolean;
    mounted: boolean;
    editObservation?: 'canonical' | 'raw-sequence';
    validationOwnership?: 'managed';
    draft?: Json;
}
export interface ValidationUpdate {
    code: string;
    issues: readonly FieldIssue[];
}
export interface ValidationPorts<T extends object> {
    locale?: SchemaLocale;
    alive(): boolean;
    form: Form;
    formView: Form;
    fieldView(field: GeneralField): GeneralField;
    configs: ReadonlyMap<Field, FieldConfiguration>;
    registered(field: GeneralField): boolean;
    tokens: Map<Field, number>;
    controls: ReadonlyMap<Field, Control>;
    activeControls(): readonly (readonly [Field, Control])[];
    liveControls(): readonly (readonly [Field, Control])[];
    /** Outstanding control validations; any semantic change revokes them. */
    controllers: Set<AbortController>;
    revoke(): void;
    ticket(): string;
    current(stamp: string): boolean;
    snapshot(): T;
    assert(): boolean;
    publish(updates: readonly ValidationUpdate[], submitted?: object): void;
}
/**
 * Every rule runs through the public validator against captured values and
 * rules. Per-field tokens and the whole-attempt stamp decide whether a result
 * may still publish feedback; stale results are dropped, never merged.
 */
export declare function createValidation<T extends object>(ports: ValidationPorts<T>): {
    validationId: (field: Field) => string;
    controlValidations: import('vue').ShallowRef<number, number>;
    validateField: (field: Field, triggerType?: string, captured?: {
        value: unknown;
        rules: FieldValidator;
        stamp: string;
        owns?: () => boolean;
        propagateErrors?: boolean;
        collect?: (updates: ValidationUpdate[], current: () => boolean) => void;
    }) => Promise<boolean>;
    validate: (owns?: () => boolean, propagateErrors?: boolean, signal?: AbortSignal) => Promise<boolean>;
};
export type Validation<T extends object> = ReturnType<typeof createValidation<T>>;
