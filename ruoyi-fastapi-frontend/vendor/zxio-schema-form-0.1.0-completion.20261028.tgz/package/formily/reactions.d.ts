import { GeneralField } from '@formily/core';
import { ISchema } from '@formily/vue';
import { FieldConfiguration } from './types';
export interface ReactionPorts {
    alive(): boolean;
    faulted(): boolean;
    fault(message: string, field?: GeneralField): void;
    /** Diagnostic ceiling; never a fixed-point solver. */
    reactionBudget?: number;
    components?: readonly string[];
    dataSourceProps?: Readonly<Record<string, string>>;
    initialize(field: GeneralField, config: FieldConfiguration, array: boolean): void;
    /** Runs authored code inside the runtime's derivation frame. */
    derive(field: GeneralField, fn: (field: GeneralField) => unknown): unknown;
}
/** Trusted schema compilation and the guarded, budgeted reaction wrapper. */
export declare function createReactions(ports: ReactionPorts): {
    compile: (node: ISchema) => ISchema;
    configOf: (node: ISchema) => FieldConfiguration | undefined;
    readonly count: number;
    /** A new external transaction starts a fresh activity budget. */
    resetActivity(): void;
};
export type Reactions = ReturnType<typeof createReactions>;
