/** Numeric schema fields retain editable text and expose the composite contract. */
export declare function createZxuiBindings(): {
    ZxInput: {
        component: import('vue').Raw<import('vue').DefineComponent<{
            modelValue?: string | number | null;
            messages?: readonly import('../fields').FieldMessage[];
        }, {
            focus: () => void | undefined;
            validate: () => boolean;
            captureEdit: () => {
                text: string;
                composition: string[];
            };
            restoreEdit(draft: import('..').Json): void;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
            "update:modelValue": (value: string) => any;
            "edit-state": (state: import('../fields').FieldEditState) => any;
        }, string, import('vue').PublicProps, Readonly<{
            modelValue?: string | number | null;
            messages?: readonly import('../fields').FieldMessage[];
        }> & Readonly<{
            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            "onEdit-state"?: ((state: import('../fields').FieldEditState) => any) | undefined;
        }>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
            input: ({
                $: import('vue').ComponentInternalInstance;
                $data: {};
                $props: Partial<{
                    type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').InputType) | ((new (...args: any[]) => string) | (() => import('element-plus').InputType) | null)[], unknown, unknown>;
                    id: string;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                    tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined) | null)[], unknown, unknown>;
                    modelModifiers: import('element-plus').InputModelModifiers;
                    autosize: import('element-plus').InputAutoSize;
                    autocomplete: AutoFill;
                    readonly: boolean;
                    clearable: boolean;
                    clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                    showPassword: boolean;
                    showWordLimit: boolean;
                    wordLimitPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
                    containerRole: string;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    inputStyle: import('vue').StyleValue;
                    autofocus: boolean;
                    rows: number;
                }> & Omit<{
                    readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').InputType) | ((new (...args: any[]) => string) | (() => import('element-plus').InputType) | null)[], unknown, unknown>;
                    readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                    readonly tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly modelValue: string | number | null;
                    readonly modelModifiers: import('element-plus').InputModelModifiers;
                    readonly autosize: import('element-plus').InputAutoSize;
                    readonly autocomplete: AutoFill;
                    readonly readonly: boolean;
                    readonly clearable: boolean;
                    readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                    readonly showPassword: boolean;
                    readonly showWordLimit: boolean;
                    readonly wordLimitPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
                    readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                    readonly autofocus: boolean;
                    readonly rows: number;
                    readonly name?: string | undefined;
                    readonly resize?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "both" | "none" | "horizontal" | "vertical", unknown> | undefined;
                    readonly size?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never> | undefined;
                    readonly id?: string | undefined;
                    readonly form?: string | undefined;
                    readonly placeholder?: string | undefined;
                    readonly disabled?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
                    readonly formatter?: ((value: string) => string) | undefined;
                    readonly parser?: ((value: string) => string) | undefined;
                    readonly inputmode?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly ariaLabel?: string | undefined;
                    readonly maxlength?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined;
                    readonly minlength?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined;
                    readonly suffixIcon?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown> | undefined;
                    readonly prefixIcon?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown> | undefined;
                    readonly containerRole?: string | undefined;
                    readonly countGraphemes?: ((value: string) => number) | undefined;
                    readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                    readonly onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                    readonly onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                    readonly onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                    readonly onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                    readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                    readonly onInput?: ((value: string) => any) | undefined;
                    readonly onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                    readonly onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                    readonly onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                    readonly onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                    readonly "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "type" | "id" | "disabled" | "tabindex" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "readonly" | "clearable" | "clearIcon" | "showPassword" | "showWordLimit" | "wordLimitPosition" | "containerRole" | "validateEvent" | "inputStyle" | "autofocus" | "rows">;
                $attrs: import('vue').Attrs;
                $refs: {
                    [x: string]: unknown;
                } & {
                    componentRef: ({
                        $: import('vue').ComponentInternalInstance;
                        $data: {};
                        $props: {
                            readonly id?: string | undefined;
                            readonly size?: import('element-plus').ComponentSize | undefined;
                            readonly disabled?: boolean | undefined;
                            readonly modelValue?: string | number | null | undefined;
                            readonly modelModifiers?: import('element-plus').InputModelModifiers | undefined;
                            readonly maxlength?: (string | number) | undefined;
                            readonly minlength?: (string | number) | undefined;
                            readonly type?: import('element-plus').InputType | undefined;
                            readonly resize?: ("none" | "both" | "horizontal" | "vertical") | undefined;
                            readonly autosize?: import('element-plus').InputAutoSize | undefined;
                            readonly autocomplete?: string | undefined;
                            readonly formatter?: ((value: string) => string) | undefined;
                            readonly parser?: ((value: string) => string) | undefined;
                            readonly placeholder?: string | undefined;
                            readonly form?: string | undefined;
                            readonly readonly?: boolean | undefined;
                            readonly clearable?: boolean | undefined;
                            readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                            readonly showPassword?: boolean | undefined;
                            readonly showWordLimit?: boolean | undefined;
                            readonly wordLimitPosition?: ("inside" | "outside") | undefined;
                            readonly suffixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                            readonly prefixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                            readonly containerRole?: string | undefined;
                            readonly tabindex?: (string | number) | undefined;
                            readonly validateEvent?: boolean | undefined;
                            readonly inputStyle?: import('vue').StyleValue;
                            readonly autofocus?: boolean | undefined;
                            readonly rows?: number | undefined;
                            readonly ariaLabel?: string | undefined;
                            readonly inputmode?: import('vue').HTMLAttributes["inputmode"];
                            readonly name?: string | undefined;
                            readonly countGraphemes?: ((value: string) => number) | undefined;
                            readonly onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                            readonly "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                            readonly onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                            readonly onInput?: ((value: string) => any) | undefined;
                            readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                            readonly onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                            readonly onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                            readonly onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                            readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                            readonly onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                            readonly onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                            readonly onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
                        $attrs: import('vue').Attrs;
                        $refs: {
                            [x: string]: unknown;
                        };
                        $slots: Readonly<{
                            [name: string]: import('vue').Slot<any> | undefined;
                        }>;
                        $root: import('vue').ComponentPublicInstance | null;
                        $parent: import('vue').ComponentPublicInstance | null;
                        $host: Element | null;
                        $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: string, evt?: Event | undefined) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "input", value: string) => void) & ((event: "keydown", evt: Event | KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear", evt: MouseEvent | undefined) => void) & ((event: "update:modelValue", value: string) => void);
                        $el: any;
                        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').InputProps> & Readonly<{
                            onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                            "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                            onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                            onInput?: ((value: string) => any) | undefined;
                            onBlur?: ((evt: FocusEvent) => any) | undefined;
                            onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                            onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                            onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                            onFocus?: ((evt: FocusEvent) => any) | undefined;
                            onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                            onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                            onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                        }>, {
                            input: import('vue').ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
                            textarea: import('vue').ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
                            ref: import('vue').ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
                            textareaStyle: import('vue').ComputedRef<import('vue').StyleValue>;
                            autosize: import('vue').Ref<import('element-plus').InputAutoSize | undefined, import('element-plus').InputAutoSize | undefined>;
                            isComposing: import('vue').Ref<boolean, boolean>;
                            passwordVisible: import('vue').Ref<boolean, boolean>;
                            focus: () => void | undefined;
                            blur: () => void | undefined;
                            select: () => void;
                            clear: (evt?: MouseEvent) => void;
                            resizeTextarea: () => void;
                        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                            clear: (evt: MouseEvent | undefined) => void;
                            "update:modelValue": (value: string) => void;
                            change: (value: string, evt?: Event | undefined) => void;
                            input: (value: string) => void;
                            blur: (evt: FocusEvent) => void;
                            compositionend: (evt: CompositionEvent) => void;
                            compositionstart: (evt: CompositionEvent) => void;
                            compositionupdate: (evt: CompositionEvent) => void;
                            focus: (evt: FocusEvent) => void;
                            keydown: (evt: Event | KeyboardEvent) => void;
                            mouseenter: (evt: MouseEvent) => void;
                            mouseleave: (evt: MouseEvent) => void;
                        }, string, {
                            type: import('element-plus').InputType;
                            disabled: boolean;
                            modelValue: string | number | null;
                            validateEvent: boolean;
                            modelModifiers: import('element-plus').InputModelModifiers;
                            autocomplete: string;
                            clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                            wordLimitPosition: "inside" | "outside";
                            tabindex: string | number;
                            inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                            rows: number;
                        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                            beforeCreate?: (() => void) | (() => void)[];
                            created?: (() => void) | (() => void)[];
                            beforeMount?: (() => void) | (() => void)[];
                            mounted?: (() => void) | (() => void)[];
                            beforeUpdate?: (() => void) | (() => void)[];
                            updated?: (() => void) | (() => void)[];
                            activated?: (() => void) | (() => void)[];
                            deactivated?: (() => void) | (() => void)[];
                            beforeDestroy?: (() => void) | (() => void)[];
                            beforeUnmount?: (() => void) | (() => void)[];
                            destroyed?: (() => void) | (() => void)[];
                            unmounted?: (() => void) | (() => void)[];
                            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                        };
                        $forceUpdate: () => void;
                        $nextTick: typeof import('vue').nextTick;
                        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
                    } & Readonly<{
                        type: import('element-plus').InputType;
                        disabled: boolean;
                        modelValue: string | number | null;
                        validateEvent: boolean;
                        modelModifiers: import('element-plus').InputModelModifiers;
                        autocomplete: string;
                        clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                        wordLimitPosition: "inside" | "outside";
                        tabindex: string | number;
                        inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                        rows: number;
                    }> & Omit<Readonly<import('element-plus').InputProps> & Readonly<{
                        onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                        onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                        onInput?: ((value: string) => any) | undefined;
                        onBlur?: ((evt: FocusEvent) => any) | undefined;
                        onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                        onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                        onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                        onFocus?: ((evt: FocusEvent) => any) | undefined;
                        onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                        onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                        onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                    }>, "blur" | "focus" | "input" | "select" | "type" | "clear" | "textarea" | "ref" | "disabled" | "tabindex" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "clearIcon" | "wordLimitPosition" | "validateEvent" | "inputStyle" | "rows" | "textareaStyle" | "isComposing" | "passwordVisible" | "resizeTextarea"> & {
                        input: HTMLInputElement | undefined;
                        textarea: HTMLTextAreaElement | undefined;
                        ref: HTMLInputElement | HTMLTextAreaElement | undefined;
                        textareaStyle: import('vue').StyleValue;
                        autosize: import('element-plus').InputAutoSize | undefined;
                        isComposing: boolean;
                        passwordVisible: boolean;
                        focus: () => void | undefined;
                        blur: () => void | undefined;
                        select: () => void;
                        clear: (evt?: MouseEvent) => void;
                        resizeTextarea: () => void;
                    } & {} & import('vue').ComponentCustomProperties & {} & {
                        $slots: {
                            prepend?: (props: {}) => any;
                        } & {
                            prefix?: (props: {}) => any;
                        } & {
                            suffix?: (props: {}) => any;
                        } & {
                            'password-icon'?: (props: {
                                visible: boolean;
                            }) => any;
                        } & {
                            append?: (props: {}) => any;
                        };
                    }) | null;
                };
                $slots: Readonly<{
                    [name: string]: import('vue').Slot<any> | undefined;
                }>;
                $root: import('vue').ComponentPublicInstance | null;
                $parent: import('vue').ComponentPublicInstance | null;
                $host: Element | null;
                $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: string, evt?: Event | undefined) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "input", value: string) => void) & ((event: "keydown", evt: Event | KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear", evt: MouseEvent | undefined) => void) & ((event: "update:modelValue", value: string) => void);
                $el: any;
                $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
                    tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "", boolean>;
                    tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "right", boolean>;
                    tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "hover", boolean>;
                    formatter: {
                        type: import('vue').PropType<(value: string) => string>;
                        required: false;
                        validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    parser: {
                        type: import('vue').PropType<(value: string) => string>;
                        required: false;
                        validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | (((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined)) | null)[], unknown, unknown, undefined, boolean>;
                    name: StringConstructor;
                    ariaLabel: StringConstructor;
                    id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                    size: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                    modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | (((new (...args: any[]) => string | number) | (() => string | number | null | undefined)) | null)[], unknown, unknown, "", boolean>;
                    modelModifiers: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').InputModelModifiers) | (() => import('element-plus').InputModelModifiers) | (((new (...args: any[]) => import('element-plus').InputModelModifiers) | (() => import('element-plus').InputModelModifiers)) | null)[], unknown, unknown, () => {}, boolean>;
                    maxlength: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    minlength: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string) | (() => import('element-plus').InputType) | (((new (...args: any[]) => string) | (() => import('element-plus').InputType)) | null)[], unknown, unknown, "text", boolean>;
                    resize: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "horizontal" | "vertical" | "none" | "both", unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    autosize: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => boolean | {
                        minRows?: number;
                        maxRows?: number;
                    }) | (() => import('element-plus').InputAutoSize) | (((new (...args: any[]) => boolean | {
                        minRows?: number;
                        maxRows?: number;
                    }) | (() => import('element-plus').InputAutoSize)) | null)[], unknown, unknown, false, boolean>;
                    autocomplete: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | (((new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill)) | null)[], unknown, unknown, "off", boolean>;
                    placeholder: {
                        readonly type: import('vue').PropType<string>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    form: {
                        readonly type: import('vue').PropType<string>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly: BooleanConstructor;
                    clearable: BooleanConstructor;
                    clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
                    showPassword: BooleanConstructor;
                    showWordLimit: BooleanConstructor;
                    wordLimitPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "inside" | "outside", unknown, "inside", boolean>;
                    suffixIcon: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    prefixIcon: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    containerRole: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                    tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    inputStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, () => import('element-plus/es/utils/typescript.mjs').Mutable<{}>, boolean>;
                    countGraphemes: {
                        readonly type: import('vue').PropType<(value: string) => number>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    autofocus: BooleanConstructor;
                    rows: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 2, boolean>;
                }>> & Readonly<{
                    onBlur?: ((evt: FocusEvent) => any) | undefined;
                    onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                    onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                    onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                    onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                    onFocus?: ((evt: FocusEvent) => any) | undefined;
                    onInput?: ((value: string) => any) | undefined;
                    onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                    onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                    onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                    onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                }>, {
                    focus: () => void | undefined;
                    blur: () => void | undefined;
                    select: () => void | undefined;
                    clear: (evt?: MouseEvent | undefined) => void | undefined;
                    input: import('vue').ComputedRef<HTMLInputElement | undefined>;
                    textarea: import('vue').ComputedRef<HTMLTextAreaElement | undefined>;
                    textareaStyle: import('vue').ComputedRef<import('vue').StyleValue>;
                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                    blur: (evt: FocusEvent) => void;
                    change: (value: string, evt?: Event | undefined) => void;
                    compositionend: (evt: CompositionEvent) => void;
                    compositionstart: (evt: CompositionEvent) => void;
                    compositionupdate: (evt: CompositionEvent) => void;
                    focus: (evt: FocusEvent) => void;
                    input: (value: string) => void;
                    keydown: (evt: Event | KeyboardEvent) => void;
                    mouseenter: (evt: MouseEvent) => void;
                    mouseleave: (evt: MouseEvent) => void;
                    clear: (evt: MouseEvent | undefined) => void;
                    "update:modelValue": (value: string) => void;
                }, string, {
                    type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').InputType) | ((new (...args: any[]) => string) | (() => import('element-plus').InputType) | null)[], unknown, unknown>;
                    id: string;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                    tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined) | null)[], unknown, unknown>;
                    modelModifiers: import('element-plus').InputModelModifiers;
                    autosize: import('element-plus').InputAutoSize;
                    autocomplete: AutoFill;
                    readonly: boolean;
                    clearable: boolean;
                    clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                    showPassword: boolean;
                    showWordLimit: boolean;
                    wordLimitPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
                    containerRole: string;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    inputStyle: import('vue').StyleValue;
                    autofocus: boolean;
                    rows: number;
                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import('vue').nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
            } & Readonly<{
                type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string) | (() => import('element-plus').InputType) | ((new (...args: any[]) => string) | (() => import('element-plus').InputType) | null)[], unknown, unknown>;
                id: string;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
                tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined) | null)[], unknown, unknown>;
                modelModifiers: import('element-plus').InputModelModifiers;
                autosize: import('element-plus').InputAutoSize;
                autocomplete: AutoFill;
                readonly: boolean;
                clearable: boolean;
                clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                showPassword: boolean;
                showWordLimit: boolean;
                wordLimitPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "inside" | "outside", unknown>;
                containerRole: string;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                inputStyle: import('vue').StyleValue;
                autofocus: boolean;
                rows: number;
            }> & Omit<Readonly<import('vue').ExtractPropTypes<{
                tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "", boolean>;
                tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "right", boolean>;
                tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "hover", boolean>;
                formatter: {
                    type: import('vue').PropType<(value: string) => string>;
                    required: false;
                    validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                parser: {
                    type: import('vue').PropType<(value: string) => string>;
                    required: false;
                    validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | (((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined)) | null)[], unknown, unknown, undefined, boolean>;
                name: StringConstructor;
                ariaLabel: StringConstructor;
                id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | (((new (...args: any[]) => string | number) | (() => string | number | null | undefined)) | null)[], unknown, unknown, "", boolean>;
                modelModifiers: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').InputModelModifiers) | (() => import('element-plus').InputModelModifiers) | (((new (...args: any[]) => import('element-plus').InputModelModifiers) | (() => import('element-plus').InputModelModifiers)) | null)[], unknown, unknown, () => {}, boolean>;
                maxlength: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                minlength: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string) | (() => import('element-plus').InputType) | (((new (...args: any[]) => string) | (() => import('element-plus').InputType)) | null)[], unknown, unknown, "text", boolean>;
                resize: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "horizontal" | "vertical" | "none" | "both", unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                autosize: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => boolean | {
                    minRows?: number;
                    maxRows?: number;
                }) | (() => import('element-plus').InputAutoSize) | (((new (...args: any[]) => boolean | {
                    minRows?: number;
                    maxRows?: number;
                }) | (() => import('element-plus').InputAutoSize)) | null)[], unknown, unknown, false, boolean>;
                autocomplete: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill) | (((new (...args: any[]) => "" | "name" | "email" | "tel" | "off" | "on" | "additional-name" | "address-level1" | "address-level2" | "address-level3" | "address-level4" | "address-line1" | "address-line2" | "address-line3" | "bday-day" | "bday-month" | "bday-year" | "cc-csc" | "cc-exp" | "cc-exp-month" | "cc-exp-year" | "cc-family-name" | "cc-given-name" | "cc-name" | "cc-number" | "cc-type" | "country" | "country-name" | "current-password" | "family-name" | "given-name" | "honorific-prefix" | "honorific-suffix" | "new-password" | "one-time-code" | "organization" | "postal-code" | "street-address" | "transaction-amount" | "transaction-currency" | "username" | "tel-area-code" | "tel-country-code" | "tel-extension" | "tel-local" | "tel-local-prefix" | "tel-local-suffix" | "tel-national" | "home email" | "home tel" | "home tel-area-code" | "home tel-country-code" | "home tel-extension" | "home tel-local" | "home tel-local-prefix" | "home tel-local-suffix" | "home tel-national" | "mobile email" | "mobile tel" | "mobile tel-area-code" | "mobile tel-country-code" | "mobile tel-extension" | "mobile tel-local" | "mobile tel-local-prefix" | "mobile tel-local-suffix" | "mobile tel-national" | "work email" | "work tel" | "work tel-area-code" | "work tel-country-code" | "work tel-extension" | "work tel-local" | "work tel-local-prefix" | "work tel-local-suffix" | "work tel-national" | "name webauthn" | "additional-name webauthn" | "address-level1 webauthn" | "address-level2 webauthn" | "address-level3 webauthn" | "address-level4 webauthn" | "address-line1 webauthn" | "address-line2 webauthn" | "address-line3 webauthn" | "bday-day webauthn" | "bday-month webauthn" | "bday-year webauthn" | "cc-csc webauthn" | "cc-exp webauthn" | "cc-exp-month webauthn" | "cc-exp-year webauthn" | "cc-family-name webauthn" | "cc-given-name webauthn" | "cc-name webauthn" | "cc-number webauthn" | "cc-type webauthn" | "country webauthn" | "country-name webauthn" | "current-password webauthn" | "family-name webauthn" | "given-name webauthn" | "honorific-prefix webauthn" | "honorific-suffix webauthn" | "new-password webauthn" | "one-time-code webauthn" | "organization webauthn" | "postal-code webauthn" | "street-address webauthn" | "transaction-amount webauthn" | "transaction-currency webauthn" | "username webauthn" | "email webauthn" | "tel webauthn" | "tel-area-code webauthn" | "tel-country-code webauthn" | "tel-extension webauthn" | "tel-local webauthn" | "tel-local-prefix webauthn" | "tel-local-suffix webauthn" | "tel-national webauthn" | "home email webauthn" | "home tel webauthn" | "home tel-area-code webauthn" | "home tel-country-code webauthn" | "home tel-extension webauthn" | "home tel-local webauthn" | "home tel-local-prefix webauthn" | "home tel-local-suffix webauthn" | "home tel-national webauthn" | "mobile email webauthn" | "mobile tel webauthn" | "mobile tel-area-code webauthn" | "mobile tel-country-code webauthn" | "mobile tel-extension webauthn" | "mobile tel-local webauthn" | "mobile tel-local-prefix webauthn" | "mobile tel-local-suffix webauthn" | "mobile tel-national webauthn" | "work email webauthn" | "work tel webauthn" | "work tel-area-code webauthn" | "work tel-country-code webauthn" | "work tel-extension webauthn" | "work tel-local webauthn" | "work tel-local-prefix webauthn" | "work tel-local-suffix webauthn" | "work tel-national webauthn" | "billing name" | "billing name webauthn" | "billing additional-name" | "billing additional-name webauthn" | "billing address-level1" | "billing address-level1 webauthn" | "billing address-level2" | "billing address-level2 webauthn" | "billing address-level3" | "billing address-level3 webauthn" | "billing address-level4" | "billing address-level4 webauthn" | "billing address-line1" | "billing address-line1 webauthn" | "billing address-line2" | "billing address-line2 webauthn" | "billing address-line3" | "billing address-line3 webauthn" | "billing bday-day" | "billing bday-day webauthn" | "billing bday-month" | "billing bday-month webauthn" | "billing bday-year" | "billing bday-year webauthn" | "billing cc-csc" | "billing cc-csc webauthn" | "billing cc-exp" | "billing cc-exp webauthn" | "billing cc-exp-month" | "billing cc-exp-month webauthn" | "billing cc-exp-year" | "billing cc-exp-year webauthn" | "billing cc-family-name" | "billing cc-family-name webauthn" | "billing cc-given-name" | "billing cc-given-name webauthn" | "billing cc-name" | "billing cc-name webauthn" | "billing cc-number" | "billing cc-number webauthn" | "billing cc-type" | "billing cc-type webauthn" | "billing country" | "billing country webauthn" | "billing country-name" | "billing country-name webauthn" | "billing current-password" | "billing current-password webauthn" | "billing family-name" | "billing family-name webauthn" | "billing given-name" | "billing given-name webauthn" | "billing honorific-prefix" | "billing honorific-prefix webauthn" | "billing honorific-suffix" | "billing honorific-suffix webauthn" | "billing new-password" | "billing new-password webauthn" | "billing one-time-code" | "billing one-time-code webauthn" | "billing organization" | "billing organization webauthn" | "billing postal-code" | "billing postal-code webauthn" | "billing street-address" | "billing street-address webauthn" | "billing transaction-amount" | "billing transaction-amount webauthn" | "billing transaction-currency" | "billing transaction-currency webauthn" | "billing username" | "billing username webauthn" | "billing email" | "billing email webauthn" | "billing tel" | "billing tel webauthn" | "billing tel-area-code" | "billing tel-area-code webauthn" | "billing tel-country-code" | "billing tel-country-code webauthn" | "billing tel-extension" | "billing tel-extension webauthn" | "billing tel-local" | "billing tel-local webauthn" | "billing tel-local-prefix" | "billing tel-local-prefix webauthn" | "billing tel-local-suffix" | "billing tel-local-suffix webauthn" | "billing tel-national" | "billing tel-national webauthn" | "billing home email" | "billing home email webauthn" | "billing home tel" | "billing home tel webauthn" | "billing home tel-area-code" | "billing home tel-area-code webauthn" | "billing home tel-country-code" | "billing home tel-country-code webauthn" | "billing home tel-extension" | "billing home tel-extension webauthn" | "billing home tel-local" | "billing home tel-local webauthn" | "billing home tel-local-prefix" | "billing home tel-local-prefix webauthn" | "billing home tel-local-suffix" | "billing home tel-local-suffix webauthn" | "billing home tel-national" | "billing home tel-national webauthn" | "billing mobile email" | "billing mobile email webauthn" | "billing mobile tel" | "billing mobile tel webauthn" | "billing mobile tel-area-code" | "billing mobile tel-area-code webauthn" | "billing mobile tel-country-code" | "billing mobile tel-country-code webauthn" | "billing mobile tel-extension" | "billing mobile tel-extension webauthn" | "billing mobile tel-local" | "billing mobile tel-local webauthn" | "billing mobile tel-local-prefix" | "billing mobile tel-local-prefix webauthn" | "billing mobile tel-local-suffix" | "billing mobile tel-local-suffix webauthn" | "billing mobile tel-national" | "billing mobile tel-national webauthn" | "billing work email" | "billing work email webauthn" | "billing work tel" | "billing work tel webauthn" | "billing work tel-area-code" | "billing work tel-area-code webauthn" | "billing work tel-country-code" | "billing work tel-country-code webauthn" | "billing work tel-extension" | "billing work tel-extension webauthn" | "billing work tel-local" | "billing work tel-local webauthn" | "billing work tel-local-prefix" | "billing work tel-local-prefix webauthn" | "billing work tel-local-suffix" | "billing work tel-local-suffix webauthn" | "billing work tel-national" | "billing work tel-national webauthn" | "shipping name" | "shipping name webauthn" | "shipping additional-name" | "shipping additional-name webauthn" | "shipping address-level1" | "shipping address-level1 webauthn" | "shipping address-level2" | "shipping address-level2 webauthn" | "shipping address-level3" | "shipping address-level3 webauthn" | "shipping address-level4" | "shipping address-level4 webauthn" | "shipping address-line1" | "shipping address-line1 webauthn" | "shipping address-line2" | "shipping address-line2 webauthn" | "shipping address-line3" | "shipping address-line3 webauthn" | "shipping bday-day" | "shipping bday-day webauthn" | "shipping bday-month" | "shipping bday-month webauthn" | "shipping bday-year" | "shipping bday-year webauthn" | "shipping cc-csc" | "shipping cc-csc webauthn" | "shipping cc-exp" | "shipping cc-exp webauthn" | "shipping cc-exp-month" | "shipping cc-exp-month webauthn" | "shipping cc-exp-year" | "shipping cc-exp-year webauthn" | "shipping cc-family-name" | "shipping cc-family-name webauthn" | "shipping cc-given-name" | "shipping cc-given-name webauthn" | "shipping cc-name" | "shipping cc-name webauthn" | "shipping cc-number" | "shipping cc-number webauthn" | "shipping cc-type" | "shipping cc-type webauthn" | "shipping country" | "shipping country webauthn" | "shipping country-name" | "shipping country-name webauthn" | "shipping current-password" | "shipping current-password webauthn" | "shipping family-name" | "shipping family-name webauthn" | "shipping given-name" | "shipping given-name webauthn" | "shipping honorific-prefix" | "shipping honorific-prefix webauthn" | "shipping honorific-suffix" | "shipping honorific-suffix webauthn" | "shipping new-password" | "shipping new-password webauthn" | "shipping one-time-code" | "shipping one-time-code webauthn" | "shipping organization" | "shipping organization webauthn" | "shipping postal-code" | "shipping postal-code webauthn" | "shipping street-address" | "shipping street-address webauthn" | "shipping transaction-amount" | "shipping transaction-amount webauthn" | "shipping transaction-currency" | "shipping transaction-currency webauthn" | "shipping username" | "shipping username webauthn" | "shipping email" | "shipping email webauthn" | "shipping tel" | "shipping tel webauthn" | "shipping tel-area-code" | "shipping tel-area-code webauthn" | "shipping tel-country-code" | "shipping tel-country-code webauthn" | "shipping tel-extension" | "shipping tel-extension webauthn" | "shipping tel-local" | "shipping tel-local webauthn" | "shipping tel-local-prefix" | "shipping tel-local-prefix webauthn" | "shipping tel-local-suffix" | "shipping tel-local-suffix webauthn" | "shipping tel-national" | "shipping tel-national webauthn" | "shipping home email" | "shipping home email webauthn" | "shipping home tel" | "shipping home tel webauthn" | "shipping home tel-area-code" | "shipping home tel-area-code webauthn" | "shipping home tel-country-code" | "shipping home tel-country-code webauthn" | "shipping home tel-extension" | "shipping home tel-extension webauthn" | "shipping home tel-local" | "shipping home tel-local webauthn" | "shipping home tel-local-prefix" | "shipping home tel-local-prefix webauthn" | "shipping home tel-local-suffix" | "shipping home tel-local-suffix webauthn" | "shipping home tel-national" | "shipping home tel-national webauthn" | "shipping mobile email" | "shipping mobile email webauthn" | "shipping mobile tel" | "shipping mobile tel webauthn" | "shipping mobile tel-area-code" | "shipping mobile tel-area-code webauthn" | "shipping mobile tel-country-code" | "shipping mobile tel-country-code webauthn" | "shipping mobile tel-extension" | "shipping mobile tel-extension webauthn" | "shipping mobile tel-local" | "shipping mobile tel-local webauthn" | "shipping mobile tel-local-prefix" | "shipping mobile tel-local-prefix webauthn" | "shipping mobile tel-local-suffix" | "shipping mobile tel-local-suffix webauthn" | "shipping mobile tel-national" | "shipping mobile tel-national webauthn" | "shipping work email" | "shipping work email webauthn" | "shipping work tel" | "shipping work tel webauthn" | "shipping work tel-area-code" | "shipping work tel-area-code webauthn" | "shipping work tel-country-code" | "shipping work tel-country-code webauthn" | "shipping work tel-extension" | "shipping work tel-extension webauthn" | "shipping work tel-local" | "shipping work tel-local webauthn" | "shipping work tel-local-prefix" | "shipping work tel-local-prefix webauthn" | "shipping work tel-local-suffix" | "shipping work tel-local-suffix webauthn" | "shipping work tel-national" | "shipping work tel-national webauthn" | `section-${string} name` | `section-${string} name webauthn` | `section-${string} additional-name` | `section-${string} additional-name webauthn` | `section-${string} address-level1` | `section-${string} address-level1 webauthn` | `section-${string} address-level2` | `section-${string} address-level2 webauthn` | `section-${string} address-level3` | `section-${string} address-level3 webauthn` | `section-${string} address-level4` | `section-${string} address-level4 webauthn` | `section-${string} address-line1` | `section-${string} address-line1 webauthn` | `section-${string} address-line2` | `section-${string} address-line2 webauthn` | `section-${string} address-line3` | `section-${string} address-line3 webauthn` | `section-${string} bday-day` | `section-${string} bday-day webauthn` | `section-${string} bday-month` | `section-${string} bday-month webauthn` | `section-${string} bday-year` | `section-${string} bday-year webauthn` | `section-${string} cc-csc` | `section-${string} cc-csc webauthn` | `section-${string} cc-exp` | `section-${string} cc-exp webauthn` | `section-${string} cc-exp-month` | `section-${string} cc-exp-month webauthn` | `section-${string} cc-exp-year` | `section-${string} cc-exp-year webauthn` | `section-${string} cc-family-name` | `section-${string} cc-family-name webauthn` | `section-${string} cc-given-name` | `section-${string} cc-given-name webauthn` | `section-${string} cc-name` | `section-${string} cc-name webauthn` | `section-${string} cc-number` | `section-${string} cc-number webauthn` | `section-${string} cc-type` | `section-${string} cc-type webauthn` | `section-${string} country` | `section-${string} country webauthn` | `section-${string} country-name` | `section-${string} country-name webauthn` | `section-${string} current-password` | `section-${string} current-password webauthn` | `section-${string} family-name` | `section-${string} family-name webauthn` | `section-${string} given-name` | `section-${string} given-name webauthn` | `section-${string} honorific-prefix` | `section-${string} honorific-prefix webauthn` | `section-${string} honorific-suffix` | `section-${string} honorific-suffix webauthn` | `section-${string} new-password` | `section-${string} new-password webauthn` | `section-${string} one-time-code` | `section-${string} one-time-code webauthn` | `section-${string} organization` | `section-${string} organization webauthn` | `section-${string} postal-code` | `section-${string} postal-code webauthn` | `section-${string} street-address` | `section-${string} street-address webauthn` | `section-${string} transaction-amount` | `section-${string} transaction-amount webauthn` | `section-${string} transaction-currency` | `section-${string} transaction-currency webauthn` | `section-${string} username` | `section-${string} username webauthn` | `section-${string} email` | `section-${string} email webauthn` | `section-${string} tel` | `section-${string} tel webauthn` | `section-${string} tel-area-code` | `section-${string} tel-area-code webauthn` | `section-${string} tel-country-code` | `section-${string} tel-country-code webauthn` | `section-${string} tel-extension` | `section-${string} tel-extension webauthn` | `section-${string} tel-local` | `section-${string} tel-local webauthn` | `section-${string} tel-local-prefix` | `section-${string} tel-local-prefix webauthn` | `section-${string} tel-local-suffix` | `section-${string} tel-local-suffix webauthn` | `section-${string} tel-national` | `section-${string} tel-national webauthn` | `section-${string} home email` | `section-${string} home email webauthn` | `section-${string} home tel` | `section-${string} home tel webauthn` | `section-${string} home tel-area-code` | `section-${string} home tel-area-code webauthn` | `section-${string} home tel-country-code` | `section-${string} home tel-country-code webauthn` | `section-${string} home tel-extension` | `section-${string} home tel-extension webauthn` | `section-${string} home tel-local` | `section-${string} home tel-local webauthn` | `section-${string} home tel-local-prefix` | `section-${string} home tel-local-prefix webauthn` | `section-${string} home tel-local-suffix` | `section-${string} home tel-local-suffix webauthn` | `section-${string} home tel-national` | `section-${string} home tel-national webauthn` | `section-${string} mobile email` | `section-${string} mobile email webauthn` | `section-${string} mobile tel` | `section-${string} mobile tel webauthn` | `section-${string} mobile tel-area-code` | `section-${string} mobile tel-area-code webauthn` | `section-${string} mobile tel-country-code` | `section-${string} mobile tel-country-code webauthn` | `section-${string} mobile tel-extension` | `section-${string} mobile tel-extension webauthn` | `section-${string} mobile tel-local` | `section-${string} mobile tel-local webauthn` | `section-${string} mobile tel-local-prefix` | `section-${string} mobile tel-local-prefix webauthn` | `section-${string} mobile tel-local-suffix` | `section-${string} mobile tel-local-suffix webauthn` | `section-${string} mobile tel-national` | `section-${string} mobile tel-national webauthn` | `section-${string} work email` | `section-${string} work email webauthn` | `section-${string} work tel` | `section-${string} work tel webauthn` | `section-${string} work tel-area-code` | `section-${string} work tel-area-code webauthn` | `section-${string} work tel-country-code` | `section-${string} work tel-country-code webauthn` | `section-${string} work tel-extension` | `section-${string} work tel-extension webauthn` | `section-${string} work tel-local` | `section-${string} work tel-local webauthn` | `section-${string} work tel-local-prefix` | `section-${string} work tel-local-prefix webauthn` | `section-${string} work tel-local-suffix` | `section-${string} work tel-local-suffix webauthn` | `section-${string} work tel-national` | `section-${string} work tel-national webauthn` | `section-${string} billing name` | `section-${string} billing name webauthn` | `section-${string} billing additional-name` | `section-${string} billing additional-name webauthn` | `section-${string} billing address-level1` | `section-${string} billing address-level1 webauthn` | `section-${string} billing address-level2` | `section-${string} billing address-level2 webauthn` | `section-${string} billing address-level3` | `section-${string} billing address-level3 webauthn` | `section-${string} billing address-level4` | `section-${string} billing address-level4 webauthn` | `section-${string} billing address-line1` | `section-${string} billing address-line1 webauthn` | `section-${string} billing address-line2` | `section-${string} billing address-line2 webauthn` | `section-${string} billing address-line3` | `section-${string} billing address-line3 webauthn` | `section-${string} billing bday-day` | `section-${string} billing bday-day webauthn` | `section-${string} billing bday-month` | `section-${string} billing bday-month webauthn` | `section-${string} billing bday-year` | `section-${string} billing bday-year webauthn` | `section-${string} billing cc-csc` | `section-${string} billing cc-csc webauthn` | `section-${string} billing cc-exp` | `section-${string} billing cc-exp webauthn` | `section-${string} billing cc-exp-month` | `section-${string} billing cc-exp-month webauthn` | `section-${string} billing cc-exp-year` | `section-${string} billing cc-exp-year webauthn` | `section-${string} billing cc-family-name` | `section-${string} billing cc-family-name webauthn` | `section-${string} billing cc-given-name` | `section-${string} billing cc-given-name webauthn` | `section-${string} billing cc-name` | `section-${string} billing cc-name webauthn` | `section-${string} billing cc-number` | `section-${string} billing cc-number webauthn` | `section-${string} billing cc-type` | `section-${string} billing cc-type webauthn` | `section-${string} billing country` | `section-${string} billing country webauthn` | `section-${string} billing country-name` | `section-${string} billing country-name webauthn` | `section-${string} billing current-password` | `section-${string} billing current-password webauthn` | `section-${string} billing family-name` | `section-${string} billing family-name webauthn` | `section-${string} billing given-name` | `section-${string} billing given-name webauthn` | `section-${string} billing honorific-prefix` | `section-${string} billing honorific-prefix webauthn` | `section-${string} billing honorific-suffix` | `section-${string} billing honorific-suffix webauthn` | `section-${string} billing new-password` | `section-${string} billing new-password webauthn` | `section-${string} billing one-time-code` | `section-${string} billing one-time-code webauthn` | `section-${string} billing organization` | `section-${string} billing organization webauthn` | `section-${string} billing postal-code` | `section-${string} billing postal-code webauthn` | `section-${string} billing street-address` | `section-${string} billing street-address webauthn` | `section-${string} billing transaction-amount` | `section-${string} billing transaction-amount webauthn` | `section-${string} billing transaction-currency` | `section-${string} billing transaction-currency webauthn` | `section-${string} billing username` | `section-${string} billing username webauthn` | `section-${string} billing email` | `section-${string} billing email webauthn` | `section-${string} billing tel` | `section-${string} billing tel webauthn` | `section-${string} billing tel-area-code` | `section-${string} billing tel-area-code webauthn` | `section-${string} billing tel-country-code` | `section-${string} billing tel-country-code webauthn` | `section-${string} billing tel-extension` | `section-${string} billing tel-extension webauthn` | `section-${string} billing tel-local` | `section-${string} billing tel-local webauthn` | `section-${string} billing tel-local-prefix` | `section-${string} billing tel-local-prefix webauthn` | `section-${string} billing tel-local-suffix` | `section-${string} billing tel-local-suffix webauthn` | `section-${string} billing tel-national` | `section-${string} billing tel-national webauthn` | `section-${string} billing home email` | `section-${string} billing home email webauthn` | `section-${string} billing home tel` | `section-${string} billing home tel webauthn` | `section-${string} billing home tel-area-code` | `section-${string} billing home tel-area-code webauthn` | `section-${string} billing home tel-country-code` | `section-${string} billing home tel-country-code webauthn` | `section-${string} billing home tel-extension` | `section-${string} billing home tel-extension webauthn` | `section-${string} billing home tel-local` | `section-${string} billing home tel-local webauthn` | `section-${string} billing home tel-local-prefix` | `section-${string} billing home tel-local-prefix webauthn` | `section-${string} billing home tel-local-suffix` | `section-${string} billing home tel-local-suffix webauthn` | `section-${string} billing home tel-national` | `section-${string} billing home tel-national webauthn` | `section-${string} billing mobile email` | `section-${string} billing mobile email webauthn` | `section-${string} billing mobile tel` | `section-${string} billing mobile tel webauthn` | `section-${string} billing mobile tel-area-code` | `section-${string} billing mobile tel-area-code webauthn` | `section-${string} billing mobile tel-country-code` | `section-${string} billing mobile tel-country-code webauthn` | `section-${string} billing mobile tel-extension` | `section-${string} billing mobile tel-extension webauthn` | `section-${string} billing mobile tel-local` | `section-${string} billing mobile tel-local webauthn` | `section-${string} billing mobile tel-local-prefix` | `section-${string} billing mobile tel-local-prefix webauthn` | `section-${string} billing mobile tel-local-suffix` | `section-${string} billing mobile tel-local-suffix webauthn` | `section-${string} billing mobile tel-national` | `section-${string} billing mobile tel-national webauthn` | `section-${string} billing work email` | `section-${string} billing work email webauthn` | `section-${string} billing work tel` | `section-${string} billing work tel webauthn` | `section-${string} billing work tel-area-code` | `section-${string} billing work tel-area-code webauthn` | `section-${string} billing work tel-country-code` | `section-${string} billing work tel-country-code webauthn` | `section-${string} billing work tel-extension` | `section-${string} billing work tel-extension webauthn` | `section-${string} billing work tel-local` | `section-${string} billing work tel-local webauthn` | `section-${string} billing work tel-local-prefix` | `section-${string} billing work tel-local-prefix webauthn` | `section-${string} billing work tel-local-suffix` | `section-${string} billing work tel-local-suffix webauthn` | `section-${string} billing work tel-national` | `section-${string} billing work tel-national webauthn` | `section-${string} shipping name` | `section-${string} shipping name webauthn` | `section-${string} shipping additional-name` | `section-${string} shipping additional-name webauthn` | `section-${string} shipping address-level1` | `section-${string} shipping address-level1 webauthn` | `section-${string} shipping address-level2` | `section-${string} shipping address-level2 webauthn` | `section-${string} shipping address-level3` | `section-${string} shipping address-level3 webauthn` | `section-${string} shipping address-level4` | `section-${string} shipping address-level4 webauthn` | `section-${string} shipping address-line1` | `section-${string} shipping address-line1 webauthn` | `section-${string} shipping address-line2` | `section-${string} shipping address-line2 webauthn` | `section-${string} shipping address-line3` | `section-${string} shipping address-line3 webauthn` | `section-${string} shipping bday-day` | `section-${string} shipping bday-day webauthn` | `section-${string} shipping bday-month` | `section-${string} shipping bday-month webauthn` | `section-${string} shipping bday-year` | `section-${string} shipping bday-year webauthn` | `section-${string} shipping cc-csc` | `section-${string} shipping cc-csc webauthn` | `section-${string} shipping cc-exp` | `section-${string} shipping cc-exp webauthn` | `section-${string} shipping cc-exp-month` | `section-${string} shipping cc-exp-month webauthn` | `section-${string} shipping cc-exp-year` | `section-${string} shipping cc-exp-year webauthn` | `section-${string} shipping cc-family-name` | `section-${string} shipping cc-family-name webauthn` | `section-${string} shipping cc-given-name` | `section-${string} shipping cc-given-name webauthn` | `section-${string} shipping cc-name` | `section-${string} shipping cc-name webauthn` | `section-${string} shipping cc-number` | `section-${string} shipping cc-number webauthn` | `section-${string} shipping cc-type` | `section-${string} shipping cc-type webauthn` | `section-${string} shipping country` | `section-${string} shipping country webauthn` | `section-${string} shipping country-name` | `section-${string} shipping country-name webauthn` | `section-${string} shipping current-password` | `section-${string} shipping current-password webauthn` | `section-${string} shipping family-name` | `section-${string} shipping family-name webauthn` | `section-${string} shipping given-name` | `section-${string} shipping given-name webauthn` | `section-${string} shipping honorific-prefix` | `section-${string} shipping honorific-prefix webauthn` | `section-${string} shipping honorific-suffix` | `section-${string} shipping honorific-suffix webauthn` | `section-${string} shipping new-password` | `section-${string} shipping new-password webauthn` | `section-${string} shipping one-time-code` | `section-${string} shipping one-time-code webauthn` | `section-${string} shipping organization` | `section-${string} shipping organization webauthn` | `section-${string} shipping postal-code` | `section-${string} shipping postal-code webauthn` | `section-${string} shipping street-address` | `section-${string} shipping street-address webauthn` | `section-${string} shipping transaction-amount` | `section-${string} shipping transaction-amount webauthn` | `section-${string} shipping transaction-currency` | `section-${string} shipping transaction-currency webauthn` | `section-${string} shipping username` | `section-${string} shipping username webauthn` | `section-${string} shipping email` | `section-${string} shipping email webauthn` | `section-${string} shipping tel` | `section-${string} shipping tel webauthn` | `section-${string} shipping tel-area-code` | `section-${string} shipping tel-area-code webauthn` | `section-${string} shipping tel-country-code` | `section-${string} shipping tel-country-code webauthn` | `section-${string} shipping tel-extension` | `section-${string} shipping tel-extension webauthn` | `section-${string} shipping tel-local` | `section-${string} shipping tel-local webauthn` | `section-${string} shipping tel-local-prefix` | `section-${string} shipping tel-local-prefix webauthn` | `section-${string} shipping tel-local-suffix` | `section-${string} shipping tel-local-suffix webauthn` | `section-${string} shipping tel-national` | `section-${string} shipping tel-national webauthn` | `section-${string} shipping home email` | `section-${string} shipping home email webauthn` | `section-${string} shipping home tel` | `section-${string} shipping home tel webauthn` | `section-${string} shipping home tel-area-code` | `section-${string} shipping home tel-area-code webauthn` | `section-${string} shipping home tel-country-code` | `section-${string} shipping home tel-country-code webauthn` | `section-${string} shipping home tel-extension` | `section-${string} shipping home tel-extension webauthn` | `section-${string} shipping home tel-local` | `section-${string} shipping home tel-local webauthn` | `section-${string} shipping home tel-local-prefix` | `section-${string} shipping home tel-local-prefix webauthn` | `section-${string} shipping home tel-local-suffix` | `section-${string} shipping home tel-local-suffix webauthn` | `section-${string} shipping home tel-national` | `section-${string} shipping home tel-national webauthn` | `section-${string} shipping mobile email` | `section-${string} shipping mobile email webauthn` | `section-${string} shipping mobile tel` | `section-${string} shipping mobile tel webauthn` | `section-${string} shipping mobile tel-area-code` | `section-${string} shipping mobile tel-area-code webauthn` | `section-${string} shipping mobile tel-country-code` | `section-${string} shipping mobile tel-country-code webauthn` | `section-${string} shipping mobile tel-extension` | `section-${string} shipping mobile tel-extension webauthn` | `section-${string} shipping mobile tel-local` | `section-${string} shipping mobile tel-local webauthn` | `section-${string} shipping mobile tel-local-prefix` | `section-${string} shipping mobile tel-local-prefix webauthn` | `section-${string} shipping mobile tel-local-suffix` | `section-${string} shipping mobile tel-local-suffix webauthn` | `section-${string} shipping mobile tel-national` | `section-${string} shipping mobile tel-national webauthn` | `section-${string} shipping work email` | `section-${string} shipping work email webauthn` | `section-${string} shipping work tel` | `section-${string} shipping work tel webauthn` | `section-${string} shipping work tel-area-code` | `section-${string} shipping work tel-area-code webauthn` | `section-${string} shipping work tel-country-code` | `section-${string} shipping work tel-country-code webauthn` | `section-${string} shipping work tel-extension` | `section-${string} shipping work tel-extension webauthn` | `section-${string} shipping work tel-local` | `section-${string} shipping work tel-local webauthn` | `section-${string} shipping work tel-local-prefix` | `section-${string} shipping work tel-local-prefix webauthn` | `section-${string} shipping work tel-local-suffix` | `section-${string} shipping work tel-local-suffix webauthn` | `section-${string} shipping work tel-national` | `section-${string} shipping work tel-national webauthn`) | (() => AutoFill)) | null)[], unknown, unknown, "off", boolean>;
                placeholder: {
                    readonly type: import('vue').PropType<string>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                form: {
                    readonly type: import('vue').PropType<string>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly: BooleanConstructor;
                clearable: BooleanConstructor;
                clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
                showPassword: BooleanConstructor;
                showWordLimit: BooleanConstructor;
                wordLimitPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "inside" | "outside", unknown, "inside", boolean>;
                suffixIcon: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                prefixIcon: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                containerRole: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                inputStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, () => import('element-plus/es/utils/typescript.mjs').Mutable<{}>, boolean>;
                countGraphemes: {
                    readonly type: import('vue').PropType<(value: string) => number>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                autofocus: BooleanConstructor;
                rows: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 2, boolean>;
            }>> & Readonly<{
                onBlur?: ((evt: FocusEvent) => any) | undefined;
                onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                onFocus?: ((evt: FocusEvent) => any) | undefined;
                onInput?: ((value: string) => any) | undefined;
                onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                "onUpdate:modelValue"?: ((value: string) => any) | undefined;
            }>, "blur" | "focus" | "input" | "select" | "clear" | "textarea" | "textareaStyle" | ("type" | "id" | "disabled" | "tabindex" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "readonly" | "clearable" | "clearIcon" | "showPassword" | "showWordLimit" | "wordLimitPosition" | "containerRole" | "validateEvent" | "inputStyle" | "autofocus" | "rows")> & {
                focus: () => void | undefined;
                blur: () => void | undefined;
                select: () => void | undefined;
                clear: (evt?: MouseEvent | undefined) => void | undefined;
                input: HTMLInputElement | undefined;
                textarea: HTMLTextAreaElement | undefined;
                textareaStyle: import('vue').StyleValue;
            } & {} & import('vue').ComponentCustomProperties & {} & {
                $slots: Readonly<{
                    prefix?(props: Record<string, unknown>): unknown;
                    suffix?(props: Record<string, unknown>): unknown;
                    prepend?(props: Record<string, unknown>): unknown;
                    append?(props: Record<string, unknown>): unknown;
                }> & {
                    prefix?(props: Record<string, unknown>): unknown;
                    suffix?(props: Record<string, unknown>): unknown;
                    prepend?(props: Record<string, unknown>): unknown;
                    append?(props: Record<string, unknown>): unknown;
                };
            }) | null;
        }, any>>;
        composite: true;
        group: boolean;
        validationOwnership: "managed";
        editObservation: "raw-sequence";
    };
    ZxInputNumber: {
        component: import('vue').Raw<import('vue').DefineComponent<{
            modelValue?: number | null;
            disabled?: boolean;
            readonly?: boolean;
            min?: number;
            max?: number;
            step?: number;
            precision?: number;
            stepStrictly?: boolean;
            disabledScientific?: boolean;
            controls?: boolean;
            controlsPosition?: "" | "right";
            messages?: readonly import('../fields').FieldMessage[];
        }, {
            focus: () => void | undefined;
            validate: () => boolean;
            captureEdit: () => {
                text: string;
                composition: string[];
            };
            restoreEdit(draft: import('..').Json): void;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
            blur: (value: FocusEvent) => any;
            focus: (value: FocusEvent) => any;
            "update:modelValue": (value: number | null) => any;
            "edit-state": (state: import('../fields').FieldEditState) => any;
        }, string, import('vue').PublicProps, Readonly<{
            modelValue?: number | null;
            disabled?: boolean;
            readonly?: boolean;
            min?: number;
            max?: number;
            step?: number;
            precision?: number;
            stepStrictly?: boolean;
            disabledScientific?: boolean;
            controls?: boolean;
            controlsPosition?: "" | "right";
            messages?: readonly import('../fields').FieldMessage[];
        }> & Readonly<{
            onBlur?: ((value: FocusEvent) => any) | undefined;
            onFocus?: ((value: FocusEvent) => any) | undefined;
            "onUpdate:modelValue"?: ((value: number | null) => any) | undefined;
            "onEdit-state"?: ((state: import('../fields').FieldEditState) => any) | undefined;
        }>, {
            step: number;
            controls: boolean;
        }, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
            input: ({
                $: import('vue').ComponentInternalInstance;
                $data: {};
                $props: Partial<{
                    id: string;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    min: number;
                    max: number;
                    tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly: boolean;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                    step: number;
                    stepStrictly: boolean;
                    controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                    align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                    disabledScientific: boolean;
                }> & Omit<{
                    readonly min: number;
                    readonly max: number;
                    readonly tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    readonly readonly: boolean;
                    readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                    readonly step: number;
                    readonly stepStrictly: boolean;
                    readonly controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                    readonly align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                    readonly disabledScientific: boolean;
                    readonly name?: string | undefined;
                    readonly size?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never> | undefined;
                    readonly id?: string | undefined;
                    readonly text?: string | undefined;
                    readonly placeholder?: string | undefined;
                    readonly disabled?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
                    readonly inputmode?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly ariaLabel?: string | undefined;
                    readonly modelValue?: number | null | undefined;
                    readonly precision?: number | undefined;
                    readonly onBlur?: ((e: FocusEvent) => any) | undefined;
                    readonly onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                    readonly onFocus?: ((e: FocusEvent) => any) | undefined;
                    readonly onInput?: ((val: number | null | undefined) => any) | undefined;
                    readonly "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                    readonly "onUpdate:text"?: ((value: string) => any) | undefined;
                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific">;
                $attrs: import('vue').Attrs;
                $refs: {
                    [x: string]: unknown;
                } & {
                    componentRef: ({
                        $: import('vue').ComponentInternalInstance;
                        $data: {};
                        $props: Partial<{
                            id: string;
                            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            min: number;
                            max: number;
                            tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                            readonly: boolean;
                            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                            step: number;
                            stepStrictly: boolean;
                            controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                            align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                            disabledScientific: boolean;
                            nativeAttrs: Record<string, unknown>;
                        }> & Omit<{
                            readonly min: number;
                            readonly max: number;
                            readonly tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            readonly tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            readonly tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            readonly readonly: boolean;
                            readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                            readonly step: number;
                            readonly stepStrictly: boolean;
                            readonly controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            readonly controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                            readonly align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                            readonly disabledScientific: boolean;
                            readonly nativeAttrs: Record<string, unknown>;
                            readonly name?: string | undefined;
                            readonly size?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never> | undefined;
                            readonly id?: string | undefined;
                            readonly text?: string | undefined;
                            readonly placeholder?: string | undefined;
                            readonly disabled?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
                            readonly inputmode?: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                            readonly ariaLabel?: string | undefined;
                            readonly modelValue?: number | null | undefined;
                            readonly precision?: number | undefined;
                            readonly onBlur?: ((e: FocusEvent) => any) | undefined;
                            readonly onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                            readonly onFocus?: ((e: FocusEvent) => any) | undefined;
                            readonly onInput?: ((val: number | null | undefined) => any) | undefined;
                            readonly "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                            readonly "onUpdate:text"?: ((value: string) => any) | undefined;
                        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific" | "nativeAttrs">;
                        $attrs: import('vue').Attrs;
                        $refs: {
                            [x: string]: unknown;
                        } & {
                            input: ({
                                $: import('vue').ComponentInternalInstance;
                                $data: {};
                                $props: {
                                    readonly id?: string | undefined;
                                    readonly size?: import('element-plus').ComponentSize | undefined;
                                    readonly disabled?: boolean | undefined;
                                    readonly modelValue?: string | number | null | undefined;
                                    readonly modelModifiers?: import('element-plus').InputModelModifiers | undefined;
                                    readonly maxlength?: (string | number) | undefined;
                                    readonly minlength?: (string | number) | undefined;
                                    readonly type?: import('element-plus').InputType | undefined;
                                    readonly resize?: ("none" | "both" | "horizontal" | "vertical") | undefined;
                                    readonly autosize?: import('element-plus').InputAutoSize | undefined;
                                    readonly autocomplete?: string | undefined;
                                    readonly formatter?: ((value: string) => string) | undefined;
                                    readonly parser?: ((value: string) => string) | undefined;
                                    readonly placeholder?: string | undefined;
                                    readonly form?: string | undefined;
                                    readonly readonly?: boolean | undefined;
                                    readonly clearable?: boolean | undefined;
                                    readonly clearIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                                    readonly showPassword?: boolean | undefined;
                                    readonly showWordLimit?: boolean | undefined;
                                    readonly wordLimitPosition?: ("inside" | "outside") | undefined;
                                    readonly suffixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                                    readonly prefixIcon?: import('element-plus/es/utils/vue/icon.mjs').IconPropType | undefined;
                                    readonly containerRole?: string | undefined;
                                    readonly tabindex?: (string | number) | undefined;
                                    readonly validateEvent?: boolean | undefined;
                                    readonly inputStyle?: import('vue').StyleValue;
                                    readonly autofocus?: boolean | undefined;
                                    readonly rows?: number | undefined;
                                    readonly ariaLabel?: string | undefined;
                                    readonly inputmode?: import('vue').HTMLAttributes["inputmode"];
                                    readonly name?: string | undefined;
                                    readonly countGraphemes?: ((value: string) => number) | undefined;
                                    readonly onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                                    readonly "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                                    readonly onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                                    readonly onInput?: ((value: string) => any) | undefined;
                                    readonly onBlur?: ((evt: FocusEvent) => any) | undefined;
                                    readonly onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                                    readonly onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                                    readonly onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                                    readonly onFocus?: ((evt: FocusEvent) => any) | undefined;
                                    readonly onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                                    readonly onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                                    readonly onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
                                $attrs: import('vue').Attrs;
                                $refs: {
                                    [x: string]: unknown;
                                };
                                $slots: Readonly<{
                                    [name: string]: import('vue').Slot<any> | undefined;
                                }>;
                                $root: import('vue').ComponentPublicInstance | null;
                                $parent: import('vue').ComponentPublicInstance | null;
                                $host: Element | null;
                                $emit: ((event: "blur", evt: FocusEvent) => void) & ((event: "change", value: string, evt?: Event | undefined) => void) & ((event: "compositionend", evt: CompositionEvent) => void) & ((event: "compositionstart", evt: CompositionEvent) => void) & ((event: "compositionupdate", evt: CompositionEvent) => void) & ((event: "focus", evt: FocusEvent) => void) & ((event: "input", value: string) => void) & ((event: "keydown", evt: Event | KeyboardEvent) => void) & ((event: "mouseenter", evt: MouseEvent) => void) & ((event: "mouseleave", evt: MouseEvent) => void) & ((event: "clear", evt: MouseEvent | undefined) => void) & ((event: "update:modelValue", value: string) => void);
                                $el: any;
                                $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').InputProps> & Readonly<{
                                    onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                                    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                                    onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                                    onInput?: ((value: string) => any) | undefined;
                                    onBlur?: ((evt: FocusEvent) => any) | undefined;
                                    onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                                    onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                                    onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                                    onFocus?: ((evt: FocusEvent) => any) | undefined;
                                    onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                                    onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                                    onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                                }>, {
                                    input: import('vue').ShallowRef<HTMLInputElement | undefined, HTMLInputElement | undefined>;
                                    textarea: import('vue').ShallowRef<HTMLTextAreaElement | undefined, HTMLTextAreaElement | undefined>;
                                    ref: import('vue').ComputedRef<HTMLInputElement | HTMLTextAreaElement | undefined>;
                                    textareaStyle: import('vue').ComputedRef<import('vue').StyleValue>;
                                    autosize: import('vue').Ref<import('element-plus').InputAutoSize | undefined, import('element-plus').InputAutoSize | undefined>;
                                    isComposing: import('vue').Ref<boolean, boolean>;
                                    passwordVisible: import('vue').Ref<boolean, boolean>;
                                    focus: () => void | undefined;
                                    blur: () => void | undefined;
                                    select: () => void;
                                    clear: (evt?: MouseEvent) => void;
                                    resizeTextarea: () => void;
                                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                                    clear: (evt: MouseEvent | undefined) => void;
                                    "update:modelValue": (value: string) => void;
                                    change: (value: string, evt?: Event | undefined) => void;
                                    input: (value: string) => void;
                                    blur: (evt: FocusEvent) => void;
                                    compositionend: (evt: CompositionEvent) => void;
                                    compositionstart: (evt: CompositionEvent) => void;
                                    compositionupdate: (evt: CompositionEvent) => void;
                                    focus: (evt: FocusEvent) => void;
                                    keydown: (evt: Event | KeyboardEvent) => void;
                                    mouseenter: (evt: MouseEvent) => void;
                                    mouseleave: (evt: MouseEvent) => void;
                                }, string, {
                                    type: import('element-plus').InputType;
                                    disabled: boolean;
                                    modelValue: string | number | null;
                                    validateEvent: boolean;
                                    modelModifiers: import('element-plus').InputModelModifiers;
                                    autocomplete: string;
                                    clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                                    wordLimitPosition: "inside" | "outside";
                                    tabindex: string | number;
                                    inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                                    rows: number;
                                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                                    beforeCreate?: (() => void) | (() => void)[];
                                    created?: (() => void) | (() => void)[];
                                    beforeMount?: (() => void) | (() => void)[];
                                    mounted?: (() => void) | (() => void)[];
                                    beforeUpdate?: (() => void) | (() => void)[];
                                    updated?: (() => void) | (() => void)[];
                                    activated?: (() => void) | (() => void)[];
                                    deactivated?: (() => void) | (() => void)[];
                                    beforeDestroy?: (() => void) | (() => void)[];
                                    beforeUnmount?: (() => void) | (() => void)[];
                                    destroyed?: (() => void) | (() => void)[];
                                    unmounted?: (() => void) | (() => void)[];
                                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                                };
                                $forceUpdate: () => void;
                                $nextTick: typeof import('vue').nextTick;
                                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
                            } & Readonly<{
                                type: import('element-plus').InputType;
                                disabled: boolean;
                                modelValue: string | number | null;
                                validateEvent: boolean;
                                modelModifiers: import('element-plus').InputModelModifiers;
                                autocomplete: string;
                                clearIcon: import('element-plus/es/utils/vue/icon.mjs').IconPropType;
                                wordLimitPosition: "inside" | "outside";
                                tabindex: string | number;
                                inputStyle: string | false | import('vue').CSSProperties | import('vue').StyleValue[] | null;
                                rows: number;
                            }> & Omit<Readonly<import('element-plus').InputProps> & Readonly<{
                                onClear?: ((evt: MouseEvent | undefined) => any) | undefined;
                                "onUpdate:modelValue"?: ((value: string) => any) | undefined;
                                onChange?: ((value: string, evt?: Event | undefined) => any) | undefined;
                                onInput?: ((value: string) => any) | undefined;
                                onBlur?: ((evt: FocusEvent) => any) | undefined;
                                onCompositionend?: ((evt: CompositionEvent) => any) | undefined;
                                onCompositionstart?: ((evt: CompositionEvent) => any) | undefined;
                                onCompositionupdate?: ((evt: CompositionEvent) => any) | undefined;
                                onFocus?: ((evt: FocusEvent) => any) | undefined;
                                onKeydown?: ((evt: Event | KeyboardEvent) => any) | undefined;
                                onMouseenter?: ((evt: MouseEvent) => any) | undefined;
                                onMouseleave?: ((evt: MouseEvent) => any) | undefined;
                            }>, "blur" | "focus" | "input" | "select" | "type" | "clear" | "textarea" | "ref" | "disabled" | "tabindex" | "modelValue" | "modelModifiers" | "autosize" | "autocomplete" | "clearIcon" | "wordLimitPosition" | "validateEvent" | "inputStyle" | "rows" | "textareaStyle" | "isComposing" | "passwordVisible" | "resizeTextarea"> & {
                                input: HTMLInputElement | undefined;
                                textarea: HTMLTextAreaElement | undefined;
                                ref: HTMLInputElement | HTMLTextAreaElement | undefined;
                                textareaStyle: import('vue').StyleValue;
                                autosize: import('element-plus').InputAutoSize | undefined;
                                isComposing: boolean;
                                passwordVisible: boolean;
                                focus: () => void | undefined;
                                blur: () => void | undefined;
                                select: () => void;
                                clear: (evt?: MouseEvent) => void;
                                resizeTextarea: () => void;
                            } & {} & import('vue').ComponentCustomProperties & {} & {
                                $slots: {
                                    prepend?: (props: {}) => any;
                                } & {
                                    prefix?: (props: {}) => any;
                                } & {
                                    suffix?: (props: {}) => any;
                                } & {
                                    'password-icon'?: (props: {
                                        visible: boolean;
                                    }) => any;
                                } & {
                                    append?: (props: {}) => any;
                                };
                            }) | null;
                        };
                        $slots: Readonly<{
                            [name: string]: import('vue').Slot<any> | undefined;
                        }>;
                        $root: import('vue').ComponentPublicInstance | null;
                        $parent: import('vue').ComponentPublicInstance | null;
                        $host: Element | null;
                        $emit: ((event: "blur", e: FocusEvent) => void) & ((event: "change", value: number | null | undefined, oldValue: number | null | undefined) => void) & ((event: "focus", e: FocusEvent) => void) & ((event: "input", val: number | null | undefined) => void) & ((event: "update:modelValue", value: number | null | undefined) => void) & ((event: "update:text", value: string) => void);
                        $el: any;
                        $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
                            nativeAttrs: {
                                type: import('vue').PropType<Record<string, unknown>>;
                                default: () => {};
                            };
                            tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown, "", boolean>;
                            tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown, "right", boolean>;
                            tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown, "hover", boolean>;
                            id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                            step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
                            stepStrictly: BooleanConstructor;
                            max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                            min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                            readonly: BooleanConstructor;
                            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                            size: {
                                readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                                readonly required: false;
                                readonly validator: ((val: unknown) => boolean) | undefined;
                                __epPropKey: true;
                            };
                            controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                            controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
                            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
                            name: StringConstructor;
                            placeholder: StringConstructor;
                            precision: {
                                readonly type: import('vue').PropType<number>;
                                readonly required: false;
                                readonly validator: ((val: unknown) => boolean) | undefined;
                                __epPropKey: true;
                            };
                            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                            ariaLabel: StringConstructor;
                            inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
                            align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
                            disabledScientific: BooleanConstructor;
                            modelValue: {
                                type: import('vue').PropType<number | null>;
                                required: false;
                                validator: ((val: unknown) => boolean) | undefined;
                                __epPropKey: true;
                            };
                            text: StringConstructor;
                        }>> & Readonly<{
                            onBlur?: ((e: FocusEvent) => any) | undefined;
                            onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                            onFocus?: ((e: FocusEvent) => any) | undefined;
                            onInput?: ((val: number | null | undefined) => any) | undefined;
                            "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                            "onUpdate:text"?: ((value: string) => any) | undefined;
                        }>, {
                            focus: () => void | undefined;
                            blur: () => void | undefined;
                        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                            blur: (e: FocusEvent) => void;
                            change: (value: number | null | undefined, oldValue: number | null | undefined) => void;
                            focus: (e: FocusEvent) => void;
                            input: (val: number | null | undefined) => void;
                            "update:modelValue": (value: number | null | undefined) => void;
                            "update:text": (value: string) => void;
                        }, string, {
                            id: string;
                            disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            min: number;
                            max: number;
                            tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                                (): string | import('@zxio/components/input').InputTooltipConfig;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                                (): import('@zxio/utils/dist/es').Placement;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                                (): import('@zxio/components/input').InputTooltipTrigger;
                                new (): any;
                                readonly prototype: any;
                            }) | null)[], unknown, unknown>;
                            inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                            readonly: boolean;
                            validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                            step: number;
                            stepStrictly: boolean;
                            controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                            controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                            align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                            disabledScientific: boolean;
                            nativeAttrs: Record<string, unknown>;
                        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                            beforeCreate?: (() => void) | (() => void)[];
                            created?: (() => void) | (() => void)[];
                            beforeMount?: (() => void) | (() => void)[];
                            mounted?: (() => void) | (() => void)[];
                            beforeUpdate?: (() => void) | (() => void)[];
                            updated?: (() => void) | (() => void)[];
                            activated?: (() => void) | (() => void)[];
                            deactivated?: (() => void) | (() => void)[];
                            beforeDestroy?: (() => void) | (() => void)[];
                            beforeUnmount?: (() => void) | (() => void)[];
                            destroyed?: (() => void) | (() => void)[];
                            unmounted?: (() => void) | (() => void)[];
                            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                        };
                        $forceUpdate: () => void;
                        $nextTick: typeof import('vue').nextTick;
                        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
                    } & Readonly<{
                        id: string;
                        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                        min: number;
                        max: number;
                        tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                            (): string | import('@zxio/components/input').InputTooltipConfig;
                            new (): any;
                            readonly prototype: any;
                        } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                            (): string | import('@zxio/components/input').InputTooltipConfig;
                            new (): any;
                            readonly prototype: any;
                        }) | null)[], unknown, unknown>;
                        tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                            (): import('@zxio/utils/dist/es').Placement;
                            new (): any;
                            readonly prototype: any;
                        } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                            (): import('@zxio/utils/dist/es').Placement;
                            new (): any;
                            readonly prototype: any;
                        }) | null)[], unknown, unknown>;
                        tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                            (): import('@zxio/components/input').InputTooltipTrigger;
                            new (): any;
                            readonly prototype: any;
                        } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                            (): import('@zxio/components/input').InputTooltipTrigger;
                            new (): any;
                            readonly prototype: any;
                        }) | null)[], unknown, unknown>;
                        inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                        readonly: boolean;
                        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                        step: number;
                        stepStrictly: boolean;
                        controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                        controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                        align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                        disabledScientific: boolean;
                        nativeAttrs: Record<string, unknown>;
                    }> & Omit<Readonly<import('vue').ExtractPropTypes<{
                        nativeAttrs: {
                            type: import('vue').PropType<Record<string, unknown>>;
                            default: () => {};
                        };
                        tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                            (): string | import('@zxio/components/input').InputTooltipConfig;
                            new (): any;
                            readonly prototype: any;
                        } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                            (): string | import('@zxio/components/input').InputTooltipConfig;
                            new (): any;
                            readonly prototype: any;
                        }) | null)[], unknown, unknown, "", boolean>;
                        tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                            (): import('@zxio/utils/dist/es').Placement;
                            new (): any;
                            readonly prototype: any;
                        } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                            (): import('@zxio/utils/dist/es').Placement;
                            new (): any;
                            readonly prototype: any;
                        }) | null)[], unknown, unknown, "right", boolean>;
                        tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                            (): import('@zxio/components/input').InputTooltipTrigger;
                            new (): any;
                            readonly prototype: any;
                        } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                            (): import('@zxio/components/input').InputTooltipTrigger;
                            new (): any;
                            readonly prototype: any;
                        }) | null)[], unknown, unknown, "hover", boolean>;
                        id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                        step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
                        stepStrictly: BooleanConstructor;
                        max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                        min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                        readonly: BooleanConstructor;
                        disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                        size: {
                            readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                            readonly required: false;
                            readonly validator: ((val: unknown) => boolean) | undefined;
                            __epPropKey: true;
                        };
                        controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                        controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
                        valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
                        name: StringConstructor;
                        placeholder: StringConstructor;
                        precision: {
                            readonly type: import('vue').PropType<number>;
                            readonly required: false;
                            readonly validator: ((val: unknown) => boolean) | undefined;
                            __epPropKey: true;
                        };
                        validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                        ariaLabel: StringConstructor;
                        inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
                        align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
                        disabledScientific: BooleanConstructor;
                        modelValue: {
                            type: import('vue').PropType<number | null>;
                            required: false;
                            validator: ((val: unknown) => boolean) | undefined;
                            __epPropKey: true;
                        };
                        text: StringConstructor;
                    }>> & Readonly<{
                        onBlur?: ((e: FocusEvent) => any) | undefined;
                        onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                        onFocus?: ((e: FocusEvent) => any) | undefined;
                        onInput?: ((val: number | null | undefined) => any) | undefined;
                        "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                        "onUpdate:text"?: ((value: string) => any) | undefined;
                    }>, "blur" | "focus" | ("id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific" | "nativeAttrs")> & {
                        focus: () => void | undefined;
                        blur: () => void | undefined;
                    } & {} & import('vue').ComponentCustomProperties & {} & {
                        $slots: Readonly<{
                            prefix?(props?: Record<string, unknown>): unknown;
                            suffix?(props?: Record<string, unknown>): unknown;
                            'increase-icon'?(props?: Record<string, unknown>): unknown;
                            'decrease-icon'?(props?: Record<string, unknown>): unknown;
                        }> & {
                            prefix?(props?: Record<string, unknown>): unknown;
                            suffix?(props?: Record<string, unknown>): unknown;
                            'increase-icon'?(props?: Record<string, unknown>): unknown;
                            'decrease-icon'?(props?: Record<string, unknown>): unknown;
                        };
                    }) | null;
                };
                $slots: Readonly<{
                    [name: string]: import('vue').Slot<any> | undefined;
                }>;
                $root: import('vue').ComponentPublicInstance | null;
                $parent: import('vue').ComponentPublicInstance | null;
                $host: Element | null;
                $emit: ((event: "blur", e: FocusEvent) => void) & ((event: "change", value: number | null | undefined, oldValue: number | null | undefined) => void) & ((event: "focus", e: FocusEvent) => void) & ((event: "input", val: number | null | undefined) => void) & ((event: "update:modelValue", value: number | null | undefined) => void) & ((event: "update:text", value: string) => void);
                $el: any;
                $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
                    tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "", boolean>;
                    tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "right", boolean>;
                    tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown, "hover", boolean>;
                    id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                    step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
                    stepStrictly: BooleanConstructor;
                    max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                    min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                    readonly: BooleanConstructor;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                    size: {
                        readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
                    valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
                    name: StringConstructor;
                    placeholder: StringConstructor;
                    precision: {
                        readonly type: import('vue').PropType<number>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    ariaLabel: StringConstructor;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
                    align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
                    disabledScientific: BooleanConstructor;
                    modelValue: {
                        type: import('vue').PropType<number | null>;
                        required: false;
                        validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    text: StringConstructor;
                }>> & Readonly<{
                    onBlur?: ((e: FocusEvent) => any) | undefined;
                    onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                    onFocus?: ((e: FocusEvent) => any) | undefined;
                    onInput?: ((val: number | null | undefined) => any) | undefined;
                    "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                    "onUpdate:text"?: ((value: string) => any) | undefined;
                }>, {
                    focus: () => void | undefined;
                    blur: () => void | undefined;
                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                    blur: (e: FocusEvent) => void;
                    change: (value: number | null | undefined, oldValue: number | null | undefined) => void;
                    focus: (e: FocusEvent) => void;
                    input: (val: number | null | undefined) => void;
                    "update:modelValue": (value: number | null | undefined) => void;
                    "update:text": (value: string) => void;
                }, string, {
                    id: string;
                    disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    min: number;
                    max: number;
                    tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                        (): string | import('@zxio/components/input').InputTooltipConfig;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                        (): import('@zxio/utils/dist/es').Placement;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                        (): import('@zxio/components/input').InputTooltipTrigger;
                        new (): any;
                        readonly prototype: any;
                    }) | null)[], unknown, unknown>;
                    inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                    readonly: boolean;
                    validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                    step: number;
                    stepStrictly: boolean;
                    controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                    align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                    disabledScientific: boolean;
                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import('vue').nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
            } & Readonly<{
                id: string;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                min: number;
                max: number;
                tooltip: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                tooltipPlacement: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                tooltipTrigger: import('@zxio/shared').EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown>;
                inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown>;
                readonly: boolean;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown>;
                step: number;
                stepStrictly: boolean;
                controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "right", unknown>;
                align: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown>;
                disabledScientific: boolean;
            }> & Omit<Readonly<import('vue').ExtractPropTypes<{
                tooltip: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string | import('@zxio/components/input').InputTooltipConfig) | (() => string | import('@zxio/components/input').InputTooltipConfig) | {
                    (): string | import('@zxio/components/input').InputTooltipConfig;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "", boolean>;
                tooltipPlacement: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => string) | (() => import('@zxio/utils/dist/es').Placement) | {
                    (): import('@zxio/utils/dist/es').Placement;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "right", boolean>;
                tooltipTrigger: import('@zxio/shared').EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                } | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import('@zxio/components/input').InputTooltipTrigger) | {
                    (): import('@zxio/components/input').InputTooltipTrigger;
                    new (): any;
                    readonly prototype: any;
                }) | null)[], unknown, unknown, "hover", boolean>;
                id: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
                step: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
                stepStrictly: BooleanConstructor;
                max: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                min: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                readonly: BooleanConstructor;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                controls: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                controlsPosition: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, "" | "right", unknown, "", boolean>;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | null)[], unknown, unknown, null, boolean>;
                name: StringConstructor;
                placeholder: StringConstructor;
                precision: {
                    readonly type: import('vue').PropType<number>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                ariaLabel: StringConstructor;
                inputmode: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal") | (() => "none" | "text" | "search" | "email" | "tel" | "url" | "numeric" | "decimal" | undefined) | null)[], unknown, unknown, undefined, boolean>;
                align: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | null)[], unknown, unknown, "center", boolean>;
                disabledScientific: BooleanConstructor;
                modelValue: {
                    type: import('vue').PropType<number | null>;
                    required: false;
                    validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                text: StringConstructor;
            }>> & Readonly<{
                onBlur?: ((e: FocusEvent) => any) | undefined;
                onChange?: ((value: number | null | undefined, oldValue: number | null | undefined) => any) | undefined;
                onFocus?: ((e: FocusEvent) => any) | undefined;
                onInput?: ((val: number | null | undefined) => any) | undefined;
                "onUpdate:modelValue"?: ((value: number | null | undefined) => any) | undefined;
                "onUpdate:text"?: ((value: string) => any) | undefined;
            }>, "blur" | "focus" | ("id" | "disabled" | "min" | "max" | "tooltip" | "tooltipPlacement" | "tooltipTrigger" | "inputmode" | "readonly" | "validateEvent" | "valueOnClear" | "step" | "stepStrictly" | "controls" | "controlsPosition" | "align" | "disabledScientific")> & {
                focus: () => void | undefined;
                blur: () => void | undefined;
            } & {} & import('vue').ComponentCustomProperties & {} & {
                $slots: Readonly<{
                    prefix?(props: Record<string, unknown>): unknown;
                    suffix?(props: Record<string, unknown>): unknown;
                    'increase-icon'?(props: Record<string, unknown>): unknown;
                    'decrease-icon'?(props: Record<string, unknown>): unknown;
                }> & {
                    prefix?(props: Record<string, unknown>): unknown;
                    suffix?(props: Record<string, unknown>): unknown;
                    'increase-icon'?(props: Record<string, unknown>): unknown;
                    'decrease-icon'?(props: Record<string, unknown>): unknown;
                };
            }) | null;
        }, any>>;
        composite: true;
        group: boolean;
        validationOwnership: "managed";
        editObservation: "raw-sequence";
    };
    ZxDatePicker: {
        component: import('vue').Raw<import('vue').DefineComponent<{
            modelValue?: import('../fields/date-text').DateFieldValue;
            valueFormat: string;
            format?: string;
            type?: import('../fields/date-text').DateFieldType;
            editable?: boolean;
            disabled?: boolean;
            readonly?: boolean;
            messages?: readonly import('../fields').FieldMessage[];
        }, {
            focus: () => void | undefined;
            validate: () => boolean;
            captureEdit(): import('..').Json;
            restoreEdit(draft: import('..').Json): void;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (value: import('../fields/date-text').DateFieldValue) => void;
            "edit-state": (state: import('../fields').FieldEditState) => void;
            blur: (value: FocusEvent) => void;
            focus: (value: FocusEvent) => void;
        }, string, import('vue').PublicProps, Readonly<{
            modelValue?: import('../fields/date-text').DateFieldValue;
            valueFormat: string;
            format?: string;
            type?: import('../fields/date-text').DateFieldType;
            editable?: boolean;
            disabled?: boolean;
            readonly?: boolean;
            messages?: readonly import('../fields').FieldMessage[];
        }> & Readonly<{
            onBlur?: ((value: FocusEvent) => any) | undefined;
            onFocus?: ((value: FocusEvent) => any) | undefined;
            "onUpdate:modelValue"?: ((value: import('../fields/date-text').DateFieldValue) => any) | undefined;
            "onEdit-state"?: ((state: import('../fields').FieldEditState) => any) | undefined;
        }>, {
            type: import('../fields/date-text').DateFieldType;
            modelValue: import('../fields/date-text').DateFieldValue;
            editable: boolean;
        }, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
            root: HTMLDivElement;
            picker: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
                readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | (((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType)) | null)[], unknown, unknown, "date", boolean>;
                readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showWeekNumber: BooleanConstructor;
                readonly ariaLabel: StringConstructor;
                readonly emptyValues: ArrayConstructor;
                readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
                readonly disabledDate: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly cellClassName: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
                readonly arrowControl: BooleanConstructor;
                readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
                readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly unlinkPanels: BooleanConstructor;
                readonly singlePanel: BooleanConstructor;
                readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
                readonly fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
                readonly disabledHours: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly disabledMinutes: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly disabledSeconds: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly id: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly name: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
                readonly popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                readonly format: StringConstructor;
                readonly valueFormat: StringConstructor;
                readonly dateFormat: StringConstructor;
                readonly timeFormat: StringConstructor;
                readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
                readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
                readonly size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly readonly: BooleanConstructor;
                readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                readonly placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
                readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
                readonly rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
                readonly startPlaceholder: StringConstructor;
                readonly endPlaceholder: StringConstructor;
                readonly defaultValue: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly defaultTime: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly isRange: BooleanConstructor;
            }>> & Readonly<{
                "onUpdate:modelValue"?: ((_value: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>) => any) | undefined;
            }>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
                [key: string]: any;
            }>, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                'update:modelValue': (_value: import('element-plus').DatePickerProps["modelValue"]) => true;
            }, import('vue').PublicProps, {
                readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | ((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | null)[], unknown, unknown>;
                readonly placeholder: string;
                readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number) | null)[], unknown, unknown>;
                readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>;
                readonly readonly: boolean;
                readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | ((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | null)[], import('element-plus').Placement, unknown>;
                readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | null)[], unknown, unknown>;
                readonly popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
                readonly popperStyle: import('vue').StyleValue;
                readonly fallbackPlacements: import('element-plus').Placement[];
                readonly popperOptions: Partial<import('element-plus').Options>;
                readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showWeekNumber: boolean;
                readonly shortcuts: unknown[];
                readonly arrowControl: boolean;
                readonly unlinkPanels: boolean;
                readonly singlePanel: boolean;
                readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly rangeSeparator: string;
                readonly isRange: boolean;
            }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import('vue').ExtractPropTypes<{
                readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | (((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType)) | null)[], unknown, unknown, "date", boolean>;
                readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showWeekNumber: BooleanConstructor;
                readonly ariaLabel: StringConstructor;
                readonly emptyValues: ArrayConstructor;
                readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
                readonly disabledDate: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly cellClassName: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
                readonly arrowControl: BooleanConstructor;
                readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
                readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly unlinkPanels: BooleanConstructor;
                readonly singlePanel: BooleanConstructor;
                readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
                readonly fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
                readonly disabledHours: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly disabledMinutes: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly disabledSeconds: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly id: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly name: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
                readonly popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                readonly format: StringConstructor;
                readonly valueFormat: StringConstructor;
                readonly dateFormat: StringConstructor;
                readonly timeFormat: StringConstructor;
                readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
                readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
                readonly size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly readonly: BooleanConstructor;
                readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                readonly placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
                readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
                readonly rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
                readonly startPlaceholder: StringConstructor;
                readonly endPlaceholder: StringConstructor;
                readonly defaultValue: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly defaultTime: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly isRange: BooleanConstructor;
            }>> & Readonly<{
                "onUpdate:modelValue"?: ((_value: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>) => any) | undefined;
            }>, () => import('vue').VNode<import('vue').RendererNode, import('vue').RendererElement, {
                [key: string]: any;
            }>, {}, {}, {}, {
                readonly type: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | ((new (...args: any[]) => "year" | "years" | "month" | "months" | "date" | "dates" | "week" | "quarter" | "quarters" | "datetime" | "datetimerange" | "daterange" | "monthrange" | "yearrange" | "quarterrange") | (() => import('element-plus').DatePickerType) | null)[], unknown, unknown>;
                readonly placeholder: string;
                readonly disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number) | null)[], unknown, unknown>;
                readonly modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | ((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | null)[], unknown, unknown>;
                readonly readonly: boolean;
                readonly clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                readonly prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | ((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | null)[], unknown, unknown>;
                readonly validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | ((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | null)[], import('element-plus').Placement, unknown>;
                readonly valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | ((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | null)[], unknown, unknown>;
                readonly popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
                readonly popperStyle: import('vue').StyleValue;
                readonly fallbackPlacements: import('element-plus').Placement[];
                readonly popperOptions: Partial<import('element-plus').Options>;
                readonly showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showWeekNumber: boolean;
                readonly shortcuts: unknown[];
                readonly arrowControl: boolean;
                readonly unlinkPanels: boolean;
                readonly singlePanel: boolean;
                readonly automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly rangeSeparator: string;
                readonly isRange: boolean;
            }> | import('vue').CreateComponentPublicInstanceWithMixins<Readonly<import('vue').ExtractPropTypes<{
                isRange: BooleanConstructor;
                showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                showWeekNumber: BooleanConstructor;
                ariaLabel: StringConstructor;
                emptyValues: ArrayConstructor;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
                disabledDate: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                cellClassName: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
                arrowControl: BooleanConstructor;
                tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                unlinkPanels: BooleanConstructor;
                singlePanel: BooleanConstructor;
                placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
                fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
                disabledHours: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                disabledMinutes: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                disabledSeconds: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                id: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                name: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
                popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                format: StringConstructor;
                valueFormat: StringConstructor;
                dateFormat: StringConstructor;
                timeFormat: StringConstructor;
                type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
                editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
                size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly: BooleanConstructor;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
                modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
                rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
                startPlaceholder: StringConstructor;
                endPlaceholder: StringConstructor;
                defaultValue: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultTime: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
            }>> & Readonly<{
                "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
            }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, "update:modelValue"[], import('vue').PublicProps, {
                type: string;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown>;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                placeholder: string;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
                readonly: boolean;
                clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
                prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
                tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
                popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
                popperStyle: import('vue').StyleValue;
                fallbackPlacements: import('element-plus').Placement[];
                placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
                popperOptions: Partial<import('element-plus').Options>;
                automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                rangeSeparator: string;
                shortcuts: unknown[];
                showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                showWeekNumber: boolean;
                arrowControl: boolean;
                unlinkPanels: boolean;
                singlePanel: boolean;
                isRange: boolean;
            }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import('vue').ExtractPropTypes<{
                isRange: BooleanConstructor;
                showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                showWeekNumber: BooleanConstructor;
                ariaLabel: StringConstructor;
                emptyValues: ArrayConstructor;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown, undefined, boolean>;
                disabledDate: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                cellClassName: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                shortcuts: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<ArrayConstructor, unknown, unknown, () => never[], boolean>;
                arrowControl: BooleanConstructor;
                tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown, 0, boolean>;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                unlinkPanels: BooleanConstructor;
                singlePanel: BooleanConstructor;
                placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown, "bottom", boolean>;
                fallbackPlacements: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[]) | (((new (...args: any[]) => import('element-plus').Placement[]) | (() => import('element-plus').Placement[])) | null)[], unknown, unknown, readonly ["bottom", "top", "right", "left"], boolean>;
                disabledHours: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledHours>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                disabledMinutes: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledMinutes>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                disabledSeconds: {
                    readonly type: import('vue').PropType<import('element-plus').GetDisabledSeconds>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                id: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                name: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>) | (((new (...args: any[]) => string | [string, string]) | (() => import('element-plus').SingleOrRange<string>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                popperClass: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue) | (((new (...args: any[]) => string | false | Record<string, any> | import('element-plus/es/utils/typescript.mjs').ClassValue[]) | (() => import('element-plus/es/utils/typescript.mjs').ClassValue)) | null)[], unknown, unknown, undefined, boolean>;
                popperStyle: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue) | (((new (...args: any[]) => string | false | import('vue').CSSProperties | import('vue').StyleValue[]) | (() => import('vue').StyleValue)) | null)[], unknown, unknown, undefined, boolean>;
                format: StringConstructor;
                valueFormat: StringConstructor;
                dateFormat: StringConstructor;
                timeFormat: StringConstructor;
                type: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, import('vue').DefineComponent<{}, void, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>, boolean>;
                editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown, "", boolean>;
                size: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<StringConstructor, "" | "default" | "large" | "small", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly: BooleanConstructor;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                placeholder: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                popperOptions: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>) | (((new (...args: any[]) => Partial<import('element-plus').Options>) | (() => Partial<import('element-plus').Options>)) | null)[], unknown, unknown, () => {}, boolean>;
                modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown, "", boolean>;
                rangeSeparator: import('element-plus/es/utils/vue/props/types.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "-", boolean>;
                startPlaceholder: StringConstructor;
                endPlaceholder: StringConstructor;
                defaultValue: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                defaultTime: {
                    readonly type: import('vue').PropType<import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>) | (((new (...args: any[]) => Date | [Date, Date]) | (() => import('element-plus').SingleOrRange<Date>)) | null)[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
            }>> & Readonly<{
                "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
            }>, () => import("vue/jsx-runtime").JSX.Element, {}, {}, {}, {
                type: string;
                disabled: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                modelValue: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null) | (((new (...args: any[]) => string | number | Date | string[] | number[] | Date[]) | (() => import('element-plus').ModelValueType | null)) | null)[], unknown, unknown>;
                validateEvent: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                placeholder: string;
                valueOnClear: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null) | (((new (...args: any[]) => string | number | boolean | Function) | (() => string | number | boolean | Function | null)) | null)[], unknown, unknown>;
                readonly: boolean;
                clearable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                clearIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
                prefixIcon: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component) | (((new (...args: any[]) => (string | import('vue').Component) & {}) | (() => string | import('vue').Component)) | null)[], unknown, unknown>;
                tabindex: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
                popperClass: import('element-plus/es/utils/typescript.mjs').ClassValue;
                popperStyle: import('vue').StyleValue;
                fallbackPlacements: import('element-plus').Placement[];
                placement: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<(new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement) | (((new (...args: any[]) => "auto" | "left" | "right" | "bottom" | "top" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import('element-plus').Placement)) | null)[], import('element-plus').Placement, unknown>;
                popperOptions: Partial<import('element-plus').Options>;
                automaticDropdown: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                editable: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                saveOnBlur: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                rangeSeparator: string;
                shortcuts: unknown[];
                showNow: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                showConfirm: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                showFooter: import('element-plus/es/utils/vue/props/types.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                showWeekNumber: boolean;
                arrowControl: boolean;
                unlinkPanels: boolean;
                singlePanel: boolean;
                isRange: boolean;
            }> | null;
        }, any>>;
        composite: true;
        group: boolean;
        validationOwnership: "managed";
        editObservation: "raw-sequence";
    };
    ZxUpload: {
        component: import('vue').Raw<import('vue').DefineComponent<{
            modelValue?: import('../fields').FieldAttachment[];
            upload: import('../fields').FieldUpload;
            disabled?: boolean;
            readonly?: boolean;
            multiple?: boolean;
            accept?: string;
            maxSize?: number;
            limit?: number;
            buttonText?: string;
            messages?: readonly import('../fields').FieldMessage[];
        }, {
            focus: () => void | undefined;
            validate: () => boolean;
            captureEdit(): import('..').Json;
            restoreEdit(draft: import('..').Json): void;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (value: import('../fields').FieldAttachment[]) => void;
            "edit-state": (state: import('../fields').FieldEditState) => void;
            blur: (value: FocusEvent) => void;
            focus: (value: FocusEvent) => void;
        }, string, import('vue').PublicProps, Readonly<{
            modelValue?: import('../fields').FieldAttachment[];
            upload: import('../fields').FieldUpload;
            disabled?: boolean;
            readonly?: boolean;
            multiple?: boolean;
            accept?: string;
            maxSize?: number;
            limit?: number;
            buttonText?: string;
            messages?: readonly import('../fields').FieldMessage[];
        }> & Readonly<{
            onBlur?: ((value: FocusEvent) => any) | undefined;
            onFocus?: ((value: FocusEvent) => any) | undefined;
            "onUpdate:modelValue"?: ((value: import('../fields').FieldAttachment[]) => any) | undefined;
            "onEdit-state"?: ((state: import('../fields').FieldEditState) => any) | undefined;
        }>, {
            modelValue: import('../fields').FieldAttachment[];
            multiple: boolean;
        }, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
            root: HTMLDivElement;
            uploader: ({
                $: import('vue').ComponentInternalInstance;
                $data: {};
                $props: Partial<{
                    readonly name: string;
                    readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly size: string;
                    readonly data: Record<string, any>;
                    readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly headers: Record<string, any>;
                    readonly modelValue: unknown[];
                    readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly action: string;
                    readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly accept: string;
                    readonly maxSize: number;
                    readonly listType: string;
                    readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly mainText: string;
                    readonly subText: string;
                    readonly buttonText: string;
                    readonly tipText: string;
                    readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                }> & Omit<{
                    readonly name: string;
                    readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly size: string;
                    readonly data: Record<string, any>;
                    readonly headers: Record<string, any>;
                    readonly modelValue: unknown[];
                    readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly action: string;
                    readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly accept: string;
                    readonly maxSize: number;
                    readonly listType: string;
                    readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly mainText: string;
                    readonly subText: string;
                    readonly buttonText: string;
                    readonly tipText: string;
                    readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly disabled?: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
                    readonly limit?: number | undefined;
                    readonly beforeUpload?: Function | undefined;
                    readonly beforeRemove?: Function | undefined;
                    readonly onError?: ((err: any) => any) | undefined;
                    readonly onRemove?: ((file: any) => any) | undefined;
                    readonly onChange?: ((val: any) => any) | undefined;
                    readonly onProgress?: ((e: any) => any) | undefined;
                    readonly onSuccess?: ((res: any) => any) | undefined;
                    readonly "onUpdate:modelValue"?: ((val: any) => any) | undefined;
                    readonly onReject?: ((rejection: import('@zxio/components/upload').UploadRejection) => any) | undefined;
                    readonly onPreview?: ((file: any) => any) | undefined;
                    readonly onExceed?: ((files: any) => any) | undefined;
                    readonly onDownload?: ((file: any) => any) | undefined;
                } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "name" | "drag" | "size" | "data" | "disabled" | "headers" | "modelValue" | "multiple" | "action" | "withCredentials" | "accept" | "maxSize" | "listType" | "showFileList" | "customFileList" | "mainText" | "subText" | "buttonText" | "tipText" | "showSubText" | "showTip" | "autoUpload" | "allowPreview" | "allowDownload" | "allowRemove">;
                $attrs: import('vue').Attrs;
                $refs: {
                    [x: string]: unknown;
                } & {
                    uploadRef: ({
                        $: import('vue').ComponentInternalInstance;
                        $data: {};
                        $props: {
                            readonly beforeUpload?: import('element-plus').UploadHooks["beforeUpload"] | undefined;
                            readonly beforeRemove?: import('element-plus').UploadHooks["beforeRemove"] | undefined;
                            readonly onRemove?: import('element-plus').UploadHooks["onRemove"] | undefined;
                            readonly onChange?: import('element-plus').UploadHooks["onChange"] | undefined;
                            readonly onPreview?: import('element-plus').UploadHooks["onPreview"] | undefined;
                            readonly onSuccess?: import('element-plus').UploadHooks["onSuccess"] | undefined;
                            readonly onProgress?: import('element-plus').UploadHooks["onProgress"] | undefined;
                            readonly onError?: import('element-plus').UploadHooks["onError"] | undefined;
                            readonly onExceed?: import('element-plus').UploadHooks["onExceed"] | undefined;
                            readonly crossorigin?: import('element-plus').Crossorigin | undefined;
                            readonly action?: string | undefined;
                            readonly headers?: (Headers | Record<string, any>) | undefined;
                            readonly method?: string | undefined;
                            readonly data?: (import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData> | ((rawFile: import('element-plus').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | undefined;
                            readonly multiple?: boolean | undefined;
                            readonly name?: string | undefined;
                            readonly drag?: boolean | undefined;
                            readonly withCredentials?: boolean | undefined;
                            readonly showFileList?: boolean | undefined;
                            readonly accept?: string | undefined;
                            readonly fileList?: import('element-plus').UploadUserFile[] | undefined;
                            readonly autoUpload?: boolean | undefined;
                            readonly listType?: import('element-plus').ListType | undefined;
                            readonly httpRequest?: import('element-plus').UploadRequestHandler | undefined;
                            readonly disabled?: boolean | undefined;
                            readonly limit?: number | undefined;
                            readonly directory?: boolean | undefined;
                        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
                        $attrs: import('vue').Attrs;
                        $refs: {
                            [x: string]: unknown;
                        };
                        $slots: Readonly<{
                            [name: string]: import('vue').Slot<any> | undefined;
                        }>;
                        $root: import('vue').ComponentPublicInstance | null;
                        $parent: import('vue').ComponentPublicInstance | null;
                        $host: Element | null;
                        $emit: (event: string, ...args: any[]) => void;
                        $el: any;
                        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').UploadProps> & Readonly<{}>, {
                            abort: (file?: import('element-plus').UploadFile) => void;
                            submit: () => void;
                            clearFiles: (states?: import('element-plus').UploadStatus[]) => void;
                            handleStart: (rawFile: import('element-plus').UploadRawFile) => void;
                            handleRemove: (file: import('element-plus').UploadFile | import('element-plus').UploadRawFile) => void;
                        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, {
                            data: import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData> | ((rawFile: import('element-plus').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>);
                            disabled: boolean;
                            name: string;
                            onChange: import('element-plus').UploadHooks["onChange"];
                            onProgress: import('element-plus').UploadHooks["onProgress"];
                            onError: import('element-plus').UploadHooks["onError"];
                            beforeUpload: import('element-plus').UploadHooks["beforeUpload"];
                            onRemove: import('element-plus').UploadHooks["onRemove"];
                            onPreview: import('element-plus').UploadHooks["onPreview"];
                            onSuccess: import('element-plus').UploadHooks["onSuccess"];
                            onExceed: import('element-plus').UploadHooks["onExceed"];
                            action: string;
                            method: string;
                            showFileList: boolean;
                            accept: string;
                            fileList: import('element-plus').UploadUserFile[];
                            autoUpload: boolean;
                            listType: import('element-plus').ListType;
                            httpRequest: import('element-plus').UploadRequestHandler;
                        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                            beforeCreate?: (() => void) | (() => void)[];
                            created?: (() => void) | (() => void)[];
                            beforeMount?: (() => void) | (() => void)[];
                            mounted?: (() => void) | (() => void)[];
                            beforeUpdate?: (() => void) | (() => void)[];
                            updated?: (() => void) | (() => void)[];
                            activated?: (() => void) | (() => void)[];
                            deactivated?: (() => void) | (() => void)[];
                            beforeDestroy?: (() => void) | (() => void)[];
                            beforeUnmount?: (() => void) | (() => void)[];
                            destroyed?: (() => void) | (() => void)[];
                            unmounted?: (() => void) | (() => void)[];
                            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                        };
                        $forceUpdate: () => void;
                        $nextTick: typeof import('vue').nextTick;
                        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
                    } & Readonly<{
                        data: import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData> | ((rawFile: import('element-plus').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>);
                        disabled: boolean;
                        name: string;
                        onChange: import('element-plus').UploadHooks["onChange"];
                        onProgress: import('element-plus').UploadHooks["onProgress"];
                        onError: import('element-plus').UploadHooks["onError"];
                        beforeUpload: import('element-plus').UploadHooks["beforeUpload"];
                        onRemove: import('element-plus').UploadHooks["onRemove"];
                        onPreview: import('element-plus').UploadHooks["onPreview"];
                        onSuccess: import('element-plus').UploadHooks["onSuccess"];
                        onExceed: import('element-plus').UploadHooks["onExceed"];
                        action: string;
                        method: string;
                        showFileList: boolean;
                        accept: string;
                        fileList: import('element-plus').UploadUserFile[];
                        autoUpload: boolean;
                        listType: import('element-plus').ListType;
                        httpRequest: import('element-plus').UploadRequestHandler;
                    }> & Omit<Readonly<import('element-plus').UploadProps> & Readonly<{}>, "name" | "abort" | "submit" | "data" | "onChange" | "onError" | "onProgress" | "disabled" | "action" | "onSuccess" | "accept" | "listType" | "showFileList" | "autoUpload" | "beforeUpload" | "onRemove" | "onPreview" | "onExceed" | "method" | "fileList" | "httpRequest" | "clearFiles" | "handleStart" | "handleRemove"> & {
                        abort: (file?: import('element-plus').UploadFile) => void;
                        submit: () => void;
                        clearFiles: (states?: import('element-plus').UploadStatus[]) => void;
                        handleStart: (rawFile: import('element-plus').UploadRawFile) => void;
                        handleRemove: (file: import('element-plus').UploadFile | import('element-plus').UploadRawFile) => void;
                    } & {} & import('vue').ComponentCustomProperties & {} & {
                        $slots: {
                            file?: (props: {
                                file: import('element-plus').UploadFile;
                                index: number;
                            }) => any;
                        } & {
                            trigger?: (props: {}) => any;
                        } & {
                            default?: (props: {}) => any;
                        } & {
                            trigger?: (props: {}) => any;
                        } & {
                            default?: (props: {}) => any;
                        } & {
                            default?: (props: {}) => any;
                        } & {
                            tip?: (props: {}) => any;
                        } & {
                            file?: (props: {
                                file: import('element-plus').UploadFile;
                                index: number;
                            }) => any;
                        };
                    }) | null;
                };
                $slots: Readonly<{
                    [name: string]: import('vue').Slot<any> | undefined;
                }>;
                $root: import('vue').ComponentPublicInstance | null;
                $parent: import('vue').ComponentPublicInstance | null;
                $host: Element | null;
                $emit: ((event: "error", err: any) => void) & ((event: "remove", file: any) => void) & ((event: "change", val: any) => void) & ((event: "progress", e: any) => void) & ((event: "success", res: any) => void) & ((event: "update:modelValue", val: any) => void) & ((event: "reject", rejection: import('@zxio/components/upload').UploadRejection) => void) & ((event: "preview", file: any) => void) & ((event: "exceed", files: any) => void) & ((event: "download", file: any) => void);
                $el: any;
                $options: import('vue').ComponentOptionsBase<Readonly<import('vue').ExtractPropTypes<{
                    readonly modelValue: import('@zxio/shared').EpPropFinalized<ArrayConstructor, unknown, unknown, () => any[], boolean>;
                    readonly action: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                    readonly headers: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
                    readonly data: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
                    readonly name: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "file", boolean>;
                    readonly withCredentials: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                    readonly multiple: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                    readonly accept: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "*", boolean>;
                    readonly limit: {
                        readonly type: import('vue').PropType<number>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly maxSize: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                    readonly listType: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "text", boolean>;
                    readonly drag: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                    readonly showFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly customFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                    readonly mainText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                    readonly subText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                    readonly buttonText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                    readonly tipText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                    readonly showSubText: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly showTip: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly autoUpload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly disabled: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                    readonly allowPreview: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly allowDownload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly allowRemove: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly beforeUpload: {
                        readonly type: import('vue').PropType<Function>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly beforeRemove: {
                        readonly type: import('vue').PropType<Function>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly size: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "default", boolean>;
                }>> & Readonly<{
                    onError?: ((err: any) => any) | undefined;
                    onRemove?: ((file: any) => any) | undefined;
                    onChange?: ((val: any) => any) | undefined;
                    onProgress?: ((e: any) => any) | undefined;
                    onSuccess?: ((res: any) => any) | undefined;
                    "onUpdate:modelValue"?: ((val: any) => any) | undefined;
                    onReject?: ((rejection: import('@zxio/components/upload').UploadRejection) => any) | undefined;
                    onPreview?: ((file: any) => any) | undefined;
                    onExceed?: ((files: any) => any) | undefined;
                    onDownload?: ((file: any) => any) | undefined;
                }>, {
                    submit: () => void | undefined;
                    abort: (file?: import('element-plus').UploadFile) => void | undefined;
                    clearFiles: () => void | undefined;
                }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
                    error: (err: any) => void;
                    remove: (file: any) => void;
                    change: (val: any) => void;
                    progress: (e: any) => void;
                    success: (res: any) => void;
                    "update:modelValue": (val: any) => void;
                    reject: (rejection: import('@zxio/components/upload').UploadRejection) => void;
                    preview: (file: any) => void;
                    exceed: (files: any) => void;
                    download: (file: any) => void;
                }, string, {
                    readonly name: string;
                    readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly size: string;
                    readonly data: Record<string, any>;
                    readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly headers: Record<string, any>;
                    readonly modelValue: unknown[];
                    readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly action: string;
                    readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly accept: string;
                    readonly maxSize: number;
                    readonly listType: string;
                    readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly mainText: string;
                    readonly subText: string;
                    readonly buttonText: string;
                    readonly tipText: string;
                    readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
                    beforeCreate?: (() => void) | (() => void)[];
                    created?: (() => void) | (() => void)[];
                    beforeMount?: (() => void) | (() => void)[];
                    mounted?: (() => void) | (() => void)[];
                    beforeUpdate?: (() => void) | (() => void)[];
                    updated?: (() => void) | (() => void)[];
                    activated?: (() => void) | (() => void)[];
                    deactivated?: (() => void) | (() => void)[];
                    beforeDestroy?: (() => void) | (() => void)[];
                    beforeUnmount?: (() => void) | (() => void)[];
                    destroyed?: (() => void) | (() => void)[];
                    unmounted?: (() => void) | (() => void)[];
                    renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
                    errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
                };
                $forceUpdate: () => void;
                $nextTick: typeof import('vue').nextTick;
                $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
            } & Readonly<{
                readonly name: string;
                readonly drag: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly size: string;
                readonly data: Record<string, any>;
                readonly disabled: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly headers: Record<string, any>;
                readonly modelValue: unknown[];
                readonly multiple: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly action: string;
                readonly withCredentials: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly accept: string;
                readonly maxSize: number;
                readonly listType: string;
                readonly showFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly customFileList: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly mainText: string;
                readonly subText: string;
                readonly buttonText: string;
                readonly tipText: string;
                readonly showSubText: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly showTip: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly autoUpload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly allowPreview: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly allowDownload: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly allowRemove: import('@zxio/shared').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            }> & Omit<Readonly<import('vue').ExtractPropTypes<{
                readonly modelValue: import('@zxio/shared').EpPropFinalized<ArrayConstructor, unknown, unknown, () => any[], boolean>;
                readonly action: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly headers: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
                readonly data: import('@zxio/shared').EpPropFinalized<ObjectConstructor, unknown, unknown, () => {}, boolean>;
                readonly name: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "file", boolean>;
                readonly withCredentials: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                readonly multiple: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                readonly accept: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "*", boolean>;
                readonly limit: {
                    readonly type: import('vue').PropType<number>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly maxSize: import('@zxio/shared').EpPropFinalized<NumberConstructor, unknown, unknown, number, boolean>;
                readonly listType: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "text", boolean>;
                readonly drag: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                readonly showFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly customFileList: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
                readonly mainText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly subText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly buttonText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly tipText: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly showSubText: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly showTip: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly autoUpload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly disabled: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                readonly allowPreview: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly allowDownload: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly allowRemove: import('@zxio/shared').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly beforeUpload: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly beforeRemove: {
                    readonly type: import('vue').PropType<Function>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly size: import('@zxio/shared').EpPropFinalized<StringConstructor, unknown, unknown, "default", boolean>;
            }>> & Readonly<{
                onError?: ((err: any) => any) | undefined;
                onRemove?: ((file: any) => any) | undefined;
                onChange?: ((val: any) => any) | undefined;
                onProgress?: ((e: any) => any) | undefined;
                onSuccess?: ((res: any) => any) | undefined;
                "onUpdate:modelValue"?: ((val: any) => any) | undefined;
                onReject?: ((rejection: import('@zxio/components/upload').UploadRejection) => any) | undefined;
                onPreview?: ((file: any) => any) | undefined;
                onExceed?: ((files: any) => any) | undefined;
                onDownload?: ((file: any) => any) | undefined;
            }>, "abort" | "submit" | "clearFiles" | ("name" | "drag" | "size" | "data" | "disabled" | "headers" | "modelValue" | "multiple" | "action" | "withCredentials" | "accept" | "maxSize" | "listType" | "showFileList" | "customFileList" | "mainText" | "subText" | "buttonText" | "tipText" | "showSubText" | "showTip" | "autoUpload" | "allowPreview" | "allowDownload" | "allowRemove")> & {
                submit: () => void | undefined;
                abort: (file?: import('element-plus').UploadFile) => void | undefined;
                clearFiles: () => void | undefined;
            } & {} & import('vue').ComponentCustomProperties & {} & {
                $slots: {
                    default?(_: {}): any;
                    trigger?(_: {}): any;
                    file?(_: {
                        file: import('element-plus').UploadFile;
                        index: number;
                    }): any;
                    tip?(_: {}): any;
                };
            }) | null;
        }, any>>;
        composite: true;
        validationOwnership: "managed";
        editObservation: "raw-sequence";
    };
};
export declare function createZxuiDefinitionPolicy(): import('./types').DefinitionPolicy;
