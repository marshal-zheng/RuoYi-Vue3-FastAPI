import { Json } from '../types';
import { ISchema } from '@formily/vue';
import { ConditionalArrayRule, ConditionalChange, ConditionalEditPolicy, EditAddress, PolicyPath, RowId, SafeDifference, SnapshotArray, SnapshotField } from './conditional-types';
export declare const pathKey: (path: PolicyPath | EditAddress) => string;
export declare function schemaNodes(schema: ISchema): Map<string, import('@formily/vue').Stringify<{
    [key: symbol]: any;
    [key: `x-${string}`]: any;
    [key: `x-${number}`]: any;
    version?: string;
    name?: import('@formily/vue').SchemaKey;
    title?: any;
    description?: any;
    default?: any;
    readOnly?: boolean;
    writeOnly?: boolean;
    type?: import('@formily/vue').SchemaTypes;
    enum?: import('@formily/vue').SchemaEnum<any> | undefined;
    const?: any;
    multipleOf?: number;
    maximum?: number;
    exclusiveMaximum?: number;
    minimum?: number;
    exclusiveMinimum?: number;
    maxLength?: number;
    minLength?: number;
    pattern?: string | RegExp;
    maxItems?: number;
    minItems?: number;
    uniqueItems?: boolean;
    maxProperties?: number;
    minProperties?: number;
    required?: string[] | boolean | string;
    format?: string;
    $ref?: string;
    $namespace?: string;
    definitions?: import('@formily/vue').SchemaProperties<any, any, any, any, any, any, any, any> | undefined;
    properties?: import('@formily/vue').SchemaProperties<any, any, any, any, any, any, any, any> | undefined;
    items?: import('@formily/vue').SchemaItems<any, any, any, any, any, any, any, any> | undefined;
    additionalItems?: import('@formily/vue').Stringify<any> | undefined;
    patternProperties?: import('@formily/vue').SchemaProperties<any, any, any, any, any, any, any, any> | undefined;
    additionalProperties?: import('@formily/vue').Stringify<any> | undefined;
    "x-value"?: any;
    "x-index"?: number;
    "x-pattern"?: any;
    "x-display"?: any;
    "x-validator"?: any;
    "x-decorator"?: any;
    "x-decorator-props"?: any;
    "x-component"?: any;
    "x-component-props"?: any;
    "x-reactions"?: import('@formily/vue').SchemaReactions<any> | undefined;
    "x-content"?: any;
    "x-data"?: any;
    "x-visible"?: boolean;
    "x-hidden"?: boolean;
    "x-disabled"?: boolean;
    "x-editable"?: boolean;
    "x-read-only"?: boolean;
    "x-read-pretty"?: boolean;
    "x-compile-omitted"?: string[];
}>>;
export declare function installPolicy(input: ConditionalEditPolicy | undefined, schema: ISchema, keys: readonly {
    path: readonly (string | number)[];
    key: string;
}[]): ConditionalEditPolicy | undefined;
export declare const idValid: (id: unknown) => id is RowId;
export declare function rowIds(value: Json, rule: ConditionalArrayRule): RowId[];
export declare function resolveAddress(values: Json, address: EditAddress, policy: ConditionalEditPolicy): {
    path: (string | number)[];
    parent: Record<string | number, Json>;
    key: string | number;
    value: Json | undefined;
    present: boolean;
};
export declare function addresses(values: Json, pattern: PolicyPath, policy: ConditionalEditPolicy): EditAddress[];
export declare function describable(target: EditAddress, policy: ConditionalEditPolicy): boolean;
export declare function projection(values: Json, policy: ConditionalEditPolicy): {
    fields: SnapshotField[];
    arrays: SnapshotArray[];
};
export declare function differences(before: Json, after: Json, policy: ConditionalEditPolicy): SafeDifference[];
export interface PlannedAction {
    change: ConditionalChange;
    path: readonly (string | number)[];
    value?: Json;
    index?: number;
    to?: number;
}
type Available = (path: readonly (string | number)[], inserted: boolean) => boolean;
export declare function plan(values: Json, changes: readonly ConditionalChange[], policy: ConditionalEditPolicy, available?: Available): {
    draft: Json;
    actions: PlannedAction[];
};
/** Re-resolve one canonical planned action against the current owner. The live
 * values are borrowed for descriptor reads only, never retained or mutated. */
export declare function resolveAction(values: Json, change: ConditionalChange, policy: ConditionalEditPolicy, available: Available): PlannedAction;
export {};
