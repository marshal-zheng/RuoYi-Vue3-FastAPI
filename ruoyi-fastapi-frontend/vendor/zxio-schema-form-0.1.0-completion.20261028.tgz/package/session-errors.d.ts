import { Field } from '@formily/core';
import { FieldPath } from './fields/types';
import { ArrayKey, FieldIssue } from './formily/types';
/** Errors are authoritative here. Native feedback is only a disposable projection. */
export declare function createErrorLedger(ports: {
    read(): object;
    fields(): readonly Field[];
    /** Membership of the current field graph; defaults to `fields()`. */
    live?(field: Field): boolean;
    visible(field: Field): boolean;
    composite(field: Field): boolean;
    active(field: Field): boolean;
    version(): number;
    changed(): void;
}, keys: readonly ArrayKey[]): {
    messages: (field: Field) => readonly FieldIssue[];
    formIssues: import('vue').ComputedRef<{
        path?: FieldPath;
        message: string;
        severity?: "error" | "warning" | "info";
    }[]>;
    project: () => void;
    set: (code: string, issues: readonly FieldIssue[], submitted?: object) => void;
    setMany: (updates: readonly {
        code: string;
        issues: readonly FieldIssue[];
    }[], submitted?: object) => void;
    forgetFields(fields: ReadonlySet<Field>): void;
    changed: () => void;
    clear: () => void;
    clearValidation(identity: string): void;
    clearField(field: Field): void;
};
