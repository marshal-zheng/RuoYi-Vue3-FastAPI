import type { GridListLoadOptions } from './use-grid-request';
declare function clearTableSelection(): void;
declare var __VLS_1: {
    query: any;
    data: any;
    mode: any;
    status: any;
    loading: any;
    refresh: any;
    updateState: any;
    updateMultiState: any;
}, __VLS_3: any, __VLS_5: any, __VLS_15: {
    grid: any;
    mode: any;
    status: any;
    loading: any;
    refresh: any;
    updateState: any;
    updateMultiState: any;
    hasData: any;
    isEmpty: boolean;
    emptySlot: any;
    renderEmpty: any;
}, __VLS_17: {
    refresh: any;
    error: null;
    isError: boolean;
}, __VLS_22: {}, __VLS_32: {
    pager: any;
};
type __VLS_Slots = {} & {
    form?: (props: typeof __VLS_1) => any;
} & {
    error?: (props: typeof __VLS_3) => any;
} & {
    status?: (props: typeof __VLS_5) => any;
} & {
    table?: (props: typeof __VLS_15) => any;
} & {
    empty?: (props: typeof __VLS_17) => any;
} & {
    emptyImage?: (props: typeof __VLS_22) => any;
} & {
    pagination?: (props: typeof __VLS_32) => any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {
    loadData: (params?: Record<string, unknown>, options?: GridListLoadOptions) => Promise<void> | undefined;
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    mode: any;
    state: import("vue").ComputedRef<{
        readonly [x: string]: any;
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        };
        readonly query: {
            readonly [x: string]: any;
        };
        readonly list: readonly any[];
        readonly loading: boolean;
        readonly error: Readonly<unknown>;
        readonly lastLoadTime: number | null;
        readonly silent: boolean;
    } | {
        readonly query: {};
        readonly list: any;
        readonly pager: any;
        readonly loading: boolean;
        readonly error: any;
        readonly lastLoadTime: null;
        readonly silent: boolean;
    }>;
    updateState: (key: string, value: unknown) => void;
    updateMultiState: (value: any) => void;
    clearTableSelection: typeof clearTableSelection;
    getStateSnapshot: () => import("./props").GridListStateSnapshot;
    renderTableEmpty: () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    readonly small: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    readonly status: Readonly<import("./props").GridListStatus>;
    readonly rows: readonly any[];
    readonly pagination: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null)) | null)[], unknown, unknown>;
    readonly initialState: Partial<import("./props").GridListState<Record<string, any>, any>>;
    readonly showPagination: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly pageSizes: unknown[];
    readonly paginationLayout: string;
    readonly paginationBackground: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadOnMounted: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly queryTransform: Function;
    readonly paramsTransform: Function;
    readonly autoRefresh: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig)) | null)[], unknown, unknown>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly syncUrlState: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly urlStateKey: string;
    readonly pageFrom0: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounceDelay: number;
    readonly defaultPageSize: number;
    readonly emptyDescription: string;
    readonly emptyImage: string;
    readonly emptyImageSize: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly showRefreshButton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showTableBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
