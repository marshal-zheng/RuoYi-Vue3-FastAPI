import { type SFCWithInstall } from '@zxio/shared';
import Input from '../components/input/src/input-core.vue';
import InputNumber from '../components/input-number/src/input-number-core.vue';
import ListView from '../components/list-view/src/list-view-core.vue';
/** Explicit capability assembly; root/leaf convenience entries stay compatible. */
export declare const ZxButton: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    } & {
        'tooltip-content'?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    };
} }> & Record<string, any>;
export declare const ZxIcon: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig) | (((new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig) | (((new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig) | (((new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig) | (((new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
} }> & Record<string, any>;
export declare const ZxTag: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly width: number;
    readonly theme: import("@zxio/shared").EpPropMergeType<StringConstructor, "plain" | "light" | "dark", unknown>;
    readonly maxWidth: string;
    readonly selfStyle: import("vue").CSSProperties;
    readonly noMargin: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltipDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly width: number;
    readonly theme: import("@zxio/shared").EpPropMergeType<StringConstructor, "plain" | "light" | "dark", unknown>;
    readonly maxWidth: string;
    readonly selfStyle: import("vue").CSSProperties;
    readonly noMargin: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltipDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly width: number;
    readonly theme: import("@zxio/shared").EpPropMergeType<StringConstructor, "plain" | "light" | "dark", unknown>;
    readonly maxWidth: string;
    readonly selfStyle: import("vue").CSSProperties;
    readonly noMargin: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltipDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly width: number;
    readonly theme: import("@zxio/shared").EpPropMergeType<StringConstructor, "plain" | "light" | "dark", unknown>;
    readonly maxWidth: string;
    readonly selfStyle: import("vue").CSSProperties;
    readonly noMargin: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltipDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        icon?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    };
} }> & Record<string, any>;
export declare const ZxInput: SFCWithInstall<typeof Input>;
export declare const ZxInputNumber: SFCWithInstall<typeof InputNumber>;
export declare const ZxDialog: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("../components/index").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("../components/index").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly beforeClose: import("../components/index").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("../components/index").DialogConfirm;
    readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (((new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("../components/index").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
    readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("../components/index").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("../components/index").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly beforeClose: import("../components/index").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("../components/index").DialogConfirm;
    readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (((new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("../components/index").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
    readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("../components/index").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("../components/index").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly beforeClose: import("../components/index").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("../components/index").DialogConfirm;
    readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (((new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("../components/index").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
    readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("../components/index").ThemeRequiredPortalTarget;
    readonly locale: Partial<import("../components/index").DialogMessages>;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding) | (((new (...args: any[]) => string | number | import("../components/index").ZxOverlayInsets) | (() => import("../components/index").ZxOverlayPadding)) | null)[], unknown, unknown>;
    readonly beforeClose: import("../components/index").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("../components/index").DialogConfirm;
    readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength) | (((new (...args: any[]) => string | number) | (() => import("../components/index").ZxOverlayLength)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (((new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("../components/index").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
    readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll) | (((new (...args: any[]) => "none" | "auto") | (() => import("../components/index").ZxOverlayBodyScroll)) | null)[], "none" | "auto", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: import("../components/index").DialogSlots;
} }> & Record<string, any>;
export declare const ZxListView: SFCWithInstall<typeof ListView>;
export declare const ZxSelect: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly error: any;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor,
        ArrayConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly paused: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltip: {
        content?: string;
        placement?: import("@zxio/utils/dist/es/index.js").StandardPlacement;
    };
    readonly transform: (list: any) => readonly import("../components/index").SelectOption[];
    readonly options: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (((new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader)) | null)[], unknown, unknown>;
    readonly valueKey: string;
    readonly entity: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null) | (((new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null)) | null)[], unknown, unknown>;
    readonly hasAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultFirst: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly remote: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchKeys: string[];
    readonly labelKey: string;
    readonly refreshing: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly objectValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly atLeastOne: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly notAutoInitSearch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly shouldCalculateMaxTag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly optionLabelRender: (item: import("../components/index").SelectOption) => string;
    readonly resolvedOptions: import("../components/index").SelectOption[];
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly error: any;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor,
        ArrayConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly paused: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltip: {
        content?: string;
        placement?: import("@zxio/utils/dist/es/index.js").StandardPlacement;
    };
    readonly transform: (list: any) => readonly import("../components/index").SelectOption[];
    readonly options: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (((new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader)) | null)[], unknown, unknown>;
    readonly valueKey: string;
    readonly entity: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null) | (((new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null)) | null)[], unknown, unknown>;
    readonly hasAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultFirst: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly remote: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchKeys: string[];
    readonly labelKey: string;
    readonly refreshing: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly objectValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly atLeastOne: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly notAutoInitSearch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly shouldCalculateMaxTag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly optionLabelRender: (item: import("../components/index").SelectOption) => string;
    readonly resolvedOptions: import("../components/index").SelectOption[];
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly error: any;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor,
        ArrayConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly paused: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltip: {
        content?: string;
        placement?: import("@zxio/utils/dist/es/index.js").StandardPlacement;
    };
    readonly transform: (list: any) => readonly import("../components/index").SelectOption[];
    readonly options: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (((new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader)) | null)[], unknown, unknown>;
    readonly valueKey: string;
    readonly entity: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null) | (((new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null)) | null)[], unknown, unknown>;
    readonly hasAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultFirst: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly remote: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchKeys: string[];
    readonly labelKey: string;
    readonly refreshing: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly objectValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly atLeastOne: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly notAutoInitSearch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly shouldCalculateMaxTag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly optionLabelRender: (item: import("../components/index").SelectOption) => string;
    readonly resolvedOptions: import("../components/index").SelectOption[];
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly error: any;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor,
        ArrayConstructor,
        ObjectConstructor
    ], unknown, unknown>;
    readonly paused: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltip: {
        content?: string;
        placement?: import("@zxio/utils/dist/es/index.js").StandardPlacement;
    };
    readonly transform: (list: any) => readonly import("../components/index").SelectOption[];
    readonly options: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (((new (...args: any[]) => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => readonly import("../components/index").SelectOption[] | import("../components/index").OptionsLoader)) | null)[], unknown, unknown>;
    readonly valueKey: string;
    readonly entity: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null) | (((new (...args: any[]) => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | readonly import("../components/index").SelectOption[] | null)) | null)[], unknown, unknown>;
    readonly hasAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultFirst: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly remote: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchKeys: string[];
    readonly labelKey: string;
    readonly refreshing: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly objectValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly atLeastOne: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly notAutoInitSearch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly shouldCalculateMaxTag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly optionLabelRender: (item: import("../components/index").SelectOption) => string;
    readonly resolvedOptions: import("../components/index").SelectOption[];
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        option?: (props: {
            option: import("../components/index").SelectOption;
        }) => any;
        header?: () => any;
        footer?: () => any;
        empty?: () => any;
        error?: (props: import("../components/index").SelectRequestState) => any;
        status?: (props: import("../components/index").SelectRequestState) => any;
        label?: (props: import("../components/index").SelectLabelSlotProps) => any;
    };
} }> & Record<string, any>;
export { createZxUiCapabilities } from '../components/capabilities/context';
export type { ZxUiCapabilities } from '../components/capabilities/context';
