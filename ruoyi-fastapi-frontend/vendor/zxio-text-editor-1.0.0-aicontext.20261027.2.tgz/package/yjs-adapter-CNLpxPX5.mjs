import { A as v, H as bo, F, G as Oe, e as u, d as la, i as hi, E as pe, I as qn, J as Kr, a as xo, D as da, c as Io, v as In, K as Sr, L as pa, Z as yi, g as fa } from "./actions-Sd62WBGv.mjs";
import { b as st, c as ua, a as $e, A as vo, f as ko, r as wo, d as ga, i as Fo, e as Ro, h as ma, j as ha, k as hn, C as Ee, l as de, m as Ar, n as Ur, o as vn, p as ya, q as ba, s as xa, t as Ia, u as So, g as Jn, v as va, w as ka } from "./runtime-plugin-definitions-DN_cDAJZ.mjs";
import { readRuntimeTargetDocumentBindingV2 as Er, attachRuntimeTargetDocumentProjectionV2 as wa, readRuntimeTargetLiveClosureV2 as Fa } from "#runtime-target-document-authority";
import { J as tn, K as Ra } from "./inline-ai-shortcut-router-a-QG5h2e.mjs";
import { EditorState as Ao, Selection as Sa } from "prosemirror-state";
import { Mapping as Aa, Step as Ea } from "prosemirror-transform";
import { e as Eo, v as Oa, g as Ta } from "./projection-r_4Na96h.mjs";
import { readTextEditorRuntimeHostCompositionV2 as Ca, readTextEditorRuntimeHostCompositionForTargetV2 as bi } from "#runtime-host-registry";
import * as Pa from "@tiptap/pm/history";
import { relativePositionToAbsolutePosition as Da, absolutePositionToRelativePosition as Ba } from "y-prosemirror";
import * as U from "yjs";
import { certifyRuntimeHostCollaborationTransportExtensionV2 as ja } from "#runtime-host-core-authority";
const af = 1, Oo = 2, cf = "sha256:0000000000000000000000000000000000000000000000000000000000000000", K = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, oe = (e, t, n = []) => {
  const r = Object.keys(e);
  return t.every((i) => Object.hasOwn(e, i)) && r.every((i) => t.includes(i) || n.includes(i));
}, T = (e) => typeof e == "string" && e.length > 0 && e.length <= 160 && /^[A-Za-z0-9][A-Za-z0-9._:/-]*$/.test(e), H = (e) => typeof e == "string" && /^sha256:[a-f0-9]{64}$/.test(e), O = (e, t) => v({ domain: `zx-ai-complex-node:${e}:v1`, value: t }), To = (e) => bo(e), Z = (e) => F(e), kn = (e, t, n = t.maxPayloadBytes) => {
  tn(e, {
    maxBytes: n,
    maxDepth: t.maxDepth,
    maxArrayEntries: t.maxArrayLength,
    maxObjectKeys: t.maxKeys,
    maxTotalObjectKeys: t.maxKeys
  }), Oe(e, {
    maxBytes: n,
    maxDepth: t.maxDepth,
    maxArrayEntries: t.maxArrayLength,
    maxObjectKeys: t.maxKeys,
    maxTotalObjectKeys: t.maxKeys
  });
  let r = 0, i = 0, o = 0, s = 0, a = 0, c = 0, l = 0, g = 0, f = 0, p = 0, d = 0;
  const h = /* @__PURE__ */ new Set(), m = (b, k) => {
    if (d += 1, typeof b == "string") {
      r = Math.max(r, b.length), l += b.length, g += b.length === 0 ? 0 : b.split(`
`).length;
      return;
    }
    if (!b || typeof b != "object") return;
    if (Array.isArray(b)) {
      b.forEach((R) => m(R, k));
      return;
    }
    const w = b, I = w.type, x = I === "bulletList" || I === "orderedList" || I === "taskList" ? k + 1 : k;
    if (I === "tableCell" || I === "tableHeader") {
      i += 1;
      const R = K(w.attrs) ? w.attrs : {};
      o = Math.max(o, Number(R.rowspan ?? 1)), s = Math.max(s, Number(R.colspan ?? 1));
    }
    if ((I === "listItem" || I === "taskItem") && (a += 1, c = Math.max(c, x)), typeof w.assetId == "string" && h.add(w.assetId), K(w.attrs)) {
      const R = w.attrs;
      typeof R.assetId == "string" && h.add(R.assetId), p += new TextEncoder().encode(
        F(R)
      ).byteLength;
    }
    Object.entries(w).forEach(([R, A]) => {
      r = Math.max(r, R.length), m(A, x);
    });
  };
  if (m(e, 0), f = h.size, r > t.maxStringLength)
    throw new RangeError("complex-string-limit-exceeded");
  const y = t.nodeBudget;
  if (y.kind === "table" && (i > y.maxCells || o > y.maxRowSpan || s > y.maxColSpan) || y.kind === "list" && (a > y.maxItems || c > y.maxDepth) || y.kind === "code" && (l > y.maxChars || g > y.maxLines) || y.kind === "media" && (f > y.maxResources || p > y.maxAttrBytes) || y.kind === "custom" && d > y.maxComplexity)
    throw new RangeError("complex-node-budget-exceeded");
}, P = (e) => JSON.parse(F(e)), Na = {
  "complex-registry-invalid": "install-adapter",
  "complex-adapter-not-found": "install-adapter",
  "complex-adapter-fingerprint-mismatch": "install-adapter",
  "complex-operation-unsupported": "reject",
  "complex-payload-invalid": "reject",
  "complex-limit-exceeded": "reject",
  "complex-address-invalid": "regenerate",
  "complex-anchor-lost": "regenerate",
  "complex-target-ambiguous": "resolve-conflict",
  "complex-target-drifted": "regenerate",
  "complex-capability-drifted": "regenerate",
  "complex-schema-invalid": "reject",
  "complex-plan-nondeterministic": "reject",
  "complex-diff-unavailable": "replan",
  "complex-resource-not-staged": "reauthorize",
  "complex-resource-policy-denied": "reject",
  "complex-resource-receipt-invalid": "reauthorize",
  "complex-resource-host-failed": "reauthorize",
  "complex-custom-admission-denied": "install-adapter",
  "complex-collaboration-conflict": "resolve-conflict",
  "complex-runner-timeout": "replan",
  "complex-runner-cancelled": "replan",
  "complex-runner-malformed": "reject",
  "complex-unsupported-host": "reject"
}, B = (e, t, n, r = {}) => u({
  code: e,
  stage: t,
  path: n.slice(0, 240),
  recovery: Na[e],
  ...r.count === void 0 ? {} : { count: r.count },
  ...r.fingerprintPrefix === void 0 ? {} : { fingerprintPrefix: r.fingerprintPrefix.slice(0, 20) }
}), Be = (e, t, n) => u({
  valid: !1,
  value: null,
  diagnostics: [B(e, t, n)]
}), Co = /* @__PURE__ */ new Set([
  "row",
  "cell",
  "list-item",
  "code-text",
  "media",
  "custom"
]), Ma = (e) => !K(e) || !oe(e, [
  "blockId",
  "localType",
  "localId",
  "semanticOffset",
  "affinity",
  "anchor"
]) || !T(e.blockId) || !Co.has(String(e.localType)) || !T(e.localId) || !Number.isSafeInteger(e.semanticOffset) || e.semanticOffset < 0 || e.affinity !== "forward" && e.affinity !== "backward" || !K(e.anchor) || !oe(e.anchor, [
  "kind",
  "blockId",
  "semanticOffset",
  "affinity",
  "relativePosition",
  "capabilityFingerprint",
  "fingerprint"
]) || e.anchor.kind !== "selection-endpoint" && e.anchor.kind !== "block-boundary" || !T(e.anchor.blockId) || !Number.isSafeInteger(e.anchor.semanticOffset) || e.anchor.semanticOffset < 0 || e.anchor.affinity !== "left" && e.anchor.affinity !== "right" || !K(e.anchor.relativePosition) || !oe(e.anchor.relativePosition, [
  "encoding",
  "value",
  "byteLength",
  "fingerprint"
]) || e.anchor.relativePosition.encoding !== "base64url" || typeof e.anchor.relativePosition.value != "string" || !Number.isSafeInteger(e.anchor.relativePosition.byteLength) || !H(e.anchor.relativePosition.fingerprint) || !H(e.anchor.capabilityFingerprint) || !H(e.anchor.fingerprint) ? null : e, za = (e) => {
  if (!K(e) || !oe(e, [
    "localId",
    "nodeTypeFingerprint",
    "contentFingerprint",
    "depth",
    "parentIds",
    "previousSiblingId",
    "nextSiblingId",
    "fingerprint"
  ]) || !T(e.localId) || !H(e.nodeTypeFingerprint) || !H(e.contentFingerprint) || !Number.isSafeInteger(e.depth) || e.depth < 0 || !Array.isArray(e.parentIds) || !e.parentIds.every(T) || e.previousSiblingId !== null && !T(e.previousSiblingId) || e.nextSiblingId !== null && !T(e.nextSiblingId))
    return null;
  const { fingerprint: t, ...n } = e;
  return H(t) && t === O("local-structure", n) ? e : null;
}, $a = (e, t) => {
  let n = null;
  const r = (o, s, a) => {
    if (n) return;
    const c = o.content ?? [];
    c.forEach((l, g) => {
      var h;
      if (n) return;
      const f = typeof ((h = l.attrs) == null ? void 0 : h.blockId) == "string" ? l.attrs.blockId : null;
      if (l.type === "listItem" && f === t) {
        const m = c.map(
          (y) => {
            var b;
            return y.type === "listItem" && typeof ((b = y.attrs) == null ? void 0 : b.blockId) == "string" ? y.attrs.blockId : null;
          }
        );
        n = {
          localId: t,
          nodeTypeFingerprint: O(
            "node-type",
            l.type
          ),
          contentFingerprint: O("node-content", l),
          depth: a,
          parentIds: s,
          previousSiblingId: m[g - 1] ?? null,
          nextSiblingId: m[g + 1] ?? null
        };
        return;
      }
      const p = f ? [...s, f] : s, d = l.type === "bulletList" || l.type === "orderedList" ? a + 1 : a;
      r(l, p, d);
    });
  };
  if (r(e, [], 0), !n) return null;
  const i = n;
  return u({
    ...i,
    fingerprint: O("local-structure", i)
  });
}, Hr = (e) => {
  if (!K(e) || typeof e.kind != "string")
    return Be("complex-address-invalid", "address", "$.target");
  if (e.kind === "stable-local") {
    if (!oe(
      e,
      ["kind", "blockId", "localType", "localId"],
      ["relativeText", "structure"]
    ) || !T(e.blockId) || !Co.has(String(e.localType)) || !T(e.localId))
      return Be(
        "complex-address-invalid",
        "address",
        "$.target"
      );
    const t = Object.hasOwn(e, "relativeText") ? Ma(e.relativeText) : void 0, n = Object.hasOwn(e, "structure") ? za(e.structure) : void 0;
    return Object.hasOwn(e, "relativeText") && !t ? Be(
      "complex-address-invalid",
      "address",
      "$.target.relativeText"
    ) : Object.hasOwn(e, "structure") && !n ? Be(
      "complex-address-invalid",
      "address",
      "$.target.structure"
    ) : u({
      valid: !0,
      value: {
        kind: "stable-local",
        blockId: e.blockId,
        localType: e.localType,
        localId: e.localId,
        ...t ? { relativeText: t } : {},
        ...n ? { structure: n } : {}
      },
      diagnostics: []
    });
  }
  return e.kind !== "validated-path" || !oe(e, [
    "kind",
    "blockId",
    "path",
    "ancestorFingerprint",
    "nodeTypeFingerprint",
    "contentFingerprint",
    "shapeFingerprint",
    "sourceSnapshotFingerprint"
  ]) || !T(e.blockId) || !Array.isArray(e.path) || e.path.length === 0 || e.path.length > 64 || !e.path.every(
    (t) => Number.isSafeInteger(t) && t >= 0
  ) || ![
    e.ancestorFingerprint,
    e.nodeTypeFingerprint,
    e.contentFingerprint,
    e.shapeFingerprint,
    e.sourceSnapshotFingerprint
  ].every(H) ? Be("complex-address-invalid", "address", "$.target") : u({
    valid: !0,
    value: e,
    diagnostics: []
  });
}, Va = (e) => {
  const t = Hr(e);
  if (!t.valid) throw new TypeError("complex-address-invalid");
  return To(t.value);
}, Wr = (e) => O(
  "address",
  new TextDecoder().decode(Va(e))
), _a = (e) => {
  if (e.address.kind !== "stable-local" || !e.address.relativeText)
    return u({
      status: "failure",
      diagnostic: B(
        "complex-address-invalid",
        "address",
        "$.target.relativeText"
      )
    });
  const t = e.address.relativeText, n = e.resolveAnchor();
  return !n || t.blockId !== e.expectedBlockId || t.localId !== e.expectedLocalId || n.blockId !== t.blockId || n.localId !== t.localId || n.semanticOffset !== t.semanticOffset ? u({
    status: "failure",
    diagnostic: B(
      "complex-anchor-lost",
      "collaboration",
      "$.target.relativeText"
    )
  }) : t.anchor.capabilityFingerprint !== e.currentCapabilityFingerprint ? u({
    status: "failure",
    diagnostic: B(
      "complex-capability-drifted",
      "collaboration",
      "$.target.relativeText.anchor.capabilityFingerprint"
    )
  }) : u({
    status: "surviving",
    semanticOffset: n.semanticOffset,
    fingerprint: O("resolved-text-address", {
      address: e.address,
      resolved: n
    })
  });
}, Po = /* @__PURE__ */ new WeakMap(), La = (e, t) => {
  Po.set(e, { registry: t });
}, qa = (e) => Po.get(e) ?? null, Xr = (e, t) => {
  var n;
  if (((n = e.attrs) == null ? void 0 : n.blockId) === t) return e;
  for (const r of e.content ?? []) {
    const i = Xr(r, t);
    if (i) return i;
  }
  return null;
}, Ve = (e) => O("node-content", e), Do = (e) => ({
  type: e.type ?? null,
  attrs: Object.keys(e.attrs ?? {}).sort(),
  content: (e.content ?? []).map(Do),
  textLength: typeof e.text == "string" ? e.text.length : null,
  marks: (e.marks ?? []).map((t) => t.type ?? null)
}), wn = (e) => O("node-shape", Do(e)), Kn = (e, t) => {
  const n = e.operations.find(
    (r) => r.name === t
  );
  if (!n) throw new TypeError("complex-operation-unsupported");
  return O("capability", {
    adapter: e.adapter,
    family: e.family,
    address: e.address,
    operation: n
  });
}, Ja = (e, t) => {
  var r;
  let n = e;
  for (const i of t) {
    if (!n) return null;
    n = (r = n.content) == null ? void 0 : r[i];
  }
  return n ?? null;
}, Ka = (e, t, n) => {
  let r = 0;
  const i = (o) => {
    var s, a;
    ((s = o.attrs) == null ? void 0 : s[t]) === n && (r += 1), (a = o.content) == null || a.forEach(i);
  };
  return i(e), r;
}, Ua = (e, t, n) => {
  let r = 0;
  const i = (s) => {
    var a;
    return ((a = s.attrs) == null ? void 0 : a.blockId) === t ? (r += 1, n) : s.content ? { ...s, content: s.content.map(i) } : s;
  }, o = i(e.body.content);
  return {
    matched: r,
    document: {
      ...e,
      body: { ...e.body, content: o }
    }
  };
}, q = (e) => u({ valid: !1, step: null, diagnostics: e }), Ha = (e, t) => {
  if (e.status !== "success" || e.canonicalOutput.byteLength > t)
    return null;
  try {
    const n = JSON.parse(new TextDecoder().decode(e.canonicalOutput));
    if (!K(n) || typeof n.valid != "boolean" || !Array.isArray(n.diagnostics))
      return null;
    if (n.valid === !1)
      return oe(n, ["valid", "plan", "diagnostics"]) && n.plan === null ? n : null;
    if (!oe(n, ["valid", "plan", "diagnostics"]) || n.diagnostics.length !== 0 || !K(n.plan) || !oe(n.plan, [
      "contractVersion",
      "nodeFamily",
      "operation",
      "atomicity",
      "effect",
      "targetFingerprint",
      "resultFingerprint",
      "assetsMetaUnchanged"
    ]) || n.plan.contractVersion !== 1 || !["table", "list", "code", "media", "custom"].includes(
      String(n.plan.nodeFamily)
    ) || typeof n.plan.operation != "string" || !["whole-operation", "declared-parts"].includes(
      String(n.plan.atomicity)
    ) || !H(n.plan.targetFingerprint) || !H(n.plan.resultFingerprint) || typeof n.plan.assetsMetaUnchanged != "boolean" || !K(n.plan.effect))
      return null;
    const r = n.plan.effect;
    return r.kind === "replace-block" && oe(r, ["kind", "blockId", "node"]) && typeof r.blockId == "string" && K(r.node) || r.kind === "replace-text" && oe(r, [
      "kind",
      "blockId",
      "startOffset",
      "endOffset",
      "text"
    ]) && typeof r.blockId == "string" && Number.isSafeInteger(r.startOffset) && Number.isSafeInteger(r.endOffset) && r.startOffset >= 0 && r.endOffset >= r.startOffset && typeof r.text == "string" ? n : null;
  } catch {
    return null;
  }
}, Wa = (e) => B(
  e.status === "timeout" ? "complex-runner-timeout" : e.status === "cancelled" ? "complex-runner-cancelled" : e.status === "over-limit" ? "complex-limit-exceeded" : "complex-runner-malformed",
  "validation",
  "$.runner"
), Xa = (e, t, n, r, i) => {
  const o = e.operation;
  if (e.sourceRegistryFingerprint !== t.fingerprint || e.sourceDescriptorFingerprint !== t.descriptorFingerprint || o.adapter.descriptorFingerprint !== t.descriptorFingerprint || o.target.blockId !== o.preconditions.blockId || o.preconditions.addressFingerprint !== Wr(o.target) || o.preconditions.capabilityFingerprint !== Kn(i, o.operation))
    return B(
      "complex-capability-drifted",
      "precondition",
      "$.bindings"
    );
  if (r.type !== o.preconditions.nodeType || Ve(r) !== o.preconditions.contentFingerprint || wn(r) !== o.preconditions.shapeFingerprint)
    return B(
      "complex-target-drifted",
      "precondition",
      "$.target"
    );
  if (o.target.kind === "validated-path") {
    if (o.target.ancestorFingerprint !== O("node-ancestor", n) || o.target.nodeTypeFingerprint !== O("node-type", r.type ?? null) || o.target.contentFingerprint !== Ve(r) || o.target.shapeFingerprint !== wn(r))
      return B(
        "complex-target-drifted",
        "precondition",
        "$.target.path"
      );
  } else {
    const s = o.target.localType === "row" ? "rowId" : o.target.localType === "cell" ? "cellId" : o.target.localType === "media" ? "assetId" : "blockId", a = o.target.localType === "code-text" ? o.target.blockId : o.target.localId;
    if (Ka(n, s, a) !== 1)
      return B(
        "complex-target-ambiguous",
        "address",
        "$.target.localId"
      );
    if (o.target.localType === "list-item" && (!o.target.structure || Z(o.target.structure) !== Z(
      $a(n, a)
    )))
      return B(
        "complex-target-drifted",
        "precondition",
        "$.target.structure"
      );
  }
  return o.target.kind === "validated-path" && o.target.sourceSnapshotFingerprint !== e.sourceSnapshotFingerprint ? B(
    "complex-target-drifted",
    "precondition",
    "$.target.sourceSnapshotFingerprint"
  ) : null;
}, Ga = (e) => {
  if (!fp(e))
    throw new TypeError("complex-registry-invalid");
  return u({
    registry: e,
    async validateAndPlan(t, n) {
      var k, w;
      if (!n || n.isolated !== !0)
        return q([
          B(
            "complex-unsupported-host",
            "validation",
            "$.runner"
          )
        ]);
      const r = Qs(e, {
        descriptor: t.operation.adapter.descriptor,
        nodeType: t.operation.adapter.nodeType,
        adapterId: t.operation.adapter.adapterId
      });
      if (!r)
        return q([
          B(
            "complex-adapter-not-found",
            "registry",
            "$.operation.adapter"
          )
        ]);
      if (r.version !== t.operation.adapter.adapterVersion || r.fingerprint !== t.operation.adapter.adapterFingerprint)
        return q([
          B(
            "complex-adapter-fingerprint-mismatch",
            "registry",
            "$.operation.adapter"
          )
        ]);
      const i = r.operations[t.operation.operation];
      if (!i)
        return q([
          B(
            "complex-operation-unsupported",
            "registry",
            "$.operation.operation"
          )
        ]);
      if (t.operation.target.kind === "validated-path" && (i.stream === "incremental" || i.collaboration === "stable-rebase"))
        return q([
          B(
            "complex-capability-drifted",
            "precondition",
            "$.operation.target.kind"
          )
        ]);
      const o = e.entries.find(
        (I) => I.adapter.adapterFingerprint === r.fingerprint
      );
      if (t.operation.target.kind === "stable-local" && !o.address.stableLocalTypes.includes(
        t.operation.target.localType
      ) || t.operation.target.kind === "validated-path" && !o.address.validatedPathFallback)
        return q([
          B(
            "complex-address-invalid",
            "address",
            "$.operation.target"
          )
        ]);
      const s = Xr(
        t.document.body.content,
        t.operation.target.blockId
      );
      if (!s)
        return q([
          B(
            "complex-target-drifted",
            "precondition",
            "$.operation.target.blockId"
          )
        ]);
      const a = t.operation.target.kind === "validated-path" ? Ja(s, t.operation.target.path) : s;
      if (!a)
        return q([
          B(
            "complex-target-drifted",
            "address",
            "$.operation.target.path"
          )
        ]);
      const c = Xa(
        t,
        e,
        s,
        a,
        o
      );
      if (c) return q([c]);
      if (t.operation.target.kind === "stable-local" && i.stream === "incremental") {
        const I = t.operation.target, x = I.relativeText;
        if (!x || !t.addressResolution)
          return q([
            B(
              "complex-address-invalid",
              "address",
              "$.operation.target.relativeText"
            )
          ]);
        const R = _a({
          address: I,
          expectedBlockId: I.blockId,
          expectedLocalId: I.localId,
          currentCapabilityFingerprint: Kn(
            o,
            t.operation.operation
          ),
          resolveAnchor: () => t.addressResolution.resolveRelativeText(x)
        });
        if (R.status === "failure")
          return q([R.diagnostic]);
      }
      let l;
      try {
        kn(t.operation.payload, i.limits), l = i.decodePayload(t.operation.payload);
      } catch {
        return q([
          B(
            "complex-limit-exceeded",
            "decode",
            "$.operation.payload"
          )
        ]);
      }
      if (!l.valid) return q(l.diagnostics);
      if (r.family === "media") {
        const I = K(l.value) ? l.value : null, x = typeof (I == null ? void 0 : I.assetId) == "string" ? I.assetId : typeof ((k = a.attrs) == null ? void 0 : k.assetId) == "string" ? a.attrs.assetId : null, R = x ? t.document.assets.find((X) => X.id === x) : null;
        if (!x || !R || !t.resourceAdmission)
          return q([
            B(
              "complex-resource-not-staged",
              "resource",
              "$.resourceAdmission"
            )
          ]);
        const A = await t.resourceAdmission.port.verify({
          receipt: t.resourceAdmission.receipt,
          expectedPhase: t.resourceAdmission.phase,
          expectedDocumentRevision: t.sourceDocumentRevision,
          expectedAssetId: x,
          expectedAssetFingerprint: O("asset", R),
          expectedPrincipalFingerprint: t.resourceAdmission.principalFingerprint,
          expectedAdapterFingerprint: r.fingerprint,
          expectedPolicyFingerprint: t.resourceAdmission.policyFingerprint,
          logicalTime: t.resourceAdmission.logicalTime
        });
        if (A.status !== "verified")
          return q([
            B(
              A.status === "unavailable" ? "complex-resource-host-failed" : "complex-resource-receipt-invalid",
              "resource",
              "$.resourceAdmission.receipt"
            )
          ]);
      }
      const g = O("execution-id", {
        operationIndex: t.operationIndex,
        adapter: t.operation.adapter,
        payload: l.value,
        target: t.operation.target
      }), f = ea({
        runtimeResourceProfileFingerprint: t.resourceProfileFingerprint,
        registryFingerprint: e.fingerprint,
        adapter: o.adapter,
        operation: o.operations.find(
          (I) => I.name === t.operation.operation
        )
      }), p = {
        action: "validate",
        adapter: t.operation.adapter,
        operation: t.operation.operation,
        input: {
          document: t.document,
          target: a,
          address: t.operation.target,
          preconditions: t.operation.preconditions,
          payload: l.value,
          operation: t.operation.operation
        }
      }, d = await n.run({
        executionId: g,
        component: i.compiler,
        canonicalInput: To(p),
        resourceProfileFingerprint: f,
        timeoutMs: i.limits.timeoutMs,
        maxOutputBytes: i.limits.maxOutputBytes
      }), h = Ha(
        d,
        i.limits.maxOutputBytes
      );
      if (!h)
        return n.terminate(g), q([Wa(d)]);
      if (!h.valid) return q(h.diagnostics);
      const m = h.plan;
      try {
        kn(
          m,
          i.limits,
          i.limits.maxOutputBytes
        );
      } catch {
        return q([
          B(
            "complex-limit-exceeded",
            "compile",
            "$.plan"
          )
        ]);
      }
      if (m.operation !== t.operation.operation || m.nodeFamily !== r.family || m.targetFingerprint !== Ve(a) || m.effect.blockId !== t.operation.target.blockId || m.effect.kind === "replace-block" && (((w = m.effect.node.attrs) == null ? void 0 : w.blockId) !== t.operation.target.blockId || m.resultFingerprint !== Ve(m.effect.node)) || r.family === "media" && m.assetsMetaUnchanged !== !0)
        return q([
          B(
            "complex-plan-nondeterministic",
            "compile",
            "$.plan"
          )
        ]);
      if (m.effect.kind === "replace-block") {
        const I = Ua(
          t.document,
          t.operation.target.blockId,
          m.effect.node
        ), x = la(
          I.document
        );
        if (I.matched !== 1 || !x.valid)
          return q([
            B(
              "complex-schema-invalid",
              "compile",
              "$.plan.effect.node"
            )
          ]);
      }
      const y = O(
        "plan-fragment",
        m
      ), b = u({
        operationIndex: t.operationIndex,
        protocolVersion: 2,
        kind: "node.apply",
        adapter: t.operation.adapter,
        target: t.operation.target,
        preconditions: t.operation.preconditions,
        operation: t.operation.operation,
        payload: l.value,
        payloadFingerprint: v(l.value),
        planFragment: m,
        planFragmentFingerprint: y,
        compiler: i.compiler,
        resourceProfileFingerprint: f
      });
      try {
        Z(b);
      } catch {
        return q([
          B(
            "complex-runner-malformed",
            "compile",
            "$.step"
          )
        ]);
      }
      return u({ valid: !0, step: b, diagnostics: [] });
    }
  });
}, Bo = (e) => !K(e) || !oe(e, [
  "descriptor",
  "descriptorFingerprint",
  "nodeType",
  "adapterId",
  "adapterVersion",
  "adapterFingerprint"
]) || !T(e.descriptor) || !H(e.descriptorFingerprint) || !T(e.nodeType) || !T(e.adapterId) || !T(e.adapterVersion) || !H(e.adapterFingerprint) ? Be(
  "complex-adapter-fingerprint-mismatch",
  "decode",
  "$.adapter"
) : u({
  valid: !0,
  value: e,
  diagnostics: []
}), jo = (e) => !K(e) || !oe(e, [
  "addressFingerprint",
  "blockId",
  "nodeType",
  "contentFingerprint",
  "shapeFingerprint",
  "capabilityFingerprint"
]) || !H(e.addressFingerprint) || !T(e.blockId) || !T(e.nodeType) || !H(e.contentFingerprint) || !H(e.shapeFingerprint) || !H(e.capabilityFingerprint) ? Be(
  "complex-payload-invalid",
  "precondition",
  "$.preconditions"
) : u({
  valid: !0,
  value: e,
  diagnostics: []
}), Za = (e, t) => {
  try {
    kn(e, t);
  } catch {
    return Be(
      "complex-limit-exceeded",
      "decode",
      "$.operation"
    );
  }
  if (!K(e) || !oe(e, [
    "kind",
    "adapter",
    "target",
    "preconditions",
    "operation",
    "payload"
  ]) || e.kind !== "node.apply" || !T(e.operation))
    return Be(
      "complex-payload-invalid",
      "decode",
      "$.operation"
    );
  const n = Bo(e.adapter), r = Hr(e.target), i = jo(e.preconditions);
  return !n.valid || !r.valid || !i.valid ? u({
    valid: !1,
    value: null,
    diagnostics: [
      ...n.diagnostics,
      ...r.diagnostics,
      ...i.diagnostics
    ]
  }) : u({
    valid: !0,
    value: {
      kind: "node.apply",
      adapter: n.value,
      target: r.value,
      preconditions: i.value,
      operation: e.operation,
      payload: e.payload
    },
    diagnostics: []
  });
}, Ya = {
  "protocol-envelope-invalid": {
    phase: "protocol",
    message: "The operation envelope is not valid protocol JSON."
  },
  "protocol-version-unsupported": {
    phase: "protocol",
    message: "The operation protocol version is not supported."
  },
  "operation-kind-unsupported": {
    phase: "shape",
    message: "The operation kind is not supported."
  },
  "operation-shape-invalid": {
    phase: "shape",
    message: "The operation does not match its exact protocol shape."
  },
  "snapshot-precondition-failed": {
    phase: "source",
    message: "The source snapshot fingerprint does not match."
  },
  "revision-precondition-failed": {
    phase: "source",
    message: "The source document revision does not match."
  },
  "descriptor-precondition-failed": {
    phase: "source",
    message: "The source descriptor fingerprint does not match."
  },
  "operation-target-not-found": {
    phase: "address",
    message: "The addressed block does not exist in the snapshot."
  },
  "operation-target-not-operable": {
    phase: "address",
    message: "The addressed block is not operable in this snapshot."
  },
  "operation-address-invalid": {
    phase: "address",
    message: "The operation address is invalid."
  },
  "operation-range-invalid": {
    phase: "address",
    message: "The text range is not an exposed UTF-16 block range."
  },
  "operation-precondition-block-mismatch": {
    phase: "precondition",
    message: "The operation precondition addresses a different block."
  },
  "operation-type-precondition-failed": {
    phase: "precondition",
    message: "The block type precondition does not match."
  },
  "operation-content-precondition-failed": {
    phase: "precondition",
    message: "The block content precondition does not match."
  },
  "operation-capability-denied": {
    phase: "capability",
    message: "The manifest capability does not permit this operation."
  },
  "operation-payload-invalid": {
    phase: "payload",
    message: "The canonical block payload is invalid."
  },
  "operation-block-id-invalid": {
    phase: "payload",
    message: "The payload blockId is invalid."
  },
  "operation-block-id-conflict": {
    phase: "payload",
    message: "The payload blockId conflicts with the snapshot."
  },
  "operation-batch-conflict": {
    phase: "batch",
    message: "The operation batch contains an implicit dependency or conflict."
  },
  "complex-node-validation-failed": {
    phase: "capability",
    message: "The complex-node operation failed closed validation."
  },
  "internal-validation-failed": {
    phase: "internal",
    message: "The operation could not be validated safely."
  }
}, C = (e, t = {}) => u({
  code: e,
  severity: "error",
  ...Ya[e],
  ...t.operationIndex === void 0 ? {} : { operationIndex: t.operationIndex },
  ...t.kind === void 0 ? {} : { kind: t.kind },
  ...t.blockId === void 0 ? {} : { blockId: t.blockId },
  ...t.nodeType === void 0 ? {} : { nodeType: t.nodeType },
  ...t.complexCode === void 0 ? {} : { complexCode: t.complexCode },
  ...t.recovery === void 0 ? {} : { recovery: t.recovery }
}), Qa = (e) => F({
  code: e.code,
  phase: e.phase,
  operationIndex: e.operationIndex ?? -1,
  kind: e.kind ?? "",
  blockId: e.blockId ?? "",
  nodeType: e.nodeType ?? "",
  complexCode: e.complexCode ?? "",
  recovery: e.recovery ?? ""
}), ct = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((n) => {
    const r = Qa(n);
    t.has(r) || t.set(r, n);
  }), u(
    [...t.entries()].sort(([n], [r]) => n.localeCompare(r)).map(([, n]) => n)
  );
}, xi = /* @__PURE__ */ new Set([
  "read-only",
  "external-resource",
  "sensitive"
]), we = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, Fn = (e, t) => Object.keys(e).every((n) => t.includes(n)), Ii = (e) => {
  try {
    F(e);
  } catch {
    return !1;
  }
  const t = (r) => r === void 0 || Array.isArray(r) && r.every(
    (i) => we(i) && Fn(i, ["type", "attrs"]) && typeof i.type == "string" && i.type.trim().length > 0 && (i.attrs === void 0 || we(i.attrs))
  ), n = (r) => !we(r) || !Fn(r, ["type", "attrs", "content", "marks", "text"]) || typeof r.type != "string" || r.type.trim().length === 0 || r.attrs !== void 0 && !we(r.attrs) || r.text !== void 0 && typeof r.text != "string" || !t(r.marks) ? !1 : r.content === void 0 || Array.isArray(r.content) && r.content.every((i) => n(i));
  return n(e);
}, vi = (e) => {
  const t = {
    operationIndex: e.operationIndex,
    kind: e.kind
  }, n = [], r = new Map(
    e.manifest.nodes.map((d) => [d.type, d])
  ), i = new Map(
    e.manifest.marks.map((d) => [d.type, d])
  ), o = () => n.push(
    C("operation-payload-invalid", t)
  ), s = (d, h, m) => {
    if (d === void 0)
      return m ? null : {};
    if (!we(d))
      return o(), null;
    const y = new Set(h);
    return m && y.add("blockId"), Object.keys(d).some((b) => !y.has(b)) ? (o(), null) : d;
  }, a = (d) => {
    if (d === void 0) return !0;
    if (!Array.isArray(d))
      return o(), !1;
    let h = !0;
    return d.forEach((m) => {
      if (!we(m) || !Fn(m, ["type", "attrs"]) || typeof m.type != "string") {
        o(), h = !1;
        return;
      }
      const y = i.get(m.type);
      if (!y || xi.has(y.risk) || y.stream === "none") {
        n.push(
          C("operation-capability-denied", {
            ...t,
            nodeType: m.type
          })
        ), h = !1;
        return;
      }
      s(m.attrs, y.readableAttrs, !1) || (h = !1);
    }), h;
  }, c = (d, h) => {
    if (!we(d) || !Fn(d, ["type", "attrs", "content", "marks", "text"]) || typeof d.type != "string" || d.type.trim().length === 0)
      return o(), !1;
    const m = r.get(d.type);
    if (!m)
      return n.push(
        C("operation-capability-denied", {
          ...t,
          nodeType: d.type
        })
      ), !1;
    if (h && m.addressability !== "block" || !h && m.addressability === "block" || m.content === "block" || m.content === "mixed" || xi.has(m.risk) || m.stream === "none")
      return n.push(
        C("operation-capability-denied", {
          ...t,
          nodeType: d.type
        })
      ), !1;
    let y = !0;
    return s(d.attrs, m.readableAttrs, h) || (y = !1), d.type === "text" ? ((typeof d.text != "string" || d.content !== void 0 || d.attrs !== void 0) && (o(), y = !1), a(d.marks) || (y = !1), y) : ((d.text !== void 0 || d.marks !== void 0) && (o(), y = !1), m.content === "none" && d.content !== void 0 ? (o(), y = !1) : d.content !== void 0 && (Array.isArray(d.content) ? d.content.forEach((k) => {
      if (m.content === "text" && (!we(k) || k.type !== "text")) {
        o(), y = !1;
        return;
      }
      c(k, !1) || (y = !1);
    }) : (o(), y = !1)), y);
  }, l = c(e.payload, !0), g = we(e.payload) ? e.payload : null, f = g && we(g.attrs) ? g.attrs : null, p = f == null ? void 0 : f.blockId;
  if (hi(p) ? e.expectedBlockId !== void 0 && p !== e.expectedBlockId ? n.push(
    C("operation-block-id-conflict", {
      ...t,
      blockId: p
    })
  ) : e.expectedBlockId === void 0 && e.observedBlockIds.has(p) && n.push(
    C("operation-block-id-conflict", {
      ...t,
      blockId: p
    })
  ) : n.push(
    C("operation-block-id-invalid", t)
  ), !l || n.length > 0 || !hi(p))
    return { valid: !1, block: null, blockId: null, diagnostics: n };
  try {
    return { valid: !0, block: JSON.parse(
      F(e.payload)
    ), blockId: p, diagnostics: [] };
  } catch {
    return {
      valid: !1,
      block: null,
      blockId: null,
      diagnostics: [
        C("operation-payload-invalid", t)
      ]
    };
  }
}, ec = (e) => Array.from(e, (t) => t.toString(16).padStart(2, "0")).join(""), Ut = async (e) => {
  var r;
  const t = (r = globalThis.crypto) == null ? void 0 : r.subtle;
  t || pe([
    {
      code: "crypto-unavailable",
      severity: "error",
      message: "Web Crypto subtle.digest is required for AI semantic fingerprints."
    }
  ]);
  const n = await t.digest("SHA-256", bo(e));
  return `sha256:${ec(new Uint8Array(n))}`;
}, Or = (e) => !!(e && Object.prototype.hasOwnProperty.call(e, "startOffset") && Object.prototype.hasOwnProperty.call(e, "endOffset")), No = (e, t) => {
  e.forEach((n) => {
    t(n), No(n.children, t);
  });
}, tc = (e, t) => {
  const n = [], r = (i, o = !1) => {
    var s;
    !o && i.address && !Or(i.address) && i.address.blockId !== t || (Or(i.address) && i.address.blockId === t && typeof i.text == "string" ? n.push({
      kind: "text",
      startOffset: i.address.startOffset,
      endOffset: i.address.endOffset,
      text: i.text
    }) : i.type === "hardBreak" && ((s = i.relation) == null ? void 0 : s.ancestorBlockId) === t && n.push({ kind: "hard-break" }), i.children.forEach((a) => r(a)));
  };
  return r(e, !0), n;
}, nc = (e, t) => {
  const n = tc(e, t);
  if (n.length === 0)
    return u([{ startOffset: 0, endOffset: 0, text: "" }]);
  const r = [];
  if (n.forEach((o, s) => {
    var d;
    if (o.kind === "text") {
      if (!Number.isInteger(o.startOffset) || !Number.isInteger(o.endOffset) || o.startOffset < 0 || o.endOffset < o.startOffset || o.text.length !== o.endOffset - o.startOffset)
        return;
      r.push(o);
      return;
    }
    const a = (d = [...n].slice(0, s).map((h, m) => ({ entry: h, entryIndex: m })).reverse().find(({ entry: h }) => h.kind === "text")) == null ? void 0 : d.entryIndex, c = n.slice(s + 1).findIndex((h) => h.kind === "text"), l = c < 0 ? -1 : s + 1 + c, g = a === void 0 ? null : n[a], f = l < 0 ? null : n[l], p = g ? g.endOffset + (s - a - 1) : f ? f.startOffset - (l - s) : s;
    !Number.isInteger(p) || p < 0 || r.push({
      startOffset: p,
      endOffset: p + 1,
      text: `
`
    });
  }), r.length !== n.length || r.some(
    (o) => o.text.length !== o.endOffset - o.startOffset
  ))
    return null;
  r.sort(
    (o, s) => o.startOffset - s.startOffset || o.endOffset - s.endOffset
  );
  const i = [];
  for (const o of r) {
    const s = i.at(-1);
    if (!s) {
      i.push({ ...o });
      continue;
    }
    if (o.startOffset < s.endOffset) return null;
    if (o.startOffset === s.endOffset) {
      s.endOffset = o.endOffset, s.text += o.text;
      continue;
    }
    i.push({ ...o });
  }
  return u(i);
}, Mo = (e) => {
  const t = /* @__PURE__ */ new Set(), n = [];
  No(e.nodes, (r) => {
    var i;
    n.push(r), (i = r.address) != null && i.blockId && t.add(r.address.blockId);
  });
  try {
    if (new Set(e.operableBlockIds).size !== e.operableBlockIds.length)
      return {
        valid: !1,
        targets: null,
        observedBlockIds: t,
        diagnostics: ct([
          C("internal-validation-failed")
        ])
      };
    const r = new Set(
      e.manifest.nodes.filter((o) => o.addressability === "block").map((o) => o.type)
    ), i = /* @__PURE__ */ new Map();
    for (const o of e.operableBlockIds) {
      const s = n.filter(
        (l) => {
          var g;
          return l.operability === "operable" && ((g = l.address) == null ? void 0 : g.blockId) === o && !Or(l.address) && r.has(l.type);
        }
      );
      if (s.length !== 1)
        return {
          valid: !1,
          targets: null,
          observedBlockIds: t,
          diagnostics: ct([
            C("internal-validation-failed")
          ])
        };
      const a = s[0], c = nc(a, o);
      if (!c)
        return {
          valid: !1,
          targets: null,
          observedBlockIds: t,
          diagnostics: ct([
            C("internal-validation-failed")
          ])
        };
      i.set(o, {
        blockId: o,
        type: a.type,
        node: a,
        intervals: c
      });
    }
    return {
      valid: !0,
      targets: i,
      observedBlockIds: t,
      diagnostics: []
    };
  } catch {
    return {
      valid: !1,
      targets: null,
      observedBlockIds: t,
      diagnostics: ct([
        C("internal-validation-failed")
      ])
    };
  }
}, zo = async (e) => {
  const t = Mo(e);
  if (!t.valid) return t;
  try {
    const n = /* @__PURE__ */ new Map();
    for (const [r, i] of t.targets)
      n.set(r, {
        ...i,
        contentFingerprint: await Ut(i.node)
      });
    return {
      valid: !0,
      targets: n,
      observedBlockIds: t.observedBlockIds,
      diagnostics: []
    };
  } catch {
    return {
      valid: !1,
      targets: null,
      observedBlockIds: t.observedBlockIds,
      diagnostics: ct([
        C("internal-validation-failed")
      ])
    };
  }
}, ki = (e) => u({
  valid: !1,
  precondition: null,
  diagnostics: ct(e)
}), lf = async (e, t) => {
  const n = await zo(e);
  if (!n.valid) return ki(n.diagnostics);
  const r = n.targets.get(t);
  if (!r)
    return ki([
      C(
        n.observedBlockIds.has(t) ? "operation-target-not-operable" : "operation-target-not-found",
        { blockId: t }
      )
    ]);
  const i = {
    blockId: t,
    type: r.type,
    contentFingerprint: r.contentFingerprint
  };
  return u({ valid: !0, precondition: i, diagnostics: [] });
}, rc = (e, t, n) => e.intervals.find(
  (r) => t >= r.startOffset && n <= r.endOffset
) ?? null, wi = (e, t) => {
  const n = t - e.startOffset;
  if (n <= 0 || n >= e.text.length) return !1;
  const r = e.text.charCodeAt(n - 1), i = e.text.charCodeAt(n);
  return r >= 55296 && r <= 56319 && i >= 56320 && i <= 57343;
}, ic = /* @__PURE__ */ new Set([
  "text.replace",
  "block.insert",
  "block.replace",
  "block.delete",
  "node.apply"
]), oc = {
  maxPayloadBytes: 12e5,
  maxDepth: 64,
  maxKeys: 16e3,
  maxArrayLength: 8192,
  maxStringLength: 5e5,
  maxDiagnostics: 8,
  maxOutputBytes: 12e5,
  timeoutMs: 2e3,
  nodeBudget: { kind: "custom", maxComplexity: 1e5 }
}, Fi = /* @__PURE__ */ new Set([
  "read-only",
  "external-resource",
  "sensitive"
]), Re = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, xe = (e, t, n = []) => {
  const r = Object.keys(e);
  return t.every(
    (i) => Object.prototype.hasOwnProperty.call(e, i)
  ) && r.every((i) => t.includes(i) || n.includes(i));
}, he = (e) => typeof e == "string" && e.trim().length > 0, on = (e) => !Re(e) || !xe(e, ["blockId", "type", "contentFingerprint"]) || !he(e.blockId) || !he(e.type) || !he(e.contentFingerprint) ? null : {
  blockId: e.blockId,
  type: e.type,
  contentFingerprint: e.contentFingerprint
}, sc = (e, t, n) => {
  if (!Re(e) || typeof e.kind != "string")
    return n.push(
      C("operation-kind-unsupported", {
        operationIndex: t
      })
    ), null;
  if (!ic.has(e.kind))
    return n.push(
      C("operation-kind-unsupported", {
        operationIndex: t
      })
    ), null;
  const r = e.kind, i = { operationIndex: t, kind: r }, o = () => (n.push(
    C("operation-shape-invalid", i)
  ), null);
  if (r === "node.apply") {
    const a = Za(
      e,
      oc
    );
    return a.valid ? a.value : o();
  }
  if (r === "text.replace") {
    if (!xe(e, ["kind", "target", "precondition", "text"]) || !Re(e.target) || !xe(e.target, ["blockId", "startOffset", "endOffset"]) || !he(e.target.blockId) || typeof e.text != "string")
      return o();
    const a = on(e.precondition);
    return a ? !Number.isInteger(e.target.startOffset) || !Number.isInteger(e.target.endOffset) || e.target.startOffset < 0 || e.target.endOffset < e.target.startOffset ? (n.push(
      C("operation-address-invalid", {
        ...i,
        blockId: e.target.blockId
      })
    ), null) : {
      kind: r,
      target: {
        blockId: e.target.blockId,
        startOffset: e.target.startOffset,
        endOffset: e.target.endOffset
      },
      precondition: a,
      text: e.text
    } : o();
  }
  if (r === "block.insert") {
    if (!xe(e, ["kind", "reference", "precondition", "block"]) || !Re(e.reference) || !xe(e.reference, ["blockId", "side"]) || !he(e.reference.blockId) || e.reference.side !== "before" && e.reference.side !== "after" || !Ii(e.block))
      return o();
    const a = on(e.precondition);
    return a ? {
      kind: r,
      reference: {
        blockId: e.reference.blockId,
        side: e.reference.side
      },
      precondition: a,
      block: e.block
    } : o();
  }
  if (r === "block.replace") {
    if (!xe(e, ["kind", "target", "precondition", "block"]) || !Re(e.target) || !xe(e.target, ["blockId"]) || !he(e.target.blockId) || !Ii(e.block))
      return o();
    const a = on(e.precondition);
    return a ? {
      kind: r,
      target: { blockId: e.target.blockId },
      precondition: a,
      block: e.block
    } : o();
  }
  if (!xe(e, ["kind", "target", "precondition"]) || !Re(e.target) || !xe(e.target, ["blockId"]) || !he(e.target.blockId))
    return o();
  const s = on(e.precondition);
  return s ? {
    kind: "block.delete",
    target: { blockId: e.target.blockId },
    precondition: s
  } : o();
}, $o = (e, t) => {
  try {
    Ra(e, "operation-protocol-v2");
  } catch {
    return t.push(C("protocol-envelope-invalid")), null;
  }
  if (!Re(e) || !xe(e, ["protocolVersion", "source", "operations"]) || (e.protocolVersion !== Oo && t.push(
    C("protocol-version-unsupported")
  ), !Re(e.source) || !xe(e.source, [
    "snapshotFingerprint",
    "documentRevision",
    "descriptorFingerprint",
    "registryFingerprint"
  ]) || !he(e.source.snapshotFingerprint) || !he(e.source.documentRevision) || !he(e.source.descriptorFingerprint) || !he(e.source.registryFingerprint) || !Array.isArray(e.operations) || e.operations.length === 0))
    return t.push(C("protocol-envelope-invalid")), null;
  const n = e.operations.map(
    (r, i) => sc(r, i, t)
  );
  return t.length > 0 || n.some((r) => !r) ? null : {
    source: {
      snapshotFingerprint: e.source.snapshotFingerprint,
      documentRevision: e.source.documentRevision,
      descriptorFingerprint: e.source.descriptorFingerprint,
      registryFingerprint: e.source.registryFingerprint
    },
    operations: n
  };
}, df = (e) => {
  const t = [];
  return $o(e, t) !== null && t.length === 0;
}, bt = (e) => u({
  valid: !1,
  diagnostics: ct(e),
  plan: null
}), or = (e) => e.kind === "block.insert" ? e.reference.blockId : e.target.blockId, Ri = (e, t, n, r) => {
  const i = n.nodes.find((o) => o.type === e.type);
  if (!i || i.addressability !== "block") return !1;
  if (t.kind === "text.replace")
    return (i.content === "text" || i.content === "inline") && i.risk === "textual" && i.stream !== "none";
  if (t.kind === "node.apply") {
    const o = r == null ? void 0 : r.registry.entries.find(
      (s) => s.adapter.adapterFingerprint === t.adapter.adapterFingerprint && s.adapter.adapterId === t.adapter.adapterId && s.adapter.nodeType === t.adapter.nodeType && s.adapter.descriptor === t.adapter.descriptor
    );
    return !!(o && e.type === t.adapter.nodeType && i.descriptor === t.adapter.descriptor && (!Fi.has(i.risk) || i.risk === "external-resource" && o.family === "media") && o.operations.some(
      (s) => s.name === t.operation
    ));
  }
  return t.kind === "block.delete" || t.kind === "block.replace" ? !Fi.has(i.risk) : !0;
}, ac = async (e) => {
  var t;
  try {
    const n = [], r = $o(e.envelope, n);
    if (!r || (r.source.snapshotFingerprint !== e.snapshot.fingerprint && n.push(
      C("snapshot-precondition-failed")
    ), r.source.documentRevision !== e.snapshot.documentRevision && n.push(
      C("revision-precondition-failed")
    ), r.source.descriptorFingerprint !== e.snapshot.descriptorFingerprint && n.push(
      C("descriptor-precondition-failed")
    ), n.length > 0)) return bt(n);
    if (r.operations.some(
      (f) => f.kind === "node.apply"
    ) && (!e.complex || r.source.registryFingerprint !== e.complex.registry.fingerprint))
      return n.push(
        C("complex-node-validation-failed", {
          complexCode: "complex-capability-drifted",
          recovery: "regenerate"
        })
      ), bt(n);
    const o = await zo(e.snapshot);
    if (!o.valid) return bt(o.diagnostics);
    const s = [], a = /* @__PURE__ */ new Map();
    for (const [f, p] of r.operations.entries())
      p.kind !== "block.insert" || !Re(p.block) || !Re(p.block.attrs) || !he(p.block.attrs.blockId) || a.set(f, p.block.attrs.blockId);
    for (const [f, p] of r.operations.entries()) {
      const d = or(p), h = { operationIndex: f, kind: p.kind, blockId: d }, m = n.length, y = o.targets.get(d);
      if (!y) {
        n.push(
          C(
            o.observedBlockIds.has(d) ? "operation-target-not-operable" : "operation-target-not-found",
            h
          )
        );
        continue;
      }
      if (p.kind === "node.apply") {
        const b = e.complex;
        if (!b) {
          n.push(
            C("complex-node-validation-failed", {
              ...h,
              complexCode: "complex-unsupported-host",
              recovery: "install-adapter"
            })
          );
          continue;
        }
        if (!Ri(
          y,
          p,
          e.snapshot.manifest,
          b
        )) {
          n.push(
            C("operation-capability-denied", {
              ...h,
              nodeType: y.type
            })
          );
          continue;
        }
        const k = await Ga(
          b.registry
        ).validateAndPlan(
          {
            document: b.document,
            sourceSnapshotFingerprint: r.source.snapshotFingerprint,
            sourceDocumentRevision: r.source.documentRevision,
            sourceDescriptorFingerprint: r.source.descriptorFingerprint,
            sourceRegistryFingerprint: r.source.registryFingerprint,
            operation: p,
            operationIndex: f,
            resourceProfileFingerprint: b.resourceProfileFingerprint,
            addressResolution: b.addressResolution,
            resourceAdmission: (t = b.resourceAdmissions) == null ? void 0 : t[f]
          },
          b.runner
        );
        k.valid ? n.length === m && s.push(k.step) : k.diagnostics.forEach(
          (w) => n.push(
            C("complex-node-validation-failed", {
              ...h,
              complexCode: w.code,
              recovery: w.recovery
            })
          )
        );
        continue;
      }
      if (p.precondition.blockId !== d && n.push(
        C(
          "operation-precondition-block-mismatch",
          h
        )
      ), p.precondition.type !== y.type && n.push(
        C("operation-type-precondition-failed", {
          ...h,
          nodeType: y.type
        })
      ), p.precondition.contentFingerprint !== y.contentFingerprint && n.push(
        C(
          "operation-content-precondition-failed",
          h
        )
      ), Ri(
        y,
        p,
        e.snapshot.manifest,
        e.complex
      ) || n.push(
        C("operation-capability-denied", {
          ...h,
          nodeType: y.type
        })
      ), p.kind === "text.replace") {
        const b = rc(
          y,
          p.target.startOffset,
          p.target.endOffset
        );
        (!b || wi(b, p.target.startOffset) || wi(b, p.target.endOffset)) && n.push(
          C("operation-range-invalid", h)
        ), n.length === m && s.push({ operationIndex: f, ...p });
        continue;
      }
      if (p.kind === "block.insert") {
        e.snapshot.scope.kind !== "document" && n.push(
          C("operation-capability-denied", h)
        );
        const b = vi({
          payload: p.block,
          manifest: e.snapshot.manifest,
          operationIndex: f,
          kind: p.kind,
          observedBlockIds: o.observedBlockIds
        });
        n.push(...b.diagnostics), n.length === m && b.valid && s.push({ operationIndex: f, ...p, block: b.block });
        continue;
      }
      if (p.kind === "block.replace") {
        const b = vi({
          payload: p.block,
          manifest: e.snapshot.manifest,
          operationIndex: f,
          kind: p.kind,
          expectedBlockId: d,
          observedBlockIds: o.observedBlockIds
        });
        n.push(...b.diagnostics), n.length === m && b.valid && s.push({ operationIndex: f, ...p, block: b.block });
        continue;
      }
      n.length === m && s.push({ operationIndex: f, ...p });
    }
    const c = /* @__PURE__ */ new Set();
    r.operations.forEach((f, p) => {
      const d = or(f);
      c.has(d) && n.push(
        C("operation-batch-conflict", {
          operationIndex: p,
          kind: f.kind,
          blockId: d
        })
      ), c.add(d);
    });
    const l = /* @__PURE__ */ new Set();
    if (a.forEach((f, p) => {
      const d = r.operations[p];
      l.has(f) && n.push(
        C("operation-batch-conflict", {
          operationIndex: p,
          kind: d.kind,
          blockId: f
        })
      ), l.add(f);
    }), r.operations.forEach((f, p) => {
      const d = or(f);
      l.has(d) && n.push(
        C("operation-batch-conflict", {
          operationIndex: p,
          kind: f.kind,
          blockId: d
        })
      );
    }), n.length > 0 || s.length !== r.operations.length)
      return bt(n);
    const g = u({
      protocolVersion: Oo,
      offsetEncoding: "utf-16",
      source: r.source,
      steps: s
    });
    return s.some((f) => f.kind === "node.apply") && La(g, e.complex.registry), u({
      valid: !0,
      diagnostics: [],
      plan: g
    });
  } catch {
    return bt([
      C("internal-validation-failed")
    ]);
  }
}, cc = {
  inputBytes: "input-bytes-budget-exceeded",
  inputDepth: "input-depth-budget-exceeded",
  inputKeys: "input-keys-budget-exceeded",
  documentNodes: "document-node-budget-exceeded",
  documentMarks: "document-mark-budget-exceeded",
  documentBlocks: "document-block-budget-exceeded",
  annotations: "annotation-budget-exceeded",
  planOperations: "plan-operation-budget-exceeded",
  executionPlugins: "execution-plugin-budget-exceeded",
  rootSteps: "root-step-budget-exceeded",
  steps: "step-budget-exceeded",
  transactions: "transaction-budget-exceeded",
  filterCalls: "filter-call-budget-exceeded",
  appendCalls: "append-call-budget-exceeded",
  appendRounds: "append-round-budget-exceeded",
  mappingMaps: "mapping-map-budget-exceeded",
  mappingRanges: "mapping-range-budget-exceeded",
  mappingBytes: "mapping-byte-budget-exceeded",
  mappingMirrors: "mapping-mirror-budget-exceeded",
  mappingMirrorBytes: "mapping-mirror-byte-budget-exceeded",
  metaBytes: "meta-byte-budget-exceeded",
  traceBytes: "trace-byte-budget-exceeded",
  pluginStateBytes: "plugin-state-byte-budget-exceeded",
  safeDiagnosticCount: "safe-diagnostic-count-budget-exceeded",
  safeDiagnosticBytes: "safe-diagnostic-byte-budget-exceeded"
}, lc = () => Object.fromEntries(
  Object.keys(st).map((e) => [e, 0])
);
class Tr extends Error {
  constructor(t, n, r, i) {
    const o = cc[t];
    super(`${o}:${i}`), this.name = "RuntimeResourceExceededV2Error", this.code = o, this.diagnostic = u({
      code: o,
      stage: t.startsWith("input") || t.startsWith("document") || t === "annotations" || t === "planOperations" || t === "executionPlugins" ? "stage-1" : "stage-2",
      path: i,
      profileId: ua.id,
      counter: t,
      current: n,
      limit: r
    });
  }
}
const Vo = (e = st) => {
  const t = lc(), n = (i, o, s = `$.resources.${i}`) => {
    if (!Number.isSafeInteger(o) || o < 0)
      throw new TypeError(
        `Invalid deterministic resource count for ${i}.`
      );
    const a = e[i];
    if (o > a)
      throw new Tr(i, o, a, s);
    t[i] = o;
  }, r = (i) => {
    const o = { ...t };
    i.forEach(({ counter: s, amount: a, path: c }) => {
      if (!Number.isSafeInteger(a) || a < 0)
        throw new TypeError(
          `Invalid deterministic resource debit for ${s}.`
        );
      const l = o[s] + a, g = e[s];
      if (l > g)
        throw new Tr(
          s,
          l,
          g,
          c ?? `$.resources.${s}`
        );
      o[s] = l;
    }), Object.assign(t, o);
  };
  return {
    limits: e,
    debit(i, o = 1, s = `$.resources.${i}`) {
      r([{ counter: i, amount: o, path: s }]);
    },
    reserve: r,
    set: n,
    snapshot: () => u({ ...t })
  };
}, dc = (e) => {
  let t = 0, n = 0;
  const r = (i, o) => {
    if (t = Math.max(t, o), !i || typeof i != "object") return;
    if (Array.isArray(i)) {
      i.forEach((c) => r(c, o + 1));
      return;
    }
    const s = i, a = Object.keys(s);
    n += a.length, a.forEach((c) => r(s[c], o + 1));
  };
  return r(e, 1), { depth: t, keys: n };
}, pc = (e) => {
  let t = 0, n = 0, r = 0;
  const i = (o) => {
    var s, a, c;
    t += 1, n += ((s = o.marks) == null ? void 0 : s.length) ?? 0, typeof ((a = o.attrs) == null ? void 0 : a.blockId) == "string" && (r += 1), (c = o.content) == null || c.forEach(i);
  };
  return i(e), { nodes: t, marks: n, blocks: r };
}, fc = (e, t, n, r, i) => {
  const o = F(t), s = dc(t), a = pc(n.body.content);
  e.set("inputBytes", new TextEncoder().encode(o).byteLength, "$"), e.set("inputDepth", s.depth, "$"), e.set("inputKeys", s.keys, "$"), e.set(
    "documentNodes",
    a.nodes,
    "$.baseDocument.body.content"
  ), e.set(
    "documentMarks",
    a.marks,
    "$.baseDocument.body.content"
  ), e.set(
    "documentBlocks",
    a.blocks,
    "$.baseDocument.body.content"
  ), e.set(
    "annotations",
    n.annotations.length,
    "$.baseDocument.annotations"
  ), e.set("planOperations", r.steps.length, "$.plan.steps"), e.set(
    "executionPlugins",
    i,
    "$.runtime.executionClosure"
  );
}, Ye = (e) => new TextEncoder().encode(F(e)).byteLength, _o = (e, t, n = {}) => {
  const r = {
    code: t,
    stage: n.stage ?? "execution",
    path: n.path ?? "$",
    ...n.profileId ? { profileId: n.profileId } : {},
    ...n.componentId ? { componentId: n.componentId } : {},
    ...n.operationIndex !== void 0 ? { operationIndex: n.operationIndex } : {},
    ...n.sequence !== void 0 ? { sequence: n.sequence } : {},
    ...n.pluginInstanceId ? { pluginInstanceId: n.pluginInstanceId } : {},
    ...n.counter ? { counter: n.counter } : {},
    ...n.current !== void 0 ? { current: n.current } : {},
    ...n.limit !== void 0 ? { limit: n.limit } : {},
    ...n.fingerprintPrefix ? { fingerprintPrefix: n.fingerprintPrefix } : {}
  };
  return e.reserve([
    {
      counter: "safeDiagnosticCount",
      amount: 1,
      path: "$.diagnostic"
    },
    {
      counter: "safeDiagnosticBytes",
      amount: Ye(r),
      path: "$.diagnostic"
    }
  ]), u(r);
}, uc = (e, t) => u(
  Object.fromEntries(
    Object.keys(e).map((n) => [
      n,
      e[n] - t[n]
    ])
  )
), gc = (e, t) => {
  const n = Ye({
    version: "runtime-execution-trace-v2",
    ...e,
    resources: t.snapshot(),
    fingerprint: "sha256:".padEnd(71, "0")
  }) + 512;
  t.debit("traceBytes", n, "$.trace");
  const r = {
    version: "runtime-execution-trace-v2",
    executionId: e.executionId,
    manifest: e.manifest,
    entries: e.entries,
    mapping: e.mapping,
    resources: t.snapshot(),
    resultFingerprint: e.resultFingerprint
  };
  return u({
    ...r,
    fingerprint: v(r)
  });
}, Gr = (e) => e.config, mc = (e, t, n, r = -1) => {
  const i = Gr(e).plugins;
  for (const [o, s] of i.entries()) {
    if (o === r) continue;
    const a = s.spec.filterTransaction;
    if (a && (n.debit("filterCalls", 1, `$.driver.filter[${o}]`), !a.call(s, t, e)))
      return !1;
  }
  return !0;
}, hc = (e, t, n, r) => {
  if (!t.before.eq(e.doc))
    throw new RangeError("transaction-attribution-invalid");
  r > 0 && n.debit(
    "pluginStateBytes",
    r,
    "$.driver.pluginState.reservation"
  ), n.debit("transactions", 1, "$.driver.transactions");
  const i = Gr(e), o = Ao, s = new o(i);
  for (const a of i.fields)
    s[a.name] = a.apply(
      t,
      e[a.name],
      e,
      s
    );
  return s;
}, yc = (e) => Gr(e).plugins;
class je extends Error {
  constructor(t, n) {
    super(`${t}:${n}`), this.code = t, this.path = n, this.name = "RuntimeDriverFailureV2Error";
  }
}
const Si = (e) => v(e.doc.toJSON()), bc = (e) => [
  ...new Set(
    e.flatMap((t) => {
      const n = t.getMeta("zx.runtime.root.v2"), r = t.getMeta("zx.runtime.appended.v2");
      return n ? n.operationSpans.map((i) => i.operationIndex) : (r == null ? void 0 : r.operationIndexes) ?? [];
    })
  )
].sort((t, n) => t - n), xc = (e) => e.steps.map((t) => {
  const n = t.toJSON(), i = t.getMap().ranges;
  return u({
    json: n,
    fingerprint: v(n),
    mapFingerprint: v({ ranges: i })
  });
}), Ic = (e, t, n) => e.map((r) => {
  const i = r.project(t), o = r.project(n);
  return u({
    pluginInstanceId: r.instanceId,
    projectorRef: r.projectorRef,
    beforeFingerprint: v(i),
    afterFingerprint: v(o),
    value: o
  });
}), vc = (e, t, n) => e.map((r) => {
  const i = r.project(t), o = r.projectAfterApply(t, n);
  return u({
    pluginInstanceId: r.instanceId,
    projectorRef: r.projectorRef,
    beforeFingerprint: v(i),
    afterFingerprint: v(o),
    value: o
  });
}), sr = (e, t) => {
  var n;
  return {
    document: e.doc.toJSON(),
    selection: e.selection.toJSON(),
    storedMarks: ((n = e.storedMarks) == null ? void 0 : n.map((r) => r.toJSON())) ?? null,
    pluginStateFingerprint: t
  };
}, ar = (e, t) => v(
  e.map((n) => ({
    pluginInstanceId: n.pluginInstanceId,
    fingerprint: t === "before" ? n.beforeFingerprint : n.afterFingerprint
  }))
), kc = (e) => {
  const t = e.getMeta("zx.runtime.root.v2"), n = e.getMeta("zx.runtime.appended.v2");
  return {
    kind: t ? "root" : "appended",
    producer: n && typeof n.pluginInstanceId == "string" ? n.pluginInstanceId : null,
    steps: e.steps.map((r) => r.toJSON()),
    before: e.before.toJSON(),
    after: e.doc.toJSON()
  };
}, Ai = (e, t, n) => {
  const {
    state: r,
    transaction: i,
    kind: o,
    sequence: s,
    executionId: a,
    spans: c,
    producerIndex: l
  } = e, g = n.snapshot();
  if (!i.before.eq(r.doc))
    throw new je(
      "transaction-attribution-invalid",
      "$.driver.before"
    );
  let f;
  try {
    f = wo(
      i,
      o,
      s,
      a
    );
  } catch (I) {
    const x = I instanceof Error && I.message === "transaction-time-invalid" ? "transaction-time-invalid" : I instanceof Error && I.message === "transaction-attribution-invalid" ? "transaction-attribution-invalid" : "transaction-meta-invalid";
    throw new je(x, "$.driver.meta");
  }
  if (n.debit("metaBytes", Ye(f), "$.driver.meta"), o === "root" && n.debit("rootSteps", i.steps.length, "$.driver.root.steps"), n.debit("steps", i.steps.length, "$.driver.steps"), !mc(r, i, n, l))
    throw new je(
      "transaction-filter-rejected",
      "$.driver.filter"
    );
  const p = vc(
    t,
    r,
    i
  ), d = p.reduce(
    (I, x) => I + Ye(x),
    0
  ), h = n.snapshot().pluginStateBytes, m = hc(
    r,
    i,
    n,
    d
  );
  if (!m.doc.eq(i.doc))
    throw new je(
      "transaction-attribution-invalid",
      "$.driver.after"
    );
  const y = Ic(t, r, m), b = y.reduce(
    (I, x) => I + Ye(x),
    0
  );
  if (b > d || v(y) !== v(p))
    throw new je(
      "plugin-conformance-missing",
      "$.driver.pluginState.reservation"
    );
  n.set(
    "pluginStateBytes",
    h + b,
    "$.driver.pluginState"
  );
  const k = t.flatMap(
    (I) => I.effect(i)
  ), w = {
    kind: o,
    sequence: s,
    logicalTime: i.time,
    rootExecutionId: a,
    sourceAttribution: ga(i, o),
    operationSpans: c,
    steps: xc(i),
    allowedMeta: f,
    beforeDocumentFingerprint: Si(r),
    afterDocumentFingerprint: Si(m),
    selectionAndStoredMarksProof: {
      selectionSet: !1,
      storedMarksSet: !1
    },
    pluginState: y,
    safeEffects: k,
    resourceDelta: uc(n.snapshot(), g)
  };
  return {
    state: m,
    entry: u({
      ...w,
      fingerprint: v(w)
    })
  };
}, wc = (e, t, n, r, i, o = $e) => {
  var m;
  const s = yc(e);
  if (s.length !== o.length || s.some((y, b) => y !== o[b].plugin))
    throw new je(
      "plugin-conformance-missing",
      "$.driver.plugins"
    );
  const a = Ai(
    {
      state: e,
      transaction: t,
      kind: "root",
      sequence: 0,
      executionId: r,
      spans: n,
      producerIndex: -1
    },
    o,
    i
  );
  let c = a.state, l = ar(
    a.entry.pluginState,
    "after"
  );
  const g = ar(
    a.entry.pluginState,
    "before"
  ), f = [t], p = [a.entry], d = o.map(() => ({
    state: e,
    n: 0,
    pluginStateFingerprint: g
  })), h = /* @__PURE__ */ new Set();
  for (; ; ) {
    i.debit("appendRounds", 1, "$.driver.append.round");
    let y = !1;
    for (let b = 0; b < o.length; b += 1) {
      const k = o[b], w = k.plugin.spec.appendTransaction, I = d[b].n;
      if (!w || I >= f.length) {
        d[b] = {
          state: c,
          n: f.length,
          pluginStateFingerprint: l
        };
        continue;
      }
      const x = f.slice(I), R = v({
        pluginInstanceId: k.instanceId,
        currentState: sr(
          c,
          l
        ),
        oldState: sr(
          d[b].state,
          d[b].pluginStateFingerprint
        ),
        orderedSeenStates: d.map(
          (Te) => sr(Te.state, Te.pluginStateFingerprint)
        ),
        visibleTransactions: x.map(kc)
      });
      if (h.has(R))
        throw new je(
          "append-fixed-point-cycle",
          "$.driver.append"
        );
      h.add(R), i.debit("appendCalls", 1, `$.driver.append[${b}]`);
      const A = w.call(
        k.plugin,
        x,
        d[b].state,
        c
      );
      if (d[b] = {
        state: c,
        n: f.length,
        pluginStateFingerprint: l
      }, !A) continue;
      const X = f.length, _ = bc(x), le = {
        executionId: r,
        sequence: X,
        pluginInstanceId: k.instanceId,
        pluginOrder: k.order,
        visibleTransactionRange: [I, f.length - 1],
        operationIndexes: _
      }, ee = A.getMeta(vo);
      if (ee) {
        const Te = {
          protocol: "zx-runtime-appended-meta-v2",
          rootExecutionId: r,
          sequence: X,
          pluginInstanceId: k.instanceId,
          pluginOrder: k.order,
          visibleTransactionRange: le.visibleTransactionRange,
          operationIndexes: _
        };
        if (F(ee) !== F(Te))
          throw new je(
            "transaction-attribution-invalid",
            "$.driver.append.meta"
          );
      } else
        ko(A, le);
      const qe = Ai(
        {
          state: c,
          transaction: A,
          kind: "appended",
          sequence: X,
          executionId: r,
          spans: [],
          producerIndex: b
        },
        o,
        i
      );
      f.push(A), p.push(qe.entry), c = qe.state, l = ar(
        qe.entry.pluginState,
        "after"
      ), y = !0, d[b] = {
        state: c,
        n: f.length,
        pluginStateFingerprint: l
      };
    }
    if (!y && d.every(
      (b) => b.n === f.length && b.state === c
    ))
      return {
        state: c,
        transactions: f,
        entries: u(p),
        pluginState: ((m = p.at(-1)) == null ? void 0 : m.pluginState) ?? []
      };
  }
};
class Lo extends TypeError {
  constructor(t) {
    super(`mark-policy-violation:${t}`), this.path = t, this.name = "RuntimeMarkPolicyV2Error";
  }
}
const Fc = (e, t) => [...e].sort((n, r) => {
  const i = (t.get(n.type.name) ?? Number.MAX_SAFE_INTEGER) - (t.get(r.type.name) ?? Number.MAX_SAFE_INTEGER);
  if (i !== 0) return i;
  const o = F(n.attrs), s = F(r.attrs);
  return o < s ? -1 : o > s ? 1 : 0;
}), Rc = (e, t) => {
  if (e.parent !== t.parent || !e.parent.inlineContent)
    throw new Lo("$.plan.text.replace.target");
}, Sc = (e, t, n, r) => {
  const i = e.resolve(t), o = e.resolve(n);
  if (Rc(i, o), r.length === 0) return [];
  const s = t === n ? i.marks() : i.marksAcross(o) ?? [], a = new Map(
    Object.keys(e.type.schema.marks).map((l, g) => [l, g])
  ), c = Fc(s, a);
  return c.forEach((l) => {
    if (!e.type.schema.marks[l.type.name])
      throw new Lo("$.plan.text.replace.marks");
  }), c;
}, Ac = (e, t) => {
  if (t <= 0 || t >= e.length) return !1;
  const n = e.charCodeAt(t - 1), r = e.charCodeAt(t);
  return n >= 55296 && n <= 56319 && r >= 56320 && r <= 57343;
}, Ec = (e) => !!(e && (typeof e == "object" || typeof e == "function") && typeof e.then == "function"), at = (e, t, n) => pe([
  {
    code: e,
    severity: "error",
    message: t,
    descriptor: n == null ? void 0 : n.descriptor,
    kind: n == null ? void 0 : n.kind,
    type: n == null ? void 0 : n.type,
    blockId: n == null ? void 0 : n.blockId,
    attr: n == null ? void 0 : n.attr
  }
]), Zr = (e, t, n, r) => {
  if (!e) return r;
  let i;
  try {
    i = e(t);
  } catch {
    return at(
      "policy-threw",
      "AI snapshot policy hook threw an exception.",
      t
    );
  }
  if (Ec(i))
    return at(
      "policy-async-result",
      "AI snapshot policy hooks must return synchronously.",
      t
    );
  try {
    F(i);
  } catch {
    return at(
      "policy-result-not-canonical",
      "AI snapshot policy decisions must be canonicalizable.",
      t
    );
  }
  const o = i == null ? void 0 : i.action;
  return typeof o != "string" || !n.has(o) ? at(
    "policy-decision-invalid",
    "AI snapshot policy returned an unknown action.",
    t
  ) : o === "replace" && !Object.prototype.hasOwnProperty.call(i, "value") ? at(
    "policy-decision-invalid",
    "AI snapshot policy replace decisions require a value.",
    t
  ) : i;
}, Oc = (e) => {
  e && (typeof e.id != "string" || !e.id.trim() || typeof e.version != "string" || !e.version.trim()) && at(
    "policy-decision-invalid",
    "AI snapshot policy requires stable non-empty id and version."
  );
}, Rn = (e, t) => Zr(e == null ? void 0 : e.node, t, /* @__PURE__ */ new Set(["include", "omit"]), {
  action: "include"
}), qo = (e, t) => Zr(
  e == null ? void 0 : e.attr,
  t,
  /* @__PURE__ */ new Set(["include", "omit", "replace"]),
  { action: "include" }
), Tc = (e, t) => {
  const n = Zr(
    e == null ? void 0 : e.text,
    t,
    /* @__PURE__ */ new Set(["include", "omit", "replace"]),
    { action: "include" }
  );
  return n.action === "replace" && typeof n.value != "string" && at(
    "policy-decision-invalid",
    "AI text policy replacement must be a string.",
    t
  ), n;
}, lt = (e) => ({
  code: "scope-access-denied",
  severity: "info",
  message: e.attr ? `Policy omitted attr "${e.attr}" from AI semantic output.` : `Policy omitted ${e.kind} "${e.type}" from AI semantic output.`,
  descriptor: e.descriptor,
  kind: e.kind,
  type: e.type,
  blockId: e.blockId,
  ...e.attr ? { attr: e.attr } : {}
}), cr = (e, t) => e.descriptor.localeCompare(t.descriptor) || e.kind.localeCompare(t.kind) || e.type.localeCompare(t.type), Jo = (e) => {
  const t = [], n = [], r = [];
  return e.forEach((i) => {
    Object.entries(i.ai.nodes).forEach(([o, s]) => {
      if (!s.supported) {
        r.push({
          descriptor: i.name,
          kind: "node",
          type: o,
          supported: !1,
          reasonCode: s.reasonCode,
          description: s.description
        });
        return;
      }
      t.push({
        descriptor: i.name,
        kind: "node",
        type: o,
        semanticName: s.semanticName,
        description: s.description,
        addressability: s.addressability,
        readableAttrs: [...s.readableAttrs].sort(),
        content: s.content,
        risk: s.risk,
        stream: s.stream
      });
    }), Object.entries(i.ai.marks).forEach(([o, s]) => {
      if (!s.supported) {
        r.push({
          descriptor: i.name,
          kind: "mark",
          type: o,
          supported: !1,
          reasonCode: s.reasonCode,
          description: s.description
        });
        return;
      }
      n.push({
        descriptor: i.name,
        kind: "mark",
        type: o,
        semanticName: s.semanticName,
        description: s.description,
        addressability: s.addressability,
        readableAttrs: [...s.readableAttrs].sort(),
        content: s.content,
        risk: s.risk,
        stream: s.stream
      });
    });
  }), t.sort(cr), n.sort(cr), r.sort(cr), { nodes: t, marks: n, unsupported: r };
}, Ko = (e, t) => (xo(e), u({
  contractVersion: 1,
  descriptorFingerprint: t,
  ...Jo(e)
})), Cc = (e) => u({
  admittedNodes: new Map(e.nodes.map((t) => [t.type, t])),
  admittedMarks: new Map(e.marks.map((t) => [t.type, t])),
  deniedNodes: /* @__PURE__ */ new Set(),
  deniedMarks: /* @__PURE__ */ new Set(),
  readableAttrs: new Map(
    [...e.nodes, ...e.marks].map((t) => [
      `${t.kind}:${t.type}`,
      new Set(t.readableAttrs)
    ])
  )
}), Pc = async (e = qn) => {
  const t = await Ut(
    Kr(e)
  );
  return Ko(
    e,
    t
  );
}, Dc = async (e, t) => {
  const r = {
    contractVersion: 1,
    descriptorFingerprint: await Ut(
      Kr(t)
    ),
    ...Jo(t)
  };
  F(e) !== F(r) && pe([
    {
      code: "manifest-drift",
      severity: "error",
      message: "AI schema manifest fingerprint does not match its descriptor truth."
    }
  ]);
}, Bc = async (e, t) => {
  Oc(t);
  const n = await Pc(e);
  await Dc(n, e);
  const r = [], i = [], o = [], s = [], a = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), g = (p) => {
    if (Rn(t, {
      phase: "manifest",
      descriptor: p.descriptor,
      type: p.type,
      kind: p.kind,
      blockId: null
    }).action === "omit")
      return (p.kind === "node" ? c : l).add(p.type), s.push(
        lt({
          descriptor: p.descriptor,
          type: p.type,
          kind: p.kind,
          blockId: null
        })
      ), null;
    const h = [];
    return p.readableAttrs.forEach((m) => {
      if (qo(t, {
        phase: "manifest",
        descriptor: p.descriptor,
        type: p.type,
        kind: p.kind,
        blockId: null,
        attr: m,
        value: null
      }).action === "omit") {
        s.push(
          lt({
            descriptor: p.descriptor,
            type: p.type,
            kind: p.kind,
            blockId: null,
            attr: m
          })
        );
        return;
      }
      h.push(m);
    }), a.set(`${p.kind}:${p.type}`, new Set(h)), { ...p, readableAttrs: h };
  };
  n.nodes.forEach((p) => {
    const d = g(p);
    d && r.push(d);
  }), n.marks.forEach((p) => {
    const d = g(p);
    d && i.push(d);
  }), n.unsupported.forEach((p) => {
    if (Rn(t, {
      phase: "manifest",
      descriptor: p.descriptor,
      type: p.type,
      kind: p.kind,
      blockId: null
    }).action === "omit") {
      (p.kind === "node" ? c : l).add(p.type), s.push(
        lt({
          descriptor: p.descriptor,
          type: p.type,
          kind: p.kind,
          blockId: null
        })
      );
      return;
    }
    o.push(p);
  });
  const f = u({
    contractVersion: n.contractVersion,
    descriptorFingerprint: n.descriptorFingerprint,
    nodes: r,
    marks: i,
    unsupported: o
  });
  return u({
    manifest: f,
    admission: {
      admittedNodes: new Map(r.map((p) => [p.type, p])),
      admittedMarks: new Map(i.map((p) => [p.type, p])),
      deniedNodes: c,
      deniedMarks: l,
      readableAttrs: a
    },
    diagnostics: s
  });
}, Uo = (e, t) => {
  var n;
  if (((n = e.attrs) == null ? void 0 : n.blockId) === t) return e;
  for (const r of e.content ?? []) {
    const i = Uo(r, t);
    if (i) return i;
  }
  return null;
}, Ei = (e, t, n) => {
  var i, o;
  let r = ((i = t.get(e)) == null ? void 0 : i.parentBlockId) ?? null;
  for (; r; )
    n.add(r), r = ((o = t.get(r)) == null ? void 0 : o.parentBlockId) ?? null;
}, lr = (e, t, n, r, i, o, s) => {
  const a = r.get(e);
  if (!a) {
    const c = Uo(n, e), l = c ? o.unsupported.find(
      (g) => g.kind === "node" && g.type === c.type
    ) : null;
    return s.push({
      code: l ? "scope-block-unsupported" : "scope-block-not-found",
      severity: "error",
      message: l ? `Requested block "${e}" has unsupported type "${c == null ? void 0 : c.type}".` : `Requested block "${e}" does not exist.`,
      type: c == null ? void 0 : c.type,
      kind: "node",
      blockId: e,
      inputIndex: t
    }), null;
  }
  return i.admittedNodes.has(a.nodeType) ? a : (s.push({
    code: "scope-access-denied",
    severity: "error",
    message: `Policy denied access to requested block "${e}".`,
    type: a.nodeType,
    kind: "node",
    blockId: e,
    inputIndex: t
  }), null);
}, Ho = (e, t, n, r, i) => {
  const o = [...n.values()].sort(
    (y, b) => y.order - b.order
  );
  if (e.kind === "document") {
    const y = (k) => {
      let w = n.get(k) ?? null;
      for (; w; ) {
        if (!r.admittedNodes.has(w.nodeType)) return !1;
        w = w.parentBlockId ? n.get(w.parentBlockId) ?? null : null;
      }
      return !0;
    }, b = o.filter((k) => y(k.blockId)).map((k) => k.blockId);
    return {
      normalized: { kind: "document" },
      selection: null,
      contentBlockIds: new Set(b),
      contextBlockIds: /* @__PURE__ */ new Set(),
      operableBlockIds: b
    };
  }
  if (e.kind === "blocks") {
    const y = [], b = /* @__PURE__ */ new Set();
    e.blockIds.length === 0 && y.push({
      code: "scope-block-not-found",
      severity: "error",
      message: "Blocks scope requires at least one explicit blockId."
    }), e.blockIds.forEach((I, x) => {
      if (b.has(I)) {
        y.push({
          code: "scope-block-duplicate",
          severity: "error",
          message: `Blocks scope repeats blockId "${I}".`,
          blockId: I,
          inputIndex: x
        });
        return;
      }
      b.add(I), lr(
        I,
        x,
        t,
        n,
        r,
        i,
        y
      );
    }), y.length > 0 && pe(y);
    const k = o.filter((I) => b.has(I.blockId)).map((I) => I.blockId), w = /* @__PURE__ */ new Set();
    return k.forEach(
      (I) => Ei(I, n, w)
    ), k.forEach((I) => w.delete(I)), {
      normalized: { kind: "blocks", blockIds: k },
      selection: null,
      contentBlockIds: new Set(k),
      contextBlockIds: w,
      operableBlockIds: k
    };
  }
  const s = [], a = lr(
    e.anchor.start.blockId,
    0,
    t,
    n,
    r,
    i,
    s
  ), c = lr(
    e.anchor.end.blockId,
    1,
    t,
    n,
    r,
    i,
    s
  );
  a && (e.anchor.start.offset < 0 || e.anchor.start.offset > a.textLength) && s.push({
    code: "selection-anchor-invalid",
    severity: "error",
    message: "Selection start offset is outside its block.",
    blockId: a.blockId,
    type: a.nodeType
  }), c && (e.anchor.end.offset < 0 || e.anchor.end.offset > c.textLength) && s.push({
    code: "selection-anchor-invalid",
    severity: "error",
    message: "Selection end offset is outside its block.",
    blockId: c.blockId,
    type: c.nodeType
  }), a && c && (a.order > c.order || a.order === c.order && e.anchor.start.offset > e.anchor.end.offset) && s.push({
    code: "selection-anchor-invalid",
    severity: "error",
    message: "Selection start must not follow selection end.",
    blockId: a.blockId
  }), s.length > 0 && pe(s), (!a || !c) && pe([
    {
      code: "selection-anchor-invalid",
      severity: "error",
      message: "Selection anchors could not be resolved."
    }
  ]);
  const l = a, g = c, f = l.blockId === g.blockId && e.anchor.start.offset === e.anchor.end.offset, p = o.filter(
    (y) => y.order >= l.order && y.order <= g.order
  ).map((y) => y.blockId), d = {
    start: {
      blockId: l.blockId,
      offset: e.anchor.start.offset
    },
    end: { blockId: g.blockId, offset: e.anchor.end.offset },
    collapsed: f,
    blockIds: p
  }, h = new Set(f ? [] : p), m = new Set(
    f ? [l.blockId] : []
  );
  return p.forEach(
    (y) => Ei(y, n, m)
  ), h.forEach((y) => m.delete(y)), {
    normalized: { kind: "selection", selection: d },
    selection: d,
    contentBlockIds: h,
    contextBlockIds: m,
    operableBlockIds: f ? [] : p
  };
}, jc = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((n) => {
    n.textSegments.forEach(
      (r) => t.set(r.node, { blockId: n.blockId, segment: r })
    );
  }), t;
}, Nc = (e, t, n) => {
  if (!n.selection) return { start: 0, end: t };
  const { selection: r } = n;
  return r.collapsed ? { start: r.start.offset, end: r.start.offset } : {
    start: e === r.start.blockId ? r.start.offset : 0,
    end: e === r.end.blockId ? r.end.offset : t
  };
}, Wo = (e, t, n, r, i) => {
  const o = [], s = jc(t), a = /* @__PURE__ */ new Map(), c = (d) => {
    var m;
    const h = typeof ((m = d.attrs) == null ? void 0 : m.blockId) == "string" ? d.attrs.blockId : null;
    return h && (r.contentBlockIds.has(h) || r.contextBlockIds.has(h)) ? !0 : (d.content ?? []).some(c);
  }, l = (d, h, m, y, b, k) => {
    const w = n.readableAttrs.get(`${m}:${y}`) ?? /* @__PURE__ */ new Set(), I = {};
    return [...w].sort().forEach((x) => {
      if (!k || !Object.prototype.hasOwnProperty.call(k, x)) return;
      const R = qo(i, {
        phase: "snapshot",
        descriptor: h,
        type: y,
        kind: m,
        blockId: b,
        attr: x,
        value: k[x]
      });
      if (R.action === "omit") {
        o.push(
          lt({
            descriptor: h,
            type: y,
            kind: m,
            blockId: b,
            attr: x
          })
        );
        return;
      }
      I[x] = R.action === "replace" ? R.value : k[x];
      try {
        F(I[x]);
      } catch {
        pe([
          {
            code: "policy-result-not-canonical",
            severity: "error",
            message: "Projected AI attribute is not canonicalizable.",
            descriptor: h,
            kind: m,
            type: y,
            blockId: b,
            attr: x
          }
        ]);
      }
    }), I;
  }, g = (d, h, m, y) => {
    const b = [];
    return d.forEach((k) => {
      const w = k.type ?? "unknown", I = n.admittedMarks.get(w);
      if (!I) {
        if (n.deniedMarks.has(w)) return;
        pe([
          {
            code: "unknown-document-mark",
            severity: "error",
            message: `Mark "${w}" is unknown, unsupported or denied by policy.`,
            kind: "mark",
            type: w,
            blockId: h
          }
        ]);
      }
      const x = I;
      if (Rn(i, {
        phase: "snapshot",
        descriptor: x.descriptor,
        kind: "mark",
        type: w,
        blockId: h
      }).action === "omit") {
        o.push(
          lt({
            descriptor: x.descriptor,
            kind: "mark",
            type: w,
            blockId: h
          })
        );
        return;
      }
      b.push({
        type: w,
        semanticName: x.semanticName,
        attrs: l(
          k,
          x.descriptor,
          "mark",
          w,
          h,
          k.attrs
        ),
        address: x.addressability === "block-range" ? { blockId: h, startOffset: m, endOffset: y } : null
      });
    }), b.sort((k, w) => k.type.localeCompare(w.type));
  }, f = (d, h, m, y) => {
    var pi, fi, ui;
    const b = d.type ?? "unknown", k = n.admittedNodes.get(b);
    if (!k) {
      if (n.deniedNodes.has(b))
        return h === "shell" && c(d) && pe([
          {
            code: "scope-access-denied",
            severity: "error",
            message: "Policy denied an ancestor required by the requested scope.",
            kind: "node",
            type: b,
            blockId: typeof ((pi = d.attrs) == null ? void 0 : pi.blockId) == "string" ? d.attrs.blockId : null
          }
        ]), null;
      if (h === "shell" && !c(d))
        return null;
      pe([
        {
          code: "unknown-document-node",
          severity: "error",
          message: `Node "${b}" is unknown, unsupported or denied by policy.`,
          kind: "node",
          type: b,
          blockId: typeof ((fi = d.attrs) == null ? void 0 : fi.blockId) == "string" ? d.attrs.blockId : null
        }
      ]);
    }
    const w = k, I = w.addressability === "block" && typeof ((ui = d.attrs) == null ? void 0 : ui.blockId) == "string" ? d.attrs.blockId : null;
    let x = h;
    if (I)
      if (r.contentBlockIds.has(I)) x = "content";
      else if (r.contextBlockIds.has(I)) x = "shell";
      else return null;
    let R = a.get(d);
    if (R || (R = Rn(i, {
      phase: "snapshot",
      descriptor: w.descriptor,
      kind: "node",
      type: b,
      blockId: I ?? m
    }).action, a.set(d, R)), R === "omit")
      return r.normalized.kind !== "document" && (I && (r.contentBlockIds.has(I) || r.contextBlockIds.has(I)) || c(d)) && pe([
        {
          code: "scope-access-denied",
          severity: "error",
          message: "Policy denied a node required by the requested scope.",
          descriptor: w.descriptor,
          kind: "node",
          type: b,
          blockId: I
        }
      ]), o.push(
        lt({
          descriptor: w.descriptor,
          kind: "node",
          type: b,
          blockId: I ?? m
        })
      ), null;
    const A = I ?? m, X = (d.content ?? []).map(
      (jt, rn) => f(jt, x, A, rn)
    ).filter((jt) => !!jt), _ = s.get(d);
    let le, ee = null;
    if (typeof d.text == "string" && _ && x === "content") {
      const jt = t.get(_.blockId), rn = Nc(
        _.blockId,
        jt.textLength,
        r
      ), nr = Math.max(_.segment.startOffset, rn.start), rr = Math.min(_.segment.endOffset, rn.end);
      if (rr <= nr) return null;
      const gi = nr - _.segment.startOffset, mi = rr - _.segment.startOffset, ir = Tc(i, {
        phase: "snapshot",
        descriptor: w.descriptor,
        type: b,
        blockId: _.blockId,
        value: d.text.slice(gi, mi)
      });
      if (ir.action === "omit")
        return o.push(
          lt({
            descriptor: w.descriptor,
            kind: "node",
            type: b,
            blockId: _.blockId
          })
        ), null;
      le = ir.action === "replace" ? ir.value : d.text.slice(gi, mi), ee = { blockId: _.blockId, startOffset: nr, endOffset: rr };
    }
    if (x === "shell" && X.length === 0 && !I) return null;
    const qe = l(
      d,
      w.descriptor,
      "node",
      b,
      I ?? m,
      d.attrs
    ), Te = x === "content" && ee ? g(
      d.marks ?? [],
      ee.blockId,
      ee.startOffset,
      ee.endOffset
    ) : [], tr = x === "content" && I ? { blockId: I } : ee, ca = I ? null : {
      addressable: !1,
      ancestorBlockId: x === "content" && m ? m : null,
      role: b,
      ordinal: y,
      persistence: "snapshot-local"
    };
    return {
      type: b,
      semanticName: w.semanticName,
      operability: x === "content" && (I && r.operableBlockIds.includes(I)) || x === "content" && ee ? "operable" : "context-only",
      address: tr,
      relation: ca,
      attrs: qe,
      ...le !== void 0 ? { text: le } : {},
      marks: Te,
      children: X
    };
  }, p = f(
    e,
    r.normalized.kind === "document" ? "content" : "shell",
    null,
    0
  );
  return {
    nodes: p ? [p] : [],
    diagnostics: o
  };
}, Mc = (e) => {
  const t = qn, n = new Set(
    t.flatMap(
      (g) => Object.entries(g.ai.nodes).filter(
        ([, f]) => f.supported && f.addressability === "block"
      ).map(([f]) => f)
    )
  ), r = Eo(e, n), i = Ko(
    t,
    v(Kr(t))
  ), o = Cc(i), s = Ho(
    { kind: "document" },
    e.body.content,
    r,
    o,
    i
  ), a = Wo(
    e.body.content,
    r,
    o,
    s
  ), c = {
    manifest: i,
    nodes: a.nodes,
    operableBlockIds: s.operableBlockIds
  }, l = Mo(c);
  if (!l.valid) throw new TypeError("plan-invalid");
  return new Map(
    [...l.targets].map(([g, f]) => [
      g,
      {
        blockId: g,
        type: f.type,
        contentFingerprint: v(f.node)
      }
    ])
  );
}, Un = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.descendants((n, r) => {
    const i = typeof n.attrs.blockId == "string" ? n.attrs.blockId : null;
    if (!i) return;
    if (t.has(i)) throw new TypeError("document-invalid");
    const o = [];
    let s = "";
    n.descendants((a, c) => {
      if (typeof a.attrs.blockId == "string" ? a.attrs.blockId : null) return !1;
      if (a.isText) {
        const g = a.text ?? "";
        return o.push({
          from: r + 1 + c,
          to: r + 1 + c + g.length,
          startOffset: s.length,
          endOffset: s.length + g.length,
          text: g
        }), s += g, !1;
      }
      if (a.type.name === "hardBreak")
        return o.push({
          from: r + 1 + c,
          to: r + 2 + c,
          startOffset: s.length,
          endOffset: s.length + 1,
          text: `
`
        }), s += `
`, !1;
    }), t.set(
      i,
      u({
        blockId: i,
        type: n.type.name,
        pos: r,
        nodeSize: n.nodeSize,
        text: s,
        textSegments: o,
        nodeJSON: n.toJSON()
      })
    );
  }), t;
}, Sn = (e, t) => {
  if (!Number.isInteger(t) || t < 0 || t > e.text.length)
    throw new RangeError("operation-compile-failed");
  if (Ac(e.text, t))
    throw new RangeError("mark-policy-violation");
  if (e.textSegments.length === 0) return e.pos + 1;
  if (t === e.text.length) return e.textSegments.at(-1).to;
  const n = e.textSegments.find(
    (r) => t >= r.startOffset && t < r.endOffset
  );
  if (!n) throw new RangeError("operation-compile-failed");
  return n.from + (t - n.startOffset);
}, se = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), re = (e, t) => {
  const n = Object.keys(e).sort(), r = [...t].sort();
  return n.length === r.length && n.every((i, o) => i === r[o]);
}, Q = (e) => typeof e == "string" && e.length > 0, zc = (e) => se(e) && re(e, ["blockId", "type", "contentFingerprint"]) && Q(e.blockId) && Q(e.type) && Q(e.contentFingerprint), $c = (e) => se(e) && Object.keys(e).every((t) => ["type", "attrs"].includes(t)) && Q(e.type) && (e.attrs === void 0 || se(e.attrs)), An = (e) => se(e) && Object.keys(e).every(
  (t) => ["type", "attrs", "content", "marks", "text"].includes(t)
) && Q(e.type) && (e.attrs === void 0 || se(e.attrs)) && (e.text === void 0 || typeof e.text == "string") && (e.marks === void 0 || Array.isArray(e.marks) && e.marks.every($c)) && (e.content === void 0 || Array.isArray(e.content) && e.content.every(An)), ut = (e) => typeof e == "string" && /^sha256:[0-9a-f]{64}$/.test(e), Vc = (e) => se(e) && re(e, [
  "id",
  "version",
  "fingerprint",
  "kind",
  "planContractVersion"
]) && Q(e.id) && Q(e.version) && ut(e.fingerprint) && e.kind === "complex-node-compiler" && e.planContractVersion === 1, _c = (e) => {
  if (!se(e) || !re(e, [
    "contractVersion",
    "nodeFamily",
    "operation",
    "atomicity",
    "effect",
    "targetFingerprint",
    "resultFingerprint",
    "assetsMetaUnchanged"
  ]) || e.contractVersion !== 1 || !["table", "list", "code", "media", "custom"].includes(
    String(e.nodeFamily)
  ) || !Q(e.operation) || !["whole-operation", "declared-parts"].includes(String(e.atomicity)) || !ut(e.targetFingerprint) || !ut(e.resultFingerprint) || typeof e.assetsMetaUnchanged != "boolean" || !se(e.effect))
    return !1;
  const t = e.effect;
  return t.kind === "replace-block" && re(t, ["kind", "blockId", "node"]) && Q(t.blockId) && An(t.node) || t.kind === "replace-text" && re(t, [
    "kind",
    "blockId",
    "startOffset",
    "endOffset",
    "text"
  ]) && Q(t.blockId) && Number.isSafeInteger(t.startOffset) && Number.isSafeInteger(t.endOffset) && t.startOffset >= 0 && t.endOffset >= t.startOffset && typeof t.text == "string";
}, Lc = (e) => {
  if (!re(e, [
    "operationIndex",
    "protocolVersion",
    "kind",
    "adapter",
    "target",
    "preconditions",
    "operation",
    "payload",
    "payloadFingerprint",
    "planFragment",
    "planFragmentFingerprint",
    "compiler",
    "resourceProfileFingerprint"
  ]) || e.protocolVersion !== 2 || e.kind !== "node.apply" || !Bo(e.adapter).valid || !Hr(e.target).valid || !jo(e.preconditions).valid || !Q(e.operation) || e.payloadFingerprint !== v(e.payload) || !ut(e.payloadFingerprint) || !_c(e.planFragment) || !ut(e.planFragmentFingerprint) || e.planFragmentFingerprint !== O("plan-fragment", e.planFragment) || !Vc(e.compiler) || !ut(e.resourceProfileFingerprint))
    return !1;
  const t = e.planFragment, n = e.preconditions, r = e.target, i = t.effect;
  return t.operation === e.operation && i.blockId === r.blockId && n.blockId === r.blockId;
}, qc = (e, t) => !se(e) || e.operationIndex !== t ? !1 : e.kind === "node.apply" ? Lc(e) : zc(e.precondition) ? e.kind === "text.replace" ? !re(e, [
  "operationIndex",
  "kind",
  "target",
  "precondition",
  "text"
]) || !se(e.target) || !re(e.target, ["blockId", "startOffset", "endOffset"]) || !Q(e.target.blockId) || !Number.isSafeInteger(e.target.startOffset) || !Number.isSafeInteger(e.target.endOffset) || e.target.startOffset < 0 || e.target.endOffset < e.target.startOffset ? !1 : typeof e.text == "string" : e.kind === "block.insert" ? re(e, [
  "operationIndex",
  "kind",
  "reference",
  "precondition",
  "block"
]) && se(e.reference) && re(e.reference, ["blockId", "side"]) && Q(e.reference.blockId) && (e.reference.side === "before" || e.reference.side === "after") && An(e.block) : e.kind === "block.replace" ? re(e, [
  "operationIndex",
  "kind",
  "target",
  "precondition",
  "block"
]) && se(e.target) && re(e.target, ["blockId"]) && Q(e.target.blockId) && An(e.block) : e.kind === "block.delete" && re(e, ["operationIndex", "kind", "target", "precondition"]) && se(e.target) && re(e.target, ["blockId"]) && Q(e.target.blockId) : !1, Yr = (e) => se(e) && re(e, [
  "protocolVersion",
  "offsetEncoding",
  "source",
  "steps"
]) && e.protocolVersion === 2 && e.offsetEncoding === "utf-16" && se(e.source) && re(e.source, [
  "snapshotFingerprint",
  "documentRevision",
  "descriptorFingerprint",
  "registryFingerprint"
]) && Q(e.source.snapshotFingerprint) && Q(e.source.documentRevision) && Q(e.source.descriptorFingerprint) && ut(e.source.registryFingerprint) && Array.isArray(e.steps) && e.steps.every(qc), Jc = (e, t, n) => {
  const r = t.steps.filter(
    (s) => s.kind === "node.apply"
  );
  if (r.length === 0) return;
  const i = qa(t), o = i == null ? void 0 : i.registry;
  if (!o || o.fingerprint !== t.source.registryFingerprint || o.descriptorFingerprint !== t.source.descriptorFingerprint || o.schemaFingerprint !== da.schemaKernelFingerprint)
    throw new TypeError("plan-invalid");
  r.forEach((s) => {
    var p;
    const a = up(o, {
      adapter: s.adapter,
      operation: s.operation
    });
    if (!a) throw new TypeError("plan-invalid");
    const c = Xr(
      e.body.content,
      s.target.blockId
    );
    let l = c;
    if (c && s.target.kind === "validated-path")
      for (const d of s.target.path)
        l = ((p = l == null ? void 0 : l.content) == null ? void 0 : p[d]) ?? null;
    const g = ea({
      runtimeResourceProfileFingerprint: n,
      registryFingerprint: o.fingerprint,
      adapter: a.entry.adapter,
      operation: a.operation
    });
    if (!(s.target.kind === "validated-path" ? a.entry.address.validatedPathFallback === !0 && a.operation.stream !== "incremental" && a.operation.collaboration === "exact-snapshot" : a.entry.address.stableLocalTypes.includes(
      s.target.localType
    )) || !l || s.payloadFingerprint !== v(s.payload) || s.target.kind === "stable-local" && a.entry.adapter.nodeType !== s.preconditions.nodeType || s.preconditions.addressFingerprint !== Wr(s.target) || s.preconditions.capabilityFingerprint !== Kn(a.entry, s.operation) || F(s.compiler) !== F(a.operation.compiler) || s.planFragment.nodeFamily !== a.entry.family || s.resourceProfileFingerprint !== g || new TextEncoder().encode(F(s.planFragment)).byteLength > a.operation.limits.maxOutputBytes)
      throw new TypeError("plan-invalid");
  });
}, Kc = (e, t, n) => {
  const r = Xo(t, n), i = r.blockId, o = e.get(i);
  if (!o || (n.kind === "node.apply" ? n.target.kind === "stable-local" ? n.preconditions.nodeType !== o.type || n.preconditions.contentFingerprint !== Ve(o.nodeJSON) || n.preconditions.shapeFingerprint !== wn(o.nodeJSON) : n.target.ancestorFingerprint !== O("node-ancestor", o.nodeJSON) : n.precondition.type !== o.type) || o.type !== r.type)
    throw new TypeError("plan-invalid");
  return o;
}, Xo = (e, t) => {
  const n = t.kind === "block.insert" ? t.reference.blockId : t.target.blockId, r = e.get(n);
  if (t.kind === "node.apply") {
    if (!r || t.preconditions.blockId !== n)
      throw new TypeError("plan-invalid");
    return r;
  }
  const i = t.precondition;
  if (!r || i.blockId !== n || i.type !== r.type || i.contentFingerprint !== r.contentFingerprint)
    throw new TypeError("plan-invalid");
  return r;
}, Uc = (e, t, n) => {
  if (!Yr(t) || t.source.documentRevision !== v(e))
    throw new TypeError("plan-invalid");
  Jc(
    e,
    t,
    n
  );
  const r = Mc(e);
  return t.steps.forEach((i) => Xo(r, i)), r;
}, Hc = (e, t, n, r, i) => {
  if (!Yr(n) || n.source.documentRevision !== v(t))
    throw new TypeError("plan-invalid");
  const o = Fo(e), s = [];
  return n.steps.forEach((a) => {
    const c = o.steps.length, l = Un(o.doc), g = Kc(l, i, a), f = a.kind === "text.replace" ? { ...a.target, text: a.text } : a.kind === "node.apply" && a.planFragment.effect.kind === "replace-text" ? a.planFragment.effect : null, p = a.kind === "block.replace" ? { node: a.block } : a.kind === "node.apply" && a.planFragment.effect.kind === "replace-block" ? a.planFragment.effect : null;
    if (f) {
      const { startOffset: d, endOffset: h, text: m } = f;
      if (h > g.text.length)
        throw new RangeError("operation-compile-failed");
      if (g.text.slice(d, h) === m) {
        s.push({
          operationIndex: a.operationIndex,
          stepStart: c,
          stepEnd: c,
          noOpReason: "already-equal"
        });
        return;
      }
      const b = Sn(g, d), k = Sn(g, h), w = Sc(o.doc, b, k, m);
      m.length === 0 ? o.delete(b, k) : o.replaceWith(
        b,
        k,
        o.doc.type.schema.text(m, w)
      );
    } else if (a.kind === "block.insert") {
      const d = o.doc.type.schema.nodeFromJSON(a.block);
      if (!d.isBlock || d.type === o.doc.type || F(d.toJSON()) !== F(a.block))
        throw new RangeError("operation-compile-failed");
      const h = typeof d.attrs.blockId == "string" ? d.attrs.blockId : null;
      if (!h || l.has(h))
        throw new RangeError("operation-compile-failed");
      const m = a.reference.side === "before" ? g.pos : g.pos + g.nodeSize;
      o.insert(m, d);
    } else if (p) {
      const d = p.node, h = o.doc.type.schema.nodeFromJSON(d);
      if (!h.isBlock || h.type === o.doc.type || F(h.toJSON()) !== F(d))
        throw new RangeError("operation-compile-failed");
      const m = typeof h.attrs.blockId == "string" ? h.attrs.blockId : null;
      if (!m || m !== g.blockId && l.has(m))
        throw new RangeError("operation-compile-failed");
      o.replaceWith(g.pos, g.pos + g.nodeSize, h);
    } else if (a.kind === "block.delete")
      o.delete(g.pos, g.pos + g.nodeSize);
    else
      throw new TypeError("plan-invalid");
    s.push({
      operationIndex: a.operationIndex,
      stepStart: c,
      stepEnd: o.steps.length
    });
  }), {
    transaction: Ro(o, r, s),
    operationSpans: u(s)
  };
};
class Vt extends RangeError {
  constructor(t, n) {
    super(`annotation-invalidated:${n}`), this.annotationId = t, this.reason = n, this.name = "RuntimeAnnotationInvalidatedV2Error";
  }
}
const Oi = (e, t) => {
  const r = [...Un(e).values()].filter(
    (i) => t >= i.pos && t <= i.pos + i.nodeSize
  ).sort((i, o) => i.nodeSize - o.nodeSize)[0];
  if (!r) return null;
  if (r.textSegments.length === 0)
    return { blockId: r.blockId, offset: 0 };
  if (t <= r.textSegments[0].from)
    return { blockId: r.blockId, offset: 0 };
  if (t >= r.textSegments.at(-1).to)
    return { blockId: r.blockId, offset: r.text.length };
  for (const i of r.textSegments)
    if (t >= i.from && t <= i.to)
      return {
        blockId: r.blockId,
        offset: i.startOffset + Math.min(
          t - i.from,
          i.endOffset - i.startOffset
        )
      };
  return null;
}, Wc = (e) => {
  const t = [...Un(e).values()].sort(
    (i, o) => i.pos - o.pos
  ), n = /* @__PURE__ */ new Map();
  let r = "";
  return t.forEach((i, o) => {
    n.set(i.blockId, r.length), r += i.text, o < t.length - 1 && (r += `
`);
  }), { value: r, starts: n, entries: t };
}, Ti = (e, t, n, r) => {
  const i = {
    original: e,
    mapped: t,
    assoc: n,
    deleted: r.deleted,
    deletedBefore: r.deletedBefore,
    deletedAfter: r.deletedAfter,
    deletedAcross: r.deletedAcross
  };
  return u({
    ...i,
    fingerprint: v(i)
  });
}, Xc = (e, t, n, r) => {
  const i = Un(t), o = i.get(e.anchor.start.blockId), s = i.get(e.anchor.end.blockId);
  if (!o || !s)
    throw new Vt(
      e.id,
      "unresolved-original-boundary"
    );
  const a = Sn(
    o,
    e.anchor.start.offset
  ), c = Sn(
    s,
    e.anchor.end.offset
  ), l = r.mapResult(a, 1), g = r.mapResult(c, -1), f = Oi(n, l.pos), p = Oi(n, g.pos);
  if (!f || !p)
    throw new Vt(
      e.id,
      "unresolved-mapped-boundary"
    );
  const d = Wc(n), h = d.starts.get(f.blockId), m = d.starts.get(p.blockId);
  if (h === void 0 || m === void 0)
    throw new Vt(
      e.id,
      "non-addressable-content"
    );
  const y = h + f.offset, b = m + p.offset;
  if (b <= y || b > d.value.length)
    throw new Vt(
      e.id,
      "collapsed-or-inverted-range"
    );
  const k = d.value.slice(y, b), w = d.value.slice(
    Math.max(0, y - 32),
    y
  ), I = d.value.slice(b, b + 32), x = Ti(
    e.anchor.start,
    f,
    1,
    l
  ), R = Ti(e.anchor.end, p, -1, g), A = {
    annotationId: e.id,
    status: "mapped",
    start: x,
    end: R,
    quote: k,
    beforeQuote: w,
    afterQuote: I
  };
  return {
    annotation: u({
      ...e,
      anchor: {
        start: f,
        end: p,
        quote: k,
        beforeQuote: w,
        afterQuote: I
      }
    }),
    evidence: u({
      ...A,
      fingerprint: v(A)
    })
  };
}, Gc = (e, t, n, r, i) => {
  const o = new Aa(), s = [], a = [], c = [];
  r.forEach((p, d) => {
    const h = o.maps.length;
    p.mapping.maps.forEach((m, y) => {
      const b = m.ranges, k = v({ ranges: b }), w = b.length / 3, I = Ye(b);
      i.debit(
        "mappingMaps",
        1,
        `$.mapping[${d}][${y}]`
      ), i.debit(
        "mappingRanges",
        w,
        `$.mapping[${d}][${y}].ranges`
      ), i.debit(
        "mappingBytes",
        I,
        `$.mapping[${d}][${y}].bytes`
      );
      const x = p.mapping.getMirror(y), R = x !== void 0 && x < y ? h + x : void 0;
      if (R !== void 0) {
        const A = [R, o.maps.length];
        i.debit(
          "mappingMirrors",
          1,
          `$.mapping[${d}][${y}].mirror`
        ), i.debit(
          "mappingMirrorBytes",
          Ye(A),
          `$.mapping[${d}][${y}].mirrorBytes`
        ), c.push(A);
      }
      o.appendMap(m, R), s.push(k), a.push(w);
    });
  });
  const l = e.annotations.map(
    (p) => Xc(p, t, n, o)
  ), g = u({
    ...e,
    body: { format: "json", content: n.toJSON() },
    annotations: l.map((p) => p.annotation)
  }), f = {
    policyRef: ma,
    mapOrder: s,
    mapRangeCounts: a,
    mirrorPairs: c,
    annotations: l.map((p) => p.evidence)
  };
  return u({
    resultDocument: g,
    projection: {
      ...f,
      fingerprint: v(f)
    }
  });
}, Zc = [
  "dateClock",
  "performanceClock",
  "random",
  "locale",
  "timezone",
  "io",
  "network",
  "storage",
  "dom",
  "timer"
], Ci = (e, t) => {
  let n = e;
  for (; n && !Object.prototype.hasOwnProperty.call(n, t); )
    n = Object.getPrototypeOf(n);
  return n;
}, Yc = (e, t) => {
  const n = {
    dateClock: 0,
    performanceClock: 0,
    random: 0,
    locale: 0,
    timezone: 0,
    io: 0,
    network: 0,
    storage: 0,
    dom: 0,
    timer: 0
  }, r = [], i = [], o = (l, g) => {
    throw n[l] += 1, new TypeError(`plugin-conformance-forbidden-capability:${g}`);
  }, s = (l, g, f, p) => {
    const d = Ci(l, g);
    if (!d) return;
    const h = Object.getOwnPropertyDescriptor(d, g);
    !h || !h.configurable && !h.writable || (Object.defineProperty(d, g, {
      configurable: h.configurable,
      enumerable: h.enumerable,
      writable: h.writable ?? !1,
      value: () => o(f, p)
    }), i.push(p), r.push(() => Object.defineProperty(d, g, h)));
  }, a = (l, g) => {
    const f = Object.getOwnPropertyDescriptor(globalThis, l);
    f && !f.configurable || (Object.defineProperty(globalThis, l, {
      configurable: !0,
      enumerable: (f == null ? void 0 : f.enumerable) ?? !1,
      get: () => o(g, l)
    }), i.push(l), r.push(() => {
      f ? Object.defineProperty(globalThis, l, f) : delete globalThis[l];
    }));
  }, c = (l, g, f, p, d) => {
    const h = Ci(l, g);
    if (!h) return;
    const m = Object.getOwnPropertyDescriptor(h, g);
    !m || !m.configurable && !m.writable || (Object.defineProperty(h, g, {
      configurable: m.configurable,
      enumerable: m.enumerable,
      writable: m.writable ?? !1,
      value(...y) {
        return n[f] += 1, d.apply(this, y);
      }
    }), i.push(p), r.push(() => Object.defineProperty(h, g, m)));
  };
  try {
    if (e.locale) {
      const f = e.locale, p = String.prototype.localeCompare;
      c(
        String.prototype,
        "localeCompare",
        "locale",
        `String.localeCompare[${f}]`,
        function(d, h, m) {
          return p.call(
            String(this),
            String(d),
            h ?? f,
            m
          );
        }
      );
    }
    if (e.timezoneOffsetMinutes !== void 0) {
      const f = e.timezoneOffsetMinutes;
      c(
        Date.prototype,
        "getTimezoneOffset",
        "timezone",
        `Date.getTimezoneOffset[${f}]`,
        () => f
      );
    }
    for (const f of e.traps)
      f === "dateClock" ? s(Date, "now", f, "Date.now") : f === "performanceClock" && typeof performance == "object" ? s(performance, "now", f, "performance.now") : f === "random" ? s(Math, "random", f, "Math.random") : f === "locale" ? (s(Intl, "DateTimeFormat", f, "Intl.DateTimeFormat"), s(
        String.prototype,
        "localeCompare",
        f,
        "String.localeCompare"
      )) : f === "timezone" ? s(
        Date.prototype,
        "getTimezoneOffset",
        f,
        "Date.getTimezoneOffset"
      ) : f === "network" ? (a("fetch", f), a("WebSocket", f)) : f === "storage" ? (a("localStorage", f), a("sessionStorage", f)) : f === "dom" ? a("document", f) : f === "timer" ? (a("setTimeout", f), a("setInterval", f)) : f === "io" && (a("XMLHttpRequest", f), a("FileReader", f));
    const l = t(), g = Zc.reduce(
      (f, p) => f + n[p],
      0
    );
    return {
      value: l,
      forbiddenTrapCounters: Object.freeze({ ...n }),
      forbiddenTrapCalls: g,
      guardedCapabilities: Object.freeze([...i].sort())
    };
  } finally {
    for (const l of r.reverse()) l();
  }
}, Qr = u([
  "baseline",
  "throwing-date-clock",
  "throwing-performance-clock",
  "locale-en",
  "locale-zh",
  "timezone-utc",
  "timezone-asia-shanghai",
  "poisoned-random",
  "io-network-storage-dom-timer-traps"
]), Qc = u({
  publicReceiptType: "ResolvedRuntimeReceiptV2",
  requiredFields: [
    "conformanceReceiptRefs",
    "conformanceEnvironmentReceiptRefs",
    "environment",
    "adapterExecutionIdentity",
    "matrixRowFingerprint"
  ]
}), Je = (e) => {
  const t = ["root"], n = e.plugins.map(() => 0), r = /* @__PURE__ */ new Set();
  let i = 0, o = "fixed-point", s = !1;
  for (; ; ) {
    let c = !1;
    for (const [l, g] of e.plugins.entries()) {
      if (n[l] >= t.length) continue;
      const f = t.slice(n[l]), p = v({
        plugin: g.id,
        visible: f,
        transactions: t,
        seen: n
      });
      if (r.has(p)) {
        o = "cycle-detected", s = !0;
        break;
      }
      r.add(p), i += 1, n[l] = t.length;
      const d = g.append(f, t);
      if (d) {
        if (t.includes(d)) {
          o = "cycle-detected", s = !0;
          break;
        }
        if (e.filter && !e.filter(d)) {
          o = "filter-rejected", s = !0;
          break;
        }
        if (t.length >= (e.maxTransactions ?? 16)) {
          o = "budget-exceeded", s = !0;
          break;
        }
        t.push(d), n[l] = t.length, c = !0;
      }
    }
    if (s || !c && n.every((l) => l === t.length)) break;
  }
  const a = {
    fixture: e.id,
    status: o,
    transactions: t,
    hookCalls: i
  };
  return u({
    ...a,
    outcomeFingerprint: v(a)
  });
}, Cr = u([
  Je({ id: "no-op", plugins: [] }),
  Je({
    id: "single-append",
    plugins: [
      {
        id: "a",
        append: (e) => e.includes("root") ? "a1" : null
      }
    ]
  }),
  Je({
    id: "multi-plugin-chain",
    plugins: [
      {
        id: "a",
        append: (e) => e.includes("root") ? "a1" : null
      },
      {
        id: "b",
        append: (e) => e.includes("a1") ? "b1" : null
      }
    ]
  }),
  Je({
    id: "same-plugin-repeat",
    plugins: [
      {
        id: "repeat-a",
        append: (e, t) => (e.includes("root") || e.some((n) => n.startsWith("pulse-"))) && t.filter((n) => n.startsWith("repeat-")).length < 3 ? `repeat-${t.length}` : null
      },
      {
        id: "pulse-b",
        append: (e, t) => e.some((n) => n.startsWith("repeat-")) && t.filter((n) => n.startsWith("pulse-")).length < 2 ? `pulse-${t.length}` : null
      }
    ]
  }),
  Je({
    id: "filter-reject",
    plugins: [{ id: "reject", append: () => "rejected" }],
    filter: () => !1
  }),
  Je({
    id: "cycle-a-b-a",
    plugins: [
      {
        id: "cycle-a",
        append: (e) => e.includes("root") || e.includes("b") ? "a" : null
      },
      {
        id: "cycle-b",
        append: (e) => e.includes("a") ? "b" : null
      }
    ],
    maxTransactions: 8
  }),
  Je({
    id: "monotonic-runaway",
    plugins: [
      {
        id: "runaway-a",
        append: (e, t) => e.includes("root") || e.some((n) => n.startsWith("b")) ? `a${t.length}` : null
      },
      {
        id: "runaway-b",
        append: (e, t) => e.some((n) => n.startsWith("a")) ? `b${t.length}` : null
      }
    ],
    maxTransactions: 4
  }),
  Je({
    id: "fixed-point",
    plugins: [
      {
        id: "fixed",
        append: (e, t) => t.length === 1 ? "fixed" : null
      }
    ]
  })
]), xt = (e, t, n) => {
  const r = {
    doc: e,
    selection: Sa.atStart(e),
    storedMarks: null
  };
  return t && (r[t] = n), r;
}, Pi = (e) => (e == null ? void 0 : e.steps.map((t) => t.toJSON())) ?? [], el = (e) => {
  var le, ee, qe, Te;
  const t = Io(), n = t.node("doc", null, [
    t.node("paragraph", { textAlign: null, blockId: "p_conformance" }, [
      t.text("a")
    ])
  ]), r = xt(n), i = e.plugin.spec.state;
  if (!i) throw new TypeError("plugin-conformance-missing");
  const o = e.plugin.key, s = i.init({ schema: t }, r), a = xt(n, o, s), c = Fo(a).insertText("x", 2);
  Ro(c, "runtime-plugin-conformance-v2", [
    { operationIndex: 0, stepStart: 0, stepEnd: 1 }
  ]);
  const l = xt(
    c.doc,
    o,
    s
  ), g = ((ee = (le = e.plugin.spec).filterTransaction) == null ? void 0 : ee.call(le, c, a)) ?? !0, f = e.projectAfterApply(a, c), p = i.apply(
    c,
    s,
    a,
    l
  ), d = xt(c.doc, o, p), h = ((Te = (qe = e.plugin.spec).appendTransaction) == null ? void 0 : Te.call(
    qe,
    [c],
    a,
    d
  )) ?? null;
  let m = p, y = d, b = null;
  if (h) {
    ko(h, {
      executionId: "runtime-plugin-conformance-v2",
      sequence: 1,
      pluginInstanceId: e.instanceId,
      pluginOrder: e.order,
      visibleTransactionRange: [0, 0],
      operationIndexes: [0]
    }), b = e.projectAfterApply(d, h);
    const tr = xt(
      h.doc,
      o,
      p
    );
    m = i.apply(
      h,
      p,
      d,
      tr
    ), y = xt(
      h.doc,
      o,
      m
    );
  }
  const k = e.project(y), w = e.effect(h ?? c), I = {
    rootFilterAccepted: g,
    appendReturned: h !== null
  }, x = {
    root: Pi(c),
    appended: Pi(h)
  }, R = {
    root: c.getMeta(hn) ?? null,
    appended: (h == null ? void 0 : h.getMeta(vo)) ?? null
  }, A = {
    initialized: s,
    afterRoot: p,
    afterAppend: m,
    projected: k,
    anticipatedRoot: f,
    anticipatedAppend: b
  }, X = [
    { phase: "state-init", fingerprint: v(s) },
    {
      phase: "filter-root",
      fingerprint: v(g)
    },
    { phase: "state-apply-root", fingerprint: v(p) },
    {
      phase: "append-return",
      fingerprint: v(h !== null)
    },
    {
      phase: "state-apply-appended",
      fingerprint: v(m)
    },
    { phase: "project", fingerprint: v(k) },
    { phase: "effect", fingerprint: v(w) }
  ], _ = {
    pluginInstanceId: e.instanceId,
    pluginOrder: e.order,
    returnProjection: I,
    stepsProjection: x,
    metaProjection: R,
    stateProjection: A,
    effectProjection: w,
    traceProjection: X,
    returnFingerprint: v(I),
    stepsFingerprint: v(x),
    metaFingerprint: v(R),
    stateProjectionFingerprint: v(A),
    traceFingerprint: v(X)
  };
  return u({
    ..._,
    outcomeFingerprint: v(_)
  });
}, Ce = u({
  kind: "environment-harness",
  id: "zx.text-editor.runtime-conformance.environment-harness",
  version: "2.0.0",
  implementationSourceFingerprint: ha
}), Go = u([
  {
    environment: "baseline",
    adapterRef: Ce,
    configuration: { ambient: "baseline" },
    traps: []
  },
  {
    environment: "throwing-date-clock",
    adapterRef: Ce,
    configuration: { dateClock: "throw-on-read" },
    traps: ["dateClock"]
  },
  {
    environment: "throwing-performance-clock",
    adapterRef: Ce,
    configuration: { performanceClock: "throw-on-read" },
    traps: ["performanceClock"]
  },
  {
    environment: "locale-en",
    adapterRef: Ce,
    configuration: { locale: "en", localeAccess: "configured-default" },
    traps: [],
    locale: "en"
  },
  {
    environment: "locale-zh",
    adapterRef: Ce,
    configuration: { locale: "zh", localeAccess: "configured-default" },
    traps: [],
    locale: "zh"
  },
  {
    environment: "timezone-utc",
    adapterRef: Ce,
    configuration: { timezone: "UTC", offsetMinutes: 0 },
    traps: [],
    timezoneOffsetMinutes: 0
  },
  {
    environment: "timezone-asia-shanghai",
    adapterRef: Ce,
    configuration: {
      timezone: "Asia/Shanghai",
      offsetMinutes: -480
    },
    traps: [],
    timezoneOffsetMinutes: -480
  },
  {
    environment: "poisoned-random",
    adapterRef: Ce,
    configuration: { random: "throw-on-read" },
    traps: ["random"]
  },
  {
    environment: "io-network-storage-dom-timer-traps",
    adapterRef: Ce,
    configuration: { ambientCapabilities: "throw-on-read" },
    traps: ["io", "network", "storage", "dom", "timer"]
  }
]);
if (F(
  Go.map((e) => e.environment)
) !== F(Qr))
  throw new TypeError("plugin-conformance-environment-registry-drift");
const Zo = () => {
  const e = Go.map((r) => {
    const i = v({
      adapterRef: r.adapterRef,
      configuration: r.configuration,
      traps: r.traps
    }), o = Yc(
      {
        traps: r.traps,
        ...r.locale ? { locale: r.locale } : {},
        ...r.timezoneOffsetMinutes !== void 0 ? { timezoneOffsetMinutes: r.timezoneOffsetMinutes } : {}
      },
      () => $e.map(el)
    ), s = v({
      adapterRef: r.adapterRef,
      environmentConfigurationFingerprint: i,
      guardedCapabilities: o.guardedCapabilities,
      forbiddenTrapCounters: o.forbiddenTrapCounters,
      pluginOutcomeFingerprints: o.value.map(
        (c) => c.outcomeFingerprint
      )
    }), a = {
      environment: r.environment,
      adapterRef: r.adapterRef,
      environmentConfigurationFingerprint: i,
      adapterExecutionIdentity: s,
      guardedCapabilities: o.guardedCapabilities,
      pluginOutcomes: o.value,
      forbiddenTrapCounters: o.forbiddenTrapCounters,
      forbiddenTrapCalls: o.forbiddenTrapCalls
    };
    return u({
      ...a,
      outcomeFingerprint: v(a)
    });
  }), t = e.reduce(
    (r, i) => r + i.forbiddenTrapCalls,
    0
  ), n = {
    environmentOutcomes: e,
    fixtureOutcomes: Cr,
    forbiddenTrapCalls: t
  };
  return u({
    ...n,
    outcomeFingerprint: v(n)
  });
}, Yo = Zo(), Qo = (e) => {
  const t = e.environmentOutcomes[0];
  if (e.forbiddenTrapCalls !== 0 || e.environmentOutcomes.length !== Qr.length || !t || e.fixtureOutcomes.length !== Cr.length || F(e.fixtureOutcomes) !== F(Cr) || e.environmentOutcomes.some(
    (n) => n.pluginOutcomes.length !== $e.length || n.forbiddenTrapCalls !== 0 || Object.values(n.forbiddenTrapCounters).some((r) => r !== 0) || n.pluginOutcomes.some(
      (r, i) => r.outcomeFingerprint !== t.pluginOutcomes[i].outcomeFingerprint
    )
  ))
    throw new TypeError("plugin-conformance-missing");
};
Qo(Yo);
const es = (e, t) => {
  const n = t.environmentOutcomes.map((i) => ({
    environment: i.environment,
    adapterRef: i.adapterRef,
    environmentConfigurationFingerprint: i.environmentConfigurationFingerprint,
    adapterExecutionIdentity: i.adapterExecutionIdentity,
    guardedCapabilities: i.guardedCapabilities,
    observedOutcome: i.pluginOutcomes[e.order],
    forbiddenTrapCounters: i.forbiddenTrapCounters,
    forbiddenTrapCalls: i.forbiddenTrapCalls,
    matrixRowFingerprint: i.outcomeFingerprint
  })), r = {
    receiptRef: e.conformanceReceiptRef,
    pluginInstanceId: e.instanceId,
    pluginOrder: e.order,
    componentFingerprint: e.componentRef.fingerprint,
    componentRefs: e.componentRefs,
    adapterFingerprint: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
    fixtureCorpusFingerprint: v({
      fixtures: t.fixtureOutcomes
    }),
    fixtureOutcomes: t.fixtureOutcomes,
    declarationContractFingerprint: v(
      Qc
    ),
    forbiddenTrapCalls: t.forbiddenTrapCalls,
    environments: Qr,
    environmentOutcomes: n,
    verificationAlgorithm: "recompute-independent-environment-matrix-rows-v3",
    status: "certified"
  };
  return u({
    ...r,
    outcomeFingerprint: v(r)
  });
}, tl = u(
  $e.map(
    (e) => es(e, Yo)
  )
), nl = (e, t) => e.kind === t.kind && e.id === t.id && e.version === t.version && e.fingerprint === t.fingerprint, rl = (e = tl) => {
  if (e.length !== $e.length)
    throw new TypeError("plugin-conformance-missing");
  const t = Zo();
  Qo(t);
  for (const [n, r] of $e.entries()) {
    const i = e[n], o = es(r, t), s = Object.values(r.componentRefs), a = r.componentRef.dependencies;
    if (F(i) !== F(o) || i.status !== "certified" || i.forbiddenTrapCalls !== 0 || i.environmentOutcomes.length !== t.environmentOutcomes.length || i.environmentOutcomes.some(
      (c) => c.forbiddenTrapCalls !== 0 || Object.values(c.forbiddenTrapCounters).some((l) => l !== 0)
    ) || i.pluginOrder !== n || s.some(
      (c) => !a.some(
        (l) => nl(l, c)
      )
    ))
      throw new TypeError("plugin-conformance-missing");
  }
  return e;
};
u({
  synchronousHookInterruption: "not-supported-in-same-isolate",
  permittedMitigation: "package-owned-certified-code-only",
  hostTerminationOutcome: "safety-watchdog-abort",
  replayableSuccessAllowed: !1
});
const il = [
  "kind",
  "version",
  "schemaSemantics",
  "operationProtocol",
  "executionClosure",
  "mappingPolicy",
  "transactionPolicy",
  "resourceProfile",
  "derivedViewProfiles",
  "fingerprints"
], ol = [
  "kind",
  "id",
  "version",
  "fingerprint",
  "dependencies"
], En = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), On = (e, t) => {
  const n = Object.keys(e).sort(), r = [...t].sort();
  return n.length === r.length && n.every((i, o) => i === r[o]);
}, ie = (e, t, n) => u({
  code: e,
  stage: "manifest",
  path: t,
  ...n ? { componentId: n } : {}
}), be = (e) => `${e.kind}:${e.id}`, Di = (e) => En(e) && On(e, ol) && typeof e.kind == "string" && typeof e.id == "string" && typeof e.version == "string" && typeof e.fingerprint == "string" && Array.isArray(e.dependencies) && e.dependencies.every(
  (t) => En(t) && On(t, ["kind", "id", "version", "fingerprint"]) && typeof t.kind == "string" && typeof t.id == "string" && typeof t.version == "string" && typeof t.fingerprint == "string"
), sl = (e) => {
  const t = [
    e.schemaSemantics,
    e.operationProtocol,
    e.executionClosure,
    e.mappingPolicy,
    e.transactionPolicy,
    e.resourceProfile
  ], n = v({
    domain: "zx-runtime-execution-semantics:v2",
    components: t
  }), r = v({
    domain: "zx-runtime-observational-profile:v2",
    components: [
      Ur,
      vn
    ]
  }), i = v({
    domain: "zx-runtime-derived-view-profile:v2",
    components: e.derivedViewProfiles
  }), o = {
    kind: e.kind,
    version: e.version,
    schemaSemantics: e.schemaSemantics,
    operationProtocol: e.operationProtocol,
    executionClosure: e.executionClosure,
    mappingPolicy: e.mappingPolicy,
    transactionPolicy: e.transactionPolicy,
    resourceProfile: e.resourceProfile,
    derivedViewProfiles: e.derivedViewProfiles,
    fingerprints: {
      executionSemanticsFingerprint: n,
      observationalProfileFingerprint: r,
      derivedViewFingerprint: i
    }
  };
  return u({
    ...o.fingerprints,
    runtimeManifestFingerprint: v({
      domain: "zx-runtime-manifest:v2",
      manifest: o
    })
  });
}, al = (e) => {
  try {
    F(e);
  } catch {
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie("runtime-manifest-invalid", "$")
    };
  }
  if (!En(e) || !On(e, il))
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie("runtime-manifest-invalid", "$")
    };
  if (e.kind !== "zx-text-editor-runtime-manifest-v2" || e.version !== "2.0.0")
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie("runtime-component-unsupported", "$.version")
    };
  const t = [
    e.schemaSemantics,
    e.operationProtocol,
    e.executionClosure,
    e.mappingPolicy,
    e.transactionPolicy,
    e.resourceProfile
  ];
  if (!t.every(Di) || !Array.isArray(e.derivedViewProfiles) || !e.derivedViewProfiles.every(Di))
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie("runtime-manifest-invalid", "$.components")
    };
  if (!En(e.fingerprints) || !On(e.fingerprints, [
    "runtimeManifestFingerprint",
    "executionSemanticsFingerprint",
    "observationalProfileFingerprint",
    "derivedViewFingerprint"
  ]))
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie("runtime-manifest-invalid", "$.fingerprints")
    };
  const n = [
    ...t,
    ...e.derivedViewProfiles
  ], r = [
    de.schemaSemantics,
    de.operationProtocol,
    de.executionClosure,
    de.mappingPolicy,
    de.transactionPolicy,
    de.resourceProfile
  ], i = t.find(
    (p, d) => be(p) !== be(r[d])
  );
  if (i)
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie(
        "runtime-component-unsupported",
        "$.components",
        i.id
      )
    };
  const o = n.find(
    (p, d) => n.findIndex((h) => be(h) === be(p)) !== d
  );
  if (o)
    return {
      valid: !1,
      manifest: null,
      diagnostic: ie(
        "runtime-manifest-invalid",
        "$.components",
        o.id
      )
    };
  const s = new Map(
    Ar.map((p) => [be(p), p])
  );
  n.forEach((p) => s.set(be(p), p));
  const a = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = (p) => {
    const d = be(p);
    if (a.has(d))
      return ie("runtime-manifest-invalid", "$.dependencies", p.id);
    if (c.has(d)) return null;
    a.add(d);
    const h = Ar.find(
      (m) => be(m) === d && m.version === p.version
    );
    if (!h)
      return ie(
        "runtime-component-unsupported",
        "$.components",
        p.id
      );
    if (h && h.fingerprint !== p.fingerprint)
      return ie(
        "runtime-fingerprint-mismatch",
        "$.components",
        p.id
      );
    if (h) {
      const m = p.dependencies.map(be), y = h.dependencies.map(be);
      if (m.length !== y.length || m.some(
        (b, k) => b !== y[k]
      ))
        return ie(
          "runtime-manifest-invalid",
          "$.dependencies.order",
          p.id
        );
    }
    for (const m of p.dependencies) {
      const y = s.get(be(m));
      if (!y)
        return ie(
          "runtime-component-unsupported",
          "$.dependencies",
          m.id
        );
      if (y.version !== m.version || y.fingerprint !== m.fingerprint)
        return ie(
          "runtime-fingerprint-mismatch",
          "$.dependencies",
          m.id
        );
      const b = l(y);
      if (b) return b;
    }
    return a.delete(d), c.add(d), null;
  };
  for (const p of n) {
    const d = l(p);
    if (d) return { valid: !1, manifest: null, diagnostic: d };
  }
  const g = e, f = sl(g);
  for (const p of Object.keys(f))
    if (g.fingerprints[p] !== f[p])
      return {
        valid: !1,
        manifest: null,
        diagnostic: ie(
          "runtime-fingerprint-mismatch",
          `$.fingerprints.${p}`
        )
      };
  return { valid: !0, manifest: u(g), diagnostic: null };
}, cl = (e) => {
  const t = al(
    de
  );
  return t.valid ? e.kind !== Ee.kind || e.version !== Ee.version || e.fingerprint !== Ee.fingerprint ? {
    status: "failure",
    diagnostic: ie("runtime-fingerprint-mismatch", "$.runtime")
  } : { status: "resolved", manifest: t.manifest } : { status: "failure", diagnostic: t.diagnostic };
}, Qe = u({
  implementationId: "zx.text-editor.runtime-observational.audit-label",
  directRuntimeImports: [
    "core/canonical-json",
    "core/execution-abi/fingerprint"
  ],
  semanticComponentDependencies: [],
  reachableAuthorities: ["observations"],
  unreachableAuthorities: [
    "document",
    "selection",
    "stored-marks",
    "semantic-plugin-state",
    "effects",
    "annotations",
    "lifecycle"
  ]
}), ll = (e) => {
  const t = u({
    componentId: Qe.implementationId,
    fingerprint: v({
      implementationId: Qe.implementationId,
      authority: e.authority,
      reachability: Qe
    })
  });
  return u({
    semantic: e.semantic,
    observations: [...e.observations, t]
  });
}, dl = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = e;
  if (Object.keys(t).sort().join("|") !== [
    "baseFingerprint",
    "derivedViewFingerprint",
    "executionSemanticsFingerprint",
    "manifestRef",
    "observationalProfileFingerprint"
  ].sort().join("|"))
    return !1;
  const r = t.manifestRef;
  return !!(r && typeof r == "object" && !Array.isArray(r) && Object.keys(r).sort().join("|") === ["fingerprint", "kind", "version"].join("|") && typeof t.baseFingerprint == "string" && typeof t.executionSemanticsFingerprint == "string" && typeof t.observationalProfileFingerprint == "string" && typeof t.derivedViewFingerprint == "string");
}, dr = (e) => e.map((t, n) => ({
  order: n,
  component: {
    kind: t.kind,
    id: t.id,
    version: t.version,
    fingerprint: t.fingerprint
  }
})), pl = (e) => e.externalExtensions.filter((t) => t.runtimeType !== "collaboration-transport").map((t) => {
  const n = u({
    classification: "external-host-extension",
    executionSemantic: "unknown",
    observational: "unknown",
    derivedView: "unknown",
    supported: !1,
    runtimeType: t.runtimeType
  }), r = t.order;
  return u({
    kind: "execution-closure",
    id: `external-host-extension-unknown:${r}`,
    version: "unsupported",
    fingerprint: v({ order: r, classification: n }),
    dependencies: []
  });
}), fl = (e) => {
  const t = pl(e), n = Ar.filter(
    (l) => l.kind !== "derived-view-profile" && l !== vn
  ), r = [
    Ur,
    vn
  ], i = de.derivedViewProfiles, o = t.length ? v({
    base: de.fingerprints.executionSemanticsFingerprint,
    external: t,
    reachability: "unknown"
  }) : de.fingerprints.executionSemanticsFingerprint, s = t.length ? v({
    base: de.fingerprints.observationalProfileFingerprint,
    external: t,
    reachability: "unknown"
  }) : de.fingerprints.observationalProfileFingerprint, a = t.length ? v({
    base: de.fingerprints.derivedViewFingerprint,
    external: t,
    reachability: "unknown"
  }) : de.fingerprints.derivedViewFingerprint, c = {
    manifestRef: Ee,
    executionSemanticsFingerprint: o,
    observationalProfileFingerprint: s,
    derivedViewFingerprint: a,
    hostComposition: {
      bindingState: e.bindingState,
      activeEditorCount: e.activeEditorCount,
      bindingProofFingerprints: e.bindings.map(
        (l) => l.bindingFingerprint
      ),
      bindings: e.bindings.map((l) => ({
        bindingFingerprint: l.bindingFingerprint,
        assemblyComponentId: l.assemblyIntegrity.assemblyComponentId,
        assemblySourceFingerprint: l.assemblyIntegrity.assemblySourceFingerprint,
        authoritySourceFingerprint: l.assemblyIntegrity.authoritySourceFingerprint,
        registrySourceFingerprint: l.assemblyIntegrity.registrySourceFingerprint,
        stateSourceFingerprint: l.assemblyIntegrity.stateSourceFingerprint,
        externalExtensionsFingerprint: l.externalExtensionsFingerprint
      })),
      fingerprint: e.fingerprint
    },
    proofs: {
      execution: dr([...n, ...t]),
      observational: dr([...r, ...t]),
      derivedView: dr([...i, ...t])
    }
  };
  return u({
    ...c,
    descriptorFingerprint: v(c)
  });
}, ts = Qe.unreachableAuthorities, ns = u(
  ts.map((e, t) => ({
    authority: e,
    semantic: {
      authority: e,
      order: t,
      value: { fingerprint: v({ authority: e, order: t }) }
    },
    observations: []
  }))
), rs = () => u(
  ns.map((e) => {
    const t = ll(e), n = v(e.semantic), r = v(t.semantic);
    return {
      authority: e.authority,
      beforeSemanticFingerprint: n,
      afterSemanticFingerprint: r,
      semanticUnchanged: n === r,
      observationCountBefore: e.observations.length,
      observationCountAfter: t.observations.length,
      observationFingerprint: v(t.observations)
    };
  })
), Bi = rs(), Pr = {
  fingerprint: v({
    domain: "zx-runtime-observational-profile:v2",
    components: [Ur]
  }),
  receiptRef: "runtime-observational-audit-label-non-interference-receipt-1",
  componentRef: vn,
  implementationSourceFingerprint: So,
  sourceReachabilityClosure: Qe,
  sourceReachabilityClosureFingerprint: v(
    Qe
  ),
  fixtureCorpusFingerprint: v(
    ns
  ),
  observedResults: Bi,
  observedOutcomeFingerprint: v(
    Bi
  ),
  forbiddenTrapCalls: 0,
  verificationAlgorithm: "execute-identity-reachability-fixtures-v2",
  unreachable: [
    "document",
    "selection",
    "stored-marks",
    "semantic-plugin-state",
    "effects",
    "annotations",
    "lifecycle"
  ]
}, De = u({
  ...Pr,
  outcomeFingerprint: v(Pr)
}), ul = () => (() => {
  const e = rs();
  return De.outcomeFingerprint === v(Pr) && De.implementationSourceFingerprint === So && De.componentRef.dependencies.length === 0 && De.sourceReachabilityClosureFingerprint === v(Qe) && Qe.semanticComponentDependencies.length === 0 && F(De.unreachable) === F(ts) && F(
    De.observedResults
  ) === F(e) && De.observedOutcomeFingerprint === v(e) && e.every(
    (t) => t.semanticUnchanged && t.observationCountAfter === t.observationCountBefore + 1
  );
})(), gl = (e, t) => e.derivedViewFingerprint === t.derivedViewFingerprint ? { status: "exact" } : {
  status: "regenerate-view",
  profileFingerprint: t.derivedViewFingerprint
}, ml = (e) => is(
  e,
  Ca()
), is = (e, t) => {
  if (!dl(e))
    return u({
      status: "unsupported-host",
      current: null,
      reasons: [
        {
          code: "runtime-component-unsupported",
          stage: "host-admission",
          path: "$.expected"
        }
      ]
    });
  const n = fl(t);
  if (t.bindings.some(
    (i) => i.assemblyIntegrity.assemblyComponentId !== "zx.text-editor.editor-runtime-assembly" || i.assemblyIntegrity.assemblySourceFingerprint !== ya || i.assemblyIntegrity.authoritySourceFingerprint !== ba || i.assemblyIntegrity.registrySourceFingerprint !== xa || i.assemblyIntegrity.stateSourceFingerprint !== Ia
  ))
    return u({
      status: "unsupported-host",
      current: n,
      reasons: [
        {
          code: "runtime-component-unsupported",
          stage: "host-admission",
          path: "$.host.composition.bindings[0].assemblyIntegrity"
        }
      ]
    });
  if (t.externalExtensions.some(
    (i) => i.runtimeType !== "collaboration-transport"
  ))
    return u({
      status: "unsupported-host",
      current: n,
      reasons: [
        {
          code: "runtime-component-unsupported",
          stage: "host-admission",
          path: "$.host.composition.externalExtensions[0]"
        }
      ]
    });
  if (e.manifestRef.kind !== Ee.kind || e.manifestRef.version !== Ee.version || e.manifestRef.fingerprint !== Ee.fingerprint)
    return u({
      status: "unsupported-host",
      current: n,
      reasons: [
        {
          code: "runtime-component-unsupported",
          stage: "host-admission",
          path: "$.expected.manifestRef"
        }
      ]
    });
  if (e.executionSemanticsFingerprint !== n.executionSemanticsFingerprint)
    return u({
      status: "regenerate-current-runtime",
      current: n,
      orderedDriftPaths: ["$.executionSemanticsFingerprint"]
    });
  const r = gl(e, n);
  return e.observationalProfileFingerprint === n.observationalProfileFingerprint ? u({
    status: "exact-admissible",
    current: n,
    checkedBaseFingerprint: e.baseFingerprint,
    derivedView: r
  }) : e.observationalProfileFingerprint === De.fingerprint && ul() ? u({
    status: "admissible-observational-drift",
    current: n,
    checkedBaseFingerprint: e.baseFingerprint,
    driftProofRefs: [De.receiptRef],
    derivedView: r
  }) : u({
    status: "regenerate-current-runtime",
    current: n,
    orderedDriftPaths: ["$.observationalProfileFingerprint"]
  });
}, hl = (e, t, n) => {
  var c;
  const r = n && typeof n == "object" ? bi(n) : bi({}), i = is(
    e,
    r
  ), o = "current" in i ? (c = i.current) == null ? void 0 : c.hostComposition : null, a = {
    status: (o == null ? void 0 : o.bindingState) === "active-editor-bound" && o.activeEditorCount > 0 && t === e.baseFingerprint && (i.status === "exact-admissible" || i.status === "admissible-observational-drift") ? "admissible" : "not-admissible",
    baseFingerprint: t,
    descriptorFingerprint: "current" in i && i.current ? i.current.descriptorFingerprint : null,
    targetBindingFingerprint: (o == null ? void 0 : o.bindingProofFingerprints[0]) ?? null,
    targetCompositionFingerprint: r.fingerprint,
    admission: i
  };
  return u({
    ...a,
    fingerprint: v(a)
  });
}, ei = (e, t, n, r, i, o, s, a) => {
  const c = a.map(({ id: g, version: f, fingerprint: p }) => ({
    id: g,
    version: f,
    fingerprint: p
  })), l = {
    id: `npm:${e}`,
    version: n,
    packageName: e,
    runtimeSpecifier: t,
    resolvedVersion: n,
    lockIntegrity: r,
    apiContractFingerprint: o,
    implementationFingerprint: s,
    admittedSemverRanges: i,
    dependencies: c
  };
  return u({
    ...l,
    fingerprint: v(l)
  });
}, ti = ei(
  "prosemirror-model",
  "prosemirror-model",
  "1.25.10",
  "sha512-9n6rH4DbJU1eH4SxLt6Y0HhJIo6cZsb7DJ/30uob1hOKPeO6TAaMWI2tc7kwR92BjfPOU2fFHWbZLovLi3XQfA==",
  ["1.25.10"],
  "sha256:b11a34cfd6b9d74ce796ea9ffe402a981a0e68845ea2da0d86b3ca65777dd2a7",
  "sha256:9352d83c23c632cf27584d4809559ba9386e9aafd57492daea76641ce571359d",
  []
), os = ei(
  "prosemirror-transform",
  "prosemirror-transform",
  "1.12.0",
  "sha512-GxboyN4AMIsoHNtz5uf2r2Ru551i5hWeCMD6E2Ib4Eogqoub0NflniaBPVQ4MrGE5yZ8JV9tUHg9qcZTTrcN4w==",
  ["1.12.0"],
  "sha256:304e41926d3299c9b30bfd418c35fffd2bd9e5ac726d6f758fb4e0f40a738d51",
  "sha256:10ceb714f60b0748d74779189b28db2208b8f375dedf82aee0751fd4873a8154",
  [ti]
), yl = ei(
  "prosemirror-state",
  "prosemirror-state",
  "1.4.4",
  "sha512-6jiYHH2CIGbCfnxdHbXZ12gySFY/fz/ulZE333G6bPqIZ4F+TXo9ifiR86nAHpWnfoNjOb3o5ESi7J8Uz1jXHw==",
  ["1.4.4"],
  "sha256:02ab5dbcaa58da1d58c46c7cdfa7f94792c5ccf0fc7c0622ef33755fe415366c",
  "sha256:d1803a8d1be1259b301409de7d4638e9036fa3a387e8614c28fc95d457ae182b",
  [ti, os]
), bl = "sha256:b88c9e76ee46c0ef1c413ad85e0d773f82825b48cb3b3cf6a6f19971b6b03f17", xl = "sha256:8608b47fb876f9a3bb921c8aa57d0ec38aae7a980d14ebe64db5f78e986afc3f";
function te(e) {
  this.content = e;
}
te.prototype = {
  constructor: te,
  find: function(e) {
    for (var t = 0; t < this.content.length; t += 2)
      if (this.content[t] === e) return t;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(e) {
    var t = this.find(e);
    return t == -1 ? void 0 : this.content[t + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(e, t, n) {
    var r = n && n != e ? this.remove(n) : this, i = r.find(e), o = r.content.slice();
    return i == -1 ? o.push(n || e, t) : (o[i + 1] = t, n && (o[i] = n)), new te(o);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(e) {
    var t = this.find(e);
    if (t == -1) return this;
    var n = this.content.slice();
    return n.splice(t, 2), new te(n);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(e, t) {
    return new te([e, t].concat(this.remove(e).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(e, t) {
    var n = this.remove(e).content.slice();
    return n.push(e, t), new te(n);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(e, t, n) {
    var r = this.remove(t), i = r.content.slice(), o = r.find(e);
    return i.splice(o == -1 ? i.length : o, 0, t, n), new te(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(e) {
    for (var t = 0; t < this.content.length; t += 2)
      e(this.content[t], this.content[t + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(e) {
    return e = te.from(e), e.size ? new te(e.content.concat(this.subtract(e).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(e) {
    return e = te.from(e), e.size ? new te(this.subtract(e).content.concat(e.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(e) {
    var t = this;
    e = te.from(e);
    for (var n = 0; n < e.content.length; n += 2)
      t = t.remove(e.content[n]);
    return t;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var e = {};
    return this.forEach(function(t, n) {
      e[t] = n;
    }), e;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
te.from = function(e) {
  if (e instanceof te) return e;
  var t = [];
  if (e) for (var n in e) t.push(n, e[n]);
  return new te(t);
};
function ss(e, t, n) {
  for (let r = 0; ; r++) {
    if (r == e.childCount || r == t.childCount)
      return e.childCount == t.childCount ? null : n;
    let i = e.child(r), o = t.child(r);
    if (i == o) {
      n += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(o))
      return n;
    if (i.isText && i.text != o.text) {
      let s = i.text, a = o.text, c = 0;
      for (; s[c] == a[c]; c++)
        n++;
      return c && c < s.length && c < a.length && ls(s.charCodeAt(c - 1)) && cs(s.charCodeAt(c)) && n--, n;
    }
    if (i.content.size || o.content.size) {
      let s = ss(i.content, o.content, n + 1);
      if (s != null)
        return s;
    }
    n += i.nodeSize;
  }
}
function as(e, t, n, r) {
  for (let i = e.childCount, o = t.childCount; ; ) {
    if (i == 0 || o == 0)
      return i == o ? null : { a: n, b: r };
    let s = e.child(--i), a = t.child(--o), c = s.nodeSize;
    if (s == a) {
      n -= c, r -= c;
      continue;
    }
    if (!s.sameMarkup(a))
      return { a: n, b: r };
    if (s.isText && s.text != a.text) {
      let l = s.text, g = a.text, f = l.length, p = g.length;
      for (; f > 0 && p > 0 && l[f - 1] == g[p - 1]; )
        f--, p--, n--, r--;
      return f && p && f < l.length && ls(l.charCodeAt(f - 1)) && cs(l.charCodeAt(f)) && (n++, r++), { a: n, b: r };
    }
    if (s.content.size || a.content.size) {
      let l = as(s.content, a.content, n - 1, r - 1);
      if (l)
        return l;
    }
    n -= c, r -= c;
  }
}
function cs(e) {
  return e >= 56320 && e < 57344;
}
function ls(e) {
  return e >= 55296 && e < 56320;
}
class j {
  /**
  @internal
  */
  constructor(t, n) {
    if (this.content = t, this.size = n || 0, n == null)
      for (let r = 0; r < t.length; r++)
        this.size += t[r].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(t, n, r, i = 0, o) {
    for (let s = 0, a = 0; a < n; s++) {
      let c = this.content[s], l = a + c.nodeSize;
      if (l > t && r(c, i + a, o || null, s) !== !1 && c.content.size) {
        let g = a + 1;
        c.nodesBetween(Math.max(0, t - g), Math.min(c.content.size, n - g), r, i + g);
      }
      a = l;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(t) {
    this.nodesBetween(0, this.size, t);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(t, n, r, i) {
    let o = "", s = !0;
    return this.nodesBetween(t, n, (a, c) => {
      let l = a.isText ? a.text.slice(Math.max(t, c) - c, n - c) : a.isLeaf ? i ? typeof i == "function" ? i(a) : i : a.type.spec.leafText ? a.type.spec.leafText(a) : "" : "";
      a.isBlock && (a.isLeaf && l || a.isTextblock) && r && (s ? s = !1 : o += r), o += l;
    }, 0), o;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(t) {
    if (!t.size)
      return this;
    if (!this.size)
      return t;
    let n = this.lastChild, r = t.firstChild, i = this.content.slice(), o = 0;
    for (n.isText && n.sameMarkup(r) && (i[i.length - 1] = n.withText(n.text + r.text), o = 1); o < t.content.length; o++)
      i.push(t.content[o]);
    return new j(i, this.size + t.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(t, n = this.size) {
    if (t == 0 && n == this.size)
      return this;
    let r = [], i = 0;
    if (n > t)
      for (let o = 0, s = 0; s < n; o++) {
        let a = this.content[o], c = s + a.nodeSize;
        c > t && ((s < t || c > n) && (a.isText ? a = a.cut(Math.max(0, t - s), Math.min(a.text.length, n - s)) : a = a.cut(Math.max(0, t - s - 1), Math.min(a.content.size, n - s - 1))), r.push(a), i += a.nodeSize), s = c;
      }
    return new j(r, i);
  }
  /**
  @internal
  */
  cutByIndex(t, n) {
    return t == n ? j.empty : t == 0 && n == this.content.length ? this : new j(this.content.slice(t, n));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(t, n) {
    let r = this.content[t];
    if (r == n)
      return this;
    let i = this.content.slice(), o = this.size + n.nodeSize - r.nodeSize;
    return i[t] = n, new j(i, o);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(t) {
    return new j([t].concat(this.content), this.size + t.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(t) {
    return new j(this.content.concat(t), this.size + t.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(t) {
    if (this.content.length != t.content.length)
      return !1;
    for (let n = 0; n < this.content.length; n++)
      if (!this.content[n].eq(t.content[n]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(t) {
    let n = this.content[t];
    if (!n)
      throw new RangeError("Index " + t + " out of range for " + this);
    return n;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(t) {
    return this.content[t] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(t) {
    for (let n = 0, r = 0; n < this.content.length; n++) {
      let i = this.content[n];
      t(i, r, n), r += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(t, n = 0) {
    return ss(this, t, n);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(t, n = this.size, r = t.size) {
    return as(this, t, n, r);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(t) {
    if (t == 0)
      return sn(0, t);
    if (t == this.size)
      return sn(this.content.length, t);
    if (t > this.size || t < 0)
      throw new RangeError(`Position ${t} outside of fragment (${this})`);
    for (let n = 0, r = 0; ; n++) {
      let i = this.child(n), o = r + i.nodeSize;
      if (o >= t)
        return o == t ? sn(n + 1, o) : sn(n, r);
      r = o;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((t) => t.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(t, n) {
    if (!n)
      return j.empty;
    if (!Array.isArray(n))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return j.fromArray(n.map(t.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(t) {
    if (!t.length)
      return j.empty;
    let n, r = 0;
    for (let i = 0; i < t.length; i++) {
      let o = t[i];
      r += o.nodeSize, i && o.isText && t[i - 1].sameMarkup(o) ? (n || (n = t.slice(0, i)), n[n.length - 1] = o.withText(n[n.length - 1].text + o.text)) : n && n.push(o);
    }
    return new j(n || t, r);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(t) {
    if (!t)
      return j.empty;
    if (t instanceof j)
      return t;
    if (Array.isArray(t))
      return this.fromArray(t);
    if (t.attrs)
      return new j([t], t.nodeSize);
    throw new RangeError("Can not convert " + t + " to a Fragment" + (t.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
j.empty = new j([], 0);
const pr = { index: 0, offset: 0 };
function sn(e, t) {
  return pr.index = e, pr.offset = t, pr;
}
function Tn(e, t) {
  if (e === t)
    return !0;
  if (!(e && typeof e == "object") || !(t && typeof t == "object"))
    return !1;
  let n = Array.isArray(e);
  if (Array.isArray(t) != n)
    return !1;
  if (n) {
    if (e.length != t.length)
      return !1;
    for (let r = 0; r < e.length; r++)
      if (!Tn(e[r], t[r]))
        return !1;
  } else {
    for (let r in e)
      if (!(r in t) || !Tn(e[r], t[r]))
        return !1;
    for (let r in t)
      if (!(r in e))
        return !1;
  }
  return !0;
}
class Y {
  /**
  @internal
  */
  constructor(t, n) {
    this.type = t, this.attrs = n;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(t) {
    let n, r = !1;
    for (let i = 0; i < t.length; i++) {
      let o = t[i];
      if (this.eq(o))
        return t;
      if (this.type.excludes(o.type))
        n || (n = t.slice(0, i));
      else {
        if (o.type.excludes(this.type))
          return t;
        !r && o.type.rank > this.type.rank && (n || (n = t.slice(0, i)), n.push(this), r = !0), n && n.push(o);
      }
    }
    return n || (n = t.slice()), r || n.push(this), n;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(t) {
    for (let n = 0; n < t.length; n++)
      if (this.eq(t[n]))
        return t.slice(0, n).concat(t.slice(n + 1));
    return t;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(t) {
    for (let n = 0; n < t.length; n++)
      if (this.eq(t[n]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(t) {
    return this == t || this.type == t.type && Tn(this.attrs, t.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let t = { type: this.type.name };
    for (let n in this.attrs) {
      t.attrs = this.attrs;
      break;
    }
    return t;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(t, n) {
    if (!n)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let r = t.marks[n.type];
    if (!r)
      throw new RangeError(`There is no mark type ${n.type} in this schema`);
    let i = r.create(n.attrs);
    return r.checkAttrs(i.attrs), i;
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(t, n) {
    if (t == n)
      return !0;
    if (t.length != n.length)
      return !1;
    for (let r = 0; r < t.length; r++)
      if (!t[r].eq(n[r]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(t) {
    if (!t || Array.isArray(t) && t.length == 0)
      return Y.none;
    if (t instanceof Y)
      return [t];
    let n = t.slice();
    return n.sort((r, i) => r.type.rank - i.type.rank), n;
  }
}
Y.none = [];
class Ht extends Error {
}
class J {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(t, n, r) {
    this.content = t, this.openStart = n, this.openEnd = r;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(t, n) {
    let r = ps(this.content, t + this.openStart, n, this.openStart + 1, this.openEnd + 1);
    return r && new J(r, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(t, n) {
    return new J(ds(this.content, t + this.openStart, n + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(t) {
    return this.content.eq(t.content) && this.openStart == t.openStart && this.openEnd == t.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let t = { content: this.content.toJSON() };
    return this.openStart > 0 && (t.openStart = this.openStart), this.openEnd > 0 && (t.openEnd = this.openEnd), t;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(t, n) {
    if (!n)
      return J.empty;
    let r = n.openStart || 0, i = n.openEnd || 0;
    if (typeof r != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new J(j.fromJSON(t, n.content), r, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(t, n = !0) {
    let r = 0, i = 0;
    for (let o = t.firstChild; o && !o.isLeaf && (n || !o.type.spec.isolating); o = o.firstChild)
      r++;
    for (let o = t.lastChild; o && !o.isLeaf && (n || !o.type.spec.isolating); o = o.lastChild)
      i++;
    return new J(t, r, i);
  }
}
J.empty = new J(j.empty, 0, 0);
function ds(e, t, n) {
  let { index: r, offset: i } = e.findIndex(t), o = e.maybeChild(r), { index: s, offset: a } = e.findIndex(n);
  if (i == t || o.isText) {
    if (a != n && !e.child(s).isText)
      throw new RangeError("Removing non-flat range");
    return e.cut(0, t).append(e.cut(n));
  }
  if (r != s)
    throw new RangeError("Removing non-flat range");
  return e.replaceChild(r, o.copy(ds(o.content, t - i - 1, n - i - 1)));
}
function ps(e, t, n, r, i, o) {
  let { index: s, offset: a } = e.findIndex(t), c = e.maybeChild(s);
  if (a == t || c.isText)
    return o && r <= 0 && i <= 0 && !o.canReplace(s, s, n) ? null : e.cut(0, t).append(n).append(e.cut(t));
  let l = ps(c.content, t - a - 1, n, s == 0 ? r - 1 : 0, s == e.childCount - 1 ? i - 1 : 0, c);
  return l && e.replaceChild(s, c.copy(l));
}
function Il(e, t, n) {
  if (n.openStart > e.depth)
    throw new Ht("Inserted content deeper than insertion position");
  if (e.depth - n.openStart != t.depth - n.openEnd)
    throw new Ht("Inconsistent open depths");
  return fs(e, t, n, 0);
}
function fs(e, t, n, r) {
  let i = e.index(r), o = e.node(r);
  if (i == t.index(r) && r < e.depth - n.openStart) {
    let s = fs(e, t, n, r + 1);
    return o.copy(o.content.replaceChild(i, s));
  } else if (n.content.size)
    if (!n.openStart && !n.openEnd && e.depth == r && t.depth == r) {
      let s = e.parent, a = s.content;
      return mt(s, a.cut(0, e.parentOffset).append(n.content).append(a.cut(t.parentOffset)));
    } else {
      let { start: s, end: a } = vl(n, e);
      return mt(o, gs(e, s, a, t, r));
    }
  else return mt(o, Cn(e, t, r));
}
function us(e, t) {
  if (!t.type.compatibleContent(e.type))
    throw new Ht("Cannot join " + t.type.name + " onto " + e.type.name);
}
function Dr(e, t, n) {
  let r = e.node(n);
  return us(r, t.node(n)), r;
}
function gt(e, t) {
  let n = t.length - 1;
  n >= 0 && e.isText && e.sameMarkup(t[n]) ? t[n] = e.withText(t[n].text + e.text) : t.push(e);
}
function qt(e, t, n, r) {
  let i = (t || e).node(n), o = 0, s = t ? t.index(n) : i.childCount;
  e && (o = e.index(n), e.depth > n ? o++ : e.textOffset && (gt(e.nodeAfter, r), o++));
  for (let a = o; a < s; a++)
    gt(i.child(a), r);
  t && t.depth == n && t.textOffset && gt(t.nodeBefore, r);
}
function mt(e, t) {
  if (!e.type.validContent(t))
    throw new Ht("Invalid content for node " + e.type.name);
  return e.copy(t);
}
function gs(e, t, n, r, i) {
  let o = e.depth > i && Dr(e, t, i + 1), s = r.depth > i && Dr(n, r, i + 1), a = [];
  return qt(null, e, i, a), o && s && t.index(i) == n.index(i) ? (us(o, s), gt(mt(o, gs(e, t, n, r, i + 1)), a)) : (o && gt(mt(o, Cn(e, t, i + 1)), a), qt(t, n, i, a), s && gt(mt(s, Cn(n, r, i + 1)), a)), qt(r, null, i, a), new j(a);
}
function Cn(e, t, n) {
  let r = [];
  if (qt(null, e, n, r), e.depth > n) {
    let i = Dr(e, t, n + 1);
    gt(mt(i, Cn(e, t, n + 1)), r);
  }
  return qt(t, null, n, r), new j(r);
}
function vl(e, t) {
  let n = t.depth - e.openStart, i = t.node(n).copy(e.content);
  for (let o = n - 1; o >= 0; o--)
    i = t.node(o).copy(j.from(i));
  return {
    start: i.resolveNoCache(e.openStart + n),
    end: i.resolveNoCache(i.content.size - e.openEnd - n)
  };
}
class Wt {
  /**
  @internal
  */
  constructor(t, n, r) {
    this.pos = t, this.path = n, this.parentOffset = r, this.depth = n.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(t) {
    return t == null ? this.depth : t < 0 ? this.depth + t : t;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(t) {
    return this.path[this.resolveDepth(t) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(t) {
    return this.path[this.resolveDepth(t) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(t) {
    return t = this.resolveDepth(t), this.index(t) + (t == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(t) {
    return t = this.resolveDepth(t), t == 0 ? 0 : this.path[t * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(t) {
    return t = this.resolveDepth(t), this.start(t) + this.node(t).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(t) {
    if (t = this.resolveDepth(t), !t)
      throw new RangeError("There is no position before the top-level node");
    return t == this.depth + 1 ? this.pos : this.path[t * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(t) {
    if (t = this.resolveDepth(t), !t)
      throw new RangeError("There is no position after the top-level node");
    return t == this.depth + 1 ? this.pos : this.path[t * 3 - 1] + this.path[t * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let t = this.parent, n = this.index(this.depth);
    if (n == t.childCount)
      return null;
    let r = this.pos - this.path[this.path.length - 1], i = t.child(n);
    return r ? t.child(n).cut(r) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let t = this.index(this.depth), n = this.pos - this.path[this.path.length - 1];
    return n ? this.parent.child(t).cut(0, n) : t == 0 ? null : this.parent.child(t - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(t, n) {
    n = this.resolveDepth(n);
    let r = this.path[n * 3], i = n == 0 ? 0 : this.path[n * 3 - 1] + 1;
    for (let o = 0; o < t; o++)
      i += r.child(o).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let t = this.parent, n = this.index();
    if (t.content.size == 0)
      return Y.none;
    if (this.textOffset)
      return t.child(n).marks;
    let r = t.maybeChild(n - 1), i = t.maybeChild(n);
    if (!r) {
      let a = r;
      r = i, i = a;
    }
    let o = r.marks;
    for (var s = 0; s < o.length; s++)
      o[s].type.spec.inclusive === !1 && (!i || !o[s].isInSet(i.marks)) && (o = o[s--].removeFromSet(o));
    return o;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(t) {
    let n = this.parent.maybeChild(this.index());
    if (!n || !n.isInline)
      return null;
    let r = n.marks, i = t.parent.maybeChild(t.index());
    for (var o = 0; o < r.length; o++)
      r[o].type.spec.inclusive === !1 && (!i || !r[o].isInSet(i.marks)) && (r = r[o--].removeFromSet(r));
    return r;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(t) {
    for (let n = this.depth; n > 0; n--)
      if (this.start(n) <= t && this.end(n) >= t)
        return n;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(t = this, n) {
    if (t.pos < this.pos)
      return t.blockRange(this);
    for (let r = this.depth - (this.parent.inlineContent || this.pos == t.pos ? 1 : 0); r >= 0; r--)
      if (t.pos <= this.end(r) && (!n || n(this.node(r))))
        return new Fl(this, t, r);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(t) {
    return this.pos - this.parentOffset == t.pos - t.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(t) {
    return t.pos > this.pos ? t : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(t) {
    return t.pos < this.pos ? t : this;
  }
  /**
  @internal
  */
  toString() {
    let t = "";
    for (let n = 1; n <= this.depth; n++)
      t += (t ? "/" : "") + this.node(n).type.name + "_" + this.index(n - 1);
    return t + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(t, n) {
    if (!(n >= 0 && n <= t.content.size))
      throw new RangeError("Position " + n + " out of range");
    let r = [], i = 0, o = n;
    for (let s = t; ; ) {
      let { index: a, offset: c } = s.content.findIndex(o), l = o - c;
      if (r.push(s, a, i + c), !l || (s = s.child(a), s.isText))
        break;
      o = l - 1, i += c + 1;
    }
    return new Wt(n, r, o);
  }
  /**
  @internal
  */
  static resolveCached(t, n) {
    let r = ji.get(t);
    if (r)
      for (let o = 0; o < r.elts.length; o++) {
        let s = r.elts[o];
        if (s.pos == n)
          return s;
      }
    else
      ji.set(t, r = new kl());
    let i = r.elts[r.i] = Wt.resolve(t, n);
    return r.i = (r.i + 1) % wl, i;
  }
}
class kl {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const wl = 12, ji = /* @__PURE__ */ new WeakMap();
class Fl {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(t, n, r) {
    this.$from = t, this.$to = n, this.depth = r;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const Rl = /* @__PURE__ */ Object.create(null);
class ze {
  /**
  @internal
  */
  constructor(t, n, r, i = Y.none) {
    this.type = t, this.attrs = n, this.marks = i, this.content = r || j.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(t) {
    return this.content.child(t);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(t) {
    return this.content.maybeChild(t);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(t) {
    this.content.forEach(t);
  }
  /**
  Invoke a callback for all descendant nodes recursively overlapping
  the given two positions that are relative to start of this
  node's content. This includes all ancestors of the nodes
  containing the two positions. The callback is invoked with the
  node, its position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(t, n, r, i = 0) {
    this.content.nodesBetween(t, n, r, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(t) {
    this.nodesBetween(0, this.content.size, t);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(t, n, r, i) {
    return this.content.textBetween(t, n, r, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(t) {
    return this == t || this.sameMarkup(t) && this.content.eq(t.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(t) {
    return this.hasMarkup(t.type, t.attrs, t.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(t, n, r) {
    return this.type == t && Tn(this.attrs, n || t.defaultAttrs || Rl) && Y.sameSet(this.marks, r || Y.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(t = null) {
    return t == this.content ? this : new ze(this.type, this.attrs, t, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(t) {
    return t == this.marks ? this : new ze(this.type, this.attrs, this.content, t);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(t, n = this.content.size) {
    return t == 0 && n == this.content.size ? this : this.copy(this.content.cut(t, n));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(t, n = this.content.size, r = !1) {
    if (t == n)
      return J.empty;
    let i = this.resolve(t), o = this.resolve(n), s = r ? 0 : i.sharedDepth(n), a = i.start(s), l = i.node(s).content.cut(i.pos - a, o.pos - a);
    return new J(l, i.depth - s, o.depth - s);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(t, n, r) {
    return Il(this.resolve(t), this.resolve(n), r);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(t) {
    for (let n = this; ; ) {
      let { index: r, offset: i } = n.content.findIndex(t);
      if (n = n.maybeChild(r), !n)
        return null;
      if (i == t || n.isText)
        return n;
      t -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(t) {
    let { index: n, offset: r } = this.content.findIndex(t);
    return { node: this.content.maybeChild(n), index: n, offset: r };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(t) {
    if (t == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: n, offset: r } = this.content.findIndex(t);
    if (r < t)
      return { node: this.content.child(n), index: n, offset: r };
    let i = this.content.child(n - 1);
    return { node: i, index: n - 1, offset: r - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(t) {
    return Wt.resolveCached(this, t);
  }
  /**
  @internal
  */
  resolveNoCache(t) {
    return Wt.resolve(this, t);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(t, n, r) {
    let i = !1;
    return n > t && this.nodesBetween(t, n, (o) => (r.isInSet(o.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let t = this.type.name;
    return this.content.size && (t += "(" + this.content.toStringInner() + ")"), ms(this.marks, t);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(t) {
    let n = this.type.contentMatch.matchFragment(this.content, 0, t);
    if (!n)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return n;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(t, n, r = j.empty, i = 0, o = r.childCount) {
    let s = this.contentMatchAt(t).matchFragment(r, i, o), a = s && s.matchFragment(this.content, n);
    if (!a || !a.validEnd)
      return !1;
    for (let c = i; c < o; c++)
      if (!this.type.allowsMarks(r.child(c).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(t, n, r, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let o = this.contentMatchAt(t).matchType(r), s = o && o.matchFragment(this.content, n);
    return s ? s.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(t) {
    return t.content.size ? this.canReplace(this.childCount, this.childCount, t.content) : this.type.compatibleContent(t.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), this.type.checkAttrs(this.attrs);
    let t = Y.none;
    for (let n = 0; n < this.marks.length; n++) {
      let r = this.marks[n];
      r.type.checkAttrs(r.attrs), t = r.addToSet(t);
    }
    if (!Y.sameSet(t, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((n) => n.type.name)}`);
    this.content.forEach((n) => n.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let t = { type: this.type.name };
    for (let n in this.attrs) {
      t.attrs = this.attrs;
      break;
    }
    return this.content.size && (t.content = this.content.toJSON()), this.marks.length && (t.marks = this.marks.map((n) => n.toJSON())), t;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(t, n) {
    if (!n)
      throw new RangeError("Invalid input for Node.fromJSON");
    let r;
    if (n.marks) {
      if (!Array.isArray(n.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      r = n.marks.map(t.markFromJSON);
    }
    if (n.type == "text") {
      if (typeof n.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return t.text(n.text, r);
    }
    let i = j.fromJSON(t, n.content), o = t.nodeType(n.type).create(n.attrs, i, r);
    return o.type.checkAttrs(o.attrs), o;
  }
}
ze.prototype.text = void 0;
class Pn extends ze {
  /**
  @internal
  */
  constructor(t, n, r, i) {
    if (super(t, n, null, i), !r)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = r;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : ms(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(t, n) {
    return this.text.slice(t, n);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(t) {
    return t == this.marks ? this : new Pn(this.type, this.attrs, this.text, t);
  }
  withText(t) {
    return t == this.text ? this : new Pn(this.type, this.attrs, t, this.marks);
  }
  cut(t = 0, n = this.text.length) {
    return t == 0 && n == this.text.length ? this : this.withText(this.text.slice(t, n));
  }
  eq(t) {
    return this.sameMarkup(t) && this.text == t.text;
  }
  toJSON() {
    let t = super.toJSON();
    return t.text = this.text, t;
  }
}
function ms(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    t = e[n].type.name + "(" + t + ")";
  return t;
}
class ht {
  /**
  @internal
  */
  constructor(t) {
    this.validEnd = t, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(t, n) {
    let r = new Sl(t, n);
    if (r.next == null)
      return ht.empty;
    let i = hs(r);
    r.next && r.err("Unexpected trailing text");
    let o = Dl(Pl(i));
    return Bl(o, r), o;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(t) {
    for (let n = 0; n < this.next.length; n++)
      if (this.next[n].type == t)
        return this.next[n].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(t, n = 0, r = t.childCount) {
    let i = this;
    for (let o = n; i && o < r; o++)
      i = i.matchType(t.child(o).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let t = 0; t < this.next.length; t++) {
      let { type: n } = this.next[t];
      if (!(n.isText || n.hasRequiredAttrs()))
        return n;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(t) {
    for (let n = 0; n < this.next.length; n++)
      for (let r = 0; r < t.next.length; r++)
        if (this.next[n].type == t.next[r].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(t, n = !1, r = 0) {
    let i = [this];
    function o(s, a) {
      let c = s.matchFragment(t, r);
      if (c && (!n || c.validEnd))
        return j.from(a.map((l) => l.createAndFill()));
      for (let l = 0; l < s.next.length; l++) {
        let { type: g, next: f } = s.next[l];
        if (!(g.isText || g.hasRequiredAttrs()) && i.indexOf(f) == -1) {
          i.push(f);
          let p = o(f, a.concat(g));
          if (p)
            return p;
        }
      }
      return null;
    }
    return o(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(t) {
    for (let r = 0; r < this.wrapCache.length; r += 2)
      if (this.wrapCache[r] == t)
        return this.wrapCache[r + 1];
    let n = this.computeWrapping(t);
    return this.wrapCache.push(t, n), n;
  }
  /**
  @internal
  */
  computeWrapping(t) {
    let n = /* @__PURE__ */ Object.create(null), r = [{ match: this, type: null, via: null }];
    for (; r.length; ) {
      let i = r.shift(), o = i.match;
      if (o.matchType(t)) {
        let s = [];
        for (let a = i; a.type; a = a.via)
          s.push(a.type);
        return s.reverse();
      }
      for (let s = 0; s < o.next.length; s++) {
        let { type: a, next: c } = o.next[s];
        !a.isLeaf && !a.hasRequiredAttrs() && !(a.name in n) && (!i.type || c.validEnd) && (r.push({ match: a.contentMatch, type: a, via: i }), n[a.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(t) {
    if (t >= this.next.length)
      throw new RangeError(`There's no ${t}th edge in this content match`);
    return this.next[t];
  }
  /**
  @internal
  */
  toString() {
    let t = [];
    function n(r) {
      t.push(r);
      for (let i = 0; i < r.next.length; i++)
        t.indexOf(r.next[i].next) == -1 && n(r.next[i].next);
    }
    return n(this), t.map((r, i) => {
      let o = i + (r.validEnd ? "*" : " ") + " ";
      for (let s = 0; s < r.next.length; s++)
        o += (s ? ", " : "") + r.next[s].type.name + "->" + t.indexOf(r.next[s].next);
      return o;
    }).join(`
`);
  }
}
ht.empty = new ht(!0);
class Sl {
  constructor(t, n) {
    this.string = t, this.nodeTypes = n, this.inline = null, this.pos = 0, this.tokens = t.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(t) {
    return this.next == t && (this.pos++ || !0);
  }
  err(t) {
    throw new SyntaxError(t + " (in content expression '" + this.string + "')");
  }
}
function hs(e) {
  let t = [];
  do
    t.push(Al(e));
  while (e.eat("|"));
  return t.length == 1 ? t[0] : { type: "choice", exprs: t };
}
function Al(e) {
  let t = [];
  do
    t.push(El(e));
  while (e.next && e.next != ")" && e.next != "|");
  return t.length == 1 ? t[0] : { type: "seq", exprs: t };
}
function El(e) {
  let t = Cl(e);
  for (; ; )
    if (e.eat("+"))
      t = { type: "plus", expr: t };
    else if (e.eat("*"))
      t = { type: "star", expr: t };
    else if (e.eat("?"))
      t = { type: "opt", expr: t };
    else if (e.eat("{"))
      t = Ol(e, t);
    else
      break;
  return t;
}
function Ni(e) {
  /\D/.test(e.next) && e.err("Expected number, got '" + e.next + "'");
  let t = Number(e.next);
  return e.pos++, t;
}
function Ol(e, t) {
  let n = Ni(e), r = n;
  return e.eat(",") && (e.next != "}" ? r = Ni(e) : r = -1), e.eat("}") || e.err("Unclosed braced range"), { type: "range", min: n, max: r, expr: t };
}
function Tl(e, t) {
  let n = e.nodeTypes, r = n[t];
  if (r)
    return [r];
  let i = [];
  for (let o in n) {
    let s = n[o];
    s.isInGroup(t) && i.push(s);
  }
  return i.length == 0 && e.err("No node type or group '" + t + "' found"), i;
}
function Cl(e) {
  if (e.eat("(")) {
    let t = hs(e);
    return e.eat(")") || e.err("Missing closing paren"), t;
  } else if (/\W/.test(e.next))
    e.err("Unexpected token '" + e.next + "'");
  else {
    let t = Tl(e, e.next).map((n) => (e.inline == null ? e.inline = n.isInline : e.inline != n.isInline && e.err("Mixing inline and block content"), { type: "name", value: n }));
    return e.pos++, t.length == 1 ? t[0] : { type: "choice", exprs: t };
  }
}
function Pl(e) {
  let t = [[]];
  return i(o(e, 0), n()), t;
  function n() {
    return t.push([]) - 1;
  }
  function r(s, a, c) {
    let l = { term: c, to: a };
    return t[s].push(l), l;
  }
  function i(s, a) {
    s.forEach((c) => c.to = a);
  }
  function o(s, a) {
    if (s.type == "choice")
      return s.exprs.reduce((c, l) => c.concat(o(l, a)), []);
    if (s.type == "seq")
      for (let c = 0; ; c++) {
        let l = o(s.exprs[c], a);
        if (c == s.exprs.length - 1)
          return l;
        i(l, a = n());
      }
    else if (s.type == "star") {
      let c = n();
      return r(a, c), i(o(s.expr, c), c), [r(c)];
    } else if (s.type == "plus") {
      let c = n();
      return i(o(s.expr, a), c), i(o(s.expr, c), c), [r(c)];
    } else {
      if (s.type == "opt")
        return [r(a)].concat(o(s.expr, a));
      if (s.type == "range") {
        let c = a;
        for (let l = 0; l < s.min; l++) {
          let g = n();
          i(o(s.expr, c), g), c = g;
        }
        if (s.max == -1)
          i(o(s.expr, c), c);
        else
          for (let l = s.min; l < s.max; l++) {
            let g = n();
            r(c, g), i(o(s.expr, c), g), c = g;
          }
        return [r(c)];
      } else {
        if (s.type == "name")
          return [r(a, void 0, s.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function ys(e, t) {
  return t - e;
}
function Mi(e, t) {
  let n = [];
  return r(t), n.sort(ys);
  function r(i) {
    let o = e[i];
    if (o.length == 1 && !o[0].term)
      return r(o[0].to);
    n.push(i);
    for (let s = 0; s < o.length; s++) {
      let { term: a, to: c } = o[s];
      !a && n.indexOf(c) == -1 && r(c);
    }
  }
}
function Dl(e) {
  let t = /* @__PURE__ */ Object.create(null);
  return n(Mi(e, 0));
  function n(r) {
    let i = [];
    r.forEach((s) => {
      e[s].forEach(({ term: a, to: c }) => {
        if (!a)
          return;
        let l;
        for (let g = 0; g < i.length; g++)
          i[g][0] == a && (l = i[g][1]);
        Mi(e, c).forEach((g) => {
          l || i.push([a, l = []]), l.indexOf(g) == -1 && l.push(g);
        });
      });
    });
    let o = t[r.join(",")] = new ht(r.indexOf(e.length - 1) > -1);
    for (let s = 0; s < i.length; s++) {
      let a = i[s][1].sort(ys);
      o.next.push({ type: i[s][0], next: t[a.join(",")] || n(a) });
    }
    return o;
  }
}
function Bl(e, t) {
  for (let n = 0, r = [e]; n < r.length; n++) {
    let i = r[n], o = !i.validEnd, s = [];
    for (let a = 0; a < i.next.length; a++) {
      let { type: c, next: l } = i.next[a];
      s.push(c.name), o && !(c.isText || c.hasRequiredAttrs()) && (o = !1), r.indexOf(l) == -1 && r.push(l);
    }
    o && t.err("Only non-generatable nodes (" + s.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function bs(e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let n in e) {
    let r = e[n];
    if (!r.hasDefault)
      return null;
    t[n] = r.default;
  }
  return t;
}
function xs(e, t) {
  let n = /* @__PURE__ */ Object.create(null);
  for (let r in e) {
    let i = t && t[r];
    if (i === void 0) {
      let o = e[r];
      if (o.hasDefault)
        i = o.default;
      else
        throw new RangeError("No value supplied for attribute " + r);
    }
    n[r] = i;
  }
  return n;
}
function Is(e, t, n, r) {
  for (let i in t)
    if (!(i in e))
      throw new RangeError(`Unsupported attribute ${i} for ${n} of type ${r}`);
  for (let i in e)
    e[i].validate && e[i].validate(t[i]);
}
function vs(e, t) {
  let n = /* @__PURE__ */ Object.create(null);
  if (t)
    for (let r in t)
      n[r] = new Nl(e, r, t[r]);
  return n;
}
class Dn {
  /**
  @internal
  */
  constructor(t, n, r) {
    this.name = t, this.schema = n, this.spec = r, this.markSet = null, this.groups = r.group ? r.group.split(" ") : [], this.attrs = vs(t, r.attrs), this.defaultAttrs = bs(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(r.inline || t == "text"), this.isText = t == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == ht.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(t) {
    return this.groups.indexOf(t) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let t in this.attrs)
      if (this.attrs[t].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(t) {
    return this == t || this.contentMatch.compatible(t.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(t) {
    return !t && this.defaultAttrs ? this.defaultAttrs : xs(this.attrs, t);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(t = null, n, r) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new ze(this, this.computeAttrs(t), j.from(n), Y.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(t = null, n, r) {
    return n = j.from(n), this.checkContent(n), new ze(this, this.computeAttrs(t), n, Y.setFrom(r));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(t = null, n, r) {
    if (t = this.computeAttrs(t), n = j.from(n), n.size) {
      let s = this.contentMatch.fillBefore(n);
      if (!s)
        return null;
      n = s.append(n);
    }
    let i = this.contentMatch.matchFragment(n), o = i && i.fillBefore(j.empty, !0);
    return o ? new ze(this, t, n.append(o), Y.setFrom(r)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(t) {
    let n = this.contentMatch.matchFragment(t);
    if (!n || !n.validEnd)
      return !1;
    for (let r = 0; r < t.childCount; r++)
      if (!this.allowsMarks(t.child(r).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(t) {
    if (!this.validContent(t))
      throw new RangeError(`Invalid content for node ${this.name}: ${t.toString().slice(0, 50)}`);
  }
  /**
  @internal
  */
  checkAttrs(t) {
    Is(this.attrs, t, "node", this.name);
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(t) {
    return this.markSet == null || this.markSet.indexOf(t) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(t) {
    if (this.markSet == null)
      return !0;
    for (let n = 0; n < t.length; n++)
      if (!this.allowsMarkType(t[n].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(t) {
    if (this.markSet == null)
      return t;
    let n;
    for (let r = 0; r < t.length; r++)
      this.allowsMarkType(t[r].type) ? n && n.push(t[r]) : n || (n = t.slice(0, r));
    return n ? n.length ? n : Y.none : t;
  }
  /**
  @internal
  */
  static compile(t, n) {
    let r = /* @__PURE__ */ Object.create(null);
    t.forEach((o, s) => r[o] = new Dn(o, n, s));
    let i = n.spec.topNode || "doc";
    if (!r[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!r.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let o in r.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return r;
  }
}
function jl(e, t, n) {
  let r = n.split("|");
  return (i) => {
    let o = i === null ? "null" : typeof i;
    if (r.indexOf(o) < 0)
      throw new RangeError(`Expected value of type ${r} for attribute ${t} on type ${e}, got ${o}`);
  };
}
class Nl {
  constructor(t, n, r) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(r, "default"), this.default = r.default, this.validate = typeof r.validate == "string" ? jl(t, n, r.validate) : r.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class ni {
  /**
  @internal
  */
  constructor(t, n, r, i) {
    this.name = t, this.rank = n, this.schema = r, this.spec = i, this.attrs = vs(t, i.attrs), this.excluded = null;
    let o = bs(this.attrs);
    this.instance = o ? new Y(this, o) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(t = null) {
    return !t && this.instance ? this.instance : new Y(this, xs(this.attrs, t));
  }
  /**
  @internal
  */
  static compile(t, n) {
    let r = /* @__PURE__ */ Object.create(null), i = 0;
    return t.forEach((o, s) => r[o] = new ni(o, i++, n, s)), r;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(t) {
    for (var n = 0; n < t.length; n++)
      t[n].type == this && (t = t.slice(0, n).concat(t.slice(n + 1)), n--);
    return t;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(t) {
    for (let n = 0; n < t.length; n++)
      if (t[n].type == this)
        return t[n];
  }
  /**
  @internal
  */
  checkAttrs(t) {
    Is(this.attrs, t, "mark", this.name);
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(t) {
    return this.excluded.indexOf(t) > -1;
  }
}
class Ml {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(t) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let n = this.spec = {};
    for (let i in t)
      n[i] = t[i];
    n.nodes = te.from(t.nodes), n.marks = te.from(t.marks || {}), this.nodes = Dn.compile(this.spec.nodes, this), this.marks = ni.compile(this.spec.marks, this);
    let r = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let o = this.nodes[i], s = o.spec.content || "", a = o.spec.marks;
      if (o.contentMatch = r[s] || (r[s] = ht.parse(s, this.nodes)), o.inlineContent = o.contentMatch.inlineContent, o.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!o.isInline || !o.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = o;
      }
      o.markSet = a == "_" ? null : a ? zi(this, a.split(" ")) : a == "" || !o.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let o = this.marks[i], s = o.spec.excludes;
      o.excluded = s == null ? [o] : s == "" ? [] : zi(this, s.split(" "));
    }
    this.nodeFromJSON = (i) => ze.fromJSON(this, i), this.markFromJSON = (i) => Y.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(t, n = null, r, i) {
    if (typeof t == "string")
      t = this.nodeType(t);
    else if (t instanceof Dn) {
      if (t.schema != this)
        throw new RangeError("Node type from different schema used (" + t.name + ")");
    } else throw new RangeError("Invalid node type: " + t);
    return t.createChecked(n, r, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(t, n) {
    let r = this.nodes.text;
    return new Pn(r, r.defaultAttrs, t, Y.setFrom(n));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(t, n) {
    return typeof t == "string" && (t = this.marks[t]), t.create(n);
  }
  /**
  @internal
  */
  nodeType(t) {
    let n = this.nodes[t];
    if (!n)
      throw new RangeError("Unknown node type: " + t);
    return n;
  }
}
function zi(e, t) {
  let n = [];
  for (let r = 0; r < t.length; r++) {
    let i = t[r], o = e.marks[i], s = o;
    if (o)
      n.push(o);
    else
      for (let a in e.marks) {
        let c = e.marks[a];
        (i == "_" || c.spec.group && c.spec.group.split(" ").indexOf(i) > -1) && n.push(s = c);
      }
    if (!s)
      throw new SyntaxError("Unknown mark type: '" + t[r] + "'");
  }
  return n;
}
const ks = 65535, ws = Math.pow(2, 16);
function zl(e, t) {
  return e + t * ws;
}
function $i(e) {
  return e & ks;
}
function $l(e) {
  return (e - (e & ks)) / ws;
}
const Fs = 1, Rs = 2, yn = 4, Ss = 8;
class Vi {
  /**
  @internal
  */
  constructor(t, n, r) {
    this.pos = t, this.delInfo = n, this.recover = r;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & Ss) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (Fs | yn)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (Rs | yn)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & yn) > 0;
  }
}
class fe {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(t, n = !1) {
    if (this.ranges = t, this.inverted = n, !t.length && fe.empty)
      return fe.empty;
  }
  /**
  @internal
  */
  recover(t) {
    let n = 0, r = $i(t);
    if (!this.inverted)
      for (let i = 0; i < r; i++)
        n += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[r * 3] + n + $l(t);
  }
  mapResult(t, n = 1) {
    return this._map(t, n, !1);
  }
  map(t, n = 1) {
    return this._map(t, n, !0);
  }
  /**
  @internal
  */
  _map(t, n, r) {
    let i = 0, o = this.inverted ? 2 : 1, s = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let c = this.ranges[a] - (this.inverted ? i : 0);
      if (c > t)
        break;
      let l = this.ranges[a + o], g = this.ranges[a + s], f = c + l;
      if (t <= f) {
        let p = l ? t == c ? -1 : t == f ? 1 : n : n, d = c + i + (p < 0 ? 0 : g);
        if (r)
          return d;
        let h = t == (n < 0 ? c : f) ? null : zl(a / 3, t - c), m = t == c ? Rs : t == f ? Fs : yn;
        return (n < 0 ? t != c : t != f) && (m |= Ss), new Vi(d, m, h);
      }
      i += g - l;
    }
    return r ? t + i : new Vi(t + i, 0, null);
  }
  /**
  @internal
  */
  touches(t, n) {
    let r = 0, i = $i(n), o = this.inverted ? 2 : 1, s = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let c = this.ranges[a] - (this.inverted ? r : 0);
      if (c > t)
        break;
      let l = this.ranges[a + o], g = c + l;
      if (t <= g && a == i * 3)
        return !0;
      r += this.ranges[a + s] - l;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(t) {
    let n = this.inverted ? 2 : 1, r = this.inverted ? 1 : 2;
    for (let i = 0, o = 0; i < this.ranges.length; i += 3) {
      let s = this.ranges[i], a = s - (this.inverted ? o : 0), c = s + (this.inverted ? 0 : o), l = this.ranges[i + n], g = this.ranges[i + r];
      t(a, a + l, c, c + g), o += g - l;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new fe(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(t) {
    return t == 0 ? fe.empty : new fe(t < 0 ? [0, -t, 0] : [0, 0, t]);
  }
}
fe.empty = new fe([]);
const fr = /* @__PURE__ */ Object.create(null);
class ne {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return fe.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(t) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(t, n) {
    if (!n || !n.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let r = fr[n.stepType];
    if (!r)
      throw new RangeError(`No step type ${n.stepType} defined`);
    return r.fromJSON(t, n);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(t, n) {
    if (t in fr)
      throw new RangeError("Duplicate use of step JSON ID " + t);
    return fr[t] = n, n.prototype.jsonID = t, n;
  }
}
class W {
  /**
  @internal
  */
  constructor(t, n) {
    this.doc = t, this.failed = n;
  }
  /**
  Create a successful step result.
  */
  static ok(t) {
    return new W(t, null);
  }
  /**
  Create a failed step result.
  */
  static fail(t) {
    return new W(null, t);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(t, n, r, i) {
    try {
      return W.ok(t.replace(n, r, i));
    } catch (o) {
      if (o instanceof Ht)
        return W.fail(o.message);
      throw o;
    }
  }
}
function ri(e, t, n) {
  let r = [];
  for (let i = 0; i < e.childCount; i++) {
    let o = e.child(i);
    o.content.size && (o = o.copy(ri(o.content, t, o))), o.isInline && (o = t(o, n, i)), r.push(o);
  }
  return j.fromArray(r);
}
class dt extends ne {
  /**
  Create a mark step.
  */
  constructor(t, n, r) {
    super(), this.from = t, this.to = n, this.mark = r;
  }
  apply(t) {
    let n = t.slice(this.from, this.to), r = t.resolve(this.from), i = r.node(r.sharedDepth(this.to)), o = new J(ri(n.content, (s, a) => !s.isAtom || !a.type.allowsMarkType(this.mark.type) ? s : s.mark(this.mark.addToSet(s.marks)), i), n.openStart, n.openEnd);
    return W.fromReplace(t, this.from, this.to, o);
  }
  invert() {
    return new pt(this.from, this.to, this.mark);
  }
  map(t) {
    let n = t.mapResult(this.from, 1), r = t.mapResult(this.to, -1);
    return n.deleted && r.deleted || n.pos >= r.pos ? null : new dt(n.pos, r.pos, this.mark);
  }
  merge(t) {
    return t instanceof dt && t.mark.eq(this.mark) && this.from <= t.to && this.to >= t.from ? new dt(Math.min(this.from, t.from), Math.max(this.to, t.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new dt(n.from, n.to, t.markFromJSON(n.mark));
  }
}
ne.jsonID("addMark", dt);
class pt extends ne {
  /**
  Create a mark-removing step.
  */
  constructor(t, n, r) {
    super(), this.from = t, this.to = n, this.mark = r;
  }
  apply(t) {
    let n = t.slice(this.from, this.to), r = new J(ri(n.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), t), n.openStart, n.openEnd);
    return W.fromReplace(t, this.from, this.to, r);
  }
  invert() {
    return new dt(this.from, this.to, this.mark);
  }
  map(t) {
    let n = t.mapResult(this.from, 1), r = t.mapResult(this.to, -1);
    return n.deleted && r.deleted || n.pos >= r.pos ? null : new pt(n.pos, r.pos, this.mark);
  }
  merge(t) {
    return t instanceof pt && t.mark.eq(this.mark) && this.from <= t.to && this.to >= t.from ? new pt(Math.min(this.from, t.from), Math.max(this.to, t.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new pt(n.from, n.to, t.markFromJSON(n.mark));
  }
}
ne.jsonID("removeMark", pt);
class ft extends ne {
  /**
  Create a node mark step.
  */
  constructor(t, n) {
    super(), this.pos = t, this.mark = n;
  }
  apply(t) {
    let n = t.nodeAt(this.pos);
    if (!n)
      return W.fail("No node at mark step's position");
    let r = n.type.create(n.attrs, null, this.mark.addToSet(n.marks));
    return W.fromReplace(t, this.pos, this.pos + 1, new J(j.from(r), 0, n.isLeaf ? 0 : 1));
  }
  invert(t) {
    let n = t.nodeAt(this.pos);
    if (n) {
      let r = this.mark.addToSet(n.marks);
      if (r.length == n.marks.length) {
        for (let i = 0; i < n.marks.length; i++)
          if (!n.marks[i].isInSet(r))
            return new ft(this.pos, n.marks[i]);
        return new ft(this.pos, this.mark);
      }
    }
    return new Xt(this.pos, this.mark);
  }
  map(t) {
    let n = t.mapResult(this.pos, 1);
    return n.deletedAfter ? null : new ft(n.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new ft(n.pos, t.markFromJSON(n.mark));
  }
}
ne.jsonID("addNodeMark", ft);
class Xt extends ne {
  /**
  Create a mark-removing step.
  */
  constructor(t, n) {
    super(), this.pos = t, this.mark = n;
  }
  apply(t) {
    let n = t.nodeAt(this.pos);
    if (!n)
      return W.fail("No node at mark step's position");
    let r = n.type.create(n.attrs, null, this.mark.removeFromSet(n.marks));
    return W.fromReplace(t, this.pos, this.pos + 1, new J(j.from(r), 0, n.isLeaf ? 0 : 1));
  }
  invert(t) {
    let n = t.nodeAt(this.pos);
    return !n || !this.mark.isInSet(n.marks) ? this : new ft(this.pos, this.mark);
  }
  map(t) {
    let n = t.mapResult(this.pos, 1);
    return n.deletedAfter ? null : new Xt(n.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new Xt(n.pos, t.markFromJSON(n.mark));
  }
}
ne.jsonID("removeNodeMark", Xt);
class ke extends ne {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(t, n, r, i = !1) {
    super(), this.from = t, this.to = n, this.slice = r, this.structure = i;
  }
  apply(t) {
    return this.structure && Br(t, this.from, this.to) ? W.fail("Structure replace would overwrite content") : W.fromReplace(t, this.from, this.to, this.slice);
  }
  getMap() {
    return new fe([this.from, this.to - this.from, this.slice.size]);
  }
  invert(t) {
    return new ke(this.from, this.from + this.slice.size, t.slice(this.from, this.to));
  }
  map(t) {
    let n = t.mapResult(this.to, -1), r = this.from == this.to && ke.MAP_BIAS < 0 ? n : t.mapResult(this.from, 1);
    return r.deletedAcross && n.deletedAcross ? null : new ke(r.pos, Math.max(r.pos, n.pos), this.slice, this.structure);
  }
  merge(t) {
    if (!(t instanceof ke) || t.structure || this.structure)
      return null;
    if (this.from + this.slice.size == t.from && !this.slice.openEnd && !t.slice.openStart) {
      let n = this.slice.size + t.slice.size == 0 ? J.empty : new J(this.slice.content.append(t.slice.content), this.slice.openStart, t.slice.openEnd);
      return new ke(this.from, this.to + (t.to - t.from), n, this.structure);
    } else if (t.to == this.from && !this.slice.openStart && !t.slice.openEnd) {
      let n = this.slice.size + t.slice.size == 0 ? J.empty : new J(t.slice.content.append(this.slice.content), t.slice.openStart, this.slice.openEnd);
      return new ke(t.from, this.to, n, this.structure);
    } else
      return null;
  }
  toJSON() {
    let t = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (t.slice = this.slice.toJSON()), this.structure && (t.structure = !0), t;
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new ke(n.from, n.to, J.fromJSON(t, n.slice), !!n.structure);
  }
}
ke.MAP_BIAS = 1;
ne.jsonID("replace", ke);
class Jt extends ne {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(t, n, r, i, o, s, a = !1) {
    super(), this.from = t, this.to = n, this.gapFrom = r, this.gapTo = i, this.slice = o, this.insert = s, this.structure = a;
  }
  apply(t) {
    if (this.structure && (Br(t, this.from, this.gapFrom) || Br(t, this.gapTo, this.to)))
      return W.fail("Structure gap-replace would overwrite content");
    let n = t.slice(this.gapFrom, this.gapTo);
    if (n.openStart || n.openEnd)
      return W.fail("Gap is not a flat range");
    let r = this.slice.insertAt(this.insert, n.content);
    return r ? W.fromReplace(t, this.from, this.to, r) : W.fail("Content does not fit in gap");
  }
  getMap() {
    return new fe([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(t) {
    let n = this.gapTo - this.gapFrom;
    return new Jt(this.from, this.from + this.slice.size + n, this.from + this.insert, this.from + this.insert + n, t.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(t) {
    let n = t.mapResult(this.from, 1), r = t.mapResult(this.to, -1), i = this.from == this.gapFrom ? n.pos : t.map(this.gapFrom, -1), o = this.to == this.gapTo ? r.pos : t.map(this.gapTo, 1);
    return n.deletedAcross && r.deletedAcross || i < n.pos || o > r.pos ? null : new Jt(n.pos, r.pos, i, o, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let t = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (t.slice = this.slice.toJSON()), this.structure && (t.structure = !0), t;
  }
  /**
  @internal
  */
  static fromJSON(t, n) {
    if (typeof n.from != "number" || typeof n.to != "number" || typeof n.gapFrom != "number" || typeof n.gapTo != "number" || typeof n.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new Jt(n.from, n.to, n.gapFrom, n.gapTo, J.fromJSON(t, n.slice), n.insert, !!n.structure);
  }
}
ne.jsonID("replaceAround", Jt);
function Br(e, t, n) {
  let r = e.resolve(t), i = n - t, o = r.depth;
  for (; i > 0 && o > 0 && r.indexAfter(o) == r.node(o).childCount; )
    o--, i--;
  if (i > 0) {
    let s = r.node(o).maybeChild(r.indexAfter(o));
    for (; i > 0; ) {
      if (!s || s.isLeaf)
        return !0;
      s = s.firstChild, i--;
    }
  }
  return !1;
}
class Kt extends ne {
  /**
  Construct an attribute step.
  */
  constructor(t, n, r) {
    super(), this.pos = t, this.attr = n, this.value = r;
  }
  apply(t) {
    let n = t.nodeAt(this.pos);
    if (!n)
      return W.fail("No node at attribute step's position");
    let r = /* @__PURE__ */ Object.create(null);
    for (let o in n.attrs)
      r[o] = n.attrs[o];
    r[this.attr] = this.value;
    let i = n.type.create(r, null, n.marks);
    return W.fromReplace(t, this.pos, this.pos + 1, new J(j.from(i), 0, n.isLeaf ? 0 : 1));
  }
  getMap() {
    return fe.empty;
  }
  invert(t) {
    return new Kt(this.pos, this.attr, t.nodeAt(this.pos).attrs[this.attr]);
  }
  map(t) {
    let n = t.mapResult(this.pos, 1);
    return n.deletedAfter ? null : new Kt(n.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(t, n) {
    if (typeof n.pos != "number" || typeof n.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new Kt(n.pos, n.attr, n.value);
  }
}
ne.jsonID("attr", Kt);
class Bn extends ne {
  /**
  Construct an attribute step.
  */
  constructor(t, n) {
    super(), this.attr = t, this.value = n;
  }
  apply(t) {
    let n = /* @__PURE__ */ Object.create(null);
    for (let i in t.attrs)
      n[i] = t.attrs[i];
    n[this.attr] = this.value;
    let r = t.type.create(n, t.content, t.marks);
    return W.ok(r);
  }
  getMap() {
    return fe.empty;
  }
  invert(t) {
    return new Bn(this.attr, t.attrs[this.attr]);
  }
  map(t) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(t, n) {
    if (typeof n.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new Bn(n.attr, n.value);
  }
}
ne.jsonID("docAttr", Bn);
let Gt = class extends Error {
};
Gt = function e(t) {
  let n = Error.call(this, t);
  return n.__proto__ = e.prototype, n;
};
Gt.prototype = Object.create(Error.prototype);
Gt.prototype.constructor = Gt;
Gt.prototype.name = "TransformError";
const Et = u({
  canonicalBytes: 2e6,
  nodes: 5e4,
  steps: 1e4,
  mappingRanges: 12e4
}), rt = { default: null }, _i = { default: null }, jn = new Ml({
  nodes: {
    doc: { content: "block+" },
    paragraph: {
      content: "inline*",
      group: "block",
      attrs: { textAlign: _i, blockId: rt }
    },
    heading: {
      content: "inline*",
      group: "block",
      defining: !0,
      attrs: { textAlign: _i, blockId: rt, level: { default: 1 } }
    },
    blockquote: {
      content: "block+",
      group: "block",
      defining: !0,
      attrs: { blockId: rt }
    },
    bulletList: {
      content: "listItem+",
      group: "block list",
      attrs: { blockId: rt }
    },
    orderedList: {
      content: "listItem+",
      group: "block list",
      attrs: {
        blockId: rt,
        start: { default: 1 },
        type: { default: null }
      }
    },
    listItem: {
      content: "paragraph block*",
      defining: !0,
      attrs: { blockId: rt }
    },
    horizontalRule: { group: "block", attrs: { blockId: rt } },
    hardBreak: { inline: !0, group: "inline", selectable: !1 },
    text: { group: "inline" }
  },
  marks: {
    bold: {},
    italic: {},
    strike: {},
    underline: {},
    code: { code: !0, excludes: "_" }
  }
}), As = u({
  schema: {
    id: "zx.text-editor.historical-v1-audit-schema",
    version: "1.0.0",
    fingerprint: v({
      nodes: Object.keys(jn.spec.nodes).sort(),
      marks: Object.keys(jn.spec.marks).sort()
    })
  },
  verifier: "historical-v1-exact-envelope-and-roundtrip@1.0.0",
  prosemirror: {
    model: "zx-prosemirror-model-legacy-v0@1.25.10",
    transform: "zx-prosemirror-transform-legacy-v0@1.12.0"
  },
  stepCodec: "historical-v1-step-from-json-roundtrip@1.0.0",
  plugin: "historical-v1-stable-block-order-projector@1.0.0",
  mapping: "historical-v1-ordered-step-map-ranges@1.0.0",
  transaction: "historical-v1-sequential-apply@1.0.0",
  resource: {
    id: "historical-v1-audit-resource-profile",
    version: "1.0.0",
    limits: Et
  }
}), bn = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), jr = (e, t) => {
  const n = Object.keys(e).sort(), r = [...t].sort();
  return n.length === r.length && n.every((i, o) => i === r[o]);
}, Vl = (e) => bn(e) && jr(e, [
  "baseDocument",
  "resultDocument",
  "resultFingerprint",
  "steps"
]) && Array.isArray(e.steps) && e.steps.length <= Et.steps && typeof e.resultFingerprint == "string", Li = (e) => {
  const t = F(e);
  if (new TextEncoder().encode(t).byteLength > Et.canonicalBytes)
    throw new TypeError("historical-resource-limit");
  if (!bn(e) || !jr(e, ["version", "body", "annotations", "assets", "meta"]) || e.version !== 2 || !bn(e.body) || !jr(e.body, ["format", "content"]) || e.body.format !== "json" || !Array.isArray(e.annotations) || !Array.isArray(e.assets) || !bn(e.meta))
    throw new TypeError("historical-document-invalid");
  const n = jn.nodeFromJSON(e.body.content);
  let r = 1;
  const i = /* @__PURE__ */ new Set();
  if (n.descendants((o) => {
    if (r += 1, r > Et.nodes)
      throw new TypeError("historical-resource-limit");
    const s = o.attrs.blockId;
    if (s == null) return !0;
    if (typeof s != "string" || !/^[a-z][a-z0-9]*_[a-z0-9]+$/.test(s) || i.has(s))
      throw new TypeError("historical-stable-identity-invalid");
    return i.add(s), !0;
  }), F(n.toJSON()) !== F(e.body.content))
    throw new TypeError("historical-document-roundtrip-invalid");
  return { envelope: e, node: n };
}, _l = (e) => {
  const t = [];
  return e.descendants((n) => (typeof n.attrs.blockId == "string" && t.push(n.attrs.blockId), !0)), t;
}, Ll = (e) => {
  const t = F(e);
  if (new TextEncoder().encode(t).byteLength > Et.canonicalBytes)
    throw new TypeError("historical-resource-limit");
  const n = Li(e.baseDocument), r = Li(e.resultDocument);
  let i = n.node, o = 0;
  const s = e.steps.map(
    (c, l) => {
      const g = ne.fromJSON(jn, c);
      if (F(g.toJSON()) !== F(c))
        throw new TypeError("historical-step-roundtrip-invalid");
      const f = [
        ...g.getMap().ranges
      ], p = f.length / 3;
      if (o += p, !Number.isSafeInteger(p) || o > Et.mappingRanges)
        throw new TypeError("historical-resource-limit");
      const d = g.apply(i);
      if (d.failed || !d.doc)
        throw new TypeError(`historical-step-invalid:${l}`);
      return i = d.doc, f;
    }
  );
  if (F(i.toJSON()) !== F(r.node.toJSON()) || v(r.envelope) !== e.resultFingerprint)
    throw new TypeError("historical-result-mismatch");
  const a = {
    schemaFingerprint: As.schema.fingerprint,
    transactionCount: e.steps.length,
    mappingRanges: s,
    pluginState: { blockIds: _l(i) },
    resultFingerprint: e.resultFingerprint
  };
  return u({
    payloadCanonical: t,
    evidence: a,
    evidenceFingerprint: v(a)
  });
}, Es = u({
  kind: "execution-closure",
  id: "zx.text-editor.execution-artifact-parser",
  version: "1.0.0",
  fingerprint: "sha256:acb8e040432aaf975734340a35c2cceaef4df5f8be529713620c1f603bf45881"
}), Os = u({
  kind: "execution-closure",
  id: "zx.text-editor.execution-abi",
  version: "1.2.0",
  fingerprint: "sha256:92e689a3ed365de863d0a9c31f7995d694d07654f7c85a78a14de26aa98e110c"
}), qi = {
  parser: Es,
  runtime: Os,
  decoderSourceFingerprint: bl,
  executableBundleSourceFingerprint: xl,
  bindings: {
    parser: "canonical-artifact-v1",
    ...As,
    exactPackageRefs: [
      ti,
      yl,
      os
    ]
  },
  liveCapability: !1
}, Ji = u({
  ...qi,
  closureFingerprint: v({
    domain: "zx-historical-runtime-closure:v1",
    projection: qi
  })
}), Ki = {
  kind: "execution-closure",
  id: "zx.text-editor.runtime-v2-historical-integrity-reader",
  version: "2.0.0"
}, Ts = u({
  ...Ki,
  fingerprint: v({
    domain: "zx-historical-runtime-v2-parser",
    projection: Ki
  })
}), an = Jn().executionClosure, ql = u({
  kind: an.kind,
  id: an.id,
  version: an.version,
  fingerprint: an.fingerprint
}), Ui = {
  parser: Ts,
  runtime: ql,
  mode: "immutable-integrity-only",
  liveCapability: !1
}, ur = u({
  ...Ui,
  closureFingerprint: v({
    domain: "zx-historical-runtime-closure:v2",
    projection: Ui
  })
}), We = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), cn = (e, t) => We(e) ? Object.keys(e).sort().join("|") === ["fingerprint", "id", "kind", "version"].join("|") && e.kind === t.kind && e.id === t.id && e.version === t.version && e.fingerprint === t.fingerprint : !1, Hi = (e) => {
  const t = e, n = We(t) ? Object.keys(t).sort().join("|") : "";
  if (We(t) && n === [
    "artifactKind",
    "closureFingerprint",
    "parserRef",
    "payload",
    "runtimeRef"
  ].sort().join("|") && t.artifactKind === "zx-text-editor-runtime-artifact-v2" && cn(t.parserRef, Ts) && cn(t.runtimeRef, ur.runtime) && t.closureFingerprint === ur.closureFingerprint) {
    const s = t.payload, a = We(s) ? Object.keys(s).sort().join("|") : "";
    if (!We(s) || a !== [
      "baseDocument",
      "baseDocumentFingerprint",
      "mappingFingerprint",
      "planDigest",
      "resultDocument",
      "resultFingerprint",
      "runtimeManifestFingerprint",
      "runtimeReceiptFingerprint",
      "traceFingerprint"
    ].sort().join("|") || !We(s.baseDocument) || !We(s.resultDocument) || typeof s.baseDocumentFingerprint != "string" || typeof s.mappingFingerprint != "string" || typeof s.planDigest != "string" || typeof s.resultFingerprint != "string" || typeof s.runtimeManifestFingerprint != "string" || typeof s.runtimeReceiptFingerprint != "string" || typeof s.traceFingerprint != "string" || s.baseDocumentFingerprint !== v(s.baseDocument) || s.resultFingerprint !== v(s.resultDocument) || s.runtimeManifestFingerprint !== Jn().fingerprints.runtimeManifestFingerprint)
      return u({
        status: "invalid-artifact",
        diagnostic: {
          code: "runtime-manifest-invalid",
          stage: "historical-audit",
          path: "$.artifact.payload"
        },
        liveCapability: !1
      });
    let c;
    try {
      c = F(s);
    } catch {
      return u({
        status: "invalid-artifact",
        diagnostic: {
          code: "runtime-manifest-invalid",
          stage: "historical-audit",
          path: "$.artifact.payload"
        },
        liveCapability: !1
      });
    }
    return u({
      status: "verified",
      artifactKind: "zx-text-editor-runtime-artifact-v2",
      auditFingerprint: v({
        closure: ur,
        payload: c
      }),
      liveCapability: !1
    });
  }
  if (!We(t) || n !== [
    "artifactKind",
    "closureFingerprint",
    "parserRef",
    "payload",
    "runtimeRef"
  ].sort().join("|") || t.artifactKind !== "zx-text-editor-execution-artifact-v1" || !cn(t.parserRef, Es) || !cn(t.runtimeRef, Os) || t.closureFingerprint !== Ji.closureFingerprint)
    return u({
      status: "historical-runtime-unsupported",
      diagnostic: {
        code: "runtime-component-unsupported",
        stage: "historical-audit",
        path: "$.artifact.runtimeRef"
      },
      liveCapability: !1
    });
  const r = t;
  let i;
  try {
    i = F(r.payload);
  } catch {
    return u({
      status: "invalid-artifact",
      diagnostic: {
        code: "runtime-manifest-invalid",
        stage: "historical-audit",
        path: "$.artifact.payload"
      },
      liveCapability: !1
    });
  }
  if (!Vl(r.payload))
    return u({
      status: "invalid-artifact",
      diagnostic: {
        code: "runtime-manifest-invalid",
        stage: "historical-audit",
        path: "$.artifact.payload"
      },
      liveCapability: !1
    });
  let o;
  try {
    o = Ll(r.payload);
  } catch {
    return u({
      status: "invalid-artifact",
      diagnostic: {
        code: "runtime-fingerprint-mismatch",
        stage: "historical-audit",
        path: "$.artifact.payload.result"
      },
      liveCapability: !1
    });
  }
  return u({
    status: "verified",
    artifactKind: r.artifactKind,
    auditFingerprint: v({
      closure: Ji,
      payload: i,
      evidenceFingerprint: o.evidenceFingerprint
    }),
    liveCapability: !1
  });
}, ln = u({
  parser: {
    kind: "execution-closure",
    id: "zx.text-editor.runtime-v2-historical-integrity-reader",
    version: "2.0.0",
    fingerprint: "sha256:f35f376acd01b971817c6f0b1589c7fd62807d3e2a0b0c66d6724c5cd1b49dbd"
  },
  runtime: {
    kind: "execution-closure",
    id: "zx.text-editor.deterministic-execution-closure",
    version: "2.0.0",
    fingerprint: "sha256:e2480ad4fa39da5b64b40fbfa76c68df85be585b174f02f716dc4a5dbedcfda0"
  },
  mode: "immutable-integrity-only",
  liveCapability: !1,
  closureFingerprint: "sha256:fd81991b39cdfcb26ba6959a21aa730a3b25a005b037c1fe47b330c0f60ab829"
}), Jl = "sha256:a5ab6d6ba0b39d11d95386ce274d6e6a9d1634db6dc00b91a9192640a1d65537", dn = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), Wi = () => u({
  status: "invalid-artifact",
  diagnostic: {
    code: "runtime-manifest-invalid",
    stage: "historical-audit",
    path: "$.artifact.payload"
  },
  liveCapability: !1
}), Kl = (e) => {
  const t = e;
  if (!dn(t) || Object.keys(t).sort().join("|") !== "artifactKind|closureFingerprint|parserRef|payload|runtimeRef" || t.artifactKind !== "zx-text-editor-runtime-artifact-v2" || t.closureFingerprint !== ln.closureFingerprint)
    return Hi(e);
  try {
    if (F(t.parserRef) !== F(ln.parser) || F(t.runtimeRef) !== F(ln.runtime))
      return Hi(e);
    const n = t.payload;
    return !dn(n) || Object.keys(n).sort().join("|") !== "baseDocument|baseDocumentFingerprint|mappingFingerprint|planDigest|resultDocument|resultFingerprint|runtimeManifestFingerprint|runtimeReceiptFingerprint|traceFingerprint" || !dn(n.baseDocument) || !dn(n.resultDocument) || ![
      "baseDocumentFingerprint",
      "mappingFingerprint",
      "planDigest",
      "resultFingerprint",
      "runtimeManifestFingerprint",
      "runtimeReceiptFingerprint",
      "traceFingerprint"
    ].every((r) => typeof n[r] == "string") || n.baseDocumentFingerprint !== v(n.baseDocument) || n.resultFingerprint !== v(n.resultDocument) || n.runtimeManifestFingerprint !== Jl ? Wi() : u({
      status: "verified",
      artifactKind: "zx-text-editor-runtime-artifact-v2",
      auditFingerprint: v({
        closure: ln,
        payload: F(n)
      }),
      liveCapability: !1
    });
  } catch {
    return Wi();
  }
}, Ul = (e) => {
  const t = e;
  if (t.destroyed === !0 || !t.state || !t.schema || t.state.schema !== t.schema)
    throw new TypeError("target-binding-invalid");
  return t;
}, Hl = (e, t) => {
  const n = t.trace.entries[0];
  if (!n || n.kind !== "root" || n.sequence !== 0 || n.sourceAttribution.owner !== "operation-compiler" || n.sourceAttribution.pluginInstanceId !== null || Object.keys(n.allowedMeta).length !== 1 || !Object.hasOwn(n.allowedMeta, hn))
    throw new TypeError("target-materialization-invalid");
  const r = Ul(e);
  if (v(r.state.doc.toJSON()) !== n.beforeDocumentFingerprint)
    throw new TypeError("target-materialization-invalid");
  const i = va(r.state, n.logicalTime);
  for (const a of n.steps) {
    const c = Ea.fromJSON(r.schema, a.json), l = c.toJSON(), g = c.getMap().ranges;
    if (F(l) !== F(a.json) || v(l) !== a.fingerprint || v({ ranges: g }) !== a.mapFingerprint)
      throw new TypeError("target-materialization-invalid");
    i.step(c);
  }
  i.setMeta(hn, n.allowedMeta[hn]);
  const o = wo(
    i,
    "root",
    n.sequence,
    n.rootExecutionId
  );
  if (v(i.doc.toJSON()) !== n.afterDocumentFingerprint || F(o) !== F(n.allowedMeta) || i.steps.length !== n.steps.length)
    throw new TypeError("target-materialization-invalid");
  const s = {
    rootExecutionId: n.rootExecutionId,
    logicalTime: i.time,
    before: i.before.toJSON(),
    after: i.doc.toJSON(),
    steps: i.steps.map((a) => a.toJSON()),
    allowedMeta: o,
    operationIndexes: n.sourceAttribution.operationIndexes
  };
  return Object.freeze({
    transaction: i,
    fingerprint: v({
      domain: "zx-runtime-fresh-root-materialization-v2",
      value: s
    })
  });
}, Wl = (e, t) => u(
  $e.map((n) => {
    const r = n.project(e), i = n.project(t);
    return {
      pluginInstanceId: n.instanceId,
      projectorRef: n.projectorRef,
      beforeFingerprint: v(r),
      afterFingerprint: v(i),
      value: i
    };
  })
), Xl = (e) => {
  const t = v({
    domain: "zx-ai-proposal-annotation-projection:v1",
    value: e.fresh.mapping.annotations
  });
  if (e.bindingAfter.bindingFingerprint !== e.bindingBefore.bindingFingerprint || e.bindingAfter.hostBindingFingerprint !== e.bindingBefore.hostBindingFingerprint || e.dispatchAdmission.status !== "admissible" || e.dispatchAdmission.targetBindingFingerprint !== e.bindingBefore.hostBindingFingerprint || v(e.afterDocument) !== e.fresh.resultFingerprint || F(e.afterDocument) !== F(e.fresh.resultDocument) || e.livePluginState.length !== e.fresh.pluginState.length || e.livePluginState.some((i, o) => {
    const s = e.fresh.pluginState[o];
    return !s || i.pluginInstanceId !== s.pluginInstanceId || F(i.projectorRef) !== F(s.projectorRef) || i.afterFingerprint !== s.afterFingerprint || F(i.value) !== F(s.value);
  }) || F(e.expectedTargetStateAfterProjection) !== F(e.targetStateAfterProjection) || t !== e.expectedAnnotationFingerprint || e.historyAfter.undoDepth !== e.historyBefore.undoDepth + 1 || e.historyAfter.redoDepth !== 0)
    return null;
  const n = e.fresh.trace.entries.map((i) => ({
    kind: i.kind,
    sequence: i.sequence,
    logicalTime: i.logicalTime,
    allowedMetaFingerprint: v(i.allowedMeta),
    afterDocumentFingerprint: i.afterDocumentFingerprint
  }));
  if (F(e.liveClosure) !== F(n))
    return null;
  const r = {
    beforeDocumentFingerprint: v(e.beforeDocument),
    afterDocumentFingerprint: v(e.afterDocument),
    annotationFingerprint: v(e.afterDocument.annotations),
    assetsFingerprint: v(e.afterDocument.assets),
    metaFingerprint: v(e.afterDocument.meta),
    targetBindingFingerprint: e.bindingAfter.bindingFingerprint,
    targetCompositionFingerprint: e.dispatchAdmission.targetCompositionFingerprint,
    freshOutcomeFingerprint: v(e.fresh),
    materializedRootFingerprint: e.materializedRootFingerprint,
    livePluginProjectionFingerprint: v(e.livePluginState),
    liveAppendedClosureFingerprint: v({
      liveClosure: e.liveClosure,
      livePluginState: e.livePluginState
    }),
    targetStateFingerprint: v(e.targetStateAfterProjection),
    historyBeforeFingerprint: e.historyBefore.fingerprint,
    historyAfterFingerprint: e.historyAfter.fingerprint,
    undoDepthDelta: 1
  };
  return u({
    ...r,
    fingerprint: v({
      domain: "zx-runtime-target-commit-proof-v2",
      value: r
    })
  });
}, xn = /* @__PURE__ */ new WeakMap(), Gl = (e) => xn.get(e) ?? null, pn = (e) => u({
  status: "rejected",
  diagnostic: {
    code: "target-guard-rejected",
    stage: "guard",
    path: e
  }
}), Cs = (e, t) => {
  if (!e || typeof e != "object" || xn.has(e))
    return pn("$.targetEditor");
  const n = Er(e);
  if (!n) return pn("$.targetBinding");
  xn.set(e, n);
  try {
    const r = t(n);
    if (r && (typeof r == "object" || typeof r == "function") && typeof r.then == "function")
      return pn("$.callback.then");
    const i = Er(e);
    return !i || i.bindingFingerprint !== n.bindingFingerprint ? pn("$.targetBinding") : { status: "success", value: r };
  } finally {
    xn.delete(e);
  }
}, Zl = Pa, Yl = (e, t) => !!(e && typeof e == "object" && !Array.isArray(e) && Object.keys(e).length === t.length && t.every((n) => Object.hasOwn(e, n))), Ql = (e, t, n, r) => u({
  code: e,
  stage: t,
  path: n
}), ge = (e, t) => u({
  status: e,
  freshOutcome: t.freshOutcome ?? null,
  dispatchAdmission: t.dispatchAdmission ?? null,
  proof: null,
  diagnostic: Ql(t.code, t.stage, t.path)
}), fn = (e) => {
  const t = e, n = t.view, r = t.state;
  if (t.destroyed === !0 || !n || !r || n.state !== r || typeof n.dispatch != "function")
    throw new TypeError("target-binding-invalid");
  return { view: n, state: r };
}, Xi = (e) => {
  var t;
  return {
    selection: e.selection.toJSON(),
    storedMarks: ((t = e.storedMarks) == null ? void 0 : t.map((n) => n.toJSON())) ?? null
  };
}, ed = (e) => Yl(e, [
  "runtime",
  "plan",
  "context",
  "targetEditor",
  "runtimeExpectation",
  "expectedResultFingerprint",
  "expectedTraceFingerprint",
  "expectedMappingFingerprint",
  "expectedResourcesFingerprint",
  "expectedPluginStateFingerprint",
  "expectedRuntimeReceiptFingerprint",
  "expectedReplayEligibility",
  "expectedAnnotationFingerprint"
]) && e.targetEditor && typeof e.targetEditor == "object" && [
  e.expectedResultFingerprint,
  e.expectedTraceFingerprint,
  e.expectedMappingFingerprint,
  e.expectedResourcesFingerprint,
  e.expectedPluginStateFingerprint,
  e.expectedRuntimeReceiptFingerprint,
  e.expectedAnnotationFingerprint
].every((t) => typeof t == "string" && t.length > 0) && e.expectedReplayEligibility === "exact-runtime-only", td = (e) => {
  if (!ed(e))
    return ge("not-admissible", {
      code: "target-binding-invalid",
      stage: "binding",
      path: "$"
    });
  const t = (i) => {
    let o;
    try {
      o = i.readCanonicalDocument(), fn(e.targetEditor);
    } catch {
      return ge("not-admissible", {
        code: "target-document-invalid",
        stage: "binding",
        path: "$.targetDocument"
      });
    }
    const s = v({
      domain: "zx-ai-proposal-base-document:v1",
      value: o
    }), a = hl(
      e.runtimeExpectation,
      s,
      e.targetEditor
    );
    if (a.status !== "admissible" || a.targetBindingFingerprint !== i.hostBindingFingerprint)
      return ge("not-admissible", {
        dispatchAdmission: a,
        code: "target-not-admissible",
        stage: "admission",
        path: "$.runtimeExpectation"
      });
    const c = ii({
      runtime: e.runtime,
      baseDocument: o,
      plan: e.plan,
      context: e.context
    });
    if (c.status === "failure")
      return ge("runtime-failure", {
        freshOutcome: c,
        dispatchAdmission: a,
        code: "target-runtime-failure",
        stage: "execute",
        path: "$.freshOutcome"
      });
    if (c.status === "safety-abort")
      return ge("safety-abort", {
        freshOutcome: c,
        dispatchAdmission: a,
        code: "target-runtime-failure",
        stage: "execute",
        path: "$.freshOutcome"
      });
    if (c.resultFingerprint !== e.expectedResultFingerprint || c.trace.fingerprint !== e.expectedTraceFingerprint || c.mapping.fingerprint !== e.expectedMappingFingerprint || v(c.resources) !== e.expectedResourcesFingerprint || v(c.pluginState) !== e.expectedPluginStateFingerprint || v(c.runtime) !== e.expectedRuntimeReceiptFingerprint || c.replayEligibility !== e.expectedReplayEligibility)
      return ge("fresh-mismatch", {
        freshOutcome: c,
        dispatchAdmission: a,
        code: "target-fresh-mismatch",
        stage: "execute",
        path: "$.freshOutcome"
      });
    if (F(c.resultDocument) === F(o))
      return u({
        status: "accepted-no-change",
        freshOutcome: c,
        dispatchAdmission: a,
        proof: null
      });
    let l;
    try {
      l = Hl(
        e.targetEditor,
        c
      );
    } catch {
      return ge("fresh-mismatch", {
        freshOutcome: c,
        dispatchAdmission: a,
        code: "target-materialization-invalid",
        stage: "materialize",
        path: "$.freshOutcome.trace.entries[0]"
      });
    }
    const g = i.readHistoryState(), f = fn(e.targetEditor).state, p = Xi(
      l.transaction
    );
    try {
      wa(
        l.transaction,
        o,
        c.resultDocument
      ), Zl.closeHistory(l.transaction), fn(e.targetEditor).view.dispatch(l.transaction);
    } catch {
      let k = !0;
      try {
        k = F(i.readCanonicalDocument()) !== F(o);
      } catch {
        k = !0;
      }
      return ge(
        k ? "post-dispatch-safety-incident" : "dispatch-failure",
        {
          freshOutcome: c,
          dispatchAdmission: a,
          code: k ? "target-post-dispatch-incident" : "target-dispatch-failure",
          stage: k ? "post-dispatch" : "dispatch",
          path: "$.targetEditor.view.dispatch"
        }
      );
    }
    const d = Er(e.targetEditor);
    if (!d)
      return ge("post-dispatch-safety-incident", {
        freshOutcome: c,
        dispatchAdmission: a,
        code: "target-post-dispatch-incident",
        stage: "post-dispatch",
        path: "$.targetBinding"
      });
    let h, m, y;
    try {
      h = d.readCanonicalDocument(), m = d.readHistoryState(), y = fn(e.targetEditor).state;
    } catch {
      return ge("post-dispatch-safety-incident", {
        freshOutcome: c,
        dispatchAdmission: a,
        code: "target-post-dispatch-incident",
        stage: "post-dispatch",
        path: "$.targetDocument"
      });
    }
    const b = Xl({
      bindingBefore: i,
      bindingAfter: d,
      beforeDocument: o,
      afterDocument: h,
      fresh: c,
      dispatchAdmission: a,
      materializedRootFingerprint: l.fingerprint,
      historyBefore: g,
      historyAfter: m,
      expectedAnnotationFingerprint: e.expectedAnnotationFingerprint,
      expectedTargetStateAfterProjection: p,
      targetStateAfterProjection: Xi(y),
      livePluginState: Wl(
        f,
        y
      ),
      liveClosure: Fa(y)
    });
    return b ? u({
      status: "committed",
      freshOutcome: c,
      dispatchAdmission: a,
      mapping: c.mapping,
      pluginState: c.pluginState,
      proof: b
    }) : ge("post-dispatch-safety-incident", {
      freshOutcome: c,
      dispatchAdmission: a,
      code: "target-post-dispatch-incident",
      stage: "post-dispatch",
      path: "$.proof"
    });
  }, n = Gl(
    e.targetEditor
  ), r = n ? {
    status: "success",
    value: t(n)
  } : Cs(e.targetEditor, t);
  return r.status === "rejected" ? ge("not-admissible", {
    code: r.diagnostic.code,
    stage: r.diagnostic.stage,
    path: r.diagnostic.path
  }) : r.value;
}, un = (e, t, n = []) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const r = Object.keys(e);
  return t.every((i) => r.includes(i)) && r.every((i) => t.includes(i) || n.includes(i));
}, nd = (e) => un(e, ["runtime", "baseDocument", "plan", "context"]) && un(e.runtime, ["kind", "version", "fingerprint"]) && e.runtime.kind === "zx-text-editor-runtime-manifest-v2" && e.runtime.version === "2.0.0" && typeof e.runtime.fingerprint == "string" && un(e.context, ["protocol"], ["intentRef"]) && e.context.protocol === "zx-runtime-execution-context-v1" && (!e.context.intentRef || un(e.context.intentRef, ["id", "version", "fingerprint"]) && typeof e.context.intentRef.id == "string" && typeof e.context.intentRef.version == "string" && typeof e.context.intentRef.fingerprint == "string") && Yr(e.plan), Ne = (e, t, n = {}) => u({
  status: "failure",
  code: t,
  diagnostic: _o(e, t, n),
  resultDocument: null,
  trace: null,
  replayEligibility: "none"
}), rd = (e, t) => {
  if (e instanceof Tr)
    return Ne(t, e.code, e.diagnostic);
  if (e instanceof je)
    return Ne(t, e.code, {
      stage: "driver",
      path: e.path
    });
  if (e instanceof Vt)
    return Ne(t, "annotation-invalidated", {
      stage: "mapping",
      path: "$.baseDocument.annotations",
      fingerprintPrefix: v(e.annotationId).slice(0, 20)
    });
  const n = e instanceof Error ? e.message : "", r = n.includes("mark-policy-violation") ? "mark-policy-violation" : n.includes("plan-invalid") ? "plan-invalid" : n.includes("operation-compile-failed") ? "operation-compile-failed" : n.includes("transaction-time-invalid") ? "transaction-time-invalid" : n.includes("transaction-meta-invalid") ? "transaction-meta-invalid" : n.includes("transaction-attribution-invalid") ? "transaction-attribution-invalid" : "runtime-internal-failure";
  return Ne(t, r);
}, ii = (e) => {
  var i, o, s;
  const t = Vo();
  try {
    tn(e, {
      maxBytes: st.inputBytes,
      maxDepth: st.inputDepth,
      maxArrayEntries: st.inputKeys,
      maxObjectKeys: st.inputKeys,
      maxTotalObjectKeys: st.inputKeys
    });
  } catch {
    return Ne(t, "plan-invalid", {
      stage: "stage-1",
      path: "$"
    });
  }
  if (!nd(e)) return Ne(t, "plan-invalid");
  const n = cl(e.runtime);
  if (n.status === "failure")
    return Ne(
      t,
      n.diagnostic.code,
      n.diagnostic
    );
  const r = In(e.baseDocument);
  if (!r.valid)
    return Ne(t, "document-invalid", {
      stage: "stage-1",
      path: ((i = r.issues[0]) == null ? void 0 : i.path) ?? "$.baseDocument"
    });
  try {
    fc(
      t,
      e,
      e.baseDocument,
      e.plan,
      $e.length
    );
    const a = Uc(
      e.baseDocument,
      e.plan,
      n.manifest.resourceProfile.fingerprint
    ), c = rl(), g = Io().nodeFromJSON(e.baseDocument.body.content), f = Ao.create({
      doc: g,
      plugins: $e.map(
        (x) => x.plugin
      )
    }), p = v({
      domain: "zx-runtime-execution-id:v2",
      runtime: e.runtime,
      baseDocument: e.baseDocument,
      plan: e.plan,
      context: e.context
    }), d = Hc(
      f,
      e.baseDocument,
      e.plan,
      p,
      a
    ), h = wc(
      f,
      d.transaction,
      d.operationSpans,
      p,
      t
    ), m = Gc(
      e.baseDocument,
      g,
      h.state.doc,
      h.transactions,
      t
    ), y = In(m.resultDocument);
    if (!y.valid)
      return Ne(t, "document-invalid", {
        stage: "serialization",
        path: ((o = y.issues[0]) == null ? void 0 : o.path) ?? "$.resultDocument"
      });
    const b = v(m.resultDocument), k = {
      manifestRef: Ee,
      executionSemanticsFingerprint: n.manifest.fingerprints.executionSemanticsFingerprint,
      observationalProfileFingerprint: n.manifest.fingerprints.observationalProfileFingerprint,
      derivedViewFingerprint: n.manifest.fingerprints.derivedViewFingerprint,
      adapterRef: ka,
      conformanceReceiptRefs: c.map(
        (x) => x.outcomeFingerprint
      ),
      conformanceEnvironmentReceiptRefs: ((s = c[0]) == null ? void 0 : s.environmentOutcomes.map((x, R) => ({
        environment: x.environment,
        adapterExecutionIdentity: x.adapterExecutionIdentity,
        matrixRowFingerprint: v({
          environment: x.environment,
          adapterExecutionIdentity: x.adapterExecutionIdentity,
          pluginRows: c.map(
            (A) => A.environmentOutcomes[R].matrixRowFingerprint
          )
        })
      }))) ?? []
    };
    t.debit(
      "traceBytes",
      Ye(k),
      "$.receipt"
    );
    const w = gc(
      {
        executionId: p,
        manifest: n.manifest.fingerprints,
        entries: h.entries,
        mapping: m.projection,
        resultFingerprint: b
      },
      t
    ), I = {
      status: "success",
      runtime: k,
      resultDocument: m.resultDocument,
      resultFingerprint: b,
      trace: w,
      mapping: m.projection,
      pluginState: h.pluginState,
      resources: t.snapshot(),
      replayEligibility: "exact-runtime-only"
    };
    return u(I);
  } catch (a) {
    return rd(a, t);
  }
}, pf = (e) => {
  const t = Vo();
  return u({
    status: "safety-abort",
    code: "safety-watchdog-abort",
    diagnostic: _o(
      t,
      "safety-watchdog-abort",
      {
        stage: "host-watchdog",
        path: "$.watchdog",
        fingerprintPrefix: v(e).slice(0, 20)
      }
    ),
    resultDocument: null,
    trace: null,
    replayEligibility: "none"
  });
}, id = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, gr = /^[A-Za-z0-9_.:-]{1,160}$/, ae = (e) => {
  const t = {
    code: e.code,
    stage: e.stage,
    path: id.test(e.path) ? e.path.slice(0, 240) : "$",
    ...Number.isSafeInteger(e.count) && e.count >= 0 ? { count: Math.min(e.count, 1e6) } : {},
    ...typeof e.fingerprint == "string" ? { fingerprintPrefix: Sr(e.fingerprint) } : {},
    ...e.operationRef && gr.test(e.operationRef) ? { operationRef: e.operationRef } : {},
    ...e.blockRef && gr.test(e.blockRef) ? { blockRef: e.blockRef } : {},
    ...e.hunkRef && gr.test(e.hunkRef) ? { hunkRef: e.hunkRef } : {}
  };
  return u(t);
}, Rt = u({
  maxBytes: 12e6,
  maxDepth: 160,
  maxArrayEntries: 12e4,
  maxObjectKeys: 96,
  maxTotalObjectKeys: 5e5
}), Hn = u({
  maxInputBytes: 12e6,
  maxOutputBytes: 2e6,
  maxHunks: 5e3
}), et = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), S = (e, t, n = []) => et(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), E = (e) => typeof e == "string" && e.trim().length > 0, G = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, D = (e, t) => v({ domain: e, value: t }), Ot = (e) => {
  const { fingerprint: t, ...n } = e;
  return n;
}, Pt = (e) => {
  tn(e, Rt);
  const { canonical: t } = Oe(
    e,
    Rt
  );
  return u(JSON.parse(t));
}, M = (e, t) => {
  try {
    return F(e) === F(t);
  } catch {
    return !1;
  }
}, Wn = (e, t = /* @__PURE__ */ new Set()) => !e || typeof e != "object" || t.has(e) ? !0 : Object.isFrozen(e) ? (t.add(e), Object.values(e).every((n) => Wn(n, t))) : !1, Ps = (e) => new TextEncoder().encode(F(e)).byteLength, Ds = (e) => [...new Set(e)].sort(), Nr = (e) => {
  const t = [], n = /* @__PURE__ */ new Map(), r = (i, o) => {
    if (!i || typeof i != "object" || Array.isArray(i)) return;
    const s = i, a = s.attrs, c = a && typeof a == "object" && !Array.isArray(a) && typeof a.blockId == "string" ? a.blockId : null, l = c ? [...o, c] : [...o];
    if (c) {
      const g = {
        id: c,
        node: s,
        fingerprint: v(s),
        ancestors: [...o],
        descendants: [],
        ordinal: t.length
      };
      t.push(g), n.set(c, g), o.forEach(
        (f) => {
          var p;
          return (p = n.get(f)) == null ? void 0 : p.descendants.push(c);
        }
      );
    }
    Array.isArray(s.content) && s.content.forEach((g) => r(g, l));
  };
  return r(e.body.content, []), t;
}, Bs = (e, t = []) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return t;
  const n = e;
  return n.attrs && typeof n.attrs == "object" && !Array.isArray(n.attrs) && typeof n.attrs.blockId == "string" && t.push(n.attrs.blockId), Array.isArray(n.content) && n.content.forEach((r) => Bs(r, t)), t;
}, od = (e) => {
  const t = "target" in e ? [e.target.blockId] : [], n = "reference" in e ? [e.reference.blockId] : [], r = "block" in e ? Bs(e.block) : [];
  return Ds([...t, ...n, ...r]);
}, Gi = (e, t) => {
  const n = new Map(t.map((i) => [i.id, i])), r = new Set(e);
  return e.forEach((i) => {
    const o = n.get(i);
    o == null || o.ancestors.forEach((s) => r.add(s)), o == null || o.descendants.forEach((s) => r.add(s));
  }), [...r].sort();
}, js = (e, t) => {
  const n = new Map(
    Nr(e).map((r) => [r.id, r.fingerprint])
  );
  return D(
    "zx-ai-proposal-targets:v1",
    t.map((r) => ({
      operationIndex: r.operationIndex,
      blocks: r.blockIds.map((i) => ({
        blockId: i,
        fingerprint: n.get(i) ?? null
      }))
    }))
  );
}, sd = (e, t, n) => {
  const r = new Map(
    n.mapping.annotations.map((i) => [
      i.annotationId,
      i
    ])
  );
  return r.size !== t.annotations.length || r.size !== e.annotations.length || e.annotations.some((i) => !r.has(i.id)) ? !1 : t.annotations.every((i) => {
    const o = r.get(i.id);
    return !!(o && i.anchor.start.blockId === o.start.mapped.blockId && i.anchor.start.offset === o.start.mapped.offset && i.anchor.end.blockId === o.end.mapped.blockId && i.anchor.end.offset === o.end.mapped.offset && (i.anchor.quote ?? "") === o.quote && (i.anchor.beforeQuote ?? "") === o.beforeQuote && (i.anchor.afterQuote ?? "") === o.afterQuote);
  });
}, it = (e, t) => ({
  valid: !1,
  diagnostic: ae({
    code: t,
    stage: "effect-proof",
    path: e
  })
}), ad = (e) => {
  const t = Nr(e.base), n = Nr(e.runtime.resultDocument), r = new Map(t.map((x) => [x.id, x])), i = new Map(n.map((x) => [x.id, x])), o = e.plan.steps.map((x) => {
    const R = od(x);
    return {
      operationIndex: x.operationIndex,
      baseBlockIds: Gi(
        R.filter((A) => r.has(A)),
        t
      ),
      resultBlockIds: Gi(
        R.filter((A) => i.has(A)),
        n
      )
    };
  }), s = new Set(
    o.flatMap((x) => x.baseBlockIds)
  ), a = new Set(
    o.flatMap((x) => x.resultBlockIds)
  ), c = new Map(
    o.map((x) => [x.operationIndex, x])
  ), l = e.runtime.trace.entries.map((x) => {
    const R = Ds(
      x.sourceAttribution.operationIndexes.flatMap((A) => {
        const X = c.get(A);
        return X ? [...X.baseBlockIds, ...X.resultBlockIds] : [];
      })
    );
    return {
      sequence: x.sequence,
      kind: x.kind,
      owner: x.sourceAttribution.owner,
      pluginInstanceId: x.sourceAttribution.pluginInstanceId,
      operationIndexes: x.sourceAttribution.operationIndexes,
      visibleTransactionRange: x.sourceAttribution.visibleTransactionRange,
      documentChanged: x.beforeDocumentFingerprint !== x.afterDocumentFingerprint,
      attributedBlockIds: R,
      safeEffectFingerprints: x.safeEffects.map(
        (A) => A.fingerprint
      )
    };
  });
  if (l.some(
    (x) => x.kind === "appended" && x.documentChanged && x.attributedBlockIds.length === 0
  ))
    return it(
      "$.runtimeOutcome.trace.entries",
      "proposal-effect-proof-invalid"
    );
  const g = t.filter((x) => !i.has(x.id)), f = n.filter((x) => !r.has(x.id));
  if (g.some((x) => !s.has(x.id)) || f.some((x) => !a.has(x.id)))
    return it(
      "$.runtimeOutcome.resultDocument.body",
      "proposal-document-drift"
    );
  const p = t.filter(
    (x) => !s.has(x.id) && i.has(x.id)
  );
  if (p.some(
    (x) => {
      var R;
      return ((R = i.get(x.id)) == null ? void 0 : R.fingerprint) !== x.fingerprint;
    }
  ))
    return it("$.effectProof.untouched", "proposal-document-drift");
  const d = p.map((x) => x.id), h = new Set(d), m = n.filter((x) => h.has(x.id)).map((x) => x.id);
  if (!M(d, m))
    return it("$.effectProof.relativeOrder", "proposal-document-drift");
  if (!M(e.base.assets, e.runtime.resultDocument.assets) || !M(e.base.meta, e.runtime.resultDocument.meta))
    return it("$.runtimeOutcome.resultDocument", "proposal-document-drift");
  if (!sd(
    e.base,
    e.runtime.resultDocument,
    e.runtime
  ))
    return it(
      "$.runtimeOutcome.mapping.annotations",
      "proposal-effect-proof-invalid"
    );
  const y = p.map((x) => ({
    blockId: x.id,
    fingerprint: x.fingerprint
  })), b = new Map(
    e.runtime.resultDocument.annotations.map((x) => [
      x.id,
      x
    ])
  ), k = e.base.annotations.filter((x) => {
    const R = b.get(x.id);
    return !!(R && !s.has(x.anchor.start.blockId) && !s.has(x.anchor.end.blockId) && !a.has(R.anchor.start.blockId) && !a.has(R.anchor.end.blockId));
  });
  if (k.some(
    (x) => !M(x, b.get(x.id))
  ))
    return it(
      "$.runtimeOutcome.resultDocument.annotations",
      "proposal-document-drift"
    );
  const w = k.map(
    (x) => ({
      annotationId: x.id,
      fingerprint: v(x)
    })
  ), I = {
    kind: "zx-ai-proposal-effect-proof-v1",
    version: "1.0.0",
    operationScopes: o,
    traceAttribution: l,
    untouchedBlockFingerprints: y,
    untouchedAnnotationFingerprints: w,
    untouchedProjectionFingerprint: D(
      "zx-ai-proposal-untouched-projection:v1",
      y
    ),
    relativeOrderFingerprint: D(
      "zx-ai-proposal-relative-order:v1",
      m
    ),
    annotationProjectionFingerprint: D(
      "zx-ai-proposal-annotation-projection:v1",
      e.runtime.mapping.annotations
    ),
    assetsMetaUnchanged: !0
  };
  return {
    valid: !0,
    proof: {
      ...I,
      fingerprint: D(
        "zx-ai-proposal-effect-proof:v1",
        I
      )
    }
  };
}, Tt = /* @__PURE__ */ new Map(), Ct = /* @__PURE__ */ new Map(), Dt = (e) => D("zx-ai-proposal-lifecycle:v1", {
  proposalId: e.proposalId,
  revision: e.revision,
  status: e.status
}), Bt = (e) => !S(e, ["proposalId", "revision", "status", "fingerprint"]) || !E(e.proposalId) || !G(e.revision) || !["active", "committed", "discarded"].includes(String(e.status)) || typeof e.fingerprint != "string" ? !1 : e.fingerprint === Dt({
  proposalId: e.proposalId,
  revision: e.revision,
  status: e.status
}), cd = (e) => {
  if (!S(e, ["proposalId", "revision"]) || !E(e.proposalId) || !G(e.revision))
    throw new TypeError("proposal-lifecycle-input-invalid");
  const t = {
    proposalId: e.proposalId,
    revision: e.revision,
    status: "active"
  }, n = u({
    ...t,
    fingerprint: Dt(t)
  });
  return Tt.has(n.proposalId) || Tt.set(n.proposalId, n), n;
}, oi = (e) => {
  var t;
  return Bt(e) && ((t = Tt.get(e.proposalId)) == null ? void 0 : t.fingerprint) === e.fingerprint;
}, ff = (e) => E(e) ? Tt.get(e) ?? null : null, tt = (e) => ae({
  code: "proposal-lifecycle-invalid",
  stage: "lifecycle",
  path: e
}), Ns = (e, t) => {
  if (!Bt(t) || t.revision >= Number.MAX_SAFE_INTEGER)
    return { status: "failure", intent: null };
  if (!oi(t) || t.status !== "active")
    return { status: "conflict", intent: null };
  const n = Pt(t), r = {
    kind: `zx-ai-proposal-${e}-intent-v1`,
    version: "1.0.0",
    proposalId: n.proposalId,
    expectedRevision: n.revision,
    expectedFingerprint: n.fingerprint,
    candidateRevision: n.revision + 1
  }, i = u({
    ...r,
    fingerprint: D(
      `zx-ai-proposal-${e}-intent:v1`,
      r
    )
  }), o = Ct.get(i.proposalId);
  return o ? o.kind === e && o.intentFingerprint === i.fingerprint ? { status: "success", intent: i } : { status: "conflict", intent: null } : (Ct.set(i.proposalId, {
    kind: e,
    intentFingerprint: i.fingerprint
  }), { status: "success", intent: i });
}, ld = (e) => {
  if (!S(e, ["lifecycle"]))
    return u({
      status: "failure",
      intent: null,
      diagnostic: tt("$")
    });
  const t = Ns("commit", e.lifecycle);
  return t.status === "success" ? u({
    status: "success",
    intent: t.intent
  }) : u({
    status: t.status,
    intent: null,
    diagnostic: tt("$.lifecycle")
  });
}, uf = (e) => {
  if (!S(e, ["lifecycle"]))
    return u({
      status: "failure",
      intent: null,
      diagnostic: tt("$")
    });
  const t = Ns("discard", e.lifecycle);
  return t.status === "success" ? u({
    status: "success",
    intent: t.intent
  }) : u({
    status: t.status,
    intent: null,
    diagnostic: tt("$.lifecycle")
  });
}, Ms = (e, t) => {
  if (!S(e, [
    "kind",
    "version",
    "proposalId",
    "expectedRevision",
    "expectedFingerprint",
    "candidateRevision",
    "fingerprint"
  ]) || e.kind !== `zx-ai-proposal-${t}-intent-v1` || e.version !== "1.0.0" || !E(e.proposalId) || !G(e.expectedRevision) || !E(e.expectedFingerprint) || e.candidateRevision !== e.expectedRevision + 1 || !E(e.fingerprint))
    return !1;
  const { fingerprint: n, ...r } = e;
  return e.fingerprint === D(`zx-ai-proposal-${t}-intent:v1`, r);
}, zs = (e, t) => {
  if (!Ms(e, t))
    return { status: "failure", lifecycle: null };
  const n = Tt.get(e.proposalId), r = Ct.get(e.proposalId);
  if (!n || n.status !== "active" || n.revision !== e.expectedRevision || n.fingerprint !== e.expectedFingerprint || (r == null ? void 0 : r.kind) !== t || r.intentFingerprint !== e.fingerprint)
    return { status: "conflict", lifecycle: null };
  const i = t === "commit" ? "committed" : "discarded", o = u({
    proposalId: e.proposalId,
    revision: e.candidateRevision,
    status: i,
    fingerprint: Dt({
      proposalId: e.proposalId,
      revision: e.candidateRevision,
      status: i
    })
  });
  return Tt.set(o.proposalId, o), Ct.delete(o.proposalId), { status: i, lifecycle: o };
}, mr = (e) => {
  if (!S(e, ["intent"]))
    return u({
      status: "failure",
      lifecycle: null,
      diagnostic: tt("$")
    });
  const t = zs(e.intent, "commit");
  return t.status === "committed" ? u({
    status: "committed",
    lifecycle: t.lifecycle
  }) : u({
    status: t.status === "conflict" ? "conflict" : "failure",
    lifecycle: null,
    diagnostic: tt("$.intent.expectedRevision")
  });
}, gf = (e) => {
  if (!S(e, ["intent"]))
    return u({
      status: "failure",
      lifecycle: null,
      diagnostic: tt("$")
    });
  const t = zs(e.intent, "discard");
  return t.status === "discarded" ? u({
    status: "discarded",
    lifecycle: t.lifecycle
  }) : u({
    status: t.status === "conflict" ? "conflict" : "failure",
    lifecycle: null,
    diagnostic: tt("$.intent.expectedRevision")
  });
}, dd = (e) => {
  if (!S(e, ["intent"])) return !1;
  const t = e.intent.kind === "zx-ai-proposal-commit-intent-v1" ? "commit" : e.intent.kind === "zx-ai-proposal-discard-intent-v1" ? "discard" : null;
  if (!t || !Ms(e.intent, t)) return !1;
  const n = Ct.get(e.intent.proposalId);
  return (n == null ? void 0 : n.kind) !== t || n.intentFingerprint !== e.intent.fingerprint ? !1 : (Ct.delete(e.intent.proposalId), !0);
}, Nt = {
  kind: "derived-view-profile",
  id: "zx.ai.proposal-rich-diff",
  version: "1.0.0",
  dependencies: [],
  algorithm: "operation-bound-structural-diff-v1",
  limits: Hn
}, St = u({
  kind: Nt.kind,
  id: Nt.id,
  version: Nt.version,
  dependencies: Nt.dependencies,
  fingerprint: D(
    "zx-ai-proposal-rich-diff-profile:v1",
    Nt
  )
}), mf = u({
  owner: "S4-versioned-review-policy",
  hunkPartialAccept: !1,
  operationPartialAccept: !1,
  hunkPartialReject: !1,
  operationPartialReject: !1,
  wholeProposalAcceptWithoutIndependentWholeReview: !1,
  allowedWithoutIndependentWholeReview: ["reject", "regenerate"]
}), Mt = (e, t, n) => u({
  status: "unavailable",
  profileRef: St,
  sourceBinding: e,
  reason: t,
  safeDiagnostic: {
    code: n,
    stage: "proposal-rich-diff",
    path: "$.proposal.richDiff",
    componentId: St.id
  }
}), Zi = (e, t) => {
  let n = null;
  const r = (i) => {
    if (n || !i || typeof i != "object" || Array.isArray(i))
      return;
    const o = i;
    if (o.attrs && typeof o.attrs == "object" && !Array.isArray(o.attrs) && o.attrs.blockId === t) {
      n = o;
      return;
    }
    Array.isArray(o.content) && o.content.forEach(r);
  };
  return r(e), n;
}, Mr = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return "";
  const t = e;
  return (typeof t.text == "string" ? t.text : "") + (Array.isArray(t.content) ? t.content.map(Mr).join("") : "");
}, Yi = (e) => {
  const t = [], n = (r) => {
    if (!r || typeof r != "object" || Array.isArray(r)) return;
    const i = r;
    Array.isArray(i.marks) && t.push(i.marks), Array.isArray(i.content) && i.content.forEach(n);
  };
  return n(e), t;
}, Qi = (e) => !!(e && typeof e.type == "string" && [
  "table",
  "tableRow",
  "tableCell",
  "codeBlock",
  "image",
  "video"
].includes(e.type)), pd = (e) => {
  switch (e) {
    case "text":
      return "Text content changed";
    case "mark":
      return "Inline formatting changed";
    case "node-type":
      return "Block type changed";
    case "node-attrs":
      return "Allowed block attributes changed";
    case "block-insert":
      return "Block inserted";
    case "block-delete":
      return "Block deleted";
    case "block-replace":
      return "Block replaced";
    case "complex-summary":
      return "Complex block changed";
  }
}, fd = (e, t, n) => {
  if (e === "text.replace") return ["text"];
  if (e === "block.insert") return ["block-insert"];
  if (e === "block.delete") return ["block-delete"];
  if (Qi(t) || Qi(n))
    return ["complex-summary"];
  const r = [];
  return (t == null ? void 0 : t.type) !== (n == null ? void 0 : n.type) && r.push("node-type"), M((t == null ? void 0 : t.attrs) ?? null, (n == null ? void 0 : n.attrs) ?? null) || r.push("node-attrs"), M(Yi(t), Yi(n)) || r.push("mark"), Mr(t) !== Mr(n) && r.push("text"), r.length > 0 ? r : ["block-replace"];
}, ud = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return null;
  const t = e.attrs;
  return t && typeof t == "object" && !Array.isArray(t) ? t.blockId ?? null : null;
}, gd = (e) => ("target" in e ? e.target.blockId : null) ?? ("block" in e ? ud(e.block) : null) ?? ("reference" in e ? e.reference.blockId : null) ?? `operation-${e.operationIndex}`, md = (e) => Number.isSafeInteger(e) && e >= 0 && e <= Hn.maxHunks, hd = (e) => Ps(e) <= Hn.maxOutputBytes, yd = (e) => {
  var n, r, i, o, s;
  const t = u({
    executionSemanticsFingerprint: ((r = (n = e == null ? void 0 : e.runtimeExecution) == null ? void 0 : n.runtime) == null ? void 0 : r.executionSemanticsFingerprint) ?? "sha256:unavailable",
    resultFingerprint: ((i = e == null ? void 0 : e.runtimeExecution) == null ? void 0 : i.resultFingerprint) ?? "sha256:unavailable",
    traceFingerprint: ((s = (o = e == null ? void 0 : e.runtimeExecution) == null ? void 0 : o.trace) == null ? void 0 : s.fingerprint) ?? "sha256:unavailable"
  });
  try {
    if (!e || e.kind !== "zx-ai-proposal-artifact-v1" || e.runtimeExecution.status !== "success" || !Wn(e) || !M(
      e.runtimeExecution.runtime.manifestRef,
      Ee
    ) || !M(
      e.descriptor.runtimeManifestRef,
      e.runtimeExecution.runtime.manifestRef
    ) || e.runtimeExecution.resultFingerprint !== v(e.runtimeExecution.resultDocument) || e.runtimeExecution.trace.resultFingerprint !== e.runtimeExecution.resultFingerprint || e.runtimeExecution.trace.fingerprint !== v(
      Ot(e.runtimeExecution.trace)
    ) || !M(
      e.runtimeExecution.trace.mapping,
      e.runtimeExecution.mapping
    ) || !M(
      e.runtimeExecution.trace.resources,
      e.runtimeExecution.resources
    ) || e.journal.sourceBinding.traceFingerprint !== e.runtimeExecution.trace.fingerprint)
      return Mt(
        t,
        "unsupported-runtime",
        "runtime-component-unsupported"
      );
    if (Ps(e) > Hn.maxInputBytes)
      return Mt(
        t,
        "resource-limit-exceeded",
        "trace-byte-budget-exceeded"
      );
    const a = [];
    if (e.operationProjection.forEach((m) => {
      const y = e.base.plan.steps[m.operationIndex], b = gd(y), k = Zi(e.base.document.body.content, b), w = Zi(
        e.runtimeExecution.resultDocument.body.content,
        b
      );
      fd(y.kind, k, w).forEach((I, x) => {
        const A = {
          id: D("zx-ai-proposal-rich-diff-hunk-id:v1", {
            profile: St.fingerprint,
            sourceBinding: t,
            proposal: e.identity,
            operationIndex: m.operationIndex,
            blockId: b,
            kind: I,
            ordinal: x
          }),
          operationIndex: m.operationIndex,
          blockId: b,
          kind: I,
          ordinal: x,
          beforeFingerprint: k ? D("zx-ai-proposal-diff-before:v1", k) : null,
          afterFingerprint: w ? D("zx-ai-proposal-diff-after:v1", w) : null,
          summary: pd(I)
        };
        a.push({
          ...A,
          fingerprint: D(
            "zx-ai-proposal-rich-diff-hunk:v1",
            A
          )
        });
      });
    }), !md(a.length))
      return Mt(
        t,
        "resource-limit-exceeded",
        "trace-byte-budget-exceeded"
      );
    const c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map();
    a.forEach((m) => {
      const y = c.get(m.operationIndex) ?? [];
      y.push(m.id), c.set(m.operationIndex, y);
      const b = l.get(m.blockId) ?? [];
      b.push(m.id), l.set(m.blockId, b);
    });
    const g = [...c.entries()].sort(([m], [y]) => m - y).map(([m, y]) => ({ operationIndex: m, hunkIds: y })), f = [...l.entries()].sort(([m], [y]) => m.localeCompare(y)).map(([m, y]) => ({ blockId: m, hunkIds: y })), p = {
      kind: "zx-ai-proposal-rich-diff-v1",
      version: "1.0.0",
      profileRef: St,
      sourceBinding: t,
      hunks: a,
      operationToHunks: g,
      blockToHunks: f
    }, d = {
      ...p,
      fingerprint: D(
        "zx-ai-proposal-rich-diff:v1",
        p
      )
    }, h = {
      status: "available",
      profileRef: St,
      sourceBinding: t,
      value: d
    };
    return hd(h) ? u({
      ...h,
      fingerprint: D(
        "zx-ai-proposal-rich-diff-outcome:v1",
        h
      )
    }) : Mt(
      t,
      "resource-limit-exceeded",
      "trace-byte-budget-exceeded"
    );
  } catch {
    return Mt(
      t,
      "derivation-failed",
      "runtime-fingerprint-mismatch"
    );
  }
}, eo = [
  "inputBytes",
  "inputDepth",
  "inputKeys",
  "documentNodes",
  "documentMarks",
  "documentBlocks",
  "annotations",
  "planOperations",
  "executionPlugins",
  "rootSteps",
  "steps",
  "transactions",
  "filterCalls",
  "appendCalls",
  "appendRounds",
  "mappingMaps",
  "mappingRanges",
  "mappingBytes",
  "mappingMirrors",
  "mappingMirrorBytes",
  "metaBytes",
  "traceBytes",
  "pluginStateBytes",
  "safeDiagnosticCount",
  "safeDiagnosticBytes"
], Nn = (e) => S(e, ["kind", "id", "version", "fingerprint"]) && [
  "schema-semantics",
  "operation-protocol",
  "execution-closure",
  "mapping-policy",
  "transaction-policy",
  "resource-profile",
  "derived-view-profile"
].includes(String(e.kind)) && E(e.id) && E(e.version) && E(e.fingerprint), Xn = (e) => S(e, [
  "kind",
  "id",
  "version",
  "fingerprint",
  "dependencies"
]) && Nn({
  kind: e.kind,
  id: e.id,
  version: e.version,
  fingerprint: e.fingerprint
}) && Array.isArray(e.dependencies) && e.dependencies.every(Nn), $s = (e) => S(e, eo) && eo.every((t) => G(e[t])), Vs = (e) => S(e, [
  "pluginInstanceId",
  "projectorRef",
  "beforeFingerprint",
  "afterFingerprint",
  "value"
]) && E(e.pluginInstanceId) && (Nn(e.projectorRef) || Xn(e.projectorRef)) && E(e.beforeFingerprint) && E(e.afterFingerprint) && e.afterFingerprint === v(e.value), to = (e) => S(e, [
  "original",
  "mapped",
  "assoc",
  "deleted",
  "deletedBefore",
  "deletedAfter",
  "deletedAcross",
  "fingerprint"
]) && S(e.original, ["blockId", "offset"]) && S(e.mapped, ["blockId", "offset"]) && E(e.original.blockId) && E(e.mapped.blockId) && G(e.original.offset) && G(e.mapped.offset) && (e.assoc === 1 || e.assoc === -1) && ["deleted", "deletedBefore", "deletedAfter", "deletedAcross"].every(
  (t) => typeof e[t] == "boolean"
) && e.fingerprint === v(Ot(e)), bd = (e) => !S(e, [
  "policyRef",
  "mapOrder",
  "mapRangeCounts",
  "mirrorPairs",
  "annotations",
  "fingerprint"
]) || !Xn(e.policyRef) || !Array.isArray(e.mapOrder) || !e.mapOrder.every(E) || !Array.isArray(e.mapRangeCounts) || !e.mapRangeCounts.every(G) || e.mapOrder.length !== e.mapRangeCounts.length || !Array.isArray(e.mirrorPairs) || !e.mirrorPairs.every(
  (n) => Array.isArray(n) && n.length === 2 && G(n[0]) && G(n[1])
) || !Array.isArray(e.annotations) ? !1 : e.annotations.every(
  (n) => S(n, [
    "annotationId",
    "status",
    "start",
    "end",
    "quote",
    "beforeQuote",
    "afterQuote",
    "fingerprint"
  ]) && E(n.annotationId) && n.status === "mapped" && to(n.start) && to(n.end) && typeof n.quote == "string" && typeof n.beforeQuote == "string" && typeof n.afterQuote == "string" && n.fingerprint === v(Ot(n))
) && e.fingerprint === v(Ot(e)), xd = (e, t) => {
  if (!S(e, [
    "kind",
    "sequence",
    "logicalTime",
    "rootExecutionId",
    "sourceAttribution",
    "operationSpans",
    "steps",
    "allowedMeta",
    "beforeDocumentFingerprint",
    "afterDocumentFingerprint",
    "selectionAndStoredMarksProof",
    "pluginState",
    "safeEffects",
    "resourceDelta",
    "fingerprint"
  ]) || e.kind !== "root" && e.kind !== "appended" || !G(e.sequence) || !G(e.logicalTime) || !E(e.rootExecutionId) || !S(e.sourceAttribution, [
    "owner",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || !["operation-compiler", "certified-plugin"].includes(
    String(e.sourceAttribution.owner)
  ) || !Array.isArray(e.sourceAttribution.visibleTransactionRange) || e.sourceAttribution.visibleTransactionRange.length !== 2 || !e.sourceAttribution.visibleTransactionRange.every(G) || !Array.isArray(e.sourceAttribution.operationIndexes) || !e.sourceAttribution.operationIndexes.every(G) || !Array.isArray(e.operationSpans) || !e.operationSpans.every(
    (s) => S(
      s,
      ["operationIndex", "stepStart", "stepEnd"],
      ["noOpReason"]
    ) && G(s.operationIndex) && G(s.stepStart) && G(s.stepEnd) && s.stepStart <= s.stepEnd && (!Object.hasOwn(s, "noOpReason") || s.noOpReason === "already-equal")
  ) || !Array.isArray(e.steps) || !e.steps.every(
    (s) => S(s, ["json", "fingerprint", "mapFingerprint"]) && et(s.json) && s.fingerprint === v(s.json) && E(s.mapFingerprint) && t.has(s.mapFingerprint)
  ) || !et(e.allowedMeta) || !E(e.beforeDocumentFingerprint) || !E(e.afterDocumentFingerprint) || !S(e.selectionAndStoredMarksProof, [
    "selectionSet",
    "storedMarksSet"
  ]) || e.selectionAndStoredMarksProof.selectionSet !== !1 || e.selectionAndStoredMarksProof.storedMarksSet !== !1 || !Array.isArray(e.pluginState) || !e.pluginState.every(Vs) || !Array.isArray(e.safeEffects) || !e.safeEffects.every(
    (s) => S(s, ["effectRef", "kind", "fingerprint"]) && (Nn(s.effectRef) || Xn(s.effectRef)) && s.kind === "observational" && E(s.fingerprint)
  ) || !$s(e.resourceDelta))
    return !1;
  const n = e.sourceAttribution, r = n.visibleTransactionRange, i = e.allowedMeta["zx.runtime.root.v2"], o = e.allowedMeta["zx.runtime.appended.v2"];
  return e.kind === "root" && (n.owner !== "operation-compiler" || n.pluginInstanceId !== null || n.pluginOrder !== null || !M(n.visibleTransactionRange, [0, 0]) || !M(
    n.operationIndexes,
    e.operationSpans.map(
      (s) => s.operationIndex
    )
  ) || !S(e.allowedMeta, ["zx.runtime.root.v2"]) || !S(i, [
    "protocol",
    "executionId",
    "sequence",
    "compilerRef",
    "operationSpans"
  ]) || i.protocol !== "zx-runtime-root-meta-v2" || i.executionId !== e.rootExecutionId || i.sequence !== e.sequence || !E(i.compilerRef) || !M(i.operationSpans, e.operationSpans)) || e.kind === "appended" && (n.owner !== "certified-plugin" || !E(n.pluginInstanceId) || !G(n.pluginOrder) || e.operationSpans.length !== 0 || r[0] > r[1] || r[1] >= e.sequence || !S(e.allowedMeta, ["zx.runtime.appended.v2"]) || !S(o, [
    "protocol",
    "rootExecutionId",
    "sequence",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || o.protocol !== "zx-runtime-appended-meta-v2" || o.rootExecutionId !== e.rootExecutionId || o.sequence !== e.sequence || o.pluginInstanceId !== n.pluginInstanceId || o.pluginOrder !== n.pluginOrder || !M(
    o.visibleTransactionRange,
    n.visibleTransactionRange
  ) || !M(o.operationIndexes, n.operationIndexes)) ? !1 : e.fingerprint === v(
    Ot(
      e
    )
  );
}, hr = (e) => {
  var i;
  const t = "target" in e ? [e.target.blockId] : [], n = "reference" in e ? [e.reference.blockId] : [], r = "block" in e && e.block && typeof e.block == "object" && typeof ((i = e.block.attrs) == null ? void 0 : i.blockId) == "string" ? [e.block.attrs.blockId] : [];
  return [.../* @__PURE__ */ new Set([...t, ...n, ...r])].sort();
}, Id = (e, t) => {
  const n = t.operationSpans, r = e.steps.map((c) => c.operationIndex), i = n.map((c) => c.operationIndex);
  if (new Set(r).size !== r.length || r.some((c, l) => c !== l) || !M(r, i))
    return null;
  let o = 0;
  const s = [], a = /* @__PURE__ */ new Map();
  e.steps.forEach((c) => {
    const l = hr(c), g = e.steps.slice(0, c.operationIndex).filter(
      (f) => hr(f).some((p) => l.includes(p))
    ).map((f) => f.operationIndex);
    a.set(c.operationIndex, g);
  });
  for (const [c, l] of n.entries()) {
    const g = e.steps[c], f = l.stepStart, p = l.stepEnd;
    if (f !== o || p > t.steps.length)
      return null;
    o = p, s.push({
      operationIndex: g.operationIndex,
      kind: g.kind,
      blockIds: hr(g),
      stepStart: f,
      stepEnd: p,
      ...l.noOpReason === "already-equal" ? { noOpReason: "already-equal" } : {},
      intentDigest: v({
        domain: "zx-ai-proposal-operation-intent:v1",
        step: g
      }),
      dependencyOperationIndexes: a.get(g.operationIndex) ?? []
    });
  }
  return o !== t.steps.length ? null : s;
}, It = (e, t, n) => ({
  valid: !1,
  diagnostic: ae({ code: e, stage: t, path: n })
}), vd = (e, t, n, r) => {
  var f, p;
  const i = Jn();
  if (!Wn(r))
    return It(
      "proposal-runtime-outcome-invalid",
      "runtime",
      "$.runtimeOutcome"
    );
  if (!S(r, [
    "status",
    "runtime",
    "resultDocument",
    "resultFingerprint",
    "trace",
    "mapping",
    "pluginState",
    "resources",
    "replayEligibility"
  ]) || r.status !== "success" || r.replayEligibility !== "exact-runtime-only" || !S(r.runtime, [
    "manifestRef",
    "executionSemanticsFingerprint",
    "observationalProfileFingerprint",
    "derivedViewFingerprint",
    "adapterRef",
    "conformanceReceiptRefs",
    "conformanceEnvironmentReceiptRefs"
  ]) || !M(r.runtime.manifestRef, e) || e.fingerprint !== i.fingerprints.runtimeManifestFingerprint || r.runtime.executionSemanticsFingerprint !== i.fingerprints.executionSemanticsFingerprint || r.runtime.observationalProfileFingerprint !== i.fingerprints.observationalProfileFingerprint || r.runtime.derivedViewFingerprint !== i.fingerprints.derivedViewFingerprint || !M(
    r.runtime.adapterRef,
    i.executionClosure
  ) || !Xn(r.runtime.adapterRef) || !Array.isArray(r.runtime.conformanceReceiptRefs) || r.runtime.conformanceReceiptRefs.length === 0 || !r.runtime.conformanceReceiptRefs.every(E) || !Array.isArray(r.runtime.conformanceEnvironmentReceiptRefs) || r.runtime.conformanceEnvironmentReceiptRefs.length === 0 || !r.runtime.conformanceEnvironmentReceiptRefs.every(
    (d) => S(d, [
      "environment",
      "adapterExecutionIdentity",
      "matrixRowFingerprint"
    ]) && E(d.environment) && E(d.adapterExecutionIdentity) && E(d.matrixRowFingerprint)
  ) || !In(r.resultDocument).valid || r.resultFingerprint !== v(r.resultDocument) || !$s(r.resources) || !Array.isArray(r.pluginState) || !r.pluginState.every(Vs))
    return It(
      "proposal-runtime-binding-mismatch",
      "runtime",
      "$.runtimeOutcome"
    );
  if (!S(r.trace, [
    "version",
    "executionId",
    "manifest",
    "entries",
    "mapping",
    "resources",
    "resultFingerprint",
    "fingerprint"
  ]) || r.trace.version !== "runtime-execution-trace-v2" || !E(r.trace.executionId) || !S(r.trace.manifest, [
    "runtimeManifestFingerprint",
    "executionSemanticsFingerprint",
    "observationalProfileFingerprint",
    "derivedViewFingerprint"
  ]) || r.trace.manifest.runtimeManifestFingerprint !== e.fingerprint || r.trace.manifest.executionSemanticsFingerprint !== r.runtime.executionSemanticsFingerprint || r.trace.manifest.observationalProfileFingerprint !== r.runtime.observationalProfileFingerprint || r.trace.manifest.derivedViewFingerprint !== r.runtime.derivedViewFingerprint || r.trace.resultFingerprint !== r.resultFingerprint || !bd(r.mapping) || !M(r.trace.mapping, r.mapping) || !M(r.trace.resources, r.resources) || r.trace.fingerprint !== v(Ot(r.trace)) || !Array.isArray(r.trace.entries) || r.trace.entries.length === 0)
    return It("proposal-trace-invalid", "trace", "$.runtimeOutcome.trace");
  const o = new Set(r.mapping.mapOrder), s = r.trace.entries, a = s.flatMap(
    (d) => d.steps.map((h) => h.mapFingerprint)
  ), c = s.every((d, h) => {
    if (d.pluginState.length === 0) return !1;
    if (h === 0) return !0;
    const m = s[h - 1].pluginState;
    return d.pluginState.length === m.length && d.pluginState.every(
      (y, b) => y.pluginInstanceId === m[b].pluginInstanceId && y.projectorRef.fingerprint === m[b].projectorRef.fingerprint && y.beforeFingerprint === m[b].afterFingerprint
    );
  });
  if (!s.every((d) => xd(d, o)) || !c || s[0].beforeDocumentFingerprint !== v(t.body.content) || ((f = s.at(-1)) == null ? void 0 : f.afterDocumentFingerprint) !== v(r.resultDocument.body.content) || !M(a, r.mapping.mapOrder) || !M(r.pluginState, (p = s.at(-1)) == null ? void 0 : p.pluginState) || r.resources.transactions !== s.length || r.resources.rootSteps !== s[0].steps.length || r.resources.steps !== a.length || r.resources.mappingMaps !== r.mapping.mapOrder.length || r.resources.mappingRanges !== r.mapping.mapRangeCounts.reduce(
    (d, h) => d + h,
    0
  ) || r.resources.mappingMirrors !== r.mapping.mirrorPairs.length || r.resources.planOperations !== n.steps.length || r.resources.executionPlugins !== r.pluginState.length || s.some(
    (d, h) => d.sequence !== h || d.logicalTime !== h || d.rootExecutionId !== r.trace.executionId
  ) || s[0].kind !== "root" || s.slice(1).some((d) => d.kind !== "appended") || s.some(
    (d, h) => h > 0 && d.beforeDocumentFingerprint !== s[h - 1].afterDocumentFingerprint
  ))
    return It(
      "proposal-trace-invalid",
      "trace",
      "$.runtimeOutcome.trace.entries"
    );
  const l = n.steps.map((d) => d.operationIndex);
  if (s.some((d) => {
    const h = d.sourceAttribution.operationIndexes;
    return h.some((m) => !l.includes(m)) || h.some(
      (m, y) => y > 0 && h[y - 1] >= m
    );
  }))
    return It(
      "proposal-operation-projection-invalid",
      "trace",
      "$.runtimeOutcome.trace.entries"
    );
  const g = Id(
    n,
    s[0]
  );
  return g ? { valid: !0, operationProjection: g } : It(
    "proposal-operation-projection-invalid",
    "trace",
    "$.runtimeOutcome.trace.entries[0].operationSpans"
  );
}, kd = (e) => S(e, ["proposalId", "variantId"], ["parentVariantId"]) && E(e.proposalId) && E(e.variantId) && (!Object.hasOwn(e, "parentVariantId") || E(e.parentVariantId)), wd = (e) => S(e, ["sourceId", "sequence", "refs"], ["timestamp"]) && E(e.sourceId) && G(e.sequence) && (!Object.hasOwn(e, "timestamp") || E(e.timestamp)) && Array.isArray(e.refs) && e.refs.every(
  (t) => S(t, ["id", "type"]) && E(t.id) && ["entity", "activity", "agent", "plan"].includes(String(t.type))
), Fd = (e) => S(e, ["kind", "version", "fingerprint"]) && e.kind === "zx-text-editor-runtime-manifest-v2" && e.version === "2.0.0" && E(e.fingerprint), Rd = (e) => S(e, ["protocol"], ["intentRef"]) && e.protocol === "zx-runtime-execution-context-v1" && (!Object.hasOwn(e, "intentRef") || S(e.intentRef, ["id", "version", "fingerprint"]) && E(e.intentRef.id) && E(e.intentRef.version) && E(e.intentRef.fingerprint)), Sd = (e) => !!(e && typeof e == "object" && !Array.isArray(e) && Array.isArray(e.steps) && e.steps.some(
  (t) => !!(t && typeof t == "object" && !Array.isArray(t)) && (t.kind === "block.move" || Object.keys(t).some(
    (n) => ["move", "moveOnly", "moveMetadata", "moveKind"].includes(n)
  ))
)), Ad = (e) => S(e, [
  "runtime",
  "baseDocument",
  "plan",
  "identity",
  "lifecycle",
  "provenance",
  "runtimeContext"
]) && Fd(e.runtime) && kd(e.identity) && Bt(e.lifecycle) && e.lifecycle.status === "active" && e.lifecycle.proposalId === e.identity.proposalId && wd(e.provenance) && Rd(e.runtimeContext) && !!(e.baseDocument && typeof e.baseDocument == "object") && !!(e.plan && typeof e.plan == "object"), Ed = (e) => {
  const t = {
    kind: "zx-ai-proposal-artifact-descriptor-v1",
    version: "1.0.0",
    envelopeRef: "zx-ai-proposal-artifact-v1",
    codecRef: "zx-ai-proposal-canonical-codec-v1",
    effectProofRef: "zx-ai-proposal-effect-proof-v1",
    richDiffProfileRef: St,
    semanticRecipeSchemaRef: "zx-ai-proposal-semantic-recipe-v1",
    lifecycleSchemaRef: "zx-ai-proposal-lifecycle-receipt-v1",
    runtimeManifestRef: e,
    runtimeTraceContractRef: "runtime-execution-trace-v2",
    forbiddenAuthorities: [
      "operation-compiler",
      "plugin-closure",
      "mapping-policy",
      "resource-ledger",
      "transaction-semantics"
    ]
  };
  return u({
    ...t,
    fingerprint: D(
      "zx-ai-proposal-artifact-descriptor:v1",
      t
    )
  });
}, _s = /* @__PURE__ */ new WeakSet(), Ls = (e) => typeof e == "object" && e !== null && _s.has(e), si = (e, t) => {
  try {
    const n = vd(
      e.runtime,
      e.baseDocument,
      e.plan,
      t
    );
    if (!n.valid) return n;
    const r = ad({
      base: e.baseDocument,
      plan: e.plan,
      runtime: t
    });
    if (!r.valid) return r;
    const i = D(
      "zx-ai-proposal-identity:v1",
      e.identity
    ), o = D(
      "zx-ai-proposal-base-document:v1",
      e.baseDocument
    ), s = D("zx-ai-proposal-plan:v1", e.plan), a = D("zx-ai-proposal-input:v1", {
      runtime: e.runtime,
      baseFingerprint: o,
      planDigest: s,
      identity: e.identity,
      lifecycle: e.lifecycle,
      provenance: e.provenance,
      runtimeContext: e.runtimeContext
    }), c = {
      kind: "zx-ai-proposal-journal-v1",
      version: "1.0.0",
      sourceBinding: {
        executionSemanticsFingerprint: t.runtime.executionSemanticsFingerprint,
        resultFingerprint: t.resultFingerprint,
        traceFingerprint: t.trace.fingerprint
      },
      trace: t.trace,
      proposalIdentityFingerprint: i,
      baseFingerprint: o,
      planDigest: s,
      lifecycleRevision: e.lifecycle.revision
    }, l = {
      ...c,
      fingerprint: D(
        "zx-ai-proposal-journal:v1",
        c
      )
    }, g = {
      document: e.baseDocument,
      fingerprint: o,
      documentRevision: e.plan.source.documentRevision,
      annotationFingerprint: D(
        "zx-ai-proposal-annotations:v1",
        e.baseDocument.annotations
      ),
      targetFingerprint: js(
        e.baseDocument,
        n.operationProjection
      ),
      plan: e.plan,
      planDigest: s,
      runtimeContext: e.runtimeContext,
      inputDigest: a
    }, f = {
      kind: "zx-ai-proposal-artifact-v1",
      version: "1.0.0",
      identity: e.identity,
      provenance: e.provenance,
      lifecycle: e.lifecycle,
      base: g,
      runtimeExecution: t,
      operationProjection: n.operationProjection,
      journal: l,
      effectProof: r.proof,
      descriptor: Ed(e.runtime)
    }, p = u(f), d = yd(p), h = D(
      "zx-ai-proposal-artifact-core:v1",
      p
    ), m = Pt({
      ...p,
      richDiff: d,
      fingerprint: h
    }), y = u({
      ...m,
      // Keep the live S2 plan capability across S3/S4. Serialized proposal
      // artifacts retain identical bytes but intentionally lose execution
      // authority and must be regenerated before another live commit.
      base: { ...m.base, plan: e.plan },
      runtimeExecution: t
    });
    return _s.add(y), {
      valid: !0,
      proposal: y
    };
  } catch {
    return {
      valid: !1,
      diagnostic: ae({
        code: "proposal-artifact-invalid",
        stage: "artifact",
        path: "$.proposal"
      })
    };
  }
}, Od = (e) => {
  if (!Ad(e))
    return u({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: ae({
        code: "proposal-input-invalid",
        stage: "input",
        path: "$"
      })
    });
  if (Sd(e.plan))
    return u({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: ae({
        code: "block-move-unsupported",
        stage: "input",
        path: "$.plan"
      })
    });
  let t;
  try {
    t = { ...Pt(e), plan: e.plan };
  } catch {
    return u({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: ae({
        code: "proposal-input-invalid",
        stage: "input",
        path: "$"
      })
    });
  }
  if (t.plan.source.documentRevision !== v(t.baseDocument))
    return u({
      status: "proposal-failure",
      runtimeOutcome: null,
      proposal: null,
      diagnostic: ae({
        code: "proposal-input-invalid",
        stage: "input",
        path: "$.plan.source.documentRevision"
      })
    });
  const n = ii({
    runtime: t.runtime,
    baseDocument: t.baseDocument,
    plan: t.plan,
    context: t.runtimeContext
  });
  return Td(t, n);
}, Td = (e, t) => {
  if (t.status === "failure")
    return u({
      status: "runtime-failure",
      runtimeOutcome: t,
      proposal: null
    });
  if (t.status === "safety-abort")
    return u({
      status: "safety-abort",
      runtimeOutcome: t,
      proposal: null
    });
  const n = si(e, t);
  return n.valid ? u({
    status: "success",
    runtimeOutcome: t,
    proposal: n.proposal
  }) : u({
    status: "proposal-failure",
    runtimeOutcome: t,
    proposal: null,
    diagnostic: n.diagnostic
  });
}, Cd = () => u({
  status: "proposal-runtime-unsupported",
  proposal: null,
  diagnostic: ae({
    code: "proposal-runtime-unsupported",
    stage: "artifact",
    path: "$.version"
  })
}), Ke = (e = "$") => u({
  status: "proposal-artifact-invalid",
  proposal: null,
  diagnostic: ae({
    code: "proposal-artifact-invalid",
    stage: "artifact",
    path: e
  })
}), Pd = (e) => S(e, [
  "kind",
  "version",
  "identity",
  "provenance",
  "lifecycle",
  "base",
  "runtimeExecution",
  "operationProjection",
  "journal",
  "effectProof",
  "richDiff",
  "descriptor",
  "fingerprint"
]) && S(
  e.identity,
  ["proposalId", "variantId"],
  ["parentVariantId"]
) && S(
  e.provenance,
  ["sourceId", "sequence", "refs"],
  ["timestamp"]
) && S(e.lifecycle, [
  "proposalId",
  "revision",
  "status",
  "fingerprint"
]) && S(e.base, [
  "document",
  "fingerprint",
  "documentRevision",
  "annotationFingerprint",
  "targetFingerprint",
  "plan",
  "planDigest",
  "runtimeContext",
  "inputDigest"
]) && Array.isArray(e.operationProjection) && e.operationProjection.every(
  (t) => S(
    t,
    [
      "operationIndex",
      "kind",
      "blockIds",
      "stepStart",
      "stepEnd",
      "intentDigest",
      "dependencyOperationIndexes"
    ],
    ["noOpReason"]
  )
) && S(e.journal, [
  "kind",
  "version",
  "sourceBinding",
  "trace",
  "proposalIdentityFingerprint",
  "baseFingerprint",
  "planDigest",
  "lifecycleRevision",
  "fingerprint"
]) && S(e.effectProof, [
  "kind",
  "version",
  "operationScopes",
  "traceAttribution",
  "untouchedBlockFingerprints",
  "untouchedAnnotationFingerprints",
  "untouchedProjectionFingerprint",
  "relativeOrderFingerprint",
  "annotationProjectionFingerprint",
  "assetsMetaUnchanged",
  "fingerprint"
]) && S(e.descriptor, [
  "kind",
  "version",
  "envelopeRef",
  "codecRef",
  "effectProofRef",
  "richDiffProfileRef",
  "semanticRecipeSchemaRef",
  "lifecycleSchemaRef",
  "runtimeManifestRef",
  "runtimeTraceContractRef",
  "forbiddenAuthorities",
  "fingerprint"
]), hf = (e) => {
  const t = Le(e);
  if (t.status !== "success")
    throw new TypeError(t.status);
  return Oe(
    t.proposal,
    Rt
  ).canonical;
}, Le = (e) => {
  if (Ls(e))
    return u({
      status: "success",
      proposal: e,
      cacheStatus: "exact"
    });
  let t = e;
  try {
    if (typeof e == "string" && (new TextEncoder().encode(e).byteLength > Rt.maxBytes || (t = JSON.parse(e), Oe(t, Rt).canonical !== e)))
      return Ke("$");
    Oe(t, Rt);
  } catch {
    return Ke("$");
  }
  if (!t || typeof t != "object" || Array.isArray(t))
    return Ke("$");
  const n = t;
  if (n.kind !== "zx-ai-proposal-artifact-v1" || n.version !== "1.0.0")
    return Cd();
  if (!Pd(t)) return Ke("$");
  const r = Pt(t);
  if (r.runtimeExecution.status !== "success")
    return Ke("$.runtimeExecution");
  const i = si(
    {
      runtime: r.descriptor.runtimeManifestRef,
      baseDocument: r.base.document,
      plan: r.base.plan,
      identity: r.identity,
      lifecycle: r.lifecycle,
      provenance: r.provenance,
      runtimeContext: r.base.runtimeContext
    },
    r.runtimeExecution
  );
  if (!i.valid) return Ke(i.diagnostic.path);
  const o = i.proposal, s = {
    ...r,
    richDiff: o.richDiff
  };
  if (!M(s, o))
    return Ke("$.fingerprint");
  const a = M(r.richDiff, o.richDiff) ? "exact" : "rich-diff-rebuilt";
  return u({
    status: "success",
    proposal: o,
    cacheStatus: a
  });
}, zt = {
  kind: "execution-closure",
  id: "zx.ai.proposal-historical-reader",
  version: "1.0.0",
  dependencies: []
}, Mn = u({
  kind: zt.kind,
  id: zt.id,
  version: zt.version,
  dependencies: zt.dependencies,
  fingerprint: D(
    "zx-ai-proposal-historical-reader:v1",
    zt
  )
}), yf = (e) => {
  const t = e.runtimeArtifact.payload, n = Le(e.sourceProposal);
  if (n.status !== "success" || n.cacheStatus !== "exact" || !et(t) || !et(t.baseDocument) || !E(t.resultFingerprint) || !Bt(e.lifecycle) || e.lifecycle.proposalId !== (n.status === "success" ? n.proposal.identity.proposalId : ""))
    throw new TypeError("historical-proposal-runtime-payload-invalid");
  const r = n.proposal;
  if (e.runtimeArtifact.artifactKind === "zx-text-editor-runtime-artifact-v2" && (!et(t) || t.baseDocumentFingerprint !== v(r.base.document) || t.planDigest !== r.base.planDigest || t.resultFingerprint !== r.runtimeExecution.resultFingerprint || t.traceFingerprint !== r.runtimeExecution.trace.fingerprint || t.mappingFingerprint !== r.runtimeExecution.mapping.fingerprint || t.runtimeReceiptFingerprint !== v(r.runtimeExecution.runtime) || t.runtimeManifestFingerprint !== r.runtimeExecution.runtime.manifestRef.fingerprint))
    throw new TypeError("historical-proposal-runtime-binding-invalid");
  const i = {
    kind: "zx-ai-proposal-historical-artifact-v1",
    version: "1.0.0",
    proposalReaderRef: Mn,
    identity: r.identity,
    lifecycle: e.lifecycle,
    provenance: r.provenance,
    operationIntentDigests: r.operationProjection.map(
      (a) => a.intentDigest
    ),
    sourceProposalFingerprint: r.fingerprint,
    baseDocumentFingerprint: v(t.baseDocument),
    resultFingerprint: t.resultFingerprint,
    runtimeArtifactFingerprint: D(
      "zx-ai-proposal-historical-runtime-artifact:v1",
      e.runtimeArtifact
    )
  }, o = {
    ...i,
    fingerprint: D(
      "zx-ai-proposal-historical-artifact:v1",
      i
    )
  }, s = {
    kind: "zx-ai-proposal-historical-envelope-v1",
    version: "1.0.0",
    proposalReaderRef: Mn,
    proposalArtifact: o,
    sourceProposal: r,
    runtimeArtifact: e.runtimeArtifact
  };
  return u({
    ...s,
    closureFingerprint: D(
      "zx-ai-proposal-historical-envelope-closure:v1",
      s
    )
  });
}, Dd = (e, t, n) => {
  const r = Le(n);
  if (r.status !== "success" || r.cacheStatus !== "exact" || !S(e, [
    "kind",
    "version",
    "proposalReaderRef",
    "identity",
    "lifecycle",
    "provenance",
    "operationIntentDigests",
    "sourceProposalFingerprint",
    "baseDocumentFingerprint",
    "resultFingerprint",
    "runtimeArtifactFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-proposal-historical-artifact-v1" || e.version !== "1.0.0" || !M(
    e.proposalReaderRef,
    Mn
  ) || !S(
    e.identity,
    ["proposalId", "variantId"],
    ["parentVariantId"]
  ) || !E(e.identity.proposalId) || !E(e.identity.variantId) || Object.hasOwn(e.identity, "parentVariantId") && !E(e.identity.parentVariantId) || !Bt(e.lifecycle) || e.lifecycle.proposalId !== e.identity.proposalId || !S(
    e.provenance,
    ["sourceId", "sequence", "refs"],
    ["timestamp"]
  ) || !E(e.provenance.sourceId) || !G(e.provenance.sequence) || Object.hasOwn(e.provenance, "timestamp") && !E(e.provenance.timestamp) || !Array.isArray(e.provenance.refs) || !e.provenance.refs.every(
    (a) => S(a, ["id", "type"]) && E(a.id) && ["entity", "activity", "agent", "plan"].includes(String(a.type))
  ) || !Array.isArray(e.operationIntentDigests) || e.operationIntentDigests.length === 0 || !e.operationIntentDigests.every(E) || new Set(e.operationIntentDigests).size !== e.operationIntentDigests.length || !M(e.identity, r.proposal.identity) || !M(e.provenance, r.proposal.provenance) || !M(
    e.operationIntentDigests,
    r.proposal.operationProjection.map(
      (a) => a.intentDigest
    )
  ) || e.sourceProposalFingerprint !== r.proposal.fingerprint || !E(e.baseDocumentFingerprint) || !E(e.resultFingerprint) || !E(e.runtimeArtifactFingerprint))
    return !1;
  const i = t.payload;
  if (!et(i) || !et(i.baseDocument) || !E(i.resultFingerprint) || e.baseDocumentFingerprint !== v(i.baseDocument) || e.resultFingerprint !== i.resultFingerprint || e.runtimeArtifactFingerprint !== D(
    "zx-ai-proposal-historical-runtime-artifact:v1",
    t
  ))
    return !1;
  const { fingerprint: o, ...s } = e;
  return e.fingerprint === D("zx-ai-proposal-historical-artifact:v1", s);
}, yr = (e) => u({
  status: "deterministic-mismatch",
  diagnostics: [
    ae({
      code: "proposal-cache-invalid",
      stage: "audit",
      path: e
    })
  ]
}), zr = (e) => u({
  status: "proposal-runtime-unsupported",
  diagnostics: [
    ae({
      code: "proposal-runtime-unsupported",
      stage: "audit",
      path: e
    })
  ]
}), no = /* @__PURE__ */ new WeakMap(), $r = (e) => {
  if (!S(e, ["mode"], ["proposal", "envelope"]) || e.mode !== "historical" && e.mode !== "exact-current" || !S(e, [
    "mode",
    e.mode === "historical" ? "envelope" : "proposal"
  ]))
    return u({
      status: "failure",
      diagnostics: [
        ae({
          code: "proposal-input-invalid",
          stage: "audit",
          path: "$"
        })
      ]
    });
  if (e.mode === "historical") {
    const i = e.envelope;
    if (!S(i, [
      "kind",
      "version",
      "proposalReaderRef",
      "proposalArtifact",
      "sourceProposal",
      "runtimeArtifact",
      "closureFingerprint"
    ]) || i.kind !== "zx-ai-proposal-historical-envelope-v1" || i.version !== "1.0.0" || !M(
      i.proposalReaderRef,
      Mn
    ) || !Dd(
      i.proposalArtifact,
      i.runtimeArtifact,
      i.sourceProposal
    ) || i.closureFingerprint !== D("zx-ai-proposal-historical-envelope-closure:v1", {
      kind: i.kind,
      version: i.version,
      proposalReaderRef: i.proposalReaderRef,
      proposalArtifact: i.proposalArtifact,
      sourceProposal: i.sourceProposal,
      runtimeArtifact: i.runtimeArtifact
    }) || !Wn(i))
      return zr("$.envelope");
    const o = Kl(
      i.runtimeArtifact
    );
    return o.status === "historical-runtime-unsupported" ? zr("$.envelope.runtimeArtifact") : o.status !== "verified" ? u({
      status: "failure",
      diagnostics: [
        ae({
          code: "proposal-artifact-invalid",
          stage: "audit",
          path: "$.envelope.runtimeArtifact"
        })
      ]
    }) : u({
      status: "audit-success",
      fingerprint: D("zx-ai-proposal-historical-audit:v1", {
        proposalArtifactFingerprint: i.proposalArtifact.fingerprint,
        runtimeAudit: o
      })
    });
  }
  const t = Ls(e.proposal), n = t && no.get(e.proposal);
  if (n) return n;
  const r = Bd(e.proposal);
  return t && no.set(e.proposal, r), r;
}, Bd = (e) => {
  const t = Le(e);
  if (t.status === "proposal-runtime-unsupported")
    return zr("$.proposal");
  if (t.status !== "success") return yr("$.proposal");
  const n = t.proposal, r = ii({
    runtime: n.descriptor.runtimeManifestRef,
    baseDocument: n.base.document,
    plan: n.base.plan,
    context: n.base.runtimeContext
  });
  if (r.status !== "success" || !M(r, n.runtimeExecution))
    return yr("$.proposal.runtimeExecution");
  const i = si(
    {
      runtime: n.descriptor.runtimeManifestRef,
      baseDocument: n.base.document,
      plan: n.base.plan,
      identity: n.identity,
      lifecycle: n.lifecycle,
      provenance: n.provenance,
      runtimeContext: n.base.runtimeContext
    },
    r
  );
  return !i.valid || !M(i.proposal, n) ? yr("$.proposal") : u({
    status: "audit-success",
    fingerprint: D("zx-ai-proposal-current-audit:v1", {
      proposalFingerprint: n.fingerprint,
      runtimeOutcome: r
    })
  });
}, Xe = (e, t) => u({
  status: "failure",
  ...e === "recipe" ? { recipe: null } : { plannerSeed: null },
  diagnostic: ae({
    code: e === "recipe" ? "proposal-recipe-invalid" : "proposal-input-invalid",
    stage: e,
    path: t
  })
}), jd = (e) => {
  if (!S(e, [
    "proposal",
    "currentDocument",
    "currentLifecycle"
  ]) || !Bt(e.currentLifecycle))
    return Xe("recipe", "$");
  const t = Le(e.proposal);
  if (t.status !== "success")
    return Xe("recipe", "$.proposal");
  const n = t.proposal, r = e.currentLifecycle;
  if (r.proposalId !== n.identity.proposalId || r.status === "discarded")
    return u({ status: "discarded", recipe: null });
  if (r.revision !== n.lifecycle.revision || r.fingerprint !== n.lifecycle.fingerprint || v(e.currentDocument) !== n.base.documentRevision || D(
    "zx-ai-proposal-base-document:v1",
    e.currentDocument
  ) !== n.base.fingerprint || D(
    "zx-ai-proposal-annotations:v1",
    e.currentDocument.annotations
  ) !== n.base.annotationFingerprint || js(
    e.currentDocument,
    n.operationProjection
  ) !== n.base.targetFingerprint)
    return u({ status: "rebase-required", recipe: null });
  const i = u({
    manifestRef: n.runtimeExecution.runtime.manifestRef,
    executionSemanticsFingerprint: n.runtimeExecution.runtime.executionSemanticsFingerprint,
    observationalProfileFingerprint: n.runtimeExecution.runtime.observationalProfileFingerprint,
    derivedViewFingerprint: n.runtimeExecution.runtime.derivedViewFingerprint,
    baseFingerprint: n.base.fingerprint
  }), o = ml(i);
  if (o.status === "regenerate-current-runtime")
    return u({
      status: "regenerate-current-runtime",
      recipe: null,
      hostAdmission: o
    });
  if (o.status === "unsupported-host")
    return u({
      status: "unsupported-host",
      recipe: null,
      hostAdmission: o
    });
  const s = {
    kind: "zx-ai-proposal-semantic-recipe-v1",
    version: "1.0.0",
    proposalFingerprint: n.fingerprint,
    baseFingerprint: n.base.fingerprint,
    plan: n.base.plan,
    planDigest: n.base.planDigest,
    expectedResultFingerprint: n.runtimeExecution.resultFingerprint,
    expectedTraceFingerprint: n.runtimeExecution.trace.fingerprint,
    expectedMappingFingerprint: n.runtimeExecution.mapping.fingerprint,
    runtimeExpectation: i,
    hostAdmission: o,
    lifecycleRevision: r.revision,
    annotationExpectationFingerprint: n.effectProof.annotationProjectionFingerprint,
    operationIntentDigests: n.operationProjection.map(
      (c) => c.intentDigest
    ),
    dispatchHandoff: {
      owner: "S4-or-S7",
      targetBoundRecheck: "recheckCurrentTextEditorRuntimeHostForDispatchV2",
      reexecution: "executeTextEditorMutationPlanV2",
      cachedAdmissionIsDispatchReceipt: !1,
      oldTraceExecutable: !1
    }
  }, a = Pt({
    ...s,
    fingerprint: D(
      "zx-ai-proposal-semantic-recipe:v1",
      s
    )
  });
  return u({
    status: "success",
    // Preserve the live S2 capability for S4/S7 dispatch. A deserialized
    // proposal still carries identical recipe bytes but no live capability.
    recipe: { ...a, plan: n.base.plan }
  });
}, Nd = (e, t, n) => S(e, ["proposalId", "variantId", "parentVariantId"]) && E(e.proposalId) && e.proposalId === n && E(e.variantId) && e.variantId !== t && e.parentVariantId === t, Md = (e) => {
  if (!S(e, [
    "proposal",
    "decision",
    "latestBaseDocument",
    "nextIdentity"
  ]) || !S(e.decision, ["kind", "operationIntentDigests"]) || e.decision.kind !== "regenerate-proposal" || !Array.isArray(e.decision.operationIntentDigests) || e.decision.operationIntentDigests.length === 0 || !e.decision.operationIntentDigests.every(E))
    return Xe("regeneration", "$");
  const t = Le(e.proposal);
  if (t.status !== "success")
    return Xe(
      "regeneration",
      "$.proposal"
    );
  const n = t.proposal;
  if (!Nd(
    e.nextIdentity,
    n.identity.variantId,
    n.identity.proposalId
  ))
    return Xe(
      "regeneration",
      "$.nextIdentity"
    );
  const r = new Set(e.decision.operationIntentDigests);
  if (r.size !== e.decision.operationIntentDigests.length)
    return Xe(
      "regeneration",
      "$.decision.operationIntentDigests"
    );
  const i = new Map(
    n.operationProjection.map((a) => [
      a.intentDigest,
      a
    ])
  );
  if (![...r].every((a) => {
    const c = i.get(a);
    return !!(c && c.dependencyOperationIndexes.every(
      (l) => {
        var g;
        return r.has(
          ((g = n.operationProjection[l]) == null ? void 0 : g.intentDigest) ?? ""
        );
      }
    ));
  }))
    return Xe(
      "regeneration",
      "$.decision.operationIntentDigests"
    );
  if (!In(e.latestBaseDocument).valid)
    return Xe(
      "regeneration",
      "$.latestBaseDocument"
    );
  const s = {
    supersededProposalFingerprint: n.fingerprint,
    latestBaseDocument: e.latestBaseDocument,
    nextIdentity: e.nextIdentity,
    operationIntentDigests: [...r].sort()
  };
  return u({
    status: "success",
    plannerSeed: Pt({
      ...s,
      fingerprint: D(
        "zx-ai-proposal-regeneration-seed:v1",
        s
      )
    })
  });
}, ue = /* @__PURE__ */ new Map(), yt = /* @__PURE__ */ new Map(), ye = (e) => e.identity.reviewId, qs = (e) => {
  const t = ye(e), n = ue.get(t);
  return n ? n.revision === e.revision && n.fingerprint === e.fingerprint && n.status === e.status && n.reservation === null : (ue.set(t, {
    revision: e.revision,
    fingerprint: e.fingerprint,
    status: e.status,
    reservation: null
  }), yt.set(t, e), !0);
}, Gn = (e) => {
  const t = ue.get(ye(e));
  return t ? t.revision === e.revision && t.fingerprint === e.fingerprint && t.status === e.status && t.reservation === null : qs(e);
}, Js = (e, t) => Gn(e) ? (ue.set(ye(t), {
  revision: t.revision,
  fingerprint: t.fingerprint,
  status: t.status,
  reservation: null
}), yt.set(ye(t), t), !0) : !1, bf = (e, t) => {
  const n = ye(e), r = t.at(-1) ?? e, i = ue.get(n), o = [e, ...t], s = i ? o.findIndex(
    (a) => a.revision === i.revision && a.fingerprint === i.fingerprint && a.status === i.status
  ) : -1;
  return i && i.reservation !== null || i && s < 0 ? "conflict" : (i == null ? void 0 : i.revision) === r.revision && i.fingerprint === r.fingerprint && i.status === r.status ? "idempotent" : (ue.set(n, {
    revision: r.revision,
    fingerprint: r.fingerprint,
    status: r.status,
    reservation: null
  }), yt.set(n, r), "reconciled");
}, zd = (e, t) => Gn(e) ? (ue.set(ye(e), {
  revision: e.revision,
  fingerprint: e.fingerprint,
  status: e.status,
  reservation: t
}), !0) : !1, br = (e, t) => {
  const n = ue.get(ye(e));
  (n == null ? void 0 : n.revision) === e.revision && n.fingerprint === e.fingerprint && n.reservation === t && ue.set(ye(e), { ...n, reservation: null });
}, gn = (e, t, n) => {
  const r = ue.get(ye(e));
  return !r || r.revision !== e.revision || r.fingerprint !== e.fingerprint || r.reservation !== n ? !1 : (ue.set(ye(t), {
    revision: t.revision,
    fingerprint: t.fingerprint,
    status: t.status,
    reservation: null
  }), yt.set(ye(t), t), !0);
}, mn = (e, t) => {
  const n = ye(e), r = yt.get(n);
  return r && r.status !== "active" ? r : (ue.set(n, {
    revision: t.revision,
    fingerprint: t.fingerprint,
    status: t.status,
    reservation: null
  }), yt.set(n, t), t);
}, xf = () => {
  ue.clear(), yt.clear();
}, N = u({
  maxBytes: 4e6,
  maxDepth: 96,
  maxArrayEntries: 3e4,
  maxObjectKeys: 64,
  maxTotalObjectKeys: 16e4,
  // Count limits remain independently reachable below the 4 MB envelope
  // ceiling, so their limit boundary is observable rather than shadowed by
  // the byte budget.
  maxItems: 512,
  maxDecisionEntries: 512,
  maxAuditEntries: 1024,
  maxNavigationPageSize: 100,
  maxDiagnosticCount: 32,
  maxSummaryLength: 240
});
u({
  items: N.maxItems,
  decisions: N.maxDecisionEntries,
  "audit-entries": N.maxAuditEntries,
  "navigation-page": N.maxNavigationPageSize,
  diagnostics: N.maxDiagnosticCount
});
const Zt = u({
  maxBytes: N.maxBytes,
  maxDepth: N.maxDepth,
  maxArrayEntries: N.maxArrayEntries,
  maxObjectKeys: N.maxObjectKeys,
  maxTotalObjectKeys: N.maxTotalObjectKeys
}), $d = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), V = (e, t, n = []) => $d(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), z = (e) => typeof e == "string" && e.trim().length > 0, Ie = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, $ = (e, t) => v({ domain: e, value: t }), Me = (e) => {
  tn(e, Zt);
  const { canonical: t } = Oe(
    e,
    Zt
  );
  return u(JSON.parse(t));
}, _e = (e, t) => {
  try {
    return F(e) === F(t);
  } catch {
    return !1;
  }
}, Vd = (e) => new TextEncoder().encode(F(e)).byteLength, zn = (e, t = /* @__PURE__ */ new Set()) => !e || typeof e != "object" || t.has(e) ? !0 : Object.isFrozen(e) ? (t.add(e), Object.values(e).every(
  (n) => zn(n, t)
)) : !1, ai = (e) => {
  const { fingerprint: t, ...n } = e;
  return n;
}, _d = (e) => [...new Set(e)].sort((t, n) => t - n), Ld = (e) => e.slice(0, N.maxSummaryLength), qd = (e) => {
  if (!e.length) return null;
  const t = new Set(e.map((i) => i.operationIndex));
  if (t.size !== e.length || e.some(
    (i, o) => i.operationIndex !== o || !i.intentDigest || i.dependencyOperationIndexes.some(
      (s, a, c) => !t.has(s) || s === i.operationIndex || s >= i.operationIndex || a > 0 && s <= c[a - 1]
    )
  ))
    return null;
  const n = e.map(
    (i) => u([...i.dependencyOperationIndexes])
  ), r = e.map(() => []);
  return n.forEach((i, o) => {
    i.forEach((s) => r[s].push(o));
  }), u({
    operationIndexes: e.map((i) => i.operationIndex),
    dependencies: n,
    reverseDependencies: r.map(_d),
    fingerprintProjection: e.map((i) => ({
      operationIndex: i.operationIndex,
      intentDigest: i.intentDigest,
      dependencies: [...i.dependencyOperationIndexes]
    }))
  });
}, Jd = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, Kd = /^[A-Za-z0-9_.:-]{1,160}$/, nt = (e) => {
  const t = (n) => n && Kd.test(n) ? Sr(
    v({ domain: "zx-ai-review-safe-ref:v1", value: n })
  ) : void 0;
  return u({
    code: e.code,
    stage: e.stage,
    path: Jd.test(e.path) ? e.path.slice(0, 240) : "$",
    ...Number.isSafeInteger(e.count) && e.count >= 0 ? { count: Math.min(e.count, 1e6) } : {},
    ...typeof e.fingerprint == "string" ? { fingerprintPrefix: Sr(e.fingerprint) } : {},
    ...t(e.reviewRef) ? { reviewRef: t(e.reviewRef) } : {},
    ...t(e.proposalRef) ? { proposalRef: t(e.proposalRef) } : {},
    ...t(e.operationRef) ? { operationRef: t(e.operationRef) } : {},
    ...t(e.blockRef) ? { blockRef: t(e.blockRef) } : {},
    ...t(e.hunkRef) ? { hunkRef: t(e.hunkRef) } : {}
  });
}, ci = (e) => {
  if (!Array.isArray(e) || e.length > N.maxDiagnosticCount)
    throw new RangeError("review-diagnostic-budget-exceeded");
  return u([...e]);
}, Ue = (e) => ({
  valid: !1,
  diagnostic: nt({
    code: "review-item-index-invalid",
    stage: "items",
    path: e
  })
}), Ud = (e, t, n) => {
  const r = e.operationProjection[t], i = new Map(
    r.blockIds.map((c, l) => [c, l])
  ), o = [...n].sort(
    (c, l) => (i.get(c.blockId) ?? Number.MAX_SAFE_INTEGER) - (i.get(l.blockId) ?? Number.MAX_SAFE_INTEGER) || c.ordinal - l.ordinal || c.id.localeCompare(l.id)
  ), s = e.effectProof.traceAttribution.filter(
    (c) => c.kind === "appended" && c.operationIndexes.includes(t)
  ).map((c) => {
    const l = {
      sequence: c.sequence,
      pluginInstanceId: c.pluginInstanceId ?? "package-runtime",
      documentChanged: c.documentChanged,
      blockRefs: [...c.attributedBlockIds],
      safeEffectFingerprints: [...c.safeEffectFingerprints]
    };
    return u({
      ...l,
      fingerprint: $(
        "zx-ai-review-appended-attribution:v1",
        l
      )
    });
  }), a = {
    operationIndex: t,
    operationKind: r.kind,
    operationIntentDigest: r.intentDigest,
    decisionKey: $("zx-ai-review-decision-key:v1", {
      proposalFingerprint: e.fingerprint,
      operationIndex: t,
      operationIntentDigest: r.intentDigest
    }),
    dependencyOperationIndexes: [...r.dependencyOperationIndexes],
    blockRefs: [...r.blockIds],
    hunkRefs: o.map((c) => ({
      hunkId: c.id,
      ordinal: c.ordinal,
      kind: c.kind,
      fingerprint: c.fingerprint
    })),
    appendedAttributionRefs: s,
    summary: Ld(
      o.length ? o.map((c) => c.summary).join(" | ") : "already-equal"
    ),
    noOpReason: r.noOpReason ?? null
  };
  return u({
    itemId: $("zx-ai-review-item-id:v1", {
      policy: "zx.ai.review-policy@1.0.0",
      proposalFingerprint: e.fingerprint,
      operationIndex: t,
      operationIntentDigest: r.intentDigest,
      hunkFingerprints: o.map((c) => c.fingerprint)
    }),
    ...a,
    fingerprint: $("zx-ai-review-item:v1", a)
  });
}, Hd = (e) => {
  if (e.richDiff.status === "unavailable")
    return u({
      valid: !0,
      capability: "coarse-review-unavailable",
      items: []
    });
  const t = e.richDiff.value;
  if (!_e(t.sourceBinding, e.richDiff.sourceBinding))
    return Ue("$.proposal.richDiff.sourceBinding");
  const n = new Map(t.hunks.map((a) => [a.id, a]));
  if (n.size !== t.hunks.length)
    return Ue("$.proposal.richDiff.hunks");
  const r = new Map(
    t.operationToHunks.map((a) => [a.operationIndex, a.hunkIds])
  );
  if (r.size !== t.operationToHunks.length || t.operationToHunks.some(
    (a, c, l) => !e.operationProjection[a.operationIndex] || c > 0 && a.operationIndex <= l[c - 1].operationIndex || new Set(a.hunkIds).size !== a.hunkIds.length
  ))
    return Ue("$.proposal.richDiff.operationToHunks");
  const i = /* @__PURE__ */ new Set(), o = [];
  for (const a of e.operationProjection) {
    const c = r.get(a.operationIndex) ?? [], l = [];
    for (const f of c) {
      const p = n.get(f);
      if (!p || i.has(f) || p.operationIndex !== a.operationIndex)
        return Ue("$.proposal.richDiff.hunks");
      i.add(f), l.push(p);
    }
    if (!l.length && a.noOpReason !== "already-equal")
      return Ue(
        `$.proposal.operationProjection[${a.operationIndex}]`
      );
    const g = e.effectProof.traceAttribution.filter(
      (f) => f.kind === "appended" && f.operationIndexes.includes(a.operationIndex)
    );
    if (l.length > N.maxNavigationPageSize || a.blockIds.length > N.maxNavigationPageSize || g.length > N.maxNavigationPageSize || g.some(
      (f) => f.attributedBlockIds.length > N.maxNavigationPageSize || f.safeEffectFingerprints.length > N.maxNavigationPageSize
    ))
      return Ue(
        `$.proposal.operationProjection[${a.operationIndex}]`
      );
    o.push(Ud(e, a.operationIndex, l));
  }
  if (i.size !== t.hunks.length || o.length > N.maxItems)
    return Ue("$.proposal.richDiff.hunks");
  const s = /* @__PURE__ */ new Map();
  return t.hunks.forEach((a) => {
    const c = s.get(a.blockId) ?? [];
    c.push(a.id), s.set(a.blockId, c);
  }), t.blockToHunks.length !== s.size || t.blockToHunks.some(
    (a) => !s.has(a.blockId) || !_e(a.hunkIds, s.get(a.blockId))
  ) ? Ue("$.proposal.richDiff.blockToHunks") : u({ valid: !0, capability: "fine-review", items: o });
}, ro = {
  id: "zx.ai.review-policy",
  version: "1.0.0",
  hunkExecutable: !1,
  partialDecisionDispatch: !1,
  fineDiffUnavailableAllowed: ["reject-all", "regenerate"],
  wholeAcceptRequiresFineReview: !0,
  independentWholeReviewSurface: "not-provided-v1",
  limits: N
}, xr = u({
  ...ro,
  fingerprint: $(
    "zx-ai-review-policy:v1",
    ro
  )
}), Ks = u({
  id: xr.id,
  version: xr.version,
  fingerprint: xr.fingerprint
}), Us = (e) => V(e, ["id", "version", "fingerprint"]) && _e(e, Ks), Hs = /* @__PURE__ */ new WeakSet(), li = (e) => $("zx-ai-review-sidecar:v1", e), Ws = (e) => {
  const t = Me({
    ...e,
    fingerprint: li(e)
  });
  return Hs.add(t), t;
}, vt = (e = "$") => u({
  status: "review-sidecar-invalid",
  sidecar: null,
  diagnostic: nt({
    code: "review-sidecar-invalid",
    stage: "codec",
    path: e
  })
}), Wd = () => u({
  status: "review-runtime-unsupported",
  sidecar: null,
  diagnostic: nt({
    code: "review-runtime-unsupported",
    stage: "codec",
    path: "$.version"
  })
}), Xd = (e) => V(e, [
  "itemId",
  "operationIndex",
  "operationKind",
  "operationIntentDigest",
  "decisionKey",
  "dependencyOperationIndexes",
  "blockRefs",
  "hunkRefs",
  "appendedAttributionRefs",
  "summary",
  "noOpReason",
  "fingerprint"
]) && z(e.itemId) && Ie(e.operationIndex) && z(e.operationKind) && z(e.operationIntentDigest) && z(e.decisionKey) && Array.isArray(e.dependencyOperationIndexes) && e.dependencyOperationIndexes.every(Ie) && Array.isArray(e.blockRefs) && e.blockRefs.length <= N.maxNavigationPageSize && e.blockRefs.every(z) && Array.isArray(e.hunkRefs) && e.hunkRefs.length <= N.maxNavigationPageSize && e.hunkRefs.every(
  (t) => V(t, ["hunkId", "ordinal", "kind", "fingerprint"]) && z(t.hunkId) && Ie(t.ordinal) && z(t.kind) && z(t.fingerprint)
) && Array.isArray(e.appendedAttributionRefs) && e.appendedAttributionRefs.length <= N.maxNavigationPageSize && e.appendedAttributionRefs.every(
  (t) => V(t, [
    "sequence",
    "pluginInstanceId",
    "documentChanged",
    "blockRefs",
    "safeEffectFingerprints",
    "fingerprint"
  ]) && Ie(t.sequence) && z(t.pluginInstanceId) && typeof t.documentChanged == "boolean" && Array.isArray(t.blockRefs) && t.blockRefs.length <= N.maxNavigationPageSize && t.blockRefs.every(z) && Array.isArray(t.safeEffectFingerprints) && t.safeEffectFingerprints.length <= N.maxNavigationPageSize && t.safeEffectFingerprints.every(z) && z(t.fingerprint) && t.fingerprint === $("zx-ai-review-appended-attribution:v1", {
    sequence: t.sequence,
    pluginInstanceId: t.pluginInstanceId,
    documentChanged: t.documentChanged,
    blockRefs: t.blockRefs,
    safeEffectFingerprints: t.safeEffectFingerprints
  })
) && typeof e.summary == "string" && e.summary.length <= N.maxSummaryLength && (e.noOpReason === null || e.noOpReason === "already-equal") && z(e.fingerprint), Gd = (e) => V(e, [
  "operationIndex",
  "operationIntentDigest",
  "dependencyOperationIndexes",
  "state",
  "decidedAtRevision",
  "fingerprint"
]) && Ie(e.operationIndex) && z(e.operationIntentDigest) && Array.isArray(e.dependencyOperationIndexes) && e.dependencyOperationIndexes.every(Ie) && ["undecided", "accepted", "rejected", "regeneration-required"].includes(
  e.state
) && (e.decidedAtRevision === null || Ie(e.decidedAtRevision)) && z(e.fingerprint), Zd = (e) => V(e, [
  "sequence",
  "kind",
  "commandId",
  "previousSidecarFingerprint",
  "operationIndexes",
  "fingerprint"
]) && Ie(e.sequence) && z(e.kind) && (e.commandId === null || z(e.commandId)) && (e.previousSidecarFingerprint === null || z(e.previousSidecarFingerprint)) && Array.isArray(e.operationIndexes) && e.operationIndexes.every(Ie) && z(e.fingerprint), Yd = (e) => V(e, [
  "kind",
  "version",
  "identity",
  "proposalBinding",
  "policyRef",
  "profileRef",
  "revision",
  "status",
  "capability",
  "items",
  "decisions",
  "auditEntries",
  "fingerprint"
]) && V(e.identity, ["reviewId"]) && z(e.identity.reviewId) && V(e.proposalBinding, [
  "proposalId",
  "variantId",
  "proposalFingerprint",
  "operationCount",
  "operationProjectionFingerprint",
  "lifecycleRevision",
  "lifecycleFingerprint",
  "baseFingerprint",
  "documentRevision",
  "annotationFingerprint",
  "targetFingerprint",
  "planDigest",
  "resultFingerprint",
  "traceFingerprint",
  "mappingFingerprint",
  "effectFingerprint",
  "richDiffStatus",
  "richDiffSourceBinding",
  "richDiffUnavailableReason",
  "richDiffFingerprint"
]) && Ie(e.proposalBinding.operationCount) && e.proposalBinding.operationCount > 0 && z(e.proposalBinding.operationProjectionFingerprint) && V(e.proposalBinding.richDiffSourceBinding, [
  "executionSemanticsFingerprint",
  "resultFingerprint",
  "traceFingerprint"
]) && ["available", "unavailable"].includes(
  String(e.proposalBinding.richDiffStatus)
) && (e.proposalBinding.richDiffUnavailableReason === null || [
  "profile-not-installed",
  "unsupported-runtime",
  "resource-limit-exceeded",
  "derivation-failed"
].includes(String(e.proposalBinding.richDiffUnavailableReason))) && Us(e.policyRef) && V(e.profileRef, [
  "kind",
  "id",
  "version",
  "fingerprint",
  "dependencies"
]) && Ie(e.revision) && [
  "active",
  "committed",
  "accepted-no-change",
  "rejected",
  "superseded",
  "invalidated"
].includes(e.status) && ["fine-review", "coarse-review-unavailable"].includes(
  e.capability
) && Array.isArray(e.items) && e.items.length <= N.maxItems && e.items.every(Xd) && Array.isArray(e.decisions) && e.decisions.length <= N.maxDecisionEntries && e.decisions.every(Gd) && Array.isArray(e.auditEntries) && e.auditEntries.length <= N.maxAuditEntries && e.auditEntries.every(Zd) && z(e.fingerprint), nn = (e) => {
  if (typeof e == "object" && e !== null && Hs.has(e))
    return u({
      status: "success",
      sidecar: e
    });
  let t = e;
  try {
    if (typeof e == "string" && (new TextEncoder().encode(e).byteLength > N.maxBytes || (t = JSON.parse(e), Oe(t, Zt).canonical !== e)))
      return vt("$");
    Oe(t, Zt);
  } catch {
    return vt("$");
  }
  if (!t || typeof t != "object" || Array.isArray(t))
    return vt("$");
  const n = t;
  if (n.kind !== "zx-ai-review-sidecar-v1" || n.version !== "1.0.0")
    return Wd();
  if (!Yd(t)) return vt("$");
  const r = Me(t);
  return r.capability === "fine-review" && (r.items.length !== r.decisions.length || r.items.length !== r.proposalBinding.operationCount) || r.capability === "coarse-review-unavailable" && r.items.length !== 0 || r.decisions.length !== r.proposalBinding.operationCount || r.items.some(
    (i, o) => {
      var s, a;
      return i.operationIndex !== o || ((s = r.decisions[o]) == null ? void 0 : s.operationIndex) !== o || ((a = r.decisions[o]) == null ? void 0 : a.operationIntentDigest) !== i.operationIntentDigest || i.fingerprint !== $("zx-ai-review-item:v1", {
        operationIndex: i.operationIndex,
        operationKind: i.operationKind,
        operationIntentDigest: i.operationIntentDigest,
        decisionKey: i.decisionKey,
        dependencyOperationIndexes: i.dependencyOperationIndexes,
        blockRefs: i.blockRefs,
        hunkRefs: i.hunkRefs,
        appendedAttributionRefs: i.appendedAttributionRefs,
        summary: i.summary,
        noOpReason: i.noOpReason
      });
    }
  ) || r.decisions.some(
    (i, o) => i.operationIndex !== o || i.fingerprint !== $("zx-ai-review-operation-decision:v1", {
      operationIndex: i.operationIndex,
      operationIntentDigest: i.operationIntentDigest,
      dependencyOperationIndexes: i.dependencyOperationIndexes,
      state: i.state,
      decidedAtRevision: i.decidedAtRevision
    })
  ) || r.auditEntries.some(
    (i, o) => i.sequence !== o || i.fingerprint !== $("zx-ai-review-audit-entry:v1", {
      sequence: i.sequence,
      kind: i.kind,
      commandId: i.commandId,
      previousSidecarFingerprint: i.previousSidecarFingerprint,
      operationIndexes: i.operationIndexes
    })
  ) || li(ai(r)) !== r.fingerprint ? vt("$.fingerprint") : u({ status: "success", sidecar: r });
}, If = (e) => {
  const t = nn(e);
  if (t.status !== "success") throw new TypeError(t.status);
  return Oe(t.sidecar, Zt).canonical;
}, Qd = (e) => {
  const t = e.lifecycle;
  return V(t, [
    "proposalId",
    "revision",
    "status",
    "fingerprint"
  ]) && t.status === "active" && oi(t) && t.proposalId === e.proposal.identity.proposalId && t.fingerprint === Dt({
    proposalId: t.proposalId,
    revision: t.revision,
    status: t.status
  }) && t.revision === e.proposal.lifecycle.revision && t.fingerprint === e.proposal.lifecycle.fingerprint;
}, ep = (e, t = "undecided", n = null) => {
  const r = {
    operationIndex: e.operationIndex,
    operationIntentDigest: e.intentDigest,
    dependencyOperationIndexes: [...e.dependencyOperationIndexes],
    state: t,
    decidedAtRevision: n
  };
  return u({
    ...r,
    fingerprint: $(
      "zx-ai-review-operation-decision:v1",
      r
    )
  });
}, Xs = (e) => {
  const t = {
    sequence: e.sequence,
    kind: e.kind,
    commandId: e.commandId,
    previousSidecarFingerprint: e.previousSidecarFingerprint,
    operationIndexes: [...e.operationIndexes]
  };
  return u({
    ...t,
    fingerprint: $(
      "zx-ai-review-audit-entry:v1",
      t
    )
  });
}, Ge = (e, t) => Ws({
  ...ai(e),
  revision: e.revision + 1,
  status: t.status ?? e.status,
  decisions: t.decisions ?? e.decisions,
  auditEntries: [
    ...e.auditEntries,
    Xs({
      sequence: e.auditEntries.length,
      kind: t.auditKind,
      commandId: t.commandId ?? null,
      previousSidecarFingerprint: e.fingerprint,
      operationIndexes: t.operationIndexes
    })
  ]
}), He = (e, t) => u({
  status: "failure",
  sidecar: null,
  diagnostic: nt({
    code: e,
    stage: e === "review-dependency-invalid" ? "decision" : "sidecar",
    path: t
  })
}), tp = (e) => {
  if (!V(e, [
    "identity",
    "policyRef",
    "proposal",
    "lifecycle"
  ]) || !V(e.identity, ["reviewId"]) || !z(e.identity.reviewId))
    return He("review-input-invalid", "$");
  if (!Us(e.policyRef))
    return He("review-policy-invalid", "$.policyRef");
  if (!zn(e.proposal) || !zn(e.lifecycle))
    return He("review-proposal-invalid", "$.proposal");
  const t = Le(e.proposal);
  if (t.status !== "success" || t.cacheStatus !== "exact")
    return He("review-proposal-invalid", "$.proposal");
  if (!Qd(e))
    return He("review-lifecycle-invalid", "$.lifecycle");
  const n = qd(t.proposal.operationProjection);
  if (!n)
    return He("review-dependency-invalid", "$.proposal.operationProjection");
  const r = Hd(t.proposal);
  if (!r.valid)
    return u({
      status: "failure",
      sidecar: null,
      diagnostic: r.diagnostic
    });
  const i = {
    proposalId: t.proposal.identity.proposalId,
    variantId: t.proposal.identity.variantId,
    proposalFingerprint: t.proposal.fingerprint,
    operationCount: t.proposal.operationProjection.length,
    operationProjectionFingerprint: $(
      "zx-ai-review-operation-projection:v1",
      t.proposal.operationProjection
    ),
    lifecycleRevision: e.lifecycle.revision,
    lifecycleFingerprint: e.lifecycle.fingerprint,
    baseFingerprint: t.proposal.base.fingerprint,
    documentRevision: t.proposal.base.documentRevision,
    annotationFingerprint: t.proposal.base.annotationFingerprint,
    targetFingerprint: t.proposal.base.targetFingerprint,
    planDigest: t.proposal.base.planDigest,
    resultFingerprint: t.proposal.runtimeExecution.resultFingerprint,
    traceFingerprint: t.proposal.runtimeExecution.trace.fingerprint,
    mappingFingerprint: t.proposal.runtimeExecution.mapping.fingerprint,
    effectFingerprint: t.proposal.effectProof.fingerprint,
    richDiffStatus: t.proposal.richDiff.status,
    richDiffSourceBinding: Me(
      t.proposal.richDiff.sourceBinding
    ),
    richDiffUnavailableReason: t.proposal.richDiff.status === "unavailable" ? t.proposal.richDiff.reason : null,
    richDiffFingerprint: $(
      "zx-ai-review-rich-diff-binding:v1",
      t.proposal.richDiff
    )
  }, o = Xs({
    sequence: 0,
    kind: "sidecar-created",
    commandId: null,
    previousSidecarFingerprint: null,
    operationIndexes: n.operationIndexes
  }), s = Ws({
    kind: "zx-ai-review-sidecar-v1",
    version: "1.0.0",
    identity: Me(e.identity),
    proposalBinding: u(i),
    policyRef: Me(e.policyRef),
    profileRef: Me(t.proposal.richDiff.profileRef),
    revision: 0,
    status: "active",
    capability: r.capability,
    items: r.items,
    decisions: t.proposal.operationProjection.map(
      (a) => ep(a)
    ),
    auditEntries: [o]
  });
  return s.items.length > N.maxItems || s.decisions.length > N.maxDecisionEntries || Vd(s) > N.maxBytes ? He("review-budget-exceeded", "$") : qs(s) ? u({ status: "active", sidecar: s }) : He("review-input-invalid", "$.identity.reviewId");
}, np = async (e) => {
  var f;
  const t = e.descriptors ?? qn;
  xo(t);
  const n = new Set(
    t.flatMap(
      (p) => Object.entries(p.ai.nodes).filter(
        ([, d]) => d.supported && d.addressability === "block"
      ).map(([d]) => d)
    )
  ), r = Eo(
    e.document,
    n
  ), i = await Bc(
    t,
    e.policy
  ), o = Ho(
    e.scope,
    e.document.body.content,
    r,
    i.admission,
    i.manifest
  ), s = Wo(
    e.document.body.content,
    r,
    i.admission,
    o,
    e.policy
  ), a = pa([
    ...i.diagnostics,
    ...s.diagnostics
  ]);
  let c = "";
  try {
    c = await Ut(e.document);
  } catch (p) {
    if (p instanceof yi) throw p;
    pe([
      {
        code: "document-format-invalid",
        severity: "error",
        message: "Canonical document v2 contains a non-canonical value."
      }
    ]);
  }
  const l = {
    contractVersion: 1,
    documentVersion: 2,
    schemaVersion: ((f = e.document.meta) == null ? void 0 : f.schemaVersion) ?? null,
    documentRevision: c,
    descriptorFingerprint: i.manifest.descriptorFingerprint,
    scope: o.normalized,
    selection: o.selection,
    manifest: i.manifest,
    nodes: s.nodes,
    operableBlockIds: o.operableBlockIds,
    diagnostics: a,
    policy: e.policy ? { id: e.policy.id, version: e.policy.version } : null
  };
  let g = "";
  try {
    g = await Ut(l);
  } catch (p) {
    if (p instanceof yi) throw p;
    pe([
      {
        code: "policy-result-not-canonical",
        severity: "error",
        message: "AI semantic snapshot payload is not canonicalizable."
      }
    ]);
  }
  return u({
    contractVersion: l.contractVersion,
    documentVersion: l.documentVersion,
    schemaVersion: l.schemaVersion,
    documentRevision: c,
    fingerprint: g,
    descriptorFingerprint: l.descriptorFingerprint,
    scope: l.scope,
    selection: l.selection,
    manifest: l.manifest,
    nodes: l.nodes,
    operableBlockIds: l.operableBlockIds,
    diagnostics: l.diagnostics
  });
}, io = (e, t, n) => u({
  kind: "unavailable",
  reason: n,
  summary: {
    nodeFamily: t.nodeFamily,
    operation: t.operation,
    risk: e.risk,
    resource: {
      status: e.risk === "external-resource" ? "verified" : "none"
    },
    atomicity: t.atomicity,
    actions: ["accept", "reject"]
  }
}), rp = (e) => {
  if (!e.descriptor.deriveReview)
    return io(e.descriptor, e.plan, "projector-missing");
  try {
    return u(
      e.descriptor.deriveReview({
        source: e.source,
        candidate: e.candidate,
        plan: e.plan,
        limits: e.descriptor.limits
      })
    );
  } catch {
    return io(e.descriptor, e.plan, "projector-failed");
  }
}, Ir = (e) => {
  try {
    return Z(e), !1;
  } catch {
    return !0;
  }
}, ip = (e) => {
  const t = [];
  let n = !0, r = !0, i = !0, o = !0, s = !0, a = !0, c = !0, l = !0, g = !0, f = !0, p = !0;
  e.fixtures.forEach((h) => {
    const m = e.adapter.operations[h.operation];
    if (!m) {
      n = r = i = c = !1, g = f = !1;
      return;
    }
    const y = m.decodePayload(h.payload);
    if (!y.valid) {
      n = !1;
      return;
    }
    try {
      const R = m.decodePayload(
        JSON.parse(Z(y.value))
      );
      n && (n = R.valid && Z(R.value) === Z(y.value)), kn(y.value, m.limits);
    } catch {
      n = !1, s = !1;
    }
    const b = {
      document: h.document,
      target: h.target,
      address: h.address,
      preconditions: h.preconditions,
      payload: y.value,
      operation: h.operation
    }, k = Z(h.document), w = Z(h.target), I = m.validate(b), x = m.validate({
      ...b,
      payload: JSON.parse(Z(y.value))
    });
    if (r && (r = Z(I) === Z(x)), i && (i = !Ir(I)), p && (p = !Ir(y.value)), f && (f = Z(h.document) === k && Z(h.target) === w), o && (o = h.address.kind === "stable-local" ? m.collaboration === "stable-rebase" || m.collaboration === "exact-snapshot" : m.collaboration === "exact-snapshot" && m.stream !== "incremental"), a && (a = m.stream !== "incremental" || !!m.validatePartial), g && (g = h.address.kind === "stable-local" && m.collaboration === "stable-rebase" || m.collaboration === "exact-snapshot"), I.valid) {
      c && (c = I.plan.contractVersion === 1 && I.plan.nodeFamily === e.adapter.family && I.plan.operation === h.operation && typeof I.plan.assetsMetaUnchanged == "boolean" && !Ir(I.plan));
      const R = I.plan.effect.kind === "replace-block" ? I.plan.effect.node : h.target, A = rp({
        descriptor: m,
        source: h.target,
        candidate: R,
        plan: I.plan
      });
      l && (l = A.kind === "hunks" || A.kind === "unavailable");
    }
  }), [
    ["codec-round-trip", n],
    ["validation-determinism", r],
    ["plan-canonical", i],
    ["stable-identity-policy", o],
    ["resource-limits", s],
    ["stream-policy", a],
    ["proposal-proof-shape", c],
    ["review-fallback", l],
    ["collaboration-policy", g],
    ["zero-effect-validation", f],
    ["forbidden-live-object", p]
  ].forEach(
    ([h, m]) => t.push({
      id: h,
      status: m ? "passed" : "failed"
    })
  );
  const d = {
    valid: t.every((h) => h.status === "passed"),
    adapterFingerprint: e.adapter.fingerprint,
    coveredOperations: [
      ...new Set(e.fixtures.map(({ operation: h }) => h))
    ].sort((h, m) => h.localeCompare(m)),
    checks: t
  };
  return u({
    ...d,
    fingerprint: O("conformance-report", d)
  });
}, op = (e) => {
  const { fingerprint: t, ...n } = e;
  return e.valid === !0 && e.checks.length > 0 && e.checks.every((r) => r.status === "passed") && e.coveredOperations.length > 0 && new Set(e.coveredOperations).size === e.coveredOperations.length && [...e.coveredOperations].sort((r, i) => r.localeCompare(i)).every(
    (r, i) => r === e.coveredOperations[i]
  ) && t === O("conformance-report", n);
}, vf = async (e) => {
  const t = ip(e);
  let n = t.valid, r = t.valid, i = t.valid;
  for (const [a, c] of e.fixtures.entries()) {
    const l = e.adapter.operations[c.operation], g = l == null ? void 0 : l.decodePayload(c.payload);
    if (!l || !(g != null && g.valid)) {
      n = r = i = !1;
      continue;
    }
    const f = await np({
      document: c.document,
      scope: { kind: "document" }
    }), p = pp({
      schema: fa(),
      descriptorFingerprint: f.descriptorFingerprint,
      adapters: [e.adapter],
      installedComponents: Bp([
        e.adapter
      ]),
      admittedAdapterFingerprints: [e.adapter.fingerprint],
      conformanceReports: [t]
    });
    if (!p.valid) {
      n = r = i = !1;
      continue;
    }
    const d = p.snapshot, h = d.entries.find(
      (_) => _.adapter.adapterFingerprint === e.adapter.fingerprint
    );
    if (!h) {
      n = r = i = !1;
      continue;
    }
    const m = Kn(
      h,
      c.operation
    );
    let y = c.address.kind === "validated-path" ? {
      ...c.address,
      sourceSnapshotFingerprint: f.fingerprint
    } : c.address;
    if (y.kind === "stable-local" && l.stream === "incremental" && y.localType !== "media" && !y.relativeText) {
      const _ = {
        encoding: "base64url",
        value: "AA",
        byteLength: 1,
        fingerprint: O("conformance-relative-position", {
          adapter: e.adapter.fingerprint,
          operation: c.operation
        })
      }, le = {
        kind: "selection-endpoint",
        blockId: y.blockId,
        semanticOffset: 0,
        affinity: "right",
        relativePosition: _,
        capabilityFingerprint: m
      };
      y = {
        ...y,
        relativeText: {
          blockId: y.blockId,
          localType: y.localType,
          localId: y.localId,
          semanticOffset: 0,
          affinity: "forward",
          anchor: {
            ...le,
            fingerprint: O(
              "conformance-relative-anchor",
              le
            )
          }
        }
      };
    }
    const b = {
      addressFingerprint: Wr(y),
      blockId: y.blockId,
      nodeType: c.target.type ?? e.adapter.nodeType,
      contentFingerprint: Ve(c.target),
      shapeFingerprint: wn(c.target),
      capabilityFingerprint: m
    }, k = await ac({
      snapshot: f,
      envelope: {
        protocolVersion: 2,
        source: {
          snapshotFingerprint: f.fingerprint,
          documentRevision: f.documentRevision,
          descriptorFingerprint: f.descriptorFingerprint,
          registryFingerprint: d.fingerprint
        },
        operations: [
          {
            kind: "node.apply",
            adapter: h.adapter,
            target: y,
            preconditions: b,
            operation: c.operation,
            payload: g.value
          }
        ]
      },
      complex: {
        document: c.document,
        registry: d,
        runner: e.createRunner(d),
        resourceProfileFingerprint: Jn().resourceProfile.fingerprint,
        addressResolution: y.kind === "stable-local" && y.relativeText ? {
          resolveRelativeText: () => ({
            blockId: y.blockId,
            localId: y.localId,
            semanticOffset: y.relativeText.semanticOffset
          })
        } : void 0
      }
    });
    if (!k.valid) {
      n = r = i = !1;
      continue;
    }
    const w = k.plan, I = w.steps[0];
    if (!I || I.kind !== "node.apply") {
      n = r = i = !1;
      continue;
    }
    const x = O("conformance-lifecycle", {
      adapter: e.adapter.fingerprint,
      operation: c.operation,
      index: a,
      plan: w
    }).slice(7, 31), R = cd({
      proposalId: `conformance_${x}`,
      revision: 0
    }), A = Od({
      runtime: Ee,
      baseDocument: c.document,
      plan: w,
      identity: {
        proposalId: R.proposalId,
        variantId: `conformance_variant_${x}`
      },
      lifecycle: R,
      provenance: {
        sourceId: `complex-conformance:${e.adapter.id}`,
        sequence: a + 1,
        refs: [
          {
            id: I.planFragmentFingerprint,
            type: "plan"
          }
        ]
      },
      runtimeContext: { protocol: "zx-runtime-execution-context-v1" }
    });
    if (n && (n = A.status === "success"), A.status !== "success") {
      r = i = !1;
      continue;
    }
    const X = tp({
      identity: { reviewId: `conformance_review_${x}` },
      policyRef: Ks,
      proposal: A.proposal,
      lifecycle: A.proposal.lifecycle
    });
    r && (r = X.status === "active"), i && (i = A.proposal.base.documentRevision === v(c.document) && /^sha256:[0-9a-f]{64}$/.test(A.proposal.base.planDigest) && Z(A.proposal.base.plan) === Z(w) && Z(I.adapter) === Z(h.adapter) && w.source.registryFingerprint === d.fingerprint);
  }
  const o = [
    ...t.checks,
    {
      id: "public-runtime-proposal",
      status: n ? "passed" : "failed"
    },
    {
      id: "public-review-sidecar",
      status: r ? "passed" : "failed"
    },
    {
      id: "fresh-artifact-binding",
      status: i ? "passed" : "failed"
    }
  ], s = {
    valid: o.every((a) => a.status === "passed"),
    adapterFingerprint: t.adapterFingerprint,
    coveredOperations: t.coveredOperations,
    checks: o
  };
  return u({
    ...s,
    fingerprint: O("conformance-report", s)
  });
}, Gs = /* @__PURE__ */ new WeakMap(), Vr = /* @__PURE__ */ new Map(), $n = (e) => `${e.descriptor}\0${e.nodeType}\0${e.id}`, Ft = (e) => `${e.id}\0${e.version}\0${e.fingerprint}`, sp = (e, t) => Ft(e) === Ft(t), ap = (e) => Object.values(e.operations).every(
  (t) => t.limits.nodeBudget.kind === e.family && t.limits.maxPayloadBytes > 0 && t.limits.maxOutputBytes > 0 && t.limits.timeoutMs > 0 && t.limits.maxDiagnostics > 0 && typeof t.decodePayload == "function" && typeof t.validate == "function" && (t.stream !== "incremental" || e.address.stableLocalTypes.length > 0 && typeof t.validatePartial == "function")
), cp = (e, t, n) => {
  var c, l, g;
  if (!Oa().valid) return !1;
  const i = Ta(), o = ["editor", "render", "ai"].map(
    (f) => i[f].entries.find((p) => p.joinKey === e)
  ), s = qn.find(
    (f) => f.name === t
  ), a = s == null ? void 0 : s.ai.nodes[n];
  return o.every(Boolean) && ((c = o[0]) == null ? void 0 : c.structuralSupport) === "supported" && ((l = o[1]) == null ? void 0 : l.renderSupport) !== "unsupported" && ((g = o[2]) == null ? void 0 : g.aiSupport) === "supported" && (a == null ? void 0 : a.supported) === !0;
}, Zs = (e) => O("adapter-descriptor", {
  contractVersion: e.contractVersion,
  id: e.id,
  version: e.version,
  component: e.component,
  hostAdmission: e.hostAdmission,
  descriptor: e.descriptor,
  descriptorFingerprint: e.descriptorFingerprint,
  nodeType: e.nodeType,
  schemaJoinKey: e.schemaJoinKey,
  schemaFingerprint: e.schemaFingerprint,
  provenanceFingerprint: e.provenanceFingerprint,
  family: e.family,
  dependencies: [...e.dependencies].sort(
    (t, n) => `${t.adapterId}:${t.adapterVersion}:${t.adapterFingerprint}`.localeCompare(
      `${n.adapterId}:${n.adapterVersion}:${n.adapterFingerprint}`
    )
  ),
  address: e.address,
  operations: Object.values(e.operations).map((t) => ({
    name: t.name,
    risk: t.risk,
    stream: t.stream,
    collaboration: t.collaboration,
    limits: t.limits,
    compiler: t.compiler
  })).sort((t, n) => t.name.localeCompare(n.name))
}), lp = (e) => ({
  adapter: {
    descriptor: e.descriptor,
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: e.nodeType,
    adapterId: e.id,
    adapterVersion: e.version,
    adapterFingerprint: e.fingerprint
  },
  component: e.component,
  hostAdmission: e.hostAdmission,
  compilerRefs: Object.values(e.operations).map((t) => t.compiler).sort((t, n) => t.id.localeCompare(n.id)),
  schemaJoinKey: e.schemaJoinKey,
  schemaFingerprint: e.schemaFingerprint,
  provenanceFingerprint: e.provenanceFingerprint,
  family: e.family,
  address: e.address,
  operations: Object.values(e.operations).map((t) => ({
    name: t.name,
    risk: t.risk,
    stream: t.stream,
    collaboration: t.collaboration,
    limits: t.limits,
    compiler: t.compiler
  })).sort((t, n) => t.name.localeCompare(n.name)),
  dependencies: [...e.dependencies].sort(
    (t, n) => t.adapterId.localeCompare(n.adapterId)
  )
}), dp = (e, t) => {
  const n = new Map(
    e.map((a) => [a.fingerprint, a])
  ), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set(), o = [], s = (a) => {
    if (!i.has(a.fingerprint)) {
      if (r.has(a.fingerprint)) {
        t.push(
          B(
            "complex-registry-invalid",
            "registry",
            `$.adapters.${a.id}.dependencies`
          )
        );
        return;
      }
      r.add(a.fingerprint), a.dependencies.forEach((c) => {
        const l = n.get(c.adapterFingerprint);
        !l || l.id !== c.adapterId || l.version !== c.adapterVersion ? t.push(
          B(
            "complex-registry-invalid",
            "registry",
            `$.adapters.${a.id}.dependencies`
          )
        ) : s(l);
      }), r.delete(a.fingerprint), i.add(a.fingerprint), o.push(a);
    }
  };
  return [...e].sort((a, c) => $n(a).localeCompare($n(c))).forEach(s), o;
}, Ys = (e, t) => {
  const n = [], r = new Map(
    e.schema.nodes.map((d) => [d.joinKey, d])
  ), i = new Set(e.installedComponents.map(Ft)), o = new Set(e.admittedAdapterFingerprints), s = new Map(
    e.conformanceReports.map((d) => [
      d.adapterFingerprint,
      d
    ])
  );
  s.size !== e.conformanceReports.length && n.push(
    B(
      "complex-registry-invalid",
      "registry",
      "$.conformanceReports"
    )
  );
  const a = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Map();
  e.adapters.forEach((d, h) => {
    var x;
    const m = `$.adapters[${h}]`, y = Zs(
      d
    ), b = $n(d), k = c.get(d.id), w = s.get(d.fingerprint), I = d.family !== "custom" || !!w && op(w) && w.adapterFingerprint === d.fingerprint && (t === "conformance-candidate" || [
      "public-runtime-proposal",
      "public-review-sidecar",
      "fresh-artifact-binding"
    ].every(
      (R) => w.checks.some(
        (A) => A.id === R && A.status === "passed"
      )
    )) && F(w.coveredOperations) === F(Object.keys(d.operations).sort());
    (d.contractVersion !== 1 || !T(d.id) || !T(d.version) || !H(d.fingerprint) || d.fingerprint !== y || a.has(b) || k !== void 0 && k !== d.fingerprint || !r.has(d.schemaJoinKey) || ((x = r.get(d.schemaJoinKey)) == null ? void 0 : x.key) !== d.nodeType || !cp(
      d.schemaJoinKey,
      d.descriptor,
      d.nodeType
    ) || d.schemaFingerprint !== e.schema.schemaKernelFingerprint || d.descriptorFingerprint !== e.descriptorFingerprint || !i.has(Ft(d.component)) || !i.has(Ft(d.hostAdmission)) || !o.has(d.fingerprint) || !I || !ap(d) || Object.values(d.operations).length === 0 || Object.entries(d.operations).some(
      ([R, A]) => R !== A.name || !i.has(Ft(A.compiler))
    )) && n.push(
      B(
        "complex-registry-invalid",
        "registry",
        m
      )
    ), a.add(b), c.set(d.id, d.fingerprint);
  });
  const l = dp(e.adapters, n);
  if (n.length > 0)
    return u({ valid: !1, snapshot: null, diagnostics: n });
  const g = l.map(lp), f = {
    contractVersion: 1,
    schemaFingerprint: e.schema.schemaKernelFingerprint,
    descriptorFingerprint: e.descriptorFingerprint,
    entries: g
  }, p = u({
    ...f,
    fingerprint: O("registry", f)
  });
  if (Gs.set(
    p,
    new Map(l.map((d) => [$n(d), d]))
  ), t === "admit") {
    const d = Vr.get(p.fingerprint);
    if (d && F(d) !== F(p))
      return u({
        valid: !1,
        snapshot: null,
        diagnostics: [
          B(
            "complex-registry-invalid",
            "registry",
            "$.fingerprint"
          )
        ]
      });
    Vr.set(p.fingerprint, p);
  }
  return u({ valid: !0, snapshot: p, diagnostics: [] });
}, kf = (e) => Ys(e, "admit"), pp = (e) => Ys(e, "conformance-candidate"), fp = (e) => {
  const { fingerprint: t, ...n } = e;
  return e.contractVersion === 1 && H(e.schemaFingerprint) && H(e.descriptorFingerprint) && Array.isArray(e.entries) && e.fingerprint === O("registry", n);
}, Qs = (e, t) => {
  var n;
  return ((n = Gs.get(e)) == null ? void 0 : n.get(`${t.descriptor}\0${t.nodeType}\0${t.adapterId}`)) ?? null;
}, wf = (e) => Vr.get(e) ?? null, up = (e, t) => {
  const n = e.entries.find(
    (s) => F(s.adapter) === F(t.adapter)
  ), r = n == null ? void 0 : n.operations.find(
    (s) => s.name === t.operation
  ), i = n ? Qs(e, {
    descriptor: n.adapter.descriptor,
    nodeType: n.adapter.nodeType,
    adapterId: n.adapter.adapterId
  }) : null, o = i == null ? void 0 : i.operations[t.operation];
  return !n || !r || !i || i.fingerprint !== n.adapter.adapterFingerprint || !o || !sp(r.compiler, o.compiler) ? null : u({ entry: n, operation: r });
}, ea = (e) => O("runtime-resource-profile-binding", {
  runtimeResourceProfileFingerprint: e.runtimeResourceProfileFingerprint,
  registryFingerprint: e.registryFingerprint,
  adapter: e.adapter,
  operation: e.operation
}), ce = u({
  table: {
    maxPayloadBytes: 512e3,
    maxDepth: 48,
    maxKeys: 12e3,
    maxArrayLength: 4096,
    maxStringLength: 64e3,
    maxDiagnostics: 8,
    maxOutputBytes: 1e6,
    timeoutMs: 2e3,
    nodeBudget: {
      kind: "table",
      maxCells: 2e3,
      maxRowSpan: 100,
      maxColSpan: 100
    }
  },
  list: {
    maxPayloadBytes: 256e3,
    maxDepth: 32,
    maxKeys: 8e3,
    maxArrayLength: 4096,
    maxStringLength: 64e3,
    maxDiagnostics: 8,
    maxOutputBytes: 512e3,
    timeoutMs: 2e3,
    nodeBudget: {
      kind: "list",
      maxItems: 2e3,
      maxDepth: 16
    }
  },
  code: {
    maxPayloadBytes: 1e6,
    maxDepth: 12,
    maxKeys: 128,
    maxArrayLength: 128,
    maxStringLength: 5e5,
    maxDiagnostics: 8,
    maxOutputBytes: 12e5,
    timeoutMs: 2e3,
    nodeBudget: {
      kind: "code",
      maxChars: 5e5,
      maxLines: 5e4
    }
  },
  media: {
    maxPayloadBytes: 64e3,
    maxDepth: 16,
    maxKeys: 256,
    maxArrayLength: 64,
    maxStringLength: 8192,
    maxDiagnostics: 8,
    maxOutputBytes: 128e3,
    timeoutMs: 2e3,
    nodeBudget: {
      kind: "media",
      maxResources: 1,
      maxAttrBytes: 16384
    }
  },
  custom: {
    maxPayloadBytes: 256e3,
    maxDepth: 32,
    maxKeys: 8e3,
    maxArrayLength: 2048,
    maxStringLength: 64e3,
    maxDiagnostics: 8,
    maxOutputBytes: 512e3,
    timeoutMs: 2e3,
    nodeBudget: { kind: "custom", maxComplexity: 2e4 }
  }
}), di = (e, t = "1.0.0") => u({
  id: e,
  version: t,
  fingerprint: O("component-ref", { id: e, version: t })
}), Zn = (e) => {
  const t = di(e);
  return u({
    ...t,
    kind: "complex-node-compiler",
    planContractVersion: 1
  });
}, gp = () => {
  const e = di(
    "zx.text-editor.complex-node.first-party-admission"
  );
  return u({ ...e, kind: "trusted-adapter-admission" });
}, L = (e) => {
  if (!K(e.input) || !oe(
    e.input,
    e.required,
    e.optional ?? []
  ) || !e.validate(e.input))
    return u({
      valid: !1,
      value: null,
      diagnostics: [
        B(
          "complex-payload-invalid",
          "decode",
          "$.payload"
        )
      ]
    });
  try {
    return u({
      valid: !0,
      value: P(e.input),
      diagnostics: []
    });
  } catch {
    return u({
      valid: !1,
      value: null,
      diagnostics: [
        B(
          "complex-payload-invalid",
          "decode",
          "$.payload"
        )
      ]
    });
  }
}, Fe = (e) => !(!K(e) || !Object.keys(e).every(
  (n) => ["type", "attrs", "content", "marks", "text"].includes(n)
) || e.type !== void 0 && typeof e.type != "string" || e.text !== void 0 && typeof e.text != "string" || e.attrs !== void 0 && !K(e.attrs) || e.content !== void 0 && (!Array.isArray(e.content) || !e.content.every(Fe)) || e.marks !== void 0 && (!Array.isArray(e.marks) || !e.marks.every(Fe))), _t = (e, t, n, r) => {
  let i = 0;
  const o = (s) => {
    var a;
    return ((a = s.attrs) == null ? void 0 : a[t]) === n ? (i += 1, r(s)) : s.content ? {
      ...P(s),
      content: s.content.map(o).filter((c) => c !== null)
    } : P(s);
  };
  return { root: o(e) ?? P(e), matched: i };
}, _r = (e, t) => {
  const n = [], r = (i) => {
    var s, a;
    const o = (s = i.attrs) == null ? void 0 : s[t];
    typeof o == "string" && n.push(o), (a = i.content) == null || a.forEach(r);
  };
  return r(e), n;
}, ta = (e, t) => t.every((n) => {
  const r = _r(e, n);
  return r.every(T) && new Set(r).size === r.length;
}), Yn = (e) => u({
  contractVersion: 1,
  nodeFamily: e.family,
  operation: e.operation,
  atomicity: e.atomicity ?? "whole-operation",
  effect: {
    kind: "replace-block",
    blockId: e.blockId,
    node: P(e.candidate)
  },
  targetFingerprint: Ve(e.source),
  resultFingerprint: Ve(e.candidate),
  assetsMetaUnchanged: e.assetsMetaUnchanged ?? !0
}), Ff = (e) => u({
  contractVersion: 1,
  nodeFamily: e.family,
  operation: e.operation,
  atomicity: "declared-parts",
  effect: {
    kind: "replace-text",
    blockId: e.blockId,
    startOffset: e.startOffset,
    endOffset: e.endOffset,
    text: e.text
  },
  targetFingerprint: Ve(e.source),
  resultFingerprint: O("text-effect-result", {
    source: e.source,
    startOffset: e.startOffset,
    endOffset: e.endOffset,
    text: e.text
  }),
  assetsMetaUnchanged: !0
}), Yt = (e, t = "$.payload") => u({
  valid: !1,
  plan: null,
  diagnostics: [B(e, "validation", t)]
}), Qn = (e) => u({ valid: !0, plan: e, diagnostics: [] }), er = (e) => {
  const t = e.version ?? "1.0.0", n = di(
    `${e.id}.component`,
    t
  ), r = {
    contractVersion: 1,
    id: e.id,
    version: t,
    component: n,
    hostAdmission: e.hostAdmission ?? gp(),
    descriptor: e.descriptor,
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: e.nodeType,
    schemaJoinKey: e.schemaJoinKey ?? `node:${e.nodeType}`,
    schemaFingerprint: e.schemaFingerprint,
    provenanceFingerprint: e.provenanceFingerprint,
    family: e.family,
    dependencies: e.dependencies ?? [],
    address: e.address ?? {
      stableLocalTypes: e.family === "table" ? ["row", "cell"] : e.family === "list" ? ["list-item"] : e.family === "code" ? ["code-text"] : e.family === "media" ? ["media"] : ["custom"],
      validatedPathFallback: !0
    },
    operations: e.operations
  };
  return u({
    ...r,
    fingerprint: Zs(r)
  });
}, Qt = (e, t, n) => {
  var r;
  if (((r = e.attrs) == null ? void 0 : r[t]) === n) return e;
  for (const i of e.content ?? []) {
    const o = Qt(i, t, n);
    if (o) return o;
  }
  return null;
}, mp = /* @__PURE__ */ new Set([
  "plaintext",
  "text",
  "javascript",
  "typescript",
  "json",
  "html",
  "css",
  "bash",
  "python",
  "go",
  "rust",
  "java",
  "sql",
  "yaml",
  "markdown",
  "vue"
]), hp = (e) => e.replace(/\r\n?/g, `
`), oo = (e, t) => {
  if (t <= 0 || t >= e.length) return !1;
  const n = e.charCodeAt(t - 1), r = e.charCodeAt(t);
  return n >= 55296 && n <= 56319 && r >= 56320 && r <= 57343;
}, Vn = (e) => (e.content ?? []).map((t) => t.text ?? "").join(""), yp = (e) => [...e].some((t) => {
  const n = t.charCodeAt(0);
  return n <= 8 || n === 11 || n === 12 || n >= 14 && n <= 31 || n === 127;
}), na = (e) => e.length <= ce.code.nodeBudget.maxChars && e.split(`
`).length <= ce.code.nodeBudget.maxLines && !yp(e), bp = (e, t) => ({
  ...P(e),
  content: t.length > 0 ? [{ type: "text", text: t }] : []
}), xp = (e) => (t) => {
  var i;
  const n = Vn(t.source).split(`
`), r = Vn(t.candidate).split(`
`);
  return n.length + r.length > 2e3 ? u({
    kind: "unavailable",
    reason: "over-limit",
    summary: {
      nodeFamily: "code",
      operation: e,
      risk: e === "code.language.set" ? "structural" : "textual",
      resource: { status: "none" },
      atomicity: e === "code.language.set" ? "whole-operation" : "declared-parts",
      actions: ["accept", "reject"]
    }
  }) : u({
    kind: "hunks",
    atomicity: e === "code.language.set" || e === "code.block.replace" ? "whole-operation" : "declared-parts",
    hunks: [
      {
        id: O("code-review-hunk", {
          operation: e,
          before: n,
          after: r
        }),
        localId: String(((i = t.source.attrs) == null ? void 0 : i.blockId) ?? "code"),
        kind: e === "code.language.set" ? "attrs" : "text",
        summary: `${e}:${n.length}->${r.length}`,
        beforeFingerprint: O("review-before", n),
        afterFingerprint: O("review-after", r)
      }
    ]
  });
}, vr = (e) => ({
  name: e.name,
  risk: e.text ? "textual" : "structural",
  stream: e.text ? "incremental" : "atomic",
  collaboration: e.text ? "stable-rebase" : "exact-snapshot",
  limits: ce.code,
  compiler: Zn(
    `zx.text-editor.complex-node.code.${e.name}`
  ),
  decodePayload: e.decodePayload,
  validate: (t) => {
    const n = e.apply(t.target, t.payload);
    return !n || n.type !== "codeBlock" || (n.content ?? []).some(
      (r) => {
        var i;
        return r.type !== "text" || (((i = r.marks) == null ? void 0 : i.length) ?? 0) > 0;
      }
    ) || !na(Vn(n)) ? Yt("complex-schema-invalid") : Qn(
      Yn({
        family: "code",
        operation: e.name,
        source: t.target,
        candidate: n,
        blockId: t.address.blockId,
        atomicity: e.text ? "declared-parts" : "whole-operation"
      })
    );
  },
  validatePartial: e.text ? (t) => t.accumulatedBytes <= ce.code.nodeBudget.maxChars ? u({
    valid: !0,
    projection: { sequence: t.sequence }
  }) : u({ valid: !1, projection: null, diagnostics: [] }) : void 0,
  deriveReview: xp(e.name)
}), Ip = (e) => {
  const t = {}, n = (r) => vr({
    name: r,
    text: !0,
    decodePayload: (i) => L({
      input: i,
      required: r === "code.text.insert" ? ["startOffset", "text"] : r === "code.text.delete" ? ["startOffset", "endOffset"] : ["startOffset", "endOffset", "text"],
      validate: (o) => Number.isSafeInteger(o.startOffset) && o.startOffset >= 0 && (r === "code.text.insert" || Number.isSafeInteger(o.endOffset) && o.endOffset >= o.startOffset) && (r === "code.text.delete" || typeof o.text == "string")
    }),
    apply: (i, o) => {
      const s = Vn(i), a = o.startOffset, c = r === "code.text.insert" ? a : o.endOffset, l = r === "code.text.delete" ? "" : o.text;
      if (a > s.length || c > s.length || oo(s, a) || oo(s, c))
        return null;
      const g = hp(
        `${s.slice(0, a)}${l}${s.slice(c)}`
      );
      return na(g) ? bp(i, g) : null;
    }
  });
  return t["code.text.replace"] = n("code.text.replace"), t["code.text.insert"] = n("code.text.insert"), t["code.text.delete"] = n("code.text.delete"), t["code.language.set"] = vr({
    name: "code.language.set",
    text: !1,
    decodePayload: (r) => L({
      input: r,
      required: ["language"],
      validate: (i) => i.language === null || mp.has(String(i.language))
    }),
    apply: (r, i) => ({
      ...P(r),
      attrs: { ...r.attrs ?? {}, language: i.language }
    })
  }), t["code.block.replace"] = vr({
    name: "code.block.replace",
    text: !1,
    decodePayload: (r) => L({
      input: r,
      required: ["block"],
      validate: (i) => Fe(i.block) && i.block.type === "codeBlock" && K(i.block.attrs)
    }),
    apply: (r, i) => {
      var o, s;
      return ((o = i.block.attrs) == null ? void 0 : o.blockId) === ((s = r.attrs) == null ? void 0 : s.blockId) ? P(i.block) : null;
    }
  }), er({
    id: "zx.text-editor.complex-node.code-block",
    descriptor: "builtinNodes",
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: "codeBlock",
    schemaFingerprint: e.schemaFingerprint,
    provenanceFingerprint: e.provenanceFingerprint,
    family: "code",
    operations: t
  });
}, Se = /* @__PURE__ */ new Set(["bulletList", "orderedList"]), vp = (e, t, n) => {
  let r = 0, i = !0;
  const o = /* @__PURE__ */ new Set(), s = (a, c, l) => {
    var g, f, p;
    if (c > t && (i = !1), a.type === "listItem") {
      r += 1;
      const d = (g = a.attrs) == null ? void 0 : g.blockId;
      !T(d) || o.has(d) ? i = !1 : o.add(d), Se.has(String(l)) || (i = !1);
      const h = a.content ?? [];
      (h.length === 0 || ((f = h[0]) == null ? void 0 : f.type) !== "paragraph" || h.slice(1).some(
        (m) => m.type !== l || !Se.has(String(m.type))
      ) || h.filter((m) => Se.has(String(m.type))).length > 1) && (i = !1);
    }
    Se.has(String(a.type)) && ((a.content ?? []).every((d) => d.type === "listItem") || (i = !1)), (p = a.content) == null || p.forEach(
      (d) => s(
        d,
        c + (Se.has(String(d.type)) ? 1 : 0),
        a.type ?? null
      )
    );
  };
  return s(e, 0, null), i && r > 0 && r <= n;
}, kp = (e, t, n) => {
  const r = _t(e, "blockId", t, (i) => {
    if (i.type !== "listItem") return i;
    const o = [...i.content ?? []], s = o.findIndex(
      (c) => c.type === "paragraph"
    );
    if (s < 0) return i;
    const a = o[s];
    return o[s] = {
      ...P(a),
      content: n.length > 0 ? [{ type: "text", text: n }] : []
    }, { ...P(i), content: o };
  });
  return r.matched === 1 ? r.root : null;
}, $t = (e, t, n) => {
  let r = 0, i = !1;
  const o = (a) => {
    const c = (a.content ?? []).map(o), l = {
      ...P(a),
      ...a.content ? { content: c } : {}
    };
    if (Se.has(String(l.type))) {
      const g = (l.content ?? []).findIndex(
        (f) => {
          var p;
          return f.type === "listItem" && ((p = f.attrs) == null ? void 0 : p.blockId) === t;
        }
      );
      if (g >= 0) {
        r += 1;
        const f = n(l, g);
        if (!f) i = !0;
        else return f;
      }
    }
    return l;
  }, s = o(e);
  return r === 1 && !i ? s : null;
}, ra = (e, t, n = []) => {
  if (t(e)) return n;
  for (const [r, i] of (e.content ?? []).entries()) {
    const o = ra(i, t, [...n, r]);
    if (o) return o;
  }
  return null;
}, kr = (e, t) => {
  var r;
  let n = e;
  for (const i of t) n = (r = n == null ? void 0 : n.content) == null ? void 0 : r[i];
  return n ?? null;
}, wp = (e, t) => {
  const n = ra(
    e,
    (y) => {
      var b;
      return y.type === "listItem" && ((b = y.attrs) == null ? void 0 : b.blockId) === t;
    }
  );
  if (!n || n.length < 3) return null;
  const r = P(e), i = n.slice(0, -1), o = i.slice(0, -1), s = o.slice(0, -1), a = kr(r, i), c = kr(r, o), l = kr(r, s), g = n.at(-1), f = i.at(-1), p = o.at(-1);
  if (!a || !c || !l || !Se.has(String(a.type)) || c.type !== "listItem" || !Se.has(String(l.type)))
    return null;
  const d = [...a.content ?? []], [h] = d.splice(g, 1);
  if (!h) return null;
  if (a.content = d, d.length === 0) {
    const y = [...c.content ?? []];
    y.splice(f, 1), c.content = y;
  }
  const m = [...l.content ?? []];
  return m.splice(p + 1, 0, h), l.content = m, r;
}, so = (e) => O("list-item-intrinsic", {
  type: e.type,
  attrs: e.attrs ?? null,
  content: (e.content ?? []).filter(
    (t) => !Se.has(String(t.type))
  )
}), Lr = (e) => {
  const t = /* @__PURE__ */ new Map(), n = (r) => {
    var i, o;
    r.type === "listItem" && T((i = r.attrs) == null ? void 0 : i.blockId) && t.set(r.attrs.blockId, r), (o = r.content) == null || o.forEach(n);
  };
  return n(e), t;
}, Fp = (e, t, n) => {
  const r = Lr(e), i = Lr(t), o = [...i.keys()].filter((c) => !r.has(c)), s = [...r.keys()].filter((c) => !i.has(c));
  if (n === "item.insert" && (o.length !== 1 || s.length !== 0) || n === "item.delete" && (s.length !== 1 || o.length !== 0) || !["item.insert", "item.delete"].includes(n) && (o.length !== 0 || s.length !== 0))
    return !1;
  const a = [...r].filter(([c, l]) => {
    const g = i.get(c);
    return g && so(l) !== so(g);
  });
  return n === "item.text.update" ? a.length === 1 : a.length === 0;
}, Rp = (e) => (t) => {
  const n = [
    .../* @__PURE__ */ new Set([
      ..._r(t.source, "blockId"),
      ..._r(t.candidate, "blockId")
    ])
  ].sort();
  return n.length > ce.list.nodeBudget.maxItems ? u({
    kind: "unavailable",
    reason: "over-limit",
    summary: {
      nodeFamily: "list",
      operation: e,
      risk: "structural",
      resource: { status: "none" },
      atomicity: "whole-operation",
      actions: ["accept", "reject"]
    }
  }) : u({
    kind: "hunks",
    atomicity: e === "item.text.update" ? "declared-parts" : "whole-operation",
    hunks: n.map((r) => {
      const i = Qt(t.source, "blockId", r), o = Qt(t.candidate, "blockId", r);
      return {
        id: O("list-review-hunk", {
          operation: e,
          id: r,
          before: i,
          after: o
        }),
        localId: r,
        kind: e.includes("text") ? "text" : "structure",
        summary: `${e}:${r}`,
        beforeFingerprint: i ? O("review-before", i) : null,
        afterFingerprint: o ? O("review-after", o) : null
      };
    })
  });
}, ot = (e) => ({
  name: e.name,
  risk: e.text ? "textual" : "structural",
  stream: e.text ? "incremental" : "atomic",
  collaboration: e.text ? "stable-rebase" : "exact-snapshot",
  limits: ce.list,
  compiler: Zn(
    `zx.text-editor.complex-node.list.${e.name}`
  ),
  decodePayload: e.decodePayload,
  validate: (t) => {
    const n = e.apply(t.target, t.payload);
    return !n || !vp(
      n,
      ce.list.nodeBudget.maxDepth,
      ce.list.nodeBudget.maxItems
    ) || !Fp(t.target, n, e.name) ? Yt("complex-schema-invalid") : Qn(
      Yn({
        family: "list",
        operation: e.name,
        source: t.target,
        candidate: n,
        blockId: t.address.blockId,
        atomicity: e.text ? "declared-parts" : "whole-operation"
      })
    );
  },
  validatePartial: e.text ? (t) => t.accumulatedBytes <= ce.list.maxPayloadBytes ? u({
    valid: !0,
    projection: { sequence: t.sequence }
  }) : u({ valid: !1, projection: null, diagnostics: [] }) : void 0,
  deriveReview: Rp(e.name)
}), ao = (e) => {
  const t = e.nodeType ?? "bulletList", n = {};
  return n["item.text.update"] = ot({
    name: "item.text.update",
    text: !0,
    decodePayload: (r) => L({
      input: r,
      required: ["itemId", "text"],
      validate: (i) => T(i.itemId) && typeof i.text == "string" && i.text.length <= ce.list.maxStringLength
    }),
    apply: (r, i) => kp(r, i.itemId, i.text)
  }), n["list.type.toggle"] = ot({
    name: "list.type.toggle",
    decodePayload: (r) => L({
      input: r,
      required: ["itemId", "listType"],
      validate: (i) => T(i.itemId) && Se.has(String(i.listType))
    }),
    apply: (r, i) => $t(r, i.itemId, (o) => ({
      ...o,
      type: i.listType
    }))
  }), n["item.indent"] = ot({
    name: "item.indent",
    decodePayload: (r) => L({
      input: r,
      required: ["itemId"],
      validate: (i) => T(i.itemId)
    }),
    apply: (r, i) => $t(r, i.itemId, (o, s) => {
      if (s === 0) return null;
      const a = [...o.content ?? []], [c] = a.splice(s, 1), l = P(a[s - 1]), g = [...l.content ?? []], f = g.findIndex(
        (p) => p.type === o.type
      );
      return f >= 0 ? g[f] = {
        ...P(g[f]),
        content: [...g[f].content ?? [], c]
      } : g.push({ type: o.type, content: [c] }), a[s - 1] = { ...l, content: g }, { ...o, content: a };
    })
  }), n["item.outdent"] = ot({
    name: "item.outdent",
    decodePayload: (r) => L({
      input: r,
      required: ["itemId"],
      validate: (i) => T(i.itemId)
    }),
    apply: (r, i) => wp(r, i.itemId)
  }), n["item.insert"] = ot({
    name: "item.insert",
    decodePayload: (r) => L({
      input: r,
      required: ["afterItemId", "item"],
      validate: (i) => T(i.afterItemId) && Fe(i.item) && i.item.type === "listItem"
    }),
    apply: (r, i) => $t(r, i.afterItemId, (o, s) => {
      const a = [...o.content ?? []], c = new Set(Lr(r).keys()), l = `item_${O("list-item-allocation", {
        source: r,
        afterItemId: i.afterItemId,
        item: {
          ...i.item,
          attrs: { ...i.item.attrs ?? {}, blockId: null }
        }
      }).slice(7, 31)}`;
      let g = l, f = 0;
      for (; c.has(g); )
        f += 1, g = `${l}_${f}`;
      return a.splice(s + 1, 0, {
        ...P(i.item),
        attrs: { ...i.item.attrs ?? {}, blockId: g }
      }), { ...o, content: a };
    })
  }), n["item.delete"] = ot({
    name: "item.delete",
    decodePayload: (r) => L({
      input: r,
      required: ["itemId"],
      validate: (i) => T(i.itemId)
    }),
    apply: (r, i) => $t(r, i.itemId, (o, s) => {
      const a = [...o.content ?? []];
      return a.length <= 1 ? null : (a.splice(s, 1), { ...o, content: a });
    })
  }), n["item.reorder-local"] = ot({
    name: "item.reorder-local",
    decodePayload: (r) => L({
      input: r,
      required: ["itemId", "beforeItemId"],
      validate: (i) => T(i.itemId) && (i.beforeItemId === null || T(i.beforeItemId)) && i.beforeItemId !== i.itemId
    }),
    apply: (r, i) => $t(r, i.itemId, (o, s) => {
      const a = [...o.content ?? []], [c] = a.splice(s, 1), l = i.beforeItemId === null ? a.length : a.findIndex(
        (g) => {
          var f;
          return ((f = g.attrs) == null ? void 0 : f.blockId) === i.beforeItemId;
        }
      );
      return l < 0 ? null : (a.splice(l, 0, c), { ...o, content: a });
    })
  }), er({
    id: `zx.text-editor.complex-node.list.${t}`,
    descriptor: "builtinNodes",
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: t,
    schemaFingerprint: e.schemaFingerprint,
    provenanceFingerprint: e.provenanceFingerprint,
    family: "list",
    operations: n
  });
}, kt = (e) => u({
  ...e,
  fingerprint: O("media-profile", e)
}), Sp = u({
  image: kt({
    kind: "image",
    nodeType: "image",
    assetTypes: ["image"],
    allowedAttrs: ["assetId", "alt", "title", "width", "height", "align"],
    allowedMimePrefixes: ["image/"],
    maximumBytes: 5e7,
    maximumDimension: 16384
  }),
  attachment: kt({
    kind: "attachment",
    nodeType: "attachment",
    assetTypes: ["file"],
    allowedAttrs: ["assetId", "display", "title"],
    allowedMimePrefixes: ["application/", "text/"],
    maximumBytes: 25e7,
    maximumDimension: 0
  }),
  video: kt({
    kind: "video",
    nodeType: "video",
    assetTypes: ["video"],
    allowedAttrs: ["assetId", "controls", "title", "width", "height"],
    allowedMimePrefixes: ["video/", "audio/"],
    maximumBytes: 1e9,
    maximumDimension: 16384
  }),
  audio: kt({
    kind: "audio",
    nodeType: "video",
    assetTypes: ["video"],
    allowedAttrs: ["assetId", "controls", "title"],
    allowedMimePrefixes: ["audio/"],
    maximumBytes: 5e8,
    maximumDimension: 0
  }),
  iframe: kt({
    kind: "iframe",
    nodeType: "iframe",
    assetTypes: ["embed"],
    allowedAttrs: ["assetId", "title", "width", "height", "allow"],
    allowedMimePrefixes: ["text/html", "application/x-embed"],
    maximumBytes: 1e7,
    maximumDimension: 16384
  }),
  embed: kt({
    kind: "embed",
    nodeType: "embed",
    assetTypes: ["embed"],
    allowedAttrs: ["assetId", "name", "title", "url"],
    allowedMimePrefixes: ["text/html", "application/x-embed"],
    maximumBytes: 1e7,
    maximumDimension: 0
  })
}), Ap = (e, t) => {
  var a, c, l;
  const n = e.mimeType ?? "", r = Number(((a = e.meta) == null ? void 0 : a.size) ?? 0), i = Number(((c = e.meta) == null ? void 0 : c.width) ?? 0), o = Number(((l = e.meta) == null ? void 0 : l.height) ?? 0);
  let s = "";
  try {
    s = new URL(e.src).protocol;
  } catch {
    return !1;
  }
  return t.assetTypes.includes(e.type) && (n.length === 0 || t.allowedMimePrefixes.some(
    (g) => n.startsWith(g)
  )) && ["https:", "zx-asset:"].includes(s) && Number.isFinite(r) && r >= 0 && r <= t.maximumBytes && Number.isFinite(i) && Number.isFinite(o) && (t.maximumDimension === 0 || i <= t.maximumDimension && o <= t.maximumDimension);
}, Ep = (e, t) => (n) => u({
  kind: "hunks",
  atomicity: "whole-operation",
  hunks: [
    {
      id: O("media-review-hunk", {
        profile: e.fingerprint,
        operation: t,
        source: n.source,
        candidate: n.candidate
      }),
      localId: e.kind,
      kind: "resource",
      summary: `${e.kind}:${t}`,
      beforeFingerprint: O(
        "review-before",
        n.source
      ),
      afterFingerprint: O(
        "review-after",
        n.candidate
      )
    }
  ]
}), wt = (e) => {
  const t = Sp[e.profile], n = (i) => ({
    name: i.name,
    risk: "external-resource",
    stream: "atomic",
    collaboration: "exact-snapshot",
    limits: ce.media,
    compiler: Zn(
      `zx.text-editor.complex-node.media.${e.profile}.${i.name}`
    ),
    decodePayload: i.decodePayload,
    validate: (o) => {
      const s = i.attrs(o.payload);
      if (!Object.keys(s).every(
        (l) => t.allowedAttrs.includes(l)
      ) || !T(s.assetId))
        return Yt("complex-resource-policy-denied");
      const a = o.document.assets.find(
        (l) => l.id === s.assetId
      );
      if (!a || !Ap(a, t))
        return Yt("complex-resource-not-staged");
      const c = {
        ...P(o.target),
        attrs: {
          ...Object.fromEntries(
            Object.entries(o.target.attrs ?? {}).map(([l, g]) => [
              l,
              ["src", "href", "url"].includes(l) ? null : g
            ])
          ),
          ...P(s)
        }
      };
      return Qn(
        Yn({
          family: "media",
          operation: i.name,
          source: o.target,
          candidate: c,
          blockId: o.address.blockId,
          assetsMetaUnchanged: !0
        })
      );
    },
    deriveReview: Ep(t, i.name)
  }), r = {};
  return r["media.presentation.update"] = n({
    name: "media.presentation.update",
    decodePayload: (i) => L({
      input: i,
      required: ["assetId", "attrs"],
      validate: (o) => T(o.assetId) && K(o.attrs) && Object.keys(o.attrs).every(
        (s) => s !== "assetId" && t.allowedAttrs.includes(s)
      )
    }),
    attrs: (i) => ({ assetId: i.assetId, ...i.attrs })
  }), r["media.replace-asset"] = n({
    name: "media.replace-asset",
    decodePayload: (i) => L({
      input: i,
      required: ["assetId"],
      validate: (o) => T(o.assetId)
    }),
    attrs: (i) => ({ assetId: i.assetId })
  }), r["media.caption-or-alt.update"] = n({
    name: "media.caption-or-alt.update",
    decodePayload: (i) => L({
      input: i,
      required: ["assetId", "value"],
      validate: (o) => T(o.assetId) && typeof o.value == "string" && o.value.length <= 4096
    }),
    attrs: (i) => ({
      assetId: i.assetId,
      ...t.kind === "image" ? { alt: i.value } : { title: i.value }
    })
  }), er({
    id: `zx.text-editor.complex-node.media.${e.profile}`,
    descriptor: e.profile === "image" ? "image" : e.profile === "video" || e.profile === "audio" ? "video" : e.profile === "iframe" ? "iframe" : e.profile === "embed" ? "embed" : "attachment",
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: t.nodeType,
    schemaFingerprint: e.schemaFingerprint,
    provenanceFingerprint: e.provenanceFingerprint,
    family: "media",
    address: e.profile === "embed" ? { stableLocalTypes: [], validatedPathFallback: !0 } : { stableLocalTypes: ["media"], validatedPathFallback: !0 },
    operations: r
  });
}, At = (e) => e.type === "tableCell" || e.type === "tableHeader", ia = (e) => e.type === "tableRow", _n = (e, t = ce.table) => {
  const n = (e.content ?? []).filter(ia), r = [];
  let i = 0, o = e.type === "table" && n.length === (e.content ?? []).length;
  n.forEach((a, c) => {
    var g, f, p;
    r[c] ?? (r[c] = []);
    let l = 0;
    for (const d of a.content ?? []) {
      if (!At(d)) {
        o = !1;
        continue;
      }
      for (; r[c][l]; ) l += 1;
      const h = Number(((g = d.attrs) == null ? void 0 : g.colspan) ?? 1), m = Number(((f = d.attrs) == null ? void 0 : f.rowspan) ?? 1), y = (p = d.attrs) == null ? void 0 : p.cellId;
      if (!Number.isSafeInteger(h) || !Number.isSafeInteger(m) || h < 1 || m < 1 || h > t.nodeBudget.maxColSpan || m > t.nodeBudget.maxRowSpan || !T(y)) {
        o = !1;
        continue;
      }
      i += 1;
      for (let b = c; b < c + m; b += 1) {
        if (b >= n.length) {
          o = !1;
          break;
        }
        r[b] ?? (r[b] = []);
        for (let k = l; k < l + h; k += 1)
          r[b][k] && (o = !1), r[b][k] = y;
      }
      l += h;
    }
  });
  const s = Math.max(0, ...r.map((a) => a.length));
  return (n.length === 0 || i === 0 || i > t.nodeBudget.maxCells || r.some(
    (a) => a.length !== s || Array.from({ length: s }, (c, l) => a[l]).some(
      (c) => !c
    )
  )) && (o = !1), u({
    valid: o,
    width: s,
    height: n.length,
    cellCount: i,
    owners: r
  });
}, Op = (e, t, n, r, i) => `${e}_${O("table-identity-repair", {
  tableId: t,
  sourceFingerprint: n,
  coordinate: r,
  occurrence: i
}).slice(7, 31)}`, en = (e, t, n, r, i, o) => {
  const s = Op(
    e,
    t,
    n,
    r,
    i
  );
  let a = s, c = 0;
  for (; o.has(a); )
    c += 1, a = `${s}_${c}`;
  return o.add(a), a;
}, Tp = (e, t, n) => {
  var c;
  const r = String((c = e.attrs) == null ? void 0 : c.blockId), i = O(
    "table-operation-base",
    e
  ), o = new Set(Ze(e, "rowId")), s = new Set(Ze(e, "cellId")), a = en(
    "row",
    r,
    i,
    `insert-after:${t ?? "start"}`,
    0,
    o
  );
  return {
    ...P(n),
    attrs: { ...n.attrs ?? {}, rowId: a },
    content: (n.content ?? []).map((l, g) => ({
      ...P(l),
      attrs: {
        ...l.attrs ?? {},
        cellId: en(
          "cell",
          r,
          i,
          `insert-row:${t ?? "start"}:${g}`,
          0,
          s
        )
      }
    }))
  };
}, co = (e, t, n, r) => {
  var i;
  return {
    ...P(t),
    attrs: {
      ...t.attrs ?? {},
      cellId: en(
        "cell",
        String((i = e.attrs) == null ? void 0 : i.blockId),
        O("table-operation-base", e),
        n,
        0,
        r
      )
    }
  };
}, lo = (e, t) => {
  const n = /* @__PURE__ */ new Map(), r = (i) => {
    var s, a;
    const o = (s = i.attrs) == null ? void 0 : s[t];
    T(o) && n.set(o, (n.get(o) ?? 0) + 1), (a = i.content) == null || a.forEach(r);
  };
  return r(e), n;
}, Rf = (e) => {
  var g;
  if (e.table.type !== "table" || !T((g = e.table.attrs) == null ? void 0 : g.blockId) || !H(e.sourceSnapshotFingerprint) || e.currentSourceSnapshotFingerprint !== e.sourceSnapshotFingerprint || !H(e.descriptorFingerprint) || e.currentDescriptorFingerprint !== e.descriptorFingerprint || e.sourceTableFingerprint !== O("node-content", e.table))
    return u({ status: "failure", table: null });
  const t = e.table.attrs.blockId, n = O("table-repair-base", {
    table: e.table,
    sourceSnapshotFingerprint: e.sourceSnapshotFingerprint,
    descriptorFingerprint: e.descriptorFingerprint
  }), r = lo(e.table, "rowId"), i = lo(e.table, "cellId"), o = new Set(
    [...r].filter(([, f]) => f === 1).map(([f]) => f)
  ), s = new Set(
    [...i].filter(([, f]) => f === 1).map(([f]) => f)
  );
  let a = !1;
  const c = (e.table.content ?? []).map((f, p) => {
    var b;
    if (!ia(f)) return f;
    const d = (b = f.attrs) == null ? void 0 : b.rowId, h = T(d) && r.get(d) === 1 ? d : en(
      "row",
      t,
      n,
      `${p}`,
      0,
      o
    );
    h !== d && (a = !0);
    const m = /* @__PURE__ */ new Map(), y = (f.content ?? []).map((k, w) => {
      var A;
      if (!At(k)) return k;
      const I = (A = k.attrs) == null ? void 0 : A.cellId, x = typeof I == "string" ? m.get(I) ?? 0 : 0;
      typeof I == "string" && m.set(I, x + 1);
      const R = T(I) && i.get(I) === 1 ? I : en(
        "cell",
        t,
        n,
        `${p}:${w}`,
        x,
        s
      );
      return R !== I && (a = !0), {
        ...P(k),
        attrs: { ...k.attrs ?? {}, cellId: R }
      };
    });
    return {
      ...P(f),
      attrs: { ...f.attrs ?? {}, rowId: h },
      content: y
    };
  }), l = { ...P(e.table), content: c };
  return ta(l, ["rowId", "cellId"]) && _n(l).valid ? u({ status: "success", table: l, changed: a }) : u({ status: "failure", table: null });
}, Cp = (e) => (t) => {
  const n = [
    .../* @__PURE__ */ new Set([
      ...Ze(t.source, "rowId"),
      ...Ze(t.source, "cellId")
    ])
  ], r = [
    .../* @__PURE__ */ new Set([
      ...Ze(t.candidate, "rowId"),
      ...Ze(t.candidate, "cellId")
    ])
  ];
  if (n.length + r.length > ce.table.nodeBudget.maxCells * 2)
    return u({
      kind: "unavailable",
      reason: "over-limit",
      summary: {
        nodeFamily: "table",
        operation: e,
        risk: "structural",
        resource: { status: "none" },
        atomicity: "whole-operation",
        actions: ["accept", "reject"]
      }
    });
  const i = [.../* @__PURE__ */ new Set([...n, ...r])].sort();
  return u({
    kind: "hunks",
    atomicity: e === "cell.content.update" ? "declared-parts" : "whole-operation",
    hunks: i.map((o) => {
      const s = Qt(
        t.source,
        o.startsWith("row_") ? "rowId" : "cellId",
        o
      ), a = Qt(
        t.candidate,
        o.startsWith("row_") ? "rowId" : "cellId",
        o
      );
      return {
        id: O("table-review-hunk", {
          operation: e,
          id: o,
          source: s,
          candidate: a
        }),
        localId: o,
        kind: e.includes("attrs") ? "attrs" : e.includes("content") ? "text" : "structure",
        summary: `${e}:${o}`,
        beforeFingerprint: s ? O("review-before", s) : null,
        afterFingerprint: a ? O("review-after", a) : null
      };
    })
  });
}, Ze = (e, t) => {
  const n = [], r = (i) => {
    var s, a;
    const o = (s = i.attrs) == null ? void 0 : s[t];
    typeof o == "string" && n.push(o), (a = i.content) == null || a.forEach(r);
  };
  return r(e), n;
}, qr = (e) => {
  const t = /* @__PURE__ */ new Map(), n = (r) => {
    var i, o;
    At(r) && T((i = r.attrs) == null ? void 0 : i.cellId) && t.set(r.attrs.cellId, r), (o = r.content) == null || o.forEach(n);
  };
  return n(e), t;
}, Pp = (e, t, n) => {
  const r = qr(e), i = qr(t), o = [...r].filter(([a, c]) => {
    const l = i.get(a);
    return l !== void 0 && O("table-preservation-cell", c) !== O("table-preservation-cell", l);
  }), s = n === "cell.content.update" || n === "cell.attrs.update" || n === "cells.merge" || n === "cells.split" ? 1 : 0;
  return o.length <= s;
}, po = (e) => [...qr(e).values()].some(
  (t) => {
    var n, r;
    return Number(((n = t.attrs) == null ? void 0 : n.colspan) ?? 1) !== 1 || Number(((r = t.attrs) == null ? void 0 : r.rowspan) ?? 1) !== 1;
  }
), Pe = (e) => ({
  name: e.name,
  risk: e.risk ?? "structural",
  stream: e.stream ?? "atomic",
  collaboration: e.collaboration ?? "exact-snapshot",
  limits: ce.table,
  compiler: Zn(
    `zx.text-editor.complex-node.table.${e.name}`
  ),
  decodePayload: e.decodePayload,
  validate: (t) => {
    const n = e.apply(t.target, t.payload);
    return !n || !ta(n, ["rowId", "cellId"]) || !_n(n).valid || !Pp(t.target, n, e.name) ? Yt("complex-schema-invalid") : Qn(
      Yn({
        family: "table",
        operation: e.name,
        source: t.target,
        candidate: n,
        blockId: t.address.blockId,
        atomicity: e.name === "cell.content.update" ? "declared-parts" : "whole-operation"
      })
    );
  },
  validatePartial: e.stream === "incremental" ? (t) => t.accumulatedBytes <= ce.table.maxPayloadBytes ? u({
    valid: !0,
    projection: { sequence: t.sequence }
  }) : u({ valid: !1, projection: null, diagnostics: [] }) : void 0,
  deriveReview: Cp(e.name)
}), Dp = (e) => {
  const t = {};
  return t["cell.content.update"] = Pe({
    name: "cell.content.update",
    stream: "incremental",
    collaboration: "stable-rebase",
    risk: "textual",
    decodePayload: (n) => L({
      input: n,
      required: ["cellId", "content"],
      validate: (r) => T(r.cellId) && Array.isArray(r.content) && r.content.every(Fe)
    }),
    apply: (n, r) => {
      const i = _t(
        n,
        "cellId",
        r.cellId,
        (o) => ({
          ...P(o),
          content: [...P(r.content)]
        })
      );
      return i.matched === 1 ? i.root : null;
    }
  }), t["cell.attrs.update"] = Pe({
    name: "cell.attrs.update",
    decodePayload: (n) => L({
      input: n,
      required: ["cellId", "attrs"],
      validate: (r) => T(r.cellId) && K(r.attrs) && Object.keys(r.attrs).every(
        (i) => ["colspan", "rowspan", "colwidth", "align"].includes(i)
      )
    }),
    apply: (n, r) => {
      const i = _t(
        n,
        "cellId",
        r.cellId,
        (o) => ({
          ...P(o),
          attrs: {
            ...o.attrs ?? {},
            ...r.attrs,
            cellId: r.cellId
          }
        })
      );
      return i.matched === 1 ? i.root : null;
    }
  }), t["row.insert"] = Pe({
    name: "row.insert",
    decodePayload: (n) => L({
      input: n,
      required: ["afterRowId", "row"],
      validate: (r) => (r.afterRowId === null || T(r.afterRowId)) && Fe(r.row) && r.row.type === "tableRow"
    }),
    apply: (n, r) => {
      const i = [...n.content ?? []], o = r.afterRowId === null ? -1 : i.findIndex((s) => {
        var a;
        return ((a = s.attrs) == null ? void 0 : a.rowId) === r.afterRowId;
      });
      return r.afterRowId !== null && o < 0 ? null : (i.splice(
        o + 1,
        0,
        Tp(n, r.afterRowId, r.row)
      ), { ...P(n), content: i });
    }
  }), t["row.delete"] = Pe({
    name: "row.delete",
    decodePayload: (n) => L({
      input: n,
      required: ["rowId"],
      validate: (r) => T(r.rowId)
    }),
    apply: (n, r) => {
      var o;
      const i = _t(
        n,
        "rowId",
        r.rowId,
        () => null
      );
      return i.matched === 1 && (((o = i.root.content) == null ? void 0 : o.length) ?? 0) > 0 ? i.root : null;
    }
  }), t["column.insert"] = Pe({
    name: "column.insert",
    decodePayload: (n) => L({
      input: n,
      required: ["index", "cells"],
      validate: (r) => Number.isSafeInteger(r.index) && r.index >= 0 && Array.isArray(r.cells) && r.cells.every((i) => Fe(i) && At(i))
    }),
    apply: (n, r) => {
      const i = n.content ?? [], o = _n(n);
      return !o.valid || po(n) || r.index > o.width || r.cells.length !== i.length ? null : {
        ...P(n),
        content: i.map((s, a) => {
          const c = [...s.content ?? []], l = new Set(Ze(n, "cellId"));
          return c.splice(
            r.index,
            0,
            co(
              n,
              r.cells[a],
              `insert-column:${r.index}:${a}`,
              l
            )
          ), { ...P(s), content: c };
        })
      };
    }
  }), t["column.delete"] = Pe({
    name: "column.delete",
    decodePayload: (n) => L({
      input: n,
      required: ["index"],
      validate: (r) => Number.isSafeInteger(r.index) && r.index >= 0
    }),
    apply: (n, r) => {
      const i = _n(n);
      return !i.valid || po(n) || i.width <= 1 || r.index >= i.width ? null : {
        ...P(n),
        content: (n.content ?? []).map((o) => {
          const s = [...o.content ?? []];
          return s.splice(r.index, 1), { ...P(o), content: s };
        })
      };
    }
  }), t["cells.merge"] = Pe({
    name: "cells.merge",
    decodePayload: (n) => L({
      input: n,
      required: ["cellIds", "survivorCell"],
      validate: (r) => {
        var i;
        return Array.isArray(r.cellIds) && r.cellIds.length >= 2 && r.cellIds.every(T) && new Set(r.cellIds).size === r.cellIds.length && Fe(r.survivorCell) && At(r.survivorCell) && ((i = r.survivorCell.attrs) == null ? void 0 : i.cellId) === r.cellIds[0];
      }
    }),
    apply: (n, r) => {
      let i = P(n), o = 0;
      return r.cellIds.forEach((s, a) => {
        const c = _t(
          i,
          "cellId",
          s,
          () => a === 0 ? P(r.survivorCell) : null
        );
        o += c.matched, i = c.root;
      }), o === r.cellIds.length ? i : null;
    }
  }), t["cells.split"] = Pe({
    name: "cells.split",
    decodePayload: (n) => L({
      input: n,
      required: ["cellId", "cells"],
      validate: (r) => {
        var i, o;
        return T(r.cellId) && Array.isArray(r.cells) && r.cells.length >= 2 && r.cells.every((s) => Fe(s) && At(s)) && ((o = (i = r.cells[0]) == null ? void 0 : i.attrs) == null ? void 0 : o.cellId) === r.cellId;
      }
    }),
    apply: (n, r) => {
      let i = 0;
      const o = new Set(Ze(n, "cellId")), s = (c) => {
        if (!c.content) return P(c);
        const l = [];
        return c.content.forEach((g) => {
          var f;
          ((f = g.attrs) == null ? void 0 : f.cellId) === r.cellId ? (i += 1, l.push(
            ...r.cells.map(
              (p, d) => d === 0 ? {
                ...P(p),
                attrs: { ...p.attrs ?? {}, cellId: r.cellId }
              } : co(
                n,
                p,
                `split:${r.cellId}:${d}`,
                o
              )
            )
          )) : l.push(s(g));
        }), { ...P(c), content: l };
      }, a = s(n);
      return i === 1 ? a : null;
    }
  }), t["table.normalize"] = Pe({
    name: "table.normalize",
    decodePayload: (n) => L({
      input: n,
      required: ["table"],
      validate: (r) => Fe(r.table) && r.table.type === "table"
    }),
    apply: (n, r) => {
      var i, o;
      return ((i = r.table.attrs) == null ? void 0 : i.blockId) === ((o = n.attrs) == null ? void 0 : o.blockId) ? P(r.table) : null;
    }
  }), er({
    id: "zx.text-editor.complex-node.table",
    descriptor: "builtinNodes",
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: "table",
    schemaFingerprint: e.schemaFingerprint,
    provenanceFingerprint: e.provenanceFingerprint,
    family: "table",
    operations: t
  });
}, Sf = (e) => [
  Dp(e),
  ao({ ...e, nodeType: "bulletList" }),
  ao({ ...e, nodeType: "orderedList" }),
  Ip(e),
  wt({ ...e, profile: "image" }),
  wt({ ...e, profile: "attachment" }),
  wt({ ...e, profile: "video" }),
  wt({ ...e, profile: "audio" }),
  wt({ ...e, profile: "iframe" }),
  wt({ ...e, profile: "embed" })
], Bp = (e) => {
  const t = e.flatMap((r) => [
    r.component,
    r.hostAdmission,
    ...Object.values(r.operations).map((i) => i.compiler)
  ]), n = /* @__PURE__ */ new Set();
  return t.filter((r) => {
    const i = `${r.id}:${r.version}:${r.fingerprint}`;
    return n.has(i) ? !1 : (n.add(i), !0);
  });
}, fo = {
  kind: "execution-closure",
  id: "zx.ai.review-historical-reader",
  version: "1.0.0",
  dependencies: []
}, Ln = u(
  {
    ...fo,
    fingerprint: $(
      "zx-ai-review-historical-reader:v1",
      fo
    )
  }
), oa = (e) => nt({
  code: "review-sidecar-invalid",
  stage: "audit",
  path: e
}), wr = (e) => u({
  status: "failure",
  diagnostics: ci([oa(e)])
}), Fr = (e) => u({
  status: "deterministic-mismatch",
  diagnostics: ci([oa(e)])
}), uo = (e) => u({
  status: "review-runtime-unsupported",
  diagnostics: ci([
    nt({
      code: "review-runtime-unsupported",
      stage: "audit",
      path: e
    })
  ])
}), jp = (e, t) => {
  if (!V(t, [
    "proposalId",
    "revision",
    "status",
    "fingerprint"
  ]) || !["active", "committed", "discarded"].includes(String(t.status)))
    return !1;
  const n = t.status, r = t.fingerprint === Dt({
    proposalId: t.proposalId,
    revision: t.revision,
    status: n
  });
  return t.proposalId !== e.proposalBinding.proposalId || !r ? !1 : n === "active" ? t.revision === e.proposalBinding.lifecycleRevision && t.fingerprint === e.proposalBinding.lifecycleFingerprint && ["active", "superseded"].includes(e.status) : t.revision === e.proposalBinding.lifecycleRevision + 1 && (n === "committed" && ["committed", "accepted-no-change", "invalidated"].includes(
    e.status
  ) || n === "discarded" && ["rejected", "invalidated"].includes(e.status));
}, Af = (e) => {
  if (!V(e, ["sidecar", "proposalEnvelope"]) || e.sidecar.status === "active" || e.proposalEnvelope.proposalArtifact.identity.proposalId !== e.sidecar.proposalBinding.proposalId || e.proposalEnvelope.proposalArtifact.identity.variantId !== e.sidecar.proposalBinding.variantId || e.proposalEnvelope.proposalArtifact.sourceProposalFingerprint !== e.sidecar.proposalBinding.proposalFingerprint || e.proposalEnvelope.sourceProposal.fingerprint !== e.sidecar.proposalBinding.proposalFingerprint)
    throw new TypeError("review-historical-envelope-input-invalid");
  const t = nn(e.sidecar);
  if (t.status !== "success" || t.sidecar.status === "active")
    throw new TypeError("review-historical-sidecar-invalid");
  if ($r({
    mode: "historical",
    envelope: e.proposalEnvelope
  }).status !== "audit-success")
    throw new TypeError("review-historical-proposal-invalid");
  const r = {
    kind: "zx-ai-review-historical-artifact-v1",
    version: "1.0.0",
    reviewReaderRef: Ln,
    reviewId: t.sidecar.identity.reviewId,
    terminalSidecarFingerprint: t.sidecar.fingerprint,
    proposalId: t.sidecar.proposalBinding.proposalId,
    proposalVariantId: t.sidecar.proposalBinding.variantId,
    proposalFingerprint: t.sidecar.proposalBinding.proposalFingerprint,
    proposalHistoricalArtifactFingerprint: e.proposalEnvelope.proposalArtifact.fingerprint,
    terminalStatus: t.sidecar.status,
    decisionFingerprints: t.sidecar.decisions.map(
      (s) => s.fingerprint
    ),
    auditFingerprints: t.sidecar.auditEntries.map(
      (s) => s.fingerprint
    )
  }, i = u({
    ...r,
    fingerprint: $(
      "zx-ai-review-historical-artifact:v1",
      r
    )
  }), o = {
    kind: "zx-ai-review-historical-envelope-v1",
    version: "1.0.0",
    reviewReaderRef: Ln,
    reviewArtifact: i,
    terminalSidecar: t.sidecar,
    proposalEnvelope: e.proposalEnvelope
  };
  return u({
    ...o,
    closureFingerprint: $(
      "zx-ai-review-historical-envelope-closure:v1",
      o
    )
  });
}, Np = (e, t) => {
  if (!V(e, [
    "kind",
    "version",
    "reviewReaderRef",
    "reviewId",
    "terminalSidecarFingerprint",
    "proposalId",
    "proposalVariantId",
    "proposalFingerprint",
    "proposalHistoricalArtifactFingerprint",
    "terminalStatus",
    "decisionFingerprints",
    "auditFingerprints",
    "fingerprint"
  ]) || e.kind !== "zx-ai-review-historical-artifact-v1" || e.version !== "1.0.0" || !_e(
    e.reviewReaderRef,
    Ln
  ) || !z(e.reviewId) || !z(e.terminalSidecarFingerprint) || e.proposalId !== t.identity.proposalId || e.proposalVariantId !== t.identity.variantId || e.proposalFingerprint !== t.sourceProposalFingerprint || e.proposalHistoricalArtifactFingerprint !== t.fingerprint || ![
    "committed",
    "accepted-no-change",
    "rejected",
    "superseded",
    "invalidated"
  ].includes(String(e.terminalStatus)) || !Array.isArray(e.decisionFingerprints) || !e.decisionFingerprints.every(z) || !Array.isArray(e.auditFingerprints) || !e.auditFingerprints.every(z) || !z(e.fingerprint))
    return !1;
  const { fingerprint: n, ...r } = e;
  return e.fingerprint === $("zx-ai-review-historical-artifact:v1", r);
}, Mp = (e, t, n) => {
  const r = nn(e);
  if (r.status !== "success" || r.sidecar.status === "active")
    return !1;
  const i = r.sidecar;
  return i.identity.reviewId === t.reviewId && i.fingerprint === t.terminalSidecarFingerprint && i.status === t.terminalStatus && i.proposalBinding.proposalId === t.proposalId && i.proposalBinding.variantId === t.proposalVariantId && i.proposalBinding.proposalFingerprint === t.proposalFingerprint && i.proposalBinding.proposalFingerprint === n.sourceProposal.fingerprint && _e(
    i.decisions.map((o) => o.fingerprint),
    t.decisionFingerprints
  ) && _e(
    i.auditEntries.map((o) => o.fingerprint),
    t.auditFingerprints
  );
}, Ef = (e) => {
  if (!V(
    e,
    ["mode"],
    ["sidecar", "proposal", "lifecycle", "envelope"]
  ) || e.mode !== "exact-current" && e.mode !== "historical")
    return wr("$");
  if (e.mode === "historical") {
    if (!V(e, ["mode", "envelope"])) return wr("$");
    const s = e.envelope;
    if (!V(s, [
      "kind",
      "version",
      "reviewReaderRef",
      "reviewArtifact",
      "terminalSidecar",
      "proposalEnvelope",
      "closureFingerprint"
    ]) || s.kind !== "zx-ai-review-historical-envelope-v1" || s.version !== "1.0.0" || !_e(
      s.reviewReaderRef,
      Ln
    ) || !Np(
      s.reviewArtifact,
      s.proposalEnvelope.proposalArtifact
    ) || !Mp(
      s.terminalSidecar,
      s.reviewArtifact,
      s.proposalEnvelope
    ) || s.closureFingerprint !== $("zx-ai-review-historical-envelope-closure:v1", {
      kind: s.kind,
      version: s.version,
      reviewReaderRef: s.reviewReaderRef,
      reviewArtifact: s.reviewArtifact,
      terminalSidecar: s.terminalSidecar,
      proposalEnvelope: s.proposalEnvelope
    }) || !zn(s))
      return uo("$.envelope");
    const a = $r({
      mode: "historical",
      envelope: s.proposalEnvelope
    });
    return a.status !== "audit-success" ? uo("$.envelope.proposalEnvelope") : u({
      status: "audit-success",
      fingerprint: $("zx-ai-review-historical-audit:v1", {
        reviewArtifactFingerprint: s.reviewArtifact.fingerprint,
        proposalAudit: a
      })
    });
  }
  if (!V(e, ["mode", "sidecar", "proposal", "lifecycle"]))
    return wr("$");
  const t = nn(e.sidecar), n = Le(e.proposal);
  if (t.status !== "success" || n.status !== "success")
    return Fr("$.sidecar");
  const r = t.sidecar, i = n.proposal;
  if (n.cacheStatus !== "exact" || r.proposalBinding.proposalId !== i.identity.proposalId || r.proposalBinding.variantId !== i.identity.variantId || r.proposalBinding.proposalFingerprint !== i.fingerprint || r.proposalBinding.operationCount !== i.operationProjection.length || r.proposalBinding.operationProjectionFingerprint !== $(
    "zx-ai-review-operation-projection:v1",
    i.operationProjection
  ) || r.proposalBinding.baseFingerprint !== i.base.fingerprint || r.proposalBinding.resultFingerprint !== i.runtimeExecution.resultFingerprint || r.proposalBinding.traceFingerprint !== i.runtimeExecution.trace.fingerprint || r.proposalBinding.mappingFingerprint !== i.runtimeExecution.mapping.fingerprint || !jp(r, e.lifecycle) || li(ai(r)) !== r.fingerprint)
    return Fr("$.sidecar.proposalBinding");
  const o = $r({
    mode: "exact-current",
    proposal: i
  });
  return o.status !== "audit-success" ? Fr("$.proposal") : u({
    status: "audit-success",
    fingerprint: $("zx-ai-review-current-audit:v1", {
      sidecarFingerprint: r.fingerprint,
      proposalAudit: o
    })
  });
}, zp = (e, t, n) => e.proposalId === t.identity.proposalId && e.status === "active" && oi(e) && e.revision === n.proposalBinding.lifecycleRevision && e.fingerprint === n.proposalBinding.lifecycleFingerprint && e.fingerprint === Dt({
  proposalId: e.proposalId,
  revision: e.revision,
  status: e.status
}), $p = (e, t) => e.status === "active" && Gn(e) && e.proposalBinding.proposalId === t.identity.proposalId && e.proposalBinding.variantId === t.identity.variantId && e.proposalBinding.proposalFingerprint === t.fingerprint && e.proposalBinding.operationCount === t.operationProjection.length && e.proposalBinding.operationProjectionFingerprint === $(
  "zx-ai-review-operation-projection:v1",
  t.operationProjection
) && e.proposalBinding.baseFingerprint === t.base.fingerprint && e.proposalBinding.documentRevision === t.base.documentRevision && e.proposalBinding.annotationFingerprint === t.base.annotationFingerprint && e.proposalBinding.targetFingerprint === t.base.targetFingerprint && e.proposalBinding.planDigest === t.base.planDigest && e.proposalBinding.resultFingerprint === t.runtimeExecution.resultFingerprint && e.proposalBinding.traceFingerprint === t.runtimeExecution.trace.fingerprint && e.proposalBinding.mappingFingerprint === t.runtimeExecution.mapping.fingerprint && e.proposalBinding.effectFingerprint === t.effectProof.fingerprint, Vp = (e, t) => e.proposalBinding.richDiffStatus === t.richDiff.status && _e(
  e.proposalBinding.richDiffSourceBinding,
  t.richDiff.sourceBinding
) && e.proposalBinding.richDiffUnavailableReason === (t.richDiff.status === "unavailable" ? t.richDiff.reason : null) && e.proposalBinding.richDiffFingerprint === $(
  "zx-ai-review-rich-diff-binding:v1",
  t.richDiff
), me = (e, t, n) => nt({
  code: e,
  stage: "eligibility",
  path: t,
  reviewRef: n.identity.reviewId,
  proposalRef: n.proposalBinding.proposalId
}), sa = (e, t, n, r = !1) => {
  const i = nn(e), o = Le(t);
  if (i.status !== "success" || o.status !== "success")
    return { valid: !1, sidecar: e, reason: "input-invalid" };
  const s = i.sidecar, a = o.proposal;
  return s.status !== "active" || !Gn(s) ? { valid: !1, sidecar: s, reason: "terminal" } : $p(s, a) ? o.cacheStatus !== "exact" || !Vp(s, a) ? { valid: !1, sidecar: s, reason: "view-drift" } : zp(n, a, s) ? {
    valid: !0,
    sidecar: i.sidecar,
    proposal: o.proposal
  } : r ? { valid: !0, sidecar: s, proposal: a } : { valid: !1, sidecar: s, reason: "lifecycle-drift" } : { valid: !1, sidecar: s, reason: "proposal-drift" };
}, _p = (e, t) => {
  const n = Ge(e, {
    status: t,
    auditKind: t === "invalidated" ? "invalidated" : "regeneration-issued",
    operationIndexes: e.decisions.map(
      (r) => r.operationIndex
    )
  });
  return Js(e, n) ? n : e;
}, Lp = (e) => {
  if (!V(e, [
    "sidecar",
    "proposal",
    "lifecycle",
    "currentDocument"
  ]))
    return u({
      status: "failure",
      sidecar: e.sidecar,
      diagnostic: me(
        "review-input-invalid",
        "$",
        e.sidecar
      )
    });
  const t = sa(
    e.sidecar,
    e.proposal,
    e.lifecycle
  );
  if (!t.valid) {
    if (t.reason === "view-drift")
      return u({
        status: "regenerate-view",
        sidecar: t.sidecar,
        diagnostic: me(
          "review-diff-unavailable",
          "$.proposal.richDiff",
          t.sidecar
        )
      });
    if (t.sidecar.status === "active" && (t.reason === "proposal-drift" || t.reason === "lifecycle-drift")) {
      const l = t.reason === "proposal-drift" ? "superseded" : "invalidated", g = _p(t.sidecar, l);
      return u({
        status: l,
        sidecar: g,
        diagnostic: me(
          "review-conflict",
          t.reason === "proposal-drift" ? "$.proposal" : "$.lifecycle",
          g
        )
      });
    }
    return u({
      status: t.sidecar.status === "active" ? "conflict" : "invalidated",
      sidecar: t.sidecar,
      diagnostic: me(
        "review-conflict",
        "$.proposal",
        t.sidecar
      )
    });
  }
  const { sidecar: n, proposal: r } = t, i = n.decisions.filter(
    (l) => l.state === "accepted"
  ), o = n.decisions.filter(
    (l) => l.state === "rejected" || l.state === "regeneration-required"
  ), s = n.decisions.filter(
    (l) => l.state === "undecided"
  );
  if (o.length === n.decisions.length && !s.length && !i.length)
    return u({ status: "reject-intent-ready", sidecar: n });
  if (o.length) {
    if (!i.length)
      return u({
        status: "failure",
        sidecar: n,
        diagnostic: me(
          "review-regeneration-invalid",
          "$.sidecar.decisions",
          n
        )
      });
    const l = $(
      "zx-ai-review-regeneration-decision:v1",
      n.decisions
    );
    return u({
      status: "regeneration-required",
      sidecar: n,
      operationIntentDigests: i.map(
        (g) => g.operationIntentDigest
      ),
      decisionFingerprint: l
    });
  }
  if (s.length)
    return u({ status: "continue-review", sidecar: n });
  if (n.capability !== "fine-review" || i.length !== n.decisions.length || n.items.length !== n.decisions.length)
    return u({
      status: "failure",
      sidecar: n,
      diagnostic: me(
        "review-diff-unavailable",
        "$.sidecar.capability",
        n
      )
    });
  const a = jd({
    proposal: r,
    currentDocument: Me(e.currentDocument),
    currentLifecycle: e.lifecycle
  });
  if (a.status !== "success")
    return u({
      status: a.status,
      sidecar: n,
      ..."diagnostic" in a ? { diagnostic: a.diagnostic } : {}
    });
  const c = a.recipe;
  return c.proposalFingerprint !== n.proposalBinding.proposalFingerprint || c.baseFingerprint !== n.proposalBinding.baseFingerprint || c.planDigest !== n.proposalBinding.planDigest || c.expectedResultFingerprint !== n.proposalBinding.resultFingerprint || c.expectedTraceFingerprint !== n.proposalBinding.traceFingerprint || c.expectedMappingFingerprint !== n.proposalBinding.mappingFingerprint || c.annotationExpectationFingerprint !== r.effectProof.annotationProjectionFingerprint || c.lifecycleRevision !== n.proposalBinding.lifecycleRevision || !_e(
    c.operationIntentDigests,
    r.operationProjection.map((l) => l.intentDigest)
  ) ? u({
    status: "failure",
    sidecar: n,
    diagnostic: me(
      "review-recipe-invalid",
      "$.recipe",
      n
    )
  }) : u({
    status: "whole-accept-ready",
    sidecar: n,
    recipe: c
  });
}, Of = (e) => {
  if (!V(e, [
    "sidecar",
    "proposal",
    "lifecycle",
    "latestBaseDocument",
    "nextIdentity"
  ]))
    return u({
      status: "failure",
      handoff: null,
      sidecar: e.sidecar,
      diagnostic: me(
        "review-input-invalid",
        "$",
        e.sidecar
      )
    });
  const t = sa(
    e.sidecar,
    e.proposal,
    e.lifecycle,
    !0
  );
  if (!t.valid)
    return u({
      status: "conflict",
      handoff: null,
      sidecar: t.sidecar,
      diagnostic: me(
        "review-conflict",
        "$.sidecar",
        t.sidecar
      )
    });
  const n = t.sidecar.decisions.filter(
    (f) => f.state === "accepted"
  ), r = t.sidecar.decisions.filter(
    (f) => f.state !== "accepted"
  );
  if (!n.length || !r.length)
    return u({
      status: "failure",
      handoff: null,
      sidecar: t.sidecar,
      diagnostic: me(
        "review-regeneration-invalid",
        "$.sidecar.decisions",
        t.sidecar
      )
    });
  const i = new Set(n.map((f) => f.operationIndex));
  if (n.some(
    (f) => f.dependencyOperationIndexes.some(
      (p) => !i.has(p)
    )
  ))
    return u({
      status: "failure",
      handoff: null,
      sidecar: t.sidecar,
      diagnostic: me(
        "review-dependency-conflict",
        "$.sidecar.decisions",
        t.sidecar
      )
    });
  const o = n.map(
    (f) => f.operationIntentDigest
  ), s = Md({
    proposal: t.proposal,
    decision: {
      kind: "regenerate-proposal",
      operationIntentDigests: o
    },
    latestBaseDocument: Me(e.latestBaseDocument),
    nextIdentity: Me(e.nextIdentity)
  });
  if (s.status !== "success")
    return u({
      status: "failure",
      handoff: null,
      sidecar: t.sidecar,
      diagnostic: s.diagnostic
    });
  const a = $(
    "zx-ai-review-regeneration-decision:v1",
    t.sidecar.decisions
  ), c = {
    kind: "zx-ai-review-regeneration-handoff-v1",
    version: "1.0.0",
    reviewFingerprint: t.sidecar.fingerprint,
    decisionFingerprint: a,
    supersededProposalFingerprint: t.proposal.fingerprint,
    latestBaseRequirement: {
      required: !0,
      latestBaseFingerprint: v(e.latestBaseDocument)
    },
    operationIntentDigests: o,
    plannerSeedFingerprint: s.plannerSeed.fingerprint
  }, l = u({
    ...c,
    fingerprint: $(
      "zx-ai-review-regeneration-handoff:v1",
      c
    )
  }), g = Ge(t.sidecar, {
    status: "superseded",
    auditKind: "regeneration-issued",
    operationIndexes: n.map((f) => f.operationIndex)
  });
  return Js(t.sidecar, g) ? u({
    status: "regeneration-required",
    handoff: l,
    sidecar: g
  }) : u({
    status: "conflict",
    handoff: null,
    sidecar: t.sidecar,
    diagnostic: me(
      "review-conflict",
      "$.sidecar.revision",
      t.sidecar
    )
  });
}, ve = (e, t, n, r) => nt({
  code: e,
  stage: t,
  path: n,
  reviewRef: r.identity.reviewId,
  proposalRef: r.proposalBinding.proposalId
}), go = (e) => {
  if (!V(e, [
    "sidecar",
    "proposal",
    "lifecycle",
    "currentDocument",
    "targetEditor"
  ]))
    return u({
      status: "failure",
      sidecar: e.sidecar,
      receipt: null,
      diagnostic: ve(
        "review-input-invalid",
        "input",
        "$",
        e.sidecar
      )
    });
  const t = Lp({
    sidecar: e.sidecar,
    proposal: e.proposal,
    lifecycle: e.lifecycle,
    currentDocument: e.currentDocument
  });
  if (t.status !== "whole-accept-ready") {
    const g = t.status === "regenerate-current-runtime" || t.status === "regenerate-view" || t.status === "continue-review" || t.status === "reject-intent-ready" ? "regeneration-required" : t.status === "discarded" || t.status === "invalidated" || t.status === "superseded" ? "conflict" : t.status;
    return u({
      status: g,
      sidecar: t.sidecar,
      receipt: null,
      ..."diagnostic" in t && t.diagnostic ? { diagnostic: t.diagnostic } : {}
    });
  }
  const n = t.sidecar;
  if (!zd(n, "commit"))
    return u({
      status: "conflict",
      sidecar: n,
      receipt: null,
      diagnostic: ve(
        "review-conflict",
        "dispatch",
        "$.sidecar.revision",
        n
      )
    });
  const r = ld({
    lifecycle: e.lifecycle
  });
  if (r.status !== "success")
    return br(n, "commit"), u({
      status: "conflict",
      sidecar: n,
      receipt: null,
      diagnostic: ve(
        "review-conflict",
        "dispatch",
        "$.lifecycle",
        n
      )
    });
  const i = r.intent, o = t.recipe, s = td({
    runtime: o.runtimeExpectation.manifestRef,
    plan: o.plan,
    context: e.proposal.base.runtimeContext,
    targetEditor: e.targetEditor,
    runtimeExpectation: o.runtimeExpectation,
    expectedResultFingerprint: o.expectedResultFingerprint,
    expectedTraceFingerprint: o.expectedTraceFingerprint,
    expectedMappingFingerprint: o.expectedMappingFingerprint,
    expectedResourcesFingerprint: v(
      e.proposal.runtimeExecution.resources
    ),
    expectedPluginStateFingerprint: v(
      e.proposal.runtimeExecution.pluginState
    ),
    expectedRuntimeReceiptFingerprint: v(
      e.proposal.runtimeExecution.runtime
    ),
    expectedReplayEligibility: e.proposal.runtimeExecution.replayEligibility,
    expectedAnnotationFingerprint: o.annotationExpectationFingerprint
  });
  if (s.status !== "committed") {
    if (s.status === "accepted-no-change") {
      if (mr({
        intent: i
      }).status !== "committed")
        return br(n, "commit"), u({
          status: "conflict",
          sidecar: n,
          receipt: null,
          diagnostic: ve(
            "review-conflict",
            "post-dispatch",
            "$.proposalLifecycle",
            n
          )
        });
      const f = Ge(n, {
        status: "accepted-no-change",
        auditKind: "accepted-no-change",
        operationIndexes: n.decisions.map(
          (p) => p.operationIndex
        )
      });
      if (!gn(n, f, "commit")) {
        const p = Ge(n, {
          status: "invalidated",
          auditKind: "invalidated",
          operationIndexes: n.decisions.map(
            (h) => h.operationIndex
          )
        }), d = mn(
          n,
          p
        );
        return u({
          status: "post-dispatch-incident",
          sidecar: d,
          receipt: null,
          diagnostic: ve(
            "review-post-dispatch-incident",
            "post-dispatch",
            "$.reviewAuthority",
            d
          )
        });
      }
      return u({
        status: "accepted-no-change",
        sidecar: f,
        receipt: null
      });
    }
    if (s.status === "post-dispatch-safety-incident") {
      mr({ intent: i });
      const g = Ge(n, {
        status: "invalidated",
        auditKind: "invalidated",
        operationIndexes: n.decisions.map(
          (p) => p.operationIndex
        )
      }), f = gn(
        n,
        g,
        "commit"
      ) ? g : mn(n, g);
      return u({
        status: "post-dispatch-incident",
        sidecar: f,
        receipt: null,
        diagnostic: ve(
          "review-post-dispatch-incident",
          "post-dispatch",
          "$.runtimeTargetCommit",
          f
        )
      });
    }
    return dd({ intent: i }), br(n, "commit"), u({
      status: s.status === "not-admissible" ? "rebase-required" : "pre-dispatch-failure",
      sidecar: n,
      receipt: null,
      diagnostic: ve(
        "review-pre-dispatch-failure",
        s.status === "dispatch-failure" ? "dispatch" : "runtime",
        "$.runtimeTargetCommit",
        n
      )
    });
  }
  const a = mr({
    intent: i
  });
  if (a.status !== "committed") {
    const g = Ge(n, {
      status: "invalidated",
      auditKind: "invalidated",
      operationIndexes: n.decisions.map(
        (p) => p.operationIndex
      )
    }), f = gn(
      n,
      g,
      "commit"
    ) ? g : mn(n, g);
    return u({
      status: "post-dispatch-incident",
      sidecar: f,
      receipt: null,
      diagnostic: ve(
        "review-post-dispatch-incident",
        "post-dispatch",
        "$.proposalLifecycle",
        f
      )
    });
  }
  const c = Ge(n, {
    status: "committed",
    auditKind: "committed",
    operationIndexes: n.decisions.map(
      (g) => g.operationIndex
    )
  });
  if (!gn(n, c, "commit")) {
    const g = Ge(n, {
      status: "invalidated",
      auditKind: "invalidated",
      operationIndexes: n.decisions.map(
        (p) => p.operationIndex
      )
    }), f = mn(
      n,
      g
    );
    return u({
      status: "post-dispatch-incident",
      sidecar: f,
      receipt: null,
      diagnostic: ve(
        "review-post-dispatch-incident",
        "post-dispatch",
        "$.reviewAuthority",
        f
      )
    });
  }
  const l = {
    kind: "zx-ai-review-committed-receipt-v1",
    version: "1.0.0",
    reviewId: c.identity.reviewId,
    reviewRevision: c.revision,
    proposalFingerprint: e.proposal.fingerprint,
    proposalLifecycleRevision: a.lifecycle.revision,
    proposalLifecycleFingerprint: a.lifecycle.fingerprint,
    recipeFingerprint: o.fingerprint,
    beforeFingerprint: s.proof.beforeDocumentFingerprint,
    afterFingerprint: s.proof.afterDocumentFingerprint,
    freshOutcomeFingerprint: s.proof.freshOutcomeFingerprint,
    dispatchAdmissionFingerprint: s.dispatchAdmission.fingerprint,
    rootTransactionFingerprint: s.proof.materializedRootFingerprint,
    liveClosureFingerprint: s.proof.liveAppendedClosureFingerprint,
    historyEventFingerprint: v({
      before: s.proof.historyBeforeFingerprint,
      after: s.proof.historyAfterFingerprint
    }),
    terminalSidecarFingerprint: c.fingerprint
  };
  return u({
    status: "committed",
    sidecar: c,
    receipt: {
      ...l,
      fingerprint: $(
        "zx-ai-review-committed-receipt:v1",
        l
      )
    }
  });
}, Tf = (e) => {
  if (!V(e, [
    "sidecar",
    "proposal",
    "lifecycle",
    "currentDocument",
    "targetEditor"
  ]))
    return go(e);
  const t = Cs(
    e.targetEditor,
    () => go(e)
  );
  return t.status === "success" ? t.value : u({
    status: "pre-dispatch-failure",
    sidecar: e.sidecar,
    receipt: null,
    diagnostic: ve(
      "review-pre-dispatch-failure",
      "dispatch",
      t.diagnostic.path,
      e.sidecar
    )
  });
}, Cf = "1.0.0", qp = "zx-ai-review-v1", Ae = u({
  maxCanonicalBytes: 4e6,
  maxDepth: 96,
  maxArrayEntries: 3e4,
  maxObjectKeys: 96,
  maxTotalObjectKeys: 18e4,
  maxStateVectorBytes: 64 * 1024,
  maxRelativeAnchorBytes: 8 * 1024,
  maxAnchors: 64,
  maxRecordBytes: 256 * 1024,
  maxRecordsPerReview: 1024,
  maxSuccessorsPerPredecessor: 32,
  maxPrincipalRefs: 128,
  maxDiagnostics: 64,
  maxBranchRefs: 64,
  maxCheckpointPrefixRefs: 1024,
  maxPendingCommands: 128,
  maxSafeIdLength: 160,
  maxFingerprintLength: 96
}), mo = u({
  maxBytes: Ae.maxCanonicalBytes,
  maxDepth: Ae.maxDepth,
  maxArrayEntries: Ae.maxArrayEntries,
  maxObjectKeys: Ae.maxObjectKeys,
  maxTotalObjectKeys: Ae.maxTotalObjectKeys
}), Lt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", Jp = (e) => !!(e && typeof e == "object" && !Array.isArray(e) && Object.getPrototypeOf(e) === Object.prototype), Kp = (e, t, n = []) => Jp(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), Pf = (e) => typeof e == "string" && e.length > 0 && e.length <= Ae.maxSafeIdLength && /^[A-Za-z0-9][A-Za-z0-9._:/-]*$/.test(e), Up = (e) => typeof e == "string" && e.length <= Ae.maxFingerprintLength && /^sha256:[a-f0-9]{64}$/.test(e), Hp = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, ho = (e) => {
  tn(
    e,
    mo
  );
  const { canonical: t } = Oe(
    e,
    mo
  );
  return u(JSON.parse(t));
}, yo = (e, t) => {
  try {
    return F(e) === F(t);
  } catch {
    return !1;
  }
}, Df = (e) => new TextEncoder().encode(F(e)).byteLength, Jr = (e, t, n = []) => v({
  domain: `zx-ai-collaboration/v1/${e}`,
  version: "1.0.0",
  parents: [...n],
  value: t
}), aa = (e) => {
  let t = "";
  for (let n = 0; n < e.length; n += 3) {
    const r = e[n], i = e[n + 1], o = e[n + 2], s = r << 16 | (i ?? 0) << 8 | (o ?? 0);
    t += Lt[s >>> 18 & 63], t += Lt[s >>> 12 & 63], i !== void 0 && (t += Lt[s >>> 6 & 63]), o !== void 0 && (t += Lt[s & 63]);
  }
  return t;
}, Wp = (e) => {
  if (!/^[A-Za-z0-9_-]*$/.test(e) || e.length % 4 === 1) return null;
  const t = [];
  for (let r = 0; r < e.length; r += 4) {
    const i = e.slice(r, r + 4), o = [...i].map(
      (a) => Lt.indexOf(a)
    );
    if (o.some((a) => a < 0)) return null;
    const s = (o[0] ?? 0) << 18 | (o[1] ?? 0) << 12 | (o[2] ?? 0) << 6 | (o[3] ?? 0);
    i.length >= 2 && t.push(s >>> 16 & 255), i.length >= 3 && t.push(s >>> 8 & 255), i.length >= 4 && t.push(s & 255);
  }
  const n = new Uint8Array(t);
  return aa(n) === e ? n : null;
}, Xp = (e, t) => {
  if (!(e instanceof Uint8Array)) throw new TypeError("bytes-required");
  const n = t === "state-vector" ? Ae.maxStateVectorBytes : t === "relative-position" ? Ae.maxRelativeAnchorBytes : Ae.maxRecordBytes;
  if (e.byteLength > n) throw new RangeError("bytes-limit-exceeded");
  const i = {
    encoding: "base64url",
    value: aa(e),
    byteLength: e.byteLength
  };
  return u({
    ...i,
    fingerprint: Jr(`bytes/${t}`, i)
  });
}, Bf = (e, t) => {
  if (!Kp(e, [
    "encoding",
    "value",
    "byteLength",
    "fingerprint"
  ]) || e.encoding !== "base64url" || typeof e.value != "string" || !Hp(e.byteLength) || !Up(e.fingerprint))
    return u({ status: "failure" });
  const n = Wp(e.value);
  if (!n || n.byteLength !== e.byteLength)
    return u({ status: "failure" });
  try {
    return Xp(n, t).fingerprint === e.fingerprint ? Object.freeze({ status: "success", bytes: n.slice() }) : u({ status: "failure" });
  } catch {
    return u({ status: "failure" });
  }
}, jf = (e) => u([...new Set(e)].sort()), Nf = (e) => {
  const { fingerprint: t, ...n } = e;
  return n;
}, Mf = (e) => {
  const t = e.extension;
  if (t.name !== "collaboration" || !t.options || t.options.document !== e.doc || t.options.field !== e.rootSharedType || t.options.fragment != null)
    throw new TypeError("collaboration-host-extension-invalid");
  ja(e.extension);
}, Rr = (e, t) => e.byteLength === t.byteLength && e.every((n, r) => n === t[r]), zf = (e) => {
  const t = e.namespace ?? qp, n = e.doc.getMap(t), r = e.contentType === "text" ? e.doc.getText(e.rootSharedType) : e.doc.getXmlFragment(e.rootSharedType), i = Object.freeze({ kind: "zx-ai-content-origin" }), o = Object.freeze({ kind: "zx-ai-log-origin" }), s = new U.UndoManager(r, {
    captureTimeout: 0,
    trackedOrigins: /* @__PURE__ */ new Set([i])
  }), a = e.doc, c = s;
  let l = "disconnected", g = !1;
  const f = /* @__PURE__ */ new Set(), p = () => {
    if (g) throw new TypeError("collaboration-adapter-destroyed");
  }, d = (m) => e.proseMirrorMapping && r instanceof U.XmlFragment ? U.encodeRelativePosition(
    Ba(
      m.absolutePosition,
      r,
      e.proseMirrorMapping
    )
  ) : U.encodeRelativePosition(
    U.createRelativePositionFromTypeIndex(
      r,
      m.absolutePosition,
      m.affinity === "left" ? -1 : 0
    )
  ), h = (m) => {
    var w;
    let y;
    try {
      y = U.decodeRelativePosition(m);
    } catch {
      return null;
    }
    let b;
    if (e.proseMirrorMapping && r instanceof U.XmlFragment) {
      const I = Da(
        e.doc,
        r,
        y,
        e.proseMirrorMapping
      );
      if (I === null) return null;
      b = I;
    } else {
      const I = U.createAbsolutePositionFromRelativePosition(
        y,
        e.doc
      );
      if (!I || I.type !== r) return null;
      b = I.index;
    }
    const k = ((w = e.resolveSemanticPosition) == null ? void 0 : w.call(e, b)) ?? {
      blockId: e.rootSharedType,
      semanticOffset: b,
      absolutePosition: b
    };
    return k ? {
      rootSharedType: e.rootSharedType,
      ...k,
      absolutePosition: b
    } : null;
  };
  return {
    documentId: e.documentId,
    rootSharedType: e.rootSharedType,
    captureStateVector() {
      return p(), U.encodeStateVector(e.doc);
    },
    captureRelativePosition(m) {
      return p(), d(m);
    },
    resolveRelativePosition(m) {
      return p(), h(m);
    },
    async enumerateRecords(m) {
      if (p(), m.documentId !== e.documentId)
        throw new TypeError("collaboration-document-mismatch");
      const y = "record/v1/", b = [...n.entries()].filter(
        ([I]) => I.startsWith(y) && I.includes(`/${m.reviewId}/`)
      ).map(([I, x]) => ({
        storageKey: I,
        value: ho(x)
      })).sort((I, x) => I.storageKey.localeCompare(x.storageKey)), k = U.encodeStateVector(e.doc);
      return {
        records: b,
        stateVector: k,
        candidateSetDigest: Jr(
          "record-set",
          b.map((I) => ({
            storageKey: I.storageKey,
            valueFingerprint: Jr(
              "stored-record-value",
              I.value
            )
          }))
        )
      };
    },
    async appendRecord(m) {
      p();
      const y = ho(m.value), b = n.get(m.storageKey);
      if (b !== void 0)
        return {
          status: yo(b, y) ? "idempotent" : "conflict",
          storageKey: m.storageKey
        };
      e.doc.transact(
        () => n.set(m.storageKey, y),
        o
      );
      const k = n.get(m.storageKey);
      return {
        status: yo(k, y) ? "appended" : "failure",
        storageKey: m.storageKey
      };
    },
    runContentCommit(m) {
      p();
      const y = U.encodeStateVector(e.doc);
      if (!Rr(y, m.expectedStateVector))
        return Object.freeze({
          status: "failure",
          dispatchStatus: "not-started",
          effectStatus: "none",
          value: null,
          proof: null
        });
      const b = s.undoStack.length, k = s.redoStack.length;
      let w = !1;
      const I = (ee) => {
        ee.origin === i && (w = !0);
      };
      a.on("afterTransaction", I);
      let x, R = !1;
      try {
        e.doc.transact(() => {
          R = !0, x = m.run();
        }, i);
      } catch {
        a.off("afterTransaction", I);
        const ee = U.encodeStateVector(e.doc);
        return Object.freeze({
          status: "failure",
          dispatchStatus: R ? "started" : "not-started",
          effectStatus: R ? Rr(y, ee) ? "unknown" : "observed" : "none",
          value: null,
          proof: null
        });
      }
      a.off("afterTransaction", I), s.stopCapturing();
      const A = U.encodeStateVector(e.doc), X = U.encodeStateAsUpdate(
        e.doc,
        y
      ), _ = s.undoStack.length, le = s.redoStack.length;
      return Object.freeze({
        status: w ? "success" : "unsupported-host",
        dispatchStatus: "started",
        effectStatus: Rr(y, A) ? "unknown" : "observed",
        value: x,
        proof: Object.freeze({
          beforeStateVector: y,
          afterStateVector: A,
          contentUpdate: X,
          observedOriginExact: w,
          historyBefore: b,
          historyAfter: _,
          redoBefore: k,
          redoAfter: le,
          remoteHistoryDelta: 0
        })
      });
    },
    observeStatus(m) {
      return p(), f.add(m), () => f.delete(m);
    },
    setStatus(m) {
      p(), l = m, f.forEach((y) => y(l));
    },
    getUndoDepth: () => s.undoStack.length,
    getRedoDepth: () => s.redoStack.length,
    undoAI() {
      return p(), s.undoStack.length === 0 ? !1 : (s.undo(), !0);
    },
    redoAI() {
      return p(), s.redoStack.length === 0 ? !1 : (s.redo(), !0);
    },
    runAIUndo(m) {
      if (p(), s.undoStack.length === 0)
        return Object.freeze({ status: "empty", proof: null });
      let y;
      try {
        y = m.readDocumentFingerprint();
      } catch {
        return Object.freeze({ status: "failure", proof: null });
      }
      const b = U.encodeStateVector(e.doc), k = s.undoStack.length, w = s.redoStack.length;
      s.stopCapturing(), s.undo();
      let I;
      try {
        I = m.readDocumentFingerprint();
      } catch {
        return Object.freeze({ status: "failure", proof: null });
      }
      const x = U.encodeStateVector(e.doc), R = U.encodeStateAsUpdate(e.doc, b);
      return Object.freeze({
        status: "success",
        proof: Object.freeze({
          beforeDocumentFingerprint: y,
          afterDocumentFingerprint: I,
          beforeStateVector: b,
          afterStateVector: x,
          undoUpdate: R,
          historyBefore: k,
          historyAfter: s.undoStack.length,
          redoBefore: w,
          redoAfter: s.redoStack.length
        })
      });
    },
    destroy() {
      g || (g = !0, f.clear(), c.destroy());
    }
  };
}, $f = (e) => {
  const t = new U.Doc({ guid: e.guid, gc: e.gc });
  try {
    return e.initialUpdate && U.applyUpdate(
      t,
      e.initialUpdate,
      Object.freeze({ kind: "recovery" })
    ), t;
  } catch (n) {
    throw t.destroy(), n;
  }
}, Vf = (e, t) => U.applyUpdate(e, t, Object.freeze({ kind: "remote" }));
export {
  fp as $,
  mf as A,
  Le as B,
  ff as C,
  dd as D,
  hf as E,
  Md as F,
  N as G,
  Ln as H,
  Ks as I,
  xr as J,
  Ef as K,
  Tf as L,
  Of as M,
  Af as N,
  tp as O,
  Rt as P,
  nn as Q,
  xf as R,
  Lp as S,
  If as T,
  kf as U,
  Zs as V,
  ea as W,
  wf as X,
  Qs as Y,
  cf as Z,
  up as _,
  Oo as a,
  Vf as a$,
  $a as a0,
  Hr as a1,
  Va as a2,
  Wr as a3,
  _a as a4,
  Sf as a5,
  Bp as a6,
  _n as a7,
  Dp as a8,
  Rf as a9,
  jo as aA,
  Za as aB,
  ip as aC,
  op as aD,
  vf as aE,
  rp as aF,
  B as aG,
  Be as aH,
  Xr as aI,
  Ve as aJ,
  wn as aK,
  Kn as aL,
  Ga as aM,
  Df as aN,
  ho as aO,
  yo as aP,
  Xp as aQ,
  Wp as aR,
  Jr as aS,
  Kp as aT,
  Up as aU,
  Pf as aV,
  Bf as aW,
  mo as aX,
  Ae as aY,
  Cf as aZ,
  qp as a_,
  ao as aa,
  Ip as ab,
  hp as ac,
  Sp as ad,
  wt as ae,
  Ap as af,
  ce as ag,
  er as ah,
  Zn as ai,
  di as aj,
  gp as ak,
  Yn as al,
  Ff as am,
  L as an,
  Yt as ao,
  Qn as ap,
  K as aq,
  oe as ar,
  T as as,
  H as at,
  O as au,
  To as av,
  Z as aw,
  kn as ax,
  P as ay,
  Bo as az,
  af as b,
  Mf as b0,
  zf as b1,
  ur as b2,
  Ts as b3,
  df as b4,
  Js as b5,
  bf as b6,
  V as b7,
  nt as b8,
  _e as b9,
  Gn as ba,
  Ge as bb,
  z as bc,
  Ie as bd,
  $ as be,
  Ld as bf,
  zd as bg,
  br as bh,
  oi as bi,
  gn as bj,
  qd as bk,
  Me as bl,
  Zt as bm,
  Jp as bn,
  Hp as bo,
  Nf as bp,
  jf as bq,
  $f as br,
  Bc as bs,
  Ho as bt,
  Wo as bu,
  Ut as bv,
  Pc as c,
  lf as d,
  np as e,
  ml as f,
  Kl as g,
  pf as h,
  td as i,
  ii as j,
  Mn as k,
  Hn as l,
  St as m,
  $r as n,
  Dt as o,
  cd as p,
  ld as q,
  hl as r,
  uf as s,
  mr as t,
  gf as u,
  ac as v,
  yf as w,
  yd as x,
  Od as y,
  jd as z
};
//# sourceMappingURL=yjs-adapter-CNLpxPX5.mjs.map
