import { certifyRuntimeHostCollaborationTransportExtensionV2 as e, readTextEditorRuntimeHostCompositionForTargetV2 as r, readTextEditorRuntimeHostCompositionV2 as i } from "#runtime-host-core-authority";
import { c as n } from "./runtime-host-editor-factory-CuJeZzsy.mjs";
export {
  e as certifyRuntimeHostCollaborationTransportExtensionV2,
  n as createPackageTextEditorRuntimeHostEditorV2,
  r as readTextEditorRuntimeHostCompositionForTargetV2,
  i as readTextEditorRuntimeHostCompositionV2
};
//# sourceMappingURL=runtime-host-authority.mjs.map
