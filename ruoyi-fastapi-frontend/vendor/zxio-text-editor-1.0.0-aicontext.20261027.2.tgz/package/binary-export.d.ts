import { ZxPollBinaryExportJobOptions, ZxSubmitBinaryExportJobOptions } from './src/export-formats/orchestrator';
import { ZxDocumentExportBundleResult } from './src/export';
import { ZxBinaryExportRequest } from './src/export-formats/contract';
import { ZxBinaryExportJobSnapshot } from './core';
export * from './src/export-formats/adapters';
export interface ZxExportBundleToBinaryOptions extends Omit<ZxSubmitBinaryExportJobOptions, 'request'> {
    request?: Omit<ZxBinaryExportRequest, 'format'>;
    waitForCompletion?: boolean;
    poll?: Omit<ZxPollBinaryExportJobOptions, 'jobStore'>;
}
export declare const exportBundleToPdf: (bundle: ZxDocumentExportBundleResult, options?: ZxExportBundleToBinaryOptions) => Promise< ZxBinaryExportJobSnapshot | null>;
export declare const exportBundleToDocx: (bundle: ZxDocumentExportBundleResult, options?: ZxExportBundleToBinaryOptions) => Promise< ZxBinaryExportJobSnapshot | null>;
//# sourceMappingURL=binary-export.d.ts.map