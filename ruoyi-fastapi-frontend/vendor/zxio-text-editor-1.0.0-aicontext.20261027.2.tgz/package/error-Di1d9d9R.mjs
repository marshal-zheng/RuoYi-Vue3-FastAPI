const o = () => /* @__PURE__ */ new Map(), i = (r, s, e) => {
  let t = r.get(s);
  return t === void 0 && r.set(s, t = e()), t;
}, d = (r, s) => {
  const e = [];
  for (const [t, n] of r)
    e.push(s(n, t));
  return e;
}, c = () => /* @__PURE__ */ new Set(), f = Array.from, h = (r, s) => {
  for (let e = 0; e < r.length; e++)
    if (!s(r[e], e, r))
      return !1;
  return !0;
}, u = (r, s) => {
  for (let e = 0; e < r.length; e++)
    if (s(r[e], e, r))
      return !0;
  return !1;
}, l = (r, s) => {
  const e = new Array(r);
  for (let t = 0; t < r; t++)
    e[t] = s(t, e);
  return e;
}, v = Array.isArray;
class b {
  constructor() {
    this._observers = o();
  }
  /**
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name
   * @param {EVENTS[NAME]} f
   */
  on(s, e) {
    return i(
      this._observers,
      /** @type {string} */
      s,
      c
    ).add(e), e;
  }
  /**
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name
   * @param {EVENTS[NAME]} f
   */
  once(s, e) {
    const t = (...n) => {
      this.off(
        s,
        /** @type {any} */
        t
      ), e(...n);
    };
    this.on(
      s,
      /** @type {any} */
      t
    );
  }
  /**
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name
   * @param {EVENTS[NAME]} f
   */
  off(s, e) {
    const t = this._observers.get(s);
    t !== void 0 && (t.delete(e), t.size === 0 && this._observers.delete(s));
  }
  /**
   * Emit a named event. All registered event listeners that listen to the
   * specified name will receive the event.
   *
   * @todo This should catch exceptions
   *
   * @template {keyof EVENTS & string} NAME
   * @param {NAME} name The event name.
   * @param {Parameters<EVENTS[NAME]>} args The arguments that are applied to the event listener.
   */
  emit(s, e) {
    return f((this._observers.get(s) || o()).values()).forEach((t) => t(...e));
  }
  destroy() {
    this._observers = o();
  }
}
class _ {
  constructor() {
    this._observers = o();
  }
  /**
   * @param {N} name
   * @param {function} f
   */
  on(s, e) {
    i(this._observers, s, c).add(e);
  }
  /**
   * @param {N} name
   * @param {function} f
   */
  once(s, e) {
    const t = (...n) => {
      this.off(s, t), e(...n);
    };
    this.on(s, t);
  }
  /**
   * @param {N} name
   * @param {function} f
   */
  off(s, e) {
    const t = this._observers.get(s);
    t !== void 0 && (t.delete(e), t.size === 0 && this._observers.delete(s));
  }
  /**
   * Emit a named event. All registered event listeners that listen to the
   * specified name will receive the event.
   *
   * @todo This should catch exceptions
   *
   * @param {N} name The event name.
   * @param {Array<any>} args The arguments that are applied to the event listener.
   */
  emit(s, e) {
    return f((this._observers.get(s) || o()).values()).forEach((t) => t(...e));
  }
  destroy() {
    this._observers = o();
  }
}
const a = (r) => new Error(r), y = () => {
  throw a("Method unimplemented");
}, g = () => {
  throw a("Unexpected case");
};
export {
  _ as O,
  b as a,
  o as b,
  a as c,
  c as d,
  h as e,
  u as f,
  g,
  d as h,
  v as i,
  y as m,
  i as s,
  l as u
};
//# sourceMappingURL=error-Di1d9d9R.mjs.map
