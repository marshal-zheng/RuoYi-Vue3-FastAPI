import { e as A, A as q, F as S, G as M } from "./actions-Sd62WBGv.mjs";
import { stringifyShortcut as G } from "@zxio/keybindings/core";
import { a as U } from "./projection-r_4Na96h.mjs";
const k = A({
  maxBytes: 1048576,
  maxDepth: 64,
  maxKeys: 16384,
  maxArrayEntries: 32768,
  maxStringBytes: 524288,
  maxNodes: 65536
});
class l extends TypeError {
  constructor(t) {
    super(`Production input rejected: ${t}`), this.name = "ProductionInputPreflightError", this.reason = t;
  }
}
const $ = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]), B = (e) => new TextEncoder().encode(e).length, R = A({
  "operation-protocol-v2": {
    maxBytes: 12e5,
    maxDepth: 64,
    maxKeys: 16e3,
    maxArrayEntries: 8192,
    maxStringBytes: 5e5,
    maxNodes: 24193,
    maxObjectKeys: 16e3
  }
}), H = [
  [12e6, 160, 12e4, 96, 5e5],
  [4e6, 96, 3e4, 64, 16e4],
  [2e6, 64, 8e3, 48, 8e4],
  [4e6, 96, 3e4, 96, 18e4],
  [512 * 1024, 40, 8192, 256, 32768],
  [2e6, 128, 3e5, 3e5, 3e5],
  [12e5, 64, 8192, 16e3, 16e3],
  [512e3, 48, 4096, 12e3, 12e3],
  [1e6, 48, 4096, 12e3, 12e3],
  [256e3, 32, 4096, 8e3, 8e3],
  [512e3, 32, 4096, 8e3, 8e3],
  [1e6, 12, 128, 128, 128],
  [12e5, 12, 128, 128, 128],
  [64e3, 16, 64, 256, 256],
  [128e3, 16, 64, 256, 256],
  [256e3, 32, 2048, 8e3, 8e3],
  [512e3, 32, 2048, 8e3, 8e3]
], Z = (e) => [
  e.maxBytes,
  e.maxDepth,
  e.maxArrayEntries,
  e.maxObjectKeys,
  e.maxTotalObjectKeys
].join(":"), W = new Set(
  H.map((e) => e.join(":"))
), v = (e, t, n) => {
  if (e > t) throw new l(n);
}, Y = (e) => {
  if (e === null || typeof e != "object" || Array.isArray(e) || Object.keys(e).some(
    (t) => !Object.hasOwn(k, t)
  ))
    throw new l("limit-profile-expanded");
  for (const t of Object.keys(e))
    if (!Number.isSafeInteger(e[t]) || e[t] < 0 || e[t] > k[t])
      throw new l("limit-profile-expanded");
  return { ...k, ...e };
}, Oe = (e, t = k) => {
  const n = Y(t);
  return _(e, {
    ...n,
    maxObjectKeys: n.maxKeys
  });
}, _ = (e, t) => {
  const n = [{ value: e, depth: 0, ancestors: /* @__PURE__ */ new Set() }];
  let r = 0, a = 0, i = 0, o = 0, d = 0, p = 0;
  for (; n.length > 0; ) {
    const u = n.pop();
    p += 1, a = Math.max(a, u.depth), v(p, t.maxNodes, "limit-nodes"), v(a, t.maxDepth, "limit-depth");
    const c = u.value;
    if (c === null)
      r += 4;
    else if (typeof c == "string") {
      const f = B(c);
      d += f, r += f + 2;
    } else if (typeof c == "number") {
      if (!Number.isFinite(c) || Object.is(c, -0))
        throw new l("invalid-number");
      r += String(c).length;
    } else if (typeof c == "boolean")
      r += c ? 4 : 5;
    else {
      if (typeof c != "object")
        throw new l("unsupported-value");
      {
        if (u.ancestors.has(c))
          throw new l("cycle-or-alias");
        const f = new Set(u.ancestors);
        f.add(c);
        const I = Array.isArray(c), g = Object.getPrototypeOf(c);
        if (I && g !== Array.prototype || !I && g !== Object.prototype && g !== null)
          throw new l("unknown-object");
        const w = Reflect.ownKeys(c);
        if (w.some((b) => typeof b == "symbol"))
          throw new l("symbol-key");
        const m = w;
        if (I) {
          const b = c;
          if (m.length !== b.length + 1 || !m.includes("length"))
            throw new l("array-shape");
          o += b.length, r += 2 + Math.max(0, b.length - 1);
          for (let h = b.length - 1; h >= 0; h -= 1) {
            const y = Object.getOwnPropertyDescriptor(
              b,
              String(h)
            );
            if (!y || !y.enumerable || !("value" in y))
              throw new l("accessor-property");
            n.push({
              value: y.value,
              depth: u.depth + 1,
              ancestors: f
            });
          }
        } else {
          v(m.length, t.maxObjectKeys, "limit-keys"), i += m.length, r += 2 + Math.max(0, m.length - 1);
          for (let b = m.length - 1; b >= 0; b -= 1) {
            const h = m[b];
            if ($.has(h))
              throw new l("forbidden-key");
            const y = Object.getOwnPropertyDescriptor(c, h);
            if (!y || !("value" in y))
              throw new l("accessor-property");
            if (!y.enumerable)
              throw new l("non-enumerable-property");
            const O = B(h);
            d += O, r += O + 3, n.push({
              value: y.value,
              depth: u.depth + 1,
              ancestors: f
            });
          }
        }
      }
    }
    v(r, t.maxBytes, "limit-bytes"), v(i, t.maxKeys, "limit-keys"), v(o, t.maxArrayEntries, "limit-array-entries"), v(d, t.maxStringBytes, "limit-string-bytes");
  }
  return A({
    kind: "zx.ai.production.input-preflight.v1",
    accepted: !0,
    bytes: r,
    depth: a,
    keys: i,
    arrayEntries: o,
    stringBytes: d,
    nodes: p
  });
}, ke = (e, t) => {
  if (!Object.hasOwn(R, t))
    throw new l("limit-profile-expanded");
  return _(
    e,
    R[t]
  );
}, X = (e, t) => {
  if (t === null || typeof t != "object" || Array.isArray(t) || JSON.stringify(Object.keys(t).sort()) !== JSON.stringify(
    [
      "maxArrayEntries",
      "maxBytes",
      "maxDepth",
      "maxObjectKeys",
      "maxTotalObjectKeys"
    ].sort()
  ) || !W.has(
    Z(t)
  ))
    throw new l("limit-profile-expanded");
  return _(e, {
    maxBytes: t.maxBytes,
    maxDepth: t.maxDepth,
    maxKeys: t.maxTotalObjectKeys,
    maxArrayEntries: t.maxArrayEntries,
    maxStringBytes: t.maxBytes,
    maxNodes: t.maxTotalObjectKeys + t.maxArrayEntries + 1,
    maxObjectKeys: t.maxObjectKeys
  });
}, P = A({
  maxBytes: 512 * 1024,
  maxDepth: 40,
  maxArrayEntries: 8192,
  maxObjectKeys: 256,
  maxTotalObjectKeys: 32768
}), J = /^[A-Za-z0-9_.:-]{1,160}$/, Q = /^[A-Za-z][A-Za-z0-9_.:-]{0,159}$/, ee = /* @__PURE__ */ new Set([
  "editor",
  "view",
  "state",
  "transaction",
  "step",
  "dispatch",
  "callback",
  "fetch",
  "eventsource",
  "websocket",
  "storage",
  "client",
  "sdk",
  "apikey",
  "api_key",
  "secret",
  "password",
  "authorization",
  "cookie",
  "token"
]), te = /(?:sk-[A-Za-z0-9_-]{12,}|bearer\s+[A-Za-z0-9._~+/-]{12,}|-----BEGIN [A-Z ]+PRIVATE KEY-----)/i, ne = (e) => {
  for (const t of e) {
    const n = t.codePointAt(0) ?? 0;
    if (n <= 8 || n === 11 || n === 12 || n >= 14 && n <= 31 || n === 127 || n >= 8234 && n <= 8238 || n >= 8294 && n <= 8297)
      return !0;
  }
  return !1;
}, C = (e) => !!(e && typeof e == "object" && !Array.isArray(e) && Object.getPrototypeOf(e) === Object.prototype), xe = (e, t, n = []) => C(e) && t.every((r) => Object.hasOwn(e, r)) && Object.keys(e).every(
  (r) => t.includes(r) || n.includes(r)
), je = (e) => typeof e == "string" && J.test(e), re = (e) => typeof e == "string" && Q.test(e), Se = (e) => typeof e == "string" && /^sha256:[a-f0-9]{64}$/i.test(e), D = (e, t = 4096) => typeof e == "string" && e.length <= t && !ne(e) && !te.test(e), E = (e, t = "$", n = /* @__PURE__ */ new Set()) => {
  if (e === null || typeof e == "boolean" || typeof e == "number" && Number.isFinite(e) && !Object.is(e, -0))
    return null;
  if (typeof e == "string")
    return D(e, 262144) ? null : t;
  if (typeof e > "u" || typeof e == "function" || typeof e == "symbol" || typeof e == "bigint" || !e || typeof e != "object" || n.has(e) || ArrayBuffer.isView(e) || e instanceof ArrayBuffer || typeof Node < "u" && e instanceof Node || typeof AbortSignal < "u" && e instanceof AbortSignal)
    return t;
  if (n.add(e), Array.isArray(e)) {
    if (Object.getPrototypeOf(e) !== Array.prototype) return t;
    for (const [r, a] of e.entries()) {
      const i = E(
        a,
        `${t}[${r}]`,
        n
      );
      if (i) return i;
    }
    return n.delete(e), null;
  }
  if (Object.getPrototypeOf(e) !== Object.prototype) return t;
  for (const [r, a] of Object.entries(e)) {
    if (ee.has(r.toLowerCase())) return `${t}.${r}`;
    const i = E(a, `${t}.${r}`, n);
    if (i) return i;
  }
  return n.delete(e), null;
}, Ee = (e) => {
  X(e, P);
  const t = E(e);
  if (t) throw new TypeError(`ai-authoring-value-invalid:${t}`);
  const { canonical: n } = M(
    e,
    P
  );
  return A(JSON.parse(n));
}, _e = (e, t) => q({ domain: e, value: t }), Be = (e, t) => {
  try {
    return S(e) === S(t);
  } catch {
    return !1;
  }
}, Re = (e) => new TextEncoder().encode(S(e)).byteLength, Pe = (e) => {
  const { fingerprint: t, ...n } = e;
  return n;
}, Ne = (e) => {
  if (!C(e) || Object.keys(e).length > 32)
    throw new TypeError("ai-authoring-options-invalid");
  const t = {};
  for (const n of Object.keys(e).sort()) {
    const r = e[n];
    if (!re(n) || !["string", "number", "boolean"].includes(typeof r) || typeof r == "string" && !D(r, 1024) || typeof r == "number" && (!Number.isFinite(r) || Object.is(r, -0)))
      throw new TypeError("ai-authoring-options-invalid");
    t[n] = r;
  }
  return A(t);
}, se = (e) => e.isComposing === !0 || e.keyCode === 229, ze = (e) => {
  if ((e.trigger === "escape" || e.trigger === "outside") && se(e))
    return A({
      hideSurface: !1,
      discardDraft: !1,
      detachAdapter: !1,
      invalidateTarget: !1,
      requiresExplicitAbortPolicy: !1,
      preservePersistentIndicator: !1,
      authorityCommand: "none"
    });
  const t = e.state === "composing", n = e.state === "streaming" || e.state === "abort-requested", r = e.trigger === "route-unmount", a = e.trigger === "editor-destroy";
  return A({
    hideSurface: !0,
    discardDraft: t,
    detachAdapter: r || a,
    invalidateTarget: a,
    requiresExplicitAbortPolicy: a && n,
    preservePersistentIndicator: n || e.state === "awaiting-review",
    authorityCommand: "none"
  });
}, Te = G(
  U("textEditor.askAI.open").defaults[0]
), L = "zx-ask-ai-bridge-v1", Ve = "ai.ask", Ce = "ai.ask.bubble", De = "ai.ask", Le = 4, ie = (e) => !!(e && typeof e == "object" && e.kind === L && typeof e.openInvocation == "function" && typeof e.getState == "function" && typeof e.subscribe == "function"), Ke = (e) => ie(e) ? e : null, Fe = (e) => {
  let t = 0;
  const n = () => {
    const r = e.owner.getProjection();
    return {
      enabled: r.state !== "detached" && !r.pendingActionId,
      busy: !!r.pendingActionId,
      reason: r.state === "detached" ? "owner-detached" : r.pendingActionId ? "busy" : void 0
    };
  };
  return {
    kind: L,
    getState: n,
    subscribe: (r) => e.owner.subscribe(r),
    async openInvocation(r) {
      var i, o;
      if (!n().enabled) return null;
      const a = await e.captureContext({
        surface: r.surface,
        blockIds: r.blockIds
      });
      return !a || !n().enabled ? null : e.owner.openInvocation({
        context: a,
        surface: {
          surface: r.surface,
          invokerToken: r.invokerToken ?? ((i = e.resolveInvokerToken) == null ? void 0 : i.call(e, r.surface)) ?? `ask-ai:${r.surface}`,
          capturedAtLogical: ((o = e.nowLogical) == null ? void 0 : o.call(e)) ?? ++t
        },
        ...r.geometry ? { geometry: r.geometry } : {},
        ...r.draftPrompt !== void 0 ? { draftPrompt: r.draftPrompt } : {}
      });
    }
  };
}, qe = 8, Me = 24, K = Object.freeze([
  "format",
  "startAi",
  "submit",
  "stop",
  "reveal",
  "continueReview",
  "accept",
  "reject",
  "reviewRefine",
  "retryRefinement"
]), oe = Object.freeze([
  "selection-bubble",
  "selection-prompt",
  "product-composer",
  "response",
  "review-preview",
  "task-indicator"
]), Ge = Object.freeze([
  "no-live-selection",
  "task-open",
  "empty-prompt",
  "composer-hidden",
  "target-overlap",
  "target-relation-unknown",
  "upstream-action-disabled",
  "authority-mismatch",
  "response-hidden",
  "no-open-task",
  "open-task-content-edit-conflict",
  "disposition-pending",
  "presentation-unverified",
  "presentation-unsupported"
]), Ue = Object.freeze([
  Object.freeze({
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    equivalentCommit: "4e9e785530ff4c173f876fcac09cf334fe61b5dc",
    evidence: "source-and-tests",
    paths: Object.freeze([
      Object.freeze({
        path: "packages/xl-ai/src/components/AIMenu/AIMenuController.tsx:21-117",
        evidence: "flip, size, autoUpdate, focus manager no opening scroll",
        decision: "adapt",
        zxuiBoundary: "fixed/visualViewport in Vue adapter; close only changes presentation",
        fixtureIds: Object.freeze(["IAC-BN-VIEWPORT-01", "IAC-BN-FOCUS-02"])
      }),
      Object.freeze({
        path: "packages/xl-ai/src/components/PromptSuggestionMenu/PromptSuggestionMenu.tsx:41-153",
        evidence: "input focus, keyboard/IME path",
        decision: "adapt",
        zxuiBoundary: "stable action ID; do not copy React state",
        fixtureIds: Object.freeze(["IAC-BN-IME-03"])
      }),
      Object.freeze({
        path: "tests/src/end-to-end/ai/ai-selection.test.tsx",
        evidence: "selection retention, open/focus/no-scroll",
        decision: "copy",
        zxuiBoundary: "rebuild with ZXUI public API + Vue editor",
        fixtureIds: Object.freeze(["IAC-BN-BROWSER-04"])
      }),
      Object.freeze({
        path: "tests/src/end-to-end/ai/ai.test.tsx",
        evidence: "selection retention, open/focus/no-scroll",
        decision: "copy",
        zxuiBoundary: "rebuild with ZXUI public API + Vue editor",
        fixtureIds: Object.freeze(["IAC-BN-BROWSER-04"])
      })
    ])
  }),
  Object.freeze({
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    evidence: "source-and-tests",
    paths: Object.freeze([
      Object.freeze({
        path: "apps/www/src/registry/ui/ai-menu.tsx:65-250,278-611",
        evidence: "selection/cursor routing, menu geometry, Escape mix",
        decision: "adapt",
        zxuiBoundary: "S6 projection/actions sole authority; reject Escape→Stop",
        fixtureIds: Object.freeze(["IAC-PL-MENU-01"])
      }),
      Object.freeze({
        path: "apps/www/src/registry/ui/ai-menu.spec.tsx:220-227",
        evidence: "missing anchor does not crash",
        decision: "copy",
        zxuiBoundary: "fallback must not retarget; no document rect",
        fixtureIds: Object.freeze(["IAC-PL-ANCHOR-02"])
      }),
      Object.freeze({
        path: "packages/ai/src/react/ai-chat/AIChatPlugin.ts",
        evidence: "local chat/plugin/stop truth",
        decision: "reject",
        zxuiBoundary: "no second controller/global plugin truth",
        fixtureIds: Object.freeze(["IAC-PL-AUTH-03"])
      })
    ])
  }),
  Object.freeze({
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    evidence: "product-observation",
    paths: Object.freeze([
      Object.freeze({
        path: "apps/web/components/tailwind/advanced-editor.tsx",
        evidence: "real-page Bubble/selector/stream product composition",
        decision: "adapt",
        zxuiBoundary: "Docs/Workbench use public projection/action only; reject provider hooks",
        fixtureIds: Object.freeze(["IAC-NV-DOGFOOD-01"])
      }),
      Object.freeze({
        path: "apps/web/components/tailwind/generative/ai-selector.tsx",
        evidence: "real-page Bubble/selector/stream product composition",
        decision: "adapt",
        zxuiBoundary: "Docs/Workbench use public projection/action only; reject provider hooks",
        fixtureIds: Object.freeze(["IAC-NV-DOGFOOD-01"])
      }),
      Object.freeze({
        path: "fixed-tree/package-scripts",
        evidence: "no upstream test/spec/script",
        decision: "reject",
        zxuiBoundary: "all adopted behaviors use ZXUI-owned fixtures only",
        fixtureIds: Object.freeze(["IAC-NV-EVIDENCE-02"])
      })
    ])
  })
]), $e = Object.freeze({
  focusedBrief: "docs/initiatives/AIEDITOR-ai-document-runtime/briefs/AIEDITOR-inline-ai-interaction-coordinator.md",
  initiative: "docs/initiatives/AIEDITOR-ai-document-runtime/README.md#inline-ai-interaction-coordinator",
  requirements: "docs/specs/AIEDITOR-inline-ai-interaction-coordinator/requirements.md",
  design: "docs/specs/AIEDITOR-inline-ai-interaction-coordinator/design.md",
  supersededByThisSpec: Object.freeze([
    Object.freeze({
      spec: "docs/specs/AIEDITOR-inline-ai-surface",
      clause: "Brewing/streaming Escape ≡ Stop",
      replacement: "Escape closes presentation only; Stop requires explicit authority action + Persistent Task Indicator recovery"
    })
  ])
}), He = (e) => `authoring.status.${e}`, s = (e, t) => Object.freeze(e ? { enabled: !0 } : { enabled: !1, reason: t }), N = (e) => {
  const t = {};
  for (const n of K)
    t[n] = Object.freeze(e[n]);
  return Object.freeze(t);
}, j = (e) => e.kind === "request" || e.kind === "review" || e.kind === "review-refinement", x = (e) => !e.productComposerVisible && !e.responseVisible && !e.reviewPreviewVisible, ae = (e, t) => e === null || t === null ? e === t : e.status !== t.status || e.sourceReviewId !== t.sourceReviewId ? !1 : e.status === "superseding-review" ? t.status === "superseding-review" && e.commandId === t.commandId : t.status === "superseding-review" || e.handoffFingerprint !== t.handoffFingerprint ? !1 : e.status === "successor-start-failed" ? t.status === "successor-start-failed" && e.failureCode === t.failureCode && e.retryActionId === t.retryActionId : t.status === "starting-successor", z = (e, t) => e.sidecar.status === "active" && (t == null ? void 0 : t.reviewId) === e.sidecar.identity.reviewId && t.revision === e.sidecar.revision && t.fingerprint === e.sidecar.fingerprint, ce = (e) => {
  var d, p, u, c;
  const t = () => Object.freeze({
    kind: "invalid",
    reason: "authority-mismatch"
  });
  if (e.projection.editorBindingId !== e.editorBindingId)
    return t();
  const n = (d = e.session) == null ? void 0 : d.activeRequestId, r = typeof n == "string" && n.length > 0, a = e.exactActiveReview !== null, i = e.reviewRefinement !== null;
  if (!ae(
    e.reviewRefinement,
    e.projection.reviewRefinement ?? null
  ) || r && (a || i && ((p = e.reviewRefinement) == null ? void 0 : p.status) !== "starting-successor"))
    return t();
  const o = e.projection.sessionRef;
  if (e.session === null != (o === void 0) || e.session && o && (o.sessionId !== e.session.identity.sessionId || o.revision !== e.session.revision || o.fingerprint !== e.session.fingerprint))
    return t();
  if (r) {
    const f = (u = e.session) == null ? void 0 : u.requests.find(
      ({ requestId: g }) => g === n
    ), I = (c = e.session) == null ? void 0 : c.attempts.find(
      ({ attemptId: g }) => g === (f == null ? void 0 : f.activeAttemptId)
    );
    return !o || !f || o.requestId !== n || o.attemptId !== (I == null ? void 0 : I.attemptId) ? t() : Object.freeze({ kind: "request", requestId: n });
  }
  if ((o == null ? void 0 : o.requestId) !== void 0 || (o == null ? void 0 : o.attemptId) !== void 0)
    return t();
  if (e.reviewRefinement) {
    const f = e.reviewRefinement;
    if (f.status === "superseding-review") {
      const I = e.exactActiveReview;
      if (!I || I.sidecar.identity.reviewId !== f.sourceReviewId || !z(I, e.projection.reviewRef))
        return t();
    } else if (a || e.projection.reviewRef)
      return t();
    return Object.freeze({ kind: "review-refinement", refinement: f });
  }
  if (e.exactActiveReview) {
    const f = e.exactActiveReview;
    return z(f, e.projection.reviewRef) ? Object.freeze({
      kind: "review",
      reviewId: f.sidecar.identity.reviewId
    }) : t();
  }
  return Object.freeze({ kind: "none" });
}, de = (e) => {
  const t = [], n = e.presentation.selectionBubbleRequested && e.liveSelection && (e.activity.kind === "none" || e.activity.kind === "review");
  return n && t.push("selection-bubble"), e.presentation.selectionPromptVisible && n && t.push("selection-prompt"), e.presentation.productComposerVisible && t.push("product-composer"), e.presentation.reviewPreviewVisible && e.activity.kind !== "invalid" ? t.push("review-preview") : e.presentation.responseVisible && e.activity.kind !== "invalid" && t.push("response"), j(e.activity) && x(e.presentation) && t.push("task-indicator"), x(e.presentation) && (e.authoringState === "error" || e.authoringState === "conflict" || e.authoringState === "detached") && !t.includes("task-indicator") && t.push("task-indicator"), Object.freeze(
    oe.filter((r) => t.includes(r))
  );
}, fe = (e) => {
  const t = [];
  return (e.refinementRetryAvailable || (j(e.activity) || e.authoringState === "error" || e.authoringState === "conflict" || e.authoringState === "detached") && x(e.presentation)) && t.push("task-indicator"), e.presentation.selectionBubbleRequested && e.liveSelection && (e.activity.kind === "review" || e.authoringState === "error" || e.authoringState === "conflict") && t.push("bubble-recovery"), Object.freeze(t);
}, le = (e) => e === "review-accept-all" || e === "review-reject-all" || e === "review-refine" || e === "review-commit", ue = (e) => {
  const { activity: t, liveSelection: n, presentation: r, promptGate: a, actions: i } = e;
  if (t.kind === "invalid")
    return N(
      Object.fromEntries(
        K.map((F) => [
          F,
          s(!1, "authority-mismatch")
        ])
      )
    );
  const o = j(t), d = r.selectionPromptVisible || r.productComposerVisible, p = n ? o ? s(!1, "open-task-content-edit-conflict") : s(!0) : s(!1, "no-live-selection"), u = n ? o ? s(!1, "task-open") : s(!0) : s(!1, "no-live-selection"), c = o ? s(!1, "task-open") : d ? a.hasValidPrompt ? r.selectionPromptVisible || i.submit ? s(!0) : s(!1, "upstream-action-disabled") : s(!1, "empty-prompt") : s(!1, "composer-hidden"), f = t.kind !== "request" ? s(!1, "no-open-task") : i.stop ? s(!0) : s(!1, "upstream-action-disabled"), I = o ? !x(r) || !i.reveal ? s(!1, "upstream-action-disabled") : s(!0) : s(!1, "no-open-task"), g = t.kind !== "review" ? s(!1, "no-open-task") : i.reveal ? s(!0) : s(!1, "upstream-action-disabled"), w = t.kind === "review-refinement" || le(e.pendingActionId), m = r.reviewPreviewVisible || r.responseVisible || r.selectionBubbleRequested && n, b = w ? s(!1, "disposition-pending") : t.kind !== "review" ? s(!1, "no-open-task") : e.reviewPresentationGate.status === "unverified" ? s(!1, "presentation-unverified") : e.reviewPresentationGate.status !== "verified" ? s(!1, "presentation-unsupported") : r.reviewPreviewVisible ? i["review-accept-all"] ? s(!0) : s(!1, "upstream-action-disabled") : s(!1, "response-hidden"), h = w ? s(!1, "disposition-pending") : t.kind !== "review" ? s(!1, "no-open-task") : m ? i["review-reject-all"] ? s(!0) : s(!1, "upstream-action-disabled") : s(!1, "response-hidden"), y = w ? s(!1, "disposition-pending") : t.kind !== "review" ? s(!1, "no-open-task") : m ? i["review-refine"] ? s(!0) : s(!1, "upstream-action-disabled") : s(!1, "response-hidden"), O = t.kind !== "review-refinement" || t.refinement.status !== "successor-start-failed" ? s(!1, "no-open-task") : e.pendingActionId ? s(!1, "disposition-pending") : i["retry-review-refine"] ? s(!0) : s(!1, "upstream-action-disabled");
  return N({
    format: p,
    startAi: u,
    submit: c,
    stop: f,
    reveal: I,
    continueReview: g,
    accept: b,
    reject: h,
    reviewRefine: y,
    retryRefinement: O
  });
}, pe = (e, t) => e.baseDocumentFingerprint === t.baseDocumentFingerprint && e.semanticSnapshotFingerprint === t.semanticSnapshotFingerprint && e.baseDocumentFingerprint.length > 0 && e.semanticSnapshotFingerprint.length > 0, T = (e) => e.kind === "document" || !Array.isArray(e.blockIds) || e.blockIds.length === 0 ? null : new Set(e.blockIds), Ie = (e, t, n, r) => Math.max(e, n) < Math.min(t, r), V = (e) => {
  if (e.blockIds.length === 0 || new Set(e.blockIds).size !== e.blockIds.length || !Number.isSafeInteger(e.start.offset) || !Number.isSafeInteger(e.end.offset) || e.start.offset < 0 || e.end.offset < 0)
    return !1;
  const t = e.blockIds.indexOf(e.start.blockId), n = e.blockIds.indexOf(e.end.blockId);
  return t >= 0 && n >= t && (t !== n || e.start.offset <= e.end.offset);
}, be = (e, t) => {
  if (!V(e) || !V(t))
    return "unknown";
  const n = (i, o) => {
    if (!i.blockIds.includes(o)) return null;
    const d = i.start.blockId === o ? i.start.offset : 0, p = i.end.blockId === o ? i.end.offset : Number.POSITIVE_INFINITY;
    return [d, p];
  }, r = new Set(t.blockIds), a = e.blockIds.filter((i) => r.has(i));
  if (a.length === 0) return "disjoint";
  for (const i of a) {
    const o = n(e, i), d = n(t, i);
    if (o && d && Ie(
      o[0],
      o[1],
      d[0],
      d[1]
    ))
      return "overlap";
  }
  return "disjoint";
}, ye = (e) => {
  const { liveTarget: t, activeTarget: n } = e;
  if (!t || !n || t.editorBindingId !== e.editorBindingId || n.editorBindingId !== e.editorBindingId || t.editorBindingId !== n.editorBindingId || t.kind !== "selection" || !pe(t, n)) return "unknown";
  if (n.kind === "document") return "overlap";
  if (n.kind === "blocks") {
    const r = T(t), a = T(n);
    if (!r || !a) return "unknown";
    for (const i of r)
      if (a.has(i)) return "overlap";
    return "disjoint";
  }
  return n.kind === "selection" ? be(t, n) : "unknown";
}, Ze = (e) => {
  const t = ce(e), n = e.selection.phase === "live" && e.selection.liveTarget != null, r = e.selection.retainedTarget != null, a = n && j(t) ? ye({
    editorBindingId: e.editorBindingId,
    liveTarget: e.selection.liveTarget,
    activeTarget: e.selection.retainedTarget
  }) : "unknown", i = de({
    liveSelection: n,
    presentation: e.presentation,
    activity: t,
    authoringState: e.projection.state
  }), o = fe({
    activity: t,
    presentation: e.presentation,
    liveSelection: n,
    authoringState: e.projection.state,
    refinementRetryAvailable: e.projection.actions["retry-review-refine"] === !0
  }), d = ue({
    activity: t,
    liveSelection: n,
    presentation: e.presentation,
    promptGate: e.promptGate,
    actions: e.projection.actions,
    pendingActionId: e.projection.pendingActionId,
    reviewPresentationGate: e.reviewPresentationGate
  });
  return Object.freeze({
    authoringState: e.projection.state,
    authoringActions: e.projection.actions,
    taskActivity: t,
    liveSelection: n,
    retainedReviewTarget: r,
    targetRelation: a,
    reviewPresentationGate: e.reviewPresentationGate,
    visibleSurfaces: i,
    recoverySurfaces: o,
    capabilities: d
  });
}, me = (e) => e.kind !== "none", ge = (e, t) => {
  var n, r, a, i, o, d, p, u;
  return t !== void 0 && t.editorBindingId === e.editorBindingId && t.projectionFingerprint === e.fingerprint && t.sessionId === ((n = e.sessionRef) == null ? void 0 : n.sessionId) && t.sessionRevision === ((r = e.sessionRef) == null ? void 0 : r.revision) && t.sessionFingerprint === ((a = e.sessionRef) == null ? void 0 : a.fingerprint) && t.requestId === ((i = e.sessionRef) == null ? void 0 : i.requestId) && t.attemptId === ((o = e.sessionRef) == null ? void 0 : o.attemptId) && t.reviewId === ((d = e.reviewRef) == null ? void 0 : d.reviewId) && t.reviewRevision === ((p = e.reviewRef) == null ? void 0 : p.revision) && t.reviewFingerprint === ((u = e.reviewRef) == null ? void 0 : u.fingerprint);
}, he = (e, t) => t.editorBindingId === e.editorBindingId && t.target.editorBindingId === e.editorBindingId, We = (e) => me(e.coordinator.taskActivity) ? e.coordinator.capabilities.reveal.enabled && e.authoring.actions.reveal === !0 && ge(e.authoring, e.actionBinding) ? Object.freeze({
  kind: "reveal",
  actionId: "reveal",
  binding: e.actionBinding
}) : Object.freeze({ kind: "closed", reason: "task-open" }) : e.selectionPreflight.status === "valid" && he(
  e.authoring,
  e.selectionPreflight.invocationContext
) ? Object.freeze({
  kind: "open",
  invocationContext: e.selectionPreflight.invocationContext
}) : Object.freeze({
  kind: "closed",
  reason: e.selectionPreflight.status === "invalid" ? e.selectionPreflight.reason ?? "selection-required" : "selection-required"
});
export {
  P as A,
  K as B,
  oe as C,
  Ge as D,
  Ue as E,
  $e as F,
  He as G,
  We as H,
  qe as I,
  X as J,
  ke as K,
  Pe as L,
  l as M,
  k as P,
  Be as a,
  Ne as b,
  Re as c,
  Ee as d,
  Se as e,
  _e as f,
  C as g,
  xe as h,
  E as i,
  je as j,
  re as k,
  D as l,
  se as m,
  De as n,
  L as o,
  Ce as p,
  Le as q,
  ze as r,
  Te as s,
  Ve as t,
  Fe as u,
  Ke as v,
  Oe as w,
  Ze as x,
  ye as y,
  Me as z
};
//# sourceMappingURL=inline-ai-shortcut-router-a-QG5h2e.mjs.map
