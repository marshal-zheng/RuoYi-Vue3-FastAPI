import { ab as ir, a8 as cr, n as nn, h as on, m as No, u as Bo, w as sn, y as zo, x as _o, t as ut, an as lr } from "./delivery-surfaces-BeupB41w.mjs";
import { b as Po, O as an, M as cn, c1 as Fo, D as ln, T as Ho, as as be, c2 as Vo, c3 as jo, ar as dn, bL as Ye, c4 as Uo, c5 as He, c6 as mt, c7 as At, bA as un, bJ as qo, bi as mn, x as Ko, bV as Wo, bW as Go, h as Xo, bY as Jo, H as Yo, bZ as Zo, b_ as Qo, b$ as es, c0 as ts, bc as rs, S as ns, aI as os, aB as ss, ax as as, ay as is, aw as cs, c8 as fn, v as ls, A as ds, aq as dr, bl as us, c9 as Ne, bS as ms, bU as fs } from "./link-paste-handler-COpsSlXB.mjs";
import { createActionPort as ps } from "@zxio/keybindings/core";
import { G as gs, i as pn, b as hs, I as bs, a as Ve, E as K, x as gn, A as Mt, z as hn, F as Ot, w as Ze, S as ys, t as ks, j as Be, n as ft, o as bn } from "./envelope-CrN5-dS1.mjs";
import { v as $t, l as pt, m as gt } from "./actions-Sd62WBGv.mjs";
import { c as Lt, a as vs } from "./stable-block-ids-CPxz-1sA.mjs";
import { ac as Ss, ad as Is, a as Ts, b as xs, c as ws } from "./orchestrator-DBIyJOJn.mjs";
import { Plugin as yn, PluginKey as kn, NodeSelection as Es, TextSelection as vn } from "@tiptap/pm/state";
import { Extension as Qe, generateJSON as Cs } from "@tiptap/core";
import { renderToHTMLString as Ds, serializeChildrenToHTMLString as Sn } from "@tiptap/static-renderer/pm/html-string";
import { Z as Rs, c as ur, d as As } from "./projection-r_4Na96h.mjs";
import Ms from "@tiptap/extension-code";
import Os from "@tiptap/extension-link";
import $s from "@tiptap/starter-kit";
import Ls from "@tiptap/extension-text-align";
import { Table as Ns } from "@tiptap/extension-table";
import Bs from "@tiptap/extension-typography";
import { TextStyle as zs, FontFamily as _s, FontSize as Ps } from "@tiptap/extension-text-style";
import { TaskList as Fs, TaskItem as Hs } from "@tiptap/extension-list";
import Vs from "@tiptap/extension-underline";
import js from "@tiptap/extension-code-block-lowlight";
const Us = { DEV: !1 }, mr = /* @__PURE__ */ new Set(), qs = () => Us.DEV, Ks = (e, t) => {
  const r = [];
  return e.descendants((n, o) => (t.includes(n.type.name) && r.push({ node: n, pos: o }), !0)), r;
}, Ws = (e) => {
  for (let t = e.length - 1; t >= 0; t -= 1) {
    const r = e[t].getMeta(
      Po
    );
    if (r)
      return r;
  }
  return null;
}, ht = (e, t, r) => {
  const n = /* @__PURE__ */ new Set(), o = [];
  return Ks(e, t).forEach(({ node: s, pos: i }) => {
    const a = gs(
      s.attrs
    );
    if (!a) {
      o.push({
        code: "missing-block-id",
        message: `Missing blockId on ${s.type.name} at position ${i}.`,
        nodeType: s.type.name,
        pos: i,
        blockId: null
      });
      return;
    }
    if (!pn(a)) {
      o.push({
        code: "invalid-block-id",
        message: `Invalid blockId "${a}" on ${s.type.name} at position ${i}.`,
        nodeType: s.type.name,
        pos: i,
        blockId: a
      });
      return;
    }
    if (n.has(a)) {
      o.push({
        code: "duplicate-block-id",
        message: `Duplicate blockId "${a}" on ${s.type.name} at position ${i}.`,
        nodeType: s.type.name,
        pos: i,
        blockId: a
      });
      return;
    }
    if (n.add(a), !r)
      return;
    const c = r.nodeDOM(i), l = c instanceof HTMLElement ? c : null;
    if (!l)
      return;
    l.getAttribute(hs) !== a && o.push({
      code: "missing-block-dom-id",
      message: `DOM data-block-id mismatch for ${s.type.name} at position ${i}.`,
      nodeType: s.type.name,
      pos: i,
      blockId: a
    }), bs(s.type.name) && l.id !== a && o.push({
      code: "heading-dom-id-mismatch",
      message: `Heading DOM id mismatch for blockId "${a}" at position ${i}.`,
      nodeType: s.type.name,
      pos: i,
      blockId: a
    });
  }), o;
};
Qe.create({
  name: "stableBlockIdentityDiagnostics",
  addOptions() {
    return {
      types: [...Ve],
      generateId: void 0,
      filterRemoteTransactions: !0
    };
  },
  addStorage() {
    return {
      issues: [],
      lastRepair: null,
      refresh: (() => [])
    };
  },
  onCreate() {
    const e = () => {
      const t = ht(
        this.editor.state.doc,
        this.options.types,
        this.editor.view
      );
      return this.storage.issues = t, t;
    };
    this.storage.refresh = e, e();
  },
  addProseMirrorPlugins() {
    const e = this, t = (r) => {
      const n = ht(
        r.state.doc,
        e.options.types,
        r
      );
      e.storage.issues = n, qs() && n.forEach((o) => {
        const s = [
          o.code,
          o.nodeType,
          o.pos,
          o.blockId ?? "missing"
        ].join(":");
        mr.has(s) || (mr.add(s), console.warn(`[stableBlockIdentity] ${o.message}`));
      });
    };
    return [
      new yn({
        key: new kn("stableBlockIdentityDiagnostics"),
        view(r) {
          return {
            update(n, o) {
              o.doc.eq(n.state.doc) || t(n);
            }
          };
        },
        appendTransaction: (r, n, o) => (e.storage.lastRepair = Ws(r), n.doc.eq(o.doc), null)
      })
    ];
  }
});
const Gs = () => ({
  blockTokenizers: [
    (e, t) => {
      const r = e[t];
      return (r == null ? void 0 : r.trim()) !== ir ? null : {
        token: {
          type: "zx_page_break",
          raw: r
        },
        nextIndex: t + 1
      };
    }
  ],
  tokenParsers: {
    zx_page_break: () => [
      {
        type: cr
      }
    ]
  },
  nodeSerializers: {
    [cr]: () => ir
  },
  inlineTextTokenizers: []
}), ze = (e, t, r, n) => ({
  code: e,
  severity: t,
  path: r,
  message: n
}), Nt = [
  "language",
  "wrap",
  "showLineNumbers",
  "copyMode"
], Bt = (e) => e.attrs ?? {}, zt = (e, t) => {
  var r;
  return typeof ((r = e.attrs) == null ? void 0 : r.blockId) == "string" && e.attrs.blockId.trim() ? e.attrs.blockId.trim() : `path:${t.join(".")}`;
}, In = (e, t = [], r = []) => {
  var n;
  return e.type === "codeBlock" && r.push({ node: e, path: t }), (n = e.content) == null || n.forEach(
    (o, s) => In(o, [...t, s], r)
  ), r;
}, Xs = (e, t) => {
  const r = e.find(
    (o) => zt(o.node, o.path) === t
  ), n = r ? Bt(r.node).groupId : null;
  return typeof n == "string" && n.trim() ? n.trim() : null;
}, Js = (e, t, r) => {
  var s;
  const n = zt(e.node, e.path);
  if (t.scope === "document") return !0;
  if (t.scope === "current-block") return n === t.currentBlockId;
  if (t.scope === "selection")
    return ((s = t.selectionBlockIds) == null ? void 0 : s.includes(n)) === !0;
  const o = t.groupId ?? Xs(r, t.currentBlockId) ?? null;
  return !!o && Bt(e.node).groupId === o;
}, Ys = (e, t) => {
  var n;
  return t in e ? ((n = e.defaultSource) == null ? void 0 : n[t]) !== "platform-default" : !1;
}, Zs = (e, t, r) => {
  const n = {};
  if (t.language !== void 0 || t.normalizeLanguageAliases) {
    const o = t.language !== void 0 ? t.language : e.language, s = on(
      typeof o == "string" ? o : null
    );
    r.push(...s.diagnostics), s.supported === !1 ? r.push(
      ze(
        "codeBlock.bulk.unsupportedLanguage",
        "warning",
        "operation.language",
        "Target language is unsupported by the code block capability map."
      )
    ) : (t.language !== void 0 || s.id !== e.language) && (n.language = s.id);
  }
  return t.wrap !== void 0 && (n.wrap = t.wrap), t.showLineNumbers !== void 0 && (n.showLineNumbers = t.showLineNumbers), t.copyMode !== void 0 && (n.copyMode = t.copyMode), n;
}, fr = (e) => Nt.filter(
  (t) => t in e || t === "language" && e.normalizeLanguageAliases === !0
), Qs = (e, t) => {
  var n;
  if ((n = e.contractRepairBlockIds) != null && n.includes(t))
    return fr(e.operation);
  if (!e.supportedFields) return [];
  const r = new Set(e.supportedFields);
  return fr(e.operation).filter(
    (o) => !r.has(o)
  );
}, ea = (e, t) => {
  const r = Bt(e.node), n = zt(e.node, e.path), o = [], s = nn(r).attrs, i = Qs(t, n);
  if (i.length)
    return {
      blockId: n,
      scope: t.scope,
      before: s,
      after: {},
      status: "failed",
      reason: `contract-repair:${i.join(",")}`,
      diagnostics: i.map(
        (d) => ze(
          "codeBlock.bulk.contractRepairRequired",
          "error",
          `operation.${d}`,
          "Bulk operation field is not supported by the current V2 contract or delivery descriptor."
        )
      )
    };
  if (r.locked === !0 || r.readonly === !0 || r.readOnly === !0)
    return {
      blockId: n,
      scope: t.scope,
      before: s,
      after: {},
      status: "skipped",
      reason: "locked-or-readonly",
      diagnostics: [
        ze(
          "codeBlock.bulk.skippedReadonly",
          "info",
          n,
          "Locked or readonly code block was skipped."
        )
      ]
    };
  const a = Zs(r, t.operation, o), c = Nt.filter(
    (d) => d in a && a[d] !== s[d]
  );
  if (o.some(
    (d) => d.code === "codeBlock.bulk.unsupportedLanguage"
  ))
    return {
      blockId: n,
      scope: t.scope,
      before: s,
      after: a,
      status: "skipped",
      reason: "unsupported-language",
      diagnostics: o
    };
  const l = c.filter(
    (d) => Ys(r, d)
  );
  return l.length && t.allowExplicitOverwrite !== !0 ? {
    blockId: n,
    scope: t.scope,
    before: s,
    after: a,
    status: "skipped",
    reason: `explicit-field:${l.join(",")}`,
    diagnostics: [
      ...o,
      ze(
        "codeBlock.bulk.explicitFieldNeedsConfirmation",
        "info",
        n,
        "Explicit, migration, or sidecar field needs preview confirmation before overwrite."
      )
    ]
  } : c.length ? {
    blockId: n,
    scope: t.scope,
    before: s,
    after: a,
    status: "will-change",
    diagnostics: o
  } : {
    blockId: n,
    scope: t.scope,
    before: s,
    after: {},
    status: "unchanged",
    reason: "no-change",
    diagnostics: o
  };
}, am = (e, t = {}) => {
  const r = In(e.content), o = r.filter(
    (a) => Js(a, e, r)
  ).map((a) => ea(a, e)), s = o.flatMap((a) => a.diagnostics), i = {
    scope: e.scope,
    total: o.length,
    willChange: o.filter((a) => a.status === "will-change").length,
    unchanged: o.filter((a) => a.status === "unchanged").length,
    skipped: o.filter((a) => a.status === "skipped").length,
    failed: o.filter((a) => a.status === "failed").length,
    items: o,
    diagnostics: s
  };
  return an(
    t.onEvent,
    cn({
      type: "bulk-preview",
      status: i.failed ? "failed" : i.skipped ? "degraded" : "success",
      diagnostics: s,
      metadata: {
        scope: e.scope,
        total: i.total,
        willChange: i.willChange,
        skipped: i.skipped,
        failed: i.failed
      }
    })
  ), i;
}, im = (e) => `${e.willChange}/${e.total} will change, ${e.skipped} skipped, ${e.failed} failed`, cm = (e) => !Nt.some((t) => t in e) && e.normalizeLanguageAliases !== !0, Tn = (e) => {
  var t;
  return typeof e.text == "string" ? e.text : e.type === "hardBreak" ? `
` : ((t = e.content) == null ? void 0 : t.map(Tn).join("")) ?? "";
}, ta = (e, t) => {
  var r;
  return typeof ((r = e.attrs) == null ? void 0 : r.blockId) == "string" && e.attrs.blockId.trim() ? e.attrs.blockId.trim() : `path:${t.join(".")}`;
}, ra = (e, t = [], r = []) => {
  var n;
  if (e.type === "codeBlock") {
    const o = nn(
      e.attrs ?? {}
    );
    r.push({
      blockId: ta(e, t),
      node: e,
      path: t,
      code: Tn(e),
      attrs: o.attrs,
      diagnostics: o.diagnostics
    });
  }
  return (n = e.content) == null || n.forEach(
    (o, s) => ra(o, [...t, s], r)
  ), r;
}, ke = (e, t, r, n) => ({
  code: e,
  severity: t,
  path: r,
  message: n
}), na = (e) => e.type === "codeBlock", je = (e) => e.attrs ?? {}, oa = (e, t) => {
  var r;
  return typeof ((r = e.attrs) == null ? void 0 : r.blockId) == "string" && e.attrs.blockId.trim() ? e.attrs.blockId.trim() : `path:${t.join(".")}`;
}, sa = (e, t) => {
  const r = e[0];
  if (!r) return null;
  const n = je(r.node), o = typeof n.groupId == "string" ? n.groupId : "";
  if (!o.trim()) return null;
  const s = [], i = /* @__PURE__ */ new Set(), a = e.map((l, d) => {
    const u = je(l.node), m = typeof u.tabLabel == "string" ? u.tabLabel.trim() : "", f = on(
      typeof u.language == "string" ? u.language : null
    ), h = [...f.diagnostics];
    return m ? i.has(m) && h.push(
      ke(
        "codeBlock.tabs.duplicateLabel",
        "warning",
        `groups.${o}.${d}.tabLabel`,
        "Tabs group labels must be unique within the group."
      )
    ) : h.push(
      ke(
        "codeBlock.tabs.emptyLabel",
        "warning",
        `groups.${o}.${d}.tabLabel`,
        "Tabs group block has an empty tabLabel."
      )
    ), i.add(m), {
      blockId: oa(l.node, l.path),
      tabLabel: m,
      language: f.id,
      diagnostics: h
    };
  });
  a.forEach((l) => s.push(...l.diagnostics)), e.length < 2 && s.push(
    ke(
      "codeBlock.tabs.tooFewBlocks",
      "warning",
      `groups.${o}`,
      "A valid tabs group needs at least two adjacent code blocks."
    )
  ), t.has(o) && s.push(
    ke(
      "codeBlock.tabs.nonContiguous",
      "warning",
      `groups.${o}`,
      "Tabs group appears in multiple non-adjacent runs."
    )
  );
  const c = s.some((l) => l.severity === "error") || s.some(
    (l) => [
      "codeBlock.tabs.duplicateLabel",
      "codeBlock.tabs.nonContiguous"
    ].includes(l.code)
  ) || e.length < 2 || a.some((l) => !l.tabLabel) ? "invalid" : s.length ? "partial" : "valid";
  return {
    groupId: o,
    blocks: a,
    status: c,
    diagnostics: s
  };
}, xn = (e, t, r, n) => {
  if (!(e != null && e.length)) return;
  const o = [];
  let s = [], i = null;
  e.forEach((l, d) => {
    const u = je(l), m = na(l) && typeof u.groupId == "string" ? u.groupId.trim() : "";
    m && m === i ? s.push({ node: l, path: [...t, d] }) : (s.length && o.push(s), s = m ? [{ node: l, path: [...t, d] }] : [], i = m || null), xn(l.content, [...t, d], r, n);
  }), s.length && o.push(s);
  const a = /* @__PURE__ */ new Map();
  o.forEach((l) => {
    const d = l[0];
    if (!d) return;
    const u = je(d.node);
    typeof u.groupId == "string" && u.groupId.trim() && a.set(
      u.groupId.trim(),
      (a.get(u.groupId.trim()) ?? 0) + 1
    );
  });
  const c = new Set(
    [...a.entries()].filter(([, l]) => l > 1).map(([l]) => l)
  );
  o.forEach((l) => {
    const d = sa(l, c);
    d && (r.push(d), n.push(...d.diagnostics));
  });
}, aa = (e, t = {}) => {
  const r = [], n = [];
  return xn(e.content, [], r, n), an(
    t.onEvent,
    cn({
      type: "tabs-edit",
      status: n.length ? "degraded" : "success",
      diagnostics: n,
      metadata: { groupCount: r.length }
    })
  ), { groups: r, diagnostics: n };
}, lm = (e, t = [
  "markdown-serializer",
  "pdf-composition",
  "docx-composition"
]) => {
  const n = aa(e).groups.filter(
    (o) => o.status !== "valid"
  );
  return t.flatMap(
    (o) => n.map(
      (s) => ke(
        "codeBlock.delivery.tabsInvalidGroup",
        "warning",
        `${o}.tabs.${s.groupId}`,
        "Invalid tabs group is delivered as ordinary adjacent code blocks on this surface."
      )
    )
  );
}, at = (e) => {
  var t;
  return {
    groupId: ((t = e.groupId) == null ? void 0 : t.trim()) || null,
    tabLabel: e.tabLabel.trim()
  };
}, dm = (e) => e.action === "create" ? e.tabs.map((t) => ({
  blockId: t.blockId,
  attrs: at({
    groupId: e.groupId,
    tabLabel: t.tabLabel
  })
})) : e.action === "rename" ? [
  {
    blockId: e.blockId,
    attrs: { tabLabel: e.tabLabel.trim() }
  }
] : e.action === "split" ? e.tabs.map((t) => ({
  blockId: t.blockId,
  attrs: at({
    groupId: e.groupId,
    tabLabel: t.tabLabel ?? ""
  })
})) : e.blockIds.map((t) => ({
  blockId: t,
  attrs: at({
    groupId: null,
    tabLabel: ""
  })
})), um = (e) => ({
  tabLabel: e.trim()
}), ia = (e, t, r, n) => ({
  code: e,
  severity: t,
  path: r,
  message: n
}), ca = [
  "public-read-page",
  "markdown-serializer",
  "search-record",
  "pdf-composition",
  "docx-composition"
], mm = (e = {}) => {
  const t = [
    {
      id: "CODEBLOCK-contract-migration",
      status: e.spec1Delivered === !0 ? "pass" : "missing",
      evidence: [
        "ZxCodeBlockAttrsV2 contains detectedLanguage, highlightLines, copyMode, groupId, tabLabel and defaultSource."
      ]
    },
    {
      id: "CODEBLOCK-editor-authoring-ux",
      status: e.spec2Delivered === !0 ? "pass" : "missing",
      evidence: [
        "NodeView consumes resolveCodeBlockEditorViewState and updateCodeBlockV2Attrs."
      ]
    },
    {
      id: "CODEBLOCK-unified-render-export",
      status: e.spec3Delivered === !0 ? "pass" : "missing",
      evidence: [
        "createCodeBlockDeliveryDescriptor and createCodeBlockSurfaceProjection are available."
      ]
    },
    {
      id: "batch-2-integration-review",
      status: e.batch2Reviewed === !0 ? "pass" : "missing",
      evidence: [
        "Spec4 task worktree restored Spec3 delivery snapshot before implementation."
      ]
    }
  ], r = [], n = No({
    code: 'console.log("ok")',
    attrs: {
      language: "ts",
      copyMode: "markdown",
      groupId: "sdk-tabs",
      tabLabel: "TypeScript",
      highlightLines: [{ from: 1 }]
    }
  }), o = Bo(n);
  r.push(...o.diagnostics), ["copyMode", "groupId", "tabLabel", "highlightLines"].forEach(
    (a) => {
      ((a === "highlightLines" ? n.display.highlightLines : n.attrs[a]) === void 0 || a === "highlightLines" && !n.display.highlightLines.length) && r.push(
        ia(
          "codeBlock.productivity.contractRepairRequired",
          "error",
          `descriptor.${a}`,
          `Descriptor cannot express ${a}; Spec4 must not add a parallel field.`
        )
      );
    }
  ), ca.forEach((a) => {
    const c = sn({
      surface: a,
      descriptor: n
    });
    r.push(...c.diagnostics);
  });
  const s = t.some(
    (a) => a.status !== "pass"
  ), i = r.some(
    (a) => a.severity === "error"
  );
  return {
    status: s ? "blocked" : i ? "contract-repair-required" : "pass",
    dependencies: t,
    diagnostics: r
  };
}, fm = [
  { name: "Black", value: "#000000" },
  { name: "Dark Gray", value: "#545454" },
  { name: "Gray", value: "#909399" },
  { name: "Light Gray", value: "#c0c4cc" },
  { name: "Red", value: "#f56c6c" },
  { name: "Orange", value: "#e6a23c" },
  { name: "Yellow", value: "#f2c037" },
  { name: "Green", value: "#67c23a" },
  { name: "Cyan", value: "#13c2c2" },
  { name: "Blue", value: "#409eff" },
  { name: "Purple", value: "#9b59b6" },
  { name: "Pink", value: "#eb2f96" }
], pm = [
  { name: "Yellow", value: "#fef08a" },
  { name: "Green", value: "#bbf7d0" },
  { name: "Blue", value: "#bfdbfe" },
  { name: "Pink", value: "#fbcfe8" },
  { name: "Purple", value: "#ddd6fe" },
  { name: "Orange", value: "#fed7aa" },
  { name: "Red", value: "#fecaca" },
  { name: "Gray", value: "#e5e7eb" }
], la = "zx-text-editor-typography-surface", da = /^-?(?:\d+|\d*\.\d+)(?:px|rem|em|%|vh|vw|vmin|vmax|ch|ex|pt|pc|cm|mm|in)$/i, ua = /^var\(\s*--[A-Za-z0-9_-]+(?:\s*,\s*[^{};]+)?\s*\)$/, ma = /^(?:calc|min|max|clamp)\([0-9A-Za-z%.,+\-/*\s()_'"-]+\)$/, wn = (e) => {
  if (typeof e != "string")
    return null;
  const t = e.trim();
  return t || null;
}, En = (e) => /[{};]/.test(e) || /\b(?:url|expression)\s*\(/i.test(e), fa = (e) => {
  const t = wn(e);
  return !t || En(t) ? null : da.test(t) || ua.test(t) || ma.test(t) ? t : null;
}, pa = (e) => {
  const t = wn(e);
  return !t || En(t) ? null : t;
}, ga = (e, t) => e === "fontSize" ? fa(t) : pa(t), ha = (e, t) => `--text-editor-content-${e}-${t === "fontSize" ? "font-size" : "font-family"}`, Ee = (e, t, r, n) => {
  const o = ga(r, n);
  o && (e[ha(t, r)] = o);
}, ba = (e) => {
  var n;
  const t = e, r = (n = t == null ? void 0 : t.storage) == null ? void 0 : n[Fo];
  return (r == null ? void 0 : r.contract) ?? ln;
}, ya = (e = null) => {
  var n, o;
  const t = e ?? ln, r = {};
  return Ee(
    r,
    "root",
    "fontSize",
    ((n = t.root.fontSize) == null ? void 0 : n.cssValue) ?? null
  ), Ee(
    r,
    "root",
    "fontFamily",
    ((o = t.root.fontFamily) == null ? void 0 : o.cssValue) ?? null
  ), Ho.forEach((s) => {
    var a, c, l, d;
    const i = t.blocks[s];
    Ee(
      r,
      s,
      "fontSize",
      ((a = i == null ? void 0 : i.fontSize) == null ? void 0 : a.cssValue) ?? ((c = t.root.fontSize) == null ? void 0 : c.cssValue)
    ), Ee(
      r,
      s,
      "fontFamily",
      ((l = i == null ? void 0 : i.fontFamily) == null ? void 0 : l.cssValue) ?? ((d = t.root.fontFamily) == null ? void 0 : d.cssValue)
    );
  }), r;
}, ka = (e = null) => ({
  className: la,
  style: ya(e)
}), gm = (e) => ka(
  ba(e)
), va = ["wss://signaling.yjs.dev"], Sa = [
  { urls: "stun:stun.l.google.com:19302" }
];
async function hm(e) {
  const {
    roomId: t,
    signaling: r = va,
    user: n,
    persistence: o = !0,
    iceServers: s = Sa,
    auth: i,
    onError: a,
    onStatusChange: c,
    onAuthError: l
  } = e;
  let d = null, u = null, m = null;
  try {
    d = await import("yjs"), u = (await import("./y-webrtc-BRK-1-Tt.mjs")).WebrtcProvider, o && (m = (await import("./y-indexeddb-CNWWqppD.mjs")).IndexeddbPersistence);
  } catch (v) {
    return a == null || a(new Error(`Failed to load collaboration dependencies: ${v}`)), null;
  }
  const f = new d.Doc({ gc: !0 });
  let h = null;
  if (o && m)
    try {
      h = new m(`zx-editor-${t}`, f);
    } catch (v) {
      a == null || a(new Error(`Failed to initialize local persistence: ${v}`));
    }
  const k = (v) => v ? r.map((C) => {
    const N = C.includes("?") ? "&" : "?";
    return `${C}${N}token=${encodeURIComponent(v)}`;
  }) : r, b = (v) => v ? { ...n, _authToken: v } : n, R = (v) => {
    if (!Number.isFinite(v) || v <= 0) return null;
    const C = Date.now(), N = v > C ? v : C + v;
    return Math.max(0, N - C - 6e4);
  };
  let T = i == null ? void 0 : i.token, y, I = "connecting", w = null;
  const p = /* @__PURE__ */ new Set(), g = /* @__PURE__ */ new Set(), x = (v) => {
    const C = v.status === "connected" ? "connected" : "disconnected";
    C !== I && (I = C, c == null || c(C)), p.forEach((N) => N(v));
  }, O = (v) => {
    g.forEach((C) => C(v));
  }, $ = () => {
    y.on("status", x), y.on("synced", O);
  }, E = () => {
    var v, C;
    (v = y.off) == null || v.call(y, "status", x), (C = y.off) == null || C.call(y, "synced", O);
  }, A = () => {
    try {
      return y = new u(t, f, {
        signaling: k(T),
        peerOpts: {
          config: { iceServers: s }
        }
      }), $(), y.awareness.setLocalStateField("user", b(T)), !0;
    } catch (v) {
      return a == null || a(new Error(`Failed to create WebRTC provider: ${v}`)), !1;
    }
  }, P = (v) => {
    if (T = v, y) {
      E();
      try {
        y.destroy();
      } catch (C) {
        a == null || a(new Error(`Failed to recreate provider: ${C}`));
      }
    }
    I = "connecting", c == null || c("connecting"), A() || (I = "disconnected", c == null || c("disconnected"));
  };
  if (!A())
    return null;
  if (i != null && i.refreshToken && (i != null && i.tokenExpiry)) {
    const v = () => {
      const C = R(i.tokenExpiry);
      C !== null && (w = setTimeout(async () => {
        try {
          const N = await i.refreshToken();
          P(N), v();
        } catch (N) {
          l == null || l({
            code: "token_expired",
            message: "Failed to refresh authentication token",
            originalError: N instanceof Error ? N : new Error(String(N))
          });
        }
      }, C));
    };
    v();
  }
  return {
    document: f,
    get awareness() {
      return y.awareness;
    },
    get status() {
      return I;
    },
    connect: () => {
      try {
        y.connect(), I = "connecting", c == null || c("connecting");
      } catch (v) {
        a == null || a(new Error(`Failed to connect: ${v}`));
      }
    },
    disconnect: () => {
      try {
        y.disconnect(), I = "disconnected", c == null || c("disconnected");
      } catch (v) {
        a == null || a(new Error(`Failed to disconnect: ${v}`));
      }
    },
    destroy: () => {
      try {
        w && (clearTimeout(w), w = null), E(), y.destroy(), h == null || h.destroy(), p.clear(), g.clear();
      } catch (v) {
        a == null || a(new Error(`Failed to destroy provider: ${v}`));
      }
    },
    on: (v, C) => {
      v === "status" ? p.add(C) : v === "synced" && g.add(C);
    },
    off: (v, C) => {
      v === "status" ? p.delete(C) : v === "synced" && g.delete(C);
    }
  };
}
const Ia = {
  maxRetries: 5,
  delay: 1e3,
  backoff: 1.5,
  maxDelay: 3e4
};
async function bm(e) {
  const {
    serverUrl: t,
    roomId: r,
    user: n,
    auth: o,
    persistence: s = !0,
    reconnect: i = {},
    onError: a,
    onStatusChange: c,
    onAuthError: l,
    onSynced: d
  } = e, u = { ...Ia, ...i };
  let m = null, f = null, h = null;
  try {
    m = await import("yjs"), f = (await import("./y-websocket-wGTAdJXE.mjs")).WebsocketProvider, s && (h = (await import("./y-indexeddb-CNWWqppD.mjs")).IndexeddbPersistence);
  } catch (S) {
    return a == null || a(new Error(`Failed to load collaboration dependencies: ${S}`)), null;
  }
  const k = new m.Doc({ gc: !0 });
  let b = null;
  if (s && h)
    try {
      b = new h(`zx-editor-${r}`, k);
    } catch (S) {
      a == null || a(new Error(`Failed to initialize local persistence: ${S}`));
    }
  const R = (S) => {
    if (!S) return t;
    const D = t.includes("?") ? "&" : "?";
    return `${t}${D}token=${encodeURIComponent(S)}`;
  }, T = (S) => S ? { ...n, _authToken: S } : n, y = (S) => {
    if (!Number.isFinite(S) || S <= 0) return null;
    const D = Date.now(), F = S > D ? S : D + S;
    return Math.max(0, F - D - 6e4);
  };
  let I = o == null ? void 0 : o.token, w = R(I), p, g = 0, x = "connecting", O = null, $ = null;
  const E = /* @__PURE__ */ new Set(), A = /* @__PURE__ */ new Set(), P = () => {
    if ((p == null ? void 0 : p.shouldConnect) === !1) return;
    if (g >= u.maxRetries) {
      a == null || a(
        new Error(
          `Max reconnection attempts (${u.maxRetries}) reached`
        )
      ), x = "disconnected", c == null || c("disconnected");
      return;
    }
    const S = Math.min(
      u.delay * u.backoff ** g,
      u.maxDelay
    );
    $ = setTimeout(() => {
      if ($ = null, (p == null ? void 0 : p.shouldConnect) !== !1 && (g++, p))
        try {
          p.connect();
        } catch (D) {
          a == null || a(
            new Error(`Reconnection attempt ${g} failed: ${D}`)
          ), P();
        }
    }, S);
  }, v = (S) => {
    const D = S.status === "connected" ? "connected" : "disconnected";
    D === "connected" && (g = 0), D !== x && (x = D, c == null || c(D), D === "disconnected" && u.maxRetries > 0 && P()), E.forEach((F) => F(S));
  }, C = (S) => {
    d == null || d(S), A.forEach((D) => D(S));
  }, N = () => {
    $ && (clearTimeout($), $ = null), x !== "disconnected" && (x = "disconnected", c == null || c("disconnected"), E.forEach(
      (S) => S({ status: "disconnected" })
    ));
  }, V = () => {
    p.on("status", v), p.on("synced", C), p.on("closed", N);
  }, _ = () => {
    var S, D, F;
    (S = p.off) == null || S.call(p, "status", v), (D = p.off) == null || D.call(p, "synced", C), (F = p.off) == null || F.call(p, "closed", N);
  }, L = () => {
    try {
      return p = new f(w, r, k, {
        connect: !0
      }), V(), p.awareness.setLocalStateField("user", T(I)), !0;
    } catch (S) {
      return a == null || a(new Error(`Failed to create WebSocket provider: ${S}`)), !1;
    }
  }, M = (S) => {
    if (I = S, w = R(I), $ && (clearTimeout($), $ = null), p) {
      _();
      try {
        p.destroy();
      } catch (D) {
        a == null || a(new Error(`Failed to recreate provider: ${D}`));
      }
    }
    g = 0, x = "connecting", c == null || c("connecting"), L() || (x = "disconnected", c == null || c("disconnected"));
  };
  if (!L())
    return null;
  if (o != null && o.refreshToken && (o != null && o.tokenExpiry)) {
    const S = () => {
      const D = y(o.tokenExpiry);
      D !== null && (O = setTimeout(async () => {
        try {
          const F = await o.refreshToken();
          M(F), S();
        } catch (F) {
          l == null || l({
            code: "token_expired",
            message: "Failed to refresh authentication token",
            originalError: F instanceof Error ? F : new Error(String(F))
          });
        }
      }, D));
    };
    S();
  }
  return {
    document: k,
    get awareness() {
      return p.awareness;
    },
    get status() {
      return x;
    },
    connect: () => {
      try {
        p.connect(), x = "connecting", c == null || c("connecting");
      } catch (S) {
        a == null || a(new Error(`Failed to connect: ${S}`));
      }
    },
    disconnect: () => {
      try {
        $ && (clearTimeout($), $ = null), p.disconnect(), x = "disconnected", c == null || c("disconnected");
      } catch (S) {
        a == null || a(new Error(`Failed to disconnect: ${S}`));
      }
    },
    destroy: () => {
      try {
        O && (clearTimeout(O), O = null), $ && (clearTimeout($), $ = null), _(), p.destroy(), b == null || b.destroy(), E.clear(), A.clear();
      } catch (S) {
        a == null || a(new Error(`Failed to destroy provider: ${S}`));
      }
    },
    on: (S, D) => {
      S === "status" ? E.add(D) : S === "synced" && A.add(D);
    },
    off: (S, D) => {
      S === "status" ? E.delete(D) : S === "synced" && A.delete(D);
    }
  };
}
function Ta() {
  return typeof crypto < "u" && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (e) => {
    const t = Math.trunc(Math.random() * 16);
    return (e === "x" ? t : t & 3 | 8).toString(16);
  });
}
async function ym(e) {
  const {
    provider: t,
    autoInterval: r = 0,
    maxSnapshots: n = 0,
    storage: o,
    onSnapshot: s,
    onBeforeRestore: i,
    onRestoreComplete: a
  } = e;
  let c = null;
  try {
    c = await import("yjs");
  } catch {
    return null;
  }
  let l = null, d = null;
  const u = [];
  if (o)
    try {
      (await o.load()).forEach((I) => {
        u.push({
          id: I.id,
          title: I.title,
          timestamp: new Date(I.timestamp),
          data: Uint8Array.from(atob(I.data), (w) => w.charCodeAt(0)),
          manual: I.manual
        });
      });
    } catch (y) {
      console.error("Failed to load snapshots from storage:", y);
    }
  const m = () => {
    if (n <= 0 || u.length <= n) return;
    const y = [...u].sort((I, w) => I.manual !== w.manual ? I.manual ? 1 : -1 : I.timestamp.getTime() - w.timestamp.getTime());
    for (; u.length > n; ) {
      const I = y.find((p) => !p.manual);
      if (!I) break;
      const w = u.findIndex((p) => p.id === I.id);
      if (w !== -1) {
        const p = u.splice(w, 1)[0];
        o == null || o.delete(p.id).catch((x) => {
          console.error("Failed to delete snapshot from storage:", x);
        });
        const g = y.indexOf(I);
        g !== -1 && y.splice(g, 1);
      }
    }
  }, f = (y, I = !1) => {
    if (!c) return null;
    const w = c.snapshot(t.document), p = c.encodeSnapshot(w), g = {
      id: Ta(),
      title: y,
      timestamp: /* @__PURE__ */ new Date(),
      data: p,
      manual: I
    };
    if (d = w, u.push(g), o) {
      const x = btoa(String.fromCharCode(...p));
      o.save({
        id: g.id,
        title: g.title,
        timestamp: g.timestamp.toISOString(),
        data: x,
        manual: g.manual
      }).catch((O) => {
        console.error("Failed to save snapshot to storage:", O);
      });
    }
    return m(), s == null || s(g), g;
  }, h = (y) => {
    if (!c || (i == null ? void 0 : i(y)) === !1) return !1;
    try {
      const w = c.decodeSnapshot(y.data), g = c.createDocFromSnapshot(
        t.document,
        w
      ).getXmlFragment("prosemirror"), x = t.document.getXmlFragment("prosemirror");
      return t.document.transact(() => {
        for (; x.length > 0; )
          x.delete(0, 1);
        const O = g.toJSON();
        Array.isArray(O) && O.forEach(($, E) => {
          x.insert(E, [$]);
        });
      }), d = w, a == null || a(y), !0;
    } catch (w) {
      return console.error("Failed to restore snapshot:", w), !1;
    }
  }, k = () => {
    if (!c || !d) return !0;
    const y = c.snapshot(t.document);
    return !c.equalSnapshots(d, y);
  }, b = () => [...u], R = (y) => {
    const I = u.findIndex((w) => w.id === y);
    return I === -1 ? !1 : (u.splice(I, 1), o && o.delete(y).catch((w) => {
      console.error("Failed to delete snapshot from storage:", w);
    }), !0);
  }, T = (y, I) => {
    if (!c) return null;
    try {
      const w = c.decodeSnapshot(y.data), p = c.decodeSnapshot(I.data), g = c.createDocFromSnapshot(t.document, w), x = c.createDocFromSnapshot(t.document, p), O = g.getXmlFragment("prosemirror"), $ = x.getXmlFragment("prosemirror"), E = O.toJSON(), A = $.toJSON(), P = [], v = [];
      let C = 0;
      const N = Array.isArray(E) ? E : [], V = Array.isArray(A) ? A : [];
      return V.forEach((_) => {
        const L = JSON.stringify(_);
        N.some(
          (S) => JSON.stringify(S) === L
        ) || (P.push(
          typeof _ == "object" && _ !== null ? _.type || "node" : String(_)
        ), C++);
      }), N.forEach((_) => {
        const L = JSON.stringify(_);
        V.some(
          (S) => JSON.stringify(S) === L
        ) || (v.push(
          typeof _ == "object" && _ !== null ? _.type || "node" : String(_)
        ), C++);
      }), { added: P, removed: v, changedCount: C };
    } catch (w) {
      return console.error("Failed to diff snapshots:", w), null;
    }
  };
  return r > 0 && (l = setInterval(() => {
    k() && f((/* @__PURE__ */ new Date()).toISOString(), !1);
  }, r)), {
    createSnapshot: f,
    restoreSnapshot: h,
    hasChanges: k,
    getSnapshots: b,
    deleteSnapshot: R,
    diffSnapshots: T,
    destroy: () => {
      l && clearInterval(l);
    }
  };
}
async function xa(e) {
  const { doc: t, captureTimeout: r = 500, trackedOrigins: n } = e;
  let o = null;
  try {
    o = await import("yjs");
  } catch {
    return null;
  }
  const s = t.getXmlFragment("prosemirror");
  let i;
  try {
    i = new o.UndoManager(s, {
      captureTimeout: r,
      trackedOrigins: n || /* @__PURE__ */ new Set([null])
    });
  } catch (a) {
    return console.error("Failed to create UndoManager:", a), null;
  }
  return {
    undo: () => {
      i.undo();
    },
    redo: () => {
      i.redo();
    },
    canUndo: () => i.undoStack.length > 0,
    canRedo: () => i.redoStack.length > 0,
    clear: () => {
      i.clear();
    },
    destroy: () => {
      i.destroy();
    }
  };
}
async function km(e, t) {
  return xa({
    doc: e.document,
    ...t
  });
}
const de = ["html", "react", "text"], pr = ["json"], ae = [
  "safe-html",
  "public-html",
  "email-html",
  "search-text",
  "excerpt"
], wa = {
  html: {
    name: "html",
    strictness: "fail-fast"
  },
  react: {
    name: "react",
    strictness: "fail-fast"
  },
  text: {
    name: "text",
    strictness: "semantic-degrade"
  }
}, Ea = (e) => wa[e], Ca = {
  "safe-html": {
    name: "safe-html",
    compatibleTargets: ["html", "react"],
    implementationStatus: "implemented",
    strictness: "fail-fast"
  },
  "public-html": {
    name: "public-html",
    compatibleTargets: ["html", "react"],
    implementationStatus: "implemented",
    strictness: "fail-fast"
  },
  "email-html": {
    name: "email-html",
    compatibleTargets: ["html"],
    implementationStatus: "implemented",
    strictness: "fail-fast"
  },
  "search-text": {
    name: "search-text",
    compatibleTargets: ["text"],
    implementationStatus: "implemented",
    strictness: "semantic-degrade"
  },
  excerpt: {
    name: "excerpt",
    compatibleTargets: ["text"],
    implementationStatus: "implemented",
    strictness: "semantic-degrade"
  }
}, Da = {
  html: "safe-html",
  react: "safe-html",
  text: "search-text"
}, Ra = (e) => Da[e], xe = (e) => Ca[e];
class gr extends Error {
  constructor(t, r) {
    super(t), this.name = "ZxRenderConformanceError", this.report = r;
  }
}
const Cn = (e, t) => Object.prototype.hasOwnProperty.call(e, t), Dn = (e) => e ? Object.freeze({ ...e }) : void 0, bt = (e) => !e || typeof e != "object" ? e : Array.isArray(e) ? (e.forEach((t) => bt(t)), Object.freeze(e)) : (Object.values(e).forEach((t) => bt(t)), Object.freeze(e)), ee = (e) => [...e].sort(), et = (e) => e === "semantic-degrade" ? "semantic-degrade" : "fail", Aa = () => Object.fromEntries(
  de.map((e) => {
    const t = Ea(e);
    return [
      e,
      {
        strictness: t.strictness,
        unsupportedHandling: et(
          t.strictness
        ),
        descriptors: /* @__PURE__ */ new Set(),
        nodes: /* @__PURE__ */ new Set(),
        marks: /* @__PURE__ */ new Set()
      }
    ];
  })
), Ma = () => Object.fromEntries(
  ae.map((e) => {
    const t = xe(e);
    return [
      e,
      {
        strictness: t.strictness,
        unsupportedHandling: et(
          t.strictness
        ),
        supportedDescriptors: /* @__PURE__ */ new Set(),
        supportedNodes: /* @__PURE__ */ new Set(),
        supportedMarks: /* @__PURE__ */ new Set(),
        semanticDegradeDescriptors: /* @__PURE__ */ new Set(),
        semanticDegradeNodes: /* @__PURE__ */ new Set(),
        semanticDegradeMarks: /* @__PURE__ */ new Set()
      }
    ];
  })
), Rn = (e) => {
  var n, o, s, i, a, c, l, d;
  const t = e.nodes ?? [], r = e.marks ?? [];
  return {
    nodes: Array.from(
      /* @__PURE__ */ new Set([
        ...t,
        ...Object.keys(((n = e.render) == null ? void 0 : n.nodes) ?? {}),
        ...Object.keys(((o = e.render) == null ? void 0 : o.textSerializers) ?? {}),
        ...Object.keys(((s = e.render) == null ? void 0 : s.excerptSerializers) ?? {}),
        ...t.length ? [] : [
          ...Object.keys(((i = e.render) == null ? void 0 : i.htmlNodeMapping) ?? {}),
          ...Object.keys(((a = e.render) == null ? void 0 : a.reactNodeMapping) ?? {})
        ]
      ])
    ),
    marks: Array.from(
      /* @__PURE__ */ new Set([
        ...r,
        ...Object.keys(((c = e.render) == null ? void 0 : c.marks) ?? {}),
        ...r.length ? [] : [
          ...Object.keys(((l = e.render) == null ? void 0 : l.htmlMarkMapping) ?? {}),
          ...Object.keys(((d = e.render) == null ? void 0 : d.reactMarkMapping) ?? {})
        ]
      ])
    )
  };
}, Oa = (e) => {
  var r;
  const t = (r = e.render) == null ? void 0 : r.targets;
  return Object.fromEntries(
    de.map((n) => {
      const o = !!(t && Cn(t, n)), s = t == null ? void 0 : t[n];
      return [
        n,
        {
          declared: o,
          state: o && (s != null && s.supported) ? "supported" : "unsupported",
          capability: Dn(s)
        }
      ];
    })
  );
}, $a = (e) => Object.fromEntries(
  ae.map((t) => {
    var s;
    const r = (s = e.render) == null ? void 0 : s.profiles, n = !!(r && Cn(r, t)), o = r == null ? void 0 : r[t];
    return [
      t,
      {
        declared: n,
        state: n && (o != null && o.supported) ? "supported" : "unsupported",
        capability: Dn(o)
      }
    ];
  })
), La = (e, t, r) => {
  var l, d, u, m;
  const n = e.render, o = (f, h) => {
    t[f].state = "invalid", r.push({
      code: "missing-target-declaration",
      descriptor: e.name,
      severity: "error",
      target: f,
      message: h
    });
  }, s = (f, h, k) => {
    t[h].state = "invalid", r.push({
      code: f,
      descriptor: e.name,
      severity: "error",
      target: h,
      message: k
    });
  }, i = !!(n != null && n.htmlNodeMapping && Object.keys(n.htmlNodeMapping).length) || !!(n != null && n.htmlMarkMapping && Object.keys(n.htmlMarkMapping).length);
  !t.html.declared && i ? o(
    "html",
    `Descriptor "${e.name}" provides HTML render contracts but does not declare render.targets.html.`
  ) : ((l = t.html.capability) == null ? void 0 : l.supported) === !1 && i && s(
    "orphan-html-contract",
    "html",
    `Descriptor "${e.name}" declares html as unsupported but still provides HTML render contracts.`
  );
  const a = !!(n != null && n.reactNodeMapping && Object.keys(n.reactNodeMapping).length) || !!(n != null && n.reactMarkMapping && Object.keys(n.reactMarkMapping).length) || !!((d = t.react.capability) != null && d.componentKey);
  !t.react.declared && a ? o(
    "react",
    `Descriptor "${e.name}" provides React render contracts but does not declare render.targets.react.`
  ) : ((u = t.react.capability) == null ? void 0 : u.supported) === !1 && a && s(
    "orphan-react-contract",
    "react",
    `Descriptor "${e.name}" declares react as unsupported but still provides React render contracts.`
  );
  const c = !!(n != null && n.textSerializers && Object.keys(n.textSerializers).length) || !!(n != null && n.excerptSerializers && Object.keys(n.excerptSerializers).length);
  !t.text.declared && c ? o(
    "text",
    `Descriptor "${e.name}" provides text/excerpt contracts but does not declare render.targets.text.`
  ) : ((m = t.text.capability) == null ? void 0 : m.supported) === !1 && c && s(
    "orphan-text-contract",
    "text",
    `Descriptor "${e.name}" declares text as unsupported but still provides text/excerpt contracts.`
  );
}, Na = (e, t, r) => {
  var a, c, l;
  const n = e.render, { nodes: o, marks: s } = Rn(e), i = (d, u, m) => {
    t[u].state = "invalid", r.push({
      code: d,
      descriptor: e.name,
      severity: "error",
      target: u,
      message: m
    });
  };
  if ((a = t.html.capability) != null && a.supported) {
    const d = o.filter(
      (m) => {
        var f, h;
        return !((f = n == null ? void 0 : n.nodes) != null && f[m]) && !((h = n == null ? void 0 : n.htmlNodeMapping) != null && h[m]);
      }
    ), u = s.filter(
      (m) => {
        var f, h;
        return !((f = n == null ? void 0 : n.marks) != null && f[m]) && !((h = n == null ? void 0 : n.htmlMarkMapping) != null && h[m]);
      }
    );
    (!o.length && !s.length || d.length > 0 || u.length > 0) && i(
      "missing-html-contract",
      "html",
      `Descriptor "${e.name}" declares html support but is missing HTML contracts${[
        d.length ? ` nodes: ${d.join(", ")}` : null,
        u.length ? ` marks: ${u.join(", ")}` : null
      ].filter(Boolean).join(";") || "."}`
    );
  }
  if ((c = t.react.capability) != null && c.supported) {
    const d = t.react.capability, u = o.filter((f) => {
      var h;
      return (h = n == null ? void 0 : n.reactNodeMapping) != null && h[f] || d.strategy === "component" && d.componentKey ? !1 : !Vo[f];
    }), m = s.filter(
      (f) => {
        var h;
        return !((h = n == null ? void 0 : n.reactMarkMapping) != null && h[f]) && !jo[f];
      }
    );
    (!o.length && !s.length || u.length > 0 || m.length > 0 || d.strategy === "component" && !d.componentKey) && i(
      "missing-react-contract",
      "react",
      `Descriptor "${e.name}" declares react support but is missing React contracts${[
        d.strategy === "component" && !d.componentKey ? " componentKey" : null,
        u.length ? ` nodes: ${u.join(", ")}` : null,
        m.length ? ` marks: ${m.join(", ")}` : null
      ].filter(Boolean).join(";") || "."}`
    );
  }
  if ((l = t.text.capability) != null && l.supported) {
    const d = o.filter(
      (m) => {
        var f, h, k;
        return !((f = n == null ? void 0 : n.nodes) != null && f[m]) && !((h = n == null ? void 0 : n.textSerializers) != null && h[m]) && !((k = n == null ? void 0 : n.excerptSerializers) != null && k[m]);
      }
    ), u = s.filter((m) => {
      var f;
      return !((f = n == null ? void 0 : n.marks) != null && f[m]);
    });
    (!o.length && !s.length || d.length > 0 || u.length > 0) && i(
      "missing-text-contract",
      "text",
      `Descriptor "${e.name}" declares text support but is missing text/excerpt contracts${[
        d.length ? ` nodes: ${d.join(", ")}` : null,
        u.length ? ` marks: ${u.join(", ")}` : null
      ].filter(Boolean).join(";") || "."}`
    );
  }
}, Ba = (e, t, r, n) => {
  ae.forEach((o) => {
    var c;
    const s = r[o];
    if (!((c = s.capability) != null && c.supported))
      return;
    const i = xe(
      o
    ).compatibleTargets;
    i.some(
      (l) => t[l].state === "supported"
    ) || (s.state = "invalid", n.push({
      code: "profile-without-target",
      descriptor: e.name,
      severity: "error",
      profile: o,
      message: `Descriptor "${e.name}" declares profile "${o}" but does not support any compatible target (${i.join(", ")}).`
    }));
  });
}, za = (e, t, r) => {
  var o;
  const n = dn(
    (o = e.render) == null ? void 0 : o.unsupported
  );
  ae.forEach((s) => {
    var c;
    const i = et(
      xe(s).strictness
    ), a = (c = n.profiles) == null ? void 0 : c[s];
    !a || a === i || (t[s].state = "invalid", r.push({
      code: "unsupported-policy-mismatch",
      descriptor: e.name,
      severity: "error",
      profile: s,
      message: `Descriptor "${e.name}" declares unsupported handling "${a}" for profile "${s}", but platform strictness requires "${i}".`
    }));
  });
}, _a = (e, t, r, n) => {
  const { nodes: o, marks: s } = Rn(e);
  de.forEach((i) => {
    if (t.targets[i].state !== "supported")
      return;
    const a = r[i];
    a.descriptors.add(t.descriptor), o.forEach((c) => a.nodes.add(c)), s.forEach((c) => a.marks.add(c));
  }), ae.forEach((i) => {
    var l;
    const a = t.profiles[i];
    if (a.state !== "supported")
      return;
    const c = n[i];
    c.supportedDescriptors.add(t.descriptor), o.forEach((d) => c.supportedNodes.add(d)), s.forEach((d) => c.supportedMarks.add(d)), ((l = a.capability) == null ? void 0 : l.degrade) === "semantic" && (c.semanticDegradeDescriptors.add(t.descriptor), o.forEach((d) => c.semanticDegradeNodes.add(d)), s.forEach((d) => c.semanticDegradeMarks.add(d)));
  });
}, Pa = (e) => Object.fromEntries(
  de.map((t) => [
    t,
    {
      strictness: e[t].strictness,
      unsupportedHandling: e[t].unsupportedHandling,
      descriptors: ee(e[t].descriptors),
      nodes: ee(e[t].nodes),
      marks: ee(e[t].marks)
    }
  ])
), Fa = (e) => Object.fromEntries(
  ae.map((t) => [
    t,
    {
      strictness: e[t].strictness,
      unsupportedHandling: e[t].unsupportedHandling,
      supportedDescriptors: ee(
        e[t].supportedDescriptors
      ),
      supportedNodes: ee(e[t].supportedNodes),
      supportedMarks: ee(e[t].supportedMarks),
      semanticDegradeDescriptors: ee(
        e[t].semanticDegradeDescriptors
      ),
      semanticDegradeNodes: ee(
        e[t].semanticDegradeNodes
      ),
      semanticDegradeMarks: ee(
        e[t].semanticDegradeMarks
      )
    }
  ])
), Ha = (e) => {
  const t = Oa(e), r = $a(e), n = [];
  return La(e, t, n), Na(e, t, n), Ba(e, t, r, n), za(e, r, n), {
    descriptor: e.name,
    targets: t,
    profiles: r,
    issues: n,
    valid: n.length === 0
  };
}, An = (e = be) => {
  const t = Aa(), r = Ma(), n = e.map((i) => {
    const a = Ha(i);
    return _a(i, a, t, r), a;
  }), o = n.flatMap((i) => i.issues), s = {
    descriptors: n,
    issues: o,
    valid: o.length === 0,
    targetMatrix: Pa(t),
    profileMatrix: Fa(r)
  };
  return bt(s);
}, vm = An, Sm = [
  "unhandled-node",
  "unhandled-mark",
  "semantic-degrade",
  "unsupported-surface",
  "surface-target-mismatch",
  "surface-profile-mismatch",
  "resolver-failure",
  "link-rewritten",
  "asset-rewritten",
  "unsupported-profile",
  "unsupported-react-component",
  "policy-sanitized"
];
class z extends Error {
  constructor(t, r = []) {
    super(t), this.diagnostics = r, this.name = "ZxRenderError";
  }
}
const J = (e = []) => e, tt = (e, t, r, n) => e.some(
  (o) => o.kind === t && o.name === r && o.path === n
), j = (e, t) => (e.push(t), e), re = (e, t) => (tt(
  e,
  t.kind,
  t.name,
  t.path
) || e.push(t), e), Va = (e) => `${e.kind}:${e.name}${e.path ? ` at ${e.path}` : ""}`, Mn = (e, t) => ({
  kind: "unhandled-node",
  name: e,
  path: t
}), On = (e, t) => ({
  kind: "unhandled-mark",
  name: e,
  path: t
}), ja = (e, t) => ({
  kind: "unsupported-profile",
  name: e,
  path: t
}), Ua = (e, t) => ({
  kind: "unsupported-surface",
  name: e,
  path: t
}), qa = (e, t) => ({
  kind: "surface-target-mismatch",
  name: e,
  path: t
}), Ka = (e, t) => ({
  kind: "surface-profile-mismatch",
  name: e,
  path: t
}), _t = (e, t) => ({
  kind: "resolver-failure",
  name: e,
  path: t
}), Wa = (e, t) => ({
  kind: "link-rewritten",
  name: e,
  path: t
}), Ga = (e, t) => ({
  kind: "asset-rewritten",
  name: e,
  path: t
}), Im = (e, t) => ({
  kind: "unsupported-react-component",
  name: e,
  path: t
}), se = (e, t) => ({
  kind: "policy-sanitized",
  name: e,
  path: t
}), yt = (e, t) => ({
  kind: "semantic-degrade",
  name: e,
  path: t
}), Xa = (e) => Object.fromEntries(
  de.map((t) => [
    t,
    {
      strictness: e.targetMatrix[t].strictness,
      unsupportedHandling: e.targetMatrix[t].unsupportedHandling,
      descriptors: new Set(e.targetMatrix[t].descriptors),
      nodes: new Set(e.targetMatrix[t].nodes),
      marks: new Set(e.targetMatrix[t].marks)
    }
  ])
), Ja = (e) => Object.fromEntries(
  ae.map((t) => [
    t,
    {
      strictness: e.profileMatrix[t].strictness,
      unsupportedHandling: e.profileMatrix[t].unsupportedHandling,
      supportedDescriptors: new Set(
        e.profileMatrix[t].supportedDescriptors
      ),
      supportedNodes: new Set(e.profileMatrix[t].supportedNodes),
      supportedMarks: new Set(e.profileMatrix[t].supportedMarks),
      semanticDegradeDescriptors: new Set(
        e.profileMatrix[t].semanticDegradeDescriptors
      ),
      semanticDegradeNodes: new Set(
        e.profileMatrix[t].semanticDegradeNodes
      ),
      semanticDegradeMarks: new Set(
        e.profileMatrix[t].semanticDegradeMarks
      )
    }
  ])
), hr = (e, t) => new Set(
  de.flatMap((r) => Array.from(e[r][t]))
), Ya = (e) => {
  var n, o, s, i, a, c, l, d;
  const t = e.nodes ?? [], r = e.marks ?? [];
  return {
    nodes: Array.from(
      /* @__PURE__ */ new Set([
        ...t,
        ...Object.keys(((n = e.render) == null ? void 0 : n.nodes) ?? {}),
        ...Object.keys(((o = e.render) == null ? void 0 : o.textSerializers) ?? {}),
        ...Object.keys(((s = e.render) == null ? void 0 : s.excerptSerializers) ?? {}),
        ...t.length ? [] : [
          ...Object.keys(((i = e.render) == null ? void 0 : i.htmlNodeMapping) ?? {}),
          ...Object.keys(((a = e.render) == null ? void 0 : a.reactNodeMapping) ?? {})
        ]
      ])
    ),
    marks: Array.from(
      /* @__PURE__ */ new Set([
        ...r,
        ...Object.keys(((c = e.render) == null ? void 0 : c.marks) ?? {}),
        ...r.length ? [] : [
          ...Object.keys(((l = e.render) == null ? void 0 : l.htmlMarkMapping) ?? {}),
          ...Object.keys(((d = e.render) == null ? void 0 : d.reactMarkMapping) ?? {})
        ]
      ])
    )
  };
}, Za = (e) => {
  const t = {}, r = e.targets.html;
  r.state === "supported" && r.capability && (t.html = r.capability);
  const n = e.targets.react;
  n.state === "supported" && n.capability && (t.react = n.capability);
  const o = e.targets.text;
  return o.state === "supported" && o.capability && (t.text = o.capability), t;
}, Qa = (e) => {
  const t = {};
  return ae.forEach((r) => {
    const n = e.profiles[r];
    n.state === "supported" && n.capability && (t[r] = n.capability);
  }), t;
}, ei = (e) => {
  if (Array.isArray(e))
    return {
      descriptors: e,
      validation: "enforce"
    };
  const t = e;
  return {
    descriptors: (t == null ? void 0 : t.descriptors) ?? be,
    validation: (t == null ? void 0 : t.validation) ?? "enforce"
  };
};
function rt(e = be) {
  var f, h, k, b, R, T, y, I, w;
  const t = ei(e), r = An(t.descriptors);
  if (!r.valid && t.validation === "enforce")
    throw new gr(
      "Render registry contains descriptor capability conformance errors.",
      r
    );
  const n = Xa(r), o = Ja(r), s = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map(), m = {
    descriptors: [...t.descriptors],
    report: r,
    htmlNodeMapping: {},
    htmlMarkMapping: {},
    reactNodeMapping: {},
    reactMarkMapping: {},
    textSerializers: {},
    excerptSerializers: {},
    nodeContracts: {},
    markContracts: {},
    supportedNodes: hr(n, "nodes"),
    supportedMarks: hr(n, "marks"),
    targetCapabilityIndex: n,
    profileSupportMatrix: o,
    descriptorTargetCapabilities: s,
    descriptorProfileCapabilities: i,
    descriptorUnsupportedPolicies: a,
    nodeDescriptorOwners: c,
    markDescriptorOwners: l,
    reactComponentKeys: d,
    nodeReactComponentKeys: u
  };
  for (const [p, g] of t.descriptors.entries()) {
    const x = r.descriptors[p], O = Za(x), $ = Qa(x), E = ti(
      (f = g.render) == null ? void 0 : f.unsupported
    ), { nodes: A, marks: P } = Ya(g);
    s.set(g.name, O), i.set(g.name, $), a.set(g.name, E), A.forEach(
      (v) => c.set(v, g.name)
    ), P.forEach(
      (v) => l.set(v, g.name)
    ), (h = g.render) != null && h.htmlNodeMapping && Object.assign(m.htmlNodeMapping, g.render.htmlNodeMapping), (k = g.render) != null && k.htmlMarkMapping && Object.assign(m.htmlMarkMapping, g.render.htmlMarkMapping), (b = g.render) != null && b.reactNodeMapping && Object.assign(
      m.reactNodeMapping,
      g.render.reactNodeMapping
    ), (R = g.render) != null && R.reactMarkMapping && Object.assign(
      m.reactMarkMapping,
      g.render.reactMarkMapping
    ), (T = g.render) != null && T.textSerializers && Object.assign(m.textSerializers, g.render.textSerializers), (y = g.render) != null && y.excerptSerializers && Object.assign(
      m.excerptSerializers,
      g.render.excerptSerializers
    ), (I = g.render) != null && I.nodes && Object.assign(m.nodeContracts, g.render.nodes), (w = g.render) != null && w.marks && Object.assign(m.markContracts, g.render.marks), ri(m, g, O);
  }
  return t.descriptors === be && Rs.forEach((p) => {
    const g = m.targetCapabilityIndex[p].nodes, x = m.targetCapabilityIndex[p].marks, O = new Set(
      ur.entries.filter(
        (A) => A.joinKey.startsWith("node:") && A.targets[p] !== "unsupported"
      ).map((A) => A.joinKey.slice(5))
    ), $ = new Set(
      ur.entries.filter(
        (A) => A.joinKey.startsWith("mark:") && A.targets[p] !== "unsupported"
      ).map((A) => A.joinKey.slice(5))
    ), E = (A, P) => A.size === P.size && Array.from(A).every((v) => P.has(v));
    if (!E(g, O) || !E(x, $))
      throw new gr(
        `Render registry target "${p}" does not match its authority projection.`,
        r
      );
  }), m;
}
const ti = (e) => dn(e), ri = (e, t, r) => {
  var s;
  const n = Object.keys(((s = t.render) == null ? void 0 : s.nodes) ?? {}), o = r.react;
  o != null && o.supported && o.componentKey && n.length && (e.reactComponentKeys.set(o.componentKey, {
    descriptor: t,
    nodeNames: n,
    strategy: o.strategy
  }), n.forEach(
    (i) => e.nodeReactComponentKeys.set(
      i,
      o.componentKey
    )
  ));
}, br = (e) => e.join("."), $n = (e, t, r = ["content"]) => {
  var n;
  t(e, r), (n = e.content) == null || n.forEach((o, s) => {
    $n(o, t, [...r, s]);
  });
}, Pt = (e, t = rt(), r = {}) => {
  const n = J(), o = new Set(r.builtinNodes ?? []), s = new Set(r.builtinMarks ?? []), i = yr(
    t,
    "nodes",
    r.target,
    r.profile
  ), a = yr(
    t,
    "marks",
    r.target,
    r.profile
  );
  return $n(e, (c, l) => {
    var d;
    if (typeof c.type == "string" && !o.has(c.type) && !i.has(c.type)) {
      const u = br(l);
      n.push(Mn(c.type, u)), kr(
        t,
        "nodes",
        c.type,
        r.profile
      ) === "semantic-degrade" && re(
        n,
        yt(c.type, u)
      );
    }
    (d = c.marks) == null || d.forEach((u, m) => {
      if (typeof u.type == "string" && !s.has(u.type) && !a.has(u.type)) {
        const f = br([...l, "marks", m]);
        n.push(On(u.type, f)), kr(
          t,
          "marks",
          u.type,
          r.profile
        ) === "semantic-degrade" && re(
          n,
          yt(u.type, f)
        );
      }
    });
  }), n;
}, Tm = (e, t = rt(), r = {}) => {
  const n = Pt(e, t, r);
  if (n.length) {
    const o = n[0];
    throw new Error(
      `Unhandled ${o.kind.replace("unhandled-", "")}: ${o.name}${o.path ? ` at ${o.path}` : ""}`
    );
  }
  return n;
}, xm = () => rt(be), yr = (e, t, r, n) => {
  let o = new Set(
    t === "nodes" ? e.supportedNodes : e.supportedMarks
  );
  if (r && (o = new Set(e.targetCapabilityIndex[r][t])), n) {
    const s = e.profileSupportMatrix[n][t === "nodes" ? "supportedNodes" : "supportedMarks"];
    o = new Set(Array.from(o).filter((i) => s.has(i)));
  }
  return o;
}, kr = (e, t, r, n) => {
  var i, a;
  if (!n)
    return null;
  const o = e.profileSupportMatrix[n];
  if (!o || o.unsupportedHandling !== et(o.strictness))
    return null;
  const s = t === "nodes" ? e.nodeDescriptorOwners.get(r) : e.markDescriptorOwners.get(r);
  return s ? (a = (i = e.descriptorUnsupportedPolicies.get(s)) == null ? void 0 : i.profiles) == null ? void 0 : a[n] : null;
}, Ft = (e) => Object.freeze([...e]), vr = (e) => !!(e && typeof e == "object" && typeof e.id == "string" && typeof e.register == "function"), Ce = (e) => Array.isArray(e) ? e.filter(vr) : vr(e) ? [e] : [], ni = (e, t) => {
  var n, o;
  if (!e || typeof e != "object")
    return [];
  const r = e;
  return [
    ...Ce(r.toolbarContribution),
    ...Ce(r.toolbarContributions),
    ...Ce(
      (n = r.getToolbarContribution) == null ? void 0 : n.call(r, t)
    ),
    ...Ce(
      (o = r.getToolbarContributions) == null ? void 0 : o.call(r, t)
    )
  ];
}, oi = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    t.has(r.definition.id) || t.set(r.definition.id, Object.freeze({ ...r }));
  }), Ft([...t.values()]);
}, Ln = (e = {}) => {
  const t = e.snapshot ?? Ye(e.editor ?? null);
  return {
    editor: e.editor ?? null,
    snapshot: t,
    capabilities: t.capabilities
  };
}, si = (e) => ({
  id: e.id,
  priority: e.priority,
  register: (t) => typeof e.items == "function" ? e.items(t) : [...e.items]
}), ai = (e = [], t = {}) => {
  const r = {
    editor: t.editor ?? null
  }, n = /* @__PURE__ */ new Map();
  return e.forEach((o) => {
    const s = [o];
    o && typeof o == "object" && "options" in o && s.push(o.options), s.forEach((i) => {
      ni(i, r).forEach((a) => {
        n.set(a.id, a);
      });
    });
  }), Ft(
    [...n.values()].sort((o, s) => {
      const i = (o.priority ?? 0) - (s.priority ?? 0);
      return i !== 0 ? i : o.id.localeCompare(s.id);
    })
  );
}, wm = (e) => {
  var r, n;
  const t = e && typeof e == "object" && "extensionManager" in e && Array.isArray((r = e.extensionManager) == null ? void 0 : r.extensions) ? ((n = e.extensionManager) == null ? void 0 : n.extensions) ?? [] : [];
  return ai(t, {
    editor: e
  });
}, Ht = (e = []) => {
  let t = 0;
  const r = /* @__PURE__ */ new Map(), n = (o) => {
    const s = t;
    return t += 1, r.set(o.id, {
      contribution: o,
      order: s
    }), () => {
      const i = r.get(o.id);
      (i == null ? void 0 : i.contribution) === o && r.delete(o.id);
    };
  };
  return e.forEach((o) => {
    n(o);
  }), {
    register: n,
    list() {
      return Ft(
        [...r.values()].sort((o, s) => {
          const i = (o.contribution.priority ?? 0) - (s.contribution.priority ?? 0);
          return i !== 0 ? i : o.order - s.order;
        }).map((o) => o.contribution)
      );
    },
    resolve(o) {
      const s = [...r.values()].sort((i, a) => {
        const c = (i.contribution.priority ?? 0) - (a.contribution.priority ?? 0);
        return c !== 0 ? c : i.order - a.order;
      }).flatMap(
        ({ contribution: i, order: a }) => i.register(o).map((c, l) => ({
          contributionId: i.id,
          contributionPriority: i.priority ?? 0,
          order: a * 1e3 + l,
          definition: c
        }))
      ).sort((i, a) => {
        const c = (i.definition.priority ?? i.contributionPriority) - (a.definition.priority ?? a.contributionPriority);
        if (c !== 0)
          return c;
        const l = i.contributionPriority - a.contributionPriority;
        return l !== 0 ? l : i.order - a.order;
      });
      return oi(s);
    }
  };
}, ii = [
  "9px",
  "10px",
  "10.5px",
  "11px",
  "12px",
  "14px",
  "16px",
  "18px",
  "20px",
  "22px",
  "24px",
  "26px",
  "28px",
  "36px",
  "42px",
  "48px",
  "72px"
], ci = [
  { label: "宋体", value: "SimSun, serif" },
  { label: "黑体", value: "SimHei, sans-serif" },
  { label: "微软雅黑", value: "Microsoft YaHei, sans-serif" },
  { label: "Arial", value: "Arial, sans-serif" },
  { label: "Times New Roman", value: "Times New Roman, serif" },
  { label: "Courier New", value: "Courier New, monospace" }
], Nn = [
  "#000000",
  "#434343",
  "#666666",
  "#999999",
  "#b7b7b7",
  "#cccccc",
  "#d9d9d9",
  "#efefef",
  "#f3f3f3",
  "#ffffff",
  "#980000",
  "#ff0000",
  "#ff9900",
  "#ffff00",
  "#00ff00",
  "#00ffff",
  "#4a86e8",
  "#0000ff",
  "#9900ff",
  "#ff00ff",
  "#e6b8af",
  "#f4cccc",
  "#fce5cd",
  "#fff2cc",
  "#d9ead3",
  "#d0e0e3",
  "#c9daf8",
  "#cfe2f3",
  "#d9d2e9",
  "#ead1dc",
  "#dd7e6b",
  "#ea9999",
  "#f9cb9c",
  "#ffe599",
  "#b6d7a8",
  "#a2c4c9",
  "#a4c2f4",
  "#9fc5e8",
  "#b4a7d6",
  "#d5a6bd",
  "#cc4125",
  "#e06666",
  "#f6b26b",
  "#ffd966",
  "#93c47d",
  "#76a5af",
  "#6d9eeb",
  "#6fa8dc",
  "#8e7cc3",
  "#c27ba0",
  "#a61c00",
  "#cc0000",
  "#e69138",
  "#f1c232",
  "#6aa84f",
  "#45818e",
  "#3c78d8",
  "#3d85c6",
  "#674ea7",
  "#a64d79",
  "#85200c",
  "#990000",
  "#b45f06",
  "#bf9000",
  "#38761d",
  "#134f5c",
  "#1155cc",
  "#0b5394",
  "#351c75",
  "#741b47",
  "#5b0f00",
  "#660000",
  "#783f04",
  "#7f6000",
  "#274e13",
  "#0c343d",
  "#1c4587",
  "#073763",
  "#20124d",
  "#4c1130"
], li = Nn, di = {
  red: "#ff0000",
  orange: "#ff9900",
  yellow: "#ffff00",
  green: "#00ff00",
  teal: "#00ffff",
  cyan: "#00ffff",
  blue: "#4a86e8",
  purple: "#9900ff",
  pink: "#ff00ff",
  gray: "#666666"
}, ui = {
  yellow: "#fff2cc",
  blue: "#c9daf8",
  green: "#d9ead3",
  red: "#f4cccc",
  orange: "#fce5cd",
  purple: "#d9d2e9",
  pink: "#ead1dc",
  gray: "#efefef",
  teal: "#d0e0e3",
  cyan: "#d0e0e3"
}, mi = (e) => e === "highlight" ? ui : di, fi = (e) => e === "highlight" ? /^var\(--prose-highlight-(\w+)\)$/ : /^var\(--prose-color-(\w+)\)$/, pi = (e) => e === "highlight" ? "namedHighlight" : "textStyle", kt = (e, t) => {
  var o;
  if (typeof e != "string")
    return null;
  const r = e.trim();
  if (!r)
    return null;
  const n = ((o = r.match(fi(t))) == null ? void 0 : o[1]) ?? r;
  return He(n) ? n : mi(t)[n] ?? null;
}, gi = (e) => {
  const t = kt(e, "highlight");
  if (t) {
    mt(t);
    return;
  }
  He(e) && mt(e);
}, Em = (e, t) => {
  var n, o;
  if (t === "highlight") {
    if (e.isActive("namedHighlight")) {
      const s = kt(
        (n = e.getAttributes("namedHighlight")) == null ? void 0 : n.color,
        "highlight"
      );
      s && mt(s);
    }
    return Uo();
  }
  return kt(
    (o = e.getAttributes("textStyle")) == null ? void 0 : o.color,
    "text"
  ) || "currentColor";
}, Sr = (e, t) => {
  var s;
  if (!e)
    return !1;
  const r = t.selection ?? null, n = r != null ? r.from === r.to : !1;
  t.mode === "highlight" && gi(t.value);
  let o = e.chain().focus(void 0, { scrollIntoView: !1 });
  return r && (o = o.setTextSelection(r)), o = o.setMark(pi(t.mode), {
    color: t.value
  }), r && !n && (o = o.setTextSelection(r.to), typeof o.command == "function" && (o = o.command(
    ({ tr: i }) => (i.setStoredMarks([]), !0)
  ))), ((s = o.run) == null ? void 0 : s.call(o)) ?? !1;
}, Ir = (e, t) => {
  var n;
  if (!e)
    return !1;
  let r = e.chain().focus(void 0, { scrollIntoView: !1 });
  return t.selection && (r = r.setTextSelection(t.selection)), t.mode === "text" ? r = r.setMark("textStyle", { color: null }).removeEmptyTextStyle() : r = r.unsetMark("namedHighlight"), ((n = r.run) == null ? void 0 : n.call(r)) ?? !1;
}, Tr = [
  { id: "paragraph", label: "Normal", value: "paragraph" },
  { id: "heading-1", label: "Heading 1", value: "heading-1" },
  { id: "heading-2", label: "Heading 2", value: "heading-2" },
  { id: "heading-3", label: "Heading 3", value: "heading-3" },
  { id: "heading-4", label: "Heading 4", value: "heading-4" },
  { id: "heading-5", label: "Heading 5", value: "heading-5" },
  { id: "heading-6", label: "Heading 6", value: "heading-6" },
  { id: "bullet-list", label: "Bulleted list", value: "bullet-list" },
  { id: "ordered-list", label: "Numbered list", value: "ordered-list" },
  { id: "task-list", label: "Checklist", value: "task-list" },
  { id: "blockquote", label: "Blockquote", value: "blockquote" },
  { id: "code-block", label: "Code block", value: "code-block" }
], U = [
  "workbench-top",
  "bubble"
], De = [
  "workbench-top",
  "bubble",
  "floating"
], q = [
  "workbench-top"
], xr = [
  "workbench-top",
  "floating"
], fe = (e, t, r) => ({
  id: e,
  kind: "separator",
  surface: r,
  priority: t
}), hi = ci.map(
  (e) => ({
    id: e.value,
    label: e.label,
    value: e.value
  })
), bi = ii.map((e) => ({
  id: e,
  label: e,
  value: e
})), yi = Nn.map((e) => ({
  id: `text-${e}`,
  label: e,
  value: e,
  swatch: e
})), ki = {
  paragraph: "block-style.paragraph",
  "heading-1": "block-style.heading",
  "heading-2": "block-style.heading",
  "heading-3": "block-style.heading",
  "heading-4": "block-style.heading",
  "heading-5": "block-style.heading",
  "heading-6": "block-style.heading",
  "bullet-list": "list.bullet",
  "ordered-list": "list.ordered",
  "task-list": "list.task",
  blockquote: "block-style.blockquote",
  "code-block": "block-style.code-block"
}, vi = /* @__PURE__ */ new Set([
  "paragraph",
  "bullet-list",
  "ordered-list",
  "task-list"
]), Si = (e) => {
  if (!At(e.editor))
    return { options: [...Tr] };
  const t = Tr.filter(
    (r) => e.capabilities.has(ki[r.value])
  );
  return {
    options: t,
    visible: t.some((r) => !vi.has(r.value))
  };
}, Ii = (e) => {
  const t = At(e);
  return t ? {
    options: t.textColors.map((r) => ({
      id: `text-${r}`,
      label: r,
      value: r,
      swatch: `var(--prose-color-${r})`
    })),
    allowCustomValue: !1
  } : { options: yi, allowCustomValue: !0 };
}, Ti = (e, t) => t && At(e) ? `var(--prose-color-${t})` : t, xi = li.map((e) => ({
  id: `highlight-${e}`,
  label: e,
  value: e,
  swatch: e
})), wr = (e, t) => {
  var r;
  return typeof ((r = e == null ? void 0 : e.commands) == null ? void 0 : r[t]) == "function";
}, B = (e, t) => {
  var n;
  if (!e)
    return !1;
  const r = t(e.chain().focus());
  return ((n = r == null ? void 0 : r.run) == null ? void 0 : n.call(r)) ?? !1;
}, Er = (e, t, ...r) => {
  var a, c, l;
  if (!e)
    return !1;
  const n = (a = e.chain) == null ? void 0 : a.call(e), o = ((c = n == null ? void 0 : n.focus) == null ? void 0 : c.call(n)) ?? n, s = o == null ? void 0 : o[t];
  if (typeof s != "function")
    return !1;
  const i = s.apply(o, r);
  return ((l = i == null ? void 0 : i.run) == null ? void 0 : l.call(i)) ?? !1;
}, Cr = (e, t, ...r) => {
  var i, a;
  if (!e)
    return !1;
  const n = (i = e.commands) == null ? void 0 : i.focus;
  typeof n == "function" && n.call(e.commands);
  const o = (a = e.commands) == null ? void 0 : a[t];
  if (typeof o != "function")
    return !1;
  const s = o.apply(e.commands, r);
  return typeof s == "boolean" ? s : !0;
}, wi = (e, t) => {
  if (!e || !t)
    return !1;
  switch (t) {
    case "paragraph":
      return B(e, (r) => r.setParagraph());
    case "heading-1":
    case "heading-2":
    case "heading-3":
    case "heading-4":
    case "heading-5":
    case "heading-6":
      return B(
        e,
        (r) => r.toggleHeading({
          level: Number(t.replace("heading-", ""))
        })
      );
    case "bullet-list":
      return B(e, (r) => r.toggleBulletList());
    case "ordered-list":
      return B(e, (r) => r.toggleOrderedList());
    case "task-list":
      return B(e, (r) => r.toggleTaskList());
    case "blockquote":
      return B(e, (r) => r.toggleBlockquote());
    case "code-block":
      return B(
        e,
        (r) => r.toggleCodeBlock(
          un({
            source: "toolbar",
            preferences: Bn(e)
          }).attrs
        )
      );
    default:
      return !1;
  }
}, Bn = (e) => {
  var t, r, n, o;
  return ((o = (n = (r = (t = e == null ? void 0 : e.extensionManager) == null ? void 0 : t.extensions) == null ? void 0 : r.find(
    (s) => s.name === "codeBlock"
  )) == null ? void 0 : n.options) == null ? void 0 : o.codeBlockPreferences) ?? null;
}, Cm = (e = {}) => si({
  id: e.id ?? "text-editor.default-toolbar",
  priority: 0,
  items: (t) => {
    var r, n, o, s, i;
    return [
      {
        id: "history.undo",
        kind: "action",
        surface: q,
        priority: 10,
        label: "Undo",
        icon: "mdi:undo-variant",
        requiredCapabilities: ["history.undo"],
        getState: ({ snapshot: a }) => ({
          disabled: !a.history.canUndo
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.undo());
        }
      },
      {
        id: "history.redo",
        kind: "action",
        surface: q,
        priority: 20,
        label: "Redo",
        icon: "mdi:redo-variant",
        requiredCapabilities: ["history.redo"],
        getState: ({ snapshot: a }) => ({
          disabled: !a.history.canRedo
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.redo());
        }
      },
      // Word-like bands: History | Style/Font | Format/Color | Lists | Align | Blocks | Insert
      fe("separator.after-history", 25, q),
      {
        id: "style.block",
        kind: "select",
        surface: De,
        priority: 30,
        label: "Block style",
        icon: "mdi:format-paragraph",
        ...Si(t),
        getState: ({ snapshot: a }) => ({
          mixed: a.indeterminate.blockStyle,
          value: a.blockStyle
        }),
        onValueChange: (a, { editor: c }) => {
          wi(
            c,
            typeof a == "string" ? a : null
          );
        }
      },
      {
        id: "font.family",
        kind: "select",
        surface: q,
        priority: 40,
        label: "Font family",
        requiredCapabilities: ["font-family"],
        options: hi,
        getState: ({ snapshot: a }) => ({
          mixed: a.indeterminate.fontFamily,
          value: a.fontFamily
        }),
        onValueChange: (a, { editor: c }) => {
          if (!c)
            return;
          const l = a ? "setFontFamily" : "unsetFontFamily";
          Er(
            c,
            l,
            ...a ? [a] : []
          ) || Cr(c, l, ...a ? [a] : []);
        }
      },
      {
        id: "font.size",
        kind: "select",
        surface: q,
        priority: 50,
        label: "Font size",
        requiredCapabilities: ["font-size"],
        options: bi,
        includeResetOption: !1,
        getState: ({ snapshot: a }) => ({
          mixed: a.indeterminate.fontSize,
          value: typeof a.fontSize == "number" ? String(a.fontSize) : a.fontSize
        }),
        onValueChange: (a, { editor: c }) => {
          if (!c)
            return;
          const l = a ? "setFontSize" : "unsetFontSize";
          Er(
            c,
            l,
            ...a ? [a] : []
          ) || Cr(c, l, ...a ? [a] : []);
        }
      },
      fe("separator.after-style", 55, De),
      {
        id: "format.bold",
        kind: "toggle",
        surface: U,
        priority: 100,
        label: "Bold",
        icon: "mdi:format-bold",
        requiredCapabilities: ["format.bold"],
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("bold")) ?? !1
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleBold());
        }
      },
      {
        id: "format.italic",
        kind: "toggle",
        surface: U,
        priority: 110,
        label: "Italic",
        icon: "mdi:format-italic",
        requiredCapabilities: ["format.italic"],
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("italic")) ?? !1
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleItalic());
        }
      },
      {
        id: "format.underline",
        kind: "toggle",
        surface: U,
        priority: 120,
        label: "Underline",
        icon: "mdi:format-underline",
        requiredCapabilities: ["format.underline"],
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("underline")) ?? !1
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleUnderline());
        }
      },
      {
        id: "format.strike",
        kind: "toggle",
        surface: U,
        priority: 130,
        label: "Strikethrough",
        icon: "mdi:format-strikethrough",
        requiredCapabilities: ["format.strike"],
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("strike")) ?? !1
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleStrike());
        }
      },
      {
        id: "text.color",
        kind: "color",
        surface: U,
        priority: 140,
        label: "Font color",
        icon: "mdi:format-color-text",
        requiredCapabilities: ["text-color"],
        ...Ii(t.editor),
        getState: ({ editor: a, snapshot: c }) => ({
          mixed: c.indeterminate.textColor,
          value: c.textColor,
          indicatorColor: Ti(a, c.textColor)
        }),
        onValueChange: (a, { editor: c }) => {
          if (typeof a == "string" && a) {
            Sr(c, {
              mode: "text",
              value: a
            });
            return;
          }
          Ir(c, { mode: "text" });
        }
      },
      {
        id: "highlight.color",
        kind: "color",
        surface: U,
        priority: 150,
        label: "Shading color",
        icon: "mdi:format-color-highlight",
        requiredCapabilities: ["highlight-color"],
        options: xi,
        allowCustomValue: !0,
        getState: ({ snapshot: a }) => ({
          mixed: a.indeterminate.highlightColor,
          value: a.highlightColor,
          indicatorColor: a.highlightColor
        }),
        onValueChange: (a, { editor: c }) => {
          if (typeof a == "string" && a) {
            Sr(c, {
              mode: "highlight",
              value: a
            });
            return;
          }
          Ir(c, { mode: "highlight" });
        }
      },
      fe("separator.after-format", 160, U),
      {
        id: "list.bullet",
        kind: "toggle",
        surface: U,
        priority: 200,
        label: "Bulleted list",
        icon: "mdi:format-list-bulleted",
        requiredCapabilities: ["list.bullet"],
        getState: ({ snapshot: a }) => ({
          active: a.listKind === "bullet-list"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleBulletList());
        }
      },
      {
        id: "list.ordered",
        kind: "toggle",
        surface: U,
        priority: 210,
        label: "Numbered list",
        icon: "mdi:format-list-numbered",
        requiredCapabilities: ["list.ordered"],
        getState: ({ snapshot: a }) => ({
          active: a.listKind === "ordered-list"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleOrderedList());
        }
      },
      {
        id: "list.task",
        kind: "toggle",
        surface: U,
        priority: 220,
        label: "Checklist",
        icon: "mdi:format-list-checks",
        requiredCapabilities: ["list.task"],
        getState: ({ snapshot: a }) => ({
          active: a.listKind === "task-list"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleTaskList());
        }
      },
      fe("separator.after-lists", 225, U),
      {
        id: "align.left",
        kind: "toggle",
        surface: q,
        priority: 230,
        label: "Left align",
        icon: "mdi:format-align-left",
        requiredCapabilities: ["alignment"],
        getState: ({ snapshot: a }) => ({
          active: a.alignment === "left"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.setTextAlign("left"));
        }
      },
      {
        id: "align.center",
        kind: "toggle",
        surface: q,
        priority: 240,
        label: "Center align",
        icon: "mdi:format-align-center",
        requiredCapabilities: ["alignment"],
        getState: ({ snapshot: a }) => ({
          active: a.alignment === "center"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.setTextAlign("center"));
        }
      },
      {
        id: "align.right",
        kind: "toggle",
        surface: q,
        priority: 250,
        label: "Right align",
        icon: "mdi:format-align-right",
        requiredCapabilities: ["alignment"],
        getState: ({ snapshot: a }) => ({
          active: a.alignment === "right"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.setTextAlign("right"));
        }
      },
      {
        id: "align.justify",
        kind: "toggle",
        surface: q,
        priority: 260,
        label: "Justify",
        icon: "mdi:format-align-justify",
        requiredCapabilities: ["alignment"],
        getState: ({ snapshot: a }) => ({
          active: a.alignment === "justify"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.setTextAlign("justify"));
        }
      },
      fe("separator.after-align", 270, U),
      {
        id: "block.blockquote",
        kind: "toggle",
        surface: De,
        priority: 300,
        label: "Blockquote",
        icon: "mdi:format-quote-close",
        requiredCapabilities: ["block-style.blockquote"],
        getState: ({ snapshot: a }) => ({
          active: a.blockStyle === "blockquote"
        }),
        run: ({ editor: a }) => {
          B(a, (c) => c.toggleBlockquote());
        }
      },
      {
        id: "block.code",
        kind: "toggle",
        surface: xr,
        priority: 310,
        label: "Code block",
        icon: "mdi:code-tags",
        requiredCapabilities: ["block-style.code-block"],
        getState: ({ snapshot: a }) => ({
          active: a.blockStyle === "code-block"
        }),
        run: ({ editor: a }) => {
          B(
            a,
            (c) => c.toggleCodeBlock(
              un({
                source: "toolbar",
                preferences: Bn(a)
              }).attrs
            )
          );
        }
      },
      {
        id: "insert.horizontal-rule",
        kind: "action",
        surface: xr,
        priority: 320,
        label: "Horizontal line",
        icon: "mdi:minus",
        requiredCapabilities: ["insert.horizontal-rule"],
        run: ({ editor: a }) => {
          B(a, (c) => c.setHorizontalRule());
        }
      },
      fe("separator.after-blocks", 330, De),
      {
        id: "insert.link",
        kind: "custom",
        surface: U,
        priority: 400,
        label: "Insert link",
        icon: "mdi:link-variant",
        requiredCapabilities: ["insert.link"],
        when: ({ editor: a }) => wr(a, "openLinkEditor"),
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("link")) ?? !1
        }),
        render: (r = e.renderers) == null ? void 0 : r["insert.link"]
      },
      {
        id: "insert.image",
        kind: "custom",
        surface: q,
        priority: 410,
        label: "Insert image",
        icon: "mdi:image-plus",
        requiredCapabilities: ["insert.image"],
        render: (n = e.renderers) == null ? void 0 : n["insert.image"]
      },
      {
        id: "insert.video",
        kind: "custom",
        surface: q,
        priority: 420,
        label: "Insert video",
        icon: "mdi:video-plus",
        requiredCapabilities: ["insert.video"],
        when: ({ editor: a }) => wr(a, "selectAndUploadVideo"),
        render: (o = e.renderers) == null ? void 0 : o["insert.video"]
      },
      {
        id: "insert.iframe",
        kind: "custom",
        surface: q,
        priority: 430,
        label: "Embed",
        icon: "mdi:application-brackets",
        requiredCapabilities: ["insert.iframe"],
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("iframe")) ?? !1
        }),
        render: (s = e.renderers) == null ? void 0 : s["insert.iframe"]
      },
      {
        id: "table.menu",
        kind: "custom",
        surface: q,
        priority: 440,
        label: "Table",
        icon: "mdi:table",
        requiredCapabilities: ["table"],
        getState: ({ editor: a }) => ({
          active: (a == null ? void 0 : a.isActive("table")) ?? !1
        }),
        render: (i = e.renderers) == null ? void 0 : i["table.menu"]
      }
    ];
  }
}), Ei = (e) => Object.freeze({
  ...e,
  sources: Object.freeze({ ...e.sources }),
  indeterminate: Object.freeze({ ...e.indeterminate }),
  history: Object.freeze({ ...e.history }),
  selection: Object.freeze({ ...e.selection }),
  capabilities: Object.freeze(new Set(e.capabilities))
}), Ci = (e) => Array.isArray(e.surface) ? [...e.surface] : [e.surface], Di = (e, t) => Ci(e).includes(t), zn = (e, t) => {
  var s, i, a;
  const r = ((s = e.requiredCapabilities) == null ? void 0 : s.every(
    (c) => t.capabilities.has(c)
  )) ?? !0, n = ((i = e.when) == null ? void 0 : i.call(e, t)) ?? !0, o = ((a = e.getState) == null ? void 0 : a.call(
    e,
    t
  )) ?? {};
  return qo({
    visible: r && n && (e.visible ?? !0) && (o.visible ?? !0),
    disabled: e.disabled ?? !1,
    active: e.active ?? !1,
    mixed: e.mixed ?? !1,
    value: e.value ?? null,
    indicatorColor: e.indicatorColor ?? null,
    ...o
  });
}, Ri = (e) => Object.freeze({
  contributionId: e.contributionId,
  definition: e.definition,
  resolved: Object.freeze({ ...e.resolved })
}), Ai = (e) => Object.freeze({
  contributionId: e.contributionId,
  contributionPriority: e.contributionPriority,
  order: e.order,
  definition: Object.freeze({ ...e.definition })
}), _n = (e, t = Ht(), r = {}) => {
  const n = r.state ?? Ye(r.editor ?? null), o = Ln({
    editor: r.editor ?? null,
    snapshot: n
  }), s = t.resolve(o).filter((i) => Di(i.definition, e)).filter((i) => r.filter ? r.filter(i, {
    editor: o.editor,
    snapshot: o.snapshot,
    surface: e,
    capabilities: o.capabilities
  }) : !0).map(Ai);
  return Object.freeze({
    surface: e,
    items: Object.freeze(s)
  });
}, Pn = (e, t = {}) => {
  const r = t.state ?? Ye(t.editor ?? null), n = Ln({
    editor: t.editor ?? null,
    snapshot: r
  }), o = e.items.map((s) => {
    const i = zn(s.definition, {
      editor: n.editor,
      snapshot: n.snapshot,
      surface: e.surface,
      capabilities: n.capabilities
    });
    return {
      contributionId: s.contributionId,
      definition: s.definition,
      resolved: i
    };
  }).filter((s) => t.includeHidden || s.resolved.visible).map(Ri);
  return Object.freeze({
    surface: e.surface,
    state: Ei(n.snapshot),
    items: Object.freeze(o)
  });
}, Mi = (e, t = Ht(), r = {}) => {
  const n = _n(
    e,
    t,
    r
  );
  return Pn(n, {
    editor: r.editor,
    state: r.state,
    includeHidden: r.includeHidden
  });
}, Dm = (e = {}) => {
  const t = e.registry ?? Ht(e.contributions ?? []);
  return {
    registry: t,
    registerContribution(r) {
      return t.register(r);
    },
    resolveState(r = null) {
      return Ye(r);
    },
    prepareSurface(r, n = {}) {
      return _n(r, t, n);
    },
    resolvePreparedSurface(r, n = {}) {
      return Pn(
        r,
        n
      );
    },
    resolveSurface(r, n = {}) {
      return Mi(r, t, n);
    }
  };
}, Fn = (e, t) => {
  var s, i;
  if (!e || !("run" in e) || typeof e.run != "function")
    return { enabled: !1, reason: "toolbar-command-unavailable" };
  const r = zn(e, t), n = ((s = e.requiredCapabilities) == null ? void 0 : s.every(
    (a) => t.capabilities.has(a)
  )) ?? !0, o = ((i = e.when) == null ? void 0 : i.call(e, t)) ?? !0;
  return {
    enabled: n && o && !r.disabled,
    checked: r.active,
    reason: n ? o ? r.disabled ? "disabled" : void 0 : "context-unavailable" : "capability-unavailable"
  };
}, Oi = (e, t) => {
  if (!(!Fn(e, t).enabled || !e || !("run" in e)))
    return e.run(t);
}, Rm = (e) => ps({
  getState: () => Fn(
    e.getDefinition(),
    e.getContext()
  ),
  subscribe: e.subscribe,
  run: () => Oi(e.getDefinition(), e.getContext())
}), $i = (e, t = {}) => e ? K(e) : K({
  meta: {
    source: "import",
    ...t
  }
}), vt = (e, t = {}) => Lt(e, t).content, Vt = (e, t, r = {}) => {
  const n = $i(t, r), o = gn(n.body.content), s = Mt(
    e,
    hn(n.assets, o, e)
  );
  return K({
    ...n,
    body: {
      content: s.content
    },
    assets: s.assets
  });
}, Li = (e, t, r = {}) => Vt(e, t, r), Ni = (e, t = {}) => {
  const r = Mt(e);
  return K({
    body: {
      content: r.content
    },
    assets: r.assets,
    meta: {
      source: "import",
      ...t
    }
  });
}, nt = (e, t, r = {}, n = {}, o = "hydrate") => o === "fresh-import" ? Ni(
  vt(e, n),
  r
) : Vt(
  vt(e, n),
  t,
  r
);
class Dr extends Error {
  constructor(t, r) {
    super(t), this.fromVersion = r, this.name = "ZxTextEditorDocumentMigrationError";
  }
}
const Ue = (e) => typeof e == "object" && e !== null, Bi = (e) => e.version === 2 && Ue(e.body) && e.body.format === "json" && Ue(e.body.content), Rr = (e) => {
  var t, r;
  return JSON.stringify({
    body: {
      format: (t = e.body) == null ? void 0 : t.format,
      content: ((r = e.body) == null ? void 0 : r.content) ?? null
    },
    assets: e.assets ?? []
  });
}, St = (e) => {
  if (Ot(e)) {
    const r = K(e);
    return {
      fromVersion: e.version,
      toVersion: r.version,
      migrated: Rr(e) !== Rr(r),
      document: r
    };
  }
  if (!Ue(e))
    throw new Dr(
      "Document payload must be an object.",
      null
    );
  const t = typeof e.version == "number" ? e.version : null;
  if (Bi(e)) {
    const r = K({
      body: e.body,
      annotations: Array.isArray(e.annotations) ? e.annotations : void 0,
      assets: Array.isArray(e.assets) ? e.assets : void 0,
      meta: Ue(e.meta) ? e.meta : void 0
    });
    return {
      fromVersion: 2,
      toVersion: r.version,
      migrated: !0,
      document: r
    };
  }
  throw new Dr(
    t === null ? "Unsupported document payload: missing required `version=2` and canonical `body.format=json`." : `Unsupported document version: ${t}. Runtime only accepts document v2 (body.format='json').`,
    t
  );
}, Hn = (e) => typeof e == "object" && e !== null && !Array.isArray(e), zi = (e) => Hn(e) && typeof e.type == "string", _i = (e) => {
  const t = typeof e == "string" ? e : JSON.stringify(e, null, 2);
  return {
    type: "doc",
    content: [
      {
        type: "codeBlock",
        attrs: {
          language: "json"
        },
        ...t ? {
          content: [
            {
              type: "text",
              text: t
            }
          ]
        } : {}
      }
    ]
  };
}, Pi = (e, t) => {
  var r;
  if (!Hn(e))
    return null;
  try {
    const n = St(e).document, o = vt(
      n.body.content,
      t.stableBlockIdentity
    ), s = K({
      body: {
        content: o
      },
      annotations: n.annotations,
      assets: n.assets,
      meta: {
        ...n.meta,
        ...t.meta,
        ...t.importMode === "fresh-import" ? {
          source: ((r = t.meta) == null ? void 0 : r.source) ?? "import"
        } : {}
      }
    });
    return {
      content: s.body.content,
      sourceType: "document",
      document: s
    };
  } catch {
    return null;
  }
}, Fi = (e, t = {}) => {
  const r = Pi(e, t);
  if (r)
    return r;
  const n = nt(
    zi(e) ? e : _i(e),
    t.baseDocument,
    t.meta,
    t.stableBlockIdentity,
    t.importMode
  );
  return {
    content: n.body.content,
    sourceType: "json",
    document: n
  };
}, It = (e = {}) => ({
  tokenParsers: { ...e.tokenParsers ?? {} },
  nodeSerializers: { ...e.nodeSerializers ?? {} },
  blockTokenizers: [...e.blockTokenizers ?? []],
  inlineTextTokenizers: [...e.inlineTextTokenizers ?? []]
}), Hi = (...e) => e.reduce(
  (t, r) => It({
    tokenParsers: {
      ...t.tokenParsers,
      ...r.tokenParsers
    },
    nodeSerializers: {
      ...t.nodeSerializers,
      ...r.nodeSerializers
    },
    blockTokenizers: [
      ...t.blockTokenizers,
      ...r.blockTokenizers
    ],
    inlineTextTokenizers: [
      ...t.inlineTextTokenizers,
      ...r.inlineTextTokenizers
    ]
  }),
  It()
), Vi = () => Hi(
  It(),
  Gs()
), Am = Vi(), ji = (e, t = {}) => {
  const r = mn(e, t.markdown), n = nt(
    r,
    t.baseDocument,
    t.meta,
    t.stableBlockIdentity,
    t.importMode
  );
  return {
    content: n.body.content,
    sourceType: "markdown",
    document: n
  };
}, Ui = Wo(Go), qi = js.extend({
  addAttributes() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      ...Ko()
    };
  }
}).configure({ lowlight: Ui }), Vn = (e = {}) => {
  const t = Xo({
    override: e.typography
  });
  return Jo([
    $s.configure(ss()),
    Vs,
    Yo.configure({}),
    Ns.configure({ ...as }),
    Fs,
    Hs.configure({ ...is }),
    Zo,
    Qo,
    es,
    Bs,
    Ls.configure({ types: [...cs] }),
    zs,
    _s,
    Ps,
    ts.configure({
      contract: t
    }),
    rs,
    Ms,
    qi,
    Os.configure({ openOnClick: !1 }),
    ns.configure({}),
    ...os(e.descriptors)
  ]);
}, Ar = (e) => typeof e == "object" && e !== null, Mr = (e) => typeof e == "number" && Number.isFinite(e) ? e : null, Ki = (e, t) => {
  var n;
  if (!((n = t == null ? void 0 : t.assets) != null && n.length))
    return e;
  const r = (o) => {
    var c, l, d;
    if (!Ar(o) || typeof o.type != "string")
      return o;
    const s = {
      ...o
    }, i = Ar(o.attrs) ? { ...o.attrs } : {}, a = Ze(o, t);
    if (a) {
      if (o.type === "attachment") {
        const u = fn(a);
        Object.entries(u).forEach(([m, f]) => {
          i[m] ?? (i[m] = f);
        });
      }
      o.type === "image" && (i.src ?? (i.src = a.src), i.title ?? (i.title = a.title ?? null), i.alt ?? (i.alt = ((c = a.meta) == null ? void 0 : c.alt) ?? a.title ?? null), i.width ?? (i.width = Mr((l = a.meta) == null ? void 0 : l.width) ?? null), i.height ?? (i.height = Mr((d = a.meta) == null ? void 0 : d.height) ?? null)), (o.type === "video" || o.type === "iframe") && (i.src ?? (i.src = a.src), i.title ?? (i.title = a.title ?? null));
    }
    return Object.keys(i).length > 0 && (s.attrs = i), Array.isArray(o.content) && o.content.length > 0 && (s.content = o.content.map((u) => r(u))), Array.isArray(o.marks) && o.marks.length > 0 && (s.marks = o.marks.map((u) => ({ ...u }))), s;
  };
  return r(e);
}, Tt = (e) => e == null ? "" : Array.isArray(e) ? `[${e.map((t) => Tt(t)).join(",")}]` : typeof e == "object" ? `{${Object.entries(e).filter(([, r]) => r !== void 0).sort(([r], [n]) => r.localeCompare(n)).map(([r, n]) => `${JSON.stringify(r)}:${Tt(n)}`).join(",")}}` : JSON.stringify(e), Re = (e) => encodeURIComponent(Tt(e)), Wi = (e) => {
  var n;
  const r = [((n = e.namespace) == null ? void 0 : n.trim()) || "zx-render"];
  return e.surface && r.push(`surface=${e.surface}`), r.push(`target=${e.target}`, `profile=${e.profile}`), e.docId !== null && e.docId !== void 0 && e.docId !== "" && r.push(`doc=${Re(e.docId)}`), e.docVersion !== null && e.docVersion !== void 0 && e.docVersion !== "" && r.push(`version=${Re(e.docVersion)}`), e.hash && r.push(`hash=${Re(e.hash)}`), e.variant !== void 0 && r.push(`variant=${Re(e.variant)}`), r.join("|");
}, jn = (e, t = {}) => Wi({
  surface: e.surface,
  target: e.target,
  profile: e.profile,
  docId: t.docId,
  docVersion: t.docVersion,
  hash: t.hash,
  namespace: t.namespace,
  variant: t.variant ?? e.variant
}), Gi = /* @__PURE__ */ new Set([
  "a",
  "blockquote",
  "br",
  "code",
  "col",
  "colgroup",
  "div",
  "em",
  "figcaption",
  "figure",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "hr",
  "iframe",
  "img",
  "input",
  "label",
  "li",
  "mark",
  "ol",
  "p",
  "pre",
  "s",
  "span",
  "strong",
  "table",
  "tbody",
  "td",
  "th",
  "thead",
  "tr",
  "u",
  "ul",
  "video"
]), Or = /* @__PURE__ */ new Set(["br", "col", "hr", "img", "input"]), Xi = /* @__PURE__ */ new Set([
  "class",
  "data-block-id",
  "data-type",
  "id",
  "style"
]), Ji = /* @__PURE__ */ new Set([
  "data-align",
  "data-block-id",
  "data-columns",
  "data-line",
  "data-embed-icon",
  "data-embed-name",
  "data-embed-title",
  "data-full-width",
  "data-id",
  "data-interactive",
  "data-label",
  "data-open",
  "data-tag-id",
  "data-tag-label",
  "data-type",
  "data-wrap",
  "data-zx-code-block",
  "data-zx-code-caption",
  "data-zx-code-collapsed",
  "data-zx-code-copy-mode",
  "data-zx-code-copy-text",
  "data-zx-code-diagnostics",
  "data-zx-code-filename",
  "data-zx-code-group-id",
  "data-zx-code-height",
  "data-zx-code-height-mode",
  "data-zx-code-highlight-lines",
  "data-zx-code-language",
  "data-zx-code-language-label",
  "data-zx-code-line-count",
  "data-zx-code-preview-lines",
  "data-zx-code-previewed",
  "data-zx-code-show-line-numbers",
  "data-zx-code-start-line",
  "data-zx-code-tab-label",
  "data-zx-code-theme",
  "data-zx-code-variant",
  "data-zx-code-wrap",
  "data-zx-page-break",
  "data-zx-page-break-id"
]), Yi = {
  a: /* @__PURE__ */ new Set([
    "class",
    "data-embed-icon",
    "data-embed-name",
    "data-embed-title",
    "data-type",
    "href",
    "rel",
    "target",
    "title"
  ]),
  col: /* @__PURE__ */ new Set(["width"]),
  div: /* @__PURE__ */ new Set([
    "class",
    "data-block-id",
    "data-columns",
    "data-open",
    "data-type",
    "data-zx-page-break",
    "data-zx-page-break-id",
    "role",
    "aria-label"
  ]),
  h1: /* @__PURE__ */ new Set(["class", "data-block-id", "id", "style"]),
  h2: /* @__PURE__ */ new Set(["class", "data-block-id", "id", "style"]),
  h3: /* @__PURE__ */ new Set(["class", "data-block-id", "id", "style"]),
  h4: /* @__PURE__ */ new Set(["class", "data-block-id", "id", "style"]),
  h5: /* @__PURE__ */ new Set(["class", "data-block-id", "id", "style"]),
  h6: /* @__PURE__ */ new Set(["class", "data-block-id", "id", "style"]),
  iframe: /* @__PURE__ */ new Set([
    "allowfullscreen",
    "class",
    "data-align",
    "data-full-width",
    "data-interactive",
    "frameborder",
    "height",
    "loading",
    "referrerpolicy",
    "sandbox",
    "src",
    "title",
    "width"
  ]),
  figcaption: /* @__PURE__ */ new Set(["class"]),
  figure: /* @__PURE__ */ new Set([
    "class",
    "data-block-id",
    "data-type",
    "data-zx-code-block",
    "data-zx-code-caption",
    "data-zx-code-collapsed",
    "data-zx-code-copy-mode",
    "data-zx-code-copy-text",
    "data-zx-code-diagnostics",
    "data-zx-code-filename",
    "data-zx-code-group-id",
    "data-zx-code-height",
    "data-zx-code-height-mode",
    "data-zx-code-highlight-lines",
    "data-zx-code-language",
    "data-zx-code-language-label",
    "data-zx-code-line-count",
    "data-zx-code-preview-lines",
    "data-zx-code-previewed",
    "data-zx-code-show-line-numbers",
    "data-zx-code-start-line",
    "data-zx-code-tab-label",
    "data-zx-code-theme",
    "data-zx-code-variant",
    "data-zx-code-wrap"
  ]),
  img: /* @__PURE__ */ new Set([
    "alt",
    "class",
    "data-align",
    "height",
    "loading",
    "src",
    "title",
    "width"
  ]),
  input: /* @__PURE__ */ new Set(["checked", "disabled", "type"]),
  label: /* @__PURE__ */ new Set(["class"]),
  li: /* @__PURE__ */ new Set(["class", "data-checked", "data-type"]),
  mark: /* @__PURE__ */ new Set(["class", "style"]),
  ol: /* @__PURE__ */ new Set(["class"]),
  p: /* @__PURE__ */ new Set(["class", "data-block-id", "style"]),
  pre: /* @__PURE__ */ new Set(["class", "data-wrap"]),
  span: /* @__PURE__ */ new Set([
    "class",
    "data-id",
    "data-label",
    "data-line",
    "data-tag-id",
    "data-tag-label",
    "data-type",
    "style"
  ]),
  table: /* @__PURE__ */ new Set(["class"]),
  td: /* @__PURE__ */ new Set(["class", "colspan", "colwidth", "rowspan"]),
  th: /* @__PURE__ */ new Set(["class", "colspan", "colwidth", "rowspan"]),
  ul: /* @__PURE__ */ new Set(["class", "data-type"]),
  video: /* @__PURE__ */ new Set(["class", "controls", "src"])
}, Zi = /* @__PURE__ */ new Set(["http:", "https:", "mailto:", "tel:"]), $r = /* @__PURE__ */ new Set(["http:", "https:"]), Qi = /* @__PURE__ */ new Set([
  "no-referrer",
  "no-referrer-when-downgrade",
  "origin",
  "origin-when-cross-origin",
  "same-origin",
  "strict-origin",
  "strict-origin-when-cross-origin",
  "unsafe-url"
]), ec = /* @__PURE__ */ new Set(["noopener", "noreferrer", "nofollow", "ugc"]), tc = /* @__PURE__ */ new Set([
  "allow-downloads",
  "allow-forms",
  "allow-modals",
  "allow-popups",
  "allow-popups-to-escape-sandbox",
  "allow-presentation",
  "allow-same-origin",
  "allow-scripts"
]), rc = /<(\/?)([a-zA-Z][\w:-]*)([^>]*)>/g, nc = /([^\s=\/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'=<>`]+)))?/g, oc = (e) => e.replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;"), sc = (e) => e.replace(
  /&#x([0-9a-f]+);/gi,
  (t, r) => String.fromCodePoint(Number.parseInt(r, 16))
).replace(
  /&#(\d+);/g,
  (t, r) => String.fromCodePoint(Number.parseInt(r, 10))
).replaceAll("&quot;", '"').replaceAll("&apos;", "'").replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&amp;", "&"), ac = (e) => e === "data-zx-code-copy-text", Un = (e) => e.startsWith("data-") && Ji.has(e), ic = (e, t) => {
  var r;
  return Xi.has(t) || ((r = Yi[e]) == null ? void 0 : r.has(t)) || Un(t);
}, cc = (e) => e.startsWith("/") || e.startsWith("./") || e.startsWith("../") || e.startsWith("#"), it = (e, t) => {
  if (cc(e))
    return !0;
  try {
    const r = new URL(e);
    return t.has(r.protocol);
  } catch {
    return !1;
  }
}, qn = (e, t, r) => {
  const n = e.split(";").map((o) => o.trim()).filter(Boolean).flatMap((o) => {
    const [s, ...i] = o.split(":"), a = s == null ? void 0 : s.trim().toLowerCase(), c = i.join(":").trim();
    return !a || !c ? (j(
      t,
      se(`${r}.style`)
    ), []) : a === "text-align" && ["left", "center", "right", "justify"].includes(c) ? [`${a}: ${c}`] : a === "color" && (/^var\(--prose-color-[\w-]+\)$/.test(c) || He(c)) ? [`${a}: ${c}`] : a === "background-color" && (/^var\(--prose-highlight-[\w-]+\)$/.test(c) || He(c)) ? [`${a}: ${c}`] : (j(
      t,
      se(`${r}.style.${a}`)
    ), []);
  });
  return n.length ? n.join("; ") : null;
}, Kn = (e) => typeof e == "string" && e.trim() ? e.trim() : null, Wn = (e, t, r, n) => {
  const o = sc(r), s = ac(t) ? o : o.trim();
  switch (t) {
    case "allowfullscreen":
    case "checked":
    case "controls":
    case "disabled":
      return s === "" || s === "true" ? "true" : null;
    case "class":
      return s.replace(/\s+/g, " ").trim() || null;
    case "colspan":
    case "height":
    case "rowspan":
    case "width":
      return /^\d+$/.test(s) ? s : null;
    case "colwidth":
      return /^(\d+\s*,\s*)*\d+$/.test(s) ? s : null;
    case "frameborder":
      return /^\d+$/.test(s) ? s : null;
    case "href":
      return it(s, Zi) ? s : null;
    case "id":
      return /^[A-Za-z0-9:_-]+$/.test(s) ? s : null;
    case "loading":
      return ["eager", "lazy"].includes(s) ? s : null;
    case "referrerpolicy":
      return Qi.has(s) ? s : null;
    case "rel": {
      const i = s.split(/\s+/).filter((a) => ec.has(a));
      return i.length ? i.join(" ") : null;
    }
    case "sandbox": {
      const i = s.split(/\s+/).filter((a) => tc.has(a));
      return i.length ? i.join(" ") : null;
    }
    case "src":
      return e === "img" && /^data:image\/[a-z0-9.+-]+;base64,[a-z0-9+/=\s]+$/i.test(
        s
      ) ? s : e === "iframe" ? it(s, $r) && ls(s, {
        allowedDomains: ds,
        blockedDomains: []
      }) ? s : null : it(s, $r) ? s : null;
    case "style":
      return qn(s, n, e);
    case "target":
      return ["_blank", "_self"].includes(s) ? s : null;
    case "type":
      return s === "checkbox" ? s : null;
    case "title":
    case "alt":
      return s || null;
    default:
      return Un(t), s || null;
  }
}, lc = (e, t, r) => {
  const n = [], o = t.replace(/\/\s*$/, "");
  for (const s of o.matchAll(nc)) {
    const [, i, a, c, l] = s, d = i.toLowerCase(), u = a ?? c ?? l ?? "";
    if (d.startsWith("on")) {
      j(
        r,
        se(`${e}.${d}`)
      );
      continue;
    }
    if (!ic(e, d)) {
      j(
        r,
        se(`${e}.${d}`)
      );
      continue;
    }
    const m = Wn(e, d, u, r);
    if (m === null) {
      j(
        r,
        se(`${e}.${d}`)
      );
      continue;
    }
    n.push(`${d}="${oc(m)}"`);
  }
  return n.length ? ` ${n.join(" ")}` : "";
}, Gn = (e, t, r, n) => {
  const o = Kn(r);
  if (!o)
    return;
  const s = Wn(
    e,
    t,
    o,
    n
  );
  if (s === null) {
    j(
      n,
      se(`${e}.${t}`)
    );
    return;
  }
  return s;
}, Mm = (e, t) => Gn("a", "href", e, t), Om = (e, t, r) => Gn(e, "src", t, r), $m = (e, t, r, n) => {
  const o = Kn(r);
  if (!o)
    return;
  const s = qn(
    `${t}: ${o}`,
    n,
    e
  );
  if (!s)
    return;
  const [, i = ""] = s.split(":");
  return i.trim() || void 0;
}, dc = (e, t = J()) => e.replace(
  /<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi,
  (n, o) => (j(
    t,
    se(o.toLowerCase())
  ), "")
).replace(
  rc,
  (n, o, s, i) => {
    const a = s.toLowerCase(), c = o === "/";
    if (!Gi.has(a))
      return j(t, se(a)), "";
    if (c)
      return Or.has(a) ? "" : `</${a}>`;
    const l = lc(
      a,
      i,
      t
    );
    return Or.has(a) || n.endsWith("/>") ? `<${a}${l}/>` : `<${a}${l}>`;
  }
), _e = {
  sanitize: (e, t) => dc(e, t.diagnostics)
}, uc = {
  "safe-html": {
    role: "safe-html-baseline",
    allowFallback: !1
  },
  "public-html": {
    role: "public-html-delivery",
    allowFallback: !1
  },
  "email-html": {
    role: "email-html-delivery",
    allowFallback: !1
  },
  "search-text": {
    role: "search-text-delivery",
    allowFallback: !1
  },
  excerpt: {
    role: "excerpt-delivery",
    allowFallback: !1
  }
}, mc = {
  "safe-html": _e,
  "public-html": _e,
  "email-html": _e
}, Lm = (e) => e ?? _e, fc = (e) => {
  const t = typeof e == "string" ? xe(e) : e;
  return {
    profile: t.name,
    implementationStatus: t.implementationStatus,
    strictness: t.strictness,
    semantics: uc[t.name],
    htmlPolicy: mc[t.name]
  };
}, pc = (e, t) => {
  const r = new Set(dr(t));
  return dr(e).some(
    (n) => r.has(n)
  );
}, gc = (e) => Object.freeze({ ...e ?? {} }), Xn = (e, t, r, n) => (j(
  r,
  ja(t, e)
), new z(n, r)), hc = (e, t, r, n, o) => {
  const s = e.renderRegistry.targetCapabilityIndex[t], i = e.renderRegistry.profileSupportMatrix[r.name];
  if (!(s.strictness === n.strictness && i.strictness === n.strictness && s.unsupportedHandling === i.unsupportedHandling))
    throw new z(
      `Render platform contract mismatch for target "${t}" and profile "${r.name}".`,
      o
    );
}, bc = (e = []) => {
  const t = [
    ...be
  ];
  return e.forEach((r) => {
    for (let n = t.length - 1; n >= 0; n -= 1) {
      const o = t[n];
      o != null && o.allowExternalOverride && pc(o, r) && t.splice(n, 1);
    }
    t.push(r);
  }), t;
}, yc = (e = []) => {
  const t = bc(e), r = rt({
    descriptors: t,
    validation: "enforce"
  });
  return {
    descriptors: [...t],
    descriptorByName: new Map(
      t.map(
        (n) => [
          n.name,
          n
        ]
      )
    ),
    report: r.report,
    renderRegistry: r,
    targetAdapterSlots: /* @__PURE__ */ new Set([
      ...de,
      ...pr
    ]),
    reservedAdapterSlots: [...pr]
  };
}, kc = (e, t, r = J()) => {
  const n = t ?? Ra(e), o = xe(n);
  if (!o.compatibleTargets.includes(e))
    throw Xn(
      e,
      n,
      r,
      `Render profile "${n}" is not compatible with target "${e}".`
    );
  return o;
}, jt = (e) => {
  const t = yc(e.descriptors), r = e.diagnostics ?? J(), n = gc(e.variant), o = kc(
    e.target,
    e.profile,
    r
  ), s = fc(o);
  if (s.implementationStatus !== "implemented")
    throw Xn(
      e.target,
      o.name,
      r,
      `Render profile "${o.name}" is declared for target "${e.target}" but is not implemented in this phase.`
    );
  return hc(
    t,
    e.target,
    o,
    s,
    r
  ), {
    target: e.target,
    profile: o,
    policy: s,
    descriptors: t.descriptors,
    registry: t,
    diagnostics: r,
    variant: n,
    createCacheKey: (i = {}) => jn(
      {
        target: e.target,
        profile: o.name,
        variant: n
      },
      i
    )
  };
}, we = (e, t) => {
  const r = t[e.target];
  if (!r)
    throw new z(
      `Render target "${e.target}" does not have a registered adapter.`,
      e.diagnostics
    );
  return r(e);
}, vc = (e) => e ?? "", Nm = (e = {}, t) => t ? K(t) : K({
  meta: {
    source: "import",
    ...e
  }
}), Sc = (e) => {
  const t = vc(e);
  return t.trim() ? Cs(
    t,
    Vn()
  ) : { type: "doc", content: [] };
}, Jn = (e, t = {}) => {
  const r = Sc(e), n = nt(
    r,
    t.baseDocument,
    t.meta,
    t.stableBlockIdentity,
    t.importMode
  );
  return {
    content: n.body.content,
    sourceType: "html",
    document: n
  };
}, Ic = (e) => ({
  type: "paragraph",
  ...e ? {
    content: [
      {
        type: "text",
        text: e
      }
    ]
  } : {}
}), Tc = (e) => ({
  type: "doc",
  content: e.split(/\r?\n/).map((t) => Ic(t))
}), Bm = (e, t = {}) => {
  const r = nt(
    Tc(e),
    t.baseDocument,
    t.meta,
    t.stableBlockIdentity,
    t.importMode
  );
  return {
    content: r.body.content,
    sourceType: "text",
    document: r
  };
}, xc = (e) => typeof e == "string" && e.length > 0, wc = (e, t) => {
  const r = e.view.nodeDOM(t);
  return r instanceof HTMLElement ? r : null;
}, Ec = (e) => {
  const t = /* @__PURE__ */ new Set(), r = (n) => {
    var o, s;
    xc((o = n.attrs) == null ? void 0 : o[ys]) && n.type && t.add(n.type), (s = n.content) == null || s.forEach(r);
  };
  return r(e), t;
}, Cc = (e, t) => {
  const { textRanges: r } = e;
  if (!r.length)
    return 0;
  const n = r[0], o = r[r.length - 1];
  if (t <= n.from)
    return 0;
  if (t >= o.to)
    return e.textLength;
  for (let s = 0; s < r.length; s++) {
    const i = r[s];
    if (t >= i.from && t <= i.to)
      return i.offsetStart + Math.min(t - i.from, i.offsetEnd - i.offsetStart);
    const a = r[s + 1];
    if (a && t > i.to && t < a.from)
      return t - i.to <= a.from - t ? i.offsetEnd : a.offsetStart;
  }
  return e.textLength;
}, ue = (e) => {
  const t = As(
    e,
    Ec(e)
  );
  return new Map(
    [...t].map(([r, n]) => [
      r,
      {
        blockId: r,
        nodeType: n.nodeType,
        pos: n.pos,
        nodeSize: n.nodeSize,
        dom: null,
        textLength: n.textLength,
        textRanges: n.textSegments.map((o) => ({
          from: o.from,
          to: o.to,
          offsetStart: o.startOffset,
          offsetEnd: o.endOffset
        }))
      }
    ])
  );
}, Ut = (e) => {
  const t = ue(e.getJSON());
  return t.forEach((r) => {
    r.dom = wc(e, r.pos);
  }), t;
}, Yn = (e, t) => e.get(t) ?? null, le = (e, t) => Yn(Ut(e), t), Se = (e, t) => {
  const r = Array.from(e.values());
  let n = null, o = 0;
  for (const s of r)
    t >= s.pos && t <= s.pos + s.nodeSize && (!n || s.nodeSize <= n.nodeSize) && (n = s, o = Cc(s, t));
  return n ? {
    blockId: n.blockId,
    offset: o
  } : null;
}, zm = (e, t) => Se(
  Ut(e),
  t
), xt = (e, t, r) => {
  const n = Yn(e, t);
  if (!n)
    return null;
  if (!n.textRanges.length)
    return n.pos;
  const o = Math.min(Math.max(r, 0), n.textLength);
  for (const s of n.textRanges)
    if (o >= s.offsetStart && o <= s.offsetEnd)
      return s.from + (o - s.offsetStart);
  return o <= 0 ? n.textRanges[0].from : n.textRanges[n.textRanges.length - 1].to;
}, te = (e, t, r) => xt(
  Ut(e),
  t,
  r
), X = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Dc = (e) => JSON.parse(JSON.stringify(e)), qt = (e) => {
  const t = e.context, r = e.beforeQuote ?? (X(t) && typeof t.before == "string" ? t.before : void 0), n = e.afterQuote ?? (X(t) && typeof t.after == "string" ? t.after : void 0);
  return {
    beforeQuote: r,
    afterQuote: n
  };
}, Rc = (e, t) => {
  var o;
  const r = (o = t == null ? void 0 : t.body) != null && o.content ? gn(t.body.content) : [], n = Mt(
    e,
    hn(t == null ? void 0 : t.assets, r, e)
  );
  return K({
    ...t,
    body: {
      content: n.content
    },
    assets: n.assets
  });
}, Ac = (e) => {
  const t = e.body;
  return (t == null ? void 0 : t.format) === "json" && X(t.content) && typeof t.content.type == "string" ? Dc(t.content) : mn(typeof (t == null ? void 0 : t.content) == "string" ? t.content : "");
}, Mc = (e) => {
  if (Array.isArray(e))
    return e.filter(X).map((t, r) => ({
      id: typeof t.id == "string" && t.id ? t.id : `comment-${r + 1}`,
      authorId: typeof t.authorId == "string" ? t.authorId : void 0,
      content: typeof t.content == "string" ? t.content : "",
      createdAt: typeof t.createdAt == "string" ? t.createdAt : (/* @__PURE__ */ new Date(0)).toISOString(),
      updatedAt: typeof t.updatedAt == "string" ? t.updatedAt : void 0
    }));
}, Oc = (e) => {
  const t = /* @__PURE__ */ new Map(), r = (o) => typeof o.text == "string" ? o.text : o.type === "hardBreak" ? `
` : "", n = (o, s) => {
    var l, d;
    const i = typeof ((l = o.attrs) == null ? void 0 : l.blockId) == "string" ? o.attrs.blockId : null, a = i ? [...s, i] : s, c = r(o);
    c && a.forEach((u) => {
      t.set(u, `${t.get(u) ?? ""}${c}`);
    }), (d = o.content) == null || d.forEach((u) => {
      n(u, a);
    });
  };
  return n(e, []), t;
}, $c = (e, t) => {
  if (typeof e.from != "number" || typeof e.to != "number" || !Number.isFinite(e.from) || !Number.isFinite(e.to) || e.to <= e.from)
    return null;
  const r = ue(t), n = Se(
    r,
    e.from
  ), o = Se(r, e.to);
  return !n || !o ? null : {
    start: n,
    end: o
  };
}, Lr = (e, t, r, n) => {
  if (!e || !t)
    return null;
  const o = [];
  let s = e.indexOf(t);
  for (; s !== -1; ) {
    let i = 0;
    r && e.slice(Math.max(0, s - r.length), s) === r && (i += 2), n && e.slice(
      s + t.length,
      s + t.length + n.length
    ) === n && (i += 2), o.push({
      index: s,
      score: i
    }), s = e.indexOf(t, s + 1);
  }
  return o.length ? o.sort((i, a) => i.score !== a.score ? a.score - i.score : i.index - a.index)[0].index : null;
}, Lc = (e) => {
  const t = ue(e), r = Oc(e), n = Array.from(t.values()).sort(
    (a, c) => a.pos - c.pos
  ), o = [];
  let s = "", i = 0;
  return n.forEach((a, c) => {
    const l = r.get(a.blockId) ?? "";
    o.push({
      blockId: a.blockId,
      start: i,
      end: i + l.length,
      textLength: l.length
    }), s += l, i += l.length, c < n.length - 1 && (s += `
`, i += 1);
  }), {
    blockText: r,
    documentText: s,
    orderedEntries: n,
    segments: o
  };
}, Nr = (e, t, r) => {
  for (let n = 0; n < e.length; n++) {
    const o = e[n];
    if (t >= o.start && t <= o.end)
      return {
        blockId: o.blockId,
        offset: Math.min(
          Math.max(t - o.start, 0),
          o.textLength
        )
      };
    const s = e[n + 1];
    if (s && t === o.end + 1)
      return r === "start" ? {
        blockId: s.blockId,
        offset: 0
      } : {
        blockId: o.blockId,
        offset: o.textLength
      };
  }
  return null;
}, Nc = (e, t) => {
  if (typeof e.quote != "string" || !e.quote)
    return null;
  const { beforeQuote: r, afterQuote: n } = qt(e), { blockText: o, documentText: s, segments: i } = Lc(t);
  if (typeof e.blockId == "string" && pn(e.blockId) && o.has(e.blockId)) {
    const d = o.get(e.blockId) ?? "", u = Lr(
      d,
      e.quote,
      r,
      n
    );
    if (u !== null)
      return {
        start: {
          blockId: e.blockId,
          offset: u
        },
        end: {
          blockId: e.blockId,
          offset: u + e.quote.length
        }
      };
  }
  const a = Lr(
    s,
    e.quote,
    r,
    n
  );
  if (a === null)
    return null;
  const c = Nr(
    i,
    a,
    "start"
  ), l = Nr(
    i,
    a + e.quote.length,
    "end"
  );
  return !c || !l ? null : {
    start: c,
    end: l
  };
}, Bc = (e) => {
  const t = typeof e.quote == "string" && e.quote ? e.quote.length : typeof e.from == "number" && typeof e.to == "number" && e.to > e.from ? e.to - e.from : 0, { beforeQuote: r, afterQuote: n } = qt(e), o = typeof e.blockId == "string" ? e.blockId : "";
  return Be({
    start: {
      blockId: o,
      offset: 0
    },
    end: {
      blockId: o,
      offset: t
    },
    quote: typeof e.quote == "string" ? e.quote : void 0,
    beforeQuote: r,
    afterQuote: n
  });
}, zc = (e, t, r) => {
  var d, u, m;
  const n = X(e.anchor) ? e.anchor : {}, o = qt(n), s = $c(
    n,
    t
  ), i = Nc(
    n,
    t
  ), a = (X(e.anchor) && X(e.anchor.start) && X(e.anchor.end) ? Be(e.anchor) : null) ?? (s ? Be({
    ...s,
    quote: n.quote,
    ...o
  }) : null) ?? (i ? Be({
    ...i,
    quote: n.quote,
    ...o
  }) : null) ?? Bc(n), c = typeof e.id == "string" && e.id ? e.id : typeof ((d = e.payload) == null ? void 0 : d.threadId) == "string" && e.payload.threadId ? e.payload.threadId : `annotation-${r + 1}`, l = Mc((u = e.payload) == null ? void 0 : u.comments);
  return ft({
    id: c,
    anchor: a,
    resolved: e.resolved,
    payload: {
      threadId: typeof ((m = e.payload) == null ? void 0 : m.threadId) == "string" && e.payload.threadId ? e.payload.threadId : c,
      comments: l
    }
  });
}, _c = (e, t) => Array.isArray(e) ? e.filter(X).map(
  (r, n) => zc(r, t, n)
) : [], Pc = (e, t = {}) => {
  var d;
  const r = X(e) ? e : {}, n = typeof r.version == "number" ? r.version : null, o = K({
    assets: ks(r.assets),
    meta: {
      source: ((d = r.meta) == null ? void 0 : d.source) ?? "import",
      ...r.meta ?? {}
    }
  }), s = Ac(r), i = Lt(
    s,
    t
  ), a = _c(
    r.annotations,
    i.content
  ), c = Rc(i.content, {
    ...o,
    annotations: a
  }), l = $t(c);
  return {
    document: c,
    fromVersion: n,
    migrated: !Ot(e) || i.regeneratedBlockIds > 0 || l.issueCount > 0,
    regeneratedBlockIds: i.regeneratedBlockIds,
    repairs: i.repairs,
    unresolvedAnnotations: l.unresolvedAnnotations,
    verification: l
  };
}, _m = (e) => {
  const t = e.map(
    (o, s) => {
      try {
        const i = Pc(o.document);
        return {
          document: i.document,
          id: o.id,
          index: s,
          regeneratedBlockIds: i.regeneratedBlockIds,
          snapshotRef: o.snapshotRef,
          status: "success",
          unresolvedAnnotations: i.unresolvedAnnotations,
          verification: i.verification
        };
      } catch (i) {
        return {
          error: i instanceof Error ? i.message : String(i),
          id: o.id,
          index: s,
          regeneratedBlockIds: 0,
          snapshotRef: o.snapshotRef,
          status: "error",
          unresolvedAnnotations: 0
        };
      }
    }
  ), r = t.filter(
    (o) => o.status === "success"
  ).length, n = t.length - r;
  return {
    results: t,
    summary: {
      totalDocuments: t.length,
      successCount: r,
      failureCount: n,
      successRate: t.length ? r / t.length : 0,
      regeneratedBlockIds: t.reduce(
        (o, s) => o + s.regeneratedBlockIds,
        0
      ),
      unresolvedAnnotations: t.reduce(
        (o, s) => o + s.unresolvedAnnotations,
        0
      ),
      rollbackSnapshotRefs: t.map((o) => o.snapshotRef).filter(
        (o) => typeof o == "string" && o.length > 0
      )
    }
  };
}, Pm = (e) => {
  const t = e.map(
    (o, s) => {
      const i = $t(o.document);
      return {
        id: o.id,
        index: s,
        snapshotRef: o.snapshotRef,
        valid: i.valid,
        verification: i
      };
    }
  ), r = t.filter((o) => o.valid).length, n = t.length - r;
  return {
    results: t,
    summary: {
      totalDocuments: t.length,
      validCount: r,
      invalidCount: n,
      failureCount: n,
      unresolvedAnnotations: t.reduce(
        (o, s) => o + s.verification.unresolvedAnnotations,
        0
      ),
      rollbackSnapshotRefs: t.map((o) => o.snapshotRef).filter(
        (o) => typeof o == "string" && o.length > 0
      )
    }
  };
}, Fc = 220, Hc = (e) => typeof e == "object" && e !== null, Vc = (e) => typeof e == "string" && e.trim() ? e.trim() : void 0, jc = (e) => typeof e == "number" && Number.isFinite(e) ? Math.max(1, Math.round(e)) : typeof e == "string" && /^\d+$/.test(e.trim()) ? Math.max(1, Number.parseInt(e.trim(), 10)) : null, Zn = (e) => e.replace(/\s+/g, " ").trim(), Uc = (e) => (e ?? []).map((t) => Kt(t)).filter(Boolean).join(" "), Kt = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? " " : Uc(e.content), Qn = (e, t = []) => {
  var r;
  if (e.type === "heading") {
    const n = Hc(e.attrs) ? e.attrs : {}, o = Zn(Kt(e)), s = jc(n.level), i = Vc(n.blockId);
    o && s && t.push({
      label: o,
      level: s,
      ...i ? { blockId: i } : {}
    });
  }
  return (r = e.content) == null || r.forEach((n) => Qn(n, t)), t;
}, qc = (e) => ({
  completion: (e == null ? void 0 : e.completion) ?? "strict-complete",
  includeComments: (e == null ? void 0 : e.includeComments) ?? !0,
  includeAssets: (e == null ? void 0 : e.includeAssets) ?? !0,
  includeSubpages: (e == null ? void 0 : e.includeSubpages) ?? !1,
  ...e != null && e.sidecars ? { sidecars: [...e.sidecars] } : {}
}), Kc = (e, t) => {
  if (e.length <= t)
    return e;
  const r = e.slice(0, t).trimEnd();
  return r.length < e.length ? `${r}...` : r;
}, Wc = (e, t) => {
  const r = Ss({
    document: e,
    variant: t
  });
  return `export-snapshot-${Is(r)}`;
}, Br = (e, t) => {
  e && e.push(t);
}, eo = (e, t = {}) => {
  var d;
  const r = qc(t.variant), n = t.diagnostics, o = vs(
    e.body.content,
    {
      types: [...Ve]
    }
  ).map((u) => ({
    code: u.code,
    message: `${u.nodeType} at ${u.path} has ${u.code}.`,
    nodeType: u.nodeType,
    path: u.path,
    blockId: u.blockId
  })), s = $t(e);
  o.forEach((u) => {
    Br(n, {
      code: `export.snapshot.${u.code}`,
      message: u.message,
      severity: "error"
    });
  }), s.issues.filter((u) => u.code === "annotation-unresolved").forEach((u) => {
    Br(n, {
      code: "export.snapshot.annotation-unresolved",
      message: u.message,
      severity: "error"
    });
  });
  const i = Qn(e.body.content), a = e.meta.title ?? ((d = i[0]) == null ? void 0 : d.label), c = Zn(Kt(e.body.content)), l = c ? Kc(c, Fc) : void 0;
  return {
    id: Wc(e, r),
    document: e,
    variant: r,
    projections: {
      ...a ? { title: a } : {},
      ...l ? { excerpt: l } : {},
      ...c ? { searchText: c } : {},
      ...i.length > 0 ? { outline: i } : {}
    },
    verification: {
      stableBlockIdentityIssues: o,
      unresolvedAnnotations: s.unresolvedAnnotations
    }
  };
}, ce = (e) => typeof e == "string" && e.trim().length > 0, to = (e, t, r) => `${e}#${t}:${String(r)}`, Gc = (e) => ({
  ...e,
  includeSubpages: !1
}), Ie = (e, t) => {
  e && e.push(t);
}, Wt = (e) => ({
  ...e,
  resolution: {
    state: "resolved"
  }
}), Xc = (e, t) => ({
  ...e,
  resolution: {
    state: "unresolved",
    missingEndpoint: t.missingEndpoint,
    reasonCode: t.reasonCode
  }
}), zr = (e) => ({
  id: e.id,
  memberId: e.memberId,
  role: e.role,
  origin: e.origin,
  documentVersion: e.document.version,
  schemaVersion: e.document.meta.schemaVersion ?? `document/v${e.document.version}`,
  ...e.revision ? { revision: e.revision } : {},
  ...e.parentId ? { parentId: e.parentId } : {},
  ...e.document.meta.title ? { title: e.document.meta.title } : {},
  ...e.document.meta.updatedAt ? { updatedAt: e.document.meta.updatedAt } : {},
  ...e.document.meta.source ? { source: e.document.meta.source } : {}
}), _r = (e) => ({
  id: e.sourceDocument.memberId,
  kind: e.sourceDocument.role === "root" ? "canonical-document" : "subpage",
  origin: e.sourceDocument.origin,
  required: !0,
  materializationState: "materialized",
  sourceDocumentId: e.sourceDocument.id
}), Jc = (e, t) => {
  if (!e.snapshot.variant.includeComments)
    return {
      members: [],
      relationships: []
    };
  const r = ue(e.snapshot.document.body.content), n = e.sourceDocument.memberId, o = e.sourceDocument.role === "root" ? "canonical-document" : "subpage", s = [], i = [];
  return e.snapshot.document.annotations.forEach((a, c) => {
    const l = ce(a.id) ? a.id : c + 1, d = to(n, "annotation", l), u = r.has(a.anchor.start.blockId), m = r.has(a.anchor.end.blockId), f = u && m ? "materialized" : "unresolved";
    (!u || !m) && Ie(t, {
      code: "export.graph.annotation-unresolved",
      message: `Annotation member "${d}" cannot resolve anchor blocks.`,
      severity: "error",
      memberId: d,
      sourceDocumentId: e.sourceDocument.id
    }), s.push({
      id: d,
      kind: "annotation-thread",
      origin: e.sourceDocument.origin,
      required: !0,
      materializationState: f,
      sourceDocumentId: e.sourceDocument.id
    }), i.push(
      Wt({
        from: {
          id: d,
          kind: "annotation-thread"
        },
        to: {
          id: n,
          kind: o
        },
        kind: "anchors-comment"
      })
    );
  }), {
    members: s,
    relationships: i
  };
}, Yc = (e, t) => {
  if (!e.snapshot.variant.includeAssets)
    return {
      members: [],
      relationships: []
    };
  const r = e.sourceDocument.memberId, n = e.sourceDocument.role === "root" ? "canonical-document" : "subpage", o = [], s = [];
  return e.snapshot.document.assets.forEach((i, a) => {
    const c = ce(i.id) ? i.id : a + 1, l = to(r, "asset", c), d = ce(i.src), u = d ? "pending" : "unresolved";
    d || Ie(t, {
      code: "export.graph.asset-unresolved",
      message: `Asset member "${l}" is missing src.`,
      severity: "error",
      memberId: l,
      sourceDocumentId: e.sourceDocument.id
    }), o.push({
      id: l,
      kind: "asset",
      origin: e.sourceDocument.origin,
      required: !0,
      materializationState: u,
      sourceDocumentId: e.sourceDocument.id,
      ...i.mimeType ? { mediaType: i.mimeType } : {}
    }), s.push(
      Wt({
        from: {
          id: r,
          kind: n
        },
        to: {
          id: l,
          kind: "asset"
        },
        kind: "references-asset"
      })
    );
  }), {
    members: o,
    relationships: s
  };
}, Ae = (e, t, r, n, o) => t.has(n.id) ? (Ie(r, {
  code: "export.graph.member-identity-collision",
  message: `${o} "${n.id}" is duplicated.`,
  severity: "error",
  memberId: n.id,
  sourceDocumentId: n.sourceDocumentId
}), !1) : (t.add(n.id), e.push(n), !0), Zc = async (e, t = {}) => {
  var m;
  const r = t.diagnostics, n = t.graphProvider, o = [], s = [], i = [], a = /* @__PURE__ */ new Set(), c = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Map(), d = {
    snapshot: e,
    sourceDocument: zr({
      id: t.rootDocumentId ?? e.id,
      memberId: `document:${e.id}`,
      role: "root",
      origin: "snapshot",
      document: e.document,
      revision: t.rootDocumentRevision
    })
  };
  i.push(d), l.set(d.sourceDocument.memberId, d), c.add(d.sourceDocument.id), Ae(
    o,
    a,
    r,
    _r(d),
    "Source member id"
  );
  const u = [];
  return n != null && n.resolveRelatedDocuments && e.variant.includeSubpages && (await n.resolveRelatedDocuments(e)).forEach((h, k) => {
    const b = ce(h.id) ? `subpage:${h.id}` : `subpage:${k + 1}`, R = eo(h.document, {
      variant: Gc(e.variant),
      diagnostics: r
    }), T = ce(h.id) ? h.id : R.id;
    if (c.has(T)) {
      Ie(r, {
        code: "export.graph.source-document-identity-collision",
        message: `Source document id "${T}" is duplicated.`,
        severity: "error",
        memberId: b,
        sourceDocumentId: T
      });
      return;
    }
    const y = {
      snapshot: R,
      sourceDocument: zr({
        id: T,
        memberId: b,
        role: h.relation,
        origin: "provider",
        document: h.document
      })
    };
    Ae(
      o,
      a,
      r,
      _r(y),
      "Provider source member id"
    ) && (c.add(T), i.push(y), l.set(b, y), u.push({
      source: y,
      relation: h.relation,
      parentMemberId: ce(h.parentMemberId) ? h.parentMemberId : void 0
    }));
  }), u.forEach((f) => {
    const h = f.parentMemberId, k = h ? l.get(h) : d;
    if (h && !k) {
      Ie(r, {
        code: "export.graph.unresolved-edge",
        message: `Subpage member "${f.source.sourceDocument.memberId}" cannot resolve parent "${h}".`,
        severity: "error",
        memberId: f.source.sourceDocument.memberId,
        sourceDocumentId: f.source.sourceDocument.id
      }), s.push(
        Xc(
          {
            from: {
              id: h,
              kind: "subpage"
            },
            to: {
              id: f.source.sourceDocument.memberId,
              kind: "subpage"
            },
            kind: f.relation === "subpage" ? "contains-subpage" : "links-to-document"
          },
          {
            missingEndpoint: "from",
            reasonCode: "missing-parent-member"
          }
        )
      );
      return;
    }
    k && (f.source.sourceDocument.parentId = k.sourceDocument.id), s.push(
      Wt({
        from: {
          id: (k == null ? void 0 : k.sourceDocument.memberId) ?? d.sourceDocument.memberId,
          kind: (k == null ? void 0 : k.sourceDocument.role) === "root" ? "canonical-document" : "subpage"
        },
        to: {
          id: f.source.sourceDocument.memberId,
          kind: "subpage"
        },
        kind: f.relation === "subpage" ? "contains-subpage" : "links-to-document"
      })
    );
  }), i.forEach((f) => {
    const h = Jc(f, r), k = Yc(f, r);
    [...h.members, ...k.members].forEach((b) => {
      Ae(o, a, r, b, "Graph member id");
    }), s.push(
      ...h.relationships,
      ...k.relationships
    );
  }), n != null && n.resolveSidecars && ((m = e.variant.sidecars) != null && m.length) && (await n.resolveSidecars(e)).forEach((h, k) => {
    const b = ce(h.id) ? `sidecar:${h.id}` : `sidecar:${k + 1}`;
    Ae(
      o,
      a,
      r,
      {
        id: b,
        kind: "sidecar",
        origin: "provider",
        required: !1,
        materializationState: "materialized"
      },
      "Provider sidecar member id"
    );
  }), {
    members: o,
    relationships: s,
    sources: i
  };
}, ne = (e) => typeof e == "string" && e.trim().length > 0, pe = (e, t) => {
  e && e.push(t);
}, Pr = (e) => e.startsWith("#") ? "anchor-link" : e.startsWith("asset:") ? "asset-link" : "canonical-link", Qc = (e) => {
  const t = [], r = [], n = (o, s) => {
    var f, h, k, b, R, T;
    const i = ne((f = o.attrs) == null ? void 0 : f.blockId) ? o.attrs.blockId : s, a = ne(o.type) ? o.type : void 0, c = ne((h = o.attrs) == null ? void 0 : h.href) ? String(o.attrs.href) : void 0;
    c && t.push({
      href: c,
      blockId: i,
      nodeType: a,
      intent: Pr(c)
    });
    const l = Ze(o, e), d = l == null ? void 0 : l.src, u = ne((k = o.attrs) == null ? void 0 : k.src) ? String(o.attrs.src) : void 0, m = d ?? u;
    m && a && ["attachment", "embed", "iframe", "image", "video"].includes(a) && r.push({
      src: m,
      assetId: (l == null ? void 0 : l.id) ?? (ne((b = o.attrs) == null ? void 0 : b.assetId) ? String(o.attrs.assetId) : void 0),
      blockId: i,
      nodeType: a,
      intent: a === "embed" ? "embed-link" : "asset-link"
    }), (R = o.marks) == null || R.forEach((y) => {
      var w;
      const I = ne((w = y.attrs) == null ? void 0 : w.href) ? String(y.attrs.href) : void 0;
      I && t.push({
        href: I,
        blockId: i,
        nodeType: a,
        markType: y.type,
        intent: Pr(I)
      });
    }), (T = o.content) == null || T.forEach((y) => n(y, i));
  };
  return n(e.body.content), {
    links: t,
    assets: r
  };
}, el = () => ({
  links: [],
  assets: []
}), tl = (e, t) => ({
  snapshot: e,
  sourceDocument: {
    id: e.id,
    memberId: t,
    role: "root",
    origin: "snapshot",
    documentVersion: e.document.version,
    schemaVersion: e.document.meta.schemaVersion ?? `document/v${e.document.version}`,
    ...e.document.meta.title ? { title: e.document.meta.title } : {},
    ...e.document.meta.updatedAt ? { updatedAt: e.document.meta.updatedAt } : {},
    ...e.document.meta.source ? { source: e.document.meta.source } : {}
  }
}), rl = async (e) => {
  var a, c, l, d, u;
  const t = el(), r = [], n = e.diagnostics, o = e.members.find(
    (m) => m.kind === "canonical-document"
  );
  if (!o)
    return pe(n, {
      code: "export.resolution.missing-canonical-member",
      message: "Cannot run export resolution because canonical-document member is missing.",
      severity: "error"
    }), {
      rewrites: r,
      traces: t
    };
  const s = (a = e.sources) != null && a.length ? [...e.sources] : [tl(e.snapshot, o.id)], i = new Set(e.members.map((m) => m.id));
  for (const m of s) {
    const f = m.sourceDocument.memberId;
    if (!i.has(f)) {
      pe(n, {
        code: "export.resolution.source-member-missing",
        message: `Cannot run export resolution because source member "${f}" is missing.`,
        severity: "error",
        memberId: f,
        sourceDocumentId: m.sourceDocument.id
      });
      continue;
    }
    const { links: h, assets: k } = Qc(
      m.snapshot.document
    );
    for (const b of h) {
      const R = {
        snapshotId: m.snapshot.id,
        memberId: f,
        sourceDocumentId: m.sourceDocument.id,
        href: b.href,
        blockId: b.blockId,
        nodeType: b.nodeType,
        markType: b.markType,
        intent: b.intent
      }, T = await ((c = e.resolvers) != null && c.links ? Promise.resolve(e.resolvers.links.resolve(R)).then(
        (I) => ({ ok: !0, value: I }),
        (I) => ({ ok: !1, error: I })
      ) : Promise.resolve({
        ok: !0,
        value: { target: b.href }
      }));
      if (!T.ok) {
        pe(n, {
          code: "export.resolution.link-failure",
          message: T.error instanceof Error ? T.error.message : `Link resolver failed for "${b.href}".`,
          severity: "error",
          memberId: f,
          sourceDocumentId: m.sourceDocument.id
        });
        continue;
      }
      const y = (l = T.value) == null ? void 0 : l.target;
      if (!ne(y)) {
        pe(n, {
          code: "export.resolution.link-unresolved",
          message: `Link rewrite cannot resolve "${b.href}".`,
          severity: "error",
          memberId: f,
          sourceDocumentId: m.sourceDocument.id
        });
        continue;
      }
      r.push({
        memberId: f,
        sourceDocumentId: m.sourceDocument.id,
        source: b.href,
        target: y,
        intent: b.intent
      }), t.links.push({
        memberId: f,
        sourceDocumentId: m.sourceDocument.id,
        href: b.href,
        resolvedHref: y,
        blockId: b.blockId,
        nodeType: b.nodeType,
        markType: b.markType,
        intent: b.intent
      });
    }
    for (const b of k) {
      const R = {
        snapshotId: m.snapshot.id,
        memberId: f,
        sourceDocumentId: m.sourceDocument.id,
        src: b.src,
        assetId: b.assetId,
        blockId: b.blockId,
        nodeType: b.nodeType,
        intent: b.intent
      }, T = await ((d = e.resolvers) != null && d.assets ? Promise.resolve(e.resolvers.assets.resolve(R)).then(
        (I) => ({ ok: !0, value: I }),
        (I) => ({ ok: !1, error: I })
      ) : Promise.resolve({
        ok: !0,
        value: { target: b.src }
      }));
      if (!T.ok) {
        pe(n, {
          code: "export.resolution.asset-failure",
          message: T.error instanceof Error ? T.error.message : `Asset resolver failed for "${b.src}".`,
          severity: "error",
          memberId: f,
          sourceDocumentId: m.sourceDocument.id
        });
        continue;
      }
      const y = (u = T.value) == null ? void 0 : u.target;
      if (!ne(y)) {
        pe(n, {
          code: "export.resolution.asset-unresolved",
          message: `Asset rewrite cannot resolve "${b.src}".`,
          severity: "error",
          memberId: f,
          sourceDocumentId: m.sourceDocument.id
        });
        continue;
      }
      r.push({
        memberId: f,
        sourceDocumentId: m.sourceDocument.id,
        source: b.src,
        target: y,
        intent: b.intent
      }), t.assets.push({
        memberId: f,
        sourceDocumentId: m.sourceDocument.id,
        src: b.src,
        resolvedSrc: y,
        assetId: b.assetId,
        blockId: b.blockId,
        nodeType: b.nodeType,
        intent: b.intent
      });
    }
  }
  return {
    rewrites: r,
    traces: t
  };
}, Me = (e, t) => {
  e && e.push(t);
}, nl = (e, t) => {
  if (t.kind !== "asset")
    return null;
  const r = /#asset:(.+)$/.exec(t.id), n = (r == null ? void 0 : r[1]) ?? (t.id.startsWith("asset:") ? t.id.slice(6) : t.id);
  return e.snapshot.document.assets.find((o) => o.id === n) ?? e.snapshot.document.assets.find(
    (o, s) => `${e.sourceDocument.memberId}#asset:${s + 1}` === t.id || `asset:${s + 1}` === t.id
  ) ?? null;
}, ol = (e, t) => {
  var r;
  return {
    ...e,
    materializationState: t.state,
    ...t.mediaType ? { mediaType: t.mediaType } : {},
    ...typeof t.size == "number" ? { size: t.size } : {},
    ...t.digest ? { digest: t.digest } : {},
    ...((r = t.locator) == null ? void 0 : r.kind) === "bundle-path" ? { path: t.locator.value } : {}
  };
}, sl = (e) => e.variant.completion ?? "strict-complete", al = (e) => ({
  snapshot: e,
  sourceDocument: {
    id: e.id,
    memberId: `document:${e.id}`,
    role: "root",
    origin: "snapshot",
    documentVersion: e.document.version,
    schemaVersion: e.document.meta.schemaVersion ?? `document/v${e.document.version}`,
    ...e.document.meta.title ? { title: e.document.meta.title } : {},
    ...e.document.meta.updatedAt ? { updatedAt: e.document.meta.updatedAt } : {},
    ...e.document.meta.source ? { source: e.document.meta.source } : {}
  }
}), il = (e, t) => {
  const r = t.some(
    (o) => o.required && o.materializationState !== "materialized"
  );
  if (e === "strict-complete")
    return {
      mode: e,
      state: r ? "staged" : "complete",
      directlyDeliverable: !r,
      mandatoryIncomplete: r
    };
  const n = t.some(
    (o) => o.materializationState !== "materialized"
  );
  return {
    mode: e,
    state: n ? "staged" : "complete",
    directlyDeliverable: !n,
    mandatoryIncomplete: r
  };
}, cl = async (e) => {
  var a, c;
  const t = sl(e.snapshot), r = e.diagnostics, n = (a = e.sources) != null && a.length ? [...e.sources] : [al(e.snapshot)], o = new Map(
    n.map((l) => [l.sourceDocument.id, l])
  ), s = [];
  for (const l of e.members) {
    if (l.kind !== "asset") {
      s.push(l);
      continue;
    }
    const d = (l.sourceDocumentId ? o.get(l.sourceDocumentId) : void 0) ?? n[0];
    if (!d) {
      const k = {
        ...l,
        materializationState: "unresolved"
      };
      s.push(k), Me(r, {
        code: "export.materialization.source-document-missing",
        message: `Member "${l.id}" cannot resolve source document "${l.sourceDocumentId ?? "unknown"}".`,
        severity: "error",
        memberId: l.id,
        sourceDocumentId: l.sourceDocumentId
      });
      continue;
    }
    const u = nl(d, l);
    if (!u) {
      const k = {
        ...l,
        materializationState: "unresolved"
      };
      s.push(k), Me(r, {
        code: "export.materialization.asset-missing",
        message: `Asset member "${l.id}" cannot find source asset.`,
        severity: "error",
        memberId: l.id,
        sourceDocumentId: d.sourceDocument.id
      });
      continue;
    }
    const m = (c = e.materializers) == null ? void 0 : c.assets;
    if (!m) {
      s.push(l);
      continue;
    }
    const f = await m.materialize(u, {
      snapshot: d.snapshot,
      member: l,
      sourceDocument: d.sourceDocument
    }), h = ol(l, f);
    s.push(h), f.state !== "materialized" && Me(r, {
      code: `export.materialization.asset-${f.state}`,
      message: f.reason ?? `Asset member "${l.id}" materialization state is "${f.state}".`,
      severity: f.state === "pending" ? "warning" : "error",
      memberId: l.id,
      sourceDocumentId: d.sourceDocument.id
    });
  }
  const i = il(t, s);
  if (i.mode === "strict-complete" && i.mandatoryIncomplete)
    throw Me(r, {
      code: "export.materialization.strict-incomplete",
      message: "strict-complete mode requires all mandatory members to be materialized.",
      severity: "error"
    }), new Error(
      "strict-complete mode requires all mandatory members to be materialized."
    );
  return {
    members: s,
    completion: {
      mode: i.mode,
      state: i.state,
      directlyDeliverable: i.directlyDeliverable
    }
  };
}, ll = (e) => ({
  id: e.id,
  memberId: `document:${e.id}`,
  role: "root",
  origin: "snapshot",
  documentVersion: e.document.version,
  schemaVersion: e.document.meta.schemaVersion ?? `document/v${e.document.version}`,
  ...e.document.meta.title ? { title: e.document.meta.title } : {},
  ...e.document.meta.updatedAt ? { updatedAt: e.document.meta.updatedAt } : {},
  ...e.document.meta.source ? { source: e.document.meta.source } : {}
}), Gt = (e) => (e.forEach((t, r) => {
  t.id || (t.id = `export-diagnostic-${r + 1}`);
}), e), dl = (e) => Gt(e).map((t) => t.id).filter((t) => typeof t == "string"), ul = (e, t) => {
  const r = /* @__PURE__ */ new Map();
  return Gt(t).forEach((n) => {
    !n.memberId || !n.id || r.set(n.memberId, [
      ...r.get(n.memberId) ?? [],
      n.id
    ]);
  }), e.map((n) => {
    const o = r.get(n.id);
    return o != null && o.length ? {
      ...n,
      diagnosticRefs: o
    } : n;
  });
}, ml = (e) => {
  var d;
  const t = e.schemaVersion ?? "2.0.0", r = e.graphVersion ?? "export-member-graph/v2", n = e.rewritePolicyVersion ?? "structured-identity-export/v2", o = e.snapshot.variant.completion ?? "strict-complete", s = e.diagnostics ?? [], i = (d = e.sourceDocuments) != null && d.length ? e.sourceDocuments : [ll(e.snapshot)], a = dl(s), c = ul(e.members, s), l = Ts({
    bundleId: e.bundleId,
    snapshotId: e.snapshot.id,
    schemaVersion: t,
    graphVersion: r,
    rewritePolicyVersion: n,
    completionMode: o,
    sourceDocuments: i,
    members: c,
    relationships: e.relationships,
    rewrites: e.rewrites,
    diagnosticRefs: a
  });
  return {
    bundleId: e.bundleId,
    snapshotId: e.snapshot.id,
    schemaVersion: t,
    graphVersion: r,
    rewritePolicyVersion: n,
    completionMode: o,
    sourceDocuments: i,
    members: c,
    relationships: e.relationships,
    rewrites: e.rewrites,
    diagnosticRefs: a,
    integrity: {
      algorithm: "sha256",
      manifestDigest: l
    }
  };
}, fl = (e) => {
  const t = Gt(e.diagnostics), r = xs(e.manifest.members);
  return {
    bundle: {
      snapshot: e.snapshot,
      manifest: e.manifest
    },
    sourceDocuments: e.manifest.sourceDocuments,
    cacheKey: ws({
      docId: e.cache.docId,
      docVersion: e.cache.docVersion,
      snapshotId: e.snapshot.id,
      variant: e.snapshot.variant,
      namespace: e.cache.namespace,
      memberGraphVersion: e.cache.memberGraphVersion ?? e.manifest.graphVersion,
      rewritePolicy: e.cache.rewritePolicy ?? e.manifest.rewritePolicyVersion
    }),
    diagnostics: t,
    diagnosticRefs: e.manifest.diagnosticRefs,
    versions: {
      manifestSchemaVersion: e.manifest.schemaVersion,
      graphVersion: e.manifest.graphVersion,
      rewritePolicyVersion: e.manifest.rewritePolicyVersion
    },
    integrity: {
      algorithm: e.manifest.integrity.algorithm,
      manifestDigest: e.manifest.integrity.manifestDigest
    },
    statistics: r,
    completion: e.materialization.completion
  };
}, Fr = (e, t, r) => {
  var n;
  return ((n = r == null ? void 0 : r.cache) == null ? void 0 : n.docId) ?? `document:${t}`;
}, Hr = (e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.cache) == null ? void 0 : r.docVersion) ?? e.meta.schemaVersion ?? `v${e.version}`;
}, Fm = async (e, t = {}) => {
  var l, d, u, m, f;
  const r = t.diagnostics ?? [], n = eo(e, {
    variant: t.variant,
    diagnostics: r
  }), o = await Zc(n, {
    graphProvider: t.graphProvider,
    diagnostics: r,
    rootDocumentId: Fr(e, n.id, t),
    rootDocumentRevision: Hr(e, t)
  }), s = await rl({
    snapshot: n,
    members: o.members,
    sources: o.sources,
    diagnostics: r,
    resolvers: t.resolvers
  }), i = await cl({
    snapshot: n,
    members: o.members,
    sources: o.sources,
    materializers: t.materializers,
    diagnostics: r
  }), a = `bundle:${n.id}`, c = ml({
    bundleId: a,
    snapshot: n,
    sourceDocuments: o.sources.map((h) => h.sourceDocument),
    members: i.members,
    relationships: o.relationships,
    rewrites: s.rewrites,
    diagnostics: r,
    schemaVersion: t.schemaVersion,
    graphVersion: (l = t.cache) == null ? void 0 : l.memberGraphVersion,
    rewritePolicyVersion: (d = t.cache) == null ? void 0 : d.rewritePolicy
  });
  return fl({
    snapshot: n,
    manifest: c,
    materialization: i,
    diagnostics: r,
    cache: {
      docId: Fr(e, n.id, t),
      docVersion: Hr(e, t),
      namespace: (u = t.cache) == null ? void 0 : u.namespace,
      memberGraphVersion: (m = t.cache) == null ? void 0 : m.memberGraphVersion,
      rewritePolicy: (f = t.cache) == null ? void 0 : f.rewritePolicy
    }
  });
}, qe = (e) => typeof e == "string" && e.trim().length > 0, Vr = (e) => typeof e == "number" && Number.isFinite(e), Oe = (e, t, r) => (re(
  t,
  _t(e.intent, e.path)
), new z(
  `Link resolver failed for surface "${e.surface}" (${e.intent}): ${r}`,
  t
)), $e = (e, t, r) => (re(
  t,
  _t(e.intent, e.path)
), new z(
  `Asset resolver failed for surface "${e.surface}" (${e.intent}): ${r}`,
  t
)), pl = () => ({
  links: [],
  assets: []
}), gl = (e, t) => {
  var n, o;
  if (!qe(e.href))
    throw Oe(
      e,
      t.diagnostics,
      "link href is missing or empty"
    );
  let r;
  try {
    if ((n = t.resolvers) != null && n.links) {
      const s = t.resolvers.links(e);
      if (!s)
        throw Oe(
          e,
          t.diagnostics,
          "resolver returned an empty link result"
        );
      r = s;
    } else
      r = {
        href: e.href
      };
  } catch (s) {
    if (s instanceof z)
      throw s;
    const i = s instanceof Error ? s.message : "unknown link resolver failure";
    throw Oe(e, t.diagnostics, i);
  }
  if (!qe(r.href))
    throw Oe(
      e,
      t.diagnostics,
      "resolver returned an empty link result"
    );
  return (r.href !== e.href || r.rel !== void 0 || r.target !== void 0) && re(
    t.diagnostics,
    Wa(e.intent, e.path)
  ), (o = t.traces) == null || o.links.push({
    surface: e.surface,
    intent: e.intent,
    href: e.href,
    resolvedHref: r.href,
    rel: r.rel,
    target: r.target,
    blockId: e.blockId,
    nodeType: e.nodeType,
    markType: e.markType,
    path: e.path
  }), r;
}, hl = (e, t) => {
  var n, o;
  if (!qe(e.asset.src))
    throw $e(
      e,
      t.diagnostics,
      "asset src is missing or empty"
    );
  let r;
  try {
    if ((n = t.resolvers) != null && n.assets) {
      const s = t.resolvers.assets(e);
      if (!s)
        throw $e(
          e,
          t.diagnostics,
          "resolver returned an empty asset result"
        );
      r = s;
    } else
      r = {
        src: e.asset.src,
        mimeType: e.asset.mimeType
      };
  } catch (s) {
    if (s instanceof z)
      throw s;
    const i = s instanceof Error ? s.message : "unknown asset resolver failure";
    throw $e(e, t.diagnostics, i);
  }
  if (!qe(r.src))
    throw $e(
      e,
      t.diagnostics,
      "resolver returned an empty asset result"
    );
  return (r.src !== e.asset.src || r.mimeType !== e.asset.mimeType || r.width !== void 0 || r.height !== void 0) && re(
    t.diagnostics,
    Ga(e.intent, e.path)
  ), (o = t.traces) == null || o.assets.push({
    surface: e.surface,
    intent: e.intent,
    src: e.asset.src,
    resolvedSrc: r.src,
    mimeType: r.mimeType,
    width: Vr(r.width) ? r.width : void 0,
    height: Vr(r.height) ? r.height : void 0,
    assetId: e.assetId ?? e.asset.id,
    assetType: e.asset.type,
    blockId: e.blockId,
    nodeType: e.nodeType,
    path: e.path
  }), r;
}, bl = [
  "public-read-page",
  "ssr-fragment",
  "email-fragment",
  "search-record",
  "excerpt-summary"
], Hm = [
  "page-html",
  "fragment-html",
  "fragment-react",
  "email-html",
  "search-record",
  "excerpt-summary"
], Xt = {
  "public-read-page": {
    name: "public-read-page",
    compatibleTargets: ["html"],
    defaultTarget: "html",
    profile: "public-html",
    payloadKinds: {
      html: "page-html"
    },
    cacheNamespace: "zx-delivery:public-page"
  },
  "ssr-fragment": {
    name: "ssr-fragment",
    compatibleTargets: ["html", "react"],
    defaultTarget: "html",
    profile: "public-html",
    payloadKinds: {
      html: "fragment-html",
      react: "fragment-react"
    },
    cacheNamespace: "zx-delivery:ssr-fragment"
  },
  "email-fragment": {
    name: "email-fragment",
    compatibleTargets: ["html"],
    defaultTarget: "html",
    profile: "email-html",
    payloadKinds: {
      html: "email-html"
    },
    cacheNamespace: "zx-delivery:email-fragment"
  },
  "search-record": {
    name: "search-record",
    compatibleTargets: ["text"],
    defaultTarget: "text",
    profile: "search-text",
    payloadKinds: {
      text: "search-record"
    },
    cacheNamespace: "zx-delivery:search-record"
  },
  "excerpt-summary": {
    name: "excerpt-summary",
    compatibleTargets: ["text"],
    defaultTarget: "text",
    profile: "excerpt",
    payloadKinds: {
      text: "excerpt-summary"
    },
    cacheNamespace: "zx-delivery:excerpt-summary"
  }
}, yl = (e, t) => (j(t, Ua(e)), new z(
  `Delivery surface "${e}" is not registered.`,
  t
)), kl = (e, t, r) => (j(
  r,
  qa(e, t)
), new z(
  `Delivery surface "${e}" is not compatible with target "${t}".`,
  r
)), vl = (e, t, r) => (j(
  r,
  Ka(e, t)
), new z(
  `Delivery surface "${e}" is backed by a fixed profile and cannot use "${t}".`,
  r
)), Sl = (e, t, r) => new z(
  `Delivery surface "${e}" does not declare a payload kind for target "${t}".`,
  r
), Il = (e) => e in Xt, Vm = () => bl.map((e) => Xt[e]), Tl = (e, t = J()) => {
  if (!Il(e))
    throw yl(e, t);
  return Xt[e];
}, xl = (e, t, r = J()) => {
  const n = t ?? e.defaultTarget;
  if (!e.compatibleTargets.includes(n))
    throw kl(
      e.name,
      n,
      r
    );
  return n;
}, wl = (e, t, r = J()) => {
  const n = t ?? e.profile;
  if (n !== e.profile)
    throw vl(
      e.name,
      n,
      r
    );
  return e.profile;
}, El = (e, t, r = J()) => {
  const n = e.payloadKinds[t];
  if (!n)
    throw Sl(e.name, t, r);
  return n;
}, Cl = "blockId", Dl = "#", Pe = (e) => typeof e == "string" && e.trim() ? e.trim() : void 0, Fe = (e) => e.join("."), Rl = (e, t, r) => typeof e[t] == "boolean" ? e[t] : r, he = (e) => typeof e == "object" && e !== null, Al = (e) => {
  try {
    const t = new URL(e);
    return ["http:", "https:", "mailto:", "tel:"].includes(t.protocol);
  } catch {
    return !1;
  }
}, Ml = (e) => {
  try {
    const t = new URL(e);
    return ["http:", "https:"].includes(t.protocol);
  } catch {
    return !1;
  }
}, Ol = (e) => K(e), ro = (e, t, r) => (re(
  e.diagnostics,
  _t("email-absolute-url", t)
), new z(r, e.diagnostics)), no = (e) => e.surface.name === "email-fragment" && Rl(e.variant, "requireAbsoluteUrls", !0), $l = (e, t, r) => {
  if (no(t) && !Al(e))
    throw ro(
      t,
      r,
      `Email delivery surface "${t.surface.name}" requires absolute link URLs.`
    );
}, Ll = (e, t, r) => {
  if (no(t) && !Ml(e))
    throw ro(
      t,
      r,
      `Email delivery surface "${t.surface.name}" requires absolute asset URLs.`
    );
}, oo = (e, t) => {
  const r = e.resolveLink(t);
  return $l(r.href, e, t.path), r;
}, jr = (e, t) => {
  const r = e.resolveAsset(t);
  return Ll(r.src, e, t.path), r;
}, Nl = (e, t, r, n, o) => {
  if (!he(e) || typeof e.type != "string")
    return e;
  const s = {
    ...e,
    ...he(e.attrs) ? { attrs: { ...e.attrs } } : {}
  };
  if (s.type !== "link" || !he(s.attrs))
    return s;
  const i = Pe(s.attrs.href);
  if (!i)
    return s;
  const a = oo(t, {
    href: i,
    intent: i.startsWith(Dl) ? "anchor-link" : "canonical-link",
    blockId: n,
    nodeType: r,
    markType: s.type,
    path: Fe(o)
  });
  return s.attrs.href = a.href, a.rel !== void 0 && (s.attrs.rel = a.rel), a.target !== void 0 && (s.attrs.target = a.target), s;
}, so = (e, t, r, n) => {
  var c, l;
  if (!he(e) || typeof e.type != "string")
    return e;
  const o = {
    ...e,
    ...he(e.attrs) ? { attrs: { ...e.attrs } } : {}
  }, s = e.type, i = he(o.attrs) ? o.attrs : void 0, a = Pe(i == null ? void 0 : i[Cl]) ?? n.blockId;
  if (i) {
    if (s === "embed") {
      const u = Pe(i.url) ?? Pe(i.name);
      if (u) {
        const m = oo(r, {
          href: u,
          intent: "embed-link",
          blockId: a,
          nodeType: s,
          path: Fe(n.path)
        });
        i.url = m.href, m.rel !== void 0 && (i.rel = m.rel), m.target !== void 0 && (i.target = m.target);
      }
    }
    const d = Ze(o, t);
    if (s === "attachment" && d) {
      Object.assign(i, fn(d));
      const u = jr(r, {
        asset: d,
        assetId: d.id,
        intent: "download",
        blockId: a,
        nodeType: s,
        path: Fe(n.path)
      });
      i.href = u.src;
    }
    if ((s === "image" || s === "video" || s === "iframe") && d && d) {
      const u = jr(r, {
        asset: d,
        assetId: d.id,
        intent: "display",
        blockId: a,
        nodeType: s,
        path: Fe(n.path)
      });
      i.src = u.src, u.width !== void 0 && (i.width = u.width), u.height !== void 0 && (i.height = u.height);
    }
  }
  return (c = o.marks) != null && c.length && (o.marks = o.marks.map(
    (d, u) => Nl(d, r, s, a, [
      ...n.path,
      "marks",
      u
    ])
  )), (l = o.content) != null && l.length && (o.content = o.content.map(
    (d, u) => so(d, t, r, {
      path: [...n.path, "content", u],
      blockId: a
    })
  )), o;
}, Bl = (e, t) => {
  const r = Ol(e);
  return r.body.content = so(
    r.body.content,
    r,
    t,
    {
      path: []
    }
  ), r;
}, ao = (e) => typeof e == "object" && e !== null, Jt = (e, t = "HTML renderer encountered unhandled content") => new z(
  e.length ? `${t}: ${Va(e[0])}` : t,
  e
), Ur = (e, t, r) => {
  const n = e.targetCapabilityIndex[r.target][t], o = e.profileSupportMatrix[r.profile.name][t === "nodes" ? "supportedNodes" : "supportedMarks"];
  return new Set(
    Array.from(n).filter((s) => o.has(s))
  );
}, zl = (e, t) => {
  if (!(e != null && e.length))
    return;
  const r = e.flatMap((n) => !ao(n) || typeof n.type != "string" ? [] : t.has(n.type) ? [n] : []);
  return r.length ? r : void 0;
}, _l = (e, t) => {
  var a;
  const r = t.registry.renderRegistry, n = Ur(
    r,
    "nodes",
    t
  ), o = Ur(
    r,
    "marks",
    t
  ), s = (c) => {
    var u;
    if (!ao(c) || typeof c.type != "string")
      return [];
    const l = (u = c.content) == null ? void 0 : u.flatMap((m) => s(m)), d = zl(c.marks, o);
    return n.has(c.type) ? [
      {
        ...c,
        marks: d,
        content: l != null && l.length ? l : void 0
      }
    ] : l ?? [];
  }, i = s(e);
  return i.length === 1 && ((a = i[0]) == null ? void 0 : a.type) === "doc" ? i[0] : {
    type: "doc",
    content: i
  };
}, Pl = (e, t, r) => r.debugMode === "drop-unhandled" ? _l(e, t) : e, Fl = (e, t) => ({ node: r, children: n }) => {
  if (tt(e, "unhandled-node", r.type.name) || j(
    e,
    Mn(r.type.name)
  ), t)
    throw Jt(e);
  return Sn(n);
}, Hl = (e, t) => ({ mark: r, children: n }) => {
  if (tt(e, "unhandled-mark", r.type.name) || j(
    e,
    On(r.type.name)
  ), t)
    throw Jt(e);
  return Sn(n);
}, Vl = (e) => {
  const t = {};
  for (const [r, n] of Object.entries(e))
    t[r] = (o) => n(o);
  return t;
}, jl = (e) => {
  const t = {};
  for (const [r, n] of Object.entries(e))
    t[r] = (o) => n(o);
  return t;
}, io = (e, t, r = {}) => {
  const n = t.diagnostics, o = t.policy.strictness === "fail-fast" && r.debugMode !== "drop-unhandled", s = Pt(
    e.content,
    t.registry.renderRegistry,
    {
      target: t.target,
      profile: t.profile.name
    }
  );
  if (n.push(...s), o && s.length)
    throw Jt(n);
  if (!t.policy.htmlPolicy)
    throw new z(
      `Render profile "${t.profile.name}" does not provide an HTML safety policy.`,
      n
    );
  try {
    const i = Ds({
      content: Pl(
        Ki(e.content, e.document),
        t,
        r
      ),
      extensions: Vn({
        descriptors: t.descriptors
      }),
      options: {
        nodeMapping: Vl(
          t.registry.renderRegistry.htmlNodeMapping
        ),
        markMapping: jl(
          t.registry.renderRegistry.htmlMarkMapping
        ),
        unhandledNode: Fl(n, o),
        unhandledMark: Hl(n, o)
      }
    });
    return t.policy.htmlPolicy.sanitize(i, {
      diagnostics: n
    });
  } catch (i) {
    if (i instanceof z)
      throw i;
    const a = i instanceof Error ? i.message : "Unknown HTML rendering failure";
    throw new z(`HTML renderer failed: ${a}`, n);
  }
}, Ul = (e, t, r = {}) => io(e, t, r), co = (e, t = {}, r = {}) => {
  const n = jt({
    target: "html",
    profile: t.profile,
    descriptors: t.descriptors,
    diagnostics: t.diagnostics,
    variant: t.variant
  });
  return we(n, {
    html: (o) => io(e, o, r)
  });
}, ql = (e, t = {}) => co(
  {
    document: e,
    content: e.body.content
  },
  t
), jm = (e, t = {}) => co(
  {
    content: e
  },
  t
), Kl = /* @__PURE__ */ new Set([
  "text",
  "hardBreak",
  "mention",
  "tagItem",
  "embed"
]), Wl = 160, Gl = "…", lo = (e) => typeof e == "object" && e !== null, H = (e) => typeof e == "string" && e.trim() ? e.trim() : null, wt = (e) => e === !0 || e === "true" ? !0 : e === !1 || e === "false" ? !1 : null, uo = (e) => typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null, mo = (e) => e.replace(/^\n+|\n+$/g, ""), Xl = (e) => e.replace(/\s+/g, " ").trim(), ot = (e) => e.join("."), ye = (e, t, r) => re(
  e,
  yt(t, r)
), Jl = (e) => typeof e.type == "string" && Kl.has(e.type), Yl = (e = []) => e.some((t) => !Jl(t)), Zl = (e, t, r) => !r.includeHeadingBreaks && (e === "heading" || t === "heading") ? `
` : `

`, Ql = (e, t, r = {}) => {
  const n = e.map((o) => ({
    type: o.type,
    text: r.compact ? o.text.trim() : mo(o.text)
  })).filter((o) => o.text);
  return n.reduce((o, s, i) => {
    var l;
    if (i === 0)
      return s.text;
    const a = (l = n[i - 1]) == null ? void 0 : l.type, c = r.compact ? " " : Zl(a, s.type, t);
    return `${o}${c}${s.text}`;
  }, "");
}, ed = (e, t) => {
  const r = " ".repeat(t.length);
  return e.split(`
`).map(
    (n, o) => o === 0 ? `${t}${n}` : n ? `${r}${n}` : r.trimEnd()
  ).join(`
`);
}, td = (e) => {
  var t;
  if (!e)
    return null;
  try {
    const n = new URL(e).pathname.split("/").filter(Boolean);
    return n.length ? decodeURIComponent(n.at(-1)) : null;
  } catch {
    const n = (((t = e.split("?")[0]) == null ? void 0 : t.split("#")[0]) ?? e).split("/").filter(Boolean);
    return n.length ? decodeURIComponent(n.at(-1)) : null;
  }
}, qr = (e) => {
  const t = typeof e == "number" && Number.isFinite(e) ? e : typeof e == "string" && /^\d+(?:\.\d+)?$/.test(e.trim()) ? Number.parseFloat(e.trim()) : null;
  if (t === null || t < 0)
    return null;
  if (t < 1024)
    return `${Math.round(t)} B`;
  const r = ["KB", "MB", "GB", "TB"];
  let n = t / 1024, o = 0;
  for (; n >= 1024 && o < r.length - 1; )
    n /= 1024, o += 1;
  return `${n >= 100 ? Math.round(n) : Math.round(n * 10) / 10} ${r[o]}`;
}, rd = (e, t) => {
  var r, n, o, s, i, a, c, l, d, u, m;
  if (!e)
    return null;
  switch (t) {
    case "alt":
      return H((r = e.meta) == null ? void 0 : r.alt) ?? H(e.title);
    case "title":
      return H(e.title);
    case "fileName":
      return H((n = e.meta) == null ? void 0 : n.fileName) ?? H(e.title) ?? td(H(e.src));
    case "mimeType":
      return H(e.mimeType);
    case "name":
      return H((o = e.meta) == null ? void 0 : o.name) ?? H(e.title);
    case "src":
    case "url":
    case "href":
      return H(e.src);
    case "fileSize":
      return typeof ((s = e.meta) == null ? void 0 : s.size) == "number" ? String(Math.round(e.meta.size)) : typeof ((i = e.meta) == null ? void 0 : i.fileSize) == "number" ? String(Math.round(e.meta.fileSize)) : H((a = e.meta) == null ? void 0 : a.size) ?? H((c = e.meta) == null ? void 0 : c.fileSize);
    case "sizeLabel":
      return qr((l = e.meta) == null ? void 0 : l.size) ?? qr((d = e.meta) == null ? void 0 : d.fileSize);
    case "icon":
      return H((u = e.meta) == null ? void 0 : u.icon);
    default:
      return H((m = e.meta) == null ? void 0 : m[t]);
  }
}, fo = (e, t, r) => {
  const n = lo(e.attrs) ? e.attrs : {}, o = Ze(e, r.document);
  return t in n && n[t] !== null && n[t] !== void 0 ? H(n[t]) : rd(o, t);
}, nd = (e, t, r, n) => {
  var s;
  const o = t.textStrategy;
  return o === "omit" ? "" : o === "children" || o === "preserve-text" ? W(e.content, r, n) : o === "attribute" ? ((s = t.textAttrs) == null ? void 0 : s.map((a) => fo(e, a, r)).find(Boolean)) ?? null ?? t.textFallback ?? "" : t.textFallback ?? "";
}, od = (e, t, r, n) => {
  typeof e.type == "string" && r.semanticDegradeNodes.has(e.type) && ye(
    r.diagnostics,
    e.type,
    ot(n)
  );
  const s = nd(e, t, r, n).trim();
  return s ? `${t.textPrefix ?? ""}${s}${t.textSuffix ?? ""}` : t.textFallback ?? "";
}, ct = (e = [], t, r, n) => e.map((o, s) => {
  const i = [...r, "content", s], a = W(o.content, t, i);
  return a ? ed(a, n(o, s)) : "";
}).filter(Boolean).join(`
`), sd = (e = [], t, r) => e.map((n, o) => {
  const s = [...r, "content", o];
  return (n.content ?? []).map(
    (a, c) => W(
      a.content,
      t,
      [...s, "content", c],
      {
        compactBlocks: !0
      }
    )
  ).filter(Boolean).join("	");
}).filter(Boolean).join(`
`), W = (e = [], t, r, n = {}) => {
  if (!e.length)
    return "";
  const o = e.map((s, i) => ({
    type: typeof s.type == "string" ? s.type : void 0,
    text: Yt(s, t, [...r, "content", i])
  }));
  return Yl(e) ? Ql(o, t, {
    compact: n.compactBlocks
  }) : o.map((s) => s.text).join("");
}, ad = (e, t, r) => {
  var n;
  (n = e.marks) == null || n.forEach((o, s) => {
    typeof o.type == "string" && t.semanticDegradeMarks.has(o.type) && ye(
      t.diagnostics,
      o.type,
      ot([...r, "marks", s])
    );
  });
}, id = (e, t, r) => ({
  node: e,
  path: r,
  includeHeadingBreaks: t.includeHeadingBreaks,
  renderNode: (n, o) => Yt(n, t, [...o]),
  renderChildren: (n, o, s = {}) => W(n, t, [...o], s),
  resolveAttribute: (n) => fo(e, n, t),
  pushSemanticDegrade: (n, o = r) => ye(
    t.diagnostics,
    n,
    ot([...o])
  )
}), Yt = (e, t, r) => {
  var s;
  if (!lo(e) || typeof e.type != "string")
    return "";
  ad(e, t, r);
  const n = t.context.profile.name === "excerpt" ? t.registry.excerptSerializers[e.type] ?? t.registry.textSerializers[e.type] : t.registry.textSerializers[e.type];
  if (n)
    return t.semanticDegradeNodes.has(e.type) && ye(
      t.diagnostics,
      e.type,
      ot(r)
    ), n(id(e, t, r));
  const o = t.registry.nodeContracts[e.type];
  if (o)
    return od(e, o, t, r);
  switch (e.type) {
    case "doc":
      return W(e.content, t, r);
    case "text":
      return typeof e.text == "string" ? e.text : "";
    case "hardBreak":
      return `
`;
    case "paragraph":
    case "heading":
      return W(e.content, t, r);
    case "blockquote":
      return W(e.content, t, r).split(`
`).map((a) => a ? `> ${a}` : ">").join(`
`);
    case "bulletList":
      return ct(e.content, t, r, () => "- ");
    case "orderedList": {
      const i = uo((s = e.attrs) == null ? void 0 : s.start) ?? 1;
      return ct(
        e.content,
        t,
        r,
        (a, c) => `${i + c}. `
      );
    }
    case "taskList":
      return ct(
        e.content,
        t,
        r,
        (i) => {
          var a;
          return (a = i.attrs) != null && a.checked ? "- [x] " : "- [ ] ";
        }
      );
    case "listItem":
    case "taskItem":
      return W(e.content, t, r);
    case "codeBlock":
      return t.context.profile.name === "excerpt" ? zo(
        ut(e)
      ) : _o(
        ut(e)
      );
    case "table":
      return sd(e.content, t, r);
    case "tableRow":
      return (e.content ?? []).map(
        (i, a) => W(
          i.content,
          t,
          [...r, "content", a],
          {
            compactBlocks: !0
          }
        )
      ).filter(Boolean).join("	");
    case "tableCell":
    case "tableHeader":
      return W(e.content, t, r, {
        compactBlocks: !0
      });
    case "horizontalRule":
      return "---";
    default:
      return W(e.content, t, r);
  }
}, cd = (e) => wt(e.includeHeadingBreaks) ?? !0, ld = (e) => ({
  maxLength: Math.max(
    uo(e.maxLength) ?? Wl,
    0
  ),
  preserveWords: wt(e.preserveWords) ?? !0,
  collapseWhitespace: wt(e.collapseWhitespace) ?? !0,
  suffix: typeof e.suffix == "string" ? e.suffix : Gl
}), dd = (e, t) => {
  if (e.length <= t.maxLength)
    return e;
  const r = Math.max(t.maxLength - t.suffix.length, 0);
  if (r === 0)
    return t.suffix.slice(0, t.maxLength);
  let n = e.slice(0, r);
  if (t.preserveWords) {
    const o = n.lastIndexOf(" ");
    o > 0 && (n = n.slice(0, o));
  }
  return `${n.trimEnd()}${t.suffix}`;
}, ud = (e, t) => {
  const r = ld(t.context.variant), n = e.trim(), o = r.collapseWhitespace ? Xl(n) : n;
  r.collapseWhitespace && o !== n && ye(
    t.diagnostics,
    "excerpt.collapse-whitespace"
  );
  const s = dd(o, r);
  return s !== o && ye(t.diagnostics, "excerpt.truncate"), s;
}, md = (e, t) => {
  const r = t.diagnostics, n = t.registry.renderRegistry;
  r.push(
    ...Pt(e.content, n, {
      target: t.target,
      profile: t.profile.name
    })
  );
  const o = n.profileSupportMatrix[t.profile.name], s = {
    context: t,
    document: e.document,
    includeHeadingBreaks: cd(t.variant),
    registry: n,
    diagnostics: r,
    semanticDegradeNodes: o.semanticDegradeNodes,
    semanticDegradeMarks: o.semanticDegradeMarks
  }, i = mo(Yt(e.content, s, []));
  return t.profile.name === "excerpt" ? ud(i, s) : i;
}, po = (e, t) => md(e, t), fd = (e) => {
  const t = { ...e.variant ?? {} };
  return e.includeHeadingBreaks !== void 0 && (t.includeHeadingBreaks = e.includeHeadingBreaks), e.maxLength !== void 0 && (t.maxLength = e.maxLength), e.preserveWords !== void 0 && (t.preserveWords = e.preserveWords), e.collapseWhitespace !== void 0 && (t.collapseWhitespace = e.collapseWhitespace), e.suffix !== void 0 && (t.suffix = e.suffix), t;
}, st = (e, t) => {
  const r = jt({
    target: "text",
    profile: t.profile,
    descriptors: t.descriptors,
    diagnostics: t.diagnostics,
    variant: fd(t)
  });
  return we(r, {
    text: (n) => po(e, n)
  });
}, Um = (e, t = {}) => st(
  {
    document: e,
    content: e.body.content
  },
  {
    ...t,
    profile: t.profile ?? "search-text"
  }
), qm = (e, t = {}) => st(
  {
    content: e
  },
  {
    ...t,
    profile: t.profile ?? "search-text"
  }
), pd = "blockId", go = (e) => typeof e == "object" && e !== null, ge = (e) => typeof e == "string" && e.trim() ? e.trim() : void 0, gd = (e) => typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null, hd = (e) => typeof e == "number" && Number.isFinite(e) ? Math.max(1, Math.round(e)) : typeof e == "string" && /^\d+$/.test(e.trim()) ? Math.max(1, Number.parseInt(e.trim(), 10)) : null, bd = (e) => e.replace(/\s+/g, " ").trim(), yd = (e) => (e ?? []).map((t) => ho(t)).filter(Boolean).join(" "), ho = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? " " : yd(e.content), Zt = (e, t = []) => {
  var r;
  if (e.type === "heading") {
    const n = go(e.attrs) ? e.attrs : {}, o = bd(ho(e)), s = hd(n.level), i = ge(n[pd]);
    o && s && t.push({
      label: o,
      level: s,
      ...i ? { blockId: i } : {}
    });
  }
  return (r = e.content) == null || r.forEach((n) => Zt(n, t)), t;
}, kd = (e) => {
  var t;
  return (e == null ? void 0 : e.meta.title) ?? (e ? (t = Zt(e.body.content)[0]) == null ? void 0 : t.label : void 0);
}, bo = (e, t) => {
  t.forEach(
    (r) => re(e, r)
  );
}, vd = (e) => {
  const t = gd(e.excerptMaxLength);
  return t !== null ? { maxLength: t } : {};
}, Sd = (e) => e.surface.name === "public-read-page" ? "public-read-page" : e.surface.name === "ssr-fragment" ? e.target === "react" ? "ssr-fragment-react" : "ssr-fragment-html" : e.surface.name === "search-record" ? "search-record" : e.surface.name === "excerpt-summary" ? "excerpt-summary" : null, yo = (e, t, r = []) => {
  var o;
  const n = [];
  return e.type === "codeBlock" && sn({
    surface: t,
    descriptor: ut(e)
  }).diagnostics.forEach((i) => {
    n.push({
      kind: "semantic-degrade",
      name: i.code,
      path: r.join(".")
    });
  }), (o = e.content) == null || o.forEach((s, i) => {
    n.push(
      ...yo(s, t, [
        ...r,
        "content",
        i
      ])
    );
  }), n;
}, Id = (e, t) => {
  const r = Sd(e);
  !r || !t || bo(
    e.diagnostics,
    yo(t.body.content, r)
  );
}, Td = (e, t = {}) => ({
  title: t.title ?? (e == null ? void 0 : e.meta.title),
  updatedAt: t.updatedAt ?? (e == null ? void 0 : e.meta.updatedAt),
  source: t.source ?? (e == null ? void 0 : e.meta.source)
}), xd = (e, t = {}) => ({
  links: [...e.links, ...t.links ?? []],
  assets: [...e.assets, ...t.assets ?? []]
}), wd = (e, t, r, n = {}) => {
  const o = go(r) ? r : {}, s = n.outline ?? (t ? Zt(t.body.content) : void 0), i = n.title ?? ge(o.title) ?? (t == null ? void 0 : t.meta.title), a = n.excerpt ?? (e === "search-record" ? ge(o.excerpt) : e === "excerpt-summary" ? ge(o.text) : void 0), c = n.searchText ?? (e === "search-record" ? ge(o.text) : void 0);
  return {
    ...i ? { title: i } : {},
    ...a ? { excerpt: a } : {},
    ...c ? { searchText: c } : {},
    ...s && (s.length > 0 || n.outline !== void 0) ? { outline: s } : {}
  };
}, Qt = (e) => {
  const t = e.diagnostics ?? J(), r = Tl(e.surface, t), n = xl(r, e.target, t), o = wl(r, e.profile, t), s = jt({
    target: n,
    profile: o,
    descriptors: e.descriptors,
    diagnostics: t,
    variant: e.variant
  }), i = e.cache, a = pl(), c = e.resolvers;
  return {
    surface: r,
    target: n,
    profile: s.profile,
    payloadKind: El(r, n, t),
    report: s.registry.report,
    diagnostics: t,
    document: e.document,
    resolvers: c,
    traces: a,
    variant: s.variant,
    renderContext: s,
    createCacheKey: (l = {}) => {
      const { variant: d, ...u } = l;
      return jn(
        {
          surface: r.name,
          target: n,
          profile: s.profile.name,
          variant: d ?? s.variant
        },
        {
          docId: u.docId ?? (i == null ? void 0 : i.docId),
          docVersion: u.docVersion ?? (i == null ? void 0 : i.docVersion),
          hash: u.hash ?? (i == null ? void 0 : i.hash),
          namespace: u.namespace ?? (i == null ? void 0 : i.namespace) ?? r.cacheNamespace
        }
      );
    },
    resolveLink: (l) => gl(
      {
        ...l,
        surface: r.name,
        profile: s.profile.name,
        document: e.document
      },
      {
        diagnostics: t,
        resolvers: c,
        traces: a
      }
    ),
    resolveAsset: (l) => hl(
      {
        ...l,
        surface: r.name,
        profile: s.profile.name
      },
      {
        diagnostics: t,
        resolvers: c,
        traces: a
      }
    )
  };
}, er = (e, t, r) => {
  const n = r[e.surface.name];
  if (!n)
    throw new z(
      `Delivery surface "${e.surface.name}" does not have a registered surface adapter.`,
      e.diagnostics
    );
  return n(t, e);
}, tr = (e, t) => (Id(e, t.document), {
  surface: e.surface.name,
  target: e.target,
  profile: e.profile.name,
  variant: e.variant,
  payload: t.payload,
  cacheKey: e.createCacheKey(t.cache),
  diagnostics: e.diagnostics,
  meta: Td(t.document, t.meta),
  traces: xd(e.traces, t.traces),
  projection: wd(
    e.surface.name,
    t.document,
    t.payload,
    t.projection
  )
}), Km = (e, t) => {
  const r = Qt(e), n = we(r.renderContext, t.target), o = er(
    r,
    n,
    t.surface
  );
  return tr(r, {
    document: e.document,
    ...o
  });
}, Ed = (e, t) => {
  const r = Bl(e, t);
  return {
    document: r,
    content: r.body.content
  };
}, rr = (e, t, r, n) => {
  const o = {
    surface: e,
    document: t,
    descriptors: r == null ? void 0 : r.descriptors,
    diagnostics: r == null ? void 0 : r.diagnostics,
    variant: r == null ? void 0 : r.variant,
    cache: r == null ? void 0 : r.cache,
    resolvers: r == null ? void 0 : r.resolvers
  }, s = Qt(o), i = we(s.renderContext, {
    html: (c) => Ul(
      Ed(t, s),
      c
    )
  }), a = er(s, i, n);
  return tr(s, {
    document: t,
    ...a
  });
}, Wm = (e, t = {}) => rr("public-read-page", e, t, {
  "public-read-page": (r) => ({
    payload: {
      html: r
    }
  })
}), Gm = (e, t = {}) => rr("ssr-fragment", e, t, {
  "ssr-fragment": (r) => ({
    payload: {
      html: r
    }
  })
}), Xm = (e, t = {}) => rr("email-fragment", e, t, {
  "email-fragment": (r) => ({
    payload: {
      html: r
    }
  })
}), ko = (e, t, r, n) => {
  const o = {
    surface: e,
    document: t,
    descriptors: r == null ? void 0 : r.descriptors,
    diagnostics: r == null ? void 0 : r.diagnostics,
    variant: r == null ? void 0 : r.variant,
    cache: r == null ? void 0 : r.cache,
    resolvers: r == null ? void 0 : r.resolvers
  }, s = Qt(o), i = we(s.renderContext, {
    text: (c) => po(
      {
        document: t,
        content: t.body.content
      },
      c
    )
  }), a = er(s, i, n);
  return tr(s, {
    document: t,
    ...a
  });
}, Cd = (e, t, r) => {
  const n = J(), o = st(
    {
      document: e,
      content: e.body.content
    },
    {
      profile: "excerpt",
      descriptors: r.descriptors,
      diagnostics: n,
      variant: vd(t.variant)
    }
  );
  return bo(t.diagnostics, n), ge(o);
}, Jm = (e, t = {}) => ko("search-record", e, t, {
  "search-record": (r, n) => {
    const o = kd(e), s = Cd(e, n, t);
    return {
      payload: {
        ...o ? { title: o } : {},
        text: r,
        ...s ? { excerpt: s } : {}
      }
    };
  }
}), Ym = (e, t = {}) => ko("excerpt-summary", e, t, {
  "excerpt-summary": (r, n) => ({
    payload: {
      text: r,
      truncated: tt(
        n.diagnostics,
        "semantic-degrade",
        "excerpt.truncate"
      )
    }
  })
}), vo = (e, t = {}) => us(e.content, {
  mode: t.mode,
  registry: t.registry,
  diagnostics: t.diagnostics
}), Dd = (e, t = {}) => vo(
  {
    content: e.body.content
  },
  t
), Zm = (e, t = {}) => vo(
  {
    content: e
  },
  t
), So = (e, t = {}) => st(e, {
  ...t,
  profile: t.profile ?? "excerpt",
  maxLength: t.maxLength,
  preserveWords: t.preserveWords,
  collapseWhitespace: t.collapseWhitespace,
  suffix: t.suffix
}), Qm = (e, t = {}) => So(
  {
    document: e,
    content: e.body.content
  },
  t
), ef = (e, t = {}) => So(
  {
    content: e
  },
  t
), Ke = "comment", Kr = 24, Et = (e) => e.type === "comment", Wr = (e) => JSON.parse(JSON.stringify(e)), oe = (e) => ({
  blockId: e.blockId,
  offset: e.offset
}), nr = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : Array.isArray(e.content) ? e.content.reduce((t, r) => t + nr(r), 2) : 1, or = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? `
` : "", Rd = (e) => (e.marks ?? []).filter(
  (t) => {
    var r;
    return t.type === Ke && typeof ((r = t.attrs) == null ? void 0 : r.commentId) == "string";
  }
), Io = (e) => Array.from(e.values()).sort((t, r) => t.pos - r.pos), Ad = (e, t) => {
  const r = /* @__PURE__ */ new Map(), n = [], o = (s, i, a) => {
    var f;
    const c = (f = s.attrs) == null ? void 0 : f.blockId, l = typeof c == "string" ? t.get(c) ?? null : null, d = l && l.pos === i ? [...a, l] : a, u = or(s);
    if (u) {
      d.forEach((T) => {
        r.set(
          T.blockId,
          `${r.get(T.blockId) ?? ""}${u}`
        );
      });
      const h = i, k = i + u.length, b = Se(t, h), R = Se(t, k);
      b && R && Rd(s).forEach((T) => {
        var y, I;
        n.push({
          absoluteFrom: h,
          absoluteTo: k,
          commentId: (y = T.attrs) == null ? void 0 : y.commentId,
          end: oe(R),
          resolved: !!((I = T.attrs) != null && I.resolved),
          start: oe(b)
        });
      });
    }
    if (!Array.isArray(s.content) || s.content.length === 0)
      return;
    let m = s.type === "doc" ? i : i + 1;
    s.content.forEach((h) => {
      o(h, m, d), m += nr(h);
    });
  };
  return o(e, 0, []), {
    blockTextById: r,
    segments: n
  };
}, Md = (e, t, r, n) => {
  const o = Io(e), s = new Map(
    o.map((l, d) => [l.blockId, d])
  ), i = s.get(r.blockId), a = s.get(n.blockId);
  if (i === void 0 || a === void 0 || i > a)
    return "";
  if (r.blockId === n.blockId)
    return (t.get(r.blockId) ?? "").slice(r.offset, n.offset);
  const c = [];
  for (let l = i; l <= a; l++) {
    const d = o[l], u = t.get(d.blockId) ?? "", m = l === i ? r.offset : 0, f = l === a ? n.offset : d.textLength;
    c.push(u.slice(m, f));
  }
  return c.join(`
`);
}, Od = (e, t, r) => ({
  afterQuote: (e.get(r.blockId) ?? "").slice(
    r.offset,
    r.offset + Kr
  ) || void 0,
  beforeQuote: (e.get(t.blockId) ?? "").slice(
    Math.max(0, t.offset - Kr),
    t.offset
  ) || void 0
}), $d = (e, t, r) => {
  const n = /* @__PURE__ */ new Map();
  return e.forEach((o) => {
    const s = n.get(o.commentId) ?? [];
    s.push(o), n.set(o.commentId, s);
  }), Array.from(n.entries()).map(([o, s]) => {
    const i = [...s].sort(
      (l, d) => l.absoluteFrom - d.absoluteFrom
    ), a = oe(i[0].start), c = oe(i[i.length - 1].end);
    return {
      commentId: o,
      start: a,
      end: c,
      resolved: i.some((l) => l.resolved),
      quote: Md(t, r, a, c),
      ...Od(r, a, c)
    };
  }).filter((o) => !!o.quote);
}, Gr = (e) => e.filter(
  (t, r) => e.findIndex(
    (n) => n.type === t.type && JSON.stringify(n.attrs ?? {}) === JSON.stringify(t.attrs ?? {})
  ) === r
), Ct = (e) => e.filter((t) => t.type !== Ke), Ld = (e, t, r) => {
  const n = or(e);
  if (!n)
    return [e];
  const o = t + n.length, s = r.filter((l) => l.from < o && l.to > t), i = Ct([...e.marks ?? []]);
  if (!s.length)
    return [
      {
        ...e,
        marks: i.length ? i : void 0
      }
    ];
  if (e.type === "hardBreak") {
    const l = s.map((u) => ({
      type: Ke,
      attrs: {
        commentId: u.commentId,
        resolved: u.resolved
      }
    })), d = Gr([...i, ...l]);
    return [
      {
        ...e,
        marks: d.length ? d : void 0
      }
    ];
  }
  const a = Array.from(
    /* @__PURE__ */ new Set([
      0,
      n.length,
      ...s.reduce((l, d) => (l.push(
        Math.max(0, d.from - t),
        Math.min(n.length, d.to - t)
      ), l), [])
    ])
  ).sort((l, d) => l - d), c = [];
  for (let l = 0; l < a.length - 1; l++) {
    const d = a[l], u = a[l + 1], m = n.slice(d, u);
    if (!m)
      continue;
    const f = s.filter(
      (k) => k.from < t + u && k.to > t + d
    ).map((k) => ({
      type: Ke,
      attrs: {
        commentId: k.commentId,
        resolved: k.resolved
      }
    })), h = Gr([...i, ...f]);
    c.push({
      ...e,
      text: m,
      marks: h.length ? h : void 0
    });
  }
  return c;
}, Nd = (e, t) => {
  const r = Io(e), n = new Map(
    r.map((o, s) => [o.blockId, s])
  );
  return t.filter(Et).reduce((o, s) => {
    const i = s.anchor.start, a = s.anchor.end, c = e.get(i.blockId), l = e.get(a.blockId), d = n.get(i.blockId), u = n.get(a.blockId);
    if (!c || !l || d === void 0 || u === void 0 || i.offset < 0 || a.offset < 0 || i.offset > c.textLength || a.offset > l.textLength || d > u || i.blockId === a.blockId && i.offset >= a.offset)
      return o;
    const m = [];
    for (let f = d; f <= u; f++) {
      const h = r[f], k = f === d ? i.offset : 0, b = f === u ? a.offset : h.textLength;
      if (b <= k)
        continue;
      const R = xt(
        e,
        h.blockId,
        k
      ), T = xt(
        e,
        h.blockId,
        b
      );
      R === null || T === null || T <= R || m.push({
        commentId: s.id,
        from: R,
        to: T,
        resolved: s.resolved
      });
    }
    return o.push(...m), o;
  }, []);
}, Bd = (e, t) => {
  const r = ue(e), n = Nd(r, t), o = (s, i) => {
    if (or(s))
      return Ld(s, i, n);
    if (!Array.isArray(s.content) || s.content.length === 0) {
      const u = s.marks ? Ct([...s.marks]) : void 0;
      return [
        {
          ...s,
          marks: u != null && u.length ? u : void 0
        }
      ];
    }
    let c = s.type === "doc" ? i : i + 1;
    const l = s.content.reduce((u, m) => {
      const f = o(m, c);
      return c += nr(m), u.push(...f), u;
    }, []), d = s.marks ? Ct([...s.marks]) : void 0;
    return [
      {
        ...s,
        marks: d != null && d.length ? d : void 0,
        content: l
      }
    ];
  };
  return o(Wr(e), 0)[0] ?? Wr(e);
}, tf = (e, t) => {
  const r = ue(e), n = bn(t.annotations), o = n.filter(
    Et
  ), s = new Map(
    o.map((u) => [u.id, u])
  ), { blockTextById: i, segments: a } = Ad(e, r), c = $d(a, r, i), l = n.map((u) => {
    if (!Et(u))
      return u;
    const m = c.find(
      (f) => f.commentId === u.id
    );
    return m ? ft({
      id: m.commentId,
      anchor: {
        ...u.anchor,
        start: oe(m.start),
        end: oe(m.end),
        quote: m.quote,
        beforeQuote: m.beforeQuote,
        afterQuote: m.afterQuote
      },
      resolved: m.resolved,
      payload: u.payload
    }) : u;
  }), d = new Set(
    n.map((u) => u.id)
  );
  return {
    annotations: [
      ...l,
      ...c.filter((u) => !d.has(u.commentId)).map((u) => {
        const m = s.get(u.commentId);
        return ft({
          id: u.commentId,
          anchor: {
            ...m == null ? void 0 : m.anchor,
            start: oe(u.start),
            end: oe(u.end),
            quote: u.quote,
            beforeQuote: u.beforeQuote,
            afterQuote: u.afterQuote
          },
          resolved: u.resolved,
          payload: m == null ? void 0 : m.payload
        });
      })
    ]
  };
}, zd = (e, t) => Bd(e, t.annotations), _d = (e) => ({
  annotations: bn(e == null ? void 0 : e.annotations)
}), rf = (e, t) => K({
  ...e,
  annotations: t.annotations
}), Xr = (e) => ["auto", "scroll", "overlay"].includes(e), Pd = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return !1;
  const t = window.getComputedStyle(e);
  return (Xr(t.overflowY) || Xr(t.overflow)) && e.scrollHeight > e.clientHeight + 1;
}, Fd = (e) => {
  if (!e || typeof document > "u")
    return null;
  let t = e.parentElement;
  for (; t && !(t === document.body || t === document.documentElement); ) {
    if (Pd(t))
      return t;
    const r = t.parentElement;
    t = r instanceof HTMLElement ? r : null;
  }
  return null;
}, Hd = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 0;
  const t = window.getComputedStyle(e), r = Number.parseFloat(t.scrollPaddingTop || "0") || 0, n = Number.parseFloat(t.paddingTop || "0") || 0;
  return r || n;
}, Vd = (e, { align: t = "nearest", scrollBehavior: r = "smooth" }) => {
  var c, l;
  if (!e)
    return;
  const n = Fd(e);
  if (!n) {
    (c = e.scrollIntoView) == null || c.call(e, {
      block: t,
      behavior: r
    });
    return;
  }
  const o = e.getBoundingClientRect(), s = n.getBoundingClientRect(), i = Hd(n);
  let a = n.scrollTop;
  if (t === "center")
    a += o.top - s.top - (s.height - o.height) / 2;
  else if (t === "start")
    a += o.top - s.top - i;
  else if (o.top < s.top + i)
    a += o.top - s.top - i;
  else if (o.bottom > s.bottom)
    a += o.bottom - s.bottom;
  else
    return;
  (l = n.scrollTo) == null || l.call(n, {
    top: Math.max(a, 0),
    behavior: r
  }), typeof n.scrollTo != "function" && (n.scrollTop = Math.max(a, 0));
}, nf = (e, t) => {
  var r;
  return ((r = le(e, t)) == null ? void 0 : r.dom) ?? null;
}, of = (e, t, r = {}) => {
  const n = le(e, t);
  if (!n)
    return !1;
  const o = e.state.doc.nodeAt(
    n.pos
  ), s = te(e, t, 0) ?? n.pos, i = Math.min(
    Math.max(s, 0),
    e.state.doc.content.size
  ), a = o && (o.isAtom || o.isLeaf) && n.textLength === 0 ? e.state.tr.setSelection(
    Es.create(e.state.doc, n.pos)
  ) : e.state.tr.setSelection(
    vn.near(e.state.doc.resolve(i))
  );
  return e.view.dispatch(a), r.focus !== !1 && e.view.focus(), Vd(n.dom, r), !0;
}, jd = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Ud = (e) => e.documentValue ? "document" : e.contentType ?? (Ot(e.modelValue) ? "document" : "html"), To = (e) => JSON.parse(JSON.stringify(e)), We = (e, t) => ({
  content: e.content,
  sourceType: e.sourceType === "html" || e.sourceType === "markdown" || e.sourceType === "json" || e.sourceType === "document" ? e.sourceType : t,
  document: e.document
}), Jr = (e, t) => {
  const r = To(e.body.content);
  return Vt(
    qd(r, t),
    e,
    e.meta
  );
}, qd = (e, t) => Lt(e, t).content, sf = (e, t = {}, r) => We(
  Jn(e, { meta: t, stableBlockIdentity: r }),
  "html"
), Kd = (e, t = {}, r, n) => We(
  Fi(e, {
    baseDocument: r,
    meta: t,
    stableBlockIdentity: n
  }),
  "json"
), af = (e) => {
  const t = Ud(e), r = (n) => {
    const o = To(n.body.content);
    return e.hydrateAnnotations ? zd(
      o,
      _d(n)
    ) : o;
  };
  if (e.documentValue) {
    const n = Jr(
      St(e.documentValue).document,
      e.stableBlockIdentity
    );
    return {
      content: r(n),
      sourceType: "document",
      document: n
    };
  }
  switch (t) {
    case "markdown":
      return We(
        ji(
          typeof e.modelValue == "string" ? e.modelValue : "",
          {
            baseDocument: e.baseDocument,
            stableBlockIdentity: e.stableBlockIdentity
          }
        ),
        "markdown"
      );
    case "json":
      return Kd(
        jd(e.modelValue) ? e.modelValue : { type: "doc", content: [] },
        {},
        e.baseDocument,
        e.stableBlockIdentity
      );
    case "document": {
      const n = Jr(
        St(e.documentValue ?? e.modelValue).document,
        e.stableBlockIdentity
      );
      return {
        content: r(n),
        sourceType: t,
        document: n
      };
    }
    case "html":
    default: {
      const n = typeof e.content == "string" ? e.content : typeof e.modelValue == "string" ? e.modelValue : "";
      return We(
        Jn(n, {
          baseDocument: e.baseDocument,
          stableBlockIdentity: e.stableBlockIdentity
        }),
        "html"
      );
    }
  }
}, Wd = (e, t, r = {}) => {
  const n = Ne(
    "text-editor:document-build",
    "buildEditorDocument",
    {
      hasBaseDocument: !!t
    }
  ), o = Ne(
    "text-editor:document-build",
    "editor.getJSON"
  ), s = e.getJSON();
  o == null || o.end({
    topLevelNodes: Array.isArray(s.content) ? s.content.length : 0
  });
  const i = Ne(
    "text-editor:document-build",
    "buildDocumentFromJSONContent"
  ), a = Li(s, t);
  return i == null || i.end({
    assetCount: a.assets.length,
    annotationCount: a.annotations.length
  }), n == null || n.end({
    topLevelNodes: Array.isArray(a.body.content.content) ? a.body.content.content.length : 0
  }), a;
}, cf = (e, t) => {
  const r = Ne(
    "text-editor:export",
    `exportEditorValue(${t.outputType})`
  ), n = t.document ?? Wd(e, t.document, {
    markdownExportMode: t.markdownExportMode
  });
  let o;
  switch (t.outputType) {
    case "html":
      o = ql(n);
      break;
    case "json":
      o = e.getJSON();
      break;
    case "markdown":
      o = Dd(n, {
        mode: t.markdownExportMode
      });
      break;
    case "document":
      o = n;
      break;
  }
  return r == null || r.end({
    outputType: t.outputType,
    outputSize: typeof o == "string" ? o.length : "body" in o ? Array.isArray(o.body.content.content) ? o.body.content.content.length : 0 : Array.isArray(o.content) ? o.content.length : 0
  }), o;
}, Dt = (e) => {
  var t;
  return (t = e == null ? void 0 : e.extensionManager) == null ? void 0 : t.extensions.find(
    (r) => r.name === "stableBlockIdentity"
  );
}, Gd = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.stableBlockIdentityDiagnostics;
}, Xd = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.stableBlockIdentityEngine;
}, Jd = (e) => {
  var r, n;
  const t = (n = (r = Dt(e)) == null ? void 0 : r.options) == null ? void 0 : n.types;
  return Array.isArray(t) && t.length > 0 ? [.../* @__PURE__ */ new Set([...Ve, ...t])] : [...Ve];
}, Yd = (e) => {
  var t;
  return !!((t = e == null ? void 0 : e.extensionManager) != null && t.extensions.some(
    (r) => r.name === "collaboration" || r.name === "collaborationCursor"
  ));
}, Zd = (e) => e ? ht(
  e.state.doc,
  Jd(e),
  e.view
) : [], Qd = (e) => {
  var t, r;
  return ((t = Xd(e)) == null ? void 0 : t.lastRepair) ?? ((r = Gd(e)) == null ? void 0 : r.lastRepair) ?? null;
}, eu = (e) => {
  const t = [];
  return e.version !== pt && t.push({
    code: "document-version-mismatch",
    message: `Document version ${e.version} does not match runtime version ${pt}.`,
    severity: "error",
    source: "document"
  }), e.body.format !== "json" && t.push({
    code: "document-format-mismatch",
    message: `Document body format "${e.body.format}" is not canonical json.`,
    severity: "error",
    source: "document"
  }), e.meta.schemaVersion !== gt && t.push({
    code: "document-schema-version-mismatch",
    message: `Document schemaVersion "${e.meta.schemaVersion ?? "missing"}" does not match "${gt}".`,
    severity: "warning",
    source: "document"
  }), t;
}, tu = (e) => {
  const t = ue(e.body.content), r = Array.from(t.values()).sort(
    (o, s) => o.pos - s.pos
  ), n = new Map(
    r.map((o, s) => [o.blockId, s])
  );
  return e.annotations.reduce((o, s) => {
    const i = s.anchor.start, a = s.anchor.end, c = t.get(i.blockId), l = t.get(a.blockId), d = n.get(i.blockId), u = n.get(a.blockId);
    return !c || !l || d === void 0 || u === void 0 ? (o.push({
      code: "annotation-unresolved",
      message: `Annotation "${s.id}" references missing block anchors.`,
      severity: "warning",
      source: "annotation",
      annotationId: s.id,
      blockId: c ? a.blockId : i.blockId
    }), o) : ((i.offset < 0 || a.offset < 0 || i.offset > c.textLength || a.offset > l.textLength || d > u || i.blockId === a.blockId && i.offset >= a.offset) && o.push({
      code: "annotation-unresolved",
      message: `Annotation "${s.id}" has an invalid block anchor range.`,
      severity: "warning",
      source: "annotation",
      annotationId: s.id,
      blockId: i.blockId
    }), o);
  }, []);
}, ru = (e) => e.map((t) => ({
  code: t.code,
  message: t.message,
  severity: "warning",
  source: "stable-block-identity",
  blockId: t.blockId,
  pos: t.pos
})), nu = (e) => e.reduce(
  (t, r) => (t[r.code] = (t[r.code] ?? 0) + 1, t),
  {}
), ou = ({
  document: e,
  editor: t
}) => {
  var a, c;
  const r = Zd(t), n = [
    ...eu(e),
    ...ru(r),
    ...tu(e)
  ], o = e.meta.schemaVersion ?? null, s = e.body.format ?? null, i = e.version === pt && s === "json" && o === gt;
  return {
    document: {
      version: e.version,
      format: s,
      schemaVersion: o,
      canonical: i,
      migrationState: i ? "ready" : "invalid"
    },
    collaboration: {
      enabled: Yd(t),
      filterRemoteTransactions: ((c = (a = Dt(t)) == null ? void 0 : a.options) == null ? void 0 : c.filterRemoteTransactions) ?? !0
    },
    stableBlockIdentity: {
      enabled: !!Dt(t),
      issueCount: r.length,
      issues: r,
      lastRepair: Qd(t)
    },
    annotations: {
      total: e.annotations.length,
      unresolvedCount: n.filter(
        (l) => l.code === "annotation-unresolved"
      ).length
    },
    diagnostics: {
      total: n.length,
      counts: nu(n),
      issues: n
    }
  };
}, lf = (e) => ou(e).diagnostics.issues;
function su(e) {
  const t = e.indexOf("?");
  if (t === -1) return null;
  const r = e.slice(t + 1);
  if (!r) return null;
  const n = r.split("&");
  for (const o of n) {
    const [s, i] = o.split("=");
    if (s === "embed_name" && i)
      return decodeURIComponent(i);
  }
  return null;
}
const df = Qe.create({
  name: "mediaDownload",
  addStorage() {
    return {
      embedUrls: []
    };
  },
  addCommands() {
    return {
      getEmbedUrls: () => ({ editor: e }) => {
        const t = [];
        let r = null, n = 0;
        return e.state.doc.descendants((o) => {
          if (o.type.name === "heading" && (n = 0, r = o.textContent.trim()), (o.type.name === "image" || o.type.name === "video") && o.attrs.src) {
            const s = o.attrs.src;
            t.push({
              title: (r || "") + (n ? ` (${n})` : ""),
              name: su(s),
              url: s
            }), n++;
          }
          return !0;
        }), this.storage.embedUrls = t, t;
      }
    };
  }
});
function Le(e, t) {
  let r = 0, n = null, o = null;
  const s = ((...i) => {
    const a = Date.now(), c = t - (a - r);
    o = i, c <= 0 ? (n && (clearTimeout(n), n = null), r = a, e(...i)) : n || (n = setTimeout(() => {
      r = Date.now(), n = null, o && e(...o);
    }, c));
  });
  return s.flush = () => {
    n && (clearTimeout(n), n = null), o && (r = Date.now(), e(...o), o = null);
  }, s;
}
const au = (e) => {
  const t = document.createElement("span");
  t.classList.add(lr("text-editor-collaboration", "cursor")), t.style.borderColor = e.color;
  const r = document.createElement("div");
  return r.classList.add(lr("text-editor-collaboration", "label")), r.style.backgroundColor = e.color, r.textContent = e.name, t.appendChild(r), t;
};
function Yr(e) {
  return e ? Array.from(e.states.entries()).map(([t, r]) => ({
    ...r.user,
    clientId: t
  })).filter((t) => t.name) : [];
}
const uf = Qe.create({
  name: "collaborationCursor",
  priority: 999,
  addOptions() {
    return {
      awareness: null,
      user: { name: "Anonymous", color: "gray" },
      render: au,
      yCursorPlugin: void 0,
      cursorThrottleMs: 50,
      selectionThrottleMs: 100
    };
  },
  addStorage() {
    const e = this.options.cursorThrottleMs ?? 50, t = this.options.selectionThrottleMs ?? 100, r = Le((o) => {
      var s;
      (s = this.options.awareness) == null || s.setLocalStateField("cursor", o);
    }, e), n = Le((o) => {
      var s;
      (s = this.options.awareness) == null || s.setLocalStateField("selection", o);
    }, t);
    return {
      users: [],
      available: !1,
      cleanup: null,
      throttledCursorUpdate: r,
      throttledSelectionUpdate: n
    };
  },
  onCreate() {
    if (!this.options.awareness)
      return;
    if (this.storage.available = !0, this.options.awareness.setLocalStateField("user", this.options.user), !this.storage.throttledCursorUpdate) {
      const t = this.options.cursorThrottleMs ?? 50;
      this.storage.throttledCursorUpdate = Le((r) => {
        var n;
        (n = this.options.awareness) == null || n.setLocalStateField("cursor", r);
      }, t);
    }
    if (!this.storage.throttledSelectionUpdate) {
      const t = this.options.selectionThrottleMs ?? 100;
      this.storage.throttledSelectionUpdate = Le((r) => {
        var n;
        (n = this.options.awareness) == null || n.setLocalStateField("selection", r);
      }, t);
    }
    const e = () => {
      this.storage.users = Yr(this.options.awareness);
    };
    this.options.awareness.on("update", e), this.storage.users = Yr(this.options.awareness), this.storage.cleanup = () => {
      var n, o, s;
      (n = this.options.awareness) == null || n.off("update", e);
      const t = this.storage.throttledCursorUpdate, r = this.storage.throttledSelectionUpdate;
      (o = t == null ? void 0 : t.flush) == null || o.call(t), (s = r == null ? void 0 : r.flush) == null || s.call(r);
    };
  },
  onDestroy() {
    var r, n, o, s;
    const e = this.storage.throttledCursorUpdate, t = this.storage.throttledSelectionUpdate;
    (r = e == null ? void 0 : e.flush) == null || r.call(e), (n = t == null ? void 0 : t.flush) == null || n.call(t), (s = (o = this.storage).cleanup) == null || s.call(o), this.storage.cleanup = null;
  },
  addCommands() {
    return {
      updateUser: (e) => () => {
        var t;
        return this.options.user = { ...this.options.user, ...e }, (t = this.options.awareness) == null || t.setLocalStateField("user", this.options.user), !0;
      },
      /**
       * Update cursor position with throttling
       */
      updateCursor: (e) => () => {
        var t;
        return this.storage.throttledCursorUpdate ? this.storage.throttledCursorUpdate(e) : (t = this.options.awareness) == null || t.setLocalStateField("cursor", e), !0;
      },
      /**
       * Update selection with throttling
       */
      updateSelection: (e) => () => {
        var t;
        return this.storage.throttledSelectionUpdate ? this.storage.throttledSelectionUpdate(e) : (t = this.options.awareness) == null || t.setLocalStateField("selection", e), !0;
      }
    };
  },
  addProseMirrorPlugins() {
    if (!this.options.awareness) return [];
    const e = this.options.awareness, t = this.options.render;
    if (this.options.yCursorPlugin)
      return [
        this.options.yCursorPlugin(e, {
          cursorBuilder: t
        })
      ];
    try {
      const r = globalThis.__yProsemirror;
      if (r != null && r.yCursorPlugin)
        return [
          r.yCursorPlugin(e, {
            cursorBuilder: t
          })
        ];
    } catch {
    }
    return [];
  }
}), mf = Qe.create({
  name: "autoLink",
  addProseMirrorPlugins() {
    return [
      new yn({
        key: new kn("autoLink"),
        props: {
          handlePaste: (e, t) => {
            var d, u;
            const r = (d = t.clipboardData) == null ? void 0 : d.getData("text/plain");
            if (!r) return !1;
            const n = r.trim();
            if (n.includes(`
`) || n.includes("\r") || !ms(n))
              return !1;
            const { state: o } = e, { selection: s } = o, { empty: i, from: a, to: c } = s, l = fs(n);
            if (i) {
              const m = (u = o.schema.marks.link) == null ? void 0 : u.create({ href: l });
              if (!m) return !1;
              const f = o.schema.text(n, [m]), h = o.tr.replaceSelectionWith(f, !1);
              return h.setSelection(
                vn.near(h.doc.resolve(a + n.length))
              ), e.dispatch(h), !0;
            } else
              return !1;
          }
        }
      })
    ];
  }
}), iu = (e) => ({
  start: {
    blockId: e.start.blockId,
    offset: e.start.offset
  },
  end: {
    blockId: e.end.blockId,
    offset: e.end.offset
  },
  quote: e.quote,
  beforeQuote: e.beforeQuote,
  afterQuote: e.afterQuote
}), ie = (e) => {
  switch (e.kind) {
    case "heading":
      return {
        kind: "heading",
        blockId: e.blockId
      };
    case "block":
      return {
        kind: "block",
        blockId: e.blockId,
        offset: e.offset
      };
    case "bookmark":
      return {
        kind: "bookmark",
        bookmarkId: e.bookmarkId
      };
    case "annotation":
      return {
        kind: "annotation",
        annotationId: e.annotationId
      };
    case "search-hit":
      return {
        kind: "search-hit",
        hitId: e.hitId
      };
    case "ai-suggestion":
      return {
        kind: "ai-suggestion",
        suggestionId: e.suggestionId
      };
    case "presence":
      return {
        kind: "presence",
        presenceId: e.presenceId
      };
    case "range":
      return {
        kind: "range",
        anchor: iu(e.anchor)
      };
  }
}, Q = (e) => ({
  source: e.source,
  target: ie(e.target),
  align: e.align,
  behavior: e.behavior,
  focusMode: e.focusMode,
  history: e.history,
  reason: e.reason
}), cu = (e) => ({
  key: e.key,
  kind: e.kind,
  label: e.label,
  blockId: e.blockId,
  outlineEligible: e.outlineEligible,
  shareable: e.shareable
}), sr = (e) => ({
  mode: e.mode,
  topInset: e.topInset,
  hasTrailingSpacer: e.hasTrailingSpacer,
  spacerHeight: e.spacerHeight
}), xo = (e) => ({
  status: e.status,
  targetOffset: e.targetOffset,
  expectedOffset: e.expectedOffset
}), ve = (e) => ({
  requestId: e.requestId,
  status: e.status,
  target: ie(e.target),
  resolvedTargetKey: e.resolvedTargetKey,
  phase: e.phase,
  reason: e.reason,
  settle: e.settle ? xo(e.settle) : null
}), Ge = (e) => ie(e), Rt = (e) => ({
  phase: e.phase,
  activeReadingHeadingId: e.activeReadingHeadingId,
  pendingRequest: e.pendingRequest ? Q(e.pendingRequest) : null,
  lastSettledTarget: e.lastSettledTarget ? ie(e.lastSettledTarget) : null,
  lastResult: e.lastResult ? ve(e.lastResult) : null,
  shareableTarget: e.shareableTarget ? Ge(e.shareableTarget) : null,
  viewport: e.viewport ? sr(e.viewport) : null
}), lt = (e = {}) => ({
  phase: e.phase ?? "idle",
  activeReadingHeadingId: e.activeReadingHeadingId ?? null,
  pendingRequest: e.pendingRequest ? Q(e.pendingRequest) : null,
  lastSettledTarget: e.lastSettledTarget ? ie(e.lastSettledTarget) : null,
  lastResult: e.lastResult ? ve(e.lastResult) : null,
  shareableTarget: e.shareableTarget ? Ge(e.shareableTarget) : null,
  viewport: e.viewport ? sr(e.viewport) : null
}), lu = (e = {}) => {
  let t = lt(e);
  const r = /* @__PURE__ */ new Set(), n = () => {
    const o = Rt(t);
    r.forEach((s) => s(o));
  };
  return {
    getSnapshot() {
      return Rt(t);
    },
    setSnapshot(o) {
      t = lt(o), n();
    },
    patchSnapshot(o) {
      t = lt({
        ...t,
        ...o
      }), n();
    },
    subscribe(o) {
      return r.add(o), () => {
        r.delete(o);
      };
    }
  };
}, Xe = "#nav=", Te = (e) => typeof e == "string" && e.length > 0, Zr = (e) => encodeURIComponent(e), du = (e) => {
  try {
    const t = decodeURIComponent(e);
    return Te(t) ? t : null;
  } catch {
    return null;
  }
}, ar = (e) => e.kind === "heading" && Te(e.blockId) ? `${Xe}heading:${Zr(
  e.blockId
)}` : e.kind === "bookmark" && Te(e.bookmarkId) ? `${Xe}bookmark:${Zr(
  e.bookmarkId
)}` : null, uu = (e) => {
  if (!Te(e))
    return null;
  const t = e.startsWith("#") ? e : `#${e}`;
  if (!t.startsWith(Xe))
    return null;
  const r = t.slice(Xe.length), n = r.indexOf(":");
  if (n <= 0)
    return null;
  const o = r.slice(0, n), s = du(r.slice(n + 1));
  return Te(s) ? o === "heading" ? {
    kind: "heading",
    blockId: s
  } : o === "bookmark" ? {
    kind: "bookmark",
    bookmarkId: s
  } : null : null;
}, mu = (e) => typeof e == "string" ? e : typeof window > "u" ? null : window.location.hash || null, fu = (e, t) => {
  if (typeof window > "u")
    return;
  const r = new URL(window.location.href);
  if (r.hash = t, e === "push") {
    window.history.pushState(window.history.state, "", r.toString());
    return;
  }
  window.history.replaceState(window.history.state, "", r.toString());
}, pu = () => ({
  sync(e) {
    if (e.request.history !== "push" && e.request.history !== "replace")
      return;
    const t = e.shareableTarget ? ar(e.shareableTarget) : null;
    t && fu(e.request.history, t);
  }
}), wo = "data-zx-navigation-spacer", gu = (e) => typeof HTMLElement < "u" && e instanceof HTMLElement, Eo = (e) => {
  if (!e)
    return null;
  const t = e.querySelector(
    `[${wo}]`
  );
  return gu(t) ? t : null;
}, Qr = (e) => {
  if (!e)
    return;
  const t = Eo(e);
  (t == null ? void 0 : t.parentElement) === e && e.removeChild(t);
}, hu = (e, t) => {
  e.style.display = "block", e.style.height = `${t}px`, e.style.pointerEvents = "none", e.style.flexShrink = "0";
}, bu = (e) => {
  const { contentRoot: t } = e;
  if (!t)
    return {
      ...e,
      hasTrailingSpacer: !1,
      spacerHeight: 0
    };
  const r = Math.max(0, e.viewportHeight - e.topInset);
  let n = Eo(t);
  return n || (n = document.createElement("div"), n.setAttribute(wo, ""), t.appendChild(n)), hu(n, r), {
    ...e,
    hasTrailingSpacer: !0,
    spacerHeight: r
  };
}, en = (e) => ["auto", "scroll", "overlay"].includes(e), Co = (e) => typeof HTMLElement < "u" && e instanceof HTMLElement, me = (e) => typeof window < "u" && e === window, dt = (e) => typeof e == "function" ? e() ?? null : e ?? null, yu = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return !1;
  const t = window.getComputedStyle(e);
  return (en(t.overflowY) || en(t.overflow)) && e.scrollHeight > e.clientHeight + 1;
}, ku = (e) => {
  if (!e || typeof document > "u")
    return null;
  let t = e.parentElement;
  for (; t; ) {
    const r = t;
    if (r === document.body || r === document.documentElement)
      break;
    if (yu(r))
      return r;
    const n = r.parentElement;
    t = n instanceof HTMLElement ? n : null;
  }
  return null;
}, vu = (e, t, r) => {
  if (r != null && Number.isFinite(r))
    return Math.max(r, 0);
  if (typeof window > "u" || typeof window.getComputedStyle != "function")
    return 0;
  const n = me(e) ? t ?? document.documentElement : e;
  if (!Co(n))
    return 0;
  const o = window.getComputedStyle(n), s = Number.parseFloat(o.scrollPaddingTop || "0") || 0, i = Number.parseFloat(o.paddingTop || "0") || 0;
  return Math.max(s || i, 0);
}, Do = (e) => me(e) ? e.innerHeight || document.documentElement.clientHeight || document.body.clientHeight || 0 : e.clientHeight, Ro = (e) => {
  if (me(e)) {
    const t = Do(e);
    return {
      x: 0,
      y: 0,
      top: 0,
      bottom: t,
      left: 0,
      right: window.innerWidth || document.documentElement.clientWidth || 0,
      width: window.innerWidth || document.documentElement.clientWidth || 0,
      height: t,
      toJSON: () => ({})
    };
  }
  return e.getBoundingClientRect();
}, Je = (e) => me(e) ? e.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0 : e.scrollTop, Su = (e) => me(e) ? Math.max(
  document.documentElement.scrollHeight,
  document.body.scrollHeight
) : e.scrollHeight, Iu = (e, t) => t || ((e == null ? void 0 : e.closest(".ProseMirror")) ?? (e == null ? void 0 : e.parentElement) ?? null), Tu = ({
  align: e,
  viewport: t,
  targetRect: r
}) => {
  const n = Ro(t.scrollContainer), o = Je(t.scrollContainer);
  if (e === "center")
    return o + (r.top - n.top) - (n.height - r.height) / 2;
  if (e === "nearest") {
    const s = n.top + t.topInset;
    return r.top < s ? o + (r.top - s) : r.bottom > n.bottom ? o + (r.bottom - n.bottom) : o;
  }
  return o + (r.top - n.top - t.topInset);
}, xu = (e, t) => {
  const r = Math.max(
    0,
    Su(e.scrollContainer) - e.viewportHeight
  );
  return Math.min(Math.max(t, 0), r);
}, Ao = (e, t, r) => {
  if (me(e.scrollContainer)) {
    e.scrollContainer.scrollTo({
      top: t,
      behavior: r
    });
    return;
  }
  if (typeof e.scrollContainer.scrollTo == "function") {
    e.scrollContainer.scrollTo({
      top: t,
      behavior: r
    });
    return;
  }
  e.scrollContainer.scrollTop = t;
}, tn = (e) => {
  if (e.request.focusMode === "preserve")
    return;
  const t = e.resolvedTarget.dom;
  if (e.request.focusMode === "editor") {
    const n = t == null ? void 0 : t.closest(".ProseMirror");
    Co(n) && typeof n.focus == "function" && n.focus();
    return;
  }
  if (!t || typeof t.focus != "function")
    return;
  let r = !1;
  t.hasAttribute("tabindex") || (t.setAttribute("tabindex", "-1"), r = !0), t.focus(), r && t.removeAttribute("tabindex");
}, wu = () => new Promise((e) => {
  if (typeof window < "u" && typeof window.requestAnimationFrame == "function") {
    window.requestAnimationFrame(() => e());
    return;
  }
  setTimeout(e, 16);
}), Mo = async (e, t, r = 2) => {
  let n = Je(e.scrollContainer), o = 0;
  for (; !t.aborted; ) {
    await wu();
    const s = Je(e.scrollContainer);
    if (Math.abs(s - n) <= 1 ? o += 1 : o = 0, n = s, o >= r)
      return;
  }
}, Eu = async ({
  clampedTop: e,
  context: t,
  settle: r,
  viewport: n
}) => {
  if (t.request.behavior !== "smooth" || (r == null ? void 0 : r.status) !== "constrained")
    return r;
  const o = Je(n.scrollContainer);
  return Math.abs(o - e) <= 1 || (Ao(n, e, "auto"), await Mo(n, t.signal), t.signal.aborted) ? r : Oo(n, t);
}, Cu = (e) => new Promise((t) => {
  if (typeof document > "u") {
    t(null);
    return;
  }
  const r = () => {
    document.removeEventListener("wheel", n, !0), document.removeEventListener("touchstart", n, !0), document.removeEventListener("keydown", n, !0), e.removeEventListener("abort", o);
  }, n = () => {
    r(), t("user-interrupted");
  }, o = () => {
    r(), t(null);
  };
  document.addEventListener("wheel", n, !0), document.addEventListener("touchstart", n, !0), document.addEventListener("keydown", n, !0), e.addEventListener("abort", o, { once: !0 });
}), Oo = (e, t) => {
  const r = t.resolvedTarget.dom;
  if (!r)
    return null;
  const n = Ro(e.scrollContainer), o = r.getBoundingClientRect();
  if (t.request.align === "center") {
    const a = (n.height - o.height) / 2, c = o.top - n.top;
    return {
      status: Math.abs(c - a) <= 2 ? "aligned" : "constrained",
      targetOffset: c,
      expectedOffset: a
    };
  }
  if (t.request.align === "nearest") {
    const a = e.topInset, c = o.top - n.top;
    return {
      status: o.top >= n.top + e.topInset - 2 && o.bottom <= n.bottom + 2 ? "aligned" : "constrained",
      targetOffset: c,
      expectedOffset: a
    };
  }
  const s = e.topInset, i = o.top - n.top;
  return {
    status: Math.abs(i - s) <= 2 ? "aligned" : "constrained",
    targetOffset: i,
    expectedOffset: s
  };
}, Y = (e) => e ? {
  mode: e.mode,
  topInset: e.topInset,
  hasTrailingSpacer: e.hasTrailingSpacer,
  spacerHeight: e.spacerHeight
} : null, Du = (e = {}) => ({ resolvedTarget: t }) => {
  const r = dt(e.scrollContainer), n = dt(e.contentRoot), o = dt(e.topInset), s = t.dom, i = ku(s), a = r ?? i ?? (typeof window < "u" ? window : null);
  if (!a)
    return null;
  const c = Iu(s, n), l = vu(
    a,
    c,
    o
  );
  return {
    scrollContainer: a,
    contentRoot: c,
    topInset: l,
    mode: me(a) ? "window" : "element",
    viewportHeight: Do(a),
    hasTrailingSpacer: !1,
    spacerHeight: 0
  };
}, Ru = async (e) => {
  const t = e.resolvedTarget.dom;
  if (!e.viewport || !t)
    return tn(e), {
      status: "completed",
      lastSettledTarget: e.resolvedTarget.target,
      shareableTarget: e.resolvedTarget.target.kind === "heading" || e.resolvedTarget.target.kind === "bookmark" ? e.resolvedTarget.target : null,
      viewport: e.viewport,
      settle: null
    };
  const r = bu(e.viewport), n = Tu({
    align: e.request.align,
    viewport: r,
    targetRect: t.getBoundingClientRect()
  }), o = xu(r, n);
  tn(e), Ao(r, o, e.request.behavior ?? "smooth");
  const s = Cu(e.signal), i = Mo(r, e.signal);
  if (await Promise.race([
    s,
    i.then(() => null)
  ]) === "user-interrupted")
    return {
      status: "cancelled",
      reason: "user-interrupted",
      viewport: r
    };
  if (e.signal.aborted)
    return {
      status: "cancelled",
      reason: "user-interrupted",
      viewport: r
    };
  const c = await Eu({
    clampedTop: o,
    context: e,
    settle: Oo(r, e),
    viewport: r
  });
  return {
    status: "completed",
    lastSettledTarget: e.resolvedTarget.target,
    shareableTarget: e.resolvedTarget.target.kind === "heading" || e.resolvedTarget.target.kind === "bookmark" ? e.resolvedTarget.target : null,
    viewport: r,
    settle: c
  };
}, Au = /* @__PURE__ */ (() => {
  let e = 0;
  return () => (e += 1, `navigation-request-${e}`);
})(), Mu = (e) => ({
  source: e.source,
  target: ie(e.target),
  align: e.align ?? "start",
  behavior: e.behavior ?? "smooth",
  focusMode: e.focusMode ?? "preserve",
  history: e.history ?? "none",
  reason: e.reason
}), $o = (e) => e.kind === "heading" || e.kind === "bookmark", Z = ({
  requestId: e,
  request: t,
  status: r,
  phase: n,
  resolvedTarget: o,
  reason: s,
  settle: i
}) => ({
  requestId: e,
  status: r,
  target: ie(t.target),
  resolvedTargetKey: o == null ? void 0 : o.key,
  phase: n,
  reason: s,
  settle: i ? xo(i) : null
}), Ou = (e, t) => ({
  ...t,
  lastSettledTarget: t.lastSettledTarget ?? e.target,
  shareableTarget: t.shareableTarget === void 0 ? $o(e.target) ? e.target : null : t.shareableTarget
}), ff = (e = {}) => {
  var I, w;
  const t = e.state ?? lu(), r = e.createRequestId ?? Au, n = e.resolver ?? (async () => ({
    status: "failed",
    reason: "target-unavailable"
  })), o = e.descriptorReader ?? (async () => []), s = e.viewportResolver ?? Du(e.viewportOptions), i = e.executor ?? (async (p) => Ou(
    p.resolvedTarget,
    await Ru(p)
  )), a = e.historyAdapter ?? pu(), c = e.observer;
  let l = null, d = null, u = null;
  const m = (p) => {
    t.patchSnapshot(p);
  }, f = (I = c == null ? void 0 : c.subscribe) == null ? void 0 : I.call(c, (p) => {
    m({
      activeReadingHeadingId: p
    });
  }), h = (w = c == null ? void 0 : c.getActiveReadingHeadingId) == null ? void 0 : w.call(c);
  h !== void 0 && m({
    activeReadingHeadingId: h
  });
  const k = (p) => {
    u && u !== p && Qr(u), u = p ?? null;
  }, b = (p, g, x) => {
    if (p.finished)
      return ve(g);
    p.finished = !0, (l == null ? void 0 : l.requestId) === p.requestId && (l = null), m({
      pendingRequest: null,
      ...x,
      lastResult: g
    });
    const O = ve(g);
    return p.resolveResult(O), O;
  }, R = (p = "user-interrupted") => {
    if (!l)
      return;
    const g = l;
    g.signal.abort();
    const x = Z({
      requestId: g.requestId,
      request: g.request,
      status: "cancelled",
      phase: "cancelled",
      reason: p
    });
    b(g, x, {
      phase: "cancelled"
    });
  }, T = (p = "user-interrupted") => {
    if (!d)
      return;
    const g = d;
    d = null, m({
      phase: "cancelled",
      pendingRequest: null,
      lastResult: Z({
        requestId: g.requestId,
        request: g.request,
        status: "cancelled",
        phase: "cancelled",
        reason: p
      })
    });
  }, y = (p) => {
    R("superseded"), T("superseded");
    const g = Mu(p), x = r();
    let O;
    const $ = new Promise((A) => {
      O = A;
    }), E = {
      requestId: x,
      request: g,
      signal: new AbortController(),
      resolveResult: O,
      finished: !1
    };
    return l = E, m({
      phase: "resolving",
      pendingRequest: Q(g)
    }), (async () => {
      var A, P, v;
      try {
        const C = {
          snapshot: t.getSnapshot(),
          signal: E.signal.signal
        }, N = await n(g, C);
        if ((l == null ? void 0 : l.requestId) !== E.requestId || E.signal.signal.aborted)
          return;
        if (N.status === "failed") {
          const G = Z({
            requestId: x,
            request: g,
            status: "failed",
            phase: "failed",
            reason: N.reason
          });
          b(E, G, {
            phase: "failed"
          });
          return;
        }
        if (N.status === "pending") {
          const G = Q(g);
          d = {
            requestId: x,
            request: Q(g)
          }, m({
            phase: "waiting-target",
            pendingRequest: G
          });
          const Lo = Z({
            requestId: x,
            request: g,
            status: "deferred",
            phase: "waiting-target",
            reason: N.reason
          });
          b(E, Lo, {
            phase: "waiting-target",
            pendingRequest: G
          });
          return;
        }
        const V = N.target, _ = t.getSnapshot(), L = await s({
          request: g,
          resolvedTarget: V,
          snapshot: _,
          signal: E.signal.signal
        });
        if ((l == null ? void 0 : l.requestId) !== E.requestId || E.signal.signal.aborted)
          return;
        if (L == null) {
          const G = Z({
            requestId: x,
            request: g,
            status: "failed",
            phase: "failed",
            resolvedTarget: V,
            reason: "viewport-unavailable"
          });
          b(E, G, {
            phase: "failed"
          });
          return;
        }
        m({
          phase: "executing",
          pendingRequest: Q(g),
          viewport: Y(L)
        }), k(L == null ? void 0 : L.contentRoot);
        const M = await i({
          request: g,
          resolvedTarget: V,
          snapshot: t.getSnapshot(),
          viewport: L ?? null,
          signal: E.signal.signal
        });
        if ((l == null ? void 0 : l.requestId) !== E.requestId || E.signal.signal.aborted)
          return;
        if (M.status === "cancelled") {
          const G = Z({
            requestId: x,
            request: g,
            status: "cancelled",
            phase: "cancelled",
            resolvedTarget: V,
            reason: M.reason ?? "user-interrupted",
            settle: M.settle
          });
          b(E, G, {
            phase: "cancelled",
            viewport: M.viewport === void 0 ? Y(L) : Y(M.viewport)
          }), k(
            M.viewport === void 0 ? L == null ? void 0 : L.contentRoot : (A = M.viewport) == null ? void 0 : A.contentRoot
          );
          return;
        }
        if (M.status === "failed") {
          const G = Z({
            requestId: x,
            request: g,
            status: "failed",
            phase: "failed",
            resolvedTarget: V,
            reason: M.reason ?? "target-unavailable",
            settle: M.settle
          });
          b(E, G, {
            phase: "failed",
            viewport: M.viewport === void 0 ? Y(L) : Y(M.viewport)
          }), k(
            M.viewport === void 0 ? L == null ? void 0 : L.contentRoot : (P = M.viewport) == null ? void 0 : P.contentRoot
          );
          return;
        }
        m({
          phase: "settling",
          pendingRequest: Q(g),
          viewport: M.viewport === void 0 ? Y(L) : Y(M.viewport)
        });
        const S = M.shareableTarget === void 0 ? $o(V.target) ? V.target : null : M.shareableTarget, D = M.lastSettledTarget === void 0 ? V.target : M.lastSettledTarget, F = Z({
          requestId: x,
          request: g,
          status: "completed",
          phase: "completed",
          resolvedTarget: V,
          settle: M.settle
        });
        if (b(E, F, {
          phase: "completed",
          lastSettledTarget: D ? ie(D) : null,
          shareableTarget: S ? Ge(S) : null,
          viewport: M.viewport === void 0 ? Y(L) : Y(M.viewport)
        }), k(
          M.viewport === void 0 ? L == null ? void 0 : L.contentRoot : (v = M.viewport) == null ? void 0 : v.contentRoot
        ), a && g.history !== "none" && S)
          try {
            await a.sync({
              request: Q(g),
              result: ve(F),
              shareableTarget: Ge(S),
              snapshot: t.getSnapshot()
            });
          } catch {
          }
      } catch {
        if ((l == null ? void 0 : l.requestId) !== E.requestId || E.signal.signal.aborted)
          return;
        const C = Z({
          requestId: x,
          request: g,
          status: "failed",
          phase: "failed",
          reason: "target-unavailable"
        });
        b(E, C, {
          phase: "failed"
        });
      }
    })(), $;
  };
  return {
    navigate: y,
    cancel(p = "user-interrupted") {
      R(p), T(p);
    },
    getSnapshot() {
      return Rt(t.getSnapshot());
    },
    subscribe(p) {
      return t.subscribe(p);
    },
    async listDescriptors(p) {
      const g = new AbortController();
      try {
        return (await o(
          {
            snapshot: t.getSnapshot(),
            signal: g.signal
          },
          p
        )).map(
          (O) => cu(O)
        );
      } finally {
        g.abort();
      }
    },
    async syncFromLocation(p) {
      const g = uu(
        mu(p)
      );
      return g ? y({
        source: "deep-link",
        target: g,
        history: "none"
      }) : null;
    },
    createShareableFragment(p) {
      return ar(p);
    },
    retryDeferredNavigation() {
      if (l || !d)
        return !1;
      const p = Q(d.request);
      return d = null, y(p), !0;
    },
    destroy() {
      var p;
      R("user-interrupted"), T("user-interrupted"), Qr(u), u = null, f == null || f(), (p = c == null ? void 0 : c.destroy) == null || p.call(c);
    }
  };
}, rn = (e) => {
  if (!e)
    return null;
  switch (e.kind) {
    case "heading":
      return `heading:${e.blockId}`;
    case "block":
      return `block:${e.blockId}${e.offset != null ? `@${e.offset}` : ""}`;
    case "bookmark":
      return `bookmark:${e.bookmarkId}`;
    case "annotation":
      return `annotation:${e.annotationId}`;
    case "search-hit":
      return `search-hit:${e.hitId}`;
    case "ai-suggestion":
      return `ai-suggestion:${e.suggestionId}`;
    case "presence":
      return `presence:${e.presenceId}`;
    case "range":
      return `range:${e.anchor.start.blockId}:${e.anchor.start.offset}-${e.anchor.end.blockId}:${e.anchor.end.offset}`;
  }
}, pf = (e) => {
  var t, r, n, o;
  return {
    phase: e.phase,
    activeReadingHeadingId: e.activeReadingHeadingId,
    pendingSource: ((t = e.pendingRequest) == null ? void 0 : t.source) ?? null,
    pendingTarget: rn((r = e.pendingRequest) == null ? void 0 : r.target),
    lastSettledTarget: rn(e.lastSettledTarget),
    lastResultStatus: ((n = e.lastResult) == null ? void 0 : n.status) ?? null,
    lastResultReason: ((o = e.lastResult) == null ? void 0 : o.reason) ?? null,
    shareableFragment: e.shareableTarget ? ar(e.shareableTarget) : null,
    viewport: e.viewport ? sr(e.viewport) : null
  };
}, $u = (e) => typeof e == "string" && e.length > 0, Lu = (e) => {
  var r, n;
  return ((n = (r = e.payload.comments[0]) == null ? void 0 : r.content) == null ? void 0 : n.trim()) || e.payload.threadId || e.id;
}, gf = () => ({
  kind: "annotation",
  resolve(e, t) {
    if (!$u(e.annotationId))
      return {
        status: "failed",
        reason: "invalid-target"
      };
    if (!Array.isArray(t.annotations))
      return {
        status: "pending",
        reason: "awaiting-provider"
      };
    const r = t.annotations.find(
      (c) => c.id === e.annotationId
    );
    if (!r)
      return {
        status: "failed",
        reason: "target-unavailable"
      };
    if (!t.editor)
      return {
        status: "pending",
        reason: "awaiting-provider"
      };
    const n = r.anchor.start, o = r.anchor.end, s = le(t.editor, n.blockId), i = te(
      t.editor,
      n.blockId,
      n.offset
    ), a = te(
      t.editor,
      o.blockId,
      o.offset
    );
    return i !== null && a !== null && a > i ? {
      status: "resolved",
      target: {
        key: `annotation:${r.id}`,
        target: e,
        dom: (s == null ? void 0 : s.dom) ?? null,
        blockId: n.blockId,
        anchor: r.anchor,
        pos: i,
        selection: {
          from: i,
          to: a
        }
      }
    } : s ? {
      status: "resolved",
      target: {
        key: `annotation:${r.id}:block`,
        target: e,
        dom: s.dom,
        blockId: n.blockId,
        anchor: r.anchor,
        pos: i ?? s.pos
      }
    } : {
      status: "failed",
      reason: "target-unavailable"
    };
  },
  list(e) {
    return Array.isArray(e.annotations) ? e.annotations.map((t) => ({
      key: `annotation:${t.id}`,
      kind: "annotation",
      label: Lu(t),
      blockId: t.anchor.start.blockId,
      outlineEligible: !1,
      shareable: !1
    })) : [];
  }
}), Nu = (e) => typeof e == "string" && e.length > 0, Bu = (e, t) => {
  if (e.selection || e.pos != null || e.dom)
    return {
      dom: e.dom ?? null,
      blockId: e.blockId,
      pos: e.pos,
      anchor: e.anchor,
      selection: e.selection
    };
  if (e.anchor && t.editor) {
    const r = te(
      t.editor,
      e.anchor.start.blockId,
      e.anchor.start.offset
    ), n = te(
      t.editor,
      e.anchor.end.blockId,
      e.anchor.end.offset
    ), o = le(
      t.editor,
      e.anchor.start.blockId
    );
    if (r !== null && n !== null && n > r)
      return {
        dom: (o == null ? void 0 : o.dom) ?? null,
        blockId: e.anchor.start.blockId,
        pos: r,
        anchor: e.anchor,
        selection: {
          from: r,
          to: n
        }
      };
  }
  if (e.blockId && t.editor) {
    const r = le(t.editor, e.blockId);
    if (r) {
      const n = te(
        t.editor,
        e.blockId,
        e.offset ?? 0
      ) ?? r.pos;
      return {
        dom: r.dom,
        blockId: e.blockId,
        pos: n,
        anchor: e.anchor,
        selection: {
          from: n,
          to: n
        }
      };
    }
  }
  return null;
}, hf = ({
  getBookmarks: e
}) => ({
  kind: "bookmark",
  async resolve(t, r) {
    if (!Nu(t.bookmarkId))
      return {
        status: "failed",
        reason: "invalid-target"
      };
    const n = await e();
    if (!Array.isArray(n))
      return {
        status: "pending",
        reason: "awaiting-provider"
      };
    const o = n.find(
      (i) => i.bookmarkId === t.bookmarkId
    );
    if (!o)
      return {
        status: "failed",
        reason: "target-unavailable"
      };
    const s = Bu(o, r);
    return s ? {
      status: "resolved",
      target: {
        key: `bookmark:${o.bookmarkId}`,
        target: t,
        dom: s.dom,
        blockId: s.blockId,
        anchor: s.anchor,
        pos: s.pos,
        selection: s.selection
      }
    } : {
      status: "pending",
      reason: "awaiting-provider"
    };
  },
  async list() {
    const t = await e();
    return Array.isArray(t) ? t.map((r) => {
      var n;
      return {
        key: `bookmark:${r.bookmarkId}`,
        kind: "bookmark",
        label: r.label,
        blockId: r.blockId ?? ((n = r.anchor) == null ? void 0 : n.start.blockId),
        outlineEligible: !1,
        shareable: !0
      };
    }) : [];
  }
}), zu = (e) => {
  switch (e.kind) {
    case "search-hit":
      return e.hitId;
    case "ai-suggestion":
      return e.suggestionId;
    case "presence":
      return e.presenceId;
  }
}, _u = (e, t) => {
  if (e.selection || e.pos != null || e.dom)
    return {
      dom: e.dom ?? null,
      blockId: e.blockId,
      pos: e.pos,
      anchor: e.anchor,
      selection: e.selection
    };
  if (e.anchor && t.editor) {
    const r = te(
      t.editor,
      e.anchor.start.blockId,
      e.anchor.start.offset
    ), n = te(
      t.editor,
      e.anchor.end.blockId,
      e.anchor.end.offset
    ), o = le(
      t.editor,
      e.anchor.start.blockId
    );
    if (r !== null && n !== null && n > r)
      return {
        dom: (o == null ? void 0 : o.dom) ?? null,
        blockId: e.anchor.start.blockId,
        pos: r,
        anchor: e.anchor,
        selection: {
          from: r,
          to: n
        }
      };
  }
  if (e.blockId && t.editor) {
    const r = le(t.editor, e.blockId);
    if (r) {
      const n = te(
        t.editor,
        e.blockId,
        e.offset ?? 0
      ) ?? r.pos;
      return {
        dom: r.dom,
        blockId: e.blockId,
        pos: n,
        anchor: e.anchor,
        selection: {
          from: n,
          to: n
        }
      };
    }
  }
  return null;
}, bf = ({
  kind: e,
  getEntries: t
}) => ({
  kind: e,
  async resolve(n, o) {
    const s = zu(n);
    if (!s)
      return {
        status: "failed",
        reason: "invalid-target"
      };
    const i = await t();
    if (!Array.isArray(i))
      return {
        status: "pending",
        reason: "awaiting-provider"
      };
    const a = i.find((l) => l.id === s);
    if (!a)
      return {
        status: "failed",
        reason: "target-unavailable"
      };
    const c = _u(a, o);
    return c ? {
      status: "resolved",
      target: {
        key: `${e}:${a.id}`,
        target: n,
        dom: c.dom,
        blockId: c.blockId,
        anchor: c.anchor,
        pos: c.pos,
        selection: c.selection
      }
    } : {
      status: "pending",
      reason: "awaiting-provider"
    };
  },
  async list() {
    const n = await t();
    return Array.isArray(n) ? n.map((o) => {
      var s;
      return {
        key: `${e}:${o.id}`,
        kind: e,
        label: o.label,
        blockId: o.blockId ?? ((s = o.anchor) == null ? void 0 : s.start.blockId),
        outlineEligible: !1,
        shareable: !1
      };
    }) : [];
  }
}), yf = (e) => ({
  getState: e.getState,
  subscribe: e.subscribe,
  invoke(t, r) {
    const n = e.getState(t);
    if (!n.enabled || n.busy)
      return { accepted: !1, reason: n.reason ?? "unavailable" };
    let o;
    try {
      o = e.run(t, r);
    } catch (s) {
      return {
        accepted: !0,
        invocationId: r.invocationId,
        completion: Promise.resolve({ status: "failed", error: s })
      };
    }
    return {
      accepted: !0,
      invocationId: r.invocationId,
      completion: Promise.resolve(o).then(
        (s) => {
          if (s === null)
            return { status: "cancelled", reason: "invocation-unavailable" };
          const i = s && typeof s == "object" && "status" in s ? s.status : void 0;
          return i === "failed" || i === "cancelled" || i === "succeeded" ? s : i === "failure" || i === "unsupported" || i === "fresh-projection-required" ? { status: "failed", error: s } : i === "busy" ? { status: "cancelled", reason: "busy" } : { status: "succeeded", value: s };
        },
        (s) => ({ status: "failed", error: s })
      )
    };
  }
});
export {
  Fi as $,
  mf as A,
  aa as B,
  uf as C,
  fm as D,
  lm as E,
  at as F,
  dm as G,
  um as H,
  mm as I,
  et as J,
  An as K,
  vm as L,
  df as M,
  rt as N,
  Pt as O,
  Tm as P,
  xm as Q,
  Fn as R,
  Oi as S,
  la as T,
  Rm as U,
  vt as V,
  Vt as W,
  Li as X,
  Ni as Y,
  gr as Z,
  nt as _,
  Dm as a,
  Wi as a$,
  ji as a0,
  vc as a1,
  Nm as a2,
  Jn as a3,
  Bm as a4,
  Dr as a5,
  St as a6,
  Pc as a7,
  _m as a8,
  Pm as a9,
  Sm as aA,
  z as aB,
  J as aC,
  tt as aD,
  j as aE,
  re as aF,
  Va as aG,
  Mn as aH,
  On as aI,
  ja as aJ,
  Ua as aK,
  qa as aL,
  Ka as aM,
  _t as aN,
  Wa as aO,
  Ga as aP,
  Im as aQ,
  se as aR,
  yt as aS,
  Gn as aT,
  Mm as aU,
  Om as aV,
  $m as aW,
  dc as aX,
  _e as aY,
  Lm as aZ,
  fc as a_,
  Gs as aa,
  eo as ab,
  Zc as ac,
  el as ad,
  rl as ae,
  cl as af,
  ml as ag,
  fl as ah,
  Fm as ai,
  It as aj,
  Hi as ak,
  Vi as al,
  Am as am,
  de as an,
  pr as ao,
  ae as ap,
  wa as aq,
  Ea as ar,
  Ca as as,
  Ra as at,
  xe as au,
  bc as av,
  yc as aw,
  kc as ax,
  jt as ay,
  we as az,
  ht as b,
  Em as b$,
  jn as b0,
  pl as b1,
  gl as b2,
  hl as b3,
  bl as b4,
  Hm as b5,
  Xt as b6,
  Il as b7,
  Vm as b8,
  Tl as b9,
  zd as bA,
  _d as bB,
  rf as bC,
  ue as bD,
  Ut as bE,
  Yn as bF,
  le as bG,
  Se as bH,
  zm as bI,
  xt as bJ,
  te as bK,
  nf as bL,
  of as bM,
  sf as bN,
  Kd as bO,
  af as bP,
  Wd as bQ,
  cf as bR,
  ou as bS,
  lf as bT,
  Vn as bU,
  Tr as bV,
  _n as bW,
  Pn as bX,
  Mi as bY,
  Sr as bZ,
  Ir as b_,
  xl as ba,
  wl as bb,
  El as bc,
  Qt as bd,
  er as be,
  tr as bf,
  Km as bg,
  Ed as bh,
  Wm as bi,
  Gm as bj,
  Xm as bk,
  Jm as bl,
  Ym as bm,
  Ul as bn,
  ql as bo,
  jm as bp,
  Dd as bq,
  Zm as br,
  po as bs,
  st as bt,
  Um as bu,
  qm as bv,
  Qm as bw,
  ef as bx,
  Ki as by,
  tf as bz,
  Cm as c,
  kt as c0,
  gi as c1,
  ci as c2,
  ii as c3,
  ui as c4,
  li as c5,
  di as c6,
  Nn as c7,
  si as c8,
  Ht as c9,
  Ln as ca,
  ai as cb,
  ku as cc,
  Ru as cd,
  yu as ce,
  lt as cf,
  ff as d,
  pf as e,
  rn as f,
  gf as g,
  hf as h,
  bf as i,
  yf as j,
  pm as k,
  ba as l,
  ka as m,
  gm as n,
  ya as o,
  hm as p,
  bm as q,
  wm as r,
  ym as s,
  xa as t,
  km as u,
  am as v,
  im as w,
  cm as x,
  ta as y,
  ra as z
};
//# sourceMappingURL=authoring-action-port-BO658pvW.mjs.map
