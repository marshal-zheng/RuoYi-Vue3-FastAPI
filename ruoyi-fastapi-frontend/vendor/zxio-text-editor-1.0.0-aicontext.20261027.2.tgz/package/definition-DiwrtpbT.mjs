class u extends TypeError {
  constructor(t, r) {
    super(`Cannot canonicalize ${t}: ${r}`), this.name = "ZxCanonicalJSONError", this.path = t;
  }
}
class O extends u {
  constructor(t, r, o) {
    super(t, r), this.name = "ZxCanonicalJSONResourceError", this.usage = o;
  }
}
const V = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]), A = (e, t) => {
  for (let r = 0; r < e.length; r += 1) {
    const o = e.charCodeAt(r);
    if (o >= 55296 && o <= 56319) {
      const m = e.charCodeAt(r + 1);
      if (!(m >= 56320 && m <= 57343))
        throw new u(
          t,
          "strings must contain valid Unicode"
        );
      r += 1;
      continue;
    }
    if (o >= 56320 && o <= 57343)
      throw new u(t, "strings must contain valid Unicode");
  }
}, F = (e, t) => {
  if (Object.getPrototypeOf(e) !== Array.prototype)
    throw new u(t, "only plain arrays are supported");
  const r = Reflect.ownKeys(e);
  if (r.some((o) => typeof o == "symbol"))
    throw new u(t, "symbol keys are not supported");
  if (r.length !== e.length + 1 || !r.includes("length"))
    throw new u(
      t,
      "arrays must be dense and contain no extra properties"
    );
  return Array.from({ length: e.length }, (o, m) => {
    const a = Object.getOwnPropertyDescriptor(e, String(m));
    if (!a || !a.enumerable || !("value" in a))
      throw new u(
        `${t}[${m}]`,
        "array entries must be enumerable data properties"
      );
    return a;
  });
}, _ = (e, t, r) => {
  if (e === null) return "null";
  switch (typeof e) {
    case "string":
      return A(e, t), JSON.stringify(e);
    case "boolean":
      return JSON.stringify(e);
    case "number":
      if (!Number.isFinite(e))
        throw new u(t, "numbers must be finite");
      if (Object.is(e, -0))
        throw new u(t, "negative zero is ambiguous");
      return JSON.stringify(e);
    case "undefined":
    case "function":
    case "symbol":
    case "bigint":
      throw new u(t, `${typeof e} is not supported`);
  }
  const o = e;
  if (r.has(o))
    throw new u(t, "cyclic values are not supported");
  const m = new Set(r);
  if (m.add(o), Array.isArray(e))
    return `[${F(e, t).map(
      (d, h) => _(d.value, `${t}[${h}]`, m)
    ).join(",")}]`;
  const a = Object.getPrototypeOf(e);
  if (a !== Object.prototype && a !== null)
    throw new u(t, "only plain objects are supported");
  const f = e, y = Reflect.ownKeys(f);
  if (y.some((d) => typeof d == "symbol"))
    throw new u(t, "symbol keys are not supported");
  const c = y;
  return c.forEach((d) => {
    if (A(d, `${t}.<key>`), V.has(d))
      throw new u(t, `forbidden object key "${d}"`);
    const h = Object.getOwnPropertyDescriptor(f, d);
    if (!h || !h.enumerable || !("value" in h))
      throw new u(
        `${t}.${d}`,
        "only enumerable data properties are supported"
      );
  }), `{${c.sort().map((d) => {
    const h = Object.getOwnPropertyDescriptor(f, d);
    return `${JSON.stringify(d)}:${_(
      h.value,
      `${t}.${d}`,
      m
    )}`;
  }).join(",")}}`;
}, R = (e) => _(e, "$", /* @__PURE__ */ new Set()), B = (e, t, r, o, m, a) => {
  const f = (s) => {
    if (a.estimatedBytes += s, a.estimatedBytes > t.maxBytes)
      throw new O(
        r,
        "maximum encoded bytes exceeded",
        {
          depth: a.depth,
          arrayEntries: a.arrayEntries,
          maxKeysPerObject: a.maxKeysPerObject,
          objectKeys: a.objectKeys,
          bytes: a.estimatedBytes
        }
      );
  };
  if (a.depth = Math.max(a.depth, o), o > t.maxDepth)
    throw new O(r, "maximum depth exceeded", {
      ...a,
      bytes: null
    });
  if (e === null) {
    f(4);
    return;
  }
  if (typeof e != "object") {
    typeof e == "string" && A(e, r);
    const s = typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isFinite(e) && !Object.is(e, -0) ? JSON.stringify(e) : void 0;
    if (s === void 0)
      throw new u(r, `${typeof e} is not supported`);
    f(new TextEncoder().encode(s).length);
    return;
  }
  if (m.has(e))
    throw new u(r, "cyclic values are not supported");
  const y = new Set(m);
  if (y.add(e), Array.isArray(e)) {
    if (a.arrayEntries += e.length, a.arrayEntries > t.maxArrayEntries)
      throw new O(
        r,
        "maximum array entries exceeded",
        { ...a, bytes: null }
      );
    f(2 + Math.max(0, e.length - 1)), F(e, r).forEach(
      (s, p) => B(
        s.value,
        t,
        `${r}[${p}]`,
        o + 1,
        y,
        a
      )
    );
    return;
  }
  const c = Object.getPrototypeOf(e);
  if (c !== Object.prototype && c !== null)
    throw new u(r, "only plain objects are supported");
  const d = Reflect.ownKeys(e);
  if (d.some((s) => typeof s == "symbol"))
    throw new u(r, "symbol keys are not supported");
  const h = d.filter(
    (s) => typeof s == "string"
  );
  if (a.maxKeysPerObject = Math.max(a.maxKeysPerObject, h.length), a.maxKeysPerObject > t.maxObjectKeys)
    throw new O(
      r,
      "maximum object keys exceeded",
      { ...a, bytes: null }
    );
  if (a.objectKeys += h.length, a.objectKeys > t.maxTotalObjectKeys)
    throw new O(
      r,
      "maximum total object keys exceeded",
      {
        depth: a.depth,
        arrayEntries: a.arrayEntries,
        maxKeysPerObject: a.maxKeysPerObject,
        objectKeys: a.objectKeys,
        bytes: a.estimatedBytes
      }
    );
  f(2 + Math.max(0, h.length - 1)), h.forEach((s) => {
    if (A(s, `${r}.<key>`), V.has(s))
      throw new u(r, `forbidden object key "${s}"`);
    const p = Object.getOwnPropertyDescriptor(e, s);
    if (!p || !p.enumerable || !("value" in p))
      throw new u(
        `${r}.${s}`,
        "only enumerable data properties are supported"
      );
    f(new TextEncoder().encode(JSON.stringify(s)).length + 1), B(
      p.value,
      t,
      `${r}.${s}`,
      o + 1,
      y,
      a
    );
  });
}, ie = (e, t) => {
  const r = {
    depth: 0,
    arrayEntries: 0,
    maxKeysPerObject: 0,
    objectKeys: 0,
    estimatedBytes: 0
  };
  B(e, t, "$", 0, /* @__PURE__ */ new Set(), r);
  const o = R(e), m = new TextEncoder().encode(o).length, { estimatedBytes: a, ...f } = r, y = { bytes: m, ...f };
  if (m > t.maxBytes)
    throw new O(
      "$",
      "maximum encoded bytes exceeded",
      y
    );
  return { canonical: o, usage: y };
}, se = (e) => new TextEncoder().encode(R(e)), T = (e) => !e || typeof e != "object" || Object.isFrozen(e) || ArrayBuffer.isView(e) ? e : (Array.isArray(e) ? e.forEach((t) => T(t)) : Object.values(e).forEach((t) => T(t)), Object.freeze(e)), x = (e, t) => e >>> t | e << 32 - t, q = Object.freeze([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), G = (e) => (e >>> 0).toString(16).padStart(8, "0"), W = (e) => {
  const t = new TextEncoder().encode(e), r = t.length * 8, o = Math.ceil((t.length + 9) / 64) * 64, m = new Uint8Array(o);
  m.set(t), m[t.length] = 128;
  const a = new DataView(m.buffer), f = Math.floor(r / 4294967296), y = r >>> 0;
  a.setUint32(o - 8, f), a.setUint32(o - 4, y);
  const c = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]), d = new Uint32Array(64);
  for (let h = 0; h < m.length; h += 64) {
    for (let b = 0; b < 16; b += 1)
      d[b] = a.getUint32(h + b * 4);
    for (let b = 16; b < 64; b += 1) {
      const S = d[b - 15], E = d[b - 2], N = x(S, 7) ^ x(S, 18) ^ S >>> 3, P = x(E, 17) ^ x(E, 19) ^ E >>> 10;
      d[b] = d[b - 16] + N + d[b - 7] + P >>> 0;
    }
    let [s, p, j, L, v, $, I, C] = c;
    for (let b = 0; b < 64; b += 1) {
      const S = x(v, 6) ^ x(v, 11) ^ x(v, 25), E = v & $ ^ ~v & I, N = C + S + E + q[b] + d[b] >>> 0, P = x(s, 2) ^ x(s, 13) ^ x(s, 22), Z = s & p ^ s & j ^ p & j, X = P + Z >>> 0;
      C = I, I = $, $ = v, v = L + N >>> 0, L = j, j = p, p = s, s = N + X >>> 0;
    }
    c[0] = c[0] + s >>> 0, c[1] = c[1] + p >>> 0, c[2] = c[2] + j >>> 0, c[3] = c[3] + L >>> 0, c[4] = c[4] + v >>> 0, c[5] = c[5] + $ >>> 0, c[6] = c[6] + I >>> 0, c[7] = c[7] + C >>> 0;
  }
  return [...c].map(G).join("");
}, D = (e) => `sha256:${W(R(e))}`, ce = (e) => e.slice(0, 20), Y = (e) => {
  throw new RangeError(`Schema attribute must satisfy ${e}.`);
}, w = (e, t, r) => ({
  id: e,
  version: "1.0.0",
  semantic: t,
  validate: (o) => r(o) || Y(t)
}), Q = (e) => {
  try {
    return R(e), !0;
  } catch {
    return !1;
  }
}, H = [
  w(
    "zx.schema-validator.canonical-value",
    "canonical JSON value",
    Q
  ),
  w(
    "zx.schema-validator.nullable-string",
    "string or null",
    (e) => e === null || typeof e == "string"
  ),
  w(
    "zx.schema-validator.string",
    "string",
    (e) => typeof e == "string"
  ),
  w(
    "zx.schema-validator.boolean",
    "boolean",
    (e) => typeof e == "boolean"
  ),
  w(
    "zx.schema-validator.nullable-boolean",
    "boolean or null",
    (e) => e === null || typeof e == "boolean"
  ),
  w(
    "zx.schema-validator.integer",
    "integer",
    (e) => Number.isInteger(e)
  ),
  w(
    "zx.schema-validator.positive-integer",
    "positive integer",
    (e) => Number.isInteger(e) && e > 0
  ),
  w(
    "zx.schema-validator.nullable-positive-number",
    "positive finite number or null",
    (e) => e === null || typeof e == "number" && Number.isFinite(e) && e > 0
  ),
  w(
    "zx.schema-validator.nullable-integer",
    "integer or null",
    (e) => e === null || Number.isInteger(e)
  ),
  w(
    "zx.schema-validator.nullable-integer-array",
    "integer array or null",
    (e) => e === null || Array.isArray(e) && e.every(Number.isInteger)
  )
], ee = new Map(H.map((e) => [e.id, e])), J = T(
  H.map(({ id: e, version: t, semantic: r }) => ({
    id: e,
    version: t,
    fingerprint: D({ id: e, version: t, semantic: r })
  }))
), te = (e) => {
  const t = J.find(
    (r) => r.id === e
  );
  if (!t)
    throw new TypeError(`Unknown package schema validator "${e}".`);
  return t;
}, de = (e) => {
  const t = ee.get(e.id), r = J.find(
    (o) => o.id === e.id
  );
  if (!t || !r || r.version !== e.version || r.fingerprint !== e.fingerprint)
    throw new TypeError(`Unresolvable package schema validator "${e.id}".`);
  return t.validate;
}, n = (e, t, r) => ({
  name: e,
  default: t,
  validator: te(r)
}), l = (e, t) => ({
  kind: "node",
  joinKey: `node:${t.key}`,
  order: e,
  attrs: t.attrs ?? [],
  ...t
}), z = (e, t) => ({
  kind: "mark",
  joinKey: `mark:${t.key}`,
  order: e,
  attrs: t.attrs ?? [],
  ...t
}), i = {
  marks: null,
  inline: !1,
  atom: !1,
  isolating: !1,
  defining: !1,
  selectable: !0,
  draggable: !1,
  code: !1,
  whitespace: null,
  linebreakReplacement: !1
}, g = () => n("blockId", null, "zx.schema-validator.nullable-string"), M = () => n("textAlign", null, "zx.schema-validator.nullable-string"), ne = {
  contractVersion: "platform-default",
  language: "platform-default",
  detectedLanguage: "platform-default",
  filename: "platform-default",
  caption: "platform-default",
  showLineNumbers: "platform-default",
  startLine: "platform-default",
  wrap: "platform-default",
  collapsed: "platform-default",
  previewLines: "platform-default",
  heightMode: "platform-default",
  height: "platform-default",
  theme: "platform-default",
  highlightLines: "platform-default",
  copyMode: "platform-default",
  variant: "platform-default",
  groupId: "platform-default",
  tabLabel: "platform-default"
}, re = [
  l(0, {
    ...i,
    key: "paragraph",
    content: "inline*",
    group: "block",
    attrs: [M(), g()]
  }),
  l(1, {
    ...i,
    key: "toggleSummary",
    content: "inline*",
    group: "block",
    defining: !0,
    selectable: !1,
    attrs: [g()]
  }),
  l(2, {
    ...i,
    key: "toggleContent",
    content: "block+",
    group: "block",
    defining: !0,
    selectable: !1,
    attrs: [g()]
  }),
  l(3, {
    ...i,
    key: "blockquote",
    content: "block+",
    group: "block",
    defining: !0,
    attrs: [g()]
  }),
  l(4, {
    ...i,
    key: "bulletList",
    content: "listItem+",
    group: "block list",
    attrs: [g()]
  }),
  l(5, { ...i, key: "doc", content: "block+", group: null }),
  l(6, {
    ...i,
    key: "hardBreak",
    content: null,
    group: "inline",
    inline: !0,
    selectable: !1,
    linebreakReplacement: !0
  }),
  l(7, {
    ...i,
    key: "horizontalRule",
    content: null,
    group: "block",
    attrs: [g()]
  }),
  l(8, {
    ...i,
    key: "listItem",
    content: "paragraph block*",
    group: null,
    defining: !0,
    attrs: [g()]
  }),
  l(9, {
    ...i,
    key: "orderedList",
    content: "listItem+",
    group: "block list",
    attrs: [
      g(),
      n("start", 1, "zx.schema-validator.positive-integer"),
      n("type", null, "zx.schema-validator.nullable-string")
    ]
  }),
  l(10, { ...i, key: "text", content: null, group: "inline" }),
  l(11, {
    ...i,
    key: "heading",
    content: "inline*",
    group: "block",
    defining: !0,
    attrs: [
      M(),
      g(),
      n("level", 1, "zx.schema-validator.positive-integer")
    ]
  }),
  l(12, {
    ...i,
    key: "table",
    content: "tableRow+",
    group: "block",
    isolating: !0,
    attrs: [g()]
  }),
  l(13, {
    ...i,
    key: "taskList",
    content: "taskItem+",
    group: "block list",
    attrs: [g()]
  }),
  l(14, {
    ...i,
    key: "taskItem",
    content: "paragraph block*",
    group: null,
    defining: !0,
    attrs: [g(), n("checked", !1, "zx.schema-validator.boolean")]
  }),
  l(15, {
    ...i,
    key: "tableRow",
    content: "(tableCell | tableHeader)*",
    group: null,
    attrs: [n("rowId", null, "zx.schema-validator.nullable-string")]
  }),
  l(16, {
    ...i,
    key: "tableHeader",
    content: "block+",
    group: null,
    isolating: !0,
    attrs: [
      n("cellId", null, "zx.schema-validator.nullable-string"),
      n("colspan", 1, "zx.schema-validator.positive-integer"),
      n("rowspan", 1, "zx.schema-validator.positive-integer"),
      n("colwidth", null, "zx.schema-validator.nullable-integer-array"),
      n("align", null, "zx.schema-validator.nullable-string")
    ]
  }),
  l(17, {
    ...i,
    key: "tableCell",
    content: "block+",
    group: null,
    isolating: !0,
    attrs: [
      n("cellId", null, "zx.schema-validator.nullable-string"),
      n("colspan", 1, "zx.schema-validator.positive-integer"),
      n("rowspan", 1, "zx.schema-validator.positive-integer"),
      n("colwidth", null, "zx.schema-validator.nullable-integer-array"),
      n("align", null, "zx.schema-validator.nullable-string")
    ]
  }),
  l(18, {
    ...i,
    key: "pageBreak",
    content: null,
    group: "block",
    atom: !0,
    isolating: !0,
    attrs: [g(), n("id", null, "zx.schema-validator.nullable-string")]
  }),
  l(19, {
    ...i,
    key: "codeBlock",
    content: "text*",
    group: "block",
    marks: "",
    defining: !0,
    code: !0,
    whitespace: "pre",
    attrs: [
      g(),
      n("language", null, "zx.schema-validator.nullable-string"),
      n("contractVersion", "zx-code-block/v2", "zx.schema-validator.string"),
      n("detectedLanguage", null, "zx.schema-validator.nullable-string"),
      n("filename", "", "zx.schema-validator.string"),
      n("caption", "", "zx.schema-validator.string"),
      n("showLineNumbers", !0, "zx.schema-validator.boolean"),
      n("startLine", 1, "zx.schema-validator.positive-integer"),
      n("wrap", "inherit", "zx.schema-validator.string"),
      n("collapsed", !1, "zx.schema-validator.boolean"),
      n("previewLines", null, "zx.schema-validator.nullable-integer"),
      n("heightMode", "max", "zx.schema-validator.string"),
      n("height", null, "zx.schema-validator.nullable-positive-number"),
      n("theme", null, "zx.schema-validator.nullable-string"),
      n("highlightLines", [], "zx.schema-validator.canonical-value"),
      n("copyMode", "plain", "zx.schema-validator.string"),
      n("variant", "code", "zx.schema-validator.string"),
      n("groupId", null, "zx.schema-validator.nullable-string"),
      n("tabLabel", "", "zx.schema-validator.string"),
      n(
        "defaultSource",
        ne,
        "zx.schema-validator.canonical-value"
      )
    ]
  }),
  l(20, {
    ...i,
    key: "attachment",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      g(),
      ...[
        "assetId",
        "display",
        "href",
        "fileName",
        "title",
        "mimeType",
        "fileSize",
        "sizeLabel",
        "fileKind",
        "badgeLabel",
        "downloadName"
      ].map(
        (e) => n(
          e,
          e === "display" ? "card" : null,
          e === "display" ? "zx.schema-validator.string" : e === "fileSize" ? "zx.schema-validator.canonical-value" : "zx.schema-validator.nullable-string"
        )
      )
    ]
  }),
  l(21, {
    ...i,
    key: "embed",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: ["assetId", "name", "title", "url", "icon"].map(
      (e) => n(e, null, "zx.schema-validator.nullable-string")
    )
  }),
  l(22, {
    ...i,
    key: "iframe",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      g(),
      n("assetId", null, "zx.schema-validator.nullable-string"),
      n("src", null, "zx.schema-validator.nullable-string"),
      n("width", null, "zx.schema-validator.canonical-value"),
      n("height", null, "zx.schema-validator.canonical-value"),
      n("aspectRatio", 0.5625, "zx.schema-validator.canonical-value"),
      n("align", "center", "zx.schema-validator.string"),
      n("title", null, "zx.schema-validator.nullable-string"),
      n("frameborder", "0", "zx.schema-validator.string"),
      n("allowfullscreen", "true", "zx.schema-validator.string"),
      n(
        "sandbox",
        "allow-scripts allow-same-origin allow-popups allow-forms",
        "zx.schema-validator.string"
      ),
      n("interactive", !1, "zx.schema-validator.boolean"),
      n("fullWidth", !1, "zx.schema-validator.boolean")
    ]
  }),
  l(23, {
    ...i,
    key: "image",
    content: null,
    group: "block",
    draggable: !0,
    attrs: [
      g(),
      ...["assetId", "src", "alt", "title"].map(
        (e) => n(e, null, "zx.schema-validator.nullable-string")
      ),
      n("width", null, "zx.schema-validator.canonical-value"),
      n("height", null, "zx.schema-validator.canonical-value"),
      n("align", "left", "zx.schema-validator.string")
    ]
  }),
  l(24, {
    ...i,
    key: "imageGroup",
    content: "image+",
    group: "block",
    isolating: !0,
    draggable: !0,
    attrs: [
      g(),
      n("columns", 4, "zx.schema-validator.positive-integer")
    ]
  }),
  l(25, {
    ...i,
    key: "mention",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: [
      n("id", null, "zx.schema-validator.nullable-string"),
      n("label", null, "zx.schema-validator.nullable-string")
    ]
  }),
  l(26, {
    ...i,
    key: "tagItem",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: [
      n("tagId", null, "zx.schema-validator.nullable-string"),
      n("tagLabel", "tag", "zx.schema-validator.string")
    ]
  }),
  l(27, {
    ...i,
    key: "toggle",
    content: "toggleSummary toggleContent",
    group: "block",
    isolating: !0,
    defining: !0,
    attrs: [g(), n("open", !1, "zx.schema-validator.boolean")]
  }),
  l(28, {
    ...i,
    key: "video",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      g(),
      n("assetId", null, "zx.schema-validator.nullable-string"),
      n("src", null, "zx.schema-validator.nullable-string")
    ]
  })
], k = {
  group: null,
  excludes: null,
  inclusive: !0,
  spanning: !0,
  code: !1
}, ae = [
  z(0, {
    ...k,
    key: "link",
    attrs: [
      n("href", null, "zx.schema-validator.nullable-string"),
      n("target", "_blank", "zx.schema-validator.nullable-string"),
      n(
        "rel",
        "noopener noreferrer nofollow",
        "zx.schema-validator.nullable-string"
      ),
      n("class", null, "zx.schema-validator.nullable-string"),
      n("title", null, "zx.schema-validator.nullable-string")
    ]
  }),
  z(1, {
    ...k,
    key: "textStyle",
    attrs: [
      n("fontFamily", null, "zx.schema-validator.nullable-string"),
      n("fontSize", null, "zx.schema-validator.nullable-string"),
      n("color", null, "zx.schema-validator.nullable-string")
    ]
  }),
  z(2, { ...k, key: "bold" }),
  z(3, { ...k, key: "italic" }),
  z(4, { ...k, key: "strike" }),
  z(5, { ...k, key: "underline" }),
  z(6, { ...k, key: "code", code: !0, excludes: "_" }),
  z(7, {
    ...k,
    key: "comment",
    attrs: [
      n("commentId", null, "zx.schema-validator.nullable-string"),
      n("resolved", !1, "zx.schema-validator.boolean")
    ]
  }),
  z(8, {
    ...k,
    key: "namedHighlight",
    inclusive: !1,
    attrs: [n("color", null, "zx.schema-validator.nullable-string")]
  })
], K = (e, t, r) => {
  const o = `zx.text-editor.authority.${e}`;
  return {
    id: o,
    version: r,
    fingerprint: D({ id: o, version: r, owner: t }),
    authority: e,
    owner: t
  };
}, oe = [
  K("document-v2", "src/document/types.ts", "2.0.0"),
  K("schema-kernel", "src/core/schema-kernel/definition.ts", "1.0.0"),
  K("ai-capability", "src/core/ai-extension-capabilities.ts", "1.0.0"),
  K("render-registry", "src/core/extension-descriptors.ts", "1.0.0")
], U = {
  schemaKernelId: "zx.text-editor.schema-kernel",
  schemaKernelVersion: "1.0.0",
  topNode: "doc",
  authorities: oe,
  validators: J,
  nodes: re,
  marks: ae
}, le = T({
  ...U,
  schemaKernelFingerprint: D(U)
}), ue = () => le;
export {
  le as Z,
  ie as a,
  de as b,
  R as c,
  T as d,
  se as e,
  ce as f,
  ue as g,
  O as h,
  W as i,
  D as s
};
//# sourceMappingURL=definition-DiwrtpbT.mjs.map
