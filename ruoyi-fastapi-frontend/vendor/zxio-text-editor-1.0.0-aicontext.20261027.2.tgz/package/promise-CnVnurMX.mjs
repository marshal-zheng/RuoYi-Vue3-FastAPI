const s = (e) => (
  /** @type {Promise<T>} */
  new Promise(e)
);
Promise.all.bind(Promise);
const r = (e) => Promise.reject(e), o = (e) => Promise.resolve(e);
export {
  r as a,
  s as c,
  o as r
};
//# sourceMappingURL=promise-CnVnurMX.mjs.map
