import { Transaction as be, PluginKey as Y, Plugin as Z } from "prosemirror-state";
import { e as r, A as f, D as H, F as k } from "./actions-Sd62WBGv.mjs";
import { Mapping as me } from "prosemirror-transform";
const D = (e, t, a, n, i, p, d, l) => {
  const b = l.map(({ id: u, version: U, fingerprint: ue }) => ({
    id: u,
    version: U,
    fingerprint: ue
  })), T = {
    id: `npm:${e}`,
    version: a,
    packageName: e,
    runtimeSpecifier: t,
    resolvedVersion: a,
    lockIntegrity: n,
    apiContractFingerprint: p,
    implementationFingerprint: d,
    admittedSemverRanges: i,
    dependencies: b
  };
  return r({
    ...T,
    fingerprint: f(T)
  });
}, S = D(
  "prosemirror-model",
  "prosemirror-model",
  "1.25.12",
  "sha512-Ue2gTmXMa7EhpLNhC7J+h4+ykD8ha12K6rrZFFKKJHBForfIStw5gJ6Zrf1mqqAa9NmpmEB4wp9bKmA4eUVjWg==",
  ["1.25.12"],
  "sha256:b11a34cfd6b9d74ce796ea9ffe402a981a0e68845ea2da0d86b3ca65777dd2a7",
  "sha256:979f44e6c7f63ce3a20b66dc2ef9e4c96ac2cbc32360f47375d4c88baf9ed181",
  []
), v = D(
  "prosemirror-transform",
  "prosemirror-transform",
  "1.12.2",
  "sha512-PE/aY0HEY4zczvmqrilgkUK/WautF0chvMqkmM/iN5/aPHvwrCWaQZjS6CIZp+K84YrvPFqrL+YArrfJX8xX7g==",
  ["1.12.2"],
  "sha256:e22fd8974004c6c9f083de095535028e31068296fefbb6f2a3da17c90c761e7b",
  "sha256:4d055cb15558c06a1ad444823f11893e4380b22b45ae211338b1c4ba7904bd15",
  [S]
), V = D(
  "prosemirror-state",
  "prosemirror-state",
  "1.4.4",
  "sha512-6jiYHH2CIGbCfnxdHbXZ12gySFY/fz/ulZE333G6bPqIZ4F+TXo9ifiR86nAHpWnfoNjOb3o5ESi7J8Uz1jXHw==",
  ["1.4.4"],
  "sha256:02ab5dbcaa58da1d58c46c7cdfa7f94792c5ccf0fc7c0622ef33755fe415366c",
  "sha256:d4bd4e98520abd0bb0150436d84a3832d856aa59636ea23a59409d35929730a3",
  [S, v]
), Ye = "sha256:0f7fc1f7430fefe0b1ccc5ba8e990af1b046cad870d99101086abc9db0fd9821", G = "sha256:77ed9078085af3da6d102aaa1c16e6f998fbedb3d226a2204c4b622496bde58b", ge = "sha256:e6fc6653d657b76d4149b5915a6def219f762a0424dd0b63ec36748dc7080c5b", Ie = "sha256:32bb9030b7493187b58d3dca8fd86e8110dbc033823432ba9dd9f0ad4f17bcd2", Re = "sha256:b9bf851be76aa150ea2eef03c7680d17430f72cd2a3a8ee9c24f58494b8a16c7", xe = "sha256:d8187e3c902a4c69f415d23bb30429d5d07792460725deaf280d69e1527ea26d", Ee = "sha256:b5a72d72f64d097b9f9eee2e84ddc5b7717b91778face3b9b099231029f1a76b", _e = "sha256:018ea543dfae0643519b6d31ee79c82e2fa75a6e48a6f10152f4c431dcc760fa", Te = r({
  contract: "sha256:776126dfe7cefc1a8978d14db6512816ecee31b667a065c95c95a1ffa3ea9b97",
  freshRootMaterializer: "sha256:27aa30c682919e8b2ed9835f00346a562e33383b2e9ec96e97650f9cd4347ed9",
  coordinator: "sha256:a51e47ec34afc6c9d6e13857b98e6bfc59a6abf207a875e07496be3d8bc18540",
  postDispatchProof: "sha256:67a632e9d12e13b21a36e75640c819f15a3fef294a76c7273b9c873ba6baad88",
  synchronousWriteGuard: "sha256:a9838b16f257c3c48f62619fd39c685850c45655a80a69fd90276681b8a14a39",
  targetDocumentAuthority: "sha256:43c0fd79317a46d841e10a612882223024dbfd4f568f724cfdab0b47d79b2948"
}), o = (e, t) => ({
  kind: e,
  id: t.id,
  version: t.version,
  fingerprint: t.fingerprint
}), s = (e, t, a, n, i = []) => {
  const p = { kind: e, id: t, version: a, semantics: n, dependencies: i };
  return r({
    kind: e,
    id: t,
    version: a,
    fingerprint: f({
      domain: `zx-runtime-component:${e}:v2`,
      projection: p
    }),
    dependencies: i
  });
}, O = s(
  "execution-closure",
  "npm:prosemirror-model",
  S.resolvedVersion,
  {
    packageFingerprint: S.fingerprint,
    implementationFingerprint: S.implementationFingerprint
  }
), K = s(
  "execution-closure",
  "npm:prosemirror-transform",
  v.resolvedVersion,
  {
    packageFingerprint: v.fingerprint,
    implementationFingerprint: v.implementationFingerprint
  },
  [o("execution-closure", O)]
), $ = s(
  "execution-closure",
  "npm:prosemirror-state",
  V.resolvedVersion,
  {
    packageFingerprint: V.fingerprint,
    apiFingerprint: V.apiContractFingerprint,
    stateSourceFingerprint: "sha256:081d675bbeaa6598c17f45be84a84011c5e083b66f9c6282be0304a5f38f7f44",
    transactionSourceFingerprint: "sha256:fbab5b3d17fc510152167b387e15dcf360c086ed78dcb2751cecae7938d01a83",
    adapterSourceFingerprint: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
    adapter: "prosemirror-state-adapter-v2"
  },
  [
    o("execution-closure", O),
    o("execution-closure", K)
  ]
), R = s(
  "schema-semantics",
  "zx.text-editor.schema-semantics",
  "2.0.0",
  {
    owner: "schema-kernel",
    documentAuthority: "document-v2",
    schemaKernelFingerprint: H.schemaKernelFingerprint,
    marks: H.marks.map((e) => ({
      key: e.key,
      order: e.order,
      inclusive: e.inclusive,
      excludes: e.excludes,
      attrs: e.attrs
    }))
  }
), Se = r([
  "text.replace",
  "block.insert",
  "block.replace",
  "block.delete",
  "node.apply"
]), E = s(
  "operation-protocol",
  "zx.text-editor.ai-mutation-plan",
  "2.0.0",
  {
    owner: "S2",
    protocolVersion: 2,
    offsetEncoding: "utf-16",
    registryBinding: "exact-fingerprint",
    v1Policy: "audit-only-no-live-converter",
    operations: Se
  },
  [o("schema-semantics", R)]
), J = s(
  "execution-closure",
  "zx.text-editor.operation-compiler-adapter",
  "2.0.0",
  {
    sourceFingerprint: "sha256:8c21f384c9e08bc7f8df660b30df12dfcdf50ba160f62ed65a2fc29c7366ea07",
    preconditionCatalogSourceFingerprint: "sha256:b45d0a4de04b2953f37742ffb24975486579cb376f2a2ace32a10f556755dbab",
    livePlanCertificationSourceFingerprint: "sha256:15f33030db66e1b01e760f3d5c0300f9d4055025453bb36c6b41883112c4ee3c",
    s2ProjectionSourceFingerprints: {
      conformance: "sha256:6d2b3df732ff1904443fafd079cb78bf0a88a48738b4eb0aadaab3093f25c3ca",
      manifest: "sha256:2bd78a70c5e5e988cd819b85317c5ca2561be21ea0ad5a9e582bf9c066e085c7",
      operationTargets: "sha256:62244a3ffc1c06c7e967bec417a752704113a448a14fb35b082884363f543e09",
      scope: "sha256:f020e82aa2356b73b1b8b4181059bb27cbd1f2f8c0dc4d5bd7b8946289264800",
      semanticTree: "sha256:365c438f6aa59e6dc483ef93c237867a17c42a8be1b44231000028fb32113c20",
      validatedBlockIndex: "sha256:36acbbe5c100368075d72d6ced1a765cf035564ee99d0b1b42f2f4fdae33a745"
    },
    rootTransactionCount: 1,
    operationOrder: "plan-order",
    spanProjection: "operation-index-step-half-open-v2",
    complexNode: {
      registry: "exact-fingerprint",
      adapterCompiler: "exact-component-ref",
      runner: "hard-terminable-isolate-required",
      fallback: "forbidden",
      resourceProfile: "manifest-bound"
    }
  },
  [
    o("schema-semantics", R),
    o("operation-protocol", E)
  ]
), c = (e, t, a, n) => s(
  "execution-closure",
  `zx.text-editor.runtime-plugin.${e}.${t}`,
  "2.0.0",
  a,
  n
), W = c(
  "stable-index",
  "factory",
  { owner: "package-exact", instanceKey: "stable-index-v2" },
  [o("schema-semantics", R)]
), M = c(
  "stable-index",
  "config",
  { key: "zxRuntimeStableIndexV2", order: 0 },
  [o("execution-closure", W)]
), Q = c(
  "stable-index",
  "state-init",
  { projection: "ordered-document-block-ids-v2" },
  [o("execution-closure", M)]
), ee = c(
  "stable-index",
  "state-apply",
  { projection: "docChanged-reproject-otherwise-identity" },
  [o("execution-closure", Q)]
), te = c(
  "stable-index",
  "projector",
  { output: "blockIds+fingerprint", canonical: !0 },
  [o("execution-closure", ee)]
), he = c(
  "stable-index",
  "filter",
  {
    accepts: "host-and-runtime-transactions",
    runtimeTargetAdmission: "package-write-guard-plus-root/appended-meta"
  },
  [o("execution-closure", M)]
), ye = c(
  "stable-index",
  "append",
  { behavior: "none" },
  [o("execution-closure", M)]
), ve = c(
  "stable-index",
  "effect",
  { behavior: "none" },
  [o("execution-closure", te)]
), h = r({
  factory: W,
  config: M,
  stateInit: Q,
  stateApply: ee,
  projector: te,
  filter: he,
  append: ye,
  effect: ve
}), y = s(
  "execution-closure",
  "zx.text-editor.runtime-plugin.stable-index",
  "2.0.0",
  {
    instanceKey: "stable-index-v2",
    order: 0,
    componentRefs: h,
    conformanceReceipt: "runtime-plugin-stable-index-v2-receipt-1",
    implementationSourceFingerprint: G
  },
  Object.values(h).map(
    (e) => o("execution-closure", e)
  )
), ne = c(
  "trace-seal",
  "factory",
  { owner: "package-exact", instanceKey: "trace-seal-v2" },
  [o("execution-closure", y)]
), A = c(
  "trace-seal",
  "config",
  { key: "zxRuntimeTraceSealV2", order: 1 },
  [o("execution-closure", ne)]
), ae = c(
  "trace-seal",
  "state-init",
  { projection: "transaction-count-zero-v2" },
  [o("execution-closure", A)]
), oe = c(
  "trace-seal",
  "state-apply",
  { projection: "runtime-transaction-count-increment-v2" },
  [o("execution-closure", ae)]
), re = c(
  "trace-seal",
  "projector",
  { output: "transactionCount+fingerprint", canonical: !0 },
  [o("execution-closure", oe)]
), Ne = c(
  "trace-seal",
  "filter",
  {
    accepts: "host-and-runtime-transactions",
    runtimeTargetAdmission: "package-write-guard-plus-root/appended-meta"
  },
  [o("execution-closure", A)]
), Oe = c(
  "trace-seal",
  "append",
  { behavior: "single-logical-transaction-after-root-v2" },
  [o("execution-closure", A)]
), Me = c(
  "trace-seal",
  "effect",
  { behavior: "bounded-observational-trace-sealed-v2" },
  [o("execution-closure", re)]
), m = r({
  factory: ne,
  config: A,
  stateInit: ae,
  stateApply: oe,
  projector: re,
  filter: Ne,
  append: Oe,
  effect: Me
}), C = s(
  "execution-closure",
  "zx.text-editor.runtime-plugin.trace-seal",
  "2.0.0",
  {
    instanceKey: "trace-seal-v2",
    order: 1,
    componentRefs: m,
    conformanceReceipt: "runtime-plugin-trace-seal-v2-receipt-1",
    implementationSourceFingerprint: G
  },
  [
    o("execution-closure", y),
    ...Object.values(m).map(
      (e) => o("execution-closure", e)
    )
  ]
), ie = s(
  "execution-closure",
  "zx.text-editor.runtime-observational.audit-label",
  "1.0.0",
  {
    owner: "S2B-observability",
    executionReachability: "none",
    behavior: "canonical-receipt-label-only",
    implementationSourceFingerprint: Ie,
    sourceReachabilityClosure: {
      semanticComponentDependencies: [],
      reachableAuthorities: ["observations"],
      unreachableAuthorities: [
        "document",
        "selection",
        "stored-marks",
        "semantic-plugin-state",
        "effects",
        "annotations",
        "lifecycle"
      ]
    },
    conformanceReceipt: "runtime-observational-audit-label-non-interference-receipt-1"
  }
), _ = s(
  "execution-closure",
  "zx.text-editor.deterministic-execution-closure",
  "2.0.0",
  {
    owner: "S2B",
    adapter: "prosemirror-state-adapter-v2",
    filterOrder: "manifest-plugin-order",
    appendSeenSemantics: "prosemirror-state-1.4.4",
    plugins: ["stable-index-v2", "trace-seal-v2"],
    pluginOrderSignificant: !0,
    watchdog: "host-non-replayable-abort-only",
    implementationSourceFingerprints: {
      stateAdapter: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
      fixedPointDriver: "sha256:abce518d9a3d1206cd96e9f5c9aa0b9b9085c2f8b52c0e7f7b928c733b9257ba",
      pluginClosure: G,
      pluginConformance: ge,
      executionTrace: "sha256:8dee1b14039e315dc231d6f201c805128e3fd9ce9447dad2367a7884b3511fc1",
      hostAdmission: "sha256:2df4555636e903ebacb7fe29ffe354abe751216f134456bdba6cebdc8465374d",
      hostCompositionAuthority: Re,
      hostCompositionRegistry: xe,
      hostCompositionState: Ee,
      editorRuntimeAssembly: _e,
      targetCommit: Te,
      orchestrator: "sha256:f1e502f884fca6e64183c09cb114dff670000fe8a9d5eaa9ab3580790196f1e9",
      resolver: "sha256:38359a64831ddca47317ae78b1d8e68e8db62fc94b8f0b7de0f9d21ecf37f8c4"
    }
  },
  [
    o("operation-protocol", E),
    o("execution-closure", J),
    o("execution-closure", O),
    o("execution-closure", K),
    o("execution-closure", $),
    o("execution-closure", y),
    o("execution-closure", C)
  ]
), F = s(
  "mapping-policy",
  "zx.text-editor.mapping-policy",
  "2.0.0",
  {
    projection: "block-pm-utf16-v2",
    composition: "root-first-all-step-maps",
    annotationBoundary: { startAssoc: 1, endAssoc: -1, expanding: !1 },
    deletionFlags: [
      "deleted",
      "deletedBefore",
      "deletedAfter",
      "deletedAcross"
    ],
    invalidation: "fail-closed",
    context: ["quote", "beforeQuote", "afterQuote"],
    textReplaceMarks: {
      collapsed: "$pos.marks()",
      range: "$from.marksAcross($to) ?? []",
      deletion: [],
      selectionAndStoredMarks: "forbidden"
    },
    implementationSourceFingerprints: {
      mapping: "sha256:fd5888ea31b7eb6029d7d09d21467e9d9a36099b08cbec89bbeb7f843fda13c3",
      marks: "sha256:8be5e04ae8b43eff89322f668bd61a3e5d499bb8a7d70d34234af45b34a8e3a2"
    }
  },
  [
    o("schema-semantics", R),
    o("operation-protocol", E),
    o("execution-closure", _)
  ]
), P = s(
  "transaction-policy",
  "zx.text-editor.transaction-policy",
  "2.0.0",
  {
    logicalTime: "zero-based-global-sequence-v1",
    rootMeta: ["zx.runtime.root.v2"],
    appendedMeta: ["zx.runtime.appended.v2"],
    forbiddenMeta: [
      "uiEvent",
      "pointer",
      "composition",
      "history",
      "yjs",
      "provider",
      "caller",
      "PluginKey"
    ],
    selectionMutation: "forbidden",
    storedMarksMutation: "forbidden",
    implementationSourceFingerprint: "sha256:7e4a8909db08d8a8e3f56af4ecca53b23e6ef2e54b09f8040e538f561d02875f"
  },
  [o("execution-closure", _)]
), Ae = r({
  inputBytes: 2e6,
  inputDepth: 128,
  inputKeys: 3e5,
  documentNodes: 5e4,
  documentMarks: 2e5,
  documentBlocks: 2e4,
  annotations: 2e4,
  planOperations: 1e4,
  executionPlugins: 16,
  rootSteps: 1e4,
  steps: 2e4,
  transactions: 256,
  filterCalls: 2048,
  appendCalls: 2048,
  appendRounds: 256,
  mappingMaps: 2e4,
  mappingRanges: 12e4,
  mappingBytes: 4e6,
  mappingMirrors: 2e4,
  mappingMirrorBytes: 1e6,
  metaBytes: 1e6,
  traceBytes: 8e6,
  pluginStateBytes: 2e6,
  safeDiagnosticCount: 16,
  safeDiagnosticBytes: 16384
}), q = s(
  "resource-profile",
  "zx.text-editor.deterministic-resource-profile",
  "2.0.0",
  {
    algorithm: "pre-debit-counts-and-canonical-utf8-bytes-v1",
    limits: Ae,
    implementationSourceFingerprint: "sha256:74442b20a3f316728b6ee2db517e43a65d79cd68fa028026e3bdc432f483f3fb"
  },
  [
    o("execution-closure", _),
    o("mapping-policy", F),
    o("transaction-policy", P)
  ]
), ce = s(
  "derived-view-profile",
  "zx.text-editor.derived-view.runtime-summary",
  "1.0.0",
  {
    owner: "proposal-view-authority",
    output: ["transactionCount", "stepCount", "annotationCount"],
    diffAlgorithm: null,
    hunkIdentity: null,
    maxInputBytes: 8e6,
    maxOutputBytes: 16384,
    implementationSourceFingerprint: "sha256:eebeca1ca662a97ef3190f83b82bb07c3349360bd8fb5ccd1e2d396bd0a81232"
  }
), Ce = [
  R,
  E,
  _,
  F,
  P,
  q
], Fe = [
  C,
  ie
], se = [ce], Pe = f({
  domain: "zx-runtime-execution-semantics:v2",
  components: Ce
}), Ue = f({
  domain: "zx-runtime-observational-profile:v2",
  components: Fe
}), Ve = f({
  domain: "zx-runtime-derived-view-profile:v2",
  components: se
}), w = {
  kind: "zx-text-editor-runtime-manifest-v2",
  version: "2.0.0",
  schemaSemantics: R,
  operationProtocol: E,
  executionClosure: _,
  mappingPolicy: F,
  transactionPolicy: P,
  resourceProfile: q,
  derivedViewProfiles: se,
  fingerprints: {
    executionSemanticsFingerprint: Pe,
    observationalProfileFingerprint: Ue,
    derivedViewFingerprint: Ve
  }
}, de = f({
  domain: "zx-runtime-manifest:v2",
  manifest: w
}), j = r({
  ...w,
  fingerprints: {
    ...w.fingerprints,
    runtimeManifestFingerprint: de
  }
}), Ze = r({
  kind: j.kind,
  version: j.version,
  fingerprint: de
}), $e = r([
  R,
  E,
  J,
  O,
  K,
  $,
  ...Object.values(h),
  y,
  ...Object.values(m),
  C,
  ie,
  _,
  F,
  P,
  q,
  ce
]), Je = () => j, x = "zx.runtime.root.v2", I = "zx.runtime.appended.v2", X = (e) => e.meta, ke = (e) => {
  if (Object.keys(X(e)).length !== 0)
    throw new TypeError("transaction-meta-invalid");
}, N = (e, t) => {
  const a = Object.keys(e).sort(), n = [...t].sort();
  return a.length === n.length && a.every((i, p) => i === n[p]);
}, g = (e) => Number.isSafeInteger(e) && e >= 0, we = (e) => Array.isArray(e) && e.every((t, a) => {
  if (!t || typeof t != "object" || Array.isArray(t)) return !1;
  const n = t;
  return !N(n, ["operationIndex", "stepStart", "stepEnd"]) && (!N(n, [
    "operationIndex",
    "stepStart",
    "stepEnd",
    "noOpReason"
  ]) || n.noOpReason !== "already-equal") ? !1 : n.operationIndex === a && g(n.stepStart) && g(n.stepEnd) && n.stepEnd >= n.stepStart;
}), je = (e) => Array.isArray(e) && e.every(
  (t, a) => g(t) && (a === 0 || t > e[a - 1])
), pe = (e, t) => {
  if (!g(t))
    throw new TypeError("transaction-time-invalid");
  const a = Object.create(be.prototype), n = a;
  return n.doc = e.doc, n.steps = [], n.docs = [], n.mapping = new me(), n.time = t, n.curSelection = e.selection, n.curSelectionFor = 0, n.updated = 0, n.meta = /* @__PURE__ */ Object.create(null), n.storedMarks = e.storedMarks, a;
}, ze = (e, t, a) => N(e, [
  "protocol",
  "executionId",
  "sequence",
  "compilerRef",
  "operationSpans"
]) && e.protocol === "zx-runtime-root-meta-v2" && e.executionId === a && e.sequence === t && e.compilerRef === "zx.text-editor.operation-compiler-adapter-v2@2.0.0" && we(e.operationSpans), Le = (e, t, a) => {
  if (!N(e, [
    "protocol",
    "rootExecutionId",
    "sequence",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || e.protocol !== "zx-runtime-appended-meta-v2" || e.rootExecutionId !== a || e.sequence !== t || typeof e.pluginInstanceId != "string" || e.pluginInstanceId.length === 0 || !g(e.pluginOrder) || !je(e.operationIndexes) || !Array.isArray(e.visibleTransactionRange) || e.visibleTransactionRange.length !== 2)
    return !1;
  const [n, i] = e.visibleTransactionRange;
  return g(n) && g(i) && n <= i && i < t;
}, We = (e) => pe(e, 0), Qe = (e, t, a) => (ke(e), e.setMeta(
  x,
  r({
    protocol: "zx-runtime-root-meta-v2",
    executionId: t,
    sequence: 0,
    compilerRef: "zx.text-editor.operation-compiler-adapter-v2@2.0.0",
    operationSpans: a
  })
), e), Be = (e, t) => {
  if (e.time !== t.sequence)
    throw new TypeError("transaction-time-invalid");
  const a = r({
    protocol: "zx-runtime-appended-meta-v2",
    rootExecutionId: t.executionId,
    sequence: t.sequence,
    pluginInstanceId: t.pluginInstanceId,
    pluginOrder: t.pluginOrder,
    visibleTransactionRange: t.visibleTransactionRange,
    operationIndexes: t.operationIndexes
  }), n = X(e);
  if (Object.keys(n).length) {
    if (Object.keys(n).length === 1 && k(n[I]) === k(a))
      return e;
    throw new TypeError("transaction-meta-invalid");
  }
  return e.setMeta(I, a), e;
}, et = (e, t, a, n) => {
  const i = X(e), p = Object.keys(i), d = t === "root" ? x : I;
  if (e.time !== a)
    throw new TypeError("transaction-time-invalid");
  if (p.length !== 1 || p[0] !== d)
    throw new TypeError("transaction-meta-invalid");
  const l = i[d];
  if (k(l), !l || typeof l != "object" || Array.isArray(l))
    throw new TypeError("transaction-meta-invalid");
  const b = l;
  if (t === "root" && !ze(b, a, n) || t === "appended" && !Le(b, a, n))
    throw new TypeError("transaction-attribution-invalid");
  if (e.selectionSet || e.storedMarksSet)
    throw new TypeError("transaction-attribution-invalid");
  return r({ [d]: l });
}, tt = (e, t) => {
  if (t === "root") {
    const n = e.getMeta(x);
    return r({
      owner: "operation-compiler",
      pluginInstanceId: null,
      pluginOrder: null,
      visibleTransactionRange: [0, 0],
      operationIndexes: n.operationSpans.map((i) => i.operationIndex)
    });
  }
  const a = e.getMeta(I);
  return r({
    owner: "certified-plugin",
    pluginInstanceId: a.pluginInstanceId,
    pluginOrder: a.pluginOrder,
    visibleTransactionRange: a.visibleTransactionRange,
    operationIndexes: a.operationIndexes
  });
}, z = (e) => {
  const t = [];
  e.descendants((n) => {
    typeof n.attrs.blockId == "string" && t.push(n.attrs.blockId);
  });
  const a = { blockIds: t };
  return r({ ...a, fingerprint: f(a) });
}, le = (e) => {
  const t = ((e == null ? void 0 : e.transactionCount) ?? 0) + 1;
  return r({
    transactionCount: t,
    fingerprint: f({ transactionCount: t })
  });
}, L = new Y(
  "zxRuntimeStableIndexV2"
), B = new Y("zxRuntimeTraceSealV2"), De = (e) => !!(e.getMeta(x) || e.getMeta(I)), fe = () => !0, Ge = new Z({
  key: L,
  state: {
    init: (e, t) => z(t.doc),
    apply: (e, t) => e.docChanged ? z(e.doc) : t
  },
  // The certified plugins are also installed in the genuine editor. Host
  // transactions must remain usable; Runtime admission is enforced by the
  // target write guard and the root/appended metadata, not by globally
  // blocking unrelated editor transactions.
  filterTransaction: fe
}), Ke = new Z({
  key: B,
  state: {
    init: () => r({
      transactionCount: 0,
      fingerprint: f({ transactionCount: 0 })
    }),
    apply: (e, t) => De(e) ? le(t) : t
  },
  filterTransaction: fe,
  appendTransaction: (e, t, a) => {
    var T;
    const n = e.find(
      (u) => !!u.getMeta(x)
    ), i = e.some(
      (u) => !!u.getMeta(I)
    ), p = (T = e.at(-1)) == null ? void 0 : T.time, d = n == null ? void 0 : n.getMeta(x);
    if (!n || i || !Number.isSafeInteger(p) || typeof (d == null ? void 0 : d.executionId) != "string" || !Array.isArray(d.operationSpans))
      return null;
    const l = d.operationSpans.map(
      (u) => u.operationIndex
    );
    if (l.some((u, U) => u !== U))
      return null;
    const b = p + 1;
    return Be(
      pe(a, b),
      {
        executionId: d.executionId,
        sequence: b,
        pluginInstanceId: "trace-seal-v2",
        pluginOrder: 1,
        visibleTransactionRange: [0, e.length - 1],
        operationIndexes: l
      }
    );
  }
}), nt = r([
  {
    order: 0,
    instanceId: "stable-index-v2",
    componentRef: y,
    componentRefs: h,
    plugin: Ge,
    projectorRef: h.projector,
    project: (e) => L.getState(e) ?? null,
    projectAfterApply: (e, t) => t.docChanged ? z(t.doc) : L.getState(e) ?? null,
    effectRef: null,
    effect: () => [],
    conformanceReceiptRef: "runtime-plugin-stable-index-v2-receipt-1"
  },
  {
    order: 1,
    instanceId: "trace-seal-v2",
    componentRef: C,
    componentRefs: m,
    plugin: Ke,
    projectorRef: m.projector,
    project: (e) => B.getState(e) ?? null,
    projectAfterApply: (e) => le(B.getState(e)),
    effectRef: m.effect,
    effect: (e) => e.getMeta(I) ? r([
      {
        effectRef: m.effect,
        kind: "observational",
        fingerprint: f({
          effect: "trace-sealed",
          sequence: e.time
        })
      }
    ]) : [],
    conformanceReceiptRef: "runtime-plugin-trace-seal-v2-receipt-1"
  }
]);
export {
  I as A,
  Ze as C,
  Se as R,
  nt as a,
  Ae as b,
  q as c,
  tt as d,
  Qe as e,
  Be as f,
  Je as g,
  F as h,
  We as i,
  Ye as j,
  x as k,
  j as l,
  $e as m,
  C as n,
  ie as o,
  _e as p,
  Re as q,
  et as r,
  xe as s,
  Ee as t,
  Ie as u,
  pe as v,
  _ as w,
  ce as x
};
//# sourceMappingURL=runtime-plugin-definitions-DN_cDAJZ.mjs.map
