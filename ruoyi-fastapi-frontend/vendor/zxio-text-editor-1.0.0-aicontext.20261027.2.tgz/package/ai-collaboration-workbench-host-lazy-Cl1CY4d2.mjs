const a = async (o) => (await import("./ai-collaboration-workbench-host-B9kPY6aZ.mjs")).createAICollaborationWorkbenchCommitHost(o), n = async (o) => (await import("./ai-collaboration-workbench-host-B9kPY6aZ.mjs")).readAICollaborationWorkbenchCanonicalDocument(o);
export {
  a as c,
  n as r
};
//# sourceMappingURL=ai-collaboration-workbench-host-lazy-Cl1CY4d2.mjs.map
