import { defineComponent as A, ref as l, computed as v, onMounted as W, onUnmounted as _, createElementBlock as p, openBlock as c, renderSlot as z, createBlock as G, createCommentVNode as D, normalizeProps as H, guardReactiveProps as K, unref as o, withCtx as O, createElementVNode as g, normalizeClass as d, createVNode as Z, withKeys as $, toDisplayString as L, nextTick as q } from "vue";
import { useNamespace as F } from "@zxio/zxui/hooks";
import { ZxDialog as T } from "@zxio/zxui/core";
import { ZxInput as j } from "@zxio/zxui/input";
import { v as R, A as E, p as C, f as J, e as M } from "./link-paste-handler-COpsSlXB.mjs";
import { H as Q } from "./runtime-extensions-B_GmfVEg.mjs";
const oe = /* @__PURE__ */ A({
  __name: "InsertIframe",
  props: {
    editor: {}
  },
  setup(P) {
    const r = P, s = F("text-editor-insert-iframe"), { binding: h } = Q(), m = l(!1), t = l(""), n = l(""), I = l(""), w = l("center"), U = l(640), b = l(360), y = l(null), B = (e) => {
      y.value = e;
    }, u = v(() => {
      if (!t.value) return !1;
      try {
        if (t.value.trim().startsWith("<iframe")) {
          const e = t.value.match(/src=["']([^"']+)["']/);
          return e != null && e[1] ? R(e[1], {
            allowedDomains: E
          }) : !1;
        }
        return R(t.value, {
          allowedDomains: E
        });
      } catch {
        return !1;
      }
    }), f = v(() => {
      if (!t.value) return "";
      if (t.value.trim().startsWith("<iframe")) {
        const e = t.value.match(/src=["']([^"']+)["']/);
        return e != null && e[1] ? C(e[1]) : t.value;
      }
      return C(t.value);
    }), N = v(() => {
      if (!t.value || !u.value)
        return { platform: "Generic", aspectRatio: 9 / 16 };
      const e = J(f.value), a = M(f.value);
      return {
        platform: (e == null ? void 0 : e.name) || "Generic",
        aspectRatio: a.ratio
      };
    });
    function S() {
      n.value = "", t.value && (u.value || (n.value = "Please enter a supported URL or iframe embed code"));
    }
    function k() {
      m.value = !0, t.value = "", n.value = "", I.value = "", w.value = "center", U.value = 640, b.value = 360, q(() => {
        var a, i;
        const e = (i = (a = y.value) == null ? void 0 : a.$el) == null ? void 0 : i.querySelector("textarea, input");
        e == null || e.focus();
      });
    }
    function x() {
      return !t.value || !u.value ? !1 : r.editor.commands.setIframe({
        src: f.value,
        width: U.value,
        height: b.value,
        title: I.value,
        align: w.value
      }) ? (r.editor.commands.focus(), !0) : (n.value = "Failed to insert embed. Please check the URL and try again.", !1);
    }
    function V(e) {
      var a;
      ((a = e.detail) == null ? void 0 : a.editor) === r.editor && k();
    }
    return W(() => {
      var e;
      r.editor && !r.editor.isDestroyed && ((e = r.editor.view) != null && e.dom) && r.editor.view.dom.addEventListener(
        "iframe:open-dialog",
        V
      );
    }), _(() => {
      var e;
      r.editor && !r.editor.isDestroyed && ((e = r.editor.view) != null && e.dom) && r.editor.view.dom.removeEventListener(
        "iframe:open-dialog",
        V
      );
    }), (e, a) => (c(), p("div", null, [
      z(e.$slots, "default", H(K({ onClick: k }))),
      o(h) ? (c(), G(o(T), {
        key: 0,
        modelValue: m.value,
        "onUpdate:modelValue": a[1] || (a[1] = (i) => m.value = i),
        title: "Insert Embed",
        width: "500px",
        "ok-text": "Insert Embed",
        "cancel-text": "Cancel",
        "ok-disabled": !t.value || !u.value,
        confirm: x,
        "append-to": o(h).target
      }, {
        default: O(() => [
          g("div", {
            class: d(o(s).e("content"))
          }, [
            g("div", {
              class: d(o(s).e("field"))
            }, [
              g("label", {
                class: d(o(s).e("label"))
              }, "URL or Embed Code", 2),
              Z(o(j), {
                ref: B,
                modelValue: t.value,
                "onUpdate:modelValue": a[0] || (a[0] = (i) => t.value = i),
                type: "textarea",
                rows: 3,
                placeholder: "https://youtube.com/watch?v=... or <iframe src=...>",
                onKeydown: $(x, ["enter"]),
                onInput: S
              }, null, 8, ["modelValue"]),
              n.value ? (c(), p("p", {
                key: 0,
                class: d(o(s).e("error"))
              }, L(n.value), 3)) : t.value && u.value ? (c(), p("p", {
                key: 1,
                class: d(o(s).e("success"))
              }, " ✓ Valid " + L(N.value.platform) + " URL ", 3)) : D("", !0)
            ], 2)
          ], 2)
        ]),
        _: 1
      }, 8, ["modelValue", "ok-disabled", "append-to"])) : D("", !0)
    ]));
  }
});
export {
  oe as default
};
//# sourceMappingURL=InsertIframe-BK7GiIag.mjs.map
