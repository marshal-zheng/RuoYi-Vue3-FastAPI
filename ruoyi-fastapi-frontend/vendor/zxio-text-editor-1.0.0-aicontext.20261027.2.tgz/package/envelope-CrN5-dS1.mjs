import { h as et, j as rt, k as nt, i as ot, m as st, c as it, l as V } from "./actions-Sd62WBGv.mjs";
const b = rt, Ft = "data-block-id", ct = {
  heading: "h",
  paragraph: "p",
  bulletList: "ul",
  orderedList: "ol",
  listItem: "li",
  taskList: "tl",
  taskItem: "ti",
  blockquote: "bq",
  codeBlock: "cb",
  horizontalRule: "hr",
  toggle: "tgl",
  toggleSummary: "tgls",
  toggleContent: "tglc",
  attachment: "att",
  image: "img",
  imageGroup: "ig",
  video: "vid",
  iframe: "ifr",
  table: "tbl",
  pageBreak: "pb"
}, at = et(), Ut = nt, w = 10, lt = (t) => t.toLowerCase().replace(/[^a-z0-9]/g, "") || "blk", dt = (t) => (t % 36).toString(36), mt = () => {
  if (typeof crypto < "u" && typeof crypto.getRandomValues == "function") {
    const t = new Uint8Array(w);
    return crypto.getRandomValues(t), Array.from(t, dt).join("");
  }
  return Math.random().toString(36).slice(2, 2 + w);
}, ft = (t) => ct[t] ?? lt(t), $ = (t) => ot(t), Kt = (t = []) => Array.from(/* @__PURE__ */ new Set([...at, ...t.filter(Boolean)])), I = (t) => `${ft(t)}_${mt()}`, xt = (t, e, r) => {
  const n = r == null ? void 0 : r({
    nodeType: t,
    nodeAttrs: e
  });
  return $(n) ? n : I(t);
}, Jt = (t, e, r) => {
  const n = r == null ? void 0 : r(t);
  if ($(n) && !e.has(n))
    return n;
  let o = I(t.nodeType);
  for (; e.has(o); )
    o = I(t.nodeType);
  return o;
}, jt = (t) => !!(t.getMeta("y-sync$") || t.getMeta("isRemote") || t.getMeta("remote") || t.getMeta("collab$")), ut = "heading", z = "id", M = "data-toc-id", yt = (t) => typeof (t == null ? void 0 : t[b]) == "string" ? t[b] : null, pt = (t) => t === ut, Pt = (t, e, r) => {
  const n = {
    ...e ?? {}
  }, o = yt(n) !== r;
  n[b] = r;
  let s = !1;
  return pt(t) && (s = n[z] !== r || n[M] !== r, n[z] = r, n[M] = r), {
    attrs: n,
    blockIdChanged: o,
    headingIdentityChanged: s,
    changed: o || s
  };
}, F = (t = {}) => ({
  blockId: typeof t.blockId == "string" ? t.blockId : "",
  offset: typeof t.offset == "number" && Number.isFinite(t.offset) ? Math.max(t.offset, 0) : 0
}), q = (t = {}) => ({
  start: F(t.start),
  end: F(t.end ?? t.start),
  ...t.quote !== void 0 ? { quote: t.quote } : {},
  ...t.beforeQuote !== void 0 ? { beforeQuote: t.beforeQuote } : {},
  ...t.afterQuote !== void 0 ? { afterQuote: t.afterQuote } : {}
}), X = (t = {}) => ({
  threadId: t.threadId ?? "",
  comments: (t.comments ?? []).map(gt)
}), gt = (t) => ({
  id: t.id,
  ...t.authorId !== void 0 ? { authorId: t.authorId } : {},
  content: t.content,
  createdAt: t.createdAt,
  ...t.updatedAt !== void 0 ? { updatedAt: t.updatedAt } : {}
}), H = (t) => ({
  id: t.id,
  type: t.type,
  anchor: q(t.anchor),
  resolved: t.resolved,
  payload: X(t.payload)
}), Vt = (t) => {
  var e, r;
  return {
    id: t.id,
    type: "comment",
    anchor: q(t.anchor),
    resolved: t.resolved ?? !1,
    payload: X({
      threadId: ((e = t.payload) == null ? void 0 : e.threadId) ?? t.id,
      comments: ((r = t.payload) == null ? void 0 : r.comments) ?? []
    })
  };
}, ht = (t) => (t ?? []).map(H), $t = (...t) => {
  const e = /* @__PURE__ */ new Map();
  return t.forEach((r) => {
    (r ?? []).forEach((n) => {
      e.set(n.id, H(n));
    });
  }), Array.from(e.values());
}, U = (t) => typeof t == "object" && t !== null && !Array.isArray(t), At = (t) => ["string", "number", "boolean"].includes(typeof t), m = (t) => typeof t == "string" && t.trim() ? t.trim() : void 0, i = (t) => typeof t == "string" && t ? t : void 0, p = (t) => typeof t == "number" && Number.isFinite(t) ? t : void 0, Q = (t) => typeof t == "boolean" ? t : void 0, K = (t, e) => {
  const r = i(t);
  return r && r !== e ? r : void 0;
}, x = (t) => Q(t) === !0 ? !0 : void 0, A = (t) => {
  if (!t)
    return;
  const e = Object.entries(t).filter(
    ([, r]) => At(r)
  );
  return e.length ? Object.fromEntries(e) : void 0;
}, Tt = (t) => {
  var e;
  if (t)
    try {
      const n = new URL(t).pathname.split("/").filter(Boolean);
      return n.length ? decodeURIComponent(n.at(-1)) : void 0;
    } catch {
      const n = (((e = t.split("?")[0]) == null ? void 0 : e.split("#")[0]) ?? t).split("/").filter(Boolean);
      return n.length ? decodeURIComponent(n.at(-1)) : void 0;
    }
}, bt = (t) => {
  if (!t)
    return;
  const e = t.toLowerCase().replaceAll(/[^a-z0-9]+/g, "-").replaceAll(/^-+|-+$/g, "");
  return e ? e.slice(0, 24) : void 0;
}, It = (t) => {
  let e = 2166136261;
  for (let r = 0; r < t.length; r += 1)
    e ^= t.charCodeAt(r), e = Math.imul(e, 16777619);
  return (e >>> 0).toString(36);
}, Et = (t) => {
  var o, s;
  const e = m((o = t.meta) == null ? void 0 : o.fileName) ?? m((s = t.meta) == null ? void 0 : s.name) ?? m(t.title) ?? Tt(m(t.src)) ?? t.type, r = bt(e) ?? t.type, n = It(
    JSON.stringify({
      type: t.type,
      src: t.src,
      title: t.title,
      mimeType: t.mimeType,
      meta: t.meta ?? null
    })
  );
  return `asset:${t.type}:${r}:${n}`;
}, G = (t) => {
  const e = m(t.title), r = m(t.mimeType), n = {
    id: m(t.id),
    type: t.type,
    src: typeof t.src == "string" ? t.src : "",
    ...e ? { title: e } : {},
    ...r ? { mimeType: r } : {},
    ...t.meta ? { meta: A(t.meta) } : {}
  };
  return {
    id: n.id ?? Et(n),
    type: n.type,
    src: n.src,
    ...n.title ? { title: n.title } : {},
    ...n.mimeType ? { mimeType: n.mimeType } : {},
    ...n.meta ? { meta: { ...n.meta } } : {}
  };
}, qt = (t) => G(t), T = (t) => (t ?? []).map(G), Bt = (t) => t.id, St = (t, e) => {
  if (e)
    return t == null ? void 0 : t.find((r) => r.id === e);
}, W = (t, e) => ({
  ...t,
  ...e,
  meta: t.meta || e.meta ? {
    ...t.meta ?? {},
    ...e.meta ?? {}
  } : void 0
}), E = (t, e) => {
  var o, s;
  if (t.id === e.id)
    return "id";
  if (t.type !== e.type)
    return null;
  if (t.src === e.src)
    return "src";
  if (t.type !== "embed")
    return null;
  const r = typeof ((o = t.meta) == null ? void 0 : o.name) == "string" ? t.meta.name : void 0, n = typeof ((s = e.meta) == null ? void 0 : s.name) == "string" ? e.meta.name : void 0;
  return r && (r === e.src || r === n) || n && n === t.src ? "embed-name" : null;
}, _t = (t, e) => {
  const r = t.find(
    (c) => E(c, e)
  );
  if (!r)
    return e;
  const n = {
    ...W(r, e),
    id: r.id
  }, o = E(r, e), s = o === "id" ? n : {
    ...n,
    id: r.id
  };
  return o === "embed-name" ? {
    ...s,
    src: r.src
  } : s;
}, Z = (...t) => {
  const e = /* @__PURE__ */ new Map();
  return t.forEach((r) => {
    T(r).forEach((n) => {
      const o = Bt(n), s = e.get(o);
      e.set(
        o,
        s ? W(s, n) : n
      );
    });
  }), Array.from(e.values());
}, Nt = (t) => {
  var r, n, o, s, c, f, l, u, y, a, g, B, S, _, N, R, O, C, L, D, k, v;
  const e = i((r = t.attrs) == null ? void 0 : r.assetId);
  switch (t.type) {
    case "image": {
      const d = i((n = t.attrs) == null ? void 0 : n.src);
      return !d || Q((o = t.attrs) == null ? void 0 : o.loading) ? null : {
        ...e ? { id: e } : {},
        type: "image",
        src: d,
        title: i((s = t.attrs) == null ? void 0 : s.title),
        meta: A({
          alt: i((c = t.attrs) == null ? void 0 : c.alt),
          width: p((f = t.attrs) == null ? void 0 : f.width),
          height: p((l = t.attrs) == null ? void 0 : l.height),
          align: K((u = t.attrs) == null ? void 0 : u.align, "left")
        })
      };
    }
    case "video": {
      const d = i((y = t.attrs) == null ? void 0 : y.src);
      return d ? {
        ...e ? { id: e } : {},
        type: "video",
        src: d
      } : null;
    }
    case "embed": {
      const d = i((a = t.attrs) == null ? void 0 : a.url) ?? i((g = t.attrs) == null ? void 0 : g.name);
      return d ? {
        ...e ? { id: e } : {},
        type: "embed",
        src: d,
        title: i((B = t.attrs) == null ? void 0 : B.title) ?? i((S = t.attrs) == null ? void 0 : S.name),
        meta: A({
          name: i((_ = t.attrs) == null ? void 0 : _.name),
          icon: i((N = t.attrs) == null ? void 0 : N.icon)
        })
      } : null;
    }
    case "iframe": {
      const d = i((R = t.attrs) == null ? void 0 : R.src);
      return d ? {
        ...e ? { id: e } : {},
        type: "embed",
        src: d,
        title: i((O = t.attrs) == null ? void 0 : O.title),
        meta: A({
          width: p((C = t.attrs) == null ? void 0 : C.width),
          height: p((L = t.attrs) == null ? void 0 : L.height),
          align: K((D = t.attrs) == null ? void 0 : D.align, "center"),
          interactive: x((k = t.attrs) == null ? void 0 : k.interactive),
          fullWidth: x((v = t.attrs) == null ? void 0 : v.fullWidth)
        })
      } : null;
    }
    default:
      return null;
  }
}, Rt = (t, e) => {
  var c, f, l, u, y;
  if (!((c = e == null ? void 0 : e.assets) != null && c.length) || typeof t.type != "string")
    return null;
  const r = i((f = t.attrs) == null ? void 0 : f.assetId);
  if (r) {
    const a = St(e.assets, r);
    if (a)
      return a;
  }
  const n = i((l = t.attrs) == null ? void 0 : l.src), o = i((u = t.attrs) == null ? void 0 : u.url), s = i((y = t.attrs) == null ? void 0 : y.name);
  return e.assets.find((a) => {
    var g;
    switch (t.type) {
      case "image":
        return a.type === "image" && a.src === n;
      case "video":
        return a.type === "video" && a.src === n;
      case "embed":
        return a.type === "embed" && (a.src === o || a.src === n || a.src === s || ((g = a.meta) == null ? void 0 : g.name) === s);
      case "iframe":
        return a.type === "embed" && a.src === n;
      default:
        return !1;
    }
  }) ?? null;
}, Y = (t, e) => {
  var n;
  const r = Nt(t);
  r && e.push(r), (n = t.content) == null || n.forEach((o) => Y(o, e));
}, tt = (t) => {
  const e = [];
  return Y(t, e), Z(e);
}, Ot = (t) => ["attachment", "embed", "iframe", "image", "video"].includes(t), Ct = (t, e, r) => {
  var n, o, s, c, f, l, u, y;
  return t === "attachment" ? {
    ...e,
    assetId: r.id
  } : t === "image" ? {
    ...e,
    assetId: r.id,
    src: r.src,
    title: i(e.title) ?? r.title ?? null,
    alt: i(e.alt) ?? m((n = r.meta) == null ? void 0 : n.alt) ?? r.title ?? null,
    width: e.width ?? p((o = r.meta) == null ? void 0 : o.width) ?? null,
    height: e.height ?? p((s = r.meta) == null ? void 0 : s.height) ?? null
  } : t === "video" ? {
    ...e,
    assetId: r.id,
    src: r.src
  } : t === "embed" ? {
    ...e,
    assetId: r.id,
    url: r.src,
    title: i(e.title) ?? r.title ?? m((c = r.meta) == null ? void 0 : c.name) ?? null,
    name: i(e.name) ?? m((f = r.meta) == null ? void 0 : f.name) ?? null,
    icon: i(e.icon) ?? m((l = r.meta) == null ? void 0 : l.icon) ?? null
  } : t === "iframe" ? {
    ...e,
    assetId: r.id,
    src: r.src,
    title: i(e.title) ?? r.title ?? null,
    width: e.width ?? p((u = r.meta) == null ? void 0 : u.width) ?? null,
    height: e.height ?? p((y = r.meta) == null ? void 0 : y.height) ?? null
  } : e;
}, J = (t, e) => {
  if (!(e != null && e.length))
    return JSON.parse(JSON.stringify(t));
  const r = (n) => {
    if (!U(n) || typeof n.type != "string")
      return n;
    const o = {
      ...n
    }, s = U(n.attrs) ? { ...n.attrs } : {};
    if (Ot(n.type)) {
      const c = Rt(
        {
          ...n,
          ...Object.keys(s).length ? { attrs: s } : {}
        },
        { assets: e }
      );
      c ? o.attrs = Ct(
        n.type,
        s,
        c
      ) : Object.keys(s).length && (o.attrs = s);
    } else Object.keys(s).length && (o.attrs = s);
    return Array.isArray(n.content) && n.content.length > 0 && (o.content = n.content.map((c) => r(c))), Array.isArray(n.marks) && n.marks.length > 0 && (o.marks = n.marks.map((c) => ({ ...c }))), o;
  };
  return r(t);
}, Lt = (t, e, r) => {
  const n = T(t), o = T(e), s = n.filter(
    (l) => l.type === "file" || !o.some(
      (u) => E(l, u)
    )
  ), c = n.filter(
    (l) => l.type !== "file"
  ), f = tt(r).map(
    (l) => _t(c, l)
  );
  return Z(s, f);
}, Dt = (t, e) => {
  const r = T(e), n = J(
    t,
    r
  ), o = tt(
    n
  ), s = Lt(
    r,
    o,
    n
  );
  return {
    assets: s,
    content: J(
      n,
      s
    )
  };
}, kt = {
  type: "doc",
  content: []
}, h = (t) => typeof t == "object" && t !== null, j = (t) => JSON.parse(JSON.stringify(t)), P = (t) => JSON.parse(JSON.stringify(t)), vt = (t) => {
  if (!h(t) || typeof t.type != "string")
    return j(kt);
  const e = j(t);
  try {
    return it().nodeFromJSON(e).toJSON();
  } catch {
    return e;
  }
}, wt = (t = {}) => ({
  format: "json",
  content: vt(t.content)
}), zt = (t = {}) => ({
  ...t.title !== void 0 ? { title: t.title } : {},
  ...t.author !== void 0 ? { author: t.author } : {},
  ...t.createdAt !== void 0 ? { createdAt: t.createdAt } : {},
  ...t.updatedAt !== void 0 ? { updatedAt: t.updatedAt } : {},
  ...t.source !== void 0 ? { source: t.source } : {},
  schemaVersion: t.schemaVersion ?? st,
  ...t.pages ? {
    pages: P(t.pages)
  } : {},
  ...t.binaryExport ? {
    binaryExport: P(t.binaryExport)
  } : {}
}), Xt = (t = {}) => {
  const e = wt(t.body), r = Dt(e.content, t.assets);
  return {
    version: V,
    body: {
      ...e,
      content: r.content
    },
    annotations: ht(t.annotations),
    assets: r.assets,
    meta: zt(t.meta)
  };
}, Ht = (t) => !h(t) || t.version !== V || !h(t.body) || t.body.format !== "json" || !h(t.body.content) || typeof t.body.content.type != "string" || !Array.isArray(t.annotations) || !Array.isArray(t.assets) ? !1 : h(t.meta);
export {
  Dt as A,
  wt as B,
  zt as C,
  ct as D,
  Xt as E,
  Ht as F,
  yt as G,
  Pt as H,
  pt as I,
  jt as J,
  b as S,
  at as a,
  Ft as b,
  Ut as c,
  I as d,
  Jt as e,
  Kt as f,
  ft as g,
  F as h,
  $ as i,
  q as j,
  X as k,
  gt as l,
  H as m,
  Vt as n,
  ht as o,
  $t as p,
  G as q,
  xt as r,
  qt as s,
  T as t,
  St as u,
  Z as v,
  Rt as w,
  tt as x,
  J as y,
  Lt as z
};
//# sourceMappingURL=envelope-CrN5-dS1.mjs.map
