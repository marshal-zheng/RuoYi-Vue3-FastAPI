import { t as it, z as dt, A as ct, R as lt, a5 as ut, a8 as Oe } from "./delivery-surfaces-BeupB41w.mjs";
const pt = (e) => typeof e == "object" && e !== null, j = (e) => e === null ? "null" : typeof e == "string" || typeof e == "number" || typeof e == "boolean" ? JSON.stringify(e) : Array.isArray(e) ? `[${e.map((t) => j(t)).join(",")}]` : pt(e) ? `{${Object.keys(e).sort().map((a) => `${JSON.stringify(a)}:${j(e[a])}`).join(",")}}` : JSON.stringify(String(e)), mt = new TextEncoder(), gt = [
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
], M = (e, t) => e >>> t | e << 32 - t, _e = (e) => {
  const t = e.length * 8, a = Math.ceil((e.length + 9) / 64) * 64, r = new Uint8Array(a), n = new DataView(r.buffer), o = new Uint32Array(64);
  r.set(e), r[e.length] = 128, n.setUint32(a - 8, Math.floor(t / 4294967296), !1), n.setUint32(a - 4, t >>> 0, !1);
  let i = 1779033703, s = 3144134277, c = 1013904242, d = 2773480762, l = 1359893119, u = 2600822924, m = 528734635, g = 1541459225;
  for (let p = 0; p < a; p += 64) {
    for (let h = 0; h < 16; h += 1)
      o[h] = n.getUint32(p + h * 4, !1);
    for (let h = 16; h < 64; h += 1) {
      const A = M(o[h - 15], 7) ^ M(o[h - 15], 18) ^ o[h - 15] >>> 3, b = M(o[h - 2], 17) ^ M(o[h - 2], 19) ^ o[h - 2] >>> 10;
      o[h] = o[h - 16] + A + o[h - 7] + b >>> 0;
    }
    let y = i, I = s, w = c, $ = d, x = l, P = u, E = m, N = g;
    for (let h = 0; h < 64; h += 1) {
      const A = M(x, 6) ^ M(x, 11) ^ M(x, 25), b = x & P ^ ~x & E, k = N + A + b + gt[h] + o[h] >>> 0, v = M(y, 2) ^ M(y, 13) ^ M(y, 22), U = y & I ^ y & w ^ I & w, V = v + U >>> 0;
      N = E, E = P, P = x, x = $ + k >>> 0, $ = w, w = I, I = y, y = k + V >>> 0;
    }
    i = i + y >>> 0, s = s + I >>> 0, c = c + w >>> 0, d = d + $ >>> 0, l = l + x >>> 0, u = u + P >>> 0, m = m + E >>> 0, g = g + N >>> 0;
  }
  return [i, s, c, d, l, u, m, g].map((p) => p.toString(16).padStart(8, "0")).join("");
}, L = (e) => _e(mt.encode(e)), oe = (e) => _e(e), an = (e) => L(
  j({
    bundleId: e.bundleId,
    snapshotId: e.snapshotId,
    schemaVersion: e.schemaVersion,
    graphVersion: e.graphVersion,
    rewritePolicyVersion: e.rewritePolicyVersion,
    completionMode: e.completionMode,
    sourceDocuments: e.sourceDocuments,
    members: e.members.map((t) => ({
      id: t.id,
      kind: t.kind,
      origin: t.origin,
      required: t.required,
      materializationState: t.materializationState,
      sourceDocumentId: t.sourceDocumentId,
      diagnosticRefs: t.diagnosticRefs,
      path: t.path,
      mediaType: t.mediaType,
      size: t.size,
      digest: t.digest
    })),
    relationships: e.relationships.map((t) => ({
      from: t.from,
      to: t.to,
      kind: t.kind,
      resolution: t.resolution
    })),
    rewrites: e.rewrites.map((t) => ({
      memberId: t.memberId,
      sourceDocumentId: t.sourceDocumentId,
      source: t.source,
      target: t.target,
      intent: t.intent
    })),
    diagnosticRefs: e.diagnosticRefs
  })
), G = (e, t) => e.filter((a) => a.materializationState === t).length, rn = (e) => ({
  memberCount: e.length,
  materializedCount: G(e, "materialized"),
  pendingCount: G(e, "pending"),
  unresolvedCount: G(e, "unresolved"),
  failedCount: G(e, "failed")
}), ft = (e) => ({
  completion: e.completion ?? "strict-complete",
  includeComments: e.includeComments ?? !0,
  includeAssets: e.includeAssets ?? !0,
  includeSubpages: e.includeSubpages ?? !1,
  sidecars: [...e.sidecars ?? []]
}), nn = (e) => [
  `ns=${e.namespace ?? "text-editor-export-bundle"}`,
  `doc=${e.docId}`,
  `docVersion=${e.docVersion}`,
  `snapshot=${e.snapshotId}`,
  `variant=${L(
    j(ft(e.variant))
  )}`,
  `graph=${e.memberGraphVersion ?? "export-member-graph/v2"}`,
  `rewrite=${e.rewritePolicy ?? "structured-identity-export/v2"}`
].join("|"), ht = "pdf-render-model/v1", on = [
  "error",
  "warning",
  "info"
], sn = [
  "eligibility",
  "composition",
  "capability",
  "lowering",
  "backend",
  "artifact",
  "result"
];
class B extends Error {
  constructor(t, a = []) {
    super(t), this.diagnostics = a, this.name = "ZxBinaryExportError";
  }
}
const _ = (e = []) => e, bt = (e, t) => e.some(
  (a) => a.code === t.code && a.target === t.target && a.phase === t.phase
), dn = (e, t) => (e.push(t), e), f = (e, t) => (bt(e, t) || e.push(t), e), cn = (e) => `${e.code}${e.target ? `:${e.target}` : ""}${e.phase ? ` @${e.phase}` : ""}`, wt = {
  top: 72,
  right: 72,
  bottom: 72,
  left: 72
}, K = {
  size: "a4",
  orientation: "portrait",
  margins: wt
}, Ne = Object.freeze({
  width: 595,
  height: 842
}), xe = {
  enabled: !0,
  showHeader: !1,
  showFooter: !0,
  pageNumbering: "document"
}, W = {
  page: {},
  headerFooter: {},
  includeComments: !0,
  includeBookmarks: !0
}, Ae = {
  a3: {
    width: 842,
    height: 1191
  },
  a4: {
    ...Ne
  },
  a5: {
    width: 420,
    height: 595
  },
  letter: {
    width: 612,
    height: 792
  },
  legal: {
    width: 612,
    height: 1008
  },
  tabloid: {
    width: 792,
    height: 1224
  }
}, yt = (e) => e === "blocking" ? "error" : e === "downgrade" ? "warning" : "info", It = (e) => ({
  page: {
    ...W.page,
    ...(e == null ? void 0 : e.page) ?? {}
  },
  headerFooter: {
    ...W.headerFooter,
    ...(e == null ? void 0 : e.headerFooter) ?? {}
  },
  includeComments: (e == null ? void 0 : e.includeComments) ?? W.includeComments,
  includeBookmarks: (e == null ? void 0 : e.includeBookmarks) ?? W.includeBookmarks
}), kt = (e, t, a, r) => {
  var l, u, m, g, p, y, I, w, $;
  const n = e.sections[t];
  if (!n)
    return {
      ...xe,
      ...a.headerFooter ?? {}
    };
  const o = n.intent.pageNumbering === "hidden" ? "none" : n.intent.pageNumbering === "restart-1" ? "section" : "document", i = {
    enabled: n.intent.headerFooterRole !== "none",
    showHeader: n.intent.headerFooterRole === "first-page",
    showFooter: n.intent.headerFooterRole !== "none",
    pageNumbering: o
  }, s = r === 1 && ((l = e.headerFooter) == null ? void 0 : l.differentFirstPage), c = (s ? (m = (u = e.headerFooter) == null ? void 0 : u.header.firstPage) == null ? void 0 : m.text : void 0) ?? ((p = (g = e.headerFooter) == null ? void 0 : g.header.default) == null ? void 0 : p.text), d = (s ? (I = (y = e.headerFooter) == null ? void 0 : y.footer.firstPage) == null ? void 0 : I.text : void 0) ?? (($ = (w = e.headerFooter) == null ? void 0 : w.footer.default) == null ? void 0 : $.text);
  return {
    ...xe,
    ...i,
    ...a.headerFooter ?? {},
    ...i.enabled && c !== void 0 ? { showHeader: !0, headerText: c } : {},
    ...i.enabled && d !== void 0 ? { showFooter: !0, footerText: d } : {}
  };
}, xt = (e, t, a) => {
  const r = e.sections[t];
  return r ? {
    size: a.page.size ?? r.page.size ?? K.size,
    width: a.page.width ?? r.page.width,
    height: a.page.height ?? r.page.height,
    orientation: a.page.orientation ?? r.page.orientation ?? K.orientation,
    margins: a.page.margins ?? r.page.margins ?? K.margins
  } : {
    ...K,
    ...a.page ?? {}
  };
}, Me = (e) => typeof e.width == "number" && Number.isFinite(e.width) && e.width > 0 && typeof e.height == "number" && Number.isFinite(e.height) && e.height > 0 ? {
  width: e.width,
  height: e.height
} : null, St = (e) => {
  const t = Me(e) ?? Ae[e.size] ?? Ne;
  return e.orientation === "landscape" ? {
    width: t.height,
    height: t.width
  } : t;
}, Bt = (e) => {
  var o, i;
  if (e.kind === "table" && e.table)
    return Math.max(2, e.table.rowCount * 2);
  if (e.kind === "image" || e.kind === "video" || e.kind === "embed")
    return 6;
  if (e.kind === "horizontal-rule")
    return 2;
  const t = ((o = e.codeBlock) == null ? void 0 : o.code.length) ?? ((i = e.text) == null ? void 0 : i.length) ?? e.inlines.reduce((s, c) => s + c.text.length, 0), a = e.kind === "heading" ? 32 : e.kind === "code-block" ? 56 : 72, r = Math.max(1, Math.ceil(t / a)), n = e.kind === "heading" || e.kind === "blockquote" ? 1 : 0;
  return r + n;
}, $t = (e, t) => {
  const a = [];
  let r = 1;
  return e.sections.forEach((n, o) => {
    const i = xt(e, o, t), s = St(i).height - i.margins.top - i.margins.bottom, c = Math.max(8, Math.floor(s / 16));
    let d = [], l = 0, u = 1;
    const m = (g = !1) => {
      if (!d.length && !g)
        return;
      const p = kt(
        e,
        o,
        t,
        u
      );
      a.push({
        id: `pdf-page:${r}`,
        sectionId: n.id,
        pageNumber: r,
        settings: i,
        headerFooter: p,
        blockRefs: d.length ? [...d] : [`empty:${n.id}:${r}`]
      }), r += 1, u += 1, d = [], l = 0;
    };
    n.blocks.forEach((g) => {
      if (g.kind === "page-break") {
        m(!0);
        return;
      }
      const p = Bt(g);
      d.length > 0 && l + p > c && m(), d.push(g.id), l += p;
    }), d.length || d.push(`empty:${n.id}`), m();
  }), a;
}, vt = (e, t, a) => `pdf-render-model-${L(
  j({
    planId: e.id,
    snapshotId: e.snapshotId,
    options: a,
    pageRefs: t.map((r) => ({
      id: r.id,
      sectionId: r.sectionId,
      pageNumber: r.pageNumber,
      settings: r.settings
    })),
    unsupported: e.unsupported.map((r) => r.code)
  })
).slice(0, 24)}`, Pt = (e, t) => {
  e.unsupported.forEach(
    (a) => f(t, {
      code: "binary-export.pdf.lowering.unsupported-semantic",
      message: `${a.code}: ${a.message}`,
      severity: yt(a.severity),
      phase: "lowering",
      format: "pdf",
      planId: e.id,
      target: a.target ?? a.path ?? a.code
    })
  );
}, Ft = (e, t, a) => {
  t.forEach((r) => {
    Ae[r.settings.size] || Me(r.settings) || f(a, {
      code: "binary-export.pdf.lowering.unsupported-page-size",
      message: `PDF lowering fell back to A4 dimensions for unsupported page size "${r.settings.size}".`,
      severity: "warning",
      phase: "lowering",
      format: "pdf",
      planId: e.id,
      target: r.settings.size
    });
  });
}, Dt = (e, t = {}) => {
  const a = t.diagnostics ?? _(), r = It(t.formatOptions), n = $t(e, r), o = r.includeBookmarks ? e.bookmarks.map((d) => ({
    id: d.id,
    label: d.label,
    level: d.level,
    ...d.targetBlockId ? { targetBlockId: d.targetBlockId } : {}
  })) : [], i = r.includeComments ? e.comments.map((d) => ({
    id: d.id,
    threadId: d.threadId,
    targetBlockId: d.startBlockId ?? d.endBlockId,
    resolved: d.resolved,
    commentCount: d.commentCount
  })) : [], s = [
    ...new Set(e.unsupported.map((d) => d.code))
  ];
  s.includes(
    "binary-export.composition.header-footer-odd-even"
  ) && f(a, {
    code: "binary-export.pdf.lowering.header-footer-odd-even-downgrade",
    message: "PDF lowering downgraded odd/even header/footer slots; only default and first-page text are projected.",
    severity: "warning",
    phase: "lowering",
    format: "pdf",
    planId: e.id,
    target: "headerFooter"
  }), !r.includeComments && e.comments.length && f(a, {
    code: "binary-export.pdf.lowering.comments-excluded",
    message: "PDF lowering excluded comments projection because includeComments is disabled.",
    severity: "warning",
    phase: "lowering",
    format: "pdf",
    planId: e.id,
    target: "comments"
  }), !r.includeBookmarks && e.bookmarks.length && f(a, {
    code: "binary-export.pdf.lowering.bookmarks-excluded",
    message: "PDF lowering excluded outline/bookmarks projection because includeBookmarks is disabled.",
    severity: "warning",
    phase: "lowering",
    format: "pdf",
    planId: e.id,
    target: "bookmarks"
  }), Ft(e, n, a), Pt(e, a);
  const c = {
    id: vt(e, n, r),
    version: ht,
    source: "composition-plan",
    planId: e.id,
    metadata: e.metadata,
    formatOptions: r,
    pages: n,
    outline: o,
    comments: i,
    unsupportedSemanticCodes: s
  };
  return f(a, {
    code: "binary-export.pdf.lowering.completed",
    message: `PDF render model lowered from composition plan with ${c.pages.length} page intents.`,
    severity: "info",
    phase: "lowering",
    format: "pdf",
    planId: e.id
  }), c;
}, ln = [
  "supported",
  "partially-supported",
  "unsupported",
  "conditional"
], Tt = [
  "headings",
  "lists",
  "tables",
  "images",
  "links",
  "inlineMarks",
  "metadata",
  "comments",
  "bookmarks",
  "toc",
  "headerFooter",
  "pageNumbering",
  "sectionSettings",
  "stagedBundleInput"
], D = Object.freeze(
  {
    level: "supported"
  }
), T = (e) => ({
  level: e.level,
  ...e.reason ? { reason: e.reason } : {}
}), Ct = () => ({
  headings: T(D),
  lists: T(D),
  tables: T(D),
  images: T(D),
  links: T(D),
  inlineMarks: T(D),
  metadata: T(D),
  comments: T(D),
  bookmarks: T(D),
  toc: T(D),
  headerFooter: T(D),
  pageNumbering: T(D),
  sectionSettings: T(D),
  stagedBundleInput: {
    level: "unsupported",
    reason: "Staged bundle consumption must be explicitly enabled by adapter/backend capability."
  }
}), F = (e) => e ? {
  level: e.level,
  ...e.reason ? { reason: e.reason } : {}
} : T(D), je = (e = {}) => {
  const t = Ct();
  return {
    headings: F(e.headings ?? t.headings),
    lists: F(e.lists ?? t.lists),
    tables: F(e.tables ?? t.tables),
    images: F(e.images ?? t.images),
    links: F(e.links ?? t.links),
    inlineMarks: F(
      e.inlineMarks ?? t.inlineMarks
    ),
    metadata: F(e.metadata ?? t.metadata),
    comments: F(e.comments ?? t.comments),
    bookmarks: F(
      e.bookmarks ?? t.bookmarks
    ),
    toc: F(e.toc ?? t.toc),
    headerFooter: F(
      e.headerFooter ?? t.headerFooter
    ),
    pageNumbering: F(
      e.pageNumbering ?? t.pageNumbering
    ),
    sectionSettings: F(
      e.sectionSettings ?? t.sectionSettings
    ),
    stagedBundleInput: F(
      e.stagedBundleInput ?? t.stagedBundleInput
    )
  };
}, Z = (e) => ({
  format: e.format,
  adapterId: e.adapterId,
  backendId: e.backendId,
  businessReady: je(e.businessReady)
}), Rt = Object.freeze({
  pdf: Z({
    format: "pdf",
    adapterId: "pdf-adapter",
    backendId: "pdf-local-compositor"
  }),
  docx: Z({
    format: "docx",
    adapterId: "docx-adapter",
    backendId: "docx-local-openxml"
  })
}), un = (e) => {
  const t = Rt[e];
  return Z({
    format: t.format,
    adapterId: t.adapterId,
    backendId: t.backendId,
    businessReady: t.businessReady
  });
}, Le = (e) => e === "unsupported" ? "blocking" : e === "partially-supported" || e === "conditional" ? "downgrade" : "info", ze = (e, t) => {
  if (t.reason)
    return t.reason;
  switch (t.level) {
    case "supported":
      return `${e} is fully supported for this adapter/backend.`;
    case "partially-supported":
      return `${e} is only partially supported for this adapter/backend.`;
    case "conditional":
      return `${e} support is conditional for this adapter/backend.`;
    case "unsupported":
      return `${e} is not supported for this adapter/backend.`;
  }
}, Et = (e) => ({
  code: e.code,
  severity: e.severity,
  message: e.message,
  ...e.target ?? e.path ? { target: e.target ?? e.path } : {}
}), Ot = (e, t) => t.level === "supported" ? null : {
  code: `binary-export.capability.${e}`,
  severity: Le(t.level),
  message: ze(e, t),
  target: e
}, _t = (e) => e.severity !== "downgrade" && e.severity !== "blocking" ? null : {
  code: e.code,
  message: e.message,
  ...e.target ? { target: e.target } : {}
}, Nt = (e) => e === "blocking" ? "error" : e === "downgrade" ? "warning" : "info", At = (e) => Tt.filter(
  (t) => t !== "stagedBundleInput"
).map(
  (t) => Ot(t, e.businessReady[t])
).filter((t) => t !== null), Mt = (e, t, a) => {
  if (!t.eligibility.requiresBestEffort)
    return;
  e.push({
    code: "binary-export.fidelity.requires-best-effort",
    severity: "downgrade",
    message: "Composition plan requires best-effort mode because input bundle is staged or non-strict.",
    target: "fidelityMode"
  });
  const r = a.businessReady.stagedBundleInput;
  r.level !== "supported" && e.push({
    code: "binary-export.capability.stagedBundleInput",
    severity: Le(r.level),
    message: ze("stagedBundleInput", r),
    target: "stagedBundleInput"
  });
}, jt = (e) => e.unsupported.map((t) => Et(t)), Lt = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((a) => {
    const r = `${a.code}|${a.target ?? ""}`, n = t.get(r);
    if (!n) {
      t.set(r, a);
      return;
    }
    const o = {
      info: 0,
      downgrade: 1,
      blocking: 2
    };
    o[a.severity] > o[n.severity] && t.set(r, a);
  }), [...t.values()];
}, fe = (e, t, a = {}) => {
  const r = a.mode ?? "fidelity-strict", n = a.tier ?? "business-ready", o = a.diagnostics ?? _(), i = Lt([
    ...At(t),
    ...jt(e)
  ]);
  Mt(i, e, t);
  const s = i.some((u) => u.severity === "blocking"), c = i.some((u) => u.severity === "downgrade"), d = r === "fidelity-strict" ? s || c ? "blocked" : "passed" : s || c ? "degraded" : "passed";
  i.forEach(
    (u) => f(o, {
      code: `binary-export.fidelity.${u.code}`,
      message: u.message,
      severity: Nt(u.severity),
      phase: "capability",
      target: u.target,
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      planId: e.id
    })
  );
  const l = i.map((u) => _t(u)).filter(
    (u) => u !== null
  );
  return {
    tier: n,
    mode: r,
    status: d,
    issues: i,
    downgradeReasons: l,
    directlyDeliverable: d === "passed"
  };
}, pn = (e, t, a = {}) => {
  const r = fe(e, t, a);
  if (r.status === "blocked") {
    const n = a.diagnostics ?? _();
    throw new B(
      "Binary export fidelity gate blocked the request under fidelity-strict mode.",
      n
    );
  }
  return r;
}, Ue = [
  "html-first",
  "browser-print-path",
  "remote-webpage-conversion",
  "consumer-shadow-exporter"
], zt = (e, t) => {
  const a = new Set(t), r = Ue.filter(
    (n) => !a.has(n)
  );
  if (r.length)
    throw new Error(
      `Backend "${e}" must explicitly forbid all platform-disallowed fallback paths. Missing: ${r.join(
        ", "
      )}`
    );
}, Ut = (e, t) => {
  if (e.runtime === "saas-service" && e.trustLevel !== "explicit-saas-opt-in")
    throw new Error(
      `SaaS backend "${e.id}" must use trustLevel "explicit-saas-opt-in".`
    );
  if (e.trustLevel === "explicit-saas-opt-in" && e.runtime !== "saas-service")
    throw new Error(
      `Backend "${e.id}" uses "explicit-saas-opt-in" trustLevel but is not declared as a SaaS runtime.`
    );
  if (e.trustLevel === "explicit-saas-opt-in" && t)
    throw new Error(
      `SaaS backend "${e.id}" cannot be enabled as default.`
    );
}, Xt = (e) => e ? {
  stagedBundleInput: {
    level: "conditional",
    reason: "Staged bundle input is permitted only when explicitly requested and fidelity report is emitted."
  }
} : {
  stagedBundleInput: {
    level: "unsupported",
    reason: "Backend only supports strict-complete bundle input."
  }
}, te = (e) => {
  const t = e.enabledByDefault ?? !1, a = e.allowStagedBundle === !0, r = e.forbiddenFallbacks ?? Ue;
  return Ut(e, t), zt(e.id, r), {
    id: e.id,
    format: e.format,
    runtime: e.runtime,
    trustLevel: e.trustLevel,
    enabledByDefault: t,
    allowStagedBundle: a,
    forbiddenFallbacks: [...r],
    capability: Z({
      format: e.format,
      adapterId: e.adapterId,
      backendId: e.id,
      businessReady: {
        ...je(),
        ...Xt(a),
        ...e.businessReady ?? {}
      }
    }),
    constraints: [...e.constraints ?? []]
  };
}, ae = (e) => {
  const a = new Map(
    e.backends.map((r) => [r.id, r])
  ).get(e.defaultBackendId);
  if (!a)
    throw new Error(
      `Adapter "${e.id}" cannot resolve default backend "${e.defaultBackendId}".`
    );
  if (a.format !== e.format)
    throw new Error(
      `Adapter "${e.id}" format "${e.format}" does not match default backend format "${a.format}".`
    );
  if (a.trustLevel === "explicit-saas-opt-in")
    throw new Error(
      `Adapter "${e.id}" cannot use SaaS opt-in backend as blessed default backend.`
    );
  if (!a.enabledByDefault)
    throw new Error(
      `Adapter "${e.id}" default backend "${a.id}" must be enabledByDefault.`
    );
  return e.backends.forEach((r) => {
    if (r.format !== e.format)
      throw new Error(
        `Backend "${r.id}" format "${r.format}" mismatches adapter format "${e.format}".`
      );
  }), {
    id: e.id,
    format: e.format,
    defaultBackendId: e.defaultBackendId,
    backends: [...e.backends]
  };
}, qt = () => {
  const e = te({
    id: "pdf-local-compositor",
    adapterId: "pdf-adapter",
    format: "pdf",
    runtime: "local-process",
    trustLevel: "trusted-local",
    enabledByDefault: !0
  }), t = te({
    id: "docx-local-openxml",
    adapterId: "docx-adapter",
    format: "docx",
    runtime: "local-process",
    trustLevel: "trusted-local",
    enabledByDefault: !0
  });
  return [
    ae({
      id: "pdf-adapter",
      format: "pdf",
      defaultBackendId: e.id,
      backends: [e]
    }),
    ae({
      id: "docx-adapter",
      format: "docx",
      defaultBackendId: t.id,
      backends: [t]
    })
  ];
}, Ht = qt(), he = (e = Ht) => {
  const t = {};
  if (e.forEach((a) => {
    if (t[a.format])
      throw new Error(
        `Duplicate adapter registration for format "${a.format}".`
      );
    t[a.format] = a;
  }), !t.pdf || !t.docx)
    throw new Error(
      "Adapter registry must register both PDF and DOCX adapters."
    );
  return {
    adapters: {
      pdf: t.pdf,
      docx: t.docx
    }
  };
}, be = (e, t) => {
  const a = e.adapters[t];
  if (!a)
    throw new B(
      `No binary export adapter is registered for format "${t}".`
    );
  return a;
}, de = (e, t, a, r, n, o = "error") => f(e, {
  code: r,
  message: n,
  severity: o,
  phase: "backend",
  format: t.format,
  adapterId: t.id,
  backendId: a
}), Yt = (e, t = {}) => {
  const a = t.diagnostics ?? _(), r = t.backendId ?? e.defaultBackendId, n = e.backends.find((i) => i.id === r);
  if (!n)
    throw de(
      a,
      e,
      r,
      "binary-export.backend.not-registered",
      `Backend "${r}" is not registered under adapter "${e.id}".`
    ), new B(
      `Backend "${r}" is not registered for adapter "${e.id}".`,
      a
    );
  const o = t.backendId === n.id;
  if (n.trustLevel === "explicit-saas-opt-in" && (!o || t.allowSaaSOptIn !== !0))
    throw de(
      a,
      e,
      n.id,
      "binary-export.backend.saas-opt-in-required",
      `SaaS backend "${n.id}" requires explicit backend selection and opt-in.`,
      "error"
    ), new B(
      `SaaS backend "${n.id}" requires explicit opt-in.`,
      a
    );
  if (!o && !n.enabledByDefault)
    throw de(
      a,
      e,
      n.id,
      "binary-export.backend.not-default-enabled",
      `Backend "${n.id}" is disabled by default and must be explicitly selected.`,
      "error"
    ), new B(
      `Backend "${n.id}" must be explicitly selected.`,
      a
    );
  return n;
}, mn = (e, t) => {
  const a = be(e, t.format);
  if (a.backends.some((n) => n.id === t.backend.id))
    throw new Error(
      `Backend "${t.backend.id}" is already registered in adapter "${a.id}".`
    );
  const r = ae({
    id: a.id,
    format: a.format,
    defaultBackendId: a.defaultBackendId,
    backends: [...a.backends, t.backend]
  });
  return he([
    ...Object.values(e.adapters).filter(
      (n) => n.format !== a.format
    ),
    r
  ]);
}, gn = (e, t) => {
  const a = be(e, t.format), r = a.backends.find((i) => i.id === t.backendId);
  if (!r)
    throw new Error(
      `Cannot register capability for unknown backend "${t.backendId}" in adapter "${a.id}".`
    );
  const n = {
    ...r,
    capability: Z({
      format: r.format,
      adapterId: a.id,
      backendId: r.id,
      businessReady: {
        ...r.capability.businessReady,
        ...t.businessReady
      }
    })
  }, o = ae({
    id: a.id,
    format: a.format,
    defaultBackendId: a.defaultBackendId,
    backends: a.backends.map(
      (i) => i.id === n.id ? n : i
    )
  });
  return he([
    ...Object.values(e.adapters).filter(
      (i) => i.format !== a.format
    ),
    o
  ]);
}, Xe = (e, t = _()) => (e.constraints.forEach(
  (a) => f(t, {
    code: `binary-export.backend.constraint.${a.code}`,
    message: a.message,
    severity: "warning",
    phase: "backend",
    format: e.format,
    backendId: e.id
  })
), t), Jt = new TextEncoder(), C = (e) => Jt.encode(e), pe = (e) => {
  const t = e.reduce((n, o) => n + o.length, 0), a = new Uint8Array(t);
  let r = 0;
  return e.forEach((n) => {
    a.set(n, r), r += n.length;
  }), a;
}, qe = Object.freeze({
  width: 595,
  height: 842
}), Vt = {
  a3: {
    width: 842,
    height: 1191
  },
  a4: {
    ...qe
  },
  a5: {
    width: 420,
    height: 595
  },
  letter: {
    width: 612,
    height: 792
  },
  legal: {
    width: 612,
    height: 1008
  },
  tabloid: {
    width: 792,
    height: 1224
  }
}, X = (e) => e.replace(/[^\x20-\x7e]/g, "?").replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)"), Se = (e) => {
  const t = e ? new Date(e) : /* @__PURE__ */ new Date();
  if (Number.isNaN(t.getTime()))
    return "D:19700101000000Z";
  const a = (r) => String(r).padStart(2, "0");
  return `D:${t.getUTCFullYear()}${a(t.getUTCMonth() + 1)}${a(
    t.getUTCDate()
  )}${a(t.getUTCHours())}${a(t.getUTCMinutes())}${a(
    t.getUTCSeconds()
  )}Z`;
}, Zt = (e) => typeof e.settings.width == "number" && Number.isFinite(e.settings.width) && e.settings.width > 0 && typeof e.settings.height == "number" && Number.isFinite(e.settings.height) && e.settings.height > 0 ? {
  width: e.settings.width,
  height: e.settings.height
} : null, He = (e) => {
  const t = Zt(e) ?? Vt[e.settings.size] ?? qe;
  return e.settings.orientation === "landscape" ? {
    width: t.height,
    height: t.width
  } : t;
}, O = (e, t = {}) => ({
  text: e,
  font: t.font ?? "F1",
  fontSize: t.fontSize ?? 12,
  leading: t.leading ?? 18,
  ...t.indent ? { indent: t.indent } : {}
}), Gt = (e) => {
  const t = /^heading-h([1-6])$/.exec(e ?? "");
  return t != null && t[1] ? Number.parseInt(t[1], 10) : 1;
}, H = (e, t = 88) => {
  if (e.length <= t)
    return [e];
  const a = e.split(/\s+/), r = [];
  let n = "";
  return a.forEach((o) => {
    const i = n ? `${n} ${o}` : o;
    if (i.length > t && n) {
      r.push(n), n = o;
      return;
    }
    n = i;
  }), n && r.push(n), r;
}, Kt = (e) => {
  var a, r, n;
  if (e.kind === "table" && e.table) {
    const o = e.table;
    return Array.from(
      { length: o.rowCount },
      (s, c) => o.cells.filter((d) => d.row === c + 1).sort((d, l) => d.column - l.column).map((d) => d.text).join(" | ")
    ).flatMap(
      (s) => H(`| ${s} |`, 72).map(
        (c) => O(c, { font: "F3", fontSize: 10, leading: 14 })
      )
    );
  }
  if (e.kind === "image")
    return [
      O(
        `[Image] ${((a = e.assetRefs) == null ? void 0 : a.join(", ")) ?? e.text ?? e.id}`,
        { font: "F4", fontSize: 11, leading: 16 }
      )
    ];
  if (e.kind === "video")
    return [
      O(
        `[Video] ${((r = e.assetRefs) == null ? void 0 : r.join(", ")) ?? e.text ?? e.id}`,
        { font: "F4", fontSize: 11, leading: 16 }
      )
    ];
  if (e.kind === "embed")
    return [
      O(
        `[Embed] ${((n = e.assetRefs) == null ? void 0 : n.join(", ")) ?? e.text ?? e.id}`,
        { font: "F4", fontSize: 11, leading: 16 }
      )
    ];
  if (e.kind === "horizontal-rule")
    return [
      O("----------------------------------------", {
        font: "F1",
        fontSize: 11,
        leading: 18
      })
    ];
  if (e.kind === "page-break")
    return [];
  const t = e.text ?? e.inlines.map((o) => o.text).join("").trim();
  if (!t)
    return [O(e.kind, { fontSize: 12, leading: 18 })];
  if (e.kind === "list-item")
    return H(`• ${t}`, 76).map(
      (o) => O(o, {
        font: "F1",
        fontSize: 12,
        leading: 18,
        indent: 12
      })
    );
  if (e.kind === "heading") {
    const o = Gt(e.styleRole), s = {
      1: { font: "F2", fontSize: 24, leading: 30 },
      2: { font: "F2", fontSize: 18, leading: 24 },
      3: { font: "F2", fontSize: 15, leading: 20 }
    }[o] ?? {
      font: "F2",
      fontSize: 14,
      leading: 18
    };
    return H(t, o === 1 ? 44 : 58).map(
      (c) => O(c, s)
    );
  }
  if (e.kind === "blockquote")
    return H(t, 74).map(
      (o) => O(`> ${o}`, {
        font: "F4",
        fontSize: 11,
        leading: 17,
        indent: 10
      })
    );
  if (e.kind === "code-block") {
    const o = e.codeBlock, i = o ? [
      o.title.filename,
      o.title.caption,
      o.language.displayLabel
    ].filter(Boolean) : [], s = o ? o.lines.visualLines.map((d, l) => o.display.showLineNumbers ? `${o.lines.lineNumbers[l] ?? o.display.startLine + l}  ${d}` : d) : t.split(`
`);
    return [
      ...i.length ? [i.join(" | ")] : [],
      ...s
    ].flatMap(
      (d) => H(d || " ", 80).map(
        (l) => O(l, {
          font: "F3",
          fontSize: 10,
          leading: 14,
          indent: 12
        })
      )
    );
  }
  return H(t).map(
    (o) => O(o, { font: "F1", fontSize: 12, leading: 18 })
  );
}, Wt = (e, t) => {
  const a = new Map(
    t.sections.flatMap(
      (r) => r.blocks.map((n) => [n.id, n])
    )
  );
  return e.pages.map((r) => {
    const n = r.blockRefs.flatMap((i) => {
      const s = a.get(i);
      return s ? Kt(s) : [
        O(`[Missing block] ${i}`, {
          font: "F4",
          fontSize: 11,
          leading: 16
        })
      ];
    }), o = e.comments.filter(
      (i) => !i.targetBlockId || r.blockRefs.includes(i.targetBlockId)
    );
    return {
      page: r,
      lines: n,
      comments: o
    };
  });
}, Qt = (e) => {
  var c;
  const { height: t } = He(e.page), a = e.page.settings.margins.left, r = t - e.page.settings.margins.top, n = ["BT"];
  let o = r;
  e.lines.forEach((d, l) => {
    l > 0 && (o -= d.leading), n.push(`/${d.font} ${d.fontSize} Tf`), n.push(`1 0 0 1 ${a + (d.indent ?? 0)} ${o} Tm`), n.push(`(${X(d.text)}) Tj`);
  });
  const i = (d) => (d == null ? void 0 : d.replace(
    /\{page\}/g,
    e.page.headerFooter.pageNumbering === "none" ? "" : String(e.page.pageNumber)
  ).trim()) ?? "";
  if (e.page.headerFooter.showFooter) {
    const d = e.page.settings.margins.bottom / 2, l = e.page.headerFooter.footerText !== void 0 ? i(e.page.headerFooter.footerText) : e.page.headerFooter.pageNumbering === "none" ? "" : `Page ${e.page.pageNumber}`;
    l && (n.push("ET"), n.push("BT"), n.push("/F1 10 Tf"), n.push(`${a} ${d} Td`), n.push(`(${X(l)}) Tj`));
  }
  const s = e.page.headerFooter.headerText !== void 0 ? i(e.page.headerFooter.headerText) : ((c = e.lines[0]) == null ? void 0 : c.text) ?? "";
  return e.page.headerFooter.showHeader && s && (n.push("ET"), n.push("BT"), n.push("/F2 10 Tf"), n.push(`${a} ${t - e.page.settings.margins.top + 18} Td`), n.push(`(${X(s)}) Tj`)), n.push("ET"), n.join(`
`);
}, ea = (e, t) => {
  const a = 700 - t * 24, r = a + 18;
  return `<< /Type /Annot /Subtype /Text /Rect [520 ${a} 540 ${r}] /Contents (${X(
    `${e.threadId} (${e.commentCount})`
  )}) /Name /Comment >>`;
}, ta = (e) => {
  const t = e.nextId ? ` /Next ${e.nextId} 0 R` : "", a = e.prevId ? ` /Prev ${e.prevId} 0 R` : "";
  return `<< /Title (${X(e.item.label)}) /Parent ${e.parentId} 0 R${a}${t} /Dest [${e.pageObjectId} 0 R /Fit] >>`;
}, aa = (e, t) => {
  const a = Wt(e, t), r = /* @__PURE__ */ new Map();
  let n = 1;
  const o = () => {
    const b = n;
    return n += 1, b;
  }, i = o(), s = o(), c = o(), d = o(), l = o(), u = o(), m = o(), g = a.map(() => o()), p = a.map(() => o()), y = a.map(
    (b) => b.comments.map(() => o())
  ), I = e.outline.length ? o() : null, w = e.outline.map(() => o());
  if (r.set(
    i,
    `<< /Type /Catalog /Pages ${s} 0 R${I ? ` /Outlines ${I} 0 R /PageMode /UseOutlines` : ""} >>`
  ), r.set(
    s,
    `<< /Type /Pages /Count ${g.length} /Kids [${g.map((b) => `${b} 0 R`).join(" ")}] >>`
  ), r.set(
    c,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"
  ), r.set(
    d,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>"
  ), r.set(
    l,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>"
  ), r.set(
    u,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique >>"
  ), r.set(
    m,
    `<< /Title (${X(
      e.metadata.title ?? "Document"
    )}) /Author (${X(
      e.metadata.author ?? "zxio"
    )}) /Producer (zxio text-editor binary-export) /CreationDate (${Se(
      e.metadata.createdAt
    )}) /ModDate (${Se(e.metadata.updatedAt)}) >>`
  ), a.forEach((b, k) => {
    const v = Qt(b), U = C(v), V = y[k] ?? [], { width: nt, height: ot } = He(b.page), st = V.length ? ` /Annots [${V.map((ie) => `${ie} 0 R`).join(" ")}]` : "";
    r.set(
      g[k],
      `<< /Type /Page /Parent ${s} 0 R /MediaBox [0 0 ${nt} ${ot}] /Resources << /Font << /F1 ${c} 0 R /F2 ${d} 0 R /F3 ${l} 0 R /F4 ${u} 0 R >> >> /Contents ${p[k]} 0 R${st} >>`
    ), r.set(
      p[k],
      `<< /Length ${U.length} >>
stream
${v}
endstream`
    ), b.comments.forEach((ie, Ie) => {
      const ke = V[Ie];
      ke && r.set(
        ke,
        ea(ie, Ie)
      );
    });
  }), I) {
    const b = /* @__PURE__ */ new Map();
    a.forEach((k, v) => {
      k.page.blockRefs.forEach((U) => {
        b.set(U, g[v]);
      });
    }), r.set(
      I,
      `<< /Type /Outlines /Count ${w.length} /First ${w[0]} 0 R /Last ${w[w.length - 1]} 0 R >>`
    ), e.outline.forEach((k, v) => {
      const U = (k.targetBlockId ? b.get(k.targetBlockId) : void 0) ?? g[0];
      r.set(
        w[v],
        ta({
          item: k,
          parentId: I,
          pageObjectId: U,
          prevId: v > 0 ? w[v - 1] : void 0,
          nextId: v < w.length - 1 ? w[v + 1] : void 0
        })
      );
    });
  }
  const $ = C(`%PDF-1.4
%ÿÿÿÿ
`), x = [$], P = [0];
  let E = $.length;
  Array.from(r.entries()).sort((b, k) => b[0] - k[0]).forEach(([b, k]) => {
    P[b] = E;
    const v = C(`${b} 0 obj
${k}
endobj
`);
    x.push(v), E += v.length;
  });
  const N = E, h = ["xref", `0 ${n}`, "0000000000 65535 f "];
  for (let b = 1; b < n; b += 1)
    h.push(
      `${String(P[b] ?? 0).padStart(10, "0")} 00000 n `
    );
  const A = [
    ...h,
    "trailer",
    `<< /Size ${n} /Root ${i} 0 R /Info ${m} 0 R >>`,
    "startxref",
    String(N),
    "%%EOF"
  ].join(`
`);
  return pe([...x, C(`${A}
`)]);
}, ra = "pdf-adapter", na = "pdf-local-compositor", oa = "application/pdf", sa = "application/json", ia = [
  {
    code: "pdf.local-trusted-runtime",
    message: "Blessed PDF backend must run in trusted local or self-hosted execution and never rely on browser print emulation."
  },
  {
    code: "pdf.no-browser-print-path",
    message: "PDF export backend must not fallback to browser print path or UI-owned print glue."
  },
  {
    code: "pdf.no-html-service-input",
    message: "PDF export backend only consumes lowered pdf render model and must not route through HTML-to-PDF service inputs."
  }
], fn = {
  physicalPagination: "supported",
  printLayout: "supported",
  headerFooter: "supported",
  pageNumbering: "supported",
  bookmarks: "supported",
  commentsProjection: "supported",
  metadataProjection: "supported"
}, da = (e, t) => {
  const a = `sha256:${oe(t)}`, r = a.replace("sha256:", "").slice(0, 16);
  return {
    id: `pdf-primary-${r}`,
    format: "pdf",
    kind: "primary",
    mediaType: oa,
    pageCount: e.pages.length,
    size: t.length,
    digest: a,
    locator: {
      kind: "artifact-store-ref",
      value: `artifacts/pdf/${e.id}/${r}.pdf`
    },
    payload: t
  };
}, ca = (e, t) => {
  const a = C(
    JSON.stringify(
      {
        fidelity: t.fidelity,
        unsupported: e.unsupportedSemanticCodes,
        diagnosticCount: t.diagnostics.length
      },
      null,
      2
    )
  ), r = `sha256:${oe(a)}`, n = r.replace("sha256:", "").slice(0, 16);
  return {
    id: `pdf-sidecar-${n}`,
    format: "pdf",
    kind: "sidecar",
    mediaType: sa,
    size: a.length,
    digest: r,
    locator: {
      kind: "artifact-store-ref",
      value: `artifacts/pdf/${e.id}/${n}.fidelity.json`
    },
    payload: a
  };
}, hn = (e) => ({
  physicalPagination: e.capability.businessReady.sectionSettings.level,
  printLayout: e.capability.businessReady.sectionSettings.level,
  headerFooter: e.capability.businessReady.headerFooter.level,
  pageNumbering: e.capability.businessReady.pageNumbering.level,
  bookmarks: e.capability.businessReady.bookmarks.level,
  commentsProjection: e.capability.businessReady.comments.level,
  metadataProjection: e.capability.businessReady.metadata.level
}), la = (e = {}) => te({
  id: na,
  adapterId: ra,
  format: "pdf",
  runtime: "local-process",
  trustLevel: "trusted-local",
  enabledByDefault: !0,
  allowStagedBundle: e.allowStagedBundle ?? !1,
  businessReady: {
    comments: {
      level: "supported",
      reason: "PDF default backend projects comment anchors and counts through composition-plan comment threads."
    },
    bookmarks: {
      level: "supported",
      reason: "PDF default backend emits outline/bookmarks from shared composition navigation anchors."
    },
    toc: {
      level: "supported",
      reason: "PDF default backend preserves TOC anchors as outline targets."
    },
    metadata: {
      level: "supported",
      reason: "PDF default backend projects document metadata fields into PDF document info."
    },
    headerFooter: {
      level: "supported",
      reason: "PDF default backend applies explicit header/footer intent from lowered page model."
    },
    pageNumbering: {
      level: "supported",
      reason: "PDF default backend applies document and section page numbering modes."
    },
    sectionSettings: {
      level: "supported",
      reason: "PDF default backend honors section/page settings from composition page intent."
    },
    ...e.businessReady ?? {}
  },
  constraints: [
    ...ia,
    ...e.constraints ?? []
  ]
}), ua = (e = {}) => {
  const t = la(e);
  return {
    descriptor: t,
    execute: (a, r) => {
      const n = r.diagnostics ?? _(), o = r.fidelityMode ?? "fidelity-strict", i = r.fidelityTier ?? "business-ready";
      if (a.planId !== r.plan.id)
        throw f(n, {
          code: "binary-export.pdf.backend.plan-mismatch",
          message: "PDF render model and execution composition plan identity do not match.",
          severity: "error",
          phase: "backend",
          format: "pdf",
          backendId: t.id,
          planId: r.plan.id,
          target: a.planId
        }), new B(
          "PDF backend received render model built from a different composition plan.",
          n
        );
      Xe(t, n), f(n, {
        code: "binary-export.pdf.backend.execution-started",
        message: "PDF blessed default backend started from lowered render model without HTML/print fallback.",
        severity: "info",
        phase: "backend",
        format: "pdf",
        backendId: t.id,
        planId: r.plan.id
      });
      const s = fe(
        r.plan,
        t.capability,
        {
          tier: i,
          mode: o,
          diagnostics: n
        }
      );
      if (o === "fidelity-strict" && s.status === "blocked")
        throw f(n, {
          code: "binary-export.pdf.backend.fidelity-blocked",
          message: "PDF backend blocked execution because fidelity-strict requirements were not met.",
          severity: "error",
          phase: "backend",
          format: "pdf",
          backendId: t.id,
          planId: r.plan.id,
          target: "fidelity"
        }), new B(
          "PDF default backend blocked by fidelity-strict gate.",
          n
        );
      const c = aa(a, r.plan), d = {
        backendId: t.id,
        artifacts: [da(a, c)],
        diagnostics: [...n],
        fidelity: s
      };
      return (s.status !== "passed" || a.unsupportedSemanticCodes.length > 0) && (d.artifacts = [
        ...d.artifacts,
        ca(a, d)
      ]), s.status === "degraded" && f(n, {
        code: "binary-export.pdf.backend.fidelity-degraded",
        message: "PDF backend completed in best-effort mode with fidelity downgrade report.",
        severity: "warning",
        phase: "backend",
        format: "pdf",
        backendId: t.id,
        planId: r.plan.id
      }), f(n, {
        code: "binary-export.pdf.backend.execution-completed",
        message: `PDF backend produced ${d.artifacts.length} artifact(s).`,
        severity: "info",
        phase: "backend",
        format: "pdf",
        backendId: t.id,
        planId: r.plan.id
      }), {
        ...d,
        diagnostics: [...n]
      };
    }
  };
}, pa = "docx-package-model/v1", ma = (e) => ({
  text: e.text,
  marks: e.marks.map((t) => String(t)),
  ...e.href ? { href: e.href } : {},
  ...e.annotationId ? { annotationId: e.annotationId } : {}
}), ga = {
  top: 72,
  right: 72,
  bottom: 72,
  left: 72
}, Q = {
  includeComments: !0,
  includeBookmarks: !0,
  includeToc: !0,
  preserveSectionPageSettings: !0
}, fa = (e) => e === "blocking" ? "error" : e === "downgrade" ? "warning" : "info", ha = (e) => ({
  includeComments: (e == null ? void 0 : e.includeComments) ?? Q.includeComments,
  includeBookmarks: (e == null ? void 0 : e.includeBookmarks) ?? Q.includeBookmarks,
  includeToc: (e == null ? void 0 : e.includeToc) ?? Q.includeToc,
  preserveSectionPageSettings: (e == null ? void 0 : e.preserveSectionPageSettings) ?? Q.preserveSectionPageSettings
}), ba = (e) => ({
  id: e.id,
  kind: e.kind,
  depth: e.depth,
  ...e.styleRole ? { styleRole: e.styleRole } : {},
  ...e.text ? { text: e.text } : {},
  inlines: e.inlines.map((t) => ma(t)),
  ...e.codeBlock ? { codeBlock: e.codeBlock } : {},
  ...e.table ? {
    table: {
      rowCount: e.table.rowCount,
      columnCount: e.table.columnCount,
      cells: e.table.cells.map((t) => ({
        row: t.row,
        column: t.column,
        text: t.text
      }))
    }
  } : {}
}), wa = (e, t, a) => {
  var s, c, d, l, u, m, g, p, y, I;
  const r = e.sections[t], n = {
    size: "a4",
    orientation: "portrait",
    margins: ga,
    headerFooterRole: "default",
    pageNumbering: "inherit"
  };
  if (!r || !a.preserveSectionPageSettings)
    return n;
  const o = r.intent.headerFooterRole === "none" ? "none" : (s = e.headerFooter) != null && s.differentFirstPage ? "first-page" : r.intent.headerFooterRole ?? "default", i = o === "first-page" && ((c = e.headerFooter) == null ? void 0 : c.differentFirstPage);
  return {
    size: r.page.size ?? n.size,
    width: r.page.width,
    height: r.page.height,
    orientation: r.page.orientation ?? n.orientation,
    margins: r.page.margins ?? n.margins,
    headerFooterRole: o,
    pageNumbering: r.intent.pageNumbering ?? "inherit",
    ...((l = (d = e.headerFooter) == null ? void 0 : d.header.default) == null ? void 0 : l.text) !== void 0 ? { headerText: e.headerFooter.header.default.text } : {},
    ...((m = (u = e.headerFooter) == null ? void 0 : u.footer.default) == null ? void 0 : m.text) !== void 0 ? { footerText: e.headerFooter.footer.default.text } : {},
    ...i && ((p = (g = e.headerFooter) == null ? void 0 : g.header.firstPage) == null ? void 0 : p.text) !== void 0 ? { firstHeaderText: e.headerFooter.header.firstPage.text } : {},
    ...i && ((I = (y = e.headerFooter) == null ? void 0 : y.footer.firstPage) == null ? void 0 : I.text) !== void 0 ? { firstFooterText: e.headerFooter.footer.firstPage.text } : {}
  };
}, ya = /* @__PURE__ */ new Set([
  "a3",
  "a4",
  "a5",
  "letter",
  "legal",
  "tabloid"
]), Ia = (e) => typeof e.settings.width == "number" && Number.isFinite(e.settings.width) && e.settings.width > 0 && typeof e.settings.height == "number" && Number.isFinite(e.settings.height) && e.settings.height > 0, ka = (e, t) => e.sections.map((a, r) => ({
  id: `docx-section:${r + 1}`,
  order: a.order,
  sourceSectionId: a.id,
  sectionBreak: a.intent.sectionBreak,
  settings: wa(e, r, t),
  blocks: a.blocks.map((n) => ba(n))
})), xa = (e) => e.styleRoles.map((t) => ({
  role: t,
  paragraphStyleId: `P_${L(t).slice(0, 8)}`,
  ...t.startsWith("inline:") ? { runStyleId: `R_${L(t).slice(0, 8)}` } : {}
})), Sa = (e, t, a, r) => `docx-package-model-${L(
  j({
    planId: e.id,
    snapshotId: e.snapshotId,
    options: r,
    sectionRefs: t.map((n) => ({
      id: n.id,
      sourceSectionId: n.sourceSectionId,
      blockCount: n.blocks.length
    })),
    styleRefs: a.map((n) => ({
      role: n.role,
      paragraphStyleId: n.paragraphStyleId,
      runStyleId: n.runStyleId
    })),
    unsupported: e.unsupported.map((n) => n.code)
  })
).slice(0, 24)}`, Ba = (e, t) => {
  e.unsupported.forEach(
    (a) => f(t, {
      code: "binary-export.docx.lowering.unsupported-semantic",
      message: `${a.code}: ${a.message}`,
      severity: fa(a.severity),
      phase: "lowering",
      format: "docx",
      planId: e.id,
      target: a.target ?? a.path ?? a.code
    })
  );
}, $a = (e, t, a) => {
  t.forEach((r) => {
    ya.has(r.settings.size) || Ia(r) || f(a, {
      code: "binary-export.docx.lowering.unsupported-page-size",
      message: `DOCX lowering fell back to A4 dimensions for unsupported page size "${r.settings.size}".`,
      severity: "warning",
      phase: "lowering",
      format: "docx",
      planId: e.id,
      target: r.settings.size
    });
  });
}, va = (e, t = {}) => {
  const a = t.diagnostics ?? _(), r = ha(t.formatOptions), n = ka(e, r), o = xa(e), i = r.includeComments ? e.comments.map((u) => ({
    id: u.id,
    threadId: u.threadId,
    targetBlockId: u.startBlockId ?? u.endBlockId,
    resolved: u.resolved,
    commentCount: u.commentCount
  })) : [], s = r.includeBookmarks ? e.bookmarks.map((u) => ({
    id: u.id,
    label: u.label,
    level: u.level,
    ...u.targetBlockId ? { targetBlockId: u.targetBlockId } : {}
  })) : [], c = r.includeToc ? e.tocAnchors.map((u) => ({
    id: u.id,
    label: u.label,
    level: u.level,
    ...u.targetBlockId ? { targetBlockId: u.targetBlockId } : {}
  })) : [], d = [
    ...new Set(e.unsupported.map((u) => u.code))
  ];
  d.includes(
    "binary-export.composition.header-footer-odd-even"
  ) && f(a, {
    code: "binary-export.docx.lowering.header-footer-odd-even-downgrade",
    message: "DOCX lowering downgraded odd/even header/footer slots; only default and first-page text are projected.",
    severity: "warning",
    phase: "lowering",
    format: "docx",
    planId: e.id,
    target: "headerFooter"
  }), !r.includeComments && e.comments.length && f(a, {
    code: "binary-export.docx.lowering.comments-excluded",
    message: "DOCX lowering excluded comments projection because includeComments is disabled.",
    severity: "warning",
    phase: "lowering",
    format: "docx",
    planId: e.id,
    target: "comments"
  }), !r.includeBookmarks && e.bookmarks.length && f(a, {
    code: "binary-export.docx.lowering.bookmarks-excluded",
    message: "DOCX lowering excluded bookmarks projection because includeBookmarks is disabled.",
    severity: "warning",
    phase: "lowering",
    format: "docx",
    planId: e.id,
    target: "bookmarks"
  }), !r.includeToc && e.tocAnchors.length && f(a, {
    code: "binary-export.docx.lowering.toc-excluded",
    message: "DOCX lowering excluded TOC anchors because includeToc is disabled.",
    severity: "warning",
    phase: "lowering",
    format: "docx",
    planId: e.id,
    target: "toc"
  }), $a(e, n, a), Ba(e, a);
  const l = {
    id: Sa(e, n, o, r),
    version: pa,
    source: "composition-plan",
    planId: e.id,
    metadata: e.metadata,
    formatOptions: r,
    sections: n,
    styles: o,
    comments: i,
    bookmarks: s,
    toc: c,
    unsupportedSemanticCodes: d
  };
  return f(a, {
    code: "binary-export.docx.lowering.completed",
    message: `DOCX package model lowered with ${l.sections.length} section(s) and ${l.styles.length} style mapping(s).`,
    severity: "info",
    phase: "lowering",
    format: "docx",
    planId: e.id
  }), l;
}, Pa = (() => {
  const e = new Uint32Array(256);
  for (let t = 0; t < 256; t += 1) {
    let a = t;
    for (let r = 0; r < 8; r += 1)
      a = a & 1 ? 3988292384 ^ a >>> 1 : a >>> 1;
    e[t] = a >>> 0;
  }
  return e;
})(), Fa = (e) => {
  let t = 4294967295;
  return e.forEach((a) => {
    t = Pa[(t ^ a) & 255] ^ t >>> 8;
  }), (t ^ 4294967295) >>> 0;
}, Da = () => {
  const e = /* @__PURE__ */ new Date(), t = Math.max(1980, e.getUTCFullYear()), a = e.getUTCMonth() + 1, r = e.getUTCDate(), n = e.getUTCHours(), o = e.getUTCMinutes(), i = Math.floor(e.getUTCSeconds() / 2);
  return {
    time: n << 11 | o << 5 | i,
    date: t - 1980 << 9 | a << 5 | r
  };
}, Ta = (e) => {
  const t = [], a = [], r = Da();
  let n = 0;
  e.forEach((c) => {
    const d = C(c.name), l = Fa(c.data), u = new Uint8Array(30 + d.length), m = new DataView(u.buffer);
    m.setUint32(0, 67324752, !0), m.setUint16(4, 20, !0), m.setUint16(6, 0, !0), m.setUint16(8, 0, !0), m.setUint16(10, r.time, !0), m.setUint16(12, r.date, !0), m.setUint32(14, l, !0), m.setUint32(18, c.data.length, !0), m.setUint32(22, c.data.length, !0), m.setUint16(26, d.length, !0), m.setUint16(28, 0, !0), u.set(d, 30);
    const g = new Uint8Array(46 + d.length), p = new DataView(g.buffer);
    p.setUint32(0, 33639248, !0), p.setUint16(4, 20, !0), p.setUint16(6, 20, !0), p.setUint16(8, 0, !0), p.setUint16(10, 0, !0), p.setUint16(12, r.time, !0), p.setUint16(14, r.date, !0), p.setUint32(16, l, !0), p.setUint32(20, c.data.length, !0), p.setUint32(24, c.data.length, !0), p.setUint16(28, d.length, !0), p.setUint16(30, 0, !0), p.setUint16(32, 0, !0), p.setUint16(34, 0, !0), p.setUint16(36, 0, !0), p.setUint32(38, 0, !0), p.setUint32(42, n, !0), g.set(d, 46), t.push(u, c.data), a.push(g), n += u.length + c.data.length;
  });
  const o = pe(a), i = new Uint8Array(22), s = new DataView(i.buffer);
  return s.setUint32(0, 101010256, !0), s.setUint16(4, 0, !0), s.setUint16(6, 0, !0), s.setUint16(8, e.length, !0), s.setUint16(10, e.length, !0), s.setUint32(12, o.length, !0), s.setUint32(16, n, !0), s.setUint16(20, 0, !0), pe([
    ...t,
    o,
    i
  ]);
}, Ye = Object.freeze({
  width: 11906,
  height: 16838
}), Ca = {
  a3: {
    width: 16838,
    height: 23811
  },
  a4: {
    ...Ye
  },
  a5: {
    width: 8391,
    height: 11906
  },
  letter: {
    width: 12240,
    height: 15840
  },
  legal: {
    width: 12240,
    height: 20160
  },
  tabloid: {
    width: 15840,
    height: 24480
  }
}, S = (e) => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"), J = (e) => Math.max(0, Math.round(e * 20)), Ra = (e) => typeof e.settings.width == "number" && Number.isFinite(e.settings.width) && e.settings.width > 0 && typeof e.settings.height == "number" && Number.isFinite(e.settings.height) && e.settings.height > 0 ? {
  width: J(e.settings.width),
  height: J(e.settings.height)
} : null, Ea = (e) => {
  const t = Ra(e) ?? Ca[e.settings.size] ?? Ye;
  return e.settings.orientation === "landscape" ? {
    width: t.height,
    height: t.width
  } : t;
}, Be = (e) => {
  if (e.codeBlock) {
    const t = [
      e.codeBlock.title.filename,
      e.codeBlock.title.caption,
      e.codeBlock.language.displayLabel
    ].filter(Boolean), a = e.codeBlock.lines.visualLines.map((r, n) => {
      var i;
      return (i = e.codeBlock) != null && i.display.showLineNumbers ? `${e.codeBlock.lines.lineNumbers[n] ?? e.codeBlock.display.startLine + n}  ${r}` : r;
    });
    return [...t.length ? [t.join(" | ")] : [], ...a].join(`
`);
  }
  return e.table ? [...e.table.cells].sort(
    (t, a) => t.row === a.row ? t.column - a.column : t.row - a.row
  ).map((t) => t.text).join(" | ") : e.text ?? e.inlines.map((t) => t.text).join("").trim();
}, Oa = (e) => {
  const t = [];
  return e.includes("bold") && t.push("<w:b/>"), e.includes("italic") && t.push("<w:i/>"), e.includes("underline") && t.push('<w:u w:val="single"/>'), e.includes("strike") && t.push("<w:strike/>"), e.includes("code") && t.push('<w:rStyle w:val="CodeInline"/>'), t.length ? `<w:rPr>${t.join("")}</w:rPr>` : "";
}, _a = (e, t) => {
  var a;
  return e.styleRole ? (a = t.get(e.styleRole)) == null ? void 0 : a.paragraphStyleId : void 0;
}, Na = (e, t, a) => (a.get(e.id) ?? []).map((n) => {
  const o = t.get(`${e.id}:${n.label}`) ?? 1;
  return `<w:bookmarkStart w:id="${o}" w:name="${S(
    n.label
  )}"/><w:bookmarkEnd w:id="${o}"/>`;
}).join(""), Aa = (e, t) => {
  const a = t.get(e.id) ?? [];
  return a.length ? {
    start: a.map((r) => `<w:commentRangeStart w:id="${r}"/>`).join(""),
    end: a.map((r) => `<w:commentRangeEnd w:id="${r}"/>`).join(""),
    ref: a.map(
      (r) => `<w:r><w:rPr><w:rStyle w:val="CommentReference"/></w:rPr><w:commentReference w:id="${r}"/></w:r>`
    ).join("")
  } : {
    start: "",
    end: "",
    ref: ""
  };
}, Ma = (e) => e.kind === "list-item" ? '<w:r><w:t xml:space="preserve">• </w:t></w:r>' : "", Je = (e) => {
  const {
    block: t,
    stylesByRole: a,
    bookmarkIds: r,
    bookmarksByTarget: n,
    commentIdsByTarget: o
  } = e, i = _a(t, a);
  if (t.kind === "page-break")
    return '<w:p><w:r><w:br w:type="page"/></w:r></w:p>';
  const s = Na(t, r, n), c = Aa(t, o), d = Ma(t), u = !(t.kind === "code-block" && t.codeBlock) && t.inlines.length ? t.inlines.map(
    (m) => `<w:r>${Oa(m.marks)}<w:t${/^\s|\s$/.test(m.text) ? ' xml:space="preserve"' : ""}>${S(m.text)}</w:t></w:r>`
  ).join("") : `<w:r><w:t${/^\s|\s$|\n/.test(Be(t) || "") ? ' xml:space="preserve"' : ""}>${S(Be(t) || "")}</w:t></w:r>`;
  return `<w:p><w:pPr>${i ? `<w:pStyle w:val="${i}"/>` : ""}</w:pPr>${s}${c.start}${d}${u}${c.end}${c.ref}</w:p>`;
}, ee = (e, t, a) => e ? `<w:p><w:pPr><w:pStyle w:val="${t}"/></w:pPr><w:r><w:t>${S(
  e.replace(/\{page\}/g, a === "hidden" ? "" : "PAGE")
)}</w:t></w:r></w:p>` : "", ja = (e, t, a, r, n) => e.table ? `<w:tbl>${Array.from({ length: e.table.rowCount }, (i, s) => `<w:tr>${e.table.cells.filter((d) => d.row === s + 1).sort((d, l) => d.column - l.column).map(
  (d) => `<w:tc><w:p><w:r><w:t>${S(
    d.text
  )}</w:t></w:r></w:p></w:tc>`
).join("")}</w:tr>`).join("")}</w:tbl>` : Je({
  block: e,
  stylesByRole: t,
  bookmarkIds: a,
  bookmarksByTarget: r,
  commentIdsByTarget: n
}), La = (e) => {
  const t = Ea(e), a = e.settings.margins, r = e.settings.pageNumbering === "restart-1" ? '<w:pgNumType w:start="1"/>' : "", n = e.settings.headerFooterRole === "first-page" ? "<w:titlePg/>" : "";
  return `<w:sectPr><w:pgSz w:w="${t.width}" w:h="${t.height}"${e.settings.orientation === "landscape" ? ' w:orient="landscape"' : ""}/><w:pgMar w:top="${J(a.top)}" w:right="${J(
    a.right
  )}" w:bottom="${J(a.bottom)}" w:left="${J(
    a.left
  )}" w:header="720" w:footer="720" w:gutter="0"/>${n}${r}</w:sectPr>`;
}, za = (e) => {
  const t = new Map(e.styles.map((s) => [s.role, s])), a = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
  e.bookmarks.forEach((s, c) => {
    if (!s.targetBlockId)
      return;
    const d = a.get(s.targetBlockId) ?? [];
    a.set(s.targetBlockId, [...d, s]), r.set(`${s.targetBlockId}:${s.label}`, c + 1);
  }), e.comments.forEach((s, c) => {
    if (!s.targetBlockId)
      return;
    const d = n.get(s.targetBlockId) ?? [];
    n.set(s.targetBlockId, [...d, c]);
  });
  const o = e.formatOptions.includeToc && e.toc.length ? '<w:p><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \\o "1-3" \\h \\z \\u </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Table of Contents</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>' : "", i = e.sections.map((s) => {
    const c = s.settings.headerFooterRole === "none" ? "" : `${ee(
      s.settings.firstHeaderText ?? "",
      "HeaderFirst",
      s.settings.pageNumbering
    )}${ee(
      s.settings.headerText ?? "",
      "Header",
      s.settings.pageNumbering
    )}`, d = s.settings.headerFooterRole === "none" ? "" : `${ee(
      s.settings.firstFooterText ?? "",
      "FooterFirst",
      s.settings.pageNumbering
    )}${ee(
      s.settings.footerText ?? "",
      "Footer",
      s.settings.pageNumbering
    )}`, l = s.blocks.map(
      (u) => u.kind === "table" ? ja(
        u,
        t,
        r,
        a,
        n
      ) : Je({
        block: u,
        stylesByRole: t,
        bookmarkIds: r,
        bookmarksByTarget: a,
        commentIdsByTarget: n
      })
    ).join("");
    return `${c}${l}${d}<w:p><w:pPr>${La(
      s
    )}</w:pPr></w:p>`;
  }).join("");
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><w:body>${o}${i}</w:body></w:document>`;
}, Ua = (e) => {
  const t = (c, d, l) => `<w:style w:type="paragraph" w:styleId="${c.paragraphStyleId}"><w:name w:val="${S(
    c.role
  )}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:outlineLvl w:val="${d - 1}"/><w:spacing w:before="${d === 1 ? 320 : 220}" w:after="${d === 1 ? 160 : 120}"/></w:pPr><w:rPr><w:b/><w:color w:val="1F2937"/><w:sz w:val="${l}"/><w:szCs w:val="${l}"/></w:rPr></w:style>`, a = (c) => `<w:style w:type="paragraph" w:styleId="${c.paragraphStyleId}"><w:name w:val="${S(
    c.role
  )}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="120" w:line="360" w:lineRule="auto"/></w:pPr></w:style>`, r = (c) => `<w:style w:type="paragraph" w:styleId="${c.paragraphStyleId}"><w:name w:val="${S(
    c.role
  )}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="80" w:after="80"/><w:ind w:left="720"/><w:pBdr><w:left w:val="single" w:sz="8" w:space="12" w:color="CBD5E1"/></w:pBdr></w:pPr><w:rPr><w:i/><w:color w:val="475569"/></w:rPr></w:style>`, n = (c) => `<w:style w:type="paragraph" w:styleId="${c.paragraphStyleId}"><w:name w:val="${S(
    c.role
  )}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:before="100" w:after="100"/><w:shd w:val="clear" w:color="auto" w:fill="F3F4F6"/></w:pPr><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/><w:color w:val="111827"/><w:sz w:val="20"/><w:szCs w:val="20"/></w:rPr></w:style>`, o = (c) => `<w:style w:type="paragraph" w:styleId="${c.paragraphStyleId}"><w:name w:val="${S(
    c.role
  )}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="60"/><w:ind w:left="720" w:hanging="360"/></w:pPr></w:style>`, i = (c) => `<w:style w:type="paragraph" w:styleId="${c.paragraphStyleId}"><w:name w:val="${S(
    c.role
  )}"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/></w:style>`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="120" w:line="360" w:lineRule="auto"/></w:pPr><w:rPr><w:color w:val="111827"/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr></w:style><w:style w:type="character" w:styleId="CommentReference"><w:name w:val="Comment Reference"/></w:style><w:style w:type="character" w:styleId="CodeInline"><w:name w:val="Code Inline"/><w:rPr><w:rFonts w:ascii="Courier New" w:hAnsi="Courier New"/><w:shd w:val="clear" w:color="auto" w:fill="F3F4F6"/></w:rPr></w:style>${e.map((c) => {
    const d = c.role.startsWith("inline:"), l = (() => {
      if (d)
        return "";
      switch (c.role) {
        case "paragraph":
          return a(c);
        case "blockquote":
          return r(c);
        case "code-block":
          return n(c);
        case "list-item":
          return o(c);
        default: {
          const m = /^heading-h([1-6])$/.exec(c.role);
          if (m) {
            const g = Number.parseInt(m[1] ?? "1", 10);
            return t(
              c,
              g,
              [0, 36, 28, 24, 22, 20, 18][g] ?? 18
            );
          }
          return i(c);
        }
      }
    })(), u = d && c.runStyleId ? `<w:style w:type="character" w:styleId="${c.runStyleId}"><w:name w:val="${S(c.role)}"/></w:style>` : "";
    return `${l}${u}`;
  }).join("")}</w:styles>`;
}, Xa = (e) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:comments xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">${e.map(
  (t, a) => `<w:comment w:id="${a}" w:author="${S(
    t.threadId
  )}"><w:p><w:r><w:t>${S(
    `${t.threadId} (${t.commentCount})`
  )}</w:t></w:r></w:p></w:comment>`
).join("")}</w:comments>`, qa = (e) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>${e ? '<Override PartName="/word/comments.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml"/>' : ""}</Types>`, Ha = () => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>', Ya = (e) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>${e ? '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments" Target="comments.xml"/>' : ""}</Relationships>`, Ja = (e, t) => `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${S(
  e.metadata.title ?? "Document"
)}</dc:title><dc:creator>${S(
  e.metadata.author ?? "zxio"
)}</dc:creator><cp:lastModifiedBy>zxio text-editor</cp:lastModifiedBy><dcterms:created xsi:type="dcterms:W3CDTF">${S(
  e.metadata.createdAt ?? t.metadata.createdAt ?? (/* @__PURE__ */ new Date()).toISOString()
)}</dcterms:created><dcterms:modified xsi:type="dcterms:W3CDTF">${S(
  e.metadata.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString()
)}</dcterms:modified></cp:coreProperties>`, Va = (e, t) => {
  const a = e.formatOptions.includeComments && e.comments.length > 0;
  return Ta([
    {
      name: "[Content_Types].xml",
      data: C(qa(a))
    },
    {
      name: "_rels/.rels",
      data: C(Ha())
    },
    {
      name: "docProps/core.xml",
      data: C(Ja(e, t))
    },
    {
      name: "word/document.xml",
      data: C(za(e))
    },
    {
      name: "word/styles.xml",
      data: C(Ua(e.styles))
    },
    {
      name: "word/_rels/document.xml.rels",
      data: C(Ya(a))
    },
    ...a ? [
      {
        name: "word/comments.xml",
        data: C(Xa(e.comments))
      }
    ] : []
  ]);
}, Za = "docx-adapter", Ga = "docx-local-openxml", Ka = "application/vnd.openxmlformats-officedocument.wordprocessingml.document", Wa = "application/json", Qa = [
  {
    code: "docx.local-trusted-runtime",
    message: "Blessed DOCX backend must run in trusted local or self-hosted execution and emit OpenXML package outputs."
  },
  {
    code: "docx.no-html-converter-path",
    message: "DOCX export backend must not fallback to HTML-to-DOCX converter services."
  },
  {
    code: "docx.no-shadow-exporter",
    message: "DOCX export backend must not route through consumer-owned shadow exporter pipelines."
  }
], bn = {
  wordStructure: "supported",
  styleRoleMapping: "supported",
  sectionSettings: "supported",
  bookmarks: "supported",
  commentsProjection: "supported",
  tocProjection: "supported",
  metadataProjection: "supported"
}, er = (e, t) => {
  const a = `sha256:${oe(t)}`, r = a.replace("sha256:", "").slice(0, 16);
  return {
    id: `docx-primary-${r}`,
    format: "docx",
    kind: "primary",
    mediaType: Ka,
    sectionCount: e.sections.length,
    size: t.length,
    digest: a,
    locator: {
      kind: "artifact-store-ref",
      value: `artifacts/docx/${e.id}/${r}.docx`
    },
    payload: t
  };
}, tr = (e, t) => {
  const a = C(
    JSON.stringify(
      {
        fidelity: t.fidelity,
        unsupported: e.unsupportedSemanticCodes,
        diagnosticCount: t.diagnostics.length
      },
      null,
      2
    )
  ), r = `sha256:${oe(a)}`, n = r.replace("sha256:", "").slice(0, 16);
  return {
    id: `docx-sidecar-${n}`,
    format: "docx",
    kind: "sidecar",
    mediaType: Wa,
    size: a.length,
    digest: r,
    locator: {
      kind: "artifact-store-ref",
      value: `artifacts/docx/${e.id}/${n}.fidelity.json`
    },
    payload: a
  };
}, wn = (e) => ({
  wordStructure: e.capability.businessReady.headings.level,
  styleRoleMapping: e.capability.businessReady.inlineMarks.level,
  sectionSettings: e.capability.businessReady.sectionSettings.level,
  bookmarks: e.capability.businessReady.bookmarks.level,
  commentsProjection: e.capability.businessReady.comments.level,
  tocProjection: e.capability.businessReady.toc.level,
  metadataProjection: e.capability.businessReady.metadata.level
}), ar = (e = {}) => te({
  id: Ga,
  adapterId: Za,
  format: "docx",
  runtime: "local-process",
  trustLevel: "trusted-local",
  enabledByDefault: !0,
  allowStagedBundle: e.allowStagedBundle ?? !1,
  businessReady: {
    comments: {
      level: "supported",
      reason: "DOCX default backend projects comments with stable anchors and thread metadata."
    },
    bookmarks: {
      level: "supported",
      reason: "DOCX default backend maps bookmarks from composition anchors to Word bookmarks."
    },
    toc: {
      level: "supported",
      reason: "DOCX default backend maps TOC anchors for Word navigation fields."
    },
    metadata: {
      level: "supported",
      reason: "DOCX default backend projects metadata into package core properties."
    },
    headerFooter: {
      level: "supported",
      reason: "DOCX default backend applies header/footer role through section settings."
    },
    pageNumbering: {
      level: "supported",
      reason: "DOCX default backend projects page numbering modes through section properties."
    },
    sectionSettings: {
      level: "supported",
      reason: "DOCX default backend applies section/page settings from composition plan intent."
    },
    ...e.businessReady ?? {}
  },
  constraints: [
    ...Qa,
    ...e.constraints ?? []
  ]
}), rr = (e = {}) => {
  const t = ar(e);
  return {
    descriptor: t,
    execute: (a, r) => {
      const n = r.diagnostics ?? _(), o = r.fidelityMode ?? "fidelity-strict", i = r.fidelityTier ?? "business-ready";
      if (a.planId !== r.plan.id)
        throw f(n, {
          code: "binary-export.docx.backend.plan-mismatch",
          message: "DOCX package model and execution composition plan identity do not match.",
          severity: "error",
          phase: "backend",
          format: "docx",
          backendId: t.id,
          planId: r.plan.id,
          target: a.planId
        }), new B(
          "DOCX backend received package model built from a different composition plan.",
          n
        );
      Xe(t, n), f(n, {
        code: "binary-export.docx.backend.execution-started",
        message: "DOCX blessed default backend started from lowered package model without HTML converter fallback.",
        severity: "info",
        phase: "backend",
        format: "docx",
        backendId: t.id,
        planId: r.plan.id
      });
      const s = fe(
        r.plan,
        t.capability,
        {
          tier: i,
          mode: o,
          diagnostics: n
        }
      );
      if (o === "fidelity-strict" && s.status === "blocked")
        throw f(n, {
          code: "binary-export.docx.backend.fidelity-blocked",
          message: "DOCX backend blocked execution because fidelity-strict requirements were not met.",
          severity: "error",
          phase: "backend",
          format: "docx",
          backendId: t.id,
          planId: r.plan.id,
          target: "fidelity"
        }), new B(
          "DOCX default backend blocked by fidelity-strict gate.",
          n
        );
      const c = Va(a, r.plan), d = {
        backendId: t.id,
        artifacts: [er(a, c)],
        diagnostics: [...n],
        fidelity: s
      };
      return (s.status !== "passed" || a.unsupportedSemanticCodes.length > 0) && (d.artifacts = [
        ...d.artifacts,
        tr(a, d)
      ]), s.status === "degraded" && f(n, {
        code: "binary-export.docx.backend.fidelity-degraded",
        message: "DOCX backend completed in best-effort mode with fidelity downgrade report.",
        severity: "warning",
        phase: "backend",
        format: "docx",
        backendId: t.id,
        planId: r.plan.id
      }), f(n, {
        code: "binary-export.docx.backend.execution-completed",
        message: `DOCX backend produced ${d.artifacts.length} artifact(s).`,
        severity: "info",
        phase: "backend",
        format: "docx",
        backendId: t.id,
        planId: r.plan.id
      }), {
        ...d,
        diagnostics: [...n]
      };
    }
  };
}, Y = (e) => ({
  phase: "eligibility",
  ...e
}), nr = (e) => (e.severity ?? "error") === "error", or = (e, t = {}) => {
  const a = t.diagnostics ?? _(), r = [], n = t.allowStagedBundle === !0, o = e.completion.mode, i = e.completion.state, s = e.bundle.manifest;
  s.integrity.manifestDigest || r.push(
    Y({
      code: "binary-export.eligibility.manifest-digest-missing",
      message: "Export bundle manifest digest is required before binary export can start.",
      severity: "error",
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      bundleId: s.bundleId
    })
  );
  const c = s.members.find(
    (l) => l.kind === "canonical-document" && l.required
  );
  c ? c.materializationState !== "materialized" && r.push(
    Y({
      code: "binary-export.eligibility.canonical-member-unmaterialized",
      message: "Canonical document member must be materialized before binary export.",
      severity: "error",
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      bundleId: s.bundleId,
      target: c.id
    })
  ) : r.push(
    Y({
      code: "binary-export.eligibility.canonical-member-missing",
      message: "Export bundle must include a required canonical-document member.",
      severity: "error",
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      bundleId: s.bundleId
    })
  ), !n && o !== "strict-complete" && r.push(
    Y({
      code: "binary-export.eligibility.non-strict-mode-blocked",
      message: "Binary export defaults to strict-complete bundles unless staged support is explicitly enabled.",
      severity: "error",
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      bundleId: s.bundleId
    })
  ), !n && i !== "complete" && r.push(
    Y({
      code: "binary-export.eligibility.staged-bundle-blocked",
      message: "Staged bundles are blocked by default for binary export eligibility.",
      severity: "error",
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      bundleId: s.bundleId
    })
  ), n && i === "staged" && r.push(
    Y({
      code: "binary-export.eligibility.staged-bundle-accepted",
      message: "Staged bundle accepted because adapter/backend explicitly enables staged input.",
      severity: "warning",
      format: t.format,
      adapterId: t.adapterId,
      backendId: t.backendId,
      bundleId: s.bundleId
    })
  ), r.forEach(
    (l) => f(a, l)
  );
  const d = !r.some(nr);
  return {
    eligible: d,
    completionMode: o,
    completionState: i,
    requiresBestEffort: d && (o !== "strict-complete" || i === "staged"),
    reasons: r
  };
}, sr = (e, t = {}) => {
  const a = or(e, t);
  if (!a.eligible)
    throw new B(
      "Binary export bundle is not eligible for composition planning.",
      [...a.reasons]
    );
  return a;
}, ir = "binary-composition-plan/v1", dr = {
  heading: "heading",
  paragraph: "paragraph",
  blockquote: "blockquote",
  bulletList: "list",
  orderedList: "list",
  taskList: "list",
  listItem: "list-item",
  taskItem: "list-item",
  codeBlock: "code-block",
  table: "table",
  tableRow: "table-row",
  tableCell: "table-cell",
  tableHeader: "table-cell",
  image: "image",
  video: "video",
  embed: "embed",
  horizontalRule: "horizontal-rule",
  [Oe]: "page-break"
}, $e = /* @__PURE__ */ new Set(["text", "hardBreak"]), cr = ct(), ce = Object.freeze({
  size: "a4",
  orientation: "portrait",
  margins: {
    top: 72,
    right: 72,
    bottom: 72,
    left: 72
  }
}), re = Object.freeze({
  sectionBreak: "document-start",
  pageBreakBefore: !1,
  headerFooterRole: "default",
  pageNumbering: "inherit"
}), q = (e) => typeof e == "object" && e !== null, z = (e) => typeof e == "string" && e.trim() ? e.trim() : void 0, lr = (e) => typeof e == "number" && Number.isFinite(e) ? Math.max(1, Math.round(e)) : typeof e == "string" && /^\d+$/.test(e.trim()) ? Math.max(1, Number.parseInt(e.trim(), 10)) : null, Ve = (e) => e.replace(/\s+/g, " ").trim(), ur = (e) => (e ?? []).map((t) => se(t)).filter(Boolean).join(" "), se = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? " " : ur(e.content), pr = (e) => {
  const t = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map();
  return e.forEach((r, n) => {
    const o = `asset:${n + 1}`, i = r.id ?? o;
    a.set(i, r);
    const s = t.get(r.src) ?? [];
    t.set(r.src, [...s, i]);
  }), {
    assetById: a,
    idsBySrc: t
  };
}, R = (e, t, a) => {
  e.unsupported.push(t), f(e.diagnostics, {
    code: t.code,
    message: t.message,
    severity: t.severity === "blocking" ? "error" : t.severity === "downgrade" ? "warning" : "info",
    phase: "composition",
    target: t.target ?? t.path,
    ...a
  });
}, mr = /* @__PURE__ */ new Set([
  "codeBlock.delivery.contractRepairRequired",
  "codeBlock.highlighter.unsupportedLanguage",
  "codeBlock.delivery.partial",
  "codeBlock.binary.interactionPartial",
  "codeBlock.binary.lineModelPartial",
  "codeBlock.binary.copyModeUnsupported"
]), gr = (e) => e.severity === "error" ? "blocking" : e.severity === "warning" ? "downgrade" : "info", fr = (e, t, a) => {
  t.forEach((r) => {
    mr.has(r.code) && R(e, {
      code: r.code,
      severity: gr(r),
      message: r.message,
      target: "codeBlock",
      path: `${a}.${r.path}`
    });
  });
}, hr = (e) => e === "textStyle" ? "text-style" : e, Ze = (e, t, a = []) => {
  var r;
  if (e.type === "text" && typeof e.text == "string") {
    const n = Array.isArray(e.marks) ? e.marks : [], o = [];
    let i, s;
    return n.forEach((c) => {
      const d = z(c == null ? void 0 : c.type);
      if (!d)
        return;
      o.push(hr(d)), t.styleRoles.add(`inline:${d}`);
      const l = q(c.attrs) ? c.attrs : {};
      d === "link" && (i = z(l.href)), d === "comment" && (s = z(l.commentId));
    }), a.push({
      text: e.text,
      marks: o,
      ...i ? { href: i } : {},
      ...s ? { annotationId: s } : {}
    }), a;
  }
  return e.type === "hardBreak" ? (a.push({
    text: `
`,
    marks: []
  }), a) : ((r = e.content) == null || r.forEach((n) => {
    Ze(n, t, a);
  }), a);
}, me = (e) => {
  const t = q(e.attrs) ? e.attrs : {};
  return z(t.blockId) ?? z(t.id);
}, br = (e) => {
  const t = q(e.attrs) ? e.attrs : {};
  switch (e.type) {
    case "heading": {
      const a = lr(t.level);
      return a ? `heading-h${a}` : "heading";
    }
    case "paragraph":
      return "paragraph";
    case "blockquote":
      return "blockquote";
    case "codeBlock":
      return "code-block";
    case "table":
      return "table";
    case "bulletList":
    case "orderedList":
    case "taskList":
      return "list";
    case "listItem":
    case "taskItem":
      return "list-item";
    case "image":
      return "media-image";
    case "video":
      return "media-video";
    case "embed":
      return "media-embed";
    case Oe:
      return "page-break";
    default:
      return;
  }
}, wr = (e) => {
  const t = (e.content ?? []).filter(
    (n) => n.type === "tableRow"
  ), a = [];
  let r = 0;
  return t.forEach((n, o) => {
    const i = (n.content ?? []).filter(
      (s) => s.type === "tableCell" || s.type === "tableHeader"
    );
    r = Math.max(r, i.length), i.forEach((s, c) => {
      a.push({
        row: o + 1,
        column: c + 1,
        text: Ve(se(s)),
        ...me(s) ? { blockId: me(s) } : {}
      });
    });
  }), {
    rowCount: t.length,
    columnCount: r,
    cells: a
  };
}, yr = (e, t, a, r) => {
  const n = q(e.attrs) ? e.attrs : {}, o = z(n.src);
  if (!o)
    return [];
  const i = a.get(o) ?? [];
  return i.length || R(t, {
    code: "binary-export.composition.asset-reference-unresolved",
    severity: "downgrade",
    message: `Node at "${r}" references src "${o}" but no exported asset was matched.`,
    path: r
  }), i;
}, Ge = (e, t, a, r, n, o = [], i) => (e.forEach((s, c) => {
  const d = z(s.type), l = `${a}.${c}`;
  if (!d || $e.has(d))
    return;
  const u = dr[d] ?? "unknown", m = br(s), g = d === "codeBlock" ? it(s) : void 0, p = g ? dt(g) : void 0, y = (g == null ? void 0 : g.summary.text) ?? Ve(se(s)), I = Ze(s, r), w = u === "table" ? wr(s) : void 0, $ = yr(s, r, n, l), x = me(s), P = cr.resolveRule(d);
  u === "unknown" && R(r, {
    code: "binary-export.composition.unsupported-node",
    severity: "downgrade",
    message: `Node type "${d}" at "${l}" has no stable composition mapping.`,
    target: d,
    path: l
  }), !(d === "listItem" && (i === "bulletList" || i === "orderedList") || d === "taskItem" && i === "taskList") && P.exportSensitive && P.risk !== "safe" && R(r, {
    code: "pages.blockSafety.export-fidelity-risk",
    severity: "downgrade",
    message: P.message,
    target: x ?? d,
    path: l
  }), m && r.styleRoles.add(m), p && fr(
    r,
    p.diagnostics,
    l
  ), o.push({
    id: x ?? `block:${l}`,
    nodeType: d,
    kind: u,
    depth: t,
    ...x ? { blockId: x } : {},
    ...m ? { styleRole: m } : {},
    ...y ? { text: y } : {},
    inlines: I,
    ...w ? { table: w } : {},
    ...$.length ? { assetRefs: $ } : {},
    ...p ? { codeBlock: p } : {}
  });
  const N = (s.content ?? []).filter((h) => {
    const A = z(h.type);
    return !!(A && !$e.has(A));
  });
  N.length && Ge(
    N,
    t + 1,
    l,
    r,
    n,
    o,
    d
  );
}), o), Ir = (e) => e.filter((t) => t.kind === "page-break").map((t) => ({
  id: `page-break:${t.id}`,
  ...t.blockId ? { blockId: t.blockId } : {},
  preserveEmptyPage: !0
})), kr = (e) => {
  const t = /#asset:(.+)$/.exec(e);
  if (t != null && t[1])
    return t[1];
  if (e.startsWith("asset:"))
    return e.slice(6);
}, ve = (e) => e ? e === "image" || e === "video" ? "display" : e === "embed" ? "embed" : e === "file" ? "download" : "unknown" : "unknown", Pe = (e) => {
  var a;
  if (!e)
    return "unknown";
  const t = (a = e.meta) == null ? void 0 : a.hidden;
  return t === !0 || t === "true" ? "hidden" : "visible";
}, xr = (e, t) => {
  const a = kr(e.id);
  if (a) {
    const r = t.assets.find((n) => n.id === a);
    if (r)
      return r;
  }
  return t.assets.find((r, n) => {
    const o = `${n + 1}`;
    return a === o;
  });
}, Sr = (e, t, a) => {
  const r = e.bundle.manifest.members.filter(
    (i) => i.kind === "asset"
  ), n = /* @__PURE__ */ new Set(), o = r.map((i) => {
    const s = xr(i, t);
    return s != null && s.id && n.add(s.id), i.materializationState !== "materialized" && R(a, {
      code: "binary-export.composition.asset-not-materialized",
      severity: i.required ? "blocking" : "downgrade",
      message: `Asset member "${i.id}" is "${i.materializationState}" during composition.`,
      target: i.id
    }), {
      id: (s == null ? void 0 : s.id) ?? i.id,
      memberId: i.id,
      ...i.sourceDocumentId ? { sourceDocumentId: i.sourceDocumentId } : {},
      ...s != null && s.type ? { type: s.type } : {},
      ...s != null && s.src ? { src: s.src } : {},
      ...i.mediaType ? { mediaType: i.mediaType } : {},
      materializationState: i.materializationState,
      required: i.required,
      visibility: Pe(s),
      role: ve(s == null ? void 0 : s.type),
      ...i.path ? { locator: i.path } : {}
    };
  });
  return t.assets.forEach((i, s) => {
    const c = i.id ?? `asset:${s + 1}`;
    n.has(c) || (R(a, {
      code: "binary-export.composition.asset-not-manifested",
      severity: "downgrade",
      message: `Document asset "${c}" did not map to an exported asset member.`,
      target: c
    }), o.push({
      id: c,
      memberId: `asset-unmapped:${c}`,
      type: i.type,
      src: i.src,
      materializationState: "unresolved",
      required: !1,
      visibility: Pe(i),
      role: ve(i.type)
    }));
  }), o;
}, Br = (e) => e.annotations.map((t) => ({
  id: t.id,
  threadId: t.payload.threadId,
  annotationId: t.id,
  ...t.anchor.start.blockId ? { startBlockId: t.anchor.start.blockId } : {},
  ...t.anchor.end.blockId ? { endBlockId: t.anchor.end.blockId } : {},
  resolved: t.resolved,
  commentCount: t.payload.comments.length
})), $r = ["default", "firstPage"], Ke = (e) => Array.isArray(e.marks) && e.marks.length > 0 ? !0 : (e.content ?? []).some((t) => Ke(t)), vr = (e, t, a, r) => {
  if (!q(e))
    return;
  if (e.state === "empty")
    return {
      slot: t,
      text: ""
    };
  if (e.state !== "content" || !q(e.content))
    return;
  const n = e.content, o = se(n);
  return o.includes("{total}") && R(a, {
    code: "binary-export.composition.header-footer-total-placeholder",
    severity: "downgrade",
    message: "Header/footer {total} placeholder is preserved for backends that support total page fields.",
    target: r
  }), Ke(n) && R(a, {
    code: "binary-export.composition.header-footer-inline-marks",
    severity: "downgrade",
    message: "Header/footer inline marks and links are reduced to plain text for first-phase binary export.",
    target: r
  }), {
    slot: t,
    text: o
  };
}, Fe = (e, t, a) => q(e) ? ((e.oddPage || e.evenPage) && R(a, {
  code: "binary-export.composition.header-footer-odd-even",
  severity: "downgrade",
  message: "Odd/even header/footer slots are preserved in document truth but downgraded in first-phase binary export.",
  target: t
}), $r.reduce((r, n) => {
  const o = vr(
    e[n],
    n,
    a,
    `headerFooter.${t}.${n}`
  );
  return o ? {
    ...r,
    [n]: o
  } : r;
}, {})) : {}, Pr = (e, t) => {
  var n;
  const a = (n = e.meta.pages) == null ? void 0 : n.headerFooter;
  if (!a)
    return null;
  const r = ut(a);
  return {
    version: 1,
    differentFirstPage: r.differentFirstPage,
    differentOddEven: r.differentOddEven,
    header: Fe(r.header, "header", t),
    footer: Fe(r.footer, "footer", t)
  };
}, We = (e, t) => e === "document-start" || e === "continuous" || e === "next-page" ? e : t, Qe = (e) => e === "default" || e === "first-page" || e === "none" ? e : re.headerFooterRole, et = (e) => e === "inherit" || e === "restart-1" || e === "hidden" ? e : re.pageNumbering, Fr = (e) => {
  var t, a, r, n, o, i, s, c, d, l, u, m;
  return {
    size: ((a = (t = e == null ? void 0 : e.defaults) == null ? void 0 : t.page) == null ? void 0 : a.size) ?? ce.size,
    ...(n = (r = e == null ? void 0 : e.defaults) == null ? void 0 : r.page) != null && n.label ? { label: e.defaults.page.label } : {},
    ...(i = (o = e == null ? void 0 : e.defaults) == null ? void 0 : o.page) != null && i.width ? { width: e.defaults.page.width } : {},
    ...(c = (s = e == null ? void 0 : e.defaults) == null ? void 0 : s.page) != null && c.height ? { height: e.defaults.page.height } : {},
    orientation: ((l = (d = e == null ? void 0 : e.defaults) == null ? void 0 : d.page) == null ? void 0 : l.orientation) ?? ce.orientation,
    margins: ((m = (u = e == null ? void 0 : e.defaults) == null ? void 0 : u.page) == null ? void 0 : m.margins) ?? ce.margins
  };
}, Dr = (e) => {
  var t, a, r, n, o, i, s, c;
  return {
    sectionBreak: We(
      (a = (t = e == null ? void 0 : e.defaults) == null ? void 0 : t.intent) == null ? void 0 : a.sectionBreak,
      re.sectionBreak
    ),
    pageBreakBefore: ((n = (r = e == null ? void 0 : e.defaults) == null ? void 0 : r.intent) == null ? void 0 : n.pageBreakBefore) ?? re.pageBreakBefore,
    headerFooterRole: Qe(
      (i = (o = e == null ? void 0 : e.defaults) == null ? void 0 : o.intent) == null ? void 0 : i.headerFooterRole
    ),
    pageNumbering: et(
      (c = (s = e == null ? void 0 : e.defaults) == null ? void 0 : s.intent) == null ? void 0 : c.pageNumbering
    )
  };
}, De = (e) => {
  var t, a;
  return e.length && ((t = e[0]) != null && t.blockId) ? [
    {
      id: "section-1",
      startBlockId: e[0].blockId
    }
  ] : [
    {
      id: "section-1",
      startBlockId: ((a = e[0]) == null ? void 0 : a.id) ?? "section-1"
    }
  ];
}, Tr = (e, t, a) => {
  const r = /* @__PURE__ */ new Map();
  e.forEach((c, d) => {
    r.set(c.id, d), c.blockId && r.set(c.blockId, d);
  });
  const n = [...(t == null ? void 0 : t.sections) ?? []], i = (n.length ? n : De(e)).map((c, d) => {
    const l = r.get(c.startBlockId);
    return l === void 0 ? (R(a, {
      code: "binary-export.composition.section-start-unresolved",
      severity: "blocking",
      message: `Section "${c.id}" references unknown startBlockId "${c.startBlockId}".`,
      target: c.id,
      path: c.startBlockId
    }), null) : {
      ...c,
      startIndex: l,
      ordinal: d
    };
  }).filter(
    (c) => c !== null
  ).sort((c, d) => c.startIndex - d.startIndex);
  if (!i.length)
    return [
      {
        ...De(e)[0],
        startIndex: 0,
        ordinal: 0
      }
    ];
  const s = i[0];
  if (s && s.startIndex > 0) {
    const c = e[0], d = (c == null ? void 0 : c.blockId) ?? (c == null ? void 0 : c.id);
    d && (f(a.diagnostics, {
      code: "binary-export.composition.implicit-leading-section",
      message: "Binary export inserted an implicit leading section because explicit section definitions do not start at the first block.",
      severity: "warning",
      phase: "composition",
      target: d
    }), i.unshift({
      id: "section-1",
      startBlockId: d,
      startIndex: 0,
      ordinal: -1
    }));
  }
  return i;
}, Cr = (e, t, a) => {
  const r = lt(e), n = Fr(r), o = Dr(r), i = Tr(t, r, a);
  return i.map((s, c) => {
    var p, y, I, w, $, x, P, E, N, h, A, b, k;
    const d = i[c + 1], l = s.startIndex, u = d ? d.startIndex : t.length, m = t.slice(l, u), g = c === 0 ? "document-start" : "next-page";
    return {
      id: s.id,
      order: c + 1,
      page: {
        size: ((p = s.page) == null ? void 0 : p.size) ?? n.size,
        ...((y = s.page) == null ? void 0 : y.label) ?? n.label ? { label: ((I = s.page) == null ? void 0 : I.label) ?? n.label } : {},
        ...((w = s.page) == null ? void 0 : w.width) ?? n.width ? { width: (($ = s.page) == null ? void 0 : $.width) ?? n.width } : {},
        ...((x = s.page) == null ? void 0 : x.height) ?? n.height ? { height: ((P = s.page) == null ? void 0 : P.height) ?? n.height } : {},
        orientation: ((E = s.page) == null ? void 0 : E.orientation) ?? n.orientation,
        margins: ((N = s.page) == null ? void 0 : N.margins) ?? n.margins
      },
      intent: {
        sectionBreak: We(
          (h = s.intent) == null ? void 0 : h.sectionBreak,
          g
        ),
        pageBreakBefore: ((A = s.intent) == null ? void 0 : A.pageBreakBefore) ?? (c === 0 ? o.pageBreakBefore : g === "next-page"),
        headerFooterRole: Qe(
          ((b = s.intent) == null ? void 0 : b.headerFooterRole) ?? o.headerFooterRole
        ),
        pageNumbering: et(
          ((k = s.intent) == null ? void 0 : k.pageNumbering) ?? o.pageNumbering
        )
      },
      blocks: m
    };
  });
}, Rr = (e) => {
  const t = e.bundle.snapshot.projections.outline ?? [], a = t.map((n, o) => ({
    id: `bookmark:${o + 1}`,
    label: n.label,
    level: n.level,
    ...n.blockId ? { targetBlockId: n.blockId } : {}
  })), r = t.map((n, o) => ({
    id: `toc:${o + 1}`,
    label: n.label,
    level: n.level,
    ...n.blockId ? { targetBlockId: n.blockId } : {}
  }));
  return {
    bookmarks: a,
    tocAnchors: r
  };
}, Er = (e, t) => {
  const a = e.bundle.snapshot.verification;
  a.unresolvedAnnotations > 0 && R(t, {
    code: "binary-export.composition.unresolved-annotations",
    severity: "blocking",
    message: `Snapshot still has ${a.unresolvedAnnotations} unresolved annotations.`
  }), a.stableBlockIdentityIssues.forEach((r) => {
    R(t, {
      code: "binary-export.composition.stable-block-identity-issue",
      severity: "blocking",
      message: r.message,
      target: r.code,
      path: r.path
    });
  });
}, Or = (e, t) => `binary-plan-${L(
  j({
    bundleId: e.bundle.manifest.bundleId,
    snapshotId: e.bundle.snapshot.id,
    completion: e.completion,
    formats: [...t].sort(),
    cacheKey: e.cacheKey
  })
)}`, _r = (e) => {
  var t;
  return (t = e == null ? void 0 : e.formatTargets) != null && t.length ? [...new Set(e.formatTargets)] : ["pdf", "docx"];
}, Nr = (e, t = {}) => {
  const a = t.diagnostics ?? _(), r = _r(t), n = sr(e, {
    allowStagedBundle: t.allowStagedBundle,
    diagnostics: a
  }), o = {
    diagnostics: a,
    unsupported: [],
    styleRoles: /* @__PURE__ */ new Set()
  }, i = e.bundle.snapshot, s = i.document, c = pr(s.assets), d = s.body.content.content ?? [], l = Ge(
    d,
    0,
    "body",
    o,
    c.idsBySrc
  ), u = Cr(s, l, o), m = Ir(l), g = Sr(e, s, o), p = Br(s), { bookmarks: y, tocAnchors: I } = Rr(e), w = Pr(s, o);
  return n.requiresBestEffort && R(o, {
    code: "binary-export.composition.requires-best-effort",
    severity: "downgrade",
    message: "Composition plan was built from staged or non-strict bundle input; downstream fidelity gate should enforce variant policy."
  }), Er(e, o), {
    id: Or(e, r),
    version: ir,
    derivedFrom: "export-bundle",
    bundleId: e.bundle.manifest.bundleId,
    snapshotId: e.bundle.snapshot.id,
    completionState: e.completion.state,
    formatTargets: r,
    eligibility: {
      completionMode: n.completionMode,
      completionState: n.completionState,
      allowStagedBundle: t.allowStagedBundle === !0,
      requiresBestEffort: n.requiresBestEffort
    },
    metadata: {
      ...i.projections.title ? { title: i.projections.title } : {},
      ...i.document.meta.author ? { author: i.document.meta.author } : {},
      ...i.document.meta.createdAt ? { createdAt: i.document.meta.createdAt } : {},
      ...i.document.meta.updatedAt ? { updatedAt: i.document.meta.updatedAt } : {},
      ...i.document.meta.source ? { source: i.document.meta.source } : {},
      ...i.document.meta.schemaVersion ? { schemaVersion: i.document.meta.schemaVersion } : {},
      ...e.versions.manifestSchemaVersion ? { versionTag: e.versions.manifestSchemaVersion } : {}
    },
    sections: u,
    comments: p,
    bookmarks: y,
    tocAnchors: I,
    assets: g,
    pageBreaks: m,
    headerFooter: w,
    styleRoles: [...o.styleRoles],
    unsupported: o.unsupported,
    statistics: {
      sectionCount: u.length,
      blockCount: l.length,
      commentCount: p.length,
      assetCount: g.length,
      pageBreakCount: m.length,
      unsupportedCount: o.unsupported.length
    }
  };
}, yn = ["pdf", "docx"], In = ["business-ready"], kn = [
  "fidelity-strict",
  "best-effort"
], xn = [
  "accepted",
  "planning",
  "queued",
  "running",
  "completed",
  "failed"
], Sn = [
  "auto",
  "force-async",
  "prefer-sync"
], Ar = (e) => e ? JSON.parse(JSON.stringify(e)) : void 0, tt = (e) => ({
  ...e,
  fidelityTier: e.fidelityTier ?? "business-ready",
  fidelityMode: e.fidelityMode ?? "fidelity-strict",
  execution: e.execution ?? "auto",
  ...e.formatOptions ? {
    formatOptions: Ar(e.formatOptions)
  } : {}
}), ge = (e) => {
  var t;
  return (t = e.formatOptions) == null ? void 0 : t[e.format];
}, le = (e) => ({
  ...e,
  diagnostics: [...e.diagnostics],
  ...e.result ? {
    result: {
      ...e.result,
      diagnostics: [...e.result.diagnostics],
      artifacts: [...e.result.artifacts],
      statistics: {
        ...e.result.statistics
      },
      fidelity: {
        ...e.result.fidelity,
        issues: [...e.result.fidelity.issues],
        downgradeReasons: [...e.result.fidelity.downgradeReasons]
      },
      capability: {
        ...e.result.capability,
        businessReady: {
          ...e.result.capability.businessReady
        }
      },
      bundleIdentity: {
        ...e.result.bundleIdentity
      },
      compositionPlanIdentity: {
        ...e.result.compositionPlanIdentity
      },
      backend: {
        ...e.result.backend,
        constraints: [...e.result.backend.constraints]
      },
      request: JSON.parse(
        JSON.stringify(e.result.request)
      ),
      job: {
        ...e.result.job,
        diagnostics: [...e.result.job.diagnostics]
      }
    }
  } : {}
}), Mr = (e = {}) => {
  const t = e.state ?? {
    jobs: /* @__PURE__ */ new Map()
  };
  return {
    async create(a) {
      t.jobs.set(a.id, le(a));
    },
    async update(a) {
      t.jobs.set(a.id, le(a));
    },
    async get(a) {
      const r = t.jobs.get(a);
      return r ? le(r) : null;
    }
  };
}, ue = (e) => ({
  ...e,
  locator: {
    ...e.locator
  }
}), Te = (e) => e ? Uint8Array.from(e) : null, jr = (e = {}) => {
  const t = e.state ?? {
    byJob: /* @__PURE__ */ new Map()
  }, a = (r) => {
    const n = t.byJob.get(r);
    if (n)
      return n;
    const o = /* @__PURE__ */ new Map();
    return t.byJob.set(r, o), o;
  };
  return {
    async put(r, n, o) {
      a(r).set(n.id, {
        artifact: ue(n),
        payload: Te(o ?? null)
      });
    },
    async get(r, n) {
      var i;
      const o = (i = t.byJob.get(r)) == null ? void 0 : i.get(n);
      return o ? ue(o.artifact) : null;
    },
    async readPayload(r, n) {
      var i;
      const o = (i = t.byJob.get(r)) == null ? void 0 : i.get(n);
      return o ? Te(o.payload) : null;
    },
    async list(r) {
      const n = t.byJob.get(r);
      return n ? [...n.values()].map((o) => ue(o.artifact)) : [];
    },
    async reset(r) {
      t.byJob.set(r, /* @__PURE__ */ new Map());
    }
  };
}, Lr = (e) => JSON.parse(JSON.stringify(e)), zr = (e) => ({
  sectionCount: e.sectionCount,
  artifactCount: e.artifacts.length,
  warningCount: e.diagnostics.filter(
    (t) => t.severity === "warning"
  ).length
}), Ur = (e) => ({
  job: {
    ...e.job,
    diagnostics: [...e.job.diagnostics]
  },
  request: {
    ...Lr(e.request)
  },
  bundleIdentity: {
    ...e.bundleIdentity
  },
  compositionPlanIdentity: {
    ...e.compositionPlanIdentity
  },
  backend: {
    ...e.backend,
    constraints: [...e.backend.constraints]
  },
  capability: {
    ...e.capability,
    businessReady: {
      ...e.capability.businessReady
    }
  },
  artifacts: [...e.artifacts],
  diagnostics: [...e.diagnostics],
  fidelity: {
    ...e.fidelity,
    issues: [...e.fidelity.issues],
    downgradeReasons: [...e.fidelity.downgradeReasons]
  },
  cacheKey: e.cacheKey,
  statistics: {
    ...e.statistics
  }
}), we = Mr(), Xr = jr(), at = "binary-plan:pending", qr = /* @__PURE__ */ new Set(["completed", "failed"]);
let Ce = 0;
const Hr = () => (Ce += 1, Ce), Re = (e) => ({
  id: e.id,
  format: e.format,
  kind: e.kind,
  mediaType: e.mediaType,
  ...e.size ? { size: e.size } : {},
  ...e.digest ? { digest: e.digest } : {},
  locator: {
    kind: e.locator.kind,
    value: e.locator.value
  }
}), Yr = (e) => ({
  id: e.id,
  runtime: e.runtime,
  trustLevel: e.trustLevel,
  allowStagedBundle: e.allowStagedBundle,
  constraints: [...e.constraints]
}), Ee = (e) => Object.fromEntries(
  Object.entries(e.businessReady).filter(([, t]) => {
    const a = t;
    return a.level !== "supported" || !!a.reason;
  })
), Jr = (e, t) => `binary-export-job-${L(
  j({
    bundleId: e.bundle.manifest.bundleId,
    snapshotId: e.bundle.snapshot.id,
    format: t.format,
    fidelityTier: t.fidelityTier,
    fidelityMode: t.fidelityMode,
    namespace: t.namespace,
    seq: Hr()
  })
).slice(0, 24)}`, Vr = (e) => [
  `ns=${e.request.namespace ?? "text-editor-binary-export"}`,
  `bundle=${e.bundle.bundle.manifest.bundleId}`,
  `snapshot=${e.bundle.bundle.snapshot.id}`,
  `format=${e.request.format}`,
  `adapter=${e.adapterId}`,
  `backend=${e.backendId}`,
  `plan=${e.plan.id}`,
  `planVersion=${e.plan.version}`,
  `fidelityTier=${e.request.fidelityTier}`,
  `fidelityMode=${e.request.fidelityMode}`,
  `formatOptions=${L(
    j(
      ge(e.request) ?? {}
    )
  )}`,
  `options=${L(
    j({
      modelId: e.modelId
    })
  )}`
].join("|"), Zr = (e, t, a) => {
  if (e === "pdf" && t === "pdf-local-compositor") {
    const r = ua({
      allowStagedBundle: a.allowStagedBundle,
      businessReady: Ee(a.capability),
      constraints: a.constraints
    });
    return {
      format: e,
      backendId: t,
      run: ({ plan: n, request: o, diagnostics: i }) => {
        const s = ge(o), c = Dt(n, {
          diagnostics: i,
          formatOptions: s
        }), d = r.execute(c, {
          plan: n,
          fidelityTier: o.fidelityTier,
          fidelityMode: o.fidelityMode,
          diagnostics: i
        });
        return {
          backend: r.descriptor,
          modelId: c.id,
          artifacts: d.artifacts.map((l) => ({
            artifact: Re(l),
            ...l.payload ? { payload: l.payload } : {}
          })),
          diagnostics: d.diagnostics,
          fidelity: d.fidelity
        };
      }
    };
  }
  if (e === "docx" && t === "docx-local-openxml") {
    const r = rr({
      allowStagedBundle: a.allowStagedBundle,
      businessReady: Ee(a.capability),
      constraints: a.constraints
    });
    return {
      format: e,
      backendId: t,
      run: ({ plan: n, request: o, diagnostics: i }) => {
        const s = ge(o), c = va(n, {
          diagnostics: i,
          formatOptions: s
        }), d = r.execute(c, {
          plan: n,
          fidelityTier: o.fidelityTier,
          fidelityMode: o.fidelityMode,
          diagnostics: i
        });
        return {
          backend: r.descriptor,
          modelId: c.id,
          artifacts: d.artifacts.map((l) => ({
            artifact: Re(l),
            ...l.payload ? { payload: l.payload } : {}
          })),
          diagnostics: d.diagnostics,
          fidelity: d.fidelity
        };
      }
    };
  }
  return null;
}, Gr = (e) => {
  var r, n;
  const t = (n = (r = e.runtimeRegistry) == null ? void 0 : r[e.format]) == null ? void 0 : n[e.backend.id];
  if (t)
    return t;
  const a = Zr(
    e.format,
    e.backend.id,
    e.backend
  );
  if (a)
    return a;
  throw f(e.diagnostics, {
    code: "binary-export.backend.runtime-missing",
    message: `No runtime execution binding was registered for backend "${e.backend.id}" (${e.format}).`,
    severity: "error",
    phase: "backend",
    format: e.format,
    adapterId: e.adapterId,
    backendId: e.backend.id,
    planId: e.planId
  }), new B(
    `No runtime binding found for backend "${e.backend.id}".`,
    e.diagnostics
  );
}, ye = /* @__PURE__ */ new Map(), Kr = (e) => ({
  id: e.id,
  format: e.request.format,
  adapterId: `${e.request.format}-adapter`,
  backendId: e.request.backend ?? `${e.request.format}-backend`,
  bundleId: e.bundle.bundle.manifest.bundleId,
  planId: at,
  state: "accepted",
  diagnostics: [...e.diagnostics]
}), Wr = (e, t) => ({
  ...e,
  ...t,
  diagnostics: t.diagnostics ? [...t.diagnostics] : [...e.diagnostics],
  ...Object.prototype.hasOwnProperty.call(t, "result") ? { result: t.result } : {}
}), rt = (e, t) => {
  Promise.resolve().then(() => t(e)).catch(() => {
  });
}, Qr = (e, t, a) => e instanceof B ? (e.diagnostics.forEach(
  (r) => f(t, r)
), e) : (f(t, {
  code: "binary-export.orchestrator.unexpected-error",
  message: e instanceof Error ? e.message : "Unexpected binary export orchestration failure.",
  severity: "error",
  phase: "result",
  format: a.format,
  adapterId: a.adapterId,
  backendId: a.backendId,
  planId: a.planId
}), new B(
  "Unexpected binary export orchestration failure.",
  t
)), ne = async (e) => {
  const t = ye.get(e);
  if (!t)
    throw new Error(
      `No binary export runtime context found for job "${e}".`
    );
  let a = await t.jobStore.get(e);
  if (!a)
    throw new Error(`Binary export job "${e}" does not exist in job store.`);
  const r = t.diagnostics, n = async (o) => (a = Wr(a, o), await t.jobStore.update(a), a);
  try {
    await n({
      state: "planning",
      diagnostics: r,
      result: void 0
    });
    const o = be(
      t.registry,
      t.request.format
    ), i = Yt(o, {
      backendId: t.request.backend,
      allowSaaSOptIn: t.allowSaaSOptIn,
      diagnostics: r
    }), s = Nr(t.bundle, {
      allowStagedBundle: i.allowStagedBundle,
      formatTargets: [t.request.format],
      diagnostics: r
    });
    await n({
      adapterId: o.id,
      backendId: i.id,
      planId: s.id,
      state: "queued",
      diagnostics: r
    }), await n({
      state: "running",
      diagnostics: r
    });
    const d = await Gr({
      format: t.request.format,
      backend: i,
      runtimeRegistry: t.runtimeRegistry,
      diagnostics: r,
      adapterId: o.id,
      planId: s.id
    }).run({
      plan: s,
      request: t.request,
      diagnostics: r
    });
    await t.artifactStore.reset(e);
    for (const p of d.artifacts)
      await t.artifactStore.put(
        e,
        p.artifact,
        p.payload
      );
    const l = await t.artifactStore.list(e), u = d.backend, m = {
      id: a.id,
      format: t.request.format,
      adapterId: o.id,
      backendId: u.id,
      bundleId: t.bundle.bundle.manifest.bundleId,
      planId: s.id,
      state: "completed",
      diagnostics: [...r]
    }, g = Ur({
      job: m,
      request: t.request,
      bundleIdentity: {
        bundleId: t.bundle.bundle.manifest.bundleId,
        snapshotId: t.bundle.bundle.snapshot.id
      },
      compositionPlanIdentity: {
        id: s.id,
        version: s.version
      },
      backend: Yr(u),
      capability: u.capability,
      artifacts: l,
      diagnostics: d.diagnostics,
      fidelity: d.fidelity,
      cacheKey: Vr({
        bundle: t.bundle,
        request: t.request,
        adapterId: o.id,
        backendId: i.id,
        plan: s,
        modelId: d.modelId
      }),
      statistics: zr({
        sectionCount: s.sections.length,
        artifacts: l,
        diagnostics: d.diagnostics
      })
    });
    return await n({
      state: "completed",
      adapterId: o.id,
      backendId: u.id,
      planId: s.id,
      diagnostics: d.diagnostics,
      result: g
    }), a;
  } catch (o) {
    const i = Qr(o, r, {
      format: a.format,
      adapterId: a.adapterId,
      backendId: a.backendId,
      planId: a.planId
    });
    return await n({
      state: "failed",
      diagnostics: i.diagnostics,
      result: void 0
    }), a;
  }
}, Bn = async (e, t) => {
  const a = tt(t.request), r = t.jobStore ?? we, n = t.artifactStore ?? Xr, o = t.diagnostics ?? _(), i = t.registry ?? he(), s = Jr(e, a), c = Kr({
    id: s,
    request: a,
    bundle: e,
    diagnostics: o
  });
  return await r.create(c), ye.set(s, {
    bundle: e,
    request: a,
    registry: i,
    runtimeRegistry: t.runtimeRegistry,
    jobStore: r,
    artifactStore: n,
    diagnostics: o,
    allowSaaSOptIn: t.allowSaaSOptIn === !0
  }), a.execution === "force-async" ? (rt(s, ne), c) : ne(s);
}, $n = async (e, t = {}) => (t.jobStore ?? we).get(e), en = (e) => new Promise((t) => {
  setTimeout(t, e);
}), vn = async (e, t = {}) => {
  const a = t.jobStore ?? we, r = Math.max(10, t.intervalMs ?? 25), n = Math.max(r, t.timeoutMs ?? 3e3), o = Date.now();
  let i = await a.get(e);
  for (; i && !qr.has(i.state); ) {
    if (Date.now() - o >= n)
      throw new B(
        `Polling binary export job "${e}" timed out.`,
        [
          {
            code: "binary-export.job.poll-timeout",
            message: `Polling timed out after ${n}ms for job "${e}".`,
            severity: "error",
            phase: "result",
            jobId: e
          }
        ]
      );
    await en(r), i = await a.get(e);
  }
  return i;
}, Pn = async (e, t = {}) => {
  const a = ye.get(e);
  if (!a)
    throw new B(
      `Cannot retry unknown binary export job "${e}".`,
      [
        {
          code: "binary-export.job.retry-context-missing",
          message: `No runtime context found for binary export job "${e}".`,
          severity: "error",
          phase: "result",
          jobId: e
        }
      ]
    );
  const r = await a.jobStore.get(e);
  if (!r)
    throw new B(
      `Cannot retry missing binary export job "${e}".`,
      [
        {
          code: "binary-export.job.retry-missing",
          message: `Job "${e}" could not be found in the configured job store.`,
          severity: "error",
          phase: "result",
          jobId: e
        }
      ]
    );
  if (r.state === "planning" || r.state === "queued" || r.state === "running")
    throw new B(
      `Cannot retry binary export job "${e}" while it is still in progress.`,
      [
        {
          code: "binary-export.job.retry-in-progress",
          message: `Job "${e}" is currently ${r.state} and cannot be retried yet.`,
          severity: "error",
          phase: "result",
          jobId: e
        }
      ]
    );
  if (a.request = tt({
    ...a.request,
    ...t.request ?? {},
    ...t.execution ? { execution: t.execution } : {}
  }), a.diagnostics = t.diagnostics ?? _(), await a.jobStore.update({
    ...r,
    format: a.request.format,
    adapterId: `${a.request.format}-adapter`,
    backendId: a.request.backend ?? `${a.request.format}-backend`,
    planId: at,
    state: "accepted",
    diagnostics: [...a.diagnostics],
    result: void 0
  }), a.request.execution === "force-async") {
    rt(e, ne);
    const n = await a.jobStore.get(e);
    if (!n)
      throw new Error(
        `Retry reset snapshot missing for binary export job "${e}".`
      );
    return n;
  }
  return ne(e);
};
export {
  hn as $,
  Ur as A,
  Ue as B,
  te as C,
  ae as D,
  Ht as E,
  he as F,
  be as G,
  Yt as H,
  mn as I,
  gn as J,
  Xe as K,
  or as L,
  sr as M,
  Nr as N,
  Mr as O,
  jr as P,
  Bn as Q,
  $n as R,
  vn as S,
  Pn as T,
  ht as U,
  Dt as V,
  ra as W,
  na as X,
  ia as Y,
  yn as Z,
  fn as _,
  an as a,
  la as a0,
  ua as a1,
  pa as a2,
  ma as a3,
  va as a4,
  Za as a5,
  Ga as a6,
  Qa as a7,
  bn as a8,
  wn as a9,
  ar as aa,
  rr as ab,
  j as ac,
  L as ad,
  rn as b,
  nn as c,
  In as d,
  kn as e,
  xn as f,
  Sn as g,
  ge as h,
  ln as i,
  Tt as j,
  je as k,
  Z as l,
  Rt as m,
  un as n,
  fe as o,
  pn as p,
  on as q,
  tt as r,
  sn as s,
  B as t,
  _ as u,
  bt as v,
  dn as w,
  f as x,
  cn as y,
  zr as z
};
//# sourceMappingURL=orchestrator-DBIyJOJn.mjs.map
