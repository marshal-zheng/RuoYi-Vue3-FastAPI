import { d as c, s, Z as P } from "./definition-DiwrtpbT.mjs";
const M = (t, o, r, f, b, g, Z, q) => {
  const $ = q.map(({ id: J, version: W, fingerprint: Q }) => ({
    id: J,
    version: W,
    fingerprint: Q
  })), y = {
    id: `npm:${t}`,
    version: r,
    packageName: t,
    runtimeSpecifier: o,
    resolvedVersion: r,
    lockIntegrity: f,
    apiContractFingerprint: g,
    implementationFingerprint: Z,
    admittedSemverRanges: b,
    dependencies: $
  };
  return c({
    ...y,
    fingerprint: s(y)
  });
}, l = M(
  "prosemirror-model",
  "prosemirror-model",
  "1.25.12",
  "sha512-Ue2gTmXMa7EhpLNhC7J+h4+ykD8ha12K6rrZFFKKJHBForfIStw5gJ6Zrf1mqqAa9NmpmEB4wp9bKmA4eUVjWg==",
  ["1.25.12"],
  "sha256:b11a34cfd6b9d74ce796ea9ffe402a981a0e68845ea2da0d86b3ca65777dd2a7",
  "sha256:979f44e6c7f63ce3a20b66dc2ef9e4c96ac2cbc32360f47375d4c88baf9ed181",
  []
), u = M(
  "prosemirror-transform",
  "prosemirror-transform",
  "1.12.2",
  "sha512-PE/aY0HEY4zczvmqrilgkUK/WautF0chvMqkmM/iN5/aPHvwrCWaQZjS6CIZp+K84YrvPFqrL+YArrfJX8xX7g==",
  ["1.12.2"],
  "sha256:e22fd8974004c6c9f083de095535028e31068296fefbb6f2a3da17c90c761e7b",
  "sha256:4d055cb15558c06a1ad444823f11893e4380b22b45ae211338b1c4ba7904bd15",
  [l]
), T = M(
  "prosemirror-state",
  "prosemirror-state",
  "1.4.4",
  "sha512-6jiYHH2CIGbCfnxdHbXZ12gySFY/fz/ulZE333G6bPqIZ4F+TXo9ifiR86nAHpWnfoNjOb3o5ESi7J8Uz1jXHw==",
  ["1.4.4"],
  "sha256:02ab5dbcaa58da1d58c46c7cdfa7f94792c5ccf0fc7c0622ef33755fe415366c",
  "sha256:d4bd4e98520abd0bb0150436d84a3832d856aa59636ea23a59409d35929730a3",
  [l, u]
), ge = "sha256:0f7fc1f7430fefe0b1ccc5ba8e990af1b046cad870d99101086abc9db0fd9821", v = "sha256:77ed9078085af3da6d102aaa1c16e6f998fbedb3d226a2204c4b622496bde58b", ee = "sha256:e6fc6653d657b76d4149b5915a6def219f762a0424dd0b63ec36748dc7080c5b", te = "sha256:32bb9030b7493187b58d3dca8fd86e8110dbc033823432ba9dd9f0ad4f17bcd2", ae = "sha256:b9bf851be76aa150ea2eef03c7680d17430f72cd2a3a8ee9c24f58494b8a16c7", ne = "sha256:d8187e3c902a4c69f415d23bb30429d5d07792460725deaf280d69e1527ea26d", oe = "sha256:b5a72d72f64d097b9f9eee2e84ddc5b7717b91778face3b9b099231029f1a76b", ce = "sha256:018ea543dfae0643519b6d31ee79c82e2fa75a6e48a6f10152f4c431dcc760fa", re = c({
  contract: "sha256:776126dfe7cefc1a8978d14db6512816ecee31b667a065c95c95a1ffa3ea9b97",
  freshRootMaterializer: "sha256:27aa30c682919e8b2ed9835f00346a562e33383b2e9ec96e97650f9cd4347ed9",
  coordinator: "sha256:a51e47ec34afc6c9d6e13857b98e6bfc59a6abf207a875e07496be3d8bc18540",
  postDispatchProof: "sha256:67a632e9d12e13b21a36e75640c819f15a3fef294a76c7273b9c873ba6baad88",
  synchronousWriteGuard: "sha256:a9838b16f257c3c48f62619fd39c685850c45655a80a69fd90276681b8a14a39",
  targetDocumentAuthority: "sha256:43c0fd79317a46d841e10a612882223024dbfd4f568f724cfdab0b47d79b2948"
}), e = (t, o) => ({
  kind: t,
  id: o.id,
  version: o.version,
  fingerprint: o.fingerprint
}), n = (t, o, r, f, b = []) => {
  const g = { kind: t, id: o, version: r, semantics: f, dependencies: b };
  return c({
    kind: t,
    id: o,
    version: r,
    fingerprint: s({
      domain: `zx-runtime-component:${t}:v2`,
      projection: g
    }),
    dependencies: b
  });
}, m = n(
  "execution-closure",
  "npm:prosemirror-model",
  l.resolvedVersion,
  {
    packageFingerprint: l.fingerprint,
    implementationFingerprint: l.implementationFingerprint
  }
), C = n(
  "execution-closure",
  "npm:prosemirror-transform",
  u.resolvedVersion,
  {
    packageFingerprint: u.fingerprint,
    implementationFingerprint: u.implementationFingerprint
  },
  [e("execution-closure", m)]
), U = n(
  "execution-closure",
  "npm:prosemirror-state",
  T.resolvedVersion,
  {
    packageFingerprint: T.fingerprint,
    apiFingerprint: T.apiContractFingerprint,
    stateSourceFingerprint: "sha256:081d675bbeaa6598c17f45be84a84011c5e083b66f9c6282be0304a5f38f7f44",
    transactionSourceFingerprint: "sha256:fbab5b3d17fc510152167b387e15dcf360c086ed78dcb2751cecae7938d01a83",
    adapterSourceFingerprint: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
    adapter: "prosemirror-state-adapter-v2"
  },
  [
    e("execution-closure", m),
    e("execution-closure", C)
  ]
), i = n(
  "schema-semantics",
  "zx.text-editor.schema-semantics",
  "2.0.0",
  {
    owner: "schema-kernel",
    documentAuthority: "document-v2",
    schemaKernelFingerprint: P.schemaKernelFingerprint,
    marks: P.marks.map((t) => ({
      key: t.key,
      order: t.order,
      inclusive: t.inclusive,
      excludes: t.excludes,
      attrs: t.attrs
    }))
  }
), ie = c([
  "text.replace",
  "block.insert",
  "block.replace",
  "block.delete",
  "node.apply"
]), d = n(
  "operation-protocol",
  "zx.text-editor.ai-mutation-plan",
  "2.0.0",
  {
    owner: "S2",
    protocolVersion: 2,
    offsetEncoding: "utf-16",
    registryBinding: "exact-fingerprint",
    v1Policy: "audit-only-no-live-converter",
    operations: ie
  },
  [e("schema-semantics", i)]
), V = n(
  "execution-closure",
  "zx.text-editor.operation-compiler-adapter",
  "2.0.0",
  {
    sourceFingerprint: "sha256:8c21f384c9e08bc7f8df660b30df12dfcdf50ba160f62ed65a2fc29c7366ea07",
    preconditionCatalogSourceFingerprint: "sha256:b45d0a4de04b2953f37742ffb24975486579cb376f2a2ace32a10f556755dbab",
    livePlanCertificationSourceFingerprint: "sha256:15f33030db66e1b01e760f3d5c0300f9d4055025453bb36c6b41883112c4ee3c",
    s2ProjectionSourceFingerprints: {
      conformance: "sha256:6d2b3df732ff1904443fafd079cb78bf0a88a48738b4eb0aadaab3093f25c3ca",
      manifest: "sha256:2bd78a70c5e5e988cd819b85317c5ca2561be21ea0ad5a9e582bf9c066e085c7",
      operationTargets: "sha256:62244a3ffc1c06c7e967bec417a752704113a448a14fb35b082884363f543e09",
      scope: "sha256:f020e82aa2356b73b1b8b4181059bb27cbd1f2f8c0dc4d5bd7b8946289264800",
      semanticTree: "sha256:365c438f6aa59e6dc483ef93c237867a17c42a8be1b44231000028fb32113c20",
      validatedBlockIndex: "sha256:36acbbe5c100368075d72d6ced1a765cf035564ee99d0b1b42f2f4fdae33a745"
    },
    rootTransactionCount: 1,
    operationOrder: "plan-order",
    spanProjection: "operation-index-step-half-open-v2",
    complexNode: {
      registry: "exact-fingerprint",
      adapterCompiler: "exact-component-ref",
      runner: "hard-terminable-isolate-required",
      fallback: "forbidden",
      resourceProfile: "manifest-bound"
    }
  },
  [
    e("schema-semantics", i),
    e("operation-protocol", d)
  ]
), a = (t, o, r, f) => n(
  "execution-closure",
  `zx.text-editor.runtime-plugin.${t}.${o}`,
  "2.0.0",
  r,
  f
), k = a(
  "stable-index",
  "factory",
  { owner: "package-exact", instanceKey: "stable-index-v2" },
  [e("schema-semantics", i)]
), _ = a(
  "stable-index",
  "config",
  { key: "zxRuntimeStableIndexV2", order: 0 },
  [e("execution-closure", k)]
), L = a(
  "stable-index",
  "state-init",
  { projection: "ordered-document-block-ids-v2" },
  [e("execution-closure", _)]
), z = a(
  "stable-index",
  "state-apply",
  { projection: "docChanged-reproject-otherwise-identity" },
  [e("execution-closure", L)]
), j = a(
  "stable-index",
  "projector",
  { output: "blockIds+fingerprint", canonical: !0 },
  [e("execution-closure", z)]
), se = a(
  "stable-index",
  "filter",
  {
    accepts: "host-and-runtime-transactions",
    runtimeTargetAdmission: "package-write-guard-plus-root/appended-meta"
  },
  [e("execution-closure", _)]
), de = a(
  "stable-index",
  "append",
  { behavior: "none" },
  [e("execution-closure", _)]
), pe = a(
  "stable-index",
  "effect",
  { behavior: "none" },
  [e("execution-closure", j)]
), h = c({
  factory: k,
  config: _,
  stateInit: L,
  stateApply: z,
  projector: j,
  filter: se,
  append: de,
  effect: pe
}), R = n(
  "execution-closure",
  "zx.text-editor.runtime-plugin.stable-index",
  "2.0.0",
  {
    instanceKey: "stable-index-v2",
    order: 0,
    componentRefs: h,
    conformanceReceipt: "runtime-plugin-stable-index-v2-receipt-1",
    implementationSourceFingerprint: v
  },
  Object.values(h).map(
    (t) => e("execution-closure", t)
  )
), B = a(
  "trace-seal",
  "factory",
  { owner: "package-exact", instanceKey: "trace-seal-v2" },
  [e("execution-closure", R)]
), E = a(
  "trace-seal",
  "config",
  { key: "zxRuntimeTraceSealV2", order: 1 },
  [e("execution-closure", B)]
), D = a(
  "trace-seal",
  "state-init",
  { projection: "transaction-count-zero-v2" },
  [e("execution-closure", E)]
), G = a(
  "trace-seal",
  "state-apply",
  { projection: "runtime-transaction-count-increment-v2" },
  [e("execution-closure", D)]
), w = a(
  "trace-seal",
  "projector",
  { output: "transactionCount+fingerprint", canonical: !0 },
  [e("execution-closure", G)]
), fe = a(
  "trace-seal",
  "filter",
  {
    accepts: "host-and-runtime-transactions",
    runtimeTargetAdmission: "package-write-guard-plus-root/appended-meta"
  },
  [e("execution-closure", E)]
), le = a(
  "trace-seal",
  "append",
  { behavior: "single-logical-transaction-after-root-v2" },
  [e("execution-closure", E)]
), be = a(
  "trace-seal",
  "effect",
  { behavior: "bounded-observational-trace-sealed-v2" },
  [e("execution-closure", w)]
), N = c({
  factory: B,
  config: E,
  stateInit: D,
  stateApply: G,
  projector: w,
  filter: fe,
  append: le,
  effect: be
}), A = n(
  "execution-closure",
  "zx.text-editor.runtime-plugin.trace-seal",
  "2.0.0",
  {
    instanceKey: "trace-seal-v2",
    order: 1,
    componentRefs: N,
    conformanceReceipt: "runtime-plugin-trace-seal-v2-receipt-1",
    implementationSourceFingerprint: v
  },
  [
    e("execution-closure", R),
    ...Object.values(N).map(
      (t) => e("execution-closure", t)
    )
  ]
), X = n(
  "execution-closure",
  "zx.text-editor.runtime-observational.audit-label",
  "1.0.0",
  {
    owner: "S2B-observability",
    executionReachability: "none",
    behavior: "canonical-receipt-label-only",
    implementationSourceFingerprint: te,
    sourceReachabilityClosure: {
      semanticComponentDependencies: [],
      reachableAuthorities: ["observations"],
      unreachableAuthorities: [
        "document",
        "selection",
        "stored-marks",
        "semantic-plugin-state",
        "effects",
        "annotations",
        "lifecycle"
      ]
    },
    conformanceReceipt: "runtime-observational-audit-label-non-interference-receipt-1"
  }
), p = n(
  "execution-closure",
  "zx.text-editor.deterministic-execution-closure",
  "2.0.0",
  {
    owner: "S2B",
    adapter: "prosemirror-state-adapter-v2",
    filterOrder: "manifest-plugin-order",
    appendSeenSemantics: "prosemirror-state-1.4.4",
    plugins: ["stable-index-v2", "trace-seal-v2"],
    pluginOrderSignificant: !0,
    watchdog: "host-non-replayable-abort-only",
    implementationSourceFingerprints: {
      stateAdapter: "sha256:28f1d129bd42bd666c7356fb761117c05a63283ea42e4cc1d86d849ab83cb009",
      fixedPointDriver: "sha256:abce518d9a3d1206cd96e9f5c9aa0b9b9085c2f8b52c0e7f7b928c733b9257ba",
      pluginClosure: v,
      pluginConformance: ee,
      executionTrace: "sha256:8dee1b14039e315dc231d6f201c805128e3fd9ce9447dad2367a7884b3511fc1",
      hostAdmission: "sha256:2df4555636e903ebacb7fe29ffe354abe751216f134456bdba6cebdc8465374d",
      hostCompositionAuthority: ae,
      hostCompositionRegistry: ne,
      hostCompositionState: oe,
      editorRuntimeAssembly: ce,
      targetCommit: re,
      orchestrator: "sha256:f1e502f884fca6e64183c09cb114dff670000fe8a9d5eaa9ab3580790196f1e9",
      resolver: "sha256:38359a64831ddca47317ae78b1d8e68e8db62fc94b8f0b7de0f9d21ecf37f8c4"
    }
  },
  [
    e("operation-protocol", d),
    e("execution-closure", V),
    e("execution-closure", m),
    e("execution-closure", C),
    e("execution-closure", U),
    e("execution-closure", R),
    e("execution-closure", A)
  ]
), x = n(
  "mapping-policy",
  "zx.text-editor.mapping-policy",
  "2.0.0",
  {
    projection: "block-pm-utf16-v2",
    composition: "root-first-all-step-maps",
    annotationBoundary: { startAssoc: 1, endAssoc: -1, expanding: !1 },
    deletionFlags: [
      "deleted",
      "deletedBefore",
      "deletedAfter",
      "deletedAcross"
    ],
    invalidation: "fail-closed",
    context: ["quote", "beforeQuote", "afterQuote"],
    textReplaceMarks: {
      collapsed: "$pos.marks()",
      range: "$from.marksAcross($to) ?? []",
      deletion: [],
      selectionAndStoredMarks: "forbidden"
    },
    implementationSourceFingerprints: {
      mapping: "sha256:fd5888ea31b7eb6029d7d09d21467e9d9a36099b08cbec89bbeb7f843fda13c3",
      marks: "sha256:8be5e04ae8b43eff89322f668bd61a3e5d499bb8a7d70d34234af45b34a8e3a2"
    }
  },
  [
    e("schema-semantics", i),
    e("operation-protocol", d),
    e("execution-closure", p)
  ]
), I = n(
  "transaction-policy",
  "zx.text-editor.transaction-policy",
  "2.0.0",
  {
    logicalTime: "zero-based-global-sequence-v1",
    rootMeta: ["zx.runtime.root.v2"],
    appendedMeta: ["zx.runtime.appended.v2"],
    forbiddenMeta: [
      "uiEvent",
      "pointer",
      "composition",
      "history",
      "yjs",
      "provider",
      "caller",
      "PluginKey"
    ],
    selectionMutation: "forbidden",
    storedMarksMutation: "forbidden",
    implementationSourceFingerprint: "sha256:7e4a8909db08d8a8e3f56af4ecca53b23e6ef2e54b09f8040e538f561d02875f"
  },
  [e("execution-closure", p)]
), ue = c({
  inputBytes: 2e6,
  inputDepth: 128,
  inputKeys: 3e5,
  documentNodes: 5e4,
  documentMarks: 2e5,
  documentBlocks: 2e4,
  annotations: 2e4,
  planOperations: 1e4,
  executionPlugins: 16,
  rootSteps: 1e4,
  steps: 2e4,
  transactions: 256,
  filterCalls: 2048,
  appendCalls: 2048,
  appendRounds: 256,
  mappingMaps: 2e4,
  mappingRanges: 12e4,
  mappingBytes: 4e6,
  mappingMirrors: 2e4,
  mappingMirrorBytes: 1e6,
  metaBytes: 1e6,
  traceBytes: 8e6,
  pluginStateBytes: 2e6,
  safeDiagnosticCount: 16,
  safeDiagnosticBytes: 16384
}), F = n(
  "resource-profile",
  "zx.text-editor.deterministic-resource-profile",
  "2.0.0",
  {
    algorithm: "pre-debit-counts-and-canonical-utf8-bytes-v1",
    limits: ue,
    implementationSourceFingerprint: "sha256:74442b20a3f316728b6ee2db517e43a65d79cd68fa028026e3bdc432f483f3fb"
  },
  [
    e("execution-closure", p),
    e("mapping-policy", x),
    e("transaction-policy", I)
  ]
), K = n(
  "derived-view-profile",
  "zx.text-editor.derived-view.runtime-summary",
  "1.0.0",
  {
    owner: "proposal-view-authority",
    output: ["transactionCount", "stepCount", "annotationCount"],
    diffAlgorithm: null,
    hunkIdentity: null,
    maxInputBytes: 8e6,
    maxOutputBytes: 16384,
    implementationSourceFingerprint: "sha256:eebeca1ca662a97ef3190f83b82bb07c3349360bd8fb5ccd1e2d396bd0a81232"
  }
), me = [
  i,
  d,
  p,
  x,
  I,
  F
], _e = [
  A,
  X
], H = [K], Re = s({
  domain: "zx-runtime-execution-semantics:v2",
  components: me
}), Ee = s({
  domain: "zx-runtime-observational-profile:v2",
  components: _e
}), xe = s({
  domain: "zx-runtime-derived-view-profile:v2",
  components: H
}), S = {
  kind: "zx-text-editor-runtime-manifest-v2",
  version: "2.0.0",
  schemaSemantics: i,
  operationProtocol: d,
  executionClosure: p,
  mappingPolicy: x,
  transactionPolicy: I,
  resourceProfile: F,
  derivedViewProfiles: H,
  fingerprints: {
    executionSemanticsFingerprint: Re,
    observationalProfileFingerprint: Ee,
    derivedViewFingerprint: xe
  }
}, Y = s({
  domain: "zx-runtime-manifest:v2",
  manifest: S
}), O = c({
  ...S,
  fingerprints: {
    ...S.fingerprints,
    runtimeManifestFingerprint: Y
  }
}), Te = c({
  kind: O.kind,
  version: O.version,
  fingerprint: Y
}), he = c([
  i,
  d,
  V,
  m,
  C,
  U,
  ...Object.values(h),
  R,
  ...Object.values(N),
  A,
  X,
  p,
  x,
  I,
  F,
  K
]), Ne = () => O;
export {
  Te as C,
  oe as R,
  ne as a,
  ae as b,
  ce as c,
  ue as d,
  F as e,
  h as f,
  R as g,
  N as h,
  A as i,
  x as j,
  ge as k,
  O as l,
  he as m,
  X as n,
  te as o,
  K as p,
  Ne as q,
  p as r,
  ie as s
};
//# sourceMappingURL=manifest-DmJF7R9Y.mjs.map
