import "yjs";
import { r as k, a as E, m as N, A as O, w as i, b as A, t as a, l as T, p as w, c as Q, d as y, e as g, f as x, i as H, g as C, s as q, h as Y, u as z, j as o, k as F, n as G, o as J, q as K, v as X, x as Z, y as p } from "./awareness-Do0nkEFk.mjs";
import { a as v } from "./error-Di1d9d9R.mjs";
const ss = 0, es = (s, e, n) => {
  switch (k(s)) {
    case ss:
      n(e, E(s));
  }
}, ns = (s) => N(s, (e, n) => `${encodeURIComponent(n)}=${encodeURIComponent(e)}`).join("&"), u = 0, M = 3, r = 1, ts = 2, b = [];
b[u] = (s, e, n, t, c) => {
  i(s, u);
  const h = K(
    e,
    s,
    n.doc,
    n
  );
  t && h === X && !n.synced && (n.synced = !0);
};
b[M] = (s, e, n, t, c) => {
  i(s, r), y(
    s,
    g(
      n.awareness,
      Array.from(n.awareness.getStates().keys())
    )
  );
};
b[r] = (s, e, n, t, c) => {
  Z(
    n.awareness,
    p(e),
    n
  );
};
b[ts] = (s, e, n, t, c) => {
  es(
    e,
    n.doc,
    (h, f) => cs(n, f)
  );
};
const R = 3e4, cs = (s, e) => console.warn(`Permission denied to access ${s.url}.
${e}`), B = (s, e, n) => {
  const t = F(e), c = o(), h = k(t), f = s.messageHandlers[h];
  return /** @type {any} */ f ? f(c, t, s, n, h) : console.error("Unable to compute message"), c;
}, as = (s) => !(s.code >= 4400 && s.code < 4500), U = (s, e, n) => {
  if (e !== null && e === s.ws) {
    s.emit("connection-close", [n, s]), s.ws = null, e.onmessage = null, e.onopen = null, e.onclose = null, e.onerror = () => {
    }, e.close(), s.wsconnecting = !1, s.wsconnected && (s.wsconnected = !1, s.synced = !1, x(
      s.awareness,
      Array.from(s.awareness.getStates().keys()).filter(
        (c) => c !== s.doc.clientID
      ),
      s
    ), s.emit("status", [{
      status: "disconnected"
    }])), s.wsUnsuccessfulReconnects++;
    let t = null;
    n != null && !s.shouldReconnect(n, s) && (s.shouldConnect = !1, t = { code: n.code, reason: n.reason }), setTimeout(
      D,
      G(
        J(2, s.wsUnsuccessfulReconnects) * 100,
        s.maxBackoffTime
      ),
      s
    ), t !== null && s.emit("closed", [t, s]);
  }
}, D = (s) => {
  if (s.shouldConnect && s.ws === null) {
    const e = new s._WS(s.url, s.protocols);
    e.binaryType = "arraybuffer", s.ws = e, s.wsconnecting = !0, s.wsconnected = !1, s.synced = !1, e.onmessage = (n) => {
      if (s.ws !== e) return;
      s.wsLastMessageReceived = C();
      const t = B(s, new Uint8Array(n.data), !0);
      T(t) > 1 && e.send(a(t));
    }, e.onerror = (n) => {
      s.ws === e && s.emit("connection-error", [n, s]);
    }, e.onclose = (n) => {
      U(s, e, n);
    }, e.onopen = () => {
      if (s.ws !== e) return;
      s.wsLastMessageReceived = C(), s.wsconnecting = !1, s.wsconnected = !0, s.emit("status", [{
        status: "connected"
      }]);
      const n = o();
      if (i(n, u), A(n, s.doc), e.send(a(n)), s.awareness.getLocalState() !== null) {
        const t = o();
        i(t, r), y(
          t,
          g(s.awareness, [
            s.doc.clientID
          ])
        ), e.send(a(t));
      }
    }, s.emit("status", [{
      status: "connecting"
    }]);
  }
}, S = (s, e) => {
  const n = s.ws;
  s.wsconnected && n && n.readyState === n.OPEN && n.send(e), s.bcconnected && w(s.bcChannel, e, s);
};
class ds extends v {
  /**
   * @param {string} serverUrl
   * @param {string} roomname
   * @param {Y.Doc} doc
   * @param {object} opts
   * @param {boolean} [opts.connect]
   * @param {awarenessProtocol.Awareness} [opts.awareness]
   * @param {Object<string,string>} [opts.params] specify url parameters
   * @param {Array<string>} [opts.protocols] specify websocket protocols
   * @param {typeof WebSocket} [opts.WebSocketPolyfill] Optionall provide a WebSocket polyfill
   * @param {number} [opts.resyncInterval] Request server state every `resyncInterval` milliseconds
   * @param {number} [opts.maxBackoffTime] Maximum amount of time to wait before trying to reconnect (we try to reconnect using exponential backoff)
   * @param {boolean} [opts.disableBc] Disable cross-tab BroadcastChannel communication
   * @param {(event: CloseEvent, provider: WebsocketProvider) => boolean} [opts.shouldReconnect] Decide whether to reconnect after the server closed the connection. By default, close codes in the 4400-4499 range are permanent - we stop reconnecting and emit a `closed` event. This is never called for connections that were closed locally (e.g. via `provider.disconnect()`).
   */
  constructor(e, n, t, {
    connect: c = !0,
    awareness: h = new O(t),
    params: f = {},
    protocols: P = [],
    WebSocketPolyfill: W = WebSocket,
    resyncInterval: I = -1,
    maxBackoffTime: V = 2500,
    disableBc: L = !1,
    shouldReconnect: $ = as
  } = {}) {
    for (super(); e[e.length - 1] === "/"; )
      e = e.slice(0, e.length - 1);
    this.serverUrl = e, this.bcChannel = e + "/" + n, this.maxBackoffTime = V, this.shouldReconnect = $, this.params = f, this.protocols = P, this.roomname = n, this.doc = t, this._WS = W, this.awareness = h, this.wsconnected = !1, this.wsconnecting = !1, this.bcconnected = !1, this.disableBc = L, this.wsUnsuccessfulReconnects = 0, this.messageHandlers = b.slice(), this._synced = !1, this.ws = null, this.wsLastMessageReceived = 0, this.shouldConnect = c, this._resyncInterval = 0, I > 0 && (this._resyncInterval = /** @type {any} */
    setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        const l = o();
        i(l, u), A(l, t), this.ws.send(a(l));
      }
    }, I)), this._bcSubscriber = (l, m) => {
      if (m !== this) {
        const d = B(this, new Uint8Array(l), !1);
        T(d) > 1 && w(this.bcChannel, a(d), this);
      }
    }, this._updateHandler = (l, m) => {
      if (m !== this) {
        const d = o();
        i(d, u), Q(d, l), S(this, a(d));
      }
    }, this.doc.on("update", this._updateHandler), this._awarenessUpdateHandler = ({ added: l, updated: m, removed: d }, is) => {
      const j = l.concat(m).concat(d), _ = o();
      i(_, r), y(
        _,
        g(h, j)
      ), S(this, a(_));
    }, this._exitHandler = () => {
      x(
        this.awareness,
        [t.clientID],
        "app closed"
      );
    }, H && typeof process < "u" && process.on("exit", this._exitHandler), h.on("update", this._awarenessUpdateHandler), this._checkInterval = /** @type {any} */
    setInterval(() => {
      this.wsconnected && R < C() - this.wsLastMessageReceived && U(
        this,
        /** @type {WebSocket} */
        this.ws,
        null
      );
    }, R / 10), c && this.connect();
  }
  get url() {
    const e = ns(this.params);
    return this.serverUrl + "/" + this.roomname + (e.length === 0 ? "" : "?" + e);
  }
  /**
   * @type {boolean}
   */
  get synced() {
    return this._synced;
  }
  set synced(e) {
    this._synced !== e && (this._synced = e, e && (this.wsUnsuccessfulReconnects = 0), this.emit("synced", [e]), this.emit("sync", [e]));
  }
  destroy() {
    this._resyncInterval !== 0 && clearInterval(this._resyncInterval), clearInterval(this._checkInterval), this.disconnect(), H && typeof process < "u" && process.off("exit", this._exitHandler), this.awareness.off("update", this._awarenessUpdateHandler), this.doc.off("update", this._updateHandler), super.destroy();
  }
  connectBc() {
    if (this.disableBc)
      return;
    this.bcconnected || (q(this.bcChannel, this._bcSubscriber), this.bcconnected = !0);
    const e = o();
    i(e, u), A(e, this.doc), w(this.bcChannel, a(e), this);
    const n = o();
    i(n, u), Y(n, this.doc), w(this.bcChannel, a(n), this);
    const t = o();
    i(t, M), w(
      this.bcChannel,
      a(t),
      this
    );
    const c = o();
    i(c, r), y(
      c,
      g(this.awareness, [
        this.doc.clientID
      ])
    ), w(
      this.bcChannel,
      a(c),
      this
    );
  }
  disconnectBc() {
    const e = o();
    i(e, r), y(
      e,
      g(this.awareness, [
        this.doc.clientID
      ], /* @__PURE__ */ new Map())
    ), S(this, a(e)), this.bcconnected && (z(this.bcChannel, this._bcSubscriber), this.bcconnected = !1);
  }
  disconnect() {
    this.shouldConnect = !1, this.disconnectBc(), this.ws !== null && U(this, this.ws, null);
  }
  connect() {
    this.shouldConnect = !0, !this.wsconnected && this.ws === null && (D(this), this.connectBc());
  }
}
export {
  ds as WebsocketProvider,
  ts as messageAuth,
  r as messageAwareness,
  M as messageQueryAwareness,
  u as messageSync
};
//# sourceMappingURL=y-websocket-wGTAdJXE.mjs.map
