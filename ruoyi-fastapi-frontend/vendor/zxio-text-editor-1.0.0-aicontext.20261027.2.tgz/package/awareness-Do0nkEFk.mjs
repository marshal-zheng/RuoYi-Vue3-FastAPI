import { u as pt, i as gt, c as Q, b as v, s as yt, d as bt, O as wt } from "./error-Di1d9d9R.mjs";
import * as j from "yjs";
const U = Math.floor, mt = Math.abs, Ce = Math.log10, St = (t, e) => t < e ? t : e, W = (t, e) => t > e ? t : e, Le = Math.pow, dt = (t) => t !== 0 ? t < 0 : 1 / t < 0, L = Date.now, H = 64, w = 128, F = 63, y = 127, Ut = 2147483647, tt = Number.MAX_SAFE_INTEGER, Be = Number.MIN_SAFE_INTEGER, At = Number.isInteger || ((t) => typeof t == "number" && isFinite(t) && U(t) === t), It = String.fromCharCode, kt = (t) => t.toLowerCase(), Ct = /^\s*/g, Lt = (t) => t.replace(Ct, ""), Bt = /([A-Z])/g, q = (t, e) => Lt(t.replace(Bt, (s) => `${e}${kt(s)}`)), vt = (t) => {
  const e = unescape(encodeURIComponent(t)), s = e.length, n = new Uint8Array(s);
  for (let o = 0; o < s; o++)
    n[o] = /** @type {number} */
    e.codePointAt(o);
  return n;
}, A = (
  /** @type {TextEncoder} */
  typeof TextEncoder < "u" ? new TextEncoder() : null
), Et = (t) => A.encode(t), Ft = A ? Et : vt;
let S = typeof TextDecoder > "u" ? null : new TextDecoder("utf-8", { fatal: !0, ignoreBOM: !0 });
S && S.decode(new Uint8Array()).length === 1 && (S = null);
const ve = (t, e) => pt(e, () => t).join("");
class Ot {
  constructor() {
    this.cpos = 0, this.cbuf = new Uint8Array(100), this.bufs = [];
  }
}
const Tt = () => new Ot(), Dt = (t) => {
  let e = t.cpos;
  for (let s = 0; s < t.bufs.length; s++)
    e += t.bufs[s].length;
  return e;
}, _t = (t) => {
  const e = new Uint8Array(Dt(t));
  let s = 0;
  for (let n = 0; n < t.bufs.length; n++) {
    const o = t.bufs[n];
    e.set(o, s), s += o.length;
  }
  return e.set(new Uint8Array(t.cbuf.buffer, 0, t.cpos), s), e;
}, Mt = (t, e) => {
  const s = t.cbuf.length;
  s - t.cpos < e && (t.bufs.push(new Uint8Array(t.cbuf.buffer, 0, t.cpos)), t.cbuf = new Uint8Array(W(s, e) * 2), t.cpos = 0);
}, a = (t, e) => {
  const s = t.cbuf.length;
  t.cpos === s && (t.bufs.push(t.cbuf), t.cbuf = new Uint8Array(s * 2), t.cpos = 0), t.cbuf[t.cpos++] = e;
}, Ee = a, f = (t, e) => {
  for (; e > y; )
    a(t, w | y & e), e = U(e / 128);
  a(t, y & e);
}, Vt = (t, e) => {
  const s = dt(e);
  for (s && (e = -e), a(t, (e > F ? w : 0) | (s ? H : 0) | F & e), e = U(e / 64); e > 0; )
    a(t, (e > y ? w : 0) | y & e), e = U(e / 128);
}, O = new Uint8Array(3e4), Nt = O.length / 3, jt = (t, e) => {
  if (e.length < Nt) {
    const s = A.encodeInto(e, O).written || 0;
    f(t, s);
    for (let n = 0; n < s; n++)
      a(t, O[n]);
  } else
    I(t, Ft(e));
}, xt = (t, e) => {
  const s = unescape(encodeURIComponent(e)), n = s.length;
  f(t, n);
  for (let o = 0; o < n; o++)
    a(
      t,
      /** @type {number} */
      s.codePointAt(o)
    );
}, T = A && /** @type {any} */
A.encodeInto ? jt : xt, Pt = (t, e) => {
  const s = t.cbuf.length, n = t.cpos, o = St(s - n, e.length), r = e.length - o;
  t.cbuf.set(e.subarray(0, o), n), t.cpos += o, r > 0 && (t.bufs.push(t.cbuf), t.cbuf = new Uint8Array(W(s * 2, r)), t.cbuf.set(e.subarray(o)), t.cpos = r);
}, I = (t, e) => {
  f(t, e.byteLength), Pt(t, e);
}, x = (t, e) => {
  Mt(t, e);
  const s = new DataView(t.cbuf.buffer, t.cpos, e);
  return t.cpos += e, s;
}, Rt = (t, e) => x(t, 4).setFloat32(0, e, !1), zt = (t, e) => x(t, 8).setFloat64(0, e, !1), Yt = (t, e) => (
  /** @type {any} */
  x(t, 8).setBigInt64(0, e, !1)
), G = new DataView(new ArrayBuffer(4)), $t = (t) => (G.setFloat32(0, t), G.getFloat32(0) === t), J = (t, e) => {
  switch (typeof e) {
    case "string":
      a(t, 119), T(t, e);
      break;
    case "number":
      At(e) && mt(e) <= Ut ? (a(t, 125), Vt(t, e)) : $t(e) ? (a(t, 124), Rt(t, e)) : (a(t, 123), zt(t, e));
      break;
    case "bigint":
      a(t, 122), Yt(t, e);
      break;
    case "object":
      if (e === null)
        a(t, 126);
      else if (gt(e)) {
        a(t, 117), f(t, e.length);
        for (let s = 0; s < e.length; s++)
          J(t, e[s]);
      } else if (e instanceof Uint8Array)
        a(t, 116), I(t, e);
      else {
        a(t, 118);
        const s = Object.keys(e);
        f(t, s.length);
        for (let n = 0; n < s.length; n++) {
          const o = s[n];
          T(t, o), J(t, e[o]);
        }
      }
      break;
    case "boolean":
      a(t, e ? 120 : 121);
      break;
    default:
      a(t, 127);
  }
}, et = Q("Unexpected end of array"), st = Q("Integer out of Range");
class qt {
  /**
   * @param {Uint8Array<Buf>} uint8Array Binary data to decode
   */
  constructor(e) {
    this.arr = e, this.pos = 0;
  }
}
const Gt = (t) => new qt(t), Jt = (t, e) => {
  const s = new Uint8Array(t.arr.buffer, t.pos + t.arr.byteOffset, e);
  return t.pos += e, s;
}, B = (t) => Jt(t, p(t)), D = (t) => t.arr[t.pos++], p = (t) => {
  let e = 0, s = 1;
  const n = t.arr.length;
  for (; t.pos < n; ) {
    const o = t.arr[t.pos++];
    if (e = e + (o & y) * s, s *= 128, o < w)
      return e;
    if (e > tt)
      throw st;
  }
  throw et;
}, Xt = (t) => {
  let e = t.arr[t.pos++], s = e & F, n = 64;
  const o = (e & H) > 0 ? -1 : 1;
  if ((e & w) === 0)
    return o * s;
  const r = t.arr.length;
  for (; t.pos < r; ) {
    if (e = t.arr[t.pos++], s = s + (e & y) * n, n *= 128, e < w)
      return o * s;
    if (s > tt)
      throw st;
  }
  throw et;
}, Zt = (t) => {
  let e = p(t);
  if (e === 0)
    return "";
  {
    let s = String.fromCodePoint(D(t));
    if (--e < 100)
      for (; e--; )
        s += String.fromCodePoint(D(t));
    else
      for (; e > 0; ) {
        const n = e < 1e4 ? e : 1e4, o = t.arr.subarray(t.pos, t.pos + n);
        t.pos += n, s += String.fromCodePoint.apply(
          null,
          /** @type {any} */
          o
        ), e -= n;
      }
    return decodeURIComponent(escape(s));
  }
}, Kt = (t) => (
  /** @type any */
  S.decode(B(t))
), _ = S ? Kt : Zt, P = (t, e) => {
  const s = new DataView(t.arr.buffer, t.arr.byteOffset + t.pos, e);
  return t.pos += e, s;
}, Qt = (t) => P(t, 4).getFloat32(0, !1), Wt = (t) => P(t, 8).getFloat64(0, !1), Ht = (t) => (
  /** @type {any} */
  P(t, 8).getBigInt64(0, !1)
), te = [
  (t) => {
  },
  // CASE 127: undefined
  (t) => null,
  // CASE 126: null
  Xt,
  // CASE 125: integer
  Qt,
  // CASE 124: float32
  Wt,
  // CASE 123: float64
  Ht,
  // CASE 122: bigint
  (t) => !1,
  // CASE 121: boolean (false)
  (t) => !0,
  // CASE 120: boolean (true)
  _,
  // CASE 119: string
  (t) => {
    const e = p(t), s = {};
    for (let n = 0; n < e; n++) {
      const o = _(t);
      s[o] = X(t);
    }
    return s;
  },
  (t) => {
    const e = p(t), s = [];
    for (let n = 0; n < e; n++)
      s.push(X(t));
    return s;
  },
  B
  // CASE 116: Uint8Array
], X = (t) => te[127 - D(t)](t), Z = (t) => t === void 0 ? null : t;
class ee {
  constructor() {
    this.map = /* @__PURE__ */ new Map();
  }
  /**
   * @param {string} key
   * @param {any} newValue
   */
  setItem(e, s) {
    this.map.set(e, s);
  }
  /**
   * @param {string} key
   */
  getItem(e) {
    return this.map.get(e);
  }
}
let nt = new ee(), R = !0;
try {
  typeof localStorage < "u" && localStorage && (nt = localStorage, R = !1);
} catch {
}
const ot = nt, se = (t) => R || addEventListener(
  "storage",
  /** @type {any} */
  t
), ne = (t) => R || removeEventListener(
  "storage",
  /** @type {any} */
  t
), M = Symbol("Equality"), Fe = (t, e) => {
  var s;
  return t === e || !!((s = t == null ? void 0 : t[M]) != null && s.call(t, e)) || !1;
}, Oe = (t) => typeof t == "object", oe = Object.keys, Te = (t, e) => {
  const s = [];
  for (const n in t)
    s.push(e(t[n], n));
  return s;
}, K = (t) => oe(t).length, De = (t, e) => {
  for (const s in t)
    if (!e(t[s], s))
      return !1;
  return !0;
}, re = (t, e) => Object.prototype.hasOwnProperty.call(t, e), _e = () => {
}, d = (t, e) => {
  if (t === e)
    return !0;
  if (t == null || e == null || t.constructor !== e.constructor && (t.constructor || Object) !== (e.constructor || Object))
    return !1;
  if (t[M] != null)
    return t[M](e);
  switch (t.constructor) {
    case ArrayBuffer:
      t = new Uint8Array(t), e = new Uint8Array(e);
    // eslint-disable-next-line no-fallthrough
    case Uint8Array: {
      if (t.byteLength !== e.byteLength)
        return !1;
      for (let s = 0; s < t.length; s++)
        if (t[s] !== e[s])
          return !1;
      break;
    }
    case Set: {
      if (t.size !== e.size)
        return !1;
      for (const s of t)
        if (!e.has(s))
          return !1;
      break;
    }
    case Map: {
      if (t.size !== e.size)
        return !1;
      for (const s of t.keys())
        if (!e.has(s) || !d(t.get(s), e.get(s)))
          return !1;
      break;
    }
    case void 0:
    case Object:
      if (K(t) !== K(e))
        return !1;
      for (const s in t)
        if (!re(t, s) || !d(t[s], e[s]))
          return !1;
      break;
    case Array:
      if (t.length !== e.length)
        return !1;
      for (let s = 0; s < t.length; s++)
        if (!d(t[s], e[s]))
          return !1;
      break;
    default:
      return !1;
  }
  return !0;
}, ae = (t, e) => e.includes(t), m = typeof process < "u" && process.release && /node|io\.js/.test(process.release.name) && Object.prototype.toString.call(typeof process < "u" ? process : 0) === "[object process]", rt = typeof window < "u" && typeof document < "u" && !m;
let u;
const ce = () => {
  if (u === void 0)
    if (m) {
      u = v();
      const t = process.argv;
      let e = null;
      for (let s = 0; s < t.length; s++) {
        const n = t[s];
        n[0] === "-" ? (e !== null && u.set(e, ""), e = n) : e !== null && (u.set(e, n), e = null);
      }
      e !== null && u.set(e, "");
    } else typeof location == "object" ? (u = v(), (location.search || "?").slice(1).split("&").forEach((t) => {
      if (t.length !== 0) {
        const [e, s] = t.split("=");
        u.set(`--${q(e, "-")}`, s), u.set(`-${q(e, "-")}`, s);
      }
    })) : u = v();
  return u;
}, V = (t) => ce().has(t), N = (t) => Z(m ? process.env[t.toUpperCase().replaceAll("-", "_")] : ot.getItem(t)), at = (t) => V("--" + t) || N(t) !== null, Me = at("production"), le = m && ae(process.env.FORCE_COLOR, ["true", "1", "2"]), Ve = le || !V("--no-colors") && // @todo deprecate --no-colors
!at("no-color") && (!m || process.stdout.isTTY) && (!m || V("--color") || N("COLORTERM") !== null || (N("TERM") || "").includes("color")), ie = (t) => new Uint8Array(t), fe = (t, e, s) => new Uint8Array(t, e, s), ue = (t) => new Uint8Array(t), he = (t) => {
  let e = "";
  for (let s = 0; s < t.byteLength; s++)
    e += It(t[s]);
  return btoa(e);
}, pe = (t) => Buffer.from(t.buffer, t.byteOffset, t.byteLength).toString("base64"), ge = (t) => {
  const e = atob(t), s = ie(e.length);
  for (let n = 0; n < e.length; n++)
    s[n] = e.charCodeAt(n);
  return s;
}, ye = (t) => {
  const e = Buffer.from(t, "base64");
  return fe(e.buffer, e.byteOffset, e.byteLength);
}, be = rt ? he : pe, we = rt ? ge : ye, ct = /* @__PURE__ */ new Map();
class me {
  /**
   * @param {string} room
   */
  constructor(e) {
    this.room = e, this.onmessage = null, this._onChange = (s) => s.key === e && this.onmessage !== null && this.onmessage({ data: we(s.newValue || "") }), se(this._onChange);
  }
  /**
   * @param {ArrayBuffer} buf
   */
  postMessage(e) {
    ot.setItem(this.room, be(ue(e)));
  }
  close() {
    ne(this._onChange);
  }
}
const Se = typeof BroadcastChannel > "u" ? me : BroadcastChannel, z = (t) => yt(ct, t, () => {
  const e = bt(), s = new Se(t);
  return s.onmessage = (n) => e.forEach((o) => o(n.data, "broadcastchannel")), {
    bc: s,
    subs: e
  };
}), Ne = (t, e) => (z(t).subs.add(e), e), je = (t, e) => {
  const s = z(t), n = s.subs.delete(e);
  return n && s.subs.size === 0 && (s.bc.close(), ct.delete(t)), n;
}, xe = (t, e, s = null) => {
  const n = z(t);
  n.bc.postMessage(e), n.subs.forEach((o) => o(e, s));
}, lt = 0, it = 1, ft = 2, Pe = (t, e) => {
  f(t, lt);
  const s = j.encodeStateVector(e);
  I(t, s);
}, de = (t, e, s) => {
  f(t, it), I(t, j.encodeStateAsUpdate(e, s));
}, Ue = (t, e, s) => de(e, s, B(t)), ut = (t, e, s, n) => {
  try {
    j.applyUpdate(e, B(t), s);
  } catch (o) {
    n != null && n(
      /** @type {Error} */
      o
    ), console.error("Caught error while handling a Yjs update", o);
  }
}, Re = (t, e) => {
  f(t, ft), I(t, e);
}, Ae = ut, ze = (t, e, s, n, o) => {
  const r = p(t);
  switch (r) {
    case lt:
      Ue(t, e, s);
      break;
    case it:
      ut(t, s, n, o);
      break;
    case ft:
      Ae(t, s, n, o);
      break;
    default:
      throw new Error("Unknown message type");
  }
  return r;
}, E = 3e4;
class Ye extends wt {
  /**
   * @param {Y.Doc} doc
   */
  constructor(e) {
    super(), this.doc = e, this.clientID = e.clientID, this.states = /* @__PURE__ */ new Map(), this.meta = /* @__PURE__ */ new Map(), this._checkInterval = /** @type {any} */
    setInterval(() => {
      const s = L();
      this.getLocalState() !== null && E / 2 <= s - /** @type {{lastUpdated:number}} */
      this.meta.get(this.clientID).lastUpdated && this.setLocalState(this.getLocalState());
      const n = [];
      this.meta.forEach((o, r) => {
        r !== this.clientID && E <= s - o.lastUpdated && this.states.has(r) && n.push(r);
      }), n.length > 0 && Ie(this, n, "timeout");
    }, U(E / 10)), e.on("destroy", () => {
      this.destroy();
    }), this.setLocalState({});
  }
  destroy() {
    this.emit("destroy", [this]), this.setLocalState(null), super.destroy(), clearInterval(this._checkInterval);
  }
  /**
   * @return {Object<string,any>|null}
   */
  getLocalState() {
    return this.states.get(this.clientID) || null;
  }
  /**
   * @param {Object<string,any>|null} state
   */
  setLocalState(e) {
    const s = this.clientID, n = this.meta.get(s), o = n === void 0 ? 0 : n.clock + 1, r = this.states.get(s);
    e === null ? this.states.delete(s) : this.states.set(s, e), this.meta.set(s, {
      clock: o,
      lastUpdated: L()
    });
    const c = [], h = [], l = [], b = [];
    e === null ? b.push(s) : r == null ? e != null && c.push(s) : (h.push(s), d(r, e) || l.push(s)), (c.length > 0 || l.length > 0 || b.length > 0) && this.emit("change", [{ added: c, updated: l, removed: b }, "local"]), this.emit("update", [{ added: c, updated: h, removed: b }, "local"]);
  }
  /**
   * @param {string} field
   * @param {any} value
   */
  setLocalStateField(e, s) {
    const n = this.getLocalState();
    n !== null && this.setLocalState({
      ...n,
      [e]: s
    });
  }
  /**
   * @return {Map<number,Object<string,any>>}
   */
  getStates() {
    return this.states;
  }
}
const Ie = (t, e, s) => {
  const n = [];
  for (let o = 0; o < e.length; o++) {
    const r = e[o];
    if (t.states.has(r)) {
      if (t.states.delete(r), r === t.clientID) {
        const c = (
          /** @type {MetaClientState} */
          t.meta.get(r)
        );
        t.meta.set(r, {
          clock: c.clock + 1,
          lastUpdated: L()
        });
      }
      n.push(r);
    }
  }
  n.length > 0 && (t.emit("change", [{ added: [], updated: [], removed: n }, s]), t.emit("update", [{ added: [], updated: [], removed: n }, s]));
}, $e = (t, e, s = t.states) => {
  const n = e.length, o = Tt();
  f(o, n);
  for (let r = 0; r < n; r++) {
    const c = e[r], h = s.get(c) || null, l = (
      /** @type {MetaClientState} */
      t.meta.get(c).clock
    );
    f(o, c), f(o, l), T(o, JSON.stringify(h));
  }
  return _t(o);
}, qe = (t, e, s) => {
  const n = Gt(e), o = L(), r = [], c = [], h = [], l = [], b = p(n);
  for (let Y = 0; Y < b; Y++) {
    const i = p(n);
    let k = p(n);
    const g = JSON.parse(_(n)), C = t.meta.get(i), ht = t.states.get(i), $ = C === void 0 ? 0 : C.clock;
    ($ < k || $ === k && g === null && t.states.has(i)) && (g === null ? i === t.clientID && t.getLocalState() != null ? k++ : t.states.delete(i) : t.states.set(i, g), t.meta.set(i, {
      clock: k,
      lastUpdated: o
    }), C === void 0 && g !== null ? r.push(i) : C !== void 0 && g === null ? l.push(i) : g !== null && (d(g, ht) || h.push(i), c.push(i)));
  }
  (r.length > 0 || h.length > 0 || l.length > 0) && t.emit("change", [{
    added: r,
    updated: h,
    removed: l
  }, s]), (r.length > 0 || c.length > 0 || l.length > 0) && t.emit("update", [{
    added: r,
    updated: c,
    removed: l
  }, s]);
};
export {
  Ye as A,
  U as B,
  It as C,
  d as D,
  M as E,
  Fe as F,
  Oe as G,
  De as H,
  Me as I,
  ve as J,
  re as K,
  Be as L,
  tt as M,
  N,
  _e as O,
  Ve as P,
  T as Q,
  X as R,
  Ft as S,
  J as T,
  Ee as U,
  we as V,
  be as W,
  D as X,
  lt as Y,
  _ as a,
  Pe as b,
  Re as c,
  I as d,
  $e as e,
  Ie as f,
  L as g,
  de as h,
  m as i,
  Tt as j,
  Gt as k,
  Dt as l,
  Te as m,
  St as n,
  Le as o,
  xe as p,
  ze as q,
  p as r,
  Ne as s,
  _t as t,
  je as u,
  it as v,
  f as w,
  qe as x,
  B as y,
  Ce as z
};
//# sourceMappingURL=awareness-Do0nkEFk.mjs.map
