import { ZxioToolDefinition } from '@zxio/mcp-core';
export declare function createTextEditorGetPropsTool(): ZxioToolDefinition;
//# sourceMappingURL=get-props.d.ts.map