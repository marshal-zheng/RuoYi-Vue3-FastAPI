import { ZxioContextPack } from '@zxio/mcp-core';
export declare const textEditorContextPack: ZxioContextPack;
//# sourceMappingURL=context.d.ts.map