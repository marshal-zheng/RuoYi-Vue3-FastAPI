import { ZxioMcpPlugin } from '@zxio/mcp-core';
export declare const textEditorPlugin: ZxioMcpPlugin;
//# sourceMappingURL=index.d.ts.map