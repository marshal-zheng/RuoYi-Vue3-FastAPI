import { realpathSync as s, existsSync as a, readFileSync as E } from "node:fs";
import { join as i, resolve as u, dirname as f, relative as g, sep as w, isAbsolute as T } from "node:path";
import { fileURLToPath as v } from "node:url";
const A = {
  description: "Rich text editor component built on Tiptap v3, supporting bubble menu, fixed menu, floating menu, drag handle, collaborative editing, code highlighting, image upload, @mentions, tags, and more.",
  architecture: "Data is sourced from JSON files under docs/public/r/text-editor/, auto-generated from source code by the generate script. Component source is in packages/text-editor/src/, built on Tiptap v3 + Vue 3 Composition API.",
  conventions: [
    "Text Editor uses Vue 3 Composition API + TypeScript",
    "All MCP tool names are prefixed with text_editor_",
    "Editor is based on @tiptap/vue-3, extensions are in src/extensions/",
    "Menu system supports three modes: BubbleMenu / FixedMenu / FloatingMenu",
    "Collaborative editing is based on Yjs + y-websocket / y-webrtc",
    "Supports custom extensions and menu button configuration"
  ],
  availableTools: ["text_editor_list_features", "text_editor_get_props"]
}, D = [
  "ZXIO_MCP_DATA_DIR",
  "ZXIO_DOCS_DATA_DIR",
  "ZXIO_DATA_DIR"
], p = "^[a-z0-9]+(?:-[a-z0-9]+)*$", l = new RegExp(p), m = {
  readOnlyHint: !0,
  destructiveHint: !1,
  idempotentHint: !0,
  openWorldHint: !1
};
function c(t, r = !1) {
  return {
    content: [{ type: "text", text: JSON.stringify(t, null, 2) }],
    structuredContent: t,
    ...r ? { isError: !0 } : {}
  };
}
function x(t) {
  return c(
    {
      error: t instanceof Error ? t.message : "Unable to read Text Editor data",
      hint: "Use text_editor_list_features for available names; generate the documentation data if it is missing."
    },
    !0
  );
}
function y(t, r) {
  if (!t || typeof t != "object" || Array.isArray(t))
    throw new Error("Arguments must be an object");
  if (Object.keys(t).some((e) => e !== r))
    throw new Error("Unexpected argument");
  if (r) {
    const e = t[r];
    if (typeof e != "string" || !l.test(e))
      throw new Error("feature must be a nonempty lowercase kebab-case name");
  }
}
function C() {
  for (const r of D) {
    const e = process.env[r];
    if (!e) continue;
    if (!e.trim())
      throw new Error(
        "Configured Text Editor documentation data directory must be nonempty"
      );
    const o = u(e), n = i(o, "text-editor");
    if (a(i(n, "types/index.json"))) return n;
    throw new Error("Configured Text Editor documentation data index not found");
  }
  const t = f(v(import.meta.url));
  for (const r of [process.cwd(), t]) {
    let e = u(r);
    for (; ; ) {
      if (a(i(e, "pnpm-workspace.yaml"))) {
        const n = i(e, "docs/public/r/text-editor");
        if (a(n)) return n;
        break;
      }
      const o = f(e);
      if (o === e) break;
      e = o;
    }
  }
}
function b(t, r) {
  const e = g(t, r);
  if (e === "" || e === ".." || e.startsWith(`..${w}`) || T(e))
    throw new Error("Documentation data path escapes its data directory");
}
function h(t, r) {
  const e = s(i(t, r));
  b(t, e);
  const o = JSON.parse(E(e, "utf-8"));
  if (!o || typeof o != "object" || Array.isArray(o))
    throw new Error("Documentation data must contain a JSON object");
  return o;
}
function _() {
  const t = C();
  if (!t) throw new Error("Text Editor data directory not found");
  const r = s(t), e = s(i(r, "types"));
  b(r, e);
  const o = h(e, "index.json"), n = o.features;
  if (!Array.isArray(n) || !n.every(
    (d) => typeof d == "string" && l.test(d)
  ))
    throw new Error("Text Editor feature index is invalid");
  return { data: o, names: n, typesDir: e };
}
function j(t) {
  const { names: r, typesDir: e } = _();
  if (!r.includes(t)) throw new Error("Unknown feature: " + t);
  return h(e, `${t}.json`);
}
function P() {
  return {
    name: "text_editor_list_features",
    title: "List Text Editor features",
    description: "List available Text Editor features and categories. Call zxio_get_domain_context first for domain context.",
    inputSchema: {
      type: "object",
      properties: {},
      additionalProperties: !1
    },
    annotations: m,
    handler: async (t) => {
      try {
        return y(t), c(_().data);
      } catch (r) {
        return x(r);
      }
    }
  };
}
function k() {
  return {
    name: "text_editor_get_props",
    title: "Get Text Editor properties",
    description: "Get properties of an indexed Text Editor feature. Call text_editor_list_features for available names and zxio_get_domain_context for domain context.",
    inputSchema: {
      type: "object",
      properties: {
        feature: {
          type: "string",
          pattern: p,
          description: "An available lowercase kebab-case Text Editor feature name"
        }
      },
      required: ["feature"],
      additionalProperties: !1
    },
    annotations: m,
    handler: async (t) => {
      try {
        return y(t, "feature"), c(j(t.feature));
      } catch (r) {
        return x(r);
      }
    }
  };
}
const R = {
  domain: "text-editor",
  contextPack: A,
  tools: [P(), k()]
};
export {
  R as textEditorPlugin
};
//# sourceMappingURL=index.mjs.map
