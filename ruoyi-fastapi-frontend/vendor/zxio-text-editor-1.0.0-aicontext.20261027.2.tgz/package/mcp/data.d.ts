import { ZxioJsonObject, ZxioToolAnnotations, ZxioToolResult } from '@zxio/mcp-core';
export declare const namePattern = "^[a-z0-9]+(?:-[a-z0-9]+)*$";
export declare const readOnlyToolAnnotations: ZxioToolAnnotations;
export declare function createJsonResult(data: ZxioJsonObject, isError?: boolean): ZxioToolResult;
export declare function createErrorResult(error: unknown): ZxioToolResult;
export declare function validateArguments(args: unknown, parameter?: 'feature'): asserts args is Record<string, unknown>;
export declare function readDataIndex(): {
    data: ZxioJsonObject;
    names: string[];
    typesDir: string;
};
export declare function readDataProps(name: string): ZxioJsonObject;
//# sourceMappingURL=data.d.ts.map