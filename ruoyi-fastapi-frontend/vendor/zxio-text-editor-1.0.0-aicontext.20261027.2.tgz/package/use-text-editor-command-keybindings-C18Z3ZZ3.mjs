import { Extension as qi } from "@tiptap/core";
import { Plugin as Vo, PluginKey as jo, NodeSelection as Cn, TextSelection as ut } from "@tiptap/pm/state";
import { computePosition as $o, flip as Ho, autoUpdate as Gi, offset as Wi, shift as Ji, size as Zi } from "@floating-ui/dom";
import { Y as Xi, $ as Yi, a0 as cn, z as Uo, a1 as Qi, H as bt, G as Ko, F as es, p as ts, a2 as ns, A as qo, B as os, D as is } from "./runtime-extensions-B_GmfVEg.mjs";
import { am as ss } from "./delivery-surfaces-BeupB41w.mjs";
import { watch as Q, defineAsyncComponent as Dt, defineComponent as Ae, inject as yt, computed as S, ref as W, onBeforeUnmount as rt, createBlock as He, createCommentVNode as se, openBlock as N, unref as v, withCtx as ht, createElementVNode as M, normalizeClass as K, createElementBlock as F, withModifiers as Ke, createVNode as j, Fragment as Le, renderList as Fe, toDisplayString as me, nextTick as ft, useAttrs as $t, shallowRef as Be, onMounted as Ht, mergeProps as st, h as Ft, provide as In, normalizeStyle as pt, renderSlot as je, reactive as rs, onScopeDispose as kt, isRef as An, normalizeProps as wt, guardReactiveProps as xt, toRef as Xe, resolveComponent as as, toRaw as hn, withKeys as oo, toValue as qe, createTextVNode as Yt, useId as ls, Teleport as cs, withDirectives as us, vShow as ds } from "vue";
import { useNamespace as Pe, useOverlayZIndex as zn, useLocale as fs } from "@zxio/zxui/hooks";
import { ZxIcon as Ie } from "@zxio/zxui/core";
import { ZxTooltipOrPopover as Qt } from "@zxio/zxui/tooltip-or-popover";
import { bB as Mn, bS as ps, bw as ms, bu as vs, bq as gs, bo as En, bP as hs, bz as bs, bC as ys, bQ as ks, bR as Go, cc as ws, bG as un, bK as en, d as xs, cd as Ts, bL as Is, e as Wo, g as As, ce as Es, bE as Ss, c as _s, a as Os, r as Rs, S as Ns, a4 as Ls, $ as Bs, a3 as Cs, a0 as zs, l as Ms, m as Jo, cf as io, c5 as Ds, c7 as Fs, c0 as Ps, c1 as Vs, bZ as js, b_ as $s, c2 as Hs, c3 as Us, c8 as Ks, j as qs } from "./authoring-action-port-BO658pvW.mjs";
import { useShortcutRuntime as Ut, useParentShortcutOwner as Zo, useShortcutPresentation as Gs, useShortcutOwner as Xo, useShortcutAction as jt, useActionView as bn, bindShortcutOwner as Ws } from "@zxio/keybindings/vue";
import { BubbleMenu as Yo, FloatingMenu as Js } from "@tiptap/vue-3/menus";
import { DecorationSet as vt, Decoration as Zs } from "@tiptap/pm/view";
import { useThemeRuntime as Xs, useThemeScope as Ys, useThemeApp as Qs } from "@zxio/zxui/theme-provider";
import { createActionPort as tn } from "@zxio/keybindings/core";
import { n as er, q as tr, m as Qo, I as dn, f as nr, H as so } from "./inline-ai-shortcut-router-a-QG5h2e.mjs";
import { bu as Ye, c as ro, bC as or, bX as it, h as ei, c9 as mt, bh as ir, r as sr } from "./link-paste-handler-COpsSlXB.mjs";
import * as ti from "@tiptap/pm/history";
import { Slice as ni, Fragment as oi } from "@tiptap/pm/model";
import { E as gt, F as nn, v as Dn, b as rr, S as ar, p as lr, f as cr } from "./envelope-CrN5-dS1.mjs";
import { c as ur } from "./stable-block-ids-CPxz-1sA.mjs";
import { useAIContextScope as dr, createAIContextKnownValues as fr, isAIContextReady as pr, AIContextError as on, captureAIContext as mr, createAIContextId as vr } from "@zxio/zxui/ai-context";
import { z as Fn, q as ii, s as si, o as gr, n as hr } from "./actions-Sd62WBGv.mjs";
import { buildProps as br, definePropType as _e, withInstall as yr } from "@zxio/zxui/runtime";
import { EditorContent as kr } from "@tiptap/vue-3";
import { dropPoint as wr } from "@tiptap/pm/transform";
import { DragHandle as xr } from "@tiptap/extension-drag-handle-vue-3";
import { createPackageTextEditorRuntimeHostEditorV2 as Tr } from "#runtime-host-authority";
const nf = qi.create(
  {
    name: "floatingQuoteButton",
    addOptions() {
      return {
        onClick: void 0,
        themeOwner: null
      };
    },
    addProseMirrorPlugins() {
      const e = this.options, t = this.editor;
      return [
        new Vo({
          key: new jo("floatingQuoteButton"),
          view: (o) => new Ir(o, t, e)
        })
      ];
    }
  }
);
class Ir {
  constructor(t, o, n) {
    this.button = null, this.binding = null, this.portalGeneration = 0, this.view = t, this.editor = o, this.options = n, this.createButton();
  }
  createButton() {
    this.button = this.view.dom.ownerDocument.createElement("button"), this.button.className = ss("text-editor-quote-button"), this.button.type = "button", this.button.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    `, this.button.style.cssText = `
      position: absolute;
      display: none;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border: none;
      border-radius: var(--zx-semantic-radius-control);
      background: var(--zx-semantic-action-focus-ring);
      color: var(--zx-semantic-text-primary);
      cursor: pointer;
      z-index: 100;
      transition: background var(--zx-semantic-motion-duration) ease;
    `, this.button.addEventListener("click", this.handleClick.bind(this)), this.button.addEventListener("mouseenter", () => {
      this.button && (this.button.style.background = "var(--zx-semantic-text-primary)");
    }), this.button.addEventListener("mouseleave", () => {
      this.button && (this.button.style.background = "var(--zx-semantic-action-focus-ring)");
    });
  }
  handleClick() {
    if (!this.options.onClick) return;
    const { from: t, to: o } = this.view.state.selection, n = this.editor.state.doc.textBetween(t, o);
    this.options.onClick(n), this.hide();
  }
  update(t) {
    this.view = t;
    const { state: o } = t, { selection: n } = o, { empty: i } = n;
    if (i || this.editor.isEditable) {
      this.hide();
      return;
    }
    this.show();
  }
  async show() {
    if (!this.button) return;
    if (!this.binding) {
      const f = this.options.themeOwner;
      if (!f) return;
      const c = ++this.portalGeneration, u = await f.acquirePortal();
      if (c !== this.portalGeneration) {
        u.ok && u.value.release();
        return;
      }
      if (!u.ok || !this.button) return;
      this.binding = u.value, this.binding.target.appendChild(this.button);
    }
    const t = this.portalGeneration, { from: o, to: n } = this.view.state.selection, i = this.view.coordsAtPos(o), s = this.view.coordsAtPos(n), a = {
      getBoundingClientRect() {
        return {
          x: i.left,
          y: i.top,
          width: s.right - i.left,
          height: s.bottom - i.top,
          top: i.top,
          right: s.right,
          bottom: s.bottom,
          left: i.left
        };
      }
    }, { x: l, y: r } = await $o(a, this.button, {
      placement: "top",
      middleware: [Xi(4), Ho(), Yi(4)]
    });
    t !== this.portalGeneration || !this.button || !this.binding || (this.button.style.left = `${l}px`, this.button.style.top = `${r}px`, this.button.style.display = "flex");
  }
  hide() {
    var t, o;
    this.portalGeneration += 1, this.button && (this.button.style.display = "none"), (t = this.button) == null || t.remove(), (o = this.binding) == null || o.release(), this.binding = null;
  }
  destroy() {
    var t;
    this.hide(), (t = this.button) == null || t.remove(), this.button = null;
  }
}
const Ar = (e, t) => {
  if (!e)
    return t.documentState.value;
  t.hasCommentExtension.value && (t.annotationBridgeState.value = bs(
    e.getJSON(),
    t.annotationBridgeState.value
  ));
  const o = ys(
    t.documentState.value,
    t.annotationBridgeState.value
  ), n = ks(e, o, {
    markdownExportMode: t.getMarkdownExportMode()
  });
  return t.documentState.value = n, t.annotationBridgeState.value = Mn(n), n;
}, yn = (e) => Mn(e), Er = (e) => {
  const t = (g = e.editor.value) => Ar(g, e), o = (g) => hs(g), n = (g) => o({
    documentValue: g,
    contentType: "document",
    stableBlockIdentity: e.getStableBlockIdentityOptions()
  }).document, i = (g) => {
    if (!e.editor.value)
      return !1;
    switch (g.sourceType) {
      case "html":
        return En(t(e.editor.value)) === g.content;
      case "json":
        return JSON.stringify(e.editor.value.getJSON()) === JSON.stringify(g.content);
      case "markdown":
        return JSON.stringify(t(e.editor.value).body.content) === JSON.stringify(g.document.body.content);
      case "document": {
        const V = n(
          t(e.editor.value)
        ), H = n(
          g.document
        );
        return JSON.stringify(V) === JSON.stringify(H);
      }
    }
  }, s = (g) => {
    e.editor.value && (e.isApplyingExternalContent.value = !0, e.documentState.value = g.document, e.annotationBridgeState.value = Mn(g.document), e.editor.value.commands.setContent(g.content ?? ""), e.isApplyingExternalContent.value = !1);
  }, a = ({
    editor: g,
    document: V,
    outputType: H
  }) => {
    const T = V ?? t(g);
    return Go(g, {
      outputType: H,
      markdownExportMode: e.getMarkdownExportMode(),
      document: T
    });
  }, l = () => t(e.editor.value), r = () => En(l()), f = (g = {}) => gs(l(), {
    mode: g.mode ?? e.getMarkdownExportMode()
  }), c = () => {
    var g;
    return ((g = e.editor.value) == null ? void 0 : g.getJSON()) ?? e.documentState.value.body.content ?? gt().body.content;
  }, u = (g = {}) => vs(l(), g), p = (g = {}) => ms(l(), g), m = (g, V = {}) => {
    if (!e.editor.value)
      return;
    const H = V.contentType ?? (nn(g) ? "document" : typeof g == "string" ? "html" : "json"), T = o({
      baseDocument: e.documentState.value,
      modelValue: g,
      documentValue: H === "document" ? g : void 0,
      content: H === "html" && typeof g == "string" ? g : null,
      contentType: H,
      hydrateAnnotations: e.hasCommentExtension.value,
      stableBlockIdentity: e.getStableBlockIdentityOptions()
    });
    s(T);
  };
  return {
    getCurrentDocument: t,
    resolveHydratedState: o,
    isHydratedStateSynced: i,
    applyHydratedEditorState: s,
    exportEditorContentValue: a,
    getHTML: r,
    getMarkdown: f,
    getJSON: c,
    getDocument: l,
    getText: u,
    getExcerpt: p,
    setContent: m,
    setHTML: (g) => {
      m(g, { contentType: "html" });
    },
    setMarkdown: (g) => {
      m(g, { contentType: "markdown" });
    },
    setJSON: (g) => {
      m(g, { contentType: "json" });
    },
    setDocument: (g) => {
      m(g, { contentType: "document" });
    },
    getRuntimeStatus: () => ps({
      editor: e.editor.value,
      document: l()
    })
  };
};
let Sr = 0, _r = 0;
const Or = () => `zx-editor-${++Sr}`, Rr = () => `zx-asset-task-${++_r}`, Nr = (e) => e.type.startsWith("image/") ? "image" : e.type.startsWith("video/") ? "video" : "file", Lr = (e, t) => {
  var i, s, a;
  const o = e.asset.meta ?? {}, n = e.asset.type === "file" ? {
    ...o,
    fileName: ((i = e.asset.meta) == null ? void 0 : i.fileName) ?? e.asset.title ?? t.name,
    size: typeof ((s = e.asset.meta) == null ? void 0 : s.size) == "number" ? (a = e.asset.meta) == null ? void 0 : a.size : t.size
  } : Object.keys(o).length ? o : void 0;
  return {
    ...e,
    asset: {
      ...e.asset,
      mimeType: e.asset.mimeType ?? (t.type ? t.type : void 0),
      title: e.asset.title ?? t.name,
      ...n ? { meta: n } : {}
    }
  };
}, Br = (e) => {
  var o;
  const t = (o = e.body.content) == null ? void 0 : o.content;
  return !Array.isArray(t) || t.length === 0;
}, Cr = ({
  editor: e,
  filePlatform: t,
  intakeDispatcher: o,
  getCurrentDocument: n,
  editorId: i = Or()
}) => {
  const s = () => t.value ?? null, a = (p) => {
    var m, y;
    (y = (m = s()) == null ? void 0 : m.onDiagnostic) == null || y.call(m, p);
  }, l = ({
    files: p,
    source: m = "programmatic",
    htmlContent: y,
    dropPos: z = null,
    context: _
  }) => {
    var V;
    const x = e.value, k = x == null ? void 0 : x.state.selection, g = n();
    return {
      source: m,
      files: Array.from(p),
      htmlContent: y,
      dropPos: z,
      selectionFrom: (k == null ? void 0 : k.from) ?? null,
      selectionTo: (k == null ? void 0 : k.to) ?? null,
      editorId: i,
      currentDocumentEmpty: (x == null ? void 0 : x.isEmpty) ?? Br(g),
      context: _,
      constraints: (V = s()) == null ? void 0 : V.constraints
    };
  }, r = async ({
    files: p,
    source: m = "programmatic",
    htmlContent: y,
    dropPos: z = null,
    anchorPos: _ = null,
    context: x
  }) => {
    const k = l({
      files: p,
      source: m,
      htmlContent: y,
      dropPos: z,
      context: x
    }), g = o == null ? void 0 : o.value;
    return g ? g.dispatch({
      event: k,
      anchorPos: _
    }) : {
      event: k,
      decision: {
        intent: "reject",
        code: "intake-dispatcher-missing",
        reason: "dispatcher-missing",
        message: "The unified file intake dispatcher is not configured for this editor instance."
      },
      handled: !1
    };
  }, f = (p, m = {}) => ({
    id: Rr(),
    kind: Nr(p),
    status: m.status ?? "queued",
    fileName: p.name,
    mimeType: p.type || "application/octet-stream",
    size: p.size,
    anchorPos: m.anchorPos ?? null,
    previewUrl: m.previewUrl,
    progress: m.progress
  }), c = (p) => {
    var m, y;
    (y = (m = s()) == null ? void 0 : m.onTaskEvent) == null || y.call(m, p);
  };
  return {
    editorId: i,
    getFilePlatform: s,
    emitDiagnostic: a,
    emitTaskEvent: c,
    captureIntakeEvent: l,
    intakeFiles: r,
    createAssetTaskRecord: f,
    uploadAsset: async (p, m = {}) => {
      const y = s();
      if (!(y != null && y.uploadAsset))
        throw new Error("filePlatform.uploadAsset is not provided");
      const z = m.intake ?? l({
        source: m.source,
        files: [p],
        htmlContent: m.htmlContent,
        dropPos: m.dropPos,
        context: m.context
      }), _ = m.emitTaskLifecycle ?? !m.task, x = m.task ?? f(p, {
        anchorPos: m.anchorPos,
        previewUrl: m.previewUrl,
        progress: m.progress
      }), k = {
        ...x,
        status: "uploading"
      };
      _ && (c({
        type: "task-created",
        intake: z,
        task: x
      }), c({
        type: "task-updated",
        intake: z,
        task: k
      }));
      try {
        const g = Lr(
          await y.uploadAsset({
            event: z,
            file: p,
            task: k,
            context: m.context ?? z.context,
            signal: m.signal,
            updateTask: m.updateTask
          }),
          p
        ), V = {
          ...k,
          status: "completed"
        };
        return _ && c({
          type: "task-completed",
          intake: z,
          task: V,
          asset: g
        }), g;
      } catch (g) {
        const V = {
          ...k,
          status: "failed",
          errorMessage: g instanceof Error ? g.message : "Unknown error"
        };
        throw _ && c({
          type: "task-failed",
          intake: z,
          task: V,
          error: {
            message: V.errorMessage
          }
        }), g;
      }
    }
  };
};
class Nt extends Error {
  constructor(t, o) {
    super(o), this.name = "ZxAssetMaterializationError", this.code = t;
  }
}
const zr = (e, t) => {
  const o = e.state.doc.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? e.state.selection.from : Math.max(0, Math.min(t, o));
}, Mr = (e) => typeof e == "string" && e ? e : void 0, Dr = (e, t, o) => {
  var i;
  const n = t.nodeKind ?? o;
  if (n === "image") {
    const s = e.schema.nodes.image;
    if (!s)
      throw new Nt(
        "asset-materializer-image-missing",
        "The image extension is not available for asset materialization."
      );
    return s.create({
      assetId: t.asset.id,
      src: t.asset.src,
      title: t.asset.title ?? null,
      alt: Mr((i = t.asset.meta) == null ? void 0 : i.alt) ?? t.asset.title ?? null
    });
  }
  if (n === "video") {
    const s = e.schema.nodes.video;
    if (!s)
      throw new Nt(
        "asset-materializer-video-missing",
        "The video extension is not available for asset materialization."
      );
    return s.create({
      assetId: t.asset.id,
      src: t.asset.src
    });
  }
  if (n === "attachment") {
    const s = e.schema.nodes.attachment;
    if (!s)
      throw new Nt(
        "asset-materializer-attachment-missing",
        "The attachment extension is not available for asset materialization."
      );
    return s.create({
      assetId: t.asset.id
    });
  }
  throw new Nt(
    "asset-materializer-node-kind-unsupported",
    `Unsupported asset node kind "${String(n)}".`
  );
}, Fr = async ({
  editor: e,
  documentState: t,
  preferredNodeKind: o,
  resolveTaskPosition: n,
  resolvedAsset: i,
  task: s
}) => {
  if (!e)
    throw new Nt(
      "asset-materializer-editor-missing",
      "The editor instance is unavailable for asset materialization."
    );
  const a = Dr(e, i, o), l = zr(
    e,
    (n == null ? void 0 : n(s.id)) ?? s.anchorPos
  );
  e.view.dispatch(e.state.tr.insert(l, a)), t.value = gt({
    ...t.value,
    assets: Dn(t.value.assets, [i.asset])
  });
}, Pr = 1, Vr = (e) => ({
  ...Object.hasOwn(e, "status") ? { status: e.status } : {},
  ...Object.hasOwn(e, "previewUrl") ? { previewUrl: e.previewUrl } : {},
  ...Object.hasOwn(e, "progress") ? { progress: e.progress } : {},
  ...Object.hasOwn(e, "errorCode") ? { errorCode: e.errorCode } : {},
  ...Object.hasOwn(e, "errorMessage") ? {
    errorMessage: e.errorMessage
  } : {}
}), kn = (e, t) => {
  if (t.type === "set") {
    const o = [...e], n = o.findIndex(
      (i) => i.id === t.task.id
    );
    return n === -1 ? (o.push(t.task), o) : (o.splice(n, 1, t.task), o);
  }
  return t.type === "patch" ? e.map(
    (o) => o.id === t.id ? {
      ...o,
      ...Vr(t.patch)
    } : o
  ) : e.filter((o) => o.id !== t.id);
}, jr = () => {
  let e = [];
  const t = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Map(), n = () => {
    const s = {
      tasks: [...e]
    };
    t.forEach((a) => a(s));
  }, i = (s) => e.find((a) => a.id === s) ?? null;
  return {
    getSnapshot: () => ({
      tasks: [...e]
    }),
    getTask: i,
    listTasks: () => [...e],
    patchTask: (s, a) => (e = kn(e, {
      type: "patch",
      id: s,
      patch: a
    }), n(), i(s)),
    registerControls: (s, a) => {
      o.set(s, a);
    },
    removeTask: (s) => {
      o.delete(s), e = kn(e, {
        type: "remove",
        id: s
      }), n();
    },
    retryTask: (s) => {
      var a, l;
      (l = (a = o.get(s)) == null ? void 0 : a.retry) == null || l.call(a);
    },
    setTask: (s) => {
      e = kn(e, {
        type: "set",
        task: s
      }), n();
    },
    subscribe: (s) => (t.add(s), () => {
      t.delete(s);
    }),
    cancelTask: (s) => {
      var a, l;
      (l = (a = o.get(s)) == null ? void 0 : a.cancel) == null || l.call(a);
    },
    requestRemove: (s) => {
      var a, l;
      (l = (a = o.get(s)) == null ? void 0 : a.remove) == null || l.call(a);
    }
  };
}, $r = (e) => {
  if (!(typeof URL > "u" || typeof URL.createObjectURL != "function"))
    try {
      return URL.createObjectURL(e);
    } catch {
      return;
    }
}, Xt = (e) => {
  if (!(!e || typeof URL > "u" || typeof URL.revokeObjectURL != "function"))
    try {
      URL.revokeObjectURL(e);
    } catch {
    }
}, Hr = (e) => e instanceof DOMException || e instanceof Error ? e.name === "AbortError" : !1, Ur = (e, t) => e instanceof Error && e.message ? e.message : t, Kr = ({
  documentState: e,
  editor: t,
  filePlatformRuntime: o,
  maxConcurrentTasks: n = Pr
}) => {
  const i = jr(), s = /* @__PURE__ */ new Map(), a = [], l = /* @__PURE__ */ new Set();
  let r = null;
  const f = (x) => i.getTask(x), c = (x, k, g) => {
    const V = i.patchTask(x, k);
    return V ? (o.emitTaskEvent({
      type: "task-updated",
      intake: g,
      task: V
    }), V) : null;
  }, u = (x, k = "Asset task cancelled.") => {
    var w;
    const g = s.get(x), V = i.getTask(x);
    if (!g || !V || ["completed", "cancelled"].includes(V.status))
      return;
    const H = a.indexOf(x);
    H >= 0 && a.splice(H, 1), (w = g.uploadController) == null || w.abort(), g.uploadController = null;
    const T = i.patchTask(x, {
      status: "cancelled",
      errorCode: void 0,
      errorMessage: void 0,
      progress: void 0
    });
    T && o.emitTaskEvent({
      type: "task-cancelled",
      intake: g.event,
      task: T,
      error: {
        message: k
      }
    });
  }, p = (x) => {
    const k = i.getTask(x);
    k && !["failed", "completed", "cancelled"].includes(k.status) && u(x);
    const g = s.get(x);
    Xt(g == null ? void 0 : g.previewUrl), s.delete(x), i.removeTask(x);
  }, m = (x) => {
    const k = s.get(x), g = i.getTask(x);
    !k || !g || !["failed", "cancelled"].includes(g.status) || !c(
      x,
      {
        status: "queued",
        errorCode: void 0,
        errorMessage: void 0,
        progress: void 0
      },
      k.event
    ) || (a.push(x), y());
  }, y = () => {
    for (; l.size < Math.max(1, n) && a.length > 0; ) {
      const x = a.shift();
      !x || l.has(x) || z(x).catch((k) => {
        o.emitDiagnostic({
          code: "asset-task-runner-unhandled",
          message: k instanceof Error ? k.message : "The asset task runner failed unexpectedly.",
          severity: "error",
          stage: "asset-pipeline",
          cause: k
        });
      });
    }
  }, z = async (x) => {
    var H;
    const k = s.get(x), g = i.getTask(x);
    if (!k || !g)
      return;
    l.add(x), k.uploadController = new AbortController(), k.previewUrl || (k.previewUrl = $r(k.file)), c(
      x,
      {
        status: "reading",
        previewUrl: k.previewUrl
      },
      k.event
    );
    const V = c(
      x,
      {
        status: "uploading"
      },
      k.event
    );
    if (!V) {
      l.delete(x), k.uploadController = null;
      return;
    }
    try {
      const T = await o.uploadAsset(
        k.file,
        {
          intake: k.event,
          anchorPos: V.anchorPos,
          previewUrl: k.previewUrl,
          context: {
            ...k.event.context ?? {},
            preferredNodeKind: k.preferredNodeKind,
            ...k.preferredNodeKind ? {
              nodeKind: k.preferredNodeKind
            } : {}
          },
          emitTaskLifecycle: !1,
          signal: k.uploadController.signal,
          task: V,
          updateTask: (J) => {
            c(x, J, k.event);
          }
        }
      ), w = i.getTask(x);
      if (!w || w.status === "cancelled") {
        Xt(k.previewUrl);
        return;
      }
      const R = c(
        x,
        {
          status: "processing",
          progress: 100
        },
        k.event
      );
      if (!R)
        return;
      await Fr({
        editor: t.value,
        documentState: e,
        preferredNodeKind: k.preferredNodeKind,
        resolveTaskPosition: r ?? ((J) => {
          var ne;
          return ((ne = i.getTask(J)) == null ? void 0 : ne.anchorPos) ?? null;
        }),
        resolvedAsset: T,
        task: R
      });
      const X = i.patchTask(x, {
        status: "completed",
        errorCode: void 0,
        errorMessage: void 0,
        progress: 100
      });
      X && o.emitTaskEvent({
        type: "task-completed",
        intake: k.event,
        task: X,
        asset: T
      }), Xt(k.previewUrl);
    } catch (T) {
      if ((H = k.uploadController) != null && H.signal.aborted || Hr(T)) {
        u(x), Xt(k.previewUrl);
        return;
      }
      const w = i.patchTask(x, {
        status: "failed",
        errorCode: T instanceof Error && "code" in T && typeof T.code == "string" ? T.code : "asset-task-failed",
        errorMessage: Ur(T, "Asset task failed.")
      });
      w && (o.emitTaskEvent({
        type: "task-failed",
        intake: k.event,
        task: w,
        error: {
          code: w.errorCode,
          message: w.errorMessage ?? "Asset task failed."
        }
      }), o.emitDiagnostic({
        code: w.errorCode ?? "asset-task-failed",
        message: w.errorMessage ?? "Asset task failed.",
        severity: "error",
        stage: T instanceof Nt ? "materialization" : "asset-pipeline",
        intake: k.event,
        task: w,
        cause: T
      }));
    } finally {
      l.delete(x), k.uploadController = null, y();
    }
  };
  return {
    enqueue: ({
      anchorPos: x = null,
      event: k,
      preferredNodeKind: g = null
    }) => k.files.length ? (k.files.forEach((V) => {
      const H = o.createAssetTaskRecord(V, {
        anchorPos: x
      });
      s.set(H.id, {
        event: k,
        file: V,
        preferredNodeKind: g,
        uploadController: null
      }), i.registerControls(H.id, {
        cancel: () => u(H.id),
        remove: () => p(H.id),
        retry: () => m(H.id)
      }), i.setTask(H), o.emitTaskEvent({
        type: "task-created",
        intake: k,
        task: H
      }), a.push(H.id);
    }), y(), !0) : !1,
    getTask: f,
    getTasks: () => i.listTasks(),
    removeTask: p,
    retryTask: m,
    setTaskPositionResolver: (x) => {
      r = x;
    },
    subscribe: (x) => i.subscribe(x),
    cancelTask: (x) => u(x)
  };
};
class Rt extends Error {
  constructor(t, o) {
    super(o), this.name = "ZxRemoteEmbedResolutionError", this.code = t;
  }
}
const Et = (e) => typeof e == "string" && e.trim().length > 0, qr = (e, t) => {
  const o = e.state.doc.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? null : Math.max(0, Math.min(t, o));
}, Gr = (e) => {
  var n, i, s, a;
  const t = e.asset, o = {
    ...e.attrs ?? {},
    url: e.url
  };
  return t != null && t.id && !Et(o.assetId) && (o.assetId = t.id), t != null && t.title && !Et(o.title) && (o.title = t.title), Et((n = t == null ? void 0 : t.meta) == null ? void 0 : n.name) && !Et(o.name) && (o.name = (i = t.meta) == null ? void 0 : i.name), Et((s = t == null ? void 0 : t.meta) == null ? void 0 : s.icon) && !Et(o.icon) && (o.icon = (a = t.meta) == null ? void 0 : a.icon), o;
}, Wr = async ({
  anchorPos: e = null,
  documentState: t,
  editor: o,
  event: n,
  filePlatform: i,
  url: s
}) => {
  if (!(i != null && i.resolveRemoteEmbed))
    throw new Rt(
      "remote-embed-resolver-missing",
      "The host platform does not provide resolveRemoteEmbed()."
    );
  if (!o)
    throw new Rt(
      "remote-embed-editor-missing",
      "The editor instance is unavailable for remote embed materialization."
    );
  const a = await i.resolveRemoteEmbed({
    event: n,
    url: s,
    htmlContent: n.htmlContent,
    context: n.context
  });
  if (!a)
    throw new Rt(
      "remote-embed-unresolved",
      `The host platform declined to resolve remote embed URL "${s}".`
    );
  if (!o.schema.nodes.embed)
    throw new Rt(
      "remote-embed-node-missing",
      "The embed extension is not available for remote embed materialization."
    );
  const r = o.chain().focus(), f = qr(o, e);
  if (f !== null && r.setTextSelection(f), !r.insertContent({
    type: "embed",
    attrs: Gr(a)
  }).run())
    throw new Rt(
      "remote-embed-materialization-failed",
      `Failed to insert the resolved remote embed for URL "${s}".`
    );
  return a.asset && (t.value = gt({
    ...t.value,
    assets: Dn(t.value.assets, [a.asset])
  })), {
    handled: !0,
    resolution: a
  };
}, Pn = (e) => typeof window < "u" && e === window, ri = (e) => typeof e == "function" ? e() ?? null : e ?? null, Jr = (e) => [...e].sort((t, o) => {
  const n = typeof t.pos == "number" ? t.pos : Number.MAX_SAFE_INTEGER, i = typeof o.pos == "number" ? o.pos : Number.MAX_SAFE_INTEGER;
  if (n !== i)
    return n - i;
  const s = typeof t.order == "number" ? t.order : 0, a = typeof o.order == "number" ? o.order : 0;
  return s - a;
}), ai = (e) => !!(e.dom && typeof e.dom.getBoundingClientRect == "function" && e.dom.isConnected !== !1), li = (e, t) => {
  const o = ri(t);
  if (o)
    return o;
  const n = e.find(ai);
  return n ? ws(n.dom) ?? (typeof window < "u" ? window : null) : typeof window < "u" ? window : null;
}, Zr = (e, t) => {
  const o = ri(t);
  if (o != null && Number.isFinite(o))
    return Math.max(o, 0);
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 0;
  const n = Pn(e) ? document.documentElement : e, i = window.getComputedStyle(n), s = Number.parseFloat(i.scrollPaddingTop || "0") || 0, a = Number.parseFloat(i.paddingTop || "0") || 0;
  return Math.max(s || a, 0);
}, Xr = (e, t) => !e || Pn(e) ? t + 1 : e.getBoundingClientRect().top + t + 1, Yr = (e) => {
  if (!e)
    return !1;
  if (!Pn(e))
    return e.scrollHeight <= e.clientHeight + 1 ? !1 : e.scrollTop + e.clientHeight >= e.scrollHeight - 1;
  if (typeof document > "u")
    return !1;
  const t = e.innerHeight || document.documentElement.clientHeight || 0, o = e.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0, n = Math.max(
    document.documentElement.scrollHeight,
    document.body.scrollHeight
  );
  return n <= t + 1 ? !1 : o + t >= n - 1;
}, Sn = (e = [], t = {}) => {
  var r, f, c, u;
  const o = Jr(e);
  if (o.length === 0)
    return null;
  const n = o.filter(ai);
  if (n.length === 0)
    return ((r = o.find((p) => p.isActive)) == null ? void 0 : r.id) ?? ((f = o[0]) == null ? void 0 : f.id) ?? null;
  const i = li(
    n,
    t.scrollContainer
  );
  if (Yr(i))
    return ((c = n[n.length - 1]) == null ? void 0 : c.id) ?? null;
  const s = Xr(
    i,
    Zr(i, t.topInset)
  );
  let a = null, l = null;
  for (const p of n) {
    const m = p.dom.getBoundingClientRect();
    m.top <= s && (a = p), !l && m.bottom >= s && (l = p);
  }
  return (a == null ? void 0 : a.id) ?? (l == null ? void 0 : l.id) ?? ((u = n[0]) == null ? void 0 : u.id) ?? null;
}, Qr = (e) => {
  let t = Sn(
    e.getHeadings(),
    {
      scrollContainer: e.scrollContainer,
      topInset: e.topInset
    }
  ), o = 0, n = null, i = null;
  const s = /* @__PURE__ */ new Set(), a = () => {
    s.forEach((u) => u(t));
  }, l = () => {
    const u = Sn(e.getHeadings(), {
      scrollContainer: e.scrollContainer,
      topInset: e.topInset
    });
    u !== t && (t = u, a());
  }, r = () => {
    o || typeof window > "u" || (o = window.requestAnimationFrame(() => {
      o = 0, l();
    }));
  }, f = () => {
    o && typeof window < "u" && (window.cancelAnimationFrame(o), o = 0), n == null || n(), n = null, i = null;
  }, c = () => {
    if (typeof window > "u")
      return;
    const u = li(
      e.getHeadings(),
      e.scrollContainer
    );
    if (u === i && n || (f(), !u))
      return;
    i = u;
    const p = window;
    u.addEventListener("scroll", r, {
      passive: !0
    }), p.addEventListener("resize", r), n = () => {
      u.removeEventListener("scroll", r), p.removeEventListener("resize", r);
    };
  };
  return {
    getActiveReadingHeadingId() {
      return t;
    },
    subscribe(u) {
      return s.add(u), c(), () => {
        s.delete(u), s.size === 0 && f();
      };
    },
    refresh() {
      c(), l();
    },
    destroy() {
      s.clear(), f();
    }
  };
}, ea = (e) => {
  var n;
  const t = (n = e.node) == null ? void 0 : n.attrs, o = t == null ? void 0 : t[ar];
  return typeof o == "string" && o.length > 0 ? o : null;
}, ta = (e) => {
  const t = e.dom;
  if (!(t instanceof HTMLElement))
    return null;
  const o = t.getAttribute(rr) || t.dataset.blockId;
  return typeof o == "string" && o.length > 0 ? o : null;
}, Lt = (e) => ta(e) ?? ea(e) ?? e.id, na = (e, t) => e.id === t || Lt(e) === t, sn = (e) => typeof e == "string" && e.length > 0, ao = (e) => {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.id == "string" && typeof t.pos == "number" && typeof t.textContent == "string" && typeof t.level == "number" && typeof t.itemIndex == "number" && typeof t.dom == "object" && t.dom !== null;
}, oa = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.tableOfContents;
}, ci = (e) => {
  const t = oa(e), o = Array.isArray(t == null ? void 0 : t.content) ? t.content.filter(ao) : [];
  return o.length > 0 ? [...o] : Array.isArray(t == null ? void 0 : t.anchors) ? t.anchors.filter(ao) : [];
}, Vn = (e, t) => ({
  status: "resolved",
  target: {
    target: e,
    ...t
  }
}), ia = (e, t) => {
  if (!sn(e.blockId))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = un(t, e.blockId);
  if (!o)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  const n = en(
    t,
    e.blockId,
    e.offset ?? 0
  ) ?? o.pos;
  return Vn(e, {
    key: `block:${e.blockId}`,
    dom: o.dom,
    blockId: e.blockId,
    pos: n,
    selection: {
      from: n,
      to: n
    }
  });
}, sa = (e, t) => {
  if (!sn(e.blockId))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = ci(t).find(
    (a) => na(a, e.blockId)
  ), n = o ? Lt(o) : e.blockId, i = un(t, n);
  if (!i)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  const s = en(t, n, 0) ?? i.pos;
  return Vn(e, {
    key: `heading:${n}`,
    dom: (o == null ? void 0 : o.dom) ?? i.dom,
    blockId: n,
    pos: (o == null ? void 0 : o.pos) ?? s,
    selection: {
      from: s,
      to: s
    }
  });
}, ra = (e) => {
  const t = e.anchor.start, o = e.anchor.end;
  return !sn(t.blockId) || !sn(o.blockId) || !Number.isFinite(t.offset) || !Number.isFinite(o.offset) || t.offset < 0 || o.offset < 0;
}, aa = (e, t) => {
  if (ra(e))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = e.anchor.start, n = e.anchor.end, i = en(
    t,
    o.blockId,
    o.offset
  ), s = en(
    t,
    n.blockId,
    n.offset
  );
  if (i === null || s === null)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  if (s <= i)
    return {
      status: "failed",
      reason: "invalid-target"
    };
  const a = un(t, o.blockId);
  return Vn(e, {
    key: `range:${o.blockId}:${o.offset}-${n.blockId}:${n.offset}`,
    dom: (a == null ? void 0 : a.dom) ?? null,
    blockId: o.blockId,
    anchor: e.anchor,
    pos: i,
    selection: {
      from: i,
      to: s
    }
  });
}, la = (e) => e ? ci(e).map((t) => ({
  key: `heading:${Lt(t)}`,
  kind: "heading",
  label: t.textContent,
  blockId: Lt(t),
  outlineEligible: !0,
  shareable: !0
})) : [], ca = () => [
  {
    kind: "heading",
    resolve: (e, t) => sa(e, t.editor),
    list: (e) => la(e.editor)
  },
  {
    kind: "block",
    resolve: (e, t) => ia(e, t.editor)
  },
  {
    kind: "range",
    resolve: (e, t) => aa(e, t.editor)
  }
], ua = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((o) => {
    t.has(o.key) || t.set(o.key, o);
  }), [...t.values()];
}, da = (e = []) => {
  const t = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set(), n = (a) => (t.set(a.kind, a), () => {
    t.get(a.kind) === a && t.delete(a.kind);
  }), i = (a) => Array.isArray(a == null ? void 0 : a.kinds) && a.kinds.length > 0 ? [...new Set(a.kinds)] : [...t.keys()], s = (a) => {
    const l = {
      kinds: a
    };
    o.forEach((r) => r(l));
  };
  return e.forEach((a) => {
    n(a);
  }), {
    register: n,
    getProvider(a) {
      return t.get(a) ?? null;
    },
    async resolve(a, l) {
      const r = t.get(a.kind);
      return r ? r.resolve(a, l) : {
        status: "failed",
        reason: "target-unavailable"
      };
    },
    async list(a, l) {
      const r = [];
      for (const f of i(l)) {
        const c = t.get(f);
        if (!(c != null && c.list))
          continue;
        const u = await c.list(a);
        r.push(...u);
      }
      return ua(r);
    },
    invalidate(a) {
      const l = Array.isArray(a) && a.length > 0 ? [...new Set(a)] : [...t.keys()];
      l.forEach((r) => {
        var f, c;
        (c = (f = t.get(r)) == null ? void 0 : f.invalidate) == null || c.call(f);
      }), s(l);
    },
    subscribeInvalidation(a) {
      return o.add(a), () => {
        o.delete(a);
      };
    }
  };
}, fa = [
  "heading",
  "block",
  "range",
  "annotation",
  "bookmark",
  "search-hit",
  "ai-suggestion",
  "presence"
], pa = (e) => {
  const t = [
    ...e.invalidationKinds ?? fa
  ], o = () => e.editor.value ? Array.from(Ss(e.editor.value).values()).filter((R) => R.nodeType === "heading").map((R, X) => ({
    id: R.blockId,
    dom: R.dom,
    pos: R.pos,
    order: X
  })) : [], n = da([
    ...ca(),
    As()
  ]);
  let i = null, s = [];
  const a = Qr({
    getHeadings: o,
    scrollContainer: () => Es(e.rootRef.value) ? e.rootRef.value : null
  }), l = (R) => {
    if (!e.editor.value || !R.resolvedTarget.selection || R.request.focusMode !== "editor" || e.editor.value.isEditable === !1)
      return;
    const X = e.editor.value.state.doc.content.size, J = Math.min(
      Math.max(R.resolvedTarget.selection.from, 0),
      X
    ), ne = Math.min(
      Math.max(R.resolvedTarget.selection.to, 0),
      X
    ), ae = typeof R.resolvedTarget.pos == "number" ? e.editor.value.state.doc.nodeAt(
      R.resolvedTarget.pos
    ) : null, C = J === ne && ae && (ae.isAtom || ae.isLeaf) ? Cn.create(e.editor.value.state.doc, J) : J === ne ? ut.near(e.editor.value.state.doc.resolve(J)) : ut.create(e.editor.value.state.doc, J, ne);
    e.editor.value.view.dispatch(
      e.editor.value.state.tr.setSelection(C)
    );
  }, r = xs({
    resolver: async (R, X) => n.resolve(R.target, {
      ...X,
      editor: e.editor.value,
      annotations: e.documentState.value.annotations
    }),
    descriptorReader: async (R, X) => n.list(
      {
        ...R,
        editor: e.editor.value,
        annotations: e.documentState.value.annotations
      },
      X
    ),
    observer: a,
    executor: async (R) => (l(R), Ts(R))
  });
  let f = 0;
  const c = () => {
    var R;
    if (typeof window > "u") {
      r.retryDeferredNavigation(), (R = a.refresh) == null || R.call(a);
      return;
    }
    f || (f = window.requestAnimationFrame(() => {
      var X;
      f = 0, r.retryDeferredNavigation(), (X = a.refresh) == null || X.call(a);
    }));
  }, u = () => {
    n.invalidate(t), c();
  }, p = () => {
    i == null || i(), i = null, s.forEach((J) => J()), s = [];
    const R = e.getBookmarkProvider();
    R && (i = n.register(R));
    const X = e.getEphemeralProviders();
    Array.isArray(X) && (s = X.map(
      (J) => n.register(J)
    )), u();
  };
  Q(
    () => [e.getBookmarkProvider(), e.getEphemeralProviders()],
    () => {
      p();
    },
    {
      immediate: !0
    }
  );
  const m = (R) => r.navigate(R), y = () => {
    r.cancel();
  }, z = () => r.getSnapshot(), _ = () => Wo(r.getSnapshot()), x = (R) => r.listDescriptors(R), k = (R) => r.syncFromLocation(R), g = (R) => r.createShareableFragment(R), V = (R) => e.editor.value ? Is(e.editor.value, R) : null, H = (R, X = {}) => !e.editor.value || !un(e.editor.value, R) ? !1 : (r.navigate({
    source: "external-api",
    target: {
      kind: "block",
      blockId: R
    },
    align: X.align,
    behavior: X.scrollBehavior,
    focusMode: X.focus === !1 ? "preserve" : "editor",
    history: "none",
    reason: "legacy-block-navigation"
  }), !0);
  return {
    navigationController: r,
    scheduleNavigationRefresh: c,
    refreshNavigationRuntime: u,
    syncEditorNavigationBridge: () => {
      if (!e.editor.value)
        return;
      const R = e.editor.value;
      R.navigationController = r, R.navigate = m, R.cancelNavigation = y, R.getNavigationSnapshot = z, R.getNavigationDebugSnapshot = _, R.listNavigationDescriptors = x, R.syncNavigationFromLocation = k, R.createShareableFragment = g, R.navigateToBlock = H;
    },
    destroy: () => {
      f && typeof window < "u" && (window.cancelAnimationFrame(f), f = 0), i == null || i(), i = null, s.forEach((R) => R()), s = [], r.destroy();
    },
    navigateToBlock: H,
    navigate: m,
    cancelNavigation: y,
    getNavigationSnapshot: z,
    getNavigationDebugSnapshot: _,
    listNavigationDescriptors: x,
    syncNavigationFromLocation: k,
    createShareableFragment: g,
    getBlockElement: V
  };
}, ma = {
  "insert.link": Dt(
    () => import("./insert-link-PkojycPb.mjs")
  ),
  "insert.image": Dt(
    () => Promise.resolve().then(() => Vl)
  ),
  "insert.video": Dt(
    () => import("./insert-video-DTLd299x.mjs")
  ),
  "insert.iframe": Dt(
    () => import("./InsertIframe-BK7GiIag.mjs")
  ),
  "table.menu": Dt(
    () => import("./table-menu-D6u64--p.mjs")
  )
}, va = (e = {}) => _s({
  ...e,
  renderers: { ...ma, ...e.renderers }
}), ga = [
  "fixed-menu",
  "bubble-menu",
  "floating-menu"
], of = {
  id: "document-workbench-toolbar-platform",
  package: "@zxio/text-editor",
  role: "toolbar-engine",
  owns: [
    "editor-command-truth",
    "toolbar-state-snapshots",
    "editor-toolbar-contributions",
    "toolbar-surface-contracts"
  ],
  doesNotOwn: ["workbench-layout", "shell-actions", "host-product-semantics"],
  legacyCompat: {
    menuModel: "MenuButton/MenuButtonConfig",
    surfaces: ga,
    status: "removed",
    replacementSurfaces: ["workbench-top", "bubble", "floating"]
  }
}, ui = (e) => {
  const t = [], o = /* @__PURE__ */ new Map();
  for (const n of e) {
    const i = Math.max(0, n.width), s = o.get(n.groupId);
    if (s == null) {
      o.set(n.groupId, t.length), t.push({
        id: n.groupId,
        width: i,
        itemIds: [n.id],
        priority: n.priority
      });
      continue;
    }
    const a = t[s];
    a.width += i, a.itemIds.push(n.id), a.priority = Math.min(a.priority, n.priority);
  }
  return t;
}, ha = (e) => {
  const t = e.items.filter((c) => c.width >= 0);
  if (t.length === 0 || e.containerWidth <= 0)
    return {
      visibleIds: [],
      overflowIds: t.map((c) => c.id)
    };
  const o = ui(t);
  if (o.length === 0)
    return { visibleIds: [], overflowIds: [] };
  if (o.reduce((c, u) => c + u.width, 0) <= e.containerWidth)
    return {
      visibleIds: o.flatMap((c) => c.itemIds),
      overflowIds: []
    };
  const i = Math.max(0, e.moreButtonWidth), s = Math.max(0, e.containerWidth - i), a = [];
  let l = 0;
  for (const c of o) {
    if (l + c.width <= s) {
      a.push(c), l += c.width;
      continue;
    }
    break;
  }
  a.length === 0 && o[0].width <= s && a.push(o[0]);
  const r = new Set(a.flatMap((c) => c.itemIds)), f = t.map((c) => c.id).filter((c) => !r.has(c));
  return {
    visibleIds: [...r],
    overflowIds: f
  };
}, ba = (e) => {
  const t = e.items.filter((u) => u.width >= 0);
  if (t.length === 0 || e.containerWidth <= 0)
    return e.overflowIds.length === t.length;
  const o = ui(t);
  if (o.length === 0)
    return e.overflowIds.length === 0;
  const n = new Set(e.overflowIds);
  let i = o.length;
  for (let u = 0; u < o.length; u += 1) {
    const p = o[u];
    if (p.itemIds.some((y) => n.has(y))) {
      if (!p.itemIds.every((y) => n.has(y)))
        return !1;
      i = u;
      break;
    }
  }
  for (let u = i; u < o.length; u += 1)
    if (!o[u].itemIds.every((m) => n.has(m)))
      return !1;
  const a = o.slice(0, i).reduce((u, p) => u + p.width, 0), l = o.reduce((u, p) => u + p.width, 0);
  if (i === o.length)
    return l <= e.containerWidth;
  const r = Math.max(0, e.moreButtonWidth), f = Math.max(0, e.containerWidth - r);
  if (a > f)
    return !1;
  const c = o[i];
  return a + c.width > f;
}, di = Symbol(
  "basicRichTextFieldContext"
), ya = (e, t) => Ye(e, {
  ...t,
  characters: Number.MAX_SAFE_INTEGER,
  bytes: Number.MAX_SAFE_INTEGER,
  nodes: Number.MAX_SAFE_INTEGER
}), ka = Object.freeze([
  {
    skillId: "improve-writing",
    label: "Improve writing",
    commandId: "improve-writing",
    description: "Clarify and strengthen the selected text"
  },
  {
    skillId: "proofread",
    label: "Proofread",
    commandId: "proofread",
    description: "Fix grammar and spelling"
  },
  {
    skillId: "explain",
    label: "Explain",
    commandId: "explain",
    description: "Explain the selected text"
  },
  {
    skillId: "reformat",
    label: "Reformat",
    commandId: "reformat",
    description: "Reformat the selected text"
  }
]), wa = Object.freeze([
  {
    id: "continue-writing",
    label: "Continue writing",
    commandId: "continue-writing",
    parameters: Object.freeze({}),
    icon: "lucide:pen-line"
  },
  {
    id: "draft-outline",
    label: "Draft an outline",
    commandId: "draft-outline",
    parameters: Object.freeze({}),
    icon: "lucide:list-tree"
  },
  {
    id: "brainstorm-ideas",
    label: "Brainstorm ideas",
    commandId: "brainstorm-ideas",
    parameters: Object.freeze({}),
    icon: "lucide:lightbulb"
  }
]), _n = (e) => e === "brewing" ? { kind: "close-presentation" } : e === "reviewing" ? { kind: "dismiss-review-ui" } : e === "skills" || e === "user-input" || e === "selection-bubble" ? { kind: "close-idle" } : { kind: "noop" }, xa = [
  {
    id: er,
    label: "Ask AI",
    shortcutBindingId: "textEditor.askAI.open"
  }
], Ta = ["aria-label", "aria-haspopup", "aria-expanded"], Ia = /* @__PURE__ */ Ae({
  name: "ZxDragHandle",
  __name: "drag-handle",
  props: {
    editor: {},
    showPlus: { type: Boolean },
    onPlusClick: { type: Function },
    askAIBridge: {}
  },
  setup(e) {
    const t = e, o = Pe("drag-handle"), n = yt("editor", null), i = S(() => t.editor ?? (n == null ? void 0 : n.value) ?? null), s = W(-1), a = W(null), l = W(!1), r = W(null), f = W([]), c = W(null), u = W(!1), p = {
      duration: 100,
      offset: [0, 0],
      zIndex: 99
    }, m = xa, { text: y } = cn({
      runtime: () => {
        var L;
        return (L = Uo(i.value)) == null ? void 0 : L.runtime;
      },
      bindingId: "textEditor.askAI.open"
    }), z = S(() => t.askAIBridge ?? null), _ = (L) => {
      s.value = L.pos, a.value = L.node, L.node || w();
    }, x = () => {
      var U;
      const L = (U = a.value) == null ? void 0 : U.attrs, O = L == null ? void 0 : L.blockId;
      return typeof O == "string" && O.length > 0 ? O : null;
    }, k = () => {
      var oe;
      const L = i.value;
      if (!L) return;
      const O = s.value;
      if (O < 0 || !a.value) return;
      const U = O + a.value.nodeSize;
      L.chain().focus().insertContentAt(U, { type: "paragraph" }).focus(U + 1).run(), (oe = t.onPlusClick) == null || oe.call(t), w();
    }, g = () => {
      c.value = null, u.value = !1;
    }, V = () => {
      u.value = !0, c.value && (c.value.exceeded = !0), w();
    }, H = (L) => {
      var U;
      if (!z.value) return;
      c.value = {
        pointerId: L.pointerId,
        x: L.clientX,
        y: L.clientY,
        exceeded: !1
      }, u.value = !1;
      const O = L.currentTarget;
      if (O instanceof HTMLElement) {
        (U = O.setPointerCapture) == null || U.call(O, L.pointerId);
        const oe = (le) => {
          const fe = c.value;
          if (!fe || fe.pointerId !== le.pointerId) return;
          const we = le.clientX - fe.x, ge = le.clientY - fe.y;
          (Math.hypot(we, ge) > tr || u.value) && (fe.exceeded = !0, w());
        }, he = (le) => {
          var fe;
          (fe = O.releasePointerCapture) == null || fe.call(O, le.pointerId), O.removeEventListener("pointermove", oe), O.removeEventListener("pointerup", he), O.removeEventListener("pointercancel", he);
        };
        O.addEventListener("pointermove", oe), O.addEventListener("pointerup", he), O.addEventListener("pointercancel", he);
      }
    }, T = async () => {
      var L;
      z.value && (l.value = !0, await ft(), (L = f.value[0]) == null || L.focus());
    }, w = () => {
      l.value = !1;
    }, R = (L) => {
      if (!z.value) return;
      const O = c.value;
      if (!O || O.pointerId !== L.pointerId) return;
      const U = !O.exceeded && !u.value && L.button === 0;
      g(), U && T();
    }, X = (L) => {
      z.value && (L.preventDefault(), L.stopPropagation());
    }, J = (L) => {
      z.value && (L.key === "Enter" || L.key === " " ? (L.preventDefault(), T()) : L.key === "Escape" && w());
    }, ne = () => {
      const L = z.value;
      if (!L) return;
      const O = x();
      L.openInvocation({
        surface: "block-handle",
        ...O ? { blockIds: [O] } : {}
      }), w();
    }, ae = (L) => {
      var O;
      L.key === "Escape" ? (L.preventDefault(), w()) : L.key === "Enter" || L.key === " " ? (L.preventDefault(), ne()) : (L.key === "ArrowDown" || L.key === "ArrowUp") && (L.preventDefault(), (O = f.value[0]) == null || O.focus());
    }, C = (L) => {
      var U;
      if (!l.value) return;
      const O = L.target;
      O instanceof Node && ((U = r.value) != null && U.contains(O) || w());
    }, B = (L) => {
      L.key === "Escape" && l.value && w();
    };
    return Q(l, (L) => {
      typeof document > "u" || (L ? (document.addEventListener("pointerdown", C, !0), document.addEventListener("keydown", B, !0)) : (document.removeEventListener("pointerdown", C, !0), document.removeEventListener("keydown", B, !0)));
    }), rt(() => {
      typeof document > "u" || (document.removeEventListener("pointerdown", C, !0), document.removeEventListener("keydown", B, !0));
    }), (L, O) => i.value ? (N(), He(v(xr), {
      key: 0,
      editor: i.value,
      "tippy-options": p,
      "on-node-change": _
    }, {
      default: ht(() => [
        M("div", {
          class: K(v(o).b()),
          onDragstart: V
        }, [
          e.showPlus ? (N(), F("button", {
            key: 0,
            type: "button",
            class: K(v(o).e("btn")),
            "aria-label": "insert block",
            onMousedown: O[0] || (O[0] = Ke(() => {
            }, ["prevent", "stop"])),
            onClick: Ke(k, ["prevent", "stop"])
          }, [
            j(v(Ie), { icon: "lucide:plus" })
          ], 34)) : se("", !0),
          M("button", {
            type: "button",
            class: K([
              v(o).e("btn"),
              v(o).e("grip"),
              v(o).is("menu-enabled", !!z.value)
            ]),
            "aria-label": z.value ? "block actions" : "drag handle",
            "aria-haspopup": z.value ? "menu" : void 0,
            "aria-expanded": z.value ? l.value : void 0,
            onPointerdown: H,
            onPointerup: R,
            onPointercancel: g,
            onClick: X,
            onKeydown: J
          }, [
            j(v(Ie), { icon: "lucide:grip-vertical" })
          ], 42, Ta),
          l.value && z.value ? (N(), F("div", {
            key: 1,
            ref_key: "menuRef",
            ref: r,
            class: K(v(o).e("menu")),
            role: "menu",
            "aria-label": "Block actions"
          }, [
            (N(!0), F(Le, null, Fe(v(m), (U) => (N(), F("button", {
              key: U.id,
              ref_for: !0,
              ref_key: "menuItemRefs",
              ref: f,
              type: "button",
              class: K(v(o).e("menu-item")),
              role: "menuitem",
              onClick: Ke(ne, ["stop"]),
              onKeydown: ae
            }, [
              M("span", null, me(U.label), 1),
              M("kbd", {
                class: K(v(o).e("shortcut"))
              }, me(v(y)), 3)
            ], 34))), 128))
          ], 2)) : se("", !0)
        ], 34)
      ]),
      _: 1
    }, 8, ["editor"])) : se("", !0);
  }
}), Aa = 8, lo = (e) => !!(e && typeof e == "object" && typeof e.on == "function" && typeof e.off == "function"), Ea = (e, t) => {
  if (e.size !== t.size)
    return !1;
  for (const o of e)
    if (!t.has(o))
      return !1;
  return !0;
}, Sa = (e) => {
  const t = [];
  let o = [];
  const n = () => {
    o.length !== 0 && (t.push(o), o = []);
  };
  for (const i of e) {
    if (i.definition.kind === "separator") {
      n();
      continue;
    }
    if (i.definition.kind === "spacer") {
      n(), t.push([i]);
      continue;
    }
    o.push(i);
  }
  return n(), t;
}, Ze = (e) => {
  e.preventDefault();
}, co = (e) => e.kind === "dropdown", wn = (e) => e.kind === "select", uo = (e) => e.kind === "color", fo = (e) => e.kind === "split-button", On = (e, t) => e == null || t == null ? e == null && t == null : e === t || String(e) === String(t), _a = (e, t) => e.find((o) => On(o.value, t)) ?? null, Oa = (e) => !!(e && (typeof e == "object" || typeof e == "function" && ("setup" in e || "render" in e || "__asyncLoader" in e))), Ra = (e) => typeof e == "function" && !Oa(e), fi = /* @__PURE__ */ Ae({
  name: "TextEditorToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    surface: {
      type: String,
      default: "workbench-top"
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    }
  },
  setup(e) {
    const t = Pe("text-editor-toolbar"), {
      text: o
    } = Qi(), n = $t(), i = yt("editor", null), s = S(() => e.editor ?? (i == null ? void 0 : i.value) ?? null), {
      binding: a
    } = bt(e.themeOwner), l = Be(null), r = Be(null), f = Be(ro()), c = W(""), u = W(null), p = W(null), m = W(null), y = W(null), z = W(/* @__PURE__ */ new Set()), _ = W(!1);
    let x = null, k = null, g = !1, V = !1, H = !1, T = !1;
    const w = S(() => e.surface === "workbench-top"), R = (d) => {
      l.value = Os({
        contributions: [...e.includeDefaultContribution ? [va()] : [], ...Rs(d), ...e.contributions]
      });
    }, X = (d) => [...d.capabilities].sort().join("|"), J = (d) => {
      var I;
      const h = ((I = l.value) == null ? void 0 : I.resolveState(d)) ?? ro();
      return f.value = h, h;
    }, ne = (d, h = J(d)) => {
      var I;
      r.value = ((I = l.value) == null ? void 0 : I.prepareSurface(e.surface, {
        editor: d,
        state: h
      })) ?? {
        surface: e.surface,
        items: []
      }, c.value = X(h);
    }, ae = () => {
      const d = s.value, h = J(d);
      (!r.value || r.value.surface !== e.surface || c.value !== X(h)) && ne(d, h);
    }, C = () => {
      H || (H = !0, Promise.resolve().then(() => {
        H = !1, !T && ae();
      }));
    }, B = (d) => {
      lo(d) && (d.off("selectionUpdate", C), d.off("transaction", C));
    }, L = (d) => {
      lo(d) && (d.on("selectionUpdate", C), d.on("transaction", C));
    };
    Q(s, (d, h) => {
      B(h), L(d), R(d), ne(d);
    }, {
      immediate: !0
    }), Q(() => [e.includeDefaultContribution, e.contributions], () => {
      R(s.value), ne(s.value);
    }, {
      deep: !0
    }), Q(() => e.surface, () => {
      ne(s.value);
    }), rt(() => {
      T = !0, k == null || k.disconnect(), k = null, B(s.value);
    });
    const O = S(() => {
      var d;
      return (r.value && ((d = l.value) == null ? void 0 : d.resolvePreparedSurface(r.value, {
        editor: s.value,
        state: f.value
      }))) ?? {
        surface: e.surface,
        state: f.value,
        items: []
      };
    }), U = S(() => Sa(O.value.items)), oe = (d, h) => {
      var I;
      return ((I = d[0]) == null ? void 0 : I.definition.id) ?? `group-${h}`;
    }, he = (d, h) => {
      const I = d.querySelector(`[data-overflow-group="${h}"]`);
      return Math.max(0, (I == null ? void 0 : I.getBoundingClientRect().width) ?? 0);
    }, le = (d) => {
      const h = y.value;
      return h ? h.getBoundingClientRect().width + (Number.parseFloat(window.getComputedStyle(h).marginLeft) || 0) + (Number.parseFloat(d.columnGap) || 0) : 0;
    }, fe = S(() => O.value.items.map((d) => {
      const h = d.resolved.value == null ? "" : String(d.resolved.value), I = d.definition.label ?? "";
      return `${d.definition.id}:${d.definition.kind}:${h}:${I}`;
    }).join("|")), we = (d = {}) => {
      if (!w.value || g || T) {
        d.force && (V = !0);
        return;
      }
      d.force && (V = !0), g = !0, ft(() => {
        requestAnimationFrame(() => {
          if (g = !1, T || !w.value) {
            V = !1;
            return;
          }
          const h = p.value, I = m.value, P = U.value, de = V;
          if (V = !1, !h || !I || P.length === 0) {
            z.value.size > 0 && (z.value = /* @__PURE__ */ new Set()), x = null;
            return;
          }
          const ze = window.getComputedStyle(h), nt = (Number.parseFloat(ze.paddingLeft) || 0) + (Number.parseFloat(ze.paddingRight) || 0), Tt = Math.max(0, h.getBoundingClientRect().width - nt);
          if (!de && x != null && Math.abs(Tt - x) < 1)
            return;
          const fn = P.flatMap((qt, Bt) => {
            const Ct = oe(qt, Bt), mn = he(I, Ct);
            return qt.map((At, Gt) => ({
              id: At.definition.id,
              width: Gt === 0 ? mn : 0,
              groupId: Ct,
              priority: At.definition.priority ?? Bt * 100
            }));
          }), Kt = {
            containerWidth: Math.max(0, Tt - Aa),
            moreButtonWidth: le(ze),
            items: fn
          }, pn = [...z.value];
          if (ba({
            ...Kt,
            overflowIds: pn
          }) && !de) {
            x = Tt;
            return;
          }
          const at = ha(Kt), It = new Set(at.overflowIds);
          Ea(It, z.value) || (z.value = It), x = Tt, It.size === 0 && (_.value = !1);
        });
      });
    };
    Ht(() => {
      !w.value || typeof ResizeObserver > "u" || (k = new ResizeObserver((d) => {
        we({
          force: d.some((h) => h.target !== p.value)
        });
      }), p.value && k.observe(p.value), y.value && k.observe(y.value), we());
    }), Q(() => [w.value, fe.value], ([d]) => {
      if (!d) {
        z.value = /* @__PURE__ */ new Set(), _.value = !1, x = null;
        return;
      }
      k && p.value && k.observe(p.value), we({
        force: !0
      });
    }), Q(p, (d, h) => {
      k && (h && k.unobserve(h), d && w.value && (k.observe(d), we()));
    }), Q(y, (d, h) => {
      k && (h && k.unobserve(h), d && k.observe(d));
    });
    const ge = () => ({
      editor: s.value,
      snapshot: f.value
    }), ce = (d, h) => {
      u.value = h ? d : u.value === d ? null : u.value;
    }, ve = () => {
      u.value = null;
    }, Ee = (d) => o(d.definition.id, d.definition.label ?? d.definition.id), ue = (d) => o(`option:${d.id}`, d.label), te = (d) => {
      if (!wn(d.definition))
        return Ee(d);
      const h = _a(d.definition.options, d.resolved.value);
      return h ? ue(h) : d.resolved.value != null ? String(d.resolved.value) : Ee(d);
    }, ye = (d) => d ? typeof d == "string" ? j(Ie, {
      icon: d,
      class: t.e("button-icon")
    }, null) : Ft(d, {
      class: t.e("button-icon")
    }) : null, re = (d, h) => typeof h == "boolean" ? h : !!d.definition.icon && (d.definition.kind === "action" || d.definition.kind === "toggle" || d.definition.kind === "color" || d.definition.kind === "custom"), Me = (d, h = {}) => {
      const I = re(d, h.iconOnly), P = h.label ?? Ee(d);
      return j(Le, null, [!h.hideIcon && d.definition.icon ? j("span", {
        class: t.e("button-icon-shell"),
        "aria-hidden": "true"
      }, [ye(d.definition.icon)]) : null, I ? null : j("span", {
        class: t.e("button-label")
      }, [P]), h.showCaret ? j("span", {
        class: t.e("button-caret"),
        "aria-hidden": "true"
      }, [j(Ie, {
        icon: "lucide:chevron-down"
      }, null)]) : null, d.resolved.indicatorColor ? j("span", {
        class: t.e("button-indicator"),
        style: {
          backgroundColor: d.resolved.indicatorColor
        },
        "aria-hidden": "true"
      }, null) : null]);
    }, Ve = (d, h = {}) => j(Le, null, [j("span", {
      class: t.e("button-icon-shell"),
      "aria-hidden": "true"
    }, [ye(d.definition.icon), d.resolved.indicatorColor ? j("span", {
      class: t.e("button-indicator"),
      style: {
        backgroundColor: d.resolved.indicatorColor
      }
    }, null) : null]), j("span", {
      class: t.e("menu-item-label")
    }, [h.label ?? Ee(d)]), h.value ? j("span", {
      class: t.e("menu-item-value")
    }, [h.value]) : null, h.showCaret ? j("span", {
      class: t.e("button-caret"),
      "aria-hidden": "true"
    }, [j(Ie, {
      icon: "lucide:chevron-right"
    }, null)]) : null]), Je = async (d) => {
      await Ns(d.definition, {
        ...ge(),
        surface: e.surface,
        capabilities: O.value.state.capabilities
      });
    }, Z = async (d, h) => {
      var I, P;
      co(d.definition) && (await ((P = (I = d.definition).onOptionSelect) == null ? void 0 : P.call(I, h, ge())), ve());
    }, ke = async (d, h) => {
      if (wn(d.definition)) {
        await d.definition.onValueChange(h, ge()), ve();
        return;
      }
      uo(d.definition) && (await d.definition.onValueChange(typeof h == "string" ? h : null, ge()), ve());
    }, Re = async (d) => {
      if (!fo(d.definition)) {
        await Je(d);
        return;
      }
      await d.definition.runPrimary(ge());
    }, Ge = (d, h = {}) => {
      const I = h.active ?? d.resolved.active, P = h.disabled ?? d.resolved.disabled, de = h.presentation === "menu", ze = !de && re(d, h.iconOnly), nt = !!h.showCaret;
      return j("button", {
        key: d.definition.id,
        type: "button",
        class: [t.e(de ? "menu-item" : "button"), h.class, I && "is-active", P && "is-disabled", u.value === d.definition.id && "is-open"],
        disabled: P,
        title: [Ee(d), h.shortcut].filter(Boolean).join(" · "),
        "aria-keyshortcuts": h.shortcutAriaLabel || void 0,
        "aria-label": Ee(d),
        "aria-haspopup": nt ? "menu" : void 0,
        "aria-expanded": nt ? u.value === d.definition.id : void 0,
        "aria-pressed": d.definition.kind === "toggle" ? I ? "true" : "false" : void 0,
        "data-item-id": d.definition.id,
        "data-kind": d.definition.kind,
        "data-icon-only": de ? void 0 : ze ? "true" : "false",
        "data-has-caret": de ? void 0 : nt ? "true" : "false",
        onMousedown: Ze,
        onClick: h.onClick
      }, [de ? Ve(d, {
        label: h.label,
        value: h.value,
        showCaret: h.showCaret
      }) : Me(d, {
        label: h.label,
        iconOnly: ze,
        showCaret: h.showCaret,
        hideIcon: h.hideIcon
      })]);
    }, Qe = (d) => d === "menu" ? "right-start" : "bottom-start", et = (d, h, I = {}) => {
      var P;
      return Ft(Qt, {
        key: d.definition.id,
        visible: u.value === d.definition.id,
        variant: "popover",
        trigger: "click",
        placement: Qe(I.presentation ?? "toolbar"),
        offset: 6,
        // ElPopover defaults to 150px; color grid needs ~256px+.
        width: "auto",
        popperClass: t.e("popover"),
        persistent: !1,
        disabled: !a.value,
        appendTo: (P = a.value) == null ? void 0 : P.target,
        "onUpdate:visible": (de) => {
          ce(d.definition.id, de);
        }
      }, {
        default: () => Ge(d, {
          label: I.label,
          value: I.value,
          iconOnly: I.iconOnly,
          hideIcon: I.hideIcon,
          presentation: I.presentation,
          showCaret: !0
        }),
        content: () => j("div", {
          class: t.e("menu"),
          onMousedown: Ze
        }, [h])
      });
    }, be = (d, h, I = {}) => j("button", {
      type: "button",
      class: [t.e("menu-item"), (I.active ?? !1) && "is-active", h.disabled && "is-disabled"],
      disabled: h.disabled,
      "data-option-id": h.id,
      onMousedown: Ze,
      onClick: I.onClick
    }, [j("span", {
      class: t.e("menu-item-label")
    }, [ue(h)])]), A = (d, h) => {
      if (d.definition.kind !== "custom")
        return null;
      if (Ra(d.definition.render)) {
        const I = d.definition.render;
        return j("div", {
          key: d.definition.id,
          class: t.e("custom"),
          "data-item-id": d.definition.id
        }, [I({
          editor: s.value,
          snapshot: O.value.state,
          item: d.definition
        })]);
      }
      return j("div", {
        key: d.definition.id,
        class: t.e("custom"),
        "data-item-id": d.definition.id
      }, [Ft(d.definition.render, {
        key: d.definition.id,
        editor: s.value
      }, {
        default: (I) => Ge(d, {
          presentation: h,
          disabled: I == null ? void 0 : I.disabled,
          shortcut: I == null ? void 0 : I.shortcut,
          shortcutAriaLabel: I == null ? void 0 : I.shortcutAriaLabel,
          active: typeof (I == null ? void 0 : I.isActive) == "boolean" ? I.isActive : d.resolved.active,
          onClick: () => {
            if (typeof (I == null ? void 0 : I.onClick) == "function") {
              I.onClick();
              return;
            }
            Je(d);
          }
        })
      })]);
    }, E = (d, h = "toolbar") => {
      var I;
      if (d.definition.kind === "separator")
        return null;
      if (d.definition.kind === "spacer")
        return j("span", {
          key: d.definition.id,
          class: t.e("spacer"),
          "data-item-id": d.definition.id,
          "aria-hidden": "true"
        }, null);
      if (d.definition.kind === "custom")
        return A(d, h);
      if (co(d.definition))
        return et(d, j("div", {
          class: t.e("menu-list")
        }, [d.definition.options.map((P) => be(d, P, {
          active: P.id === d.resolved.value,
          onClick: () => {
            Z(d, P.id);
          }
        }))]), {
          presentation: h
        });
      if (wn(d.definition)) {
        const P = d.definition.includeResetOption !== !1;
        return et(
          d,
          j("div", {
            class: t.e("menu-list")
          }, [P ? j("button", {
            type: "button",
            class: [t.e("menu-item"), d.resolved.value == null && "is-active"],
            onMousedown: Ze,
            onClick: () => {
              ke(d, null);
            }
          }, [j("span", {
            class: t.e("menu-item-label")
          }, [o("panel:default", "Default")])]) : null, d.definition.options.map((de) => be(d, de, {
            active: On(de.value, d.resolved.value),
            onClick: () => {
              ke(d, de.value ?? null);
            }
          }))]),
          // The track shows the current value in place of the name; a menu
          // row keeps the name and trails the value.
          h === "menu" ? {
            presentation: h,
            value: d.resolved.value != null ? te(d) : null
          } : {
            label: te(d)
          }
        );
      }
      if (uo(d.definition))
        return et(d, j("div", {
          class: t.e("color-panel")
        }, [j("button", {
          type: "button",
          class: [t.e("color-clear"), d.resolved.value == null && "is-active"],
          onMousedown: Ze,
          onClick: () => {
            ke(d, null);
          }
        }, [j("span", {
          class: t.e("menu-item-label")
        }, [o("panel:clear-color", "Clear color")])]), j("div", {
          class: t.e("color-grid")
        }, [d.definition.options.map((P) => j("button", {
          type: "button",
          class: [t.e("color-swatch"), On(P.value, d.resolved.value) && "is-active"],
          title: ue(P),
          "aria-label": ue(P),
          style: {
            backgroundColor: P.swatch
          },
          onMousedown: Ze,
          onClick: () => {
            ke(d, P.value ?? null);
          }
        }, null))]), d.definition.allowCustomValue ? j("label", {
          class: t.e("color-picker")
        }, [j("span", {
          class: t.e("color-picker-label")
        }, [o("panel:custom", "Custom")]), j("input", {
          type: "color",
          value: typeof d.resolved.value == "string" ? d.resolved.value : "#000000",
          onMousedown: Ze,
          onInput: (P) => {
            ke(d, P.target.value);
          }
        }, null)]) : null]), {
          presentation: h
        });
      if (fo(d.definition)) {
        const P = d.definition;
        return j("div", {
          key: P.id,
          class: [t.e("split-button"), d.resolved.active && "is-active", d.resolved.disabled && "is-disabled"]
        }, [Ge(d, {
          presentation: h,
          label: P.primaryAction.label ?? Ee(d),
          onClick: () => {
            Re(d);
          }
        }), Ft(Qt, {
          visible: u.value === P.id,
          variant: "popover",
          trigger: "click",
          placement: Qe(h),
          offset: 6,
          width: "auto",
          popperClass: t.e("popover"),
          persistent: !1,
          disabled: !a.value,
          appendTo: (I = a.value) == null ? void 0 : I.target,
          "onUpdate:visible": (de) => {
            ce(P.id, de);
          }
        }, {
          default: () => j("button", {
            type: "button",
            class: [t.e("split-caret"), d.resolved.disabled && "is-disabled"],
            "aria-label": `${Ee(d)} options`,
            disabled: d.resolved.disabled,
            onMousedown: Ze
          }, [j("span", {
            class: t.e("button-caret"),
            "aria-hidden": "true"
          }, [j(Ie, {
            icon: h === "menu" ? "lucide:chevron-right" : "lucide:chevron-down"
          }, null)])]),
          content: () => j("div", {
            class: t.e("menu"),
            onMousedown: Ze
          }, [j("div", {
            class: t.e("menu-list")
          }, [P.options.map((de) => be(d, de, {
            onClick: () => {
              var ze;
              (ze = P.onOptionSelect) == null || ze.call(P, de.id, ge()), ve();
            }
          }))])])
        })]);
      }
      return Ge(d, {
        presentation: h,
        onClick: () => {
          Je(d), h === "menu" && (_.value = !1);
        }
      });
    }, q = (d) => w.value && d.some((h) => z.value.has(h.definition.id)), Y = S(() => U.value.filter((d) => d.some((h) => z.value.has(h.definition.id)))), pe = (d, h, I = {
      includeLeadingSeparator: !0
    }) => {
      const P = oe(d, h), de = I.includeLeadingSeparator !== !1;
      return j("div", {
        key: P,
        class: [t.e("group"), q(d) && "is-overflowed"],
        "data-group-index": h,
        "data-overflow-group": P
      }, [de && h > 0 ? j("span", {
        class: t.e("separator"),
        "aria-hidden": "true"
      }, null) : null, d.map((ze) => E(ze))]);
    }, Se = (d) => {
      const h = d.definition;
      return h.kind === "separator" || h.kind === "spacer" ? null : j("div", {
        key: `overflow-${h.id}`,
        class: t.e("overflow-entry"),
        "data-overflow-item-id": h.id
      }, [E(d, "menu")]);
    }, Ce = () => {
      var h;
      if (!w.value)
        return null;
      const d = Y.value.length === 0;
      return Ft(Qt, {
        visible: _.value,
        variant: "popover",
        trigger: "click",
        placement: "bottom-end",
        offset: 6,
        width: "auto",
        popperClass: t.e("popover"),
        persistent: !1,
        disabled: d || !a.value,
        appendTo: (h = a.value) == null ? void 0 : h.target,
        "onUpdate:visible": (I) => {
          _.value = I;
        }
      }, {
        default: () => j("button", {
          ref: y,
          type: "button",
          class: [t.e("button"), t.e("more-button"), d && "is-idle", _.value && "is-open"],
          "aria-hidden": d ? "true" : void 0,
          tabindex: d ? -1 : void 0,
          title: "More",
          "aria-label": o("panel:more", "More toolbar actions"),
          "aria-haspopup": "menu",
          "aria-expanded": _.value ? "true" : "false",
          "data-icon-only": "true",
          "data-has-caret": "false",
          onMousedown: Ze
        }, [j("span", {
          class: t.e("button-icon-shell"),
          "aria-hidden": "true"
        }, [j(Ie, {
          icon: "lucide:ellipsis",
          class: t.e("button-icon")
        }, null)])]),
        content: () => j("div", {
          class: [t.e("menu"), t.e("overflow-panel")],
          role: "menu",
          onMousedown: Ze
        }, [Y.value.map((I, P) => j("div", {
          key: `overflow-group-${oe(I, P)}`,
          class: t.e("overflow-section")
        }, [P > 0 ? j("div", {
          class: t.e("overflow-section-divider"),
          "aria-hidden": "true"
        }, null) : null, I.map((de) => Se(de))]))])
      });
    };
    return () => {
      const d = s.value, h = O.value.items;
      if (!d || h.length === 0)
        return null;
      const I = U.value;
      if (I.length === 0)
        return null;
      const P = Object.fromEntries(Object.entries(n).filter(([de]) => de !== "class" && de !== "style"));
      return w.value ? j("div", st({
        ref: p,
        class: [t.b(), n.class],
        style: n.style,
        "data-surface": e.surface,
        "data-overflow": "true"
      }, P), [j("div", {
        ref: m,
        class: t.e("track")
      }, [I.map((de, ze) => pe(de, ze))]), Ce()]) : j("div", st({
        class: [t.b(), n.class],
        style: n.style,
        "data-surface": e.surface
      }, P), [I.map((de, ze) => pe(de, ze))]);
    };
  }
}), po = ["image", "iframe", "video", "imageGroup", "codeBlock", "horizontalRule"], Na = (e) => {
  var o;
  if (!e || typeof e != "object") return !1;
  const t = (o = e.toJSON) == null ? void 0 : o.call(e);
  return (t == null ? void 0 : t.type) === "nodeRange";
}, La = Object.freeze({
  strategy: "fixed",
  placement: "top-start",
  offset: 8,
  flip: Object.freeze({
    fallbackPlacements: ["bottom-start"]
  }),
  shift: Object.freeze({
    padding: 8,
    crossAxis: !0
  })
}), Ba = ({
  state: e
}) => {
  var n, i;
  const {
    selection: t
  } = e;
  if (t.empty || Na(t))
    return !1;
  if (t instanceof Cn) {
    const s = t.node;
    if (s && po.includes(s.type.name))
      return !1;
  }
  const o = (i = (n = t.$from) == null ? void 0 : n.node) == null ? void 0 : i.call(n, t.$from.depth);
  return !(o && po.includes(o.type.name));
}, Ca = /* @__PURE__ */ Ae({
  name: "TextEditorBubbleToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    },
    options: {
      type: Object,
      default: () => ({})
    },
    shouldShow: {
      type: Function,
      default: null
    }
  },
  setup(e) {
    const t = Pe("text-editor-bubble-menu"), o = $t(), n = yt("editor", null), i = S(() => e.editor ?? (n == null ? void 0 : n.value) ?? null), {
      binding: s
    } = bt(e.themeOwner), a = W(!1), l = zn(a), r = () => {
      a.value = !0, typeof e.options.onShow == "function" && e.options.onShow();
    }, f = () => {
      a.value = !1, typeof e.options.onHide == "function" && e.options.onHide();
    };
    return () => {
      const c = i.value, u = s.value;
      if (!c || !u)
        return null;
      const p = Object.fromEntries(Object.entries(o).filter(([m]) => m !== "class" && m !== "style"));
      return (
        // TipTap removes/reparents its menu element. Keep a Vue-owned root so
        // toggling the toolbar (for example on readonly) has a stable anchor.
        j("div", {
          style: {
            display: "contents"
          }
        }, [j(Yo, st({
          editor: c,
          shouldShow: e.shouldShow ?? Ba,
          options: {
            ...La,
            ...e.options,
            onShow: r,
            onHide: f
          },
          appendTo: () => u.target,
          class: [t.b(), o.class],
          style: {
            zIndex: l.value
          }
        }, p), {
          default: () => [j(fi, {
            themeOwner: e.themeOwner,
            editor: c,
            surface: "bubble",
            contributions: e.contributions,
            includeDefaultContribution: e.includeDefaultContribution,
            style: o.style
          }, null)]
        })])
      );
    };
  }
}), za = (e) => typeof e == "object" && e !== null && !Array.isArray(e), mo = (e) => typeof e == "string" || za(e), Ma = br({
  contentProfile: { type: String, values: ["full", "basic-rich-text"], default: "full" },
  contentLimits: { type: _e(Object), default: void 0 },
  /**
   * @description Frozen Runtime-derived owner for every editor overlay and feedback surface.
   */
  themeOwner: {
    type: _e(Object),
    default: void 0
  },
  /**
   * @description Editor content (deprecated HTML import bridge alias)
   */
  content: {
    type: String,
    default: null
  },
  /**
   * @description v-model binding value for explicit HTML import, Markdown, or JSON modes
   */
  modelValue: {
    type: _e([String, Object]),
    default: ""
  },
  /**
   * @description Explicit input content type. Prefer `document` or `markdown`; `html` is import-only bridge mode.
   */
  contentType: {
    type: String,
    values: ["html", "markdown", "json", "document"],
    default: "html"
  },
  /**
   * @description Explicit output content type
   */
  outputType: {
    type: String,
    values: ["html", "markdown", "json", "document"],
    default: "html"
  },
  /**
   * @description Markdown export mode
   */
  markdownExportMode: {
    type: String,
    values: ["semantic"],
    default: "semantic"
  },
  /**
   * @description Canonical document envelope value (preferred persistence contract)
   */
  documentValue: {
    type: _e(Object),
    default: null
  },
  /**
   * @description Placeholder text or function (supports Tiptap's node-based placeholder)
   * @example
   * // Static placeholder
   * placeholder="Write something..."
   * // Dynamic placeholder based on node type
   * :placeholder="({ node }) => node.type.name === 'heading' ? 'Enter title...' : 'Write something...'"
   */
  placeholder: {
    type: _e([String, Function]),
    default: void 0
  },
  /**
   * @description Placeholder contract for structured block-level defaults (Notion-style headings, lists, etc.)
   */
  placeholderContract: {
    type: _e(Object),
    default: null
  },
  /**
   * @description Custom class for editor content area
   */
  editorClass: {
    type: _e([
      String,
      Array,
      Object
    ]),
    default: ""
  },
  /**
   * @description Effective typography contract override for root and block defaults
   */
  typography: {
    type: _e(Object),
    default: null
  },
  /**
   * @description Whether the editor is editable
   */
  editable: {
    type: Boolean,
    default: !0
  },
  /**
   * @description Whether to autofocus on mount
   */
  autofocus: {
    type: Boolean,
    default: !1
  },
  /**
   * @description Selection bubble toolbar. Mounted by default; pass `false`
   * when the host composes its own bubble surface.
   */
  bubbleToolbar: {
    type: _e([Boolean, Object]),
    default: !0
  },
  /**
   * @description Drag handle configuration
   */
  dragHandle: {
    type: _e([Boolean, Object]),
    default: !1
  },
  /**
   * @description Additional TipTap extensions
   */
  extensions: {
    type: _e(Array),
    default: () => []
  },
  /**
   * @description Stable block identity configuration
   */
  stableBlockIdentity: {
    type: _e(Object),
    default: () => ({})
  },
  /**
   * @description Collaboration mode model emit strategy
   */
  collaborationEmit: {
    type: _e(String),
    values: ["none", "html", "markdown", "json", "document", "delta"],
    default: "none"
  },
  /**
   * @description StarterKit configuration options
   */
  starterkitOptions: {
    type: _e(Object),
    default: () => ({})
  },
  /**
   * @description Optional editor-only Pages layout engine config. Disabled unless an object is provided.
   */
  pagesLayout: {
    type: _e([
      Boolean,
      Object
    ]),
    default: !1
  },
  /**
   * @description Optional Pages header/footer contract and command layer. Disabled unless an object is provided.
   */
  pagesHeaderFooter: {
    type: _e([
      Boolean,
      Object
    ]),
    default: !1
  },
  /**
   * @description Mention configuration
   */
  mentions: {
    type: _e([Array, Object]),
    default: null
  },
  /**
   * @description Tag suggestions
   */
  tags: {
    type: _e(Array),
    default: () => []
  },
  /**
   * @description Suggestion runtime configuration for mention, tag, emoji, and slash triggers
   */
  suggestions: {
    type: _e(Object),
    default: () => ({})
  },
  /**
   * @description Formal Slash Catalog Contribution/merge entries (e.g. platform Ask AI).
   */
  slashCatalogContributions: {
    type: _e(Array),
    default: () => []
  },
  /**
   * @description Formal host contract for the file intake and asset platform.
   * Use this as the long-term integration boundary for classify/import/upload/
   * resolve/policy/openNew/task hooks.
   */
  filePlatform: {
    type: _e(Object),
    default: null
  },
  /**
   * @description Host-provided bookmark navigation source for shareable bookmark navigation and deep-link recovery. Use `createBookmarkNavigationProvider({ getBookmarks })`.
   */
  bookmarkProvider: {
    type: _e(Object),
    default: void 0
  },
  /**
   * @description Host-provided ephemeral navigation sources such as search hits, AI suggestions, or collaborator follow. These targets participate in controller navigation but never enter the shareable URL contract.
   */
  ephemeralProviders: {
    type: _e(Array),
    default: void 0
  },
  /**
   * @description Host-owned code block preferences. These never enter document JSON; they only influence new code block defaults and local authoring UI ordering.
   */
  codeBlockPreferences: {
    type: _e(Object),
    default: null
  }
}), Da = {
  "content-issue": (e) => !0,
  /**
   * @description Emitted when content changes
   */
  change: (e) => mo(e),
  /**
   * @description v-model update event
   */
  "update:modelValue": (e) => mo(e),
  /**
   * @description Document envelope update event
   */
  "update:documentValue": (e) => nn(e),
  /**
   * @description Emitted when the document envelope changes
   */
  "document-change": (e) => nn(e),
  /**
   * @description Emitted when editor gains focus
   */
  focus: (e) => e instanceof FocusEvent,
  /**
   * @description Emitted when editor loses focus
   */
  blur: (e) => e instanceof FocusEvent,
  /**
   * @description Emitted on every editor transaction
   */
  transaction: (e) => !0,
  /**
   * @description Emitted when collaboration delta strategy is enabled
   */
  delta: (e) => Array.isArray(e == null ? void 0 : e.steps) && typeof (e == null ? void 0 : e.version) == "number"
}, Fa = (e, t, o) => {
  switch (t) {
    case "none":
    case "delta":
      return;
    case "html":
    case "markdown":
    case "json":
    case "document":
      return Go(e, {
        outputType: t,
        document: o
      });
  }
}, Pa = Object.freeze([
  ".md",
  ".markdown",
  ".html",
  ".htm",
  ".json",
  ".txt"
]), St = (e, t, o) => ({
  intent: "reject",
  code: e,
  reason: t,
  message: o
}), Va = (e) => {
  const t = e.lastIndexOf(".");
  return t < 0 ? "" : e.slice(t).toLowerCase();
}, ja = (e) => e.trim().toLowerCase() === "readme", $a = (e) => {
  var t, o;
  return (o = (t = e.constraints) == null ? void 0 : t.importExtensions) != null && o.length ? e.constraints.importExtensions.map(
    (n) => n.toLowerCase()
  ) : [...Pa];
}, Ha = (e, t) => {
  const o = Va(e.name);
  if (!t.includes(o))
    return ja(e.name) || e.type === "text/markdown" ? "markdown" : e.type === "text/html" ? "html" : e.type === "application/json" || e.type === "text/json" ? "json" : e.type === "text/plain" ? "text" : null;
  switch (o) {
    case ".md":
    case ".markdown":
      return "markdown";
    case ".html":
    case ".htm":
      return "html";
    case ".json":
      return "json";
    case ".txt":
      return "text";
    default:
      return null;
  }
}, Ua = (e) => e.type.startsWith("image/") ? "image" : e.type.startsWith("video/") ? "video" : "file", Ka = (e) => {
  var i;
  const t = (i = e.context) == null ? void 0 : i.remoteUrl;
  if (typeof t == "string" && /^https?:\/\//i.test(t))
    return t;
  const o = e.htmlContent;
  if (!o)
    return null;
  const n = o.match(/\b(?:src|href)=["'](https?:\/\/[^"']+)["']/i);
  return (n == null ? void 0 : n[1]) ?? null;
}, qa = (e, t, o) => ({
  event: e,
  decision: t,
  handled: o
}), Ga = async ({
  event: e,
  filePlatform: t
}) => {
  var c, u, p, m, y, z;
  const o = Ka(e);
  if ((u = (c = e.constraints) == null ? void 0 : c.allowedSources) != null && u.length && !e.constraints.allowedSources.includes(e.source))
    return St(
      "source-not-allowed",
      "source-rejected",
      `File intake source "${e.source}" is not allowed by the current platform policy.`
    );
  const n = (p = e.constraints) != null && p.maxFileSizeBytes ? e.files.find(
    (_) => _.size > e.constraints.maxFileSizeBytes
  ) : null;
  if (n)
    return St(
      "file-too-large",
      "size-rejected",
      `File "${n.name}" exceeds the maximum allowed size.`
    );
  const i = await ((m = t == null ? void 0 : t.classify) == null ? void 0 : m.call(t, e));
  if (i)
    return i;
  if (e.files.length === 0)
    return o ? {
      intent: "embed-remote",
      url: o
    } : St(
      "empty-intake",
      "no-files",
      "The intake event did not contain files or a resolvable remote URL."
    );
  const s = $a(e), a = e.files.map(
    (_) => Ha(_, s)
  ), l = a.filter(
    (_) => !!_
  );
  if (l.length > 0 && l.length !== e.files.length)
    return St(
      "mixed-intents-not-supported",
      "mixed-intents",
      "A single intake event cannot mix import-content files with attachment files."
    );
  if (l.length > 0)
    return e.files.length > 1 ? St(
      "multiple-import-files-not-supported",
      "multiple-import-files",
      "A single intake event cannot import more than one text file at a time."
    ) : {
      intent: "import-content",
      format: a[0] ?? void 0
    };
  const r = (z = (y = e.constraints) == null ? void 0 : y.allowedMimeTypes) != null && z.length ? e.files.find(
    (_) => {
      var x, k;
      return !!_.type && !((k = (x = e.constraints) == null ? void 0 : x.allowedMimeTypes) != null && k.includes(_.type));
    }
  ) : null;
  if (r)
    return St(
      "mime-not-allowed",
      "mime-rejected",
      `File "${r.name}" is not allowed by the current MIME policy.`
    );
  const f = Array.from(
    new Set(e.files.map((_) => Ua(_)))
  );
  return {
    intent: "attach-asset",
    assetKind: f.length === 1 ? f[0] : void 0
  };
}, ct = (e, t, o) => qa(e, t, o), Wa = (e) => {
  var o;
  const t = (o = e.body.content) == null ? void 0 : o.content;
  return !Array.isArray(t) || t.length === 0;
}, Ja = (e) => e.source === "drop" || e.source === "paste", Za = async ({
  currentDocument: e,
  event: t,
  file: o,
  filePlatform: n,
  format: i
}) => {
  var a;
  if (Wa(e))
    return "replace-current";
  const s = await ((a = n == null ? void 0 : n.chooseImportDisposition) == null ? void 0 : a.call(n, {
    event: t,
    file: o,
    format: i,
    currentDocument: e
  }));
  return s || (Ja(t) ? "insert-at-selection" : "cancel");
};
function Xa(e, t = !1) {
  const o = e.length;
  let n = 0, i = "", s = 0, a = 16, l = 0, r = 0, f = 0, c = 0, u = 0;
  function p(g, V) {
    let H = 0, T = 0;
    for (; H < g; ) {
      let w = e.charCodeAt(n);
      if (w >= 48 && w <= 57)
        T = T * 16 + w - 48;
      else if (w >= 65 && w <= 70)
        T = T * 16 + w - 65 + 10;
      else if (w >= 97 && w <= 102)
        T = T * 16 + w - 97 + 10;
      else
        break;
      n++, H++;
    }
    return H < g && (T = -1), T;
  }
  function m(g) {
    n = g, i = "", s = 0, a = 16, u = 0;
  }
  function y() {
    let g = n;
    if (e.charCodeAt(n) === 48)
      n++;
    else
      for (n++; n < e.length && _t(e.charCodeAt(n)); )
        n++;
    if (n < e.length && e.charCodeAt(n) === 46)
      if (n++, n < e.length && _t(e.charCodeAt(n)))
        for (n++; n < e.length && _t(e.charCodeAt(n)); )
          n++;
      else
        return u = 3, e.substring(g, n);
    let V = n;
    if (n < e.length && (e.charCodeAt(n) === 69 || e.charCodeAt(n) === 101))
      if (n++, (n < e.length && e.charCodeAt(n) === 43 || e.charCodeAt(n) === 45) && n++, n < e.length && _t(e.charCodeAt(n))) {
        for (n++; n < e.length && _t(e.charCodeAt(n)); )
          n++;
        V = n;
      } else
        u = 3;
    return e.substring(g, V);
  }
  function z() {
    let g = "", V = n;
    for (; ; ) {
      if (n >= o) {
        g += e.substring(V, n), u = 2;
        break;
      }
      const H = e.charCodeAt(n);
      if (H === 34) {
        g += e.substring(V, n), n++;
        break;
      }
      if (H === 92) {
        if (g += e.substring(V, n), n++, n >= o) {
          u = 2;
          break;
        }
        switch (e.charCodeAt(n++)) {
          case 34:
            g += '"';
            break;
          case 92:
            g += "\\";
            break;
          case 47:
            g += "/";
            break;
          case 98:
            g += "\b";
            break;
          case 102:
            g += "\f";
            break;
          case 110:
            g += `
`;
            break;
          case 114:
            g += "\r";
            break;
          case 116:
            g += "	";
            break;
          case 117:
            const w = p(4);
            w >= 0 ? g += String.fromCharCode(w) : u = 4;
            break;
          default:
            u = 5;
        }
        V = n;
        continue;
      }
      if (H >= 0 && H <= 31)
        if (Pt(H)) {
          g += e.substring(V, n), u = 2;
          break;
        } else
          u = 6;
      n++;
    }
    return g;
  }
  function _() {
    if (i = "", u = 0, s = n, r = l, c = f, n >= o)
      return s = o, a = 17;
    let g = e.charCodeAt(n);
    if (xn(g)) {
      do
        n++, i += String.fromCharCode(g), g = e.charCodeAt(n);
      while (xn(g));
      return a = 15;
    }
    if (Pt(g))
      return n++, i += String.fromCharCode(g), g === 13 && e.charCodeAt(n) === 10 && (n++, i += `
`), l++, f = n, a = 14;
    switch (g) {
      // tokens: []{}:,
      case 123:
        return n++, a = 1;
      case 125:
        return n++, a = 2;
      case 91:
        return n++, a = 3;
      case 93:
        return n++, a = 4;
      case 58:
        return n++, a = 6;
      case 44:
        return n++, a = 5;
      // strings
      case 34:
        return n++, i = z(), a = 10;
      // comments
      case 47:
        const V = n - 1;
        if (e.charCodeAt(n + 1) === 47) {
          for (n += 2; n < o && !Pt(e.charCodeAt(n)); )
            n++;
          return i = e.substring(V, n), a = 12;
        }
        if (e.charCodeAt(n + 1) === 42) {
          n += 2;
          const H = o - 1;
          let T = !1;
          for (; n < H; ) {
            const w = e.charCodeAt(n);
            if (w === 42 && e.charCodeAt(n + 1) === 47) {
              n += 2, T = !0;
              break;
            }
            n++, Pt(w) && (w === 13 && e.charCodeAt(n) === 10 && n++, l++, f = n);
          }
          return T || (n++, u = 1), i = e.substring(V, n), a = 13;
        }
        return i += String.fromCharCode(g), n++, a = 16;
      // numbers
      case 45:
        if (i += String.fromCharCode(g), n++, n === o || !_t(e.charCodeAt(n)))
          return a = 16;
      // found a minus, followed by a number so
      // we fall through to proceed with scanning
      // numbers
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
        return i += y(), a = 11;
      // literals and unknown symbols
      default:
        for (; n < o && x(g); )
          n++, g = e.charCodeAt(n);
        if (s !== n) {
          switch (i = e.substring(s, n), i) {
            case "true":
              return a = 8;
            case "false":
              return a = 9;
            case "null":
              return a = 7;
          }
          return a = 16;
        }
        return i += String.fromCharCode(g), n++, a = 16;
    }
  }
  function x(g) {
    if (xn(g) || Pt(g))
      return !1;
    switch (g) {
      case 125:
      case 93:
      case 123:
      case 91:
      case 34:
      case 58:
      case 44:
      case 47:
        return !1;
    }
    return !0;
  }
  function k() {
    let g;
    do
      g = _();
    while (g >= 12 && g <= 15);
    return g;
  }
  return {
    setPosition: m,
    getPosition: () => n,
    scan: t ? k : _,
    getToken: () => a,
    getTokenValue: () => i,
    getTokenOffset: () => s,
    getTokenLength: () => n - s,
    getTokenStartLine: () => r,
    getTokenStartCharacter: () => s - c,
    getTokenError: () => u
  };
}
function xn(e) {
  return e === 32 || e === 9;
}
function Pt(e) {
  return e === 10 || e === 13;
}
function _t(e) {
  return e >= 48 && e <= 57;
}
var vo;
(function(e) {
  e[e.lineFeed = 10] = "lineFeed", e[e.carriageReturn = 13] = "carriageReturn", e[e.space = 32] = "space", e[e._0 = 48] = "_0", e[e._1 = 49] = "_1", e[e._2 = 50] = "_2", e[e._3 = 51] = "_3", e[e._4 = 52] = "_4", e[e._5 = 53] = "_5", e[e._6 = 54] = "_6", e[e._7 = 55] = "_7", e[e._8 = 56] = "_8", e[e._9 = 57] = "_9", e[e.a = 97] = "a", e[e.b = 98] = "b", e[e.c = 99] = "c", e[e.d = 100] = "d", e[e.e = 101] = "e", e[e.f = 102] = "f", e[e.g = 103] = "g", e[e.h = 104] = "h", e[e.i = 105] = "i", e[e.j = 106] = "j", e[e.k = 107] = "k", e[e.l = 108] = "l", e[e.m = 109] = "m", e[e.n = 110] = "n", e[e.o = 111] = "o", e[e.p = 112] = "p", e[e.q = 113] = "q", e[e.r = 114] = "r", e[e.s = 115] = "s", e[e.t = 116] = "t", e[e.u = 117] = "u", e[e.v = 118] = "v", e[e.w = 119] = "w", e[e.x = 120] = "x", e[e.y = 121] = "y", e[e.z = 122] = "z", e[e.A = 65] = "A", e[e.B = 66] = "B", e[e.C = 67] = "C", e[e.D = 68] = "D", e[e.E = 69] = "E", e[e.F = 70] = "F", e[e.G = 71] = "G", e[e.H = 72] = "H", e[e.I = 73] = "I", e[e.J = 74] = "J", e[e.K = 75] = "K", e[e.L = 76] = "L", e[e.M = 77] = "M", e[e.N = 78] = "N", e[e.O = 79] = "O", e[e.P = 80] = "P", e[e.Q = 81] = "Q", e[e.R = 82] = "R", e[e.S = 83] = "S", e[e.T = 84] = "T", e[e.U = 85] = "U", e[e.V = 86] = "V", e[e.W = 87] = "W", e[e.X = 88] = "X", e[e.Y = 89] = "Y", e[e.Z = 90] = "Z", e[e.asterisk = 42] = "asterisk", e[e.backslash = 92] = "backslash", e[e.closeBrace = 125] = "closeBrace", e[e.closeBracket = 93] = "closeBracket", e[e.colon = 58] = "colon", e[e.comma = 44] = "comma", e[e.dot = 46] = "dot", e[e.doubleQuote = 34] = "doubleQuote", e[e.minus = 45] = "minus", e[e.openBrace = 123] = "openBrace", e[e.openBracket = 91] = "openBracket", e[e.plus = 43] = "plus", e[e.slash = 47] = "slash", e[e.formFeed = 12] = "formFeed", e[e.tab = 9] = "tab";
})(vo || (vo = {}));
new Array(20).fill(0).map((e, t) => " ".repeat(t));
const Ot = 200;
new Array(Ot).fill(0).map((e, t) => `
` + " ".repeat(t)), new Array(Ot).fill(0).map((e, t) => "\r" + " ".repeat(t)), new Array(Ot).fill(0).map((e, t) => `\r
` + " ".repeat(t)), new Array(Ot).fill(0).map((e, t) => `
` + "	".repeat(t)), new Array(Ot).fill(0).map((e, t) => "\r" + "	".repeat(t)), new Array(Ot).fill(0).map((e, t) => `\r
` + "	".repeat(t));
var rn;
(function(e) {
  e.DEFAULT = {
    allowTrailingComma: !1
  };
})(rn || (rn = {}));
function Ya(e, t = [], o = rn.DEFAULT) {
  let n = null, i = [];
  const s = [];
  function a(r) {
    Array.isArray(i) ? i.push(r) : n !== null && (i[n] = r);
  }
  return Qa(e, {
    onObjectBegin: () => {
      const r = {};
      a(r), s.push(i), i = r, n = null;
    },
    onObjectProperty: (r) => {
      n = r;
    },
    onObjectEnd: () => {
      i = s.pop();
    },
    onArrayBegin: () => {
      const r = [];
      a(r), s.push(i), i = r, n = null;
    },
    onArrayEnd: () => {
      i = s.pop();
    },
    onLiteralValue: a,
    onError: (r, f, c) => {
      t.push({ error: r, offset: f, length: c });
    }
  }, o), i[0];
}
function Qa(e, t, o = rn.DEFAULT) {
  const n = Xa(e, !1), i = [];
  let s = 0;
  function a(B) {
    return B ? () => s === 0 && B(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter()) : () => !0;
  }
  function l(B) {
    return B ? (L) => s === 0 && B(L, n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter()) : () => !0;
  }
  function r(B) {
    return B ? (L) => s === 0 && B(L, n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter(), () => i.slice()) : () => !0;
  }
  function f(B) {
    return B ? () => {
      s > 0 ? s++ : B(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter(), () => i.slice()) === !1 && (s = 1);
    } : () => !0;
  }
  function c(B) {
    return B ? () => {
      s > 0 && s--, s === 0 && B(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter());
    } : () => !0;
  }
  const u = f(t.onObjectBegin), p = r(t.onObjectProperty), m = c(t.onObjectEnd), y = f(t.onArrayBegin), z = c(t.onArrayEnd), _ = r(t.onLiteralValue), x = l(t.onSeparator), k = a(t.onComment), g = l(t.onError), V = o && o.disallowComments, H = o && o.allowTrailingComma;
  function T() {
    for (; ; ) {
      const B = n.scan();
      switch (n.getTokenError()) {
        case 4:
          w(
            14
            /* ParseErrorCode.InvalidUnicode */
          );
          break;
        case 5:
          w(
            15
            /* ParseErrorCode.InvalidEscapeCharacter */
          );
          break;
        case 3:
          w(
            13
            /* ParseErrorCode.UnexpectedEndOfNumber */
          );
          break;
        case 1:
          V || w(
            11
            /* ParseErrorCode.UnexpectedEndOfComment */
          );
          break;
        case 2:
          w(
            12
            /* ParseErrorCode.UnexpectedEndOfString */
          );
          break;
        case 6:
          w(
            16
            /* ParseErrorCode.InvalidCharacter */
          );
          break;
      }
      switch (B) {
        case 12:
        case 13:
          V ? w(
            10
            /* ParseErrorCode.InvalidCommentToken */
          ) : k();
          break;
        case 16:
          w(
            1
            /* ParseErrorCode.InvalidSymbol */
          );
          break;
        case 15:
        case 14:
          break;
        default:
          return B;
      }
    }
  }
  function w(B, L = [], O = []) {
    if (g(B), L.length + O.length > 0) {
      let U = n.getToken();
      for (; U !== 17; ) {
        if (L.indexOf(U) !== -1) {
          T();
          break;
        } else if (O.indexOf(U) !== -1)
          break;
        U = T();
      }
    }
  }
  function R(B) {
    const L = n.getTokenValue();
    return B ? _(L) : (p(L), i.push(L)), T(), !0;
  }
  function X() {
    switch (n.getToken()) {
      case 11:
        const B = n.getTokenValue();
        let L = Number(B);
        isNaN(L) && (w(
          2
          /* ParseErrorCode.InvalidNumberFormat */
        ), L = 0), _(L);
        break;
      case 7:
        _(null);
        break;
      case 8:
        _(!0);
        break;
      case 9:
        _(!1);
        break;
      default:
        return !1;
    }
    return T(), !0;
  }
  function J() {
    return n.getToken() !== 10 ? (w(3, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ]), !1) : (R(!1), n.getToken() === 6 ? (x(":"), T(), C() || w(4, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ])) : w(5, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ]), i.pop(), !0);
  }
  function ne() {
    u(), T();
    let B = !1;
    for (; n.getToken() !== 2 && n.getToken() !== 17; ) {
      if (n.getToken() === 5) {
        if (B || w(4, [], []), x(","), T(), n.getToken() === 2 && H)
          break;
      } else B && w(6, [], []);
      J() || w(4, [], [
        2,
        5
        /* SyntaxKind.CommaToken */
      ]), B = !0;
    }
    return m(), n.getToken() !== 2 ? w(7, [
      2
      /* SyntaxKind.CloseBraceToken */
    ], []) : T(), !0;
  }
  function ae() {
    y(), T();
    let B = !0, L = !1;
    for (; n.getToken() !== 4 && n.getToken() !== 17; ) {
      if (n.getToken() === 5) {
        if (L || w(4, [], []), x(","), T(), n.getToken() === 4 && H)
          break;
      } else L && w(6, [], []);
      B ? (i.push(0), B = !1) : i[i.length - 1]++, C() || w(4, [], [
        4,
        5
        /* SyntaxKind.CommaToken */
      ]), L = !0;
    }
    return z(), B || i.pop(), n.getToken() !== 4 ? w(8, [
      4
      /* SyntaxKind.CloseBracketToken */
    ], []) : T(), !0;
  }
  function C() {
    switch (n.getToken()) {
      case 3:
        return ae();
      case 1:
        return ne();
      case 10:
        return R(!0);
      default:
        return X();
    }
  }
  return T(), n.getToken() === 17 ? o.allowEmptyContent ? !0 : (w(4, [], []), !1) : C() ? (n.getToken() !== 17 && w(9, [], []), !0) : (w(4, [], []), !1);
}
var go;
(function(e) {
  e[e.None = 0] = "None", e[e.UnexpectedEndOfComment = 1] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 2] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 3] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 4] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 5] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 6] = "InvalidCharacter";
})(go || (go = {}));
var ho;
(function(e) {
  e[e.OpenBraceToken = 1] = "OpenBraceToken", e[e.CloseBraceToken = 2] = "CloseBraceToken", e[e.OpenBracketToken = 3] = "OpenBracketToken", e[e.CloseBracketToken = 4] = "CloseBracketToken", e[e.CommaToken = 5] = "CommaToken", e[e.ColonToken = 6] = "ColonToken", e[e.NullKeyword = 7] = "NullKeyword", e[e.TrueKeyword = 8] = "TrueKeyword", e[e.FalseKeyword = 9] = "FalseKeyword", e[e.StringLiteral = 10] = "StringLiteral", e[e.NumericLiteral = 11] = "NumericLiteral", e[e.LineCommentTrivia = 12] = "LineCommentTrivia", e[e.BlockCommentTrivia = 13] = "BlockCommentTrivia", e[e.LineBreakTrivia = 14] = "LineBreakTrivia", e[e.Trivia = 15] = "Trivia", e[e.Unknown = 16] = "Unknown", e[e.EOF = 17] = "EOF";
})(ho || (ho = {}));
const bo = Ya;
var yo;
(function(e) {
  e[e.InvalidSymbol = 1] = "InvalidSymbol", e[e.InvalidNumberFormat = 2] = "InvalidNumberFormat", e[e.PropertyNameExpected = 3] = "PropertyNameExpected", e[e.ValueExpected = 4] = "ValueExpected", e[e.ColonExpected = 5] = "ColonExpected", e[e.CommaExpected = 6] = "CommaExpected", e[e.CloseBraceExpected = 7] = "CloseBraceExpected", e[e.CloseBracketExpected = 8] = "CloseBracketExpected", e[e.EndOfFileExpected = 9] = "EndOfFileExpected", e[e.InvalidCommentToken = 10] = "InvalidCommentToken", e[e.UnexpectedEndOfComment = 11] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 12] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 13] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 14] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 15] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 16] = "InvalidCharacter";
})(yo || (yo = {}));
function ko(e) {
  switch (e) {
    case 1:
      return "InvalidSymbol";
    case 2:
      return "InvalidNumberFormat";
    case 3:
      return "PropertyNameExpected";
    case 4:
      return "ValueExpected";
    case 5:
      return "ColonExpected";
    case 6:
      return "CommaExpected";
    case 7:
      return "CloseBraceExpected";
    case 8:
      return "CloseBracketExpected";
    case 9:
      return "EndOfFileExpected";
    case 10:
      return "InvalidCommentToken";
    case 11:
      return "UnexpectedEndOfComment";
    case 12:
      return "UnexpectedEndOfString";
    case 13:
      return "UnexpectedEndOfNumber";
    case 14:
      return "InvalidUnicode";
    case 15:
      return "InvalidEscapeCharacter";
    case 16:
      return "InvalidCharacter";
  }
  return "<unknown ParseErrorCode>";
}
const wo = (e) => e.map((t) => ({
  code: `json-parse/${ko(t.error)}`,
  message: ko(t.error),
  offset: t.offset,
  length: t.length
})), el = async (e, t) => {
  const o = await e.text();
  if (t === "json") {
    const n = [], i = bo(o, n, {
      allowEmptyContent: !1,
      allowTrailingComma: !1,
      disallowComments: !0
    });
    if (n.length === 0)
      return {
        format: t,
        rawText: o,
        value: i,
        parsedValue: i,
        jsonParseMode: "json",
        jsonDiagnostics: []
      };
    const s = [], a = bo(o, s, {
      allowEmptyContent: !1,
      allowTrailingComma: !0,
      disallowComments: !1
    });
    return s.length === 0 ? {
      format: t,
      rawText: o,
      value: a,
      parsedValue: a,
      jsonParseMode: "jsonc",
      jsonDiagnostics: wo(n)
    } : {
      format: t,
      rawText: o,
      value: o,
      jsonParseMode: "raw-text",
      jsonDiagnostics: wo(s)
    };
  }
  return {
    format: t,
    rawText: o,
    value: o
  };
}, tl = (e) => typeof e == "object" && e !== null && !Array.isArray(e), nl = (e) => tl(e) && typeof e.type == "string", ol = (e) => nn(e) || nl(e), il = async (e, t, o, n) => {
  const s = (o != null && o.resolveJsonImportMode && n ? await o.resolveJsonImportMode({
    event: n,
    file: e,
    rawText: t.rawText,
    parsedValue: t.parsedValue,
    parseMode: t.jsonParseMode ?? "raw-text",
    diagnostics: t.jsonDiagnostics ?? []
  }) : "auto") ?? "auto";
  if (s === "code-block")
    return t.rawText;
  if (s === "canonical-document") {
    if (!ol(t.parsedValue))
      throw new Error(
        'JSON import mode "canonical-document" requires a canonical document envelope or JSONContent payload.'
      );
    return t.parsedValue;
  }
  return t.parsedValue ?? t.rawText;
}, sl = async (e, t, o, n) => {
  const i = await el(e, t);
  switch (t) {
    case "markdown":
      return zs(i.value, {
        importMode: "fresh-import",
        meta: {
          source: "import"
        }
      }).document;
    case "html":
      return Cs(
        o != null && o.sanitizeImportedHtml && n ? await o.sanitizeImportedHtml(i.value, {
          event: n,
          file: e
        }) : i.value,
        {
          importMode: "fresh-import",
          meta: {
            source: "import"
          }
        }
      ).document;
    case "json":
      return Bs(
        await il(e, i, o, n),
        {
          importMode: "fresh-import",
          meta: {
            source: "import"
          }
        }
      ).document;
    case "text":
      return Ls(i.value, {
        importMode: "fresh-import",
        meta: {
          source: "import"
        }
      }).document;
  }
}, rl = (e) => ({
  ...e,
  body: {
    ...e.body,
    content: or(
      e.body.content,
      "file-intake"
    )
  }
}), al = async ({
  applyImportedDocument: e,
  currentDocument: t,
  event: o,
  file: n,
  filePlatform: i,
  format: s,
  insertImportedDocument: a
}) => {
  const l = await Za({
    currentDocument: t,
    event: o,
    file: n,
    filePlatform: i,
    format: s
  });
  if (l === "cancel")
    return {
      disposition: l,
      handled: !0
    };
  const r = rl(
    await sl(n, s, i, o)
  );
  if (l === "replace-current")
    return e(r), {
      disposition: l,
      document: r,
      handled: !0
    };
  if (l === "insert-at-selection") {
    if (!a)
      throw new Error(
        'Text file import disposition "insert-at-selection" requires an insertion callback.'
      );
    return a(r, {
      event: o,
      file: n,
      format: s
    }), {
      disposition: l,
      document: r,
      handled: !0
    };
  }
  return l === "open-new" ? (await (i == null ? void 0 : i.openNewImportedDocument({
    event: o,
    file: n,
    format: s,
    document: r
  })), {
    disposition: l,
    document: r,
    handled: !0
  }) : {
    disposition: l,
    handled: !0
  };
}, ll = (e, t) => {
  var i, s;
  const o = (i = e.context) == null ? void 0 : i.preferredNodeKind;
  if (o === "image" || o === "video" || o === "attachment")
    return o;
  const n = (s = e.context) == null ? void 0 : s.nodeKind;
  if (n === "image" || n === "video" || n === "attachment")
    return n;
  if (t.intent === "attach-asset") {
    if (t.assetKind === "image")
      return "image";
    if (t.assetKind === "video")
      return "video";
    if (t.assetKind === "file")
      return "attachment";
  }
  return null;
}, cl = (e, t, o) => {
  const { event: n } = e, i = e.anchorPos ?? n.dropPos ?? null;
  return t.enqueue({
    anchorPos: i,
    event: n,
    preferredNodeKind: ll(n, o)
  });
}, ul = ({
  applyImportedDocument: e,
  assetPipelineRuntime: t,
  documentState: o,
  editor: n,
  filePlatformRuntime: i,
  getCurrentDocument: s,
  insertImportedDocument: a
}) => ({
  dispatch: async (l) => {
    const r = i.getFilePlatform(), f = l.event.htmlContent && (r != null && r.sanitizeImportedHtml) ? {
      ...l.event,
      htmlContent: await r.sanitizeImportedHtml(
        l.event.htmlContent,
        {
          event: l.event,
          file: l.event.files[0] ?? null
        }
      )
    } : l.event, c = await Ga({
      event: f,
      filePlatform: r
    });
    it("text-editor:file-intake", "intake classified", {
      source: f.source,
      dropPos: f.dropPos,
      selectionFrom: f.selectionFrom,
      selectionTo: f.selectionTo,
      files: f.files.map((m) => ({
        name: m.name,
        type: m.type,
        size: m.size
      })),
      decision: c
    });
    const u = n.value;
    if (c.intent === "reject")
      return ct(f, c, !0);
    if (c.intent === "import-content") {
      const m = f.files[0];
      if (!m)
        return ct(
          f,
          {
            intent: "reject",
            code: "missing-import-file",
            reason: "import-file-missing",
            message: "Import-content decisions require a concrete file payload."
          },
          !0
        );
      try {
        const y = await al({
          applyImportedDocument: e,
          currentDocument: s(),
          event: f,
          file: m,
          filePlatform: r,
          format: c.format ?? "text",
          insertImportedDocument: a
        });
        return it("text-editor:file-intake", "text import executed", {
          source: f.source,
          fileName: m.name,
          format: c.format ?? "text",
          disposition: y.disposition,
          handled: y.handled
        }), ct(f, c, y.handled);
      } catch (y) {
        return it("text-editor:file-intake", "text import failed", {
          source: f.source,
          fileName: m.name,
          format: c.format ?? "text",
          error: y instanceof Error ? y.message : String(y)
        }), ct(
          f,
          {
            intent: "reject",
            code: "import-failed",
            reason: "import-error",
            message: y instanceof Error ? y.message : "The text file import pipeline failed."
          },
          !0
        );
      }
    }
    if (c.intent === "embed-remote")
      try {
        const m = await Wr({
          anchorPos: l.anchorPos ?? f.dropPos ?? null,
          documentState: o,
          editor: u,
          event: f,
          filePlatform: r,
          url: c.url ?? ""
        });
        return it("text-editor:file-intake", "remote embed executed", {
          source: f.source,
          url: c.url ?? "",
          handled: m.handled
        }), ct(f, c, m.handled);
      } catch (m) {
        const y = m instanceof Rt ? m.code : "remote-embed-failed", z = m instanceof Error ? m.message : "The remote embed pipeline failed.";
        return i.emitDiagnostic({
          code: y,
          message: z,
          severity: "error",
          stage: "intake",
          intake: f,
          cause: m
        }), ct(
          f,
          {
            intent: "reject",
            code: y,
            reason: "remote-embed-error",
            message: z
          },
          !0
        );
      }
    if (!u || c.intent !== "attach-asset")
      return ct(
        f,
        {
          intent: "reject",
          code: "unsupported-intent",
          reason: "intent-not-supported",
          message: `The intake pipeline does not support intent "${String(
            c.intent
          )}".`
        },
        !0
      );
    const p = cl(
      {
        ...l,
        event: f
      },
      t,
      c
    );
    return ct(f, c, p);
  }
}), pi = /* @__PURE__ */ Ae({
  name: "ZxTextEditor",
  inheritAttrs: !1,
  __name: "text-editor",
  props: Ma,
  emits: Da,
  setup(e, { expose: t, emit: o }) {
    const n = e, i = Ut(), s = Zo(), a = o, l = Ko(n.themeOwner);
    if (!l || l.state !== "active")
      throw new Error("EDITOR_THEME_OWNER_REQUIRED");
    In(es, l);
    const r = Pe("text-editor"), f = Pe("code-block"), c = Be(null), u = W(null), p = W(gt()), m = W(yn()), y = W(!1), z = S(() => n.filePlatform ?? null), _ = Be(null), x = S(
      () => n.bubbleToolbar !== !1 && n.editable
    ), k = S(
      () => typeof n.bubbleToolbar == "object" && n.bubbleToolbar !== null ? n.bubbleToolbar : {}
    ), g = S(() => n.dragHandle ? n.dragHandle === !0 ? !0 : n.dragHandle.showPlus !== !1 : !1), V = S(() => {
      if (!(!n.dragHandle || n.dragHandle === !0))
        return n.dragHandle.onPlusClick;
    }), H = S(() => !n.dragHandle || n.dragHandle === !0 ? null : n.dragHandle.askAIBridge ?? null), T = $t(), w = S(() => K(T.class)), R = S(() => pt(T.style)), X = S(() => Object.fromEntries(
      Object.entries(T).filter(([b]) => b !== "class" && b !== "style")
    )), J = S(() => {
      const b = c.value ? Ms(c.value) : ei({
        override: n.typography
      });
      return Jo(b);
    }), ne = S(
      () => ts(n.extensions, "comment")
    ), ae = (b, D) => {
      const $ = b.state.doc.resolve(D);
      let G = $.depth;
      for (; G > 0 && $.node(G).type.name !== "codeBlock"; ) G--;
      if (G === 0) return null;
      const ee = $.node(G), ie = $.before(G), xe = b.nodeDOM(ie), Oe = xe instanceof HTMLElement ? xe : null;
      return { node: ee, from: ie, dom: Oe };
    }, C = (b, D, $) => {
      const G = f.b(), ee = Array.from(
        b.dom.querySelectorAll(`.${G}`)
      );
      if (!ee.length) return null;
      const ie = 8, xe = 24;
      for (const Oe of ee) {
        const Te = Oe.getBoundingClientRect(), lt = $ >= Te.top && $ <= Te.bottom, tt = D >= Te.left - xe && D <= Te.right + xe;
        if (lt && (D < Te.left - 1 || D > Te.right + 1) || $ > Te.bottom && $ <= Te.bottom + ie && tt)
          return Oe;
      }
      return null;
    }, B = (b, D, $) => {
      var Oe;
      const G = D + $, ee = b.state.doc.nodeAt(G);
      if ((ee == null ? void 0 : ee.type.name) === "paragraph" && ee.content.size === 0) {
        const Te = b.state.tr.setSelection(
          ut.create(b.state.doc, G + 1)
        );
        return b.dispatch(Te.scrollIntoView()), !0;
      }
      const ie = b.state.schema.nodes.paragraph, xe = ie == null ? void 0 : ie.createAndFill();
      if (xe && ie) {
        const Te = b.state.doc.resolve(G), lt = Te.index();
        if (Te.parent.canReplaceWith(lt, lt, ie)) {
          const tt = b.state.tr.insert(G, xe);
          return tt.setSelection(ut.create(tt.doc, G + 1)), b.dispatch(tt.scrollIntoView()), !0;
        }
      }
      return (Oe = c.value) == null || Oe.chain().focus().setNodeSelection(D).createParagraphNear().run(), !0;
    }, L = (b, D) => {
      var xe;
      const $ = b.state.doc.resolve(D), G = $.nodeBefore;
      if ((G == null ? void 0 : G.type.name) === "paragraph" && G.content.size === 0) {
        const Oe = b.state.tr.setSelection(
          ut.create(b.state.doc, D - 1)
        );
        return b.dispatch(Oe.scrollIntoView()), !0;
      }
      const ee = b.state.schema.nodes.paragraph, ie = ee == null ? void 0 : ee.createAndFill();
      if (ie && ee) {
        const Oe = $.index();
        if ($.parent.canReplaceWith(Oe, Oe, ee)) {
          const Te = b.state.tr.insert(D, ie);
          return Te.setSelection(ut.create(Te.doc, D + 1)), b.dispatch(Te.scrollIntoView()), !0;
        }
      }
      return (xe = c.value) == null || xe.chain().focus().setNodeSelection(D).createParagraphNear().run(), !0;
    }, O = (b) => {
      const D = b.state.doc;
      let $ = 0;
      for (let G = 0; G < D.childCount; G++) {
        const ee = D.child(G);
        if (G === D.childCount - 1) return { node: ee, from: $ };
        $ += ee.nodeSize;
      }
      return null;
    }, U = (b) => {
      var ie, xe;
      const D = (ie = c.value) == null ? void 0 : ie.view;
      if (!D || b.button !== 0) return;
      const $ = b.target;
      if ($ && D.dom.contains($)) return;
      const G = D.dom.getBoundingClientRect();
      if (b.clientY <= G.bottom + 1) return;
      b.preventDefault();
      const ee = O(D);
      if ((ee == null ? void 0 : ee.node.type.name) === "codeBlock") {
        B(D, ee.from, ee.node.nodeSize), D.focus();
        return;
      }
      (xe = c.value) == null || xe.chain().focus("end").run();
    }, oe = (b) => {
      var D;
      return Array.from(((D = b.dataTransfer) == null ? void 0 : D.files) ?? []);
    }, he = (b) => {
      var $;
      if (oe(b).length > 0)
        return !0;
      const D = ($ = b.dataTransfer) == null ? void 0 : $.types;
      return !!(D && Array.from(D).includes("Files"));
    }, le = (b) => {
      at.emitDiagnostic({
        code: "root-drop-intake-dispatch-failed",
        message: b instanceof Error ? b.message : "Failed to dispatch dropped files from the editor root.",
        severity: "error",
        stage: "intake",
        cause: b
      });
    }, fe = (b) => {
      var $;
      const D = ($ = c.value) == null ? void 0 : $.view.dom;
      return !!(D && b instanceof Node && D.contains(b));
    }, we = (b) => {
      he(b) && (fe(b.target) || (b.preventDefault(), b.dataTransfer && (b.dataTransfer.dropEffect = "copy")));
    }, ge = (b) => {
      if (n.contentProfile === "basic-rich-text" && oe(b).length) {
        b.preventDefault(), b.stopPropagation(), a("content-issue", "备注不支持图片或附件");
        return;
      }
      const D = oe(b);
      D.length !== 0 && (fe(b.target) || (b.preventDefault(), Promise.resolve(
        at.intakeFiles({
          source: "drop",
          files: D,
          dropPos: null,
          anchorPos: null
        })
      ).catch(($) => {
        le($);
      })));
    }, ce = (b, D, $) => {
      var Zn, Xn, Yn, Qn;
      const G = $.target;
      if (!G) return !1;
      const ee = $.clientX, ie = $.clientY, xe = f.b(), Oe = f.e("line-numbers"), Te = f.e("body"), lt = f.e("pre"), tt = f.e("code"), We = G.closest(`.${xe}`), Mi = G.closest(`.${Oe}`);
      let Wt = ae(b, D);
      if (!Wt && G === b.dom) {
        const $e = C(b, ee, ie);
        if ($e) {
          const Ue = b.posAtDOM($e, 0);
          Wt = ae(b, Ue);
        }
      }
      if (We || Wt) {
        const $e = Wt || (We ? ae(b, D) : null);
        if ($e) {
          const Ue = (Zn = $e.dom || We) == null ? void 0 : Zn.getBoundingClientRect(), vn = Ue ? ee < Ue.left - 2 && ie >= Ue.top && ie <= Ue.bottom : !1;
          if (Mi || vn)
            return L(b, $e.from);
          const eo = (Xn = We || $e.dom) == null ? void 0 : Xn.querySelector(
            `.${Te}`
          ), to = (Yn = We || $e.dom) == null ? void 0 : Yn.querySelector(
            `.${lt}`
          ), no = (Qn = We || $e.dom) == null ? void 0 : Qn.querySelector(
            `.${tt}`
          );
          if (eo && to && no && eo.contains(G) && to.contains(G)) {
            const Zt = document.createRange();
            Zt.selectNodeContents(no);
            const zt = Array.from(Zt.getClientRects()).filter(
              (Mt) => Mt.width > 0 && Mt.height > 0
            );
            if (zt.length > 0) {
              const Mt = Math.max(...zt.map((ot) => ot.bottom)), Vi = 1, gn = zt.filter(
                (ot) => Math.abs(ot.bottom - Mt) <= Vi
              ), ji = Math.max(...gn.map((ot) => ot.right)), $i = Math.min(...gn.map((ot) => ot.top)), Hi = Math.max(...gn.map((ot) => ot.bottom)), Ui = ie >= $i - 1 && ie <= Hi + 1 && ee > ji + 6, Ki = ie > Mt + 6;
              if (Ui || Ki)
                return B(b, $e.from, $e.node.nodeSize);
            }
          }
          if (Ue) {
            const Zt = ee > Ue.right + 2 && ie >= Ue.top && ie <= Ue.bottom, zt = ie > Ue.bottom + 2;
            if (Zt || zt)
              return B(b, $e.from, $e.node.nodeSize);
          }
        }
      }
      const Gn = G.closest(
        "p, h1, h2, h3, h4, h5, h6, li, blockquote, td, th"
      );
      if (!Gn) return !1;
      const Jt = [], Di = document.createTreeWalker(Gn, NodeFilter.SHOW_TEXT);
      let Wn;
      for (; Wn = Di.nextNode(); )
        Jt.push(Wn);
      if (Jt.length === 0) return !1;
      const Jn = document.createRange(), Fi = Jt[Jt.length - 1];
      Jn.selectNodeContents(Fi);
      const Pi = Jn.getBoundingClientRect();
      if (ee > Pi.right + 2) {
        const Ue = b.state.doc.resolve(D).end(), vn = b.state.tr.setSelection(
          ut.create(b.state.doc, Ue)
        );
        return b.dispatch(vn), !0;
      }
      return !1;
    }, ve = pa({
      editor: c,
      rootRef: u,
      documentState: p,
      getBookmarkProvider: () => n.bookmarkProvider,
      getEphemeralProviders: () => n.ephemeralProviders
    }), Ee = ve.navigationController, ue = ve.scheduleNavigationRefresh, te = ve.refreshNavigationRuntime, ye = ve.syncEditorNavigationBridge, re = ve.navigateToBlock, Me = ve.navigate, Ve = ve.cancelNavigation, Je = ve.getNavigationSnapshot, Z = ve.getNavigationDebugSnapshot, ke = ve.listNavigationDescriptors, Re = ve.syncNavigationFromLocation, Ge = ve.createShareableFragment, Qe = ve.getBlockElement, et = S(() => ({
      attributes: {
        class: K([r.e("prose"), n.editorClass])
      },
      handleClick: ce
    })), be = Er({
      editor: c,
      documentState: p,
      annotationBridgeState: m,
      hasCommentExtension: ne,
      isApplyingExternalContent: y,
      getMarkdownExportMode: () => n.markdownExportMode,
      getStableBlockIdentityOptions: () => {
        var b, D;
        return {
          types: (b = n.stableBlockIdentity) == null ? void 0 : b.types,
          generateId: (D = n.stableBlockIdentity) == null ? void 0 : D.generateId
        };
      }
    }), A = be.getCurrentDocument, E = be.resolveHydratedState, q = be.isHydratedStateSynced, Y = be.getHTML, pe = be.getMarkdown, Se = be.getJSON, Ce = be.getDocument, d = be.getText, h = be.getExcerpt, I = (b, D) => {
      n.contentProfile === "basic-rich-text" && Ye(b, n.contentLimits), be.setContent(b, D);
    }, P = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      be.setHTML(b);
    }, de = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      be.setMarkdown(b);
    }, ze = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      be.setJSON(b);
    }, nt = (b) => I(b, { contentType: "document" }), Tt = be.getRuntimeStatus, fn = (b) => JSON.parse(
      JSON.stringify(
        Array.isArray(b.body.content.content) ? b.body.content.content : []
      )
    ), Kt = (b, D) => {
      const { doc: $ } = b.state, G = Math.max(0, Math.min(D, $.content.size)), ee = $.resolve(G);
      for (let ie = ee.depth; ie > 0; ie -= 1)
        if (ee.node(ie).isBlock && ee.depth >= ie)
          return ee.before(ie);
      return G;
    }, pn = (b, D, $) => {
      if (typeof $.dropPos == "number") {
        const G = wr(
          b.state.doc,
          $.dropPos,
          D
        ), ee = G ?? Kt(b, $.dropPos);
        return it(
          "text-editor:file-import",
          "resolved drop insertion range",
          {
            requestedDropPos: $.dropPos,
            normalizedDropPos: G,
            insertionPos: ee
          }
        ), {
          from: ee,
          to: ee
        };
      }
      return {
        from: $.selectionFrom ?? b.state.selection.from,
        to: $.selectionTo ?? b.state.selection.to
      };
    }, qn = (b, D) => {
      var tt;
      const $ = c.value;
      if (!$) {
        nt(b);
        return;
      }
      const G = fn(b);
      if (G.length === 0)
        return;
      const ee = G.map(
        (We) => $.schema.nodeFromJSON(We)
      ), ie = new ni(oi.fromArray(ee), 0, 0), xe = A($), Oe = gt({
        ...xe,
        assets: Dn(xe.assets, b.assets),
        annotations: lr(
          xe.annotations,
          b.annotations
        )
      });
      p.value = Oe, m.value = yn(Oe);
      const Te = pn(
        $,
        ie,
        D.event
      );
      it("text-editor:file-import", "applying imported content", {
        importedNodeCount: G.length,
        importedNodeTypes: G.map((We) => We.type),
        event: D.event,
        insertionRange: Te
      });
      const lt = $.state.tr.replaceRange(
        Te.from,
        Te.to,
        ie
      );
      $.view.focus(), $.view.dispatch(lt.scrollIntoView()), it("text-editor:file-import", "import transaction applied", {
        selectionFrom: $.state.selection.from,
        selectionTo: $.state.selection.to,
        topLevelNodeTypes: ((tt = A($).body.content.content) == null ? void 0 : tt.map(
          (We) => We.type
        )) ?? []
      });
    }, at = Cr({
      editor: c,
      filePlatform: z,
      intakeDispatcher: _,
      getCurrentDocument: () => A()
    }), It = Kr({
      documentState: p,
      editor: c,
      filePlatformRuntime: at
    });
    _.value = ul({
      applyImportedDocument: (b) => nt(b),
      assetPipelineRuntime: It,
      documentState: p,
      editor: c,
      filePlatformRuntime: at,
      getCurrentDocument: () => A(),
      insertImportedDocument: (b, D) => qn(b, D)
    });
    const qt = (b) => {
      be.applyHydratedEditorState(b), te();
    };
    Q(
      () => [
        n.content,
        n.modelValue,
        n.documentValue,
        n.contentType
      ],
      () => {
        var ee, ie;
        if (!c.value) return;
        const b = mt(
          "text-editor:external-sync",
          "props->editor sync watcher",
          {
            contentType: n.contentType,
            hasDocumentValue: !!n.documentValue
          }
        );
        if (n.contentProfile === "basic-rich-text") {
          if (JSON.stringify(n.documentValue) === JSON.stringify(be.getDocument())) {
            b == null || b.end({ applied: !1, sourceType: "document" });
            return;
          }
          try {
            Ye(n.documentValue, n.contentLimits);
          } catch (xe) {
            a("content-issue", String(xe)), b == null || b.end({ applied: !1 });
            return;
          }
        }
        const D = E({
          content: n.content,
          modelValue: n.modelValue,
          documentValue: n.documentValue,
          contentType: n.contentType,
          hydrateAnnotations: ne.value,
          stableBlockIdentity: {
            types: (ee = n.stableBlockIdentity) == null ? void 0 : ee.types,
            generateId: (ie = n.stableBlockIdentity) == null ? void 0 : ie.generateId
          }
        }), $ = mt(
          "text-editor:external-sync",
          "isHydratedStateSynced"
        ), G = q(D);
        $ == null || $.end({
          synced: G,
          sourceType: D.sourceType
        }), G || (it(
          "text-editor:external-sync",
          "applying external hydrated state",
          {
            sourceType: D.sourceType
          }
        ), qt(D)), b == null || b.end({
          applied: !G,
          sourceType: D.sourceType
        });
      },
      { deep: !0 }
    ), Q(
      () => n.editable,
      (b) => {
        c.value && (c.value.setEditable(b, !1), c.value.view.dispatch(
          c.value.state.tr.setSelection(c.value.state.selection).setStoredMarks(c.value.state.storedMarks).setMeta("addToHistory", !1)
        ));
      }
    ), Q(
      et,
      (b) => {
        c.value && c.value.setOptions({ editorProps: b });
      },
      { deep: !0 }
    );
    const Bt = () => {
      const b = c.value;
      b && ["codeBlock", "slashCommands", "contentPaste"].forEach((D) => {
        const $ = b.extensionManager.extensions.find(
          (G) => G.name === D
        );
        $ != null && $.options && ($.options.codeBlockPreferences = n.codeBlockPreferences);
      });
    }, Ct = () => {
      const b = c.value;
      if (!b) return;
      const D = b.extensionManager.extensions.find(
        ($) => $.name === "slashCommands"
      );
      D != null && D.options && (D.options.catalogContributions = n.slashCatalogContributions ?? null);
    };
    Q(
      () => n.codeBlockPreferences,
      () => {
        Bt();
      },
      { deep: !0 }
    ), Q(
      () => n.slashCatalogContributions,
      () => {
        Ct();
      },
      { deep: !0 }
    );
    const mn = yt(di, !1);
    Ht(() => {
      var D, $;
      n.contentProfile === "basic-rich-text" && (mn ? ya : Ye)(n.documentValue, n.contentLimits);
      const b = E({
        content: n.content,
        modelValue: n.modelValue,
        documentValue: n.documentValue,
        contentType: n.contentType,
        hydrateAnnotations: ne.value,
        stableBlockIdentity: {
          types: (D = n.stableBlockIdentity) == null ? void 0 : D.types,
          generateId: ($ = n.stableBlockIdentity) == null ? void 0 : $.generateId
        }
      });
      p.value = b.document, m.value = yn(
        b.document
      ), c.value = Tr(
        {
          content: b.content,
          editorProps: et.value,
          editable: n.editable,
          autofocus: n.autofocus,
          onUpdate: ({ editor: G }) => {
            it("text-editor:update", "editor onUpdate fired"), Ri(G);
          },
          onTransaction: ({
            editor: G,
            transaction: ee
          }) => {
            a("transaction", G), Ni(ee), Li(G, ee), ue();
          },
          onFocus: ({ event: G }) => {
            a("focus", G);
          },
          onBlur: ({ event: G }) => {
            a("blur", G);
          }
        },
        {
          contentProfile: n.contentProfile,
          contentLimits: n.contentLimits,
          onContentIssue: (G) => a("content-issue", G),
          pages: n.contentProfile === "basic-rich-text" ? !1 : void 0,
          dragHandle: n.contentProfile === "basic-rich-text" ? !1 : n.dragHandle,
          shortcutRuntime: i,
          shortcutParentOwner: s,
          extensions: n.extensions,
          getCurrentDocument: () => A(),
          mentions: n.mentions,
          placeholder: n.placeholder,
          placeholderContract: n.placeholderContract,
          stableBlockIdentity: n.stableBlockIdentity,
          starterkitOptions: n.starterkitOptions,
          suggestions: n.suggestions,
          editable: n.editable,
          pagesHeaderFooter: n.pagesHeaderFooter,
          pagesLayout: n.pagesLayout,
          tags: n.tags,
          typography: n.typography,
          assetPipelineRuntime: It,
          filePlatform: z.value,
          codeBlockPreferences: n.codeBlockPreferences,
          slashCatalogContributions: n.slashCatalogContributions,
          filePlatformRuntime: at,
          themeOwner: l
        }
      ), ye(), te(), Bt(), Ct();
    }), rt(() => {
      ve.destroy(), c.value && (c.value.destroy(), c.value = null);
    }), In(
      "editor",
      S(() => c.value)
    );
    const At = S(() => n.extensions.some((b) => {
      const D = b == null ? void 0 : b.name;
      return D === "collaboration" || D === "collaborationCursor";
    }));
    let Gt = 0;
    const Ri = (b) => {
      if (y.value) return;
      const D = mt(
        "text-editor:update",
        "handleContentUpdate",
        {
          outputType: n.outputType,
          contentType: n.contentType,
          isCollaboration: At.value
        }
      ), $ = mt(
        "text-editor:update",
        "getCurrentDocument"
      ), G = A(b);
      $ == null || $.end({
        topLevelNodes: Array.isArray(G.body.content.content) ? G.body.content.content.length : 0
      });
      const ee = mt(
        "text-editor:update",
        "exportEditorContentValue"
      ), ie = be.exportEditorContentValue({
        editor: b,
        document: G,
        outputType: n.outputType
      });
      ee == null || ee.end({
        exportedType: typeof ie
      });
      const xe = mt(
        "text-editor:update",
        "emit events"
      );
      if (a("change", ie), a("update:documentValue", G), a("document-change", G), At.value) {
        const Te = Fa(
          b,
          n.collaborationEmit,
          G
        );
        Te !== void 0 && a("update:modelValue", Te);
      } else
        a("update:modelValue", ie);
      xe == null || xe.end();
      const Oe = mt(
        "text-editor:navigation",
        "refreshNavigationRuntime"
      );
      te(), Oe == null || Oe.end(), D == null || D.end({
        topLevelNodes: Array.isArray(G.body.content.content) ? G.body.content.content.length : 0
      });
    }, Ni = (b) => {
      const D = ir(
        b
      );
      if (!D)
        return;
      const $ = gt({
        ...p.value,
        meta: {
          ...p.value.meta,
          pages: D.pages
        }
      });
      p.value = $, a("update:documentValue", $), a("document-change", $);
    }, Li = (b, D) => {
      if (At.value && n.collaborationEmit === "delta" && D) {
        const $ = D;
        $.steps && $.steps.length > 0 && (Gt++, a("delta", {
          steps: $.steps,
          version: Gt
        }));
      }
    }, Bi = () => {
      var b;
      (b = c.value) == null || b.chain().focus().run();
    }, Ci = () => {
      var b;
      (b = u.value) == null || b.blur();
    }, zi = ti;
    return t({
      editor: c,
      navigationController: Ee,
      rootRef: u,
      focus: Bi,
      blur: Ci,
      getHTML: Y,
      getMarkdown: pe,
      getJSON: Se,
      getDocument: Ce,
      navigate: Me,
      cancelNavigation: Ve,
      getNavigationSnapshot: Je,
      getNavigationDebugSnapshot: Z,
      listNavigationDescriptors: ke,
      syncNavigationFromLocation: Re,
      createShareableFragment: Ge,
      navigateToBlock: re,
      getBlockElement: Qe,
      getRuntimeStatus: Tt,
      getText: d,
      getExcerpt: h,
      setHTML: P,
      setMarkdown: de,
      setJSON: ze,
      setDocument: nt,
      setContent: I,
      intakeFiles: async (b, D = {}) => {
        if (n.contentProfile === "basic-rich-text")
          throw a("content-issue", "备注不支持图片或附件"), new TypeError("basic-rich-text:resources-not-supported");
        return at.intakeFiles({
          files: Array.from(b),
          source: D.source,
          htmlContent: D.htmlContent,
          dropPos: D.dropPos,
          anchorPos: D.anchorPos,
          context: D.context
        });
      },
      clearContent: () => {
        n.contentProfile === "basic-rich-text" && c.value ? (c.value.view.dispatch(
          zi.closeHistory(c.value.state.tr)
        ), c.value.commands.clearContent()) : P("");
      },
      isEmpty: () => {
        var b;
        return ((b = c.value) == null ? void 0 : b.isEmpty) ?? !0;
      }
    }), (b, D) => c.value ? (N(), F("div", st({
      key: 0,
      ref_key: "rootRef",
      ref: u,
      class: [v(r).b(), w.value],
      style: R.value
    }, X.value, {
      onDragoverCapture: we,
      onDropCapture: ge
    }), [
      b.dragHandle ? (N(), He(Ia, {
        key: 0,
        editor: c.value,
        "show-plus": g.value,
        "on-plus-click": V.value,
        "ask-ai-bridge": H.value
      }, null, 8, ["editor", "show-plus", "on-plus-click", "ask-ai-bridge"])) : se("", !0),
      je(b.$slots, "top", { editor: c.value }),
      je(b.$slots, "editor", { editor: c.value }, () => [
        j(v(kr), {
          editor: c.value,
          class: K([v(r).e("content"), J.value.className]),
          style: pt(J.value.style),
          onMousedown: U
        }, null, 8, ["editor", "class", "style"])
      ]),
      x.value ? (N(), He(v(Ca), {
        key: 1,
        editor: c.value,
        contributions: k.value.contributions,
        "should-show": k.value.shouldShow,
        options: k.value.options
      }, null, 8, ["editor", "contributions", "should-show", "options"])) : se("", !0),
      je(b.$slots, "bottom", { editor: c.value })
    ], 16)) : se("", !0);
  }
});
function sf() {
  const e = rs({
    uploading: !1,
    progress: 0,
    uploaded: 0,
    total: 0,
    error: null,
    result: null
  }), t = () => {
    e.uploading = !1, e.progress = 0, e.uploaded = 0, e.total = 0, e.error = null, e.result = null;
  }, o = S(() => e.uploading), n = S(() => e.progress), i = S(() => e.error), s = S(() => e.result);
  return {
    upload: (l, r) => dl(l, r, e, t),
    reset: t,
    state: e,
    isUploading: o,
    progress: n,
    error: i,
    result: s
  };
}
async function dl(e, t, o, n) {
  var s;
  if (!(t != null && t.endpoint))
    throw new Error("Upload endpoint is required");
  if (!e)
    throw new Error("File is required");
  n(), o.uploading = !0;
  let i = e;
  if ((s = t.optimize) != null && s.enabled && e.type.startsWith("image/"))
    try {
      i = await vl(e, t.optimize);
    } catch (a) {
      console.warn("Image optimization failed, using original file:", a);
    }
  return new Promise((a, l) => {
    const r = new XMLHttpRequest();
    r.upload.addEventListener("progress", (u) => {
      var p;
      u.lengthComputable && (o.uploaded = u.loaded, o.total = u.total, o.progress = Math.round(u.loaded / u.total * 100)), (p = t.onProgress) == null || p.call(t, u);
    }), r.upload.addEventListener("load", () => {
      o.progress = 100;
    }), r.addEventListener("error", () => {
      const u = new Error("Upload failed");
      o.error = u, o.uploading = !1, l(u);
    }), r.onreadystatechange = () => {
      if (r.readyState !== XMLHttpRequest.DONE) return;
      const u = fl(r.getAllResponseHeaders()), p = pl(r.responseText), m = {
        data: p,
        status: r.status,
        headers: u
      };
      if (r.status >= 200 && r.status < 300) {
        o.result = m, o.uploading = !1, a(m);
        return;
      }
      const y = ml(r.status, p);
      o.error = y, o.uploading = !1, l(y);
    };
    const f = t.method ?? "POST";
    if (r.open(f, t.endpoint, !0), r.withCredentials = !!t.withCredentials, t.headers)
      for (const [u, p] of Object.entries(t.headers))
        r.setRequestHeader(u, p);
    const c = new FormData();
    if (c.append(t.fieldName ?? "file", i, e.name), t.data)
      for (const [u, p] of Object.entries(t.data))
        c.append(u, p);
    r.send(c);
  });
}
function fl(e) {
  return e ? e.split(`\r
`).filter(Boolean).reduce((t, o) => {
    const n = o.indexOf(": ");
    if (n > 0) {
      const i = o.slice(0, n).trim().toLowerCase(), s = o.slice(n + 2).trim();
      i && (t[i] = s);
    }
    return t;
  }, {}) : {};
}
function pl(e) {
  try {
    return JSON.parse(e);
  } catch {
    return e;
  }
}
function ml(e, t) {
  if (t instanceof Error) return t;
  const o = (typeof t == "object" && t !== null && "message" in t ? String(t.message) : void 0) || (typeof t == "string" ? t : "Upload failed");
  return new Error(`${e || 0}: ${o}`);
}
async function vl(e, t) {
  const { maxWidth: o, maxHeight: n, quality: i = 0.8, outputFormat: s } = t;
  return new Promise((a, l) => {
    const r = new Image(), f = URL.createObjectURL(e);
    r.onload = () => {
      URL.revokeObjectURL(f);
      let { width: c, height: u } = r;
      o && c > o && (u = Math.round(u * o / c), c = o), n && u > n && (c = Math.round(c * n / u), u = n);
      const p = document.createElement("canvas");
      p.width = c, p.height = u;
      const m = p.getContext("2d");
      if (!m) {
        l(new Error("Failed to get canvas context"));
        return;
      }
      m.drawImage(r, 0, 0, c, u);
      const y = s || e.type || "image/jpeg";
      p.toBlob(
        (z) => {
          z ? a(z) : l(new Error("Failed to create blob"));
        },
        y,
        i
      );
    }, r.onerror = () => {
      URL.revokeObjectURL(f), l(new Error("Failed to load image"));
    }, r.src = f;
  });
}
const gl = (e) => ({
  requestId: "navigation-request-unavailable",
  status: "failed",
  target: e.target,
  phase: "failed",
  reason: "target-unavailable",
  settle: null
}), hl = (e = {}) => {
  const t = W(io());
  let o = null;
  const n = () => {
    const u = v(e.controller);
    if (u)
      return u;
    const p = v(e.editor);
    return p ? typeof p.navigate == "function" && typeof p.getSnapshot == "function" && typeof p.subscribe == "function" ? p : p.navigationController ?? null : null;
  }, i = (u) => {
    if (o == null || o(), o = null, !u) {
      t.value = io();
      return;
    }
    t.value = u.getSnapshot(), o = u.subscribe((p) => {
      t.value = p;
    });
  };
  Q(
    () => [v(e.controller), v(e.editor)],
    () => {
      i(n());
    },
    { immediate: !0 }
  ), kt(() => {
    o == null || o(), o = null;
  });
  const s = async (u) => {
    const p = n();
    return p ? p.navigate(u) : gl(u);
  }, a = (u, p) => s({
    ...p,
    source: "bookmark",
    target: {
      kind: "bookmark",
      bookmarkId: u
    }
  }), l = (u, p) => s({
    ...p,
    source: "annotation",
    target: {
      kind: "annotation",
      annotationId: u
    }
  }), r = (u, p) => s({
    ...p,
    source: "search",
    target: {
      kind: "search-hit",
      hitId: u
    }
  }), f = (u, p) => s({
    ...p,
    source: "ai",
    target: {
      kind: "ai-suggestion",
      suggestionId: u
    }
  }), c = (u, p) => s({
    ...p,
    source: "presence",
    target: {
      kind: "presence",
      presenceId: u
    }
  });
  return {
    snapshot: t,
    debug: S(() => Wo(t.value)),
    activeReadingHeadingId: S(
      () => t.value.activeReadingHeadingId
    ),
    async listDescriptors(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.listDescriptors(u)) ?? [];
    },
    async listBookmarkDescriptors() {
      var u;
      return ((u = n()) == null ? void 0 : u.listDescriptors({ kinds: ["bookmark"] })) ?? [];
    },
    navigate: s,
    navigateToBookmark: a,
    navigateToAnnotation: l,
    navigateToCommentThread: l,
    navigateToSearchHit: r,
    navigateToAiSuggestion: f,
    navigateToPresence: c,
    followCollaborator: c,
    cancelNavigation() {
      var u;
      (u = n()) == null || u.cancel();
    },
    async syncFromLocation(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.syncFromLocation(u)) ?? null;
    },
    createShareableFragment(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.createShareableFragment(u)) ?? null;
    }
  };
}, jn = (e) => {
  const t = e.originalLevel ?? e.level;
  return Number.isFinite(t) && t > 0 ? t : 1;
}, bl = (e, t = null, o = 0) => ({
  id: Lt(e),
  label: e.textContent,
  anchor: e,
  parentId: t,
  children: [],
  originalLevel: jn(e),
  depth: o,
  indexLabel: null,
  isActive: !!e.isActive,
  isScrolledOver: !!e.isScrolledOver,
  isExpanded: !0,
  isVisible: !0
}), $n = (e) => e.map((t) => ({
  ...t,
  children: $n(t.children)
})), Hn = (e) => {
  const t = [], o = (n) => {
    for (const i of n)
      t.push(i), i.children.length > 0 && o(i.children);
  };
  return o(e), t;
}, yl = (e = []) => {
  var i;
  const t = [...e].sort((s, a) => s.pos !== a.pos ? s.pos - a.pos : s.itemIndex - a.itemIndex), o = [], n = [
    {
      level: 0,
      node: null
    }
  ];
  for (const s of t) {
    const a = jn(s);
    for (; n.length > 1 && n[n.length - 1].level >= a; )
      n.pop();
    const l = ((i = n[n.length - 1]) == null ? void 0 : i.node) ?? null, r = bl(
      s,
      (l == null ? void 0 : l.id) ?? null,
      l ? l.depth + 1 : 0
    );
    l ? l.children.push(r) : o.push(r), n.push({
      level: a,
      node: r
    });
  }
  return {
    tree: o,
    flat: Hn(o)
  };
}, kl = (e, t = {}) => {
  const o = $n(e), n = Hn(o), i = t.showIndex ?? !1, s = (a, l = []) => {
    a.forEach((r, f) => {
      var p;
      const c = [...l, f + 1], u = i ? c.join(".") : null;
      r.indexLabel = ((p = t.indexStrategy) == null ? void 0 : p.call(t, {
        node: r,
        root: o,
        flat: n
      })) ?? u, r.children.length > 0 && s(r.children, c);
    });
  };
  return s(o), {
    tree: o,
    flat: n
  };
}, wl = (e) => {
  if (typeof window > "u" || typeof document > "u" || e == null)
    return null;
  if (typeof e == "string")
    try {
      return document.querySelector(e);
    } catch {
      return null;
    }
  if (typeof e == "function")
    try {
      return e();
    } catch {
      return null;
    }
  return typeof HTMLElement < "u" && e instanceof HTMLElement ? e : null;
}, an = (e, t) => {
  for (const o of e) {
    if (o.id === t)
      return [o.id];
    const n = an(o.children, t);
    if (n.length > 0)
      return [o.id, ...n];
  }
  return [];
}, xl = (e = [], t = null) => Sn(
  e.map((o) => ({
    id: Lt(o),
    dom: o.dom,
    pos: o.pos,
    order: o.itemIndex,
    isActive: o.isActive
  })),
  {
    scrollContainer: t
  }
), Tl = (e, t) => {
  const o = e.originalLevel || jn(e.anchor);
  return (t.minLevel == null || o >= t.minLevel) && (t.maxLevel == null || o <= t.maxLevel);
}, Rn = (e, t, o = 0, n = null) => {
  const i = [];
  for (const s of e) {
    if (Tl(s, t)) {
      const l = {
        ...s,
        parentId: n,
        depth: o,
        isVisible: !0,
        children: Rn(
          s.children,
          t,
          o + 1,
          s.id
        )
      };
      i.push(l);
      continue;
    }
    i.push(
      ...Rn(s.children, t, o, n)
    );
  }
  return i;
}, Il = (e, t, o) => {
  if (!o)
    return null;
  const n = new Set(t.map((s) => s.id));
  if (n.has(o))
    return o;
  const i = an(e, o);
  for (let s = i.length - 1; s >= 0; s -= 1)
    if (n.has(i[s]))
      return i[s];
  return null;
}, Al = (e, t = {}) => {
  const o = $n(e), n = Rn(o, t), i = Hn(n), s = new Set(t.expandedKeys ?? []), a = Il(o, i, t.activeId), l = a ? i.findIndex((r) => r.id === a) : -1;
  return i.forEach((r, f) => {
    r.isActive = r.id === a, r.isScrolledOver = l >= 0 && f < l, r.isVisible = !0, r.isExpanded = r.children.length === 0 || s.has(r.id);
  }), {
    tree: n,
    flat: i
  };
}, El = { DEV: !1 }, xo = (e) => Array.isArray(e) ? [...e] : [], Sl = (e) => e.filter((t) => t.children.length > 0).map((t) => t.id), De = (e) => An(e) ? e.value : e, To = /* @__PURE__ */ new Set(), _l = () => El.DEV, Vt = (e) => {
  !_l() || To.has(e) || (To.add(e), console.warn(`[useTextEditorToc] ${e}`));
}, mi = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.tableOfContents;
}, Ol = (e) => !!(e && typeof e.on == "function" && typeof e.off == "function"), Io = (e) => {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.id == "string" && typeof t.pos == "number" && typeof t.textContent == "string" && typeof t.level == "number" && typeof t.itemIndex == "number" && typeof t.dom == "object" && t.dom !== null;
}, Rl = (e) => {
  const t = mi(e), o = Array.isArray(t == null ? void 0 : t.content) ? t.content.filter(Io) : [];
  if (o.length > 0)
    return [...o];
  const n = Array.isArray(t == null ? void 0 : t.anchors) ? t.anchors.filter(Io) : [];
  return n.length > 0 ? [...n] : [];
}, Ao = (e) => ["auto", "scroll", "overlay"].includes(e), vi = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return !1;
  const t = window.getComputedStyle(e);
  return (Ao(t.overflowY) || Ao(t.overflow)) && e.scrollHeight > e.clientHeight + 1;
}, Nl = (e) => {
  if (!e || typeof document > "u")
    return null;
  let t = e.parentElement;
  for (; t && !(t === document.body || t === document.documentElement); ) {
    if (vi(t))
      return t;
    const o = t.parentElement;
    t = o instanceof HTMLElement ? o : null;
  }
  return null;
}, Eo = (e, t) => t && e && t.contains(e) && vi(t) ? t : Nl(e) ?? t, Ll = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 16;
  const t = window.getComputedStyle(e), o = Number.parseFloat(t.scrollPaddingTop || "0") || 0, n = Number.parseFloat(t.paddingTop || "0") || 0;
  return o || n;
}, So = (e) => (e == null ? void 0 : e.navigationController) ?? null;
function Bl(e = {}) {
  const t = e.editor !== void 0, o = Be([]), n = W(null), i = W(
    De(e.defaultExpandedKeys) === void 0 ? null : xo(De(e.defaultExpandedKeys))
  ), s = S(
    () => De(e.anchors) !== void 0
  ), a = S(
    () => De(e.expandedKeys) !== void 0
  ), l = S(() => !!De(e.editor)), r = S(
    () => So(De(e.editor))
  ), f = hl({
    controller: r
  });
  Q(
    () => De(e.defaultExpandedKeys),
    (C) => {
      a.value || (C === void 0 ? i.value = null : i.value = xo(C));
    },
    {
      deep: !0
    }
  );
  const c = (C) => {
    if (!C) {
      o.value = [], t || Vt(
        "Provide `anchors` or pass an editor instance with the TableOfContents extension enabled."
      );
      return;
    }
    if (!mi(C)) {
      o.value = [], Vt(
        "The editor is missing `storage.tableOfContents`. Enable the TableOfContents extension before using `useTextEditorToc`."
      );
      return;
    }
    So(C) || Vt(
      "The editor is missing `navigationController`. Use `ZxTextEditor` for platform-backed TOC navigation, or pass standalone `anchors` instead of relying on editor fallback behavior."
    ), o.value = Rl(C);
  };
  Q(
    () => [De(e.editor), s.value],
    ([C, B], L, O) => {
      if (B) {
        o.value = [];
        return;
      }
      if (c(C), !C)
        return;
      if (!Ol(C)) {
        Vt(
          "The editor is missing `on/off` transaction hooks. TOC anchors will be read once but cannot live-refresh from editor transactions."
        );
        return;
      }
      const U = () => {
        c(C);
      };
      C.on("transaction", U), O(() => {
        C.off("transaction", U);
      });
    },
    {
      immediate: !0
    }
  );
  const u = S(() => {
    const C = De(e.anchors);
    return C !== void 0 ? C : o.value;
  }), p = S(
    () => yl(u.value ?? [])
  ), m = S(
    () => wl(De(e.scrollContainer))
  ), y = S(
    () => {
      var C;
      return Eo(
        ((C = u.value[0]) == null ? void 0 : C.dom) ?? null,
        m.value
      );
    }
  ), z = S(
    () => kl(p.value.tree, {
      showIndex: De(e.showIndex) ?? !1,
      indexStrategy: De(e.indexStrategy)
    })
  ), _ = S(
    () => Sl(z.value.flat)
  ), x = S(
    () => r.value ? f.activeReadingHeadingId.value : l.value ? null : n.value
  ), k = () => {
    if (l.value) {
      n.value = null;
      return;
    }
    n.value = xl(
      u.value,
      y.value
    );
  };
  Q(
    u,
    () => {
      l.value || k();
    },
    {
      immediate: !0,
      deep: !0
    }
  ), Q(
    () => [y.value, l.value],
    ([C, B], L, O) => {
      if (B || (k(), typeof window > "u"))
        return;
      const U = C ?? window;
      let oe = 0;
      const he = () => {
        oe || (oe = window.requestAnimationFrame(() => {
          oe = 0, k();
        }));
      };
      U.addEventListener("scroll", he, {
        passive: !0
      }), window.addEventListener("resize", he), O(() => {
        oe && window.cancelAnimationFrame(oe), U.removeEventListener("scroll", he), window.removeEventListener("resize", he);
      });
    },
    {
      immediate: !0
    }
  );
  const g = S(() => {
    const B = De(e.expandedKeys) ?? i.value ?? _.value, L = new Set(B);
    return (De(e.autoExpandActivePath) ?? !0) && x.value && an(z.value.tree, x.value).forEach((O) => {
      L.add(O);
    }), [...L];
  }), V = S(
    () => Al(z.value.tree, {
      activeId: x.value,
      expandedKeys: g.value,
      minLevel: De(e.minLevel),
      maxLevel: De(e.maxLevel)
    })
  ), H = S(() => V.value.tree), T = S(() => V.value.flat), w = S(() => g.value), R = S(
    () => T.value.filter((C) => C.isVisible).length === 0
  ), X = (C) => {
    a.value || (i.value = C);
  };
  return {
    tree: H,
    flat: T,
    activeId: x,
    expandedKeys: w,
    isEmpty: R,
    navigateTo: (C) => {
      var L, O;
      const B = T.value.find((U) => U.id === C);
      if (B) {
        if (r.value) {
          f.navigate({
            source: "outline",
            target: {
              kind: "heading",
              blockId: B.id
            },
            align: "start",
            history: "none"
          });
          return;
        }
        if (l.value) {
          Vt(
            "Editor-backed TOC navigation requires `navigationController`. Legacy block navigation fallback is intentionally disabled."
          );
          return;
        }
        if (n.value = B.id, !!B.anchor.dom)
          try {
            const U = Eo(
              B.anchor.dom,
              y.value
            );
            if (U) {
              const oe = U.getBoundingClientRect(), he = B.anchor.dom.getBoundingClientRect(), le = Ll(U), fe = U.scrollTop + he.top - oe.top - le;
              U.scrollTo({
                top: Math.max(fe, 0),
                behavior: "smooth"
              });
              return;
            }
            (O = (L = B.anchor.dom).scrollIntoView) == null || O.call(L, {
              block: "start",
              behavior: "smooth"
            });
          } catch {
          }
      }
    },
    toggleExpanded: (C) => {
      if (a.value)
        return;
      const B = new Set(i.value ?? _.value);
      B.has(C) ? B.delete(C) : B.add(C), X([...B]);
    },
    expandPath: (C) => {
      if (a.value)
        return;
      const B = new Set(i.value ?? _.value);
      an(z.value.tree, C).forEach((L) => {
        B.add(L);
      }), X([...B]);
    }
  };
}
const Cl = {
  white: "#ffffff"
};
function zl(e) {
  if (e === "transparent" || e === Cl.white) return !0;
  if (!e.startsWith("#")) return !1;
  const t = e.replace("#", ""), o = Number.parseInt(t.slice(0, 2), 16), n = Number.parseInt(t.slice(2, 4), 16), i = Number.parseInt(t.slice(4, 6), 16);
  return (0.299 * o + 0.587 * n + 0.114 * i) / 255 > 0.65;
}
const Ml = ["onClick"], gi = /* @__PURE__ */ Ae({
  name: "ZxTextEditorFontColor",
  __name: "font-color",
  props: {
    editor: {
      type: null,
      required: !0
    },
    mode: {
      type: String,
      default: "both"
    }
  },
  setup(e) {
    const t = e, o = Pe("text-editor-font-color"), n = W(!1), i = W("text"), s = W(null), a = W(null), l = W(null), { binding: r } = bt();
    Q(
      () => t.mode,
      (T) => {
        T && T !== "both" && (i.value = T);
      },
      { immediate: !0 }
    );
    const f = S(() => t.mode === "both"), c = () => {
      if (!t.editor) return;
      const { from: T, to: w } = t.editor.state.selection;
      l.value = { from: T, to: w };
    };
    Q(n, (T) => {
      T && c();
    });
    const u = S(() => {
      var T;
      return (T = r.value) == null ? void 0 : T.target;
    }), p = S(() => i.value === "background" ? Ds : Fs), m = (T) => zl(T), y = (T) => {
      const w = z();
      return w ? w.toLowerCase() === T.toLowerCase() : !1;
    }, z = () => {
      if (!t.editor) return null;
      if (i.value === "background") {
        const w = t.editor.getAttributes("namedHighlight");
        return _(w == null ? void 0 : w.color);
      }
      const T = t.editor.getAttributes("textStyle");
      return _(T == null ? void 0 : T.color);
    }, _ = (T) => Ps(
      T,
      i.value === "background" ? "highlight" : "text"
    ), x = S(() => {
      if (!t.editor) return !0;
      if (i.value === "background")
        return !t.editor.isActive("namedHighlight");
      const T = t.editor.getAttributes("textStyle");
      return !(T != null && T.color);
    }), k = (T) => {
      if (!t.editor) return;
      n.value = !1;
      const w = l.value || t.editor.state.selection;
      i.value === "background" && Vs(T), requestAnimationFrame(() => {
        t.editor && js(t.editor, {
          mode: i.value === "background" ? "highlight" : "text",
          value: T,
          selection: w
        });
      });
    }, g = () => {
      if (!t.editor) return;
      n.value = !1;
      const T = l.value || t.editor.state.selection;
      requestAnimationFrame(() => {
        t.editor && $s(t.editor, {
          mode: i.value === "text" ? "text" : "highlight",
          selection: T
        });
      });
    }, V = async () => {
      var R;
      if (!("EyeDropper" in window)) {
        (R = a.value) == null || R.click();
        return;
      }
      const w = await new window.EyeDropper().open();
      w != null && w.sRGBHex && k(w.sRGBHex);
    }, H = (T) => {
      const w = T.target, R = w == null ? void 0 : w.value;
      R && k(R);
    };
    return (T, w) => (N(), He(v(Qt), {
      visible: n.value,
      "onUpdate:visible": w[8] || (w[8] = (R) => n.value = R),
      variant: "popover",
      trigger: "click",
      "show-arrow": !1,
      placement: "bottom-start",
      width: "auto",
      teleported: !0,
      "append-to": u.value,
      disabled: !v(r),
      "popper-class": v(o).e("popper")
    }, {
      content: ht(() => [
        M("div", {
          class: K(v(o).b()),
          onMousedown: w[7] || (w[7] = Ke(() => {
          }, ["prevent"]))
        }, [
          f.value ? (N(), F("div", {
            key: 0,
            class: K(v(o).e("tabs"))
          }, [
            M("button", {
              class: K([v(o).e("tab"), { "is-active": i.value === "text" }]),
              type: "button",
              onMousedown: w[0] || (w[0] = Ke(() => {
              }, ["prevent"])),
              onClick: w[1] || (w[1] = (R) => i.value = "text")
            }, [
              j(v(Ie), { icon: "lucide:type" }),
              w[9] || (w[9] = M("span", null, "文字颜色", -1))
            ], 34),
            M("button", {
              class: K([v(o).e("tab"), { "is-active": i.value === "background" }]),
              type: "button",
              onMousedown: w[2] || (w[2] = Ke(() => {
              }, ["prevent"])),
              onClick: w[3] || (w[3] = (R) => i.value = "background")
            }, [
              j(v(Ie), { icon: "lucide:highlighter" }),
              w[10] || (w[10] = M("span", null, "背景颜色", -1))
            ], 34)
          ], 2)) : se("", !0),
          M("div", {
            class: K(v(o).e("palette"))
          }, [
            M("button", {
              class: K([v(o).e("clear-option"), { "is-active": x.value }]),
              type: "button",
              onMousedown: w[4] || (w[4] = Ke(() => {
              }, ["prevent"])),
              onClick: g
            }, [
              M("span", {
                class: K([v(o).e("clear-swatch"), { "is-active": x.value }])
              }, [
                M("span", {
                  class: K(v(o).e("clear-line"))
                }, null, 2)
              ], 2),
              M("span", {
                class: K(v(o).e("clear-label"))
              }, "无", 2)
            ], 34),
            M("div", {
              class: K(v(o).e("grid"))
            }, [
              (N(!0), F(Le, null, Fe(p.value, (R, X) => (N(), F("button", {
                key: X,
                class: K([
                  v(o).e("swatch"),
                  {
                    "is-light": m(R),
                    "is-active": y(R)
                  }
                ]),
                style: pt({ backgroundColor: R }),
                type: "button",
                onMousedown: w[5] || (w[5] = Ke(() => {
                }, ["prevent"])),
                onClick: (J) => k(R)
              }, [
                y(R) ? (N(), He(v(Ie), {
                  key: 0,
                  icon: "lucide:check",
                  class: K([v(o).e("check"), { "is-dark": m(R) }])
                }, null, 8, ["class"])) : se("", !0)
              ], 46, Ml))), 128))
            ], 2),
            M("div", {
              class: K(v(o).e("custom-section"))
            }, [
              M("span", {
                class: K(v(o).e("custom-label"))
              }, "自定义", 2),
              M("div", {
                class: K(v(o).e("custom-actions"))
              }, [
                M("label", {
                  class: K(v(o).e("custom-btn"))
                }, [
                  j(v(Ie), { icon: "lucide:plus-circle" }),
                  M("input", {
                    ref_key: "customColorInputRef",
                    ref: a,
                    class: K(v(o).e("custom-input")),
                    type: "color",
                    tabindex: "-1",
                    onInput: H
                  }, null, 34)
                ], 2),
                M("button", {
                  class: K(v(o).e("custom-btn")),
                  type: "button",
                  onMousedown: w[6] || (w[6] = Ke(() => {
                  }, ["prevent"])),
                  onClick: V
                }, [
                  j(v(Ie), { icon: "lucide:pipette" })
                ], 34)
              ], 2)
            ], 2)
          ], 2)
        ], 34)
      ]),
      default: ht(() => [
        M("span", {
          ref_key: "referenceRef",
          ref: s,
          onMousedown: Ke(c, ["prevent"])
        }, [
          je(T.$slots, "default", wt(xt({ isActive: n.value })))
        ], 544)
      ]),
      _: 3
    }, 8, ["visible", "append-to", "disabled", "popper-class"]));
  }
}), rf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorTextColor",
  __name: "text-color",
  props: {
    editor: {}
  },
  setup(e) {
    return (t, o) => (N(), He(gi, {
      editor: e.editor,
      mode: "text"
    }, {
      default: ht((n) => [
        je(t.$slots, "default", wt(xt(n)))
      ]),
      _: 3
    }, 8, ["editor"]));
  }
}), af = /* @__PURE__ */ Ae({
  name: "ZxTextEditorHighlightColor",
  __name: "highlight-color",
  props: {
    editor: {}
  },
  setup(e) {
    return (t, o) => (N(), He(gi, {
      editor: e.editor,
      mode: "background"
    }, {
      default: ht((n) => [
        je(t.$slots, "default", wt(xt(n)))
      ]),
      _: 3
    }, 8, ["editor"]));
  }
}), Dl = /* @__PURE__ */ Ae({
  name: "ZxTextEditorInsertImage",
  __name: "insert-image",
  props: {
    editor: {}
  },
  setup(e) {
    const t = e, o = Pe("text-editor-insert-image"), n = W(null), i = W(!1), s = W([]), { binding: a } = bt(), l = () => {
      var c;
      (c = n.value) == null || c.click();
    }, r = (c) => {
      const u = c.target, p = u.files;
      p && p.length > 0 && t.editor && (p.length === 1 ? t.editor.chain().focus().uploadImage(p[0], "picker").run() : (s.value = Array.from(p), i.value = !0)), u && (u.value = "");
    }, f = () => {
      i.value = !1, s.value = [];
    };
    return (c, u) => (N(), F(Le, null, [
      je(c.$slots, "default", wt(xt({ onClick: l })), void 0, !0),
      M("input", {
        ref_key: "fileInputRef",
        ref: n,
        type: "file",
        class: K(v(o).e("file-input")),
        accept: "image/*",
        multiple: "",
        onChange: r
      }, null, 34),
      i.value && e.editor && v(a) ? (N(), He(ns, {
        key: 0,
        modelValue: i.value,
        "onUpdate:modelValue": u[0] || (u[0] = (p) => i.value = p),
        files: s.value,
        "onUpdate:files": u[1] || (u[1] = (p) => s.value = p),
        mode: "new",
        editor: e.editor,
        "portal-binding": v(a),
        onClose: f
      }, null, 8, ["modelValue", "files", "editor", "portal-binding"])) : se("", !0)
    ], 64));
  }
}), Fl = (e, t) => {
  const o = e.__vccOpts || e;
  for (const [n, i] of t)
    o[n] = i;
  return o;
}, Pl = /* @__PURE__ */ Fl(Dl, [["__scopeId", "data-v-3a55a987"]]), Vl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Pl
}, Symbol.toStringTag, { value: "Module" })), lf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorInsertVideo",
  __name: "insert-video",
  props: {
    editor: {}
  },
  setup(e) {
    const t = e, o = () => {
      t.editor && t.editor.chain().focus().selectAndUploadVideo().run();
    };
    return (n, i) => je(n.$slots, "default", wt(xt({ onClick: o })));
  }
}), cf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorInsertLink",
  __name: "insert-link",
  props: {
    editor: {},
    actionRef: {}
  },
  setup(e) {
    var f;
    const t = e, o = Be(null);
    Q(
      () => t.editor,
      (c, u, p) => {
        p(
          qo(c, (m) => {
            o.value = (m == null ? void 0 : m.editLink) ?? null;
          })
        );
      },
      { immediate: !0, flush: "sync" }
    );
    const n = S(() => t.actionRef ?? o.value), i = Be((f = n.value) == null ? void 0 : f.getView()), s = Gs(), a = S(() => {
      const c = i.value;
      if (!c) return;
      const u = s.formatMany(c.shortcuts, {
        platform: c.platform
      });
      return {
        ...c,
        shortcutText: u.label,
        shortcutAriaLabel: u.ariaLabel
      };
    });
    let l = () => {
    };
    Q(
      n,
      (c) => {
        l();
        const u = () => {
          i.value = c == null ? void 0 : c.getView();
        };
        l = (c == null ? void 0 : c.subscribe(u)) ?? (() => {
        }), u();
      },
      { immediate: !0 }
    ), kt(() => l());
    const r = () => {
      var c;
      return (c = n.value) == null ? void 0 : c.invoke();
    };
    return (c, u) => {
      var p, m, y;
      return je(c.$slots, "default", wt(xt({
        onClick: r,
        disabled: !((p = a.value) != null && p.enabled),
        shortcut: (m = a.value) == null ? void 0 : m.shortcutText,
        shortcutAriaLabel: (y = a.value) == null ? void 0 : y.shortcutAriaLabel
      })));
    };
  }
}), jl = ["onClick", "onMouseover"], $l = ["src", "alt"], uf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorMentionList",
  __name: "mention-list",
  props: {
    items: {},
    command: { type: Function }
  },
  setup(e, { expose: t }) {
    const o = e, n = Pe("text-editor-mention-list"), i = W(0);
    Q(
      () => o.items,
      () => {
        i.value = 0;
      }
    );
    const s = () => {
      i.value = (i.value + o.items.length - 1) % o.items.length;
    }, a = () => {
      i.value = (i.value + 1) % o.items.length;
    }, l = () => {
      r(i.value);
    }, r = (c) => {
      const u = o.items[c];
      u && o.command({
        id: u.value || u.id,
        label: u.label
      });
    };
    return t({
      onKeyDown: ({ event: c }) => c.key === "ArrowUp" ? (s(), !0) : c.key === "ArrowDown" ? (a(), !0) : c.key === "Enter" ? (l(), !0) : !1
    }), (c, u) => e.items.length ? (N(), F("div", {
      key: 0,
      class: K(v(n).b())
    }, [
      M("div", {
        class: K(v(n).e("scroll"))
      }, [
        (N(!0), F(Le, null, Fe(e.items, (p, m) => (N(), F("button", {
          key: p.id || m,
          class: K([v(n).e("item"), v(n).is("selected", m === i.value)]),
          type: "button",
          onClick: (y) => r(m),
          onMouseover: (y) => i.value = m
        }, [
          p.avatar ? (N(), F("span", {
            key: 0,
            class: K(v(n).e("avatar"))
          }, [
            M("img", {
              src: p.avatar,
              alt: p.label
            }, null, 8, $l)
          ], 2)) : se("", !0),
          M("span", {
            class: K(v(n).e("label"))
          }, me(p.label), 3)
        ], 42, jl))), 128))
      ], 2)
    ], 2)) : se("", !0);
  }
}), Hl = ["aria-expanded", "aria-current"], Ul = ["aria-label"], Kl = ["title"], ql = /* @__PURE__ */ Ae({
  name: "ZxTextEditorTocNode",
  __name: "toc-node",
  props: {
    node: {}
  },
  emits: ["navigate", "toggle"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = Pe("text-editor-toc"), s = Xe(o, "node"), a = S(() => s.value.children.length > 0), l = () => {
      n("navigate", s.value);
    }, r = () => {
      n("toggle", s.value);
    };
    return (f, c) => {
      const u = as("TocNode", !0);
      return N(), F("div", {
        class: K([
          v(i).e("node"),
          v(i).is("active", s.value.isActive),
          v(i).is("scrolled", s.value.isScrolledOver)
        ]),
        role: "treeitem",
        "aria-expanded": a.value ? s.value.isExpanded ? "true" : "false" : void 0,
        "aria-current": s.value.isActive ? "location" : void 0
      }, [
        M("div", {
          class: K(v(i).e("row")),
          style: pt({ "--toc-depth": s.value.depth })
        }, [
          a.value ? (N(), F("button", {
            key: 0,
            type: "button",
            class: K([v(i).e("branch"), v(i).is("expanded", s.value.isExpanded)]),
            "aria-label": s.value.isExpanded ? "Collapse section" : "Expand section",
            onClick: Ke(r, ["stop"])
          }, [
            (N(), F("svg", {
              viewBox: "0 0 12 12",
              fill: "currentColor",
              class: K(v(i).e("branch-icon")),
              "aria-hidden": "true"
            }, [...c[2] || (c[2] = [
              M("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M5.84 7.787a.2.2 0 0 0 .32 0l2.6-3.467A.2.2 0 0 0 8.6 4H3.4a.2.2 0 0 0-.16.32z"
              }, null, -1)
            ])], 2))
          ], 10, Ul)) : (N(), F("span", {
            key: 1,
            class: K(v(i).e("spacer")),
            "aria-hidden": "true"
          }, null, 2)),
          je(f.$slots, "item", {
            node: s.value,
            navigate: l,
            toggle: r
          }, () => [
            M("button", {
              type: "button",
              class: K(v(i).e("item")),
              title: s.value.label,
              onClick: l
            }, [
              s.value.indexLabel ? (N(), F("span", {
                key: 0,
                class: K(v(i).e("index"))
              }, me(s.value.indexLabel), 3)) : se("", !0),
              M("span", {
                class: K(v(i).e("label"))
              }, me(s.value.label), 3)
            ], 10, Kl)
          ])
        ], 6),
        a.value && s.value.isExpanded ? (N(), F("div", {
          key: 0,
          class: K(v(i).e("children")),
          role: "group"
        }, [
          (N(!0), F(Le, null, Fe(s.value.children, (p) => (N(), He(u, {
            key: p.id,
            node: p,
            onNavigate: c[0] || (c[0] = (m) => n("navigate", m)),
            onToggle: c[1] || (c[1] = (m) => n("toggle", m))
          }, {
            item: ht((m) => [
              je(f.$slots, "item", st({ ref_for: !0 }, m))
            ]),
            _: 3
          }, 8, ["node"]))), 128))
        ], 2)) : se("", !0)
      ], 10, Hl);
    };
  }
}), df = /* @__PURE__ */ Ae({
  name: "ZxTextEditorToC",
  __name: "toc",
  props: {
    editor: {
      type: Object,
      default: null
    },
    anchors: {
      type: Array,
      default: void 0
    },
    scrollContainer: {
      type: [String, Object, Function],
      default: void 0
    },
    minLevel: {
      type: Number,
      default: void 0
    },
    maxLevel: {
      type: Number,
      default: void 0
    },
    showIndex: {
      type: Boolean,
      default: !1
    },
    indexStrategy: {
      type: Function,
      default: void 0
    },
    expandedKeys: {
      type: Array,
      default: void 0
    },
    defaultExpandedKeys: {
      type: Array,
      default: void 0
    },
    autoExpandActivePath: {
      type: Boolean,
      default: !0
    },
    emptyText: {
      type: String,
      default: "暂无标题"
    }
  },
  emits: ["update:expandedKeys", "item-click"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = Pe("text-editor-toc"), s = W(null), { activeId: a, tree: l, expandedKeys: r, isEmpty: f, navigateTo: c, toggleExpanded: u } = Bl({
      editor: Xe(o, "editor"),
      anchors: Xe(o, "anchors"),
      scrollContainer: Xe(o, "scrollContainer"),
      minLevel: Xe(o, "minLevel"),
      maxLevel: Xe(o, "maxLevel"),
      showIndex: Xe(o, "showIndex"),
      indexStrategy: Xe(o, "indexStrategy"),
      expandedKeys: Xe(o, "expandedKeys"),
      defaultExpandedKeys: Xe(o, "defaultExpandedKeys"),
      autoExpandActivePath: Xe(o, "autoExpandActivePath")
    }), p = async () => {
      var g, V;
      await ft();
      const x = (g = s.value) == null ? void 0 : g.querySelector(
        '[aria-current="location"]'
      ), k = (x == null ? void 0 : x.querySelector(`.${i.e("item")}`)) ?? x;
      (V = k == null ? void 0 : k.scrollIntoView) == null || V.call(k, {
        block: "nearest",
        behavior: "smooth"
      });
    };
    Q(a, (x) => {
      x && p();
    });
    const m = S(() => r.value), y = (x) => {
      const k = new Set(m.value);
      return k.has(x) ? k.delete(x) : k.add(x), [...k];
    }, z = (x) => {
      if (x.children.length === 0)
        return;
      const k = y(x.id);
      n("update:expandedKeys", k), u(x.id);
    }, _ = (x) => {
      c(x.id), n("item-click", x);
    };
    return (x, k) => (N(), F("nav", {
      ref_key: "rootRef",
      ref: s,
      class: K(v(i).b()),
      "aria-label": "Table of contents"
    }, [
      M("div", {
        class: K(v(i).e("content"))
      }, [
        v(f) ? je(x.$slots, "empty", wt(xt({ emptyText: e.emptyText })), () => [
          M("div", {
            class: K(v(i).e("empty"))
          }, me(e.emptyText), 3)
        ], void 0, 0) : (N(), F("div", {
          key: 1,
          class: K(v(i).e("tree")),
          role: "tree"
        }, [
          (N(!0), F(Le, null, Fe(v(l), (g) => (N(), He(ql, {
            key: g.id,
            node: g,
            onNavigate: _,
            onToggle: z
          }, {
            item: ht((V) => [
              je(x.$slots, "item", st({ ref_for: !0 }, V))
            ]),
            _: 3
          }, 8, ["node"]))), 128))
        ], 2))
      ], 2)
    ], 2));
  }
}), hi = (e) => e, bi = hi({
  status: {
    idle: "Ready",
    composing: "Writing instructions",
    prepared: "Ready to generate",
    starting: "Starting generation",
    streaming: "Generating",
    "abort-requested": "Requesting stop",
    "awaiting-review": "Ready to review",
    error: "Generation failed",
    conflict: "Document changed",
    stopped: "Stopped",
    completed: "Completed",
    detached: "Task running in background"
  },
  writingResultOutcome: {
    "document-changed": "The document changed. Regenerate to use the current text.",
    "anchor-lost": "The text at the cursor changed. Place the cursor, then regenerate.",
    "output-truncated": "The response hit the length limit. Copy it or regenerate.",
    "incomplete-result": "The response is incomplete. Copy it or regenerate.",
    "empty-result": "The response is empty. Add a topic and regenerate.",
    "invalid-structure": "The response does not match the requested format. Regenerate.",
    "outline-depth-exceeded": "The outline exceeds the requested depth. Regenerate.",
    "idea-count-mismatch": "The number of ideas differs from the request. Regenerate.",
    "duplicate-ideas": "Some ideas repeat. Regenerate."
  },
  chrome: {
    accept: "Accept",
    reject: "Reject",
    close: "Close",
    followUpPlaceholder: "Add a follow-up…",
    followUpAria: "Add a follow-up",
    reviewAria: "Inline diff review",
    reviewActionsAria: "Inline diff review actions",
    acceptUnavailable: "Accept unavailable: {reason}",
    controlUnavailable: "{label}. Unavailable: {reason}",
    hintAccept: "Accept",
    hintReject: "Reject",
    hintStep: "Step",
    followUpResets: "A follow-up clears {n} staged choice(s).",
    liveDecided: "Paragraph {ordinal}: {state}. {pending} pending.",
    liveAllDecided: "Paragraph {ordinal}: {state}. All changes decided.",
    liveFocused: "Paragraph {ordinal} of {total}: {state}.",
    liveUndecided: "Paragraph {ordinal}: back to pending."
  },
  hunk: {
    keep: "Keep",
    restore: "Keep original",
    undo: "Undo",
    kept: "Kept",
    restored: "Original kept",
    pending: "Pending",
    willDelete: "This paragraph will be removed",
    added: "New paragraph",
    ariaReplace: "Paragraph {ordinal} of {total}: {state}",
    ariaInsert: "Paragraph {ordinal} of {total} (new paragraph): {state}",
    ariaDelete: "Paragraph {ordinal} of {total} (removal): {state}"
  },
  presentation: {
    replacement: {
      title: "Review suggested edit",
      description: "Compare the removed and added text, then choose an action."
    },
    deletion: {
      title: "Review deletion",
      description: "This suggestion removes the selected text."
    },
    "no-change": {
      title: "No changes proposed",
      description: "The candidate matches the selected text. Accept closes the review without changing document history."
    },
    degraded: {
      title: "Limited diff preview",
      description: "The full inline diff cannot be shown safely. Accept is unavailable; reject or close this review."
    },
    conflict: {
      title: "Document changed",
      description: "Accept is unavailable until the review is restarted on the latest document."
    },
    error: {
      title: "Review unavailable",
      description: "The suggestion could not be prepared. Reject or close this review."
    }
  },
  disabledReason: {
    "disposition-pending": "Another review action is in progress.",
    "presentation-unverified": "The suggestion could not be verified.",
    "presentation-unsupported": "This suggestion cannot be reviewed inline.",
    "reject-only": "This review is reject-only.",
    conflict: "The document changed after this review started.",
    "action-unavailable": "This action is not currently available."
  },
  busy: {
    accept: "Accepting suggestion…",
    reject: "Rejecting suggestion…",
    "add-follow-up": "Starting follow-up…",
    close: "Closing preview…"
  },
  skills: {
    "improve-writing": {
      label: "Improve writing",
      description: "Clarify and strengthen the selected text"
    },
    proofread: {
      label: "Proofread",
      description: "Fix grammar and spelling"
    },
    explain: {
      label: "Explain",
      description: "Explain the selected text"
    },
    reformat: {
      label: "Reformat",
      description: "Reformat the selected text"
    }
  },
  slash: {
    "continue-writing": {
      label: "Continue writing"
    },
    "draft-outline": {
      label: "Draft an outline"
    },
    "brainstorm-ideas": {
      label: "Brainstorm ideas"
    }
  },
  surface: {
    askAi: "Ask AI",
    editWithAi: "Edit with AI",
    askAiPlaceholder: "Ask AI to write anything…",
    skills: "Skills",
    skillsSettings: "Skills settings",
    suggestions: "Suggestions",
    stop: "Stop",
    generating: "Generating",
    stopping: "Stopping…",
    insertBelow: "Insert below",
    insert: "Insert",
    copy: "Copy",
    copied: "Copied",
    copyFailed: "Could not copy. Select the text and copy it manually.",
    discard: "Discard",
    reviewRefine: "Review Refine",
    result: "AI result",
    resultActionsAria: "AI result actions",
    reviewResult: "Review AI result",
    continueReview: "Continue Review",
    selectionMenuAria: "Ask AI selection menu",
    skillsListAria: "AI skills",
    contextPlanned: "Will use {n} context blocks",
    contextSubmitted: "Used {n} context blocks",
    contextPrefix: "{n} preceding blocks",
    contextSuffix: "{n} following blocks",
    contextOutline: "outline",
    contextDigest: "summary",
    contextOmitted: "{n} blocks omitted",
    contextFull: "complete authorized text",
    contextPartial: "partial text",
    contextSummarized: "summary coverage",
    contextPolicyExcluded: "{n} blocks excluded by policy",
    contextTokensEstimated: "about {estimated} input tokens",
    contextTokensActual: "{actual} input tokens (estimated {estimated})"
  },
  handoff: {
    "multi-block-selection": "Skills work on one paragraph at a time. Select text within a single paragraph.",
    "explicit-line-break": "Selections with a manual line break are not supported yet. Select text on one line.",
    "unsupported-node": "AI editing is not available for this block type yet.",
    "collapsed-selection": "Select some text first.",
    "task-open": "An AI task is already open. Finish or close it before starting another.",
    "capture-failed": "Could not read this selection. Select the text again and retry.",
    unavailable: "Ask AI could not start for this selection."
  },
  error: {
    generic: "Something went wrong with this AI task.",
    category: {
      transport: "The AI service could not be reached.",
      "provider-adapter": "The AI service returned an error.",
      validation: "This request could not be completed as written.",
      "resource-limit": "This request is larger than the AI service allows.",
      unsupported: "This request is not supported here.",
      "anchor-lost": "The text this task was working on is no longer in the document.",
      conflict: "The document changed while this task was open.",
      abort: "This task could not be stopped."
    },
    code: {
      "transport.network": "Could not connect to the AI service. Check the network, then retry.",
      "transport.provider-unavailable": "The AI service is temporarily unavailable. Retry in a moment.",
      "transport.rate-limited": "Too many requests in a short time. Wait a moment, then retry.",
      "transport.transport-failed": "The request to the AI service failed.",
      "transport.transport-disconnected": "The connection closed before the response finished.",
      "transport.timeout": "The AI service took too long to respond.",
      "provider-adapter.auth-failed": "The AI service rejected the credentials of this site. Contact the site administrator.",
      "provider-adapter.quota-exceeded": "The AI service quota has run out. Contact the site administrator.",
      "provider-adapter.request-rejected": "The AI service rejected this request.",
      "provider-adapter.empty-output": "The AI service returned an empty response.",
      "provider-adapter.protocol": "The AI service returned a response that could not be read.",
      "provider-adapter.internal": "The AI integration hit an internal error.",
      "provider-adapter.handoff-failure": "The response could not be prepared for review.",
      "resource-limit.context-overflow": "The request is too long for the model. Select less text, then try again.",
      "resource-limit.output-truncated": "The response reached the length limit before it finished.",
      "resource-limit.resource-limit": "The response exceeded the allowed size.",
      "validation.content-filtered": "The AI service declined this request. Rephrase it, then try again.",
      "abort.abort-unsupported": "This AI service cannot stop a running task."
    }
  },
  action: {
    submit: "Generate",
    stop: "Stop",
    retry: "Retry",
    restart: "Regenerate",
    supersede: "Replace request",
    "follow-up": "Follow up",
    reveal: "Reveal",
    "review-previous": "Previous change",
    "review-next": "Next change",
    "review-decide": "Decide",
    "review-accept-all": "Accept all",
    "review-reject-all": "Reject all",
    "review-commit": "Apply",
    "review-regenerate": "Regenerate suggestion",
    "review-refine": "Review Refine",
    "retry-review-refine": "Retry refinement",
    close: "Close",
    "edit-prompt": "Edit instructions",
    "reselect-target": "Reselect text",
    "narrow-scope": "Narrow the selection",
    "choose-supported-command": "Choose another command",
    "contact-host": "Contact support"
  },
  actionHint: {
    retry: "Re-sends the same request",
    restart: "Uses the current document",
    "follow-up": "Builds on the previous result",
    "retry-review-refine": "Re-sends the same refinement"
  }
}), Gl = hi({
  status: {
    idle: "就绪",
    composing: "编辑要求",
    prepared: "准备生成",
    starting: "正在启动生成",
    streaming: "正在生成",
    "abort-requested": "正在请求停止",
    "awaiting-review": "等待审阅",
    error: "生成失败",
    conflict: "正文已变化",
    stopped: "已停止",
    completed: "已完成",
    detached: "任务在后台继续"
  },
  writingResultOutcome: {
    "document-changed": "正文已变化，请重新生成以使用当前正文。",
    "anchor-lost": "光标处的内容已变化，请先放置光标再重新生成。",
    "output-truncated": "回复达到长度上限被截断，可复制内容或重新生成。",
    "incomplete-result": "回复尚未完成，可复制内容或重新生成。",
    "empty-result": "回复为空，请补充主题后重新生成。",
    "invalid-structure": "回复不符合所需格式，请重新生成。",
    "outline-depth-exceeded": "大纲层级超出要求，请重新生成。",
    "idea-count-mismatch": "想法数量与要求不符，请重新生成。",
    "duplicate-ideas": "部分想法重复，请重新生成。"
  },
  chrome: {
    accept: "接受",
    reject: "拒绝",
    close: "关闭",
    followUpPlaceholder: "补充追问…",
    followUpAria: "补充追问",
    reviewAria: "行内改写审阅",
    reviewActionsAria: "行内改写审阅操作",
    acceptUnavailable: "无法接受：{reason}",
    controlUnavailable: "{label}。不可用：{reason}",
    hintAccept: "接受",
    hintReject: "拒绝",
    hintStep: "逐段",
    followUpResets: "追问会清空 {n} 项裁决。",
    liveDecided: "第 {ordinal} 段：{state}，还剩 {pending} 段待定。",
    liveAllDecided: "第 {ordinal} 段：{state}，已全部裁决。",
    liveFocused: "第 {ordinal} 段，共 {total} 段：{state}。",
    liveUndecided: "第 {ordinal} 段：已撤回，回到待定。"
  },
  hunk: {
    keep: "采用",
    restore: "留原文",
    undo: "撤回",
    kept: "已采用",
    restored: "留原文",
    pending: "待定",
    willDelete: "此段将删除",
    added: "新增",
    ariaReplace: "第 {ordinal} 段，共 {total} 段：{state}",
    ariaInsert: "第 {ordinal} 段，共 {total} 段（新增段落）：{state}",
    ariaDelete: "第 {ordinal} 段，共 {total} 段（删除）：{state}"
  },
  presentation: {
    replacement: {
      title: "审阅建议改写",
      description: "对比删除与新增内容，然后选择操作。"
    },
    deletion: {
      title: "审阅删除建议",
      description: "这条建议会删除所选文字。"
    },
    "no-change": {
      title: "没有提出改动",
      description: "候选文本与选区相同。接受后会关闭审阅，且不改写文档历史。"
    },
    degraded: {
      title: "仅提供有限预览",
      description: "完整行内 diff 无法安全展示。无法接受；请拒绝或关闭本次审阅。"
    },
    conflict: {
      title: "文档已变化",
      description: "请先按最新文档重新发起审阅，然后才能接受。"
    },
    error: {
      title: "无法审阅",
      description: "建议未能准备完成。请拒绝或关闭本次审阅。"
    }
  },
  disabledReason: {
    "disposition-pending": "另一项审阅操作正在进行。",
    "presentation-unverified": "建议未能通过校验。",
    "presentation-unsupported": "这条建议无法在行内审阅。",
    "reject-only": "本次审阅只能拒绝。",
    conflict: "审阅开始后文档已变化。",
    "action-unavailable": "当前无法执行此操作。"
  },
  busy: {
    accept: "正在接受建议…",
    reject: "正在拒绝建议…",
    "add-follow-up": "正在开始追问…",
    close: "正在关闭预览…"
  },
  skills: {
    "improve-writing": {
      label: "改进写作",
      description: "让所选文字更清晰、更有力"
    },
    proofread: {
      label: "校对",
      description: "修正语法和拼写"
    },
    explain: {
      label: "解释",
      description: "解释所选文字"
    },
    reformat: {
      label: "重排格式",
      description: "重新整理所选文字的格式"
    }
  },
  slash: {
    "continue-writing": {
      label: "继续写"
    },
    "draft-outline": {
      label: "起草大纲"
    },
    "brainstorm-ideas": {
      label: "头脑风暴"
    }
  },
  surface: {
    askAi: "问 AI",
    editWithAi: "用 AI 编辑",
    askAiPlaceholder: "让 AI 写任何内容…",
    skills: "技能",
    skillsSettings: "技能设置",
    suggestions: "建议",
    stop: "停止",
    generating: "生成中",
    stopping: "正在停止…",
    insertBelow: "插入到下方",
    insert: "插入",
    copy: "复制",
    copied: "已复制",
    copyFailed: "复制失败，请手动选中文本复制。",
    discard: "舍弃",
    reviewRefine: "继续改写",
    result: "AI 结果",
    resultActionsAria: "AI 结果操作",
    reviewResult: "审阅 AI 结果",
    continueReview: "继续审阅",
    selectionMenuAria: "问 AI 选区菜单",
    skillsListAria: "AI 技能",
    contextPlanned: "将参考 {n} 段上下文",
    contextSubmitted: "已参考 {n} 段上下文",
    contextPrefix: "光标前 {n} 段",
    contextSuffix: "光标后 {n} 段",
    contextOutline: "大纲",
    contextDigest: "摘要",
    contextOmitted: "省略 {n} 段",
    contextFull: "完整授权正文",
    contextPartial: "部分正文",
    contextSummarized: "摘要覆盖",
    contextPolicyExcluded: "策略排除 {n} 段",
    contextTokensEstimated: "约 {estimated} 输入 token",
    contextTokensActual: "实际 {actual} 输入 token（预估 {estimated}）"
  },
  handoff: {
    "multi-block-selection": "技能一次只处理一个段落。请在同一段内选择文字。",
    "explicit-line-break": "暂不支持包含手动换行的选区。请选择同一行中的文字。",
    "unsupported-node": "这类块暂不支持 AI 编辑。",
    "collapsed-selection": "请先选中一段文字。",
    "task-open": "已有进行中的 AI 任务。请先完成或关闭后再开始新的任务。",
    "capture-failed": "无法读取这次选区。请重新选择文字后再试。",
    unavailable: "无法对这次选区启动问 AI。"
  },
  error: {
    generic: "本次 AI 任务出错了。",
    category: {
      transport: "无法连接 AI 服务。",
      "provider-adapter": "AI 服务返回了错误。",
      validation: "这条请求无法按当前写法完成。",
      "resource-limit": "这条请求超出了 AI 服务的处理上限。",
      unsupported: "此处不支持这条请求。",
      "anchor-lost": "本次任务处理的文字已不在文档中。",
      conflict: "任务进行期间文档已变化。",
      abort: "无法停止本次任务。"
    },
    code: {
      "transport.network": "无法连接 AI 服务。请检查网络后重试。",
      "transport.provider-unavailable": "AI 服务暂时不可用，请稍后重试。",
      "transport.rate-limited": "短时间内请求过多，请稍等后重试。",
      "transport.transport-failed": "发往 AI 服务的请求失败了。",
      "transport.transport-disconnected": "回复完成前连接已断开。",
      "transport.timeout": "AI 服务响应超时。",
      "provider-adapter.auth-failed": "AI 服务拒绝了本站的凭据，请联系站点管理员。",
      "provider-adapter.quota-exceeded": "AI 服务额度已用完，请联系站点管理员。",
      "provider-adapter.request-rejected": "AI 服务拒绝了这条请求。",
      "provider-adapter.empty-output": "AI 服务返回了空回复。",
      "provider-adapter.protocol": "AI 服务返回的内容无法解析。",
      "provider-adapter.internal": "AI 集成内部出错。",
      "provider-adapter.handoff-failure": "回复未能整理成可审阅的结果。",
      "resource-limit.context-overflow": "请求内容超出模型上限。请少选一些文字后再试。",
      "resource-limit.output-truncated": "回复达到长度上限，未能写完。",
      "resource-limit.resource-limit": "回复超出了允许的大小。",
      "validation.content-filtered": "AI 服务拒绝回答这条请求。请换个说法后再试。",
      "abort.abort-unsupported": "这个 AI 服务不支持中途停止。"
    }
  },
  action: {
    submit: "生成",
    stop: "停止",
    retry: "重试",
    restart: "重新生成",
    supersede: "替换请求",
    "follow-up": "追问",
    reveal: "显示任务",
    "review-previous": "上一处",
    "review-next": "下一处",
    "review-decide": "裁决",
    "review-accept-all": "全部接受",
    "review-reject-all": "全部拒绝",
    "review-commit": "应用",
    "review-regenerate": "重新生成建议",
    "review-refine": "继续改写",
    "retry-review-refine": "重试改写",
    close: "关闭",
    "edit-prompt": "修改要求",
    "reselect-target": "重新选择",
    "narrow-scope": "缩小范围",
    "choose-supported-command": "换个命令",
    "contact-host": "联系管理员"
  },
  actionHint: {
    retry: "重发同一请求",
    restart: "按当前正文生成",
    "follow-up": "基于上一次结果",
    "retry-review-refine": "重发同一改写"
  }
}), Wl = (e, t) => e.replace(
  /\{(\w+)\}/g,
  (o, n) => `${t[n] ?? `{${n}}`}`
), Jl = (e) => (e ?? "").toLowerCase().replace(/_/g, "-").startsWith("zh"), Zl = (e) => Jl(e) ? Gl : bi, Xl = (e) => ka.map((t) => {
  const o = e.skills[t.skillId];
  return o ? { ...t, label: o.label, description: o.description } : t;
}), Yl = (e) => wa.map((t) => {
  const o = e.slash[t.id];
  return o ? { ...t, label: o.label } : t;
}), _o = (e, t = bi) => t.handoff[e.reason] ?? t.handoff.unavailable, Un = () => {
  const { lang: e } = fs(), t = S(() => Zl(e.value)), o = S(
    () => Xl(t.value)
  ), n = S(
    () => Yl(t.value)
  );
  return {
    lang: e,
    messages: t,
    defaultSkills: o,
    slashSuggestions: n,
    formatCopy: Wl
  };
};
let Ql = 0;
const ec = (e = `inline-ai-focus-${++Ql}`) => {
  let t = null;
  return {
    create: (o = 1500) => (t = {
      instanceId: e,
      expiresAt: Date.now() + Math.max(0, o),
      revoked: !1
    }, t),
    current: () => t,
    revoke: () => {
      t ? t = { ...t, revoked: !0 } : t = null;
    },
    isActive: (o = t) => !o || o !== t || o.revoked || o.instanceId !== e ? !1 : Date.now() <= o.expiresAt
  };
}, tc = (e) => e instanceof HTMLElement ? !!e.closest('input, textarea, [contenteditable="true"]') : !1, nc = (e) => {
  var i;
  const t = e.event.target, o = tc(t);
  e.claim(), (i = e.focusToken) == null || i.create(), o || e.event.preventDefault();
  const n = e.inputEl ?? (o && t instanceof HTMLElement ? t : null);
  n && typeof n.focus == "function" && n.focus({ preventScroll: !0 });
}, oc = (e) => {
  e.claim();
  const t = e.focusToken.create(), o = typeof document < "u" ? document.activeElement : null;
  return (e.raf ?? requestAnimationFrame)(async () => {
    var a;
    if (!e.focusToken.isActive(t) || (await ((a = e.afterGeometry) == null ? void 0 : a.call(e)), !e.focusToken.isActive(t))) return;
    const i = e.getInput();
    if (!i) return;
    const s = typeof document < "u" ? document.activeElement : null;
    if (s && s !== i && s !== o && !i.contains(s)) {
      const l = s === document.body || s === document.documentElement, r = !!s.closest("[data-inline-ai-focus-root]"), f = s.matches('[contenteditable="true"]');
      if (!l && !r && !f) {
        const c = s.closest(
          'input, textarea, button, select, [contenteditable="true"], [tabindex]'
        );
        if (c && !i.contains(c)) return;
      }
    }
    i.focus({ preventScroll: !0 });
  }), t;
}, ic = (e) => Qo(e), Tn = (e) => e.kind === "geometry" || e.kind === "scroll" || e.kind === "visualViewport", Oo = (e) => e !== !1 && e !== null && e !== void 0, sc = (e) => {
  const t = async () => {
    await ft(), Oo(e.activationKey()) && e.input.value && oc({
      claim: e.claim,
      focusToken: e.focusToken,
      getInput: () => e.input.value
    });
  };
  return Q(
    [e.activationKey, e.input],
    ([o]) => {
      if (!Oo(o)) {
        e.focusToken.revoke();
        return;
      }
      e.input.value && t();
    },
    { flush: "post", immediate: !0 }
  ), rt(() => {
    e.focusToken.revoke();
  }), {
    requestFocus: t
  };
}, rc = {
  key: 0,
  class: "zx-inline-ai-surface__sr-only"
}, ac = ["value", "placeholder", "aria-label", "aria-disabled", "data-testid"], lc = ["disabled", "aria-disabled", "data-testid"], Nn = /* @__PURE__ */ Ae({
  __name: "InlineAiPromptComposer",
  props: {
    modelValue: {},
    variant: {},
    activationKey: { type: [String, Number, Boolean, null] },
    submitEnabled: { type: Boolean },
    shortcut: {},
    inputAriaDisabled: { type: [Boolean, String] },
    placeholder: {},
    accessibleLabel: {}
  },
  emits: ["update:modelValue", "submit", "focus-intent"],
  setup(e, { expose: t, emit: o }) {
    const n = e, i = o, s = Be(null), a = ec(), l = Be(n.modelValue), { messages: r } = Un(), f = S(() => n.variant === "slash"), c = S(() => n.variant === "selection"), u = S(() => !l.value.trim()), p = S(
      () => n.accessibleLabel ?? (f.value ? r.value.surface.askAi : r.value.surface.editWithAi)
    ), m = S(
      () => n.placeholder ?? (f.value ? r.value.surface.askAiPlaceholder : r.value.surface.editWithAi)
    ), y = S(
      () => c.value ? "inline-ai-edit-with-ai" : "inline-ai-surface-prompt"
    ), z = S(
      () => c.value ? "inline-ai-prompt-send" : "inline-ai-surface-send"
    ), _ = S(() => f.value || !u.value), x = S(
      () => c.value ? [
        "zx-inline-ai-prompt-composer",
        "zx-inline-ai-selection-menu__prompt-row"
      ] : [
        "zx-inline-ai-prompt-composer",
        "zx-inline-ai-surface__prompt-row",
        { "zx-inline-ai-surface__prompt-row--slash": f.value }
      ]
    ), k = S(
      () => c.value ? ["zx-inline-ai-prompt-composer__selection-label"] : ["zx-inline-ai-surface__prompt-label"]
    ), g = S(
      () => c.value ? [
        "zx-inline-ai-prompt-composer__control",
        "zx-inline-ai-selection-menu__prompt"
      ] : [
        "zx-inline-ai-prompt-composer__control",
        "zx-inline-ai-surface__prompt",
        { "zx-inline-ai-surface__prompt--slash": f.value }
      ]
    ), V = S(
      () => c.value ? ["zx-inline-ai-selection-menu__send"] : ["zx-inline-ai-surface__send", "zx-inline-ai-surface__hit"]
    ), H = () => {
      const C = s.value;
      if (!C) return;
      const B = getComputedStyle(C), L = Number.parseFloat(B.minHeight) || 0, O = Number.parseFloat(B.maxHeight) || Number.POSITIVE_INFINITY;
      C.style.height = "auto";
      const U = Math.min(
        Math.max(C.scrollHeight, L),
        O
      );
      C.style.height = `${U}px`, C.style.overflowY = C.scrollHeight > O ? "auto" : "hidden";
    };
    sc({
      activationKey: () => n.activationKey,
      claim: () => i("focus-intent"),
      focusToken: a,
      input: s
    }), Q(
      () => n.modelValue,
      (C) => {
        C !== l.value && (l.value = C);
      }
    ), Q([l, () => n.variant], () => {
      ft(H);
    }), Ht(() => {
      H();
    });
    const T = (C) => {
      const B = C.currentTarget;
      l.value = B.value, i("update:modelValue", B.value);
    }, w = () => {
      i("submit");
    }, R = () => {
      w();
    }, X = (C) => {
      C.key !== "Enter" || C.isComposing || C.keyCode === 229 || ic(C) || C.shiftKey || C.metaKey || C.ctrlKey || (C.preventDefault(), w());
    }, J = (C) => {
      nc({
        event: C,
        claim: () => i("focus-intent"),
        inputEl: s.value,
        focusToken: a
      });
      const B = a.current();
      queueMicrotask(() => {
        a.current() === B && a.revoke();
      });
    }, ne = () => {
      if (a.isActive()) {
        a.revoke();
        return;
      }
      i("focus-intent");
    };
    return t({ focus: () => {
      var C;
      (C = s.value) == null || C.focus({ preventScroll: !0 });
    } }), (C, B) => (N(), F("div", {
      class: K(x.value)
    }, [
      M("label", {
        class: K(k.value)
      }, [
        c.value ? se("", !0) : (N(), F("span", rc, me(p.value), 1)),
        M("textarea", {
          ref_key: "inputEl",
          ref: s,
          value: l.value,
          class: K(g.value),
          rows: "1",
          placeholder: m.value,
          "aria-label": p.value,
          "aria-disabled": e.inputAriaDisabled,
          "data-testid": y.value,
          "data-inline-ai-edit-with-ai": "",
          onInput: T,
          onPointerdown: J,
          onFocus: ne,
          onKeydown: X
        }, null, 42, ac)
      ], 2),
      u.value && e.shortcut ? (N(), F("kbd", {
        key: 0,
        class: K(
          c.value ? "zx-inline-ai-selection-menu__shortcut" : "zx-inline-ai-surface__shortcut"
        ),
        "aria-hidden": "true"
      }, me(e.shortcut), 3)) : se("", !0),
      _.value ? (N(), F("button", {
        key: 1,
        type: "button",
        class: K(V.value),
        disabled: c.value ? void 0 : u.value || n.submitEnabled === !1,
        "aria-disabled": c.value && n.submitEnabled === !1 ? "true" : void 0,
        "aria-label": "Send",
        "data-testid": z.value,
        onClick: R
      }, [
        j(v(Ie), {
          icon: "lucide:arrow-up",
          "aria-hidden": "true"
        })
      ], 10, lc)) : se("", !0)
    ], 2));
  }
}), cc = Object.freeze([
  { id: "paragraph", label: "Text", icon: "lucide:type" },
  { id: "heading-1", label: "Heading 1", icon: "lucide:heading-1" },
  { id: "heading-2", label: "Heading 2", icon: "lucide:heading-2" },
  { id: "heading-3", label: "Heading 3", icon: "lucide:heading-3" },
  { id: "heading-4", label: "Heading 4", icon: "lucide:heading-4" },
  { id: "bullet-list", label: "Bulleted list", icon: "lucide:list" },
  { id: "ordered-list", label: "Numbered list", icon: "lucide:list-ordered" },
  { id: "task-list", label: "To-do list", icon: "lucide:list-checks" },
  { id: "code-block", label: "Code", icon: "lucide:code" },
  { id: "blockquote", label: "Quote", icon: "lucide:quote" }
]), uc = Object.freeze([
  { id: "color", label: "Text color", glyph: "A" },
  { id: "bold", label: "Bold", glyph: "B" },
  { id: "italic", label: "Italic", glyph: "I" },
  { id: "underline", label: "Underline", glyph: "U" },
  { id: "clear", label: "Clear formatting", glyph: "Tx" },
  { id: "link", label: "Link", glyph: "a/" },
  { id: "strike", label: "Strikethrough", glyph: "S" },
  { id: "code", label: "Code", glyph: "</>" }
]), Ne = (e, t) => {
  var i;
  if (!(e != null && e.chain)) return !1;
  const o = e.chain().focus(), n = t(o);
  return ((i = n == null ? void 0 : n.run) == null ? void 0 : i.call(n)) ?? !1;
}, dc = (e) => e != null && e.isActive ? e.isActive("heading", { level: 1 }) ? "Heading 1" : e.isActive("heading", { level: 2 }) ? "Heading 2" : e.isActive("heading", { level: 3 }) ? "Heading 3" : e.isActive("heading", { level: 4 }) ? "Heading 4" : e.isActive("bulletList") ? "Bulleted list" : e.isActive("orderedList") ? "Numbered list" : e.isActive("taskList") ? "To-do list" : e.isActive("codeBlock") ? "Code" : e.isActive("blockquote") ? "Quote" : "Normal text" : "Normal text", fc = (e) => e != null && e.isActive ? e.isActive("heading", { level: 1 }) ? "heading-1" : e.isActive("heading", { level: 2 }) ? "heading-2" : e.isActive("heading", { level: 3 }) ? "heading-3" : e.isActive("heading", { level: 4 }) ? "heading-4" : e.isActive("bulletList") ? "bullet-list" : e.isActive("orderedList") ? "ordered-list" : e.isActive("taskList") ? "task-list" : e.isActive("codeBlock") ? "code-block" : e.isActive("blockquote") ? "blockquote" : "paragraph" : "paragraph", pc = (e, t) => {
  switch (t) {
    case "paragraph":
      return Ne(e, (o) => {
        var n;
        return (n = o.setParagraph) == null ? void 0 : n.call(o);
      });
    case "heading-1":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 1 });
      });
    case "heading-2":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 2 });
      });
    case "heading-3":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 3 });
      });
    case "heading-4":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 4 });
      });
    case "bullet-list":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleBulletList) == null ? void 0 : n.call(o);
      });
    case "ordered-list":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleOrderedList) == null ? void 0 : n.call(o);
      });
    case "task-list":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleTaskList) == null ? void 0 : n.call(o);
      });
    case "blockquote":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleBlockquote) == null ? void 0 : n.call(o);
      });
    case "code-block":
      return Ne(e, (o) => {
        var n;
        return (n = o.toggleCodeBlock) == null ? void 0 : n.call(o);
      });
    default:
      return !1;
  }
}, mc = (e, t) => !(e != null && e.isActive) || t === "clear" || t === "color" ? !1 : t === "link" ? e.isActive("link") : e.isActive(t), vc = "var(--zx-semantic-action-focus-ring)", gc = (e, t, o = () => typeof window < "u" ? window.prompt("Link URL", "https://") : null) => {
  var n, i, s, a;
  switch (t) {
    case "color": {
      const l = (i = (n = e == null ? void 0 : e.getAttributes) == null ? void 0 : n.call(e, "textStyle")) == null ? void 0 : i.color;
      return typeof l == "string" && l.length > 0 ? Ne(e, (r) => {
        var f;
        return (f = r.unsetColor) == null ? void 0 : f.call(r);
      }) : Ne(
        e,
        (r) => {
          var f;
          return (f = r.setColor) == null ? void 0 : f.call(r, vc);
        }
      );
    }
    case "bold":
      return Ne(e, (l) => {
        var r;
        return (r = l.toggleBold) == null ? void 0 : r.call(l);
      });
    case "italic":
      return Ne(e, (l) => {
        var r;
        return (r = l.toggleItalic) == null ? void 0 : r.call(l);
      });
    case "underline":
      return Ne(e, (l) => {
        var r;
        return (r = l.toggleUnderline) == null ? void 0 : r.call(l);
      });
    case "strike":
      return Ne(e, (l) => {
        var r;
        return (r = l.toggleStrike) == null ? void 0 : r.call(l);
      });
    case "code":
      return Ne(e, (l) => {
        var r;
        return (r = l.toggleCode) == null ? void 0 : r.call(l);
      });
    case "clear":
      return Ne(e, (l) => {
        var r;
        return (r = l.unsetAllMarks) == null ? void 0 : r.call(l);
      });
    case "link": {
      if ((s = e == null ? void 0 : e.isActive) != null && s.call(e, "link"))
        return Ne(
          e,
          (r) => {
            var f, c, u;
            return (u = (c = (f = r.extendMarkRange) == null ? void 0 : f.call(r, "link")) == null ? void 0 : c.unsetLink) == null ? void 0 : u.call(c);
          }
        );
      const l = (a = o()) == null ? void 0 : a.trim();
      return l ? Ne(
        e,
        (r) => {
          var f, c, u;
          return (u = (c = (f = r.extendMarkRange) == null ? void 0 : f.call(r, "link")) == null ? void 0 : c.setLink) == null ? void 0 : u.call(c, { href: l });
        }
      ) : !1;
    }
    default:
      return !1;
  }
}, hc = ["aria-label"], bc = ["aria-expanded", "aria-disabled"], yc = { class: "zx-inline-ai-selection-menu__turn-into-label" }, kc = ["aria-checked", "data-active", "aria-disabled", "onClick"], wc = {
  class: "zx-inline-ai-selection-menu__turn-into-item-icon",
  "aria-hidden": "true"
}, xc = { class: "zx-inline-ai-selection-menu__turn-into-item-label" }, Tc = {
  key: 1,
  class: "zx-inline-ai-selection-menu__check-spacer",
  "aria-hidden": "true"
}, Ic = {
  class: "zx-inline-ai-selection-menu__format",
  "data-testid": "inline-ai-format-grid",
  role: "toolbar",
  "aria-label": "Text formatting"
}, Ac = ["aria-label", "aria-pressed", "aria-disabled", "data-format", "onClick"], Ec = { class: "zx-inline-ai-selection-menu__skills-header" }, Sc = { class: "zx-inline-ai-selection-menu__section-label" }, _c = ["aria-label"], Oc = ["data-skill-id", "data-testid", "aria-disabled", "onClick"], Rc = ["data-reason", "title"], Nc = { class: "zx-inline-ai-selection-menu__notice-text" }, Lc = {
  key: 1,
  class: "zx-inline-ai-selection-menu__divider",
  "aria-hidden": "true"
}, Bc = ["aria-disabled"], Cc = ["aria-disabled"], zc = {
  class: "zx-ai-authoring-sr-only",
  "data-testid": "inline-ai-capability-reason",
  role: "status",
  "aria-live": "polite"
}, Mc = /* @__PURE__ */ Ae({
  __name: "InlineAiSelectionMenu",
  props: {
    skills: {},
    editor: { default: null },
    disabled: { type: Boolean, default: !1 },
    capabilities: { default: null },
    autoFocusPrompt: { type: Boolean, default: !1 },
    notice: { default: null }
  },
  emits: ["skill-invoke", "edit-with-ai", "prompt-submit", "continue-review", "review-refine", "retain-selection", "prompt-draft"],
  setup(e, { emit: t }) {
    const o = t, n = W(!1), i = W(""), s = W(0), a = W(""), l = W(null);
    let r = null;
    const { messages: f, defaultSkills: c } = Un(), u = S(() => e.skills ?? c.value), p = S(
      () => e.notice ? _o(e.notice, f.value) : ""
    ), m = (te, ye) => {
      var Me;
      if (e.disabled)
        return { enabled: !1, reason: "authority-mismatch" };
      const re = (Me = e.capabilities) == null ? void 0 : Me[te];
      return re || (ye ? { enabled: !0 } : { enabled: !1, reason: "upstream-action-disabled" });
    }, y = S(() => m("format", !0)), z = S(() => m("startAi", !0)), _ = S(() => m("submit", !0)), x = S(() => m("continueReview", !1)), k = S(() => m("reviewRefine", !1)), g = S(
      () => e.capabilities !== null && (x.value.enabled || x.value.reason !== "no-open-task")
    ), V = S(
      () => e.capabilities !== null && (k.value.enabled || k.value.reason !== "no-open-task")
    ), H = S(() => ({
      editor: e.editor,
      revision: s.value
    })), T = S(() => dc(H.value.editor)), w = S(() => fc(H.value.editor)), { text: R } = cn({
      runtime: Ut(),
      bindingId: "textEditor.inlineEdit.open"
    }), X = uc, J = cc, ne = () => {
      s.value += 1;
    }, ae = (te) => {
      te && (a.value = `authoring.capability.${te}`);
    }, C = () => {
      r != null && (clearTimeout(r), r = null);
    }, B = () => {
      if (!y.value.enabled) {
        ae(y.value.reason);
        return;
      }
      C(), n.value = !0;
    }, L = () => {
      C(), r = setTimeout(() => {
        n.value = !1, r = null;
      }, 140);
    }, O = () => {
      C(), n.value = !1;
    };
    Q(
      () => e.editor,
      () => {
        s.value += 1, O();
      }
    ), Q(i, (te) => {
      o("prompt-draft", te);
    }), Q(
      () => e.notice,
      (te) => {
        te && (a.value = _o(
          te,
          f.value
        ));
      },
      { immediate: !0 }
    ), rt(() => {
      O();
    });
    const U = () => {
      if (!y.value.enabled) {
        ae(y.value.reason);
        return;
      }
      n.value ? O() : B();
    }, oe = (te) => {
      if (!y.value.enabled) {
        ae(y.value.reason);
        return;
      }
      pc(e.editor, te), O(), ne();
    }, he = (te) => {
      if (!y.value.enabled) {
        ae(y.value.reason);
        return;
      }
      gc(e.editor, te), ne();
    }, le = (te) => mc(H.value.editor, te), fe = (te) => {
      if (!z.value.enabled) {
        ae(z.value.reason);
        return;
      }
      o("retain-selection"), o("skill-invoke", te);
    }, we = () => {
      const te = i.value.trim();
      if (!te) {
        if (!z.value.enabled) {
          ae(z.value.reason);
          return;
        }
        o("edit-with-ai");
        return;
      }
      if (!_.value.enabled) {
        ae(_.value.reason);
        return;
      }
      o("prompt-submit", te);
    }, ge = () => {
      if (!x.value.enabled) {
        ae(x.value.reason);
        return;
      }
      o("continue-review");
    }, ce = () => {
      var ye;
      const te = i.value.trim();
      if (!te) {
        ae("empty-prompt"), (ye = l.value) == null || ye.focus();
        return;
      }
      if (!k.value.enabled) {
        ae(k.value.reason);
        return;
      }
      o("review-refine", te);
    }, ve = (te) => {
      const ye = te.target;
      ye != null && ye.closest('input, textarea, [contenteditable="true"]') || te.preventDefault();
    }, Ee = () => {
      o("retain-selection");
    }, ue = (te) => te ? void 0 : "true";
    return (te, ye) => (N(), F("div", {
      class: "zx-inline-ai-selection-menu",
      "data-testid": "inline-ai-selection-menu",
      "data-inline-ai-focus-root": "",
      role: "menu",
      "aria-label": v(f).surface.selectionMenuAria,
      onMousedown: ve
    }, [
      M("div", {
        class: "zx-inline-ai-selection-menu__turn-into",
        onMouseenter: B,
        onMouseleave: L
      }, [
        M("button", {
          type: "button",
          class: "zx-inline-ai-selection-menu__turn-into-trigger",
          "data-testid": "inline-ai-turn-into-trigger",
          "aria-haspopup": "menu",
          "aria-expanded": n.value,
          "aria-disabled": ue(y.value.enabled),
          onClick: U,
          onFocus: B
        }, [
          j(v(Ie), {
            class: "zx-inline-ai-selection-menu__turn-into-icon",
            icon: "lucide:type",
            "aria-hidden": "true"
          }),
          M("span", yc, me(T.value), 1),
          j(v(Ie), {
            class: "zx-inline-ai-selection-menu__chevron",
            icon: "lucide:chevron-right",
            "aria-hidden": "true"
          })
        ], 40, bc),
        n.value ? (N(), F("div", {
          key: 0,
          class: "zx-inline-ai-selection-menu__turn-into-panel",
          "data-testid": "inline-ai-turn-into-panel",
          role: "menu",
          "aria-label": "Turn into",
          onMouseenter: B,
          onMouseleave: L
        }, [
          (N(!0), F(Le, null, Fe(v(J), (re) => (N(), F("button", {
            key: re.id,
            type: "button",
            class: "zx-inline-ai-selection-menu__turn-into-item",
            role: "menuitemradio",
            "aria-checked": w.value === re.id,
            "data-active": w.value === re.id ? "true" : "false",
            "aria-disabled": ue(y.value.enabled),
            onClick: (Me) => oe(re.id)
          }, [
            M("span", wc, [
              j(v(Ie), {
                icon: re.icon
              }, null, 8, ["icon"])
            ]),
            M("span", xc, me(re.label), 1),
            w.value === re.id ? (N(), He(v(Ie), {
              key: 0,
              class: "zx-inline-ai-selection-menu__check",
              icon: "lucide:check",
              "aria-hidden": "true"
            })) : (N(), F("span", Tc))
          ], 8, kc))), 128))
        ], 32)) : se("", !0)
      ], 32),
      ye[1] || (ye[1] = M("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      M("div", Ic, [
        (N(!0), F(Le, null, Fe(v(X), (re) => (N(), F("button", {
          key: re.id,
          type: "button",
          class: K(["zx-inline-ai-selection-menu__format-btn", {
            "is-active": le(re.id),
            "is-italic": re.id === "italic",
            "is-underline": re.id === "underline",
            "is-strike": re.id === "strike"
          }]),
          "aria-label": re.label,
          "aria-pressed": le(re.id),
          "aria-disabled": ue(y.value.enabled),
          "data-format": re.id,
          onClick: (Me) => he(re.id)
        }, me(re.glyph), 11, Ac))), 128))
      ]),
      ye[2] || (ye[2] = M("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      M("div", Ec, [
        M("span", Sc, me(v(f).surface.skills), 1),
        j(v(Ie), {
          class: "zx-inline-ai-selection-menu__skills-icon",
          icon: "lucide:sliders-horizontal",
          "aria-hidden": "true",
          "data-testid": "inline-ai-skills-settings-icon"
        })
      ]),
      M("div", {
        class: "zx-inline-ai-selection-menu__skills",
        "data-testid": "inline-ai-skills-list",
        role: "group",
        "aria-label": v(f).surface.skillsListAria
      }, [
        (N(!0), F(Le, null, Fe(u.value, (re) => (N(), F("button", {
          key: re.skillId,
          type: "button",
          class: "zx-inline-ai-selection-menu__skill",
          role: "menuitem",
          "data-skill-id": re.skillId,
          "data-testid": `inline-ai-skill-${re.skillId}`,
          "aria-disabled": ue(z.value.enabled),
          onClick: (Me) => fe(re)
        }, me(re.label), 9, Oc))), 128))
      ], 8, _c),
      e.notice ? (N(), F("p", {
        key: 0,
        class: "zx-inline-ai-selection-menu__notice",
        "data-testid": "inline-ai-selection-notice",
        "data-reason": e.notice.reason,
        title: e.notice.detail,
        role: "note"
      }, [
        j(v(Ie), {
          class: "zx-inline-ai-selection-menu__notice-icon",
          icon: "lucide:info",
          "aria-hidden": "true"
        }),
        M("span", Nc, me(p.value), 1)
      ], 8, Rc)) : se("", !0),
      g.value || V.value ? (N(), F("div", Lc)) : se("", !0),
      g.value ? (N(), F("button", {
        key: 2,
        type: "button",
        class: "zx-inline-ai-selection-menu__skill",
        "data-testid": "inline-ai-continue-review",
        "aria-disabled": ue(x.value.enabled),
        onClick: ge
      }, me(v(f).surface.continueReview), 9, Bc)) : se("", !0),
      V.value ? (N(), F("button", {
        key: 3,
        type: "button",
        class: "zx-inline-ai-selection-menu__skill",
        "data-testid": "inline-ai-review-refine",
        "aria-disabled": ue(k.value.enabled),
        onClick: ce
      }, me(v(f).surface.reviewRefine), 9, Cc)) : se("", !0),
      ye[3] || (ye[3] = M("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      j(Nn, {
        ref_key: "promptComposerRef",
        ref: l,
        modelValue: i.value,
        "onUpdate:modelValue": ye[0] || (ye[0] = (re) => i.value = re),
        variant: "selection",
        "activation-key": e.autoFocusPrompt ? !0 : null,
        "submit-enabled": _.value.enabled,
        shortcut: v(R),
        "input-aria-disabled": ue(
          i.value.trim() ? _.value.enabled : z.value.enabled || _.value.enabled || _.value.reason === "empty-prompt"
        ),
        onSubmit: we,
        onFocusIntent: Ee
      }, null, 8, ["modelValue", "activation-key", "submit-enabled", "shortcut", "input-aria-disabled"]),
      M("div", zc, me(a.value), 1)
    ], 40, hc));
  }
}), Dc = (e = globalThis.matchMedia) => {
  var t;
  try {
    return ((t = e == null ? void 0 : e("(prefers-reduced-motion: reduce)")) == null ? void 0 : t.matches) === !0;
  } catch {
    return !1;
  }
}, yi = (e) => {
  Dc() && (e.style.setProperty("transition", "none"), e.style.setProperty("animation", "none"), e.dataset.inlineAiReducedMotion = "true");
}, Fc = (e) => {
  const t = e.elements.floating;
  t.style.setProperty(
    "--inline-ai-available-width",
    `${Math.max(0, Math.floor(e.availableWidth))}px`
  ), t.style.setProperty(
    "--inline-ai-available-height",
    `${Math.max(0, Math.floor(e.availableHeight))}px`
  ), t.dataset.inlineAiViewportSource = globalThis.visualViewport ? "visualViewport" : "layoutViewport", yi(t);
}, ki = Object.freeze({
  fallbackPlacements: ["top-start"]
}), wi = Object.freeze({
  padding: dn,
  // A retained target can move outside the viewport while its task remains
  // open. For bottom/top placement, crossAxis is the vertical axis: clamp the
  // recovery surface into the visible viewport instead of following the
  // off-screen document coordinate.
  crossAxis: !0
}), xi = Object.freeze({
  padding: dn,
  apply: Fc
}), Pc = (e) => ({
  left: e.left,
  top: e.top,
  width: e.width,
  height: e.height,
  right: e.left + e.width,
  bottom: e.top + e.height,
  x: e.left,
  y: e.top
}), Ti = (e) => ({
  getBoundingClientRect: () => {
    const t = e();
    if (!t)
      return new DOMRect(0, 0, 0, 0);
    const o = Pc(t);
    return {
      ...o,
      toJSON: () => o
    };
  }
}), Vc = () => [
  Wi(dn),
  Ho(ki),
  Ji(wi),
  Zi(xi)
], jc = async (e) => {
  const t = e.getAnchor ?? (() => e.anchor);
  if (!t()) return {};
  const n = Ti(t), { x: i, y: s } = await $o(n, e.floating, {
    strategy: "fixed",
    placement: "bottom-start",
    middleware: Vc()
  });
  yi(e.floating);
  const a = globalThis.visualViewport;
  return e.floating.dataset.inlineAiViewportSource = a ? "visualViewport" : "layoutViewport", {
    position: "fixed",
    // Keep layout coordinates stable and move the overlay on the compositor.
    // Response shells can grow from compact Prompt chrome to a rich review;
    // changing left/top for every measured size would create avoidable CLS.
    left: "0px",
    top: "0px",
    transform: `translate3d(${Math.round(i)}px, ${Math.round(s)}px, 0)`
  };
}, $c = (e) => {
  var u, p;
  const t = Ti(e.getAnchor);
  let o;
  const n = new Promise((m) => {
    o = m;
  });
  let i = !1;
  const s = () => jc({
    getAnchor: e.getAnchor,
    floating: e.floating
  }).then((m) => {
    Object.keys(m).length > 0 && e.onStyle(m), i || (i = !0, o());
  });
  s();
  const a = Gi(t, e.floating, s, {
    ancestorScroll: !0,
    ancestorResize: !0,
    elementResize: !0,
    layoutShift: !0
  }), r = (e.windowLike ?? globalThis).visualViewport, f = () => {
    s();
  };
  (u = r == null ? void 0 : r.addEventListener) == null || u.call(r, "resize", f), (p = r == null ? void 0 : r.addEventListener) == null || p.call(r, "scroll", f), typeof window < "u" && window.addEventListener("resize", f);
  const c = (() => {
    var m, y;
    a(), (m = r == null ? void 0 : r.removeEventListener) == null || m.call(r, "resize", f), (y = r == null ? void 0 : r.removeEventListener) == null || y.call(r, "scroll", f), typeof window < "u" && window.removeEventListener("resize", f), i || (i = !0, o());
  });
  return Object.defineProperty(c, "ready", {
    value: n,
    enumerable: !0
  }), c;
}, Hc = (e) => ({
  position: "fixed",
  left: "0px",
  top: "0px",
  transform: `translate3d(${Math.round(e.left)}px, ${Math.round(
    e.top + e.height + dn
  )}px, 0)`
}), Uc = (e) => {
  var o;
  if (!e || typeof e != "object") return !1;
  const t = (o = e.toJSON) == null ? void 0 : o.call(e);
  return (t == null ? void 0 : t.type) === "nodeRange";
}, Ro = /* @__PURE__ */ new Set([
  "image",
  "iframe",
  "video",
  "imageGroup",
  "codeBlock",
  "horizontalRule"
]), Kc = Object.freeze({
  strategy: "fixed",
  placement: "bottom-start",
  offset: 8,
  flip: ki,
  shift: wi,
  size: xi
}), qc = (e = {}) => Object.freeze({
  ...e,
  ...Kc
}), Gc = (e) => Number.isFinite(e.top) && Number.isFinite(e.left) && e.height > 0 && // Allow zero-width caret rects at line ends; reject empty/invalid boxes.
(e.width > 0 || e.height >= 1), Wc = (e) => {
  const t = Array.from(e).filter(Gc);
  return t.length === 0 ? null : t[t.length - 1];
}, No = (e) => {
  const t = e.clientRects ? Wc(e.clientRects) : null;
  if (t)
    return new DOMRect(t.right, t.top, 0, Math.max(1, t.height));
  const o = Math.max(e.from, e.to), n = o > Math.min(e.from, e.to) ? o - 1 : o, i = e.coordsAtPos(n), s = i.right, a = i.top, l = Math.max(1, i.bottom - i.top);
  return new DOMRect(s, a, 0, l);
}, Jc = (e) => {
  if (typeof window > "u" || typeof document > "u")
    return [];
  const t = window.getSelection();
  if (!t || t.isCollapsed || t.rangeCount === 0)
    return [];
  const o = t.getRangeAt(0), n = e.dom;
  return n && !n.contains(o.commonAncestorContainer) && o.commonAncestorContainer !== n ? [] : Array.from(o.getClientRects());
}, Zc = (e, t) => {
  let o, n;
  return () => {
    var i;
    try {
      if (!e || e.isDestroyed) return null;
      const s = e.view;
      if (!((i = s == null ? void 0 : s.state) != null && i.selection) || typeof s.coordsAtPos != "function")
        return null;
      const a = s.coordsAtPos.bind(s), l = s.state.selection, r = (t == null ? void 0 : t()) ?? (l.from === l.to ? null : { from: l.from, to: l.to });
      if (!r || r.from === r.to) return null;
      const f = `${r.from}:${r.to}`;
      f !== o && (o = f, n = void 0);
      const c = No({
        from: r.from,
        to: r.to,
        coordsAtPos: a
      }), p = l.from === r.from && l.to === r.to ? Jc(s) : [], m = p.length > 0 ? No({
        from: r.from,
        to: r.to,
        coordsAtPos: a,
        clientRects: p
      }) : null;
      m && (n = {
        x: m.x - c.x,
        y: m.y - c.y,
        height: m.height - c.height
      });
      const y = m ?? (n ? new DOMRect(
        c.x + n.x,
        c.y + n.y,
        0,
        Math.max(1, c.height + n.height)
      ) : c);
      return {
        getBoundingClientRect: () => y,
        getClientRects: () => [y]
      };
    } catch {
      return null;
    }
  };
}, Xc = ({
  state: e
}) => {
  var n, i;
  const { selection: t } = e;
  if (t.empty || Uc(t))
    return !1;
  if (t instanceof Cn) {
    const s = t.node;
    if (s && Ro.has(s.type.name))
      return !1;
  }
  const o = (i = (n = t.$from) == null ? void 0 : n.node) == null ? void 0 : i.call(n, t.$from.depth);
  return !(o && Ro.has(o.type.name));
}, Ii = "inlineAiBubbleMenu", Yc = 140, Lo = (e) => e.suppress || e.pointerSelecting && !e.pointerSelectionSettled ? !1 : (e.shouldShow ?? Xc)(e.payload), Qc = (e) => {
  var n, i;
  const t = (n = e.editor) == null ? void 0 : n.view;
  if (!((i = t == null ? void 0 : t.state) != null && i.tr) || typeof t.dispatch != "function") return;
  const o = e.pluginKey ?? Ii;
  t.dispatch(t.state.tr.setMeta(o, e.visible ? "show" : "hide"));
}, Ai = /* @__PURE__ */ new WeakMap(), ff = () => {
  const e = Be(
    null
  ), t = S(
    () => {
      var n;
      return ((n = e.value) == null ? void 0 : n.stage.value) ?? null;
    }
  ), o = {
    stage: t,
    active: S(() => t.value !== null),
    dismiss: () => {
      const n = e.value;
      return (n == null ? void 0 : n.stage.value) == null ? !1 : (n.dismiss(), !0);
    }
  };
  return Ai.set(o, { participant: e }), Object.freeze(o);
}, eu = (e, t) => {
  const o = Ai.get(e);
  if (!o)
    throw new TypeError(
      "[text-editor/authoring-ui] Invalid Inline AI Bubble Escape channel"
    );
  if (o.participant.value && o.participant.value !== t)
    throw new TypeError(
      "[text-editor/authoring-ui] Duplicate Inline AI Bubble Escape owner"
    );
  return o.participant.value = t, () => {
    o.participant.value === t && (o.participant.value = null);
  };
}, tu = Object.freeze([
  "multi-block-selection",
  "explicit-line-break",
  "unsupported-node",
  "collapsed-selection",
  "task-open",
  "capture-failed",
  "unavailable"
]), Bo = (e) => typeof e == "string" && tu.includes(
  e
), nu = (e) => {
  if (typeof e == "string") {
    const t = e.trim();
    return Bo(t) ? { reason: t } : { reason: "unavailable", ...t ? { detail: t } : {} };
  }
  if (e && typeof e == "object") {
    const { reason: t, detail: o } = e, n = Bo(t), i = typeof o == "string" && o.trim() ? o.trim() : !n && typeof t == "string" && t.trim() ? t.trim() : void 0;
    return {
      reason: n ? t : "unavailable",
      ...i ? { detail: i } : {}
    };
  }
  return { reason: "unavailable" };
}, ou = (e) => {
  let t = null;
  return {
    target: e.target,
    get outcome() {
      return t;
    },
    accept() {
      var o;
      return t !== null ? !1 : (t = "accepted", (o = e.onAccept) == null || o.call(e), !0);
    },
    reject(o) {
      var n;
      return t !== null ? !1 : (t = "rejected", ((n = e.onReject) == null ? void 0 : n.call(e, nu(o))) ?? !1);
    }
  };
}, dt = new jo("inlineAiRetainedSelection"), iu = "zx-inline-ai-retained-selection", Kn = (e, t, o) => {
  const n = Math.max(0, Math.min(t, o, e)), i = Math.max(0, Math.min(Math.max(t, o), e));
  return i <= n ? null : { from: n, to: i };
}, su = (e, t) => {
  if (!t) return vt.empty;
  const o = Kn(e.content.size, t.from, t.to);
  return o ? vt.create(e, [
    Zs.inline(o.from, o.to, {
      class: iu
    })
  ]) : vt.empty;
}, ru = () => new Vo({
  key: dt,
  state: {
    init: () => vt.empty,
    apply: (e, t, o, n) => {
      const i = e.getMeta(
        dt
      );
      return (i == null ? void 0 : i.kind) === "clear" ? vt.empty : (i == null ? void 0 : i.kind) === "set" ? su(n.doc, {
        from: i.from,
        to: i.to
      }) : !e.docChanged || t === vt.empty ? t : t.map(e.mapping, e.doc);
    }
  },
  props: {
    decorations(e) {
      return dt.getState(e);
    }
  }
}), au = (e) => {
  const t = e.state;
  return dt.getState(t) !== void 0;
}, Ei = (e) => !e || e.isDestroyed ? !1 : au(e) ? !0 : typeof e.registerPlugin != "function" ? !1 : (e.registerPlugin(ru()), !0), Ln = (e, t) => {
  if (!e || e.isDestroyed || !e.view || !Ei(e)) return !1;
  const { state: o, view: n } = e;
  let i;
  if (!t || t.from === t.to)
    i = o.tr.setMeta(dt, {
      kind: "clear"
    });
  else {
    const s = Kn(o.doc.content.size, t.from, t.to);
    s ? i = o.tr.setMeta(dt, {
      kind: "set",
      from: s.from,
      to: s.to
    }) : i = o.tr.setMeta(dt, {
      kind: "clear"
    });
  }
  return n.dispatch(i), !0;
}, Co = (e) => Ln(e, null), lu = (e) => {
  if (!(e != null && e.state)) return null;
  const t = dt.getState(
    e.state
  );
  if (!t || t === vt.empty) return null;
  let o = Number.POSITIVE_INFINITY, n = Number.NEGATIVE_INFINITY;
  for (const i of t.find())
    o = Math.min(o, i.from), n = Math.max(n, i.to);
  return !Number.isFinite(o) || !Number.isFinite(n) || n <= o ? null : Kn(e.state.doc.content.size, o, n);
}, cu = Object.freeze({ openCount: 0, active: null }), zo = (e) => ({
  anchor: e.anchor ?? e.from,
  head: e.head ?? e.to,
  from: e.from,
  to: e.to
}), Si = (e) => ({
  anchor: e.anchor ?? e.from,
  head: e.head ?? e.to,
  from: e.from,
  to: e.to
}), uu = (e, t) => e.from === t.from && e.to === t.to, du = (e) => e.active !== null && e.active.phase !== "dismissed", fu = (e, t) => {
  var o;
  switch (t.kind) {
    case "end":
      return e.active ? { openCount: e.openCount, active: null } : e;
    case "restore":
      return e.active || t.session.openId !== e.openCount ? e : {
        openCount: e.openCount,
        active: { ...t.session, phase: "active", owned: !1 }
      };
    case "dismiss": {
      if (!e.active || e.active.phase === "dismissed" && !t.range) return e;
      const n = t.range ? zo(t.range) : Si(e.active);
      return {
        openCount: e.openCount,
        active: {
          ...e.active,
          ...n,
          phase: "dismissed",
          owned: !1
        }
      };
    }
    case "chrome-focus":
      return !e.active || e.active.phase === "dismissed" || e.active.owned ? e : {
        openCount: e.openCount,
        active: { ...e.active, owned: !0 }
      };
    case "selection-sync": {
      if ((o = e.active) != null && o.owned && e.active.phase !== "dismissed")
        return e;
      const { eligible: n, range: i } = t;
      if (!n || !i || i.from === i.to)
        return e.active ? { openCount: e.openCount, active: null } : e;
      if (e.active && uu(e.active, i)) return e;
      const s = e.openCount + 1, a = zo(i);
      return {
        openCount: s,
        active: {
          openId: s,
          ...a,
          phase: "active",
          owned: !1
        }
      };
    }
    default:
      return e;
  }
}, pu = (e) => e.active ? { from: e.active.from, to: e.active.to } : null, mu = (e) => e.active ? Si(e.active) : null, vu = (e) => {
  var t;
  return ((t = e.active) == null ? void 0 : t.openId) ?? e.openCount;
}, pf = /* @__PURE__ */ Ae({
  name: "InlineAiBubbleMenu",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    skills: {
      type: Array,
      default: void 0
    },
    disabled: {
      type: Boolean,
      default: !1
    },
    capabilities: {
      type: Object,
      default: null
    },
    /**
     * When true (e.g. product shell brewing/reviewing), hide the selection menu
     * so it does not stack under InlineAiSurface.
     */
    suppress: {
      type: Boolean,
      default: !1
    },
    /**
     * Optional per-editor state/action bridge for the catalog-owned Escape
     * adapter. The Bubble itself never registers a key listener.
     */
    escapeChannel: {
      type: Object,
      default: null
    },
    options: {
      type: Object,
      default: () => ({})
    },
    shouldShow: {
      type: Function,
      default: null
    },
    pluginKey: {
      type: [String, Object],
      default: Ii
    }
  },
  emits: {
    /**
     * `handoff` is the Bubble's receipt: hosts call `accept()` once their own
     * chrome takes over, or `reject(reason)` when the open fails closed so the
     * Bubble restores itself on the same selection with an inline notice.
     */
    "skill-invoke": (e, t, o) => !0,
    "edit-with-ai": (e, t) => !0,
    "prompt-submit": (e, t, o) => !0,
    "continue-review": () => !0,
    "review-refine": (e) => !0,
    "prompt-draft": (e) => !0
  },
  setup(e, {
    emit: t
  }) {
    const o = Pe("inline-ai-bubble-menu"), {
      defaultSkills: n
    } = Un(), i = S(() => e.skills ?? n.value), s = $t(), a = yt("editor", null), l = S(() => e.editor ?? (a == null ? void 0 : a.value) ?? null), {
      binding: r
    } = bt(e.themeOwner), f = S(() => qc(e.options)), c = W(cu), u = S(() => pu(c.value)), p = S(() => mu(c.value)), m = S(() => du(c.value)), y = zn(m), z = S(() => {
      var A;
      return m.value ? "bubble" : ((A = c.value.active) == null ? void 0 : A.phase) === "dismissed" ? "selection" : null;
    }), _ = W(!1);
    let x = null, k = null, g = !1;
    const V = W(null), H = S(() => {
      const A = V.value, E = c.value.active;
      return !A || !E || E.openId !== A.openId ? null : A;
    }), T = W(!1), w = W(!1);
    let R;
    const X = (A) => {
      c.value = fu(c.value, A);
    };
    Q(
      () => {
        var A;
        return ((A = c.value.active) == null ? void 0 : A.owned) === !0 && u.value;
      },
      (A) => {
        var q;
        const E = l.value;
        A && ((q = e.capabilities) == null ? void 0 : q.startAi.enabled) !== !1 && (_.value = Ln(E, A));
      },
      // Pointer focus removes the browser's native selection immediately. Paint
      // the bookmarked range before that focus transfer can invalidate the live
      // selection capability used by the guard above.
      {
        flush: "sync"
      }
    );
    const J = (A = l.value) => {
      _.value && (Co(A), _.value = !1);
    }, ne = () => {
      if (typeof document > "u") return;
      const A = document.getSelection();
      !A || A.rangeCount === 0 || A.collapseToEnd();
    }, ae = () => {
      const A = l.value;
      if (!A) {
        X({
          kind: "selection-sync",
          eligible: !1,
          range: null
        });
        return;
      }
      const E = A.state, q = Lo({
        payload: {
          editor: A,
          state: E
        },
        suppress: e.suppress,
        pointerSelecting: T.value,
        pointerSelectionSettled: w.value,
        shouldShow: e.shouldShow
      }), Y = E == null ? void 0 : E.selection;
      X({
        kind: "selection-sync",
        eligible: q,
        range: Y ? {
          anchor: Y.anchor,
          from: Y.from,
          head: Y.head,
          to: Y.to
        } : null
      });
    }, C = (A) => {
      var Y;
      const E = Lo({
        payload: A,
        suppress: e.suppress,
        pointerSelecting: T.value,
        pointerSelectionSettled: w.value,
        shouldShow: e.shouldShow
      }), q = (Y = A.state) == null ? void 0 : Y.selection;
      return X({
        kind: "selection-sync",
        eligible: E,
        range: q ? {
          anchor: q.anchor,
          from: q.from,
          head: q.head,
          to: q.to
        } : null
      }), m.value;
    }, B = (A) => {
      Qc({
        editor: l.value,
        pluginKey: e.pluginKey,
        visible: A
      });
    }, L = () => {
      R !== void 0 && (clearTimeout(R), R = void 0);
    }, O = () => {
      L(), T.value && (R = setTimeout(() => {
        R = void 0, T.value && (w.value = !0, ae(), B(m.value));
      }, Yc));
    }, U = () => {
      T.value && (w.value = !1), ae(), T.value && (B(m.value), O());
    }, oe = (A) => {
      var q, Y;
      const E = m.value;
      if (X({
        kind: "end"
      }), B(!1), A === "handoff") {
        _.value = !1;
        return;
      }
      if (J(), E) {
        const pe = (q = l.value) == null ? void 0 : q.commands;
        (Y = pe == null ? void 0 : pe.focus) == null || Y.call(pe);
      }
    }, he = (A, E) => {
      var Y, pe, Se, Ce, d, h, I;
      let q = !1;
      if ((Y = A == null ? void 0 : A.state) != null && Y.doc && ((pe = A == null ? void 0 : A.state) != null && pe.tr) && (A != null && A.view))
        try {
          const P = ut.create(A.state.doc, E.anchor, E.head);
          A.view.dispatch(A.state.tr.setSelection(P)), q = !0;
        } catch {
        }
      q || (Ce = (Se = A == null ? void 0 : A.commands) == null ? void 0 : Se.setTextSelection) == null || Ce.call(Se, E.anchor === E.head ? E.head : {
        from: E.from,
        to: E.to
      }), typeof ((d = A == null ? void 0 : A.view) == null ? void 0 : d.focus) == "function" ? A.view.focus() : (I = (h = A == null ? void 0 : A.commands) == null ? void 0 : h.focus) == null || I.call(h);
    }, le = () => {
      if (!m.value) return;
      const A = hn(l.value), E = p.value, q = lu(A), Y = E && q ? {
        anchor: E.anchor > E.head ? q.to : q.from,
        head: E.anchor > E.head ? q.from : q.to,
        from: q.from,
        to: q.to
      } : E;
      X({
        kind: "dismiss",
        range: Y ?? void 0
      }), B(!1), Y && he(A, Y), J();
    }, fe = () => {
      var q, Y, pe;
      if (z.value !== "selection") return;
      const A = hn(l.value), E = p.value;
      X({
        kind: "end"
      }), B(!1), J(), E ? (he(A, {
        anchor: E.head,
        head: E.head,
        from: E.head,
        to: E.head
      }), ne()) : typeof ((q = A == null ? void 0 : A.view) == null ? void 0 : q.focus) == "function" ? A.view.focus() : (pe = (Y = A == null ? void 0 : A.commands) == null ? void 0 : Y.focus) == null || pe.call(Y);
    }, we = {
      stage: z,
      dismiss: () => {
        z.value === "bubble" ? le() : fe();
      }
    };
    let ge;
    Q(() => e.escapeChannel, (A) => {
      ge == null || ge(), ge = A ? eu(A, we) : void 0;
    }, {
      immediate: !0
    }), Q(() => e.suppress, (A) => {
      if (A) {
        L(), w.value = !1, x = null, k = null, V.value = null, X({
          kind: "end"
        }), B(!1), _.value = !1;
        return;
      }
      ae(), B(m.value), J();
    });
    const ce = (A) => {
      var Y, pe;
      if (!m.value) return;
      const E = A.target;
      if (!E || E.closest(".zx-inline-ai-bubble-menu")) return;
      const q = (pe = (Y = l.value) == null ? void 0 : Y.view) == null ? void 0 : pe.dom;
      q != null && q.contains(E) || oe("dismiss");
    }, ve = () => {
      var A;
      m.value && ((A = c.value.active) != null && A.owned) && oe("dismiss");
    }, Ee = (A) => {
      var q, Y;
      if (A.button !== 0 || (q = c.value.active) != null && q.owned) return;
      const E = A.target;
      (Y = E == null ? void 0 : E.closest) != null && Y.call(E, ".zx-inline-ai-bubble-menu") || (T.value = !0, w.value = !1, L(), c.value.active && (X({
        kind: "end"
      }), B(!1)));
    }, ue = () => {
      T.value && (L(), T.value = !1, w.value = !1, ae(), B(m.value));
    }, te = (A) => {
      var q;
      const E = (q = A == null ? void 0 : A.view) == null ? void 0 : q.dom;
      E == null || E.addEventListener("pointerdown", Ee);
    }, ye = (A) => {
      var q;
      const E = (q = A == null ? void 0 : A.view) == null ? void 0 : q.dom;
      E == null || E.removeEventListener("pointerdown", Ee);
    }, re = (A) => {
      var q, Y, pe, Se;
      const E = A;
      E != null && E.state && (E != null && E.view) && Ei(E), (q = E == null ? void 0 : E.off) == null || q.call(E, "focus", ve), (Y = E == null ? void 0 : E.on) == null || Y.call(E, "focus", ve), (pe = E == null ? void 0 : E.off) == null || pe.call(E, "selectionUpdate", U), (Se = E == null ? void 0 : E.on) == null || Se.call(E, "selectionUpdate", U), te(A);
    }, Me = (A) => {
      var q, Y;
      const E = A;
      (q = E == null ? void 0 : E.off) == null || q.call(E, "focus", ve), (Y = E == null ? void 0 : E.off) == null || Y.call(E, "selectionUpdate", U), ye(A);
    };
    Q(l, (A, E) => {
      E && E !== A && J(E), Me(E ?? null), re(A);
    }, {
      immediate: !0
    });
    const Ve = () => {
      Tn({
        kind: "scroll"
      }), Tn({
        kind: "visualViewport"
      }), Tn({
        kind: "geometry"
      });
    }, Je = () => {
      var E;
      const A = (E = r.value) == null ? void 0 : E.target.querySelector(".zx-inline-ai-bubble-menu");
      A instanceof HTMLElement && (A.dataset.inlineAiViewportSource = window.visualViewport ? "visualViewport" : "layoutViewport");
    };
    Ht(() => {
      var A, E;
      Je(), document.addEventListener("pointerdown", ce, !0), window.addEventListener("pointerup", ue, !0), window.addEventListener("pointercancel", ue, !0), window.addEventListener("scroll", Ve, !0), (A = window.visualViewport) == null || A.addEventListener("resize", Ve), (E = window.visualViewport) == null || E.addEventListener("scroll", Ve), re(l.value);
    }), rt(() => {
      var A, E;
      L(), ge == null || ge(), ge = void 0, document.removeEventListener("pointerdown", ce, !0), window.removeEventListener("pointerup", ue, !0), window.removeEventListener("pointercancel", ue, !0), window.removeEventListener("scroll", Ve, !0), (A = window.visualViewport) == null || A.removeEventListener("resize", Ve), (E = window.visualViewport) == null || E.removeEventListener("scroll", Ve), Me(l.value), J();
    });
    const Z = (A) => {
      if (x !== A) return null;
      const E = k;
      return x = null, k = null, E;
    }, ke = (A, E) => {
      var Ce;
      const q = Z(A);
      if (!q) return !1;
      const Y = hn(l.value);
      Co(Y), _.value = !1;
      const pe = c.value.active;
      if (pe && pe.openId !== q.openId) return !1;
      pe && (g = !0, X({
        kind: "end"
      }));
      const Se = (Ce = Y == null ? void 0 : Y.state) == null ? void 0 : Ce.selection;
      return !Se || Se.from !== q.from || Se.to !== q.to || (X({
        kind: "restore",
        session: q
      }), !m.value) ? (B(!1), !1) : (V.value = {
        ...E,
        openId: q.openId
      }, B(!0), !0);
    }, Re = (A) => {
      const E = u.value, q = c.value.active, Y = l.value;
      E && Ln(Y, E), V.value = null, g = !1, x = null, k = null;
      const pe = ou({
        target: E,
        onAccept: () => {
          Z(pe);
        },
        onReject: (Ce) => ke(pe, Ce)
      });
      x = pe, k = q;
      const Se = A(E, pe);
      return g ? (g = !1, Se) : (_.value = !1, oe("handoff"), Se);
    }, Ge = (A) => {
      Re((E, q) => t("skill-invoke", A, E, q));
    }, Qe = () => {
      Re((A, E) => t("edit-with-ai", A, E));
    }, et = (A) => {
      Re((E, q) => t("prompt-submit", A, E, q));
    }, be = () => {
      X({
        kind: "chrome-focus"
      });
    };
    return () => {
      const A = l.value, E = r.value;
      if (!A || !E) return null;
      const q = Object.fromEntries(Object.entries(s).filter(([d]) => d !== "class" && d !== "style")), Y = Zc(A, () => u.value), pe = () => {
        t("continue-review");
      }, Se = (d) => {
        oe("handoff"), t("review-refine", d);
      }, Ce = (d) => {
        t("prompt-draft", d);
      };
      return j(Yo, st({
        editor: A,
        pluginKey: e.pluginKey,
        shouldShow: C,
        options: f.value,
        getReferencedVirtualElement: Y,
        appendTo: () => E.target,
        class: [o.b(), "zx-inline-ai-bubble-menu", s.class],
        style: {
          zIndex: y.value
        }
      }, q), {
        default: () => [j(Mc, {
          key: vu(c.value),
          editor: A,
          skills: i.value,
          disabled: e.disabled,
          capabilities: e.capabilities,
          autoFocusPrompt: !1,
          notice: H.value,
          "onSkill-invoke": Ge,
          "onEdit-with-ai": Qe,
          "onPrompt-submit": et,
          "onContinue-review": pe,
          "onReview-refine": Se,
          "onRetain-selection": be,
          "onPrompt-draft": Ce
        }, null)]
      });
    };
  }
}), mf = /* @__PURE__ */ Ae({
  name: "TextEditorFloatingToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    },
    options: {
      type: Object,
      default: () => ({})
    }
  },
  setup(e) {
    const t = Pe("text-editor-floating-menu"), o = $t(), n = yt("editor", null), i = S(() => e.editor ?? (n == null ? void 0 : n.value) ?? null), {
      binding: s
    } = bt(e.themeOwner);
    return () => {
      const a = i.value, l = s.value;
      if (!a || !l)
        return null;
      const r = Object.fromEntries(Object.entries(o).filter(([f]) => f !== "class" && f !== "style"));
      return j(Js, st({
        editor: a,
        appendTo: () => l.target,
        class: [t.b(), o.class]
      }, e.options, r), {
        default: () => [j(fi, {
          themeOwner: e.themeOwner,
          editor: a,
          surface: "floating",
          contributions: e.contributions,
          includeDefaultContribution: e.includeDefaultContribution,
          style: o.style
        }, null)]
      });
    };
  }
}), gu = ["value"], hu = ["value"], bu = ["value"], yu = ["value"], vf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorFontFamilySelector",
  __name: "font-family-selector",
  props: {
    fontSizes: { default: () => [...Us] },
    fontFamilies: { default: () => [...Hs] }
  },
  setup(e) {
    const t = Pe("text-editor-font-selector"), o = yt("editor"), n = S(() => o != null && o.value && o.value.getAttributes("textStyle").fontSize || ""), i = S(() => o != null && o.value && o.value.getAttributes("textStyle").fontFamily || ""), s = (r, ...f) => {
      var k, g, V, H;
      if (!(o != null && o.value)) return !1;
      const c = (g = (k = o.value).chain) == null ? void 0 : g.call(k), u = ((V = c == null ? void 0 : c.focus) == null ? void 0 : V.call(c)) ?? c, p = u, m = p == null ? void 0 : p[r];
      if (typeof m == "function") {
        const T = m.apply(u, f);
        return ((H = T == null ? void 0 : T.run) == null ? void 0 : H.call(T)) ?? !1;
      }
      const y = o.value.commands, z = y.focus;
      typeof z == "function" && z.call(y);
      const _ = y[r];
      if (typeof _ != "function")
        return !1;
      const x = _.apply(y, f);
      return typeof x == "boolean" ? x : !0;
    }, a = (r) => {
      const f = r.target.value;
      o != null && o.value && (f ? s("setFontSize", f) : s("unsetFontSize"));
    }, l = (r) => {
      const f = r.target.value;
      o != null && o.value && (f ? s("setFontFamily", f) : s("unsetFontFamily"));
    };
    return (r, f) => (N(), F("div", {
      class: K(v(t).b())
    }, [
      M("select", {
        class: K(v(t).e("size-select")),
        value: n.value,
        onChange: a
      }, [
        f[0] || (f[0] = M("option", { value: "" }, "默认", -1)),
        (N(!0), F(Le, null, Fe(e.fontSizes, (c) => (N(), F("option", {
          key: c,
          value: c
        }, me(c), 9, hu))), 128))
      ], 42, gu),
      M("select", {
        class: K(v(t).e("family-select")),
        value: i.value,
        onChange: l
      }, [
        f[1] || (f[1] = M("option", { value: "" }, "默认字体", -1)),
        (N(!0), F(Le, null, Fe(e.fontFamilies, (c) => (N(), F("option", {
          key: c.value,
          value: c.value
        }, me(c.label), 9, yu))), 128))
      ], 42, bu)
    ], 2));
  }
}), gf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorFloatingComments",
  __name: "floating-comments",
  props: {
    editor: {},
    threads: {},
    comments: {},
    activeAnnotationId: {},
    activeCommentId: {},
    currentUser: {},
    readonly: { type: Boolean }
  },
  emits: ["activate", "create", "edit", "delete", "resolve", "reply"],
  setup(e) {
    const t = Pe("text-editor-floating-comments");
    return (o, n) => (N(), F("div", {
      class: K(v(t).b())
    }, [
      je(o.$slots, "default", {}, () => [
        M("div", {
          class: K(v(t).e("placeholder"))
        }, " FloatingComments 组件需要由应用层提供实现 ", 2)
      ])
    ], 2));
  }
}), ku = ["value", "placeholder", "disabled", "onKeydown"], hf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorCommentEditor",
  __name: "comment-editor",
  props: {
    content: { default: "" },
    editable: { type: Boolean, default: !0 },
    placeholder: { default: "输入评论..." },
    showToolbar: { type: Boolean },
    autofocus: { type: Boolean }
  },
  emits: ["submit", "cancel", "update:content"],
  setup(e, { emit: t }) {
    const o = Pe("text-editor-comment-editor"), n = t, i = (l) => {
      const r = l.target.value;
      n("update:content", r);
    }, s = () => {
      n("submit", e.content);
    }, a = () => {
      n("cancel");
    };
    return (l, r) => (N(), F("div", {
      class: K(v(o).b())
    }, [
      je(l.$slots, "default", {}, () => [
        M("textarea", {
          class: K(v(o).e("textarea")),
          value: e.content,
          placeholder: e.placeholder,
          disabled: !e.editable,
          onInput: i,
          onKeydown: [
            oo(Ke(s, ["ctrl"]), ["enter"]),
            oo(a, ["escape"])
          ]
        }, null, 42, ku),
        M("div", {
          class: K(v(o).e("actions"))
        }, [
          M("button", {
            type: "button",
            class: K(v(o).e("cancel")),
            onClick: a
          }, " 取消 ", 2),
          M("button", {
            type: "button",
            class: K(v(o).e("submit")),
            onClick: s
          }, " 提交 ", 2)
        ], 2)
      ])
    ], 2));
  }
}), wu = ["onClick", "onMouseenter"], bf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorEmbedList",
  __name: "embed-list",
  props: {
    items: {},
    query: {},
    command: { type: Function }
  },
  setup(e, { expose: t }) {
    const o = Pe("text-editor-embed-list"), n = e, i = W(0);
    Q(
      () => n.items,
      () => {
        i.value = 0;
      }
    );
    const s = (l) => {
      const r = n.items[l];
      r && n.command(r);
    };
    return t({ onKeyDown: (l) => l.key === "ArrowUp" ? (i.value = (i.value - 1 + n.items.length) % n.items.length, !0) : l.key === "ArrowDown" ? (i.value = (i.value + 1) % n.items.length, !0) : l.key === "Enter" ? (s(i.value), !0) : !1 }), (l, r) => (N(), F("div", {
      class: K(v(o).b())
    }, [
      e.items.length === 0 ? (N(), F("div", {
        key: 0,
        class: K(v(o).e("empty"))
      }, me(e.query ? "未找到匹配的文档" : "输入关键词搜索文档"), 3)) : se("", !0),
      (N(!0), F(Le, null, Fe(e.items, (f, c) => (N(), F("button", {
        key: f.name,
        type: "button",
        class: K([v(o).e("item"), v(o).is("selected", c === i.value)]),
        onClick: (u) => s(c),
        onMouseenter: (u) => i.value = c
      }, [
        M("span", {
          class: K(v(o).e("icon"))
        }, "📄", 2),
        M("span", {
          class: K(v(o).e("title"))
        }, me(f.title), 3)
      ], 42, wu))), 128))
    ], 2));
  }
}), xu = (e) => {
  if (typeof e == "boolean") return e;
  if (typeof process < "u" && process.env.VITEST === "true")
    return !0;
  if (typeof window < "u" && typeof window.matchMedia == "function")
    try {
      return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch {
      return !1;
    }
  return !1;
}, Tu = () => typeof Intl < "u" && typeof Intl.Segmenter == "function" ? new Intl.Segmenter(void 0, { granularity: "word" }) : "word", Iu = (e) => {
  const t = Tu();
  return t !== "word" ? Array.from(t.segment(e), ({ segment: o }) => o) : e.match(/\s+|[^\s]+/gu) ?? [];
}, Au = (e, t = {}) => {
  const o = W(""), n = W(!1), i = W(0);
  let s = "", a = 0, l = [], r = !1;
  const f = t.delayInMs === null ? 0 : Math.max(0, t.delayInMs ?? 10), c = typeof requestAnimationFrame == "function" ? requestAnimationFrame : (_) => setTimeout(() => _(Date.now()), 16), u = S(
    () => i.value === 0 && !n.value && o.value === qe(e)
  ), p = () => {
    a += 1, l = [], r = !1, i.value = 0, n.value = !1;
  }, m = (_) => {
    p(), s = _, o.value = _;
  }, y = (_) => {
    if (r || _ !== a || l.length === 0) return;
    r = !0, c(() => {
      if (_ !== a) return;
      r = !1;
      const k = l.shift();
      if (k !== void 0 && (o.value += k), i.value = l.length, l.length === 0) {
        n.value = !1, qe(e) || (s = "", o.value = "");
        return;
      }
      setTimeout(() => y(_), f);
    });
  }, z = (_) => {
    const x = Iu(_);
    if (x.length === 0) return;
    const k = a;
    l.push(...x), i.value = l.length, n.value = !0, y(k);
  };
  return Q(
    () => qe(e),
    (_) => {
      if (xu(qe(t.snap))) {
        m(_);
        return;
      }
      if (!_) {
        if (i.value > 0 || n.value)
          return;
        p(), s = "", o.value = "";
        return;
      }
      _.startsWith(s) || (p(), s = "", o.value = "");
      const x = _.slice(s.length);
      x && (s = _, z(x));
    },
    { immediate: !0 }
  ), rt(() => {
    p();
  }), {
    displayedText: o,
    isRevealing: n,
    isCaughtUp: u
  };
}, Eu = ["innerHTML"], Su = /* @__PURE__ */ Ae({
  name: "ZxTextEditorView",
  __name: "text-editor-view",
  props: {
    document: {},
    typography: { default: () => ({
      root: { fontSize: { cssValue: "1em", displayValue: "1em" } }
    }) }
  },
  setup(e) {
    const t = e, o = S(
      () => Jo(
        ei({ override: t.typography })
      )
    ), n = S(
      () => t.document ? En(t.document, { profile: "safe-html" }) : ""
    );
    return (i, s) => (N(), F("div", {
      class: K(["zx-text-editor-view", o.value.className]),
      style: pt(o.value.style)
    }, [
      n.value ? (N(), F("div", {
        key: 0,
        class: "ProseMirror zx-text-editor__prose",
        innerHTML: n.value
      }, null, 8, Eu)) : se("", !0)
    ], 6));
  }
}), _u = { class: "zx-field-ai__context" }, Ou = { class: "zx-inline-ai-surface__status" }, Ru = ["disabled"], Nu = ["disabled"], Lu = ["checked", "disabled", "data-context-id", "onChange"], Bu = {
  key: 1,
  "aria-label": "本次已提供的信息",
  "data-testid": "field-ai-receipt"
}, Cu = {
  key: 2,
  role: "status",
  "data-testid": "field-ai-notice"
}, zu = /* @__PURE__ */ Ae({
  inheritAttrs: !1,
  __name: "FieldAIContext",
  props: {
    choices: {},
    selectedIds: {},
    receipt: {},
    notices: {},
    disabled: { type: Boolean },
    busy: { type: Boolean }
  },
  emits: ["update:selectedIds", "draft"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = {
      policy: "策略",
      budget: "预算",
      unavailable: "不可用",
      empty: "空值"
    }, s = (a, l) => {
      const r = l.target.checked;
      n(
        "update:selectedIds",
        r ? [...o.selectedIds, a] : o.selectedIds.filter((f) => f !== a)
      );
    };
    return (a, l) => (N(), F("div", _u, [
      M("p", Ou, " AI 生成，采用前请核对。" + me(e.busy ? "生成中，预览尚未校验。" : ""), 1),
      l[2] || (l[2] = M("p", { class: "zx-inline-ai-surface__status" }, " 仅保护本次编辑中已知的个人信息；手输内容和重新加载的历史信息请自行核对。 ", -1)),
      M("button", {
        type: "button",
        disabled: e.disabled,
        "data-testid": "field-ai-draft-context",
        onClick: l[0] || (l[0] = (r) => n("draft"))
      }, " 根据表单信息起草 ", 8, Ru),
      e.choices.length ? (N(), F("fieldset", {
        key: 0,
        disabled: e.disabled
      }, [
        l[1] || (l[1] = M("legend", null, "补充上下文（可选）", -1)),
        (N(!0), F(Le, null, Fe(e.choices, (r) => (N(), F("label", {
          key: r.id
        }, [
          M("input", {
            type: "checkbox",
            checked: e.selectedIds.includes(r.id),
            disabled: r.disabled,
            "data-context-id": r.id,
            onChange: (f) => s(r.id, f)
          }, null, 40, Lu),
          Yt(" " + me(r.label), 1)
        ]))), 128))
      ], 8, Nu)) : se("", !0),
      e.receipt ? (N(), F("ul", Bu, [
        (N(!0), F(Le, null, Fe(e.receipt.included, (r) => (N(), F("li", {
          key: r.id
        }, me(r.label) + "：" + me(r.masked ? "已脱敏" : "已提供"), 1))), 128)),
        (N(!0), F(Le, null, Fe(e.receipt.withheld, (r) => (N(), F("li", {
          key: r.id
        }, me(r.label) + "：未提供（" + me(i[r.reason]) + "） ", 1))), 128))
      ])) : se("", !0),
      e.notices.length ? (N(), F("p", Cu, " 部分信息未提供，可在上方选择或补充后重新生成。 ")) : se("", !0)
    ]));
  }
}), Mu = ["id", "aria-busy"], Du = { class: "zx-inline-ai-surface__slash-header" }, Fu = { class: "zx-inline-ai-surface__slash-title" }, Pu = {
  key: 0,
  class: "zx-field-ai__scope"
}, Vu = {
  key: 0,
  class: "zx-inline-ai-surface__error zx-field-ai__note",
  role: "alert"
}, ju = { class: "zx-inline-ai-surface__slash-suggestion-list" }, $u = ["disabled", "data-field-ai-suggestion", "onClick"], Hu = {
  key: 1,
  class: "zx-inline-ai-surface__result-footer"
}, Uu = { class: "zx-inline-ai-surface__result-commands" }, Ku = {
  key: 1,
  class: "zx-inline-ai-surface__response"
}, qu = {
  key: 0,
  class: "zx-inline-ai-surface__pondering",
  "data-testid": "field-ai-pondering"
}, Gu = { class: "zx-inline-ai-surface__pondering-lead" }, Wu = {
  class: "zx-inline-ai-surface__pondering-icon",
  "aria-hidden": "true"
}, Ju = {
  key: 1,
  class: "zx-inline-ai-surface__result"
}, Zu = { class: "zx-inline-ai-surface__result-body" }, Xu = {
  class: "zx-inline-ai-surface__avatar",
  "aria-hidden": "true"
}, Yu = { class: "zx-inline-ai-surface__result-content" }, Qu = {
  key: 0,
  class: "zx-field-ai__candidate",
  "aria-label": "AI 候选内容",
  "data-testid": "field-ai-candidate"
}, ed = {
  key: 0,
  class: "zx-inline-ai-surface__status"
}, td = {
  key: 1,
  class: "zx-inline-ai-surface__preview zx-field-ai__stream",
  "data-testid": "field-ai-stream"
}, nd = {
  key: 0,
  class: "zx-inline-ai-surface__caret",
  "aria-hidden": "true"
}, od = {
  key: 2,
  class: "zx-inline-ai-surface__error",
  role: "alert"
}, id = {
  key: 3,
  class: "zx-inline-ai-surface__status",
  role: "status"
}, sd = {
  key: 4,
  class: "zx-inline-ai-surface__status zx-field-ai__hint"
}, rd = {
  key: 0,
  class: "zx-inline-ai-surface__result-footer"
}, ad = { class: "zx-inline-ai-surface__result-icons" }, ld = {
  key: 1,
  class: "zx-inline-ai-surface__result-controls zx-field-ai__controls"
}, cd = {
  class: "zx-field-ai__control-row",
  role: "group",
  "aria-label": "候选操作"
}, ud = {
  key: 1,
  class: "zx-inline-ai-surface__follow-up zx-field-ai__follow-up",
  "data-testid": "field-ai-follow-up"
}, dd = { class: "zx-inline-ai-surface__result-commands" }, fd = ["disabled", "aria-keyshortcuts"], pd = {
  class: "zx-inline-ai-surface__kbd",
  "aria-hidden": "true"
}, md = /* @__PURE__ */ Ae({
  __name: "FieldAIPopover",
  props: {
    controller: {},
    themeOwner: {},
    anchor: { type: Function }
  },
  emits: ["focusin", "focusout"],
  setup(e, { expose: t, emit: o }) {
    const n = e, i = o, {
      open: s,
      phase: a,
      instruction: l,
      scope: r,
      target: f,
      candidate: c,
      refinementPreview: u,
      stream: p,
      error: m,
      stale: y,
      submitted: z,
      empty: _,
      suggestions: x,
      busy: k,
      canAccept: g,
      available: V,
      selectedContextIds: H,
      contextChoices: T,
      receipt: w,
      notices: R,
      draftFromContext: X,
      start: J,
      cancel: ne,
      stop: ae,
      generate: C,
      regenerate: B,
      accept: L
    } = n.controller, O = ls(), U = `${O}-suggestions`, { binding: oe } = bt(n.themeOwner), he = zn(() => s.value), le = W(), fe = W(""), we = S(() => z.value ? "response" : "composer"), ge = S(
      () => !!f.value && !y.value && !k.value && V.value
    ), ce = S(
      () => s.value && we.value === "composer" ? "composer" : !1
    ), ve = S(
      () => r.value === "selection" ? "想怎么改所选文字？" : _.value ? "想写什么？例如：说明岗位职责、交接事项…" : "想怎么改？例如：更简洁、改成要点…"
    ), Ee = () => {
      ge.value && C();
    }, ue = () => {
      const h = fe.value.trim();
      !h || k.value || y.value || (fe.value = "", C(h));
    }, { displayedText: te } = Au(
      () => c.value ? "" : p.value
    ), ye = Ut(), { text: re, aria: Me } = cn({
      runtime: ye,
      bindingId: "textEditor.review.accept"
    }), Ve = typeof navigator < "u" && /Mac|iPhone|iPad|iPod/.test(navigator.platform ?? ""), Je = S(
      () => re.value || (Ve ? "⌘ ⏎" : "Ctrl ⏎")
    ), Z = S(
      () => Me.value || (Ve ? "Meta+Enter" : "Control+Enter")
    ), ke = (h) => {
      if (!Qo(h)) {
        if (h.key === "Escape") {
          h.preventDefault(), h.stopPropagation(), ne();
          return;
        }
        h.key === "Enter" && (h.metaKey || h.ctrlKey) && g.value && (h.preventDefault(), h.stopPropagation(), L());
      }
    }, Re = () => {
      var I;
      const h = document.activeElement;
      return !h || h === document.body || !!((I = le.value) != null && I.contains(h));
    }, Ge = async () => {
      await ft();
      const h = le.value;
      if (!h || !Re()) return;
      (h.querySelector(
        '[data-field-ai-primary]:not(:disabled), [data-testid="field-ai-stop"]'
      ) ?? h).focus({ preventScroll: !0 });
    };
    Q(a, (h, I) => {
      s.value && h !== I && h !== "idle" && Ge();
    });
    const Qe = (h) => {
      var P, de;
      const I = h.target;
      I instanceof Node && ((P = le.value) != null && P.contains(I) || (de = n.anchor()) != null && de.contains(I) || we.value === "composer" && !l.value.trim() && !y.value && n.controller.close());
    };
    Q(
      s,
      (h) => {
        typeof document > "u" || (h ? document.addEventListener("pointerdown", Qe, !0) : (document.removeEventListener("pointerdown", Qe, !0), fe.value = ""));
      },
      { immediate: !0 }
    );
    const et = ["position", "left", "top", "transform"];
    let be = {};
    const A = () => {
      const h = le.value;
      if (h)
        for (const I of et) {
          const P = be[I];
          P ? h.style.setProperty(I, P) : h.style.removeProperty(I);
        }
    }, E = (h) => {
      be = h, A();
    };
    let q, Y;
    const pe = () => {
      const h = n.anchor();
      if (!h) return;
      const I = h.getBoundingClientRect();
      return {
        kind: "virtual-rect",
        left: I.left,
        top: I.top,
        width: I.width,
        height: I.height
      };
    }, Se = () => {
      const h = le.value, I = pe();
      h && I && h.style.setProperty(
        "--field-ai-anchor-width",
        `${Math.round(I.width)}px`
      );
    }, Ce = () => {
      q == null || q(), q = void 0, Y == null || Y.disconnect(), Y = void 0;
    }, d = () => {
      Ce();
      const h = le.value, I = pe();
      if (!h || !I || !s.value) return;
      E(
        Object.keys(be).length ? be : Hc(I)
      ), Se(), q = $c({
        getAnchor: pe,
        floating: h,
        onStyle: (de) => {
          E(de), Se();
        }
      });
      const P = n.anchor();
      P && typeof ResizeObserver < "u" && (Y = new ResizeObserver(Se), Y.observe(P));
    };
    return Q(
      le,
      (h) => {
        h ? d() : (Ce(), be = {});
      },
      { flush: "post" }
    ), rt(() => {
      typeof document < "u" && document.removeEventListener("pointerdown", Qe, !0), Ce();
    }), t({ rootEl: le }), (h, I) => v(oe) ? (N(), He(cs, {
      key: 0,
      to: v(oe).target
    }, [
      v(s) ? (N(), F("section", {
        key: 0,
        id: v(O),
        ref_key: "rootEl",
        ref: le,
        class: K([
          "zx-field-ai zx-inline-ai-surface zx-inline-ai-surface--anchored",
          we.value === "composer" ? "zx-inline-ai-surface--slash-composer" : "zx-inline-ai-surface--response"
        ]),
        style: pt({ zIndex: v(he) }),
        role: "dialog",
        "aria-label": "AI 帮写",
        "aria-busy": v(k) || void 0,
        tabindex: "-1",
        "data-testid": "field-ai",
        onKeydown: ke,
        onFocusin: I[12] || (I[12] = (P) => i("focusin", P)),
        onFocusout: I[13] || (I[13] = (P) => i("focusout", P))
      }, [
        j(zu, {
          "selected-ids": v(H),
          "onUpdate:selectedIds": I[0] || (I[0] = (P) => An(H) ? H.value = P : null),
          choices: v(T),
          receipt: v(w),
          notices: v(R),
          disabled: !v(V) || v(y),
          busy: v(k),
          onDraft: v(X)
        }, null, 8, ["selected-ids", "choices", "receipt", "notices", "disabled", "busy", "onDraft"]),
        we.value === "composer" ? (N(), F(Le, { key: 0 }, [
          M("header", Du, [
            j(v(Ie), {
              class: "zx-inline-ai-surface__slash-mark",
              icon: "lucide:sparkles",
              "aria-hidden": "true"
            }),
            M("span", Fu, [
              I[14] || (I[14] = Yt(" AI 帮写 ", -1)),
              v(r) === "selection" ? (N(), F("span", Pu, " 所选文字 ")) : se("", !0)
            ])
          ]),
          j(Nn, {
            modelValue: v(l),
            "onUpdate:modelValue": I[1] || (I[1] = (P) => An(l) ? l.value = P : null),
            variant: "slash",
            "activation-key": ce.value,
            "submit-enabled": ge.value,
            placeholder: ve.value,
            "accessible-label": "AI 帮写指令",
            onSubmit: Ee
          }, null, 8, ["modelValue", "activation-key", "submit-enabled", "placeholder"]),
          v(m) ? (N(), F("p", Vu, me(v(m)), 1)) : se("", !0),
          us(M("section", {
            class: "zx-inline-ai-surface__slash-suggestions",
            "aria-labelledby": U
          }, [
            M("span", {
              id: U,
              class: "zx-inline-ai-surface__slash-suggestions-label"
            }, " 试试 "),
            M("ul", ju, [
              (N(!0), F(Le, null, Fe(v(x), (P) => (N(), F("li", {
                key: P.id
              }, [
                M("button", {
                  type: "button",
                  class: "zx-inline-ai-surface__slash-suggestion",
                  disabled: !ge.value,
                  "data-field-ai-suggestion": P.id,
                  onClick: (de) => v(C)(P.instruction)
                }, [
                  j(v(Ie), {
                    class: "zx-inline-ai-surface__slash-suggestion-icon",
                    icon: P.icon ?? "lucide:sparkles",
                    "aria-hidden": "true"
                  }, null, 8, ["icon"]),
                  M("span", null, me(P.label), 1)
                ], 8, $u)
              ]))), 128))
            ])
          ], 512), [
            [ds, !v(l).trim() && !v(y)]
          ]),
          v(y) ? (N(), F("footer", Hu, [
            M("div", Uu, [
              M("button", {
                type: "button",
                class: "zx-inline-ai-surface__command zx-inline-ai-surface__hit",
                "data-testid": "field-ai-discard",
                onClick: I[2] || (I[2] = //@ts-ignore
                (...P) => v(ne) && v(ne)(...P))
              }, " 关闭 "),
              M("button", {
                type: "button",
                class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                "data-testid": "field-ai-reload",
                "data-field-ai-primary": "",
                onClick: I[3] || (I[3] = (P) => v(J)())
              }, " 重新读取原文 ")
            ])
          ])) : se("", !0)
        ], 64)) : (N(), F("div", Ku, [
          v(k) && !v(te) ? (N(), F("div", qu, [
            M("span", Gu, [
              M("span", Wu, [
                j(v(Ie), {
                  class: "zx-inline-ai-surface__pondering-orbit",
                  icon: "lucide:loader-circle"
                }),
                I[15] || (I[15] = M("span", { class: "zx-inline-ai-surface__pondering-spark" }, null, -1))
              ]),
              I[16] || (I[16] = M("span", { class: "zx-inline-ai-surface__pondering-text" }, [
                M("span", { class: "zx-inline-ai-surface__pondering-label" }, " 正在生成… ")
              ], -1)),
              I[17] || (I[17] = M("span", {
                class: "zx-inline-ai-surface__sr-only",
                role: "status",
                "aria-live": "polite"
              }, " 正在生成，原文保持不变 ", -1))
            ]),
            M("button", {
              type: "button",
              class: "zx-inline-ai-surface__stop zx-inline-ai-surface__hit",
              "aria-label": "停止生成",
              title: "停止生成",
              "data-testid": "field-ai-stop",
              onClick: I[4] || (I[4] = //@ts-ignore
              (...P) => v(ae) && v(ae)(...P))
            }, [...I[18] || (I[18] = [
              M("span", {
                class: "zx-inline-ai-surface__stop-glyph",
                "aria-hidden": "true"
              }, null, -1)
            ])])
          ])) : (N(), F("div", Ju, [
            M("div", Zu, [
              M("div", Xu, [
                j(v(Ie), { icon: "lucide:sparkles" })
              ]),
              M("div", Yu, [
                v(c) || v(u) ? (N(), F("div", Qu, [
                  j(Su, {
                    document: v(c) ?? v(u)
                  }, null, 8, ["document"]),
                  v(c) ? se("", !0) : (N(), F("p", ed, " 原候选仅供继续改写，不能直接采用。 "))
                ])) : v(te) ? (N(), F("div", td, [
                  Yt(me(v(te)), 1),
                  v(k) ? (N(), F("span", nd)) : se("", !0)
                ])) : se("", !0),
                v(m) ? (N(), F("p", od, me(v(m)), 1)) : v(a) === "stopped" ? (N(), F("p", id, " 已停止，原文未改动。 ")) : v(c) ? (N(), F("p", sd, " 采用后替换" + me(v(r) === "selection" ? "所选文字" : "整段内容") + "，可撤销 ", 1)) : se("", !0)
              ])
            ]),
            v(k) ? (N(), F("footer", rd, [
              M("div", ad, [
                M("button", {
                  type: "button",
                  class: "zx-inline-ai-surface__stop zx-inline-ai-surface__hit",
                  "aria-label": "停止生成",
                  title: "停止生成",
                  "data-testid": "field-ai-stop",
                  onClick: I[5] || (I[5] = //@ts-ignore
                  (...P) => v(ae) && v(ae)(...P))
                }, [...I[19] || (I[19] = [
                  M("span", {
                    class: "zx-inline-ai-surface__stop-glyph",
                    "aria-hidden": "true"
                  }, null, -1)
                ])])
              ])
            ])) : (N(), F("div", ld, [
              I[21] || (I[21] = M("hr", {
                class: "zx-field-ai__divider",
                "aria-hidden": "true"
              }, null, -1)),
              M("footer", cd, [
                v(c) && !v(y) ? (N(), F("button", {
                  key: 0,
                  type: "button",
                  class: "zx-inline-ai-surface__tool zx-inline-ai-surface__hit",
                  "aria-label": "重新生成",
                  title: "按同样的要求重新生成",
                  "data-testid": "field-ai-regenerate",
                  onClick: I[6] || (I[6] = //@ts-ignore
                  (...P) => v(B) && v(B)(...P))
                }, [
                  j(v(Ie), {
                    icon: "lucide:refresh-cw",
                    "aria-hidden": "true"
                  })
                ])) : se("", !0),
                (v(c) || v(u) || v(R).length) && !v(y) ? (N(), F("div", ud, [
                  j(Nn, {
                    modelValue: fe.value,
                    "onUpdate:modelValue": I[7] || (I[7] = (P) => fe.value = P),
                    variant: "surface",
                    "activation-key": !1,
                    placeholder: "继续修改，例如：再短一点",
                    "accessible-label": "继续修改候选",
                    "submit-enabled": !!fe.value.trim(),
                    onSubmit: ue
                  }, null, 8, ["modelValue", "submit-enabled"])
                ])) : se("", !0),
                M("div", dd, [
                  M("button", {
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__hit",
                    "data-testid": "field-ai-discard",
                    onClick: I[8] || (I[8] = //@ts-ignore
                    (...P) => v(ne) && v(ne)(...P))
                  }, me(v(c) ? "舍弃" : "关闭"), 1),
                  v(y) ? (N(), F("button", {
                    key: 0,
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                    "data-testid": "field-ai-reload",
                    "data-field-ai-primary": "",
                    onClick: I[9] || (I[9] = (P) => v(J)())
                  }, " 重新读取原文 ")) : v(c) ? (N(), F("button", {
                    key: 1,
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                    disabled: !v(g),
                    "aria-keyshortcuts": Z.value,
                    "data-testid": "field-ai-accept",
                    "data-field-ai-primary": "",
                    onClick: I[10] || (I[10] = //@ts-ignore
                    (...P) => v(L) && v(L)(...P))
                  }, [
                    I[20] || (I[20] = Yt(" 采用 ", -1)),
                    M("kbd", pd, me(Je.value), 1)
                  ], 8, fd)) : v(l).trim() ? (N(), F("button", {
                    key: 2,
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                    "data-testid": "field-ai-retry",
                    "data-field-ai-primary": "",
                    onClick: I[11] || (I[11] = (P) => v(C)())
                  }, " 重试 ")) : se("", !0)
                ])
              ])
            ]))
          ]))
        ]))
      ], 46, Mu)) : se("", !0)
    ], 8, ["to"])) : se("", !0);
  }
}), _i = "ai.ask", vd = (e) => ({
  id: _i,
  title: "Ask AI",
  description: "Write or revise with AI",
  icon: "lucide:sparkles",
  keywords: ["ai", "ask", "write", "ai 帮写", "帮写", "写"],
  aliases: ["ai"],
  shortcutBindingId: "textEditor.askAI.open",
  group: "ai",
  priority: -100,
  command: ({ editor: t, range: o }) => {
    t.chain().focus().deleteRange(o).run(), queueMicrotask(e);
  }
}), gd = (e) => Ks({
  id: "zx-field-ai",
  priority: -50,
  items: () => [
    {
      id: _i,
      kind: "dropdown",
      surface: "bubble",
      priority: -50,
      label: "AI",
      icon: "lucide:sparkles",
      getState: () => ({ disabled: e.disabled() }),
      options: [
        ...e.suggestions().map((t) => ({
          id: `ai-${t.id}`,
          label: t.label,
          icon: t.icon
        })),
        { id: "ai-custom", label: "Ask AI…", icon: "lucide:pen-line" }
      ],
      onOptionSelect: (t) => {
        if (e.disabled()) return;
        const o = e.suggestions().find((n) => `ai-${n.id}` === t);
        e.open(o == null ? void 0 : o.instruction);
      }
    }
  ]
}), hd = Object.freeze([
  {
    id: "draft",
    label: "根据表单信息写一条备注",
    instruction: "根据提供的业务上下文，写一条简洁、准确的备注。",
    icon: "lucide:pen-line"
  },
  {
    id: "draft-points",
    label: "用要点列出关键信息",
    instruction: "根据提供的业务上下文，用要点列表写一条备注，每条一句话。",
    icon: "lucide:list"
  }
]), bd = Object.freeze([
  {
    id: "polish",
    label: "润色",
    instruction: "请润色表达，保留原意和事实，使文字清晰自然。",
    icon: "lucide:wand-sparkles"
  },
  {
    id: "concise",
    label: "精简",
    instruction: "请精简内容，保留关键事实和结论，去掉重复表述。",
    icon: "lucide:minimize-2"
  },
  {
    id: "points",
    label: "整理要点",
    instruction: "请保留原意，将内容整理成简洁清晰的要点列表。",
    icon: "lucide:list"
  }
]), Oi = (e, t) => {
  var o;
  return ((o = t == null ? void 0 : t.suggestions) == null ? void 0 : o.call(t, e)) ?? (e.empty && e.target === "document" ? hd : bd);
}, ln = (e) => nr("zx-text-editor-field-ai:v1", e.getJSON()), Bn = (e) => gt({
  body: { format: "json", content: e },
  annotations: [],
  assets: []
}), yd = (e, t) => {
  const { from: o, to: n, empty: i } = e.state.selection;
  return {
    fingerprint: ln(e),
    from: o,
    to: n,
    document: Ye(Bn(e.getJSON()), t),
    selection: i ? null : Ye(
      Bn(
        ur(
          e.state.doc.cut(o, n).toJSON()
        ).content
      ),
      t
    )
  };
}, Mo = (e, t, o, n, i) => {
  if (ln(e) !== t.fingerprint)
    throw new Error("原文已变化，请重新打开 AI 后生成");
  const s = Ye(n, i);
  if (!s) throw new Error("AI 没有返回可采用的内容，请重试");
  const a = oi.fromArray(
    s.body.content.content.map(
      (r) => e.schema.nodeFromJSON(r)
    )
  ), l = e.state.tr;
  if (o === "selection") {
    if (t.from === t.to || !t.selection)
      throw new Error("所选文字已不可用，请重新选择");
    const r = s.body.content.content.every(
      (f) => f.type === "paragraph"
    );
    l.replaceRange(
      t.from,
      t.to,
      new ni(a, r ? 1 : 0, r ? 1 : 0)
    );
  } else
    l.replaceWith(0, l.doc.content.size, a);
  return sr(l, l.doc, {
    types: cr()
  }), Ye(Bn(l.doc.toJSON()), i), { candidate: s, transaction: l };
};
function kd(e) {
  const t = dr(), o = fr(), n = W("rewrite"), i = W([]), s = Be(null);
  let a = 0;
  const l = S(
    () => t == null ? void 0 : t.definition.purposes[e.purpose() ?? ""]
  ), r = S(
    () => !!l.value && !!t && pr(t.status())
  ), f = S(
    () => {
      var p;
      return (((p = l.value) == null ? void 0 : p.selectableContextIds) ?? []).map((m) => {
        var z;
        const y = t.definition.items.find((_) => _.id === m);
        return {
          id: m,
          label: y.label,
          disabled: y.sensitivity === "personal" && ((z = t.status().policy) == null ? void 0 : z.personal) === "never"
        };
      });
    }
  );
  return Q(
    () => JSON.stringify([n.value, i.value]),
    () => {
      a++, e.invalidate("form");
    },
    { flush: "sync" }
  ), Q(
    () => t == null ? void 0 : t.stamp(),
    () => e.invalidate("form"),
    { flush: "sync" }
  ), Q(
    () => JSON.stringify([
      t == null ? void 0 : t.instanceKey(),
      e.purpose(),
      t == null ? void 0 : t.status()
    ]),
    (p, m) => {
      JSON.parse(p)[0] !== JSON.parse(m)[0] && o.reset(), e.invalidate("identity");
    },
    { flush: "sync" }
  ), kt(() => o.reset()), {
    available: r,
    action: n,
    selectedContextIds: i,
    choices: f,
    receipt: s,
    capture: async (p, m) => {
      if (!t || !e.purpose() || !r.value)
        throw new on("not-ready");
      const y = await mr(t, {
        purpose: e.purpose(),
        knownValues: o,
        signal: m,
        request: p,
        selection: () => ({
          action: i.value.length ? "include-context" : n.value,
          selectedContextIds: i.value,
          revision: a
        })
      });
      return s.value = y.receipt, y;
    },
    validateResult: (p, m) => {
      const y = () => {
        throw new on("invalid-output");
      };
      (!p || typeof p != "object" || Object.keys(p).sort().join(",") !== "document,meta,notices" || !Array.isArray(p.notices) || p.notices.length > 16 || !p.meta || Object.keys(p.meta).sort().join(",") !== "contextIds,model,promptVersion" || p.meta.promptVersion !== "text-field/v1" || typeof p.meta.model != "string" || !p.meta.model || [...p.meta.model].length > 128 || JSON.stringify(p.meta.contextIds) !== JSON.stringify(m) || p.document === null && !p.notices.length) && y();
      const z = new Set(
        t == null ? void 0 : t.definition.items.filter((_) => _.sensitivity !== "secret").map((_) => _.id)
      );
      for (const _ of p.notices)
        (!_ || Object.keys(_).sort().join(",") !== "code,contextIds" || _.code !== "information-unavailable" || !Array.isArray(_.contextIds) || _.contextIds.length > 16 || new Set(_.contextIds).size !== _.contextIds.length || _.contextIds.some((x) => !z.has(x))) && y();
      return p;
    }
  };
}
const Do = ti, Fo = (e) => JSON.parse(JSON.stringify(e));
function wd(e) {
  const t = W(!1), o = W(
    "idle"
  ), n = W(""), i = W("document"), s = Be(null), a = Be(null), l = W(""), r = W(""), f = W(!1), c = Be([]), u = W(!1);
  let p = 0, m;
  const y = Be(null), z = S(() => o.value === "generating"), _ = S(
    () => o.value === "ready" && !!a.value && !f.value && T.available.value && !e.disabled()
  ), x = S(() => {
    var O;
    return !((O = s.value) != null && O.document);
  }), k = S(
    () => Oi(
      { target: i.value, empty: x.value },
      e.adapter()
    )
  ), g = () => {
    p++, m == null || m.abort(), m = void 0;
  }, V = () => {
    const O = e.editor(), U = s.value;
    return !!O && !!U && ln(O) === U.fingerprint && O.state.selection.from === U.from && O.state.selection.to === U.to;
  }, H = () => {
    g(), f.value = !0, a.value = null, y.value = null, w = void 0, l.value = "", c.value = [], o.value = "error", r.value = "原文已变化，请重新打开 AI 后生成；当前原文已保留";
  }, T = kd({
    purpose: e.purpose,
    invalidate(O) {
      if (g(), O === "identity") {
        R();
        return;
      }
      if (t.value) {
        if (f.value || !V()) {
          H();
          return;
        }
        y.value = a.value ?? y.value, a.value = null, w = void 0, l.value = "", o.value = "idle", c.value = [], r.value = t.value && u.value ? "上下文已变化，旧候选仅供改写，请重新生成后采用" : "";
      }
    }
  });
  let w;
  const R = () => {
    g(), t.value = !1, a.value = null, l.value = "", o.value = "idle", r.value = "", s.value = null, u.value = !1, y.value = null, w = void 0, c.value = [], T.receipt.value = null;
  }, X = (O) => {
    s.value = yd(O, e.limits()), i.value = s.value.selection ? "selection" : "document";
  }, J = (O) => {
    var oe;
    const U = e.editor();
    if (!(!U || e.disabled() || !e.adapter() || !T.available.value)) {
      R(), t.value = !0, f.value = !1, n.value = "";
      try {
        X(U), T.selectedContextIds.value = [], T.action.value = (oe = s.value) != null && oe.document ? "rewrite" : "draft";
      } catch {
        r.value = "请先检查原文的格式和长度，再使用 AI", o.value = "error";
        return;
      }
      O != null && O.trim() && C(O);
    }
  }, ne = () => {
    g(), o.value = "stopped";
  }, ae = () => {
    var O;
    R(), e.disabled() || (O = e.editor()) == null || O.commands.focus();
  }, C = async (O = n.value) => {
    const U = e.editor(), oe = e.adapter(), he = s.value;
    if (!U || !oe || !he || e.disabled() || f.value || !O.trim() || !T.available.value)
      return;
    g();
    const le = p, fe = new AbortController();
    m = fe, n.value = O, u.value = !0;
    const we = a.value ?? y.value;
    y.value = we, a.value = null, l.value = "", r.value = "", c.value = [], o.value = "generating";
    const ge = () => le === p && t.value && !fe.signal.aborted && T.available.value && !e.disabled();
    try {
      const ce = await T.capture(
        Fo({
          instruction: O.trim(),
          target: i.value,
          document: he.document,
          selection: i.value === "selection" ? he.selection : null,
          candidate: we ?? null
        }),
        fe.signal
      );
      if (!ge()) return;
      for (const ue of [
        ce.request.document,
        ce.request.selection,
        ce.request.candidate
      ])
        ue !== null && Ye(ue, e.limits());
      const ve = await oe.generate(
        {
          ...ce.request,
          version: "ai-context/v1",
          requestId: vr(),
          captureId: ce.captureId,
          manifestRevision: ce.manifestRevision,
          policyRevision: ce.policyRevision,
          scope: ce.scope,
          purpose: ce.purpose,
          action: ce.action,
          selectedContextIds: ce.selectedContextIds,
          profile: "basic-rich-text",
          context: ce.items
        },
        {
          signal: fe.signal,
          onDelta: (ue) => {
            ge() && typeof ue == "string" && (l.value = (l.value + ue).slice(0, 1e5));
          }
        }
      );
      if (!ge()) return;
      if (ce.assertCurrent(), T.validateResult(
        ve,
        ce.items.map((ue) => ue.id)
      ), c.value = Fo(ve.notices), w = ce, ve.document === null) {
        o.value = "ready", l.value = "";
        return;
      }
      const Ee = ce.restore(ve.document);
      a.value = Mo(
        U,
        he,
        i.value,
        Ee,
        e.limits()
      ).candidate, o.value = "ready";
    } catch (ce) {
      if (!ge()) return;
      o.value = "error", r.value = ce instanceof on && ce.code === "placeholder-conflict" ? "内容包含保留占位符，请调整后再生成" : ce instanceof on && ce.code === "personal-blocked" ? "当前策略不允许发送内容中的已知个人信息，请调整内容后重试" : "AI 生成未完成，或结果不符合字段格式或长度限制，请调整要求后重试";
    } finally {
      le === p && (m = void 0);
    }
  }, B = () => {
    z.value || f.value || !n.value.trim() || (a.value = null, y.value = null, C(n.value));
  }, L = () => {
    const O = e.editor();
    if (!(!O || !s.value || !_.value))
      try {
        if (!w) throw new Error("missing AI capture");
        w.assertCurrent();
        const { transaction: U } = Mo(
          O,
          s.value,
          i.value,
          a.value,
          e.limits()
        ), oe = U.doc;
        if (t.value = !1, O.view.dispatch(Do.closeHistory(U)), !O.state.doc.eq(oe))
          throw new Error("内容未能应用，请重新生成");
        O.view.dispatch(
          Do.closeHistory(O.state.tr).setMeta("addToHistory", !1)
        ), R(), O.commands.focus();
      } catch (U) {
        t.value = !0, r.value = U instanceof Error ? U.message : "内容未能应用，请重试", o.value = "error";
      }
  };
  return Q(
    e.editor,
    (O, U, oe) => {
      if (U && R(), !O) return;
      const he = () => {
        const le = s.value;
        if (!t.value || !le) return;
        const fe = ln(O) === le.fingerprint;
        if (!u.value && o.value === "idle") {
          const { from: ge, to: ce } = O.state.selection;
          if (fe && ge === le.from && ce === le.to) return;
          try {
            X(O);
            return;
          } catch {
          }
        }
        const we = O.state.selection;
        fe && we.from === le.from && we.to === le.to || H();
      };
      O.on("transaction", he), oe(() => O.off("transaction", he));
    },
    { immediate: !0 }
  ), Q(
    () => [e.disabled(), e.adapter()],
    () => {
      t.value && R();
    }
  ), Q(i, () => {
    g(), a.value = null, l.value = "", o.value = "idle", y.value = null;
  }), kt(g), {
    open: t,
    phase: o,
    instruction: n,
    scope: i,
    target: s,
    candidate: a,
    refinementPreview: S(
      () => a.value ? null : y.value
    ),
    stream: l,
    error: r,
    stale: f,
    submitted: u,
    empty: x,
    suggestions: k,
    busy: z,
    canAccept: _,
    available: T.available,
    selectedContextIds: T.selectedContextIds,
    contextChoices: T.choices,
    receipt: T.receipt,
    notices: c,
    draftFromContext: () => {
      T.selectedContextIds.value = [], T.action.value = "draft", C(n.value.trim() || "根据本次提供的信息起草");
    },
    start: J,
    close: R,
    cancel: ae,
    stop: ne,
    generate: C,
    regenerate: B,
    accept: L
  };
}
const xd = ["title", "aria-label", "aria-expanded"], Td = {
  key: 3,
  class: "zx-text-editor-field__message",
  role: "status"
}, Id = ["role"], yf = /* @__PURE__ */ Ae({
  name: "ZxTextEditorField",
  inheritAttrs: !1,
  __name: "text-editor-field",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    placeholder: {},
    id: {},
    contentLimits: {},
    ai: {},
    aiPurpose: {},
    messages: { default: () => [] }
  },
  emits: ["update:modelValue", "focus", "blur", "edit-state"],
  setup(e, { expose: t, emit: o }) {
    const n = (Z) => Object.fromEntries(
      Object.entries(Z).filter(([ke]) => ke !== "class" && ke !== "style")
    );
    In(di, !0);
    const i = e, s = o, a = {
      root: {
        fontSize: {
          cssValue: "var(--el-font-size-base, 14px)",
          displayValue: "14px"
        },
        fontFamily: { cssValue: "var(--el-font-family)", displayValue: "Default" }
      }
    }, l = Ko(), r = Xs(), f = Ys(), c = Qs(), u = Be(l);
    let p = !1;
    Q(
      () => f.ok ? f.value.value : null,
      () => {
        var Re;
        if (l || !r.ok) return;
        const Z = os({
          nearestScope: f.ok ? f.value.value : null,
          nearestScopeAvailable: f.ok,
          app: c.ok ? c.value : null
        });
        if (!Z) return;
        p && ((Re = u.value) == null || Re.dispose());
        const ke = is(r.value, Z);
        ke.ok && (u.value = ke.value, p = !0);
      },
      { immediate: !0 }
    );
    const m = W(), y = W(), z = W(), _ = () => {
      var Z;
      return ((Z = z.value) == null ? void 0 : Z.rootEl) ?? null;
    }, x = (Z) => {
      var ke, Re;
      return Z instanceof Node && (!!((ke = y.value) != null && ke.contains(Z)) || !!((Re = _()) != null && Re.contains(Z)));
    };
    let k = !1;
    function g(Z) {
      k || s("focus", Z), k = !0;
    }
    async function V(Z) {
      x(Z.relatedTarget) || (await ft(), !x(document.activeElement) && (k = !1, R.value = "", s("blur", Z)));
    }
    const H = (Z) => {
      m.value = Z ?? void 0;
    }, T = W(!1), w = W(""), R = W(""), X = S(() => {
      var Z;
      return ((Z = m.value) == null ? void 0 : Z.editor) ?? null;
    }), J = wd({
      editor: () => X.value,
      adapter: () => i.ai,
      disabled: () => !!i.disabled || !!i.readonly || T.value,
      limits: () => i.contentLimits,
      purpose: () => i.aiPurpose
    }), ne = S(
      () => !!i.ai && !i.disabled && !i.readonly && J.available.value
    ), ae = () => {
      J.open.value ? J.cancel() : J.start();
    }, C = vd(() => J.start()), B = gd({
      suggestions: () => Oi({ target: "selection", empty: !1 }, i.ai),
      disabled: () => !ne.value || T.value,
      open: (Z) => J.start(Z)
    }), L = S(
      () => i.ai ? { contributions: [B] } : !0
    ), O = S(() => i.ai ? [C] : []), U = Ut(), oe = Xo({
      contributions: [Fn],
      kind: "textEditor.authoring",
      root: y,
      active: ne,
      focusRequired: !0
    }), he = jt(ii, {
      owner: oe,
      keyboardArgs: () => {
      },
      port: tn({
        getState: () => ({ enabled: ne.value && !T.value }),
        subscribe: (Z) => Q([ne, T], Z, { flush: "sync" }),
        run: () => J.start()
      })
    }), le = jt(si, {
      owner: oe,
      keyboardArgs: () => {
      },
      port: tn({
        getState: () => ({ enabled: J.open.value }),
        subscribe: (Z) => Q(J.open, Z, { flush: "sync" }),
        run: () => J.cancel()
      })
    });
    kt(() => {
      he.dispose(), le.dispose();
    });
    const { text: fe } = cn({
      runtime: U,
      bindingId: "textEditor.askAI.open"
    }), we = S(
      () => fe.value ? `AI 帮写 (${fe.value})` : "AI 帮写"
    ), ce = Be({
      version: 2,
      body: {
        format: "json",
        content: {
          type: "doc",
          content: [
            {
              type: "paragraph",
              attrs: {
                textAlign: null,
                blockId: `blk_${crypto.randomUUID().replaceAll("-", "")}`
              }
            }
          ]
        }
      },
      annotations: [],
      assets: [],
      meta: { schemaVersion: "stable-block-identity/v2" }
    }), ve = S(() => i.modelValue ?? ce.value), Ee = S(() => [
      ...T.value ? [{ severity: "error", message: "请完成输入法输入后再提交" }] : [],
      ...w.value ? [{ severity: "error", message: w.value }] : []
    ]), ue = () => s("edit-state", {
      pending: T.value || J.open.value,
      blocking: Ee.value
    });
    function te(Z) {
      if (i.disabled || i.readonly || T.value) return;
      let ke = Z;
      try {
        ke = Ye(Z, i.contentLimits), w.value = "", ke === null && (ce.value = Z);
      } catch (Re) {
        w.value = String(Re).includes("characters") ? "备注正文最多 5,000 个字符，当前输入已保留" : "备注文档超过资源或结构限制，当前输入已保留";
      }
      JSON.stringify(ke) !== JSON.stringify(i.modelValue) && s("update:modelValue", ke), ue();
    }
    function ye(Z) {
      R.value = Z.includes("basic-rich-text:link") ? "链接地址不受支持，请使用 http(s)、mailto 或 tel 链接" : Z.includes("basic-rich-text:") ? "该格式不受支持，内容未改变" : Z;
    }
    function re() {
      T.value = !0, ue();
    }
    async function Me() {
      T.value = !1, await ft(), m.value && te(m.value.getDocument()), ue();
    }
    function Ve(Z) {
      (Z.isComposing || T.value || Z.keyCode === 229) && Z.key === "Enter" && Z.stopPropagation();
    }
    Q(
      () => [i.disabled, i.readonly],
      () => ue()
    ), Q(
      () => i.modelValue,
      (Z) => {
        try {
          Ye(Z, i.contentLimits), w.value = "";
        } catch {
          w.value = "备注文档无法读取或超过限制";
        }
        ue();
      },
      { immediate: !0 }
    ), Q([J.open, J.busy], ue), Ht(ue), rt(() => {
      var Z;
      p && ((Z = u.value) == null || Z.dispose());
    });
    function Je() {
      return J.close(), T.value && m.value && (T.value = !1, te(m.value.getDocument())), null;
    }
    return t({
      focus: () => {
        var Z;
        return (Z = m.value) == null ? void 0 : Z.focus();
      },
      validate: () => (ue(), !Ee.value.length && !J.open.value),
      captureEdit: Je
    }), (Z, ke) => (N(), F("div", {
      ref_key: "fieldRoot",
      ref: y,
      class: K(["zx-text-editor-field", [
        K(Z.$attrs.class),
        {
          "is-disabled": e.disabled,
          "is-invalid": Ee.value.length,
          "has-ai": ne.value,
          "is-ai-open": v(J).open.value
        }
      ]]),
      style: pt(pt(Z.$attrs.style)),
      onCompositionstart: re,
      onCompositionend: Me,
      onKeydownCapture: Ve,
      onFocusin: g,
      onFocusout: V
    }, [
      u.value ? (N(), He(pi, st({
        key: 0,
        id: e.id,
        ref: H
      }, n(Z.$attrs), {
        "theme-owner": u.value,
        "content-profile": "basic-rich-text",
        "bubble-toolbar": L.value,
        "slash-catalog-contributions": O.value,
        "content-limits": e.contentLimits,
        "document-value": ve.value,
        "content-type": "document",
        "output-type": "document",
        editable: !e.disabled && !e.readonly,
        typography: a,
        placeholder: e.placeholder ?? (ne.value ? "输入内容；按 / 或点 ✦ 使用 AI 帮写" : "输入内容；输入 / 插入列表，选中文字可设置格式"),
        "onUpdate:documentValue": te,
        onContentIssue: ye
      }), null, 16, ["id", "theme-owner", "bubble-toolbar", "slash-catalog-contributions", "content-limits", "document-value", "editable", "placeholder"])) : se("", !0),
      ne.value ? (N(), F("button", {
        key: 1,
        type: "button",
        class: K(["zx-text-editor-field__ai", { "is-active": v(J).open.value }]),
        title: we.value,
        "aria-label": we.value,
        "aria-haspopup": "dialog",
        "aria-expanded": v(J).open.value,
        "data-testid": "field-ai-trigger",
        onMousedown: ke[0] || (ke[0] = Ke(() => {
        }, ["prevent"])),
        onClick: ae
      }, [
        j(v(Ie), {
          icon: "lucide:sparkles",
          "aria-hidden": "true"
        })
      ], 42, xd)) : se("", !0),
      e.ai ? (N(), He(md, {
        key: 2,
        ref_key: "popover",
        ref: z,
        controller: v(J),
        "theme-owner": u.value,
        anchor: () => y.value,
        onFocusin: g,
        onFocusout: V
      }, null, 8, ["controller", "theme-owner", "anchor"])) : se("", !0),
      R.value ? (N(), F("p", Td, me(R.value), 1)) : se("", !0),
      (N(!0), F(Le, null, Fe([...e.messages, ...Ee.value], (Re, Ge) => (N(), F("p", {
        key: Ge,
        class: K(["zx-text-editor-field__message", { "is-error": Re.severity === "error" }]),
        role: Re.severity === "error" ? "alert" : void 0
      }, me(Re.message), 11, Id))), 128))
    ], 38));
  }
}), kf = yr(pi), Ad = (e) => {
  const t = _n(e.shellState);
  return t.kind === "close-presentation" ? ((e.handlers.closePresentation ?? e.handlers.closeIdle)(), { kind: "close-presentation" }) : t.kind === "dismiss-review-ui" ? (e.handlers.dismissReviewUi(), t) : (t.kind === "close-idle" && e.handlers.closeIdle(), t);
}, Po = (e, t) => qs({
  getState: e,
  run: t,
  subscribe: (o) => Q(e, o, { flush: "sync" })
});
function wf(e) {
  const t = Xo({
    contributions: [Fn],
    kind: "textEditor.authoring",
    roots: () => [
      qe(e.root),
      ...e.roots ? qe(e.roots) : []
    ].filter((r) => !!r),
    active: e.active,
    focusRequired: !0
  }), o = () => {
    const r = qe(e.editorBindingId).trim();
    if (!r) throw new Error("editorBindingId must not be empty");
    return r;
  };
  let n = 0;
  const i = e.inlineEdit ? jt(gr, {
    owner: t,
    keyboardArgs: () => {
    },
    port: Po(
      () => {
        const r = so(
          e.inlineEdit.getRouteInput()
        );
        return {
          enabled: r.kind !== "closed",
          reason: r.kind === "closed" ? r.reason : void 0
        };
      },
      () => {
        const r = so(
          e.inlineEdit.getRouteInput()
        );
        return r.kind === "closed" ? null : r.kind === "reveal" ? e.inlineEdit.owner.dispatch(r.actionId, r.binding).then((f) => {
          var c, u;
          return (u = (c = e.inlineEdit).onRevealReceipt) == null || u.call(c, f), f;
        }) : e.inlineEdit.owner.openInvocation({
          context: r.invocationContext,
          surface: {
            surface: "shortcut",
            invokerToken: `inline-edit-shortcut:${o()}`,
            capturedAtLogical: ++n
          }
        });
      }
    )
  }) : null, s = e.askAI ? jt(ii, {
    owner: t,
    keyboardArgs: () => {
    },
    port: {
      ...Po(
        e.askAI.getState,
        () => e.askAI.openInvocation({ surface: "shortcut" })
      ),
      subscribe: e.askAI.subscribe
    }
  }) : null, a = S(() => {
    var f;
    const r = qe(e.escape.shellState);
    return _n(r).kind === "noop" && ((f = e.escape.selectionBubble) != null && f.active.value) ? "selection-bubble" : r;
  }), l = jt(si, {
    owner: t,
    keyboardArgs: () => {
    },
    port: tn({
      getState: () => ({
        enabled: _n(a.value).kind !== "noop",
        reason: "no-ai-surface"
      }),
      subscribe: (r) => Q(a, r, { flush: "sync" }),
      run: () => Ad({
        shellState: a.value,
        handlers: a.value === "selection-bubble" ? {
          ...e.escape.handlers,
          closeIdle: () => {
            var r;
            return (r = e.escape.selectionBubble) == null ? void 0 : r.dismiss();
          }
        } : e.escape.handlers
      })
    })
  });
  return kt(() => {
    i == null || i.dispose(), s == null || s.dispose(), l.dispose();
  }), {
    owner: t,
    inlineEdit: i ? bn(i, {
      args: void 0,
      bindingId: "textEditor.inlineEdit.open"
    }) : null,
    askAI: s ? bn(s, {
      args: void 0,
      bindingId: "textEditor.askAI.open"
    }) : null,
    escape: bn(l, {
      args: void 0,
      bindingId: "textEditor.inlineAi.escape"
    })
  };
}
function xf(e) {
  const t = e.runtime ?? Ut(), o = Zo(), n = Be(null), i = S(
    () => {
      var l, r;
      return qe(e.root) ?? ((r = (l = qe(e.editor)) == null ? void 0 : l.view) == null ? void 0 : r.dom) ?? null;
    }
  );
  let s = () => {
  };
  const a = Q(
    [() => qe(e.editor), i],
    ([l, r]) => {
      if (s(), s = () => {
      }, n.value = null, !l || !r) return;
      const f = Uo(l);
      if (f) {
        if (f.runtime.runtimeId !== t.runtimeId)
          throw new Error("external-editor-shortcut-runtime-mismatch");
        s = qo(l, (y) => {
          if (y && y.runtime.runtimeId !== t.runtimeId)
            throw new Error("external-editor-shortcut-runtime-mismatch");
          n.value = (y == null ? void 0 : y.editLink) ?? null;
        });
        return;
      }
      const c = t.createOwner({
        contributions: [Fn],
        kind: "textEditor.editor",
        parent: o,
        focusRequired: !0
      }), u = t.attachAction(hr, {
        owner: c,
        keyboardArgs: () => {
        },
        port: tn({
          getState: () => ({
            enabled: qe(e.active) !== !1 && !l.isDestroyed && l.isEditable !== !1 && typeof l.commands.openLinkEditor == "function",
            reason: "link-command-unavailable"
          }),
          subscribe: (y) => {
            var _, x;
            const z = Q(() => qe(e.active), y, {
              flush: "sync"
            });
            return (_ = l.on) == null || _.call(l, "transaction", y), (x = l.on) == null || x.call(l, "update", y), () => {
              var k, g;
              z(), (k = l.off) == null || k.call(l, "transaction", y), (g = l.off) == null || g.call(l, "update", y);
            };
          },
          run: () => {
            const y = l.commands.openLinkEditor;
            if (typeof y != "function")
              throw new Error("link-command-unavailable");
            return y.call(l.commands) === !0;
          }
        })
      }), p = Ws(t, c, { roots: [r] }), m = (y) => p.dispatch(y, "editor");
      r.addEventListener("keydown", m, !0), n.value = u.forArgs(void 0, {
        bindingId: "textEditor.link.edit"
      }), s = () => {
        r.removeEventListener("keydown", m, !0), p.dispose(), u.dispose(), c.dispose();
      };
    },
    { immediate: !0, flush: "sync" }
  );
  return kt(() => {
    a(), s();
  }), { action: n };
}
export {
  gi as A,
  rf as B,
  af as C,
  Pl as D,
  lf as E,
  nf as F,
  cf as G,
  uf as H,
  Ia as I,
  df as J,
  fi as K,
  Ca as L,
  pf as M,
  mf as N,
  vf as O,
  gf as P,
  hf as Q,
  ga as T,
  kf as Z,
  bf as _,
  Da as a,
  va as b,
  ff as c,
  sf as d,
  Ad as e,
  hl as f,
  Bl as g,
  xf as h,
  yf as i,
  Su as j,
  yn as k,
  Er as l,
  pa as m,
  Cr as n,
  Nt as o,
  Fr as p,
  jr as q,
  kn as r,
  Kr as s,
  Rt as t,
  wf as u,
  Wr as v,
  of as w,
  ba as x,
  ha as y,
  Ma as z
};
//# sourceMappingURL=use-text-editor-command-keybindings-C18Z3ZZ3.mjs.map
