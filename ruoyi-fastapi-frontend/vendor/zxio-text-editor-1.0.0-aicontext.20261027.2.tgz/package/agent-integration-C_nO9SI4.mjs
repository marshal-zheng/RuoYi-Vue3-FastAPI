class x extends TypeError {
  constructor(t, r) {
    super(`Cannot canonicalize ${t}: ${r}`), this.name = "ZxCanonicalJSONError", this.path = t;
  }
}
class C extends x {
  constructor(t, r, i) {
    super(t, r), this.name = "ZxCanonicalJSONResourceError", this.usage = i;
  }
}
const pe = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]), Z = (e, t) => {
  for (let r = 0; r < e.length; r += 1) {
    const i = e.charCodeAt(r);
    if (i >= 55296 && i <= 56319) {
      const n = e.charCodeAt(r + 1);
      if (!(n >= 56320 && n <= 57343))
        throw new x(
          t,
          "strings must contain valid Unicode"
        );
      r += 1;
      continue;
    }
    if (i >= 56320 && i <= 57343)
      throw new x(t, "strings must contain valid Unicode");
  }
}, ge = (e, t) => {
  if (Object.getPrototypeOf(e) !== Array.prototype)
    throw new x(t, "only plain arrays are supported");
  const r = Reflect.ownKeys(e);
  if (r.some((i) => typeof i == "symbol"))
    throw new x(t, "symbol keys are not supported");
  if (r.length !== e.length + 1 || !r.includes("length"))
    throw new x(
      t,
      "arrays must be dense and contain no extra properties"
    );
  return Array.from({ length: e.length }, (i, n) => {
    const o = Object.getOwnPropertyDescriptor(e, String(n));
    if (!o || !o.enumerable || !("value" in o))
      throw new x(
        `${t}[${n}]`,
        "array entries must be enumerable data properties"
      );
    return o;
  });
}, ee = (e, t, r) => {
  if (e === null) return "null";
  switch (typeof e) {
    case "string":
      return Z(e, t), JSON.stringify(e);
    case "boolean":
      return JSON.stringify(e);
    case "number":
      if (!Number.isFinite(e))
        throw new x(t, "numbers must be finite");
      if (Object.is(e, -0))
        throw new x(t, "negative zero is ambiguous");
      return JSON.stringify(e);
    case "undefined":
    case "function":
    case "symbol":
    case "bigint":
      throw new x(t, `${typeof e} is not supported`);
  }
  const i = e;
  if (r.has(i))
    throw new x(t, "cyclic values are not supported");
  const n = new Set(r);
  if (n.add(i), Array.isArray(e))
    return `[${ge(e, t).map(
      (d, y) => ee(d.value, `${t}[${y}]`, n)
    ).join(",")}]`;
  const o = Object.getPrototypeOf(e);
  if (o !== Object.prototype && o !== null)
    throw new x(t, "only plain objects are supported");
  const a = e, s = Reflect.ownKeys(a);
  if (s.some((d) => typeof d == "symbol"))
    throw new x(t, "symbol keys are not supported");
  const p = s;
  return p.forEach((d) => {
    if (Z(d, `${t}.<key>`), pe.has(d))
      throw new x(t, `forbidden object key "${d}"`);
    const y = Object.getOwnPropertyDescriptor(a, d);
    if (!y || !y.enumerable || !("value" in y))
      throw new x(
        `${t}.${d}`,
        "only enumerable data properties are supported"
      );
  }), `{${p.sort().map((d) => {
    const y = Object.getOwnPropertyDescriptor(a, d);
    return `${JSON.stringify(d)}:${ee(
      y.value,
      `${t}.${d}`,
      n
    )}`;
  }).join(",")}}`;
}, L = (e) => ee(e, "$", /* @__PURE__ */ new Set()), te = (e, t, r, i, n, o) => {
  const a = (l) => {
    if (o.estimatedBytes += l, o.estimatedBytes > t.maxBytes)
      throw new C(
        r,
        "maximum encoded bytes exceeded",
        {
          depth: o.depth,
          arrayEntries: o.arrayEntries,
          maxKeysPerObject: o.maxKeysPerObject,
          objectKeys: o.objectKeys,
          bytes: o.estimatedBytes
        }
      );
  };
  if (o.depth = Math.max(o.depth, i), i > t.maxDepth)
    throw new C(r, "maximum depth exceeded", {
      ...o,
      bytes: null
    });
  if (e === null) {
    a(4);
    return;
  }
  if (typeof e != "object") {
    typeof e == "string" && Z(e, r);
    const l = typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isFinite(e) && !Object.is(e, -0) ? JSON.stringify(e) : void 0;
    if (l === void 0)
      throw new x(r, `${typeof e} is not supported`);
    a(new TextEncoder().encode(l).length);
    return;
  }
  if (n.has(e))
    throw new x(r, "cyclic values are not supported");
  const s = new Set(n);
  if (s.add(e), Array.isArray(e)) {
    if (o.arrayEntries += e.length, o.arrayEntries > t.maxArrayEntries)
      throw new C(
        r,
        "maximum array entries exceeded",
        { ...o, bytes: null }
      );
    a(2 + Math.max(0, e.length - 1)), ge(e, r).forEach(
      (l, A) => te(
        l.value,
        t,
        `${r}[${A}]`,
        i + 1,
        s,
        o
      )
    );
    return;
  }
  const p = Object.getPrototypeOf(e);
  if (p !== Object.prototype && p !== null)
    throw new x(r, "only plain objects are supported");
  const d = Reflect.ownKeys(e);
  if (d.some((l) => typeof l == "symbol"))
    throw new x(r, "symbol keys are not supported");
  const y = d.filter(
    (l) => typeof l == "string"
  );
  if (o.maxKeysPerObject = Math.max(o.maxKeysPerObject, y.length), o.maxKeysPerObject > t.maxObjectKeys)
    throw new C(
      r,
      "maximum object keys exceeded",
      { ...o, bytes: null }
    );
  if (o.objectKeys += y.length, o.objectKeys > t.maxTotalObjectKeys)
    throw new C(
      r,
      "maximum total object keys exceeded",
      {
        depth: o.depth,
        arrayEntries: o.arrayEntries,
        maxKeysPerObject: o.maxKeysPerObject,
        objectKeys: o.objectKeys,
        bytes: o.estimatedBytes
      }
    );
  a(2 + Math.max(0, y.length - 1)), y.forEach((l) => {
    if (Z(l, `${r}.<key>`), pe.has(l))
      throw new x(r, `forbidden object key "${l}"`);
    const A = Object.getOwnPropertyDescriptor(e, l);
    if (!A || !A.enumerable || !("value" in A))
      throw new x(
        `${r}.${l}`,
        "only enumerable data properties are supported"
      );
    a(new TextEncoder().encode(JSON.stringify(l)).length + 1), te(
      A.value,
      t,
      `${r}.${l}`,
      i + 1,
      s,
      o
    );
  });
}, le = (e, t) => {
  const r = {
    depth: 0,
    arrayEntries: 0,
    maxKeysPerObject: 0,
    objectKeys: 0,
    estimatedBytes: 0
  };
  te(e, t, "$", 0, /* @__PURE__ */ new Set(), r);
  const i = L(e), n = new TextEncoder().encode(i).length, { estimatedBytes: o, ...a } = r, s = { bytes: n, ...a };
  if (n > t.maxBytes)
    throw new C(
      "$",
      "maximum encoded bytes exceeded",
      s
    );
  return { canonical: i, usage: s };
}, rt = (e) => new TextEncoder().encode(L(e)), V = (e) => !e || typeof e != "object" || Object.isFrozen(e) || ArrayBuffer.isView(e) ? e : (Array.isArray(e) ? e.forEach((t) => V(t)) : Object.values(e).forEach((t) => V(t)), Object.freeze(e)), K = (e, t) => e >>> t | e << 32 - t, Se = Object.freeze([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), we = (e) => (e >>> 0).toString(16).padStart(8, "0"), ke = (e) => {
  const t = new TextEncoder().encode(e), r = t.length * 8, i = Math.ceil((t.length + 9) / 64) * 64, n = new Uint8Array(i);
  n.set(t), n[t.length] = 128;
  const o = new DataView(n.buffer), a = Math.floor(r / 4294967296), s = r >>> 0;
  o.setUint32(i - 8, a), o.setUint32(i - 4, s);
  const p = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]), d = new Uint32Array(64);
  for (let y = 0; y < n.length; y += 64) {
    for (let w = 0; w < 16; w += 1)
      d[w] = o.getUint32(y + w * 4);
    for (let w = 16; w < 64; w += 1) {
      const z = d[w - 15], _ = d[w - 2], G = K(z, 7) ^ K(z, 18) ^ z >>> 3, Q = K(_, 17) ^ K(_, 19) ^ _ >>> 10;
      d[w] = d[w - 16] + G + d[w - 7] + Q >>> 0;
    }
    let [l, A, T, q, O, N, U, X] = p;
    for (let w = 0; w < 64; w += 1) {
      const z = K(O, 6) ^ K(O, 11) ^ K(O, 25), _ = O & N ^ ~O & U, G = X + z + _ + Se[w] + d[w] >>> 0, Q = K(l, 2) ^ K(l, 13) ^ K(l, 22), be = l & A ^ l & T ^ A & T, Ae = Q + be >>> 0;
      X = U, U = N, N = O, O = q + G >>> 0, q = T, T = A, A = l, l = G + Ae >>> 0;
    }
    p[0] = p[0] + l >>> 0, p[1] = p[1] + A >>> 0, p[2] = p[2] + T >>> 0, p[3] = p[3] + q >>> 0, p[4] = p[4] + O >>> 0, p[5] = p[5] + N >>> 0, p[6] = p[6] + U >>> 0, p[7] = p[7] + X >>> 0;
  }
  return [...p].map(we).join("");
}, Fe = (e) => `sha256:${ke(L(e))}`, De = (e) => e.slice(0, 20), u = V({
  maxBytes: 2e6,
  maxDepth: 48,
  maxArrayEntries: 8192,
  maxObjectKeys: 40,
  maxTotalObjectKeys: 65536,
  maxRuns: 1,
  maxItems: 64,
  maxEvents: 4096,
  maxRefs: 512,
  maxApprovals: 64,
  maxCitations: 256,
  maxDiagnostics: 32,
  maxAuditEntries: 4096,
  maxRecoveryRetries: 3,
  maxLabelLength: 160,
  maxSafeDisplayLength: 320,
  maxRefLength: 160,
  maxToolScopes: 32,
  maxDependenciesPerItem: 32
}), $ = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), S = (e, t, r = []) => $(e) && t.every((i) => Object.hasOwn(e, i)) && Object.keys(e).every(
  (i) => t.includes(i) || r.includes(i)
), c = (e) => typeof e == "string" && e.length > 0 && e.length <= u.maxRefLength && /^[A-Za-z0-9_.:-]+$/.test(e), f = (e) => typeof e == "string" && /^sha256:[a-f0-9]{64}$/.test(e), E = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, m = (e, t) => Fe({ domain: e, value: t }), v = (e) => {
  const { canonical: t } = le(e, {
    maxBytes: u.maxBytes,
    maxDepth: u.maxDepth,
    maxArrayEntries: u.maxArrayEntries,
    maxObjectKeys: u.maxObjectKeys,
    maxTotalObjectKeys: u.maxTotalObjectKeys
  });
  return V(JSON.parse(t));
}, M = (e, t) => {
  try {
    return L(e) === L(t);
  } catch {
    return !1;
  }
}, Ee = /* @__PURE__ */ new Set([
  "prompt",
  "documentText",
  "toolArguments",
  "toolResult",
  "snippet",
  "uri",
  "url",
  "query",
  "token",
  "secret",
  "password",
  "apiKey",
  "stack",
  "providerBody",
  "providerMetadata",
  "editor",
  "transaction",
  "yDoc",
  "dispatch",
  "callback",
  "fetch",
  "socket"
]), me = (e, t, r) => {
  if (e == null) return null;
  if (typeof e == "function" || typeof e == "symbol")
    return g("agent-input-invalid", "contract");
  if (typeof e != "object") return null;
  if (r > u.maxDepth || t.has(e))
    return g("agent-resource-exceeded", "contract");
  if (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)
    return g("agent-input-invalid", "contract");
  const i = Object.getPrototypeOf(e);
  if (!Array.isArray(e) && i !== Object.prototype && i !== null)
    return g("agent-input-invalid", "contract");
  t.add(e);
  const n = Array.isArray(e) ? e.map((o, a) => [String(a), o]) : Object.entries(e);
  for (const [o, a] of n) {
    if (Ee.has(o))
      return t.delete(e), g("agent-input-invalid", "contract", {
        category: "forbidden-field"
      });
    const s = me(a, t, r + 1);
    if (s)
      return t.delete(e), s;
  }
  return t.delete(e), null;
}, j = (e) => {
  try {
    return le(e, {
      maxBytes: u.maxBytes,
      maxDepth: u.maxDepth,
      maxArrayEntries: u.maxArrayEntries,
      maxObjectKeys: u.maxObjectKeys,
      maxTotalObjectKeys: u.maxTotalObjectKeys
    }), me(e, /* @__PURE__ */ new Set(), 0);
  } catch {
    return g("agent-resource-exceeded", "contract");
  }
}, g = (e, t, r = {}) => V({
  code: e,
  stage: t,
  ...Number.isSafeInteger(r.ordinal) && (r.ordinal ?? -1) >= 0 ? { ordinal: r.ordinal } : {},
  ...Number.isSafeInteger(r.count) && (r.count ?? -1) >= 0 ? { count: Math.min(r.count, 1e6) } : {},
  ...r.category && /^[a-z0-9-]{1,80}$/.test(r.category) ? { category: r.category } : {},
  ...r.fingerprint ? { fingerprintPrefix: De(r.fingerprint) } : {}
}), F = (e) => {
  const { fingerprint: t, ...r } = e;
  return r;
}, h = "1.0.0", R = (e = "agent-input-invalid", t = "contract", r) => ({
  ok: !1,
  diagnostic: g(e, t, { category: r })
}), qe = /* @__PURE__ */ new Set([
  "permission",
  "source",
  "context",
  "base-document",
  "descriptor",
  "runtime",
  "policy"
]), J = (e) => !S(e, ["kind", "ref", "fingerprint"]) || !qe.has(e.kind) || !c(e.ref) || !f(e.fingerprint) ? R() : {
  ok: !0,
  value: v(
    e
  )
}, ne = (e) => !S(e, [
  "documentRef",
  "baseDocumentFingerprint",
  "baseRevisionRef",
  "stateVectorRef",
  "scopeRef",
  "descriptorRef",
  "runtimeRef",
  "policyRef",
  "intentFingerprint"
]) || !c(e.documentRef) || !f(e.baseDocumentFingerprint) || !c(e.baseRevisionRef) || !c(e.stateVectorRef) || !c(e.scopeRef) || !c(e.descriptorRef) || !c(e.runtimeRef) || !c(e.policyRef) || !f(e.intentFingerprint) ? R() : {
  ok: !0,
  value: v(
    e
  )
}, ue = /* @__PURE__ */ new Set(["document", "tool"]), Oe = /* @__PURE__ */ new Set([
  "prepared",
  "running",
  "waiting-tool-approval",
  "waiting-document-review",
  "aborting",
  "blocked",
  "sealed"
]), Te = /* @__PURE__ */ new Set([
  "succeeded",
  "failed",
  "aborted",
  "denied",
  "rejected",
  "refine-required",
  "conflict",
  "rebase-required",
  "revoked",
  "superseded"
]), Re = /* @__PURE__ */ new Set([
  "tool-execution",
  "document-review",
  "document-commit",
  "abort-acknowledgement",
  "zero-effect"
]), Ke = (e) => {
  if (!S(
    e,
    [
      "itemRef",
      "kind",
      "required",
      "attemptRef",
      "dependencies",
      "dependsOnItemRefs",
      "status",
      "fingerprint"
    ],
    [
      "predecessorAttemptRef",
      "outcome",
      "receiptRef",
      "receiptKind",
      "effectRef",
      "toolApprovalDecisionReceiptRef",
      "toolApprovalDecisionFingerprint",
      "toolExecutionReceiptRef",
      "toolExecutionFingerprint",
      "reviewDecisionReceiptRef",
      "reviewDecisionFingerprint",
      "documentCommitReceiptRef",
      "documentCommitFingerprint",
      "undoReceiptRef",
      "originReceiptRef",
      "document"
    ]
  ) || !c(e.itemRef) || !ue.has(e.kind) || typeof e.required != "boolean" || !c(e.attemptRef) || e.predecessorAttemptRef !== void 0 && !c(e.predecessorAttemptRef) || !Array.isArray(e.dependencies) || e.dependencies.length > u.maxDependenciesPerItem || !Array.isArray(e.dependsOnItemRefs) || e.dependsOnItemRefs.some((r) => !c(r)) || !Oe.has(e.status) || e.outcome !== void 0 && !Te.has(e.outcome) || e.receiptRef !== void 0 && !c(e.receiptRef) || e.receiptKind !== void 0 && !Re.has(e.receiptKind) || e.effectRef !== void 0 && !c(e.effectRef) || e.toolApprovalDecisionReceiptRef !== void 0 && !c(e.toolApprovalDecisionReceiptRef) || e.toolApprovalDecisionFingerprint !== void 0 && !f(e.toolApprovalDecisionFingerprint) || e.toolExecutionReceiptRef !== void 0 && !c(e.toolExecutionReceiptRef) || e.toolExecutionFingerprint !== void 0 && !f(e.toolExecutionFingerprint) || e.reviewDecisionReceiptRef !== void 0 && !c(e.reviewDecisionReceiptRef) || e.reviewDecisionFingerprint !== void 0 && !f(e.reviewDecisionFingerprint) || e.documentCommitReceiptRef !== void 0 && !c(e.documentCommitReceiptRef) || e.documentCommitFingerprint !== void 0 && !f(e.documentCommitFingerprint) || e.undoReceiptRef !== void 0 && !c(e.undoReceiptRef) || e.originReceiptRef !== void 0 && !c(e.originReceiptRef) || !f(e.fingerprint))
    return R();
  for (const r of e.dependencies)
    if (!J(r).ok) return R();
  if (e.kind === "document" && (e.document === void 0 || !ne(e.document).ok))
    return R("agent-authority-mismatch", "authority");
  if (e.kind === "tool" && e.document !== void 0) return R();
  const t = e;
  return t.fingerprint !== m(
    "zx-agent-integration/v1/item",
    F(t)
  ) ? R("agent-authority-mismatch", "authority") : { ok: !0, value: v(t) };
}, je = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if ($(e) && Array.isArray(e.items) && e.items.length > u.maxItems)
    return R("agent-resource-exceeded", "contract");
  if (!S(e, [
    "version",
    "runRef",
    "runPrincipalRef",
    "purposeDigest",
    "policyRef",
    "policyFingerprint",
    "logicalTime",
    "items"
  ]) || e.version !== h || !c(e.runRef) || !c(e.runPrincipalRef) || !f(e.purposeDigest) || !c(e.policyRef) || !f(e.policyFingerprint) || !E(e.logicalTime) || !Array.isArray(e.items) || e.items.length === 0 || !e.items.some(
    (o) => $(o) && o.required === !0
  ) || e.items.length > u.maxItems)
    return R(
      e && $(e) && e.version !== h ? "agent-version-unsupported" : "agent-input-invalid"
    );
  const r = /* @__PURE__ */ new Set();
  let i = 3;
  for (const o of e.items) {
    if (!$(o) || !c(o.itemRef) || r.has(o.itemRef) || !ue.has(o.kind) || typeof o.required != "boolean" || !c(o.attemptRef) || o.predecessorAttemptRef !== void 0 && !c(o.predecessorAttemptRef) || !Array.isArray(o.dependencies) || o.dependencies.length > u.maxDependenciesPerItem || !Array.isArray(o.dependsOnItemRefs))
      return R();
    if (r.add(o.itemRef), i += 2 + (o.predecessorAttemptRef === void 0 ? 0 : 1) + o.dependencies.length + o.dependsOnItemRefs.length + (o.kind === "document" ? 7 : 0), i > u.maxRefs)
      return R("agent-resource-exceeded", "contract");
    for (const a of o.dependencies)
      if (!J(a).ok) return R();
    if (o.kind === "document" && !ne(o.document).ok)
      return R("agent-authority-mismatch", "authority");
  }
  for (const o of e.items)
    if (o.dependsOnItemRefs.some((a) => !c(a) || !r.has(a)))
      return R("agent-authority-mismatch", "authority");
  const n = e.items.filter(
    (o) => o.kind === "document"
  );
  for (let o = 0; o < n.length; o += 1)
    for (let a = o + 1; a < n.length; a += 1) {
      const s = n[o], p = n[a];
      if (s.document.documentRef === p.document.documentRef && !s.dependsOnItemRefs.includes(p.itemRef) && !p.dependsOnItemRefs.includes(s.itemRef))
        return R("agent-authority-mismatch", "authority");
    }
  return {
    ok: !0,
    value: v(e)
  };
}, oe = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(
    e,
    [
      "version",
      "ref",
      "kind",
      "safeLabel",
      "redactionReceiptRef",
      "sourceSnapshotFingerprint",
      "permissionSnapshotFingerprint",
      "dependencySnapshots",
      "resolverCapabilityRef",
      "status",
      "order",
      "dedupeKey",
      "outcomeBindingRef",
      "fingerprint"
    ],
    ["safeReason"]
  ) || e.version !== h || !c(e.ref) || !(/* @__PURE__ */ new Set(["source", "context", "citation", "provenance"])).has(
    e.kind
  ) || typeof e.safeLabel != "string" || e.safeLabel.length === 0 || e.safeLabel.length > u.maxLabelLength || !c(e.redactionReceiptRef) || !f(e.sourceSnapshotFingerprint) || !f(e.permissionSnapshotFingerprint) || !Array.isArray(e.dependencySnapshots) || e.dependencySnapshots.length < 3 || e.dependencySnapshots.length > u.maxDependenciesPerItem || e.dependencySnapshots.some(
    (a) => !J(a).ok
  ) || !c(e.resolverCapabilityRef) || !(/* @__PURE__ */ new Set(["available", "unavailable", "revoked"])).has(
    e.status
  ) || e.safeReason !== void 0 && !(/* @__PURE__ */ new Set([
    "no-access",
    "deleted-source",
    "resolver-timeout",
    "citation-mismatch",
    "permission-revoked"
  ])).has(e.safeReason) || e.status === "available" && e.safeReason !== void 0 || e.status !== "available" && e.safeReason === void 0 || !Number.isSafeInteger(e.order) || e.order < 0 || !f(e.dedupeKey) || !c(e.outcomeBindingRef) || !f(e.fingerprint))
    return R();
  const r = e, i = r.dependencySnapshots.find(
    (a) => a.kind === "permission"
  ), n = r.dependencySnapshots.find(
    (a) => a.kind === "source"
  ), o = r.dependencySnapshots.find(
    (a) => a.kind === "context"
  );
  return !i || !n || !o || i.fingerprint !== r.permissionSnapshotFingerprint || n.fingerprint !== r.sourceSnapshotFingerprint || new Set(
    r.dependencySnapshots.map(
      (a) => `${a.kind}:${a.ref}`
    )
  ).size !== r.dependencySnapshots.length || r.fingerprint !== m(
    "zx-agent-integration/v1/source-ref",
    F(r)
  ) ? R("agent-authority-mismatch", "authority") : { ok: !0, value: v(r) };
}, Ie = /* @__PURE__ */ new Set([
  "run-started",
  "item-started",
  "tool-approval-requested",
  "tool-decision-observed",
  "tool-execution-observed",
  "document-review-observed",
  "document-commit-observed",
  "dependency-revoked",
  "citation-status-observed",
  "capability-unavailable",
  "abort-requested",
  "abort-acknowledged",
  "retry-item",
  "host-summary-observed",
  "checkpoint-observed"
]), Pe = /* @__PURE__ */ new Set([
  "succeeded",
  "partially-succeeded",
  "failed",
  "aborted",
  "denied",
  "rejected",
  "refine-required",
  "conflict",
  "rebase-required",
  "revoked",
  "superseded"
]), se = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(
    e,
    [
      "version",
      "eventRef",
      "runRef",
      "runPrincipalRef",
      "expectedRunRevision",
      "sequence",
      "logicalTime",
      "predecessorFingerprint",
      "kind",
      "fingerprint"
    ],
    [
      "itemRef",
      "dependencyFingerprint",
      "outcome",
      "receiptRef",
      "receiptFingerprint",
      "receiptKind",
      "approvalDecisionFingerprint",
      "reviewDecision",
      "undoReceiptRef",
      "originReceiptRef",
      "citation",
      "freshAttemptRef",
      "freshDependencies",
      "freshDocument",
      "idempotencyKey",
      "expiresAt"
    ]
  ) || e.version !== h || !c(e.eventRef) || !c(e.runRef) || !c(e.runPrincipalRef) || !Number.isSafeInteger(e.expectedRunRevision) || e.expectedRunRevision < 0 || !Number.isSafeInteger(e.sequence) || e.sequence < 0 || !E(e.logicalTime) || !f(e.predecessorFingerprint) || !Ie.has(e.kind) || e.itemRef !== void 0 && !c(e.itemRef) || e.dependencyFingerprint !== void 0 && !f(e.dependencyFingerprint) || e.outcome !== void 0 && !Pe.has(e.outcome) || e.receiptRef !== void 0 && !c(e.receiptRef) || e.receiptFingerprint !== void 0 && !f(e.receiptFingerprint) || e.receiptKind !== void 0 && !Re.has(e.receiptKind) || e.approvalDecisionFingerprint !== void 0 && !f(e.approvalDecisionFingerprint) || e.reviewDecision !== void 0 && !(/* @__PURE__ */ new Set(["accept", "reject", "refine", "supersede"])).has(
    e.reviewDecision
  ) || e.undoReceiptRef !== void 0 && !c(e.undoReceiptRef) || e.originReceiptRef !== void 0 && !c(e.originReceiptRef) || e.freshAttemptRef !== void 0 && !c(e.freshAttemptRef) || e.idempotencyKey !== void 0 && !c(e.idempotencyKey) || e.expiresAt !== void 0 && !E(e.expiresAt) || !f(e.fingerprint) || e.citation !== void 0 && !oe(e.citation).ok || e.freshDependencies !== void 0 && (!Array.isArray(e.freshDependencies) || e.freshDependencies.some(
    (i) => !J(i).ok
  )) || e.freshDocument !== void 0 && !ne(e.freshDocument).ok)
    return R();
  const r = e;
  return r.fingerprint !== m(
    "zx-agent-integration/v1/event",
    F(r)
  ) ? R("agent-authority-mismatch", "authority") : { ok: !0, value: v(r) };
}, Ve = /* @__PURE__ */ new Set([
  "request-tool-approval",
  "abort-tool-execution",
  "abort-document-operation",
  "request-citation-reveal",
  "request-missing-range",
  "request-current-checkpoint",
  "verify-terminal-root",
  "request-effect-status",
  "request-abort-status",
  "require-fresh-admission",
  "mark-unrecoverable"
]), Ne = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(
    e,
    [
      "version",
      "effectRef",
      "idempotencyKey",
      "expectedRunRevision",
      "itemRef",
      "attemptRef",
      "intentFingerprint",
      "dependencySnapshots",
      "expiresAt",
      "kind",
      "payloadFingerprint",
      "fingerprint"
    ],
    ["recovery"]
  ) || e.version !== h || !c(e.effectRef) || !c(e.idempotencyKey) || !Number.isSafeInteger(e.expectedRunRevision) || e.expectedRunRevision < 0 || !c(e.itemRef) || !c(e.attemptRef) || !f(e.intentFingerprint) || !Array.isArray(e.dependencySnapshots) || e.dependencySnapshots.length > u.maxDependenciesPerItem || e.dependencySnapshots.some(
    (i) => !J(i).ok
  ) || !E(e.expiresAt) || !Ve.has(e.kind) || e.recovery !== void 0 && (!S(e.recovery, [
    "firstSequence",
    "lastSequence",
    "expectedPredecessorFingerprint",
    "maxRetries"
  ]) || !Number.isSafeInteger(e.recovery.firstSequence) || e.recovery.firstSequence < 0 || !Number.isSafeInteger(e.recovery.lastSequence) || e.recovery.lastSequence < e.recovery.firstSequence || e.recovery.lastSequence - e.recovery.firstSequence + 1 > u.maxEvents || !f(e.recovery.expectedPredecessorFingerprint) || e.recovery.maxRetries !== u.maxRecoveryRetries) || (/* @__PURE__ */ new Set([
    "request-missing-range",
    "request-current-checkpoint",
    "verify-terminal-root",
    "request-effect-status",
    "request-abort-status",
    "mark-unrecoverable"
  ])).has(e.kind) !== (e.recovery !== void 0) || !f(e.payloadFingerprint) || !f(e.fingerprint))
    return R();
  const r = e;
  return r.fingerprint !== m(
    "zx-agent-integration/v1/effect",
    F(r)
  ) ? R("agent-authority-mismatch", "authority") : { ok: !0, value: v(r) };
}, Ce = /* @__PURE__ */ new Set([
  "agent-input-invalid",
  "agent-version-unsupported",
  "agent-resource-exceeded",
  "agent-revision-conflict",
  "agent-event-gap",
  "agent-event-duplicate-conflict",
  "agent-event-late",
  "agent-authority-mismatch",
  "agent-dependency-revoked",
  "agent-capability-unavailable",
  "agent-summary-conflict",
  "agent-historical-audit-only"
]), ze = /* @__PURE__ */ new Set([
  "contract",
  "host-admission",
  "event",
  "authority",
  "projection",
  "recovery",
  "historical"
]), _e = (e) => !S(
  e,
  ["code", "stage"],
  ["ordinal", "count", "category", "fingerprintPrefix"]
) || !Ce.has(e.code) || !ze.has(e.stage) || e.ordinal !== void 0 && (!Number.isSafeInteger(e.ordinal) || e.ordinal < 0) || e.count !== void 0 && (!Number.isSafeInteger(e.count) || e.count < 0) || e.category !== void 0 && (typeof e.category != "string" || !/^[a-z0-9-]{1,80}$/.test(e.category)) || e.fingerprintPrefix !== void 0 && (typeof e.fingerprintPrefix != "string" || !/^[a-f0-9]{1,16}$/.test(e.fingerprintPrefix)) ? R() : {
  ok: !0,
  value: v(e)
}, $e = (e) => {
  if (!S(
    e,
    [
      "eventRef",
      "sequence",
      "revision",
      "predecessorFingerprint",
      "eventFingerprint",
      "transition",
      "logicalTime",
      "authorityReceiptRoots",
      "dependencySnapshotRoots",
      "fingerprint"
    ],
    ["attemptRef"]
  ) || !c(e.eventRef) || !Number.isSafeInteger(e.sequence) || e.sequence < 0 || !Number.isSafeInteger(e.revision) || e.revision < 0 || e.attemptRef !== void 0 && !c(e.attemptRef) || !f(e.predecessorFingerprint) || !f(e.eventFingerprint) || !(/* @__PURE__ */ new Set([
    "accepted",
    "accepted-idempotent",
    "late-observation",
    "rejected"
  ])).has(e.transition) || !E(e.logicalTime) || !Array.isArray(e.authorityReceiptRoots) || e.authorityReceiptRoots.some((r) => !f(r)) || !Array.isArray(e.dependencySnapshotRoots) || e.dependencySnapshotRoots.some((r) => !f(r)) || !f(e.fingerprint))
    return R();
  const t = e;
  return t.fingerprint !== m(
    "zx-agent-integration/v1/audit-node",
    F(t)
  ) ? R("agent-authority-mismatch", "authority") : { ok: !0, value: v(t) };
}, Be = /* @__PURE__ */ new Set([
  "prepared",
  "running",
  "waiting-tool-approval",
  "waiting-document-review",
  "pending-review",
  "aborting",
  "blocked",
  "terminal"
]), Le = /* @__PURE__ */ new Set([
  "succeeded",
  "partially-succeeded",
  "failed",
  "aborted"
]), Y = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(
    e,
    [
      "version",
      "runRef",
      "runPrincipalRef",
      "purposeDigest",
      "policyRef",
      "policyFingerprint",
      "logicalTime",
      "revision",
      "nextExpectedSequence",
      "status",
      "items",
      "citations",
      "effects",
      "diagnostics",
      "audit",
      "fingerprint"
    ],
    ["outcome"]
  ) || e.version !== h || !c(e.runRef) || !c(e.runPrincipalRef) || !f(e.purposeDigest) || !c(e.policyRef) || !f(e.policyFingerprint) || !E(e.logicalTime) || !Number.isSafeInteger(e.revision) || !Number.isSafeInteger(e.nextExpectedSequence) || !Be.has(e.status) || e.outcome !== void 0 && !Le.has(e.outcome) || !Array.isArray(e.items) || e.items.length === 0 || e.items.length > u.maxItems || !Array.isArray(e.citations) || e.citations.length > u.maxCitations || !Array.isArray(e.effects) || e.effects.length > u.maxItems || !Array.isArray(e.diagnostics) || e.diagnostics.length > u.maxDiagnostics || !Array.isArray(e.audit) || e.audit.length > u.maxAuditEntries || !f(e.fingerprint))
    return R();
  for (const i of e.items) if (!Ke(i).ok) return R();
  for (const i of e.citations)
    if (!oe(i).ok) return R();
  for (const i of e.effects)
    if (!Ne(i).ok) return R();
  for (const i of e.diagnostics)
    if (!_e(i).ok) return R();
  for (const i of e.audit)
    if (!$e(i).ok) return R();
  const r = e;
  return r.status === "terminal" != !!r.outcome || r.status === "terminal" && !r.items.filter((i) => i.required).every((i) => i.status === "sealed") ? R("agent-summary-conflict", "event") : r.fingerprint !== m(
    "zx-agent-integration/v1/run",
    F(r)
  ) ? R("agent-authority-mismatch", "authority") : { ok: !0, value: v(r) };
}, it = (e) => {
  const t = Y(e);
  if (t.ok === !1) throw new TypeError(t.diagnostic.code);
  return JSON.stringify(t.value);
}, nt = (e) => V({
  version: h,
  status: "audit-only",
  diagnostic: g(
    "agent-historical-audit-only",
    "historical",
    {
      fingerprint: m(
        "zx-agent-integration/v1/historical",
        e
      )
    }
  ),
  fingerprint: m(
    "zx-agent-integration/v1/historical-result",
    {
      status: "audit-only",
      inputFingerprint: m(
        "zx-agent-integration/v1/historical",
        e
      )
    }
  )
}), Me = [
  "version",
  "requestRef",
  "runRef",
  "runPrincipalRef",
  "approvalActorRef",
  "targetPrincipalRef",
  "approvalAuthorityRef",
  "effectRef",
  "expectedRunRevision",
  "permissionSnapshotRef",
  "dependencySnapshots",
  "toolRef",
  "toolVersion",
  "schemaFingerprint",
  "intentDigest",
  "risk",
  "capability",
  "scopeRefs",
  "targetRefs",
  "safeDisplay",
  "redactionReceiptRef",
  "expiresAt",
  "oneShotKey",
  "fingerprint"
], ye = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(e, Me) || e.version !== h || !c(e.requestRef) || !c(e.runRef) || !c(e.runPrincipalRef) || !c(e.approvalActorRef) || !c(e.targetPrincipalRef) || !c(e.approvalAuthorityRef) || !c(e.effectRef) || !Number.isSafeInteger(e.expectedRunRevision) || e.expectedRunRevision < 0 || !S(e.permissionSnapshotRef, [
    "kind",
    "ref",
    "fingerprint"
  ]) || e.permissionSnapshotRef.kind !== "permission" || !c(e.permissionSnapshotRef.ref) || !f(e.permissionSnapshotRef.fingerprint) || !Array.isArray(e.dependencySnapshots) || e.dependencySnapshots.length === 0 || e.dependencySnapshots.length > u.maxDependenciesPerItem || e.dependencySnapshots.some(
    (i) => !S(i, ["kind", "ref", "fingerprint"]) || !(/* @__PURE__ */ new Set([
      "permission",
      "source",
      "context",
      "base-document",
      "descriptor",
      "runtime",
      "policy"
    ])).has(i.kind) || !c(i.ref) || !f(i.fingerprint)
  ) || !c(e.toolRef) || typeof e.toolVersion != "string" || e.toolVersion.length === 0 || e.toolVersion.length > 40 || !f(e.schemaFingerprint) || !f(e.intentDigest) || !(/* @__PURE__ */ new Set(["low", "medium", "high", "critical"])).has(e.risk) || !(/* @__PURE__ */ new Set(["read", "write", "send", "delete", "execute"])).has(
    e.capability
  ) || !Array.isArray(e.scopeRefs) || e.scopeRefs.length === 0 || e.scopeRefs.length > u.maxToolScopes || e.scopeRefs.some((i) => !c(i)) || !Array.isArray(e.targetRefs) || e.targetRefs.length === 0 || e.targetRefs.some((i) => !c(i)) || typeof e.safeDisplay != "string" || e.safeDisplay.length === 0 || e.safeDisplay.length > u.maxSafeDisplayLength || !c(e.redactionReceiptRef) || !E(e.expiresAt) || !c(e.oneShotKey) || !f(e.fingerprint))
    return {
      ok: !1,
      diagnostic: g("agent-input-invalid", "authority")
    };
  const r = e;
  return !r.dependencySnapshots.some(
    (i) => i.kind === "permission" && M(i, r.permissionSnapshotRef)
  ) || new Set(
    r.dependencySnapshots.map(
      (i) => `${i.kind}:${i.ref}`
    )
  ).size !== r.dependencySnapshots.length ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "authority"
    )
  } : r.fingerprint !== m(
    "zx-agent-integration/v1/tool-approval-request",
    F(r)
  ) ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "authority"
    )
  } : { ok: !0, value: v(r) };
}, ot = (e) => {
  const t = {
    version: h,
    ...e
  }, r = {
    ...t,
    fingerprint: m(
      "zx-agent-integration/v1/tool-approval-request",
      t
    )
  }, i = ye(r);
  if (i.ok === !1) throw new TypeError(i.diagnostic.code);
  return i.value;
}, st = (e) => {
  if (!ye(e.request).ok || !c(e.receiptRef) || e.approvalActorRef !== e.request.approvalActorRef || e.targetPrincipalRef !== e.request.targetPrincipalRef || e.approvalAuthorityRef !== e.request.approvalAuthorityRef || e.permissionSnapshotFingerprint !== e.request.permissionSnapshotRef.fingerprint || !(/* @__PURE__ */ new Set(["approve", "deny", "cancel"])).has(e.decision) || !E(e.decidedAt) || e.decidedAt > e.request.expiresAt)
    return {
      ok: !1,
      diagnostic: g(
        "agent-authority-mismatch",
        "authority"
      )
    };
  const r = {
    version: h,
    receiptRef: e.receiptRef,
    requestFingerprint: e.request.fingerprint,
    runRef: e.request.runRef,
    runPrincipalRef: e.request.runPrincipalRef,
    approvalActorRef: e.approvalActorRef,
    targetPrincipalRef: e.targetPrincipalRef,
    approvalAuthorityRef: e.approvalAuthorityRef,
    permissionSnapshotFingerprint: e.permissionSnapshotFingerprint,
    decision: e.decision,
    decidedAt: e.decidedAt,
    expiresAt: e.request.expiresAt,
    oneShotScope: e.request.oneShotKey
  };
  return {
    ok: !0,
    value: v({
      ...r,
      fingerprint: m(
        "zx-agent-integration/v1/tool-decision",
        r
      )
    })
  };
}, Je = [
  "version",
  "receiptRef",
  "requestFingerprint",
  "runRef",
  "runPrincipalRef",
  "approvalActorRef",
  "targetPrincipalRef",
  "approvalAuthorityRef",
  "permissionSnapshotFingerprint",
  "decision",
  "decidedAt",
  "expiresAt",
  "oneShotScope",
  "fingerprint"
], ct = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(e, Je) || e.version !== h || !c(e.receiptRef) || !f(e.requestFingerprint) || !c(e.runRef) || !c(e.runPrincipalRef) || !c(e.approvalActorRef) || !c(e.targetPrincipalRef) || !c(e.approvalAuthorityRef) || !f(e.permissionSnapshotFingerprint) || !(/* @__PURE__ */ new Set(["approve", "deny", "cancel"])).has(e.decision) || !E(e.decidedAt) || !E(e.expiresAt) || e.decidedAt > e.expiresAt || !c(e.oneShotScope) || !f(e.fingerprint))
    return {
      ok: !1,
      diagnostic: g("agent-input-invalid", "authority")
    };
  const r = e;
  return r.fingerprint !== m(
    "zx-agent-integration/v1/tool-decision",
    F(r)
  ) ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "authority"
    )
  } : { ok: !0, value: v(r) };
}, Ue = [
  "version",
  "receiptRef",
  "approvalDecisionFingerprint",
  "effectRef",
  "idempotencyKey",
  "expectedRunRevision",
  "runRef",
  "runPrincipalRef",
  "targetPrincipalRef",
  "intentFingerprint",
  "permissionSnapshotFingerprint",
  "dependencySnapshots",
  "expiresAt",
  "status",
  "terminalAt",
  "safeResultDigest",
  "fingerprint"
], ce = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(e, Ue, [
    "simulationScope",
    "fixtureFingerprint"
  ]) || e.version !== h || !c(e.receiptRef) || !f(e.approvalDecisionFingerprint) || !c(e.effectRef) || !c(e.idempotencyKey) || !Number.isSafeInteger(e.expectedRunRevision) || e.expectedRunRevision < 0 || !c(e.runRef) || !c(e.runPrincipalRef) || !c(e.targetPrincipalRef) || !f(e.intentFingerprint) || !f(e.permissionSnapshotFingerprint) || !Array.isArray(e.dependencySnapshots) || e.dependencySnapshots.length === 0 || e.dependencySnapshots.length > u.maxDependenciesPerItem || e.dependencySnapshots.some(
    (n) => !S(n, ["kind", "ref", "fingerprint"]) || !(/* @__PURE__ */ new Set([
      "permission",
      "source",
      "context",
      "base-document",
      "descriptor",
      "runtime",
      "policy"
    ])).has(n.kind) || !c(n.ref) || !f(n.fingerprint)
  ) || !E(e.expiresAt) || !(/* @__PURE__ */ new Set(["succeeded", "failed", "aborted"])).has(e.status) || !E(e.terminalAt) || e.terminalAt > e.expiresAt || !f(e.safeResultDigest) || e.simulationScope !== void 0 && e.simulationScope !== "simulation" || e.fixtureFingerprint !== void 0 && !f(e.fixtureFingerprint) || e.simulationScope === "simulation" != (e.fixtureFingerprint !== void 0) || !f(e.fingerprint))
    return {
      ok: !1,
      diagnostic: g("agent-input-invalid", "authority")
    };
  const r = e, i = r.dependencySnapshots.find(
    (n) => n.kind === "permission"
  );
  return !i || i.fingerprint !== r.permissionSnapshotFingerprint || new Set(
    r.dependencySnapshots.map(
      (n) => `${n.kind}:${n.ref}`
    )
  ).size !== r.dependencySnapshots.length ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "authority"
    )
  } : r.fingerprint !== m(
    "zx-agent-integration/v1/tool-execution",
    F(r)
  ) ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "authority"
    )
  } : { ok: !0, value: v(r) };
}, at = (e) => {
  const t = {
    version: h,
    ...e,
    receiptRef: e.receiptRef
  }, r = {
    ...t,
    fingerprint: m(
      "zx-agent-integration/v1/tool-execution",
      t
    )
  }, i = ce(r);
  if (i.ok === !1) throw new TypeError(i.diagnostic.code);
  return i.value;
}, dt = (e) => e.decision.decision === "approve" && e.decision.requestFingerprint === e.request.fingerprint && e.execution.approvalDecisionFingerprint === e.decision.fingerprint && e.execution.effectRef === e.request.effectRef && e.execution.expectedRunRevision === e.request.expectedRunRevision && e.execution.runRef === e.request.runRef && e.execution.runPrincipalRef === e.request.runPrincipalRef && e.execution.targetPrincipalRef === e.request.targetPrincipalRef && e.execution.intentFingerprint === e.request.intentDigest && e.execution.permissionSnapshotFingerprint === e.request.permissionSnapshotRef.fingerprint && M(
  e.execution.dependencySnapshots,
  e.request.dependencySnapshots
) && M(
  e.execution.dependencySnapshots,
  e.currentDependencySnapshots
) && e.execution.idempotencyKey === e.request.oneShotKey && e.execution.expiresAt === e.request.expiresAt && e.currentLogicalTime <= e.execution.expiresAt && e.execution.terminalAt <= e.execution.expiresAt, W = (e) => {
  const t = j(e);
  if (t) return { ok: !1, diagnostic: t };
  if (!S(e, [
    "version",
    "hostRef",
    "hostVersion",
    "capabilityRefs",
    "policyFingerprint",
    "sourceClosureFingerprint",
    "supportedEventVersions",
    "supportedReceiptVersions",
    "scope",
    "fingerprint"
  ]) || e.version !== h || !c(e.hostRef) || typeof e.hostVersion != "string" || e.hostVersion.length === 0 || e.hostVersion.length > 40 || !Array.isArray(e.capabilityRefs) || e.capabilityRefs.length === 0 || e.capabilityRefs.length > u.maxRefs || e.capabilityRefs.some((i) => !c(i)) || !f(e.policyFingerprint) || !f(e.sourceClosureFingerprint) || !Array.isArray(e.supportedEventVersions) || e.supportedEventVersions.length !== 1 || e.supportedEventVersions.some(
    (i) => i !== h
  ) || !Array.isArray(e.supportedReceiptVersions) || e.supportedReceiptVersions.length !== 1 || e.supportedReceiptVersions.some(
    (i) => i !== h
  ) || !(/* @__PURE__ */ new Set(["simulation", "package-conformance", "deployment"])).has(
    e.scope
  ) || !f(e.fingerprint))
    return {
      ok: !1,
      diagnostic: g(
        "agent-version-unsupported",
        "host-admission"
      )
    };
  const r = e;
  return r.fingerprint !== m(
    "zx-agent-integration/v1/host-descriptor",
    F(r)
  ) ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "host-admission"
    )
  } : { ok: !0, value: v(r) };
}, Ge = (e) => {
  const t = {
    version: h,
    ...e
  }, r = v({
    ...t,
    fingerprint: m(
      "zx-agent-integration/v1/host-descriptor",
      t
    )
  }), i = W(r);
  if (i.ok === !1) throw new TypeError(i.diagnostic.code);
  return i.value;
}, ft = (e) => {
  const t = W(e.descriptor);
  if (!t.ok || t.value.policyFingerprint !== e.expectedPolicyFingerprint || t.value.sourceClosureFingerprint !== e.expectedSourceClosureFingerprint || !f(e.contractFingerprint))
    return {
      ok: !1,
      diagnostic: g(
        "agent-authority-mismatch",
        "host-admission"
      )
    };
  const r = {
    version: h,
    hostRef: t.value.hostRef,
    descriptorFingerprint: t.value.fingerprint,
    contractFingerprint: e.contractFingerprint,
    status: "admitted",
    scope: t.value.scope
  };
  return {
    ok: !0,
    value: v({
      ...r,
      fingerprint: m(
        "zx-agent-integration/v1/host-admission",
        r
      )
    })
  };
}, pt = (e, t) => e === "event" ? se(t) : ce(t), gt = (e) => {
  const t = ce(e.receipt);
  return t.ok && t.value.runRef === e.expectedRunRef && t.value.runPrincipalRef === e.expectedRunPrincipalRef && t.value.targetPrincipalRef === e.expectedTargetPrincipalRef && t.value.effectRef === e.expectedEffectRef && t.value.idempotencyKey === e.expectedIdempotencyKey && t.value.expectedRunRevision === e.expectedRunRevision && t.value.intentFingerprint === e.expectedIntentFingerprint && M(
    t.value.dependencySnapshots,
    e.expectedDependencySnapshots
  ) && t.value.expiresAt === e.expectedExpiresAt && t.value.terminalAt <= e.currentLogicalTime && e.currentLogicalTime <= t.value.expiresAt;
}, b = Object.freeze({
  providerLeakage: "AGENT_PORT_PROVIDER_PRIVATE_LEAK",
  packageSideEffect: "AGENT_PACKAGE_DIRECT_SIDE_EFFECT",
  directMutation: "AGENT_DOCUMENT_DIRECT_MUTATION",
  crossDocumentToken: "AGENT_CROSS_DOCUMENT_COMMIT_TOKEN",
  fakeBypass: "AGENT_FAKE_ONLY_BYPASS",
  receiptSubstitution: "AGENT_RECEIPT_AUTHORITY_SUBSTITUTION",
  currentAdmissionRequired: "AGENT_HISTORICAL_ADMISSION_REJECTED",
  citationDiagnosticLeak: "AGENT_CITATION_DIAGNOSTIC_LEAK"
}), He = /* @__PURE__ */ new Map([
  ["provider", b.providerLeakage],
  ["providerMetadata", b.providerLeakage],
  ["toolArguments", b.providerLeakage],
  ["toolResult", b.providerLeakage],
  ["fetch", b.packageSideEffect],
  ["socket", b.packageSideEffect],
  ["storage", b.packageSideEffect],
  ["toolExecutor", b.packageSideEffect],
  ["editor", b.directMutation],
  ["transaction", b.directMutation],
  ["yDoc", b.directMutation],
  ["globalCommitToken", b.crossDocumentToken],
  ["deploymentClaim", b.fakeBypass],
  ["enterpriseClaim", b.fakeBypass],
  ["uri", b.citationDiagnosticLeak],
  ["snippet", b.citationDiagnosticLeak]
]), re = (e, t) => {
  if (!(!e || typeof e != "object")) {
    if (Array.isArray(e)) {
      e.forEach((r) => re(r, t));
      return;
    }
    for (const [r, i] of Object.entries(e)) {
      const n = He.get(r);
      n && t.add(n), re(i, t);
    }
  }
}, lt = (e) => {
  const t = /* @__PURE__ */ new Set(), r = [], i = W(e.descriptor), n = m(
    "zx-agent-integration/v1/rejected-descriptor",
    e.descriptor
  );
  (!i.ok || !f(e.suiteFingerprint) || i.value.policyFingerprint !== e.expectedPolicyFingerprint || i.value.sourceClosureFingerprint !== e.expectedSourceClosureFingerprint) && (t.add(b.currentAdmissionRequired), r.push(
    g("agent-authority-mismatch", "host-admission")
  )), re(e, t), j(e) && (t.size === 0 && t.add(b.providerLeakage), r.push(
    g("agent-input-invalid", "contract", {
      category: "forbidden-field"
    })
  ));
  const o = /* @__PURE__ */ new Map();
  for (const y of e.events) {
    const l = se(y);
    if (l.ok === !1) {
      t.add(b.receiptSubstitution), r.push(l.diagnostic);
      continue;
    }
    const A = o.get(l.value.eventRef);
    A && A !== l.value.fingerprint && t.add(b.receiptSubstitution), o.set(l.value.eventRef, l.value.fingerprint);
  }
  const a = i.ok ? i.value.fingerprint : n, s = i.ok ? i.value.scope : "package-conformance", p = [...t].sort(), d = {
    version: h,
    status: p.length === 0 ? "admitted" : "rejected",
    descriptorFingerprint: a,
    suiteFingerprint: f(e.suiteFingerprint) ? e.suiteFingerprint : m(
      "zx-agent-integration/v1/invalid-suite",
      e.suiteFingerprint
    ),
    findingIds: p,
    diagnostics: r,
    scope: s,
    current: !0
  };
  return v({
    ...d,
    fingerprint: m(
      "zx-agent-integration/v1/conformance-result",
      d
    )
  });
}, mt = (e) => v({
  version: h,
  status: "audit-only",
  inputFingerprint: m(
    "zx-agent-integration/v1/historical-conformance",
    e
  ),
  diagnostic: g(
    "agent-historical-audit-only",
    "historical"
  )
}), he = async (e) => {
  const { readAISessionReviewArtifactTransfer: t } = await import("./handoff-DTkrV4lN.mjs"), r = t(e.transfer);
  if (r.status !== "success" || !c(e.document.documentRef) || !f(e.operationFingerprint) || !c(r.transfer.proposal.identity.proposalId) || !c(r.transfer.sidecar.identity.reviewId) || !f(r.transfer.receipt.fingerprint) || !f(
    r.transfer.proposal.runtimeExecution.trace.fingerprint
  ) || !f(r.transfer.proposal.fingerprint) || !f(r.transfer.proposal.lifecycle.fingerprint) || !f(r.transfer.sidecar.fingerprint))
    return {
      ok: !1,
      diagnostic: g(
        "agent-authority-mismatch",
        "authority"
      )
    };
  const i = {
    documentRef: e.document.documentRef,
    operationReceiptFingerprint: r.transfer.receipt.fingerprint,
    detachedExecutionReceiptFingerprint: r.transfer.proposal.runtimeExecution.trace.fingerprint,
    proposalRef: r.transfer.proposal.identity.proposalId,
    proposalFingerprint: r.transfer.proposal.fingerprint,
    proposalReceiptFingerprint: r.transfer.proposal.lifecycle.fingerprint,
    reviewRef: r.transfer.sidecar.identity.reviewId,
    reviewReceiptRef: r.transfer.sidecar.identity.reviewId,
    reviewFingerprint: r.transfer.sidecar.fingerprint,
    reviewDecision: "pending",
    commitStatus: "awaiting-review"
  };
  return {
    ok: !0,
    value: v({
      ...i,
      fingerprint: m(
        "zx-agent-integration/v1/public-document-authority-handoff",
        {
          ...i,
          operationFingerprint: e.operationFingerprint
        }
      )
    })
  };
}, ut = async (e) => {
  if (e.handoff.sealedResult.kind !== "operation-envelope" || e.handoff.sealedResult.contentDigest !== e.operationFingerprint)
    return {
      ok: !1,
      diagnostic: g(
        "agent-authority-mismatch",
        "authority"
      )
    };
  const { executeAISessionProposalHandoff: t } = await import("./handoff-DTkrV4lN.mjs"), r = await t(
    e.handoff,
    e.runtime
  );
  return r.status !== "awaiting-review" ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "authority"
    )
  } : he({
    document: e.document,
    operationFingerprint: e.operationFingerprint,
    transfer: r.transfer
  });
}, Rt = (e) => he(e), Ze = (e) => {
  const t = {
    version: h,
    ...e
  };
  return v({
    ...t,
    fingerprint: m(
      "zx-agent-integration/v1/event",
      t
    )
  });
}, yt = (e) => {
  const t = Ge({
    hostRef: e.hostRef,
    hostVersion: e.hostVersion,
    capabilityRefs: [
      "capability.agent-events",
      "capability.agent-receipts"
    ],
    policyFingerprint: e.policyFingerprint,
    sourceClosureFingerprint: e.sourceClosureFingerprint,
    supportedEventVersions: [h],
    supportedReceiptVersions: [h],
    scope: "simulation"
  }), r = e.schedule.events.map(Ze), i = m(
    "zx-agent-integration/v1/fake-host-schedule",
    {
      seedRef: e.schedule.seedRef,
      fixtureFingerprint: e.schedule.fixtureFingerprint,
      events: r
    }
  );
  return v({
    descriptor: t,
    scheduleFingerprint: i,
    events: r,
    simulationOnly: !0
  });
}, Ye = (e) => e.status === "waiting-document-review" ? ["review"] : e.status !== "sealed" ? [] : e.outcome === "succeeded" ? e.receiptRef ? ["inspect-receipt", "rerun-as-new-item"] : ["rerun-as-new-item"] : e.receiptRef ? ["inspect-receipt", "retry"] : ["retry"], We = (e) => e.status === "terminal" ? "terminal" : e.status === "pending-review" ? "outcome-review" : e.status === "waiting-tool-approval" ? "tool-approval" : e.status === "waiting-document-review" ? "document-review" : e.status === "aborting" ? "aborting" : e.status === "blocked" ? "blocked" : e.status === "prepared" ? "prepared" : "running", H = (e) => {
  const t = e.items.filter((n) => n.status === "sealed").length, r = e.items.map((n, o) => {
    const a = {
      ordinal: o,
      kind: n.kind,
      status: n.status,
      ...n.outcome ? { outcome: n.outcome } : {},
      receiptAvailable: !!n.receiptRef,
      allowedActions: Ye(n)
    };
    return {
      ...a,
      fingerprint: m(
        "zx-agent-integration/v1/projection-item",
        a
      )
    };
  }), i = {
    version: h,
    runRef: e.runRef,
    status: e.status,
    ...e.outcome ? { outcome: e.outcome } : {},
    stage: We(e),
    progress: { sealed: t, total: e.items.length },
    availableActions: [
      ...e.status !== "terminal" && e.status !== "aborting" ? ["abort"] : [],
      ...e.items.some(
        (n) => n.status === "sealed" && n.outcome !== "succeeded"
      ) ? ["retry"] : [],
      ...e.items.some((n) => n.status === "waiting-document-review") ? ["review"] : []
    ],
    diagnostics: e.diagnostics,
    items: r,
    citations: e.citations.map((n, o) => ({
      ordinal: o,
      safeLabel: n.safeLabel,
      status: n.status,
      ...n.safeReason ? { safeReason: n.safeReason } : {},
      canReveal: n.status === "available"
    }))
  };
  return v({
    ...i,
    fingerprint: m(
      "zx-agent-integration/v1/projection",
      i
    )
  });
}, ht = (e, t) => {
  const r = Y(e);
  if (!r.ok || !f(t))
    throw new TypeError("agent-input-invalid");
  const i = r.value.audit, n = {
    version: h,
    runRef: r.value.runRef,
    firstSequence: i[0]?.sequence ?? 0,
    lastSequence: i.at(-1)?.sequence ?? 0,
    terminalItemRoots: r.value.items.filter((o) => o.status === "sealed").map((o) => o.fingerprint),
    authorityReceiptRoots: i.flatMap(
      (o) => o.authorityReceiptRoots
    ),
    lateEventProofs: i.filter((o) => o.transition === "late-observation").map((o) => o.fingerprint),
    predecessorRoots: i.map((o) => o.predecessorFingerprint),
    dependencySnapshotRoots: i.flatMap(
      (o) => o.dependencySnapshotRoots
    ),
    contractFingerprint: t,
    auditOnly: !0
  };
  return v({
    ...n,
    fingerprint: m(
      "zx-agent-integration/v1/audit-compaction",
      n
    )
  });
}, vt = (e) => {
  const t = Y(e.state), r = W(e.hostDescriptor);
  return !t.ok || !r.ok || e.hostAdmission.status !== "admitted" || e.hostAdmission.hostRef !== r.value.hostRef || e.hostAdmission.descriptorFingerprint !== r.value.fingerprint || e.hostAdmission.contractFingerprint !== e.expectedContractFingerprint || !f(e.expectedContractFingerprint) ? {
    ok: !1,
    diagnostic: g(
      "agent-authority-mismatch",
      "recovery"
    )
  } : t;
}, xt = (e) => {
  const t = {
    version: h,
    ...e
  }, r = v({
    ...t,
    fingerprint: m(
      "zx-agent-integration/v1/source-ref",
      t
    )
  }), i = oe(r);
  if (i.ok === !1) throw new TypeError(i.diagnostic.code);
  return i.value;
}, bt = (e) => {
  const t = e.state.citations.find(
    (i) => i.ref === e.citationRef
  );
  if (!t || t.status !== "available" || e.runPrincipalRef !== e.state.runPrincipalRef || !M(
    t.dependencySnapshots,
    e.dependencySnapshots
  ) || !c(e.citationRef))
    return null;
  const r = {
    version: h,
    effectRef: m(
      "zx-agent-integration/v1/reveal-effect-ref",
      {
        run: e.state.runRef,
        citation: t.ref,
        revision: e.state.revision
      }
    ).slice(0, 48),
    idempotencyKey: m(
      "zx-agent-integration/v1/reveal-key",
      {
        run: e.state.runRef,
        citation: t.ref,
        revision: e.state.revision
      }
    ).slice(0, 48),
    expectedRunRevision: e.state.revision,
    itemRef: t.outcomeBindingRef,
    attemptRef: t.outcomeBindingRef,
    intentFingerprint: t.fingerprint,
    dependencySnapshots: V([...t.dependencySnapshots]),
    expiresAt: e.logicalTime + 1,
    kind: "request-citation-reveal",
    payloadFingerprint: m(
      "zx-agent-integration/v1/reveal-payload",
      {
        citationRef: t.ref,
        runPrincipalRef: e.runPrincipalRef,
        dependencySnapshots: e.dependencySnapshots
      }
    )
  };
  return v({
    ...r,
    fingerprint: m(
      "zx-agent-integration/v1/effect",
      r
    )
  });
}, At = (e) => {
  const t = /* @__PURE__ */ new Map();
  for (const r of e) {
    const i = t.get(r.ref);
    if (i && i !== r.fingerprint) return r;
    t.set(r.ref, r.fingerprint);
  }
  return null;
}, ae = (e) => m("zx-agent-integration/v1/item", e), P = (e, t, r) => {
  const i = {
    ...F(e),
    status: "sealed",
    outcome: t,
    ...r.receiptRef ? { receiptRef: r.receiptRef } : {},
    ...r.receiptKind ? { receiptKind: r.receiptKind } : {}
  };
  return {
    ...i,
    fingerprint: ae(i)
  };
}, D = (e, t) => {
  const r = Object.fromEntries(
    Object.entries({ ...F(e), ...t }).filter(
      ([, i]) => i !== void 0
    )
  );
  return {
    ...r,
    fingerprint: ae(r)
  };
}, ve = (e) => {
  const t = e.filter((n) => n.required), r = t.map((n) => n.outcome), i = r.filter((n) => n === "succeeded").length;
  return i === t.length ? "succeeded" : i > 0 ? "partially-succeeded" : r.length > 0 && r.every((n) => n === "aborted") ? "aborted" : "failed";
}, Xe = (e, t) => {
  const r = e.filter((i) => i.required);
  return r.length > 0 && r.every((i) => i.status === "sealed") ? t === "terminal" ? "terminal" : "pending-review" : r.some((i) => i.status === "aborting") ? "aborting" : r.some((i) => i.status === "blocked") ? "blocked" : r.some((i) => i.status === "waiting-tool-approval") ? "waiting-tool-approval" : r.some((i) => i.status === "waiting-document-review") ? "waiting-document-review" : e.some((i) => i.status === "running") ? "running" : t === "prepared" ? "prepared" : "running";
}, de = (e, t, r) => m(e, {
  event: t.fingerprint,
  item: r.fingerprint
}).slice(0, 48), B = (e, t, r, i) => {
  const n = {
    version: h,
    effectRef: de("zx-agent-integration/v1/effect-ref", e, t),
    idempotencyKey: e.idempotencyKey ?? de("zx-agent-integration/v1/effect-key", e, t),
    expectedRunRevision: e.expectedRunRevision + 1,
    itemRef: t.itemRef,
    attemptRef: t.attemptRef,
    intentFingerprint: t.fingerprint,
    dependencySnapshots: t.dependencies,
    expiresAt: e.expiresAt ?? e.logicalTime + 1,
    kind: r,
    ...i ? { recovery: i } : {},
    payloadFingerprint: m(
      "zx-agent-integration/v1/effect-payload",
      { kind: r, event: e.fingerprint, item: t.fingerprint }
    )
  };
  return {
    ...n,
    fingerprint: m(
      "zx-agent-integration/v1/effect",
      n
    )
  };
}, fe = (e, t, r, i) => {
  const n = {
    eventRef: t.eventRef,
    sequence: t.sequence,
    revision: e.revision + (r === "accepted" ? 1 : 0),
    ...i ? { attemptRef: i.attemptRef } : {},
    predecessorFingerprint: t.predecessorFingerprint,
    eventFingerprint: t.fingerprint,
    transition: r,
    logicalTime: t.logicalTime,
    authorityReceiptRoots: t.receiptRef ? [
      m(
        "zx-agent-integration/v1/authority-receipt-root",
        t.receiptRef
      )
    ] : [],
    dependencySnapshotRoots: (i?.dependencies ?? []).map(
      (o) => o.fingerprint
    )
  };
  return {
    ...n,
    fingerprint: m(
      "zx-agent-integration/v1/audit-node",
      n
    )
  };
}, ie = (e) => v({
  ...e,
  fingerprint: m("zx-agent-integration/v1/run", e)
}), St = (e) => {
  const t = je(e);
  if (t.ok === !1) throw new TypeError(t.diagnostic.code);
  const r = t.value.items.map((i) => {
    const n = { ...i, status: "prepared" };
    return {
      ...n,
      fingerprint: ae(n)
    };
  });
  return ie({
    version: h,
    runRef: t.value.runRef,
    runPrincipalRef: t.value.runPrincipalRef,
    purposeDigest: t.value.purposeDigest,
    policyRef: t.value.policyRef,
    policyFingerprint: t.value.policyFingerprint,
    logicalTime: t.value.logicalTime,
    revision: 0,
    nextExpectedSequence: 0,
    status: "prepared",
    items: r,
    citations: [],
    effects: [],
    diagnostics: [],
    audit: []
  });
}, I = (e, t, r, i = []) => ({
  status: t,
  state: e,
  effects: i,
  projection: H(e),
  diagnostic: r
}), xe = (e, t) => t.itemRef ? e.items.find((r) => r.itemRef === t.itemRef) : void 0, Qe = (e, t) => {
  const r = [];
  return { items: e.items.map((n) => {
    if (!((!t.itemRef || n.itemRef === t.itemRef) && (!t.dependencyFingerprint || n.dependencies.some(
      (s) => s.fingerprint === t.dependencyFingerprint
    ))) || n.status === "sealed") return n;
    if (n.status === "prepared")
      return P(n, "revoked", {
        ...t,
        receiptKind: "zero-effect"
      });
    const a = n.kind === "tool" ? "abort-tool-execution" : "abort-document-operation";
    return r.push(B(t, n, a)), D(n, { status: "aborting" });
  }), effects: r };
}, et = (e, t) => {
  let r = [...e.items], i = [...e.citations];
  const n = [];
  let o = !1, a;
  const s = xe(e, t), p = (d) => {
    r = r.map(
      (y) => y.itemRef === d.itemRef ? d : y
    );
  };
  switch (t.kind) {
    case "run-started":
      break;
    case "item-started":
      if (!s || s.status !== "prepared" || !s.dependsOnItemRefs.every((d) => {
        const y = e.items.find(
          (l) => l.itemRef === d
        );
        return y?.status === "sealed" && y.outcome === "succeeded";
      })) {
        a = g(
          "agent-authority-mismatch",
          "event",
          { category: "phase-mismatch" }
        );
        break;
      }
      p(D(s, { status: "running" }));
      break;
    case "tool-approval-requested":
      if (!s || s.kind !== "tool" || !["prepared", "running"].includes(s.status)) {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "phase-mismatch"
          }
        );
        break;
      }
      p(D(s, { status: "waiting-tool-approval" })), n.push(B(t, s, "request-tool-approval"));
      break;
    case "tool-decision-observed":
      if (!s || s.kind !== "tool" || s.status !== "waiting-tool-approval" || !t.receiptRef || !t.receiptFingerprint) {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "phase-mismatch"
          }
        );
        break;
      }
      t.outcome === "denied" || t.outcome === "aborted" ? p(
        D(P(s, t.outcome, t), {
          toolApprovalDecisionReceiptRef: t.receiptRef,
          toolApprovalDecisionFingerprint: t.receiptFingerprint
        })
      ) : p(
        D(s, {
          status: "running",
          toolApprovalDecisionReceiptRef: t.receiptRef,
          toolApprovalDecisionFingerprint: t.receiptFingerprint
        })
      );
      break;
    case "tool-execution-observed":
      if (!s || s.kind !== "tool" || s.status !== "running" || !s.toolApprovalDecisionFingerprint || t.approvalDecisionFingerprint !== s.toolApprovalDecisionFingerprint || !t.receiptRef || !t.receiptFingerprint || !t.outcome) {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "phase-mismatch"
          }
        );
        break;
      }
      p(
        D(
          P(s, t.outcome, t),
          {
            toolExecutionReceiptRef: t.receiptRef,
            toolExecutionFingerprint: t.receiptFingerprint
          }
        )
      );
      break;
    case "document-review-observed":
      if (!s || s.kind !== "document" || !["prepared", "running", "waiting-document-review"].includes(
        s.status
      ) || !t.receiptRef || !t.receiptFingerprint || !t.reviewDecision) {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "phase-mismatch"
          }
        );
        break;
      }
      if (t.reviewDecision !== "accept") {
        const d = t.reviewDecision === "reject" ? "rejected" : t.reviewDecision === "refine" ? "refine-required" : "superseded";
        p(
          D(P(s, d, t), {
            reviewDecisionReceiptRef: t.receiptRef,
            reviewDecisionFingerprint: t.receiptFingerprint
          })
        );
      } else
        p(
          D(s, {
            status: "waiting-document-review",
            ...t.receiptRef ? { receiptRef: t.receiptRef } : {},
            receiptKind: "document-review",
            reviewDecisionReceiptRef: t.receiptRef,
            reviewDecisionFingerprint: t.receiptFingerprint
          })
        );
      break;
    case "document-commit-observed":
      if (!s || s.kind !== "document" || s.status !== "waiting-document-review" || !s.reviewDecisionFingerprint || !t.receiptRef || !t.receiptFingerprint || !t.outcome) {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "phase-mismatch"
          }
        );
        break;
      }
      p(
        t.outcome === "succeeded" ? D(P(s, t.outcome, t), {
          documentCommitReceiptRef: t.receiptRef,
          documentCommitFingerprint: t.receiptFingerprint,
          undoReceiptRef: t.undoReceiptRef,
          originReceiptRef: t.originReceiptRef
        }) : P(s, t.outcome, t)
      );
      break;
    case "dependency-revoked": {
      const d = Qe(e, t);
      r = [...d.items], n.push(...d.effects);
      break;
    }
    case "citation-status-observed":
      if (!t.citation) {
        a = g("agent-input-invalid", "event");
        break;
      }
      if (i.some(
        (d) => d.ref === t.citation.ref && d.fingerprint !== t.citation.fingerprint
      )) {
        a = g(
          "agent-authority-mismatch",
          "event",
          { category: "citation-conflict" }
        );
        break;
      }
      i = i.filter(
        (d) => d.ref !== t.citation.ref
      ), i.push(t.citation), i.sort((d, y) => d.order - y.order), i.length > u.maxCitations && (a = g("agent-resource-exceeded", "event"));
      break;
    case "capability-unavailable":
      s && s.status !== "sealed" ? p(D(s, { status: "blocked" })) : r = r.map(
        (d) => d.status === "sealed" ? d : D(d, { status: "blocked" })
      ), a = g(
        "agent-capability-unavailable",
        "host-admission"
      );
      break;
    case "abort-requested":
      r = r.map((d) => d.status === "sealed" ? d : d.status === "prepared" ? P(d, "aborted", {
        ...t,
        receiptKind: "zero-effect"
      }) : (n.push(
        B(
          t,
          d,
          d.kind === "tool" ? "abort-tool-execution" : "abort-document-operation"
        )
      ), D(d, { status: "aborting" })));
      break;
    case "abort-acknowledged":
      if (!s || s.status !== "aborting") {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "phase-mismatch"
          }
        );
        break;
      }
      p(P(s, "aborted", t));
      break;
    case "retry-item":
      if (!s || s.status !== "sealed" || s.outcome === "succeeded" || !t.freshAttemptRef || !t.freshDependencies || s.kind === "document" && !t.freshDocument) {
        a = g(
          "agent-authority-mismatch",
          "event",
          {
            category: "fresh-admission-required"
          }
        );
        break;
      }
      p(
        D(s, {
          predecessorAttemptRef: s.attemptRef,
          attemptRef: t.freshAttemptRef,
          dependencies: t.freshDependencies,
          ...t.freshDocument ? { document: t.freshDocument } : {},
          status: "prepared",
          outcome: void 0,
          receiptRef: void 0,
          receiptKind: void 0,
          effectRef: void 0,
          toolApprovalDecisionReceiptRef: void 0,
          toolApprovalDecisionFingerprint: void 0,
          toolExecutionReceiptRef: void 0,
          toolExecutionFingerprint: void 0,
          reviewDecisionReceiptRef: void 0,
          reviewDecisionFingerprint: void 0,
          documentCommitReceiptRef: void 0,
          documentCommitFingerprint: void 0,
          undoReceiptRef: void 0,
          originReceiptRef: void 0
        })
      ), n.push(B(t, s, "require-fresh-admission"));
      break;
    case "host-summary-observed": {
      const d = r.filter((l) => l.required).every((l) => l.status === "sealed"), y = ve(r);
      !d || t.outcome !== y ? a = g("agent-summary-conflict", "event") : o = !0;
      break;
    }
  }
  return { items: r, citations: i, effects: n, requestedTerminal: o, diagnostic: a };
}, k = (e, t) => t.some((r) => e[r] !== void 0), tt = (e) => {
  const t = [
    "dependencyFingerprint",
    "outcome",
    "receiptRef",
    "receiptFingerprint",
    "receiptKind",
    "approvalDecisionFingerprint",
    "reviewDecision",
    "undoReceiptRef",
    "originReceiptRef",
    "citation",
    "freshAttemptRef",
    "freshDependencies",
    "freshDocument",
    "idempotencyKey",
    "expiresAt"
  ], r = () => g("agent-input-invalid", "event", {
    category: "event-shape-mismatch"
  });
  if (e.reviewDecision !== void 0 && e.kind !== "document-review-observed")
    return r();
  switch (e.kind) {
    case "run-started":
      return e.itemRef || k(e, t) ? r() : null;
    case "item-started":
      return !e.itemRef || k(e, t) ? r() : null;
    case "tool-approval-requested":
      return !e.itemRef || !e.idempotencyKey || e.expiresAt === void 0 || k(
        e,
        t.filter(
          (i) => i !== "idempotencyKey" && i !== "expiresAt"
        )
      ) ? r() : null;
    case "tool-decision-observed":
      return !e.itemRef || !e.receiptRef || !e.receiptFingerprint || e.outcome !== void 0 && !["denied", "aborted"].includes(e.outcome) || k(e, [
        "dependencyFingerprint",
        "receiptKind",
        "approvalDecisionFingerprint",
        "undoReceiptRef",
        "originReceiptRef",
        "citation",
        "freshAttemptRef",
        "freshDependencies",
        "freshDocument",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "tool-execution-observed":
      return !e.itemRef || !e.receiptRef || !e.receiptFingerprint || e.receiptKind !== "tool-execution" || !e.approvalDecisionFingerprint || !e.outcome || !["succeeded", "failed", "aborted"].includes(e.outcome) || k(e, [
        "dependencyFingerprint",
        "undoReceiptRef",
        "originReceiptRef",
        "citation",
        "freshAttemptRef",
        "freshDependencies",
        "freshDocument",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "document-review-observed":
      return !e.itemRef || !e.receiptRef || !e.receiptFingerprint || e.receiptKind !== "document-review" || !e.reviewDecision || e.outcome !== void 0 || k(e, [
        "dependencyFingerprint",
        "approvalDecisionFingerprint",
        "undoReceiptRef",
        "originReceiptRef",
        "citation",
        "freshAttemptRef",
        "freshDependencies",
        "freshDocument",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "document-commit-observed":
      return !e.itemRef || !e.receiptRef || !e.receiptFingerprint || e.receiptKind !== "document-commit" || !e.outcome || !["succeeded", "failed", "conflict", "rebase-required"].includes(
        e.outcome
      ) || e.outcome === "succeeded" && (!e.undoReceiptRef || !e.originReceiptRef) || e.outcome !== "succeeded" && (e.undoReceiptRef || e.originReceiptRef) || k(e, [
        "dependencyFingerprint",
        "approvalDecisionFingerprint",
        "citation",
        "freshAttemptRef",
        "freshDependencies",
        "freshDocument",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "dependency-revoked":
      return !e.dependencyFingerprint || k(e, [
        "outcome",
        "receiptRef",
        "receiptFingerprint",
        "receiptKind",
        "approvalDecisionFingerprint",
        "undoReceiptRef",
        "originReceiptRef",
        "citation",
        "freshAttemptRef",
        "freshDependencies",
        "freshDocument",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "citation-status-observed":
      return e.itemRef || !e.citation || k(
        e,
        t.filter((i) => i !== "citation")
      ) ? r() : null;
    case "capability-unavailable":
      return k(e, t) ? r() : null;
    case "abort-requested":
      return e.itemRef || k(e, t) ? r() : null;
    case "abort-acknowledged":
      return !e.itemRef || !e.receiptRef || e.receiptKind !== "abort-acknowledgement" || e.outcome !== "aborted" || k(e, [
        "dependencyFingerprint",
        "approvalDecisionFingerprint",
        "undoReceiptRef",
        "originReceiptRef",
        "citation",
        "freshAttemptRef",
        "freshDependencies",
        "freshDocument",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "retry-item":
      return !e.itemRef || !e.freshAttemptRef || !e.freshDependencies || k(e, [
        "dependencyFingerprint",
        "outcome",
        "receiptRef",
        "receiptFingerprint",
        "receiptKind",
        "approvalDecisionFingerprint",
        "undoReceiptRef",
        "originReceiptRef",
        "citation",
        "idempotencyKey",
        "expiresAt"
      ]) ? r() : null;
    case "host-summary-observed":
      return e.itemRef || !e.outcome || !["succeeded", "partially-succeeded", "failed", "aborted"].includes(
        e.outcome
      ) || k(
        e,
        t.filter((i) => i !== "outcome")
      ) ? r() : null;
    case "checkpoint-observed":
      return e.itemRef || k(e, t) ? r() : null;
  }
}, wt = (e, t) => {
  const r = Y(e);
  if (r.ok === !1)
    return I(e, "rejected", r.diagnostic);
  const i = se(t);
  if (i.ok === !1)
    return I(e, "rejected", i.diagnostic);
  const n = r.value, o = i.value, a = tt(o);
  if (a)
    return I(n, "rejected", a);
  if (o.runRef !== n.runRef || o.runPrincipalRef !== n.runPrincipalRef)
    return I(
      n,
      "rejected",
      g("agent-authority-mismatch", "authority")
    );
  if (o.sequence < n.nextExpectedSequence)
    return n.audit.find(
      (q) => q.sequence === o.sequence
    )?.eventFingerprint === o.fingerprint ? {
      status: "accepted-idempotent",
      state: n,
      effects: [],
      projection: H(n)
    } : I(
      n,
      "rejected",
      g("agent-event-duplicate-conflict", "event", {
        ordinal: o.sequence
      })
    );
  if (o.sequence > n.nextExpectedSequence) {
    const T = n.items[0], q = o.sequence - n.nextExpectedSequence, O = q <= u.maxEvents, N = B(
      o,
      T,
      O ? "request-missing-range" : "mark-unrecoverable",
      {
        firstSequence: n.nextExpectedSequence,
        lastSequence: O ? o.sequence - 1 : n.nextExpectedSequence,
        expectedPredecessorFingerprint: n.fingerprint,
        maxRetries: u.maxRecoveryRetries
      }
    );
    return I(
      n,
      "blocked",
      g("agent-event-gap", "recovery", {
        ordinal: n.nextExpectedSequence,
        count: q
      }),
      [N]
    );
  }
  if (o.expectedRunRevision !== n.revision || o.predecessorFingerprint !== n.fingerprint)
    return I(
      n,
      "rejected",
      g("agent-authority-mismatch", "event", {
        category: "revision-mismatch"
      })
    );
  if (n.status === "terminal") {
    const T = fe(n, o, "late-observation"), q = ie({
      ...F(n),
      logicalTime: Math.max(n.logicalTime, o.logicalTime),
      nextExpectedSequence: n.nextExpectedSequence + 1,
      audit: [...n.audit, T].slice(
        -u.maxAuditEntries
      )
    });
    return {
      status: "late-observation",
      state: q,
      effects: [],
      projection: H(q),
      diagnostic: g("agent-event-late", "event")
    };
  }
  const s = et(n, o);
  if (s.diagnostic?.code === "agent-input-invalid" || s.diagnostic?.category === "phase-mismatch" || s.diagnostic?.category === "fresh-admission-required")
    return I(n, "rejected", s.diagnostic);
  let p = Xe(s.items, n.status);
  o.kind === "run-started" && p === "prepared" && (p = "running");
  let d;
  s.requestedTerminal && (p = "terminal", d = ve(s.items));
  const y = s.diagnostic ? [...n.diagnostics, s.diagnostic].slice(
    -u.maxDiagnostics
  ) : n.diagnostics, l = fe(n, o, "accepted", xe(n, o)), A = ie({
    ...F(n),
    logicalTime: Math.max(n.logicalTime, o.logicalTime),
    revision: n.revision + 1,
    nextExpectedSequence: n.nextExpectedSequence + 1,
    status: p,
    ...d ? { outcome: d } : {},
    items: s.items,
    citations: s.citations,
    effects: s.effects,
    diagnostics: y,
    audit: [...n.audit, l].slice(
      -u.maxAuditEntries
    )
  });
  return {
    status: s.diagnostic ? "blocked" : "accepted",
    state: A,
    effects: s.effects,
    projection: H(A),
    ...s.diagnostic ? { diagnostic: s.diagnostic } : {}
  };
};
export {
  ct as $,
  it as A,
  nt as B,
  b as C,
  lt as D,
  mt as E,
  ut as F,
  Rt as G,
  Ze as H,
  yt as I,
  u as J,
  W as K,
  Ge as L,
  ft as M,
  pt as N,
  gt as O,
  H as P,
  ht as Q,
  vt as R,
  xt as S,
  bt as T,
  At as U,
  St as V,
  wt as W,
  ye as X,
  ot as Y,
  h as Z,
  st as _,
  le as a,
  ce as a0,
  at as a1,
  dt as a2,
  rt as b,
  L as c,
  V as d,
  c as e,
  De as f,
  f as g,
  S as h,
  $ as i,
  E as j,
  m as k,
  v as l,
  M as m,
  g as n,
  J as o,
  Ke as p,
  je as q,
  j as r,
  Fe as s,
  oe as t,
  se as u,
  Ne as v,
  F as w,
  _e as x,
  $e as y,
  Y as z
};
//# sourceMappingURL=agent-integration-C_nO9SI4.mjs.map
