// AI Authoring presentation is a separate public facet so adding bounded
// authoring adapters cannot perturb the certified editor assembly bundle.
export * from './src/components/ai-authoring'
export * from './src/composables/use-ai-authoring'
export { useTextEditorCommandKeybindings } from './src/shortcuts/use-text-editor-command-keybindings'
export type { TextEditorCommandKeybindingsEditorV1 } from './src/shortcuts/use-text-editor-command-keybindings'
export { useTextEditorShellKeybindings } from './src/shortcuts/use-text-editor-shell-keybindings'
export { executeInlineAiEscapeDisposition } from './src/components/ai-authoring/inline-ai-escape'
