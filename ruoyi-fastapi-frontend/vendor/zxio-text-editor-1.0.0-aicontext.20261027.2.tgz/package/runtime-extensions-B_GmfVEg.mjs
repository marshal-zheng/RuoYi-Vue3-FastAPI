import { Node as Re, mergeAttributes as Oe, nodeInputRule as pa, Extension as qe, defaultBlockAt as pt, getMarkRange as fa, markInputRule as ga, textblockTypeInputRule as ha } from "@tiptap/core";
import { Plugin as Ne, PluginKey as Me, AllSelection as ja, NodeSelection as va, TextSelection as Ke } from "@tiptap/pm/state";
import { DOMParser as Ut, DOMSerializer as ba, Slice as _a } from "@tiptap/pm/model";
import { bw as vn, k as ya, bP as wa, bQ as ka, e as Ca, p as Pt, v as bn, g as Mt, A as xa, bv as _n, as as yn, ap as Ea, at as Ta, br as Dt, bR as La, bp as Et, bu as Ia, bs as Sa, bS as Kt, bT as Aa, bU as Pa, bM as Ma, bB as wn, bC as Da, bi as Ra, bV as kn, bW as Cn, l as Oa, Z as Na, n as Xt, ae as $a, ag as za, ab as Ba, ad as Fa, af as Ha, ai as Va, aj as qa, ak as Gt, an as Zt, am as Wa, a3 as Ua, a2 as Ka, a8 as Xa, a7 as Yt, R as Ga, U as Za, a6 as Ya, a4 as Ja, bA as Qa, G as eo, F as to, E as no, B as ao, z as oo, y as io, x as so, bX as xn, au as ro, h as lo, bY as mo, H as co, bZ as uo, b_ as po, b$ as fo, c0 as go, aO as ho, bc as jo, aM as vo, aR as bo, a_ as _o, a as yo, S as wo, aB as ko, aC as Co, ax as xo, ay as Eo, aw as To, aq as Lo } from "./link-paste-handler-COpsSlXB.mjs";
import { detectShortcutPlatform as En, createShortcutRuntime as Tn, createActionPort as Jt } from "@zxio/keybindings/core";
import { bindShortcutOwner as Io, useShortcutPresentation as So } from "@zxio/keybindings/vue";
import { z as Ao, n as Po, p as Mo } from "./actions-Sd62WBGv.mjs";
import { selectAll as Qt } from "@tiptap/pm/commands";
import Do from "@tiptap/starter-kit";
import { Placeholder as Ro } from "@tiptap/extensions";
import Oo from "@tiptap/extension-text-align";
import { Table as No } from "@tiptap/extension-table";
import $o from "@tiptap/extension-typography";
import { TextStyle as zo, FontFamily as Bo, FontSize as Fo } from "@tiptap/extension-text-style";
import { TaskList as Ho, TaskItem as Vo } from "@tiptap/extension-list";
import qo from "@tiptap/extension-underline";
import { render as Ye, h as Rt, defineComponent as ke, computed as R, createBlock as Ce, openBlock as L, unref as r, withCtx as je, createElementVNode as b, normalizeClass as d, createVNode as B, toDisplayString as Q, createElementBlock as A, Fragment as ve, createCommentVNode as V, ref as S, onMounted as Fe, normalizeStyle as De, withModifiers as N, watch as Le, onUnmounted as ze, withDirectives as Je, renderList as Pe, vModelText as ht, onBeforeUpdate as Ln, renderSlot as In, nextTick as Ae, toValue as ot, toRef as en, Teleport as Sn, Transition as An, createTextVNode as Ie, withKeys as $e, inject as Pn, shallowRef as Ue, onBeforeUnmount as Wo, onScopeDispose as Mn, mergeProps as Uo, vShow as tn } from "vue";
import Ko from "@tiptap/extension-link";
import { useNamespace as xe, useLocale as Xo, useOverlayZIndex as Go } from "@zxio/zxui/hooks";
import { ZxIcon as te, ZxDialog as Zo, ZxButton as We } from "@zxio/zxui/core";
import { ZxInput as Yo } from "@zxio/zxui/input";
import { offset as Jo, shift as Qo, flip as Dn, autoUpdate as ei, computePosition as ti } from "@floating-ui/dom";
import { nodeViewProps as bt, NodeViewWrapper as et, VueNodeViewRenderer as Ge, VueRenderer as ni, NodeViewContent as Rn } from "@tiptap/vue-3";
import On from "@tiptap/suggestion";
import ai from "@tiptap/extension-code-block-lowlight";
import oi from "@tiptap/extension-code";
import { liftTarget as Ot, replaceStep as Nn, canSplit as ft, ReplaceAroundStep as nn, canJoin as $n } from "prosemirror-transform";
import { Slice as jt, Fragment as tt } from "prosemirror-model";
import { TextSelection as Xe, Selection as Te, NodeSelection as Be, AllSelection as zn } from "prosemirror-state";
import { am as an, j as Bn, h as ii, k as si } from "./delivery-surfaces-BeupB41w.mjs";
import { ZxSelect as Nt } from "@zxio/zxui/select";
import ri from "@tiptap/extension-node-range";
import "@tiptap/extension-drag-handle-vue-3";
import { DecorationSet as li, Decoration as mi } from "@tiptap/pm/view";
import { FileHandler as ci } from "@tiptap/extension-file-handler";
import { ZxTooltipOrPopover as Ve } from "@zxio/zxui/tooltip-or-popover";
import { u as ui } from "./envelope-CrN5-dS1.mjs";
import { a as di } from "./runtime-plugin-definitions-DN_cDAJZ.mjs";
import { RUNTIME_TARGET_DOCUMENT_PROJECTION_PLUGIN_V2 as pi } from "#runtime-target-document-authority";
const fi = [
  "filename",
  "caption",
  "startLine",
  "wrap",
  "showLineNumbers",
  "collapsed",
  "previewLines",
  "diagnostics"
], gi = "输入代码，或先选择语言", hi = "添加文件名", ji = "添加说明", vi = (e, t = vn) => {
  const n = e.copy.text.length === 0, a = e.lines.visualLineCount > t.longCodePreviewThreshold, o = e.display.collapsed ? e.display.previewTo : e.lines.visualLineCount, i = e.lines.visualLines.slice(0, o), s = e.lines.lineNumbers.slice(0, o), l = e.copy.mode === "plain";
  return {
    header: {
      languageLabel: ya(e.attrs.language),
      language: e.attrs.language,
      filename: e.attrs.filename,
      caption: e.attrs.caption,
      canCopyPlain: l,
      copyDisabledReason: l ? null : "Markdown copy is deferred; plain copy is available.",
      moreSettingsFields: fi
    },
    body: {
      isEmpty: n,
      codePlaceholder: n ? gi : null,
      filenamePlaceholder: e.attrs.filename ? null : hi,
      captionPlaceholder: e.attrs.caption ? null : ji,
      visualLines: e.lines.visualLines,
      visibleVisualLines: i,
      lineNumbers: e.lines.lineNumbers,
      visibleLineNumbers: s,
      showLineNumbers: e.display.showLineNumbers,
      wrap: e.display.wrap,
      collapsed: e.display.collapsed,
      previewFrom: e.display.previewFrom,
      previewTo: o,
      visualLineCount: e.lines.visualLineCount,
      isLong: a,
      maxBodyHeight: !e.display.collapsed && a ? t.longCodeMaxBodyHeight : null,
      scrollStatePersistence: "ui-only"
    },
    copy: {
      text: e.copy.text,
      mode: e.copy.mode
    },
    diagnostics: e.diagnostics
  };
}, bi = /^\s*```[\w#+.-]*[\t ]*\n[\s\S]*\n?```\s*$/m, _i = /(^\s{2,}\S)|(\b(const|let|var|function|class|import|export|return|if|for|while|try|catch)\b)|([{}[\];]|=>)|(^\s*[$#]\s+\S)/u, yi = (e, t = {}) => {
  if (bi.test(e))
    return {
      kind: "code-block",
      reason: "markdown-fence"
    };
  if (t.explicitCodeBlockContext)
    return {
      kind: "code-block",
      reason: "explicit-context"
    };
  const n = e.replace(/\r\n/g, `
`).replace(/\r/g, `
`).split(`
`);
  if (n.length < 2)
    return {
      kind: "preserve-existing-paste",
      reason: "ordinary-text"
    };
  const a = n.filter((s) => s.trim()), o = a.filter((s) => _i.test(s)), i = /[{}]/.test(e) || /;\s*(?:\n|$)/.test(e) || /^\s{2,}\S/m.test(e);
  return a.length >= 3 && o.length >= 2 && i ? {
    kind: "code-block",
    reason: "classifier"
  } : {
    kind: "preserve-existing-paste",
    reason: "ordinary-text"
  };
}, Fn = (e, t) => {
  var o;
  const n = e ? (o = e.ownerDocument.defaultView) == null ? void 0 : o.getComputedStyle(e).getPropertyValue(`--text-editor-space-${t}`) : void 0, a = Number.parseFloat(n ?? "");
  return Number.isFinite(a) ? a : t * 2;
}, Hn = (e) => Jo(({ elements: t }) => Fn(t.floating, e)), wi = (e) => Qo(({ elements: t }) => ({
  padding: Fn(t.floating, e)
})), on = (e) => {
  const t = typeof e.title == "string" ? e.title : typeof e["data-embed-title"] == "string" ? e["data-embed-title"] : "", n = typeof e.name == "string" ? e.name : typeof e["data-embed-name"] == "string" ? e["data-embed-name"] : "";
  return t || n;
}, ki = Re.create({
  name: "embed",
  group: "inline",
  inline: !0,
  atom: !0,
  selectable: !0,
  draggable: !1,
  addOptions() {
    return {
      getDocuments: async () => [],
      component: void 0,
      trigger: "[[",
      urlTemplate: (e) => e.url,
      interactive: !1,
      themeOwner: null
    };
  },
  addAttributes() {
    return {
      name: {
        default: null,
        parseHTML: (e) => e.getAttribute("data-embed-name"),
        renderHTML: (e) => e.name ? { "data-embed-name": e.name } : {}
      },
      title: {
        default: null,
        parseHTML: (e) => {
          var t;
          return e.getAttribute("data-embed-title") || ((t = e.textContent) == null ? void 0 : t.replace(/^\[\[|\]\]$/g, ""));
        },
        renderHTML: (e) => e.title ? { "data-embed-title": e.title } : {}
      },
      url: {
        default: null,
        parseHTML: (e) => e.getAttribute("href"),
        renderHTML: (e) => e.url ? { href: e.url } : {}
      },
      icon: {
        default: null,
        parseHTML: (e) => e.getAttribute("data-embed-icon"),
        renderHTML: (e) => e.icon ? { "data-embed-icon": e.icon } : {}
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'a[data-type="embed"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e, node: t }) {
    const n = on(t.attrs);
    return [
      "a",
      Oe(e, {
        "data-type": "embed",
        class: an("text-editor-embed")
      }),
      `[[${n}]]`
    ];
  },
  renderText({ node: e }) {
    const t = on(e.attrs);
    return t ? `[[${t}]]` : "";
  },
  addCommands() {
    return {
      insertEmbed: (e) => ({ editor: t, chain: n }) => {
        var i, s;
        const a = (this.options.trigger ?? "[[").length, o = {
          from: Math.max(0, t.state.selection.from - a),
          to: t.state.selection.from
        };
        return n().deleteRange(o).insertContent({
          type: this.name,
          attrs: {
            name: e.name,
            title: e.title,
            url: ((s = (i = this.options).urlTemplate) == null ? void 0 : s.call(i, e)) ?? e.url,
            icon: e.icon
          }
        }).run();
      }
    };
  },
  addProseMirrorPlugins() {
    const e = this.options, t = this.editor;
    return [
      On({
        editor: t,
        char: e.trigger ?? "[[",
        allowSpaces: !0,
        startOfLine: !1,
        allowedPrefixes: null,
        command: ({ editor: n, range: a, props: o }) => {
          var s;
          const i = o;
          n.chain().focus().deleteRange(a).insertContent({
            type: this.name,
            attrs: {
              name: i.name,
              title: i.title,
              url: ((s = e.urlTemplate) == null ? void 0 : s.call(e, i)) ?? i.url,
              icon: i.icon
            }
          }).run();
        },
        items: async ({ query: n }) => (await e.getDocuments(n)).slice(0, 10),
        render: () => {
          let n = null, a = null, o = null, i = null, s = 0;
          const l = () => {
            s += 1, o == null || o.remove(), o = null, n && Ye(null, n), n = null, a = null, i == null || i.release(), i = null;
          }, m = (c) => {
            if (!i || !n || !e.component) return;
            const u = Rt(e.component, {
              ...c,
              ref: (j) => {
                a = j;
              }
            });
            u.appContext = i.appContext, Ye(u, n);
          };
          return {
            onStart: async (c) => {
              if (!e.component || !e.themeOwner) return;
              l();
              const u = ++s, j = await e.themeOwner.acquirePortal();
              if (u !== s) {
                j.ok && j.value.release();
                return;
              }
              j.ok && (i = j.value, o = i.target.ownerDocument.createElement("div"), n = i.target.ownerDocument.createElement("div"), o.className = an("text-editor-embed-popup"), o.appendChild(n), i.target.appendChild(o), m(c), sn(c, o));
            },
            onUpdate: (c) => {
              m(c), o && sn(c, o);
            },
            onKeyDown: (c) => {
              var u;
              return c.event.key === "Escape" ? (l(), !0) : ((u = a == null ? void 0 : a.onKeyDown) == null ? void 0 : u.call(a, c.event)) ?? !1;
            },
            onExit: () => {
              l();
            }
          };
        }
      })
    ];
  }
});
function sn(e, t) {
  const { clientRect: n } = e;
  if (!n) return;
  const a = n();
  if (!a) return;
  const o = t.ownerDocument, i = o.defaultView, s = (i == null ? void 0 : i.scrollX) || o.documentElement.scrollLeft, l = (i == null ? void 0 : i.scrollY) || o.documentElement.scrollTop;
  t.style.position = "absolute", t.style.left = `${a.left + s}px`, t.style.top = `${a.bottom + l + 8}px`, t.style.zIndex = "100";
}
const Ci = { key: 0 }, xi = { key: 1 }, Ei = { key: 1 }, Ti = /* @__PURE__ */ ke({
  __name: "AttachmentNodeView",
  props: bt,
  setup(e) {
    const t = e, n = xe("text-editor-attachment-node"), a = R(
      () => t.editor.extensionManager.extensions.find(
        (p) => p.name === "attachment"
      )
    ), o = R(() => {
      var x, v;
      const p = (v = (x = a.value) == null ? void 0 : x.options) == null ? void 0 : v.getCurrentDocument;
      return typeof p == "function" ? p() : null;
    }), i = R(() => {
      const p = typeof t.node.attrs.assetId == "string" ? t.node.attrs.assetId : null;
      return !p || !o.value ? null : ui(o.value.assets, p) ?? null;
    }), s = R(() => wa(i.value)), l = R(() => ka(s.value.fileKind)), m = R(() => t.editor.isEditable), c = R(() => [
      n.b(),
      n.is("selected", t.selected),
      t.node.attrs.display === "compact" ? n.m("compact") : "",
      i.value ? "" : n.is("missing", !0)
    ]);
    function u() {
      const p = t.getPos();
      typeof p == "number" && t.editor.commands.setNodeSelection(p);
    }
    function j(p) {
      p.preventDefault(), p.stopPropagation();
    }
    function f(p) {
      j(p), !(!s.value.href || typeof window > "u") && window.open(s.value.href, "_blank", "noopener,noreferrer");
    }
    function g(p) {
      if (j(p), !s.value.href || typeof document > "u")
        return;
      const x = document.createElement("a");
      x.href = s.value.href, x.target = "_blank", x.rel = "noopener noreferrer", x.download = s.value.downloadName, x.click();
    }
    function h(p, x) {
      j(x), t.updateAttributes({ display: p });
    }
    return (p, x) => (L(), Ce(r(et), {
      "data-block-id": p.node.attrs.blockId || void 0
    }, {
      default: je(() => [
        b("div", {
          class: d(c.value),
          onClick: u
        }, [
          b("div", {
            class: d(r(n).e("surface"))
          }, [
            b("div", {
              class: d(r(n).e("icon"))
            }, [
              B(r(te), { icon: l.value }, null, 8, ["icon"])
            ], 2),
            b("div", {
              class: d(r(n).e("content"))
            }, [
              b("div", {
                class: d(r(n).e("title-row"))
              }, [
                b("span", {
                  class: d(r(n).e("name"))
                }, Q(s.value.fileName), 3),
                b("span", {
                  class: d(r(n).e("badge"))
                }, Q(s.value.badgeLabel), 3)
              ], 2),
              b("div", {
                class: d(r(n).e("meta"))
              }, [
                i.value ? (L(), A(ve, { key: 0 }, [
                  s.value.mimeType ? (L(), A("span", Ci, Q(s.value.mimeType), 1)) : V("", !0),
                  s.value.sizeLabel ? (L(), A("span", xi, Q(s.value.sizeLabel), 1)) : V("", !0)
                ], 64)) : (L(), A("span", Ei, "Missing asset reference"))
              ], 2)
            ], 2),
            b("div", {
              class: d(r(n).e("actions"))
            }, [
              s.value.href ? (L(), A("button", {
                key: 0,
                type: "button",
                class: d(r(n).e("action-btn")),
                title: "Open attachment",
                onClick: f
              }, [
                B(r(te), { icon: "lucide:external-link" })
              ], 2)) : V("", !0),
              s.value.href ? (L(), A("button", {
                key: 1,
                type: "button",
                class: d(r(n).e("action-btn")),
                title: "Download attachment",
                onClick: g
              }, [
                B(r(te), { icon: "lucide:download" })
              ], 2)) : V("", !0),
              p.selected && m.value ? (L(), A(ve, { key: 2 }, [
                b("button", {
                  type: "button",
                  class: d([
                    r(n).e("action-btn"),
                    r(n).is("active", p.node.attrs.display !== "compact")
                  ]),
                  title: "Card display",
                  onClick: x[0] || (x[0] = (v) => h("card", v))
                }, [
                  B(r(te), { icon: "lucide:panel-top" })
                ], 2),
                b("button", {
                  type: "button",
                  class: d([
                    r(n).e("action-btn"),
                    r(n).is("active", p.node.attrs.display === "compact")
                  ]),
                  title: "Compact display",
                  onClick: x[1] || (x[1] = (v) => h("compact", v))
                }, [
                  B(r(te), { icon: "lucide:minus" })
                ], 2)
              ], 64)) : V("", !0)
            ], 2)
          ], 2)
        ], 2)
      ]),
      _: 1
    }, 8, ["data-block-id"]));
  }
}), Li = Re.create({
  name: "attachment",
  group: "block",
  atom: !0,
  selectable: !0,
  draggable: !0,
  addOptions() {
    return {
      getCurrentDocument: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      display: {
        default: "card",
        parseHTML: (e) => e.dataset.display === "compact" ? "compact" : "card",
        renderHTML: (e) => ({
          "data-display": e.display === "compact" ? "compact" : "card"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="attachment"]'
      },
      {
        tag: 'a[data-type="attachment"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(this.options.HTMLAttributes, e, {
        "data-type": "attachment"
      })
    ];
  },
  addNodeView() {
    return Ge(Ti);
  },
  addCommands() {
    return {
      setAttachment: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: {
          assetId: e.assetId,
          display: e.display ?? "card"
        }
      }),
      setAttachmentDisplay: (e) => ({ commands: t }) => t.updateAttributes(this.name, { display: e })
    };
  }
}), Ii = ["src", "title"], Si = ["title"], Ai = ["value", "disabled"], lt = 640, Pi = /* @__PURE__ */ ke({
  __name: "IframeNodeView",
  props: bt,
  setup(e) {
    const t = e, n = xe("text-editor-iframe-node"), a = S(null), o = S(null), i = S(!1), s = S(0), l = S(0), m = S(9 / 16), c = S(!1);
    function u() {
      const E = t.getPos();
      typeof E == "number" && t.editor.commands.setNodeSelection(E);
    }
    function j(E) {
      const H = E.target;
      !(H.closest(`.${n.e("controls")}`) || H.closest(`.${n.e("caption")}`)) && c.value && u();
    }
    const f = R(() => t.node.attrs.fullWidth === !0), g = R(() => {
      if (f.value)
        return {
          width: "100%",
          aspectRatio: `${1 / m.value}`
        };
      const E = t.node.attrs.width || lt, H = t.node.attrs.height || E * m.value;
      return {
        width: `${E}px`,
        height: `${H}px`
      };
    }), h = R(() => f.value ? {
      width: "100%",
      maxWidth: "100%"
    } : {
      width: `${t.node.attrs.width || lt}px`,
      maxWidth: "100%"
    }), p = R(() => [
      n.b(),
      n.is("selected", t.selected),
      n.is("full-width", f.value),
      t.node.attrs.align === "center" ? n.m("center") : "",
      t.node.attrs.align === "right" ? n.m("right") : "",
      t.node.attrs.align === "left" ? n.m("left") : ""
    ]);
    Fe(() => {
      if (c.value = t.editor.isEditable, t.node.attrs.aspectRatio)
        m.value = t.node.attrs.aspectRatio;
      else if (t.node.attrs.src) {
        const E = Ca(t.node.attrs.src);
        m.value = E.ratio, t.updateAttributes({ aspectRatio: E.ratio });
      }
    }), t.editor.on("update", () => {
      c.value = t.editor.isEditable;
    });
    function x(E) {
      var H;
      if (c.value) {
        if (u(), i.value = !0, s.value = E.clientX, l.value = ((H = o.value) == null ? void 0 : H.offsetWidth) || t.node.attrs.width || lt, t.node.attrs.aspectRatio)
          m.value = t.node.attrs.aspectRatio;
        else {
          const W = t.node.attrs.width || l.value, se = t.node.attrs.height || W * m.value;
          W && se && (m.value = se / W);
        }
        window.addEventListener("mousemove", v), window.addEventListener("mouseup", w), document.body.style.cursor = "ew-resize";
      }
    }
    function v(E) {
      if (!i.value || !a.value || !o.value) return;
      const W = t.editor.view.dom.clientWidth, se = E.clientX - s.value;
      let ae = l.value + se;
      ae = Math.max(200, Math.min(ae, W - 40));
      const F = ae * m.value;
      a.value.style.width = `${ae}px`, a.value.style.height = `${F}px`, o.value.style.width = `${ae}px`;
    }
    function w() {
      if (i.value && (i.value = !1, window.removeEventListener("mousemove", v), window.removeEventListener("mouseup", w), document.body.style.cursor = "", a.value && o.value)) {
        const E = a.value.offsetWidth, H = a.value.offsetHeight;
        t.updateAttributes({
          width: E,
          height: H,
          aspectRatio: m.value
        }), a.value.style.width = "", a.value.style.height = "", o.value.style.width = "";
      }
    }
    function C(E) {
      t.updateAttributes({ align: E });
    }
    function k() {
      if (!f.value)
        t.updateAttributes({ fullWidth: !0 });
      else {
        const H = t.editor.view.dom.clientWidth, W = Math.min(lt, H - 40), se = W * m.value;
        t.updateAttributes({ fullWidth: !1, width: W, height: se });
      }
    }
    function y() {
      const E = t.getPos();
      typeof E == "number" && t.editor.chain().focus().deleteRange({ from: E, to: E + t.node.nodeSize }).run();
    }
    function Z(E) {
      E.key === "Enter" ? (E.preventDefault(), $()) : E.key === "Escape" || E.key === "ArrowDown" ? (E.preventDefault(), U()) : E.key === "ArrowUp" ? (E.preventDefault(), J()) : (E.key === "Delete" || E.key === "Backspace") && (E.preventDefault(), y());
    }
    function q(E) {
      t.editor.commands.focus(), t.editor.chain().setTextSelection(E).scrollIntoView().run();
    }
    function $() {
      const E = t.getPos();
      typeof E == "number" && (t.editor.commands.focus(), t.editor.chain().setTextSelection(E + 1).createParagraphNear().scrollIntoView().run());
    }
    function U() {
      const E = t.getPos();
      typeof E == "number" && q(E + 1);
    }
    function J() {
      const E = t.getPos();
      typeof E == "number" && q(E - 1);
    }
    return (E, H) => (L(), Ce(r(et), {
      "data-block-id": E.node.attrs.blockId || void 0
    }, {
      default: je(() => [
        b("div", {
          ref_key: "containerRef",
          ref: o,
          class: d(p.value),
          style: De(h.value),
          tabindex: "0",
          onClick: j,
          onKeydown: Z
        }, [
          b("div", {
            class: d(r(n).e("wrapper"))
          }, [
            E.node.attrs.src ? (L(), A("iframe", {
              key: 0,
              ref_key: "iframeRef",
              ref: a,
              class: d([
                r(n).e("iframe"),
                r(n).is("disabled", c.value && !E.node.attrs.interactive)
              ]),
              src: E.node.attrs.src,
              style: De(g.value),
              title: E.node.attrs.title || "",
              frameborder: "0",
              allowfullscreen: "",
              loading: "lazy",
              referrerpolicy: "no-referrer-when-downgrade",
              sandbox: "allow-scripts allow-same-origin allow-popups allow-forms",
              onClick: N(u, ["stop"])
            }, null, 14, Ii)) : V("", !0),
            c.value && !E.node.attrs.interactive ? (L(), A("div", {
              key: 1,
              class: d(r(n).e("overlay")),
              onClick: N(u, ["stop"])
            }, null, 2)) : V("", !0),
            c.value ? (L(), A("div", {
              key: 2,
              class: d(r(n).e("controls"))
            }, [
              b("div", {
                class: d(r(n).e("align-controls"))
              }, [
                b("button", {
                  class: d([
                    r(n).e("align-btn"),
                    r(n).is("active", E.node.attrs.align === "left")
                  ]),
                  title: "左对齐",
                  onClick: H[0] || (H[0] = N((W) => C("left"), ["stop"]))
                }, [
                  B(r(te), { icon: "lucide:align-left" })
                ], 2),
                b("button", {
                  class: d([
                    r(n).e("align-btn"),
                    r(n).is("active", E.node.attrs.align === "center")
                  ]),
                  title: "居中",
                  onClick: H[1] || (H[1] = N((W) => C("center"), ["stop"]))
                }, [
                  B(r(te), { icon: "lucide:align-center" })
                ], 2),
                b("button", {
                  class: d([
                    r(n).e("align-btn"),
                    r(n).is("active", E.node.attrs.align === "right")
                  ]),
                  title: "右对齐",
                  onClick: H[2] || (H[2] = N((W) => C("right"), ["stop"]))
                }, [
                  B(r(te), { icon: "lucide:align-right" })
                ], 2)
              ], 2),
              b("button", {
                class: d([r(n).e("action-btn"), r(n).is("active", f.value)]),
                title: f.value ? "恢复原始大小" : "全宽显示",
                onClick: N(k, ["stop"])
              }, [
                B(r(te), {
                  icon: f.value ? "lucide:minimize-2" : "lucide:maximize-2"
                }, null, 8, ["icon"])
              ], 10, Si),
              f.value ? V("", !0) : (L(), A("button", {
                key: 0,
                class: d(r(n).e("resize-handle")),
                title: "调整大小",
                onMousedown: N(x, ["prevent"])
              }, [
                B(r(te), { icon: "lucide:move-diagonal-2" })
              ], 34))
            ], 2)) : V("", !0),
            E.node.attrs.src ? V("", !0) : (L(), A("div", {
              key: 3,
              class: d(r(n).e("loading"))
            }, [
              b("div", {
                class: d(r(n).e("loading-content"))
              }, [
                b("div", {
                  class: d(r(n).e("loading-icon"))
                }, "🔗", 2),
                b("div", {
                  class: d(r(n).e("loading-text"))
                }, "Loading embed...", 2)
              ], 2)
            ], 2))
          ], 2),
          (c.value || E.node.attrs.title) && E.node.attrs.src ? (L(), A("input", {
            key: 0,
            value: E.node.attrs.title,
            class: d(r(n).e("caption")),
            placeholder: "Add caption",
            disabled: !c.value,
            onInput: H[3] || (H[3] = (W) => t.updateAttributes({
              title: W.target.value
            })),
            onKeydown: Z
          }, null, 42, Ai)) : V("", !0)
        ], 38)
      ]),
      _: 1
    }, 8, ["data-block-id"]));
  }
}), Mi = Re.create({
  name: "iframe",
  group: "block",
  selectable: !0,
  draggable: !0,
  atom: !0,
  addOptions() {
    return {
      allowedDomains: xa,
      blockedDomains: [],
      themeOwner: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: {
        default: null,
        parseHTML: (e) => e.getAttribute("src"),
        renderHTML: (e) => ({
          src: e.src
        })
      },
      width: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("width");
          return t ? Number.parseInt(t, 10) : null;
        },
        renderHTML: (e) => ({
          width: e.width ? String(e.width) : null
        })
      },
      height: {
        default: null,
        parseHTML: (e) => {
          const t = e.getAttribute("height");
          return t ? Number.parseInt(t, 10) : null;
        },
        renderHTML: (e) => ({
          height: e.height ? String(e.height) : null
        })
      },
      aspectRatio: {
        default: 9 / 16,
        // Default 16:9 aspect ratio
        parseHTML: () => null,
        // Don't parse from HTML
        renderHTML: () => ({})
        // Don't render to HTML
      },
      align: {
        default: "center",
        parseHTML: (e) => {
          const t = (e.dataset.align || e.getAttribute("align") || "left").toLowerCase();
          return ["left", "center", "right"].includes(t) ? t : "left";
        },
        renderHTML: (e) => ({
          "data-align": e.align || "center"
        })
      },
      title: {
        default: null,
        parseHTML: (e) => e.getAttribute("title"),
        renderHTML: (e) => ({
          title: e.title
        })
      },
      frameborder: {
        default: "0",
        renderHTML: () => ({
          frameborder: "0"
        })
      },
      allowfullscreen: {
        default: "true",
        renderHTML: () => ({
          allowfullscreen: "true"
        })
      },
      sandbox: {
        default: "allow-scripts allow-same-origin allow-popups allow-forms",
        renderHTML: (e) => ({
          sandbox: e.sandbox
        })
      },
      interactive: {
        default: !1,
        parseHTML: (e) => e.dataset.interactive === "true",
        renderHTML: (e) => ({
          "data-interactive": e.interactive ? "true" : "false"
        })
      },
      fullWidth: {
        default: !1,
        parseHTML: (e) => e.dataset.fullWidth === "true",
        renderHTML: (e) => ({
          "data-full-width": e.fullWidth ? "true" : "false"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "iframe[src]",
        getAttrs: (e) => {
          const t = e.getAttribute("src"), n = e.getAttribute("width"), a = e.getAttribute("height"), o = e.getAttribute("title"), i = e.dataset.align;
          return {
            assetId: e.dataset.assetId ?? null,
            src: t,
            width: n ? Number.parseInt(n, 10) : null,
            height: a ? Number.parseInt(a, 10) : null,
            title: o || null,
            align: i || "center"
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "iframe",
      Oe(this.options.HTMLAttributes, e, {
        loading: "lazy",
        referrerpolicy: "no-referrer-when-downgrade"
      })
    ];
  },
  addNodeView() {
    return Ge(Pi);
  },
  addCommands() {
    return {
      setIframeAlign: (e) => ({ commands: t }) => t.updateAttributes(this.name, { align: e }),
      setIframe: (e) => ({ commands: t, editor: n }) => {
        if (!bn(e.src, this.options))
          return !1;
        const a = Pt(e.src), o = n.view.dom, i = (o == null ? void 0 : o.clientWidth) || 800, s = Mt(
          a,
          i
        ), l = {
          src: a,
          width: e.width || s.width,
          height: e.height || s.height,
          title: e.title,
          align: e.align || "center",
          aspectRatio: s.height / s.width,
          interactive: e.interactive
        };
        return t.insertContent({
          type: this.name,
          attrs: l
        });
      },
      insertIframeURL: (e) => ({ commands: t }) => {
        const n = Pt(e);
        return t.setIframe({ src: n });
      },
      openIframeDialog: () => ({ editor: e }) => {
        const t = new CustomEvent("iframe:open-dialog", {
          detail: { editor: e }
        });
        return e.view.dom.dispatchEvent(t), !0;
      }
    };
  },
  // Add ProseMirror plugin for paste handling
  addProseMirrorPlugins() {
    const e = this;
    return [
      new Ne({
        key: new Me("iframe-paste-handler"),
        props: {
          handlePaste: (t, n, a) => {
            var s, l;
            const o = (s = n.clipboardData) == null ? void 0 : s.getData("text/plain"), i = (l = n.clipboardData) == null ? void 0 : l.getData("text/html");
            if (i) {
              const m = rn(i);
              if (m)
                return Tt(
                  t,
                  e,
                  m.src,
                  m.width,
                  m.height,
                  m.title
                );
            }
            if (o && o.includes("<iframe")) {
              const m = rn(o);
              if (m)
                return Tt(
                  t,
                  e,
                  m.src,
                  m.width,
                  m.height,
                  m.title
                );
            }
            return o && /^https?:\/\/(?:www\.)?(?:youtube\.com\/watch\?v=[\w-]+|youtu\.be\/[\w-]+|youtube\.com\/embed\/[\w-]+|vimeo\.com\/\d+|player\.vimeo\.com\/video\/\d+|codepen\.io\/[\w-]+\/pen\/[\w-]+|codesandbox\.io\/[\w\/.-]+|figma\.com\/[\w\/.-]+|embed\.figma\.com\/[\w\/.-]+)$/.test(o.trim()) ? Tt(t, e, o.trim()) : !1;
          }
        }
      })
    ];
  }
});
function rn(e) {
  try {
    const a = new DOMParser().parseFromString(e, "text/html").querySelector("iframe");
    if (!a) {
      const m = e.match(/<iframe[^>]*src=["']([^"']+)["'][^>]*>/i);
      if (m) {
        const c = m[1], u = e.match(/width=["'](\d+)["']/i), j = e.match(/height=["'](\d+)["']/i), f = e.match(/title=["']([^"']+)["']/i);
        return {
          src: c,
          width: u ? Number.parseInt(u[1], 10) : void 0,
          height: j ? Number.parseInt(j[1], 10) : void 0,
          title: f ? f[1] : void 0
        };
      }
      return null;
    }
    const o = a.getAttribute("src");
    if (!o) return null;
    const i = a.getAttribute("width") ? Number.parseInt(a.getAttribute("width"), 10) : void 0, s = a.getAttribute("height") ? Number.parseInt(a.getAttribute("height"), 10) : void 0, l = a.getAttribute("title") || void 0;
    return { src: o, width: i, height: s, title: l };
  } catch {
    return null;
  }
}
function Tt(e, t, n, a, o, i) {
  if (!confirm(
    `Do you want to embed this content?

URL: ${n}

Click "OK" to create an embed, or "Cancel" to paste as plain text.`
  ) || !bn(n, t.options))
    return !1;
  const l = Pt(n), m = t.editor.view.dom, c = (m == null ? void 0 : m.clientWidth) || 800, u = a || Mt(l, c).width, j = o || Mt(l, c).height, f = {
    src: l,
    width: u,
    height: j,
    title: i,
    align: "center",
    aspectRatio: j / u
  }, g = e.state.schema.nodes.iframe.create(f), h = e.state.tr.replaceSelectionWith(g);
  return e.dispatch(h), !0;
}
const Di = (e) => Array.from(e), Vn = (e, t, n = {}) => {
  if (!e)
    return !1;
  const a = Di(t);
  return a.length === 0 ? !1 : (Promise.resolve(
    e.intakeFiles({
      source: "picker",
      files: a,
      anchorPos: n.anchorPos,
      context: n.context,
      htmlContent: n.htmlContent
    })
  ).catch((o) => {
    e.emitDiagnostic({
      code: "picker-intake-dispatch-failed",
      message: o instanceof Error ? o.message : "Failed to dispatch picked files.",
      severity: "error",
      stage: "intake",
      cause: o
    });
  }), !0);
}, Ri = (e) => Array.from(e), qn = (e, t, n = {}) => {
  if (!e)
    return !1;
  const a = Ri(t);
  return a.length === 0 ? !1 : (Promise.resolve(
    e.intakeFiles({
      source: n.source ?? "programmatic",
      files: a,
      anchorPos: n.anchorPos,
      dropPos: n.dropPos,
      context: n.context,
      htmlContent: n.htmlContent
    })
  ).catch((o) => {
    e.emitDiagnostic({
      code: "programmatic-intake-dispatch-failed",
      message: o instanceof Error ? o.message : "Failed to dispatch programmatic files.",
      severity: "error",
      stage: "intake",
      cause: o
    });
  }), !0);
}, Oi = ["src", "alt", "width", "height"], Ni = ["title"], $i = ["onMousedown"], zi = ["disabled"], Bi = /* @__PURE__ */ ke({
  __name: "ImageNodeView",
  props: bt,
  setup(e) {
    const t = e, n = xe("text-editor-image-node"), a = S(null), o = S(null), i = S(!1), s = S(0), l = S(0), m = S(0), c = S(0), u = S(1), j = S(!0), f = S(0), g = S(0), h = S(null), p = S(null), x = R(
      () => i.value ? f.value : t.node.attrs.width
    ), v = R(
      () => i.value ? g.value : t.node.attrs.height
    ), w = R(() => {
      const _ = {};
      if (x.value && (_.width = `${x.value}px`), i.value) {
        const z = h.value;
        if (z === "nw" || z === "sw") {
          const le = f.value - m.value;
          _.transform = `translateX(${-le}px)`;
        }
      }
      return _;
    }), C = ["nw", "ne", "sw", "se"], k = R(() => {
      var le, _e;
      const _ = (_e = (le = t.editor) == null ? void 0 : le.view) == null ? void 0 : _e.dom;
      if (!_) return !1;
      const z = _.clientWidth, oe = t.node.attrs.width;
      return oe && Math.abs(oe - z) < 10;
    });
    function y() {
      var _e, me, fe, ye;
      const _ = (me = (_e = t.editor) == null ? void 0 : _e.view) == null ? void 0 : me.dom;
      if (!_) return;
      const z = _.clientWidth, oe = t.node.attrs.width || ((fe = a.value) == null ? void 0 : fe.naturalWidth) || 0, le = t.node.attrs.height || ((ye = a.value) == null ? void 0 : ye.naturalHeight) || 0;
      if (k.value && p.value) {
        const O = le / oe;
        t.updateAttributes({
          width: p.value,
          height: Math.round(p.value * O)
        }), p.value = null;
      } else {
        p.value = oe;
        const O = le / oe;
        t.updateAttributes({
          width: z,
          height: Math.round(z * O)
        });
      }
    }
    function Z() {
      const _ = t.getPos();
      typeof _ == "number" && t.editor.commands.setNodeSelection(_);
    }
    const q = S(t.node.attrs.alt || ""), $ = S(!1), U = R(() => [
      n.b(),
      n.is("selected", t.selected),
      t.node.attrs.align === "center" ? n.m("center") : "",
      t.node.attrs.align === "right" ? n.m("right") : "",
      t.node.attrs.align === "left" ? n.m("left") : ""
    ]);
    function J(_) {
      _.key === "Escape" && t.selected && (_.preventDefault(), _.stopPropagation(), ae());
    }
    Fe(() => {
      if ($.value = t.editor.isEditable, a.value) {
        const _ = t.node.attrs.width || a.value.naturalWidth, z = t.node.attrs.height || a.value.naturalHeight;
        _ && z && (u.value = z / _);
      }
    }), Le(
      () => t.selected,
      (_) => {
        _ ? document.addEventListener("keydown", J) : document.removeEventListener("keydown", J);
      },
      { immediate: !0 }
    ), ze(() => {
      document.removeEventListener("keydown", J);
    }), t.editor.on("update", () => {
      $.value = t.editor.isEditable;
    });
    function E(_) {
      const z = _.target.value;
      q.value = z, t.updateAttributes({ alt: z });
    }
    function H(_) {
      _.key === "Enter" ? (_.preventDefault(), se()) : (_.key === "Escape" || _.key === "ArrowDown") && (_.preventDefault(), ae()), _.key === "ArrowUp" && (_.preventDefault(), de());
    }
    function W(_) {
      t.editor.commands.focus(), t.editor.chain().setTextSelection(_).scrollIntoView().run();
    }
    function se() {
      const _ = t.getPos();
      typeof _ == "number" && (t.editor.commands.focus(), t.editor.chain().setTextSelection(_ + 1).createParagraphNear().scrollIntoView().run());
    }
    function ae() {
      const _ = t.getPos();
      typeof _ == "number" && W(_ + 1);
    }
    function de() {
      const _ = t.getPos();
      typeof _ == "number" && W(_ - 1);
    }
    function ie(_, z) {
      var _e, me, fe, ye;
      if (!$.value) return;
      Z(), s.value = _.clientX, l.value = _.clientY, m.value = ((_e = a.value) == null ? void 0 : _e.offsetWidth) || t.node.attrs.width || 0, c.value = ((me = a.value) == null ? void 0 : me.offsetHeight) || t.node.attrs.height || 0, f.value = m.value, g.value = c.value, h.value = z || "se", j.value = !_.shiftKey;
      const oe = t.node.attrs.width || ((fe = a.value) == null ? void 0 : fe.naturalWidth), le = t.node.attrs.height || ((ye = a.value) == null ? void 0 : ye.naturalHeight);
      oe && le ? u.value = le / oe : u.value = 1, i.value = !0, window.addEventListener("mousemove", he), window.addEventListener("mouseup", be), window.addEventListener("keydown", re), window.addEventListener("keyup", ce), document.body.style.cursor = F(z || "se");
    }
    function F(_) {
      switch (_) {
        case "nw":
        case "se":
          return "nwse-resize";
        case "ne":
        case "sw":
          return "nesw-resize";
        default:
          return "se-resize";
      }
    }
    function re(_) {
      _.key === "Shift" && (j.value = !1);
    }
    function ce(_) {
      _.key === "Shift" && (j.value = !0);
    }
    function he(_) {
      if (!i.value || !a.value || !o.value) return;
      _.preventDefault();
      const oe = t.editor.view.dom.clientWidth, le = _.clientX - s.value, _e = _.clientY - l.value;
      let me = m.value, fe = c.value;
      const ye = h.value;
      ye === "se" ? (me = m.value + le, fe = j.value ? me * u.value : c.value + _e) : ye === "sw" ? (me = m.value - le, fe = j.value ? me * u.value : c.value + _e) : ye === "ne" ? (me = m.value + le, fe = j.value ? me * u.value : c.value - _e) : ye === "nw" && (me = m.value - le, fe = j.value ? me * u.value : c.value - _e), me = Math.max(50, Math.min(me, oe)), fe = j.value ? me * u.value : Math.max(50, fe), f.value = Math.round(me), g.value = Math.round(fe);
    }
    function be() {
      i.value && (t.updateAttributes({
        width: f.value,
        height: g.value
      }), i.value = !1, h.value = null, window.removeEventListener("mousemove", he), window.removeEventListener("mouseup", be), window.removeEventListener("keydown", re), window.removeEventListener("keyup", ce), document.body.style.cursor = "");
    }
    function K(_) {
      t.editor.commands.setImageAlign(_);
    }
    return (_, z) => (L(), Ce(r(et), {
      "data-block-id": _.node.attrs.blockId || void 0
    }, {
      default: je(() => [
        b("div", {
          ref_key: "containerRef",
          ref: o,
          class: d(U.value),
          style: De(w.value)
        }, [
          b("div", {
            class: d(r(n).e("wrapper"))
          }, [
            _.node.attrs.src ? (L(), A("img", {
              key: 0,
              ref_key: "imageRef",
              ref: a,
              class: d(r(n).e("image")),
              src: _.node.attrs.src,
              alt: _.node.attrs.alt || "",
              width: x.value,
              height: v.value,
              onClick: N(Z, ["stop"])
            }, null, 10, Oi)) : V("", !0),
            i.value ? (L(), A("div", {
              key: 1,
              class: d(r(n).e("size-tooltip"))
            }, Q(f.value) + " × " + Q(g.value), 3)) : V("", !0),
            _.selected && $.value ? (L(), A("div", {
              key: 2,
              class: d(r(n).e("controls"))
            }, [
              b("div", {
                class: d(r(n).e("align-controls"))
              }, [
                b("button", {
                  class: d([
                    r(n).e("align-btn"),
                    r(n).is("active", _.node.attrs.align === "left")
                  ]),
                  onClick: z[0] || (z[0] = N((oe) => K("left"), ["stop"]))
                }, [
                  B(r(te), { icon: "lucide:align-left" })
                ], 2),
                b("button", {
                  class: d([
                    r(n).e("align-btn"),
                    r(n).is("active", _.node.attrs.align === "center")
                  ]),
                  onClick: z[1] || (z[1] = N((oe) => K("center"), ["stop"]))
                }, [
                  B(r(te), { icon: "lucide:align-center" })
                ], 2),
                b("button", {
                  class: d([
                    r(n).e("align-btn"),
                    r(n).is("active", _.node.attrs.align === "right")
                  ]),
                  onClick: z[2] || (z[2] = N((oe) => K("right"), ["stop"]))
                }, [
                  B(r(te), { icon: "lucide:align-right" })
                ], 2)
              ], 2),
              b("button", {
                class: d([r(n).e("expand-btn"), r(n).is("active", k.value)]),
                title: k.value ? "Restore size" : "Expand to full width",
                onClick: N(y, ["stop"])
              }, [
                B(r(te), {
                  icon: k.value ? "lucide:minimize-2" : "lucide:maximize-2"
                }, null, 8, ["icon"])
              ], 10, Ni)
            ], 2)) : V("", !0),
            _.selected && $.value ? (L(), A(ve, { key: 3 }, Pe(C, (oe) => b("div", {
              key: oe,
              class: d([r(n).e("corner-handle"), r(n).em("corner-handle", oe)]),
              onMousedown: N((le) => ie(le, oe), ["prevent"])
            }, null, 42, $i)), 64)) : V("", !0)
          ], 2),
          $.value || _.node.attrs.alt ? Je((L(), A("input", {
            key: 0,
            "onUpdate:modelValue": z[3] || (z[3] = (oe) => q.value = oe),
            class: d(r(n).e("caption")),
            placeholder: "Add caption",
            disabled: !$.value,
            onChange: E,
            onKeydown: H
          }, null, 42, zi)), [
            [ht, q.value]
          ]) : V("", !0)
        ], 6)
      ]),
      _: 1
    }, 8, ["data-block-id"]));
  }
}), Fi = /(?:^|\s)(!\[(.+|:?)]\((\S+)(?:(?:\s+)["'](\S+)["'])?\))$/, Hi = (e, t, n, a) => {
  e.emitDiagnostic({
    code: t,
    message: n,
    severity: "error",
    stage: "intake",
    cause: a
  });
}, Vi = Re.create({
  name: "image",
  group: "block",
  draggable: !0,
  selectable: !0,
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: { default: null },
      alt: { default: null },
      title: { default: null },
      width: { default: null },
      height: { default: null },
      align: {
        default: "left",
        parseHTML: (e) => {
          const t = (e.dataset.align || e.getAttribute("align") || "left").toLowerCase();
          return ["left", "center", "right"].includes(t) ? t : "left";
        },
        renderHTML: (e) => ({
          "data-align": e.align || "left"
        })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "img[src]",
        getAttrs: (e) => {
          if (typeof e == "string") return {};
          const t = e;
          return {
            assetId: t.dataset.assetId ?? null,
            src: t.getAttribute("src"),
            alt: t.getAttribute("alt"),
            title: t.getAttribute("title"),
            width: t.getAttribute("width"),
            height: t.getAttribute("height")
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "img",
      Oe(this.options.HTMLAttributes || {}, e)
    ];
  },
  addNodeView() {
    return Ge(Bi);
  },
  addOptions() {
    return {
      filePlatformRuntime: null,
      HTMLAttributes: {}
    };
  },
  addCommands() {
    return {
      setImageAlign: (e) => ({ commands: t }) => t.updateAttributes(this.name, { align: e }),
      setImage: (e) => ({ commands: t, editor: n }) => {
        const a = t.insertContent({
          type: this.name,
          attrs: e
        });
        return a && e.src && qi(n.view, e.src, (o, i) => {
          ln(e.src, n.view, i);
        }), a;
      },
      uploadImage: (e, t = "programmatic") => () => this.options.filePlatformRuntime ? t === "programmatic" || t === "picker" ? qn(
        this.options.filePlatformRuntime,
        [e],
        {
          source: t === "picker" ? "picker" : "programmatic",
          context: {
            nodeKind: "image",
            preferredNodeKind: "image"
          }
        }
      ) : (Promise.resolve(
        this.options.filePlatformRuntime.intakeFiles({
          source: t,
          files: [e],
          context: {
            nodeKind: "image",
            preferredNodeKind: "image"
          }
        })
      ).catch((n) => {
        const a = this.options.filePlatformRuntime;
        Hi(
          a,
          `${t}-image-intake-dispatch-failed`,
          n instanceof Error ? n.message : `Failed to dispatch ${t} image intake.`,
          n
        );
      }), !0) : !1,
      selectAndUploadImage: () => ({ dispatch: e }) => {
        if (!this.options.filePlatformRuntime)
          return !1;
        if (!e)
          return !0;
        const t = document.createElement("input");
        return t.type = "file", t.accept = "image/*", t.onchange = (n) => {
          const a = n.target;
          a.files && a.files.length && Vn(
            this.options.filePlatformRuntime,
            a.files,
            {
              context: {
                nodeKind: "image",
                preferredNodeKind: "image"
              }
            }
          );
        }, t.click(), !0;
      }
    };
  },
  addInputRules() {
    return [
      pa({
        find: Fi,
        type: this.type,
        getAttributes: (e) => {
          const [, , t, n, a] = e;
          return { src: n, alt: t, title: a };
        }
      })
    ];
  },
  addProseMirrorPlugins() {
    const e = this;
    return [
      new Ne({
        appendTransaction(t, n, a) {
          const o = [];
          return t.some((i) => i.docChanged) && a.doc.descendants((i, s) => {
            i.type.name === "image" && i.attrs.src && (!i.attrs.width || !i.attrs.height) && o.push({ node: i, pos: s });
          }), o.length === 0 || o.forEach(({ node: i, pos: s }) => {
            const l = e.editor;
            l && ln(i.attrs.src, l.view, s);
          }), null;
        }
      })
    ];
  }
});
function qi(e, t, n) {
  e.state.doc.descendants((a, o) => {
    if (a.type.name === "image" && a.attrs.src === t)
      return n(a, o), !1;
  });
}
function ln(e, t, n) {
  Wi(e).then((a) => {
    const o = t.state.doc.nodeAt(n);
    if (!o || o.type.name !== "image")
      return;
    const i = o.attrs;
    if (i.width == null || i.height == null) {
      const s = t.state.tr.setNodeMarkup(n, void 0, {
        ...i,
        width: i.width ?? a.width,
        height: i.height ?? a.height
      });
      t.dispatch(s);
    }
  }).catch(() => {
  });
}
function Wi(e) {
  return new Promise((t, n) => {
    const a = new Image();
    a.onload = () => t({
      width: a.naturalWidth,
      height: a.naturalHeight
    }), a.onerror = n, a.src = e;
  });
}
const Wn = (e) => typeof e == "function" ? e() : e, Ui = async (e, t) => {
  var a;
  if ((a = t == null ? void 0 : t.target) != null && a.isConnected)
    return { kind: "theme", lease: t };
  if (t && t.release(), !e || e.state !== "active")
    return { kind: "document" };
  const n = await e.acquirePortal();
  return n.ok ? n.value.target.isConnected ? { kind: "theme", lease: n.value } : (n.value.release(), { kind: "unavailable" }) : { kind: "unavailable" };
}, mn = (e, t) => {
  var a, o;
  if ((o = (a = t.portalLease) == null ? void 0 : a.target) != null && o.isConnected)
    return Promise.resolve({
      kind: "theme",
      lease: t.portalLease
    });
  if (t.portalInFlight)
    return t.portalInFlight;
  const n = Ui(e, t.portalLease).then(
    (i) => (t.portalInFlight === n && (t.portalInFlight = null), t.disposed ? (i.kind === "theme" && i.lease !== t.portalLease && i.lease.release(), { kind: "unavailable" }) : i.kind === "theme" ? t.portalLease && t.portalLease !== i.lease && t.portalLease.target.isConnected ? (i.lease.release(), { kind: "theme", lease: t.portalLease }) : (t.portalLease = i.lease, i) : (t.portalLease && !t.portalLease.target.isConnected && (t.portalLease = null), i))
  );
  return t.portalInFlight = n, n;
}, Lt = (e, t) => {
  const n = t.minQueryLength ?? 0, o = t.initialItems !== void 0 && (e.loading || n > 0 && e.query.length < n) ? Wn(t.initialItems) ?? [] : e.items, i = typeof t.loading == "function" ? t.loading({
    editor: e.editor,
    query: e.query,
    items: o,
    loading: e.loading
  }) : t.loading ?? e.loading;
  return {
    ...e,
    items: o,
    loading: i
  };
};
function _t(e) {
  return qe.create({
    name: e.name,
    addOptions() {
      var n;
      const t = e.addOptions ? e.addOptions.call(this) : {};
      return {
        themeOwner: e.themeOwner ?? null,
        ...t,
        suggestion: {
          char: e.char,
          pluginKey: e.pluginKey,
          items: ({ query: a, editor: o, signal: i }) => e.items({ query: a, editor: o, signal: i }),
          command: e.command,
          allowSpaces: e.allowSpaces,
          allowToIncludeChar: e.allowToIncludeChar,
          allowedPrefixes: e.allowedPrefixes,
          startOfLine: e.startOfLine,
          decorationTag: e.decorationTag || "span",
          decorationClass: e.decorationClass || "suggestion",
          decorationContent: e.decorationContent,
          decorationEmptyClass: e.decorationEmptyClass,
          minQueryLength: e.minQueryLength,
          debounce: e.debounce,
          initialItems: e.initialItems,
          loading: void 0,
          placement: e.placement,
          // Upstream takes the gap only in pixels, so its offset is zeroed
          // and a scale-derived one runs ahead of flip instead.
          offset: { mainAxis: 0, crossAxis: 0 },
          container: e.container,
          flip: !1,
          floatingUi: {
            ...e.floatingUi,
            middleware: [
              Hn(e.gap ?? 2),
              ...e.flip === !1 ? [] : [Dn()],
              ...((n = e.floatingUi) == null ? void 0 : n.middleware) ?? []
            ]
          },
          dismissOnOutsideClick: e.dismissOnOutsideClick,
          shouldShow: e.shouldShow,
          shouldResetDismissed: e.shouldResetDismissed,
          allow: e.allow,
          findSuggestionMatch: e.findSuggestionMatch
        }
      };
    },
    addStorage() {
      return {
        disposed: !1,
        portalLease: null,
        portalInFlight: null
      };
    },
    onCreate() {
      mn(this.options.themeOwner, this.storage);
    },
    onDestroy() {
      var t;
      this.storage.disposed = !0, this.storage.portalInFlight = null, (t = this.storage.portalLease) == null || t.release(), this.storage.portalLease = null;
    },
    addProseMirrorPlugins() {
      const {
        initialItems: t,
        loading: n,
        render: a,
        ...o
      } = this.options.suggestion, i = this.options.suggestion, s = this.storage;
      return [
        On({
          editor: this.editor,
          ...o,
          initialItems: Wn(t),
          render: () => {
            let l = null, m = null, c = 0, u = null;
            const j = () => {
              const f = l == null ? void 0 : l.element;
              m == null || m(), l && l.destroy(), f instanceof HTMLElement && f.remove(), m = null, l = null;
            };
            return {
              onStart: async (f) => {
                const g = ++c;
                u = f;
                const h = await mn(
                  this.options.themeOwner,
                  s
                );
                if (g !== c || this.editor.isDestroyed || h.kind === "unavailable")
                  return;
                const p = u, x = Lt(
                  p,
                  i
                );
                l = new ni(e.component, {
                  editor: x.editor,
                  props: x
                }), l.element instanceof HTMLElement && (h.kind === "theme" && h.lease.target.appendChild(l.element), m = x.mount(l.element), u && u !== p && l.updateProps(
                  Lt(
                    u,
                    i
                  )
                ));
              },
              onUpdate(f) {
                u = f, l == null || l.updateProps(
                  Lt(f, i)
                );
              },
              onKeyDown(f) {
                return (f.event.key === "Escape" || f.event.key === "Esc") && f.event.stopPropagation(), l && l.ref && typeof l.ref.onKeyDown == "function" ? l.ref.onKeyDown(f) : !1;
              },
              onExit() {
                c += 1, u = null, j();
              }
            };
          }
        })
      ];
    }
  });
}
const Ki = ["onClick", "onMouseover"], $t = /* @__PURE__ */ ke({
  __name: "SuggestionList",
  props: {
    items: {
      type: Array,
      required: !0
    },
    command: {
      type: Function,
      required: !0
    },
    wide: {
      type: Boolean,
      default: !1
    },
    showNoResults: {
      type: Boolean,
      default: !1
    },
    loading: {
      type: Boolean,
      default: !1
    }
  },
  setup(e, { expose: t }) {
    const n = e, a = xe("text-editor-suggestion"), o = S(0), i = S(null), s = S([]);
    Ln(() => {
      s.value = [];
    });
    const l = () => {
      Ae(() => {
        const g = s.value[o.value];
        g && g.scrollIntoView({ block: "nearest" });
      });
    }, m = (g) => {
      const h = n.items[g];
      h && n.command(h);
    }, c = ({ event: g }) => n.items.length ? g.key === "ArrowUp" ? (u(), !0) : g.key === "ArrowDown" ? (j(), !0) : g.key === "Enter" ? (f(), !0) : !1 : !1, u = () => {
      o.value = (o.value + n.items.length - 1) % n.items.length, l();
    }, j = () => {
      o.value = (o.value + 1) % n.items.length, l();
    }, f = () => {
      m(o.value);
    };
    return Le(
      () => n.items,
      () => {
        o.value = 0;
      }
    ), t({
      onKeyDown: c
    }), (g, h) => e.items.length || e.loading || e.showNoResults ? (L(), A("div", {
      key: 0,
      ref_key: "container",
      ref: i,
      class: d([r(a).b(), e.wide ? r(a).m("wide") : ""])
    }, [
      e.loading ? (L(), A("div", {
        key: 0,
        class: d(r(a).e("loading")),
        "aria-live": "polite"
      }, " Loading... ", 2)) : V("", !0),
      (L(!0), A(ve, null, Pe(e.items, (p, x) => (L(), A("button", {
        key: x,
        ref_for: !0,
        ref: (v) => {
          v && (s.value[x] = v);
        },
        class: d([r(a).e("item"), r(a).is("selected", x === o.value)]),
        onClick: (v) => m(x),
        onMouseover: (v) => o.value = x
      }, [
        In(g.$slots, "default", {
          item: p,
          index: x
        }, () => [
          b("span", null, Q(p.display || p.label || p.title || p.name), 1)
        ])
      ], 42, Ki))), 128)),
      !e.loading && !e.items.length && e.showNoResults ? (L(), A("div", {
        key: 1,
        class: d(r(a).e("no-results"))
      }, " No results ", 2)) : V("", !0)
    ], 2)) : V("", !0);
  }
});
function Xi(e) {
  const t = {
    name: "mention",
    group: "inline",
    inline: !0,
    selectable: !0,
    atom: !0,
    addOptions() {
      return {
        component: void 0
      };
    },
    addAttributes() {
      return {
        id: {
          default: null,
          parseHTML: (n) => n.dataset.id,
          renderHTML: (n) => n.id ? { "data-id": n.id } : {}
        },
        label: {
          default: null,
          parseHTML: (n) => n.dataset.label,
          renderHTML: (n) => n.label ? { "data-label": n.label } : {}
        }
      };
    },
    parseHTML() {
      return [
        {
          tag: 'span.mention[data-type="mention"]',
          getAttrs: (n) => {
            const a = n;
            return {
              id: a.dataset.id,
              label: a.dataset.label
            };
          }
        }
      ];
    },
    renderHTML({ HTMLAttributes: n }) {
      return [
        "span",
        Oe(n, {
          class: "mention",
          "data-type": "mention"
        }),
        `@${n["data-label"] || n.id || ""}`
      ];
    },
    renderText({ node: n }) {
      return `@${n.attrs.label || n.attrs.id || ""}`;
    }
  };
  return e && (t.addNodeView = () => Ge(e)), Re.create(t);
}
const Gi = _t({
  name: "mentionSuggestion",
  char: "@",
  pluginKey: new Me("mentionSuggestion"),
  component: $t,
  addOptions() {
    return {
      mentions: []
    };
  },
  items: ({ query: e, editor: t }) => {
    const { mentions: n } = t.extensionManager.extensions.find(
      (i) => i.name === "mentionSuggestion"
    ).options;
    return ot(n).filter(
      (i) => i.label.toLowerCase().startsWith(e.toLowerCase())
    ).slice(0, 10).map((i) => ({
      ...i,
      display: i.label
    }));
  },
  command: ({ editor: e, range: t, props: n }) => {
    const a = {
      id: n.id || n.value,
      label: n.label
    };
    e.chain().focus().insertContentAt(t, [
      {
        type: "mention",
        attrs: a
      }
    ]).run();
  },
  placement: "bottom-start",
  gap: 4,
  allowSpaces: !1,
  decorationTag: "span",
  decorationClass: "mention-suggestion-active"
}), Zi = qe.create({
  name: "mentionExtension",
  addOptions() {
    return {
      mentions: [],
      component: void 0,
      suggestion: {},
      themeOwner: null
    };
  },
  addExtensions() {
    return [
      Xi(this.options.component),
      Gi.configure({
        mentions: this.options.mentions,
        suggestion: this.options.suggestion,
        themeOwner: this.options.themeOwner ?? null
      })
    ];
  }
});
function Yi(e) {
  const {
    targetRef: t,
    zoomLevel: n,
    panThreshold: a = 10,
    onSwipeLeft: o,
    onSwipeRight: i,
    onDoubleTap: s,
    onTap: l,
    onPanStart: m,
    onPanMove: c,
    onPanAnimate: u,
    onPinchStart: j,
    onPinchMove: f,
    onPinchEnd: g
  } = e, h = S(!1), p = S(!1), x = S(!1);
  let v = 0, w = 0, C = 0, k = 0, y = !1, Z = null, q = 0, $ = 0, U = 0, J = 0, E = 0;
  function H(F, re) {
    const ce = F.clientX - re.clientX, he = F.clientY - re.clientY;
    return Math.sqrt(ce * ce + he * he);
  }
  function W(F) {
    var ce;
    if (!((ce = t.value) != null && ce.contains(F.target))) return;
    y = !1;
    const re = Date.now();
    if (F.touches.length === 2)
      p.value = !0, k = H(F.touches[0], F.touches[1]), j == null || j();
    else if (F.touches.length === 1) {
      if (v = F.touches[0].clientX, w = F.touches[0].clientY, J = v, E = w, U = re, re - C < 300) {
        s == null || s(F), C = 0;
        return;
      }
      C = re;
    }
  }
  function se(F) {
    var ce;
    if (!((ce = t.value) != null && ce.contains(F.target))) return;
    const re = Date.now();
    if (F.touches.length === 2 && p.value) {
      F.preventDefault();
      const be = H(F.touches[0], F.touches[1]) / k;
      f == null || f(be);
    } else if (F.touches.length === 1) {
      const he = F.touches[0].clientX, be = F.touches[0].clientY, K = he - v, _ = be - w, z = re - U;
      z > 0 && (q = (he - J) / z, $ = (be - E) / z), J = he, E = be, U = re, !y && (Math.abs(K) > a || Math.abs(_) > a) && (y = !0, h.value = !0, m == null || m()), y && n.value > 100 && (F.preventDefault(), c == null || c(K, _));
    }
  }
  function ae(F) {
    if (p.value && F.touches.length < 2 && (p.value = !1, g == null || g()), F.touches.length === 0) {
      if (h.value)
        h.value = !1, n.value > 100 && (Math.abs(q) > 0.1 || Math.abs($) > 0.1) && de();
      else if (!y && !p.value)
        l == null || l(F);
      else if (y && n.value <= 100) {
        const re = J - v;
        Math.abs(re) > 50 && (re > 0 ? i == null || i() : o == null || o());
      }
      y = !1;
    }
  }
  function de() {
    x.value = !0;
    const F = 0.95, re = 0.01;
    function ce() {
      if (q *= F, $ *= F, Math.abs(q) < re && Math.abs($) < re) {
        x.value = !1, Z = null;
        return;
      }
      u == null || u(q * 16, $ * 16), Z = requestAnimationFrame(ce);
    }
    Z = requestAnimationFrame(ce);
  }
  function ie() {
    Z !== null && (cancelAnimationFrame(Z), Z = null), x.value = !1;
  }
  return Fe(() => {
    const F = t.value;
    F && (F.addEventListener("touchstart", W, {
      passive: !1
    }), F.addEventListener("touchmove", se, { passive: !1 }), F.addEventListener("touchend", ae));
  }), ze(() => {
    const F = t.value;
    F && (F.removeEventListener("touchstart", W), F.removeEventListener("touchmove", se), F.removeEventListener("touchend", ae)), ie();
  }), {
    isPanning: h,
    isPinching: p,
    isAnimatingPan: x
  };
}
function Ji(e) {
  const { initialIndex: t, imageCount: n, onNavigate: a } = e, o = S(t.value);
  Le(t, (l) => {
    o.value = l;
  });
  function i() {
    n.value <= 1 || (o.value = (o.value + 1) % n.value, a == null || a());
  }
  function s() {
    n.value <= 1 || (o.value = (o.value - 1 + n.value) % n.value, a == null || a());
  }
  return {
    currentIndex: o,
    nextImage: i,
    previousImage: s
  };
}
function Qi(e) {
  const {
    containerRef: t,
    isEnabled: n,
    minZoom: a = 25,
    maxZoom: o = 300,
    zoomStep: i = 25
  } = e, s = S(100), l = S({ x: 0, y: 0 }), m = S(!1), c = S({ x: 0, y: 0 }), u = 90, j = 110;
  let f = 0, g = 0, h = 0, p = 0;
  function x() {
    const q = Math.min(o, s.value + i);
    s.value = q;
  }
  function v() {
    const q = Math.max(a, s.value - i);
    s.value = q, q <= 100 && (l.value = { x: 0, y: 0 });
  }
  function w() {
    s.value = 100, l.value = { x: 0, y: 0 };
  }
  function C(q) {
    s.value <= 100 || (m.value = !0, f = q.clientX, g = q.clientY, h = l.value.x, p = l.value.y, document.addEventListener("mousemove", k), document.addEventListener("mouseup", y));
  }
  function k(q) {
    if (!m.value) return;
    const $ = q.clientX - f, U = q.clientY - g;
    l.value = {
      x: h + $,
      y: p + U
    };
  }
  function y() {
    m.value = !1, document.removeEventListener("mousemove", k), document.removeEventListener("mouseup", y);
  }
  function Z(q) {
    var $;
    n.value && ($ = t.value) != null && $.contains(q.target) && (q.preventDefault(), q.deltaY < 0 ? x() : v());
  }
  return Fe(() => {
    document.addEventListener("wheel", Z, { passive: !1 });
  }), ze(() => {
    document.removeEventListener("wheel", Z), document.removeEventListener("mousemove", k), document.removeEventListener("mouseup", y);
  }), {
    zoomLevel: s,
    panPosition: l,
    isMousePanning: m,
    initialPanPositionOnGestureStart: c,
    zoomIn: x,
    zoomOut: v,
    resetZoom: w,
    handlePanStart: C,
    snapThresholdLower: u,
    snapThresholdUpper: j
  };
}
const es = ["src", "alt"], ts = 3e3, Un = /* @__PURE__ */ ke({
  name: "ZxTextEditorImageViewer",
  __name: "image-viewer-modal",
  props: {
    show: { type: Boolean },
    images: {},
    initialIndex: {},
    portalBinding: {}
  },
  emits: ["update:show", "terminal-close"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = xe("text-editor-image-viewer"), i = n.portalBinding.target.ownerDocument, s = S(null), l = S(null), m = S(null), c = S(0), u = S(!1), j = S(100), f = S(!0), g = S(null), {
      zoomLevel: h,
      panPosition: p,
      isMousePanning: x,
      initialPanPositionOnGestureStart: v,
      zoomIn: w,
      zoomOut: C,
      resetZoom: k,
      handlePanStart: y,
      snapThresholdLower: Z,
      snapThresholdUpper: q
    } = Qi({
      containerRef: s,
      isEnabled: en(n, "show")
    }), { currentIndex: $, nextImage: U, previousImage: J } = Ji({
      initialIndex: en(n, "initialIndex"),
      imageCount: R(() => n.images.length),
      onNavigate: k
    }), E = R(() => n.images[$.value]), {
      isPanning: H,
      isPinching: W,
      isAnimatingPan: se
    } = Yi({
      targetRef: s,
      zoomLevel: h,
      panThreshold: 10,
      onSwipeLeft: () => {
        h.value <= 100 && U();
      },
      onSwipeRight: () => {
        h.value <= 100 && J();
      },
      onDoubleTap: (K) => {
        var _;
        (_ = m.value) != null && _.contains(K.target) || (h.value > 100 ? k() : (h.value = 200, p.value = { x: 0, y: 0 }));
      },
      onTap: (K) => {
        K.target === l.value && F();
      },
      onPanStart: () => {
        h.value <= 100 || (v.value = { ...p.value });
      },
      onPanMove: (K, _) => {
        h.value <= 100 || (p.value = {
          x: v.value.x + K,
          y: v.value.y + _
        });
      },
      onPanAnimate: (K, _) => {
        p.value = {
          x: p.value.x + K,
          y: p.value.y + _
        };
      },
      onPinchStart: () => {
        j.value = h.value, v.value = { ...p.value };
      },
      onPinchMove: (K) => {
        const _ = j.value * K;
        let z = Math.max(25, Math.min(300, Math.round(_)));
        z > Z && z < q && (z = 100), h.value = z;
      },
      onPinchEnd: () => {
        h.value < 100 && k(), v.value = { x: 0, y: 0 };
      }
    }), ae = R(() => x.value || H.value);
    function de() {
      f.value = !0, g.value && clearTimeout(g.value), g.value = setTimeout(() => {
        !ae.value && !W.value ? f.value = !1 : de();
      }, ts);
    }
    function ie() {
      (!W.value || !f.value) && de();
    }
    function F() {
      a("update:show", !1), k(), g.value && (clearTimeout(g.value), g.value = null);
    }
    function re() {
      var oe;
      const K = E.value, _ = i.createElement("a");
      _.href = K.src;
      const z = ((oe = K.alt) == null ? void 0 : oe.replace(/[^a-z0-9]/gi, "_").toLowerCase()) || K.src.split("/").pop() || "download";
      _.download = z.includes(".") ? z : `${z}.jpg`, i.body.appendChild(_), _.click(), i.body.removeChild(_);
    }
    function ce() {
      const K = s.value;
      u.value ? i.exitFullscreen && (i.exitFullscreen(), u.value = !1) : K != null && K.requestFullscreen && (K.requestFullscreen(), u.value = !0);
    }
    function he() {
      u.value = !!i.fullscreenElement;
    }
    function be(K) {
      if (n.show)
        switch (ie(), K.key) {
          case "ArrowLeft":
            ae.value || J(), K.preventDefault();
            break;
          case "ArrowRight":
            ae.value || U(), K.preventDefault();
            break;
          case "+":
          case "=":
            w(), K.preventDefault();
            break;
          case "-":
            C(), K.preventDefault();
            break;
          case "Escape":
            F(), K.preventDefault();
            break;
          case "f":
          case "F":
            ce(), K.preventDefault();
            break;
        }
    }
    return Le(
      () => n.show,
      (K) => {
        K ? (f.value = !0, k(), de()) : (g.value && (clearTimeout(g.value), g.value = null), u.value && i.exitFullscreen && i.exitFullscreen());
      }
    ), Le(m, (K) => {
      if (K) {
        const _ = () => {
          c.value = K.offsetHeight;
        }, z = new ResizeObserver(_);
        z.observe(K), _(), ze(() => z.disconnect());
      } else
        c.value = 0;
    }), Fe(() => {
      i.addEventListener("fullscreenchange", he), i.addEventListener("keydown", be);
    }), ze(() => {
      i.removeEventListener("fullscreenchange", he), i.removeEventListener("keydown", be), g.value && clearTimeout(g.value), u.value && i.exitFullscreen && i.exitFullscreen();
    }), (K, _) => (L(), Ce(Sn, {
      to: n.portalBinding.target
    }, [
      B(An, {
        "enter-active-class": r(o).m("enter-active"),
        "leave-active-class": r(o).m("leave-active"),
        "enter-from-class": r(o).m("enter-from"),
        "leave-to-class": r(o).m("leave-to"),
        onAfterLeave: _[11] || (_[11] = (z) => K.$emit("terminal-close")),
        appear: ""
      }, {
        default: je(() => [
          n.show ? (L(), A("div", {
            key: 0,
            ref_key: "imageContainer",
            ref: s,
            class: d(r(o).b()),
            onMousemove: ie,
            onTouchstart: ie,
            onTouchmove: ie
          }, [
            b("div", {
              ref_key: "backdropElement",
              ref: l,
              class: d(r(o).e("backdrop")),
              onClick: F
            }, null, 2),
            b("div", {
              class: d(r(o).e("image-container"))
            }, [
              b("img", {
                src: E.value.src,
                alt: E.value.alt || "Image preview",
                class: d([
                  r(o).e("image"),
                  r(o).is("zoomed", r(h) > 100),
                  r(o).is("panning", r(x))
                ]),
                style: De({
                  transform: `scale(${r(h) / 100}) translate(${r(p).x}px, ${r(p).y}px)`,
                  transition: ae.value || r(W) || r(se) ? "none" : "transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)"
                }),
                draggable: "false",
                onMousedown: _[0] || (_[0] = //@ts-ignore
                (...z) => r(y) && r(y)(...z))
              }, null, 46, es)
            ], 2),
            E.value.alt ? (L(), A("div", {
              key: 0,
              class: d([r(o).e("caption"), r(o).is("hidden", !f.value)])
            }, Q(E.value.alt), 3)) : V("", !0),
            b("div", {
              ref_key: "controlsBar",
              ref: m,
              class: d([r(o).e("controls"), r(o).is("hidden", !f.value)]),
              onTouchstart: _[6] || (_[6] = N(() => {
              }, ["stop"])),
              onTouchmove: _[7] || (_[7] = N(() => {
              }, ["stop"])),
              onTouchend: _[8] || (_[8] = N(() => {
              }, ["stop"])),
              onMousedown: _[9] || (_[9] = N(() => {
              }, ["stop"])),
              onWheel: _[10] || (_[10] = N(() => {
              }, ["stop"]))
            }, [
              b("div", {
                class: d(r(o).e("control-group"))
              }, [
                B(r(Ve), {
                  content: "Previous image",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d([r(o).e("btn"), r(o).m("left")]),
                      type: "button",
                      onClick: _[1] || (_[1] = N(
                        //@ts-ignore
                        (...z) => r(J) && r(J)(...z),
                        ["stop"]
                      ))
                    }, [
                      B(r(te), {
                        icon: "lucide:chevron-left",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                b("span", {
                  class: d(r(o).e("text"))
                }, Q(r($) + 1) + "/" + Q(n.images.length), 3),
                B(r(Ve), {
                  content: "Next image",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d([r(o).e("btn"), r(o).m("right")]),
                      type: "button",
                      onClick: _[2] || (_[2] = N(
                        //@ts-ignore
                        (...z) => r(U) && r(U)(...z),
                        ["stop"]
                      ))
                    }, [
                      B(r(te), {
                        icon: "lucide:chevron-right",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"])
              ], 2),
              b("div", {
                class: d(r(o).e("control-group"))
              }, [
                B(r(Ve), {
                  content: "Zoom out",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d([r(o).e("btn"), r(o).m("left")]),
                      type: "button",
                      onClick: _[3] || (_[3] = N(
                        //@ts-ignore
                        (...z) => r(C) && r(C)(...z),
                        ["stop"]
                      ))
                    }, [
                      B(r(te), {
                        icon: "lucide:minus",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                B(r(Ve), {
                  content: "Reset zoom",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d(r(o).e("btn")),
                      type: "button",
                      onClick: _[4] || (_[4] = N(
                        //@ts-ignore
                        (...z) => r(k) && r(k)(...z),
                        ["stop"]
                      ))
                    }, [
                      b("span", {
                        class: d(r(o).e("text"))
                      }, Q(r(h)) + "%", 3)
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                B(r(Ve), {
                  content: "Zoom in",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d([r(o).e("btn"), r(o).m("right")]),
                      type: "button",
                      onClick: _[5] || (_[5] = N(
                        //@ts-ignore
                        (...z) => r(w) && r(w)(...z),
                        ["stop"]
                      ))
                    }, [
                      B(r(te), {
                        icon: "lucide:plus",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"])
              ], 2),
              b("div", {
                class: d(r(o).e("control-group"))
              }, [
                B(r(Ve), {
                  content: "Download image",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d([r(o).e("btn"), r(o).m("left")]),
                      type: "button",
                      onClick: N(re, ["stop"])
                    }, [
                      B(r(te), {
                        icon: "lucide:download",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"]),
                B(r(Ve), {
                  content: u.value ? "Exit fullscreen" : "Enter fullscreen",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d([r(o).e("btn"), r(o).m("right"), r(o).m("hidden-mobile")]),
                      type: "button",
                      onClick: N(ce, ["stop"])
                    }, [
                      B(r(te), {
                        icon: u.value ? "lucide:minimize" : "lucide:maximize",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["icon", "class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["content", "append-to"])
              ], 2),
              b("div", {
                class: d(r(o).e("control-group"))
              }, [
                B(r(Ve), {
                  content: "Close",
                  placement: "bottom",
                  "append-to": n.portalBinding.target
                }, {
                  default: je(() => [
                    b("button", {
                      class: d(r(o).e("btn")),
                      type: "button",
                      onClick: N(F, ["stop"])
                    }, [
                      B(r(te), {
                        icon: "lucide:x",
                        class: d(r(o).e("icon"))
                      }, null, 8, ["class"])
                    ], 2)
                  ]),
                  _: 1
                }, 8, ["append-to"])
              ], 2)
            ], 34)
          ], 34)) : V("", !0)
        ]),
        _: 1
      }, 8, ["enter-active-class", "leave-active-class", "enter-from-class", "leave-to-class"])
    ], 8, ["to"]));
  }
}), ns = qe.create({
  name: "imageViewer",
  addOptions() {
    return { themeOwner: null };
  },
  addStorage() {
    return { destroyed: !1, disposers: /* @__PURE__ */ new Set() };
  },
  onDestroy() {
    this.storage.destroyed = !0;
    for (const e of [...this.storage.disposers]) e();
    this.storage.disposers.clear();
  },
  addCommands() {
    return {
      openImageViewer: (e) => ({ editor: t }) => {
        const n = [];
        t.state.doc.descendants((o) => (o.type.name === "image" && n.push({
          src: o.attrs.src,
          alt: o.attrs.alt || null
        }), !0));
        const a = n.findIndex((o) => o.src === e);
        return as(
          this.options.themeOwner,
          n,
          a,
          (o) => {
            this.storage.destroyed ? o() : this.storage.disposers.add(o);
          },
          (o) => this.storage.disposers.delete(o)
        ), !0;
      }
    };
  },
  addProseMirrorPlugins() {
    const e = this;
    return [
      new Ne({
        key: new Me("imageViewer"),
        props: {
          handleClick(t, n, a) {
            var l;
            if (e.editor.isEditable)
              return !1;
            const { state: o } = t, i = o.doc.nodeAt(n);
            if ((i == null ? void 0 : i.type.name) === "image") {
              a.preventDefault();
              const m = i.attrs.src;
              return e.editor.commands.openImageViewer(m), !0;
            }
            const s = (l = t.dom.ownerDocument.defaultView) == null ? void 0 : l.HTMLImageElement;
            if (s && a.target instanceof s) {
              let m = !1;
              if (o.doc.descendants((c, u) => {
                if (c.type.name === "image" && !m) {
                  const j = t.nodeDOM(u);
                  if (j && (j === a.target || j.contains(a.target)))
                    return a.preventDefault(), e.editor.commands.openImageViewer(c.attrs.src), m = !0, !1;
                }
                return !0;
              }), m) return !0;
            }
            return !1;
          }
        }
      })
    ];
  }
});
async function as(e, t, n, a, o) {
  if (!e) return;
  const i = await e.acquirePortal();
  if (!i.ok) return;
  const s = i.value, l = s.target.ownerDocument.createElement("div");
  s.target.appendChild(l);
  let m = !1;
  const c = () => {
    m || (m = !0, Ye(null, l), l.remove(), s.release(), o(c));
  };
  a(c);
  const u = Rt(Un, {
    show: !0,
    images: t,
    initialIndex: n,
    portalBinding: s,
    "onUpdate:show": (j) => {
      !j && !l.isConnected && c();
    },
    onTerminalClose: c
  });
  u.appContext = s.appContext;
  try {
    Ye(u, l);
  } catch {
    c();
  }
}
const is = _t({
  name: "tagSuggestion",
  char: "#",
  pluginKey: new Me("tagSuggestion"),
  component: $t,
  addOptions() {
    return {
      tags: [],
      suggestion: {}
    };
  },
  items: ({ query: e, editor: t }) => {
    const { tags: n } = t.extensionManager.extensions.find(
      (i) => i.name === "tagSuggestion"
    ).options, a = ot(n), o = a.filter(
      (i) => i.label.toLowerCase().startsWith(e.toLowerCase())
    ).map((i) => ({ ...i, display: i.label }));
    return e.length > 0 && !a.some(
      (i) => i.label.toLowerCase() === e.toLowerCase()
    ) && o.push({
      display: `New tag: "${e}"`,
      label: e,
      isNew: !0
    }), o;
  },
  command: ({ editor: e, range: t, props: n }) => {
    const a = {
      tagLabel: n.label,
      ...n.id && !n.isNew && { tagId: n.id }
    };
    e.chain().focus().insertContentAt(t, [
      {
        type: _n.name,
        attrs: a
      },
      {
        type: "text",
        text: " "
      }
    ]).run();
  },
  placement: "bottom-start",
  gap: 4,
  allowSpaces: !1,
  decorationTag: "span",
  decorationClass: "tag-suggestion-active"
});
class It extends Error {
  constructor(t, n) {
    super(n), this.name = "ZxHostAssetUploadError", this.code = t;
  }
}
const ss = (e, t) => e instanceof Error && e.message ? e.message : t, rs = async ({
  context: e,
  expectedNodeKind: t,
  file: n,
  filePlatformRuntime: a,
  source: o = "programmatic"
}) => {
  if (!a)
    throw new It(
      "file-platform-runtime-missing",
      "The file platform runtime is not available for host uploads."
    );
  try {
    const i = await a.uploadAsset(n, {
      source: o,
      context: e
    });
    if (t && i.nodeKind !== t) {
      const s = new It(
        "host-upload-node-kind-mismatch",
        `Expected host upload to resolve as "${t}" but received "${i.nodeKind}".`
      );
      throw a.emitDiagnostic({
        code: s.code,
        message: s.message,
        severity: "error",
        stage: "asset-pipeline",
        cause: s
      }), s;
    }
    return i;
  } catch (i) {
    throw i instanceof It || a.emitDiagnostic({
      code: "host-upload-failed",
      message: ss(i, "The host asset upload failed."),
      severity: "error",
      stage: "asset-pipeline",
      cause: i
    }), i;
  }
}, at = new Me("assetTaskPlaceholder"), ls = (e, t) => {
  const n = e.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? n : Math.max(0, Math.min(t, n));
}, ms = (e) => ["queued", "reading", "uploading", "processing", "failed"].includes(
  e.status
), mt = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.find().forEach((n) => {
    const a = typeof n.spec.taskId == "string" ? n.spec.taskId : null;
    a && t.set(a, n.from);
  }), t;
}, St = (e, t, n) => {
  const a = document.createElement("button");
  a.type = "button", a.textContent = t, a.className = "zx-text-editor-asset-placeholder__action", a.addEventListener("mousedown", (o) => {
    o.preventDefault();
  }), a.addEventListener("click", (o) => {
    o.preventDefault(), o.stopPropagation(), n();
  }), e.append(a);
}, cs = (e) => {
  switch (e.status) {
    case "queued":
      return "Queued";
    case "reading":
      return "Preparing";
    case "uploading":
      return typeof e.progress == "number" ? `Uploading ${Math.round(e.progress)}%` : "Uploading";
    case "processing":
      return "Processing";
    case "failed":
      return e.errorMessage ?? "Upload failed";
    default:
      return e.status;
  }
}, us = (e, t) => {
  const n = document.createElement("div");
  n.className = `zx-text-editor-asset-placeholder is-${e.status}`, n.dataset.assetTaskId = e.id;
  const a = document.createElement("strong");
  a.className = "zx-text-editor-asset-placeholder__title", a.textContent = e.fileName, n.append(a);
  const o = document.createElement("div");
  if (o.className = "zx-text-editor-asset-placeholder__status", o.textContent = cs(e), n.append(o), e.previewUrl && e.kind === "image") {
    const s = document.createElement("img");
    s.className = "zx-text-editor-asset-placeholder__preview", s.src = e.previewUrl, s.alt = e.fileName, n.append(s);
  }
  if (typeof e.progress == "number" && e.status !== "failed") {
    const s = document.createElement("progress");
    s.className = "zx-text-editor-asset-placeholder__progress", s.max = 100, s.value = Math.max(0, Math.min(e.progress, 100)), n.append(s);
  }
  const i = document.createElement("div");
  return i.className = "zx-text-editor-asset-placeholder__actions", e.status === "failed" ? (St(i, "Retry", () => t.retryTask(e.id)), St(i, "Remove", () => t.removeTask(e.id))) : St(i, "Cancel", () => t.cancelTask(e.id)), n.append(i), n;
}, cn = (e, t, n) => {
  const a = t.getTasks().filter(ms);
  return li.create(
    e,
    a.map(
      (o, i) => mi.widget(
        ls(
          e,
          n.get(o.id) ?? o.anchorPos ?? null
        ),
        () => us(o, t),
        {
          key: `${o.id}:${o.status}:${o.progress ?? "none"}:${o.errorCode ?? "ok"}`,
          side: i + 1,
          taskId: o.id
        }
      )
    )
  );
}, ds = (e, t) => {
  if (!e)
    return null;
  const n = at.getState(e);
  return (n == null ? void 0 : n.positions.get(t)) ?? null;
}, ps = ({
  assetPipelineRuntime: e = null
} = {}) => qe.create({
  name: "assetTaskPlaceholder",
  addProseMirrorPlugins() {
    return e ? [
      new Ne({
        key: at,
        state: {
          init: (t, n) => {
            const a = cn(
              n.doc,
              e,
              /* @__PURE__ */ new Map()
            );
            return {
              decorations: a,
              positions: mt(a)
            };
          },
          apply: (t, n) => {
            const a = n.decorations.map(
              t.mapping,
              t.doc
            );
            if (!t.getMeta(
              at
            ) && !t.docChanged)
              return {
                decorations: a,
                positions: mt(a)
              };
            const i = cn(
              t.doc,
              e,
              mt(a)
            );
            return {
              decorations: i,
              positions: mt(i)
            };
          }
        },
        props: {
          decorations(t) {
            var n;
            return (n = at.getState(t)) == null ? void 0 : n.decorations;
          }
        },
        view: (t) => {
          e.setTaskPositionResolver(
            (a) => ds(t.state, a)
          );
          const n = e.subscribe(() => {
            const a = t.state.tr.setMeta(at, {
              refresh: !0
            }).setMeta("addToHistory", !1);
            t.dispatch(a);
          });
          return {
            destroy: () => {
              e.setTaskPositionResolver(null), n();
            }
          };
        }
      })
    ] : [];
  }
}), fs = ["onDragstart", "onDragover", "onDragleave"], gs = ["onClick"], hs = ["src", "alt"], js = ["onClick"], vs = ["title"], bs = ["onBlur", "onKeydown"], _s = ["title"], ys = ["src", "alt"], ws = ["onClick"], ks = ["title"], Cs = ["onBlur", "onKeydown"], xs = /* @__PURE__ */ ke({
  __name: "ImageGroupUploadDialog",
  props: {
    modelValue: {
      type: Boolean,
      required: !0
    },
    files: {
      type: Array,
      required: !0
    },
    editor: {
      type: Object,
      required: !0
    },
    mode: {
      type: String,
      default: "new"
    },
    existingImages: {
      type: Array,
      default: void 0
    },
    initialColumns: {
      type: Number,
      default: void 0
    },
    portalBinding: {
      type: Object,
      required: !0
    }
  },
  emits: ["update:modelValue", "close", "update:files", "save"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = xe("text-editor-image-group-dialog"), i = R({
      get: () => n.modelValue,
      set: (T) => a("update:modelValue", T)
    }), s = S(!1), l = S(null), m = S(null), c = S(!1), u = S(null), j = S(""), f = S(null), g = S(!1), h = S(4), p = S(0), x = S(0), v = S(0), w = S([]), C = S([]), k = R(() => w.value.some(Boolean)), y = S([]);
    Le(
      () => n.modelValue,
      (T) => {
        if (T && n.mode === "edit") {
          const M = (n.existingImages || []).map(
            se
          ), P = (n.files || []).map(W);
          y.value = [...M, ...P], n.initialColumns && (h.value = n.initialColumns, c.value = !0);
        } else T && n.mode === "new" && (y.value = (n.files || []).map(W), h.value = ae(y.value.length), c.value = !0);
      },
      { immediate: !0 }
    ), Le(
      () => n.existingImages,
      (T) => {
        if (n.modelValue && n.mode === "edit") {
          const M = (T || []).map(
            se
          ), P = (n.files || []).map(W);
          y.value = [...M, ...P];
        }
      },
      { deep: !0 }
    ), Le(
      () => n.files,
      (T) => {
        n.mode === "new" && (y.value = (T || []).map(W));
      },
      { deep: !0 }
    ), Fe(() => {
      window.addEventListener("dragover", _), window.addEventListener("drop", E), window.addEventListener("dragleave", z);
    }), ze(() => {
      window.removeEventListener("dragover", _), window.removeEventListener("drop", E), window.removeEventListener("dragleave", z);
    });
    async function Z() {
      const T = y.value.filter((G) => G.type === "file" && G.file).map((G) => G.file);
      let M = [];
      T.length > 0 && (M = await Y(T));
      const P = /* @__PURE__ */ new Map();
      T.forEach((G, ee) => {
        const ue = M[ee];
        ue != null && ue.success && ue.file && P.set(G, {
          src: ue.file.src || "",
          alt: ue.file.alt || ""
        });
      });
      const X = [];
      for (const G of y.value)
        if (G.type === "existing" && G.existing)
          X.push(G.existing);
        else if (G.type === "file" && G.file) {
          const ee = P.get(G.file);
          ee && X.push(ee);
        }
      return a("save", {
        images: X,
        columns: h.value
      }), g.value = !1, !0;
    }
    async function q() {
      if (!n.files || n.files.length === 0) return !1;
      const M = (await Y(n.files)).filter((P) => P.success && P.file).map((P) => {
        var X, G;
        return {
          src: ((X = P.file) == null ? void 0 : X.src) || "",
          alt: ((G = P.file) == null ? void 0 : G.alt) || ""
        };
      });
      return M.length > 1 && n.editor.chain().focus().setImageGroup({ images: M, columns: h.value }).run(), g.value = !1, a("close"), !0;
    }
    function $(T) {
      if (y.value.splice(T, 1), n.mode === "new") {
        const M = y.value.filter((P) => P.type === "file" && P.file).map((P) => P.file);
        a("update:files", M);
      }
    }
    function U() {
      const T = document.createElement("input");
      T.type = "file", T.accept = "image/*", T.multiple = !0, T.onchange = (M) => {
        const P = M.target.files;
        P && J(Array.from(P));
      }, T.click();
    }
    function J(T) {
      const P = T.filter((ee) => ee.type.startsWith("image/")).map(W), X = y.value.filter((ee) => ee.type === "file" && ee.file).map((ee) => `${ee.file.name}-${ee.file.size}`), G = P.filter(
        (ee) => !X.includes(`${ee.file.name}-${ee.file.size}`)
      );
      if (y.value.push(...G), n.mode === "new") {
        const ee = y.value.filter((ue) => ue.type === "file" && ue.file).map((ue) => ue.file);
        a("update:files", ee);
      }
    }
    function E(T) {
      var P;
      T.preventDefault(), T.stopPropagation();
      const M = Array.from(((P = T.dataTransfer) == null ? void 0 : P.files) || []);
      M.length && J(M), s.value = !1;
    }
    function H(T) {
      var P;
      T.preventDefault(), T.stopPropagation();
      const M = Array.from(((P = T.dataTransfer) == null ? void 0 : P.files) || []);
      if (M.length)
        J(M);
      else if (l.value !== null && m.value !== null && l.value !== m.value) {
        const [X] = y.value.splice(l.value, 1);
        if (y.value.splice(m.value, 0, X), n.mode === "new") {
          const G = y.value.filter((ee) => ee.type === "file" && ee.file).map((ee) => ee.file);
          a("update:files", G);
        }
      }
      s.value = !1, l.value = null, m.value = null;
    }
    function W(T) {
      return {
        type: "file",
        file: T,
        id: `file-${T.name}-${T.size}-${Date.now()}`
      };
    }
    function se(T) {
      return {
        type: "existing",
        existing: T,
        id: `existing-${T.src}-${Date.now()}`
      };
    }
    function ae(T) {
      return T <= 4 ? T : T % 4 === 0 ? 4 : T % 3 === 0 ? 3 : T > 10 ? 4 : 3;
    }
    function de() {
      var M;
      const T = n.editor.extensionManager.extensions.find(
        (P) => P.name === "imageGroup"
      );
      return (M = T == null ? void 0 : T.options) == null ? void 0 : M.filePlatformRuntime;
    }
    function ie(T) {
      const M = URL.createObjectURL(T);
      return ze(() => {
        URL.revokeObjectURL(M);
      }), M;
    }
    function F(T) {
      const M = ["image/heic", "image/heif"], P = [".heic", ".heif"], X = M.includes(T.type), G = P.some(
        (ee) => {
          var ue;
          return (ue = T.name) == null ? void 0 : ue.toLowerCase().endsWith(ee);
        }
      );
      return !X && !G;
    }
    function re(T, M) {
      T.preventDefault(), m.value = M;
    }
    function ce(T) {
      l.value = T;
    }
    function he() {
      l.value = null, m.value = null;
    }
    function be(T, M) {
      m.value === M && (m.value = null);
    }
    function K(T) {
      return m.value === T && l.value !== null && l.value !== T;
    }
    function _(T) {
      T.preventDefault(), T.dataTransfer && Array.from(T.dataTransfer.types).includes("Files") && (s.value = !0);
    }
    function z(T) {
      (T.target === window || T.relatedTarget === null) && (s.value = !1);
    }
    const oe = R(() => ({
      gridTemplateColumns: `repeat(${h.value || 4}, minmax(0, 1fr))`
    })), le = R({
      get: () => String(h.value ?? 4),
      set: (T) => {
        h.value = +T;
      }
    }), _e = [
      { label: "2 columns", value: "2" },
      { label: "3 columns", value: "3" },
      { label: "4 columns", value: "4" }
    ];
    function me(T, M) {
      u.value = T, j.value = M, Ae(() => {
        f.value && (f.value.focus(), f.value.select());
      });
    }
    function fe(T, M) {
      var G;
      const [P] = T.split("-"), X = j.value.trim();
      P === "existing" ? (G = y.value[M]) != null && G.existing && (y.value[M].existing.alt = X) : P === "file" && y.value[M] && (y.value[M].alt = X), u.value = null, j.value = "";
    }
    function ye() {
      u.value = null, j.value = "";
    }
    function O(T, M) {
      u.value === T && fe(T, M);
    }
    async function Y(T) {
      const M = de();
      g.value = !0, v.value = T.length, x.value = 0, p.value = 0, w.value = Array.from({ length: T.length }).fill(
        null
      ), C.value = Array.from({ length: T.length }).fill(
        {
          success: !1
        }
      );
      const P = T.map(async (G, ee) => {
        try {
          const ue = await rs({
            file: G,
            filePlatformRuntime: M,
            source: "picker",
            context: {
              nodeKind: "imageGroup",
              preferredNodeKind: "image",
              usage: "image-group"
            },
            expectedNodeKind: "image"
          }), Se = {
            src: ue.asset.src,
            alt: ue.asset.title || G.name
          };
          return C.value[ee] = { success: !0, file: Se }, { success: !0, file: Se };
        } catch (ue) {
          const Se = ue;
          return w.value[ee] = Se, C.value[ee] = { success: !1, error: Se }, { success: !1, error: Se };
        } finally {
          x.value++, p.value = Math.round(
            x.value / v.value * 100
          );
        }
      });
      return await Promise.all(P);
    }
    return (T, M) => (L(), A(ve, null, [
      B(r(Zo), {
        modelValue: i.value,
        "onUpdate:modelValue": M[8] || (M[8] = (P) => i.value = P),
        title: n.mode === "edit" ? "Edit Images" : "Upload Images",
        width: "800px",
        "close-on-click-modal": !1,
        "cancel-text": "Cancel",
        "ok-text": n.mode === "edit" ? "Save" : "Upload",
        "ok-disabled": g.value,
        loading: g.value,
        confirm: n.mode === "edit" ? Z : q,
        "append-to": n.portalBinding.target,
        onClose: M[9] || (M[9] = (P) => T.$emit("close"))
      }, {
        default: je(() => [
          b("div", {
            class: d(r(o).e("content"))
          }, [
            b("div", {
              class: d(r(o).e("header"))
            }, [
              B(r(We), { onClick: U }, {
                default: je(() => [
                  B(r(te), { icon: "mdi:image-plus" }),
                  M[10] || (M[10] = Ie(" Add images ", -1))
                ]),
                _: 1
              }),
              B(r(Nt), {
                modelValue: le.value,
                "onUpdate:modelValue": M[0] || (M[0] = (P) => le.value = P),
                class: d(r(o).e("column-select")),
                size: "small",
                options: _e,
                "append-to": n.portalBinding.target,
                onChange: M[1] || (M[1] = (P) => h.value = +P)
              }, null, 8, ["modelValue", "class", "append-to"])
            ], 2),
            y.value && y.value.length ? (L(), A("div", {
              key: 0,
              class: d(r(o).e("grid")),
              style: De(oe.value)
            }, [
              (L(!0), A(ve, null, Pe(y.value, (P, X) => {
                var G, ee, ue, Se;
                return L(), A("div", {
                  key: P.id,
                  class: d([r(o).e("item"), r(o).is("drop-target", K(X))]),
                  draggable: !0,
                  onDragstart: (ge) => ce(X),
                  onDragover: (ge) => re(ge, X),
                  onDrop: M[6] || (M[6] = (ge) => H(ge)),
                  onDragend: he,
                  onDragleave: (ge) => be(ge, X)
                }, [
                  b("button", {
                    type: "button",
                    class: d(r(o).e("remove-btn")),
                    "aria-label": "Remove image",
                    onClick: N((ge) => $(X), ["stop"])
                  }, [
                    B(r(te), { icon: "mdi:close" })
                  ], 10, gs),
                  P.type === "existing" ? (L(), A(ve, { key: 0 }, [
                    b("img", {
                      src: (G = P.existing) == null ? void 0 : G.src,
                      alt: ((ee = P.existing) == null ? void 0 : ee.alt) || "",
                      class: d(r(o).e("image"))
                    }, null, 10, hs),
                    b("div", {
                      class: d([
                        r(o).e("caption-overlay"),
                        r(o).is("editing", u.value === `${P.type}-${X}`)
                      ])
                    }, [
                      u.value !== `${P.type}-${X}` ? (L(), A("div", {
                        key: 0,
                        class: d(r(o).e("caption-text")),
                        onClick: N((ge) => {
                          var st;
                          return me(
                            `${P.type}-${X}`,
                            ((st = P.existing) == null ? void 0 : st.alt) || ""
                          );
                        }, ["stop"])
                      }, [
                        b("div", {
                          class: d(r(o).e("caption-label")),
                          title: ((ue = P.existing) == null ? void 0 : ue.alt) || "Click to add caption"
                        }, Q(((Se = P.existing) == null ? void 0 : Se.alt) || "Add caption..."), 11, vs)
                      ], 10, js)) : (L(), A("div", {
                        key: 1,
                        class: d(r(o).e("caption-input-wrapper")),
                        onClick: M[3] || (M[3] = N(() => {
                        }, ["stop"]))
                      }, [
                        Je(b("input", {
                          ref_for: !0,
                          ref: (ge) => f.value = ge,
                          "onUpdate:modelValue": M[2] || (M[2] = (ge) => j.value = ge),
                          class: d(r(o).e("caption-input")),
                          placeholder: "Add caption...",
                          maxlength: "200",
                          onBlur: (ge) => O(`${P.type}-${X}`, X),
                          onKeydown: [
                            $e(N((ge) => fe(`${P.type}-${X}`, X), ["prevent"]), ["enter"]),
                            $e(ye, ["escape"])
                          ]
                        }, null, 42, bs), [
                          [ht, j.value]
                        ])
                      ], 2))
                    ], 2)
                  ], 64)) : P.type === "file" && P.file ? (L(), A(ve, { key: 1 }, [
                    F(P.file) ? P.file.type.startsWith("image/") ? (L(), A(ve, { key: 1 }, [
                      b("img", {
                        src: ie(P.file),
                        class: d(r(o).e("image")),
                        alt: P.alt || ""
                      }, null, 10, ys),
                      b("div", {
                        class: d([
                          r(o).e("caption-overlay"),
                          r(o).is("editing", u.value === `${P.type}-${X}`)
                        ])
                      }, [
                        u.value !== `${P.type}-${X}` ? (L(), A("div", {
                          key: 0,
                          class: d(r(o).e("caption-text")),
                          onClick: N((ge) => me(`${P.type}-${X}`, P.alt || ""), ["stop"])
                        }, [
                          b("div", {
                            class: d(r(o).e("caption-label")),
                            title: P.alt || "Click to add caption"
                          }, Q(P.alt || "Add caption..."), 11, ks)
                        ], 10, ws)) : (L(), A("div", {
                          key: 1,
                          class: d(r(o).e("caption-input-wrapper")),
                          onClick: M[5] || (M[5] = N(() => {
                          }, ["stop"]))
                        }, [
                          Je(b("input", {
                            "onUpdate:modelValue": M[4] || (M[4] = (ge) => j.value = ge),
                            class: d(r(o).e("caption-input")),
                            placeholder: "Add caption...",
                            maxlength: "200",
                            onBlur: (ge) => O(`${P.type}-${X}`, X),
                            onKeydown: [
                              $e(N((ge) => fe(`${P.type}-${X}`, X), ["prevent"]), ["enter"]),
                              $e(ye, ["escape"])
                            ]
                          }, null, 42, Cs), [
                            [ht, j.value]
                          ])
                        ], 2))
                      ], 2)
                    ], 64)) : V("", !0) : (L(), A("div", {
                      key: 0,
                      class: d(r(o).e("unsupported"))
                    }, [
                      b("span", {
                        class: d(r(o).e("unsupported-name")),
                        title: P.file.name
                      }, Q(P.file.name), 11, _s)
                    ], 2))
                  ], 64)) : V("", !0)
                ], 42, fs);
              }), 128))
            ], 6)) : V("", !0),
            y.value && y.value.length ? (L(), A("div", {
              key: 1,
              class: d(r(o).e("help-text"))
            }, " Upload more images by dropping them anywhere in this window. Reorder images by dragging them. Hover over an image to edit caption. ", 2)) : (L(), A("div", {
              key: 2,
              class: d(r(o).e("empty"))
            }, [
              b("div", {
                class: d(r(o).e("dropzone")),
                onClick: U,
                onDragover: M[7] || (M[7] = N(() => {
                }, ["prevent"])),
                onDrop: N(E, ["prevent"])
              }, [
                b("div", {
                  class: d(r(o).e("dropzone-icon"))
                }, [
                  B(r(te), { icon: "mdi:image-plus" })
                ], 2),
                b("div", {
                  class: d(r(o).e("dropzone-text"))
                }, " Drag & drop images here or click to select ", 2)
              ], 34)
            ], 2)),
            g.value ? (L(), A("div", {
              key: 3,
              class: d(r(o).e("progress"))
            }, [
              b("div", {
                class: d(r(o).e("progress-text"))
              }, " Uploading: " + Q(x.value) + "/" + Q(v.value), 3),
              b("div", {
                class: d(r(o).e("progress-bar"))
              }, [
                b("div", {
                  class: d(r(o).e("progress-fill")),
                  style: De({ width: p.value + "%" })
                }, null, 6)
              ], 2),
              k.value ? (L(), A("div", {
                key: 0,
                class: d(r(o).e("progress-error"))
              }, " Some files failed to upload. ", 2)) : V("", !0)
            ], 2)) : V("", !0)
          ], 2)
        ]),
        _: 1
      }, 8, ["modelValue", "title", "ok-text", "ok-disabled", "loading", "confirm", "append-to"]),
      (L(), Ce(Sn, {
        to: n.portalBinding.target
      }, [
        B(An, { name: "fade" }, {
          default: je(() => [
            s.value ? (L(), A("div", {
              key: 0,
              class: d(r(o).e("drag-overlay"))
            }, [
              b("div", {
                class: d(r(o).e("drag-overlay-text"))
              }, "Drop images anywhere", 2)
            ], 2)) : V("", !0)
          ]),
          _: 1
        })
      ], 8, ["to"]))
    ], 64));
  }
}), Hm = (e) => e.nearestScope && e.nearestScope.state !== "disposed" ? e.nearestScope : e.nearestScopeAvailable ? null : e.app ?? null, ct = (e) => Object.freeze({ ok: !0, value: e, diagnostics: [] }), Ze = (e, t, n = {}) => Object.freeze({
  ok: !1,
  diagnostics: Object.freeze([
    Object.freeze({ code: e, phase: t, details: Object.freeze({ ...n }) })
  ])
}), Es = (e) => Object.freeze({
  runtimeId: e.runtimeId,
  scopeId: e.scopeId,
  target: e.target,
  appContext: e.appContext,
  get themeId() {
    return e.themeId;
  },
  get variantKey() {
    return e.variantKey;
  }
}), Vm = (e, t) => {
  if (!e || !t || e.runtimeId !== t.runtimeId)
    return Ze("EDITOR_THEME_OWNER_RUNTIME_MISMATCH", "create");
  const n = e.resolveFeedbackOwner(t);
  if (!n.ok) return n;
  if (n.value.runtimeId !== e.runtimeId || n.value.scope.runtimeId !== e.runtimeId || n.value.state === "disposed" || n.value.scope.state === "disposed")
    return Ze("EDITOR_THEME_OWNER_INACTIVE", "create");
  const a = e.createFeedback(n.value.scope);
  if (!a.ok) return a;
  const o = n.value.scope, i = n.value.appContext, s = a.value, l = /* @__PURE__ */ new Set();
  let m = "active";
  const c = () => Promise.resolve(Ze("EDITOR_THEME_OWNER_DISPOSED", "feedback")), u = Object.freeze({
    message(...f) {
      return m === "active" ? s.message(...f) : c();
    },
    notification(...f) {
      return m === "active" ? s.notification(...f) : c();
    },
    confirm(...f) {
      return m === "active" ? s.confirm(...f) : c();
    }
  }), j = {
    runtimeId: e.runtimeId,
    scopeId: o.scopeId,
    get state() {
      return m;
    },
    feedback: u,
    async acquirePortal() {
      if (m !== "active")
        return Ze("EDITOR_THEME_OWNER_DISPOSED", "portal");
      const f = await e.acquirePortal(o);
      if (!f.ok) return f;
      const g = f.value;
      if (g.runtimeId !== e.runtimeId || g.scopeId !== o.scopeId || g.appContext !== i)
        return g.release(), Ze("EDITOR_THEME_PORTAL_IDENTITY_MISMATCH", "portal");
      if (m !== "active")
        return g.release(), Ze("EDITOR_THEME_OWNER_DISPOSED", "portal");
      let h = !1;
      const p = Object.freeze({
        runtimeId: g.runtimeId,
        scopeId: g.scopeId,
        target: g.target,
        appContext: g.appContext,
        get themeId() {
          return g.themeId;
        },
        get variantKey() {
          return g.variantKey;
        },
        release() {
          h || (h = !0, l.delete(p), g.release());
        }
      });
      return l.add(p), ct(p);
    },
    dispose() {
      if (m === "disposed") return ct(void 0);
      m = "disposed";
      for (const f of [...l]) f.release();
      return ct(void 0);
    }
  };
  return ct(Object.freeze(j));
}, Kn = Symbol.for(
  "@zxio/text-editor/theme-owner"
), qm = (e) => e ?? Pn(Kn, null), Ts = (e) => {
  const t = e ?? Pn(Kn, null), n = Ue(null), a = Ue([]);
  let o = null, i = 0, s = !0;
  const l = () => {
    i += 1, s = !1, n.value = null, o == null || o.release(), o = null;
  };
  return (async () => {
    if (!t || t.state !== "active") {
      a.value = Object.freeze([
        Object.freeze({
          code: "EDITOR_THEME_OWNER_REQUIRED",
          phase: "portal",
          details: Object.freeze({})
        })
      ]);
      return;
    }
    const c = ++i, u = await t.acquirePortal();
    if (!s || c !== i) {
      u.ok && u.value.release();
      return;
    }
    if (!u.ok) {
      a.value = u.diagnostics;
      return;
    }
    o = u.value, n.value = Es(u.value), a.value = [];
  })(), Wo(l), Object.freeze({
    binding: n,
    diagnostics: a,
    release: l
  });
}, Ls = ["onClick"], Is = ["src", "alt", "onClick"], Ss = ["src", "alt"], As = ["title"], Ps = /* @__PURE__ */ ke({
  __name: "ImageGroupNodeView",
  props: {
    decorations: {},
    selected: { type: Boolean },
    updateAttributes: { type: Function },
    deleteNode: { type: Function },
    node: {},
    view: {},
    getPos: {},
    innerDecorations: {},
    editor: {},
    extension: {},
    HTMLAttributes: {}
  },
  setup(e) {
    var Z, q;
    const t = e, n = xe("text-editor-image-group"), a = (q = (Z = t.editor.extensionManager.extensions.find(
      ($) => $.name === "imageGroup"
    )) == null ? void 0 : Z.options) == null ? void 0 : q.themeOwner, { binding: o } = Ts(a), i = R(() => {
      var $;
      return (($ = t.node.attrs) == null ? void 0 : $.columns) || 4;
    }), s = R(() => {
      var $;
      return (($ = t.node.content) == null ? void 0 : $.content) || [];
    }), l = R(() => ({
      gridTemplateColumns: `repeat(${i.value}, minmax(0, 1fr))`
    })), m = S(t.editor.isEditable), c = [
      { label: "2 columns", value: "2" },
      { label: "3 columns", value: "3" },
      { label: "4 columns", value: "4" }
    ], u = R({
      get: () => String(i.value),
      set: ($) => t.updateAttributes({ columns: +$ })
    }), j = S(!1), f = S(0), g = R(
      () => s.value.map(($) => ({
        src: $.attrs.src,
        alt: $.attrs.alt || ""
      }))
    ), h = S(!1), p = S([]), x = R(
      () => s.value.map(($) => ({
        src: $.attrs.src,
        alt: $.attrs.alt || ""
      }))
    );
    Fe(() => {
      const $ = () => {
        m.value = t.editor.isEditable;
      };
      t.editor.on("update", $), ze(() => {
        t.editor.off("update", $);
      });
    });
    function v() {
      p.value = [], h.value = !0;
    }
    function w() {
      h.value = !1, p.value = [];
    }
    async function C($) {
      t.editor.commands.command(({ tr: U, state: J }) => {
        const E = t.getPos();
        if (typeof E == "number") {
          const H = J.doc.nodeAt(E);
          if (H && H.type.name === "imageGroup") {
            const W = $.images.map(
              (de) => J.schema.nodes.image.create({ src: de.src, alt: de.alt })
            ), se = { ...H.attrs, columns: $.columns }, ae = H.type.create(se, W);
            return U.replaceWith(E, E + H.nodeSize, ae), !0;
          }
        }
        return !1;
      }), h.value = !1;
    }
    function k($) {
      t.editor.isEditable || (f.value = $, j.value = !0);
    }
    function y($) {
      const U = s.value.slice();
      U.splice($, 1), U.length === 0 ? t.editor.commands.deleteNode("imageGroup") : (t.updateAttributes({}), t.editor.commands.command(({ tr: J, state: E }) => {
        const H = t.getPos();
        if (typeof H == "number") {
          const W = E.doc.nodeAt(H);
          if (W && W.type.name === "imageGroup") {
            const se = U.map(
              (ae) => E.schema.nodes.image.create(ae.attrs)
            );
            return J.replaceWith(H + 1, H + 1 + W.content.size, se), !0;
          }
        }
        return !1;
      }));
    }
    return ($, U) => (L(), Ce(r(et), {
      "data-block-id": e.node.attrs.blockId || void 0
    }, {
      default: je(() => {
        var J;
        return [
          b("div", {
            class: d(r(n).b())
          }, [
            m.value ? (L(), A("div", {
              key: 0,
              class: d(r(n).e("header"))
            }, [
              B(r(We), {
                size: "small",
                onClick: v
              }, {
                default: je(() => [
                  B(r(te), { icon: "lucide:edit" }),
                  U[3] || (U[3] = Ie(" Edit ", -1))
                ]),
                _: 1
              }),
              B(r(Nt), {
                modelValue: u.value,
                "onUpdate:modelValue": U[0] || (U[0] = (E) => u.value = E),
                class: d(r(n).e("column-select")),
                size: "small",
                options: c,
                "append-to": (J = r(o)) == null ? void 0 : J.target
              }, null, 8, ["modelValue", "class", "append-to"])
            ], 2)) : V("", !0),
            b("div", {
              class: d(r(n).e("grid")),
              style: De(l.value)
            }, [
              (L(!0), A(ve, null, Pe(s.value, (E, H) => (L(), A("div", {
                key: E.attrs.src + H,
                class: d(r(n).e("item"))
              }, [
                m.value ? (L(), A("button", {
                  key: 0,
                  type: "button",
                  class: d(r(n).e("remove-btn")),
                  "aria-label": "Remove image",
                  onClick: N((W) => y(H), ["stop"])
                }, [
                  B(r(te), { icon: "lucide:x" })
                ], 10, Ls)) : V("", !0),
                m.value ? (L(), A("img", {
                  key: 2,
                  src: E.attrs.src,
                  alt: E.attrs.alt || "",
                  class: d(r(n).e("image"))
                }, null, 10, Ss)) : (L(), A("img", {
                  key: 1,
                  src: E.attrs.src,
                  alt: E.attrs.alt || "",
                  class: d([r(n).e("image"), r(n).is("clickable", !0)]),
                  onClick: (W) => k(H)
                }, null, 10, Is)),
                E.attrs.alt ? (L(), A("div", {
                  key: 3,
                  class: d(r(n).e("caption"))
                }, [
                  b("div", {
                    class: d(r(n).e("caption-text")),
                    title: E.attrs.alt
                  }, Q(E.attrs.alt), 11, As)
                ], 2)) : V("", !0)
              ], 2))), 128))
            ], 6),
            j.value && r(o) ? (L(), Ce(Un, {
              key: 1,
              show: j.value,
              "onUpdate:show": U[1] || (U[1] = (E) => j.value = E),
              images: g.value,
              "initial-index": f.value,
              "portal-binding": r(o)
            }, null, 8, ["show", "images", "initial-index", "portal-binding"])) : V("", !0),
            h.value && r(o) ? (L(), Ce(xs, {
              key: 2,
              modelValue: h.value,
              "onUpdate:modelValue": U[2] || (U[2] = (E) => h.value = E),
              files: p.value,
              editor: t.editor,
              mode: "edit",
              "existing-images": x.value,
              "initial-columns": i.value,
              "portal-binding": r(o),
              onClose: w,
              onSave: C
            }, null, 8, ["modelValue", "files", "editor", "existing-images", "initial-columns", "portal-binding"])) : V("", !0),
            In($.$slots, "default")
          ], 2)
        ];
      }),
      _: 3
    }, 8, ["data-block-id"]));
  }
}), Ms = Re.create({
  name: "imageGroup",
  group: "block",
  content: "image+",
  // one or more images
  selectable: !0,
  draggable: !0,
  isolating: !0,
  addOptions() {
    return {
      filePlatformRuntime: null,
      themeOwner: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      columns: {
        default: 4
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="image-group"]',
        getAttrs: (e) => {
          if (typeof e == "string") return {};
          const t = e;
          return {
            columns: t.dataset.columns ? Number(t.dataset.columns) : 4
          };
        }
      }
    ];
  },
  renderHTML({ HTMLAttributes: e, node: t }) {
    return [
      "div",
      Oe(
        {
          "data-type": "image-group",
          "data-columns": t.attrs.columns
        },
        this.options.HTMLAttributes,
        e
      ),
      0
      // content placeholder for child images
    ];
  },
  addNodeView() {
    return Ge(Ps);
  },
  addCommands() {
    return {
      setImageGroup: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: {
          columns: e.columns || 4
        },
        content: e.images.map((n) => ({
          type: "image",
          attrs: n
        }))
      })
    };
  }
}), Ds = (e, t, n, a) => {
  e.emitDiagnostic({
    code: t,
    message: n,
    severity: "error",
    stage: "intake",
    cause: a
  });
}, Rs = Re.create({
  name: "video",
  group: "block",
  selectable: !0,
  draggable: !0,
  atom: !0,
  addOptions() {
    return {
      filePlatformRuntime: null,
      HTMLAttributes: {}
    };
  },
  addAttributes() {
    return {
      assetId: {
        default: null,
        parseHTML: (e) => e.dataset.assetId ?? null,
        renderHTML: (e) => ({
          "data-asset-id": e.assetId
        })
      },
      src: {
        default: null
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: "video"
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "video",
      Oe(this.options.HTMLAttributes, e, {
        controls: ""
      })
    ];
  },
  addCommands() {
    return {
      setVideo: (e) => ({ commands: t }) => t.insertContent({
        type: this.name,
        attrs: e
      }),
      uploadVideo: (e, t = "programmatic") => () => this.options.filePlatformRuntime ? t === "programmatic" || t === "picker" ? qn(
        this.options.filePlatformRuntime,
        [e],
        {
          source: t === "picker" ? "picker" : "programmatic",
          context: {
            nodeKind: "video",
            preferredNodeKind: "video"
          }
        }
      ) : (Promise.resolve(
        this.options.filePlatformRuntime.intakeFiles({
          source: t,
          files: [e],
          context: {
            nodeKind: "video",
            preferredNodeKind: "video"
          }
        })
      ).catch((n) => {
        const a = this.options.filePlatformRuntime;
        Ds(
          a,
          `${t}-video-intake-dispatch-failed`,
          n instanceof Error ? n.message : `Failed to dispatch ${t} video intake.`,
          n
        );
      }), !0) : !1,
      selectAndUploadVideo: () => ({ dispatch: e }) => {
        if (!this.options.filePlatformRuntime)
          return !1;
        if (!e)
          return !0;
        const t = document.createElement("input");
        return t.type = "file", t.accept = "video/*", t.onchange = (n) => {
          const a = n.target;
          a.files && a.files.length && Vn(
            this.options.filePlatformRuntime,
            a.files,
            {
              context: {
                nodeKind: "video",
                preferredNodeKind: "video"
              }
            }
          );
        }, t.click(), !0;
      }
    };
  },
  addNodeView() {
    return ({ editor: e, node: t }) => {
      const n = (i, s) => {
        const l = typeof s.attrs.blockId == "string" ? s.attrs.blockId : null;
        if (l) {
          i.dataset.blockId = l;
          return;
        }
        delete i.dataset.blockId;
      }, a = document.createElement("div");
      a.className = `relative aspect-w-16 aspect-h-9${e.isEditable ? " cursor-pointer" : ""}`, n(a, t);
      const o = document.createElement("video");
      if (o.src = t.attrs.src, o.setAttribute("controls", ""), e.isEditable) {
        const i = document.createElement("div");
        i.className = "absolute top-0 right-0 text-xs m-2 bg-surface-gray-6 text-ink-white px-2 py-1 rounded-md", i.innerHTML = "Video", a.append(i);
      }
      return a.append(o), {
        dom: a,
        update: (i) => i.type.name !== this.name ? !1 : (o.src = i.attrs.src, n(a, i), !0)
      };
    };
  }
}), Os = /* @__PURE__ */ ke({
  name: "ToggleNodeView",
  __name: "ToggleNodeView",
  props: {
    decorations: {},
    selected: { type: Boolean },
    updateAttributes: { type: Function },
    deleteNode: { type: Function },
    node: {},
    view: {},
    getPos: {},
    innerDecorations: {},
    editor: {},
    extension: {},
    HTMLAttributes: {}
  },
  setup(e) {
    const t = e, n = xe("toggle"), a = S(t.node.attrs.open ?? !1);
    Le(
      () => t.node.attrs.open,
      (i) => {
        typeof i == "boolean" && (a.value = i);
      },
      { immediate: !0 }
    );
    const o = (i) => {
      i.preventDefault(), i.stopPropagation();
      const s = !a.value;
      if (a.value = s, t.updateAttributes({
        open: s
      }), !s) {
        const l = t.getPos();
        if (typeof l != "number") return;
        const { selection: m } = t.editor.state;
        if (!(m.from >= l && m.to <= l + t.node.nodeSize)) return;
        const u = t.node.firstChild;
        if (!u) return;
        const j = l + 1 + u.nodeSize - 1;
        t.editor.chain().focus().setTextSelection(j).run();
      }
    };
    return (i, s) => (L(), Ce(r(et), {
      as: "div",
      class: d([r(n).b(), { [r(n).is("open")]: a.value }]),
      "data-block-id": e.node.attrs.blockId || void 0,
      "data-open": a.value
    }, {
      default: je(() => [
        b("div", {
          class: d(r(n).e("summary")),
          onClick: o,
          onMousedown: s[0] || (s[0] = N(() => {
          }, ["prevent"]))
        }, [
          b("span", {
            class: d(r(n).e("icon")),
            "aria-hidden": "true"
          }, [
            (L(), A("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              width: "16",
              height: "16",
              viewBox: "0 0 24 24",
              fill: "currentColor",
              class: d([r(n).e("arrow"), { [r(n).is("rotated")]: a.value }])
            }, [...s[1] || (s[1] = [
              b("path", { d: "M8 5.5l7.5 6.5-7.5 6.5z" }, null, -1)
            ])], 2))
          ], 2)
        ], 34),
        b("div", {
          class: d(r(n).e("body"))
        }, [
          B(r(Rn), {
            class: d(r(n).e("editor-content"))
          }, null, 8, ["class"])
        ], 2)
      ]),
      _: 1
    }, 8, ["class", "data-block-id", "data-open"]));
  }
}), un = (e) => e.content.size === 0 ? !0 : e.textContent.replace(/[\s\u200B\uFEFF]/g, "").length === 0, Ns = Re.create({
  name: "toggle",
  group: "block",
  content: "toggleSummary toggleContent",
  defining: !0,
  isolating: !0,
  addOptions() {
    return {
      HTMLAttributes: {},
      persist: !0,
      openClassName: "is-open"
    };
  },
  addAttributes() {
    return {
      open: {
        default: !1,
        parseHTML: (e) => e.dataset.open === "true",
        renderHTML: (e) => ({ "data-open": e.open ? "true" : "false" })
      }
    };
  },
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(this.options.HTMLAttributes, e, {
        "data-type": "toggle"
      }),
      0
    ];
  },
  addNodeView() {
    return Ge(Os);
  },
  addCommands() {
    return {
      setToggle: () => ({ commands: e }) => e.insertContent({
        type: this.name,
        attrs: { open: !1 },
        content: [
          {
            type: "toggleSummary",
            content: []
          },
          {
            type: "toggleContent",
            content: [{ type: "paragraph" }]
          }
        ]
      }),
      toggleToggleOpen: () => ({ tr: e, state: t, dispatch: n }) => {
        const { selection: a } = t, { $from: o } = a;
        let i = o.depth;
        for (; i > 0; ) {
          const s = o.node(i);
          if (s.type.name === "toggle") {
            if (n) {
              const l = o.before(i), m = !s.attrs.open;
              if (e.setNodeMarkup(l, void 0, {
                ...s.attrs,
                open: m
              }), !m) {
                let c = o.depth;
                for (; c > i && o.node(c).type.name !== "toggleContent"; )
                  c--;
                if (c > i && o.node(c).type.name === "toggleContent") {
                  const u = s.firstChild;
                  if (u) {
                    const j = l + 1 + u.nodeSize - 1;
                    e.setSelection(
                      Xe.create(e.doc, j)
                    );
                  }
                }
              }
              n(e);
            }
            return !0;
          }
          i--;
        }
        return !1;
      },
      unsetToggle: () => ({ tr: e, state: t, dispatch: n }) => {
        const { selection: a } = t, { $from: o } = a;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const s = o.before(i), l = t.doc.nodeAt(s);
        if (!l) return !1;
        const m = t.schema.nodes.paragraph, c = [], u = l.firstChild;
        u && u.content.size > 0 && m && c.push(
          m.create(null, u.content)
        );
        const j = l.childCount > 1 ? l.child(1) : null;
        if (j && j.forEach((f) => {
          c.push(f.copy(f.content));
        }), c.length === 0 && m && c.push(m.create()), n) {
          e.replaceWith(
            s,
            s + l.nodeSize,
            c
          );
          const f = s + 1;
          f <= e.doc.content.size && e.setSelection(
            Xe.create(e.doc, f)
          ), n(e.scrollIntoView());
        }
        return !0;
      }
    };
  },
  addKeyboardShortcuts() {
    return {
      "Mod-Shift-t": () => this.editor.commands.setToggle()
    };
  }
}), $s = Re.create({
  name: "toggleSummary",
  priority: 1e3,
  group: "block",
  content: "inline*",
  defining: !0,
  selectable: !1,
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle-summary"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(e, { "data-type": "toggle-summary" }),
      0
    ];
  },
  addKeyboardShortcuts() {
    return {
      // Enter in summary: move to content or unset if empty
      Enter: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a } = n;
        return a.parent.type.name !== "toggleSummary" ? !1 : un(a.parent) ? e.commands.command(({ state: o, dispatch: i }) => {
          const { selection: s } = o, { $from: l } = s;
          let m = l.depth;
          for (; m > 0 && l.node(m).type.name !== "toggle"; )
            m--;
          if (m === 0) return !1;
          const c = l.before(m), u = o.doc.nodeAt(c);
          if (!u) return !1;
          const j = o.schema.nodes.paragraph;
          if (!j) return !1;
          const f = o.tr.replaceWith(
            c,
            c + u.nodeSize,
            j.create()
          ), g = c + 1;
          return g <= f.doc.content.size && f.setSelection(Xe.create(f.doc, g)), i && i(f.scrollIntoView()), !0;
        }) : e.commands.command(({ state: o, dispatch: i }) => {
          const { selection: s } = o, { $head: l } = s;
          if (l.parent.type.name !== "toggleSummary") return !1;
          let m = l.depth;
          for (; m > 0 && l.node(m).type.name !== "toggle"; )
            m--;
          if (m === 0) return !1;
          const c = o.tr, u = l.before(m), j = l.node(m), f = j.firstChild, g = j.childCount > 1 ? j.child(1) : null;
          if (!f || !g) return !1;
          const h = j.attrs.open === !0, p = u + j.nodeSize, x = (U) => {
            const J = o.schema.nodes.paragraph;
            return !!(U && J && U.type === J && U.content.size === 0);
          };
          if (!h) {
            const U = c.doc.resolve(p);
            if (x(U.nodeAfter)) {
              const ie = p + U.nodeAfter.nodeSize;
              for (; ; ) {
                const F = c.doc.resolve(ie);
                if (!x(F.nodeAfter)) break;
                c.delete(
                  ie,
                  ie + F.nodeAfter.nodeSize
                );
              }
              return c.setSelection(
                Te.near(c.doc.resolve(p + 1), 1)
              ), i && i(c.scrollIntoView()), !0;
            }
            const J = m - 1, E = l.node(J), H = l.indexAfter(m), W = pt(E.contentMatchAt(H));
            if (!W || !E.canReplaceWith(H, H, W))
              return !1;
            const se = W.createAndFill();
            if (!se) return !1;
            const ae = l.after(m);
            c.replaceWith(ae, ae, se);
            const de = c.doc.resolve(ae);
            return c.setSelection(Te.near(de, 1)), i && i(c.scrollIntoView()), !0;
          }
          const v = g.firstChild, w = o.schema.nodes.paragraph;
          if (v && w && v.type === w && v.content.size === 0) {
            for (; ; ) {
              const E = c.doc.resolve(p);
              if (!x(E.nodeAfter)) break;
              c.delete(
                p,
                p + E.nodeAfter.nodeSize
              );
            }
            const U = u + 1 + f.nodeSize, J = Xe.near(
              c.doc.resolve(U + 1),
              1
            );
            return c.setSelection(J), i && i(c.scrollIntoView()), !0;
          }
          const C = o.doc.nodeAt(l.after()) ?? g, k = 0, y = pt(C.contentMatchAt(k));
          if (!y || !C.canReplaceWith(k, k, y)) return !1;
          const Z = y.createAndFill();
          if (!Z) return !1;
          const q = l.after() + 1;
          for (; ; ) {
            const U = c.doc.resolve(p);
            if (!x(U.nodeAfter)) break;
            c.delete(
              p,
              p + U.nodeAfter.nodeSize
            );
          }
          c.replaceWith(q, q, Z);
          const $ = c.doc.resolve(q);
          return c.setSelection(Te.near($, 1)), i && i(c.scrollIntoView()), !0;
        });
      },
      // Mod-Shift-Enter in summary: insert a new default block below the toggle (without changing open state)
      "Mod-Shift-Enter": ({ editor: e }) => e.commands.command(({ state: t, dispatch: n }) => {
        const { selection: a } = t, { $head: o } = a;
        if (o.parent.type.name !== "toggleSummary") return !1;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const s = o.before(i), l = o.node(i), m = s + l.nodeSize, c = t.tr, u = c.doc.resolve(m), j = (w) => {
          const C = t.schema.nodes.paragraph;
          return !!(w && C && w.type === C && w.content.size === 0);
        };
        if (j(u.nodeAfter)) {
          const w = m + u.nodeAfter.nodeSize;
          for (; ; ) {
            const C = c.doc.resolve(w);
            if (!j(C.nodeAfter)) break;
            c.delete(
              w,
              w + C.nodeAfter.nodeSize
            );
          }
          return c.setSelection(
            Te.near(c.doc.resolve(m + 1), 1)
          ), n && n(c.scrollIntoView()), !0;
        }
        const f = o.node(-2), g = o.indexAfter(-1), h = pt(f.contentMatchAt(g));
        if (!h || !f.canReplaceWith(g, g, h)) return !1;
        const p = h.createAndFill();
        if (!p) return !1;
        const x = o.after(-1);
        c.replaceWith(x, x, p);
        const v = c.doc.resolve(x);
        return c.setSelection(Te.near(v, 1)), n && n(c.scrollIntoView()), !0;
      }),
      // Backspace at start of empty summary: unset toggle
      Backspace: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        return !o || a.parent.type.name !== "toggleSummary" || a.parentOffset !== 0 ? !1 : un(a.parent) ? e.commands.unsetToggle() : !1;
      }
    };
  }
}), zs = Re.create({
  name: "toggleContent",
  priority: 1e3,
  group: "block",
  content: "block+",
  defining: !0,
  selectable: !1,
  parseHTML() {
    return [
      {
        tag: 'div[data-type="toggle-content"]'
      }
    ];
  },
  renderHTML({ HTMLAttributes: e }) {
    return [
      "div",
      Oe(e, { "data-type": "toggle-content" }),
      0
    ];
  },
  addKeyboardShortcuts() {
    return {
      // Escape: move focus back to summary (Notion-like "go to parent block")
      Escape: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a } = n;
        let o = a.depth;
        for (; o > 0 && a.node(o).type.name !== "toggleContent"; )
          o--;
        if (o === 0) return !1;
        let i = o;
        for (; i > 0 && a.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const s = a.before(i), m = a.node(i).firstChild;
        if (!m) return !1;
        const c = s + 1 + m.nodeSize - 1;
        return e.chain().setTextSelection(c).focus().run();
      },
      // ArrowUp at the top of the first content block: move to summary end
      ArrowUp: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        if (!o || !a.parent.isTextblock || a.parentOffset !== 0) return !1;
        let i = a.depth;
        for (; i > 0 && a.node(i).type.name !== "toggleContent"; )
          i--;
        if (i === 0) return !1;
        const s = a.before(i), l = a.pos > 0 ? t.doc.resolve(a.pos - 1) : null, m = l ? Te.findFrom(l, -1, !0) : null;
        if (m) {
          let h = m.$from.depth;
          for (; h > 0 && m.$from.node(h).type.name !== "toggleContent"; )
            h--;
          if (h > 0 && m.$from.before(h) === s)
            return !1;
        }
        let c = i;
        for (; c > 0 && a.node(c).type.name !== "toggle"; )
          c--;
        if (c === 0) return !1;
        const u = a.before(c), f = a.node(c).firstChild;
        if (!f) return !1;
        const g = u + 1 + f.nodeSize - 1;
        return e.chain().setTextSelection(g).focus().run();
      },
      // ArrowDown at the end of the last content block: move to the next block after the toggle (create if needed)
      ArrowDown: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        if (!o || !a.parent.isTextblock || a.parentOffset !== a.parent.content.size) return !1;
        let i = a.depth;
        for (; i > 0 && a.node(i).type.name !== "toggleContent"; )
          i--;
        if (i === 0) return !1;
        const s = a.before(i), l = Math.min(a.pos + 1, t.doc.content.size), m = Te.findFrom(
          t.doc.resolve(l),
          1,
          !0
        );
        if (m) {
          let c = m.$from.depth;
          for (; c > 0 && m.$from.node(c).type.name !== "toggleContent"; )
            c--;
          if (c > 0 && m.$from.before(c) === s)
            return !1;
        }
        return e.commands.command(({ state: c, dispatch: u }) => {
          const { selection: j } = c, { $from: f } = j;
          let g = f.depth;
          for (; g > 0 && f.node(g).type.name !== "toggle"; )
            g--;
          if (g === 0) return !1;
          const h = f.before(g), p = f.node(g), x = h + p.nodeSize, v = c.tr, w = v.doc.resolve(x);
          if (w.nodeAfter)
            return v.setSelection(Te.near(w, 1)), u && u(v.scrollIntoView()), !0;
          const k = c.schema.nodes.paragraph, y = k == null ? void 0 : k.createAndFill();
          return !k || !y ? !1 : (v.insert(x, y), v.setSelection(Xe.create(v.doc, x + 1)), u && u(v.scrollIntoView()), !0);
        });
      },
      // Mod-Shift-Enter: insert a new default block below the toggle (works from content too)
      "Mod-Shift-Enter": ({ editor: e }) => e.commands.command(({ state: t, dispatch: n }) => {
        const { selection: a } = t, { $head: o } = a;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "toggle"; )
          i--;
        if (i === 0) return !1;
        const s = o.before(i), l = o.node(i), m = s + l.nodeSize, c = t.tr, u = c.doc.resolve(m), j = (C) => {
          const k = t.schema.nodes.paragraph;
          return !!(C && k && C.type === k && C.content.size === 0);
        };
        if (j(u.nodeAfter)) {
          const C = m + u.nodeAfter.nodeSize;
          for (; ; ) {
            const k = c.doc.resolve(C);
            if (!j(k.nodeAfter)) break;
            c.delete(
              C,
              C + k.nodeAfter.nodeSize
            );
          }
          return c.setSelection(
            Te.near(c.doc.resolve(m + 1), 1)
          ), n && n(c.scrollIntoView()), !0;
        }
        const f = i - 1, g = o.node(f), h = o.indexAfter(i), p = pt(g.contentMatchAt(h));
        if (!p || !g.canReplaceWith(h, h, p)) return !1;
        const x = p.createAndFill();
        if (!x) return !1;
        const v = o.after(i);
        c.replaceWith(v, v, x);
        const w = c.doc.resolve(v);
        return c.setSelection(Te.near(w, 1)), n && n(c.scrollIntoView()), !0;
      }),
      // Backspace in empty first block of content: move to summary
      Backspace: ({ editor: e }) => {
        const { state: t } = e, { selection: n } = t, { $from: a, empty: o } = n;
        if (!o || a.parentOffset !== 0) return !1;
        let i = a.depth;
        for (; i > 0 && a.node(i).type.name !== "toggleContent"; )
          i--;
        if (i === 0) return !1;
        const s = a.node(i), m = a.before(i) + 1;
        if (a.before(a.depth) !== m || a.parent.content.size > 0) return !1;
        if (s.childCount === 1) {
          const u = i - 1, j = a.before(u), f = t.doc.nodeAt(j);
          if (f && f.firstChild) {
            const g = j + 1 + f.firstChild.nodeSize - 1;
            return e.chain().setTextSelection(g).focus().run();
          }
        }
        return !1;
      }
    };
  }
}), Bs = ({
  mentions: e,
  suggestions: t,
  themeOwner: n
}) => {
  const a = Array.isArray(e) ? {} : (e == null ? void 0 : e.suggestion) ?? {};
  return Zi.configure(
    Array.isArray(e) ? {
      mentions: e,
      suggestion: (t == null ? void 0 : t.mention) ?? {},
      themeOwner: n ?? null
    } : {
      mentions: (e == null ? void 0 : e.mentions) || [],
      component: e == null ? void 0 : e.component,
      suggestion: {
        ...a,
        ...t == null ? void 0 : t.mention
      },
      themeOwner: n ?? null
    }
  );
}, Fs = {
  attachment: ({ getCurrentDocument: e }) => Li.configure({
    getCurrentDocument: e ?? null
  }),
  embed: ({ themeOwner: e }) => ki.configure({
    getDocuments: async () => [],
    themeOwner: e ?? null
  }),
  iframe: ({ themeOwner: e }) => Mi.configure({ themeOwner: e ?? null }),
  image: ({ filePlatformRuntime: e, themeOwner: t }) => [
    Vi.configure({
      filePlatformRuntime: e ?? null
    }),
    ns.configure({ themeOwner: t ?? null })
  ],
  imageGroup: ({ filePlatformRuntime: e, themeOwner: t }) => Ms.configure({
    filePlatformRuntime: e ?? null,
    themeOwner: t ?? null
  }),
  mention: (e) => Bs(e),
  tag: ({ suggestions: e, tags: t, themeOwner: n }) => [
    _n,
    is.configure({
      suggestion: (e == null ? void 0 : e.tag) ?? {},
      tags: () => t ?? [],
      themeOwner: n ?? null
    })
  ],
  toggle: () => [Ns, $s, zs],
  video: ({ filePlatformRuntime: e }) => Rs.configure({
    filePlatformRuntime: e ?? null
  })
}, Hs = (e = {}, t = yn) => t.flatMap((n) => {
  const a = Fs[n.name];
  return a ? Ea(a(e)) : Ta(
    {
      ...e,
      mode: "editor"
    },
    [n]
  );
}), vt = (e) => e.commands, Vs = (e) => {
  const t = e;
  return t.$anchorCell !== void 0 && t.$headCell !== void 0 && typeof t.isColSelection == "function" && typeof t.isRowSelection == "function";
}, qs = (e) => {
  const { from: t, to: n } = e.selection;
  return {
    from: Math.min(t, n),
    to: Math.max(t, n)
  };
}, dn = (e) => {
  for (let t = e.depth; t > 0; t -= 1)
    if (e.node(t).isTextblock)
      return t;
  return -1;
}, Ws = (e, t, n) => {
  const a = qs(e);
  return a.from === t && a.to === n;
};
function pn(e, t) {
  const { selection: n } = e;
  if (n instanceof ja || Vs(n))
    return !1;
  if (n instanceof va) {
    if (n.node.type.name !== "codeBlock")
      return !1;
    const j = n.from + 1, f = n.to - 1;
    return j >= f ? !1 : (t && t(e.tr.setSelection(Ke.create(e.doc, j, f))), !0);
  }
  if (!(n instanceof Ke))
    return !1;
  const { $from: a, $to: o } = n, i = dn(a), s = dn(o);
  if (i < 0 || s < 0)
    return !1;
  if (!(i === s && a.before(i) === o.before(s)))
    return Qt(e, t);
  const m = a.node(i), c = a.start(i), u = a.end(i);
  return m.content.size === 0 ? !1 : Ws(e, c, u) ? Qt(e, t) : (t && t(
    e.tr.setSelection(
      Ke.create(e.doc, c, u)
    )
  ), !0);
}
const zt = "textEditorShortcutKeymap", Us = (e, t, n = {}) => {
  var g;
  const a = En(
    ((g = t.dom.ownerDocument.defaultView) == null ? void 0 : g.navigator.userAgent) ?? ""
  );
  if (!n.runtime && !a)
    throw new Error(
      "An explicit shortcut runtime is required for an unknown platform"
    );
  const o = n.runtime ? null : Tn({ platform: a }), i = n.runtime ?? o, s = i.createOwner({
    contributions: [Ao],
    kind: "textEditor.editor",
    parent: n.parent,
    focusRequired: !0
  }), l = (h) => (e.on("transaction", h), e.on("update", h), e.on("selectionUpdate", h), e.on("destroy", h), () => {
    e.off("transaction", h), e.off("update", h), e.off("selectionUpdate", h), e.off("destroy", h);
  }), m = () => !e.isDestroyed && !t.isDestroyed, c = i.attachAction(Po, {
    owner: s,
    keyboardArgs: () => {
    },
    port: Jt({
      subscribe: l,
      getState: () => {
        const h = vt(e).openLinkEditor;
        return {
          enabled: m() && e.isEditable && typeof h == "function",
          reason: m() ? e.isEditable ? typeof h != "function" ? "link-command-unavailable" : void 0 : "editor-readonly" : "editor-destroyed"
        };
      },
      run: () => vt(e).openLinkEditor()
    })
  }), u = i.attachAction(Mo, {
    owner: s,
    keyboardArgs: () => {
    },
    port: Jt({
      subscribe: l,
      getState: () => ({
        enabled: m() && pn(t.state),
        reason: "selection-not-progressive"
      }),
      run: () => pn(t.state, t.dispatch.bind(t))
    })
  }), j = Io(i, s, { roots: [t.dom] });
  let f = !1;
  return {
    runtime: i,
    owner: s,
    editLink: c.forArgs(void 0, {
      bindingId: "textEditor.link.edit"
    }),
    progressiveSelect: u.forArgs(void 0, {
      bindingId: "textEditor.progressiveSelect"
    }),
    dispatch: (h) => j.dispatch(h, "editor"),
    dispose: () => {
      f || (f = !0, j.dispose(), c.dispose(), u.dispose(), s.dispose(), o == null || o.dispose());
    }
  };
}, Ks = (e) => {
  var n;
  const t = (n = e == null ? void 0 : e.storage) == null ? void 0 : n[zt];
  return (t == null ? void 0 : t.owner) ?? null;
}, Wm = (e, t) => {
  var a, o;
  const n = (a = e == null ? void 0 : e.storage) == null ? void 0 : a[zt];
  return t((n == null ? void 0 : n.owner) ?? null), (o = n == null ? void 0 : n.listeners) == null || o.add(t), () => {
    var i;
    (i = n == null ? void 0 : n.listeners) == null || i.delete(t);
  };
}, gt = zt;
function Xs(e = {}) {
  if ([...e.existingExtensionNames ?? []].includes(
    gt
  ))
    throw new Error(
      `[text-editor/shortcuts] Duplicate TipTap extension name: ${gt}`
    );
  return qe.create({
    name: gt,
    priority: 1100,
    addStorage: () => ({
      owner: null,
      ownedRuntime: null,
      listeners: /* @__PURE__ */ new Set()
    }),
    onDestroy() {
      var t, n;
      (t = this.storage.owner) == null || t.dispose(), this.storage.owner = null, this.storage.listeners.forEach((a) => a(null)), this.storage.listeners.clear(), (n = this.storage.ownedRuntime) == null || n.dispose(), this.storage.ownedRuntime = null;
    },
    addProseMirrorPlugins() {
      const t = this.editor, n = this.storage;
      return [
        new Ne({
          props: {
            handleKeyDown: (a, o) => {
              var i;
              return ((i = n.owner) == null ? void 0 : i.dispatch(o)) ?? !1;
            }
          },
          view: (a) => {
            var i;
            if (!e.runtime && !n.ownedRuntime) {
              const s = En(
                ((i = a.dom.ownerDocument.defaultView) == null ? void 0 : i.navigator.userAgent) ?? ""
              );
              if (!s)
                throw new Error(
                  "An explicit shortcut runtime is required for an unknown platform"
                );
              n.ownedRuntime = Tn({ platform: s });
            }
            const o = Us(t, a, {
              ...e,
              runtime: e.runtime ?? n.ownedRuntime
            });
            return n.owner = o, n.listeners.forEach((s) => s(o)), {
              destroy: () => {
                o.dispose(), n.owner === o && (n.owner = null, n.listeners.forEach((s) => s(null)));
              }
            };
          }
        })
      ];
    }
  });
}
const Gs = /* @__PURE__ */ new Set([
  "doc",
  "paragraph",
  "text",
  "hardBreak",
  "bold",
  "italic",
  "link",
  "textStyle",
  "namedColor",
  "bulletList",
  "orderedList",
  "listItem",
  "undoRedo",
  "history",
  "dropCursor",
  "gapCursor",
  "stableBlockIdentity",
  "stableBlockIdentityEngine",
  "stableBlockDomAttributes",
  "stableBlockIdentityDiagnostics",
  "textEditorSchemaKernelBinding",
  "placeholder",
  "deterministicRuntimeCommitClosure",
  "textEditorTypographyContract",
  // Interaction surfaces stay mounted; the profile boundary filters their items.
  "slashCommands",
  gt
]), Zs = new RegExp(
  `^color:\\s*var\\(--prose-color-(${Dt.textColors.join(
    "|"
  )})\\);?$`
), Xn = (e) => {
  const t = typeof e.config.addExtensions == "function", n = e.name === "link" ? { addProseMirrorPlugins: () => [] } : Gs.has(e.name) || e.name === "starterKit" ? {} : {
    addKeyboardShortcuts: () => ({}),
    addInputRules: () => [],
    addPasteRules: () => [],
    addProseMirrorPlugins: () => [],
    addNodeView: () => null
  };
  return e.extend({
    ...n,
    ...t ? {
      addExtensions() {
        var a;
        return (((a = this.parent) == null ? void 0 : a.call(this)) ?? []).map(Xn);
      }
    } : {}
  });
}, Ys = (e) => ({
  version: 2,
  body: { format: "json", content: e },
  assets: [],
  annotations: [],
  meta: { schemaVersion: "stable-block-identity/v2" }
}), Js = (e) => {
  const t = JSON.parse(JSON.stringify(e));
  let n = 0;
  const a = (o) => {
    var i;
    o.attrs && "blockId" in o.attrs && (o.attrs.blockId = `blk_probe${++n}`), (i = o.content) == null || i.forEach(a);
  };
  return a(t), Ys(t);
};
function Qs(e) {
  var o, i;
  const t = new DOMParser().parseFromString(e, "text/html");
  let n = !1;
  t.querySelectorAll("script,style,img,video,audio,iframe,object,embed,input").forEach((s) => {
    n = !0, s.remove();
  }), t.querySelectorAll("table").forEach((s) => {
    const l = t.createElement("div");
    s.querySelectorAll("tr").forEach((m) => {
      const c = t.createElement("p");
      c.textContent = Array.from(m.children).map((u) => u.textContent ?? "").join("	"), l.append(c);
    }), s.replaceWith(...l.childNodes);
  }), t.querySelectorAll("pre").forEach((s) => {
    const l = t.createElement("div");
    (s.textContent ?? "").replace(/\r\n?/g, `
`).split(`
`).forEach((m) => {
      const c = t.createElement("p");
      c.textContent = m, l.append(c);
    }), s.replaceWith(...l.childNodes);
  });
  const a = /* @__PURE__ */ new Set([
    "P",
    "BR",
    "B",
    "STRONG",
    "I",
    "EM",
    "A",
    "OL",
    "UL",
    "LI"
  ]);
  for (const s of Array.from(t.body.querySelectorAll("*")).reverse()) {
    const l = s.tagName === "SPAN" && s.attributes.length === 1 && ((i = Zs.exec(((o = s.getAttribute("style")) == null ? void 0 : o.trim()) ?? "")) == null ? void 0 : i[1]);
    if (/^H[1-6]$/.test(s.tagName) || s.tagName === "DIV") {
      const m = t.createElement("p");
      m.append(...s.childNodes), s.replaceWith(m);
    } else if (l)
      s.setAttribute("style", `color: var(--prose-color-${l})`);
    else if (!a.has(s.tagName)) s.replaceWith(...s.childNodes);
    else {
      const m = s.getAttribute("href"), c = s.getAttribute("start");
      for (const u of Array.from(s.attributes)) s.removeAttribute(u.name);
      if (s.tagName === "A")
        try {
          s.setAttribute("href", Sa(m)), s.setAttribute("target", "_blank"), s.setAttribute("rel", "noopener noreferrer nofollow");
        } catch {
          s.replaceWith(...s.childNodes);
        }
      s.tagName === "OL" && c && /^\d+$/.test(c) && +c >= 1 && +c <= 1e6 && s.setAttribute("start", c);
    }
  }
  return { html: t.body.innerHTML, dropped: n };
}
const er = (e) => qe.create({
  name: La,
  priority: 1e4,
  addStorage: () => ({
    capabilities: new Set(Dt.capabilities),
    textColors: Dt.textColors
  }),
  addProseMirrorPlugins() {
    let t = !1;
    const n = new Ut(
      this.editor.schema,
      Ut.fromSchema(this.editor.schema).rules
    ), a = n.parseSlice.bind(n);
    return n.parseSlice = (o, i) => a(o, { ...i, preserveWhitespace: !0 }), [
      new Ne({
        key: new Me("basicRichTextAdmission"),
        filterTransaction: (o) => {
          var i;
          if (!o.docChanged) return !0;
          try {
            return Ia(
              Js(o.doc.toJSON()),
              o.getMeta("paste") ? e.limits : {
                ...Et,
                ...e.limits,
                characters: Number.MAX_SAFE_INTEGER,
                bytes: Number.MAX_SAFE_INTEGER,
                nodes: Number.MAX_SAFE_INTEGER
              }
            ), !0;
          } catch (s) {
            return (i = e.issue) == null || i.call(e, String(s)), !1;
          }
        },
        props: {
          clipboardParser: n,
          clipboardTextParser: (o, i) => {
            const s = document.createElement("div"), l = ba.fromSchema(this.editor.schema);
            for (const m of o.replace(/\r\n?/g, `
`).split(`
`)) {
              const c = s.appendChild(document.createElement("p"));
              m && c.appendChild(
                l.serializeNode(
                  this.editor.schema.text(m, i.marks())
                )
              );
            }
            return n.parseSlice(s, {
              context: i,
              preserveWhitespace: !0
            });
          },
          transformPastedText: (o) => {
            var i, s;
            return t = new TextEncoder().encode(o).length > (((i = e.limits) == null ? void 0 : i.bytes) ?? Et.bytes), t ? ((s = e.issue) == null || s.call(e, "粘贴内容超过文档资源限制，未插入"), "") : o;
          },
          transformPastedHTML: (o) => {
            var s, l, m;
            if (t = !1, new TextEncoder().encode(o).length > (((s = e.limits) == null ? void 0 : s.bytes) ?? Et.bytes))
              return t = !0, (l = e.issue) == null || l.call(e, "粘贴内容超过文档资源限制，未插入"), "";
            const i = Qs(o);
            return i.dropped && ((m = e.issue) == null || m.call(e, "已略去不支持的图片或非文字内容")), i.html;
          },
          handlePaste: (o, i) => {
            var s, l;
            return t ? (t = !1, !0) : (s = i.clipboardData) != null && s.files.length ? ((l = e.issue) == null || l.call(e, "备注不支持图片或附件"), !0) : !1;
          },
          handleDrop: (o, i) => {
            var s, l;
            return (s = i.dataTransfer) != null && s.files.length ? ((l = e.issue) == null || l.call(e, "备注不支持图片或附件"), !0) : !1;
          }
        }
      })
    ];
  }
}), tr = {
  "history.undo": "撤销",
  "history.redo": "重做",
  "style.block": "段落样式",
  "font.family": "字体",
  "font.size": "字号",
  "format.bold": "加粗",
  "format.italic": "斜体",
  "format.underline": "下划线",
  "format.strike": "删除线",
  "text.color": "文字颜色",
  "highlight.color": "底纹颜色",
  "list.bullet": "无序列表",
  "list.ordered": "有序列表",
  "list.task": "任务列表",
  "align.left": "左对齐",
  "align.center": "居中",
  "align.right": "右对齐",
  "align.justify": "两端对齐",
  "block.blockquote": "引用",
  "block.code": "代码块",
  "insert.horizontal-rule": "分割线",
  "insert.link": "链接",
  "insert.image": "图片",
  "insert.video": "视频",
  "insert.iframe": "嵌入网页",
  "table.menu": "表格",
  "ai.ask": "AI",
  "option:ai-custom": "自定义指令…",
  "option:paragraph": "正文",
  "option:heading-1": "标题 1",
  "option:heading-2": "标题 2",
  "option:heading-3": "标题 3",
  "option:heading-4": "标题 4",
  "option:heading-5": "标题 5",
  "option:heading-6": "标题 6",
  "option:bullet-list": "无序列表",
  "option:ordered-list": "有序列表",
  "option:task-list": "任务列表",
  "option:blockquote": "引用",
  "option:code-block": "代码块",
  "option:text-red": "红色",
  "option:text-orange": "橙色",
  "option:text-green": "绿色",
  "option:text-blue": "蓝色",
  "option:text-purple": "紫色",
  "option:text-gray": "灰色",
  "panel:default": "默认",
  "panel:clear-color": "清除颜色",
  "panel:custom": "自定义",
  "panel:more": "更多工具",
  "link:invalid": "请输入有效的链接地址（如 https://example.com）",
  "link:address": "链接地址",
  "link:apply": "应用链接",
  "link:cancel": "取消链接编辑",
  "link:copy": "复制链接",
  "link:edit": "编辑链接",
  "link:remove": "移除链接",
  "slash-group:recent": "最近使用",
  "slash-group:ai": "AI",
  "slash:ai.ask": "AI 帮写",
  "slash:ai.ask:description": "按你的要求撰写或修改",
  "slash-group:basic": "基础块",
  "slash-group:media": "媒体",
  "slash-group:advanced": "高级",
  "slash:heading-1": "一级标题",
  "slash:heading-1:description": "大号章节标题",
  "slash:heading-2": "二级标题",
  "slash:heading-2:description": "中号章节标题",
  "slash:heading-3": "三级标题",
  "slash:heading-3:description": "小号章节标题",
  "slash:heading-4": "四级标题",
  "slash:heading-4:description": "最小章节标题",
  "slash:bullet-list": "无序列表",
  "slash:bullet-list:description": "用圆点列出要点",
  "slash:ordered-list": "有序列表",
  "slash:ordered-list:description": "按 1、2、3 编号",
  "slash:task-list": "任务列表",
  "slash:task-list:description": "带复选框的清单",
  "slash:toggle-list": "折叠块",
  "slash:toggle-list:description": "可展开收起的内容",
  "slash:blockquote": "引用",
  "slash:blockquote:description": "引用一段文字",
  "slash:horizontal-rule": "分割线",
  "slash:horizontal-rule:description": "插入一条分隔线",
  "slash:image": "图片",
  "slash:image:description": "上传或嵌入图片",
  "slash:video": "视频",
  "slash:video:description": "上传或嵌入视频",
  "slash:code-block": "代码块",
  "slash:code-block:description": "带高亮的代码片段",
  "slash:link": "链接",
  "slash:link:description": "插入网页链接",
  "slash:table": "表格",
  "slash:table:description": "插入 3×3 表格",
  "slash:embed": "嵌入网页",
  "slash:embed:description": "嵌入外部页面",
  "slash:align-left": "左对齐",
  "slash:align-left:description": "段落左对齐",
  "slash:align-center": "居中",
  "slash:align-center:description": "段落居中",
  "slash:align-right": "右对齐",
  "slash:align-right:description": "段落右对齐",
  "slash:align-justify": "两端对齐",
  "slash:align-justify:description": "段落两端对齐"
}, Gn = () => {
  const { lang: e } = Xo(), t = R(() => e.value.toLowerCase().startsWith("zh"));
  return { text: (a, o) => t.value && a && tr[a] || o };
}, nr = ["href", "title"], ar = /* @__PURE__ */ ke({
  name: "ZxTextEditorLinkPopup",
  __name: "link-popup",
  props: {
    href: {}
  },
  emits: ["updateHref", "close"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = xe("text-editor-link-popup"), { text: i } = Gn(), s = S(null), l = (w) => {
      s.value = w;
    }, m = S(n.href), c = S(n.href === ""), u = S(!1), j = R(() => !u.value || m.value === "" ? !1 : !Kt(m.value)), f = R(() => m.value ? i(
      "link:invalid",
      "Please enter a valid URL (e.g., https://example.com)"
    ) : ""), g = () => {
      u.value = !0;
    }, h = () => {
      u.value = !0, (m.value === "" || Kt(m.value)) && a("updateHref", m.value);
    }, p = () => {
      n.href ? (c.value = !1, m.value = n.href, u.value = !1) : a("updateHref", "");
    }, x = async () => {
      var w, C;
      c.value = !0, u.value = !1, await Ae(), (C = (w = s.value) == null ? void 0 : w.focus) == null || C.call(w);
    }, v = async () => {
      m.value && await navigator.clipboard.writeText(m.value);
    };
    return Fe(async () => {
      var w, C;
      await Ae(), (C = (w = s.value) == null ? void 0 : w.focus) == null || C.call(w);
    }), (w, C) => (L(), A("div", {
      class: d(r(o).b())
    }, [
      b("div", {
        class: d(r(o).e("input-wrapper"))
      }, [
        c.value ? (L(), Ce(r(Yo), {
          key: 0,
          ref: l,
          modelValue: m.value,
          "onUpdate:modelValue": C[0] || (C[0] = (k) => m.value = k),
          class: d([r(o).e("input"), { "is-error": j.value }]),
          "aria-label": r(i)("link:address", "Link address"),
          placeholder: "https://example.com",
          onKeydown: [
            $e(h, ["enter"]),
            C[1] || (C[1] = $e((k) => a("close"), ["esc"]))
          ],
          onInput: g
        }, null, 8, ["modelValue", "class", "aria-label"])) : (L(), A("a", {
          key: 1,
          class: d(r(o).e("link")),
          href: m.value,
          title: m.value,
          target: "_blank",
          rel: "noopener noreferrer"
        }, Q(m.value), 11, nr)),
        j.value ? (L(), A("div", {
          key: 2,
          class: d(r(o).e("error"))
        }, Q(f.value), 3)) : V("", !0)
      ], 2),
      b("div", {
        class: d(r(o).e("actions"))
      }, [
        c.value ? (L(), A(ve, { key: 0 }, [
          B(r(We), {
            icon: "lucide:check",
            size: "small",
            text: "",
            "aria-label": r(i)("link:apply", "Apply link"),
            disabled: j.value && m.value !== "",
            onClick: h
          }, null, 8, ["aria-label", "disabled"]),
          B(r(We), {
            icon: "lucide:x",
            size: "small",
            text: "",
            "aria-label": r(i)("link:cancel", "Cancel link editing"),
            onClick: p
          }, null, 8, ["aria-label"])
        ], 64)) : (L(), A(ve, { key: 1 }, [
          B(r(We), {
            icon: "lucide:copy",
            size: "small",
            text: "",
            "aria-label": r(i)("link:copy", "Copy link"),
            onClick: v
          }, null, 8, ["aria-label"]),
          B(r(We), {
            icon: "lucide:pencil",
            size: "small",
            text: "",
            "aria-label": r(i)("link:edit", "Edit link"),
            onClick: x
          }, null, 8, ["aria-label"]),
          B(r(We), {
            icon: "lucide:link-2-off",
            size: "small",
            text: "",
            "aria-label": r(i)("link:remove", "Remove link"),
            onClick: C[2] || (C[2] = (k) => a("updateHref", ""))
          }, null, 8, ["aria-label"])
        ], 64))
      ], 2)
    ], 2));
  }
});
function or(e, t, n) {
  const {
    placement: a = "bottom-start",
    appendTo: o,
    interactive: i = !0,
    onClickOutside: s
  } = n, l = typeof o == "function" ? o() : o, m = l.ownerDocument, c = m.defaultView ?? globalThis, u = m.createElement("div");
  u.style.position = "absolute", u.style.zIndex = "9999", u.style.left = "0", u.style.top = "0", u.appendChild(e), l.appendChild(u);
  let j = t, f = null, g = null;
  const h = {
    getBoundingClientRect: () => j()
  }, p = async () => {
    const { x: y, y: Z } = await ti(h, u, {
      placement: a,
      middleware: [Hn(4), Dn(), wi(4)]
    });
    Object.assign(u.style, {
      left: `${y}px`,
      top: `${Z}px`
    });
  }, x = (y) => {
    u.contains(y.target) || s == null || s();
  }, v = () => {
    if (u.style.display = "block", p(), f = ei(h, u, p, {
      animationFrame: !0
    }), i && s) {
      const y = c.setTimeout(() => {
        g = null, m.addEventListener("mousedown", x);
      }, 0);
      g = () => c.clearTimeout(y);
    }
  }, w = () => {
    u.style.display = "none", f == null || f(), f = null, g == null || g(), g = null, m.removeEventListener("mousedown", x);
  }, C = () => {
    w(), u.remove();
  }, k = (y) => {
    y.getReferenceClientRect && (j = y.getReferenceClientRect, p());
  };
  return v(), {
    show: v,
    hide: w,
    destroy: C,
    setProps: k,
    element: u
  };
}
const ut = /* @__PURE__ */ new WeakMap(), ir = Ko.extend({
  addOptions() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      openOnClick: !1,
      autolink: !0,
      defaultProtocol: "https",
      linkOnPaste: !1,
      themeOwner: null
    };
  },
  addCommands() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      openLinkEditor: () => ({ editor: t }) => {
        var C;
        if (t.isDestroyed || !t.isEditable) return !1;
        const { state: n } = t, { from: a, to: o } = n.selection, { doc: i } = n;
        let s, l, m = !1, c = null;
        if (a === o) {
          const k = n.selection.$from, y = fa(k, this.type);
          if (y) {
            s = y;
            const Z = i.nodeAt(k.pos);
            Z && (l = Z.marks.find((q) => q.type === this.type)), t.chain().setTextSelection({ from: y.from, to: y.to }).run(), m = !0;
          } else
            c = a;
        } else
          s = { from: a, to: o }, l = i.resolve(a).marks().find((k) => k.type === this.type);
        if (!s && c === null) return !1;
        const u = (l == null ? void 0 : l.attrs.href) || "", j = (s == null ? void 0 : s.from) ?? a, f = (s == null ? void 0 : s.to) ?? o;
        (C = ut.get(t)) == null || C.abort();
        const g = new AbortController();
        ut.set(t, g);
        const h = () => g.abort(), p = ({
          transaction: k
        }) => {
          (k.docChanged || !t.isEditable) && h();
        }, x = () => {
          (t.isDestroyed || !t.isEditable) && h();
        }, v = () => {
          t.off("transaction", p), t.off("update", x), t.off("destroy", h), g.signal.removeEventListener("abort", v), ut.get(t) === g && ut.delete(t);
        };
        t.on("transaction", p), t.on("update", x), t.on("destroy", h), g.signal.addEventListener("abort", v, { once: !0 });
        const w = () => {
          g.signal.aborted || sr(
            this.options.themeOwner,
            u,
            t.view.dom,
            g.signal
          ).then((k) => {
            if (g.signal.aborted || t.isDestroyed || !t.isEditable)
              return;
            v();
            const y = Pa(k);
            let Z = t.chain().focus(null, { scrollIntoView: !1 });
            if (c !== null) {
              y && Z.insertContentAt(c, {
                type: "text",
                text: y,
                marks: [{ type: this.name, attrs: { href: y } }]
              }).command(({ tr: q }) => (q.setStoredMarks([]), !0)).run();
              return;
            }
            if (y === "") {
              Z.setTextSelection({ from: j, to: f }).unsetLink().command(({ tr: q }) => (q.setStoredMarks([]), !0)).run();
              return;
            }
            Z = Z.setTextSelection({ from: j, to: f }).setLink({ href: y }).setTextSelection(f).command(({ tr: q }) => (q.setStoredMarks([]), !0)), Z.run();
          }).catch(() => {
          }).finally(v);
        };
        return m ? requestAnimationFrame(w) : w(), !0;
      }
    };
  },
  addProseMirrorPlugins() {
    var t;
    const e = ((t = this.parent) == null ? void 0 : t.call(this)) || [];
    return e.push(
      Aa({
        editor: this.editor,
        defaultProtocol: this.options.defaultProtocol,
        type: this.type
      }),
      rr({
        editor: this.editor,
        type: this.type
      }),
      new Ne({
        props: {
          handleClick: (n, a, o) => {
            var i;
            if (this.editor.isEditable) {
              if (!this.editor.isActive("link")) return !1;
              if (o.preventDefault(), o.metaKey) {
                const s = (i = o.target) == null ? void 0 : i.getAttribute("href");
                s && window.open(s, "_blank");
              } else
                vt(this.editor).openLinkEditor();
            }
          }
        }
      })
    ), e;
  }
});
async function sr(e, t, n, a) {
  var s;
  if (!e) throw new Error("EDITOR_THEME_OWNER_REQUIRED");
  if (a.aborted) throw new Error("Link editing cancelled");
  const o = await e.acquirePortal();
  if (!o.ok) throw new Error((s = o.diagnostics[0]) == null ? void 0 : s.code);
  const i = o.value;
  if (a.aborted)
    throw i.release(), new Error("Link editing cancelled");
  return new Promise((l, m) => {
    const c = i.target.ownerDocument.createElement("div");
    let u;
    const j = i.target.ownerDocument.defaultView, f = j == null ? void 0 : j.getSelection(), g = (j == null ? void 0 : j.requestAnimationFrame.bind(j)) ?? ((k) => (queueMicrotask(() => k(0)), 0));
    if (f && f.rangeCount > 0) {
      const k = f.getRangeAt(0), y = k.getBoundingClientRect(), Z = k.collapsed;
      u = () => ({
        width: 0,
        height: y.height,
        top: y.top,
        right: Z ? y.left : y.right,
        bottom: y.bottom,
        left: y.left,
        x: y.left,
        y: y.top,
        toJSON: () => ({})
      });
    } else
      u = () => n.getBoundingClientRect();
    let h = null, p = !1, x = !1;
    const v = (k, y) => {
      x || (x = !0, k === "resolve" ? l(y) : m(y));
    }, w = () => {
      p || (p = !0, a.removeEventListener("abort", w), v("reject", "Link editing cancelled or destroyed"), g(() => {
        h == null || h.destroy(), Ye(null, c), c == null || c.remove(), h = null, i.release();
      }));
    }, C = Rt(ar, {
      href: t,
      onClose: () => {
        v("reject", "Link editing cancelled"), w();
      },
      onUpdateHref: (k) => {
        v("resolve", k), w();
      }
    });
    C.appContext = i.appContext, a.addEventListener("abort", w, { once: !0 });
    try {
      Ye(C, c), h = or(c, u, {
        placement: "top",
        appendTo: i.target,
        interactive: !0,
        onClickOutside: w
      });
    } catch (k) {
      v("reject", k), w();
    }
  });
}
function rr(e) {
  return new Ne({
    key: new Me("clearLinkMarkOnBoundary"),
    appendTransaction: (t, n, a) => {
      if (!e.editor.isEditable)
        return null;
      const { tr: o, doc: i, selection: s, storedMarks: l } = a, { $from: m, empty: c } = s;
      if (!c || !l || l.length === 0)
        return null;
      const u = e.type;
      return !l.some(
        (h) => h.type === u
      ) || m.marks().some(
        (h) => h.type === u
      ) ? null : o.setStoredMarks([]);
    }
  });
}
const lr = /* @__PURE__ */ ke({
  __name: "EmojiList",
  props: {
    items: {
      type: Array,
      required: !0
    },
    editor: {
      type: Object,
      required: !0
    },
    range: {
      type: Object,
      required: !0
    },
    command: {
      type: Function,
      required: !0
    },
    loading: {
      type: Boolean,
      default: !1
    }
  },
  setup(e, { expose: t }) {
    const n = e, a = xe("text-editor-suggestion"), o = S(null), i = (m) => {
      m && n.command(m);
    }, s = (m) => {
      i(m);
    };
    return t({
      onKeyDown: ({ event: m }) => {
        var c;
        return ((c = o.value) == null ? void 0 : c.onKeyDown({ event: m })) ?? !1;
      }
    }), (m, c) => (L(), Ce($t, {
      ref_key: "suggestionList",
      ref: o,
      items: e.items,
      command: s,
      loading: e.loading
    }, {
      default: je(({ item: u }) => [
        b("span", {
          class: d(r(a).e("item-icon"))
        }, Q(u.emoji), 3),
        b("span", null, Q(u.name), 1)
      ]),
      _: 1
    }, 8, ["items", "loading"]));
  }
}), mr = /* @__PURE__ */ JSON.parse('[{"name":"grinning","emoji":"😀"},{"name":"grimacing","emoji":"😬"},{"name":"grin","emoji":"😁"},{"name":"joy","emoji":"😂"},{"name":"rofl","emoji":"🤣"},{"name":"smiley","emoji":"😃"},{"name":"smile","emoji":"😄"},{"name":"sweat_smile","emoji":"😅"},{"name":"laughing","emoji":"😆"},{"name":"innocent","emoji":"😇"},{"name":"wink","emoji":"😉"},{"name":"blush","emoji":"😊"},{"name":"slightly_smiling_face","emoji":"🙂"},{"name":"upside_down_face","emoji":"🙃"},{"name":"relaxed","emoji":"☺"},{"name":"yum","emoji":"😋"},{"name":"relieved","emoji":"😌"},{"name":"heart_eyes","emoji":"😍"},{"name":"kissing_heart","emoji":"😘"},{"name":"kissing","emoji":"😗"},{"name":"kissing_smiling_eyes","emoji":"😙"},{"name":"kissing_closed_eyes","emoji":"😚"},{"name":"stuck_out_tongue_winking_eye","emoji":"😜"},{"name":"stuck_out_tongue_closed_eyes","emoji":"😝"},{"name":"stuck_out_tongue","emoji":"😛"},{"name":"money_mouth_face","emoji":"🤑"},{"name":"nerd_face","emoji":"🤓"},{"name":"sunglasses","emoji":"😎"},{"name":"clown_face","emoji":"🤡"},{"name":"cowboy_hat_face","emoji":"🤠"},{"name":"hugs","emoji":"🤗"},{"name":"smirk","emoji":"😏"},{"name":"no_mouth","emoji":"😶"},{"name":"neutral_face","emoji":"😐"},{"name":"expressionless","emoji":"😑"},{"name":"unamused","emoji":"😒"},{"name":"roll_eyes","emoji":"🙄"},{"name":"thinking","emoji":"🤔"},{"name":"lying_face","emoji":"🤥"},{"name":"flushed","emoji":"😳"},{"name":"disappointed","emoji":"😞"},{"name":"worried","emoji":"😟"},{"name":"angry","emoji":"😠"},{"name":"rage","emoji":"😡"},{"name":"pensive","emoji":"😔"},{"name":"confused","emoji":"😕"},{"name":"slightly_frowning_face","emoji":"🙁"},{"name":"frowning_face","emoji":"☹"},{"name":"persevere","emoji":"😣"},{"name":"confounded","emoji":"😖"},{"name":"tired_face","emoji":"😫"},{"name":"weary","emoji":"😩"},{"name":"triumph","emoji":"😤"},{"name":"open_mouth","emoji":"😮"},{"name":"scream","emoji":"😱"},{"name":"fearful","emoji":"😨"},{"name":"cold_sweat","emoji":"😰"},{"name":"hushed","emoji":"😯"},{"name":"frowning_with_open_mouth","emoji":"😦"},{"name":"anguished","emoji":"😧"},{"name":"cry","emoji":"😢"},{"name":"disappointed_relieved","emoji":"😥"},{"name":"drooling_face","emoji":"🤤"},{"name":"sleepy","emoji":"😪"},{"name":"sweat","emoji":"😓"},{"name":"sob","emoji":"😭"},{"name":"dizzy_face","emoji":"😵"},{"name":"astonished","emoji":"😲"},{"name":"zipper_mouth_face","emoji":"🤐"},{"name":"nauseated_face","emoji":"🤢"},{"name":"sneezing_face","emoji":"🤧"},{"name":"mask","emoji":"😷"},{"name":"face_with_thermometer","emoji":"🤒"},{"name":"face_with_head_bandage","emoji":"🤕"},{"name":"sleeping","emoji":"😴"},{"name":"zzz","emoji":"💤"},{"name":"poop","emoji":"💩"},{"name":"smiling_imp","emoji":"😈"},{"name":"imp","emoji":"👿"},{"name":"japanese_ogre","emoji":"👹"},{"name":"japanese_goblin","emoji":"👺"},{"name":"skull","emoji":"💀"},{"name":"ghost","emoji":"👻"},{"name":"alien","emoji":"👽"},{"name":"robot","emoji":"🤖"},{"name":"smiley_cat","emoji":"😺"},{"name":"smile_cat","emoji":"😸"},{"name":"joy_cat","emoji":"😹"},{"name":"heart_eyes_cat","emoji":"😻"},{"name":"smirk_cat","emoji":"😼"},{"name":"kissing_cat","emoji":"😽"},{"name":"scream_cat","emoji":"🙀"},{"name":"crying_cat_face","emoji":"😿"},{"name":"pouting_cat","emoji":"😾"},{"name":"raised_hands","emoji":"🙌"},{"name":"clap","emoji":"👏"},{"name":"wave","emoji":"👋"},{"name":"call_me_hand","emoji":"🤙"},{"name":"+1","emoji":"👍"},{"name":"-1","emoji":"👎"},{"name":"facepunch","emoji":"👊"},{"name":"fist","emoji":"✊"},{"name":"fist_left","emoji":"🤛"},{"name":"fist_right","emoji":"🤜"},{"name":"v","emoji":"✌"},{"name":"ok_hand","emoji":"👌"},{"name":"raised_hand","emoji":"✋"},{"name":"raised_back_of_hand","emoji":"🤚"},{"name":"open_hands","emoji":"👐"},{"name":"muscle","emoji":"💪"},{"name":"pray","emoji":"🙏"},{"name":"handshake","emoji":"🤝"},{"name":"point_up","emoji":"☝"},{"name":"point_up_2","emoji":"👆"},{"name":"point_down","emoji":"👇"},{"name":"point_left","emoji":"👈"},{"name":"point_right","emoji":"👉"},{"name":"fu","emoji":"🖕"},{"name":"raised_hand_with_fingers_splayed","emoji":"🖐"},{"name":"metal","emoji":"🤘"},{"name":"crossed_fingers","emoji":"🤞"},{"name":"vulcan_salute","emoji":"🖖"},{"name":"writing_hand","emoji":"✍"},{"name":"selfie","emoji":"🤳"},{"name":"nail_care","emoji":"💅"},{"name":"lips","emoji":"👄"},{"name":"tongue","emoji":"👅"},{"name":"ear","emoji":"👂"},{"name":"nose","emoji":"👃"},{"name":"eye","emoji":"👁"},{"name":"eyes","emoji":"👀"},{"name":"bust_in_silhouette","emoji":"👤"},{"name":"busts_in_silhouette","emoji":"👥"},{"name":"speaking_head","emoji":"🗣"},{"name":"baby","emoji":"👶"},{"name":"boy","emoji":"👦"},{"name":"girl","emoji":"👧"},{"name":"man","emoji":"👨"},{"name":"woman","emoji":"👩"},{"name":"blonde_woman","emoji":"👱‍♀️"},{"name":"blonde_man","emoji":"👱"},{"name":"older_man","emoji":"👴"},{"name":"older_woman","emoji":"👵"},{"name":"man_with_gua_pi_mao","emoji":"👲"},{"name":"woman_with_turban","emoji":"👳‍♀️"},{"name":"man_with_turban","emoji":"👳"},{"name":"policewoman","emoji":"👮‍♀️"},{"name":"policeman","emoji":"👮"},{"name":"construction_worker_woman","emoji":"👷‍♀️"},{"name":"construction_worker_man","emoji":"👷"},{"name":"guardswoman","emoji":"💂‍♀️"},{"name":"guardsman","emoji":"💂"},{"name":"female_detective","emoji":"🕵️‍♀"},{"name":"male_detective","emoji":"🕵"},{"name":"woman_health_worker","emoji":"👩‍⚕️"},{"name":"man_health_worker","emoji":"👨‍⚕️"},{"name":"woman_farmer","emoji":"👩‍🌾"},{"name":"man_farmer","emoji":"👨‍🌾"},{"name":"woman_cook","emoji":"👩‍🍳"},{"name":"man_cook","emoji":"👨‍🍳"},{"name":"woman_student","emoji":"👩‍🎓"},{"name":"man_student","emoji":"👨‍🎓"},{"name":"woman_singer","emoji":"👩‍🎤"},{"name":"man_singer","emoji":"👨‍🎤"},{"name":"woman_teacher","emoji":"👩‍🏫"},{"name":"man_teacher","emoji":"👨‍🏫"},{"name":"woman_factory_worker","emoji":"👩‍🏭"},{"name":"man_factory_worker","emoji":"👨‍🏭"},{"name":"woman_technologist","emoji":"👩‍💻"},{"name":"man_technologist","emoji":"👨‍💻"},{"name":"woman_office_worker","emoji":"👩‍💼"},{"name":"man_office_worker","emoji":"👨‍💼"},{"name":"woman_mechanic","emoji":"👩‍🔧"},{"name":"man_mechanic","emoji":"👨‍🔧"},{"name":"woman_scientist","emoji":"👩‍🔬"},{"name":"man_scientist","emoji":"👨‍🔬"},{"name":"woman_artist","emoji":"👩‍🎨"},{"name":"man_artist","emoji":"👨‍🎨"},{"name":"woman_firefighter","emoji":"👩‍🚒"},{"name":"man_firefighter","emoji":"👨‍🚒"},{"name":"woman_pilot","emoji":"👩‍✈️"},{"name":"man_pilot","emoji":"👨‍✈️"},{"name":"woman_astronaut","emoji":"👩‍🚀"},{"name":"man_astronaut","emoji":"👨‍🚀"},{"name":"woman_judge","emoji":"👩‍⚖️"},{"name":"man_judge","emoji":"👨‍⚖️"},{"name":"mrs_claus","emoji":"🤶"},{"name":"santa","emoji":"🎅"},{"name":"angel","emoji":"👼"},{"name":"pregnant_woman","emoji":"🤰"},{"name":"princess","emoji":"👸"},{"name":"prince","emoji":"🤴"},{"name":"bride_with_veil","emoji":"👰"},{"name":"person_in_tuxedo","emoji":"🤵"},{"name":"running_woman","emoji":"🏃‍♀️"},{"name":"running_man","emoji":"🏃"},{"name":"walking_woman","emoji":"🚶‍♀️"},{"name":"walking_man","emoji":"🚶"},{"name":"dancer","emoji":"💃"},{"name":"man_dancing","emoji":"🕺"},{"name":"dancing_women","emoji":"👯"},{"name":"dancing_men","emoji":"👯‍♂"},{"name":"couple","emoji":"👫"},{"name":"two_men_holding_hands","emoji":"👬"},{"name":"two_women_holding_hands","emoji":"👭"},{"name":"bowing_woman","emoji":"🙇‍♀️"},{"name":"bowing_man","emoji":"🙇"},{"name":"man_facepalming","emoji":"🤦‍♂️"},{"name":"woman_facepalming","emoji":"🤦‍♀️"},{"name":"woman_shrugging","emoji":"🤷‍♀️"},{"name":"man_shrugging","emoji":"🤷‍♂️"},{"name":"tipping_hand_woman","emoji":"💁‍♀️"},{"name":"tipping_hand_man","emoji":"💁‍♂️"},{"name":"no_good_woman","emoji":"🙅‍♀️"},{"name":"no_good_man","emoji":"🙅‍♂️"},{"name":"ok_woman","emoji":"🙆‍♀️"},{"name":"ok_man","emoji":"🙆‍♂️"},{"name":"raising_hand_woman","emoji":"🙋‍♀️"},{"name":"raising_hand_man","emoji":"🙋‍♂️"},{"name":"pouting_woman","emoji":"🙎‍♀️"},{"name":"pouting_man","emoji":"🙎‍♂️"},{"name":"frowning_woman","emoji":"🙍‍♀️"},{"name":"frowning_man","emoji":"🙍‍♂️"},{"name":"haircut_woman","emoji":"💇‍♀️"},{"name":"haircut_man","emoji":"💇‍♂️"},{"name":"massage_woman","emoji":"💆‍♀️"},{"name":"massage_man","emoji":"💆‍♂️"},{"name":"couple_with_heart","emoji":"💑"},{"name":"couple_with_heart_woman_woman","emoji":"👩‍❤️‍👩"},{"name":"couple_with_heart_man_man","emoji":"👨‍❤️‍👨"},{"name":"couplekiss_man_woman","emoji":"💏"},{"name":"couplekiss_woman_woman","emoji":"👩‍❤️‍💋‍👩"},{"name":"couplekiss_man_man","emoji":"👨‍❤️‍💋‍👨"},{"name":"family","emoji":"👪"},{"name":"family_man_woman_girl","emoji":"👨‍👩‍👧"},{"name":"family_man_woman_girl_boy","emoji":"👨‍👩‍👧‍👦"},{"name":"family_man_woman_boy_boy","emoji":"👨‍👩‍👦‍👦"},{"name":"family_man_woman_girl_girl","emoji":"👨‍👩‍👧‍👧"},{"name":"family_woman_woman_boy","emoji":"👩‍👩‍👦"},{"name":"family_woman_woman_girl","emoji":"👩‍👩‍👧"},{"name":"family_woman_woman_girl_boy","emoji":"👩‍👩‍👧‍👦"},{"name":"family_woman_woman_boy_boy","emoji":"👩‍👩‍👦‍👦"},{"name":"family_woman_woman_girl_girl","emoji":"👩‍👩‍👧‍👧"},{"name":"family_man_man_boy","emoji":"👨‍👨‍👦"},{"name":"family_man_man_girl","emoji":"👨‍👨‍👧"},{"name":"family_man_man_girl_boy","emoji":"👨‍👨‍👧‍👦"},{"name":"family_man_man_boy_boy","emoji":"👨‍👨‍👦‍👦"},{"name":"family_man_man_girl_girl","emoji":"👨‍👨‍👧‍👧"},{"name":"family_woman_boy","emoji":"👩‍👦"},{"name":"family_woman_girl","emoji":"👩‍👧"},{"name":"family_woman_girl_boy","emoji":"👩‍👧‍👦"},{"name":"family_woman_boy_boy","emoji":"👩‍👦‍👦"},{"name":"family_woman_girl_girl","emoji":"👩‍👧‍👧"},{"name":"family_man_boy","emoji":"👨‍👦"},{"name":"family_man_girl","emoji":"👨‍👧"},{"name":"family_man_girl_boy","emoji":"👨‍👧‍👦"},{"name":"family_man_boy_boy","emoji":"👨‍👦‍👦"},{"name":"family_man_girl_girl","emoji":"👨‍👧‍👧"},{"name":"womans_clothes","emoji":"👚"},{"name":"tshirt","emoji":"👕"},{"name":"jeans","emoji":"👖"},{"name":"necktie","emoji":"👔"},{"name":"dress","emoji":"👗"},{"name":"bikini","emoji":"👙"},{"name":"kimono","emoji":"👘"},{"name":"lipstick","emoji":"💄"},{"name":"kiss","emoji":"💋"},{"name":"footprints","emoji":"👣"},{"name":"high_heel","emoji":"👠"},{"name":"sandal","emoji":"👡"},{"name":"boot","emoji":"👢"},{"name":"mans_shoe","emoji":"👞"},{"name":"athletic_shoe","emoji":"👟"},{"name":"womans_hat","emoji":"👒"},{"name":"tophat","emoji":"🎩"},{"name":"rescue_worker_helmet","emoji":"⛑"},{"name":"mortar_board","emoji":"🎓"},{"name":"crown","emoji":"👑"},{"name":"school_satchel","emoji":"🎒"},{"name":"pouch","emoji":"👝"},{"name":"purse","emoji":"👛"},{"name":"handbag","emoji":"👜"},{"name":"briefcase","emoji":"💼"},{"name":"eyeglasses","emoji":"👓"},{"name":"dark_sunglasses","emoji":"🕶"},{"name":"ring","emoji":"💍"},{"name":"closed_umbrella","emoji":"🌂"},{"name":"dog","emoji":"🐶"},{"name":"cat","emoji":"🐱"},{"name":"mouse","emoji":"🐭"},{"name":"hamster","emoji":"🐹"},{"name":"rabbit","emoji":"🐰"},{"name":"fox_face","emoji":"🦊"},{"name":"bear","emoji":"🐻"},{"name":"panda_face","emoji":"🐼"},{"name":"koala","emoji":"🐨"},{"name":"tiger","emoji":"🐯"},{"name":"lion","emoji":"🦁"},{"name":"cow","emoji":"🐮"},{"name":"pig","emoji":"🐷"},{"name":"pig_nose","emoji":"🐽"},{"name":"frog","emoji":"🐸"},{"name":"squid","emoji":"🦑"},{"name":"octopus","emoji":"🐙"},{"name":"shrimp","emoji":"🦐"},{"name":"monkey_face","emoji":"🐵"},{"name":"gorilla","emoji":"🦍"},{"name":"see_no_evil","emoji":"🙈"},{"name":"hear_no_evil","emoji":"🙉"},{"name":"speak_no_evil","emoji":"🙊"},{"name":"monkey","emoji":"🐒"},{"name":"chicken","emoji":"🐔"},{"name":"penguin","emoji":"🐧"},{"name":"bird","emoji":"🐦"},{"name":"baby_chick","emoji":"🐤"},{"name":"hatching_chick","emoji":"🐣"},{"name":"hatched_chick","emoji":"🐥"},{"name":"duck","emoji":"🦆"},{"name":"eagle","emoji":"🦅"},{"name":"owl","emoji":"🦉"},{"name":"bat","emoji":"🦇"},{"name":"wolf","emoji":"🐺"},{"name":"boar","emoji":"🐗"},{"name":"horse","emoji":"🐴"},{"name":"unicorn","emoji":"🦄"},{"name":"honeybee","emoji":"🐝"},{"name":"bug","emoji":"🐛"},{"name":"butterfly","emoji":"🦋"},{"name":"snail","emoji":"🐌"},{"name":"lady_beetle","emoji":"🐞"},{"name":"ant","emoji":"🐜"},{"name":"spider","emoji":"🕷"},{"name":"scorpion","emoji":"🦂"},{"name":"crab","emoji":"🦀"},{"name":"snake","emoji":"🐍"},{"name":"lizard","emoji":"🦎"},{"name":"turtle","emoji":"🐢"},{"name":"tropical_fish","emoji":"🐠"},{"name":"fish","emoji":"🐟"},{"name":"blowfish","emoji":"🐡"},{"name":"dolphin","emoji":"🐬"},{"name":"shark","emoji":"🦈"},{"name":"whale","emoji":"🐳"},{"name":"whale2","emoji":"🐋"},{"name":"crocodile","emoji":"🐊"},{"name":"leopard","emoji":"🐆"},{"name":"tiger2","emoji":"🐅"},{"name":"water_buffalo","emoji":"🐃"},{"name":"ox","emoji":"🐂"},{"name":"cow2","emoji":"🐄"},{"name":"deer","emoji":"🦌"},{"name":"dromedary_camel","emoji":"🐪"},{"name":"camel","emoji":"🐫"},{"name":"elephant","emoji":"🐘"},{"name":"rhinoceros","emoji":"🦏"},{"name":"goat","emoji":"🐐"},{"name":"ram","emoji":"🐏"},{"name":"sheep","emoji":"🐑"},{"name":"racehorse","emoji":"🐎"},{"name":"pig2","emoji":"🐖"},{"name":"rat","emoji":"🐀"},{"name":"mouse2","emoji":"🐁"},{"name":"rooster","emoji":"🐓"},{"name":"turkey","emoji":"🦃"},{"name":"dove","emoji":"🕊"},{"name":"dog2","emoji":"🐕"},{"name":"poodle","emoji":"🐩"},{"name":"cat2","emoji":"🐈"},{"name":"rabbit2","emoji":"🐇"},{"name":"chipmunk","emoji":"🐿"},{"name":"paw_prints","emoji":"🐾"},{"name":"dragon","emoji":"🐉"},{"name":"dragon_face","emoji":"🐲"},{"name":"cactus","emoji":"🌵"},{"name":"christmas_tree","emoji":"🎄"},{"name":"evergreen_tree","emoji":"🌲"},{"name":"deciduous_tree","emoji":"🌳"},{"name":"palm_tree","emoji":"🌴"},{"name":"seedling","emoji":"🌱"},{"name":"herb","emoji":"🌿"},{"name":"shamrock","emoji":"☘"},{"name":"four_leaf_clover","emoji":"🍀"},{"name":"bamboo","emoji":"🎍"},{"name":"tanabata_tree","emoji":"🎋"},{"name":"leaves","emoji":"🍃"},{"name":"fallen_leaf","emoji":"🍂"},{"name":"maple_leaf","emoji":"🍁"},{"name":"ear_of_rice","emoji":"🌾"},{"name":"hibiscus","emoji":"🌺"},{"name":"sunflower","emoji":"🌻"},{"name":"rose","emoji":"🌹"},{"name":"wilted_flower","emoji":"🥀"},{"name":"tulip","emoji":"🌷"},{"name":"blossom","emoji":"🌼"},{"name":"cherry_blossom","emoji":"🌸"},{"name":"bouquet","emoji":"💐"},{"name":"mushroom","emoji":"🍄"},{"name":"chestnut","emoji":"🌰"},{"name":"jack_o_lantern","emoji":"🎃"},{"name":"shell","emoji":"🐚"},{"name":"spider_web","emoji":"🕸"},{"name":"earth_americas","emoji":"🌎"},{"name":"earth_africa","emoji":"🌍"},{"name":"earth_asia","emoji":"🌏"},{"name":"full_moon","emoji":"🌕"},{"name":"waning_gibbous_moon","emoji":"🌖"},{"name":"last_quarter_moon","emoji":"🌗"},{"name":"waning_crescent_moon","emoji":"🌘"},{"name":"new_moon","emoji":"🌑"},{"name":"waxing_crescent_moon","emoji":"🌒"},{"name":"first_quarter_moon","emoji":"🌓"},{"name":"waxing_gibbous_moon","emoji":"🌔"},{"name":"new_moon_with_face","emoji":"🌚"},{"name":"full_moon_with_face","emoji":"🌝"},{"name":"first_quarter_moon_with_face","emoji":"🌛"},{"name":"last_quarter_moon_with_face","emoji":"🌜"},{"name":"sun_with_face","emoji":"🌞"},{"name":"crescent_moon","emoji":"🌙"},{"name":"star","emoji":"⭐"},{"name":"star2","emoji":"🌟"},{"name":"dizzy","emoji":"💫"},{"name":"sparkles","emoji":"✨"},{"name":"comet","emoji":"☄"},{"name":"sunny","emoji":"☀"},{"name":"sun_behind_small_cloud","emoji":"🌤"},{"name":"partly_sunny","emoji":"⛅"},{"name":"sun_behind_large_cloud","emoji":"🌥"},{"name":"sun_behind_rain_cloud","emoji":"🌦"},{"name":"cloud","emoji":"☁"},{"name":"cloud_with_rain","emoji":"🌧"},{"name":"cloud_with_lightning_and_rain","emoji":"⛈"},{"name":"cloud_with_lightning","emoji":"🌩"},{"name":"zap","emoji":"⚡"},{"name":"fire","emoji":"🔥"},{"name":"boom","emoji":"💥"},{"name":"snowflake","emoji":"❄"},{"name":"cloud_with_snow","emoji":"🌨"},{"name":"snowman","emoji":"⛄"},{"name":"snowman_with_snow","emoji":"☃"},{"name":"wind_face","emoji":"🌬"},{"name":"dash","emoji":"💨"},{"name":"tornado","emoji":"🌪"},{"name":"fog","emoji":"🌫"},{"name":"open_umbrella","emoji":"☂"},{"name":"umbrella","emoji":"☔"},{"name":"droplet","emoji":"💧"},{"name":"sweat_drops","emoji":"💦"},{"name":"ocean","emoji":"🌊"},{"name":"green_apple","emoji":"🍏"},{"name":"apple","emoji":"🍎"},{"name":"pear","emoji":"🍐"},{"name":"tangerine","emoji":"🍊"},{"name":"lemon","emoji":"🍋"},{"name":"banana","emoji":"🍌"},{"name":"watermelon","emoji":"🍉"},{"name":"grapes","emoji":"🍇"},{"name":"strawberry","emoji":"🍓"},{"name":"melon","emoji":"🍈"},{"name":"cherries","emoji":"🍒"},{"name":"peach","emoji":"🍑"},{"name":"pineapple","emoji":"🍍"},{"name":"kiwi_fruit","emoji":"🥝"},{"name":"avocado","emoji":"🥑"},{"name":"tomato","emoji":"🍅"},{"name":"eggplant","emoji":"🍆"},{"name":"cucumber","emoji":"🥒"},{"name":"carrot","emoji":"🥕"},{"name":"hot_pepper","emoji":"🌶"},{"name":"potato","emoji":"🥔"},{"name":"corn","emoji":"🌽"},{"name":"sweet_potato","emoji":"🍠"},{"name":"peanuts","emoji":"🥜"},{"name":"honey_pot","emoji":"🍯"},{"name":"croissant","emoji":"🥐"},{"name":"bread","emoji":"🍞"},{"name":"baguette_bread","emoji":"🥖"},{"name":"cheese","emoji":"🧀"},{"name":"egg","emoji":"🥚"},{"name":"bacon","emoji":"🥓"},{"name":"pancakes","emoji":"🥞"},{"name":"poultry_leg","emoji":"🍗"},{"name":"meat_on_bone","emoji":"🍖"},{"name":"fried_shrimp","emoji":"🍤"},{"name":"fried_egg","emoji":"🍳"},{"name":"hamburger","emoji":"🍔"},{"name":"fries","emoji":"🍟"},{"name":"stuffed_flatbread","emoji":"🥙"},{"name":"hotdog","emoji":"🌭"},{"name":"pizza","emoji":"🍕"},{"name":"spaghetti","emoji":"🍝"},{"name":"taco","emoji":"🌮"},{"name":"burrito","emoji":"🌯"},{"name":"green_salad","emoji":"🥗"},{"name":"shallow_pan_of_food","emoji":"🥘"},{"name":"ramen","emoji":"🍜"},{"name":"stew","emoji":"🍲"},{"name":"fish_cake","emoji":"🍥"},{"name":"sushi","emoji":"🍣"},{"name":"bento","emoji":"🍱"},{"name":"curry","emoji":"🍛"},{"name":"rice_ball","emoji":"🍙"},{"name":"rice","emoji":"🍚"},{"name":"rice_cracker","emoji":"🍘"},{"name":"oden","emoji":"🍢"},{"name":"dango","emoji":"🍡"},{"name":"shaved_ice","emoji":"🍧"},{"name":"ice_cream","emoji":"🍨"},{"name":"icecream","emoji":"🍦"},{"name":"cake","emoji":"🍰"},{"name":"birthday","emoji":"🎂"},{"name":"custard","emoji":"🍮"},{"name":"candy","emoji":"🍬"},{"name":"lollipop","emoji":"🍭"},{"name":"chocolate_bar","emoji":"🍫"},{"name":"popcorn","emoji":"🍿"},{"name":"doughnut","emoji":"🍩"},{"name":"cookie","emoji":"🍪"},{"name":"milk_glass","emoji":"🥛"},{"name":"beer","emoji":"🍺"},{"name":"beers","emoji":"🍻"},{"name":"clinking_glasses","emoji":"🥂"},{"name":"wine_glass","emoji":"🍷"},{"name":"tumbler_glass","emoji":"🥃"},{"name":"cocktail","emoji":"🍸"},{"name":"tropical_drink","emoji":"🍹"},{"name":"champagne","emoji":"🍾"},{"name":"sake","emoji":"🍶"},{"name":"tea","emoji":"🍵"},{"name":"coffee","emoji":"☕"},{"name":"baby_bottle","emoji":"🍼"},{"name":"spoon","emoji":"🥄"},{"name":"fork_and_knife","emoji":"🍴"},{"name":"plate_with_cutlery","emoji":"🍽"},{"name":"soccer","emoji":"⚽"},{"name":"basketball","emoji":"🏀"},{"name":"football","emoji":"🏈"},{"name":"baseball","emoji":"⚾"},{"name":"tennis","emoji":"🎾"},{"name":"volleyball","emoji":"🏐"},{"name":"rugby_football","emoji":"🏉"},{"name":"8ball","emoji":"🎱"},{"name":"golf","emoji":"⛳"},{"name":"golfing_woman","emoji":"🏌️‍♀"},{"name":"golfing_man","emoji":"🏌"},{"name":"ping_pong","emoji":"🏓"},{"name":"badminton","emoji":"🏸"},{"name":"goal_net","emoji":"🥅"},{"name":"ice_hockey","emoji":"🏒"},{"name":"field_hockey","emoji":"🏑"},{"name":"cricket_bat_and_ball","emoji":"🏏"},{"name":"ski","emoji":"🎿"},{"name":"skier","emoji":"⛷"},{"name":"snowboarder","emoji":"🏂"},{"name":"person_fencing","emoji":"🤺"},{"name":"women_wrestling","emoji":"🤼‍♀"},{"name":"men_wrestling","emoji":"🤼‍♂"},{"name":"woman_cartwheeling","emoji":"🤸‍♀️"},{"name":"man_cartwheeling","emoji":"🤸‍♂️"},{"name":"woman_playing_handball","emoji":"🤾‍♀️"},{"name":"man_playing_handball","emoji":"🤾‍♂️"},{"name":"ice_skate","emoji":"⛸"},{"name":"bow_and_arrow","emoji":"🏹"},{"name":"fishing_pole_and_fish","emoji":"🎣"},{"name":"boxing_glove","emoji":"🥊"},{"name":"martial_arts_uniform","emoji":"🥋"},{"name":"rowing_woman","emoji":"🚣‍♀️"},{"name":"rowing_man","emoji":"🚣"},{"name":"swimming_woman","emoji":"🏊‍♀️"},{"name":"swimming_man","emoji":"🏊"},{"name":"woman_playing_water_polo","emoji":"🤽‍♀️"},{"name":"man_playing_water_polo","emoji":"🤽‍♂️"},{"name":"surfing_woman","emoji":"🏄‍♀️"},{"name":"surfing_man","emoji":"🏄"},{"name":"bath","emoji":"🛀"},{"name":"basketball_woman","emoji":"⛹️‍♀"},{"name":"basketball_man","emoji":"⛹"},{"name":"weight_lifting_woman","emoji":"🏋️‍♀"},{"name":"weight_lifting_man","emoji":"🏋"},{"name":"biking_woman","emoji":"🚴‍♀️"},{"name":"biking_man","emoji":"🚴"},{"name":"mountain_biking_woman","emoji":"🚵‍♀️"},{"name":"mountain_biking_man","emoji":"🚵"},{"name":"horse_racing","emoji":"🏇"},{"name":"business_suit_levitating","emoji":"🕴"},{"name":"trophy","emoji":"🏆"},{"name":"running_shirt_with_sash","emoji":"🎽"},{"name":"medal_sports","emoji":"🏅"},{"name":"medal_military","emoji":"🎖"},{"name":"1st_place_medal","emoji":"🥇"},{"name":"2nd_place_medal","emoji":"🥈"},{"name":"3rd_place_medal","emoji":"🥉"},{"name":"reminder_ribbon","emoji":"🎗"},{"name":"rosette","emoji":"🏵"},{"name":"ticket","emoji":"🎫"},{"name":"tickets","emoji":"🎟"},{"name":"performing_arts","emoji":"🎭"},{"name":"art","emoji":"🎨"},{"name":"circus_tent","emoji":"🎪"},{"name":"woman_juggling","emoji":"🤹‍♀️"},{"name":"man_juggling","emoji":"🤹‍♂️"},{"name":"microphone","emoji":"🎤"},{"name":"headphones","emoji":"🎧"},{"name":"musical_score","emoji":"🎼"},{"name":"musical_keyboard","emoji":"🎹"},{"name":"drum","emoji":"🥁"},{"name":"saxophone","emoji":"🎷"},{"name":"trumpet","emoji":"🎺"},{"name":"guitar","emoji":"🎸"},{"name":"violin","emoji":"🎻"},{"name":"clapper","emoji":"🎬"},{"name":"video_game","emoji":"🎮"},{"name":"space_invader","emoji":"👾"},{"name":"dart","emoji":"🎯"},{"name":"game_die","emoji":"🎲"},{"name":"slot_machine","emoji":"🎰"},{"name":"bowling","emoji":"🎳"},{"name":"red_car","emoji":"🚗"},{"name":"taxi","emoji":"🚕"},{"name":"blue_car","emoji":"🚙"},{"name":"bus","emoji":"🚌"},{"name":"trolleybus","emoji":"🚎"},{"name":"racing_car","emoji":"🏎"},{"name":"police_car","emoji":"🚓"},{"name":"ambulance","emoji":"🚑"},{"name":"fire_engine","emoji":"🚒"},{"name":"minibus","emoji":"🚐"},{"name":"truck","emoji":"🚚"},{"name":"articulated_lorry","emoji":"🚛"},{"name":"tractor","emoji":"🚜"},{"name":"kick_scooter","emoji":"🛴"},{"name":"motorcycle","emoji":"🏍"},{"name":"bike","emoji":"🚲"},{"name":"motor_scooter","emoji":"🛵"},{"name":"rotating_light","emoji":"🚨"},{"name":"oncoming_police_car","emoji":"🚔"},{"name":"oncoming_bus","emoji":"🚍"},{"name":"oncoming_automobile","emoji":"🚘"},{"name":"oncoming_taxi","emoji":"🚖"},{"name":"aerial_tramway","emoji":"🚡"},{"name":"mountain_cableway","emoji":"🚠"},{"name":"suspension_railway","emoji":"🚟"},{"name":"railway_car","emoji":"🚃"},{"name":"train","emoji":"🚋"},{"name":"monorail","emoji":"🚝"},{"name":"bullettrain_side","emoji":"🚄"},{"name":"bullettrain_front","emoji":"🚅"},{"name":"light_rail","emoji":"🚈"},{"name":"mountain_railway","emoji":"🚞"},{"name":"steam_locomotive","emoji":"🚂"},{"name":"train2","emoji":"🚆"},{"name":"metro","emoji":"🚇"},{"name":"tram","emoji":"🚊"},{"name":"station","emoji":"🚉"},{"name":"helicopter","emoji":"🚁"},{"name":"small_airplane","emoji":"🛩"},{"name":"airplane","emoji":"✈"},{"name":"flight_departure","emoji":"🛫"},{"name":"flight_arrival","emoji":"🛬"},{"name":"sailboat","emoji":"⛵"},{"name":"motor_boat","emoji":"🛥"},{"name":"speedboat","emoji":"🚤"},{"name":"ferry","emoji":"⛴"},{"name":"passenger_ship","emoji":"🛳"},{"name":"rocket","emoji":"🚀"},{"name":"artificial_satellite","emoji":"🛰"},{"name":"seat","emoji":"💺"},{"name":"canoe","emoji":"🛶"},{"name":"anchor","emoji":"⚓"},{"name":"construction","emoji":"🚧"},{"name":"fuelpump","emoji":"⛽"},{"name":"busstop","emoji":"🚏"},{"name":"vertical_traffic_light","emoji":"🚦"},{"name":"traffic_light","emoji":"🚥"},{"name":"checkered_flag","emoji":"🏁"},{"name":"ship","emoji":"🚢"},{"name":"ferris_wheel","emoji":"🎡"},{"name":"roller_coaster","emoji":"🎢"},{"name":"carousel_horse","emoji":"🎠"},{"name":"building_construction","emoji":"🏗"},{"name":"foggy","emoji":"🌁"},{"name":"tokyo_tower","emoji":"🗼"},{"name":"factory","emoji":"🏭"},{"name":"fountain","emoji":"⛲"},{"name":"rice_scene","emoji":"🎑"},{"name":"mountain","emoji":"⛰"},{"name":"mountain_snow","emoji":"🏔"},{"name":"mount_fuji","emoji":"🗻"},{"name":"volcano","emoji":"🌋"},{"name":"japan","emoji":"🗾"},{"name":"camping","emoji":"🏕"},{"name":"tent","emoji":"⛺"},{"name":"national_park","emoji":"🏞"},{"name":"motorway","emoji":"🛣"},{"name":"railway_track","emoji":"🛤"},{"name":"sunrise","emoji":"🌅"},{"name":"sunrise_over_mountains","emoji":"🌄"},{"name":"desert","emoji":"🏜"},{"name":"beach_umbrella","emoji":"🏖"},{"name":"desert_island","emoji":"🏝"},{"name":"city_sunrise","emoji":"🌇"},{"name":"city_sunset","emoji":"🌆"},{"name":"cityscape","emoji":"🏙"},{"name":"night_with_stars","emoji":"🌃"},{"name":"bridge_at_night","emoji":"🌉"},{"name":"milky_way","emoji":"🌌"},{"name":"stars","emoji":"🌠"},{"name":"sparkler","emoji":"🎇"},{"name":"fireworks","emoji":"🎆"},{"name":"rainbow","emoji":"🌈"},{"name":"houses","emoji":"🏘"},{"name":"european_castle","emoji":"🏰"},{"name":"japanese_castle","emoji":"🏯"},{"name":"stadium","emoji":"🏟"},{"name":"statue_of_liberty","emoji":"🗽"},{"name":"house","emoji":"🏠"},{"name":"house_with_garden","emoji":"🏡"},{"name":"derelict_house","emoji":"🏚"},{"name":"office","emoji":"🏢"},{"name":"department_store","emoji":"🏬"},{"name":"post_office","emoji":"🏣"},{"name":"european_post_office","emoji":"🏤"},{"name":"hospital","emoji":"🏥"},{"name":"bank","emoji":"🏦"},{"name":"hotel","emoji":"🏨"},{"name":"convenience_store","emoji":"🏪"},{"name":"school","emoji":"🏫"},{"name":"love_hotel","emoji":"🏩"},{"name":"wedding","emoji":"💒"},{"name":"classical_building","emoji":"🏛"},{"name":"church","emoji":"⛪"},{"name":"mosque","emoji":"🕌"},{"name":"synagogue","emoji":"🕍"},{"name":"kaaba","emoji":"🕋"},{"name":"shinto_shrine","emoji":"⛩"},{"name":"watch","emoji":"⌚"},{"name":"iphone","emoji":"📱"},{"name":"calling","emoji":"📲"},{"name":"computer","emoji":"💻"},{"name":"keyboard","emoji":"⌨"},{"name":"desktop_computer","emoji":"🖥"},{"name":"printer","emoji":"🖨"},{"name":"computer_mouse","emoji":"🖱"},{"name":"trackball","emoji":"🖲"},{"name":"joystick","emoji":"🕹"},{"name":"clamp","emoji":"🗜"},{"name":"minidisc","emoji":"💽"},{"name":"floppy_disk","emoji":"💾"},{"name":"cd","emoji":"💿"},{"name":"dvd","emoji":"📀"},{"name":"vhs","emoji":"📼"},{"name":"camera","emoji":"📷"},{"name":"camera_flash","emoji":"📸"},{"name":"video_camera","emoji":"📹"},{"name":"movie_camera","emoji":"🎥"},{"name":"film_projector","emoji":"📽"},{"name":"film_strip","emoji":"🎞"},{"name":"telephone_receiver","emoji":"📞"},{"name":"phone","emoji":"☎"},{"name":"pager","emoji":"📟"},{"name":"fax","emoji":"📠"},{"name":"tv","emoji":"📺"},{"name":"radio","emoji":"📻"},{"name":"studio_microphone","emoji":"🎙"},{"name":"level_slider","emoji":"🎚"},{"name":"control_knobs","emoji":"🎛"},{"name":"stopwatch","emoji":"⏱"},{"name":"timer_clock","emoji":"⏲"},{"name":"alarm_clock","emoji":"⏰"},{"name":"mantelpiece_clock","emoji":"🕰"},{"name":"hourglass_flowing_sand","emoji":"⏳"},{"name":"hourglass","emoji":"⌛"},{"name":"satellite","emoji":"📡"},{"name":"battery","emoji":"🔋"},{"name":"electric_plug","emoji":"🔌"},{"name":"bulb","emoji":"💡"},{"name":"flashlight","emoji":"🔦"},{"name":"candle","emoji":"🕯"},{"name":"wastebasket","emoji":"🗑"},{"name":"oil_drum","emoji":"🛢"},{"name":"money_with_wings","emoji":"💸"},{"name":"dollar","emoji":"💵"},{"name":"yen","emoji":"💴"},{"name":"euro","emoji":"💶"},{"name":"pound","emoji":"💷"},{"name":"moneybag","emoji":"💰"},{"name":"credit_card","emoji":"💳"},{"name":"gem","emoji":"💎"},{"name":"balance_scale","emoji":"⚖"},{"name":"wrench","emoji":"🔧"},{"name":"hammer","emoji":"🔨"},{"name":"hammer_and_pick","emoji":"⚒"},{"name":"hammer_and_wrench","emoji":"🛠"},{"name":"pick","emoji":"⛏"},{"name":"nut_and_bolt","emoji":"🔩"},{"name":"gear","emoji":"⚙"},{"name":"chains","emoji":"⛓"},{"name":"gun","emoji":"🔫"},{"name":"bomb","emoji":"💣"},{"name":"hocho","emoji":"🔪"},{"name":"dagger","emoji":"🗡"},{"name":"crossed_swords","emoji":"⚔"},{"name":"shield","emoji":"🛡"},{"name":"smoking","emoji":"🚬"},{"name":"skull_and_crossbones","emoji":"☠"},{"name":"coffin","emoji":"⚰"},{"name":"funeral_urn","emoji":"⚱"},{"name":"amphora","emoji":"🏺"},{"name":"crystal_ball","emoji":"🔮"},{"name":"prayer_beads","emoji":"📿"},{"name":"barber","emoji":"💈"},{"name":"alembic","emoji":"⚗"},{"name":"telescope","emoji":"🔭"},{"name":"microscope","emoji":"🔬"},{"name":"hole","emoji":"🕳"},{"name":"pill","emoji":"💊"},{"name":"syringe","emoji":"💉"},{"name":"thermometer","emoji":"🌡"},{"name":"label","emoji":"🏷"},{"name":"bookmark","emoji":"🔖"},{"name":"toilet","emoji":"🚽"},{"name":"shower","emoji":"🚿"},{"name":"bathtub","emoji":"🛁"},{"name":"key","emoji":"🔑"},{"name":"old_key","emoji":"🗝"},{"name":"couch_and_lamp","emoji":"🛋"},{"name":"sleeping_bed","emoji":"🛌"},{"name":"bed","emoji":"🛏"},{"name":"door","emoji":"🚪"},{"name":"bellhop_bell","emoji":"🛎"},{"name":"framed_picture","emoji":"🖼"},{"name":"world_map","emoji":"🗺"},{"name":"parasol_on_ground","emoji":"⛱"},{"name":"moyai","emoji":"🗿"},{"name":"shopping","emoji":"🛍"},{"name":"shopping_cart","emoji":"🛒"},{"name":"balloon","emoji":"🎈"},{"name":"flags","emoji":"🎏"},{"name":"ribbon","emoji":"🎀"},{"name":"gift","emoji":"🎁"},{"name":"confetti_ball","emoji":"🎊"},{"name":"tada","emoji":"🎉"},{"name":"dolls","emoji":"🎎"},{"name":"wind_chime","emoji":"🎐"},{"name":"crossed_flags","emoji":"🎌"},{"name":"izakaya_lantern","emoji":"🏮"},{"name":"email","emoji":"✉"},{"name":"envelope_with_arrow","emoji":"📩"},{"name":"incoming_envelope","emoji":"📨"},{"name":"e-mail","emoji":"📧"},{"name":"love_letter","emoji":"💌"},{"name":"postbox","emoji":"📮"},{"name":"mailbox_closed","emoji":"📪"},{"name":"mailbox","emoji":"📫"},{"name":"mailbox_with_mail","emoji":"📬"},{"name":"mailbox_with_no_mail","emoji":"📭"},{"name":"package","emoji":"📦"},{"name":"postal_horn","emoji":"📯"},{"name":"inbox_tray","emoji":"📥"},{"name":"outbox_tray","emoji":"📤"},{"name":"scroll","emoji":"📜"},{"name":"page_with_curl","emoji":"📃"},{"name":"bookmark_tabs","emoji":"📑"},{"name":"bar_chart","emoji":"📊"},{"name":"chart_with_upwards_trend","emoji":"📈"},{"name":"chart_with_downwards_trend","emoji":"📉"},{"name":"page_facing_up","emoji":"📄"},{"name":"date","emoji":"📅"},{"name":"calendar","emoji":"📆"},{"name":"spiral_calendar","emoji":"🗓"},{"name":"card_index","emoji":"📇"},{"name":"card_file_box","emoji":"🗃"},{"name":"ballot_box","emoji":"🗳"},{"name":"file_cabinet","emoji":"🗄"},{"name":"clipboard","emoji":"📋"},{"name":"spiral_notepad","emoji":"🗒"},{"name":"file_folder","emoji":"📁"},{"name":"open_file_folder","emoji":"📂"},{"name":"card_index_dividers","emoji":"🗂"},{"name":"newspaper_roll","emoji":"🗞"},{"name":"newspaper","emoji":"📰"},{"name":"notebook","emoji":"📓"},{"name":"closed_book","emoji":"📕"},{"name":"green_book","emoji":"📗"},{"name":"blue_book","emoji":"📘"},{"name":"orange_book","emoji":"📙"},{"name":"notebook_with_decorative_cover","emoji":"📔"},{"name":"ledger","emoji":"📒"},{"name":"books","emoji":"📚"},{"name":"open_book","emoji":"📖"},{"name":"link","emoji":"🔗"},{"name":"paperclip","emoji":"📎"},{"name":"paperclips","emoji":"🖇"},{"name":"scissors","emoji":"✂"},{"name":"triangular_ruler","emoji":"📐"},{"name":"straight_ruler","emoji":"📏"},{"name":"pushpin","emoji":"📌"},{"name":"round_pushpin","emoji":"📍"},{"name":"triangular_flag_on_post","emoji":"🚩"},{"name":"white_flag","emoji":"🏳"},{"name":"black_flag","emoji":"🏴"},{"name":"rainbow_flag","emoji":"🏳️‍🌈"},{"name":"closed_lock_with_key","emoji":"🔐"},{"name":"lock","emoji":"🔒"},{"name":"unlock","emoji":"🔓"},{"name":"lock_with_ink_pen","emoji":"🔏"},{"name":"pen","emoji":"🖊"},{"name":"fountain_pen","emoji":"🖋"},{"name":"black_nib","emoji":"✒"},{"name":"memo","emoji":"📝"},{"name":"pencil2","emoji":"✏"},{"name":"crayon","emoji":"🖍"},{"name":"paintbrush","emoji":"🖌"},{"name":"mag","emoji":"🔍"},{"name":"mag_right","emoji":"🔎"},{"name":"heart","emoji":"❤"},{"name":"yellow_heart","emoji":"💛"},{"name":"green_heart","emoji":"💚"},{"name":"blue_heart","emoji":"💙"},{"name":"purple_heart","emoji":"💜"},{"name":"black_heart","emoji":"🖤"},{"name":"broken_heart","emoji":"💔"},{"name":"heavy_heart_exclamation","emoji":"❣"},{"name":"two_hearts","emoji":"💕"},{"name":"revolving_hearts","emoji":"💞"},{"name":"heartbeat","emoji":"💓"},{"name":"heartpulse","emoji":"💗"},{"name":"sparkling_heart","emoji":"💖"},{"name":"cupid","emoji":"💘"},{"name":"gift_heart","emoji":"💝"},{"name":"heart_decoration","emoji":"💟"},{"name":"peace_symbol","emoji":"☮"},{"name":"latin_cross","emoji":"✝"},{"name":"star_and_crescent","emoji":"☪"},{"name":"om","emoji":"🕉"},{"name":"wheel_of_dharma","emoji":"☸"},{"name":"star_of_david","emoji":"✡"},{"name":"six_pointed_star","emoji":"🔯"},{"name":"menorah","emoji":"🕎"},{"name":"yin_yang","emoji":"☯"},{"name":"orthodox_cross","emoji":"☦"},{"name":"place_of_worship","emoji":"🛐"},{"name":"ophiuchus","emoji":"⛎"},{"name":"aries","emoji":"♈"},{"name":"taurus","emoji":"♉"},{"name":"gemini","emoji":"♊"},{"name":"cancer","emoji":"♋"},{"name":"leo","emoji":"♌"},{"name":"virgo","emoji":"♍"},{"name":"libra","emoji":"♎"},{"name":"scorpius","emoji":"♏"},{"name":"sagittarius","emoji":"♐"},{"name":"capricorn","emoji":"♑"},{"name":"aquarius","emoji":"♒"},{"name":"pisces","emoji":"♓"},{"name":"id","emoji":"🆔"},{"name":"atom_symbol","emoji":"⚛"},{"name":"u7a7a","emoji":"🈳"},{"name":"u5272","emoji":"🈹"},{"name":"radioactive","emoji":"☢"},{"name":"biohazard","emoji":"☣"},{"name":"mobile_phone_off","emoji":"📴"},{"name":"vibration_mode","emoji":"📳"},{"name":"u6709","emoji":"🈶"},{"name":"u7121","emoji":"🈚"},{"name":"u7533","emoji":"🈸"},{"name":"u55b6","emoji":"🈺"},{"name":"u6708","emoji":"🈷"},{"name":"eight_pointed_black_star","emoji":"✴"},{"name":"vs","emoji":"🆚"},{"name":"accept","emoji":"🉑"},{"name":"white_flower","emoji":"💮"},{"name":"ideograph_advantage","emoji":"🉐"},{"name":"secret","emoji":"㊙"},{"name":"congratulations","emoji":"㊗"},{"name":"u5408","emoji":"🈴"},{"name":"u6e80","emoji":"🈵"},{"name":"u7981","emoji":"🈲"},{"name":"a","emoji":"🅰"},{"name":"b","emoji":"🅱"},{"name":"ab","emoji":"🆎"},{"name":"cl","emoji":"🆑"},{"name":"o2","emoji":"🅾"},{"name":"sos","emoji":"🆘"},{"name":"no_entry","emoji":"⛔"},{"name":"name_badge","emoji":"📛"},{"name":"no_entry_sign","emoji":"🚫"},{"name":"x","emoji":"❌"},{"name":"o","emoji":"⭕"},{"name":"stop_sign","emoji":"🛑"},{"name":"anger","emoji":"💢"},{"name":"hotsprings","emoji":"♨"},{"name":"no_pedestrians","emoji":"🚷"},{"name":"do_not_litter","emoji":"🚯"},{"name":"no_bicycles","emoji":"🚳"},{"name":"non-potable_water","emoji":"🚱"},{"name":"underage","emoji":"🔞"},{"name":"no_mobile_phones","emoji":"📵"},{"name":"exclamation","emoji":"❗"},{"name":"grey_exclamation","emoji":"❕"},{"name":"question","emoji":"❓"},{"name":"grey_question","emoji":"❔"},{"name":"bangbang","emoji":"‼"},{"name":"interrobang","emoji":"⁉"},{"name":"100","emoji":"💯"},{"name":"low_brightness","emoji":"🔅"},{"name":"high_brightness","emoji":"🔆"},{"name":"trident","emoji":"🔱"},{"name":"fleur_de_lis","emoji":"⚜"},{"name":"part_alternation_mark","emoji":"〽"},{"name":"warning","emoji":"⚠"},{"name":"children_crossing","emoji":"🚸"},{"name":"beginner","emoji":"🔰"},{"name":"recycle","emoji":"♻"},{"name":"u6307","emoji":"🈯"},{"name":"chart","emoji":"💹"},{"name":"sparkle","emoji":"❇"},{"name":"eight_spoked_asterisk","emoji":"✳"},{"name":"negative_squared_cross_mark","emoji":"❎"},{"name":"white_check_mark","emoji":"✅"},{"name":"diamond_shape_with_a_dot_inside","emoji":"💠"},{"name":"cyclone","emoji":"🌀"},{"name":"loop","emoji":"➿"},{"name":"globe_with_meridians","emoji":"🌐"},{"name":"m","emoji":"Ⓜ"},{"name":"atm","emoji":"🏧"},{"name":"sa","emoji":"🈂"},{"name":"passport_control","emoji":"🛂"},{"name":"customs","emoji":"🛃"},{"name":"baggage_claim","emoji":"🛄"},{"name":"left_luggage","emoji":"🛅"},{"name":"wheelchair","emoji":"♿"},{"name":"no_smoking","emoji":"🚭"},{"name":"wc","emoji":"🚾"},{"name":"parking","emoji":"🅿"},{"name":"potable_water","emoji":"🚰"},{"name":"mens","emoji":"🚹"},{"name":"womens","emoji":"🚺"},{"name":"baby_symbol","emoji":"🚼"},{"name":"restroom","emoji":"🚻"},{"name":"put_litter_in_its_place","emoji":"🚮"},{"name":"cinema","emoji":"🎦"},{"name":"signal_strength","emoji":"📶"},{"name":"koko","emoji":"🈁"},{"name":"ng","emoji":"🆖"},{"name":"ok","emoji":"🆗"},{"name":"up","emoji":"🆙"},{"name":"cool","emoji":"🆒"},{"name":"new","emoji":"🆕"},{"name":"free","emoji":"🆓"},{"name":"zero","emoji":"0️⃣"},{"name":"one","emoji":"1️⃣"},{"name":"two","emoji":"2️⃣"},{"name":"three","emoji":"3️⃣"},{"name":"four","emoji":"4️⃣"},{"name":"five","emoji":"5️⃣"},{"name":"six","emoji":"6️⃣"},{"name":"seven","emoji":"7️⃣"},{"name":"eight","emoji":"8️⃣"},{"name":"nine","emoji":"9️⃣"},{"name":"keycap_ten","emoji":"🔟"},{"name":"asterisk","emoji":"*️⃣"},{"name":"1234","emoji":"🔢"},{"name":"arrow_forward","emoji":"▶"},{"name":"pause_button","emoji":"⏸"},{"name":"next_track_button","emoji":"⏭"},{"name":"stop_button","emoji":"⏹"},{"name":"record_button","emoji":"⏺"},{"name":"play_or_pause_button","emoji":"⏯"},{"name":"previous_track_button","emoji":"⏮"},{"name":"fast_forward","emoji":"⏩"},{"name":"rewind","emoji":"⏪"},{"name":"twisted_rightwards_arrows","emoji":"🔀"},{"name":"repeat","emoji":"🔁"},{"name":"repeat_one","emoji":"🔂"},{"name":"arrow_backward","emoji":"◀"},{"name":"arrow_up_small","emoji":"🔼"},{"name":"arrow_down_small","emoji":"🔽"},{"name":"arrow_double_up","emoji":"⏫"},{"name":"arrow_double_down","emoji":"⏬"},{"name":"arrow_right","emoji":"➡"},{"name":"arrow_left","emoji":"⬅"},{"name":"arrow_up","emoji":"⬆"},{"name":"arrow_down","emoji":"⬇"},{"name":"arrow_upper_right","emoji":"↗"},{"name":"arrow_lower_right","emoji":"↘"},{"name":"arrow_lower_left","emoji":"↙"},{"name":"arrow_upper_left","emoji":"↖"},{"name":"arrow_up_down","emoji":"↕"},{"name":"left_right_arrow","emoji":"↔"},{"name":"arrows_counterclockwise","emoji":"🔄"},{"name":"arrow_right_hook","emoji":"↪"},{"name":"leftwards_arrow_with_hook","emoji":"↩"},{"name":"arrow_heading_up","emoji":"⤴"},{"name":"arrow_heading_down","emoji":"⤵"},{"name":"hash","emoji":"#️⃣"},{"name":"information_source","emoji":"ℹ"},{"name":"abc","emoji":"🔤"},{"name":"abcd","emoji":"🔡"},{"name":"capital_abcd","emoji":"🔠"},{"name":"symbols","emoji":"🔣"},{"name":"musical_note","emoji":"🎵"},{"name":"notes","emoji":"🎶"},{"name":"wavy_dash","emoji":"〰"},{"name":"curly_loop","emoji":"➰"},{"name":"heavy_check_mark","emoji":"✔"},{"name":"arrows_clockwise","emoji":"🔃"},{"name":"heavy_plus_sign","emoji":"➕"},{"name":"heavy_minus_sign","emoji":"➖"},{"name":"heavy_division_sign","emoji":"➗"},{"name":"heavy_multiplication_x","emoji":"✖"},{"name":"heavy_dollar_sign","emoji":"💲"},{"name":"currency_exchange","emoji":"💱"},{"name":"copyright","emoji":"©"},{"name":"registered","emoji":"®"},{"name":"tm","emoji":"™"},{"name":"end","emoji":"🔚"},{"name":"back","emoji":"🔙"},{"name":"on","emoji":"🔛"},{"name":"top","emoji":"🔝"},{"name":"soon","emoji":"🔜"},{"name":"ballot_box_with_check","emoji":"☑"},{"name":"radio_button","emoji":"🔘"},{"name":"white_circle","emoji":"⚪"},{"name":"black_circle","emoji":"⚫"},{"name":"red_circle","emoji":"🔴"},{"name":"large_blue_circle","emoji":"🔵"},{"name":"small_orange_diamond","emoji":"🔸"},{"name":"small_blue_diamond","emoji":"🔹"},{"name":"large_orange_diamond","emoji":"🔶"},{"name":"large_blue_diamond","emoji":"🔷"},{"name":"small_red_triangle","emoji":"🔺"},{"name":"black_small_square","emoji":"▪"},{"name":"white_small_square","emoji":"▫"},{"name":"black_large_square","emoji":"⬛"},{"name":"white_large_square","emoji":"⬜"},{"name":"small_red_triangle_down","emoji":"🔻"},{"name":"black_medium_square","emoji":"◼"},{"name":"white_medium_square","emoji":"◻"},{"name":"black_medium_small_square","emoji":"◾"},{"name":"white_medium_small_square","emoji":"◽"},{"name":"black_square_button","emoji":"🔲"},{"name":"white_square_button","emoji":"🔳"},{"name":"speaker","emoji":"🔈"},{"name":"sound","emoji":"🔉"},{"name":"loud_sound","emoji":"🔊"},{"name":"mute","emoji":"🔇"},{"name":"mega","emoji":"📣"},{"name":"loudspeaker","emoji":"📢"},{"name":"bell","emoji":"🔔"},{"name":"no_bell","emoji":"🔕"},{"name":"black_joker","emoji":"🃏"},{"name":"mahjong","emoji":"🀄"},{"name":"spades","emoji":"♠"},{"name":"clubs","emoji":"♣"},{"name":"hearts","emoji":"♥"},{"name":"diamonds","emoji":"♦"},{"name":"flower_playing_cards","emoji":"🎴"},{"name":"thought_balloon","emoji":"💭"},{"name":"right_anger_bubble","emoji":"🗯"},{"name":"speech_balloon","emoji":"💬"},{"name":"left_speech_bubble","emoji":"🗨"},{"name":"clock1","emoji":"🕐"},{"name":"clock2","emoji":"🕑"},{"name":"clock3","emoji":"🕒"},{"name":"clock4","emoji":"🕓"},{"name":"clock5","emoji":"🕔"},{"name":"clock6","emoji":"🕕"},{"name":"clock7","emoji":"🕖"},{"name":"clock8","emoji":"🕗"},{"name":"clock9","emoji":"🕘"},{"name":"clock10","emoji":"🕙"},{"name":"clock11","emoji":"🕚"},{"name":"clock12","emoji":"🕛"},{"name":"clock130","emoji":"🕜"},{"name":"clock230","emoji":"🕝"},{"name":"clock330","emoji":"🕞"},{"name":"clock430","emoji":"🕟"},{"name":"clock530","emoji":"🕠"},{"name":"clock630","emoji":"🕡"},{"name":"clock730","emoji":"🕢"},{"name":"clock830","emoji":"🕣"},{"name":"clock930","emoji":"🕤"},{"name":"clock1030","emoji":"🕥"},{"name":"clock1130","emoji":"🕦"},{"name":"clock1230","emoji":"🕧"},{"name":"afghanistan","emoji":"🇦🇫"},{"name":"aland_islands","emoji":"🇦🇽"},{"name":"albania","emoji":"🇦🇱"},{"name":"algeria","emoji":"🇩🇿"},{"name":"american_samoa","emoji":"🇦🇸"},{"name":"andorra","emoji":"🇦🇩"},{"name":"angola","emoji":"🇦🇴"},{"name":"anguilla","emoji":"🇦🇮"},{"name":"antarctica","emoji":"🇦🇶"},{"name":"antigua_barbuda","emoji":"🇦🇬"},{"name":"argentina","emoji":"🇦🇷"},{"name":"armenia","emoji":"🇦🇲"},{"name":"aruba","emoji":"🇦🇼"},{"name":"australia","emoji":"🇦🇺"},{"name":"austria","emoji":"🇦🇹"},{"name":"azerbaijan","emoji":"🇦🇿"},{"name":"bahamas","emoji":"🇧🇸"},{"name":"bahrain","emoji":"🇧🇭"},{"name":"bangladesh","emoji":"🇧🇩"},{"name":"barbados","emoji":"🇧🇧"},{"name":"belarus","emoji":"🇧🇾"},{"name":"belgium","emoji":"🇧🇪"},{"name":"belize","emoji":"🇧🇿"},{"name":"benin","emoji":"🇧🇯"},{"name":"bermuda","emoji":"🇧🇲"},{"name":"bhutan","emoji":"🇧🇹"},{"name":"bolivia","emoji":"🇧🇴"},{"name":"caribbean_netherlands","emoji":"🇧🇶"},{"name":"bosnia_herzegovina","emoji":"🇧🇦"},{"name":"botswana","emoji":"🇧🇼"},{"name":"brazil","emoji":"🇧🇷"},{"name":"british_indian_ocean_territory","emoji":"🇮🇴"},{"name":"british_virgin_islands","emoji":"🇻🇬"},{"name":"brunei","emoji":"🇧🇳"},{"name":"bulgaria","emoji":"🇧🇬"},{"name":"burkina_faso","emoji":"🇧🇫"},{"name":"burundi","emoji":"🇧🇮"},{"name":"cape_verde","emoji":"🇨🇻"},{"name":"cambodia","emoji":"🇰🇭"},{"name":"cameroon","emoji":"🇨🇲"},{"name":"canada","emoji":"🇨🇦"},{"name":"canary_islands","emoji":"🇮🇨"},{"name":"cayman_islands","emoji":"🇰🇾"},{"name":"central_african_republic","emoji":"🇨🇫"},{"name":"chad","emoji":"🇹🇩"},{"name":"chile","emoji":"🇨🇱"},{"name":"cn","emoji":"🇨🇳"},{"name":"christmas_island","emoji":"🇨🇽"},{"name":"cocos_islands","emoji":"🇨🇨"},{"name":"colombia","emoji":"🇨🇴"},{"name":"comoros","emoji":"🇰🇲"},{"name":"congo_brazzaville","emoji":"🇨🇬"},{"name":"congo_kinshasa","emoji":"🇨🇩"},{"name":"cook_islands","emoji":"🇨🇰"},{"name":"costa_rica","emoji":"🇨🇷"},{"name":"croatia","emoji":"🇭🇷"},{"name":"cuba","emoji":"🇨🇺"},{"name":"curacao","emoji":"🇨🇼"},{"name":"cyprus","emoji":"🇨🇾"},{"name":"czech_republic","emoji":"🇨🇿"},{"name":"denmark","emoji":"🇩🇰"},{"name":"djibouti","emoji":"🇩🇯"},{"name":"dominica","emoji":"🇩🇲"},{"name":"dominican_republic","emoji":"🇩🇴"},{"name":"ecuador","emoji":"🇪🇨"},{"name":"egypt","emoji":"🇪🇬"},{"name":"el_salvador","emoji":"🇸🇻"},{"name":"equatorial_guinea","emoji":"🇬🇶"},{"name":"eritrea","emoji":"🇪🇷"},{"name":"estonia","emoji":"🇪🇪"},{"name":"ethiopia","emoji":"🇪🇹"},{"name":"eu","emoji":"🇪🇺"},{"name":"falkland_islands","emoji":"🇫🇰"},{"name":"faroe_islands","emoji":"🇫🇴"},{"name":"fiji","emoji":"🇫🇯"},{"name":"finland","emoji":"🇫🇮"},{"name":"fr","emoji":"🇫🇷"},{"name":"french_guiana","emoji":"🇬🇫"},{"name":"french_polynesia","emoji":"🇵🇫"},{"name":"french_southern_territories","emoji":"🇹🇫"},{"name":"gabon","emoji":"🇬🇦"},{"name":"gambia","emoji":"🇬🇲"},{"name":"georgia","emoji":"🇬🇪"},{"name":"de","emoji":"🇩🇪"},{"name":"ghana","emoji":"🇬🇭"},{"name":"gibraltar","emoji":"🇬🇮"},{"name":"greece","emoji":"🇬🇷"},{"name":"greenland","emoji":"🇬🇱"},{"name":"grenada","emoji":"🇬🇩"},{"name":"guadeloupe","emoji":"🇬🇵"},{"name":"guam","emoji":"🇬🇺"},{"name":"guatemala","emoji":"🇬🇹"},{"name":"guernsey","emoji":"🇬🇬"},{"name":"guinea","emoji":"🇬🇳"},{"name":"guinea_bissau","emoji":"🇬🇼"},{"name":"guyana","emoji":"🇬🇾"},{"name":"haiti","emoji":"🇭🇹"},{"name":"honduras","emoji":"🇭🇳"},{"name":"hong_kong","emoji":"🇭🇰"},{"name":"hungary","emoji":"🇭🇺"},{"name":"iceland","emoji":"🇮🇸"},{"name":"india","emoji":"🇮🇳"},{"name":"indonesia","emoji":"🇮🇩"},{"name":"iran","emoji":"🇮🇷"},{"name":"iraq","emoji":"🇮🇶"},{"name":"ireland","emoji":"🇮🇪"},{"name":"isle_of_man","emoji":"🇮🇲"},{"name":"israel","emoji":"🇮🇱"},{"name":"it","emoji":"🇮🇹"},{"name":"cote_divoire","emoji":"🇨🇮"},{"name":"jamaica","emoji":"🇯🇲"},{"name":"jp","emoji":"🇯🇵"},{"name":"jersey","emoji":"🇯🇪"},{"name":"jordan","emoji":"🇯🇴"},{"name":"kazakhstan","emoji":"🇰🇿"},{"name":"kenya","emoji":"🇰🇪"},{"name":"kiribati","emoji":"🇰🇮"},{"name":"kosovo","emoji":"🇽🇰"},{"name":"kuwait","emoji":"🇰🇼"},{"name":"kyrgyzstan","emoji":"🇰🇬"},{"name":"laos","emoji":"🇱🇦"},{"name":"latvia","emoji":"🇱🇻"},{"name":"lebanon","emoji":"🇱🇧"},{"name":"lesotho","emoji":"🇱🇸"},{"name":"liberia","emoji":"🇱🇷"},{"name":"libya","emoji":"🇱🇾"},{"name":"liechtenstein","emoji":"🇱🇮"},{"name":"lithuania","emoji":"🇱🇹"},{"name":"luxembourg","emoji":"🇱🇺"},{"name":"macau","emoji":"🇲🇴"},{"name":"macedonia","emoji":"🇲🇰"},{"name":"madagascar","emoji":"🇲🇬"},{"name":"malawi","emoji":"🇲🇼"},{"name":"malaysia","emoji":"🇲🇾"},{"name":"maldives","emoji":"🇲🇻"},{"name":"mali","emoji":"🇲🇱"},{"name":"malta","emoji":"🇲🇹"},{"name":"marshall_islands","emoji":"🇲🇭"},{"name":"martinique","emoji":"🇲🇶"},{"name":"mauritania","emoji":"🇲🇷"},{"name":"mauritius","emoji":"🇲🇺"},{"name":"mayotte","emoji":"🇾🇹"},{"name":"mexico","emoji":"🇲🇽"},{"name":"micronesia","emoji":"🇫🇲"},{"name":"moldova","emoji":"🇲🇩"},{"name":"monaco","emoji":"🇲🇨"},{"name":"mongolia","emoji":"🇲🇳"},{"name":"montenegro","emoji":"🇲🇪"},{"name":"montserrat","emoji":"🇲🇸"},{"name":"morocco","emoji":"🇲🇦"},{"name":"mozambique","emoji":"🇲🇿"},{"name":"myanmar","emoji":"🇲🇲"},{"name":"namibia","emoji":"🇳🇦"},{"name":"nauru","emoji":"🇳🇷"},{"name":"nepal","emoji":"🇳🇵"},{"name":"netherlands","emoji":"🇳🇱"},{"name":"new_caledonia","emoji":"🇳🇨"},{"name":"new_zealand","emoji":"🇳🇿"},{"name":"nicaragua","emoji":"🇳🇮"},{"name":"niger","emoji":"🇳🇪"},{"name":"nigeria","emoji":"🇳🇬"},{"name":"niue","emoji":"🇳🇺"},{"name":"norfolk_island","emoji":"🇳🇫"},{"name":"northern_mariana_islands","emoji":"🇲🇵"},{"name":"north_korea","emoji":"🇰🇵"},{"name":"norway","emoji":"🇳🇴"},{"name":"oman","emoji":"🇴🇲"},{"name":"pakistan","emoji":"🇵🇰"},{"name":"palau","emoji":"🇵🇼"},{"name":"palestinian_territories","emoji":"🇵🇸"},{"name":"panama","emoji":"🇵🇦"},{"name":"papua_new_guinea","emoji":"🇵🇬"},{"name":"paraguay","emoji":"🇵🇾"},{"name":"peru","emoji":"🇵🇪"},{"name":"philippines","emoji":"🇵🇭"},{"name":"pitcairn_islands","emoji":"🇵🇳"},{"name":"poland","emoji":"🇵🇱"},{"name":"portugal","emoji":"🇵🇹"},{"name":"puerto_rico","emoji":"🇵🇷"},{"name":"qatar","emoji":"🇶🇦"},{"name":"reunion","emoji":"🇷🇪"},{"name":"romania","emoji":"🇷🇴"},{"name":"ru","emoji":"🇷🇺"},{"name":"rwanda","emoji":"🇷🇼"},{"name":"st_barthelemy","emoji":"🇧🇱"},{"name":"st_helena","emoji":"🇸🇭"},{"name":"st_kitts_nevis","emoji":"🇰🇳"},{"name":"st_lucia","emoji":"🇱🇨"},{"name":"st_pierre_miquelon","emoji":"🇵🇲"},{"name":"st_vincent_grenadines","emoji":"🇻🇨"},{"name":"samoa","emoji":"🇼🇸"},{"name":"san_marino","emoji":"🇸🇲"},{"name":"sao_tome_principe","emoji":"🇸🇹"},{"name":"saudi_arabia","emoji":"🇸🇦"},{"name":"senegal","emoji":"🇸🇳"},{"name":"serbia","emoji":"🇷🇸"},{"name":"seychelles","emoji":"🇸🇨"},{"name":"sierra_leone","emoji":"🇸🇱"},{"name":"singapore","emoji":"🇸🇬"},{"name":"sint_maarten","emoji":"🇸🇽"},{"name":"slovakia","emoji":"🇸🇰"},{"name":"slovenia","emoji":"🇸🇮"},{"name":"solomon_islands","emoji":"🇸🇧"},{"name":"somalia","emoji":"🇸🇴"},{"name":"south_africa","emoji":"🇿🇦"},{"name":"south_georgia_south_sandwich_islands","emoji":"🇬🇸"},{"name":"kr","emoji":"🇰🇷"},{"name":"south_sudan","emoji":"🇸🇸"},{"name":"es","emoji":"🇪🇸"},{"name":"sri_lanka","emoji":"🇱🇰"},{"name":"sudan","emoji":"🇸🇩"},{"name":"suriname","emoji":"🇸🇷"},{"name":"swaziland","emoji":"🇸🇿"},{"name":"sweden","emoji":"🇸🇪"},{"name":"switzerland","emoji":"🇨🇭"},{"name":"syria","emoji":"🇸🇾"},{"name":"taiwan","emoji":"🇹🇼"},{"name":"tajikistan","emoji":"🇹🇯"},{"name":"tanzania","emoji":"🇹🇿"},{"name":"thailand","emoji":"🇹🇭"},{"name":"timor_leste","emoji":"🇹🇱"},{"name":"togo","emoji":"🇹🇬"},{"name":"tokelau","emoji":"🇹🇰"},{"name":"tonga","emoji":"🇹🇴"},{"name":"trinidad_tobago","emoji":"🇹🇹"},{"name":"tunisia","emoji":"🇹🇳"},{"name":"tr","emoji":"🇹🇷"},{"name":"turkmenistan","emoji":"🇹🇲"},{"name":"turks_caicos_islands","emoji":"🇹🇨"},{"name":"tuvalu","emoji":"🇹🇻"},{"name":"uganda","emoji":"🇺🇬"},{"name":"ukraine","emoji":"🇺🇦"},{"name":"united_arab_emirates","emoji":"🇦🇪"},{"name":"uk","emoji":"🇬🇧"},{"name":"us","emoji":"🇺🇸"},{"name":"us_virgin_islands","emoji":"🇻🇮"},{"name":"uruguay","emoji":"🇺🇾"},{"name":"uzbekistan","emoji":"🇺🇿"},{"name":"vanuatu","emoji":"🇻🇺"},{"name":"vatican_city","emoji":"🇻🇦"},{"name":"venezuela","emoji":"🇻🇪"},{"name":"vietnam","emoji":"🇻🇳"},{"name":"wallis_futuna","emoji":"🇼🇫"},{"name":"western_sahara","emoji":"🇪🇭"},{"name":"yemen","emoji":"🇾🇪"},{"name":"zambia","emoji":"🇿🇲"},{"name":"zimbabwe","emoji":"🇿🇼"},{"name":"star_struck","emoji":"🤩"},{"name":"face_with_raised_eyebrow","emoji":"🤨"},{"name":"exploding_head","emoji":"🤯"},{"name":"crazy_face","emoji":"🤪"},{"name":"face_with_symbols_over_mouth","emoji":"🤬"},{"name":"face_vomiting","emoji":"🤮"},{"name":"shushing_face","emoji":"🤫"},{"name":"face_with_hand_over_mouth","emoji":"🤭"},{"name":"face_with_monocle","emoji":"🧐"},{"name":"child","emoji":"🧒"},{"name":"adult","emoji":"🧑"},{"name":"older_adult","emoji":"🧓"},{"name":"woman_with_headscarf","emoji":"🧕"},{"name":"bearded_person","emoji":"🧔"},{"name":"breast_feeding","emoji":"🤱"},{"name":"mage","emoji":"🧙"},{"name":"woman_mage","emoji":"🧙‍♀️"},{"name":"fairy","emoji":"🧚"},{"name":"vampire","emoji":"🧛"},{"name":"merperson","emoji":"🧜"},{"name":"merman","emoji":"🧜‍♂️"},{"name":"elf","emoji":"🧝"},{"name":"genie","emoji":"🧞"},{"name":"woman_genie","emoji":"🧞‍♀"},{"name":"zombie","emoji":"🧟"},{"name":"woman_zombie","emoji":"🧟‍♀"},{"name":"person_in_steamy_room","emoji":"🧖"},{"name":"woman_in_steamy_room","emoji":"🧖‍♀️"},{"name":"person_climbing","emoji":"🧗"},{"name":"woman_climbing","emoji":"🧗‍♀️"},{"name":"person_in_lotus_position","emoji":"🧘"},{"name":"woman_in_lotus_position","emoji":"🧘‍♀️"},{"name":"love_you_gesture","emoji":"🤟"},{"name":"palms_up_together","emoji":"🤲"},{"name":"brain","emoji":"🧠"},{"name":"orange_heart","emoji":"🧡"},{"name":"scarf","emoji":"🧣"},{"name":"gloves","emoji":"🧤"},{"name":"coat","emoji":"🧥"},{"name":"socks","emoji":"🧦"},{"name":"billed_cap","emoji":"🧢"},{"name":"zebra","emoji":"🦓"},{"name":"giraffe","emoji":"🦒"},{"name":"hedgehog","emoji":"🦔"},{"name":"sauropod","emoji":"🦕"},{"name":"t_rex","emoji":"🦖"},{"name":"cricket","emoji":"🦗"},{"name":"coconut","emoji":"🥥"},{"name":"broccoli","emoji":"🥦"},{"name":"pretzel","emoji":"🥨"},{"name":"cut_of_meat","emoji":"🥩"},{"name":"sandwich","emoji":"🥪"},{"name":"bowl_with_spoon","emoji":"🥣"},{"name":"canned_food","emoji":"🥫"},{"name":"dumpling","emoji":"🥟"},{"name":"fortune_cookie","emoji":"🥠"},{"name":"takeout_box","emoji":"🥡"},{"name":"pie","emoji":"🥧"},{"name":"cup_with_straw","emoji":"🥤"},{"name":"chopsticks","emoji":"🥢"},{"name":"flying_saucer","emoji":"🛸"},{"name":"sled","emoji":"🛷"},{"name":"curling_stone","emoji":"🥌"},{"name":"svalbard_and_jan_mayen","emoji":"🇸🇯"},{"name":"st_martin","emoji":"🇲🇫"},{"name":"us_outlying_islands","emoji":"🇺🇲"},{"name":"tristan_da_cunha","emoji":"🇹🇦"},{"name":"heard_and_mc_donald_islands","emoji":"🇭🇲"},{"name":"ceuta_and_melilla","emoji":"🇪🇦"},{"name":"diego_garcia","emoji":"🇩🇬"},{"name":"ascension_island","emoji":"🇦🇨"},{"name":"bouvet_island","emoji":"🇧🇻"},{"name":"clipperton_island","emoji":"🇨🇵"},{"name":"united_nations","emoji":"🇺🇳"},{"name":"smiling_face_with_three_hearts","emoji":"🥰"},{"name":"hot_face","emoji":"🥵"},{"name":"cold_face","emoji":"🥶"},{"name":"partying_face","emoji":"🥳"},{"name":"woozy_face","emoji":"🥴"},{"name":"pleading_face","emoji":"🥺"},{"name":"man_red_haired","emoji":"👨‍🦰"},{"name":"man_curly_haired","emoji":"👨‍🦱"},{"name":"man_white_haired","emoji":"👨‍🦳"},{"name":"man_bald","emoji":"👨‍🦲"},{"name":"woman_red_haired","emoji":"👩‍🦰"},{"name":"woman_curly_haired","emoji":"👩‍🦱"},{"name":"woman_white_haired","emoji":"👩‍🦳"},{"name":"woman_bald","emoji":"👩‍🦲"},{"name":"superhero","emoji":"🦸"},{"name":"man_superhero","emoji":"🦸‍♂️"},{"name":"woman_superhero","emoji":"🦸‍♀️"},{"name":"supervillain","emoji":"🦹"},{"name":"woman_supervillain","emoji":"🦹‍♀️"},{"name":"man_supervillain","emoji":"🦹‍♂️"},{"name":"leg","emoji":"🦵"},{"name":"foot","emoji":"🦶"},{"name":"bone","emoji":"🦴"},{"name":"tooth","emoji":"🦷"},{"name":"goggles","emoji":"🥽"},{"name":"lab_coat","emoji":"🥼"},{"name":"hiking_boot","emoji":"🥾"},{"name":"flat_shoe","emoji":"🥿"},{"name":"raccoon","emoji":"🦝"},{"name":"llama","emoji":"🦙"},{"name":"hippopotamus","emoji":"🦛"},{"name":"kangaroo","emoji":"🦘"},{"name":"badger","emoji":"🦡"},{"name":"swan","emoji":"🦢"},{"name":"peacock","emoji":"🦚"},{"name":"parrot","emoji":"🦜"},{"name":"lobster","emoji":"🦞"},{"name":"mosquito","emoji":"🦟"},{"name":"microbe","emoji":"🦠"},{"name":"mango","emoji":"🥭"},{"name":"leafy_green","emoji":"🥬"},{"name":"bagel","emoji":"🥯"},{"name":"salt","emoji":"🧂"},{"name":"moon_cake","emoji":"🥮"},{"name":"cupcake","emoji":"🧁"},{"name":"compass","emoji":"🧭"},{"name":"brick","emoji":"🧱"},{"name":"skateboard","emoji":"🛹"},{"name":"luggage","emoji":"🧳"},{"name":"firecracker","emoji":"🧨"},{"name":"red_gift_envelope","emoji":"🧧"},{"name":"softball","emoji":"🥎"},{"name":"flying_disc","emoji":"🥏"},{"name":"lacrosse","emoji":"🥍"},{"name":"nazar_amulet","emoji":"🧿"},{"name":"jigsaw","emoji":"🧩"},{"name":"teddy_bear","emoji":"🧸"},{"name":"chess_pawn","emoji":"♟"},{"name":"thread","emoji":"🧵"},{"name":"yarn","emoji":"🧶"},{"name":"abacus","emoji":"🧮"},{"name":"receipt","emoji":"🧾"},{"name":"toolbox","emoji":"🧰"},{"name":"magnet","emoji":"🧲"},{"name":"test_tube","emoji":"🧪"},{"name":"petri_dish","emoji":"🧫"},{"name":"dna","emoji":"🧬"},{"name":"lotion_bottle","emoji":"🧴"},{"name":"safety_pin","emoji":"🧷"},{"name":"broom","emoji":"🧹"},{"name":"basket","emoji":"🧺"},{"name":"roll_of_toilet_paper","emoji":"🧻"},{"name":"soap","emoji":"🧼"},{"name":"sponge","emoji":"🧽"},{"name":"fire_extinguisher","emoji":"🧯"},{"name":"infinity","emoji":"♾"},{"name":"pirate_flag","emoji":"🏴‍☠"},{"name":"waffle","emoji":"🧇"},{"name":"otter","emoji":"🦦"},{"name":"sloth","emoji":"🦥"},{"name":"ice_cube","emoji":"🧊"},{"name":"ringer_planet","emoji":"🪐"},{"name":"flamingo","emoji":"🦩"},{"name":"yawning_face","emoji":"🥱"},{"name":"pinching_hand","emoji":"🤏"},{"name":"service_dog","emoji":"🐕‍🦺"},{"name":"orangutan","emoji":"🦧"},{"name":"auto_rickshaw","emoji":"🛺"},{"name":"parachute","emoji":"🪂"},{"name":"yo-yo","emoji":"🪀"},{"name":"kite","emoji":"🪁"},{"name":"brown_square","emoji":"🟫"},{"name":"purple_square","emoji":"🟪"},{"name":"blue_square","emoji":"🟦"},{"name":"green_square","emoji":"🟩"},{"name":"yellow_square","emoji":"🟨"},{"name":"orange_square","emoji":"🟧"},{"name":"red_square","emoji":"🟥"},{"name":"brown_circle","emoji":"🟤"},{"name":"purple_circle","emoji":"🟣"},{"name":"green_circle","emoji":"🟢"},{"name":"yellow_circle","emoji":"🟡"},{"name":"orange_circle","emoji":"🟠"},{"name":"razor","emoji":"🪒"},{"name":"chair","emoji":"🪑"},{"name":"stethoscope","emoji":"🩺"},{"name":"adhesive_bandage","emoji":"🩹"},{"name":"drop_of_blood","emoji":"🩸"},{"name":"probing_cane","emoji":"🦯"},{"name":"axe","emoji":"🪓"},{"name":"diya_lamp","emoji":"🪔"},{"name":"banjo","emoji":"🪕"},{"name":"ballet_shoes","emoji":"🩰"},{"name":"shorts","emoji":"🩳"},{"name":"briefs","emoji":"🩲"},{"name":"one_piece_swimsuit","emoji":"🩱"},{"name":"sari","emoji":"🥻"},{"name":"safety_vest","emoji":"🦺"},{"name":"diving_mask","emoji":"🤿"},{"name":"motorized_wheelchair","emoji":"🦼"},{"name":"manual_wheelchair","emoji":"🦽"},{"name":"hindu_temple","emoji":"🛕"},{"name":"maté","emoji":"🧉"},{"name":"beverage_box","emoji":"🧃"},{"name":"oyster","emoji":"🦪"},{"name":"butter","emoji":"🧈"},{"name":"falafel","emoji":"🧆"},{"name":"onion","emoji":"🧅"},{"name":"garlic","emoji":"🧄"},{"name":"skunk","emoji":"🦨"},{"name":"guide_dog","emoji":"🦮"},{"name":"people_holding_hands","emoji":"🧑‍🤝‍🧑"},{"name":"woman_in_manual_wheelchair","emoji":"👩‍🦽"},{"name":"man_in_manual_wheelchair","emoji":"👨‍🦽"},{"name":"woman_in_motorized_wheelchair","emoji":"👩‍🦼"},{"name":"man_in_motorized_wheelchair","emoji":"👨‍🦼"},{"name":"woman_with_probing_cane","emoji":"👩‍🦯"},{"name":"man_with_probing_cane","emoji":"👨‍🦯"},{"name":"woman_kneeling","emoji":"🧎‍♀️"},{"name":"man_kneeling","emoji":"🧎‍♂️"},{"name":"man_standing","emoji":"🧍‍♂️"},{"name":"woman_standing","emoji":"🧍‍♀️"},{"name":"deaf_woman","emoji":"🧏‍♀️"},{"name":"deaf_man","emoji":"🧏‍♂️"},{"name":"hear_with_hearing_aid","emoji":"🦻"},{"name":"mechanical_leg","emoji":"🦿"},{"name":"mechanical_arm","emoji":"🦾"},{"name":"white_heart","emoji":"🤍"},{"name":"brown_heart","emoji":"🤎"},{"name":"transgender_flag","emoji":"🏳️‍⚧"},{"name":"smiling_face_with_tear","emoji":"🥲"},{"name":"disguised_face","emoji":"🥸"},{"name":"pinched_fingers","emoji":"🤌"},{"name":"anatomical_heart","emoji":"🫀"},{"name":"lungs","emoji":"🫁"},{"name":"ninja","emoji":"🥷"},{"name":"mx_claus","emoji":"🧑‍🎄"},{"name":"people_hugging","emoji":"🫂"},{"name":"black_cat","emoji":"🐈‍⬛"},{"name":"bison","emoji":"🦬"},{"name":"mammoth","emoji":"🦣"},{"name":"beaver","emoji":"🦫"},{"name":"dodo","emoji":"🦤"},{"name":"feather","emoji":"🪶"},{"name":"seal","emoji":"🦭"},{"name":"beetle","emoji":"🪲"},{"name":"cockroach","emoji":"🪳"},{"name":"fly","emoji":"🪰"},{"name":"worm","emoji":"🪱"},{"name":"potted_plant","emoji":"🪴"},{"name":"blueberries","emoji":"🫐"},{"name":"olive","emoji":"🫒"},{"name":"bell_pepper","emoji":"🫑"},{"name":"flatbread","emoji":"🫓"},{"name":"tamale","emoji":"🫔"},{"name":"fondue","emoji":"🫕"},{"name":"teapot","emoji":"🫖"},{"name":"bubble_tea","emoji":"🧋"},{"name":"rock","emoji":"🪨"},{"name":"wood","emoji":"🪵"},{"name":"hut","emoji":"🛖"},{"name":"pickup_truck","emoji":"🛻"},{"name":"roller_skate","emoji":"🛼"},{"name":"magic_wand","emoji":"🪄"},{"name":"piñata","emoji":"🪅"},{"name":"nesting_dolls","emoji":"🪆"},{"name":"sewing_needle","emoji":"🪡"},{"name":"knot","emoji":"🪢"},{"name":"thong_sandal","emoji":"🩴"},{"name":"military_helmet","emoji":"🪖"},{"name":"accordion","emoji":"🪗"},{"name":"long_drum","emoji":"🪘"},{"name":"coin","emoji":"🪙"},{"name":"boomerang","emoji":"🪃"},{"name":"carpentry_saw","emoji":"🪚"},{"name":"screwdriver","emoji":"🪛"},{"name":"hook","emoji":"🪝"},{"name":"ladder","emoji":"🪜"},{"name":"mirror","emoji":"🪞"},{"name":"window","emoji":"🪟"},{"name":"plunger","emoji":"🪠"},{"name":"mouse_trap","emoji":"🪤"},{"name":"bucket","emoji":"🪣"},{"name":"toothbrush","emoji":"🪥"},{"name":"headstone","emoji":"🪦"},{"name":"placard","emoji":"🪧"},{"name":"transgender_symbol","emoji":"⚧"},{"name":"man_feeding_baby","emoji":"👨‍🍼"},{"name":"person_feeding_baby","emoji":"🧑‍🍼"},{"name":"polar_bear","emoji":"🐻‍❄"},{"name":"melting_face","emoji":"🫠"},{"name":"smiling_face","emoji":"☺"},{"name":"face_with_open_eyes_and_hand_over_mouth","emoji":"🫢"},{"name":"face_with_peeking_eye","emoji":"🫣"},{"name":"saluting_face","emoji":"🫡"},{"name":"dotted_line_face","emoji":"🫥"},{"name":"face_in_clouds","emoji":"😶‍🌫"},{"name":"face_exhaling","emoji":"😮‍💨"},{"name":"face_with_spiral_eyes","emoji":"😵‍💫"},{"name":"face_with_diagonal_mouth","emoji":"🫤"},{"name":"frowning_face","emoji":"☹"},{"name":"face_holding_back_tears","emoji":"🥹"},{"name":"heart_on_fire","emoji":"❤️‍🔥"},{"name":"mending_heart","emoji":"❤️‍🩹"},{"name":"eye_in_speech_bubble","emoji":"👁️‍🗨"},{"name":"rightwards_hand","emoji":"🫱"},{"name":"leftwards_hand","emoji":"🫲"},{"name":"palm_down_hand","emoji":"🫳"},{"name":"palm_up_hand","emoji":"🫴"},{"name":"hand_with_index_finger_and_thumb_crossed","emoji":"🫰"},{"name":"index_pointing_at_the_viewer","emoji":"🫵"},{"name":"heart_hands","emoji":"🫶"},{"name":"biting_lip","emoji":"🫦"},{"name":"man_beard","emoji":"🧔‍♂"},{"name":"woman_beard","emoji":"🧔‍♀"},{"name":"person_red_hair","emoji":"🧑‍🦰"},{"name":"person_curly_hair","emoji":"🧑‍🦱"},{"name":"person_white_hair","emoji":"🧑‍🦳"},{"name":"person_bald","emoji":"🧑‍🦲"},{"name":"man_blond_hair","emoji":"👱‍♂️"},{"name":"person_frowning","emoji":"🙍"},{"name":"person_pouting","emoji":"🙎"},{"name":"person_gesturing_no","emoji":"🙅"},{"name":"person_gesturing_ok","emoji":"🙆"},{"name":"person_tipping_hand","emoji":"💁"},{"name":"person_raising_hand","emoji":"🙋"},{"name":"deaf_person","emoji":"🧏"},{"name":"man_bowing","emoji":"🙇‍♂️"},{"name":"person_facepalming","emoji":"🤦"},{"name":"person_shrugging","emoji":"🤷"},{"name":"health_worker","emoji":"🧑‍⚕️"},{"name":"student","emoji":"🧑‍🎓"},{"name":"teacher","emoji":"🧑‍🏫"},{"name":"judge","emoji":"🧑‍⚖️"},{"name":"farmer","emoji":"🧑‍🌾"},{"name":"cook","emoji":"🧑‍🍳"},{"name":"mechanic","emoji":"🧑‍🔧"},{"name":"factory_worker","emoji":"🧑‍🏭"},{"name":"office_worker","emoji":"🧑‍💼"},{"name":"scientist","emoji":"🧑‍🔬"},{"name":"technologist","emoji":"🧑‍💻"},{"name":"singer","emoji":"🧑‍🎤"},{"name":"artist","emoji":"🧑‍🎨"},{"name":"pilot","emoji":"🧑‍✈️"},{"name":"astronaut","emoji":"🧑‍🚀"},{"name":"firefighter","emoji":"🧑‍🚒"},{"name":"man_police_officer","emoji":"👮‍♂️"},{"name":"man_detective","emoji":"🕵️‍♂️"},{"name":"man_guard","emoji":"💂‍♂️"},{"name":"man_construction_worker","emoji":"👷‍♂️"},{"name":"person_with_crown","emoji":"🫅"},{"name":"man_wearing_turban","emoji":"👳‍♂️"},{"name":"man_in_tuxedo","emoji":"🤵‍♂️"},{"name":"woman_in_tuxedo","emoji":"🤵‍♀️"},{"name":"man_with_veil","emoji":"👰‍♂️"},{"name":"woman_with_veil","emoji":"👰‍♀️"},{"name":"pregnant_man","emoji":"🫃"},{"name":"pregnant_person","emoji":"🫄"},{"name":"woman_feeding_baby","emoji":"👩‍🍼"},{"name":"man_mage","emoji":"🧙‍♂️"},{"name":"man_fairy","emoji":"🧚‍♂️"},{"name":"woman_fairy","emoji":"🧚‍♀️"},{"name":"man_vampire","emoji":"🧛‍♂️"},{"name":"woman_vampire","emoji":"🧛‍♀️"},{"name":"mermaid","emoji":"🧜‍♀️"},{"name":"man_elf","emoji":"🧝‍♂️"},{"name":"woman_elf","emoji":"🧝‍♀️"},{"name":"man_genie","emoji":"🧞‍♂"},{"name":"man_zombie","emoji":"🧟‍♂"},{"name":"troll","emoji":"🧌"},{"name":"person_getting_massage","emoji":"💆"},{"name":"person_getting_haircut","emoji":"💇"},{"name":"man_walking","emoji":"🚶‍♂️"},{"name":"person_standing","emoji":"🧍"},{"name":"person_kneeling","emoji":"🧎"},{"name":"person_with_white_cane","emoji":"🧑‍🦯"},{"name":"person_in_motorized_wheelchair","emoji":"🧑‍🦼"},{"name":"person_in_manual_wheelchair","emoji":"🧑‍🦽"},{"name":"man_running","emoji":"🏃‍♂️"},{"name":"women_with_bunny_ears","emoji":"👯‍♀"},{"name":"man_in_steamy_room","emoji":"🧖‍♂️"},{"name":"man_climbing","emoji":"🧗‍♂️"},{"name":"man_golfing","emoji":"🏌️‍♂️"},{"name":"man_surfing","emoji":"🏄‍♂️"},{"name":"man_rowing_boat","emoji":"🚣‍♂️"},{"name":"man_swimming","emoji":"🏊‍♂️"},{"name":"man_bouncing_ball","emoji":"⛹️‍♂️"},{"name":"man_lifting_weights","emoji":"🏋️‍♂️"},{"name":"man_biking","emoji":"🚴‍♂️"},{"name":"man_mountain_biking","emoji":"🚵‍♂️"},{"name":"person_cartwheeling","emoji":"🤸"},{"name":"people_wrestling","emoji":"🤼"},{"name":"person_playing_water_polo","emoji":"🤽"},{"name":"person_playing_handball","emoji":"🤾"},{"name":"person_juggling","emoji":"🤹"},{"name":"man_in_lotus_position","emoji":"🧘‍♂️"},{"name":"kiss_woman_man","emoji":"👩‍❤️‍💋‍👨"},{"name":"couple_with_heart_woman_man","emoji":"👩‍❤️‍👨"},{"name":"family_man_woman_boy","emoji":"👨‍👩‍👦"},{"name":"red_hair","emoji":"🦰"},{"name":"curly_hair","emoji":"🦱"},{"name":"white_hair","emoji":"🦳"},{"name":"bald","emoji":"🦲"},{"name":"coral","emoji":"🪸"},{"name":"lotus","emoji":"🪷"},{"name":"empty_nest","emoji":"🪹"},{"name":"nest_with_eggs","emoji":"🪺"},{"name":"beans","emoji":"🫘"},{"name":"pouring_liquid","emoji":"🫗"},{"name":"jar","emoji":"🫙"},{"name":"playground_slide","emoji":"🛝"},{"name":"wheel","emoji":"🛞"},{"name":"ring_buoy","emoji":"🛟"},{"name":"hamsa","emoji":"🪬"},{"name":"mirror_ball","emoji":"🪩"},{"name":"low_battery","emoji":"🪫"},{"name":"crutch","emoji":"🩼"},{"name":"xray","emoji":"🩻"},{"name":"elevator","emoji":"🛗"},{"name":"bubbles","emoji":"🫧"},{"name":"identification_card","emoji":"🪪"},{"name":"eject_button","emoji":"⏏"},{"name":"female_sign","emoji":"♀"},{"name":"male_sign","emoji":"♂"},{"name":"heavy_equals_sign","emoji":"🟰"},{"name":"medical_symbol","emoji":"⚕"},{"name":"england","emoji":"🏴󠁧󠁢󠁥󠁮󠁧󠁿"},{"name":"scotland","emoji":"🏴󠁧󠁢󠁳󠁣󠁴󠁿"},{"name":"wales","emoji":"🏴󠁧󠁢󠁷󠁬󠁳󠁿"}]'), cr = mr, ur = _t({
  name: "emoji",
  char: ":",
  pluginKey: new Me("emojiSuggestion"),
  items: ({ query: e }) => cr.filter(
    (t) => t.name.toLowerCase().includes(e.toLowerCase())
  ).sort((t, n) => {
    const a = t.name.toLowerCase(), o = n.name.toLowerCase(), i = e.toLowerCase();
    return a === i && o !== i ? -1 : o === i && a !== i ? 1 : a.startsWith(i) && !o.startsWith(i) ? -1 : o.startsWith(i) && !a.startsWith(i) ? 1 : a.length - o.length;
  }).slice(0, 5),
  command: ({ editor: e, range: t, props: n }) => {
    n && n.emoji ? e.chain().focus().deleteRange(t).insertContent(n.emoji).run() : console.error(
      "Emoji command execution error: emoji property not found on selected item or item is invalid.",
      n
    );
  },
  component: lr
}), dr = (e) => {
  const t = Ue(0), n = So();
  let a = () => {
  };
  Le(
    () => ot(e.runtime),
    (s) => {
      a(), a = (s == null ? void 0 : s.subscribe(() => {
        t.value++;
      })) ?? (() => {
      }), t.value++;
    },
    { immediate: !0, flush: "sync" }
  ), Mn(() => a());
  const o = R(() => {
    var s;
    return t.value, (s = ot(e.runtime)) == null ? void 0 : s.getSnapshot().bindings.find((l) => l.id === e.bindingId);
  }), i = R(() => {
    const s = ot(e.runtime), l = o.value;
    return !s || !(l != null && l.bindingEnabled) ? { label: "", ariaLabel: "" } : n.formatMany(l.configuredShortcut, {
      platform: s.platform
    });
  });
  return {
    view: o,
    text: R(() => i.value.label),
    aria: R(() => i.value.ariaLabel)
  };
}, pr = ["onClick", "onMouseover"], fr = /* @__PURE__ */ ke({
  __name: "SlashCommandsList",
  props: {
    items: {
      type: Array,
      required: !0
    },
    editor: {
      type: Object,
      required: !0
    },
    range: {
      type: Object,
      required: !0
    },
    command: {
      type: Function,
      required: !0
    },
    query: String,
    loading: {
      type: Boolean,
      default: !1
    }
  },
  setup(e, { expose: t }) {
    const n = e, a = xe("text-editor-suggestion"), o = Go(!0), { text: i } = Gn(), s = {
      recent: "Recently used",
      ai: "AI",
      basic: "Basic blocks",
      media: "Media",
      advanced: "Advanced"
    }, l = (v) => {
      var C, k;
      const w = (C = n.items[v]) == null ? void 0 : C.group;
      return !w || w === ((k = n.items[v - 1]) == null ? void 0 : k.group) ? null : i(`slash-group:${w}`, s[w] ?? w);
    }, m = dr({
      runtime: () => {
        var v;
        return (v = Ks(n.editor)) == null ? void 0 : v.runtime;
      },
      bindingId: "textEditor.askAI.open"
    }), c = (v) => v.shortcutBindingId === "textEditor.askAI.open" ? m.text.value : v.shortcut ?? "", u = S(0), j = S(null), f = S([]);
    Ln(() => {
      f.value = [];
    });
    const g = (v) => {
      v && n.command(v);
    }, h = () => {
      Ae(() => {
        const v = f.value[u.value];
        v && v.scrollIntoView({ block: "nearest" });
      });
    }, p = (v) => {
      const w = n.items[v];
      w && g(w);
    }, x = ({ event: v }) => n.items.length ? v.key === "ArrowUp" ? (u.value = (u.value + n.items.length - 1) % n.items.length, h(), !0) : v.key === "ArrowDown" ? (u.value = (u.value + 1) % n.items.length, h(), !0) : v.key === "Enter" ? (p(u.value), !0) : !1 : !1;
    return Le(
      () => n.items,
      () => {
        u.value = 0;
      }
    ), t({
      onKeyDown: x
    }), (v, w) => n.items.length || n.loading ? (L(), A("div", {
      key: 0,
      ref_key: "container",
      ref: j,
      class: d([r(a).b(), r(a).m("rich")]),
      style: De({ zIndex: r(o) })
    }, [
      n.loading ? (L(), A("div", {
        key: 0,
        class: d(r(a).e("loading")),
        "aria-live": "polite"
      }, " Loading... ", 2)) : V("", !0),
      (L(!0), A(ve, null, Pe(n.items, (C, k) => (L(), A(ve, { key: k }, [
        l(k) ? (L(), A("div", {
          key: 0,
          class: d(r(a).e("group-title"))
        }, Q(l(k)), 3)) : V("", !0),
        b("button", {
          ref_for: !0,
          ref: (y) => {
            y && (f.value[k] = y);
          },
          class: d([r(a).e("item"), r(a).is("selected", k === u.value)]),
          onClick: (y) => p(k),
          onMouseover: (y) => u.value = k
        }, [
          b("span", {
            class: d(r(a).e("item-icon-shell"))
          }, [
            C.icon ? (L(), Ce(r(te), {
              key: 0,
              icon: C.icon,
              class: d(r(a).e("item-icon"))
            }, null, 8, ["icon", "class"])) : V("", !0)
          ], 2),
          b("span", {
            class: d(r(a).e("item-body"))
          }, [
            b("span", {
              class: d(r(a).e("item-title"))
            }, Q(r(i)(C.id && `slash:${C.id}`, C.title)), 3),
            C.description ? (L(), A("span", {
              key: 0,
              class: d(r(a).e("item-description"))
            }, Q(r(i)(C.id && `slash:${C.id}:description`, C.description)), 3)) : V("", !0)
          ], 2),
          c(C) ? (L(), A("kbd", {
            key: 0,
            class: d(r(a).e("shortcut"))
          }, Q(c(C)), 3)) : V("", !0)
        ], 42, pr)
      ], 64))), 128))
    ], 6)) : V("", !0);
  }
}), gr = (e) => e.trim().toLowerCase(), hr = (e, t) => {
  const n = gr(t);
  return n ? [
    e.title,
    e.description,
    ...e.aliases ?? [],
    ...e.keywords ?? []
  ].filter((o) => typeof o == "string").map((o) => o.toLowerCase()).some(
    (o) => o.startsWith(n) || o.includes(n) || n.includes(o)
  ) : !0;
}, jr = (e, t, n) => e.filter(
  (a) => (!n || (a.requiredCapabilities ?? []).every(
    (o) => n.has(o)
  )) && hr(a, t)
), vr = (e) => ({
  id: e.id,
  title: e.title,
  description: e.description,
  icon: e.icon,
  aliases: e.aliases ? [...e.aliases] : void 0,
  keywords: e.keywords ? [...e.keywords] : void 0,
  shortcut: e.shortcut,
  shortcutBindingId: e.shortcutBindingId,
  group: e.group,
  priority: e.priority,
  requiredCapabilities: e.requiredCapabilities,
  command: e.command
}), br = (e, t = []) => {
  const n = /* @__PURE__ */ new Map();
  e.forEach((a, o) => {
    const i = `builtin:${a.title}:${o}`;
    n.set(i, { ...a, priority: o });
  });
  for (const a of t)
    n.set(
      `contribution:${a.id}`,
      vr(a)
    );
  return [...n.values()].sort(
    (a, o) => (a.priority ?? 0) - (o.priority ?? 0)
  );
}, Zn = "zx-text-editor:slash-recents", Yn = 5, _r = "recent", Jn = (e) => e.id ?? e.title, Qn = () => {
  var e;
  try {
    const t = (e = globalThis.localStorage) == null ? void 0 : e.getItem(Zn);
    if (!t) return [];
    const n = JSON.parse(t);
    return Array.isArray(n) ? n.filter((a) => typeof a == "string").slice(0, Yn) : [];
  } catch {
    return [];
  }
}, yr = (e) => {
  var t;
  try {
    const n = Jn(e), a = [n, ...Qn().filter((o) => o !== n)];
    (t = globalThis.localStorage) == null || t.setItem(
      Zn,
      JSON.stringify(a.slice(0, Yn))
    );
  } catch {
  }
}, wr = (e, t) => {
  if (t.trim()) return [...e];
  const n = Qn();
  if (n.length === 0) return [...e];
  const a = new Map(e.map((s) => [Jn(s), s])), o = n.map((s) => a.get(s)).filter((s) => s !== void 0);
  if (o.length === 0) return [...e];
  const i = new Set(o);
  return [
    ...o.map((s) => ({ ...s, group: _r })),
    ...e.filter((s) => !i.has(s))
  ];
}, kr = new Me(
  "slashCommandSuggestion"
), Cr = (e) => {
  var t, n;
  return ((n = (t = e.extensionManager.extensions.find(
    (a) => a.name === "slashCommands"
  )) == null ? void 0 : t.options) == null ? void 0 : n.codeBlockPreferences) ?? null;
}, xr = (e, t, n) => {
  const a = e.state.doc, o = Math.min(Math.max(t.from, 1), a.content.size);
  let i = null;
  a.descendants((c, u) => {
    if (c.type.name !== "heading" || c.attrs.level !== n)
      return !0;
    const j = u + 1, f = u + Math.max(1, c.nodeSize - 1), g = Math.min(Math.max(o, j), f), h = Math.abs(g - o);
    return (!i || h < i.distance || h === i.distance && u > i.pos) && (i = { distance: h, pos: u, nodeSize: c.nodeSize }), !0;
  });
  const s = i;
  if (!s)
    return null;
  const l = s.pos + 1, m = s.pos + Math.max(1, s.nodeSize - 1);
  return Math.min(Math.max(o, l), m);
}, dt = (e) => ({ editor: t, range: n }) => {
  t.chain().focus().deleteRange(n).setHeading({ level: e }).command(() => {
    const a = xr(t, n, e);
    if (a === null)
      return !0;
    const o = t.state.tr.setSelection(
      Ke.create(t.state.doc, a)
    );
    return t.view.dispatch(o), !0;
  }).run();
}, Er = () => [
  // 标题 - 文档结构最基础
  {
    id: "heading-1",
    title: "Heading 1",
    description: "Large section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h1", "title", "标题", "biaoti", "yijibiaoti"],
    icon: "lucide:heading-1",
    command: dt(1)
  },
  {
    id: "heading-2",
    title: "Heading 2",
    description: "Medium section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h2", "标题", "biaoti", "erjibiaoti"],
    icon: "lucide:heading-2",
    command: dt(2)
  },
  {
    id: "heading-3",
    title: "Heading 3",
    description: "Small section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h3", "标题", "biaoti", "sanjibiaoti"],
    icon: "lucide:heading-3",
    command: dt(3)
  },
  {
    id: "heading-4",
    title: "Heading 4",
    description: "Smallest section heading",
    group: "basic",
    requiredCapabilities: ["block-style.heading"],
    aliases: ["h4", "标题", "biaoti"],
    icon: "lucide:heading-4",
    command: dt(4)
  },
  // 列表 - 内容组织高频操作
  {
    id: "bullet-list",
    title: "Bullet List",
    description: "Simple bulleted list",
    group: "basic",
    requiredCapabilities: ["list.bullet"],
    aliases: ["ul", "unordered", "无序列表", "liebiao", "wuxuliebiao"],
    icon: "lucide:list",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleBulletList().run();
    }
  },
  {
    id: "ordered-list",
    title: "Numbered List",
    description: "Ordered list with numbers",
    group: "basic",
    requiredCapabilities: ["list.ordered"],
    aliases: ["ol", "ordered", "有序列表", "youxuliebiao"],
    icon: "lucide:list-ordered",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleOrderedList().run();
    }
  },
  {
    id: "task-list",
    title: "Task List",
    description: "Checklist with checkboxes",
    group: "basic",
    requiredCapabilities: ["list.task"],
    aliases: ["todo", "checkbox", "待办", "daiban", "renwuliebiao"],
    icon: "lucide:list-checks",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleTaskList().run();
    }
  },
  // Toggle (折叠块)
  {
    id: "toggle-list",
    title: "Toggle List",
    description: "Collapsible content block",
    group: "basic",
    requiredCapabilities: ["block-style.toggle"],
    aliases: ["collapse", "fold", "折叠", "zhedie"],
    icon: "lucide:chevron-right",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setToggle().run();
    }
  },
  // 引用与分隔
  {
    id: "blockquote",
    title: "Blockquote",
    description: "Capture a quote",
    group: "basic",
    requiredCapabilities: ["block-style.blockquote"],
    aliases: ["quote", "cite", "引用", "yinyong"],
    icon: "lucide:quote",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).toggleBlockquote().run();
    }
  },
  {
    id: "horizontal-rule",
    title: "Horizontal Rule",
    description: "Visual divider line",
    group: "basic",
    requiredCapabilities: ["insert.horizontal-rule"],
    aliases: ["hr", "divider", "分割线", "fengexian"],
    icon: "lucide:minus",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setHorizontalRule().run();
    }
  },
  // 媒体插入
  {
    id: "image",
    title: "Image",
    description: "Upload or embed an image",
    group: "media",
    requiredCapabilities: ["insert.image"],
    aliases: ["img", "photo", "picture", "图片", "tupian"],
    icon: "lucide:image",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).selectAndUploadImage().run();
    }
  },
  {
    id: "video",
    title: "Video",
    description: "Upload or embed a video",
    group: "media",
    requiredCapabilities: ["insert.video"],
    aliases: ["movie", "视频", "shipin"],
    icon: "lucide:video",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).selectAndUploadVideo().run();
    }
  },
  // 代码
  {
    id: "code-block",
    title: "Code Block",
    description: "Code snippet with highlighting",
    group: "advanced",
    requiredCapabilities: ["block-style.code-block"],
    aliases: ["```", "snippet", "代码", "daima", "daimakuai"],
    icon: "lucide:code",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).insertContent(
        wn({
          source: "slash",
          preferences: Cr(e)
        })
      ).run();
    }
  },
  // 链接
  {
    id: "link",
    title: "Link",
    description: "Link to a web page",
    group: "advanced",
    requiredCapabilities: ["insert.link"],
    aliases: ["url", "href", "链接", "lianjie"],
    icon: "lucide:link",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).run(), vt(e).openLinkEditor();
    }
  },
  // 表格
  {
    id: "table",
    title: "Table",
    description: "Insert a 3×3 table",
    group: "advanced",
    requiredCapabilities: ["insert.table"],
    aliases: ["grid", "表格", "biaoge"],
    icon: "lucide:table-2",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).insertTable({ rows: 3, cols: 3, withHeaderRow: !0 }).run();
    }
  },
  // 嵌入 - 相对低频
  {
    id: "embed",
    title: "Embed",
    description: "Embed an external page",
    group: "advanced",
    requiredCapabilities: ["insert.iframe"],
    aliases: ["iframe", "嵌入", "qianru"],
    icon: "lucide:gallery-vertical",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).openIframeDialog().run();
    }
  },
  // 对齐 - 低频格式化，收尾
  {
    id: "align-left",
    title: "Align Left",
    description: "Align block text left",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["left", "左对齐", "zuoduiqi"],
    icon: "lucide:align-left",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("left").run();
    }
  },
  {
    id: "align-center",
    title: "Align Center",
    description: "Center block text",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["center", "居中", "juzhong"],
    icon: "lucide:align-center",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("center").run();
    }
  },
  {
    id: "align-right",
    title: "Align Right",
    description: "Align block text right",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["right", "右对齐", "youduiqi"],
    icon: "lucide:align-right",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("right").run();
    }
  },
  {
    id: "align-justify",
    title: "Align Justify",
    description: "Justify block text",
    group: "advanced",
    requiredCapabilities: ["alignment"],
    aliases: ["justify", "两端对齐", "liangduanduiqi"],
    icon: "lucide:align-justify",
    command: ({ editor: e, range: t }) => {
      e.chain().focus().deleteRange(t).setTextAlign("justify").run();
    }
  }
], Tr = (e, t, n) => wr(
  jr(
    br(
      Er(),
      (e == null ? void 0 : e.catalogContributions) ?? []
    ),
    t,
    n
  ),
  t
), Lr = _t({
  name: "slashCommands",
  char: "/",
  pluginKey: kr,
  addOptions: () => ({
    codeBlockPreferences: null,
    catalogContributions: null
  }),
  items: ({ query: e, editor: t }) => {
    var a;
    const n = (a = t.extensionManager.extensions.find(
      (o) => o.name === "slashCommands"
    )) == null ? void 0 : a.options;
    return Tr(
      n,
      e,
      Ma(t)
    );
  },
  command: ({ editor: e, range: t, props: n }) => {
    n && typeof n.command == "function" && (yr(n), n.command({ editor: e, range: t }));
  },
  component: fr
});
function Ir(e) {
  return e.split(`
`).filter(
    (a) => (
      // check for inline markdown content like images, links, italic, bold, etc.
      /!\[.*\]\(.*\)/.test(a) || /\[.*\]\(.*\)/.test(a) || /(^|\s)\*.*\*(\s|$)/.test(a) || /(^|\s)_.*_(\s|$)/.test(a) || /(^|\s)\*\*.*\*\*(\s|$)/.test(a) || /(^|\s)__.*__(\s|$)/.test(a) || /(^|\s)~~.*~~(\s|$)/.test(a) || // check for block markdown content like headings, code blocks, lists, etc.
      a.startsWith("![") || a.startsWith("#") || a.startsWith("> ") || a.startsWith("*") || a.startsWith("- ") || a.startsWith("1. ") || a.startsWith("|") || a.startsWith("```") || a.startsWith("`") || a.startsWith("[") || a.startsWith("---")
    )
  ).length > 0;
}
const Sr = (e) => {
  var a;
  const { $from: t } = e.selection;
  let n = t.depth;
  for (; n > 0; ) {
    if (((a = t.node(n).type) == null ? void 0 : a.name) === "codeBlock")
      return !0;
    n -= 1;
  }
  return !1;
}, Ar = (e) => {
  var t;
  return e ? (t = e.files) != null && t.length ? !0 : Array.from(e.items ?? []).some(
    (n) => n.kind === "file"
  ) : !1;
}, Pr = qe.create({
  name: "contentPaste",
  addOptions() {
    return {
      enabled: !0,
      filePlatformRuntime: null,
      codeBlockPreferences: null
    };
  },
  addProseMirrorPlugins() {
    return [
      new Ne({
        key: new Me("contentPaste"),
        props: {
          handleDOMEvents: {
            copy: (e, t) => {
              var i, s;
              const n = window.getSelection();
              if (!n) return !1;
              const a = document.createElement("div");
              for (let l = 0; l < n.rangeCount; l++)
                a.appendChild(n.getRangeAt(l).cloneContents());
              return a.querySelectorAll("img").forEach((l) => {
                const m = l.getAttribute("src");
                m && m.startsWith("/") && l.setAttribute("src", `${window.location.origin}${m}`);
              }), (i = t.clipboardData) == null || i.setData("text/html", a.innerHTML), (s = t.clipboardData) == null || s.setData("text/plain", n.toString()), t.preventDefault(), !0;
            }
          },
          handlePaste: (e, t, n) => {
            var c, u;
            if (!this.options.enabled || this.options.filePlatformRuntime && Ar(t.clipboardData))
              return !1;
            const a = (c = t.clipboardData) == null ? void 0 : c.getData("text/html");
            if (a && /<(?:img|iframe|video)\b/i.test(a) && this.options.filePlatformRuntime)
              return Promise.resolve(
                this.options.filePlatformRuntime.intakeFiles({
                  source: "paste",
                  files: [],
                  htmlContent: a
                })
              ).catch((j) => {
                var f;
                (f = this.options.filePlatformRuntime) == null || f.emitDiagnostic({
                  code: "paste-html-media-intake-dispatch-failed",
                  message: j instanceof Error ? j.message : "Failed to dispatch HTML media paste through unified intake.",
                  severity: "error",
                  stage: "intake",
                  cause: j
                });
              }), !0;
            const o = (u = t.clipboardData) == null ? void 0 : u.getData("text/plain");
            if (!o) return !1;
            if (!Ir(o)) {
              if (Sr(e.state) || yi(o).kind !== "code-block")
                return !1;
              const f = e.state.schema.nodeFromJSON(
                wn({
                  code: o,
                  source: "paste",
                  preferences: this.options.codeBlockPreferences
                })
              );
              return e.dispatch(
                e.state.tr.replaceSelectionWith(f, !1).scrollIntoView()
              ), !0;
            }
            const i = Da(
              Ra(o),
              "paste"
            ), s = e.state.schema.nodeFromJSON(i), l = new _a(s.content, 0, 0), m = e.state.tr.replaceSelection(l);
            return e.dispatch(m), !0;
          }
        }
      })
    ];
  }
}), ea = (e, t) => e.selection.empty ? !1 : (t && t(e.tr.deleteSelection().scrollIntoView()), !0);
function Mr(e, t) {
  let { $cursor: n } = e.selection;
  return !n || (t ? !t.endOfTextblock("backward", e) : n.parentOffset > 0) ? null : n;
}
const Dr = (e, t, n) => {
  let a = Mr(e, n);
  if (!a)
    return !1;
  let o = ta(a);
  if (!o) {
    let s = a.blockRange(), l = s && Ot(s);
    return l == null ? !1 : (t && t(e.tr.lift(s, l).scrollIntoView()), !0);
  }
  let i = o.nodeBefore;
  if (aa(e, o, t, -1))
    return !0;
  if (a.parent.content.size == 0 && (Qe(i, "end") || Be.isSelectable(i)))
    for (let s = a.depth; ; s--) {
      let l = Nn(e.doc, a.before(s), a.after(s), jt.empty);
      if (l && l.slice.size < l.to - l.from) {
        if (t) {
          let m = e.tr.step(l);
          m.setSelection(Qe(i, "end") ? Te.findFrom(m.doc.resolve(m.mapping.map(o.pos, -1)), -1) : Be.create(m.doc, o.pos - i.nodeSize)), t(m.scrollIntoView());
        }
        return !0;
      }
      if (s == 1 || a.node(s - 1).childCount > 1)
        break;
    }
  return i.isAtom && o.depth == a.depth - 1 ? (t && t(e.tr.delete(o.pos - i.nodeSize, o.pos).scrollIntoView()), !0) : !1;
};
function Qe(e, t, n = !1) {
  for (let a = e; a; a = t == "start" ? a.firstChild : a.lastChild) {
    if (a.isTextblock)
      return !0;
    if (n && a.childCount != 1)
      return !1;
  }
  return !1;
}
const Rr = (e, t, n) => {
  let { $head: a, empty: o } = e.selection, i = a;
  if (!o)
    return !1;
  if (a.parent.isTextblock) {
    if (n ? !n.endOfTextblock("backward", e) : a.parentOffset > 0)
      return !1;
    i = ta(a);
  }
  let s = i && i.nodeBefore;
  return !s || !Be.isSelectable(s) ? !1 : (t && t(e.tr.setSelection(Be.create(e.doc, i.pos - s.nodeSize)).scrollIntoView()), !0);
};
function ta(e) {
  if (!e.parent.type.spec.isolating)
    for (let t = e.depth - 1; t >= 0; t--) {
      if (e.index(t) > 0)
        return e.doc.resolve(e.before(t + 1));
      if (e.node(t).type.spec.isolating)
        break;
    }
  return null;
}
function Or(e, t) {
  let { $cursor: n } = e.selection;
  return !n || (t ? !t.endOfTextblock("forward", e) : n.parentOffset < n.parent.content.size) ? null : n;
}
const Nr = (e, t, n) => {
  let a = Or(e, n);
  if (!a)
    return !1;
  let o = na(a);
  if (!o)
    return !1;
  let i = o.nodeAfter;
  if (aa(e, o, t, 1))
    return !0;
  if (a.parent.content.size == 0 && (Qe(i, "start") || Be.isSelectable(i))) {
    let s = Nn(e.doc, a.before(), a.after(), jt.empty);
    if (s && s.slice.size < s.to - s.from) {
      if (t) {
        let l = e.tr.step(s);
        l.setSelection(Qe(i, "start") ? Te.findFrom(l.doc.resolve(l.mapping.map(o.pos)), 1) : Be.create(l.doc, l.mapping.map(o.pos))), t(l.scrollIntoView());
      }
      return !0;
    }
  }
  return i.isAtom && o.depth == a.depth - 1 ? (t && t(e.tr.delete(o.pos, o.pos + i.nodeSize).scrollIntoView()), !0) : !1;
}, $r = (e, t, n) => {
  let { $head: a, empty: o } = e.selection, i = a;
  if (!o)
    return !1;
  if (a.parent.isTextblock) {
    if (n ? !n.endOfTextblock("forward", e) : a.parentOffset < a.parent.content.size)
      return !1;
    i = na(a);
  }
  let s = i && i.nodeAfter;
  return !s || !Be.isSelectable(s) ? !1 : (t && t(e.tr.setSelection(Be.create(e.doc, i.pos)).scrollIntoView()), !0);
};
function na(e) {
  if (!e.parent.type.spec.isolating)
    for (let t = e.depth - 1; t >= 0; t--) {
      let n = e.node(t);
      if (e.index(t) + 1 < n.childCount)
        return e.doc.resolve(e.after(t + 1));
      if (n.type.spec.isolating)
        break;
    }
  return null;
}
const zr = (e, t) => {
  let { $head: n, $anchor: a } = e.selection;
  return !n.parent.type.spec.code || !n.sameParent(a) ? !1 : (t && t(e.tr.insertText(`
`).scrollIntoView()), !0);
};
function Bt(e) {
  for (let t = 0; t < e.edgeCount; t++) {
    let { type: n } = e.edge(t);
    if (n.isTextblock && !n.hasRequiredAttrs())
      return n;
  }
  return null;
}
const fn = (e, t) => {
  let { $head: n, $anchor: a } = e.selection;
  if (!n.parent.type.spec.code || !n.sameParent(a))
    return !1;
  let o = n.node(-1), i = n.indexAfter(-1), s = Bt(o.contentMatchAt(i));
  if (!s || !o.canReplaceWith(i, i, s))
    return !1;
  if (t) {
    let l = n.after(), m = e.tr.replaceWith(l, l, s.createAndFill());
    m.setSelection(Te.near(m.doc.resolve(l), 1)), t(m.scrollIntoView());
  }
  return !0;
}, Br = (e, t) => {
  let n = e.selection, { $from: a, $to: o } = n;
  if (n instanceof zn || a.parent.inlineContent || o.parent.inlineContent)
    return !1;
  let i = Bt(o.parent.contentMatchAt(o.indexAfter()));
  if (!i || !i.isTextblock)
    return !1;
  if (t) {
    let s = (!a.parentOffset && o.index() < o.parent.childCount ? a : o).pos, l = e.tr.insert(s, i.createAndFill());
    l.setSelection(Xe.create(l.doc, s + 1)), t(l.scrollIntoView());
  }
  return !0;
}, Fr = (e, t) => {
  let { $cursor: n } = e.selection;
  if (!n || n.parent.content.size)
    return !1;
  if (n.depth > 1 && n.after() != n.end(-1)) {
    let i = n.before();
    if (ft(e.doc, i))
      return t && t(e.tr.split(i).scrollIntoView()), !0;
  }
  let a = n.blockRange(), o = a && Ot(a);
  return o == null ? !1 : (t && t(e.tr.lift(a, o).scrollIntoView()), !0);
};
function Hr(e) {
  return (t, n) => {
    if (t.selection instanceof Be && t.selection.node.isBlock) {
      let { $from: g } = t.selection;
      return !g.parentOffset || !ft(t.doc, g.pos) ? !1 : (n && n(t.tr.split(g.pos).scrollIntoView()), !0);
    }
    if (!t.selection.$from.depth)
      return !1;
    let a = t.tr;
    !t.selection.empty && (t.selection instanceof Xe || t.selection instanceof zn) && a.deleteSelection();
    let { $from: o } = a.selection, i = a.steps.length, s = [], l, m, c = !1, u = !1;
    for (let g = o.depth; ; g--)
      if (o.node(g).isBlock) {
        c = o.end(g) == o.pos + (o.depth - g), u = o.start(g) == o.pos - (o.depth - g), m = Bt(o.node(g - 1).contentMatchAt(o.indexAfter(g - 1))), s.unshift(c && m ? { type: m } : null), l = g;
        break;
      } else {
        if (g == 1)
          return !1;
        s.unshift(null);
      }
    let j = o.pos, f = ft(a.doc, j, s.length, s);
    if (f || (s[0] = m ? { type: m } : null, f = ft(a.doc, j, s.length, s)), !f)
      return !1;
    if (a.split(j, s.length, s), !c && u && o.node(l).type != m) {
      let g = a.mapping.slice(i), h = g.map(o.before(l)), p = a.doc.resolve(h);
      m && o.node(l - 1).canReplaceWith(p.index(), p.index() + 1, m) && a.setNodeMarkup(g.map(o.before(l)), m);
    }
    return n && n(a.scrollIntoView()), !0;
  };
}
const Vr = Hr();
function qr(e, t, n) {
  let a = t.nodeBefore, o = t.nodeAfter, i = t.index();
  return !a || !o || !a.type.compatibleContent(o.type) ? !1 : !a.content.size && t.parent.canReplace(i - 1, i) ? (n && n(e.tr.delete(t.pos - a.nodeSize, t.pos).scrollIntoView()), !0) : !t.parent.canReplace(i, i + 1) || !(o.isTextblock || $n(e.doc, t.pos)) ? !1 : (n && n(e.tr.join(t.pos).scrollIntoView()), !0);
}
function aa(e, t, n, a) {
  let o = t.nodeBefore, i = t.nodeAfter, s, l, m = o.type.spec.isolating || i.type.spec.isolating;
  if (!m && qr(e, t, n))
    return !0;
  let c = !m && t.parent.canReplace(t.index(), t.index() + 1);
  if (c && (s = (l = o.contentMatchAt(o.childCount)).findWrapping(i.type)) && l.matchType(s[0] || i.type).validEnd) {
    if (n) {
      let g = t.pos + i.nodeSize, h = tt.empty;
      for (let v = s.length - 1; v >= 0; v--)
        h = tt.from(s[v].create(null, h));
      h = tt.from(o.copy(h));
      let p = e.tr.step(new nn(t.pos - 1, g, t.pos, g, new jt(h, 1, 0), s.length, !0)), x = p.doc.resolve(g + 2 * s.length);
      x.nodeAfter && x.nodeAfter.type == o.type && $n(p.doc, x.pos) && p.join(x.pos), n(p.scrollIntoView());
    }
    return !0;
  }
  let u = i.type.spec.isolating || a > 0 && m ? null : Te.findFrom(t, 1), j = u && u.$from.blockRange(u.$to), f = j && Ot(j);
  if (f != null && f >= t.depth)
    return n && n(e.tr.lift(j, f).scrollIntoView()), !0;
  if (c && Qe(i, "start", !0) && Qe(o, "end")) {
    let g = o, h = [];
    for (; h.push(g), !g.isTextblock; )
      g = g.lastChild;
    let p = i, x = 1;
    for (; !p.isTextblock; p = p.firstChild)
      x++;
    if (g.canReplace(g.childCount, g.childCount, p.content)) {
      if (n) {
        let v = tt.empty;
        for (let C = h.length - 1; C >= 0; C--)
          v = tt.from(h[C].copy(v));
        let w = e.tr.step(new nn(t.pos - h.length, t.pos + i.nodeSize, t.pos + x, t.pos + i.nodeSize - x, new jt(v, h.length, 0), 0, !0));
        n(w.scrollIntoView());
      }
      return !0;
    }
  }
  return !1;
}
function Ft(...e) {
  return function(t, n, a) {
    for (let o = 0; o < e.length; o++)
      if (e[o](t, n, a))
        return !0;
    return !1;
  };
}
Ft(ea, Dr, Rr);
Ft(ea, Nr, $r);
Ft(zr, Br, Fr, Vr);
typeof navigator < "u" ? /Mac|iP(hone|[oa]d)/.test(navigator.platform) : typeof os < "u" && os.platform && os.platform() == "darwin";
const Wr = ["aria-label"], Ur = ["aria-label"], Kr = /* @__PURE__ */ ke({
  name: "CodeBlockCollapsedProjection",
  __name: "code-block-collapsed-projection",
  props: {
    lines: {},
    lineNumbers: {},
    totalLineCount: {},
    showLineNumbers: { type: Boolean }
  },
  emits: ["request-expand"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = xe("code-block"), i = R(() => {
      const s = Math.max(1, n.totalLineCount), l = Math.min(s, Math.max(1, n.lines.length));
      return l < s ? `显示前 ${l} 行，共 ${s} 行` : `共 ${s} 行`;
    });
    return (s, l) => (L(), A("div", {
      class: d(r(o).e("collapsed-projection")),
      contenteditable: "false",
      role: "region",
      "aria-label": i.value,
      "data-zx-code-block-collapsed-projection": "true"
    }, [
      b("div", {
        class: d(r(o).e("collapsed-lines"))
      }, [
        (L(!0), A(ve, null, Pe(e.lines, (m, c) => (L(), A("div", {
          key: `${e.lineNumbers[c] ?? c}:${c}`,
          class: d(r(o).e("collapsed-line"))
        }, [
          e.showLineNumbers ? (L(), A("span", {
            key: 0,
            class: d(r(o).e("collapsed-line-number")),
            "aria-hidden": "true"
          }, Q(e.lineNumbers[c] ?? c + 1), 3)) : V("", !0),
          b("code", {
            class: d(r(o).e("collapsed-code"))
          }, Q(m), 3)
        ], 2))), 128))
      ], 2),
      b("button", {
        class: d(r(o).e("collapsed-expand")),
        type: "button",
        "aria-label": `展开代码块编辑，${i.value}`,
        onMousedown: l[0] || (l[0] = N(() => {
        }, ["prevent"])),
        onClick: l[1] || (l[1] = (m) => a("request-expand"))
      }, [
        l[2] || (l[2] = b("span", null, "展开编辑", -1)),
        b("span", {
          class: d(r(o).e("collapsed-summary"))
        }, Q(i.value), 3)
      ], 42, Ur)
    ], 10, Wr));
  }
}), Xr = kn(Cn), Gr = (e) => Array.isArray(e) ? e.filter((t) => typeof t == "string") : typeof e == "string" ? e.split(/\s+/).filter(Boolean) : [], gn = (e) => Bn(e).split(`
`).map(
  (t) => t ? [
    {
      text: t,
      classNames: []
    }
  ] : []
), Zr = (e, t) => {
  const n = Bn(e), a = ii(t).id;
  if (!a || a === "plaintext")
    return gn(n);
  let o;
  try {
    o = Xr.highlight(
      a,
      n
    );
  } catch {
    return gn(n);
  }
  const i = [[]], s = (m, c) => {
    const u = m.split(`
`);
    u.forEach((j, f) => {
      j && i[i.length - 1].push({ text: j, classNames: c }), f < u.length - 1 && i.push([]);
    });
  }, l = (m, c) => {
    var f, g;
    const u = Gr((f = m.properties) == null ? void 0 : f.className), j = u.length ? [.../* @__PURE__ */ new Set([...c, ...u])] : c;
    m.type === "text" && typeof m.value == "string" && s(m.value, j), (g = m.children) == null || g.forEach((h) => l(h, j));
  };
  return l(o, []), i;
}, Yr = ["data-zx-fold-row-offset"], Jr = ["aria-label", "onClick"], Qr = /* @__PURE__ */ ke({
  __name: "code-block-folded-projection",
  props: {
    rows: {},
    code: {},
    language: {}
  },
  emits: ["toggle-fold", "request-edit"],
  setup(e, { emit: t }) {
    const n = xe("code-block"), a = e, o = t, i = R(
      () => Zr(a.code, a.language)
    ), s = R(() => a.rows.map((v) => {
      const C = i.value[v.lineIndex] ?? [], k = C.map((y) => y.text).join("");
      return {
        row: v,
        tokens: k === v.text ? C : [{ text: v.text, classNames: [] }]
      };
    })), l = (v) => {
      var w;
      return ((w = v.target) == null ? void 0 : w.closest("button")) !== null;
    }, m = (v) => {
      var w;
      return ((w = v.target) == null ? void 0 : w.closest(
        '[data-zx-fold-edit-target="true"]'
      )) !== null;
    }, c = (v) => {
      var y;
      const w = v.target, C = w == null ? void 0 : w.closest("[data-zx-fold-row-offset]"), k = Number(C == null ? void 0 : C.dataset.zxFoldRowOffset);
      return Number.isFinite(k) ? k : ((y = a.rows[0]) == null ? void 0 : y.fromOffset) ?? 0;
    }, u = (v, w, C) => {
      v.preventDefault(), o("request-edit", {
        offset: c(v),
        trigger: w,
        pendingEdit: C
      });
    }, j = (v) => {
      l(v) || !m(v) || u(v, "pointer");
    }, f = (v) => {
      if (!l(v)) {
        if (v.key === "Enter" || v.key === "F2") {
          u(v, "keyboard");
          return;
        }
        if (v.key === "Backspace") {
          u(v, "beforeinput", { type: "delete-backward" });
          return;
        }
        if (v.key === "Delete") {
          u(v, "beforeinput", { type: "delete-forward" });
          return;
        }
        v.key.length === 1 && !v.altKey && !v.ctrlKey && !v.metaKey && u(v, "beforeinput", {
          type: "insert-text",
          text: v.key
        });
      }
    }, g = (v) => {
      const w = v;
      if (w.inputType === "deleteContentBackward") {
        u(v, "beforeinput", { type: "delete-backward" });
        return;
      }
      if (w.inputType === "deleteContentForward") {
        u(v, "beforeinput", { type: "delete-forward" });
        return;
      }
      w.inputType === "insertText" && typeof w.data == "string" && u(v, "beforeinput", {
        type: "insert-text",
        text: w.data
      });
    }, h = (v) => {
      var w;
      u(v, "paste", {
        type: "insert-plain-text",
        text: ((w = v.clipboardData) == null ? void 0 : w.getData("text/plain")) ?? "",
        source: "paste"
      });
    }, p = (v) => {
      var w;
      u(v, "drop", {
        type: "insert-plain-text",
        text: ((w = v.dataTransfer) == null ? void 0 : w.getData("text/plain")) ?? "",
        source: "drop"
      });
    }, x = (v) => {
      u(v, "composition");
    };
    return (v, w) => (L(), A("pre", {
      class: d([r(n).e("pre"), r(n).e("folded-pre")]),
      contenteditable: "false",
      role: "region",
      tabindex: "0",
      "aria-label": "折叠代码阅读视图。按 Enter 或 F2 进入编辑",
      onPointerdownCapture: j,
      onKeydownCapture: f,
      onBeforeinputCapture: g,
      onPasteCapture: h,
      onDropCapture: p,
      onCompositionstartCapture: x
    }, [
      w[10] || (w[10] = Ie("    ", -1)),
      b("code", {
        class: d([r(n).e("code"), r(n).e("folded-code")])
      }, [
        w[8] || (w[8] = Ie(`
      `, -1)),
        (L(!0), A(ve, null, Pe(s.value, (C) => (L(), A("span", {
          key: `projection:${C.row.lineNumber}:${C.row.fromOffset}`,
          class: d([r(n).e("folded-line"), C.row.folded && r(n).is("folded")]),
          "data-zx-fold-row-offset": C.row.fromOffset
        }, [
          w[5] || (w[5] = Ie(`
        
        
        `, -1)),
          b("span", {
            class: d(r(n).e("folded-line-text")),
            "data-zx-fold-edit-target": "true"
          }, [
            (L(!0), A(ve, null, Pe(C.tokens, (k, y) => (L(), A("span", {
              key: `${y}:${k.text}:${k.classNames.join(".")}`,
              class: d(k.classNames)
            }, Q(k.text), 3))), 128))
          ], 2),
          w[6] || (w[6] = Ie(`
        `, -1)),
          C.row.folded && C.row.rangeKey ? (L(), A("button", {
            key: 0,
            class: d(r(n).e("fold-placeholder")),
            type: "button",
            "aria-label": `展开第 ${C.row.lineNumber} 行代码区域，显示隐藏的 ${C.row.hiddenLineCount} 行`,
            "aria-expanded": "false",
            onMousedown: w[0] || (w[0] = N(() => {
            }, ["prevent"])),
            onClick: N((k) => o("toggle-fold", C.row.rangeKey), ["stop"])
          }, [
            w[1] || (w[1] = Ie(`
          `, -1)),
            w[2] || (w[2] = b("span", { "aria-hidden": "true" }, "…", -1)),
            w[3] || (w[3] = Ie(`
          `, -1)),
            b("span", {
              class: d(r(n).e("fold-placeholder-count"))
            }, `
            隐藏 ` + Q(C.row.hiddenLineCount) + ` 行
          `, 3),
            w[4] || (w[4] = Ie(`
        `, -1))
          ], 42, Jr)) : V("", !0),
          w[7] || (w[7] = Ie(`
      `, -1))
        ], 10, Yr))), 128)),
        w[9] || (w[9] = Ie(`
    `, -1))
      ], 2),
      w[11] || (w[11] = Ie(`
  `, -1))
    ], 34));
  }
}), el = ["data-zx-fold-row"], tl = ["aria-label", "aria-expanded", "onClick"], nl = /* @__PURE__ */ ke({
  __name: "code-block-folding-gutter",
  props: {
    mode: {},
    rows: {},
    highlightedLineNumbers: {}
  },
  emits: ["toggle-fold"],
  setup(e, { emit: t }) {
    const n = xe("code-block"), a = t, o = (i) => i.folded ? `展开第 ${i.lineNumber} 行代码区域，显示隐藏的 ${i.hiddenLineCount} 行` : `折叠第 ${i.lineNumber} 行代码区域`;
    return (i, s) => (L(), A("div", {
      class: d([
        r(n).e("gutter"),
        r(n).is("numbers-visible", e.mode !== "folds"),
        r(n).is("folds-visible", e.mode !== "numbers")
      ]),
      contenteditable: "false",
      "aria-hidden": "false"
    }, [
      (L(!0), A(ve, null, Pe(e.rows, (l) => (L(), A("span", {
        key: `gutter:${l.lineNumber}:${l.fromOffset}`,
        class: d([
          r(n).e("gutter-row"),
          l.rangeKey && r(n).is("foldable"),
          l.folded && r(n).is("folded"),
          e.highlightedLineNumbers.has(l.lineNumber) && r(n).is("highlighted")
        ]),
        "data-zx-fold-row": l.lineIndex
      }, [
        e.mode !== "folds" ? (L(), A("span", {
          key: 0,
          class: d(r(n).e("line-number-text"))
        }, Q(l.lineNumber), 3)) : V("", !0),
        e.mode !== "numbers" ? (L(), A("span", {
          key: 1,
          class: d(r(n).e("fold-cell"))
        }, [
          l.rangeKey ? (L(), A("button", {
            key: 0,
            class: d(r(n).e("fold-toggle")),
            type: "button",
            "aria-label": o(l),
            "aria-expanded": !l.folded,
            onMousedown: s[0] || (s[0] = N(() => {
            }, ["prevent"])),
            onClick: (m) => a("toggle-fold", l.rangeKey)
          }, [
            B(r(te), {
              icon: l.folded ? "lucide:chevron-right" : "lucide:chevron-down"
            }, null, 8, ["icon"])
          ], 42, tl)) : (L(), A("span", {
            key: 1,
            class: d(r(n).e("fold-spacer"))
          }, null, 2))
        ], 2)) : V("", !0)
      ], 10, el))), 128))
    ], 2));
  }
}), al = /* @__PURE__ */ ke({
  __name: "code-block-language-select",
  props: {
    modelValue: {
      type: null,
      required: !0
    },
    languageOptions: {
      type: Array,
      default: void 0
    },
    recentLanguages: {
      type: Array,
      default: () => []
    },
    defaultLanguage: {
      type: null,
      default: null
    }
  },
  emits: ["update:modelValue", "change", "dropdown-visible-change"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = R(
      () => n.languageOptions ?? Oa(Na, {
        recentLanguages: n.recentLanguages,
        defaultLanguage: n.defaultLanguage
      }).map((m) => ({
        label: m.label,
        value: m.id
      }))
    ), i = R({
      get: () => n.modelValue ?? "plaintext",
      set: (m) => a("update:modelValue", Xt(m))
    }), s = (m) => {
      a("change", Xt(m));
    }, l = (m) => {
      a("dropdown-visible-change", m);
    };
    return (m, c) => (L(), Ce(r(Nt), Uo({
      modelValue: i.value,
      "onUpdate:modelValue": c[0] || (c[0] = (u) => i.value = u),
      options: o.value,
      size: "small",
      filterable: "",
      placeholder: "选择语言",
      teleported: !1
    }, m.$attrs, {
      onChange: s,
      onVisibleChange: l
    }), null, 16, ["modelValue", "options"]));
  }
}), ol = ["maxlength", "placeholder", "onKeydown"], il = /* @__PURE__ */ ke({
  name: "CodeBlockTitle",
  __name: "code-block-title",
  props: {
    modelValue: {
      type: String,
      required: !0
    },
    maxLength: {
      type: Number,
      default: 50
    },
    placeholder: {
      type: String,
      default: "未命名代码块"
    }
  },
  emits: ["update:modelValue"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = xe("code-block"), i = S(!1), s = S(""), l = S(null), m = () => {
      s.value = n.modelValue, i.value = !0, Ae(() => {
        var j, f;
        (j = l.value) == null || j.focus(), (f = l.value) == null || f.select();
      });
    }, c = () => {
      const j = s.value.trim();
      a("update:modelValue", j), i.value = !1;
    }, u = () => {
      i.value = !1, s.value = n.modelValue;
    };
    return (j, f) => (L(), A("div", {
      class: d(r(o).e("title-wrapper"))
    }, [
      i.value ? Je((L(), A("input", {
        key: 0,
        ref_key: "inputRef",
        ref: l,
        "onUpdate:modelValue": f[0] || (f[0] = (g) => s.value = g),
        class: d(r(o).e("title-input")),
        type: "text",
        maxlength: e.maxLength,
        placeholder: e.placeholder,
        onMousedown: f[1] || (f[1] = N(() => {
        }, ["stop"])),
        onClick: f[2] || (f[2] = N(() => {
        }, ["stop"])),
        onKeydown: [
          f[3] || (f[3] = N(() => {
          }, ["stop"])),
          $e(N(c, ["prevent"]), ["enter"]),
          $e(N(u, ["prevent"]), ["escape"])
        ],
        onBlur: c
      }, null, 42, ol)), [
        [ht, s.value]
      ]) : (L(), A("span", {
        key: 1,
        class: d([r(o).e("title"), r(o).is("empty", !e.modelValue)]),
        onMousedown: f[4] || (f[4] = N(() => {
        }, ["stop"])),
        onDblclick: N(m, ["stop"])
      }, Q(e.modelValue || e.placeholder), 35))
    ], 2));
  }
}), sl = ["title", "aria-label", "aria-expanded"], rl = ["disabled"], ll = ["aria-pressed"], ml = ["aria-pressed"], cl = ["disabled", "title", "aria-label"], ul = ["aria-expanded"], dl = /* @__PURE__ */ ke({
  name: "CodeBlockHeader",
  __name: "code-block-header",
  props: {
    language: {},
    title: {},
    collapsed: { type: Boolean },
    codeContent: {},
    copyContent: {},
    copyMode: {},
    wrap: {},
    showLineNumbers: { type: Boolean },
    canCopyPlain: { type: Boolean },
    canCopyMarkdown: { type: Boolean },
    copyDisabledReason: {},
    settingsOpen: { type: Boolean },
    detectingLanguage: { type: Boolean },
    recentLanguages: {},
    defaultLanguage: {}
  },
  emits: ["update:language", "update:title", "toggle-collapse", "toggle-wrap", "toggle-line-numbers", "toggle-settings", "copy", "copy-failed", "detect-language", "dropdown-visible-change"],
  setup(e, { emit: t }) {
    const n = e, a = t, o = (h) => {
      a("update:language", h);
    }, i = (h) => {
      a("update:title", h);
    }, s = (h) => {
      a("dropdown-visible-change", h);
    }, l = xe("code-block"), m = S(!1), c = S(!1), u = R(() => !n.canCopyPlain && !n.canCopyMarkdown ? n.copyDisabledReason ?? "复制不可用" : m.value ? "已复制" : c.value ? "复制失败" : n.copyMode === "markdown" ? "复制 Markdown" : "复制代码"), j = R(() => m.value ? "lucide:check" : c.value ? "lucide:circle-alert" : "lucide:copy"), f = async (h) => {
      var v;
      if ((v = navigator == null ? void 0 : navigator.clipboard) != null && v.writeText) {
        await navigator.clipboard.writeText(h);
        return;
      }
      const p = document.createElement("textarea");
      p.value = h, p.style.position = "fixed", p.style.left = "0", p.style.top = "0", p.style.opacity = "0", p.setAttribute("readonly", "true"), document.body.appendChild(p), p.focus(), p.select();
      const x = document.execCommand("copy");
      if (document.body.removeChild(p), !x) throw new Error("copy failed");
    }, g = async () => {
      if (!(!n.canCopyPlain && !n.canCopyMarkdown))
        try {
          await f(n.copyContent ?? n.codeContent ?? ""), m.value = !0, c.value = !1, a("copy"), window.setTimeout(() => {
            m.value = !1;
          }, 1500);
        } catch {
          c.value = !0, a("copy-failed"), window.setTimeout(() => {
            c.value = !1;
          }, 1500);
        }
    };
    return (h, p) => (L(), A("div", {
      class: d(r(l).e("header")),
      contenteditable: "false"
    }, [
      b("div", {
        class: d(r(l).e("header-left"))
      }, [
        b("button", {
          class: d(r(l).e("collapse-btn")),
          type: "button",
          title: e.collapsed ? "展开" : "折叠",
          "aria-label": e.collapsed ? "展开代码块" : "折叠代码块",
          "aria-expanded": !e.collapsed,
          onMousedown: p[0] || (p[0] = N(() => {
          }, ["prevent"])),
          onClick: p[1] || (p[1] = (x) => a("toggle-collapse"))
        }, [
          B(r(te), {
            icon: e.collapsed ? "lucide:chevron-right" : "lucide:chevron-down"
          }, null, 8, ["icon"])
        ], 42, sl),
        B(il, {
          "model-value": e.title,
          "max-length": 50,
          "onUpdate:modelValue": i
        }, null, 8, ["model-value"])
      ], 2),
      b("div", {
        class: d(r(l).e("header-right"))
      }, [
        B(al, {
          "model-value": e.language,
          class: d(r(l).e("select")),
          "recent-languages": e.recentLanguages,
          "default-language": e.defaultLanguage,
          "onUpdate:modelValue": o,
          onDropdownVisibleChange: s
        }, null, 8, ["model-value", "class", "recent-languages", "default-language"]),
        b("button", {
          class: d([r(l).e("action-btn"), e.detectingLanguage && r(l).is("active")]),
          type: "button",
          disabled: e.detectingLanguage,
          title: "识别代码语言",
          "aria-label": "识别代码语言",
          onMousedown: p[2] || (p[2] = N(() => {
          }, ["prevent"])),
          onClick: p[3] || (p[3] = (x) => a("detect-language"))
        }, [
          B(r(te), { icon: "lucide:wand-sparkles" })
        ], 42, rl),
        b("button", {
          class: d([r(l).e("action-btn"), e.wrap === "on" && r(l).is("active")]),
          type: "button",
          "aria-pressed": e.wrap === "on",
          title: "切换自动换行",
          "aria-label": "切换代码自动换行",
          onMousedown: p[4] || (p[4] = N(() => {
          }, ["prevent"])),
          onClick: p[5] || (p[5] = (x) => a("toggle-wrap"))
        }, [
          B(r(te), { icon: "lucide:wrap-text" })
        ], 42, ll),
        b("button", {
          class: d([r(l).e("action-btn"), e.showLineNumbers && r(l).is("active")]),
          type: "button",
          "aria-pressed": e.showLineNumbers,
          title: "切换行号",
          "aria-label": "切换代码行号",
          onMousedown: p[6] || (p[6] = N(() => {
          }, ["prevent"])),
          onClick: p[7] || (p[7] = (x) => a("toggle-line-numbers"))
        }, [
          B(r(te), { icon: "lucide:list-ordered" })
        ], 42, ml),
        b("button", {
          class: d([
            r(l).e("action-btn"),
            r(l).is("copied", m.value),
            r(l).is("failed", c.value)
          ]),
          type: "button",
          disabled: !e.canCopyPlain && !e.canCopyMarkdown,
          title: u.value,
          "aria-label": u.value,
          onMousedown: p[8] || (p[8] = N(() => {
          }, ["prevent"])),
          onClick: g
        }, [
          B(r(te), { icon: j.value }, null, 8, ["icon"])
        ], 42, cl),
        b("button", {
          class: d([r(l).e("action-btn"), e.settingsOpen && r(l).is("active")]),
          type: "button",
          "aria-expanded": e.settingsOpen,
          title: "代码块设置",
          "aria-label": "打开代码块设置",
          onMousedown: p[9] || (p[9] = N(() => {
          }, ["prevent"])),
          onClick: p[10] || (p[10] = (x) => a("toggle-settings"))
        }, [
          B(r(te), { icon: "lucide:settings-2" })
        ], 42, ul)
      ], 2)
    ], 2));
  }
}), pl = (e, t) => e.length === t.length && e.every((n, a) => {
  const o = t[a];
  return (o == null ? void 0 : o.state) === n.state && o.source === n.source && o.kind === n.kind && o.anchor.startText === n.anchor.startText && o.anchor.endText === n.anchor.endText && o.anchor.span === n.anchor.span && o.anchor.depth === n.anchor.depth;
}), fl = (e) => ({
  offset: e.offset,
  trigger: e.trigger,
  pendingEdit: e.pendingEdit ? { ...e.pendingEdit } : void 0
}), gl = (e) => {
  var ye;
  const t = S(typeof globalThis.IntersectionObserver != "function"), n = S(!1), a = Ue(e.lines.value), o = Ue([]), i = Ue(null), s = Ue(null), l = S(0), m = S(0), c = S(!1), u = S(!1), j = e.resolveFolding ?? qa, f = e.resolveCanonicalLineOffsets ?? Ha;
  let g = 0, h = null, p = null, x = null, v = 0, w = null, C = null;
  const k = () => {
    h == null || h.disconnect(), h = null;
  }, y = () => {
    c.value = !0;
  }, Z = (O) => {
    const Y = O.relatedTarget;
    c.value = !!(x && typeof Node < "u" && Y instanceof Node && x.contains(Y));
  }, q = () => {
    x == null || x.removeEventListener("focusin", y), x == null || x.removeEventListener("focusout", Z), x = null, c.value = !1;
  }, $ = (O) => {
    n.value = (O == null ? void 0 : O.matches) ?? (p == null ? void 0 : p.matches) ?? !1;
  };
  typeof window < "u" && typeof window.matchMedia == "function" && (p = window.matchMedia("(pointer: coarse)"), $(), (ye = p.addEventListener) == null || ye.call(p, "change", $)), Le(
    e.bodyRef,
    (O) => {
      if (k(), q(), O && (x = O, O.addEventListener("focusin", y), O.addEventListener("focusout", Z), c.value = !!(typeof document < "u" && document.activeElement && O.contains(document.activeElement))), typeof globalThis.IntersectionObserver != "function") {
        t.value = !0;
        return;
      }
      if (!O) {
        t.value = !1;
        return;
      }
      t.value = !1, h = new IntersectionObserver((Y) => {
        const T = Y[Y.length - 1];
        T && (t.value = T.isIntersecting);
      }), h.observe(O);
    },
    { immediate: !0 }
  ), Le(
    e.code,
    () => {
      i.value = null, a.value = e.lines.value, m.value += 1;
    },
    { flush: "sync" }
  );
  const U = R(
    () => {
      var O;
      return ((O = e.coarsePointerOverride) == null ? void 0 : O.value) ?? n.value;
    }
  ), J = R(
    () => e.focused.value || c.value
  ), E = R(
    () => {
      var O;
      return $a(e.wrap.value, (O = e.hostWrap) == null ? void 0 : O.value);
    }
  ), H = R(
    () => t.value && (e.hovered.value || J.value || U.value || o.value.length > 0)
  ), W = R(() => {
    var ee;
    const O = a.value, Y = e.code.value.length, T = e.language.value, M = E.value, P = e.wrapAlignmentSupported.value, X = (ee = e.budget) == null ? void 0 : ee.value, G = {
      lines: O,
      characterCount: Y,
      language: T,
      effectiveWrap: M,
      wrapAlignmentSupported: P,
      budget: X
    };
    return g += 1, {
      key: [
        Ba,
        m.value,
        (T == null ? void 0 : T.trim().toLowerCase()) ?? "",
        M,
        Fa(X),
        P ? "wrap-supported" : "wrap-unsupported"
      ].join("\0"),
      input: G,
      decision: za({
        ...G,
        visible: !0,
        blockCollapsed: !1,
        foldingRequested: !0
      })
    };
  }), se = R(() => (W.value, g)), ae = R(() => ({
    ...W.value.input,
    visible: t.value,
    blockCollapsed: e.blockCollapsed.value,
    foldingRequested: H.value
  })), de = R(
    () => f(e.code.value)
  ), ie = R(() => {
    const O = ae.value, Y = W.value.key, T = i.value;
    if ((T == null ? void 0 : T.key) === Y && T.result.decision.status === "disabled")
      return T.result;
    const M = W.value.decision, P = M.status !== "enabled" ? M : O.visible ? O.blockCollapsed ? {
      status: "deferred",
      reason: "block-collapsed",
      metrics: M.metrics
    } : O.foldingRequested ? M : {
      status: "deferred",
      reason: "gutter-not-requested",
      metrics: M.metrics
    } : {
      status: "deferred",
      reason: "not-visible",
      metrics: M.metrics
    };
    if (P.status !== "enabled") {
      const G = Va(P);
      return P.status === "disabled" && (i.value = { key: Y, result: G }), G;
    }
    if ((T == null ? void 0 : T.key) === Y) return T.result;
    l.value += 1;
    const X = j(O);
    return i.value = { key: Y, result: X }, X;
  }), F = R(
    () => ie.value.decision.status === "enabled" && ie.value.scanStatus === "complete" ? Gt(o.value, ie.value.ranges) : []
  ), re = R(
    () => F.value.some((O) => O.state === "active")
  ), ce = R(
    () => Zt({
      lines: a.value,
      lineNumbers: e.lineNumbers.value,
      lineOffsets: re.value ? de.value : void 0,
      ranges: ie.value.decision.status === "enabled" ? ie.value.ranges : [],
      activeIntents: F.value
    })
  ), he = R(
    () => ce.value.some((O) => O.folded)
  ), be = R(() => {
    const O = ie.value;
    if (e.blockCollapsed.value || O.decision.status === "disabled" && O.decision.reason === "wrap-unsupported")
      return "none";
    const Y = O.decision.status === "enabled" && O.ranges.length > 0;
    return e.showLineNumbers.value && Y ? "numbers-and-folds" : e.showLineNumbers.value ? "numbers" : t.value && (Y || O.decision.status === "enabled" || O.decision.status === "deferred" && O.decision.reason === "gutter-not-requested") ? "folds" : "none";
  }), K = () => {
    o.value = [];
  }, _ = () => {
    const O = e.canonicalContentRef.value;
    return !!(O && O.style.display !== "none" && O.getAttribute("aria-hidden") !== "true");
  }, z = async (O, Y) => {
    var T;
    await Ae(), !(u.value || Y !== v || !_() || O > e.code.value.length) && ((T = e.restoreCanonicalFocus) == null || T.call(e, O));
  }, oe = () => {
    if (typeof document > "u") return e.focused.value;
    const O = document.activeElement, Y = e.bodyRef.value;
    return !O || O === document.body ? e.focused.value : Y != null && Y.contains(O) ? !0 : Y && O.contains(Y) ? e.focused.value : !1;
  };
  Le(
    ie,
    (O) => {
      var X;
      if (O.decision.status === "enabled" && O.scanStatus === "complete") {
        s.value = O;
        const G = Gt(o.value, O.ranges);
        pl(o.value, G) || (o.value = G);
        return;
      }
      if (O.decision.status !== "disabled" || o.value.length === 0)
        return;
      const Y = s.value, M = ((X = (Y ? Zt({
        lines: a.value,
        lineNumbers: e.lineNumbers.value,
        lineOffsets: de.value,
        ranges: Y.ranges,
        activeIntents: o.value
      }) : []).find((G) => G.folded)) == null ? void 0 : X.fromOffset) ?? 0, P = oe();
      if (K(), P && e.restoreCanonicalFocus) {
        const G = ++v;
        z(M, G);
      }
    },
    { immediate: !0 }
  );
  const le = (O) => {
    const Y = ie.value;
    Y.decision.status !== "enabled" || Y.scanStatus !== "complete" || (o.value = Wa({
      previous: o.value,
      ranges: Y.ranges,
      rangeKey: O
    }));
  }, _e = (O) => {
    if (w) return w;
    const Y = Math.floor(O.offset);
    if (!Number.isFinite(Y) || Y < 0 || Y > e.code.value.length)
      return Promise.resolve("cancelled");
    C = fl({ ...O, offset: Y });
    const T = ++v;
    w = (async () => (K(), await Ae(), u.value || T !== v || Y > e.code.value.length || !_() ? (C = null, "cancelled") : "ready"))();
    const M = () => {
      T === v && (w = null);
    };
    return w.then(M, M), w;
  }, me = () => {
    const O = C;
    return C = null, O;
  }, fe = () => {
    var O;
    u.value || (u.value = !0, v += 1, C = null, w = null, K(), i.value = null, s.value = null, k(), q(), (O = p == null ? void 0 : p.removeEventListener) == null || O.call(p, "change", $), p = null);
  };
  return Mn(fe), {
    decision: R(() => ie.value.decision),
    diagnostics: R(() => ie.value.diagnostics),
    effectiveWrap: E,
    displayedRows: ce,
    hasActiveFolds: he,
    gutterMode: be,
    visible: t,
    coarsePointer: U,
    focusedWithin: J,
    resolverCallCount: l,
    staticPolicyEvaluationCount: se,
    toggleFold: le,
    prepareForLocalEdit: _e,
    consumePreparedLocalEdit: me,
    clearFolds: K,
    cleanup: fe
  };
}, hl = ["value", "placeholder"], jl = ["value", "placeholder"], vl = ["value"], bl = ["value"], _l = ["value"], yl = ["value"], wl = ["value"], kl = ["value"], Cl = ["checked"], xl = ["checked"], El = ["checked"], Tl = ["disabled", "onClick"], Ll = ["hidden", "aria-hidden", "data-zx-folding-decision", "data-zx-folding-reason"], Il = ["hidden", "aria-hidden"], Sl = ["value", "placeholder", "disabled"], Al = /* @__PURE__ */ ke({
  __name: "code-block-component",
  props: bt,
  setup(e) {
    const t = xe("code-block"), n = e, a = R(() => n.node), o = R(
      () => {
        var D, I;
        return ((I = (D = n.editor.extensionManager.extensions.find(
          (ne) => ne.name === "codeBlock"
        )) == null ? void 0 : D.options) == null ? void 0 : I.codeBlockPreferences) ?? null;
      }
    ), i = S(!1), s = S(!1), l = S(!1), m = S(!1), c = S(!1), u = S(null), j = S([]), f = S(null), g = S(null), h = S(!1), p = S(null);
    let x = !1, v = 0;
    const w = () => {
      const D = ++v;
      Ae(() => {
        !x && D === v && n.editor.view.focus();
      });
    }, C = R(() => a.value.textContent || ""), k = R(
      () => si({
        code: C.value,
        attrs: a.value.attrs
      })
    ), y = R(() => vi(k.value)), Z = (D) => {
      const I = n.getPos();
      if (typeof I != "number") return;
      const ne = I + 1, we = ne + C.value.length, pe = Math.min(
        we,
        Math.max(ne, ne + Math.floor(D))
      ), Ee = n.editor.state.tr.setSelection(
        Ke.create(n.editor.state.doc, pe)
      );
      n.editor.view.dispatch(Ee), w();
    }, q = S(!1), $ = gl({
      code: C,
      lines: R(() => k.value.lines.visualLines),
      lineNumbers: R(() => k.value.lines.lineNumbers),
      language: R(() => k.value.attrs.language),
      wrap: R(() => k.value.attrs.wrap),
      blockCollapsed: R(() => k.value.attrs.collapsed),
      showLineNumbers: R(() => k.value.attrs.showLineNumbers),
      hovered: i,
      focused: s,
      bodyRef: f,
      canonicalContentRef: g,
      wrapAlignmentSupported: q,
      restoreCanonicalFocus: Z
    }), {
      coarsePointer: U,
      decision: J,
      diagnostics: E,
      displayedRows: H,
      effectiveWrap: W,
      focusedWithin: se,
      gutterMode: ae,
      hasActiveFolds: de,
      toggleFold: ie
    } = $, F = R(
      () => Ua(C.value, k.value.attrs)
    ), re = R(
      () => Ka({
        mode: k.value.attrs.copyMode,
        scope: "current-tab",
        block: F.value
      })
    ), ce = R(() => {
      var D;
      return [
        ...y.value.diagnostics,
        ...re.value.diagnostics,
        ...((D = u.value) == null ? void 0 : D.diagnostics) ?? [],
        ...j.value,
        ...E.value
      ];
    }), he = R(
      () => Xa(k.value.attrs.highlightLines)
    ), be = S(""), K = R(() => {
      const D = /* @__PURE__ */ new Set();
      return k.value.attrs.highlightLines.forEach((I) => {
        const ne = I.to ?? I.from;
        for (let we = I.from; we <= ne; we += 1)
          D.add(k.value.attrs.startLine + we - 1);
      }), D;
    }), _ = (D, I = {}) => {
      const ne = n.getPos();
      typeof ne == "number" && (n.editor.commands.updateCodeBlockV2AttrsAt(ne, D), (I.restoreFocus ?? !0) && Ae(() => {
        n.editor.commands.focus();
      }));
    }, z = R(() => {
      const D = p.value ?? k.value.display.height, I = {};
      return y.value.body.collapsed ? (I.maxHeight = `calc(${y.value.body.previewTo} * 20px + 16px)`, I.overflow = "hidden", I) : k.value.display.heightMode === "auto" ? (y.value.body.maxBodyHeight && (I.maxHeight = y.value.body.maxBodyHeight, I.overflow = "auto"), I) : typeof D == "number" && Number.isFinite(D) ? (I.height = `${D}px`, I) : (I.maxHeight = y.value.body.maxBodyHeight ?? "320px", I.overflow = "auto", I);
    }), oe = R(() => ({
      whiteSpace: W.value === "on" ? "pre-wrap" : "pre"
    })), le = () => {
      const D = n.getPos();
      if (typeof D != "number") return;
      const { selection: I } = n.editor.state, ne = I.from, we = I.to, pe = D, Ee = D + n.node.nodeSize;
      s.value = ne >= pe && we <= Ee, ne > pe && we < Ee && y.value.body.collapsed && n.editor.commands.setNodeSelection(D);
    }, _e = (D) => {
      _({ language: D });
    }, me = (D) => {
      _({ filename: D }, { restoreFocus: !1 });
    }, fe = (D) => {
      me(D.target.value);
    }, ye = (D) => {
      _(
        { caption: D.target.value },
        { restoreFocus: !1 }
      );
    }, O = (D) => {
      const I = { collapsed: D };
      if (D && k.value.attrs.previewLines === null && (I.previewLines = vn.longCodePreviewLines), _(I), D) {
        const ne = n.getPos();
        typeof ne == "number" && Ae(() => n.editor.commands.setNodeSelection(ne));
      }
    }, Y = () => {
      O(!y.value.body.collapsed);
    }, T = (D) => {
      var Wt;
      const I = n.getPos();
      if (typeof I != "number" || !n.editor.isEditable) return;
      const ne = I + 1, we = C.value.length, pe = Math.min(we, Math.max(0, D.offset)), Ee = ne + pe, He = n.editor.state.tr;
      let Ct = Ee;
      switch ((Wt = D.pendingEdit) == null ? void 0 : Wt.type) {
        case "insert-text":
        case "insert-plain-text": {
          const xt = D.pendingEdit.text;
          xt && (He.insertText(xt, Ee, Ee), Ct += xt.length);
          break;
        }
        case "delete-backward":
          pe > 0 && (He.delete(Ee - 1, Ee), Ct -= 1);
          break;
        case "delete-forward":
          pe < we && He.delete(Ee, Ee + 1);
          break;
      }
      He.setSelection(
        Ke.create(He.doc, Ct)
      ), n.editor.view.dispatch(He), w();
    }, M = async (D) => {
      if (!n.editor.isEditable || await $.prepareForLocalEdit(D) !== "ready") return;
      const ne = $.consumePreparedLocalEdit();
      ne && T(ne);
    }, P = () => {
      const D = k.value.attrs.wrap;
      _({ wrap: D === "on" ? "off" : "on" });
    }, X = () => {
      _({ showLineNumbers: !k.value.attrs.showLineNumbers });
    }, G = () => {
      m.value = !m.value;
    }, ee = (D) => {
      l.value = D;
    }, ue = (D) => {
      _({
        startLine: Number(D.target.value)
      });
    }, Se = (D) => {
      const I = D.target.value;
      _({ previewLines: I ? Number(I) : null });
    }, ge = (D) => {
      _({
        copyMode: D.target.value
      });
    }, st = (D) => {
      const I = D.target.value.trim();
      _({ groupId: I || null }, { restoreFocus: !1 });
    }, oa = (D) => {
      _(
        { tabLabel: D.target.value },
        { restoreFocus: !1 }
      );
    }, ia = (D) => {
      be.value = D.target.value;
    }, Ht = (D, I) => {
      const ne = I === "clear" ? [] : D, we = Ya({
        currentRanges: k.value.attrs.highlightLines,
        edit: {
          ranges: ne,
          mode: I
        },
        lineCount: Ja(C.value),
        interactive: !0
      });
      j.value = we.diagnostics, we.patch && _(we.patch, { restoreFocus: !1 });
    }, sa = (D, I) => {
      be.value = D.target.value;
      const ne = Yt(
        D.target.value
      );
      Ht(ne, I);
    }, rt = (D) => {
      const I = be.value || he.value;
      Ht(Yt(I), D);
    }, ra = (D) => {
      _({
        wrap: D.target.checked ? "on" : "off"
      });
    }, la = (D) => {
      _({
        showLineNumbers: D.target.checked
      });
    }, ma = (D) => {
      O(D.target.checked);
    }, ca = async () => {
      c.value = !0, j.value = [];
      try {
        u.value = await Ga({
          code: C.value,
          currentLanguage: k.value.attrs.language
        });
      } finally {
        c.value = !1;
      }
    }, ua = (D) => {
      if (!u.value) return;
      const I = Za(u.value, D);
      I && (_(I), u.value = null);
    };
    let Vt = 0, yt = 0, qt = 0;
    const da = (D) => {
      if (!n.editor.isEditable) return;
      D.preventDefault(), h.value = !0, Vt = D.clientY;
      const I = f.value;
      yt = (I == null ? void 0 : I.offsetHeight) || 0, qt = I && Number.parseFloat(window.getComputedStyle(I).minHeight) || 0, p.value = yt, window.addEventListener("mousemove", wt), window.addEventListener("mouseup", kt), document.body.style.cursor = "ns-resize";
    }, wt = (D) => {
      if (!h.value) return;
      const I = D.clientY - Vt, ne = Math.max(qt, yt + I);
      p.value = ne;
    }, kt = () => {
      if (!h.value) return;
      h.value = !1, window.removeEventListener("mousemove", wt), window.removeEventListener("mouseup", kt), document.body.style.cursor = "";
      const D = p.value;
      p.value = null, typeof D == "number" && Number.isFinite(D) && _({ height: D, heightMode: "fixed" });
    };
    return Fe(() => {
      le(), n.editor.on("selectionUpdate", le);
    }), ze(() => {
      x = !0, v += 1, $.cleanup(), n.editor.off("selectionUpdate", le), window.removeEventListener("mousemove", wt), window.removeEventListener("mouseup", kt), document.body.style.cursor = "";
    }), (D, I) => (L(), Ce(r(et), {
      as: "div",
      class: d([
        r(t).b(),
        r(t).is("collapsed", y.value.body.collapsed),
        r(t).is("empty", y.value.body.isEmpty),
        r(t).is("long", y.value.body.isLong),
        r(t).is("hovered", i.value || l.value || m.value),
        r(t).is("focused", r(se)),
        r(t).is("coarse-pointer", r(U)),
        r(t).is("wrap-on", r(W) === "on"),
        r(t).is("wrap-off", r(W) === "off")
      ]),
      "data-zx-code-contract-version": k.value.attrs.contractVersion,
      "data-zx-code-language": y.value.header.language || "plaintext",
      onMouseenter: I[20] || (I[20] = (ne) => i.value = !0),
      onMouseleave: I[21] || (I[21] = (ne) => i.value = !1)
    }, {
      default: je(() => {
        var ne, we;
        return [
          B(dl, {
            language: y.value.header.language,
            title: y.value.header.filename,
            collapsed: y.value.body.collapsed,
            "code-content": y.value.copy.text,
            "copy-content": re.value.text,
            "copy-mode": k.value.attrs.copyMode,
            wrap: y.value.body.wrap,
            "show-line-numbers": y.value.body.showLineNumbers,
            "can-copy-plain": y.value.header.canCopyPlain,
            "can-copy-markdown": re.value.status !== "failed",
            "copy-disabled-reason": y.value.header.copyDisabledReason,
            "settings-open": m.value,
            "detecting-language": c.value,
            "recent-languages": ((ne = o.value) == null ? void 0 : ne.recentLanguages) ?? [],
            "default-language": ((we = o.value) == null ? void 0 : we.defaultLanguage) ?? null,
            "onUpdate:language": _e,
            "onUpdate:title": me,
            onToggleCollapse: Y,
            onToggleWrap: P,
            onToggleLineNumbers: X,
            onToggleSettings: G,
            onDetectLanguage: ca,
            onDropdownVisibleChange: ee
          }, null, 8, ["language", "title", "collapsed", "code-content", "copy-content", "copy-mode", "wrap", "show-line-numbers", "can-copy-plain", "can-copy-markdown", "copy-disabled-reason", "settings-open", "detecting-language", "recent-languages", "default-language"]),
          m.value ? (L(), A("div", {
            key: 0,
            class: d(r(t).e("settings")),
            contenteditable: "false",
            role: "dialog",
            "aria-label": "代码块设置",
            onKeydown: I[18] || (I[18] = $e(N((pe) => m.value = !1, ["stop", "prevent"]), ["esc"]))
          }, [
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "文件名", 2),
              b("input", {
                value: k.value.attrs.filename,
                placeholder: y.value.body.filenamePlaceholder || "",
                class: d(r(t).e("settings-input")),
                onMousedown: I[0] || (I[0] = N(() => {
                }, ["stop"])),
                onInput: fe
              }, null, 42, hl)
            ], 2),
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "说明", 2),
              b("input", {
                value: k.value.attrs.caption,
                placeholder: y.value.body.captionPlaceholder || "",
                class: d(r(t).e("settings-input")),
                onMousedown: I[1] || (I[1] = N(() => {
                }, ["stop"])),
                onInput: ye
              }, null, 42, jl)
            ], 2),
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "起始行号", 2),
              b("input", {
                value: k.value.attrs.startLine,
                class: d(r(t).e("settings-input")),
                type: "number",
                min: "1",
                step: "1",
                onMousedown: I[2] || (I[2] = N(() => {
                }, ["stop"])),
                onChange: ue
              }, null, 42, vl)
            ], 2),
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "预览行数", 2),
              b("input", {
                value: k.value.attrs.previewLines ?? "",
                class: d(r(t).e("settings-input")),
                type: "number",
                min: "1",
                step: "1",
                placeholder: "全部",
                onMousedown: I[3] || (I[3] = N(() => {
                }, ["stop"])),
                onChange: Se
              }, null, 42, bl)
            ], 2),
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "复制模式", 2),
              b("select", {
                value: k.value.attrs.copyMode,
                class: d([r(t).e("settings-input"), r(t).e("settings-select")]),
                onMousedown: I[4] || (I[4] = N(() => {
                }, ["stop"])),
                onChange: ge
              }, [...I[22] || (I[22] = [
                b("option", { value: "plain" }, "Plain text", -1),
                b("option", { value: "markdown" }, "Markdown", -1)
              ])], 42, _l)
            ], 2),
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "Tabs 组", 2),
              b("input", {
                value: k.value.attrs.groupId ?? "",
                class: d(r(t).e("settings-input")),
                placeholder: "groupId",
                onMousedown: I[5] || (I[5] = N(() => {
                }, ["stop"])),
                onInput: st
              }, null, 42, yl)
            ], 2),
            b("label", {
              class: d(r(t).e("settings-field"))
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "Tab 标签", 2),
              b("input", {
                value: k.value.attrs.tabLabel,
                class: d(r(t).e("settings-input")),
                placeholder: "tabLabel",
                onMousedown: I[6] || (I[6] = N(() => {
                }, ["stop"])),
                onInput: oa
              }, null, 42, wl)
            ], 2),
            b("label", {
              class: d([r(t).e("settings-field"), r(t).is("wide")])
            }, [
              b("span", {
                class: d(r(t).e("settings-label"))
              }, "高亮行", 2),
              b("input", {
                value: he.value,
                class: d(r(t).e("settings-input")),
                placeholder: "例如 1, 3-5",
                onMousedown: I[7] || (I[7] = N(() => {
                }, ["stop"])),
                onInput: ia,
                onChange: I[8] || (I[8] = (pe) => sa(pe, "replace"))
              }, null, 42, kl)
            ], 2),
            b("div", {
              class: d([r(t).e("settings-actions"), r(t).is("wide")])
            }, [
              b("button", {
                type: "button",
                onMousedown: I[9] || (I[9] = N(() => {
                }, ["prevent"])),
                onClick: I[10] || (I[10] = (pe) => rt("replace"))
              }, " 设置 ", 32),
              b("button", {
                type: "button",
                onMousedown: I[11] || (I[11] = N(() => {
                }, ["prevent"])),
                onClick: I[12] || (I[12] = (pe) => rt("add"))
              }, " 添加 ", 32),
              b("button", {
                type: "button",
                onMousedown: I[13] || (I[13] = N(() => {
                }, ["prevent"])),
                onClick: I[14] || (I[14] = (pe) => rt("remove"))
              }, " 删除 ", 32),
              b("button", {
                type: "button",
                onMousedown: I[15] || (I[15] = N(() => {
                }, ["prevent"])),
                onClick: I[16] || (I[16] = (pe) => rt("clear"))
              }, " 清空 ", 32)
            ], 2),
            b("div", {
              class: d(r(t).e("settings-checks"))
            }, [
              b("label", {
                class: d(r(t).e("settings-check"))
              }, [
                b("input", {
                  type: "checkbox",
                  checked: k.value.attrs.wrap === "on",
                  onChange: ra
                }, null, 40, Cl),
                I[23] || (I[23] = b("span", null, "自动换行", -1))
              ], 2),
              b("label", {
                class: d(r(t).e("settings-check"))
              }, [
                b("input", {
                  type: "checkbox",
                  checked: k.value.attrs.showLineNumbers,
                  onChange: la
                }, null, 40, xl),
                I[24] || (I[24] = b("span", null, "显示行号", -1))
              ], 2),
              b("label", {
                class: d(r(t).e("settings-check"))
              }, [
                b("input", {
                  type: "checkbox",
                  checked: k.value.attrs.collapsed,
                  onChange: ma
                }, null, 40, El),
                I[25] || (I[25] = b("span", null, "折叠代码块", -1))
              ], 2)
            ], 2),
            u.value ? (L(), A("div", {
              key: 0,
              class: d(r(t).e("detection"))
            }, [
              b("div", {
                class: d(r(t).e("detection-title"))
              }, " 语言识别: " + Q(u.value.status), 3),
              (L(!0), A(ve, null, Pe(u.value.candidates, (pe, Ee) => (L(), A("button", {
                key: `${pe.language}:${Ee}`,
                class: d(r(t).e("detection-option")),
                type: "button",
                disabled: u.value.status !== "success",
                onMousedown: I[17] || (I[17] = N(() => {
                }, ["prevent"])),
                onClick: (He) => ua(Ee)
              }, [
                b("span", null, Q(pe.language || "Unsupported"), 1),
                b("span", null, Q(Math.round(pe.confidence * 100)) + "%", 1)
              ], 42, Tl))), 128))
            ], 2)) : V("", !0),
            ce.value.length ? (L(), A("div", {
              key: 1,
              class: d(r(t).e("diagnostics"))
            }, [
              (L(!0), A(ve, null, Pe(ce.value, (pe) => (L(), A("div", {
                key: `${pe.code}:${pe.path}`,
                class: d(r(t).e("diagnostic"))
              }, Q(pe.message), 3))), 128))
            ], 2)) : V("", !0)
          ], 34)) : V("", !0),
          Je(b("div", {
            ref_key: "bodyRef",
            ref: f,
            class: d(r(t).e("body")),
            style: De(z.value),
            hidden: y.value.body.collapsed,
            "aria-hidden": y.value.body.collapsed,
            "data-zx-folding-decision": r(J).status,
            "data-zx-folding-reason": r(J).reason
          }, [
            r(ae) !== "none" ? (L(), Ce(nl, {
              key: 0,
              mode: r(ae),
              rows: r(H),
              "highlighted-line-numbers": K.value,
              onToggleFold: r(ie)
            }, null, 8, ["mode", "rows", "highlighted-line-numbers", "onToggleFold"])) : V("", !0),
            Je(b("pre", {
              ref_key: "canonicalContentRef",
              ref: g,
              class: d(r(t).e("pre")),
              hidden: r(de),
              "aria-hidden": r(de),
              "data-zx-code-canonical-content": "true"
            }, [
              B(r(Rn), {
                as: "code",
                class: d(r(t).e("code")),
                style: De(oe.value)
              }, null, 8, ["class", "style"])
            ], 10, Il), [
              [tn, !r(de)]
            ]),
            r(de) ? (L(), Ce(Qr, {
              key: 1,
              rows: r(H),
              code: C.value,
              language: k.value.attrs.language,
              onToggleFold: r(ie),
              onRequestEdit: M
            }, null, 8, ["rows", "code", "language", "onToggleFold"])) : V("", !0),
            y.value.body.codePlaceholder ? (L(), A("div", {
              key: 2,
              class: d(r(t).e("empty-state")),
              contenteditable: "false"
            }, [
              b("span", null, Q(y.value.body.codePlaceholder), 1),
              b("span", {
                class: d(r(t).e("empty-state-meta"))
              }, Q(y.value.header.languageLabel), 3)
            ], 2)) : V("", !0)
          ], 14, Ll), [
            [tn, !y.value.body.collapsed]
          ]),
          y.value.body.collapsed ? (L(), Ce(Kr, {
            key: 1,
            lines: y.value.body.visibleVisualLines,
            "line-numbers": y.value.body.visibleLineNumbers,
            "total-line-count": y.value.body.visualLineCount,
            "show-line-numbers": y.value.body.showLineNumbers,
            onRequestExpand: Y
          }, null, 8, ["lines", "line-numbers", "total-line-count", "show-line-numbers"])) : V("", !0),
          n.editor.isEditable || y.value.header.caption ? (L(), A("label", {
            key: 2,
            class: d(r(t).e("caption")),
            contenteditable: "false"
          }, [
            b("span", {
              class: d(r(t).e("caption-label"))
            }, "说明", 2),
            b("input", {
              value: y.value.header.caption,
              class: d(r(t).e("caption-input")),
              placeholder: y.value.body.captionPlaceholder || "",
              disabled: !n.editor.isEditable,
              onMousedown: I[19] || (I[19] = N(() => {
              }, ["stop"])),
              onInput: ye
            }, null, 42, Sl)
          ], 2)) : V("", !0),
          y.value.body.collapsed ? V("", !0) : (L(), A("div", {
            key: 3,
            class: d([
              r(t).e("resize-handle"),
              r(t).is("visible", i.value || r(se))
            ]),
            contenteditable: "false",
            onMousedown: N(da, ["prevent"])
          }, [
            b("div", {
              class: d(r(t).e("resize-bar"))
            }, null, 2)
          ], 34))
        ];
      }),
      _: 1
    }, 8, ["class", "data-zx-code-contract-version", "data-zx-code-language"]));
  }
}), At = " ".repeat(4), Pl = new RegExp("(?<=^|[^`])`([^`]+)`(?!`)$"), Ml = /^(```|~~~)([a-zA-Z0-9#+.-]*)[\s\n]$/;
function hn(e) {
  const { $from: t, from: n, to: a } = e.selection;
  let o = t.depth;
  for (; o > 0 && t.node(o).type.name !== "codeBlock"; ) o--;
  if (o === 0) return null;
  const i = t.node(o), s = t.start(o), l = i.textContent, m = n - s, c = a - s;
  return { start: s, text: l, fromOffset: m, toOffset: c };
}
function jn(e, t, n) {
  const a = e.lastIndexOf(`
`, Math.max(0, t - 1)) + 1;
  let o = n;
  o > 0 && e[o - 1] === `
` && o--;
  const i = [a];
  let s = a;
  for (; ; ) {
    const l = e.indexOf(`
`, s);
    if (l === -1 || l >= o) break;
    i.push(l + 1), s = l + 1;
  }
  return i;
}
const Dl = kn(Cn), Rl = ai.extend({
  addOptions() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      codeBlockPreferences: null
    };
  },
  addAttributes() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      ...so()
    };
  },
  addCommands() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      updateCodeBlockV2Attrs: io(),
      updateCodeBlockV2AttrsAt: oo(),
      updateCodeBlockV2AttrsById: ao(),
      applyCodeBlockBulkPreview: no(),
      applyCodeBlockTabEditPatches: to(),
      reorderCodeBlockTabById: eo()
    };
  },
  addNodeView() {
    return Ge(Al);
  },
  addInputRules() {
    var e;
    return [
      ha({
        find: Ml,
        type: this.type,
        getAttributes: (t) => Qa({
          language: t[2] || null,
          preferences: this.options.codeBlockPreferences,
          source: "markdown-fence"
        }).attrs
      }),
      ...((e = this.parent) == null ? void 0 : e.call(this)) ?? []
    ];
  },
  addKeyboardShortcuts() {
    var e;
    return {
      ...(e = this.parent) == null ? void 0 : e.call(this),
      Tab: () => {
        const { state: t, dispatch: n } = this.editor.view, a = hn(t);
        if (!a) return !1;
        const { start: o, text: i, fromOffset: s, toOffset: l } = a, m = i.slice(s, l).includes(`
`), c = t.tr;
        if (m)
          for (const u of jn(i, s, l)) {
            const j = c.mapping.map(o + u);
            c.insertText(At, j);
          }
        else
          c.insertText(At, t.selection.from);
        return n(c), !0;
      },
      "Shift-Tab": () => {
        const { state: t, dispatch: n } = this.editor.view, a = hn(t);
        if (!a) return !1;
        const { start: o, text: i, fromOffset: s, toOffset: l } = a, m = t.tr;
        for (const c of jn(i, s, l)) {
          let u = 0;
          if (i.slice(c, c + 4) === At ? u = 4 : i[c] === "	" && (u = 1), u > 0) {
            const j = m.mapping.map(o + c), f = m.mapping.map(o + c + u);
            m.delete(j, f);
          }
        }
        return n(m), !0;
      },
      // Mod-a progressive selection is owned by TextEditorShortcutKeymap
      // (catalog textEditor.progressiveSelect). Do not re-register here.
      "Mod-Enter": () => {
        const { state: t, dispatch: n } = this.editor.view, { selection: a } = t, { $from: o } = a;
        let i = o.depth;
        for (; i > 0 && o.node(i).type.name !== "codeBlock"; )
          i--;
        if (i === 0)
          return fn(t, n);
        const s = o.before(i), l = o.node(i), m = s + l.nodeSize, u = t.doc.resolve(m).nodeAfter;
        if ((u == null ? void 0 : u.type.name) === "paragraph" && u.content.size === 0) {
          const j = t.tr.setSelection(
            Ke.create(t.doc, m + 1)
          );
          return n(j.scrollIntoView()), !0;
        }
        return fn(t, n);
      },
      "`": () => {
        const { from: t, to: n } = this.editor.state.selection;
        return t === n ? !1 : this.editor.commands.toggleCode();
      }
    };
  }
}).configure({ lowlight: Dl }), Ol = oi.extend({
  addKeyboardShortcuts() {
    return {
      "Mod-e": () => this.editor.commands.toggleCode(),
      "`": () => {
        const { from: e, to: t } = this.editor.state.selection;
        return e === t ? !1 : this.editor.commands.toggleCode();
      }
    };
  },
  addInputRules() {
    return [
      ga({
        find: Pl,
        type: this.type
      })
    ];
  }
}), Nl = ri.extend({
  addProseMirrorPlugins() {
    this.options.key == null && (this.options.key = "Mod");
    const e = this.parent;
    return (e == null ? void 0 : e.call(this)) ?? [];
  },
  addKeyboardShortcuts() {
    const e = this.parent, n = { ...(e == null ? void 0 : e.call(this)) ?? {} };
    return delete n["Mod-a"], n;
  }
}), $l = (e) => [e.name, e.type, e.size, e.lastModified].join("::"), zl = (e) => {
  var a;
  if ((a = e == null ? void 0 : e.files) != null && a.length)
    return [];
  const t = [], n = /* @__PURE__ */ new Set();
  return Array.from((e == null ? void 0 : e.items) ?? []).forEach((o) => {
    if (o.kind !== "file")
      return;
    const i = o.getAsFile();
    if (!i)
      return;
    const s = $l(i);
    n.has(s) || (n.add(s), t.push(i));
  }), t;
}, Bl = (e, t, n) => {
  e && (xn("text-editor:file-intake", "drop files captured", {
    files: t.map((a) => ({
      name: a.name,
      type: a.type,
      size: a.size
    })),
    dropPos: n
  }), Promise.resolve(
    e.intakeFiles({
      source: "drop",
      files: t,
      dropPos: n,
      anchorPos: n
    })
  ).catch((a) => {
    e.emitDiagnostic({
      code: "drop-intake-dispatch-failed",
      message: a instanceof Error ? a.message : "Failed to dispatch dropped files.",
      severity: "error",
      stage: "intake",
      cause: a
    });
  }));
}, Fl = (e, t, n) => {
  e && (xn("text-editor:file-intake", "paste files captured", {
    files: t.map((a) => ({
      name: a.name,
      type: a.type,
      size: a.size
    })),
    hasHtmlContent: !!n
  }), Promise.resolve(
    e.intakeFiles({
      source: "paste",
      files: t,
      htmlContent: n || void 0
    })
  ).catch((a) => {
    e.emitDiagnostic({
      code: "paste-intake-dispatch-failed",
      message: a instanceof Error ? a.message : "Failed to dispatch pasted files.",
      severity: "error",
      stage: "intake",
      cause: a
    });
  }));
}, Hl = ci.extend({
  addProseMirrorPlugins() {
    var t;
    return [
      ...((t = this.parent) == null ? void 0 : t.call(this)) ?? [],
      new Ne({
        key: new Me("fileHandlerClipboardItemFallback"),
        props: {
          handlePaste: (n, a) => {
            var i, s, l;
            const o = zl(a.clipboardData);
            return o.length === 0 ? !1 : (a.preventDefault(), a.stopPropagation(), (l = (s = this.options).onPaste) == null || l.call(
              s,
              this.editor,
              o,
              ((i = a.clipboardData) == null ? void 0 : i.getData("text/html")) || void 0
            ), !0);
          }
        }
      })
    ];
  }
}), Vl = ({
  filePlatformRuntime: e
}) => Hl.configure({
  consumePasteEvent: !0,
  onDrop: (t, n, a) => {
    Bl(e, n, a);
  },
  onPaste: (t, n, a) => {
    Fl(e, n, a);
  }
}), ql = Object.freeze({
  firstParagraph: "请输入内容...",
  headings: Object.freeze({
    1: "Heading 1",
    2: "Heading 2",
    3: "Heading 3",
    4: "Heading 4",
    5: "Heading 5",
    6: "Heading 6"
  }),
  bulletList: "Bullet List",
  orderedList: "Numbered List",
  taskItem: "To-do",
  blockquote: "Quote",
  codeBlock: "Code",
  toggle: "Toggle heading"
}), Wl = (e = {}) => {
  const t = e.base ?? ql, n = e.override ?? null, a = { ...t.headings };
  if (n != null && n.headings)
    for (const o of [1, 2, 3, 4, 5, 6])
      Object.prototype.hasOwnProperty.call(n.headings, o) && (a[o] = n.headings[o]);
  return Object.freeze({
    firstParagraph: n && Object.prototype.hasOwnProperty.call(n, "firstParagraph") ? n.firstParagraph ?? "" : t.firstParagraph,
    headings: Object.freeze(a),
    bulletList: n && Object.prototype.hasOwnProperty.call(n, "bulletList") ? n.bulletList ?? "" : t.bulletList,
    orderedList: n && Object.prototype.hasOwnProperty.call(n, "orderedList") ? n.orderedList ?? "" : t.orderedList,
    taskItem: n && Object.prototype.hasOwnProperty.call(n, "taskItem") ? n.taskItem ?? "" : t.taskItem,
    blockquote: n && Object.prototype.hasOwnProperty.call(n, "blockquote") ? n.blockquote ?? "" : t.blockquote,
    codeBlock: n && Object.prototype.hasOwnProperty.call(n, "codeBlock") ? n.codeBlock ?? "" : t.codeBlock,
    toggle: n && Object.prototype.hasOwnProperty.call(n, "toggle") ? n.toggle ?? "" : t.toggle
  });
}, Ul = ro, Kl = qe.create({
  name: "deterministicRuntimeCommitClosure",
  addProseMirrorPlugins() {
    return [
      ...di.map((e) => e.plugin),
      pi
    ];
  }
}), Xl = (e) => !!e, it = (e) => (e == null ? void 0 : e.name) ?? null, Gl = (e, t) => e.some((n) => it(n) === t), Zl = (e, t = Ul) => e.filter((n) => {
  const a = it(n);
  return !a || !t.has(a);
}), Yl = (e, t) => e.map((n) => {
  const a = n.options;
  return !a || !Object.prototype.hasOwnProperty.call(a, "themeOwner") ? n : n.configure({ themeOwner: t ?? null });
}), Jl = (e) => {
  const t = /* @__PURE__ */ new Map();
  e.forEach((o) => {
    const i = it(o);
    i && t.set(i, o);
  });
  const n = /* @__PURE__ */ new Set(), a = [];
  return e.forEach((o) => {
    const i = it(o);
    if (!i) {
      a.push(o);
      return;
    }
    n.has(i) || (n.add(i), a.push(t.get(i) ?? o));
  }), a;
}, Ql = new Map(
  yn.map(
    (e) => [
      e.name,
      e
    ]
  )
), em = (e) => {
  const t = [];
  return e.forEach((n) => {
    const a = Ql.get(n);
    a && t.push(a);
  }), t;
}, tm = (e, t) => e.allowExternalOverride && Lo(e).some(
  (n) => Gl(t, n)
), nt = (e, t, n) => Hs(
  {
    themeOwner: t.themeOwner,
    filePlatform: t.filePlatform,
    filePlatformRuntime: t.filePlatformRuntime,
    getCurrentDocument: t.getCurrentDocument ?? null,
    mentions: t.mentions,
    suggestions: t.suggestions,
    tags: t.tags
  },
  em(e).filter(
    (a) => !tm(a, n)
  )
), nm = (e) => ({ node: t, editor: n, pos: a }) => {
  var m;
  const { doc: o } = n.state;
  if (a < 0 || a > o.content.size) return "";
  const i = o.resolve(a), s = /* @__PURE__ */ new Set();
  for (let c = i.depth; c > 0; c--)
    s.add(i.node(c).type.name);
  const l = o.firstChild === t || ((m = o.firstChild) == null ? void 0 : m.content.firstChild) === t;
  if (t.type.name === "paragraph") {
    if (s.has("taskItem"))
      return e.taskItem;
    if (s.has("bulletList"))
      return e.bulletList;
    if (s.has("orderedList"))
      return e.orderedList;
  }
  if (t.type.name === "paragraph" && l)
    return e.firstParagraph;
  if (t.type.name === "heading") {
    const c = t.attrs.level ?? 1, u = c >= 1 && c <= 6 ? c : 1;
    return e.headings[u];
  }
  switch (t.type.name) {
    case "blockquote":
      return e.blockquote;
    case "codeBlock":
      return e.codeBlock;
    case "toggle":
      return e.toggle;
    default:
      return "";
  }
}, Um = (e = {}) => {
  var u, j, f, g, h;
  const t = Yl(
    Zl(e.extensions ?? []),
    e.themeOwner
  ), n = lo({
    override: e.typography
  }), a = typeof e.placeholder == "string" && e.placeholder ? { firstParagraph: e.placeholder } : null, o = e.placeholderContract || a ? {
    ...e.placeholderContract ?? {},
    ...a ?? {}
  } : e.placeholderContract, i = Wl({
    override: o
  }), s = nm(i), l = typeof e.placeholder == "function" ? e.placeholder : null, m = l ? (p) => {
    const x = l(p);
    return typeof x == "string" ? x : s(p);
  } : s, c = mo(
    Jl(
      [
        Do.configure({
          ...ko(e.starterkitOptions)
        }),
        Kl,
        qo,
        co.configure(
          Co(e.starterkitOptions)
        ),
        No.configure({ ...xo }),
        Ho,
        Vo.configure({ ...Eo }),
        uo,
        po,
        fo,
        $o,
        Oo.configure({ types: [...To] }),
        zo,
        Bo,
        Fo,
        go.configure({
          contract: n
        }),
        e.pages === !1 ? !1 : ho.configure({
          getCurrentDocument: e.getCurrentDocument ?? null,
          ...e.pages ?? {}
        }),
        e.pages === !1 ? !1 : jo,
        e.pages === !1 ? !1 : vo,
        e.pagesHeaderFooter !== void 0 && e.pagesHeaderFooter !== !1 && bo.configure({
          getCurrentDocument: e.getCurrentDocument ?? null,
          editable: e.editable,
          ...e.pagesHeaderFooter ?? {}
        }),
        e.pagesLayout !== void 0 && e.pagesLayout !== !1 && _o.configure(e.pagesLayout),
        ...nt(
          ["comment", "namedColor", "namedHighlight"],
          e,
          t
        ),
        Ol,
        Rl.configure({
          codeBlockPreferences: e.codeBlockPreferences ?? null
        }),
        yo,
        Xs({
          runtime: e.shortcutRuntime,
          parent: e.shortcutParentOwner,
          existingExtensionNames: (e.extensions ?? []).map(
            it
          )
        }),
        ...nt(
          ["attachment", "image", "imageGroup", "video", "iframe"],
          e,
          t
        ),
        ir.configure({
          openOnClick: !1,
          themeOwner: e.themeOwner ?? null
        }),
        ps({
          assetPipelineRuntime: e.assetPipelineRuntime ?? null
        }),
        Vl({
          filePlatformRuntime: e.filePlatformRuntime ?? null
        }),
        Ro.configure({
          // - placeholder (string) is merged into the contract as firstParagraph.
          // - placeholder (function) can override per-node behavior and falls back
          //   to the contract-driven placeholder when it returns a non-string value.
          placeholder: m,
          // Apply placeholders to nested blocks (e.g. paragraphs inside lists),
          // to match Notion-style list placeholders.
          includeChildren: !0
        }),
        ...nt(
          ["mention"],
          e,
          t
        ),
        ur.configure({
          suggestion: ((u = e.suggestions) == null ? void 0 : u.emoji) ?? {},
          themeOwner: e.themeOwner ?? null
        }),
        Lr.configure({
          suggestion: ((j = e.suggestions) == null ? void 0 : j.slash) ?? {},
          codeBlockPreferences: e.codeBlockPreferences ?? null,
          catalogContributions: e.slashCatalogContributions ?? null,
          themeOwner: e.themeOwner ?? null
        }),
        ...nt(
          ["tag", "embed"],
          e,
          t
        ),
        // Unified drop/paste file adapters own File[] intake. ContentPaste keeps
        // markdown and HTML bridging until intent classification fully lands.
        Pr.configure({
          enabled: !0,
          filePlatformRuntime: e.filePlatformRuntime,
          codeBlockPreferences: e.codeBlockPreferences ?? null
        }),
        ...nt(
          ["toggle"],
          e,
          t
        ),
        e.dragHandle && Nl.configure({
          key: null,
          depth: 0
        }),
        wo.configure({
          types: (f = e.stableBlockIdentity) == null ? void 0 : f.types,
          generateId: (g = e.stableBlockIdentity) == null ? void 0 : g.generateId,
          filterRemoteTransactions: (h = e.stableBlockIdentity) == null ? void 0 : h.filterRemoteTransactions
        }),
        ...t
      ].filter(
        (p) => Xl(p)
      )
    )
  );
  return e.contentProfile === "basic-rich-text" ? [...c.map(Xn), er({ limits: e.contentLimits, issue: e.onContentIssue })] : c;
};
export {
  wi as $,
  Wm as A,
  Hm as B,
  Pr as C,
  Vm as D,
  ki as E,
  Kn as F,
  qm as G,
  Ts as H,
  Vi as I,
  Al as J,
  dl as K,
  ir as L,
  Zi as M,
  al as N,
  il as O,
  Un as P,
  _t as Q,
  Ns as R,
  Lr as S,
  is as T,
  $s as U,
  Rs as V,
  zs as W,
  Fn as X,
  Hn as Y,
  It as Z,
  ar as _,
  Ol as a,
  dr as a0,
  Gn as a1,
  xs as a2,
  Rl as b,
  ns as c,
  Mi as d,
  Ms as e,
  ur as f,
  jr as g,
  br as h,
  vr as i,
  vi as j,
  yi as k,
  Hs as l,
  hr as m,
  Ul as n,
  it as o,
  Gl as p,
  Zl as q,
  Tr as r,
  Um as s,
  at as t,
  rs as u,
  ds as v,
  ps as w,
  zt as x,
  Us as y,
  Ks as z
};
//# sourceMappingURL=runtime-extensions-B_GmfVEg.mjs.map
