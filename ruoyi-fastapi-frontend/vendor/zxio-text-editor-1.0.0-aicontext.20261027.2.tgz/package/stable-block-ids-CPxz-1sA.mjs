import { f as k, G as h, i as S, e as g, H as f } from "./envelope-CrN5-dS1.mjs";
import { f as u } from "./actions-Sd62WBGv.mjs";
const B = (n) => JSON.parse(JSON.stringify(n)), T = (n) => n.length === 0 ? "root" : n.map((s) => `content.${s}`).join("."), v = (n, s = {}) => {
  const c = B(n), t = /* @__PURE__ */ new Set(), r = [];
  let d = 0;
  const b = k(s.types), i = (e, y) => {
    var p;
    if (b.includes(e.type ?? "")) {
      const o = h(e.attrs), l = o ? S(o) ? t.has(o) ? "duplicate" : null : "invalid" : "missing";
      let a = o;
      if (l && (a = g(
        {
          nodeType: e.type ?? "unknown",
          nodeAttrs: e.attrs ?? {}
        },
        t,
        s.generateId
      ), r.push({
        nodeType: e.type ?? "unknown",
        path: T(y),
        previousBlockId: o,
        nextBlockId: a,
        reason: l
      })), a) {
        const I = f(
          e.type ?? "unknown",
          e.attrs,
          a
        );
        e.attrs = I.attrs, I.headingIdentityChanged && (d += 1), t.add(a);
      }
    }
    (p = e.content) == null || p.forEach((o, l) => {
      i(o, [...y, l]);
    });
  };
  return i(c, []), {
    content: c,
    regeneratedBlockIds: r.length,
    synchronizedHeadingIdentities: d,
    repairs: r
  };
}, z = (n, s = {}) => {
  const c = new Set(k(s.types));
  return u(n).issues.filter((t) => c.has(t.nodeType)).map((t) => ({
    blockId: t.blockId,
    code: t.code,
    nodeType: t.nodeType,
    path: t.path === "$.body.content" ? "root" : t.path.replace("$.body.content.", "").replace(/content\[(\d+)\]/g, "content.$1")
  }));
};
export {
  z as a,
  v as c
};
//# sourceMappingURL=stable-block-ids-CPxz-1sA.mjs.map
