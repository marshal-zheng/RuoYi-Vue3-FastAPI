import { E as f } from "./use-text-editor-command-keybindings-C18Z3ZZ3.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-video-DTLd299x.mjs.map
