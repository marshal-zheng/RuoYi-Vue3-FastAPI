import { d as y, s as E } from "./definition-DiwrtpbT.mjs";
import { R as v, a as A, b as F, c as R } from "./manifest-DmJF7R9Y.mjs";
const x = [], l = /* @__PURE__ */ new WeakMap(), C = /* @__PURE__ */ new WeakSet(), P = (n) => {
  C.add(n);
}, c = (n, t) => Object.prototype.hasOwnProperty.call(n, t), I = (n) => n !== null && (typeof n == "object" || typeof n == "function") ? n : null, f = (n) => {
  const t = l.get(n);
  if (t) return t;
  const e = Symbol();
  return l.set(n, e), e;
}, m = (n) => {
  const t = [];
  for (const e of n) {
    const i = I(e);
    if (!i) return null;
    t.push(f(i));
  }
  return Object.freeze(t);
}, b = (n, t) => n.length === t.length && n.every((e, i) => {
  const r = I(e);
  return !!(r && l.get(r) === t[i]);
}), S = (n) => n !== null && typeof n == "object" && C.has(n) ? "collaboration-transport" : typeof n == "function" ? "function" : n !== null && typeof n == "object" ? "object" : "other", T = (n) => {
  var p, h;
  if (!n || typeof n != "object") return null;
  const t = n, e = (p = Object.getPrototypeOf(n)) == null ? void 0 : p.constructor;
  if (typeof e != "function" || t.constructor !== e || !c(t, "callbacks") || !c(t, "commandManager") || !c(t, "destroyed") || !c(t, "extensionManager") || !c(t, "extensionStorage") || !c(t, "instanceId") || !c(t, "options") || !c(t, "schema") || !c(t, "editorState") || t.destroyed !== !1 || !t.callbacks || typeof t.callbacks != "object" || !t.commandManager || typeof t.commandManager != "object" || t.commandManager.editor !== n || !t.extensionManager || typeof t.extensionManager != "object" || !t.extensionStorage || typeof t.extensionStorage != "object" || typeof t.instanceId != "string" || !/^[a-z0-9]{7}$/.test(t.instanceId) || !t.options || typeof t.options != "object" || !t.schema || typeof t.schema != "object") return null;
  const i = t.callbacks, r = t.extensionManager, g = t.options, a = t.state, d = t.view, o = g.extensions, s = Array.isArray(o) ? o[0] : null, u = (h = s && typeof s == "object" ? Object.getPrototypeOf(s) : null) == null ? void 0 : h.constructor;
  return !Array.isArray(i.beforeCreate) || i.beforeCreate.length === 0 || !Array.isArray(i.destroy) || i.destroy.length === 0 || r.editor !== n || r.schema !== t.schema || !Array.isArray(r.baseExtensions) || !Array.isArray(r.extensions) || !Array.isArray(o) || o.length === 0 || typeof u != "function" || typeof r.constructor != "function" || !a || typeof a != "object" || !d || typeof d != "object" || d.state !== a || a.schema !== t.schema ? null : { editor: t, editorConstructor: e, extensionConstructor: u, extensionManager: r, extensionManagerConstructor: r.constructor, optionExtensions: o, managerBaseExtensions: r.baseExtensions, managerResolvedExtensions: r.extensions };
}, M = (n) => {
  try {
    return T(n);
  } catch {
    return null;
  }
}, k = (n) => {
  try {
    return c(n, "destroyed") ? n.destroyed === !0 : null;
  } catch {
    return null;
  }
}, O = (n, t) => {
  const e = M(n);
  return !!(e && l.get(e.editorConstructor) === t.editorConstructorIdentity && l.get(e.extensionConstructor) === t.extensionConstructorIdentity && l.get(e.extensionManager) === t.extensionManagerIdentity && l.get(e.extensionManagerConstructor) === t.extensionManagerConstructorIdentity && b(e.optionExtensions, t.optionExtensionIdentities) && b(e.managerBaseExtensions, t.managerBaseExtensionIdentities) && b(e.managerResolvedExtensions, t.managerResolvedExtensionIdentities));
}, B = (n, t) => {
  const e = m(n.optionExtensions), i = m(n.managerBaseExtensions), r = m(n.managerResolvedExtensions);
  if (!e || !i || !r) return null;
  const g = y({ assemblyComponentId: "zx.text-editor.editor-runtime-assembly", assemblySourceFingerprint: R, authoritySourceFingerprint: F, registrySourceFingerprint: A, stateSourceFingerprint: v }), a = y(t.map((s, u) => ({ order: u, runtimeType: S(s) }))), d = E(a), o = y({ bindingFingerprint: E({ protocol: "zx-text-editor-runtime-host-composition-binding-v5", assemblyIntegrity: g, externalExtensionsFingerprint: d }), assemblyIntegrity: g, externalExtensionsFingerprint: d });
  return y({ proof: o, externalExtensions: a, editorConstructorIdentity: f(n.editorConstructor), extensionConstructorIdentity: f(n.extensionConstructor), extensionManagerIdentity: f(n.extensionManager), extensionManagerConstructorIdentity: f(n.extensionManagerConstructor), optionExtensionIdentities: e, managerBaseExtensionIdentities: i, managerResolvedExtensionIdentities: r });
}, V = (n) => {
  const t = M(n.targetEditor);
  if (!t) return null;
  const e = B(t, n.externalExtensions);
  return e ? (x.push({ issued: e, targetEditor: new WeakRef(n.targetEditor), invalidated: !1 }), e.proof.bindingFingerprint) : null;
}, j = (n) => {
  const t = [];
  let e = 0;
  for (let o = x.length - 1; o >= 0; o -= 1) {
    const s = x[o], u = s.targetEditor.deref();
    if (!u) {
      x.splice(o, 1);
      continue;
    }
    const p = k(u);
    if (p === !0) {
      x.splice(o, 1);
      continue;
    }
    if (!(n && u !== n)) {
      if (p === null || s.invalidated || !O(u, s.issued)) {
        s.invalidated = !0, e += 1;
        continue;
      }
      t.push(s.issued);
    }
  }
  const i = t.sort((o, s) => o.proof.bindingFingerprint < s.proof.bindingFingerprint ? -1 : o.proof.bindingFingerprint > s.proof.bindingFingerprint ? 1 : 0);
  let r = 0;
  const g = [...i.flatMap((o) => o.externalExtensions.map((s) => ({ order: r++, runtimeType: s.runtimeType }))), ...Array.from({ length: e }, () => ({ order: r++, runtimeType: "other" }))], a = i.length + e, d = { protocol: "zx-text-editor-runtime-host-composition-v2", bindingState: a ? "active-editor-bound" : "unbound", activeEditorCount: a, bindings: i.map((o) => o.proof), externalExtensions: g };
  return y({ ...d, fingerprint: E(d) });
}, H = () => j(), W = (n) => j(n);
export {
  V as bindPackageTextEditorRuntimeHostEditorV2,
  P as certifyRuntimeHostCollaborationTransportExtensionV2,
  W as readTextEditorRuntimeHostCompositionForTargetV2,
  H as readTextEditorRuntimeHostCompositionV2
};
//# sourceMappingURL=runtime-host-core-authority.mjs.map
