"use strict";const r=e=>new Promise(e);Promise.all.bind(Promise);const s=e=>Promise.reject(e),o=e=>Promise.resolve(e);exports.create=r;exports.reject=s;exports.resolve=o;
//# sourceMappingURL=promise-JImdLuJf.js.map
