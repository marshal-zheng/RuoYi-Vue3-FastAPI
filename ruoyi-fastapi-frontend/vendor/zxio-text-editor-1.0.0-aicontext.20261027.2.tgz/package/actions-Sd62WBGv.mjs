import { Schema as Fe } from "prosemirror-model";
import { defineContextKey as He, defineAction as R, defineShortcutContribution as Ue, context as Ve } from "@zxio/keybindings/core";
class A extends TypeError {
  constructor(t, n) {
    super(`Cannot canonicalize ${t}: ${n}`), this.name = "ZxCanonicalJSONError", this.path = t;
  }
}
class H extends A {
  constructor(t, n, o) {
    super(t, n), this.name = "ZxCanonicalJSONResourceError", this.usage = o;
  }
}
const Te = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]), Y = (e, t) => {
  for (let n = 0; n < e.length; n += 1) {
    const o = e.charCodeAt(n);
    if (o >= 55296 && o <= 56319) {
      const s = e.charCodeAt(n + 1);
      if (!(s >= 56320 && s <= 57343))
        throw new A(
          t,
          "strings must contain valid Unicode"
        );
      n += 1;
      continue;
    }
    if (o >= 56320 && o <= 57343)
      throw new A(t, "strings must contain valid Unicode");
  }
}, Ne = (e, t) => {
  if (Object.getPrototypeOf(e) !== Array.prototype)
    throw new A(t, "only plain arrays are supported");
  const n = Reflect.ownKeys(e);
  if (n.some((o) => typeof o == "symbol"))
    throw new A(t, "symbol keys are not supported");
  if (n.length !== e.length + 1 || !n.includes("length"))
    throw new A(
      t,
      "arrays must be dense and contain no extra properties"
    );
  return Array.from({ length: e.length }, (o, s) => {
    const r = Object.getOwnPropertyDescriptor(e, String(s));
    if (!r || !r.enumerable || !("value" in r))
      throw new A(
        `${t}[${s}]`,
        "array entries must be enumerable data properties"
      );
    return r;
  });
}, me = (e, t, n) => {
  if (e === null) return "null";
  switch (typeof e) {
    case "string":
      return Y(e, t), JSON.stringify(e);
    case "boolean":
      return JSON.stringify(e);
    case "number":
      if (!Number.isFinite(e))
        throw new A(t, "numbers must be finite");
      if (Object.is(e, -0))
        throw new A(t, "negative zero is ambiguous");
      return JSON.stringify(e);
    case "undefined":
    case "function":
    case "symbol":
    case "bigint":
      throw new A(t, `${typeof e} is not supported`);
  }
  const o = e;
  if (n.has(o))
    throw new A(t, "cyclic values are not supported");
  const s = new Set(n);
  if (s.add(o), Array.isArray(e))
    return `[${Ne(e, t).map(
      (l, p) => me(l.value, `${t}[${p}]`, s)
    ).join(",")}]`;
  const r = Object.getPrototypeOf(e);
  if (r !== Object.prototype && r !== null)
    throw new A(t, "only plain objects are supported");
  const c = e, d = Reflect.ownKeys(c);
  if (d.some((l) => typeof l == "symbol"))
    throw new A(t, "symbol keys are not supported");
  const a = d;
  return a.forEach((l) => {
    if (Y(l, `${t}.<key>`), Te.has(l))
      throw new A(t, `forbidden object key "${l}"`);
    const p = Object.getOwnPropertyDescriptor(c, l);
    if (!p || !p.enumerable || !("value" in p))
      throw new A(
        `${t}.${l}`,
        "only enumerable data properties are supported"
      );
  }), `{${a.sort().map((l) => {
    const p = Object.getOwnPropertyDescriptor(c, l);
    return `${JSON.stringify(l)}:${me(
      p.value,
      `${t}.${l}`,
      s
    )}`;
  }).join(",")}}`;
}, v = (e) => me(e, "$", /* @__PURE__ */ new Set()), pe = (e, t, n, o, s, r) => {
  const c = (m) => {
    if (r.estimatedBytes += m, r.estimatedBytes > t.maxBytes)
      throw new H(
        n,
        "maximum encoded bytes exceeded",
        {
          depth: r.depth,
          arrayEntries: r.arrayEntries,
          maxKeysPerObject: r.maxKeysPerObject,
          objectKeys: r.objectKeys,
          bytes: r.estimatedBytes
        }
      );
  };
  if (r.depth = Math.max(r.depth, o), o > t.maxDepth)
    throw new H(n, "maximum depth exceeded", {
      ...r,
      bytes: null
    });
  if (e === null) {
    c(4);
    return;
  }
  if (typeof e != "object") {
    typeof e == "string" && Y(e, n);
    const m = typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isFinite(e) && !Object.is(e, -0) ? JSON.stringify(e) : void 0;
    if (m === void 0)
      throw new A(n, `${typeof e} is not supported`);
    c(new TextEncoder().encode(m).length);
    return;
  }
  if (s.has(e))
    throw new A(n, "cyclic values are not supported");
  const d = new Set(s);
  if (d.add(e), Array.isArray(e)) {
    if (r.arrayEntries += e.length, r.arrayEntries > t.maxArrayEntries)
      throw new H(
        n,
        "maximum array entries exceeded",
        { ...r, bytes: null }
      );
    c(2 + Math.max(0, e.length - 1)), Ne(e, n).forEach(
      (m, b) => pe(
        m.value,
        t,
        `${n}[${b}]`,
        o + 1,
        d,
        r
      )
    );
    return;
  }
  const a = Object.getPrototypeOf(e);
  if (a !== Object.prototype && a !== null)
    throw new A(n, "only plain objects are supported");
  const l = Reflect.ownKeys(e);
  if (l.some((m) => typeof m == "symbol"))
    throw new A(n, "symbol keys are not supported");
  const p = l.filter(
    (m) => typeof m == "string"
  );
  if (r.maxKeysPerObject = Math.max(r.maxKeysPerObject, p.length), r.maxKeysPerObject > t.maxObjectKeys)
    throw new H(
      n,
      "maximum object keys exceeded",
      { ...r, bytes: null }
    );
  if (r.objectKeys += p.length, r.objectKeys > t.maxTotalObjectKeys)
    throw new H(
      n,
      "maximum total object keys exceeded",
      {
        depth: r.depth,
        arrayEntries: r.arrayEntries,
        maxKeysPerObject: r.maxKeysPerObject,
        objectKeys: r.objectKeys,
        bytes: r.estimatedBytes
      }
    );
  c(2 + Math.max(0, p.length - 1)), p.forEach((m) => {
    if (Y(m, `${n}.<key>`), Te.has(m))
      throw new A(n, `forbidden object key "${m}"`);
    const b = Object.getOwnPropertyDescriptor(e, m);
    if (!b || !b.enumerable || !("value" in b))
      throw new A(
        `${n}.${m}`,
        "only enumerable data properties are supported"
      );
    c(new TextEncoder().encode(JSON.stringify(m)).length + 1), pe(
      b.value,
      t,
      `${n}.${m}`,
      o + 1,
      d,
      r
    );
  });
}, qe = (e, t) => {
  const n = {
    depth: 0,
    arrayEntries: 0,
    maxKeysPerObject: 0,
    objectKeys: 0,
    estimatedBytes: 0
  };
  pe(e, t, "$", 0, /* @__PURE__ */ new Set(), n);
  const o = v(e), s = new TextEncoder().encode(o).length, { estimatedBytes: r, ...c } = n, d = { bytes: s, ...c };
  if (s > t.maxBytes)
    throw new H(
      "$",
      "maximum encoded bytes exceeded",
      d
    );
  return { canonical: o, usage: d };
}, nn = (e) => new TextEncoder().encode(v(e)), E = (e) => !e || typeof e != "object" || Object.isFrozen(e) || ArrayBuffer.isView(e) ? e : (Array.isArray(e) ? e.forEach((t) => E(t)) : Object.values(e).forEach((t) => E(t)), Object.freeze(e)), z = (e, t) => e >>> t | e << 32 - t, Je = Object.freeze([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), Xe = (e) => (e >>> 0).toString(16).padStart(8, "0"), Ze = (e) => {
  const t = new TextEncoder().encode(e), n = t.length * 8, o = Math.ceil((t.length + 9) / 64) * 64, s = new Uint8Array(o);
  s.set(t), s[t.length] = 128;
  const r = new DataView(s.buffer), c = Math.floor(n / 4294967296), d = n >>> 0;
  r.setUint32(o - 8, c), r.setUint32(o - 4, d);
  const a = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]), l = new Uint32Array(64);
  for (let p = 0; p < s.length; p += 64) {
    for (let O = 0; O < 16; O += 1)
      l[O] = r.getUint32(p + O * 4);
    for (let O = 16; O < 64; O += 1) {
      const K = l[O - 15], U = l[O - 2], J = z(K, 7) ^ z(K, 18) ^ K >>> 3, re = z(U, 17) ^ z(U, 19) ^ U >>> 10;
      l[O] = l[O - 16] + J + l[O - 7] + re >>> 0;
    }
    let [m, b, k, j, S, M, B, w] = a;
    for (let O = 0; O < 64; O += 1) {
      const K = z(S, 6) ^ z(S, 11) ^ z(S, 25), U = S & M ^ ~S & B, J = w + K + U + Je[O] + l[O] >>> 0, re = z(m, 2) ^ z(m, 13) ^ z(m, 22), Le = m & b ^ m & k ^ b & k, Ke = re + Le >>> 0;
      w = B, B = M, M = S, S = j + J >>> 0, j = k, k = b, b = m, m = J + Ke >>> 0;
    }
    a[0] = a[0] + m >>> 0, a[1] = a[1] + b >>> 0, a[2] = a[2] + k >>> 0, a[3] = a[3] + j >>> 0, a[4] = a[4] + S >>> 0, a[5] = a[5] + M >>> 0, a[6] = a[6] + B >>> 0, a[7] = a[7] + w >>> 0;
  }
  return [...a].map(Xe).join("");
}, P = (e) => `sha256:${Ze(v(e))}`, on = (e) => e.slice(0, 20), g = (e, t, n, o, s, r, c = []) => ({
  supported: !0,
  semanticName: e,
  description: t,
  addressability: n,
  readableAttrs: c,
  content: o,
  risk: s,
  stream: r
}), T = (e, t, n, o, s, r, c = []) => ({
  supported: !0,
  semanticName: e,
  description: t,
  addressability: n,
  readableAttrs: c,
  content: o,
  risk: s,
  stream: r
}), $ = (e) => E(e), Qe = E({
  builtinNodes: $({
    nodes: {
      blockquote: g(
        "Block quote",
        "A quoted block.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      bulletList: g(
        "Bullet list",
        "An unordered list.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      codeBlock: g(
        "Code block",
        "A preformatted code block.",
        "block",
        "text",
        "textual",
        "atomic",
        ["language"]
      ),
      doc: g(
        "Document",
        "The canonical document root.",
        "none",
        "block",
        "read-only",
        "none"
      ),
      hardBreak: g(
        "Hard break",
        "An explicit line break.",
        "nearest-block",
        "none",
        "textual",
        "incremental"
      ),
      heading: g(
        "Heading",
        "A section heading.",
        "block",
        "inline",
        "textual",
        "incremental",
        ["level", "textAlign"]
      ),
      horizontalRule: g(
        "Horizontal rule",
        "A thematic divider.",
        "block",
        "none",
        "structural",
        "atomic"
      ),
      listItem: g(
        "List item",
        "A structured list item.",
        "block",
        "mixed",
        "structural",
        "atomic"
      ),
      orderedList: g(
        "Ordered list",
        "An ordered list.",
        "block",
        "block",
        "structural",
        "atomic",
        ["start"]
      ),
      pageBreak: g(
        "Page break",
        "A pagination boundary.",
        "block",
        "none",
        "structural",
        "atomic"
      ),
      paragraph: g(
        "Paragraph",
        "A paragraph of inline content.",
        "block",
        "inline",
        "textual",
        "incremental",
        ["textAlign"]
      ),
      table: g(
        "Table",
        "A table containing rows and cells.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      tableCell: g(
        "Table cell",
        "A non-header table cell.",
        "nearest-block",
        "mixed",
        "structural",
        "atomic",
        ["cellId"]
      ),
      tableHeader: g(
        "Table header",
        "A table header cell.",
        "nearest-block",
        "mixed",
        "structural",
        "atomic",
        ["cellId"]
      ),
      tableRow: g(
        "Table row",
        "A row within a table.",
        "nearest-block",
        "block",
        "structural",
        "atomic",
        ["rowId"]
      ),
      taskItem: g(
        "Task item",
        "A checkable list item.",
        "block",
        "mixed",
        "structural",
        "atomic",
        ["checked"]
      ),
      taskList: g(
        "Task list",
        "A list of task items.",
        "block",
        "block",
        "structural",
        "atomic"
      ),
      text: g(
        "Text",
        "Canonical inline text.",
        "nearest-block",
        "text",
        "textual",
        "incremental"
      )
    },
    marks: {}
  }),
  builtinMarks: $({
    nodes: {},
    marks: {
      bold: T(
        "Bold",
        "Strong emphasis.",
        "block-range",
        "text",
        "textual",
        "incremental"
      ),
      code: T(
        "Inline code",
        "Inline code semantics.",
        "block-range",
        "text",
        "textual",
        "atomic"
      ),
      italic: T(
        "Italic",
        "Emphasized text.",
        "block-range",
        "text",
        "textual",
        "incremental"
      ),
      link: T(
        "Link",
        "A hyperlink on a block-local range.",
        "block-range",
        "text",
        "external-resource",
        "atomic",
        ["href", "rel", "target"]
      ),
      strike: T(
        "Strikethrough",
        "Struck text styling.",
        "block-range",
        "text",
        "textual",
        "incremental"
      ),
      textStyle: T(
        "Text style",
        "Allowlisted text style attrs.",
        "block-range",
        "text",
        "textual",
        "atomic",
        ["color", "fontFamily", "fontSize"]
      ),
      underline: T(
        "Underline",
        "Underlined text styling.",
        "block-range",
        "text",
        "textual",
        "incremental"
      )
    }
  }),
  attachment: $({
    nodes: {
      attachment: g(
        "Attachment",
        "An asset attachment.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "display"]
      )
    },
    marks: {}
  }),
  comment: $({
    nodes: {},
    marks: {
      comment: T(
        "Comment anchor",
        "A comment annotation anchor.",
        "block-range",
        "text",
        "sensitive",
        "none",
        ["commentId", "resolved"]
      )
    }
  }),
  embed: $({
    nodes: {
      embed: g(
        "Embed",
        "An external resource embed.",
        "nearest-block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "name", "title", "url"]
      )
    },
    marks: {}
  }),
  iframe: $({
    nodes: {
      iframe: g(
        "Embedded frame",
        "An embedded frame.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "title", "width", "height", "aspectRatio"]
      )
    },
    marks: {}
  }),
  image: $({
    nodes: {
      image: g(
        "Image",
        "An image with descriptive metadata.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "alt", "title", "width", "height", "align"]
      )
    },
    marks: {}
  }),
  imageGroup: $({
    nodes: {
      imageGroup: g(
        "Image group",
        "A group of image blocks.",
        "block",
        "block",
        "structural",
        "atomic",
        ["columns"]
      )
    },
    marks: {}
  }),
  mention: $({
    nodes: {
      mention: g(
        "Mention",
        "An inline mention reference.",
        "nearest-block",
        "none",
        "sensitive",
        "atomic",
        ["id", "label"]
      )
    },
    marks: {}
  }),
  namedColor: $({
    nodes: {},
    marks: {
      namedColor: T(
        "Named text color",
        "A named foreground color.",
        "block-range",
        "text",
        "textual",
        "atomic",
        ["color"]
      )
    }
  }),
  namedHighlight: $({
    nodes: {},
    marks: {
      namedHighlight: T(
        "Named highlight",
        "A named highlight color.",
        "block-range",
        "text",
        "textual",
        "atomic",
        ["color"]
      )
    }
  }),
  tag: $({
    nodes: {
      tagItem: g(
        "Tag",
        "An inline tag reference.",
        "nearest-block",
        "none",
        "sensitive",
        "atomic",
        ["tagId", "tagLabel"]
      )
    },
    marks: {}
  }),
  toggle: $({
    nodes: {
      toggle: g(
        "Toggle",
        "A collapsible container.",
        "block",
        "block",
        "structural",
        "atomic",
        ["open"]
      ),
      toggleSummary: g(
        "Toggle summary",
        "A toggle summary.",
        "block",
        "mixed",
        "structural",
        "atomic"
      ),
      toggleContent: g(
        "Toggle content",
        "A toggle content container.",
        "block",
        "block",
        "structural",
        "atomic"
      )
    },
    marks: {}
  }),
  video: $({
    nodes: {
      video: g(
        "Video",
        "A video resource.",
        "block",
        "none",
        "external-resource",
        "atomic",
        ["assetId", "controls"]
      )
    },
    marks: {}
  })
}), Ye = {
  builtinNodes: [
    "blockId",
    "cellId",
    "checked",
    "language",
    "level",
    "rowId",
    "start",
    "textAlign"
  ],
  builtinMarks: ["color", "fontFamily", "fontSize", "href", "rel", "target"],
  attachment: ["assetId", "display"],
  comment: ["commentId", "resolved"],
  embed: ["assetId", "name", "title", "url", "icon"],
  iframe: [
    "assetId",
    "src",
    "width",
    "height",
    "aspectRatio",
    "align",
    "title",
    "interactive",
    "fullWidth"
  ],
  image: [
    "assetId",
    "src",
    "alt",
    "title",
    "width",
    "height",
    "align",
    "loading"
  ],
  imageGroup: ["columns"],
  mention: ["id", "label"],
  namedColor: ["color"],
  namedHighlight: ["color"],
  tag: ["tagId", "tagLabel"],
  toggle: ["open"],
  video: ["assetId", "src", "controls"]
}, fe = /* @__PURE__ */ new WeakMap(), Ge = (e, t) => {
  const n = E({
    name: e,
    attrs: Ye[e],
    nodes: Object.keys(t.nodes),
    marks: Object.keys(t.marks),
    ai: t
  }), o = new Proxy(n, {
    get(s, r, c) {
      var d;
      return Reflect.has(s, r) ? Reflect.get(s, r, c) : (d = fe.get(o)) == null ? void 0 : d[r];
    }
  });
  return o;
}, oe = E(
  Object.entries(Qe).map(
    ([e, t]) => Ge(e, t)
  )
), rn = (e, t) => {
  const n = oe.find(
    (o) => o.name === e
  );
  if (!n)
    throw new TypeError(`Unknown canonical text-editor descriptor "${e}".`);
  if (fe.has(n))
    throw new TypeError(`Text-editor descriptor "${e}" was bound twice.`);
  fe.set(n, t);
}, We = (e) => {
  throw new RangeError(`Schema attribute must satisfy ${e}.`);
}, N = (e, t, n) => ({
  id: e,
  version: "1.0.0",
  semantic: t,
  validate: (o) => n(o) || We(t)
}), et = (e) => {
  try {
    return v(e), !0;
  } catch {
    return !1;
  }
}, Ce = [
  N(
    "zx.schema-validator.canonical-value",
    "canonical JSON value",
    et
  ),
  N(
    "zx.schema-validator.nullable-string",
    "string or null",
    (e) => e === null || typeof e == "string"
  ),
  N(
    "zx.schema-validator.string",
    "string",
    (e) => typeof e == "string"
  ),
  N(
    "zx.schema-validator.boolean",
    "boolean",
    (e) => typeof e == "boolean"
  ),
  N(
    "zx.schema-validator.nullable-boolean",
    "boolean or null",
    (e) => e === null || typeof e == "boolean"
  ),
  N(
    "zx.schema-validator.integer",
    "integer",
    (e) => Number.isInteger(e)
  ),
  N(
    "zx.schema-validator.positive-integer",
    "positive integer",
    (e) => Number.isInteger(e) && e > 0
  ),
  N(
    "zx.schema-validator.nullable-positive-number",
    "positive finite number or null",
    (e) => e === null || typeof e == "number" && Number.isFinite(e) && e > 0
  ),
  N(
    "zx.schema-validator.nullable-integer",
    "integer or null",
    (e) => e === null || Number.isInteger(e)
  ),
  N(
    "zx.schema-validator.nullable-integer-array",
    "integer array or null",
    (e) => e === null || Array.isArray(e) && e.every(Number.isInteger)
  )
], tt = new Map(Ce.map((e) => [e.id, e])), be = E(
  Ce.map(({ id: e, version: t, semantic: n }) => ({
    id: e,
    version: t,
    fingerprint: P({ id: e, version: t, semantic: n })
  }))
), nt = (e) => {
  const t = be.find(
    (n) => n.id === e
  );
  if (!t)
    throw new TypeError(`Unknown package schema validator "${e}".`);
  return t;
}, ot = (e) => {
  const t = tt.get(e.id), n = be.find(
    (o) => o.id === e.id
  );
  if (!t || !n || n.version !== e.version || n.fingerprint !== e.fingerprint)
    throw new TypeError(`Unresolvable package schema validator "${e.id}".`);
  return t.validate;
}, i = (e, t, n) => ({
  name: e,
  default: t,
  validator: nt(n)
}), y = (e, t) => ({
  kind: "node",
  joinKey: `node:${t.key}`,
  order: e,
  attrs: t.attrs ?? [],
  ...t
}), _ = (e, t) => ({
  kind: "mark",
  joinKey: `mark:${t.key}`,
  order: e,
  attrs: t.attrs ?? [],
  ...t
}), x = {
  marks: null,
  inline: !1,
  atom: !1,
  isolating: !1,
  defining: !1,
  selectable: !0,
  draggable: !1,
  code: !1,
  whitespace: null,
  linebreakReplacement: !1
}, I = () => i("blockId", null, "zx.schema-validator.nullable-string"), ue = () => i("textAlign", null, "zx.schema-validator.nullable-string"), rt = {
  contractVersion: "platform-default",
  language: "platform-default",
  detectedLanguage: "platform-default",
  filename: "platform-default",
  caption: "platform-default",
  showLineNumbers: "platform-default",
  startLine: "platform-default",
  wrap: "platform-default",
  collapsed: "platform-default",
  previewLines: "platform-default",
  heightMode: "platform-default",
  height: "platform-default",
  theme: "platform-default",
  highlightLines: "platform-default",
  copyMode: "platform-default",
  variant: "platform-default",
  groupId: "platform-default",
  tabLabel: "platform-default"
}, at = [
  y(0, {
    ...x,
    key: "paragraph",
    content: "inline*",
    group: "block",
    attrs: [ue(), I()]
  }),
  y(1, {
    ...x,
    key: "toggleSummary",
    content: "inline*",
    group: "block",
    defining: !0,
    selectable: !1,
    attrs: [I()]
  }),
  y(2, {
    ...x,
    key: "toggleContent",
    content: "block+",
    group: "block",
    defining: !0,
    selectable: !1,
    attrs: [I()]
  }),
  y(3, {
    ...x,
    key: "blockquote",
    content: "block+",
    group: "block",
    defining: !0,
    attrs: [I()]
  }),
  y(4, {
    ...x,
    key: "bulletList",
    content: "listItem+",
    group: "block list",
    attrs: [I()]
  }),
  y(5, { ...x, key: "doc", content: "block+", group: null }),
  y(6, {
    ...x,
    key: "hardBreak",
    content: null,
    group: "inline",
    inline: !0,
    selectable: !1,
    linebreakReplacement: !0
  }),
  y(7, {
    ...x,
    key: "horizontalRule",
    content: null,
    group: "block",
    attrs: [I()]
  }),
  y(8, {
    ...x,
    key: "listItem",
    content: "paragraph block*",
    group: null,
    defining: !0,
    attrs: [I()]
  }),
  y(9, {
    ...x,
    key: "orderedList",
    content: "listItem+",
    group: "block list",
    attrs: [
      I(),
      i("start", 1, "zx.schema-validator.positive-integer"),
      i("type", null, "zx.schema-validator.nullable-string")
    ]
  }),
  y(10, { ...x, key: "text", content: null, group: "inline" }),
  y(11, {
    ...x,
    key: "heading",
    content: "inline*",
    group: "block",
    defining: !0,
    attrs: [
      ue(),
      I(),
      i("level", 1, "zx.schema-validator.positive-integer")
    ]
  }),
  y(12, {
    ...x,
    key: "table",
    content: "tableRow+",
    group: "block",
    isolating: !0,
    attrs: [I()]
  }),
  y(13, {
    ...x,
    key: "taskList",
    content: "taskItem+",
    group: "block list",
    attrs: [I()]
  }),
  y(14, {
    ...x,
    key: "taskItem",
    content: "paragraph block*",
    group: null,
    defining: !0,
    attrs: [I(), i("checked", !1, "zx.schema-validator.boolean")]
  }),
  y(15, {
    ...x,
    key: "tableRow",
    content: "(tableCell | tableHeader)*",
    group: null,
    attrs: [i("rowId", null, "zx.schema-validator.nullable-string")]
  }),
  y(16, {
    ...x,
    key: "tableHeader",
    content: "block+",
    group: null,
    isolating: !0,
    attrs: [
      i("cellId", null, "zx.schema-validator.nullable-string"),
      i("colspan", 1, "zx.schema-validator.positive-integer"),
      i("rowspan", 1, "zx.schema-validator.positive-integer"),
      i("colwidth", null, "zx.schema-validator.nullable-integer-array"),
      i("align", null, "zx.schema-validator.nullable-string")
    ]
  }),
  y(17, {
    ...x,
    key: "tableCell",
    content: "block+",
    group: null,
    isolating: !0,
    attrs: [
      i("cellId", null, "zx.schema-validator.nullable-string"),
      i("colspan", 1, "zx.schema-validator.positive-integer"),
      i("rowspan", 1, "zx.schema-validator.positive-integer"),
      i("colwidth", null, "zx.schema-validator.nullable-integer-array"),
      i("align", null, "zx.schema-validator.nullable-string")
    ]
  }),
  y(18, {
    ...x,
    key: "pageBreak",
    content: null,
    group: "block",
    atom: !0,
    isolating: !0,
    attrs: [I(), i("id", null, "zx.schema-validator.nullable-string")]
  }),
  y(19, {
    ...x,
    key: "codeBlock",
    content: "text*",
    group: "block",
    marks: "",
    defining: !0,
    code: !0,
    whitespace: "pre",
    attrs: [
      I(),
      i("language", null, "zx.schema-validator.nullable-string"),
      i("contractVersion", "zx-code-block/v2", "zx.schema-validator.string"),
      i("detectedLanguage", null, "zx.schema-validator.nullable-string"),
      i("filename", "", "zx.schema-validator.string"),
      i("caption", "", "zx.schema-validator.string"),
      i("showLineNumbers", !0, "zx.schema-validator.boolean"),
      i("startLine", 1, "zx.schema-validator.positive-integer"),
      i("wrap", "inherit", "zx.schema-validator.string"),
      i("collapsed", !1, "zx.schema-validator.boolean"),
      i("previewLines", null, "zx.schema-validator.nullable-integer"),
      i("heightMode", "max", "zx.schema-validator.string"),
      i("height", null, "zx.schema-validator.nullable-positive-number"),
      i("theme", null, "zx.schema-validator.nullable-string"),
      i("highlightLines", [], "zx.schema-validator.canonical-value"),
      i("copyMode", "plain", "zx.schema-validator.string"),
      i("variant", "code", "zx.schema-validator.string"),
      i("groupId", null, "zx.schema-validator.nullable-string"),
      i("tabLabel", "", "zx.schema-validator.string"),
      i(
        "defaultSource",
        rt,
        "zx.schema-validator.canonical-value"
      )
    ]
  }),
  y(20, {
    ...x,
    key: "attachment",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      I(),
      ...[
        "assetId",
        "display",
        "href",
        "fileName",
        "title",
        "mimeType",
        "fileSize",
        "sizeLabel",
        "fileKind",
        "badgeLabel",
        "downloadName"
      ].map(
        (e) => i(
          e,
          e === "display" ? "card" : null,
          e === "display" ? "zx.schema-validator.string" : e === "fileSize" ? "zx.schema-validator.canonical-value" : "zx.schema-validator.nullable-string"
        )
      )
    ]
  }),
  y(21, {
    ...x,
    key: "embed",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: ["assetId", "name", "title", "url", "icon"].map(
      (e) => i(e, null, "zx.schema-validator.nullable-string")
    )
  }),
  y(22, {
    ...x,
    key: "iframe",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      I(),
      i("assetId", null, "zx.schema-validator.nullable-string"),
      i("src", null, "zx.schema-validator.nullable-string"),
      i("width", null, "zx.schema-validator.canonical-value"),
      i("height", null, "zx.schema-validator.canonical-value"),
      i("aspectRatio", 0.5625, "zx.schema-validator.canonical-value"),
      i("align", "center", "zx.schema-validator.string"),
      i("title", null, "zx.schema-validator.nullable-string"),
      i("frameborder", "0", "zx.schema-validator.string"),
      i("allowfullscreen", "true", "zx.schema-validator.string"),
      i(
        "sandbox",
        "allow-scripts allow-same-origin allow-popups allow-forms",
        "zx.schema-validator.string"
      ),
      i("interactive", !1, "zx.schema-validator.boolean"),
      i("fullWidth", !1, "zx.schema-validator.boolean")
    ]
  }),
  y(23, {
    ...x,
    key: "image",
    content: null,
    group: "block",
    draggable: !0,
    attrs: [
      I(),
      ...["assetId", "src", "alt", "title"].map(
        (e) => i(e, null, "zx.schema-validator.nullable-string")
      ),
      i("width", null, "zx.schema-validator.canonical-value"),
      i("height", null, "zx.schema-validator.canonical-value"),
      i("align", "left", "zx.schema-validator.string")
    ]
  }),
  y(24, {
    ...x,
    key: "imageGroup",
    content: "image+",
    group: "block",
    isolating: !0,
    draggable: !0,
    attrs: [
      I(),
      i("columns", 4, "zx.schema-validator.positive-integer")
    ]
  }),
  y(25, {
    ...x,
    key: "mention",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: [
      i("id", null, "zx.schema-validator.nullable-string"),
      i("label", null, "zx.schema-validator.nullable-string")
    ]
  }),
  y(26, {
    ...x,
    key: "tagItem",
    content: null,
    group: "inline",
    inline: !0,
    atom: !0,
    attrs: [
      i("tagId", null, "zx.schema-validator.nullable-string"),
      i("tagLabel", "tag", "zx.schema-validator.string")
    ]
  }),
  y(27, {
    ...x,
    key: "toggle",
    content: "toggleSummary toggleContent",
    group: "block",
    isolating: !0,
    defining: !0,
    attrs: [I(), i("open", !1, "zx.schema-validator.boolean")]
  }),
  y(28, {
    ...x,
    key: "video",
    content: null,
    group: "block",
    atom: !0,
    draggable: !0,
    attrs: [
      I(),
      i("assetId", null, "zx.schema-validator.nullable-string"),
      i("src", null, "zx.schema-validator.nullable-string")
    ]
  })
], D = {
  group: null,
  excludes: null,
  inclusive: !0,
  spanning: !0,
  code: !1
}, st = [
  _(0, {
    ...D,
    key: "link",
    attrs: [
      i("href", null, "zx.schema-validator.nullable-string"),
      i("target", "_blank", "zx.schema-validator.nullable-string"),
      i(
        "rel",
        "noopener noreferrer nofollow",
        "zx.schema-validator.nullable-string"
      ),
      i("class", null, "zx.schema-validator.nullable-string"),
      i("title", null, "zx.schema-validator.nullable-string")
    ]
  }),
  _(1, {
    ...D,
    key: "textStyle",
    attrs: [
      i("fontFamily", null, "zx.schema-validator.nullable-string"),
      i("fontSize", null, "zx.schema-validator.nullable-string"),
      i("color", null, "zx.schema-validator.nullable-string")
    ]
  }),
  _(2, { ...D, key: "bold" }),
  _(3, { ...D, key: "italic" }),
  _(4, { ...D, key: "strike" }),
  _(5, { ...D, key: "underline" }),
  _(6, { ...D, key: "code", code: !0, excludes: "_" }),
  _(7, {
    ...D,
    key: "comment",
    attrs: [
      i("commentId", null, "zx.schema-validator.nullable-string"),
      i("resolved", !1, "zx.schema-validator.boolean")
    ]
  }),
  _(8, {
    ...D,
    key: "namedHighlight",
    inclusive: !1,
    attrs: [i("color", null, "zx.schema-validator.nullable-string")]
  })
], X = (e, t, n) => {
  const o = `zx.text-editor.authority.${e}`;
  return {
    id: o,
    version: n,
    fingerprint: P({ id: o, version: n, owner: t }),
    authority: e,
    owner: t
  };
}, it = [
  X("document-v2", "src/document/types.ts", "2.0.0"),
  X("schema-kernel", "src/core/schema-kernel/definition.ts", "1.0.0"),
  X("ai-capability", "src/core/ai-extension-capabilities.ts", "1.0.0"),
  X("render-registry", "src/core/extension-descriptors.ts", "1.0.0")
], ge = {
  schemaKernelId: "zx.text-editor.schema-kernel",
  schemaKernelVersion: "1.0.0",
  topNode: "doc",
  authorities: it,
  validators: be,
  nodes: at,
  marks: st
}, C = E({
  ...ge,
  schemaKernelFingerprint: P(ge)
}), an = () => C, G = E({
  maxBytes: 2e6,
  maxDepth: 128,
  maxArrayEntries: 5e4,
  maxObjectKeys: 1024,
  maxTotalObjectKeys: 3e5,
  maxComponents: 256,
  maxDependencies: 1024,
  maxNodes: 5e4,
  maxMarks: 2e5,
  maxPlugins: 128,
  maxSteps: 1e4,
  maxReaderEntries: 64
}), ae = {
  id: "zx.text-editor.execution-resource-profile",
  version: "1.0.0",
  limits: G
};
E({
  id: ae.id,
  version: ae.version,
  fingerprint: P(ae),
  dependencies: []
});
const Re = (e) => qe(e, G), ye = (e, t) => {
  if (t <= 0 || t >= e.length) return !1;
  const n = e.charCodeAt(t - 1), o = e.charCodeAt(t);
  return n >= 55296 && n <= 56319 && o >= 56320 && o <= 57343;
}, ct = (e, t, n) => {
  const o = [...e].sort((p, m) => p.order - m.order), s = new Map(
    o.map((p, m) => [p.blockId, m])
  );
  if (s.size !== o.length || new Set(o.map((p) => p.order)).size !== o.length)
    return null;
  const r = s.get(t.blockId), c = s.get(n.blockId);
  if (r === void 0 || c === void 0 || r > c)
    return null;
  const d = o[r], a = o[c];
  return !Number.isInteger(t.offset) || !Number.isInteger(n.offset) || t.offset < 0 || n.offset < 0 || t.offset > d.text.length || n.offset > a.text.length || ye(d.text, t.offset) || ye(a.text, n.offset) || r === c && t.offset >= n.offset ? null : {
    quote: r === c ? d.text.slice(t.offset, n.offset) : o.slice(r, c + 1).map((p, m, b) => {
      const k = m === 0 ? t.offset : 0, j = m === b.length - 1 ? n.offset : p.text.length;
      return p.text.slice(k, j);
    }).join(`
`),
    before: d.text.slice(0, t.offset),
    after: a.text.slice(n.offset)
  };
}, W = (e) => e.length === 0 ? void 0 : Object.fromEntries(
  e.map((t) => [
    t.name,
    {
      default: t.default,
      validate: ot(t.validator)
    }
  ])
), lt = (e) => ({
  ...e.content !== null ? { content: e.content } : {},
  ...e.group !== null ? { group: e.group } : {},
  ...e.marks !== null ? { marks: e.marks } : {},
  ...e.inline ? { inline: !0 } : {},
  ...e.atom ? { atom: !0 } : {},
  ...e.isolating ? { isolating: !0 } : {},
  ...e.defining ? { defining: !0 } : {},
  ...e.selectable ? {} : { selectable: !1 },
  ...e.draggable ? { draggable: !0 } : {},
  ...e.code ? { code: !0 } : {},
  ...e.whitespace !== null ? { whitespace: e.whitespace } : {},
  ...e.linebreakReplacement ? { linebreakReplacement: !0 } : {},
  ...W(e.attrs) ? { attrs: W(e.attrs) } : {}
}), dt = (e) => ({
  ...e.group !== null ? { group: e.group } : {},
  ...e.excludes !== null ? { excludes: e.excludes } : {},
  ...e.inclusive ? {} : { inclusive: !1 },
  ...e.spanning ? {} : { spanning: !1 },
  ...W(e.attrs) ? { attrs: W(e.attrs) } : {},
  ...e.code ? { code: !0 } : {}
}), mt = new Fe({
  topNode: C.topNode,
  nodes: Object.fromEntries(
    C.nodes.map((e) => [
      e.key,
      lt(e)
    ])
  ),
  marks: Object.fromEntries(
    C.marks.map((e) => [
      e.key,
      dt(e)
    ])
  )
}), pt = () => mt, ft = /^[a-z][a-z0-9]*_[a-z0-9]+$/, sn = "blockId", ht = (e) => typeof e == "string" && e.length > 3 && e.length <= 64 && ft.test(e), Be = new Set(
  C.nodes.filter((e) => e.attrs.some((t) => t.name === "blockId")).map((e) => e.key)
), Q = (e) => !!e && typeof e == "object" && !Array.isArray(e), bt = (e) => e.length === 0 ? "$.body.content" : `$.body.content.${e.map((t) => `content[${t}]`).join(".")}`, _e = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : Array.isArray(e.content) ? e.content.reduce(
  (t, n) => t + (Q(n) ? _e(n) : 0),
  0
) : 0, ut = (e) => {
  Re(e);
  const t = [], n = [], o = [], s = /* @__PURE__ */ new Set();
  let r = 0;
  const c = (d, a) => {
    const l = typeof d.type == "string" ? d.type : "unknown", p = bt(a);
    if (Be.has(l)) {
      const m = Q(d.attrs) ? d.attrs : {}, b = typeof m.blockId == "string" ? m.blockId : null, k = b ? ht(b) ? s.has(b) ? "duplicate-block-id" : null : "invalid-block-id" : "missing-block-id";
      if (k)
        t.push({ code: k, path: p, nodeType: l, blockId: b });
      else if (b) {
        s.add(b);
        const { content: j, ...S } = d;
        n.push({
          blockId: b,
          nodeType: l,
          path: p,
          order: r++,
          utf16TextLength: _e(d),
          nodeFingerprint: P(S),
          subtreeFingerprint: P(d)
        }), o.push({
          blockId: b,
          path: p,
          nodeType: l,
          documentAttrs: { blockId: b },
          renderAttrs: {
            dataBlockId: b,
            domId: l === "heading" ? b : null
          }
        });
      }
    }
    Array.isArray(d.content) && d.content.forEach((m, b) => {
      Q(m) && c(m, [...a, b]);
    });
  };
  return Q(e) && c(e, []), E({
    valid: t.length === 0,
    issues: t,
    index: n,
    attrSynchronization: o,
    canonicalFingerprint: P({ index: n, attrSynchronization: o })
  });
}, gt = () => E([...Be]), yt = 2, xt = "stable-block-identity/v2", se = {
  id: "zx.text-editor.document-v2-verifier",
  version: "2.1.0",
  schemaKernel: {
    id: C.schemaKernelId,
    version: C.schemaKernelVersion,
    fingerprint: C.schemaKernelFingerprint
  },
  pipeline: [
    "bounded-canonical-input",
    "exact-envelope-shape",
    "exact-node-mark-shape",
    "prosemirror-node-from-json",
    "stable-identity",
    "annotation-utf16-cross-block-lf-quote-context",
    "exact-asset-recursive-pages-header-footer-binary-export-meta-contract",
    "full-envelope-canonical-roundtrip"
  ],
  diagnosticAggregation: "continue-safe-independent-checks-after-exact-structural-admission"
}, kt = E({
  id: se.id,
  version: se.version,
  fingerprint: P(se)
}), h = (e) => !!e && typeof e == "object" && !Array.isArray(e), u = (e, t, n = []) => {
  const o = Object.keys(e), s = /* @__PURE__ */ new Set([...t, ...n]);
  return t.every((r) => Object.hasOwn(e, r)) && o.every((r) => s.has(r));
}, f = (e, t, n, o = {}) => ({ code: e, path: t, message: n, ...o }), wt = (e) => e.reduce(
  (t, n) => (t[n.code] = (t[n.code] ?? 0) + 1, t),
  {}
), V = (e, t) => E({
  valid: e.length === 0,
  issueCount: e.length,
  issues: [...e],
  unresolvedAnnotations: e.filter(
    (n) => n.code === "annotation-unresolved"
  ).length,
  headingIdentityViolations: e.filter(
    (n) => n.code === "heading-identity-uninferable"
  ).length,
  counts: wt(e),
  documentFingerprint: t,
  verifier: kt
}), At = new Map(
  C.nodes.map((e) => [
    e.key,
    e
  ])
), It = new Map(
  C.marks.map((e) => [
    e.key,
    e
  ])
), Ot = (e, t, n) => {
  if (!h(e) || !u(e, ["type"], ["attrs"])) {
    n.push(f("document-shape-invalid", t, "Mark shape is invalid."));
    return;
  }
  const o = typeof e.type == "string" ? It.get(e.type) : void 0;
  if (!o) {
    n.push(
      f("document-schema-invalid", `${t}.type`, "Unknown mark type.")
    );
    return;
  }
  const s = o.attrs.map((r) => r.name);
  if (s.length === 0) {
    Object.hasOwn(e, "attrs") && n.push(
      f(
        "document-shape-invalid",
        `${t}.attrs`,
        "Mark has no attributes."
      )
    );
    return;
  }
  (!h(e.attrs) || !u(e.attrs, s)) && n.push(
    f(
      "document-shape-invalid",
      `${t}.attrs`,
      "Mark attributes are not exact."
    )
  );
}, De = (e, t, n, o) => {
  if (o.nodes += 1, o.nodes > G.maxNodes) {
    n.push(
      f(
        "document-resource-limit-exceeded",
        t,
        "Document node count exceeds the package limit.",
        { count: o.nodes }
      )
    );
    return;
  }
  if (!h(e)) {
    n.push(
      f("document-shape-invalid", t, "Node must be an object.")
    );
    return;
  }
  const s = typeof e.type == "string" ? e.type : null, r = s ? At.get(s) : void 0;
  if (!r) {
    n.push(
      f("document-schema-invalid", `${t}.type`, "Unknown node type.")
    );
    return;
  }
  const c = s === "text", d = c ? ["type", "text", "marks"] : ["type", "attrs", "content", "marks"];
  (!Object.hasOwn(e, "type") || Object.keys(e).some((l) => !d.includes(l))) && n.push(
    f("document-shape-invalid", t, "Node properties are not exact.")
  ), c ? (typeof e.text != "string" || e.text.length === 0) && n.push(
    f(
      "document-shape-invalid",
      `${t}.text`,
      "Text must be non-empty."
    )
  ) : Object.hasOwn(e, "text") && n.push(
    f(
      "document-shape-invalid",
      `${t}.text`,
      "Only text nodes may contain text."
    )
  );
  const a = r.attrs.map((l) => l.name);
  a.length > 0 ? (!h(e.attrs) || !u(e.attrs, a)) && n.push(
    f(
      "document-shape-invalid",
      `${t}.attrs`,
      "Node attributes are not exact."
    )
  ) : Object.hasOwn(e, "attrs") && n.push(
    f(
      "document-shape-invalid",
      `${t}.attrs`,
      "Node has no attributes."
    )
  ), Object.hasOwn(e, "marks") && (Array.isArray(e.marks) ? (o.marks += e.marks.length, o.marks > G.maxMarks ? n.push(
    f(
      "document-resource-limit-exceeded",
      `${t}.marks`,
      "Document mark count exceeds the package limit.",
      { count: o.marks }
    )
  ) : e.marks.forEach(
    (l, p) => Ot(l, `${t}.marks[${p}]`, n)
  )) : n.push(
    f(
      "document-shape-invalid",
      `${t}.marks`,
      "Marks must be an array."
    )
  )), Object.hasOwn(e, "content") && (Array.isArray(e.content) ? e.content.forEach(
    (l, p) => De(l, `${t}.content[${p}]`, n, o)
  ) : n.push(
    f(
      "document-shape-invalid",
      `${t}.content`,
      "Content must be an array."
    )
  ));
}, Et = (e, t, n, o) => {
  if (!h(e) || !u(
    e,
    ["id", "type", "src"],
    ["title", "mimeType", "meta"]
  ) || typeof e.id != "string" || !e.id || !["image", "video", "embed", "file"].includes(String(e.type)) || typeof e.src != "string" || Object.hasOwn(e, "title") && typeof e.title != "string" || Object.hasOwn(e, "mimeType") && typeof e.mimeType != "string") {
    o.push(
      f("asset-contract-invalid", t, "Asset contract is invalid.")
    );
    return;
  }
  n.has(e.id) && o.push(
    f("asset-contract-invalid", `${t}.id`, "Asset id is duplicated.")
  ), n.add(e.id), Object.hasOwn(e, "meta") && (!h(e.meta) || Object.values(e.meta).some(
    (s) => !["string", "number", "boolean"].includes(typeof s)
  )) && o.push(
    f(
      "asset-contract-invalid",
      `${t}.meta`,
      "Asset metadata is invalid."
    )
  );
}, L = (e) => typeof e == "string" && e.length > 0, he = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0, ee = (e) => typeof e == "number" && Number.isFinite(e) && e > 0, Pe = (e) => h(e) && u(e, ["top", "right", "bottom", "left"]) && ["top", "right", "bottom", "left"].every(
  (t) => he(e[t])
), te = (e) => h(e) && u(
  e,
  [],
  ["sectionBreak", "pageBreakBefore", "headerFooterRole", "pageNumbering"]
) && (!Object.hasOwn(e, "sectionBreak") || ["document-start", "continuous", "next-page"].includes(
  String(e.sectionBreak)
)) && (!Object.hasOwn(e, "pageBreakBefore") || typeof e.pageBreakBefore == "boolean") && (!Object.hasOwn(e, "headerFooterRole") || ["default", "first-page", "none"].includes(
  String(e.headerFooterRole)
)) && (!Object.hasOwn(e, "pageNumbering") || ["inherit", "restart-1", "hidden"].includes(String(e.pageNumbering))), jt = (e) => h(e) && u(e, ["id"], ["label", "width", "height"]) && L(e.id) && (!Object.hasOwn(e, "label") || typeof e.label == "string") && (!Object.hasOwn(e, "width") || ee(e.width)) && (!Object.hasOwn(e, "height") || ee(e.height)), xe = (e, t) => {
  if (!h(e)) return !1;
  const n = ["pageFormat", "orientation", "margins"];
  return u(e, t ? [] : n, t ? n : []) ? (!Object.hasOwn(e, "pageFormat") || jt(e.pageFormat)) && (!Object.hasOwn(e, "orientation") || e.orientation === "portrait" || e.orientation === "landscape") && (!Object.hasOwn(e, "margins") || Pe(e.margins)) : !1;
}, St = /* @__PURE__ */ new Set([
  "bold",
  "italic",
  "underline",
  "strike",
  "code",
  "link"
]), $t = /* @__PURE__ */ new Set([
  "http:",
  "https:",
  "mailto:",
  "tel:"
]), vt = (e) => {
  if (typeof e != "string" || e.length === 0 || e !== e.trim())
    return !1;
  try {
    const t = new URL(e, "https://zx.local");
    return $t.has(t.protocol) || t.protocol === "https:" && !/^[a-z][a-z0-9+.-]*:/i.test(e);
  } catch {
    return !1;
  }
}, zt = (e) => !h(e) || typeof e.type != "string" || !St.has(e.type) ? !1 : e.type !== "link" ? u(e, ["type"]) : u(e, ["type", "attrs"]) && h(e.attrs) && u(e.attrs, ["href"]) && vt(e.attrs.href), Tt = (e) => !h(e) || typeof e.type != "string" ? !1 : e.type === "hardBreak" ? u(e, ["type"]) : e.type === "text" && u(e, ["type", "text"], ["marks"]) && typeof e.text == "string" && (!Object.hasOwn(e, "marks") || Array.isArray(e.marks) && e.marks.every(zt)), Nt = (e) => h(e) && e.type === "doc" && u(e, ["type"], ["content"]) && (!Object.hasOwn(e, "content") || Array.isArray(e.content) && e.content.every(
  (t) => h(t) && t.type === "paragraph" && u(t, ["type"], ["content"]) && (!Object.hasOwn(t, "content") || Array.isArray(t.content) && t.content.every(Tt))
)), Ct = (e) => h(e) && (e.state === "empty" && u(e, ["state"]) || e.state === "content" && u(e, ["state", "content"]) && Nt(e.content)), Rt = ["default", "firstPage", "oddPage", "evenPage"], Z = (e) => h(e) && u(e, [], Rt) && Object.values(e).every(Ct), Bt = (e) => !h(e) || !u(
  e,
  ["version", "differentFirstPage", "differentOddEven"],
  ["headerTopMargin", "footerBottomMargin", "header", "footer", "sections"]
) || e.version !== 1 || typeof e.differentFirstPage != "boolean" || typeof e.differentOddEven != "boolean" || Object.hasOwn(e, "headerTopMargin") && !he(e.headerTopMargin) || Object.hasOwn(e, "footerBottomMargin") && !he(e.footerBottomMargin) || Object.hasOwn(e, "header") && !Z(e.header) || Object.hasOwn(e, "footer") && !Z(e.footer) || Object.hasOwn(e, "sections") && !Array.isArray(e.sections) ? !1 : !Array.isArray(e.sections) || e.sections.every(
  (t) => h(t) && u(
    t,
    ["sectionId"],
    [
      "startBlockId",
      "differentFirstPage",
      "differentOddEven",
      "header",
      "footer"
    ]
  ) && L(t.sectionId) && (!Object.hasOwn(t, "startBlockId") || L(t.startBlockId)) && (!Object.hasOwn(t, "differentFirstPage") || typeof t.differentFirstPage == "boolean") && (!Object.hasOwn(t, "differentOddEven") || typeof t.differentOddEven == "boolean") && (!Object.hasOwn(t, "header") || Z(t.header)) && (!Object.hasOwn(t, "footer") || Z(t.footer))
), _t = (e) => {
  if (!h(e) || !u(
    e,
    ["version", "defaults"],
    ["sections", "headerFooter"]
  ) || e.version !== 1 || !h(e.defaults) || !u(e.defaults, ["page"], ["intent"]) || !xe(e.defaults.page, !1) || Object.hasOwn(e.defaults, "intent") && !te(e.defaults.intent) || Object.hasOwn(e, "headerFooter") && !Bt(e.headerFooter) || Object.hasOwn(e, "sections") && !Array.isArray(e.sections))
    return !1;
  const t = /* @__PURE__ */ new Set();
  return !Array.isArray(e.sections) || e.sections.every((n) => !h(n) || !u(n, ["id", "startBlockId"], ["page", "intent"]) || !L(n.id) || t.has(n.id) || !L(n.startBlockId) || Object.hasOwn(n, "page") && !xe(n.page, !0) || Object.hasOwn(n, "intent") && !te(n.intent) ? !1 : (t.add(n.id), !0));
}, ke = (e) => h(e) && u(
  e,
  [],
  ["size", "label", "width", "height", "orientation", "margins"]
) && (!Object.hasOwn(e, "size") || L(e.size)) && (!Object.hasOwn(e, "label") || typeof e.label == "string") && (!Object.hasOwn(e, "width") || ee(e.width)) && (!Object.hasOwn(e, "height") || ee(e.height)) && (!Object.hasOwn(e, "orientation") || e.orientation === "portrait" || e.orientation === "landscape") && (!Object.hasOwn(e, "margins") || Pe(e.margins)), Dt = (e) => {
  if (!h(e) || !u(e, [], ["defaults", "sections"]) || Object.hasOwn(e, "defaults") && (!h(e.defaults) || !u(e.defaults, [], ["page", "intent"]) || Object.hasOwn(e.defaults, "page") && !ke(e.defaults.page) || Object.hasOwn(e.defaults, "intent") && !te(e.defaults.intent)) || Object.hasOwn(e, "sections") && !Array.isArray(e.sections))
    return !1;
  const t = /* @__PURE__ */ new Set();
  return !Array.isArray(e.sections) || e.sections.every((n) => !h(n) || !u(n, ["id", "startBlockId"], ["page", "intent"]) || !L(n.id) || t.has(n.id) || !L(n.startBlockId) || Object.hasOwn(n, "page") && !ke(n.page) || Object.hasOwn(n, "intent") && !te(n.intent) ? !1 : (t.add(n.id), !0));
}, Pt = (e, t) => {
  if (!h(e) || !u(
    e,
    [],
    [
      "title",
      "author",
      "createdAt",
      "updatedAt",
      "source",
      "schemaVersion",
      "pages",
      "binaryExport"
    ]
  )) {
    t.push(
      f(
        "meta-contract-invalid",
        "$.meta",
        "Document metadata shape is invalid."
      )
    );
    return;
  }
  ["title", "author", "createdAt", "updatedAt", "schemaVersion"].forEach(
    (n) => {
      Object.hasOwn(e, n) && typeof e[n] != "string" && t.push(
        f(
          "meta-contract-invalid",
          `$.meta.${n}`,
          "Metadata field must be a string."
        )
      );
    }
  ), Object.hasOwn(e, "source") && e.source !== "editor" && e.source !== "import" && t.push(
    f(
      "meta-contract-invalid",
      "$.meta.source",
      "Metadata source is invalid."
    )
  ), ["pages", "binaryExport"].forEach((n) => {
    const o = n === "pages" ? _t(e[n]) : Dt(e[n]);
    Object.hasOwn(e, n) && !o && t.push(
      f(
        "meta-contract-invalid",
        `$.meta.${n}`,
        "Metadata contract field must be an object."
      )
    );
  });
}, Mt = (e, t, n) => {
  const o = /* @__PURE__ */ new Map();
  t.forEach((d) => {
    h(d) && typeof d.id == "string" && o.set(d.id, d);
  });
  const s = /* @__PURE__ */ new Set(), r = {
    attachment: "file",
    embed: "embed",
    iframe: "embed",
    image: "image",
    video: "video"
  }, c = (d, a) => {
    const l = h(d.attrs) ? d.attrs : null, p = typeof d.type == "string" ? d.type : "", m = typeof (l == null ? void 0 : l.assetId) == "string" ? l.assetId : null;
    if (m) {
      const b = o.get(m);
      if (!b || b.type !== r[p])
        n.push(
          f(
            "asset-contract-invalid",
            `${a}.attrs.assetId`,
            "Asset reference is unresolved or has the wrong type."
          )
        );
      else {
        s.add(m);
        const k = typeof (l == null ? void 0 : l.src) == "string" ? l.src : typeof (l == null ? void 0 : l.url) == "string" ? l.url : null;
        k !== null && k !== b.src && n.push(
          f(
            "asset-contract-invalid",
            `${a}.attrs.assetId`,
            "Asset reference source does not match the asset table."
          )
        );
      }
    }
    Array.isArray(d.content) && d.content.forEach((b, k) => {
      h(b) && c(b, `${a}.content[${k}]`);
    });
  };
  h(e) && c(e, "$.body.content"), t.forEach((d, a) => {
    h(d) && typeof d.id == "string" && d.type !== "file" && !s.has(d.id) && n.push(
      f(
        "asset-contract-invalid",
        `$.assets[${a}].id`,
        "Non-file asset is not referenced by the document."
      )
    );
  });
}, Lt = (e) => {
  const t = /* @__PURE__ */ new Map(), n = (s) => typeof s.text == "string" ? s.text : s.type === "hardBreak" ? `
` : Array.isArray(s.content) ? s.content.map((r) => h(r) ? n(r) : "").join("") : "", o = (s) => {
    const r = h(s.attrs) ? s.attrs : null;
    typeof (r == null ? void 0 : r.blockId) == "string" && t.set(r.blockId, n(s)), Array.isArray(s.content) && s.content.forEach((c) => h(c) && o(c));
  };
  return h(e) && o(e), t;
}, Kt = (e, t, n, o) => {
  const s = new Map(t.map((a) => [a.blockId, a])), r = Lt(n), c = t.map((a) => ({
    blockId: a.blockId,
    order: a.order,
    text: r.get(a.blockId) ?? ""
  })), d = /* @__PURE__ */ new Set();
  e.forEach((a, l) => {
    const p = `$.annotations[${l}]`;
    if (!h(a) || !u(a, ["id", "type", "anchor", "resolved", "payload"]) || typeof a.id != "string" || !a.id || a.type !== "comment" || typeof a.resolved != "boolean" || !h(a.anchor) || !u(
      a.anchor,
      ["start", "end"],
      ["quote", "beforeQuote", "afterQuote"]
    ) || !h(a.payload) || !u(a.payload, ["threadId", "comments"]) || typeof a.payload.threadId != "string" || !Array.isArray(a.payload.comments)) {
      o.push(
        f(
          "annotation-contract-invalid",
          p,
          "Annotation contract is invalid."
        )
      );
      return;
    }
    d.has(a.id) && o.push(
      f(
        "annotation-contract-invalid",
        `${p}.id`,
        "Annotation id is duplicated."
      )
    ), d.add(a.id), a.payload.comments.forEach((w, O) => {
      (!h(w) || !u(
        w,
        ["id", "content", "createdAt"],
        ["authorId", "updatedAt"]
      ) || ["id", "content", "createdAt"].some(
        (K) => typeof w[K] != "string"
      ) || Object.hasOwn(w, "authorId") && typeof w.authorId != "string" || Object.hasOwn(w, "updatedAt") && typeof w.updatedAt != "string") && o.push(
        f(
          "annotation-contract-invalid",
          `${p}.payload.comments[${O}]`,
          "Annotation comment is invalid."
        )
      );
    });
    const m = a.anchor, b = (w) => h(w) && u(w, ["blockId", "offset"]) && typeof w.blockId == "string" && Number.isInteger(w.offset) && w.offset >= 0 ? { blockId: w.blockId, offset: w.offset } : null, k = b(m.start), j = b(m.end), S = k ? s.get(k.blockId) : void 0, M = j ? s.get(j.blockId) : void 0;
    if (!k || !j || !S || !M || k.offset > S.utf16TextLength || j.offset > M.utf16TextLength || S.order > M.order || k.blockId === j.blockId && k.offset >= j.offset) {
      o.push(
        f(
          "annotation-unresolved",
          `${p}.anchor`,
          "Annotation anchor is unresolved.",
          {
            annotationId: a.id,
            blockId: (k == null ? void 0 : k.blockId) ?? (j == null ? void 0 : j.blockId) ?? null
          }
        )
      );
      return;
    }
    ["quote", "beforeQuote", "afterQuote"].forEach((w) => {
      Object.hasOwn(m, w) && typeof m[w] != "string" && o.push(
        f(
          "annotation-contract-invalid",
          `${p}.anchor.${w}`,
          "Quote context must be a string."
        )
      );
    });
    const B = ct(
      c,
      k,
      j
    );
    if (!B) {
      o.push(
        f(
          "annotation-unresolved",
          `${p}.anchor`,
          "Annotation text projection is unresolved.",
          {
            annotationId: a.id,
            blockId: k.blockId
          }
        )
      );
      return;
    }
    typeof m.quote == "string" && m.quote !== B.quote && o.push(
      f(
        "annotation-quote-mismatch",
        `${p}.anchor.quote`,
        "Annotation quote does not match UTF-16 range."
      )
    ), typeof m.beforeQuote == "string" && !B.before.endsWith(m.beforeQuote) && o.push(
      f(
        "annotation-quote-mismatch",
        `${p}.anchor.beforeQuote`,
        "Annotation leading context does not match."
      )
    ), typeof m.afterQuote == "string" && !B.after.startsWith(m.afterQuote) && o.push(
      f(
        "annotation-quote-mismatch",
        `${p}.anchor.afterQuote`,
        "Annotation trailing context does not match."
      )
    );
  });
}, Ft = (e) => {
  let t;
  try {
    t = Re(e).canonical;
  } catch (a) {
    const l = a instanceof Error && a.name === "ZxCanonicalJSONResourceError";
    return V(
      [
        f(
          l ? "document-resource-limit-exceeded" : "document-content-invalid",
          "$",
          l ? "Document exceeds package resource limits." : "Document is not canonical JSON."
        )
      ],
      null
    );
  }
  const n = [];
  if (!h(e) || !u(e, ["version", "body", "annotations", "assets", "meta"]))
    return V(
      [
        f(
          "document-shape-invalid",
          "$",
          "Document v2 envelope is not exact."
        )
      ],
      null
    );
  if (e.version !== yt && n.push(
    f(
      "document-version-mismatch",
      "$.version",
      "Document version is unsupported."
    )
  ), !h(e.body) || !u(e.body, ["format", "content"]) ? n.push(
    f("document-shape-invalid", "$.body", "Document body is not exact.")
  ) : (e.body.format !== "json" && n.push(
    f(
      "document-format-mismatch",
      "$.body.format",
      "Document body format must be json."
    )
  ), h(e.body.content) ? De(e.body.content, "$.body.content", n, {
    nodes: 0,
    marks: 0
  }) : n.push(
    f(
      "document-content-invalid",
      "$.body.content",
      "Document body content must be a node object."
    )
  )), Array.isArray(e.annotations) || n.push(
    f(
      "document-shape-invalid",
      "$.annotations",
      "Annotations must be an array."
    )
  ), !Array.isArray(e.assets))
    n.push(
      f("document-shape-invalid", "$.assets", "Assets must be an array.")
    );
  else {
    const a = /* @__PURE__ */ new Set();
    e.assets.forEach(
      (l, p) => Et(l, `$.assets[${p}]`, a, n)
    );
  }
  Pt(e.meta, n), h(e.meta) && e.meta.schemaVersion !== xt && n.push(
    f(
      "document-schema-version-mismatch",
      "$.meta.schemaVersion",
      "Document schema version is unsupported."
    )
  );
  const o = /* @__PURE__ */ new Set([
    "document-content-invalid",
    "document-resource-limit-exceeded",
    "document-schema-invalid",
    "document-shape-invalid"
  ]);
  if (!h(e.body) || n.some((a) => o.has(a.code)))
    return V(n, null);
  let s;
  try {
    const a = pt().nodeFromJSON(e.body.content);
    a.check(), s = a.toJSON();
  } catch {
    return V(
      [
        ...n,
        f(
          "document-schema-invalid",
          "$.body.content",
          "Document does not satisfy the exact schema kernel."
        )
      ],
      null
    );
  }
  const r = ut(s);
  r.issues.forEach((a) => {
    n.push(
      f(a.code, a.path, "Stable block identity is invalid.", {
        blockId: a.blockId
      })
    ), a.nodeType === "heading" && n.push(
      f(
        "heading-identity-uninferable",
        a.path,
        "Heading identity cannot be inferred.",
        {
          blockId: a.blockId
        }
      )
    );
  }), Array.isArray(e.assets) && Mt(s, e.assets, n), Array.isArray(e.annotations) && Kt(
    e.annotations,
    r.index,
    s,
    n
  );
  const c = {
    version: 2,
    body: { format: "json", content: s },
    annotations: e.annotations,
    assets: e.assets,
    meta: e.meta
  };
  return v(c) !== t && n.push(
    f(
      "document-roundtrip-mismatch",
      "$",
      "Full document envelope is not canonical round-trip equivalent."
    )
  ), V(
    n,
    n.length === 0 ? P(c) : null
  );
}, cn = Ft, we = (e) => v({
  code: e.code,
  descriptor: e.descriptor ?? "",
  kind: e.kind ?? "",
  type: e.type ?? "",
  blockId: e.blockId ?? "",
  attr: e.attr ?? "",
  inputIndex: e.inputIndex ?? -1
}), Ht = (e) => [...e].sort(
  (t, n) => we(t).localeCompare(we(n))
), Ut = (e) => E({
  valid: !e.some((t) => t.severity === "error"),
  issues: Ht(e)
});
class Me extends Error {
  constructor(t) {
    var n;
    super(
      ((n = t.issues[0]) == null ? void 0 : n.message) ?? "AI semantic contract validation failed."
    ), this.name = "ZxAISemanticContractError", this.report = E(t);
  }
}
const ln = (e) => {
  throw new Me(Ut(e));
}, Vt = /* @__PURE__ */ new Set(["block", "nearest-block", "none"]), qt = /* @__PURE__ */ new Set(["block-range", "none"]), Jt = /* @__PURE__ */ new Set(["none", "text", "inline", "block", "mixed"]), Xt = /* @__PURE__ */ new Set([
  "read-only",
  "textual",
  "structural",
  "external-resource",
  "sensitive"
]), Zt = /* @__PURE__ */ new Set(["incremental", "atomic", "none"]), Qt = /* @__PURE__ */ new Set([
  "external-resource-restricted",
  "not-addressable",
  "requires-specialized-operation",
  "sensitive-content",
  "unsafe-projection"
]), Yt = new Set(
  gt()
), q = (e) => typeof e == "string" && e.trim().length > 0, ie = (e = []) => [...new Set(e)].sort(), ne = (e) => [...e].sort((t, n) => t.name.localeCompare(n.name)).map((t) => ({
  name: t.name,
  attrs: ie(t.attrs),
  nodes: ie(t.nodes),
  marks: ie(t.marks),
  ai: {
    nodes: Object.fromEntries(
      Object.entries(t.ai.nodes).sort(
        ([n], [o]) => n.localeCompare(o)
      )
    ),
    marks: Object.fromEntries(
      Object.entries(t.ai.marks).sort(
        ([n], [o]) => n.localeCompare(o)
      )
    )
  }
})), Ae = (e, t, n, o, s) => {
  const r = new Set(o), c = new Set(Object.keys(s));
  o.forEach((d) => {
    c.has(d) || e.push({
      code: "ai-capability-missing",
      severity: "error",
      message: `Descriptor "${t.name}" is missing an AI ${n} capability for "${d}".`,
      descriptor: t.name,
      kind: n,
      type: d
    });
  }), c.forEach((d) => {
    r.has(d) || e.push({
      code: "ai-capability-orphan",
      severity: "error",
      message: `Descriptor "${t.name}" has an orphan AI ${n} capability for "${d}".`,
      descriptor: t.name,
      kind: n,
      type: d
    });
  });
}, Ie = (e, t, n, o, s) => {
  const r = (a, l) => e.push({
    code: "ai-capability-invalid",
    severity: "error",
    message: a,
    descriptor: t.name,
    kind: n,
    type: o,
    attr: l
  });
  if (!s || typeof s != "object") {
    r(`AI ${n} capability "${o}" must be an object.`);
    return;
  }
  if (s.supported === !1) {
    Qt.has(s.reasonCode) || r(`Unsupported AI ${n} "${o}" has an invalid reason code.`), q(s.description) || r(`Unsupported AI ${n} "${o}" requires a description.`);
    return;
  }
  if (s.supported !== !0) {
    r(
      `AI ${n} capability "${o}" requires an explicit supported state.`
    );
    return;
  }
  if (q(s.semanticName) || r(`Supported AI ${n} "${o}" requires a semanticName.`), q(s.description) || r(`Supported AI ${n} "${o}" requires a description.`), (n === "node" ? Vt : qt).has(s.addressability) || r(`Supported AI ${n} "${o}" has invalid addressability.`), Jt.has(s.content) || r(`Supported AI ${n} "${o}" has invalid content projection.`), Xt.has(s.risk) || r(`Supported AI ${n} "${o}" has invalid risk.`), Zt.has(s.stream) || r(`Supported AI ${n} "${o}" has invalid stream policy.`), !Array.isArray(s.readableAttrs)) {
    r(`Supported AI ${n} "${o}" requires readableAttrs.`);
    return;
  }
  const c = new Set(t.attrs ?? []), d = /* @__PURE__ */ new Set();
  s.readableAttrs.forEach((a) => {
    if (!q(a) || d.has(a)) {
      r(
        `Supported AI ${n} "${o}" has an invalid readable attr.`,
        a
      );
      return;
    }
    d.add(a), c.has(a) || e.push({
      code: "ai-readable-attr-outside-descriptor",
      severity: "error",
      message: `AI ${n} "${o}" exposes attr "${a}" outside descriptor "${t.name}".`,
      descriptor: t.name,
      kind: n,
      type: o,
      attr: a
    });
  }), n === "node" && o === "doc" && s.addressability === "block" && r("The document root cannot claim stable block addressability."), n === "node" && s.addressability === "block" && !Yt.has(o) && !c.has("blockId") && r(
    `Addressable AI node "${o}" must participate in stable block identity.`,
    "blockId"
  );
}, Gt = (e = oe) => {
  const t = [], n = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map();
  e.forEach((c) => {
    (!q(c.name) || n.has(c.name)) && t.push({
      code: "ai-descriptor-ownership-conflict",
      severity: "error",
      message: `AI descriptor name "${c.name}" is invalid or duplicated.`,
      descriptor: c.name
    }), n.add(c.name);
    const d = c.nodes ?? [], a = c.marks ?? [], l = c.ai;
    if (!l || typeof l != "object" || !l.nodes || !l.marks) {
      t.push({
        code: "ai-capability-missing",
        severity: "error",
        message: `Descriptor "${c.name}" requires explicit ai.nodes and ai.marks maps.`,
        descriptor: c.name
      });
      return;
    }
    Ae(t, c, "node", d, l.nodes), Ae(t, c, "mark", a, l.marks), d.forEach((p) => {
      const m = o.get(p);
      m ? t.push({
        code: "ai-descriptor-ownership-conflict",
        severity: "error",
        message: `AI node "${p}" is owned by both "${m}" and "${c.name}".`,
        descriptor: c.name,
        kind: "node",
        type: p
      }) : o.set(p, c.name);
    }), a.forEach((p) => {
      const m = s.get(p);
      m ? t.push({
        code: "ai-descriptor-ownership-conflict",
        severity: "error",
        message: `AI mark "${p}" is owned by both "${m}" and "${c.name}".`,
        descriptor: c.name,
        kind: "mark",
        type: p
      }) : s.set(p, c.name);
    }), Object.entries(l.nodes).forEach(
      ([p, m]) => Ie(t, c, "node", p, m)
    ), Object.entries(l.marks).forEach(
      ([p, m]) => Ie(t, c, "mark", p, m)
    );
  });
  let r = "";
  try {
    r = v(
      ne(e)
    );
  } catch {
    t.push({
      code: "ai-capability-invalid",
      severity: "error",
      message: "Descriptor AI capability metadata must be canonicalizable."
    });
  }
  return E({
    valid: t.length === 0,
    issues: [...t].sort(
      (c, d) => v(c).localeCompare(v(d))
    ),
    descriptors: [...n].sort(),
    nodeTypes: [...o.keys()].sort(),
    markTypes: [...s.keys()].sort(),
    capabilityCanonicalForm: r
  });
}, dn = (e = oe) => {
  const t = Gt(e);
  if (!t.valid)
    throw new Me(t);
  return t;
}, mn = (e = oe) => ne(e), pn = (e, t) => {
  const n = v(ne(e)) === v(ne(t));
  return E({
    valid: n,
    issues: n ? [] : [
      {
        code: "platform-descriptor-drift",
        severity: "error",
        message: "AI and platform assembly descriptors do not share one capability truth."
      }
    ]
  });
}, Wt = He(
  "textEditor.review.hunkFocused",
  !1
), F = (e) => e === void 0, Oe = R({
  id: "textEditor.selection.progressive",
  label: "Progressive text selection",
  validateArgs: F
}), Ee = R({
  id: "textEditor.editor.editLink",
  label: "Edit link",
  validateArgs: F
}), je = R({
  id: "textEditor.ai.openInlineEdit",
  label: "Inline Edit",
  validateArgs: F
}), Se = R({
  id: "textEditor.ai.openAskAI",
  label: "Ask AI",
  validateArgs: F
}), $e = R({
  id: "textEditor.ai.dismiss",
  label: "Dismiss Inline AI",
  validateArgs: F
}), ve = R({
  id: "textEditor.review.accept",
  label: "Accept changes",
  validateArgs: F
}), ce = R({
  id: "textEditor.review.decideOperation",
  label: "Decide review operation",
  validateArgs: (e) => {
    if (!e || typeof e != "object") return !1;
    const t = e;
    return Object.keys(t).length === 2 && typeof t.operationIndex == "number" && Number.isInteger(t.operationIndex) && t.operationIndex >= 0 && (t.kind === "accept-operation" || t.kind === "reject-operation");
  }
}), ze = R({
  id: "textEditor.agent.cancelToolApproval",
  label: "Cancel tool approval",
  validateArgs: F
}), le = R({
  id: "textEditor.review.decideHunk",
  label: "Decide paragraph change",
  validateArgs: (e) => {
    if (!e || typeof e != "object") return !1;
    const t = e;
    return Object.keys(t).length === 2 && typeof t.hunkId == "string" && t.hunkId.length > 0 && (t.decision === "accepted" || t.decision === "rejected" || t.decision === "undecided");
  }
}), de = R({
  id: "textEditor.review.stepHunk",
  label: "Move between paragraph changes",
  validateArgs: (e) => {
    if (!e || typeof e != "object") return !1;
    const t = e;
    return Object.keys(t).length === 1 && (t.direction === "forward" || t.direction === "backward");
  }
}), fn = Ue({
  id: "textEditor",
  actions: [
    Oe,
    Ee,
    je,
    Se,
    $e,
    ve,
    le,
    de,
    ce,
    ze
  ],
  bindings: [
    {
      id: "textEditor.review.acceptOperation",
      action: ce,
      scope: "textEditor.operationReview",
      defaults: ["A"]
    },
    {
      id: "textEditor.review.rejectOperation",
      action: ce,
      scope: "textEditor.operationReview",
      defaults: ["R"]
    },
    {
      id: "textEditor.agent.cancelToolApproval",
      action: ze,
      scope: "textEditor.toolApproval",
      delivery: "capture",
      stopPropagation: !0,
      defaults: ["Escape"],
      configurable: !1,
      allowInEditable: !0
    },
    {
      id: "textEditor.progressiveSelect",
      action: Oe,
      scope: "textEditor.editor",
      defaults: ["Mod+A"],
      delivery: "editor",
      allowInEditable: !0,
      configurable: !1,
      repeatPolicy: "allow"
    },
    {
      id: "textEditor.link.edit",
      action: Ee,
      scope: "textEditor.editor",
      delivery: "editor",
      defaults: ["Mod+Shift+K"],
      allowInEditable: !0
    },
    {
      id: "textEditor.inlineEdit.open",
      action: je,
      scope: "textEditor.authoring",
      delivery: "capture",
      stopPropagation: !0,
      defaults: ["Mod+K"],
      allowInEditable: !0
    },
    {
      id: "textEditor.askAI.open",
      action: Se,
      scope: "textEditor.authoring",
      delivery: "capture",
      stopPropagation: !0,
      defaults: ["Mod+J"],
      allowInEditable: !0
    },
    {
      id: "textEditor.inlineAi.escape",
      action: $e,
      scope: "textEditor.authoring",
      delivery: "capture",
      stopPropagation: !0,
      defaults: ["Escape"],
      allowInEditable: !0,
      configurable: !1
    },
    {
      id: "textEditor.review.accept",
      action: ve,
      scope: "textEditor.review",
      delivery: "editor",
      defaults: ["Mod+Enter"],
      allowInEditable: !0
    },
    {
      id: "textEditor.review.keep",
      action: le,
      scope: "textEditor.review",
      delivery: "editor",
      defaults: ["Mod+Y"],
      allowInEditable: !0
    },
    {
      id: "textEditor.review.restore",
      action: le,
      scope: "textEditor.review",
      delivery: "editor",
      defaults: ["Mod+Backspace"],
      allowInEditable: !0,
      when: Ve.eq(Wt, !0)
    },
    {
      id: "textEditor.review.previous",
      action: de,
      scope: "textEditor.review",
      delivery: "editor",
      defaults: ["Alt+ArrowUp"],
      allowInEditable: !0
    },
    {
      id: "textEditor.review.next",
      action: de,
      scope: "textEditor.review",
      delivery: "editor",
      defaults: ["Alt+ArrowDown"],
      allowInEditable: !0
    }
  ]
});
export {
  P as A,
  Re as B,
  Qe as C,
  C as D,
  ln as E,
  v as F,
  qe as G,
  nn as H,
  oe as I,
  mn as J,
  on as K,
  Ht as L,
  H as M,
  Ze as N,
  rn as O,
  pn as P,
  ot as Q,
  Me as Z,
  dn as a,
  Gt as b,
  pt as c,
  Ft as d,
  E as e,
  ut as f,
  an as g,
  gt as h,
  ht as i,
  sn as j,
  ft as k,
  yt as l,
  xt as m,
  Ee as n,
  je as o,
  Oe as p,
  Se as q,
  Wt as r,
  $e as s,
  ve as t,
  ce as u,
  cn as v,
  ze as w,
  le as x,
  de as y,
  fn as z
};
//# sourceMappingURL=actions-Sd62WBGv.mjs.map
