import { JSONContent } from '@tiptap/core';
import { ZxAssetDraft, ZxAssetRef } from './types';
export declare const cloneAssetRef: (asset: ZxAssetDraft | ZxAssetRef) => ZxAssetRef;
export declare const createAssetRef: (asset: ZxAssetDraft | ZxAssetRef) => ZxAssetRef;
export declare const normalizeAssets: (assets?: readonly ZxAssetDraft[] | null) => ZxAssetRef[];
export declare const resolveAssetRefById: (assets: readonly ZxAssetRef[] | null | undefined, assetId: string | null | undefined) => ZxAssetRef | undefined;
export declare const mergeAssetRefs: (...assetLists: Array<readonly ZxAssetDraft[] | null | undefined>) => ZxAssetRef[];
export declare const resolveAssetRefForNode: (node: JSONContent, document: {
    assets: readonly ZxAssetRef[];
} | null | undefined) => ZxAssetRef | null;
export declare const extractAssetsFromJSONContent: (content: JSONContent) => ZxAssetRef[];
export declare const normalizeAssetReferencesInContent: (content: JSONContent, assets: readonly ZxAssetRef[] | null | undefined) => JSONContent;
export declare const mergeDocumentAssets: (baseAssets: readonly ZxAssetDraft[] | null | undefined, baseReferencedAssets: readonly ZxAssetDraft[] | null | undefined, content: JSONContent) => ZxAssetRef[];
export declare const normalizeDocumentAssetModel: (content: JSONContent, assets?: readonly ZxAssetDraft[] | null) => {
    assets: ZxAssetRef[];
    content: JSONContent;
};
//# sourceMappingURL=assets.d.ts.map