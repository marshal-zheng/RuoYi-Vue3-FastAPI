import { ZxAssetDraft, ZxDocumentMeta, ZxTextEditorDocument, ZxTextEditorDocumentBody } from './types';
export interface ZxTextEditorDocumentDraft extends Omit<Partial<ZxTextEditorDocument>, 'assets' | 'body' | 'meta'> {
    assets?: ZxAssetDraft[];
    body?: Partial<ZxTextEditorDocumentBody>;
    meta?: Partial<ZxDocumentMeta>;
}
export { ZX_TEXT_EDITOR_DOCUMENT_VERSION, ZX_TEXT_EDITOR_SCHEMA_VERSION, } from './constants';
export declare const createDocumentBody: (body?: Partial<ZxTextEditorDocumentBody>) => ZxTextEditorDocumentBody;
export declare const createDocumentMeta: (meta?: Partial<ZxDocumentMeta>) => ZxDocumentMeta;
export declare const createTextEditorDocument: (document?: ZxTextEditorDocumentDraft) => ZxTextEditorDocument;
export declare const isTextEditorDocument: (value: unknown) => value is ZxTextEditorDocument;
//# sourceMappingURL=envelope.d.ts.map