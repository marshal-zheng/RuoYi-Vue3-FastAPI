export declare const ZX_TEXT_EDITOR_DOCUMENT_VERSION: 2;
export declare const ZX_TEXT_EDITOR_SCHEMA_VERSION = "stable-block-identity/v2";
//# sourceMappingURL=constants.d.ts.map