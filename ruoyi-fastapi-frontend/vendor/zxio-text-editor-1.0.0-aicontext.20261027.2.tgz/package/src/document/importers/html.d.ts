import { JSONContent } from '@tiptap/core';
import { ZxDocumentMeta, ZxTextEditorDocument } from '../types';
import { ZxDocumentImportOptions, ZxDocumentImportResult } from './shared';
export type ZxHTMLDocumentImportOptions = ZxDocumentImportOptions;
export declare const normalizeLegacyHtmlContent: (value: string | null | undefined) => string;
export declare const createLegacyHtmlDocument: (meta?: Partial<ZxDocumentMeta>, baseDocument?: ZxTextEditorDocument | null) => ZxTextEditorDocument;
export declare const importHTMLToDocument: (html: string, options?: ZxHTMLDocumentImportOptions) => ZxDocumentImportResult<JSONContent>;
//# sourceMappingURL=html.d.ts.map