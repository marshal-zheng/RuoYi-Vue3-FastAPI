import { ZxAnnotation, ZxAnnotationComment, ZxAnnotationPayload, ZxTextAnchor, ZxTextPosition } from './types';
export declare const createTextPosition: (position?: Partial<ZxTextPosition>) => ZxTextPosition;
export declare const createTextAnchor: (anchor?: Partial<ZxTextAnchor>) => ZxTextAnchor;
export declare const createAnnotationPayload: (payload?: Partial<ZxAnnotationPayload>) => ZxAnnotationPayload;
export declare const cloneAnnotationComment: (comment: ZxAnnotationComment) => ZxAnnotationComment;
export declare const cloneAnnotation: (annotation: ZxAnnotation) => ZxAnnotation;
export declare const createCommentAnnotation: (annotation: Pick<ZxAnnotation, "id"> & Partial<Omit<ZxAnnotation, "id" | "type" | "payload">> & {
    payload?: Partial<ZxAnnotationPayload>;
}) => ZxAnnotation;
export declare const normalizeAnnotations: (annotations?: ZxAnnotation[] | null) => ZxAnnotation[];
export declare const mergeAnnotations: (...annotationLists: Array<readonly ZxAnnotation[] | null | undefined>) => ZxAnnotation[];
//# sourceMappingURL=annotations.d.ts.map