import { ZX_CODE_BLOCK_CONTRACT_VERSION } from './defaults';
import { ZxCodeBlockDiagnostic } from './diagnostics';
export { ZX_CODE_BLOCK_CONTRACT_VERSION } from './defaults';
export type ZxCodeBlockDefaultSource = 'platform-default' | 'user-preference' | 'node-explicit' | 'migration';
export type ZxCodeBlockWrap = 'inherit' | 'off' | 'on';
export type ZxCodeBlockHeightMode = 'auto' | 'max' | 'fixed';
export type ZxCodeBlockCopyMode = 'plain' | 'markdown';
export type ZxCodeBlockVariant = 'code';
export type ZxCodeBlockFieldLifecycleState = 'implemented' | 'reserved' | 'deferred' | 'unsupported';
export interface ZxCodeBlockLineRange {
    from: number;
    to?: number;
}
export interface ZxCodeBlockAttrsV2 {
    contractVersion: typeof ZX_CODE_BLOCK_CONTRACT_VERSION;
    language: string | null;
    detectedLanguage: string | null;
    filename: string;
    caption: string;
    showLineNumbers: boolean;
    startLine: number;
    wrap: ZxCodeBlockWrap;
    collapsed: boolean;
    previewLines: number | null;
    heightMode: ZxCodeBlockHeightMode;
    height: number | null;
    theme: string | null;
    highlightLines: ZxCodeBlockLineRange[];
    copyMode: ZxCodeBlockCopyMode;
    variant: ZxCodeBlockVariant;
    groupId: string | null;
    tabLabel: string;
    defaultSource: Partial<Record<Exclude<keyof ZxCodeBlockAttrsV2, 'defaultSource'>, ZxCodeBlockDefaultSource>>;
}
export interface ZxCodeBlockFieldLifecycle {
    field: keyof ZxCodeBlockAttrsV2;
    type: string;
    defaultValue: unknown;
    sourcePolicy: string;
    lifecycle: ZxCodeBlockFieldLifecycleState;
    persisted: boolean;
    headless: boolean;
    descriptor: boolean;
    notes: string;
}
export interface ZxNormalizeCodeBlockAttrsOptions {
    source?: ZxCodeBlockDefaultSource;
    explicitKeys?: Iterable<string>;
    defaults?: Partial<ZxCodeBlockAttrsV2>;
}
export interface ZxNormalizeCodeBlockAttrsResult {
    attrs: ZxCodeBlockAttrsV2;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export declare const normalizeCodeBlockAttrs: (input?: Partial<ZxCodeBlockAttrsV2> & Record<string, unknown>, options?: ZxNormalizeCodeBlockAttrsOptions) => ZxNormalizeCodeBlockAttrsResult;
//# sourceMappingURL=contract.d.ts.map