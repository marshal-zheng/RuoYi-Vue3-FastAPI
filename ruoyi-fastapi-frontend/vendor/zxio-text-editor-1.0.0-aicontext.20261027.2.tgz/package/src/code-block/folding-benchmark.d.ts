import { ZxCodeBlockFoldingDecision, ZxCodeBlockFoldingResult } from './folding';
export interface ZxCodeBlockFoldingBenchmarkSample {
    name: 'ordinary' | 'ten-thousand-short-lines' | 'one-megabyte-single-line';
    code: string;
    language: string | null;
}
export interface ZxCodeBlockFoldingBenchmarkObservation {
    name: ZxCodeBlockFoldingBenchmarkSample['name'];
    method: 'single-process-performance-now-observation';
    input: {
        lineCount: number;
        characterCount: number;
        maxLineLength: number;
    };
    durationMs: number;
    decision: ZxCodeBlockFoldingDecision;
    scanStatus: ZxCodeBlockFoldingResult['scanStatus'];
    resolverExecuted: boolean;
    scanMetrics: ZxCodeBlockFoldingResult['scanMetrics'];
}
export declare const createCodeBlockFoldingBenchmarkSamples: () => readonly ZxCodeBlockFoldingBenchmarkSample[];
export declare const runCodeBlockFoldingBenchmarkSample: (sample: ZxCodeBlockFoldingBenchmarkSample) => ZxCodeBlockFoldingBenchmarkObservation;
//# sourceMappingURL=folding-benchmark.d.ts.map