import { ZxCodeBlockFallbackCandidate } from './folding-fallback';
import { ZxCodeBlockFoldKind, ZxCodeBlockFoldRange } from './folding-legacy';
import { ZxCodeBlockWrap } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
export type { ZxCodeBlockFoldKind, ZxCodeBlockFoldRange };
/**
 * @deprecated Use resolveCodeBlockFolding() for bounded, capability-aware
 * folding. This adapter intentionally preserves the original one-argument
 * contract and legacy behavior.
 */
export declare const resolveCodeBlockFoldRanges: (lines: readonly string[]) => ZxCodeBlockFoldRange[];
export type ZxCodeBlockFoldSource = 'fallback';
export type ZxCodeBlockFoldingDecisionStatus = 'enabled' | 'deferred' | 'disabled';
export type ZxCodeBlockFoldingReason = 'ready' | 'not-visible' | 'block-collapsed' | 'gutter-not-requested' | 'wrap-unsupported' | 'line-budget' | 'character-budget' | 'long-line-budget' | 'unsupported-language' | 'scan-budget-exceeded';
export interface ZxCodeBlockFoldingBudget {
    maxLines: number;
    maxCharacters: number;
    maxLineLength: number;
    maxCandidates: number;
    maxNestingDepth: number;
    maxScannedCharacters: number;
}
export declare const DEFAULT_CODE_BLOCK_FOLDING_BUDGET: Readonly<{
    maxLines: 5000;
    maxCharacters: 200000;
    maxLineLength: 20000;
    maxCandidates: 1000;
    maxNestingDepth: 128;
    maxScannedCharacters: 200000;
}>;
export declare const CODE_BLOCK_FOLDING_ENGINE_VERSION: "folding-safety/v1";
export interface ZxCodeBlockFoldingPolicyInput {
    lines: readonly string[];
    characterCount: number;
    language: string | null;
    effectiveWrap: 'on' | 'off';
    visible: boolean;
    blockCollapsed: boolean;
    foldingRequested: boolean;
    wrapAlignmentSupported: boolean;
    budget?: Partial<ZxCodeBlockFoldingBudget>;
}
export interface ZxCodeBlockFoldingMetrics {
    lineCount: number;
    characterCount: number;
    maxLineLength: number;
}
interface ZxCodeBlockFoldingDecisionBase {
    metrics: ZxCodeBlockFoldingMetrics;
}
export type ZxCodeBlockFoldingDecision = (ZxCodeBlockFoldingDecisionBase & {
    status: 'enabled';
    reason: 'ready';
}) | (ZxCodeBlockFoldingDecisionBase & {
    status: 'deferred';
    reason: 'not-visible' | 'block-collapsed' | 'gutter-not-requested';
}) | (ZxCodeBlockFoldingDecisionBase & {
    status: 'disabled';
    reason: 'wrap-unsupported' | 'line-budget' | 'character-budget' | 'long-line-budget' | 'unsupported-language' | 'scan-budget-exceeded';
});
export type ZxCodeBlockFoldingSkippedDecision = Exclude<ZxCodeBlockFoldingDecision, {
    status: 'enabled';
}>;
export interface ZxCodeBlockResolvedFoldRange extends ZxCodeBlockFoldRange {
    key: string;
    source: ZxCodeBlockFoldSource;
    anchor: {
        startText: string;
        endText: string;
        span: number;
        depth: number;
    };
}
export interface ZxCodeBlockFoldingResult {
    decision: ZxCodeBlockFoldingDecision;
    scanStatus: 'not-run' | 'complete' | 'budget-exceeded';
    ranges: readonly ZxCodeBlockResolvedFoldRange[];
    diagnostics: readonly ZxCodeBlockDiagnostic[];
    scanMetrics: {
        scannedCharacters: number;
        candidateCount: number;
        maxObservedDepth: number;
    };
}
export interface ZxCodeBlockFoldIntent {
    state: 'active' | 'suspended';
    source: ZxCodeBlockFoldSource;
    kind: ZxCodeBlockFoldKind;
    anchor: ZxCodeBlockResolvedFoldRange['anchor'];
}
export interface ZxCodeBlockDisplayRow {
    lineIndex: number;
    lineNumber: number;
    fromOffset: number;
    text: string;
    rangeKey: string | null;
    folded: boolean;
    hiddenLineCount: number;
}
export type ZxCodeBlockPendingEdit = {
    type: 'insert-text';
    text: string;
} | {
    type: 'delete-backward';
} | {
    type: 'delete-forward';
} | {
    type: 'insert-plain-text';
    text: string;
    source: 'paste' | 'drop';
};
export interface ZxCodeBlockLocalEditRequest {
    offset: number;
    trigger: 'pointer' | 'keyboard' | 'beforeinput' | 'paste' | 'drop' | 'composition';
    pendingEdit?: ZxCodeBlockPendingEdit;
}
export declare const resolveCodeBlockFoldingBudget: (budget?: Partial<ZxCodeBlockFoldingBudget>) => ZxCodeBlockFoldingBudget;
export declare const createCodeBlockFoldingBudgetFingerprint: (budget?: Partial<ZxCodeBlockFoldingBudget>) => string;
export declare const resolveCodeBlockEffectiveWrap: (wrap: ZxCodeBlockWrap, hostWrap?: "on" | "off") => "on" | "off";
export declare const resolveCodeBlockCanonicalLineOffsets: (code: string) => readonly number[];
export declare const evaluateCodeBlockFoldingPolicy: (input: ZxCodeBlockFoldingPolicyInput) => ZxCodeBlockFoldingDecision;
export declare const normalizeCodeBlockFoldRanges: (lines: readonly string[], candidates: readonly ZxCodeBlockFallbackCandidate[]) => readonly ZxCodeBlockResolvedFoldRange[];
export declare const createCodeBlockFoldingSkippedResult: (decision: ZxCodeBlockFoldingSkippedDecision) => ZxCodeBlockFoldingResult;
export declare const resolveCodeBlockFolding: (input: ZxCodeBlockFoldingPolicyInput) => ZxCodeBlockFoldingResult;
export declare const reconcileCodeBlockFoldIntents: (previous: readonly ZxCodeBlockFoldIntent[], nextRanges: readonly ZxCodeBlockResolvedFoldRange[]) => readonly ZxCodeBlockFoldIntent[];
export declare const setCodeBlockFoldIntent: (input: {
    previous: readonly ZxCodeBlockFoldIntent[];
    ranges: readonly ZxCodeBlockResolvedFoldRange[];
    rangeKey: string;
    folded: boolean;
}) => readonly ZxCodeBlockFoldIntent[];
export declare const toggleCodeBlockFoldIntent: (input: {
    previous: readonly ZxCodeBlockFoldIntent[];
    ranges: readonly ZxCodeBlockResolvedFoldRange[];
    rangeKey: string;
}) => readonly ZxCodeBlockFoldIntent[];
export declare const projectCodeBlockDisplayRows: (input: {
    lines: readonly string[];
    lineNumbers: readonly number[];
    lineOffsets?: readonly number[];
    ranges: readonly ZxCodeBlockResolvedFoldRange[];
    activeIntents: readonly ZxCodeBlockFoldIntent[];
}) => readonly ZxCodeBlockDisplayRow[];
//# sourceMappingURL=folding.d.ts.map