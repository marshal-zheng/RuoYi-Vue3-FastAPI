import { JSONContent } from '@tiptap/core';
import { ZxCodeBlockAttrsV2, ZxCodeBlockCopyMode, ZxCodeBlockWrap } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
import { ZxCodeBlockProductivityEventCallback } from './productivity-events';
export type ZxCodeBlockBulkScope = 'current-block' | 'selection' | 'document' | 'current-group';
export interface ZxCodeBlockBulkOperation {
    language?: string | null;
    wrap?: ZxCodeBlockWrap;
    showLineNumbers?: boolean;
    copyMode?: ZxCodeBlockCopyMode;
    normalizeLanguageAliases?: boolean;
}
export interface ZxCodeBlockBulkPreviewItem {
    blockId: string;
    scope: ZxCodeBlockBulkScope;
    before: Partial<ZxCodeBlockAttrsV2>;
    after: Partial<ZxCodeBlockAttrsV2>;
    status: 'will-change' | 'unchanged' | 'skipped' | 'failed';
    reason?: string;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export interface ZxScanCodeBlockBulkOperationInput {
    content: JSONContent;
    scope: ZxCodeBlockBulkScope;
    operation: ZxCodeBlockBulkOperation;
    currentBlockId?: string;
    selectionBlockIds?: string[];
    groupId?: string | null;
    allowExplicitOverwrite?: boolean;
    supportedFields?: readonly BulkField[];
    contractRepairBlockIds?: readonly string[];
}
export interface ZxCodeBlockBulkPreview {
    scope: ZxCodeBlockBulkScope;
    total: number;
    willChange: number;
    unchanged: number;
    skipped: number;
    failed: number;
    items: ZxCodeBlockBulkPreviewItem[];
    diagnostics: ZxCodeBlockDiagnostic[];
}
declare const CODE_BLOCK_BULK_FIELDS: readonly ["language", "wrap", "showLineNumbers", "copyMode"];
type BulkField = (typeof CODE_BLOCK_BULK_FIELDS)[number];
export declare const scanCodeBlockBulkOperation: (input: ZxScanCodeBlockBulkOperationInput, options?: {
    onEvent?: ZxCodeBlockProductivityEventCallback;
}) => ZxCodeBlockBulkPreview;
export declare const summarizeCodeBlockBulkPreview: (preview: ZxCodeBlockBulkPreview) => string;
export declare const isCodeBlockBulkOperationEmpty: (operation: ZxCodeBlockBulkOperation) => boolean;
export {};
//# sourceMappingURL=bulk-normalization.d.ts.map