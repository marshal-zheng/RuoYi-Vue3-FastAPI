import { ZxCodeBlockHeadlessModel, ZxCodeBlockLineModel } from './model';
import { ZxCodeBlockAttrsV2, ZxCodeBlockLineRange } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
import { ZxCodeBlockHighlighterAdapter, ZxCodeBlockNormalizedLanguage } from './language';
export declare const ZX_CODE_BLOCK_DESCRIPTOR_VERSION: "text-editor.code-block-descriptor/v2";
export interface ZxCodeBlockDeliveryDescriptor {
    version: typeof ZX_CODE_BLOCK_DESCRIPTOR_VERSION;
    nodeType: 'codeBlock';
    attrs: ZxCodeBlockAttrsV2;
    code: string;
    language: ZxCodeBlockNormalizedLanguage;
    displayLabel: string;
    display: {
        filename: string;
        caption: string;
        showLineNumbers: boolean;
        startLine: number;
        wrap: ZxCodeBlockAttrsV2['wrap'];
        collapsed: boolean;
        previewFrom: number;
        previewTo: number;
        heightMode: ZxCodeBlockAttrsV2['heightMode'];
        height: number | null;
        highlightLines: ZxCodeBlockLineRange[];
        theme: string | null;
    };
    lines: ZxCodeBlockLineModel;
    copy: ZxCodeBlockHeadlessModel['copy'];
    summary: {
        text: string;
        previewText: string;
        lineCount: number;
    };
    capabilities: {
        highlight: 'supported' | 'unsupported' | 'partial';
        markdownMeta: 'supported' | 'unsupported' | 'partial';
        binaryExport: 'supported' | 'unsupported' | 'partial';
    };
    diagnostics: ZxCodeBlockDiagnostic[];
}
export interface ZxCreateCodeBlockDeliveryDescriptorInput {
    code: string;
    attrs: Partial<ZxCodeBlockAttrsV2>;
    highlighter?: ZxCodeBlockHighlighterAdapter;
}
export declare const createCodeBlockDeliveryDescriptor: (input: ZxCreateCodeBlockDeliveryDescriptorInput) => ZxCodeBlockDeliveryDescriptor;
//# sourceMappingURL=descriptor.d.ts.map