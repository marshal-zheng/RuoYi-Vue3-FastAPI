import { ZxCodeBlockAttrsV2 } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
export interface ZxCodeBlockHTMLParseResult {
    attrs: ZxCodeBlockAttrsV2;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export declare const parseCodeBlockHTMLAttrs: (element: HTMLElement | Record<string, unknown>) => ZxCodeBlockHTMLParseResult;
export declare const renderCodeBlockHTMLAttrs: (attrsInput: Partial<ZxCodeBlockAttrsV2>) => Record<string, string>;
//# sourceMappingURL=html.d.ts.map