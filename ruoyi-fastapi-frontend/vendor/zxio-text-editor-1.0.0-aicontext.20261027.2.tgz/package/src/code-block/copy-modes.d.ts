import { JSONContent } from '@tiptap/core';
import { ZxCodeBlockAttrsV2 } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
import { ZxCodeBlockProductivityEventCallback } from './productivity-events';
export interface ZxCodeBlockCopyRequest {
    mode: 'plain' | 'markdown';
    scope: 'current-block' | 'current-tab' | 'group';
}
export interface ZxCodeBlockCopyResult {
    status: 'success' | 'degraded' | 'failed';
    mimeType: 'text/plain' | 'text/markdown';
    text: string;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export interface ZxResolveCodeBlockCopyRequestInput extends ZxCodeBlockCopyRequest {
    block: JSONContent;
    groupBlocks?: JSONContent[];
}
export declare const resolveCodeBlockCopyRequest: (input: ZxResolveCodeBlockCopyRequestInput, options?: {
    onEvent?: ZxCodeBlockProductivityEventCallback;
}) => ZxCodeBlockCopyResult;
export declare const createCodeBlockJSONForCopy: (code: string, attrs: Partial<ZxCodeBlockAttrsV2>) => JSONContent;
//# sourceMappingURL=copy-modes.d.ts.map