import { ZxCodeBlockAttrsV2, ZxCodeBlockLineRange } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
import { ZxCodeBlockProductivityEventCallback } from './productivity-events';
export interface ZxCodeBlockHighlightEdit {
    ranges: ZxCodeBlockLineRange[];
    mode: 'replace' | 'add' | 'remove' | 'clear';
}
export interface ZxNormalizeCodeBlockHighlightEditInput {
    currentRanges?: ZxCodeBlockLineRange[];
    edit: ZxCodeBlockHighlightEdit;
    lineCount: number;
    interactive?: boolean;
}
export interface ZxNormalizeCodeBlockHighlightEditResult {
    status: 'success' | 'failed';
    ranges: ZxCodeBlockLineRange[];
    patch: Pick<ZxCodeBlockAttrsV2, 'highlightLines'> | null;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export declare const countCodeBlockLogicalLines: (code: string) => number;
export declare const normalizeCodeBlockHighlightRanges: (ranges: ZxCodeBlockLineRange[] | undefined, lineCount: number, options?: {
    interactive?: boolean;
}) => {
    status: "failed";
    ranges: never[];
    diagnostics: ZxCodeBlockDiagnostic[];
} | {
    status: "success";
    ranges: ({
        from: number;
        to: number;
    } | {
        from: number;
    })[];
    diagnostics: ZxCodeBlockDiagnostic[];
};
export declare const normalizeCodeBlockHighlightEdit: (input: ZxNormalizeCodeBlockHighlightEditInput, options?: {
    onEvent?: ZxCodeBlockProductivityEventCallback;
}) => ZxNormalizeCodeBlockHighlightEditResult;
export declare const parseCodeBlockHighlightInput: (value: string) => ZxCodeBlockLineRange[];
export declare const formatCodeBlockHighlightRanges: (ranges: readonly ZxCodeBlockLineRange[]) => string;
//# sourceMappingURL=highlight-editor.d.ts.map