import { JSONContent } from '@tiptap/core';
import { ZxCodeBlockLineRange, ZxCodeBlockWrap } from './contract';
import { ZxCodeBlockDeliveryDescriptor } from './descriptor';
import { ZxCodeBlockDiagnostic } from './diagnostics';
type ZxCodeBlockJSONContentLike = JSONContent | {
    toJSON?: () => JSONContent;
    attrs?: Record<string, unknown>;
    content?: unknown;
    text?: unknown;
    textContent?: unknown;
    type?: unknown;
};
export declare const ZX_CODE_BLOCK_DELIVERY_SURFACES: readonly ["public-read-page", "ssr-fragment-html", "ssr-fragment-react", "markdown-serializer", "markdown-parser", "html-serializer", "html-parser", "search-record", "excerpt-summary", "pdf-composition", "docx-composition"];
export type ZxCodeBlockDeliverySurface = (typeof ZX_CODE_BLOCK_DELIVERY_SURFACES)[number];
export declare const ZX_CODE_BLOCK_DESCRIPTOR_FIELD_GROUPS: readonly ["code", "language", "display", "lines", "copy", "summary", "capabilities", "diagnostics"];
export type ZxCodeBlockDescriptorFieldGroup = (typeof ZX_CODE_BLOCK_DESCRIPTOR_FIELD_GROUPS)[number];
export declare const ZX_CODE_BLOCK_DELIVERY_DIAGNOSTIC_CODES: readonly ["codeBlock.delivery.contractRepairRequired", "codeBlock.delivery.fieldPartial", "codeBlock.delivery.fieldUnsupported", "codeBlock.delivery.securityRedacted", "codeBlock.delivery.legacyFallbackForbidden", "codeBlock.delivery.htmlFirstForbidden"];
export type ZxCodeBlockDeliveryDiagnosticCode = (typeof ZX_CODE_BLOCK_DELIVERY_DIAGNOSTIC_CODES)[number];
export type ZxCodeBlockFieldSupport = 'supported' | 'partial' | 'unsupported' | 'not-emitted';
export type ZxCodeBlockFieldSupportMatrix = Record<ZxCodeBlockDescriptorFieldGroup, ZxCodeBlockFieldSupport>;
export interface ZxCodeBlockDescriptorCompatibilityResult {
    ok: boolean;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export interface ZxCodeBlockVisibleLineModel {
    lines: string[];
    lineNumbers: number[];
    previewed: boolean;
    previewFrom: number;
    previewTo: number;
    totalLineCount: number;
}
export interface ZxCodeBlockSurfaceProjection {
    surface: ZxCodeBlockDeliverySurface;
    descriptorVersion: string;
    descriptor: ZxCodeBlockDeliveryDescriptor;
    fieldSupport: ZxCodeBlockFieldSupportMatrix;
    diagnostics: ZxCodeBlockDiagnostic[];
    code: string;
    language: ZxCodeBlockDeliveryDescriptor['language'];
    displayLabel: string;
    display: ZxCodeBlockDeliveryDescriptor['display'];
    lines: ZxCodeBlockDeliveryDescriptor['lines'];
    visibleLines: ZxCodeBlockVisibleLineModel;
    copy: ZxCodeBlockDeliveryDescriptor['copy'];
    summary: ZxCodeBlockDeliveryDescriptor['summary'];
    capabilities: ZxCodeBlockDeliveryDescriptor['capabilities'];
}
export interface ZxBinaryCompositionCodeBlock {
    kind: 'code-block';
    descriptorVersion: string;
    code: string;
    language: {
        id: string | null;
        displayLabel: string;
        supported: boolean | null;
    };
    title: {
        filename: string;
        caption: string;
    };
    display: {
        showLineNumbers: boolean;
        startLine: number;
        wrap: ZxCodeBlockWrap;
        collapsed: boolean;
        previewFrom: number;
        previewTo: number;
        previewed: boolean;
        heightMode: ZxCodeBlockDeliveryDescriptor['display']['heightMode'];
        height: number | null;
        highlightLines: ZxCodeBlockLineRange[];
        theme: string | null;
    };
    lines: ZxCodeBlockDeliveryDescriptor['lines'];
    copy: ZxCodeBlockDeliveryDescriptor['copy'];
    capabilities: ZxCodeBlockDeliveryDescriptor['capabilities'];
    diagnostics: ZxCodeBlockDiagnostic[];
    fieldSupport: {
        pdf: ZxCodeBlockFieldSupportMatrix;
        docx: ZxCodeBlockFieldSupportMatrix;
    };
}
export declare const ZX_CODE_BLOCK_SURFACE_FIELD_SUPPORT: {
    readonly 'public-read-page': {
        readonly summary: "partial";
        readonly code: ZxCodeBlockFieldSupport;
        readonly language: ZxCodeBlockFieldSupport;
        readonly display: ZxCodeBlockFieldSupport;
        readonly copy: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly lines: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'ssr-fragment-html': {
        readonly summary: "partial";
        readonly code: ZxCodeBlockFieldSupport;
        readonly language: ZxCodeBlockFieldSupport;
        readonly display: ZxCodeBlockFieldSupport;
        readonly copy: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly lines: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'ssr-fragment-react': {
        readonly summary: "partial";
        readonly code: ZxCodeBlockFieldSupport;
        readonly language: ZxCodeBlockFieldSupport;
        readonly display: ZxCodeBlockFieldSupport;
        readonly copy: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly lines: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'markdown-serializer': {
        readonly language: "partial";
        readonly lines: "partial";
        readonly copy: "partial";
        readonly summary: "not-emitted";
        readonly code: ZxCodeBlockFieldSupport;
        readonly display: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'markdown-parser': {
        readonly language: "partial";
        readonly code: ZxCodeBlockFieldSupport;
        readonly display: ZxCodeBlockFieldSupport;
        readonly copy: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly summary: ZxCodeBlockFieldSupport;
        readonly lines: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'html-serializer': {
        readonly lines: "partial";
        readonly copy: "not-emitted";
        readonly summary: "not-emitted";
        readonly code: ZxCodeBlockFieldSupport;
        readonly language: ZxCodeBlockFieldSupport;
        readonly display: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'html-parser': ZxCodeBlockFieldSupportMatrix;
    readonly 'search-record': {
        readonly language: "not-emitted";
        readonly display: "not-emitted";
        readonly lines: "not-emitted";
        readonly copy: "not-emitted";
        readonly code: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly summary: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'excerpt-summary': {
        readonly code: "partial";
        readonly language: "not-emitted";
        readonly display: "not-emitted";
        readonly lines: "not-emitted";
        readonly copy: "not-emitted";
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly summary: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'pdf-composition': {
        readonly display: "partial";
        readonly lines: "partial";
        readonly copy: "partial";
        readonly summary: "partial";
        readonly code: ZxCodeBlockFieldSupport;
        readonly language: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
    readonly 'docx-composition': {
        readonly display: "partial";
        readonly lines: "partial";
        readonly copy: "partial";
        readonly summary: "partial";
        readonly code: ZxCodeBlockFieldSupport;
        readonly language: ZxCodeBlockFieldSupport;
        readonly diagnostics: ZxCodeBlockFieldSupport;
        readonly capabilities: ZxCodeBlockFieldSupport;
    };
};
export declare const createCodeBlockDescriptorFromJSONContent: (node: ZxCodeBlockJSONContentLike) => ZxCodeBlockDeliveryDescriptor;
export declare const assertCodeBlockDescriptorCompatibility: (descriptor: unknown) => ZxCodeBlockDescriptorCompatibilityResult;
export declare const resolveCodeBlockVisibleLines: (descriptor: ZxCodeBlockDeliveryDescriptor) => ZxCodeBlockVisibleLineModel;
export declare const createCodeBlockSurfaceProjection: (input: {
    surface: ZxCodeBlockDeliverySurface;
    descriptor: ZxCodeBlockDeliveryDescriptor;
}) => ZxCodeBlockSurfaceProjection;
export declare const serializeCodeBlockDescriptorToSearchText: (descriptor: ZxCodeBlockDeliveryDescriptor) => string;
export declare const serializeCodeBlockDescriptorToExcerpt: (descriptor: ZxCodeBlockDeliveryDescriptor) => string;
export declare const projectCodeBlockDescriptorToBinaryComposition: (descriptor: ZxCodeBlockDeliveryDescriptor) => ZxBinaryCompositionCodeBlock;
export {};
//# sourceMappingURL=delivery-surfaces.d.ts.map