export type ZxCodeBlockDiagnosticSeverity = 'info' | 'warning' | 'error';
export interface ZxCodeBlockDiagnostic {
    code: string;
    severity: ZxCodeBlockDiagnosticSeverity;
    path: string;
    message: string;
}
export declare const createCodeBlockDiagnostic: (diagnostic: ZxCodeBlockDiagnostic) => ZxCodeBlockDiagnostic;
export declare const pushUniqueCodeBlockDiagnostic: (diagnostics: ZxCodeBlockDiagnostic[], diagnostic: ZxCodeBlockDiagnostic) => void;
//# sourceMappingURL=diagnostics.d.ts.map