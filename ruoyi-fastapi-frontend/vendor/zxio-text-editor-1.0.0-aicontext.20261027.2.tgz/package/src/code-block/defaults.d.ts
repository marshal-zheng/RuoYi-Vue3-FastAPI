import { ZxCodeBlockAttrsV2, ZxCodeBlockDefaultSource } from './contract';
export declare const ZX_CODE_BLOCK_CONTRACT_VERSION: "zx-code-block/v2";
export declare const ZX_CODE_BLOCK_DEFAULT_SOURCE_VALUES: readonly ["platform-default", "user-preference", "node-explicit", "migration"];
export declare const createCodeBlockDefaultSource: (source?: ZxCodeBlockDefaultSource) => ZxCodeBlockAttrsV2["defaultSource"];
export declare const createDefaultCodeBlockAttrs: (source?: ZxCodeBlockDefaultSource) => ZxCodeBlockAttrsV2;
export declare const ZX_CODE_BLOCK_FIELD_LIFECYCLE: readonly [{
    readonly field: "contractVersion";
    readonly type: "'zx-code-block/v2'";
    readonly defaultValue: "zx-code-block/v2";
    readonly sourcePolicy: "platform-default/generated";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Migration idempotency marker";
}, {
    readonly field: "language";
    readonly type: "string | null";
    readonly defaultValue: null;
    readonly sourcePolicy: "node-explicit | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Normalized language id";
}, {
    readonly field: "detectedLanguage";
    readonly type: "string | null";
    readonly defaultValue: null;
    readonly sourcePolicy: "node-explicit | platform-default";
    readonly lifecycle: "reserved";
    readonly persisted: true;
    readonly headless: false;
    readonly descriptor: true;
    readonly notes: "Reserved for language detection";
}, {
    readonly field: "filename";
    readonly type: "string";
    readonly defaultValue: "";
    readonly sourcePolicy: "node-explicit | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Display filename or migrated legacy title";
}, {
    readonly field: "caption";
    readonly type: "string";
    readonly defaultValue: "";
    readonly sourcePolicy: "node-explicit | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Optional prose caption";
}, {
    readonly field: "showLineNumbers";
    readonly type: "boolean";
    readonly defaultValue: true;
    readonly sourcePolicy: "node-explicit | user-preference | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Line number display state";
}, {
    readonly field: "startLine";
    readonly type: "number";
    readonly defaultValue: 1;
    readonly sourcePolicy: "node-explicit | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "First rendered line number";
}, {
    readonly field: "wrap";
    readonly type: "'inherit' | 'off' | 'on'";
    readonly defaultValue: "inherit";
    readonly sourcePolicy: "node-explicit | user-preference | markdown-sidecar | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Wrap preference state";
}, {
    readonly field: "collapsed";
    readonly type: "boolean";
    readonly defaultValue: false;
    readonly sourcePolicy: "node-explicit | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Collapsed display state";
}, {
    readonly field: "previewLines";
    readonly type: "number | null";
    readonly defaultValue: null;
    readonly sourcePolicy: "node-explicit | user-preference | markdown-sidecar | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Preview line count when collapsed";
}, {
    readonly field: "heightMode";
    readonly type: "'auto' | 'max' | 'fixed'";
    readonly defaultValue: "max";
    readonly sourcePolicy: "node-explicit | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Height semantics for current and later UI";
}, {
    readonly field: "height";
    readonly type: "number | null";
    readonly defaultValue: null;
    readonly sourcePolicy: "node-explicit | migration | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Fixed or max height value in pixels";
}, {
    readonly field: "theme";
    readonly type: "string | null";
    readonly defaultValue: null;
    readonly sourcePolicy: "node-explicit | user-preference | platform-default";
    readonly lifecycle: "reserved";
    readonly persisted: true;
    readonly headless: false;
    readonly descriptor: true;
    readonly notes: "Reserved highlighter theme preference";
}, {
    readonly field: "highlightLines";
    readonly type: "ZxCodeBlockLineRange[]";
    readonly defaultValue: readonly [];
    readonly sourcePolicy: "node-explicit | markdown-sidecar | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Line highlight ranges";
}, {
    readonly field: "copyMode";
    readonly type: "'plain' | 'markdown'";
    readonly defaultValue: "plain";
    readonly sourcePolicy: "node-explicit | user-preference | platform-default";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Copy behavior preference";
}, {
    readonly field: "variant";
    readonly type: "'code'";
    readonly defaultValue: "code";
    readonly sourcePolicy: "node-explicit | platform-default";
    readonly lifecycle: "reserved";
    readonly persisted: true;
    readonly headless: false;
    readonly descriptor: true;
    readonly notes: "Reserved variant discriminator";
}, {
    readonly field: "groupId";
    readonly type: "string | null";
    readonly defaultValue: null;
    readonly sourcePolicy: "node-explicit | platform-default";
    readonly lifecycle: "reserved";
    readonly persisted: true;
    readonly headless: false;
    readonly descriptor: true;
    readonly notes: "Reserved multilingual group id";
}, {
    readonly field: "tabLabel";
    readonly type: "string";
    readonly defaultValue: "";
    readonly sourcePolicy: "node-explicit | platform-default";
    readonly lifecycle: "reserved";
    readonly persisted: true;
    readonly headless: false;
    readonly descriptor: true;
    readonly notes: "Reserved multilingual tab label";
}, {
    readonly field: "defaultSource";
    readonly type: "field source map";
    readonly defaultValue: "generated";
    readonly sourcePolicy: "generated from normalization";
    readonly lifecycle: "implemented";
    readonly persisted: true;
    readonly headless: true;
    readonly descriptor: true;
    readonly notes: "Per-field source provenance";
}];
//# sourceMappingURL=defaults.d.ts.map