import { JSONContent } from '@tiptap/core';
import { ZxCodeBlockAttrsV2 } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
export interface ZxCodeBlockDocumentEntry {
    blockId: string;
    node: JSONContent;
    path: number[];
    code: string;
    attrs: ZxCodeBlockAttrsV2;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export declare const createCodeBlockDocumentEntryId: (node: JSONContent, path: readonly number[]) => string;
export declare const collectCodeBlockDocumentEntries: (node: JSONContent, path?: number[], entries?: ZxCodeBlockDocumentEntry[]) => ZxCodeBlockDocumentEntry[];
//# sourceMappingURL=document-entries.d.ts.map