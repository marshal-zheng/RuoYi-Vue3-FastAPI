import { ZxCodeBlockDiagnostic } from './diagnostics';
import { ZxCodeBlockFoldKind, ZxCodeBlockFoldingBudget } from './folding';
export type ZxCodeBlockLexicalProfile = 'brace-c-comments' | 'brace-json' | 'indent-hash-comments' | 'indent-only' | 'region-only' | 'none';
export interface ZxCodeBlockFallbackCandidate {
    startLine: number;
    endLine: number;
    kind: ZxCodeBlockFoldKind;
    depth: number;
}
export interface ZxCodeBlockFallbackResult {
    status: 'complete' | 'budget-exceeded';
    candidates: readonly ZxCodeBlockFallbackCandidate[];
    diagnostics: readonly ZxCodeBlockDiagnostic[];
    metrics: {
        scannedCharacters: number;
        candidateCount: number;
        maxObservedDepth: number;
    };
}
export declare const resolveCodeBlockLexicalProfile: (language: string | null) => ZxCodeBlockLexicalProfile;
export declare const resolveCodeBlockFallback: (input: {
    lines: readonly string[];
    language: string | null;
    budget: ZxCodeBlockFoldingBudget;
}) => ZxCodeBlockFallbackResult;
//# sourceMappingURL=folding-fallback.d.ts.map