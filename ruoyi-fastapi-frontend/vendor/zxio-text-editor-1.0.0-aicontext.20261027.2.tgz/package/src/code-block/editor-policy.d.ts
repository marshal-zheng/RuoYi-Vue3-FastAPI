import { ZxCodeBlockHeadlessModel } from './model';
import { ZxCodeBlockAttrsV2, ZxNormalizeCodeBlockAttrsResult } from './contract';
export interface ZxCodeBlockEditorPolicy {
    longCodePreviewThreshold: number;
    /**
     * Retained for compatibility with hosts that provide the old policy shape.
     * Long paste/import content now stays expanded by default.
     */
    longCodePreviewLines: number;
    longCodeMaxBodyHeight: string;
    newBlockDefaults: Pick<ZxCodeBlockAttrsV2, 'showLineNumbers' | 'wrap' | 'collapsed' | 'previewLines'>;
}
export declare const DEFAULT_CODE_BLOCK_EDITOR_POLICY: ZxCodeBlockEditorPolicy;
export declare const applyNewCodeBlockEditorDefaults: (attrs?: Partial<ZxCodeBlockAttrsV2>, policy?: ZxCodeBlockEditorPolicy) => Partial<ZxCodeBlockAttrsV2>;
export declare const applyLongCodePreviewDefaults: (input: {
    code: string;
    attrs?: Partial<ZxCodeBlockAttrsV2>;
    model?: ZxCodeBlockHeadlessModel;
}, policy?: ZxCodeBlockEditorPolicy) => Partial<ZxCodeBlockAttrsV2>;
export declare const normalizeCodeBlockEditorAttrs: (attrs: Partial<ZxCodeBlockAttrsV2>, explicitKeys?: Iterable<string>) => ZxNormalizeCodeBlockAttrsResult;
//# sourceMappingURL=editor-policy.d.ts.map