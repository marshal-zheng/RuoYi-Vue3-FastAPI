import { ZxCodeBlockAttrsV2, ZxCodeBlockWrap } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
import { ZxCodeBlockHeadlessModel } from './model';
import { ZxCodeBlockEditorPolicy } from './editor-policy';
export type ZxCodeBlockMoreSettingsField = 'filename' | 'caption' | 'startLine' | 'wrap' | 'showLineNumbers' | 'collapsed' | 'previewLines' | 'diagnostics';
export interface ZxCodeBlockEditorViewState {
    header: {
        languageLabel: string;
        language: string | null;
        filename: string;
        caption: string;
        canCopyPlain: boolean;
        copyDisabledReason: string | null;
        moreSettingsFields: ZxCodeBlockMoreSettingsField[];
    };
    body: {
        isEmpty: boolean;
        codePlaceholder: string | null;
        filenamePlaceholder: string | null;
        captionPlaceholder: string | null;
        visualLines: string[];
        visibleVisualLines: string[];
        lineNumbers: number[];
        visibleLineNumbers: number[];
        showLineNumbers: boolean;
        wrap: ZxCodeBlockWrap;
        collapsed: boolean;
        previewFrom: number;
        previewTo: number;
        visualLineCount: number;
        isLong: boolean;
        maxBodyHeight: string | null;
        scrollStatePersistence: 'ui-only';
    };
    copy: {
        text: string;
        mode: ZxCodeBlockAttrsV2['copyMode'];
    };
    diagnostics: ZxCodeBlockDiagnostic[];
}
export declare const resolveCodeBlockEditorViewState: (model: ZxCodeBlockHeadlessModel, policy?: ZxCodeBlockEditorPolicy) => ZxCodeBlockEditorViewState;
//# sourceMappingURL=editor-view-state.d.ts.map