export type ZxCodeBlockFoldKind = 'bracket' | 'comment' | 'indent' | 'region';
export interface ZxCodeBlockFoldRange {
    startLine: number;
    endLine: number;
    kind: ZxCodeBlockFoldKind;
}
export declare const resolveLegacyCodeBlockFoldRanges: (lines: readonly string[]) => ZxCodeBlockFoldRange[];
//# sourceMappingURL=folding-legacy.d.ts.map