import { ZxCodeBlockEditorPolicy } from './editor-policy';
import { ZxCodeBlockUserPreferences } from './preferences';
import { ZxCodeBlockAttrsV2 } from './contract';
import { ZxCodeBlockDiagnostic } from './diagnostics';
import { JSONContent } from '@tiptap/core';
export type ZxCodeBlockAuthoringSource = 'slash' | 'toolbar' | 'markdown-fence' | 'paste' | 'file-intake';
export interface CreateCodeBlockAuthoringInput {
    code?: string;
    language?: string | null;
    attrs?: Partial<ZxCodeBlockAttrsV2>;
    preferences?: Partial<ZxCodeBlockUserPreferences> | null;
    source: ZxCodeBlockAuthoringSource;
}
export interface ResolveCodeBlockCreationAttrsResult {
    attrs: Partial<ZxCodeBlockAttrsV2>;
    diagnostics: ZxCodeBlockDiagnostic[];
}
export declare const resolveCodeBlockCreationAttrs: (input: CreateCodeBlockAuthoringInput, policy?: ZxCodeBlockEditorPolicy) => ResolveCodeBlockCreationAttrsResult;
export declare const createCodeBlockJSONContent: (input: CreateCodeBlockAuthoringInput, policy?: ZxCodeBlockEditorPolicy) => JSONContent;
export declare const applyCodeBlockAuthoringDefaultsToJSONContent: (content: JSONContent, source: Extract<ZxCodeBlockAuthoringSource, "paste" | "file-intake">, policy?: ZxCodeBlockEditorPolicy) => JSONContent;
//# sourceMappingURL=authoring-commands.d.ts.map