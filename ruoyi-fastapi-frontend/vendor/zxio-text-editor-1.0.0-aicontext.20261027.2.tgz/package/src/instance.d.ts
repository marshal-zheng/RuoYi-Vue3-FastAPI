import { TextEditorInstance } from './types';
export type ZxTextEditorInstance = TextEditorInstance;
export type { TextEditorInstance };
//# sourceMappingURL=instance.d.ts.map