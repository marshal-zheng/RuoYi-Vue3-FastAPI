import { Editor } from '@tiptap/core';
import { ZxAnnotation, ZxAnnotationComment, ZxTextAnchor } from '../document';
/** Single comment payload */
export type CommentData = ZxAnnotationComment;
/** Comment thread data derived from annotations sidecar */
export interface CommentThreadData {
    /** Annotation identifier */
    id: string;
    /** Thread identifier */
    threadId: string;
    /** Anchor used to relocate the thread */
    anchor: ZxTextAnchor;
    /** Whether the thread is resolved */
    resolved: boolean;
    /** Thread comments */
    comments: CommentData[];
    /** Top position for floating UI placement */
    top?: number;
}
/** FloatingComments component props interface */
export interface FloatingCommentsProps {
    /** Editor instance */
    editor: Editor;
    /** Annotation-backed comment threads */
    threads: CommentThreadData[];
    /** Deprecated alias for threads */
    comments?: CommentThreadData[];
    /** Currently active annotation/thread ID */
    activeAnnotationId?: string | null;
    /** Deprecated alias for activeAnnotationId */
    activeCommentId?: string | null;
    /** Current user info */
    currentUser?: CommentUser;
    /** Whether in read-only mode */
    readonly?: boolean;
}
/** Comment user information */
export interface CommentUser {
    /** User ID */
    id: string;
    /** Full name */
    full_name?: string;
    /** Avatar URL */
    user_image?: string;
}
/** FloatingComments component events interface */
export interface FloatingCommentsEmits {
    /** Thread activated */
    (e: 'activate', annotationId: string): void;
    /** Create a new thread */
    (e: 'create', data: {
        annotation: ZxAnnotation;
    }): void;
    /** Edit an existing comment */
    (e: 'edit', data: {
        annotationId: string;
        commentId: string;
        content: string;
    }): void;
    /** Delete a thread */
    (e: 'delete', annotationId: string): void;
    /** Resolve a thread */
    (e: 'resolve', annotationId: string): void;
    /** Reply to a thread */
    (e: 'reply', data: {
        annotationId: string;
        content: string;
    }): void;
}
/** CommentEditor component props interface */
export interface CommentEditorProps {
    /** Initial content */
    content?: string;
    /** Whether editable */
    editable?: boolean;
    /** Placeholder text */
    placeholder?: string;
    /** Whether to show toolbar */
    showToolbar?: boolean;
    /** Whether to auto focus */
    autofocus?: boolean;
}
/** CommentEditor component events interface */
export interface CommentEditorEmits {
    /** Submit comment */
    (e: 'submit', content: string): void;
    /** Cancel editing */
    (e: 'cancel'): void;
    /** Content changed */
    (e: 'update:content', content: string): void;
}
//# sourceMappingURL=comment.d.ts.map