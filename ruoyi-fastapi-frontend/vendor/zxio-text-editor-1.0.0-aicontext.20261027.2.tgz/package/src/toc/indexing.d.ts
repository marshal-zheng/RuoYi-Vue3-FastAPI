import { ApplyTocIndexingOptions, NormalizeTocAnchorsResult, TextEditorTocNode } from './types';
export declare const applyTocIndexing: (input: TextEditorTocNode[], options?: ApplyTocIndexingOptions) => NormalizeTocAnchorsResult;
//# sourceMappingURL=indexing.d.ts.map