import { TocAnchor } from '../extensions/table-of-contents';
export declare const getTocAnchorNavigationId: (anchor: TocAnchor) => string;
export declare const matchesTocAnchorNavigationId: (anchor: TocAnchor, value: string) => boolean;
//# sourceMappingURL=identity.d.ts.map