export * from './html-adapter';
export * from './legacy-events';
//# sourceMappingURL=index.d.ts.map