export { createLegacyHtmlDocument, normalizeLegacyHtmlContent, } from '../document/importers/html';
//# sourceMappingURL=html-adapter.d.ts.map