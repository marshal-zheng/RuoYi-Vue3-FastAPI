import { ZxRenderProfileName, ZxRenderTargetName } from './contract';
import { ZxDeliverySurfaceName } from './surfaces';
export interface ZxRenderCacheKeyOptions {
    surface?: ZxDeliverySurfaceName | null;
    target: ZxRenderTargetName;
    profile: ZxRenderProfileName;
    docId?: string | number | null;
    docVersion?: string | number | null;
    hash?: string | null;
    variant?: unknown;
    namespace?: string;
}
export interface ZxScopedRenderCacheKeyOptions extends Omit<ZxRenderCacheKeyOptions, 'target' | 'profile' | 'surface'> {
}
export declare const createRenderCacheKey: (options: ZxRenderCacheKeyOptions) => string;
export declare const createScopedRenderCacheKey: (scope: Pick<ZxRenderCacheKeyOptions, "target" | "profile" | "surface"> & {
    variant?: unknown;
}, options?: ZxScopedRenderCacheKeyOptions) => string;
//# sourceMappingURL=cache.d.ts.map