import { ZxRenderExecutionContext } from './platform';
import { JSONContent } from '../types/tiptap-json-content';
import { ZxTextEditorDocument } from '../document';
import { ZxBaseRenderOptions, ZxRenderProfileName } from './contract';
export type ZxHTMLRenderProfileName = Extract<ZxRenderProfileName, 'safe-html' | 'public-html' | 'email-html'>;
export interface ZxHTMLRenderOptions extends ZxBaseRenderOptions {
    profile?: ZxHTMLRenderProfileName;
}
export interface ZxHTMLRenderInput {
    content: JSONContent;
    document?: ZxTextEditorDocument;
}
interface ZxHTMLRenderInternalOptions {
    debugMode?: 'drop-unhandled';
}
export declare const renderHTMLInputWithContext: (input: ZxHTMLRenderInput, context: ZxRenderExecutionContext<"html">, options?: ZxHTMLRenderInternalOptions) => string;
export declare const renderDocumentToHTML: (document: ZxTextEditorDocument, options?: ZxHTMLRenderOptions) => string;
export declare const renderJSONContentToHTML: (content: JSONContent, options?: ZxHTMLRenderOptions) => string;
export {};
//# sourceMappingURL=html.d.ts.map