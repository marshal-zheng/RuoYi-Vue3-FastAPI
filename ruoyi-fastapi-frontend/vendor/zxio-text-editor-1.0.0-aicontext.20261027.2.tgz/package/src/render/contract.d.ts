import { ZxExtensionDescriptor } from '../core/extension-descriptors';
import { ZxRenderDiagnostic } from './diagnostics';
export declare const ZX_RENDER_TARGET_NAMES: readonly ["html", "react", "text"];
export type ZxRenderTargetName = (typeof ZX_RENDER_TARGET_NAMES)[number];
export declare const ZX_RESERVED_RENDER_ADAPTER_SLOTS: readonly ["json"];
export type ZxReservedRenderAdapterSlotName = (typeof ZX_RESERVED_RENDER_ADAPTER_SLOTS)[number];
export type ZxRenderAdapterSlotName = ZxRenderTargetName | ZxReservedRenderAdapterSlotName;
export declare const ZX_RENDER_PROFILE_NAMES: readonly ["safe-html", "public-html", "email-html", "search-text", "excerpt"];
export type ZxRenderProfileName = (typeof ZX_RENDER_PROFILE_NAMES)[number];
export type ZxRenderImplementationStatus = 'implemented' | 'contract-only';
export type ZxRenderStrictness = 'fail-fast' | 'semantic-degrade';
export interface ZxRenderTargetDefinition {
    name: ZxRenderTargetName;
    strictness: ZxRenderStrictness;
}
export declare const ZX_RENDER_TARGETS: {
    readonly html: {
        readonly name: "html";
        readonly strictness: "fail-fast";
    };
    readonly react: {
        readonly name: "react";
        readonly strictness: "fail-fast";
    };
    readonly text: {
        readonly name: "text";
        readonly strictness: "semantic-degrade";
    };
};
export interface ZxRenderProfileDefinition {
    name: ZxRenderProfileName;
    compatibleTargets: readonly ZxRenderTargetName[];
    implementationStatus: ZxRenderImplementationStatus;
    strictness: ZxRenderStrictness;
}
export declare const getRenderTargetDefinition: (target: ZxRenderTargetName) => ZxRenderTargetDefinition;
export interface ZxBaseRenderOptions {
    descriptors?: readonly ZxExtensionDescriptor[];
    diagnostics?: ZxRenderDiagnostic[];
    variant?: Record<string, unknown>;
}
//# sourceMappingURL=contract.d.ts.map