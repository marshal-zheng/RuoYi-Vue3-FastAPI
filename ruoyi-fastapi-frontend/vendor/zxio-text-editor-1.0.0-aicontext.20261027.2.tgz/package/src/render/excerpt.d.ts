import { JSONContent } from '@tiptap/core';
import { ZxTextEditorDocument } from '../document';
import { ZxBaseRenderOptions } from './contract';
import { ZxTextRenderInput } from './text';
export interface ZxExcerptOptions extends ZxBaseRenderOptions {
    profile?: 'excerpt';
    maxLength?: number;
    preserveWords?: boolean;
    collapseWhitespace?: boolean;
    suffix?: string;
}
export interface ZxExcerptRenderInput extends ZxTextRenderInput {
    content: JSONContent;
    document?: ZxTextEditorDocument;
}
export declare const renderDocumentToExcerpt: (document: ZxTextEditorDocument, options?: ZxExcerptOptions) => string;
export declare const renderJSONContentToExcerpt: (content: JSONContent, options?: ZxExcerptOptions) => string;
//# sourceMappingURL=excerpt.d.ts.map