import { ZxRenderProfileName } from './contract';
export declare const ZX_RENDER_DIAGNOSTIC_KINDS: readonly ["unhandled-node", "unhandled-mark", "semantic-degrade", "unsupported-surface", "surface-target-mismatch", "surface-profile-mismatch", "resolver-failure", "link-rewritten", "asset-rewritten", "unsupported-profile", "unsupported-react-component", "policy-sanitized"];
export type ZxRenderDiagnosticKind = (typeof ZX_RENDER_DIAGNOSTIC_KINDS)[number];
export interface ZxRenderDiagnostic {
    kind: ZxRenderDiagnosticKind;
    name: string;
    path?: string;
}
export declare class ZxRenderError extends Error {
    readonly diagnostics: ZxRenderDiagnostic[];
    constructor(message: string, diagnostics?: ZxRenderDiagnostic[]);
}
export declare const createRenderDiagnostics: (diagnostics?: ZxRenderDiagnostic[]) => ZxRenderDiagnostic[];
export declare const hasRenderDiagnostic: (diagnostics: readonly ZxRenderDiagnostic[], kind: ZxRenderDiagnostic["kind"], name: string, path?: string) => boolean;
export declare const pushRenderDiagnostic: (diagnostics: ZxRenderDiagnostic[], diagnostic: ZxRenderDiagnostic) => ZxRenderDiagnostic[];
export declare const pushUniqueRenderDiagnostic: (diagnostics: ZxRenderDiagnostic[], diagnostic: ZxRenderDiagnostic) => ZxRenderDiagnostic[];
export declare const describeRenderDiagnostic: (diagnostic: ZxRenderDiagnostic) => string;
export declare const createUnhandledNodeDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
export declare const createUnhandledMarkDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
export declare const createUnsupportedProfileDiagnostic: (profile: ZxRenderProfileName, path?: string) => ZxRenderDiagnostic;
export declare const createUnsupportedSurfaceDiagnostic: (surface: string, path?: string) => ZxRenderDiagnostic;
export declare const createSurfaceTargetMismatchDiagnostic: (surface: string, path?: string) => ZxRenderDiagnostic;
export declare const createSurfaceProfileMismatchDiagnostic: (surface: string, path?: string) => ZxRenderDiagnostic;
export declare const createResolverFailureDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
export declare const createLinkRewrittenDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
export declare const createAssetRewrittenDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
export declare const createUnsupportedReactComponentDiagnostic: (componentKey: string, path?: string) => ZxRenderDiagnostic;
export declare const createPolicySanitizedDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
export declare const createSemanticDegradeDiagnostic: (name: string, path?: string) => ZxRenderDiagnostic;
//# sourceMappingURL=diagnostics.d.ts.map