import { ZxTextEditorDocument } from '../document';
import { ZxRenderDiagnostic } from './diagnostics';
import { ZxAssetResolveRequest, ZxLinkResolveRequest, ZxRenderResolvedAsset, ZxResolvedLink } from './resolvers';
import { ZxDeliverySurfaceName } from './surfaces';
export interface ZxStructuredDeliveryRewriteContext {
    surface: {
        name: ZxDeliverySurfaceName;
    };
    diagnostics: ZxRenderDiagnostic[];
    variant: Readonly<Record<string, unknown>>;
    resolveLink: (request: Omit<ZxLinkResolveRequest, 'surface' | 'profile' | 'document'>) => ZxResolvedLink;
    resolveAsset: (request: Omit<ZxAssetResolveRequest, 'surface' | 'profile'>) => ZxRenderResolvedAsset;
}
export declare const prepareStructuredDeliveryDocument: (document: ZxTextEditorDocument, context: ZxStructuredDeliveryRewriteContext) => ZxTextEditorDocument;
//# sourceMappingURL=delivery-rewrite.d.ts.map