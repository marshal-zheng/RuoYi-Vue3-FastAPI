import { JSONContent } from '@tiptap/core';
import { ZxTextEditorDocument } from '../document';
import { ZxRenderCapabilityConformanceReport } from '../core/extension-conformance';
import { ZxScopedRenderCacheKeyOptions } from './cache';
import { ZxBaseRenderOptions, ZxRenderProfileDefinition, ZxRenderProfileName, ZxRenderTargetName } from './contract';
import { ZxRenderDiagnostic } from './diagnostics';
import { ZxRenderExecutionContext, ZxRenderTargetAdapterMap } from './platform';
import { ZxEmailFragmentPayload, ZxDeliveryProjection, ZxPublicReadPagePayload, ZxDeliveryResultBase, ZxDeliveryResultMeta, ZxSSRHTMLFragmentPayload, ZxDeliveryTraces, ZxExcerptSummaryPayload, ZxSearchRecordPayload } from './result';
import { ZxAssetResolveRequest, ZxDeliveryResolverBundle, ZxDeliveryResolverTraceState, ZxLinkResolveRequest, ZxRenderResolvedAsset, ZxResolvedLink } from './resolvers';
import { ZxDeliveryPayloadKind, ZxDeliverySurfaceDefinition, ZxDeliverySurfaceName } from './surfaces';
type ZxDeliveryVariant = Record<string, unknown>;
export interface ZxDeliveryCacheOptions extends Omit<ZxScopedRenderCacheKeyOptions, 'variant'> {
}
export interface ZxBaseDeliveryOptions<TVariant extends ZxDeliveryVariant = ZxDeliveryVariant> extends Omit<ZxBaseRenderOptions, 'variant'> {
    variant?: TVariant;
    cache?: ZxDeliveryCacheOptions;
    resolvers?: ZxDeliveryResolverBundle;
}
export interface ZxPublicReadPageOptions extends ZxBaseDeliveryOptions<{
    includeHeadingAnchors?: boolean;
}> {
}
export interface ZxSSRFragmentOptions extends ZxBaseDeliveryOptions<{
    includeDataAttributes?: boolean;
}> {
}
export interface ZxEmailFragmentOptions extends ZxBaseDeliveryOptions<{
    requireAbsoluteUrls?: boolean;
}> {
}
export interface ZxSearchRecordOptions extends ZxBaseDeliveryOptions<{
    excerptMaxLength?: number;
}> {
}
export interface ZxExcerptSummaryOptions extends ZxBaseDeliveryOptions<{
    maxLength?: number;
    preserveWords?: boolean;
    collapseWhitespace?: boolean;
    suffix?: string;
}> {
}
export interface ZxDeliveryRequest extends ZxBaseRenderOptions {
    surface: ZxDeliverySurfaceName;
    target?: ZxRenderTargetName;
    profile?: ZxRenderProfileName;
    document?: ZxTextEditorDocument;
    cache?: ZxDeliveryCacheOptions;
    resolvers?: ZxDeliveryResolverBundle;
}
export interface ZxDeliveryExecutionContext {
    surface: ZxDeliverySurfaceDefinition;
    target: ZxRenderTargetName;
    profile: ZxRenderProfileDefinition;
    payloadKind: ZxDeliveryPayloadKind;
    report: ZxRenderCapabilityConformanceReport;
    diagnostics: ZxRenderDiagnostic[];
    document?: ZxTextEditorDocument;
    resolvers?: ZxDeliveryResolverBundle;
    traces: ZxDeliveryResolverTraceState;
    variant: Readonly<Record<string, unknown>>;
    renderContext: ZxRenderExecutionContext;
    createCacheKey: (options?: ZxScopedRenderCacheKeyOptions) => string;
    resolveLink: (request: Omit<ZxLinkResolveRequest, 'surface' | 'profile' | 'document'>) => ZxResolvedLink;
    resolveAsset: (request: Omit<ZxAssetResolveRequest, 'surface' | 'profile'>) => ZxRenderResolvedAsset;
}
export interface ZxDeliveryResultInput<TPayload> {
    payload: TPayload;
    cache?: ZxScopedRenderCacheKeyOptions;
    meta?: Partial<ZxDeliveryResultMeta>;
    projection?: Partial<ZxDeliveryProjection>;
    traces?: Partial<ZxDeliveryTraces>;
}
export interface ZxDeliveryRenderInput {
    content: JSONContent;
    document?: ZxTextEditorDocument;
}
interface ZxDeliveryEnvelopeInput<TPayload> extends ZxDeliveryResultInput<TPayload> {
    document?: ZxTextEditorDocument;
}
export type ZxDeliverySurfaceAdapter<TRenderResult, TPayload> = (renderResult: TRenderResult, context: ZxDeliveryExecutionContext) => ZxDeliveryResultInput<TPayload>;
export type ZxDeliverySurfaceAdapterMap<TRenderResult, TPayload> = Partial<Record<ZxDeliverySurfaceName, ZxDeliverySurfaceAdapter<TRenderResult, TPayload>>>;
export interface ZxDeliveryAdapterBundle<TRenderResult, TPayload> {
    target: ZxRenderTargetAdapterMap<TRenderResult>;
    surface: ZxDeliverySurfaceAdapterMap<TRenderResult, TPayload>;
}
export declare const createDeliveryExecutionContext: (request: ZxDeliveryRequest) => ZxDeliveryExecutionContext;
export declare const runSurfaceAdapter: <TRenderResult, TPayload>(context: ZxDeliveryExecutionContext, renderResult: TRenderResult, adapters: ZxDeliverySurfaceAdapterMap<TRenderResult, TPayload>) => ZxDeliveryResultInput<TPayload>;
export declare const buildDeliveryResultEnvelope: <TPayload>(context: ZxDeliveryExecutionContext, input: ZxDeliveryEnvelopeInput<TPayload>) => ZxDeliveryResultBase<TPayload>;
export declare const executeDeliverySurface: <TRenderResult, TPayload>(request: ZxDeliveryRequest, adapters: ZxDeliveryAdapterBundle<TRenderResult, TPayload>) => ZxDeliveryResultBase<TPayload>;
export declare const createStructuredDeliveryRenderInput: (document: ZxTextEditorDocument, context: ZxDeliveryExecutionContext) => ZxDeliveryRenderInput & {
    document: ZxTextEditorDocument;
};
export declare const renderDocumentToPublicReadPage: (document: ZxTextEditorDocument, options?: ZxPublicReadPageOptions) => ZxDeliveryResultBase<ZxPublicReadPagePayload>;
export declare const renderDocumentToSSRFragment: (document: ZxTextEditorDocument, options?: ZxSSRFragmentOptions) => ZxDeliveryResultBase<ZxSSRHTMLFragmentPayload>;
export declare const renderDocumentToEmailFragment: (document: ZxTextEditorDocument, options?: ZxEmailFragmentOptions) => ZxDeliveryResultBase<ZxEmailFragmentPayload>;
export declare const renderDocumentToSearchRecord: (document: ZxTextEditorDocument, options?: ZxSearchRecordOptions) => ZxDeliveryResultBase<ZxSearchRecordPayload>;
export declare const renderDocumentToExcerptSummary: (document: ZxTextEditorDocument, options?: ZxExcerptSummaryOptions) => ZxDeliveryResultBase<ZxExcerptSummaryPayload>;
export {};
//# sourceMappingURL=delivery.d.ts.map