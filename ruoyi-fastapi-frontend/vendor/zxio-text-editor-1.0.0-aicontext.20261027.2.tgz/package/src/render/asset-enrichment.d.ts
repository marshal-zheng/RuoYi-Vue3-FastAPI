import { JSONContent } from '@tiptap/core';
import { ZxTextEditorDocument } from '../document';
export declare const enrichRenderableContentWithAssets: (content: JSONContent, document?: ZxTextEditorDocument) => JSONContent;
//# sourceMappingURL=asset-enrichment.d.ts.map