import { ZxTextEditorDocument } from '../document/types';
import { ZxAIComplexNodeBoundedRunnerV1, ZxAIComplexNodeCommitDispatchResultV1, ZxAIComplexNodeCommitResourceRequestV1, ZxAIComplexNodeKernelInputV1, ZxAIComplexNodeRegistrySnapshotV1, ZxAIComplexNodeResourceAdmissionPortV1, ZxAIComplexNodeResourceReceiptV1 } from './complex-node';
import { ZxAISessionReviewArtifactTransferV1 } from './session-transport';
/**
 * Rebuilds a complex proposal from operation intent against the current
 * canonical document. No plan, Runtime trace, mapping or receipt from the
 * source artifact is reused.
 */
export declare const regenerateComplexNodeProposalForCurrentDocument: (input: {
    readonly sourceTransfer: ZxAISessionReviewArtifactTransferV1;
    readonly currentDocument: ZxTextEditorDocument;
    readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
    readonly runner: ZxAIComplexNodeBoundedRunnerV1;
    readonly resourceProfileFingerprint: string;
    readonly addressResolution?: ZxAIComplexNodeKernelInputV1["addressResolution"];
    readonly resourceAdmissions?: Readonly<Record<number, NonNullable<ZxAIComplexNodeKernelInputV1["resourceAdmission"]>>>;
    readonly proposalId: string;
    readonly variantId: string;
    readonly reviewId: string;
}) => Promise<{
    status: "failure";
    transfer: null;
} | {
    status: "success";
    transfer: ZxAISessionReviewArtifactTransferV1;
    proof: {
        sourceProposalFingerprint: string;
        sourcePlanDigest: string;
        currentDocumentRevision: string;
        successorProposalFingerprint: string;
        successorPlanDigest: string;
        successorRuntimeReceiptFingerprint: string;
        oldExecutableArtifactReused: false;
        fingerprint: string;
    };
}>;
/**
 * Final media admission lives at the target-dispatch seam, after fresh
 * proposal/review regeneration and immediately before the existing S7 fenced
 * commit callback. The host must issue a new commit-phase receipt; proposal
 * receipts, replayed nonces and current-base/asset drift fail before dispatch.
 */
export declare const dispatchComplexNodeCommitWithFreshResourceAdmissions: <T>(input: {
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly currentDocument: ZxTextEditorDocument;
    readonly currentDocumentRevision: string;
    readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
    readonly principalFingerprint: string;
    readonly policyFingerprint: string;
    readonly logicalTime: number;
    readonly port: ZxAIComplexNodeResourceAdmissionPortV1;
    readonly requestCommitReceipt: (request: ZxAIComplexNodeCommitResourceRequestV1) => Promise<ZxAIComplexNodeResourceReceiptV1>;
    /** Existing S7 global reservation/dispatch authority. */
    readonly dispatch: () => Promise<T>;
}) => Promise<ZxAIComplexNodeCommitDispatchResultV1<T>>;
//# sourceMappingURL=complex-node-fresh-lifecycle.d.ts.map