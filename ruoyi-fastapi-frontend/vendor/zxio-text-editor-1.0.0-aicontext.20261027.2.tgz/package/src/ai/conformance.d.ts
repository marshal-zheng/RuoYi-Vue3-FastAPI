import { ZxAICapabilityConformanceReport, ZxAIMarkCapability, ZxAINodeCapability, ZxAISemanticContractReport } from './contract';
import { ZxExtensionDescriptor } from '../core/extension-descriptors';
export declare const createAICapabilityConformanceReport: (descriptors?: readonly ZxExtensionDescriptor[]) => ZxAICapabilityConformanceReport;
export declare const assertAICapabilityConformance: (descriptors?: readonly ZxExtensionDescriptor[]) => ZxAICapabilityConformanceReport;
export declare const createAICapabilityCanonicalPayload: (descriptors?: readonly ZxExtensionDescriptor[]) => {
    name: string;
    attrs: string[];
    nodes: string[];
    marks: string[];
    ai: {
        nodes: {
            [k: string]: ZxAINodeCapability;
        };
        marks: {
            [k: string]: ZxAIMarkCapability;
        };
    };
}[];
export declare const createAIPlatformDescriptorParityReport: (descriptors: readonly ZxExtensionDescriptor[], platformDescriptors: readonly ZxExtensionDescriptor[]) => ZxAISemanticContractReport;
export declare const createAIEntryDependencyConformanceReport: (runtimeDependencies: readonly string[]) => ZxAISemanticContractReport;
//# sourceMappingURL=conformance.d.ts.map