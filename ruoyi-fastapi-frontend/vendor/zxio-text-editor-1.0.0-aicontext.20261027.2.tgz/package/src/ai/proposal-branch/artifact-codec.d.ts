import { ZxAIProposalArtifactReadResult, ZxAIProposalArtifactV1 } from './contract';
export declare const serializeAIProposalArtifact: (proposal: ZxAIProposalArtifactV1) => string;
export declare const readAIProposalArtifact: (input: unknown) => ZxAIProposalArtifactReadResult;
//# sourceMappingURL=artifact-codec.d.ts.map