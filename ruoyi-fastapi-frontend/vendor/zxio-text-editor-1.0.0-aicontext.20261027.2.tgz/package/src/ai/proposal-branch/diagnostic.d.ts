import { ZxAIProposalDiagnostic, ZxAIProposalDiagnosticCode, ZxAIProposalDiagnosticStage } from './contract';
export declare const createAIProposalDiagnostic: (input: {
    readonly code: ZxAIProposalDiagnosticCode;
    readonly stage: ZxAIProposalDiagnosticStage;
    readonly path: string;
    readonly count?: number;
    readonly fingerprint?: string;
    readonly operationRef?: string;
    readonly blockRef?: string;
    readonly hunkRef?: string;
}) => ZxAIProposalDiagnostic;
//# sourceMappingURL=diagnostic.d.ts.map