import { ZxAIPrepareProposalCommitRecipeOptions, ZxAIProposalRecipeResult, ZxAIProposalRegenerationResult, ZxAIValidateProposalRegenerationOptions } from './contract';
export declare const prepareAIProposalCommitRecipe: (options: ZxAIPrepareProposalCommitRecipeOptions) => ZxAIProposalRecipeResult;
export declare const validateAIProposalRegenerationEnvelope: (options: ZxAIValidateProposalRegenerationOptions) => ZxAIProposalRegenerationResult;
//# sourceMappingURL=commit-recipe.d.ts.map