import { RuntimeExecutionOutcomeV2 } from '../../core/deterministic-runtime';
import { ZxTextEditorDocument } from '../../document/types';
import { ZxAIMutationPlan } from '../contract';
import { ZxAIProposalDiagnostic, ZxAIProposalEffectProofV1, ZxAIProposalOperationProjectionV1 } from './contract';
export declare const createAIProposalTargetFingerprint: (document: ZxTextEditorDocument, operations: readonly ZxAIProposalOperationProjectionV1[]) => string;
export type EffectProofResult = {
    readonly valid: true;
    readonly proof: ZxAIProposalEffectProofV1;
} | {
    readonly valid: false;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export declare const createAIProposalEffectProof: (input: {
    readonly base: ZxTextEditorDocument;
    readonly plan: ZxAIMutationPlan;
    readonly runtime: Extract<RuntimeExecutionOutcomeV2, {
        status: "success";
    }>;
}) => EffectProofResult;
//# sourceMappingURL=effect-proof.d.ts.map