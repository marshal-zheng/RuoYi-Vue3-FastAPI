import { DerivedViewOutcomeV2, HistoricalRuntimeArtifactV2, RuntimeAdmissionExpectationV2, RuntimeComponentRefV2, RuntimeExecutionContextV2, RuntimeExecutionOutcomeV2, RuntimeHostAdmissionOutcomeV2, RuntimeManifestRefV2 } from '../../core/deterministic-runtime';
import { ZxTextEditorDocument } from '../../document/types';
import { ZxAIMutationPlan } from '../contract';
export declare const ZX_AI_PROPOSAL_CONTRACT_VERSION: "1.0.0";
export interface ZxAIProposalIdentity {
    readonly proposalId: string;
    readonly variantId: string;
    readonly parentVariantId?: string;
}
export interface ZxAIProposalProvenanceRef {
    readonly id: string;
    readonly type: 'entity' | 'activity' | 'agent' | 'plan';
}
export interface ZxAIProposalProvenance {
    readonly sourceId: string;
    readonly sequence: number;
    readonly timestamp?: string;
    readonly refs: readonly ZxAIProposalProvenanceRef[];
}
export interface ZxAIProposalLifecycleReceipt {
    readonly proposalId: string;
    readonly revision: number;
    readonly status: 'active' | 'committed' | 'discarded';
    readonly fingerprint: string;
}
export interface ZxAIProposalDiagnostic {
    readonly code: ZxAIProposalDiagnosticCode;
    readonly stage: ZxAIProposalDiagnosticStage;
    readonly path: string;
    readonly count?: number;
    readonly fingerprintPrefix?: string;
    readonly operationRef?: string;
    readonly blockRef?: string;
    readonly hunkRef?: string;
}
export type ZxAIProposalDiagnosticCode = 'proposal-input-invalid' | 'proposal-runtime-outcome-invalid' | 'proposal-runtime-binding-mismatch' | 'proposal-trace-invalid' | 'proposal-operation-projection-invalid' | 'proposal-artifact-invalid' | 'proposal-runtime-unsupported' | 'proposal-effect-proof-invalid' | 'proposal-document-drift' | 'proposal-lifecycle-invalid' | 'proposal-cache-invalid' | 'proposal-recipe-invalid' | 'block-move-unsupported';
export type ZxAIProposalDiagnosticStage = 'input' | 'runtime' | 'trace' | 'artifact' | 'effect-proof' | 'diff' | 'audit' | 'recipe' | 'lifecycle' | 'regeneration';
export interface ZxAIProposalOperationProjectionV1 {
    readonly operationIndex: number;
    readonly kind: ZxAIMutationPlan['steps'][number]['kind'];
    readonly blockIds: readonly string[];
    readonly stepStart: number;
    readonly stepEnd: number;
    readonly noOpReason?: 'already-equal';
    readonly intentDigest: string;
    readonly dependencyOperationIndexes: readonly number[];
}
export interface ZxAIProposalJournalV1 {
    readonly kind: 'zx-ai-proposal-journal-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly sourceBinding: {
        readonly executionSemanticsFingerprint: string;
        readonly resultFingerprint: string;
        readonly traceFingerprint: string;
    };
    readonly trace: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }>['trace'];
    readonly proposalIdentityFingerprint: string;
    readonly baseFingerprint: string;
    readonly planDigest: string;
    readonly lifecycleRevision: number;
    readonly fingerprint: string;
}
export interface ZxAIProposalEffectProofV1 {
    readonly kind: 'zx-ai-proposal-effect-proof-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly operationScopes: readonly {
        readonly operationIndex: number;
        readonly baseBlockIds: readonly string[];
        readonly resultBlockIds: readonly string[];
    }[];
    readonly traceAttribution: readonly {
        readonly sequence: number;
        readonly kind: 'root' | 'appended';
        readonly owner: 'operation-compiler' | 'certified-plugin';
        readonly pluginInstanceId: string | null;
        readonly operationIndexes: readonly number[];
        readonly visibleTransactionRange: readonly [number, number];
        readonly documentChanged: boolean;
        readonly attributedBlockIds: readonly string[];
        readonly safeEffectFingerprints: readonly string[];
    }[];
    readonly untouchedBlockFingerprints: readonly {
        readonly blockId: string;
        readonly fingerprint: string;
    }[];
    readonly untouchedAnnotationFingerprints: readonly {
        readonly annotationId: string;
        readonly fingerprint: string;
    }[];
    readonly untouchedProjectionFingerprint: string;
    readonly relativeOrderFingerprint: string;
    readonly annotationProjectionFingerprint: string;
    readonly assetsMetaUnchanged: true;
    readonly fingerprint: string;
}
export type ZxAIProposalDiffHunkKind = 'text' | 'mark' | 'node-type' | 'node-attrs' | 'block-insert' | 'block-delete' | 'block-replace' | 'complex-summary';
export interface ZxAIProposalDiffHunkV1 {
    readonly id: string;
    readonly operationIndex: number;
    readonly blockId: string;
    readonly kind: ZxAIProposalDiffHunkKind;
    readonly ordinal: number;
    readonly beforeFingerprint: string | null;
    readonly afterFingerprint: string | null;
    readonly summary: string;
    readonly fingerprint: string;
}
export interface ZxAIProposalRichDiffV1 {
    readonly kind: 'zx-ai-proposal-rich-diff-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly profileRef: RuntimeComponentRefV2;
    readonly sourceBinding: {
        readonly executionSemanticsFingerprint: string;
        readonly resultFingerprint: string;
        readonly traceFingerprint: string;
    };
    readonly hunks: readonly ZxAIProposalDiffHunkV1[];
    readonly operationToHunks: readonly {
        readonly operationIndex: number;
        readonly hunkIds: readonly string[];
    }[];
    readonly blockToHunks: readonly {
        readonly blockId: string;
        readonly hunkIds: readonly string[];
    }[];
    readonly fingerprint: string;
}
export interface ZxAIProposalArtifactDescriptorV1 {
    readonly kind: 'zx-ai-proposal-artifact-descriptor-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly envelopeRef: string;
    readonly codecRef: string;
    readonly effectProofRef: string;
    readonly richDiffProfileRef: RuntimeComponentRefV2;
    readonly semanticRecipeSchemaRef: string;
    readonly lifecycleSchemaRef: string;
    readonly runtimeManifestRef: RuntimeManifestRefV2;
    readonly runtimeTraceContractRef: string;
    readonly forbiddenAuthorities: readonly [
        'operation-compiler',
        'plugin-closure',
        'mapping-policy',
        'resource-ledger',
        'transaction-semantics'
    ];
    readonly fingerprint: string;
}
export interface ZxAIProposalArtifactV1 {
    readonly kind: 'zx-ai-proposal-artifact-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly identity: ZxAIProposalIdentity;
    readonly provenance: ZxAIProposalProvenance;
    readonly lifecycle: ZxAIProposalLifecycleReceipt & {
        readonly status: 'active';
    };
    readonly base: {
        readonly document: ZxTextEditorDocument;
        readonly fingerprint: string;
        readonly documentRevision: string;
        readonly annotationFingerprint: string;
        readonly targetFingerprint: string;
        readonly plan: ZxAIMutationPlan;
        readonly planDigest: string;
        readonly runtimeContext: RuntimeExecutionContextV2;
        readonly inputDigest: string;
    };
    readonly runtimeExecution: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }>;
    readonly operationProjection: readonly ZxAIProposalOperationProjectionV1[];
    readonly journal: ZxAIProposalJournalV1;
    readonly effectProof: ZxAIProposalEffectProofV1;
    readonly richDiff: DerivedViewOutcomeV2<ZxAIProposalRichDiffV1>;
    readonly descriptor: ZxAIProposalArtifactDescriptorV1;
    readonly fingerprint: string;
}
export interface ZxAIExecuteProposalOptions {
    readonly runtime: RuntimeManifestRefV2;
    readonly baseDocument: ZxTextEditorDocument;
    readonly plan: ZxAIMutationPlan;
    readonly identity: ZxAIProposalIdentity;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly provenance: ZxAIProposalProvenance;
    readonly runtimeContext: RuntimeExecutionContextV2;
}
export type ZxAIProposalExecutionResult = {
    readonly status: 'success';
    readonly runtimeOutcome: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }>;
    readonly proposal: ZxAIProposalArtifactV1;
} | {
    readonly status: 'runtime-failure';
    readonly runtimeOutcome: Extract<RuntimeExecutionOutcomeV2, {
        status: 'failure';
    }>;
    readonly proposal: null;
} | {
    readonly status: 'safety-abort';
    readonly runtimeOutcome: Extract<RuntimeExecutionOutcomeV2, {
        status: 'safety-abort';
    }>;
    readonly proposal: null;
} | {
    readonly status: 'proposal-failure';
    readonly runtimeOutcome: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }> | null;
    readonly proposal: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export type ZxAIProposalArtifactReadResult = {
    readonly status: 'success';
    readonly proposal: ZxAIProposalArtifactV1;
    readonly cacheStatus: 'exact' | 'rich-diff-rebuilt';
} | {
    readonly status: 'proposal-artifact-invalid';
    readonly proposal: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
} | {
    readonly status: 'proposal-runtime-unsupported';
    readonly proposal: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export interface ZxAIProposalHistoricalArtifactV1 {
    readonly kind: 'zx-ai-proposal-historical-artifact-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly proposalReaderRef: RuntimeComponentRefV2;
    readonly identity: ZxAIProposalIdentity;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly provenance: ZxAIProposalProvenance;
    readonly operationIntentDigests: readonly string[];
    readonly sourceProposalFingerprint: string;
    readonly baseDocumentFingerprint: string;
    readonly resultFingerprint: string;
    readonly runtimeArtifactFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAIProposalHistoricalEnvelopeV1 {
    readonly kind: 'zx-ai-proposal-historical-envelope-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly proposalReaderRef: RuntimeComponentRefV2;
    readonly proposalArtifact: ZxAIProposalHistoricalArtifactV1;
    readonly sourceProposal: ZxAIProposalArtifactV1;
    readonly runtimeArtifact: HistoricalRuntimeArtifactV2;
    readonly closureFingerprint: string;
}
export interface ZxAIAuditCurrentProposalOptions {
    readonly mode: 'exact-current';
    readonly proposal: ZxAIProposalArtifactV1;
}
export interface ZxAIAuditHistoricalProposalOptions {
    readonly mode: 'historical';
    readonly envelope: ZxAIProposalHistoricalEnvelopeV1;
}
export type ZxAIAuditProposalOptions = ZxAIAuditCurrentProposalOptions | ZxAIAuditHistoricalProposalOptions;
export type ZxAIProposalAuditResult = {
    readonly status: 'audit-success';
    readonly fingerprint: string;
} | {
    readonly status: 'deterministic-mismatch';
    readonly diagnostics: readonly ZxAIProposalDiagnostic[];
} | {
    readonly status: 'proposal-runtime-unsupported';
    readonly diagnostics: readonly ZxAIProposalDiagnostic[];
} | {
    readonly status: 'failure';
    readonly diagnostics: readonly ZxAIProposalDiagnostic[];
};
export interface ZxAIProposalSemanticRecipeV1 {
    readonly kind: 'zx-ai-proposal-semantic-recipe-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly proposalFingerprint: string;
    readonly baseFingerprint: string;
    readonly plan: ZxAIMutationPlan;
    readonly planDigest: string;
    readonly expectedResultFingerprint: string;
    readonly expectedTraceFingerprint: string;
    readonly expectedMappingFingerprint: string;
    readonly runtimeExpectation: RuntimeAdmissionExpectationV2;
    readonly hostAdmission: Extract<RuntimeHostAdmissionOutcomeV2, {
        status: 'exact-admissible' | 'admissible-observational-drift';
    }>;
    readonly lifecycleRevision: number;
    readonly annotationExpectationFingerprint: string;
    readonly operationIntentDigests: readonly string[];
    readonly dispatchHandoff: {
        readonly owner: 'S4-or-S7';
        readonly targetBoundRecheck: 'recheckCurrentTextEditorRuntimeHostForDispatchV2';
        readonly reexecution: 'executeTextEditorMutationPlanV2';
        readonly cachedAdmissionIsDispatchReceipt: false;
        readonly oldTraceExecutable: false;
    };
    readonly fingerprint: string;
}
export interface ZxAIPrepareProposalCommitRecipeOptions {
    readonly proposal: ZxAIProposalArtifactV1;
    readonly currentDocument: ZxTextEditorDocument;
    readonly currentLifecycle: ZxAIProposalLifecycleReceipt;
}
export type ZxAIProposalRecipeResult = {
    readonly status: 'success';
    readonly recipe: ZxAIProposalSemanticRecipeV1;
} | {
    readonly status: 'rebase-required' | 'regenerate-current-runtime' | 'unsupported-host' | 'discarded';
    readonly recipe: null;
    readonly hostAdmission?: RuntimeHostAdmissionOutcomeV2;
} | {
    readonly status: 'failure';
    readonly recipe: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export interface ZxAIProposalRegenerationDecisionV1 {
    readonly kind: 'regenerate-proposal';
    readonly operationIntentDigests: readonly string[];
}
export interface ZxAIValidateProposalRegenerationOptions {
    readonly proposal: ZxAIProposalArtifactV1;
    readonly decision: ZxAIProposalRegenerationDecisionV1;
    readonly latestBaseDocument: ZxTextEditorDocument;
    readonly nextIdentity: ZxAIProposalIdentity;
}
export type ZxAIProposalRegenerationResult = {
    readonly status: 'success';
    readonly plannerSeed: {
        readonly supersededProposalFingerprint: string;
        readonly latestBaseDocument: ZxTextEditorDocument;
        readonly nextIdentity: ZxAIProposalIdentity;
        readonly operationIntentDigests: readonly string[];
        readonly fingerprint: string;
    };
} | {
    readonly status: 'failure';
    readonly plannerSeed: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export interface ZxAIProposalDiscardIntent {
    readonly kind: 'zx-ai-proposal-discard-intent-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly proposalId: string;
    readonly expectedRevision: number;
    readonly expectedFingerprint: string;
    readonly candidateRevision: number;
    readonly fingerprint: string;
}
export interface ZxAICreateProposalDiscardIntentOptions {
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
}
export type ZxAIProposalDiscardIntentResult = {
    readonly status: 'success';
    readonly intent: ZxAIProposalDiscardIntent;
} | {
    readonly status: 'conflict' | 'failure';
    readonly intent: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export interface ZxAIProposalCommitIntent {
    readonly kind: 'zx-ai-proposal-commit-intent-v1';
    readonly version: typeof ZX_AI_PROPOSAL_CONTRACT_VERSION;
    readonly proposalId: string;
    readonly expectedRevision: number;
    readonly expectedFingerprint: string;
    readonly candidateRevision: number;
    readonly fingerprint: string;
}
export interface ZxAICreateProposalCommitIntentOptions {
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
}
export type ZxAIProposalCommitIntentResult = {
    readonly status: 'success';
    readonly intent: ZxAIProposalCommitIntent;
} | {
    readonly status: 'conflict' | 'failure';
    readonly intent: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export interface ZxAIFinalizeProposalCommitIntentOptions {
    readonly intent: ZxAIProposalCommitIntent;
}
export type ZxAIProposalCommitResult = {
    readonly status: 'committed';
    readonly lifecycle: ZxAIProposalLifecycleReceipt & {
        readonly status: 'committed';
    };
} | {
    readonly status: 'conflict' | 'failure';
    readonly lifecycle: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export type ZxAIReleaseProposalLifecycleIntentOptions = {
    readonly intent: ZxAIProposalCommitIntent;
} | {
    readonly intent: ZxAIProposalDiscardIntent;
};
export interface ZxAIFinalizeProposalDiscardIntentOptions {
    readonly intent: ZxAIProposalDiscardIntent;
}
export type ZxAIProposalDiscardResult = {
    readonly status: 'discarded';
    readonly lifecycle: ZxAIProposalLifecycleReceipt & {
        readonly status: 'discarded';
    };
} | {
    readonly status: 'conflict' | 'failure';
    readonly lifecycle: null;
    readonly diagnostic: ZxAIProposalDiagnostic;
};
export interface ZxAIProposalReferenceProvenanceV1 {
    readonly repository: 'BlockNote' | 'Plate' | 'Novel';
    readonly commit: string;
    readonly paths: readonly string[];
    readonly decisions: readonly {
        readonly decision: 'adapt' | 'reject';
        readonly boundary: string;
        readonly fixtureIds: readonly string[];
    }[];
}
//# sourceMappingURL=contract.d.ts.map