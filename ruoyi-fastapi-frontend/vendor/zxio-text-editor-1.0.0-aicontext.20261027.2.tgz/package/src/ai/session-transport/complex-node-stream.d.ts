import { reduceComplexNodeSessionStream, ZxAIComplexNodeStreamEventV1, ZxAIComplexNodeStreamStateV1 } from '../complex-node/stream';
import { ZxAIComplexNodeAdapterRefV1, ZxAIComplexNodeStreamPolicy } from '../complex-node/contract';
export interface ZxAISessionComplexNodeStreamStateV1 {
    readonly kind: 'zx-ai-session-complex-node-stream-v1';
    readonly requestId: string;
    readonly attemptId: string;
    readonly stream: ZxAIComplexNodeStreamStateV1;
    readonly fingerprint: string;
}
/** S5-owned complex stream state; S8 supplies only the typed partial reducer. */
export declare const createAISessionComplexNodeStream: (input: {
    readonly requestId: string;
    readonly attemptId: string;
    readonly adapter: ZxAIComplexNodeAdapterRefV1;
    readonly operation: string;
    readonly policy: ZxAIComplexNodeStreamPolicy;
}) => ZxAISessionComplexNodeStreamStateV1;
export declare const reduceAISessionComplexNodeStream: (state: ZxAISessionComplexNodeStreamStateV1, event: ZxAIComplexNodeStreamEventV1, options: Parameters<typeof reduceComplexNodeSessionStream>[2]) => ZxAISessionComplexNodeStreamStateV1;
export declare const projectAISessionComplexNodeTransientPreview: (state: ZxAISessionComplexNodeStreamStateV1) => {
    readonly kind: "complex-node-transient-preview-v1";
    readonly executable: false;
    readonly durable: false;
    readonly adapterFingerprint: string;
    readonly operation: string;
    readonly byteLength: number;
    readonly status: "receiving" | "complete-candidate";
    readonly fingerprint: string;
} | null;
export declare const readAISessionComplexNodeCompletePayload: (state: ZxAISessionComplexNodeStreamStateV1) => Uint8Array | null;
//# sourceMappingURL=complex-node-stream.d.ts.map