import { ZxAIProposalArtifactV1, ZxAIProposalLifecycleReceipt } from '../proposal-branch';
import { ZxAIReviewSidecarV1 } from '../review-runtime';
export declare const ZX_AI_SESSION_CONTRACT_VERSION: "1.0.0";
export type ZxAISessionContractVersion = typeof ZX_AI_SESSION_CONTRACT_VERSION;
export interface ZxAISessionPolicyLimitsV1 {
    readonly maxBytes: number;
    readonly maxDepth: number;
    readonly maxArrayEntries: number;
    readonly maxObjectKeys: number;
    readonly maxTotalObjectKeys: number;
    readonly maxRequests: number;
    readonly maxAttempts: number;
    readonly maxEventsPerAttempt: number;
    readonly maxChunkBytes: number;
    readonly maxProjectionTextBytes: number;
    readonly maxProjectionSegments: number;
    readonly maxToolSummaries: number;
    readonly maxAuditEntries: number;
    readonly maxCheckpointBytes: number;
    readonly maxDiagnostics: number;
    readonly maxRetries: number;
    readonly maxHandoffs: number;
    readonly maxIdLength: number;
    readonly maxDiagnosticPathLength: number;
    readonly maxLogicalDuration: number;
}
export interface ZxAISessionPolicyV1 {
    readonly id: 'zx.ai.session-policy';
    readonly version: ZxAISessionContractVersion;
    readonly limits: ZxAISessionPolicyLimitsV1;
    readonly retryableTerminalReasons: readonly ZxAISessionRetryableTerminalReasonV1[];
    readonly resumeCapability: 'resume:same-attempt-checkpoint-v1';
    readonly oneActiveRequest: true;
}
export type ZxAISessionRetryableTerminalReasonV1 = 'transport-failed' | 'transport-disconnected' | 'resource-exceeded' | 'malformed';
export interface ZxAISessionPolicyRefV1 {
    readonly id: 'zx.ai.session-policy';
    readonly version: ZxAISessionContractVersion;
    readonly fingerprint: string;
}
export type ZxAISessionStatusV1 = 'open' | 'closing' | 'closed' | 'corrupt' | 'unsupported';
export type ZxAISessionRequestStatusV1 = 'prepared' | 'active' | 'awaiting-review' | 'succeeded' | 'failed' | 'aborted' | 'superseded';
export type ZxAISessionAttemptStatusV1 = 'created' | 'starting' | 'streaming' | 'abort-requested' | 'suspended' | 'succeeded' | 'failed' | 'aborted' | 'superseded';
export type ZxAISessionRequestKindV1 = 'selection' | 'cursor' | 'block' | 'long-running' | 'improve' | 'fix' | 'shorter' | 'longer' | 'continue' | 'follow-up';
export interface ZxAISessionIdentityV1 {
    readonly sessionId: string;
}
export interface ZxAISessionSnapshotRefV1 {
    readonly kind: 'semantic-snapshot' | 'scope' | 'base-document' | 'intent';
    readonly fingerprint: string;
    readonly revision?: string;
}
export interface ZxAISessionRequestInputV1 {
    readonly kind: ZxAISessionRequestKindV1;
    readonly semanticSnapshotRef: ZxAISessionSnapshotRefV1;
    readonly scopeRef: ZxAISessionSnapshotRefV1;
    readonly baseDocumentRef: ZxAISessionSnapshotRefV1;
    readonly intentRef: ZxAISessionSnapshotRefV1;
    readonly presentationContextFingerprint?: string;
}
export interface ZxAISessionRequestLineageV1 {
    readonly restartedFromRequestId?: string;
    readonly supersededRequestId?: string;
}
export interface ZxAISessionRequestV1 {
    readonly requestId: string;
    readonly sessionId: string;
    readonly lineage: ZxAISessionRequestLineageV1;
    readonly input: ZxAISessionRequestInputV1;
    readonly inputFingerprint: string;
    readonly policyFingerprint: string;
    readonly logicalCreatedAt: number;
    readonly status: ZxAISessionRequestStatusV1;
    readonly activeAttemptId?: string;
    readonly publishedHandoffFingerprint?: string;
}
export interface ZxAITransportDescriptorRefV1 {
    readonly transportId: string;
    readonly version: ZxAISessionContractVersion;
    readonly capabilityFingerprint: string;
}
export interface ZxAISessionAbortIntentV1 {
    readonly intentId: string;
    readonly revision: number;
    readonly logicalRequestedAt: number;
    readonly effectId: string;
    readonly fingerprint: string;
}
export type ZxAISessionAttemptTerminalReasonV1 = 'succeeded' | 'transport-failed' | 'transport-disconnected' | 'aborted' | 'abort-unsupported' | 'resource-exceeded' | 'malformed' | 'superseded' | 'handoff-failure' | 'safety-abort' | 'timeout';
export interface ZxAISessionAttemptTerminalV1 {
    readonly reason: ZxAISessionAttemptTerminalReasonV1;
    readonly resultKind?: ZxAISessionSealedResultKindV1;
    readonly sealedResultFingerprint?: string;
    readonly diagnosticCode?: ZxAISessionDiagnosticCode;
    /** Present only on terminals produced by an `attempt-failed` event. */
    readonly failureClass?: ZxAIAttemptFailureClassV1;
    readonly fingerprint: string;
}
export interface ZxAISessionAttemptV1 {
    readonly attemptId: string;
    readonly requestId: string;
    readonly predecessorAttemptId?: string;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
    readonly status: ZxAISessionAttemptStatusV1;
    readonly expectedSequence: number;
    readonly sequenceOrigin: 0;
    readonly acceptedTextBytes: number;
    readonly acceptedToolSummaryCount: number;
    readonly lastEventFingerprint?: string;
    readonly checkpointFingerprint?: string;
    readonly abortIntent?: ZxAISessionAbortIntentV1;
    readonly terminal?: ZxAISessionAttemptTerminalV1;
    readonly retryCount: number;
}
export type ZxAISessionSealedResultKindV1 = 'message-only' | 'operation-envelope' | 'no-change';
export interface ZxAISessionSealedResultV1 {
    readonly kind: ZxAISessionSealedResultKindV1;
    readonly contentDigest: string;
    readonly resourceTotals: {
        readonly eventCount: number;
        readonly textBytes: number;
        readonly toolSummaryCount: number;
    };
    readonly operationEnvelope?: unknown;
    readonly messageDigest?: string;
    readonly fingerprint: string;
}
export interface ZxAISessionProjectionSegmentV1 {
    readonly ordinal: number;
    readonly text: string;
    readonly byteLength: number;
}
export interface ZxAISessionToolSummaryV1 {
    readonly toolKind: string;
    readonly status: 'started' | 'completed' | 'failed';
    readonly digest: string;
    readonly count: number;
}
export interface ZxAISessionProjectionV1 {
    readonly requestId: string | null;
    readonly attemptId: string | null;
    readonly requestStatus: ZxAISessionRequestStatusV1 | 'idle';
    readonly attemptStatus: ZxAISessionAttemptStatusV1 | 'idle';
    readonly assistantSegments: readonly ZxAISessionProjectionSegmentV1[];
    readonly assistantTextBytes: number;
    readonly truncated: boolean;
    readonly progress: {
        readonly stage: string;
        readonly code: string;
        readonly count: number;
    } | null;
    readonly toolSummaries: readonly ZxAISessionToolSummaryV1[];
    readonly capabilities: {
        readonly canAbort: boolean;
        readonly canRetry: boolean;
        readonly canResume: boolean;
        readonly canSupersede: boolean;
    };
    readonly lastDiagnostic: ZxAISessionDiagnosticV1 | null;
    readonly diagnostics: readonly ZxAISessionDiagnosticV1[];
    readonly proposalRef: string | null;
    readonly reviewRef: string | null;
    readonly fingerprint: string;
}
export interface ZxAISessionHandoffReceiptV1 {
    readonly kind: 'zx-ai-session-handoff-receipt-v1';
    readonly version: ZxAISessionContractVersion;
    readonly handoffId: string;
    readonly effectId: string;
    readonly sourceRevision: number;
    readonly sourceSessionFingerprint: string;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly resultKind: ZxAISessionSealedResultKindV1;
    readonly sealedResultFingerprint: string;
    readonly proposalId?: string;
    readonly proposalFingerprint?: string;
    readonly reviewId?: string;
    readonly reviewFingerprint?: string;
    readonly lifecycleFingerprint?: string;
    readonly outcome: ZxAISessionHandoffOutcomeStatusV1;
    readonly fingerprint: string;
}
export type ZxAISessionHandoffBindingV1 = ZxAISessionHandoffReceiptV1;
export type ZxAISessionHandoffOutcomeStatusV1 = 'message-only' | 'no-change' | 'awaiting-review' | 'handoff-failure';
export interface ZxAISessionReviewArtifactTransferV1 {
    readonly kind: 'zx-ai-session-review-artifact-transfer-v1';
    readonly version: ZxAISessionContractVersion;
    readonly receipt: ZxAISessionHandoffReceiptV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly fingerprint: string;
}
export type ZxAISessionReviewArtifactTransferReadResultV1 = {
    readonly status: 'success';
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
} | {
    readonly status: 'failure';
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
export type ZxAISessionHandoffOutcomeV1 = {
    readonly status: 'message-only' | 'no-change';
    readonly receipt?: never;
    readonly transfer?: never;
    readonly diagnostic?: never;
} | {
    readonly status: 'awaiting-review';
    readonly receipt: ZxAISessionHandoffReceiptV1;
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly diagnostic?: never;
} | {
    readonly status: 'handoff-failure';
    readonly diagnostic: ZxAISessionDiagnosticV1;
    readonly receipt?: never;
    readonly transfer?: never;
};
export interface ZxAISessionAuditHeadV1 {
    readonly sequence: number;
    readonly fingerprint: string | null;
}
export interface ZxAISessionAuditEntryV1 {
    readonly sequence: number;
    readonly kind: 'session-created' | 'command-accepted' | 'command-idempotent' | 'event-accepted' | 'event-idempotent' | 'late-event' | 'effect-published' | 'handoff-published' | 'checkpoint' | 'compaction' | 'session-closed';
    readonly commandKind?: string;
    readonly eventKind?: string;
    readonly eventSequence?: number;
    readonly requestId?: string;
    readonly attemptId?: string;
    readonly effectId?: string;
    readonly previousFingerprint: string | null;
    readonly refs: readonly {
        readonly id: string;
        readonly type: string;
    }[];
    readonly compaction?: {
        readonly priorHead: ZxAISessionAuditHeadV1;
        readonly droppedStartSequence: number;
        readonly droppedEndSequence: number;
        readonly droppedCount: number;
        readonly leftBoundaryFingerprint: string;
        readonly rightBoundaryFingerprint: string;
        readonly preservedTerminalRoots: readonly string[];
        readonly preservedHandoffRoots: readonly string[];
        readonly preservedLateEventProofs: readonly {
            readonly attemptId: string;
            readonly sequence: number;
            readonly fingerprint: string;
        }[];
    };
    readonly fingerprint: string;
}
export interface ZxAISessionArtifactV1 {
    readonly kind: 'zx-ai-session-artifact-v1';
    readonly version: ZxAISessionContractVersion;
    readonly identity: ZxAISessionIdentityV1;
    readonly revision: number;
    readonly policyRef: ZxAISessionPolicyRefV1;
    readonly status: ZxAISessionStatusV1;
    readonly activeRequestId?: string;
    readonly requests: readonly ZxAISessionRequestV1[];
    readonly attempts: readonly ZxAISessionAttemptV1[];
    readonly projection: ZxAISessionProjectionV1;
    readonly handoffs: readonly ZxAISessionHandoffBindingV1[];
    readonly sealedResult?: ZxAISessionSealedResultV1;
    readonly auditHead: ZxAISessionAuditHeadV1;
    readonly auditEntries: readonly ZxAISessionAuditEntryV1[];
    readonly recentEventProofs: readonly {
        readonly attemptId: string;
        readonly sequence: number;
        readonly fingerprint: string;
    }[];
    readonly fingerprint: string;
}
export type ZxAISessionDiagnosticStage = 'contract' | 'identity' | 'command' | 'event' | 'projection' | 'transport-admission' | 'checkpoint' | 'replay' | 'handoff' | 'historical';
export type ZxAISessionDiagnosticCode = 'session-input-invalid' | 'session-identity-invalid' | 'session-lineage-invalid' | 'session-revision-conflict' | 'session-busy' | 'session-terminal' | 'session-unsupported' | 'session-malformed' | 'session-resource-exceeded' | 'session-event-gap' | 'session-event-duplicate-conflict' | 'session-event-out-of-order' | 'session-event-after-terminal' | 'session-abort-race' | 'session-retry-ineligible' | 'session-resume-conflict' | 'session-handoff-failure' | 'session-safety-abort' | 'session-historical-unsupported' | 'session-transport-unsupported' | 'session-transport-failure' | 'session-checkpoint-invalid' | 'session-replay-invalid';
export interface ZxAISessionDiagnosticV1 {
    readonly code: ZxAISessionDiagnosticCode;
    readonly stage: ZxAISessionDiagnosticStage;
    readonly path: string;
    readonly count?: number;
    readonly fingerprintPrefix?: string;
    readonly sessionRef?: string;
    readonly requestRef?: string;
    readonly attemptRef?: string;
    readonly capability?: string;
    readonly terminalReason?: string;
}
export type ZxAISessionClosedStatusV1 = 'success' | 'accepted' | 'idempotent' | 'conflict' | 'busy' | 'unsupported' | 'malformed' | 'resource-exceeded' | 'disconnected' | 'aborted' | 'superseded' | 'retry-required' | 'resume-required' | 'handoff-failure' | 'safety-abort' | 'failure';
export type ZxAITransportEventKindV1 = 'attempt-started' | 'assistant-delta' | 'progress' | 'tool-summary' | 'checkpoint' | 'abort-acknowledged' | 'attempt-succeeded' | 'attempt-failed' | 'transport-disconnected';
export type ZxAITransportAttemptFailureReasonV1 = 'transport-failed' | 'transport-disconnected' | 'resource-exceeded' | 'malformed' | 'safety-abort';
export type ZxAITransportDiagnosticCodeV1 = 'session-transport-failure' | 'session-resource-exceeded' | 'session-malformed' | 'session-safety-abort';
/**
 * Provider-neutral cause of a failed attempt. Adapters map vendor facts to a
 * class; the class shapes offered actions and copy but never grants retry.
 */
export type ZxAIAttemptFailureClassV1 = 'network' | 'provider-unavailable' | 'rate-limited' | 'auth-failed' | 'quota-exceeded' | 'request-rejected' | 'context-overflow' | 'output-truncated' | 'content-filtered' | 'empty-output' | 'protocol' | 'internal';
export type ZxAITransportEventPayloadV1 = {
    readonly kind: 'attempt-started';
    readonly transportAdmissionFingerprint: string;
    readonly transportExecutionReceiptRef: string;
} | {
    readonly kind: 'assistant-delta';
    readonly text: string;
    readonly encoding: 'utf-8-delta';
} | {
    readonly kind: 'progress';
    readonly stage: string;
    readonly code: string;
    readonly count: number;
} | {
    readonly kind: 'tool-summary';
    readonly toolKind: string;
    readonly status: 'started' | 'completed' | 'failed';
    readonly digest: string;
    readonly count: number;
} | {
    readonly kind: 'checkpoint';
    readonly checkpointRef: string;
    readonly checkpointDigest: string;
} | {
    readonly kind: 'abort-acknowledged';
    readonly abortIntentId: string;
    readonly effectId: string;
    readonly transportAdmissionFingerprint: string;
    readonly receiptKind: 'acknowledged' | 'unsupported' | 'failed';
} | {
    readonly kind: 'attempt-succeeded';
    readonly result: Omit<ZxAISessionSealedResultV1, 'fingerprint'> & {
        readonly fingerprint?: string;
    };
} | {
    readonly kind: 'attempt-failed';
    readonly reason: ZxAITransportAttemptFailureReasonV1;
    readonly diagnosticCode: ZxAITransportDiagnosticCodeV1;
    readonly failureClass: ZxAIAttemptFailureClassV1;
} | {
    readonly kind: 'transport-disconnected';
    readonly reason: 'disconnected';
    readonly checkpointDigest?: string;
} | {
    readonly kind: 'transport-disconnected';
    readonly reason: 'timeout';
    readonly logicalTime: number;
    readonly checkpointDigest?: string;
};
export interface ZxAITransportEventEnvelopeV1 {
    readonly version: ZxAISessionContractVersion;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly sequence: number;
    readonly kind: ZxAITransportEventKindV1;
    readonly previousEventFingerprint?: string;
    readonly payload: ZxAITransportEventPayloadV1;
    readonly payloadFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAISessionCommandKindV1 = 'create-request' | 'start-attempt' | 'accept-event' | 'request-abort' | 'acknowledge-abort' | 'retry' | 'resume' | 'restart' | 'supersede' | 'publish-handoff' | 'close-session';
export interface ZxAISessionCommandBindingV1 {
    readonly sessionId: string;
    readonly expectedRevision: number;
    readonly expectedSessionFingerprint: string;
    readonly logicalTime?: number;
}
export type ZxAISessionCommandV1 = (ZxAISessionCommandBindingV1 & {
    readonly kind: 'create-request';
    readonly requestId: string;
    readonly input: ZxAISessionRequestInputV1;
    readonly logicalCreatedAt: number;
    readonly restartedFromRequestId?: string;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'start-attempt';
    readonly requestId: string;
    readonly attemptId: string;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'accept-event';
    readonly event: ZxAITransportEventEnvelopeV1;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'request-abort';
    readonly requestId: string;
    readonly attemptId: string;
    readonly intentId: string;
    readonly logicalRequestedAt: number;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'acknowledge-abort';
    readonly requestId: string;
    readonly attemptId: string;
    readonly event: ZxAITransportEventEnvelopeV1;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'retry';
    readonly requestId: string;
    readonly attemptId: string;
    readonly predecessorAttemptId: string;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'resume';
    readonly requestId: string;
    readonly attemptId: string;
    readonly checkpointFingerprint: string;
    readonly expectedSequence: number;
    readonly expectedEventFingerprint: string;
    readonly expectedAuditHead: string | null;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'restart';
    readonly requestId: string;
    readonly input: ZxAISessionRequestInputV1;
    readonly logicalCreatedAt: number;
    readonly restartedFromRequestId: string;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'supersede';
    readonly requestId: string;
    readonly input: ZxAISessionRequestInputV1;
    readonly logicalCreatedAt: number;
    readonly supersededRequestId: string;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'publish-handoff';
    readonly requestId: string;
    readonly attemptId: string;
    readonly receipt: ZxAISessionHandoffReceiptV1;
}) | (ZxAISessionCommandBindingV1 & {
    readonly kind: 'close-session';
    readonly force?: boolean;
});
export type ZxAISessionEffectKindV1 = 'transport-start' | 'transport-abort' | 'transport-resume' | 'proposal-handoff';
export interface ZxAISessionEffectBaseV1 {
    readonly effectId: string;
    readonly kind: ZxAISessionEffectKindV1;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly sourceRevision: number;
    readonly sourceFingerprint: string;
    readonly idempotencyKey: string;
}
export type ZxAISessionEffectV1 = (ZxAISessionEffectBaseV1 & {
    readonly kind: 'transport-start';
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
    readonly requestProjection: {
        readonly inputFingerprint: string;
        readonly kind: ZxAISessionRequestKindV1;
        readonly policyFingerprint: string;
    };
}) | (ZxAISessionEffectBaseV1 & {
    readonly kind: 'transport-abort';
    readonly abortIntentId: string;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}) | (ZxAISessionEffectBaseV1 & {
    readonly kind: 'transport-resume';
    readonly checkpointFingerprint: string;
    readonly expectedSequence: number;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}) | (ZxAISessionEffectBaseV1 & {
    readonly kind: 'proposal-handoff';
    readonly sealedResultFingerprint: string;
    readonly resultKind: ZxAISessionSealedResultKindV1;
});
export interface ZxAISessionCommandReceiptV1 {
    readonly commandKind: ZxAISessionCommandKindV1;
    readonly status: ZxAISessionClosedStatusV1;
    readonly sessionId: string;
    readonly revision: number;
    readonly sessionFingerprint: string;
    readonly requestId?: string;
    readonly attemptId?: string;
    readonly effectIds: readonly string[];
    readonly fingerprint: string;
}
export type ZxAISessionReduceResultV1 = {
    readonly status: 'accepted';
    readonly session: ZxAISessionArtifactV1;
    readonly receipt: ZxAISessionCommandReceiptV1;
    readonly effects: readonly ZxAISessionEffectV1[];
} | {
    readonly status: 'idempotent';
    readonly session: ZxAISessionArtifactV1;
    readonly receipt: ZxAISessionCommandReceiptV1;
} | {
    readonly status: 'conflict' | 'unsupported' | 'failure' | 'busy';
    readonly session: ZxAISessionArtifactV1;
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
export type ZxAISessionRuntimeReduceResultV1 = ZxAISessionReduceResultV1 | {
    readonly status: 'failure';
    readonly session: null;
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
export interface ZxAITransportCapabilityV1 {
    readonly start: true;
    readonly abort: boolean;
    readonly resume: false | 'resume:same-attempt-checkpoint-v1';
    readonly requestKinds: readonly ZxAISessionRequestKindV1[];
}
export interface ZxAITransportDescriptorV1 {
    readonly transportId: string;
    readonly version: ZxAISessionContractVersion;
    readonly capabilities: ZxAITransportCapabilityV1;
    readonly policyFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAITransportCapabilityReceiptV1 {
    readonly kind: 'zx-ai-transport-admission-receipt-v1';
    readonly sessionId: string;
    readonly sourceRevision: number;
    readonly sourceSessionFingerprint: string;
    readonly requestId: string;
    readonly requestKind: ZxAISessionRequestKindV1;
    readonly requestInputFingerprint: string;
    readonly policyFingerprint: string;
    readonly transportId: string;
    readonly version: ZxAISessionContractVersion;
    readonly descriptorFingerprint: string;
    readonly capabilities: ZxAITransportCapabilityV1;
    readonly fingerprint: string;
}
export type ZxAITransportAdmissionReceiptV1 = ZxAITransportCapabilityReceiptV1;
export type ZxAITransportAbortPortOutcomeV1 = {
    readonly status: 'accepted';
    readonly receiptKind: 'acknowledged';
    readonly abortIntentId: string;
    readonly effectId: string;
    readonly transportAdmissionFingerprint: string;
} | {
    readonly status: 'unsupported';
    readonly abortIntentId: string;
    readonly effectId: string;
    readonly transportAdmissionFingerprint: string;
} | {
    readonly status: 'failed';
    readonly abortIntentId: string;
    readonly effectId: string;
    readonly transportAdmissionFingerprint: string;
    readonly code: string;
};
export interface ZxAITransportStartEffectV1 {
    readonly effectId: string;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly requestProjection: {
        readonly inputFingerprint: string;
        readonly kind: ZxAISessionRequestKindV1;
        readonly policyFingerprint: string;
    };
    readonly policyFingerprint: string;
    readonly correlationRef: string;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}
export interface ZxAITransportAbortEffectV1 {
    readonly effectId: string;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly abortIntentId: string;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}
export interface ZxAITransportResumeEffectV1 {
    readonly effectId: string;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly checkpointFingerprint: string;
    readonly expectedSequence: number;
    readonly transportAdmission: ZxAITransportAdmissionReceiptV1;
}
export interface ZxAITransportPortV1 {
    readonly descriptor: ZxAITransportDescriptorV1;
    start(effect: ZxAITransportStartEffectV1): AsyncIterable<ZxAITransportEventEnvelopeV1>;
    abort(effect: ZxAITransportAbortEffectV1): Promise<ZxAITransportAbortPortOutcomeV1>;
    resume?(effect: ZxAITransportResumeEffectV1): AsyncIterable<ZxAITransportEventEnvelopeV1>;
}
export interface ZxAISessionCheckpointV1 {
    readonly kind: 'zx-ai-session-checkpoint-v1';
    readonly version: ZxAISessionContractVersion;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly revision: number;
    readonly sessionFingerprint: string;
    readonly lastSequence: number;
    readonly lastEventFingerprint: string | null;
    readonly projectionFingerprint: string;
    readonly policyFingerprint: string;
    readonly capabilityFingerprint: string;
    readonly auditHead: ZxAISessionAuditHeadV1;
    readonly fingerprint: string;
}
export interface ZxAISessionHistoricalEnvelopeV1 {
    readonly kind: 'zx-ai-session-historical-envelope-v1';
    readonly reader: 'zx-ai-session-historical-reader-v1';
    readonly version: ZxAISessionContractVersion;
    readonly artifact: ZxAISessionArtifactV1;
    readonly mode: 'audit-only';
    readonly fingerprint: string;
}
export interface ZxAISessionReferenceProvenanceV1 {
    readonly repository: 'BlockNote' | 'Plate' | 'Novel';
    readonly commit: string;
    readonly paths: readonly string[];
    readonly decisions: readonly {
        readonly decision: 'copy' | 'adapt' | 'reject';
        readonly boundary: string;
        readonly fixtureIds: readonly string[];
    }[];
}
export type ZxAIFakeTransportStepV1 = {
    readonly kind: 'emit';
    readonly event: ZxAITransportEventEnvelopeV1;
} | {
    readonly kind: 'wait-for-effect';
    readonly effectKind: string;
} | {
    readonly kind: 'reject-port-call';
    readonly code: string;
} | {
    readonly kind: 'complete';
};
export interface ZxAICreateSessionOptionsV1 {
    readonly sessionId: string;
    readonly policyRef?: ZxAISessionPolicyRefV1;
    readonly logicalCreatedAt?: number;
}
export interface ZxAISessionArtifactReadResultV1 {
    readonly status: 'success' | 'failure' | 'unsupported';
    readonly session: ZxAISessionArtifactV1 | null;
    readonly diagnostic: ZxAISessionDiagnosticV1 | null;
}
export interface ZxAISessionCheckpointReadResultV1 {
    readonly status: 'success' | 'failure' | 'unsupported';
    readonly checkpoint: ZxAISessionCheckpointV1 | null;
    readonly diagnostic: ZxAISessionDiagnosticV1 | null;
}
export interface ZxAISessionReplayOptionsV1 {
    readonly checkpoint: ZxAISessionCheckpointV1;
    readonly session: ZxAISessionArtifactV1;
    readonly events: readonly ZxAITransportEventEnvelopeV1[];
}
export interface ZxAISessionReplayResultV1 {
    readonly status: 'success' | 'failure';
    readonly session: ZxAISessionArtifactV1 | null;
    readonly diagnostic: ZxAISessionDiagnosticV1 | null;
}
export interface ZxAISessionAuditOptionsV1 {
    readonly session: ZxAISessionArtifactV1;
    readonly mode?: 'current' | 'historical';
}
export interface ZxAISessionAuditResultV1 {
    readonly status: 'success' | 'unsupported' | 'failure';
    readonly entries: readonly ZxAISessionAuditEntryV1[];
    readonly head: ZxAISessionAuditHeadV1;
    readonly diagnostic: ZxAISessionDiagnosticV1 | null;
}
//# sourceMappingURL=contract.d.ts.map