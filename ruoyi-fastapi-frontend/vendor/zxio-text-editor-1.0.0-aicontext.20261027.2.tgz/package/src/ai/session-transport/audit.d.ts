import { ZxAISessionArtifactV1, ZxAISessionAuditEntryV1, ZxAISessionAuditHeadV1, ZxAISessionAuditOptionsV1, ZxAISessionAuditResultV1, ZxAISessionDiagnosticV1 } from './contract';
export type ZxAIAppendAuditResultV1 = {
    readonly ok: true;
    readonly head: ZxAISessionAuditHeadV1;
    readonly entries: readonly ZxAISessionAuditEntryV1[];
    readonly compacted: boolean;
} | {
    readonly ok: false;
    readonly diagnostic: ZxAISessionDiagnosticV1;
    readonly head: ZxAISessionAuditHeadV1;
    readonly entries: readonly ZxAISessionAuditEntryV1[];
};
export declare const appendAudit: (session: Pick<ZxAISessionArtifactV1, "auditEntries" | "auditHead">, input: {
    readonly kind: ZxAISessionAuditEntryV1["kind"];
    readonly commandKind?: string;
    readonly eventKind?: string;
    readonly eventSequence?: number;
    readonly requestId?: string;
    readonly attemptId?: string;
    readonly effectId?: string;
    readonly refs: readonly {
        readonly id: string;
        readonly type: string;
    }[];
}) => ZxAIAppendAuditResultV1;
/**
 * Host persistence integration contract (codec-only; no storage dependency).
 * Hosts must CAS on session.fingerprint / checkpoint.fingerprint and never
 * auto-upgrade historical artifacts into live resume.
 */
export declare const AI_SESSION_HOST_PERSISTENCE_CONTRACT_V1: {
    id: string;
    storageOwner: string;
    codecOnly: boolean;
    casFields: readonly ["fingerprint", "revision", "auditHead.fingerprint"];
    forbidAutoUpgrade: boolean;
    forbidLiveResumeFromHistorical: boolean;
    historicalMode: "audit-only";
};
export declare const auditAISession: (options: ZxAISessionAuditOptionsV1) => ZxAISessionAuditResultV1;
//# sourceMappingURL=audit.d.ts.map