import { ZxAISessionArtifactV1, ZxAISessionCheckpointReadResultV1, ZxAISessionCheckpointV1, ZxAISessionReplayOptionsV1, ZxAISessionReplayResultV1 } from './contract';
export declare const createAISessionCheckpoint: (options: {
    readonly session: ZxAISessionArtifactV1;
    readonly requestId: string;
    readonly attemptId: string;
}) => ZxAISessionCheckpointV1 | null;
export declare const readAISessionCheckpoint: (input: unknown) => ZxAISessionCheckpointReadResultV1;
export declare const replayAISession: (options: ZxAISessionReplayOptionsV1) => ZxAISessionReplayResultV1;
//# sourceMappingURL=checkpoint.d.ts.map