import { ZxAISessionArtifactV1, ZxAISessionAttemptV1, ZxAISessionDiagnosticV1, ZxAISessionProjectionV1, ZxAISessionRequestInputV1, ZxAISessionRequestV1, ZxAITransportDescriptorRefV1 } from './contract';
export declare const emptySessionProjection: (overrides?: Partial<ZxAISessionProjectionV1>) => ZxAISessionProjectionV1;
export declare const computeSessionArtifactFingerprint: (artifact: Omit<ZxAISessionArtifactV1, "fingerprint">) => string;
export declare const publishSessionArtifact: (artifact: Omit<ZxAISessionArtifactV1, "fingerprint">) => ZxAISessionArtifactV1;
export declare const computeRequestInputFingerprint: (input: ZxAISessionRequestInputV1) => string;
export declare const validateRequestInput: (input: unknown) => {
    readonly ok: true;
    readonly value: ZxAISessionRequestInputV1;
} | {
    readonly ok: false;
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
export declare const validateTransportRef: (value: unknown) => value is ZxAITransportDescriptorRefV1;
export declare const findRequest: (session: ZxAISessionArtifactV1, requestId: string) => ZxAISessionRequestV1 | undefined;
export declare const findAttempt: (session: ZxAISessionArtifactV1, attemptId: string) => ZxAISessionAttemptV1 | undefined;
export declare const activeAttemptFor: (session: ZxAISessionArtifactV1, requestId: string) => ZxAISessionAttemptV1 | undefined;
export declare const verifySessionLineage: (session: ZxAISessionArtifactV1) => ZxAISessionDiagnosticV1 | null;
export declare const isTerminalAttemptStatus: (status: ZxAISessionAttemptV1["status"]) => boolean;
export declare const isTerminalRequestStatus: (status: ZxAISessionRequestV1["status"]) => boolean;
export declare const isActiveAttemptStatus: (status: ZxAISessionAttemptV1["status"]) => boolean;
//# sourceMappingURL=identity.d.ts.map