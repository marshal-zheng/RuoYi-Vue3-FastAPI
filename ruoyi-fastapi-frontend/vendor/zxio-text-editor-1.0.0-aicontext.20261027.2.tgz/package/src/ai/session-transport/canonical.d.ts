import { deepFreeze } from '../../core/canonical-json';
import { fingerprintPrefix } from '../../core/execution-abi/fingerprint';
import { ZxAISessionDiagnosticCode, ZxAISessionDiagnosticStage, ZxAISessionDiagnosticV1 } from './contract';
export declare const isRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasExactKeys: (value: unknown, required: readonly string[], optional?: readonly string[]) => value is Record<string, unknown>;
export declare const isNonEmptyString: (value: unknown) => value is string;
export declare const isSafeNonNegativeInteger: (value: unknown) => value is number;
export declare const isSafeId: (value: unknown) => value is string;
export declare const isSessionFingerprint: (value: unknown) => value is string;
export declare const fingerprintSessionDomain: (domain: string, value: unknown) => string;
export declare const canonicalSessionClone: <TValue>(value: TValue) => TValue;
export declare const canonicalSessionEqual: (left: unknown, right: unknown) => boolean;
export declare const canonicalSessionByteLength: (value: unknown) => number;
export declare const isDeepFrozenSessionValue: (value: unknown, seen?: Set<object>) => boolean;
export declare const withoutSessionFingerprint: <TValue extends {
    readonly fingerprint: unknown;
}>(value: TValue) => Omit<TValue, "fingerprint">;
export declare const createAISessionDiagnostic: (input: {
    readonly code: ZxAISessionDiagnosticCode;
    readonly stage: ZxAISessionDiagnosticStage;
    readonly path: string;
    readonly count?: number;
    readonly fingerprint?: string;
    readonly sessionRef?: string;
    readonly requestRef?: string;
    readonly attemptRef?: string;
    readonly capability?: string;
    readonly terminalReason?: string;
}) => ZxAISessionDiagnosticV1;
export declare const rejectLiveOrForbiddenValue: (value: unknown, path?: string) => ZxAISessionDiagnosticV1 | null;
export declare const assertNoAmbientClockInSource: (source: string) => boolean;
export { deepFreeze, fingerprintPrefix };
//# sourceMappingURL=canonical.d.ts.map