import { ZxAIAttemptFailureClassV1, ZxAISessionArtifactV1, ZxAISessionAttemptV1, ZxAISessionDiagnosticV1, ZxAISessionSealedResultV1, ZxAITransportAttemptFailureReasonV1, ZxAITransportEventEnvelopeV1, ZxAITransportEventPayloadV1 } from './contract';
/** Each failure class is meaningful only under the reasons listed here. */
export declare const AI_ATTEMPT_FAILURE_CLASSES_BY_REASON_V1: Readonly<Record<ZxAITransportAttemptFailureReasonV1, readonly ZxAIAttemptFailureClassV1[]>>;
export declare const isAIAttemptFailureClassForReason: (reason: unknown, failureClass: unknown) => boolean;
export declare const computePayloadFingerprint: (payload: ZxAITransportEventPayloadV1) => string;
export declare const computeEventFingerprint: (event: Omit<ZxAITransportEventEnvelopeV1, "fingerprint">) => string;
export declare const sealResultFingerprint: (result: Omit<ZxAISessionSealedResultV1, "fingerprint">) => string;
export declare const computeSealedContentDigest: (result: Pick<ZxAISessionSealedResultV1, "kind" | "operationEnvelope" | "messageDigest">) => string;
export declare const publishSealedResult: (result: Omit<ZxAISessionSealedResultV1, "fingerprint" | "contentDigest"> & {
    readonly contentDigest?: string;
}) => ZxAISessionSealedResultV1;
export declare const validateTransportEventEnvelope: (event: unknown) => {
    readonly ok: true;
    readonly value: ZxAITransportEventEnvelopeV1;
} | {
    readonly ok: false;
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
export declare const admitEventAgainstAttempt: (session: ZxAISessionArtifactV1, attempt: ZxAISessionAttemptV1, event: ZxAITransportEventEnvelopeV1) => {
    readonly ok: true;
    readonly mode: "accept" | "idempotent";
} | {
    readonly ok: false;
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
export declare const validateSealedResultCandidate: (payload: Extract<ZxAITransportEventPayloadV1, {
    kind: "attempt-succeeded";
}>) => {
    readonly ok: true;
    readonly value: ZxAISessionSealedResultV1;
} | {
    readonly ok: false;
    readonly diagnostic: ZxAISessionDiagnosticV1;
};
type ZxAIBuildTransportEventInputV1 = {
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly sequence: number;
    readonly kind: ZxAITransportEventEnvelopeV1['kind'];
    readonly payload: Exclude<ZxAITransportEventPayloadV1, {
        readonly kind: 'attempt-succeeded';
    }> | {
        readonly kind: 'attempt-succeeded';
        readonly result: Omit<ZxAISessionSealedResultV1, 'fingerprint' | 'contentDigest'> & {
            readonly contentDigest?: string;
        };
    };
    readonly previousEventFingerprint?: string;
};
/**
 * Safe event facade. Terminal candidates are sealed here so public transports
 * never need a fingerprint/content-digest constructor.
 */
export declare const buildTransportEvent: (input: ZxAIBuildTransportEventInputV1) => ZxAITransportEventEnvelopeV1;
export {};
//# sourceMappingURL=event-validator.d.ts.map