import { createAISessionDiagnostic } from './canonical';
import { ZxAISessionArtifactReadResultV1, ZxAISessionArtifactV1, ZxAISessionHistoricalEnvelopeV1 } from './contract';
export declare const AI_SESSION_HISTORICAL_READER_V1: "zx-ai-session-historical-reader-v1";
export declare const readAISessionArtifact: (input: unknown) => ZxAISessionArtifactReadResultV1;
export declare const serializeAISessionArtifact: (session: ZxAISessionArtifactV1) => ZxAISessionArtifactV1;
export declare const createAISessionHistoricalEnvelope: (session: ZxAISessionArtifactV1) => {
    readonly status: "success";
    readonly envelope: ZxAISessionHistoricalEnvelopeV1;
} | {
    readonly status: "unsupported" | "failure";
    readonly diagnostic: ReturnType<typeof createAISessionDiagnostic>;
};
//# sourceMappingURL=historical.d.ts.map