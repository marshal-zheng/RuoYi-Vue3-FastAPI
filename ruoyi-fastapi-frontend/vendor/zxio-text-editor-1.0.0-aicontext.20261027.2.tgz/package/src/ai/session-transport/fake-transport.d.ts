import { ZxAIFakeTransportStepV1, ZxAITransportPortV1 } from './contract';
export interface ZxAIDeterministicFakeTransportV1 extends ZxAITransportPortV1 {
    readonly steps: readonly ZxAIFakeTransportStepV1[];
    advance(): void;
    pendingEffectKind(): string | null;
}
export interface ZxAICreateDeterministicTransportOptions {
    readonly transportId?: string;
    readonly steps?: readonly ZxAIFakeTransportStepV1[];
    readonly abort?: boolean;
    readonly resume?: false | 'resume:same-attempt-checkpoint-v1';
    readonly requestKinds?: ZxAITransportPortV1['descriptor']['capabilities']['requestKinds'];
}
/**
 * Scripted deterministic fake transport. No network, no real timers.
 * Tests explicitly call advance() / consume async iterators.
 */
export declare const createDeterministicAITransport: (options?: ZxAICreateDeterministicTransportOptions) => ZxAIDeterministicFakeTransportV1;
//# sourceMappingURL=fake-transport.d.ts.map