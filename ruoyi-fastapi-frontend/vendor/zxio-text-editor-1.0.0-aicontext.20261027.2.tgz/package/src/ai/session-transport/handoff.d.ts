import { ZxAIExecuteReviewRegenerationSuccessorOptionsV1, ZxAIExecuteReviewRegenerationSuccessorOutcomeV1 } from './regeneration-successor';
import { ZxAIValidateOperationEnvelopeOptions, ZxSemanticSnapshot } from '../contract';
import { ZxTextEditorDocument } from '../../document/types';
import { ZxAISessionEffectV1, ZxAISessionHandoffOutcomeV1, ZxAISessionHandoffReceiptV1, ZxAISessionReviewArtifactTransferReadResultV1, ZxAISessionReviewArtifactTransferV1, ZxAISessionSealedResultV1 } from './contract';
export interface ZxAIExecuteSessionProposalHandoffOptionsV1 {
    readonly sealedResult: ZxAISessionSealedResultV1;
    readonly effect?: Extract<ZxAISessionEffectV1, {
        readonly kind: 'proposal-handoff';
    }>;
    readonly snapshot?: ZxSemanticSnapshot;
    readonly baseDocument?: ZxTextEditorDocument;
    readonly proposalId?: string;
    readonly variantId?: string;
    readonly reviewId?: string;
    readonly documentSentinel?: unknown;
}
/** Public alias aligned with design.md API naming. */
export type ZxAIExecuteSessionHandoffOptions = ZxAIExecuteSessionProposalHandoffOptionsV1;
export interface ZxAIExecuteSessionHandoffRuntimeV1 {
    /**
     * Optional host-owned cooperative scheduler. It stays separate from the
     * canonical options so callbacks never enter validation or fingerprints.
     */
    readonly yieldControl?: () => Promise<void>;
    /**
     * Host-installed S8 authority ports. They stay outside the canonical S5
     * artifact while the resulting plan/proposal retain only exact refs.
     */
    readonly complex?: ZxAIValidateOperationEnvelopeOptions['complex'];
}
export declare const bindHandoff: (body: Omit<ZxAISessionHandoffReceiptV1, "fingerprint">) => ZxAISessionHandoffReceiptV1;
export declare const readAISessionReviewArtifactTransfer: (input: unknown) => ZxAISessionReviewArtifactTransferReadResultV1;
export declare const bindReviewArtifactTransfer: (input: {
    readonly receipt: ZxAISessionHandoffReceiptV1;
    readonly proposal: ZxAISessionReviewArtifactTransferV1["proposal"];
    readonly lifecycle: ZxAISessionReviewArtifactTransferV1["lifecycle"];
    readonly sidecar: ZxAISessionReviewArtifactTransferV1["sidecar"];
}) => ZxAISessionReviewArtifactTransferV1;
/**
 * Public S2 → Runtime v2/S3 → S4 orchestration only.
 * Never constructs Transaction/Step/EditorState or calls dispatch.
 */
export declare const executeAISessionProposalHandoff: (options: ZxAIExecuteSessionProposalHandoffOptionsV1, runtime?: ZxAIExecuteSessionHandoffRuntimeV1) => Promise<ZxAISessionHandoffOutcomeV1>;
export declare const executeAIReviewRegenerationSuccessor: (options: ZxAIExecuteReviewRegenerationSuccessorOptionsV1, runtime?: ZxAIExecuteSessionHandoffRuntimeV1) => Promise<ZxAIExecuteReviewRegenerationSuccessorOutcomeV1>;
//# sourceMappingURL=handoff.d.ts.map