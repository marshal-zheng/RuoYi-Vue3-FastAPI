import { ZxAICollaborationDiagnosticCodeV1, ZxAICollaborationDiagnosticStageV1, ZxAICollaborationDiagnosticV1 } from './contract';
export declare const createAICollaborationDiagnostic: (input: {
    readonly code: ZxAICollaborationDiagnosticCodeV1;
    readonly stage: ZxAICollaborationDiagnosticStageV1;
    readonly path: string;
    readonly recovery?: ZxAICollaborationDiagnosticV1["recovery"];
    readonly reviewRef?: string;
    readonly commandRef?: string;
    readonly branchRefs?: readonly string[];
    readonly count?: number;
    readonly fingerprint?: string;
}) => ZxAICollaborationDiagnosticV1;
//# sourceMappingURL=diagnostic.d.ts.map