import { ZxTextEditorDocument } from '../../document/types';
import { ZxAICollaborationProviderStatusV1 } from './runtime';
import * as Y from 'yjs';
export interface ZxDeterministicYjsCollaborationPeerV1 {
    readonly peerId: string;
    readonly doc: Y.Doc;
    readonly setStatus: (status: ZxAICollaborationProviderStatusV1) => void;
    destroy(): void;
}
export interface ZxDeterministicYjsCollaborationMessageV1 {
    readonly messageId: string;
    readonly sourcePeerId: string;
    readonly targetPeerId: string;
    readonly logicalSequence: number;
    readonly byteLength: number;
    readonly delayed: boolean;
}
export interface ZxDeterministicYjsPeerStateVectorReceiptV1 {
    readonly kind: 'zx-ai-deterministic-peer-state-vector-v1';
    readonly peerId: string;
    readonly byteLength: number;
    readonly fingerprint: string;
}
export interface ZxDeterministicYjsCollaborationConnectorV1 {
    connect(peerId: string): void;
    disconnect(peerId: string): void;
    duplicate(messageId: string): string;
    delay(messageId: string): void;
    drop(messageId: string): void;
    releaseDelayed(messageId?: string): void;
    flushFIFO(input?: {
        readonly targetPeerId?: string;
        readonly limit?: number;
    }): number;
    flushReverse(input?: {
        readonly targetPeerId?: string;
        readonly limit?: number;
    }): number;
    pending(): readonly ZxDeterministicYjsCollaborationMessageV1[];
    isConnected(peerId: string): boolean;
    destroy(): void;
}
export declare const createDeterministicYjsCollaborationPeer: (input: {
    readonly peerId: string;
    readonly guid: string;
    readonly gc: boolean;
    readonly initialText?: string;
    readonly initialDocument?: ZxTextEditorDocument;
    readonly initialUpdate?: Uint8Array;
    readonly setStatus?: (status: ZxAICollaborationProviderStatusV1) => void;
}) => ZxDeterministicYjsCollaborationPeerV1;
export declare const createDeterministicYjsCollaborationConnector: (input: {
    readonly peers: readonly ZxDeterministicYjsCollaborationPeerV1[];
}) => ZxDeterministicYjsCollaborationConnectorV1;
export declare const captureDeterministicYjsPeerStateVector: (peer: ZxDeterministicYjsCollaborationPeerV1) => ZxDeterministicYjsPeerStateVectorReceiptV1;
export declare const mutateDeterministicYjsCollaborationPeer: (peer: ZxDeterministicYjsCollaborationPeerV1, input: Readonly<{
    key: string;
    value: string;
}>) => void;
export declare const createDeterministicYjsCollaborationCheckpoint: (peers: readonly ZxDeterministicYjsCollaborationPeerV1[]) => Uint8Array;
export declare const applyDeterministicYjsCollaborationCheckpoint: (peers: readonly ZxDeterministicYjsCollaborationPeerV1[], checkpoint: Uint8Array) => void;
//# sourceMappingURL=deterministic-connector.d.ts.map