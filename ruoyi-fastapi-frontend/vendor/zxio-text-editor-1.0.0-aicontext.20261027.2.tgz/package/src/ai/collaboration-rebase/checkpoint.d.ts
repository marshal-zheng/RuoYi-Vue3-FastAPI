import { ZxAICollaborationAdmissionReceiptV1, ZxAICollaborationDiagnosticV1, ZxAICollaborationGraphV1, ZxAICollaborationHostPolicyPortV1, ZxAIDurableReviewCheckpointV1, ZxAIYjsCollaborationAdapterV1 } from './contract';
export interface ZxAICollaborationCheckpointCommandV1 {
    readonly commandFingerprint: string;
    readonly artifactFingerprint: string;
    readonly compactedPrefixFingerprints: readonly string[];
}
export declare const fingerprintAICollaborationCheckpointPrefix: (compactedPrefixFingerprints: readonly string[]) => string;
export declare const deriveAICollaborationCheckpointCommand: (input: {
    readonly checkpoint: ZxAIDurableReviewCheckpointV1;
}) => ZxAICollaborationCheckpointCommandV1 | null;
export type ZxAICollaborationCheckpointResultV1 = {
    readonly status: 'published' | 'idempotent';
    readonly checkpoint: ZxAIDurableReviewCheckpointV1;
} | {
    readonly status: 'not-terminal' | 'conflict' | 'pending-authorization' | 'denied' | 'storage-conflict' | 'failure';
    readonly checkpoint: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export declare const prepareAICollaborationCheckpoint: (input: {
    readonly graph: ZxAICollaborationGraphV1;
    readonly suffixBoundaryFingerprint: string | null;
}) => ZxAICollaborationCheckpointCommandV1 | null;
export declare const createAICollaborationCheckpoint: (input: {
    readonly graph: ZxAICollaborationGraphV1;
    readonly documentId: string;
    readonly principalRef: string;
    readonly suffixBoundaryFingerprint: string | null;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
    readonly logicalTime: number;
    readonly policy: ZxAICollaborationHostPolicyPortV1;
    readonly adapter: ZxAIYjsCollaborationAdapterV1;
}) => Promise<ZxAICollaborationCheckpointResultV1>;
export declare const applyAICollaborationCheckpointDominance: (input: {
    readonly checkpoint: ZxAIDurableReviewCheckpointV1;
    readonly records: readonly unknown[];
}) => {
    status: "invalid";
    auditRedundantFingerprints: readonly string[];
    incidentFingerprints: readonly string[];
} | {
    status: "incident" | "dominated";
    auditRedundantFingerprints: string[];
    incidentFingerprints: string[];
    fingerprint: string;
};
//# sourceMappingURL=checkpoint.d.ts.map