import { ZxAICollaborationBaseBindingV1, ZxAICollaborationGraphV1, ZxAICollaborationHostPolicyPortV1, ZxAIYjsRecordEnumerationV1 } from './contract';
import { ZxAIReviewAuthorityReconciliationResultV1 } from '../review-runtime';
import { ZxAISessionReviewArtifactTransferV1 } from '../session-transport';
export interface ZxAIDeriveCollaborationGraphInputV1 {
    readonly enumeration: ZxAIYjsRecordEnumerationV1;
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly baseBinding: ZxAICollaborationBaseBindingV1;
    readonly policy: ZxAICollaborationHostPolicyPortV1;
    readonly logicalTime: number;
}
export declare const deriveAICollaborationCandidateGraph: (input: ZxAIDeriveCollaborationGraphInputV1) => Promise<ZxAICollaborationGraphV1>;
export declare const reconcileAICollaborationGraphAuthority: (graph: ZxAICollaborationGraphV1) => ZxAIReviewAuthorityReconciliationResultV1 | null;
//# sourceMappingURL=candidate-graph.d.ts.map