import { ZxAICollaborationActionV1, ZxAICollaborationAdmissionReceiptV1, ZxAICollaborationDiagnosticV1, ZxAICollaborationHostPolicyPortV1 } from './contract';
export interface ZxAICreateCollaborationAdmissionInputV1 {
    readonly principalRef: string;
    readonly documentId: string;
    readonly action: ZxAICollaborationActionV1;
    readonly commandFingerprint: string;
    readonly artifactFingerprint: string;
    readonly policyFingerprint: string;
    readonly issuedAtLogicalTime: number;
    readonly expiresAtLogicalTime: number;
    readonly verifierEvidenceFingerprint: string;
}
export type ZxAICollaborationFreshAdmissionResultV1 = {
    readonly status: 'verified';
    readonly receipt: ZxAICollaborationAdmissionReceiptV1;
} | {
    readonly status: 'denied' | 'invalid' | 'pending-authorization';
    readonly receipt: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export interface ZxDeterministicCollaborationPrincipalV1 {
    readonly principalRef: string;
    readonly actions: readonly ZxAICollaborationActionV1[];
}
export interface ZxCreateDeterministicCollaborationHostPolicyOptionsV1 {
    readonly documentId: string;
    readonly policyFingerprint: string;
    readonly principals: readonly ZxDeterministicCollaborationPrincipalV1[];
    readonly supportsGlobalCommitReservation?: boolean;
    readonly enumerationComplete?: boolean;
    readonly compactionAllowed?: boolean;
    readonly historicallyAcceptedAdmissionFingerprints?: readonly string[];
    readonly historicallyAcceptedPolicyFingerprints?: readonly string[];
}
export interface ZxDeterministicCollaborationHostPolicyV1 {
    readonly port: ZxAICollaborationHostPolicyPortV1;
    setUnavailable(value: boolean): void;
    setEnumerationComplete(value: boolean): void;
    setPolicyFingerprint(value: string): void;
    revokePrincipal(principalRef: string): void;
    restorePrincipal(principalRef: string): void;
    readFence(documentId: string, reviewId: string): 'open' | 'reserved' | 'terminal' | 'incident';
    readAcceptedAdmissionFingerprints(): readonly string[];
    readAcceptedPolicyFingerprints(): readonly string[];
}
export declare const createAICollaborationAdmissionReceipt: (input: ZxAICreateCollaborationAdmissionInputV1) => ZxAICollaborationAdmissionReceiptV1;
declare const verifyAICollaborationAdmission: (input: {
    readonly port: ZxAICollaborationHostPolicyPortV1;
    readonly receipt: ZxAICollaborationAdmissionReceiptV1;
    readonly expectedDocumentId: string;
    readonly expectedAction: ZxAICollaborationActionV1;
    readonly expectedCommandFingerprint: string;
    readonly expectedArtifactFingerprint: string;
    readonly expectedPolicyFingerprint: string;
    readonly logicalTime: number;
    readonly mode: "fresh" | "historical";
}) => Promise<ZxAICollaborationFreshAdmissionResultV1>;
export declare const verifyAICollaborationAdmissionFresh: (input: Omit<Parameters<typeof verifyAICollaborationAdmission>[0], "mode">) => Promise<ZxAICollaborationFreshAdmissionResultV1>;
export declare const verifyAICollaborationAdmissionHistorical: (input: Omit<Parameters<typeof verifyAICollaborationAdmission>[0], "mode">) => Promise<ZxAICollaborationFreshAdmissionResultV1>;
export declare const createDeterministicAICollaborationHostPolicy: (options: ZxCreateDeterministicCollaborationHostPolicyOptionsV1) => ZxDeterministicCollaborationHostPolicyV1;
export {};
//# sourceMappingURL=admission.d.ts.map