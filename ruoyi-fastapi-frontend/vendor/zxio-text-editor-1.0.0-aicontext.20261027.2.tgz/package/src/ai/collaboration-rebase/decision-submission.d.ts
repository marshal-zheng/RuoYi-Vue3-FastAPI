import { ZxAIReviewAuthorityReconciliationResultV1, ZxAIReviewDecisionCommandV1 } from '../review-runtime';
import { ZxAISessionReviewArtifactTransferV1 } from '../session-transport';
import { ZxAICollaborationAdmissionReceiptV1, ZxAICollaborationBaseBindingV1, ZxAICollaborationGraphV1, ZxAICollaborationHostPolicyPortV1, ZxAIDurableReviewEntryV1, ZxAIYjsCollaborationAdapterV1 } from './contract';
import { ZxAIPreparedDurableReviewDecisionEntryV1 } from './review-entry';
export interface ZxAISubmitDurableReviewDecisionInputV1 {
    readonly graph: ZxAICollaborationGraphV1;
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly baseBinding: ZxAICollaborationBaseBindingV1;
    readonly command: ZxAIReviewDecisionCommandV1;
    readonly principalRef: string;
    readonly admissionPolicyFingerprint: string;
    readonly logicalSequence: number;
    readonly logicalTime: number;
    readonly adapter: ZxAIYjsCollaborationAdapterV1;
    readonly policy: ZxAICollaborationHostPolicyPortV1;
    readonly authorize: (input: {
        readonly prepared: ZxAIPreparedDurableReviewDecisionEntryV1;
    }) => ZxAICollaborationAdmissionReceiptV1 | Promise<ZxAICollaborationAdmissionReceiptV1>;
}
export type ZxAISubmitDurableReviewDecisionResultV1 = {
    readonly status: 'submitted';
    readonly entry: ZxAIDurableReviewEntryV1;
    readonly graph: ZxAICollaborationGraphV1;
    readonly reconciled: ZxAIReviewAuthorityReconciliationResultV1;
    readonly stageTrace: readonly [
        'prepare',
        'fresh-admission',
        'append',
        'complete-reread',
        'graph',
        'reconcile'
    ];
} | {
    readonly status: 'invalid-input' | 'pending-authorization' | 'denied' | 'storage-conflict' | 'graph-conflict' | 'reconcile-failure';
    readonly entry: null;
    readonly graph: ZxAICollaborationGraphV1 | null;
    readonly reconciled: null;
    readonly stageTrace: readonly string[];
};
export declare const submitAIDurableReviewDecision: (input: ZxAISubmitDurableReviewDecisionInputV1) => Promise<ZxAISubmitDurableReviewDecisionResultV1>;
//# sourceMappingURL=decision-submission.d.ts.map