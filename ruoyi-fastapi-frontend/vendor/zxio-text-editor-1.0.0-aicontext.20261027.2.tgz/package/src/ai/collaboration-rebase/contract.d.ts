import { ZxAIReviewDecisionCommandV1, ZxAIReviewHistoricalEnvelopeV1, ZxAIReviewSidecarV1 } from '../review-runtime';
import { ZxAICollaborationConflictResolutionCommandV1 } from './conflict-resolution';
import { ZxAISessionReviewArtifactTransferV1 } from '../session-transport';
import { ZX_AI_COLLABORATION_CONTRACT_VERSION } from './limits';
export type ZxAICollaborationContractVersion = typeof ZX_AI_COLLABORATION_CONTRACT_VERSION;
export type ZxAICollaborationDiagnosticCodeV1 = 'collaboration-input-invalid' | 'collaboration-artifact-invalid' | 'collaboration-runtime-unsupported' | 'collaboration-resource-limit' | 'collaboration-identity-conflict' | 'collaboration-storage-conflict' | 'collaboration-pending-sync' | 'collaboration-pending-predecessor' | 'collaboration-authorization-unavailable' | 'collaboration-admission-invalid' | 'collaboration-denied' | 'collaboration-review-conflict' | 'collaboration-anchor-lost' | 'collaboration-anchor-ambiguous' | 'collaboration-capability-changed' | 'collaboration-rebase-required' | 'collaboration-rebase-unsupported' | 'collaboration-invariant-violation' | 'collaboration-post-dispatch-incident' | 'collaboration-checkpoint-invalid';
export type ZxAICollaborationDiagnosticStageV1 = 'input' | 'codec' | 'capture' | 'anchor' | 'storage' | 'authorization' | 'graph' | 'reconcile' | 'rebase' | 'commit' | 'history' | 'checkpoint' | 'projection' | 'lifecycle';
export interface ZxAICollaborationDiagnosticV1 {
    readonly code: ZxAICollaborationDiagnosticCodeV1;
    readonly stage: ZxAICollaborationDiagnosticStageV1;
    readonly path: string;
    readonly recovery: 'none' | 'retry-verification' | 'reconnect' | 'replan' | 'resolve-conflict' | 'reject' | 'finalize-proof';
    readonly reviewRef?: string;
    readonly commandRef?: string;
    readonly branchRefs?: readonly string[];
    readonly count?: number;
    readonly fingerprintPrefix?: string;
}
export interface ZxAICollaborationBytesRefV1 {
    readonly encoding: 'base64url';
    readonly value: string;
    readonly byteLength: number;
    readonly fingerprint: string;
}
export interface ZxAICollaborationStateVectorRefV1 {
    readonly codec: 'yjs-state-vector-v1';
    readonly bytes: ZxAICollaborationBytesRefV1;
    readonly fingerprint: string;
}
export interface ZxAICollaborationAnchorRefV1 {
    readonly kind: 'selection-endpoint' | 'block-boundary';
    readonly blockId: string;
    readonly semanticOffset: number;
    readonly affinity: 'left' | 'right';
    readonly relativePosition: ZxAICollaborationBytesRefV1;
    readonly capabilityFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationDocumentScopeV1 {
    readonly kind: 'document-scope';
    readonly localAnchor: null;
    readonly fingerprint: string;
}
export interface ZxAICollaborationRefV1 {
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationBaseBindingV1 {
    readonly kind: 'zx-ai-collaboration-base-binding-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly documentId: string;
    readonly rootSharedType: string;
    readonly documentRevision: string;
    readonly documentFingerprint: string;
    readonly baseFingerprint: string;
    readonly targetFingerprint: string;
    readonly stableBlockIds: readonly string[];
    readonly anchors: readonly ZxAICollaborationAnchorRefV1[];
    readonly documentScope: ZxAICollaborationDocumentScopeV1 | null;
    readonly stateVector: ZxAICollaborationStateVectorRefV1;
    readonly schemaRef: ZxAICollaborationRefV1;
    readonly runtimeRef: ZxAICollaborationRefV1;
    readonly policyRef: ZxAICollaborationRefV1;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly handoffFingerprint: string;
    readonly sessionTransferFingerprint: string;
    readonly proposalId: string;
    readonly variantId: string;
    readonly proposalFingerprint: string;
    readonly lifecycleFingerprint: string;
    readonly reviewId: string;
    readonly sidecarFingerprint: string;
    readonly capturedAtLogicalTime: number;
    readonly captureProofFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAICollaborationActionV1 = 'publish-root' | 'decision' | 'reject' | 'rebase' | 'resolve-conflict' | 'commit' | 'compact';
export interface ZxAICollaborationAdmissionReceiptV1 {
    readonly kind: 'zx-ai-collaboration-admission-receipt-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly principalRef: string;
    readonly documentId: string;
    readonly namespace: string;
    readonly action: ZxAICollaborationActionV1;
    readonly commandFingerprint: string;
    readonly artifactFingerprint: string;
    readonly policyFingerprint: string;
    readonly issuedAtLogicalTime: number;
    readonly expiresAtLogicalTime: number;
    readonly verifierEvidenceFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationEnumerationProofV1 {
    readonly kind: 'zx-ai-collaboration-enumeration-proof-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly documentId: string;
    readonly namespace: string;
    readonly reviewId: string;
    readonly stateVectorFingerprint: string;
    readonly recordSetFingerprint: string;
    readonly policyFingerprint: string;
    readonly complete: true;
    readonly fingerprint: string;
}
export interface ZxAIDurableReviewRootV1 {
    readonly kind: 'zx-ai-durable-review-root-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reviewId: string;
    readonly sessionTransferFingerprint: string;
    readonly proposalFingerprint: string;
    readonly lifecycleFingerprint: string;
    readonly initialSidecarFingerprint: string;
    readonly initialSidecar: ZxAIReviewSidecarV1;
    readonly baseBindingFingerprint: string;
    readonly creatorPrincipalRef: string;
    readonly policyFingerprint: string;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
    readonly admissionFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAIDurableReviewEntryKindV1 = 'decision' | 'rebase' | 'commit' | 'reject' | 'conflict-resolution';
export interface ZxAICollaborationTerminalLineageV1 {
    readonly kind: 'zx-ai-collaboration-terminal-lineage-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly entryKind: 'reject' | 'rebase' | 'conflict-resolution';
    readonly sourceRootFingerprint: string;
    readonly sourceHeadFingerprint: string;
    readonly sourcePredecessorFingerprint: string;
    readonly sourceHandoffFingerprint: string | null;
    readonly successorIdentityFingerprint: string | null;
    readonly successorRootFingerprint: string | null;
    readonly currentBaseBindingFingerprint: string | null;
    readonly resolutionCommandFingerprint: string | null;
    readonly preservedBranchFingerprints: readonly string[];
    readonly terminalArtifactFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAIDurableReviewEntryV1 {
    readonly kind: 'zx-ai-durable-review-entry-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reviewId: string;
    readonly rootFingerprint: string;
    readonly commandId: string;
    readonly entryKind: ZxAIDurableReviewEntryKindV1;
    readonly priorReviewRevision: number;
    readonly priorSidecarFingerprint: string;
    readonly priorEntryFingerprint: string | null;
    readonly command: ZxAIReviewDecisionCommandV1 | ZxAICollaborationCommitCommandV1 | ZxAICollaborationConflictResolutionCommandV1 | null;
    readonly commandFingerprint: string;
    readonly principalRef: string;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
    readonly resultingSidecar: ZxAIReviewSidecarV1;
    readonly resultingSidecarFingerprint: string;
    readonly resultReceiptFingerprint: string | null;
    readonly collaborationDispatchAdmission: ZxAICollaborationAdmissionReceiptV1 | null;
    readonly collaborationCommitReceipt: ZxAICollaborationCommitReceiptV1 | null;
    readonly terminalCurrentBaseBinding: ZxAICollaborationBaseBindingV1 | null;
    readonly terminalHistoricalEnvelope: ZxAIReviewHistoricalEnvelopeV1 | null;
    readonly terminalLineage: ZxAICollaborationTerminalLineageV1 | null;
    readonly logicalSequence: number;
    readonly fingerprint: string;
}
export interface ZxAIDurableReviewCheckpointV1 {
    readonly kind: 'zx-ai-durable-review-checkpoint-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reviewId: string;
    readonly rootFingerprint: string;
    readonly compactedPrefixFingerprints: readonly string[];
    readonly terminalEntryFingerprint: string;
    readonly terminalArtifactFingerprint: string;
    readonly terminalHistoricalEnvelope: ZxAIReviewHistoricalEnvelopeV1;
    readonly auditHeadFingerprint: string;
    readonly suffixBoundaryFingerprint: string | null;
    readonly compactionAdmission: ZxAICollaborationAdmissionReceiptV1;
    readonly compactionAdmissionFingerprint: string;
    readonly hostCompactionAdmissionFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationSuccessorLineageV1 {
    readonly kind: 'zx-ai-collaboration-successor-lineage-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reviewId: string;
    readonly rootFingerprint: string;
    readonly sourceReviewId: string;
    readonly sourceRootFingerprint: string;
    readonly sourceHeadFingerprint: string;
    readonly sourceEntryFingerprint: string | null;
    readonly sourceReviewFingerprint: string;
    readonly sourceTerminalEntryFingerprint: string;
    readonly sourceTerminalSidecarFingerprint: string;
    readonly sourceTerminalArtifactFingerprint: string;
    readonly sourceTerminalLineageFingerprint: string;
    readonly sourceHandoffFingerprint: string;
    readonly sourceResolutionCommandFingerprint: string | null;
    readonly sourceProposalFingerprint: string;
    readonly sourceBaseBindingFingerprint: string;
    readonly currentBaseBindingFingerprint: string;
    readonly successorIdentityFingerprint: string;
    readonly successorTransferFingerprint: string;
    readonly successorProposalFingerprint: string;
    readonly successorLifecycleFingerprint: string;
    readonly successorSidecarFingerprint: string;
    readonly successorBaseBindingFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAIDurableReviewRecordV1 = ZxAIDurableReviewRootV1 | ZxAIDurableReviewEntryV1 | ZxAIDurableReviewCheckpointV1 | ZxAICollaborationSuccessorLineageV1;
export interface ZxAIYjsStoredRecordV1 {
    readonly storageKey: string;
    readonly value: unknown;
}
export interface ZxAIYjsRecordEnumerationV1 {
    readonly records: readonly ZxAIYjsStoredRecordV1[];
    readonly stateVector: Uint8Array;
    readonly candidateSetDigest: string;
}
export interface ZxAIYjsAppendResultV1 {
    readonly status: 'appended' | 'idempotent' | 'conflict' | 'failure';
    readonly storageKey: string;
}
export interface ZxAIRuntimeResolvedAnchorV1 {
    readonly rootSharedType: string;
    readonly blockId: string;
    readonly semanticOffset: number;
    readonly absolutePosition: number;
}
export interface ZxAISemanticAnchorInputV1 {
    readonly blockId: string;
    readonly semanticOffset: number;
    readonly affinity: 'left' | 'right';
    readonly capabilityFingerprint: string;
    readonly absolutePosition: number;
}
export interface ZxAIYjsContentCommitProofV1 {
    readonly beforeStateVector: Uint8Array;
    readonly afterStateVector: Uint8Array;
    readonly contentUpdate: Uint8Array;
    readonly observedOriginExact: boolean;
    readonly historyBefore: number;
    readonly historyAfter: number;
    readonly redoBefore: number;
    readonly redoAfter: number;
    readonly remoteHistoryDelta: number;
}
export interface ZxAIYjsUndoProofV1 {
    readonly beforeDocumentFingerprint: string;
    readonly afterDocumentFingerprint: string;
    readonly beforeStateVector: Uint8Array;
    readonly afterStateVector: Uint8Array;
    readonly undoUpdate: Uint8Array;
    readonly historyBefore: number;
    readonly historyAfter: number;
    readonly redoBefore: number;
    readonly redoAfter: number;
}
export interface ZxAIYjsUndoOutcomeV1 {
    readonly status: 'success' | 'empty' | 'failure';
    readonly proof: ZxAIYjsUndoProofV1 | null;
}
export interface ZxAIYjsContentCommitOutcomeV1<TValue> {
    readonly status: 'success' | 'unsupported-host' | 'failure';
    readonly dispatchStatus: 'not-started' | 'started';
    readonly effectStatus: 'none' | 'observed' | 'unknown';
    readonly value: TValue | null;
    readonly proof: ZxAIYjsContentCommitProofV1 | null;
}
export interface ZxAIYjsCollaborationAdapterV1 {
    readonly documentId: string;
    readonly rootSharedType: string;
    captureStateVector(): Uint8Array;
    captureRelativePosition(input: ZxAISemanticAnchorInputV1): Uint8Array;
    resolveRelativePosition(input: Uint8Array): ZxAIRuntimeResolvedAnchorV1 | null;
    enumerateRecords(input: {
        readonly documentId: string;
        readonly reviewId: string;
    }): Promise<ZxAIYjsRecordEnumerationV1>;
    appendRecord(input: {
        readonly storageKey: string;
        readonly value: unknown;
        readonly originKind: 'log';
    }): Promise<ZxAIYjsAppendResultV1>;
    runContentCommit<TValue>(input: {
        readonly expectedStateVector: Uint8Array;
        readonly run: () => TValue;
    }): ZxAIYjsContentCommitOutcomeV1<TValue>;
    observeStatus(listener: (status: 'connecting' | 'connected' | 'disconnected' | 'synced') => void): () => void;
    setStatus(status: 'connecting' | 'connected' | 'disconnected' | 'synced'): void;
    getUndoDepth(): number;
    getRedoDepth(): number;
    undoAI(): boolean;
    redoAI(): boolean;
    runAIUndo(input: {
        readonly readDocumentFingerprint: () => string;
    }): ZxAIYjsUndoOutcomeV1;
    destroy(): void;
}
export type ZxAICollaborationAdmissionVerificationResultV1 = {
    readonly status: 'verified';
    readonly receiptFingerprint: string;
} | {
    readonly status: 'denied' | 'invalid' | 'unavailable';
};
export type ZxAICollaborationEnumerationVerificationResultV1 = {
    readonly status: 'complete';
    readonly proof: ZxAICollaborationEnumerationProofV1;
} | {
    readonly status: 'pending' | 'denied' | 'invalid';
};
export interface ZxAICollaborationCommitReservationV1 {
    readonly kind: 'zx-ai-collaboration-commit-reservation-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reservationId: string;
    readonly documentId: string;
    readonly reviewId: string;
    readonly durableHeadFingerprint: string;
    readonly stateVectorFingerprint: string;
    readonly policyFingerprint: string;
    readonly status: 'reserved' | 'terminal' | 'incident';
    readonly fingerprint: string;
}
export type ZxAICollaborationCommitReservationResultV1 = {
    readonly status: 'reserved';
    readonly reservation: ZxAICollaborationCommitReservationV1;
} | {
    readonly status: 'lost' | 'unavailable' | 'unsupported-host';
};
export interface ZxAICollaborationHostPolicyPortV1 {
    verifyAdmission(input: {
        readonly receipt: ZxAICollaborationAdmissionReceiptV1;
        readonly expectedDocumentId: string;
        readonly expectedAction: ZxAICollaborationActionV1;
        readonly expectedCommandFingerprint: string;
        readonly expectedArtifactFingerprint: string;
        readonly expectedPolicyFingerprint: string;
        readonly logicalTime: number;
    }): Promise<ZxAICollaborationAdmissionVerificationResultV1>;
    verifyHistoricalAdmission(input: {
        readonly receipt: ZxAICollaborationAdmissionReceiptV1;
        readonly expectedDocumentId: string;
        readonly expectedAction: ZxAICollaborationActionV1;
        readonly expectedCommandFingerprint: string;
        readonly expectedArtifactFingerprint: string;
        readonly expectedPolicyFingerprint: string;
        readonly logicalTime: number;
    }): Promise<ZxAICollaborationAdmissionVerificationResultV1>;
    recordAcceptedAdmission(input: {
        readonly receipt: ZxAICollaborationAdmissionReceiptV1;
        readonly documentId: string;
        readonly reviewId: string;
        readonly recordFingerprint: string;
    }): Promise<'recorded' | 'idempotent' | 'denied' | 'unavailable'>;
    verifyEnumeration(input: {
        readonly documentId: string;
        readonly namespace: string;
        readonly reviewId: string;
        readonly stateVectorFingerprint: string;
        readonly recordSetFingerprint: string;
        readonly policyFingerprint: string;
    }): Promise<ZxAICollaborationEnumerationVerificationResultV1>;
    reserveCommit(input: {
        readonly documentId: string;
        readonly reviewId: string;
        readonly durableHeadFingerprint: string;
        readonly stateVectorFingerprint: string;
        readonly policyFingerprint: string;
    }): Promise<ZxAICollaborationCommitReservationResultV1>;
    releaseCommit(input: {
        readonly reservation: ZxAICollaborationCommitReservationV1;
    }): Promise<boolean>;
    finalizeCommit(input: {
        readonly reservation: ZxAICollaborationCommitReservationV1;
        readonly terminalEntryFingerprint: string;
        readonly incidentProofFingerprint?: string;
    }): Promise<boolean>;
    finalizeCommitIncident(input: {
        readonly reservation: ZxAICollaborationCommitReservationV1;
        readonly proofFingerprint: string;
    }): Promise<boolean>;
    verifyCommitFence(input: {
        readonly documentId: string;
        readonly reviewId: string;
    }): Promise<'open' | 'reserved' | 'terminal' | 'incident' | 'unavailable'>;
    admitCompaction(input: {
        readonly reviewId: string;
        readonly terminalEntryFingerprint: string;
        readonly prefixFingerprint: string;
    }): Promise<{
        readonly status: 'admitted';
        readonly admissionFingerprint: string;
    } | {
        readonly status: 'denied' | 'unavailable';
    }>;
}
export interface ZxAICollaborationGraphV1 {
    readonly status: 'accepted' | 'review-conflict' | 'pending' | 'storage-conflict' | 'invalid';
    readonly root: ZxAIDurableReviewRootV1 | null;
    readonly acceptedEntries: readonly ZxAIDurableReviewEntryV1[];
    readonly acceptedHeadFingerprint: string | null;
    readonly forkEntryFingerprints: readonly string[];
    readonly pendingEntryFingerprints: readonly string[];
    readonly invalidEntryFingerprints: readonly string[];
    readonly diagnostics: readonly ZxAICollaborationDiagnosticV1[];
    readonly fingerprint: string;
}
export type ZxAICollaborationDriftDispositionV1 = 'unchanged' | 'replication-coordinate-changed' | 'replan-required' | 'anchor-lost' | 'capability-changed' | 'review-conflict' | 'unsupported' | 'invariant-violation';
export interface ZxAICollaborationDriftResultV1 {
    readonly disposition: ZxAICollaborationDriftDispositionV1;
    readonly targetMoved: boolean;
    readonly survivingAnchorFingerprints: readonly string[];
    readonly diagnostic: ZxAICollaborationDiagnosticV1 | null;
    readonly fingerprint: string;
}
export interface ZxAICollaborationRebaseHandoffV1 {
    readonly kind: 'zx-ai-collaboration-rebase-handoff-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly sourceRootFingerprint: string;
    readonly sourceEntryFingerprint: string | null;
    readonly sourceProposalFingerprint: string;
    readonly sourceReviewFingerprint: string;
    readonly sourceDecisionFingerprint: string;
    readonly sourceBaseBindingFingerprint: string;
    readonly currentBaseBindingFingerprint: string;
    readonly survivingAnchorFingerprints: readonly string[];
    readonly operationIntentDigests: readonly string[];
    readonly latestSemanticSnapshotFingerprint: string;
    readonly regenerationHandoffFingerprint: string;
    readonly sourceTerminalSidecarFingerprint: string;
    readonly policyFingerprint: string;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
    readonly admissionFingerprint: string;
    readonly nextProposalId: string;
    readonly nextVariantId: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationCommitCommandV1 {
    readonly kind: 'zx-ai-collaboration-commit-command-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly commandId: string;
    readonly documentId: string;
    readonly reviewId: string;
    readonly rootFingerprint: string;
    readonly durableHeadFingerprint: string;
    readonly expectedReviewRevision: number;
    readonly expectedSidecarFingerprint: string;
    readonly currentBindingFingerprint: string;
    readonly currentDocumentFingerprint: string;
    readonly currentStateVectorFingerprint: string;
    readonly driftFingerprint: string;
    readonly policyFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationCommitReceiptV1 {
    readonly kind: 'zx-ai-collaboration-commit-receipt-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reviewId: string;
    readonly durableHeadFingerprint: string;
    readonly s4CommittedReceiptFingerprint: string;
    readonly terminalSidecarFingerprint: string;
    readonly beforeDocumentFingerprint: string;
    readonly afterDocumentFingerprint: string;
    readonly beforeStateVectorFingerprint: string;
    readonly afterStateVectorFingerprint: string;
    readonly contentUpdateFingerprint: string;
    readonly contentUpdateByteLength: number;
    readonly originKind: 'ai-content';
    readonly observedOriginProofFingerprint: string;
    readonly historyProofFingerprint: string;
    readonly admissionFingerprint: string;
    readonly commitReservationFingerprint: string;
    readonly fingerprint: string;
}
export interface ZxAICollaborationCommitIncidentProofV1 {
    readonly kind: 'zx-ai-collaboration-commit-incident-proof-v1';
    readonly version: ZxAICollaborationContractVersion;
    readonly reservation: ZxAICollaborationCommitReservationV1;
    readonly receipt: ZxAICollaborationCommitReceiptV1;
    readonly terminalEntry: ZxAIDurableReviewEntryV1;
    readonly fingerprint: string;
}
export interface ZxAICollaborationDurableProjectionV1 {
    readonly reviewId: string;
    readonly graphFingerprint: string;
    readonly policyFingerprint: string;
    readonly currentBindingFingerprint: string;
    readonly commitFenceStatus: 'open' | 'reserved' | 'terminal' | 'incident' | 'unavailable';
    readonly graphStatus: ZxAICollaborationGraphV1['status'];
    readonly acceptedHeadFingerprint: string | null;
    readonly branchRefs: readonly string[];
    readonly pendingRefs: readonly string[];
    readonly incident: boolean;
    readonly anchorState: 'valid' | 'lost' | 'ambiguous' | 'unknown';
    readonly rebaseDisposition: ZxAICollaborationDriftDispositionV1;
    readonly actorDisplayRefs: readonly string[];
    readonly allowedActions: readonly ZxAICollaborationActionV1[];
    readonly diagnostics: readonly ZxAICollaborationDiagnosticV1[];
    readonly fingerprint: string;
}
export interface ZxAICollaborationPresentationContractV1 {
    readonly regionRole: 'region';
    readonly reviewRole: 'group';
    readonly statusRole: 'status';
    readonly keyboardCommands: readonly {
        readonly key: 'Enter' | 'Escape' | 'ArrowLeft' | 'ArrowRight';
        readonly action: 'activate' | 'hide' | 'previous' | 'next';
    }[];
    readonly visibleFocus: true;
    readonly nonColorStateIndicators: true;
    readonly liveRegionMode: 'status-changes-only';
    readonly announcesIncrementalContent: false;
    readonly fingerprint: string;
}
export interface ZxAICollaborationEphemeralProjectionV1 {
    readonly providerStatus: 'connecting' | 'connected' | 'disconnected' | 'synced';
    readonly onlineActorRefs: readonly string[];
    readonly cursorCount: number;
    readonly reviewerTyping: boolean;
}
export interface ZxAICollaborationProjectionV1 {
    readonly durable: ZxAICollaborationDurableProjectionV1;
    readonly ephemeral: ZxAICollaborationEphemeralProjectionV1;
}
export interface ZxAICollaborationReferenceProvenanceDecisionV1 {
    readonly sourcePath: string;
    readonly sourceTestPath: string | null;
    readonly decision: 'copy' | 'adapt' | 'reject';
    readonly boundary: string;
    readonly difference: string;
    readonly fixtureIds: readonly string[];
}
export interface ZxAICollaborationReferenceProvenanceV1 {
    readonly repository: 'BlockNote' | 'Plate' | 'Novel';
    readonly commit: string;
    readonly decisions: readonly ZxAICollaborationReferenceProvenanceDecisionV1[];
    readonly fingerprint: string;
}
export interface ZxAIDurableRootInputV1 {
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly baseBinding: ZxAICollaborationBaseBindingV1;
    readonly creatorPrincipalRef: string;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
}
export interface ZxAICreateCollaborationBaseBindingOptionsV1 {
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly documentId: string;
    readonly rootSharedType: string;
    readonly documentRevision: string;
    readonly documentFingerprint: string;
    readonly baseFingerprint: string;
    readonly targetFingerprint: string;
    readonly stableBlockIds: readonly string[];
    readonly scopeKind: 'selection' | 'blocks' | 'document';
    readonly anchors: readonly ZxAISemanticAnchorInputV1[];
    readonly schemaRef: ZxAICollaborationRefV1;
    readonly runtimeRef: ZxAICollaborationRefV1;
    readonly policyRef: ZxAICollaborationRefV1;
    readonly capturedAtLogicalTime: number;
    readonly captureProofFingerprint: string;
}
export type ZxAICollaborationBaseBindingResultV1 = {
    readonly status: 'success';
    readonly binding: ZxAICollaborationBaseBindingV1;
} | {
    readonly status: 'identity-conflict' | 'failure';
    readonly binding: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export type ZxAICollaborationAnchorResolutionResultV1 = {
    readonly status: 'surviving';
    readonly anchor: ZxAICollaborationAnchorRefV1;
    readonly resolved: ZxAIRuntimeResolvedAnchorV1;
    readonly targetMoved: boolean;
    readonly fingerprint: string;
} | {
    readonly status: 'anchor-lost' | 'anchor-ambiguous' | 'capability-changed';
    readonly anchor: ZxAICollaborationAnchorRefV1;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
//# sourceMappingURL=contract.d.ts.map