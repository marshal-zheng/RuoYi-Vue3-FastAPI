import { ZxAICollaborationDurableProjectionV1, ZxAICollaborationEphemeralProjectionV1, ZxAICollaborationProjectionV1 } from './contract';
export interface ZxAICollaborationAwarenessInputV1 {
    readonly providerStatus: 'connecting' | 'connected' | 'disconnected' | 'synced';
    readonly actors: readonly {
        readonly actorRef: unknown;
        readonly cursorVisible?: unknown;
        readonly reviewerTyping?: unknown;
    }[];
}
export declare const projectAICollaborationAwareness: (input: ZxAICollaborationAwarenessInputV1) => ZxAICollaborationEphemeralProjectionV1;
export declare const mergeAICollaborationProjection: (input: {
    readonly durable: ZxAICollaborationDurableProjectionV1;
    readonly ephemeral: ZxAICollaborationEphemeralProjectionV1;
}) => ZxAICollaborationProjectionV1;
//# sourceMappingURL=awareness.d.ts.map