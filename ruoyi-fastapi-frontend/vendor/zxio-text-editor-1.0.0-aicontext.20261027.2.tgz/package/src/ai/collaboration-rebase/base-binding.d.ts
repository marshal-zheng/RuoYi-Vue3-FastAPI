import { ZxAICollaborationBaseBindingResultV1, ZxAICollaborationBaseBindingV1, ZxAICreateCollaborationBaseBindingOptionsV1, ZxAIYjsCollaborationAdapterV1 } from './contract';
export declare const createAICollaborationBaseBinding: (options: ZxAICreateCollaborationBaseBindingOptionsV1, adapter: ZxAIYjsCollaborationAdapterV1) => ZxAICollaborationBaseBindingResultV1;
export declare const createAICollaborationCurrentBinding: (options: ZxAICreateCollaborationBaseBindingOptionsV1, adapter: ZxAIYjsCollaborationAdapterV1) => ZxAICollaborationBaseBindingResultV1;
export declare const compareAICollaborationBaseIdentity: (existing: ZxAICollaborationBaseBindingV1, candidate: ZxAICollaborationBaseBindingV1) => "idempotent" | "identity-conflict";
//# sourceMappingURL=base-binding.d.ts.map