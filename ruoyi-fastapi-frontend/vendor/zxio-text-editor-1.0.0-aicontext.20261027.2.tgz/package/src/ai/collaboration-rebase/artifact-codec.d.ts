import { ZxAICollaborationAdmissionReceiptV1, ZxAICollaborationBaseBindingV1, ZxAICollaborationCommitReceiptV1, ZxAICollaborationDiagnosticV1, ZxAICollaborationRebaseHandoffV1, ZxAICollaborationSuccessorLineageV1, ZxAIDurableReviewCheckpointV1, ZxAIDurableReviewEntryV1, ZxAIDurableReviewRecordV1, ZxAIDurableReviewRootV1 } from './contract';
type ArtifactReadSuccess<TValue> = {
    readonly status: 'success';
    readonly artifact: TValue;
};
type ArtifactReadFailure = {
    readonly status: 'invalid' | 'unsupported';
    readonly artifact: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export type ZxAICollaborationArtifactReadResultV1<TValue> = ArtifactReadSuccess<TValue> | ArtifactReadFailure;
export declare const readAICollaborationAdmissionReceipt: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAICollaborationAdmissionReceiptV1>;
export declare const readAICollaborationCommitReceipt: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAICollaborationCommitReceiptV1>;
export declare const readAICollaborationBaseBinding: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAICollaborationBaseBindingV1>;
export declare const readAIDurableReviewRoot: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAIDurableReviewRootV1>;
export declare const readAIDurableReviewEntry: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAIDurableReviewEntryV1>;
export declare const readAIDurableReviewCheckpoint: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAIDurableReviewCheckpointV1>;
export declare const readAICollaborationSuccessorLineage: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAICollaborationSuccessorLineageV1>;
export declare const readAICollaborationRebaseHandoff: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAICollaborationRebaseHandoffV1>;
export declare const readAIDurableReviewRecord: (input: unknown) => ZxAICollaborationArtifactReadResultV1<ZxAIDurableReviewRecordV1>;
export declare const serializeAICollaborationArtifact: (input: unknown) => string;
export declare const AI_COLLABORATION_HISTORICAL_READER_V1: {
    kind: "zx-ai-collaboration-historical-reader-v1";
    version: "1.0.0";
    mode: "audit-only";
    supportsLiveRestore: false;
};
export type ZxAICollaborationHistoricalAuditResultV1 = {
    readonly status: 'audit-success';
    readonly recordFingerprint: string;
    readonly terminalArtifactFingerprint: string;
    readonly auditFingerprint: string;
    readonly liveRestoreAllowed: false;
} | {
    readonly status: 'invalid' | 'not-terminal' | 'unsupported';
    readonly liveRestoreAllowed: false;
};
export declare const auditAICollaborationHistoricalRecord: (input: unknown) => ZxAICollaborationHistoricalAuditResultV1;
export type { ZxAICollaborationCommitReceiptV1, ZxAICollaborationRebaseHandoffV1, };
//# sourceMappingURL=artifact-codec.d.ts.map