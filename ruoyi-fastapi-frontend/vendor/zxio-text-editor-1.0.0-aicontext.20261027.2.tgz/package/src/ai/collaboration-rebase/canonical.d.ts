import { ZxAICollaborationBytesRefV1 } from './contract';
export declare const isCollaborationRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasExactCollaborationKeys: (value: unknown, required: readonly string[], optional?: readonly string[]) => value is Record<string, unknown>;
export declare const isSafeCollaborationId: (value: unknown) => value is string;
export declare const isCollaborationFingerprint: (value: unknown) => value is string;
export declare const isSafeCollaborationInteger: (value: unknown) => value is number;
export declare const canonicalCollaborationClone: <TValue>(value: TValue) => TValue;
export declare const canonicalCollaborationEqual: (left: unknown, right: unknown) => boolean;
export declare const canonicalCollaborationByteLength: (value: unknown) => number;
export declare const fingerprintCollaborationDomain: (domain: string, value: unknown, parentFingerprints?: readonly string[]) => string;
export declare const decodeBase64Url: (value: string) => Uint8Array | null;
export declare const createCollaborationBytesRef: (bytes: Uint8Array, domain: "state-vector" | "relative-position" | "content-update") => ZxAICollaborationBytesRefV1;
export declare const readCollaborationBytesRef: (input: unknown, domain: "state-vector" | "relative-position" | "content-update") => {
    readonly status: "success";
    readonly bytes: Uint8Array;
} | {
    readonly status: "failure";
};
export declare const sortedUniqueCollaborationStrings: (values: readonly string[]) => readonly string[];
export declare const withoutCollaborationFingerprint: <TValue extends {
    readonly fingerprint: unknown;
}>(value: TValue) => Omit<TValue, "fingerprint">;
//# sourceMappingURL=canonical.d.ts.map