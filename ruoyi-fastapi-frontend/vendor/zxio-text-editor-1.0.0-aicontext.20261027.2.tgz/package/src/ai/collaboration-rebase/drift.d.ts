import { ZxAICollaborationAnchorResolutionResultV1, ZxAICollaborationBaseBindingV1, ZxAICollaborationDriftResultV1, ZxAICollaborationGraphV1 } from './contract';
export interface ZxAIClassifyCollaborationDriftInputV1 {
    readonly graph: ZxAICollaborationGraphV1;
    readonly baseBinding: ZxAICollaborationBaseBindingV1;
    readonly currentBinding: ZxAICollaborationBaseBindingV1;
    readonly policyStatus: 'verified' | 'pending' | 'denied' | 'invalid';
    readonly schemaCompatible: boolean;
    readonly runtimeCompatible: boolean;
    readonly capabilityCompatible: boolean | 'unknown';
    readonly currentTargetAdmissible: boolean;
    readonly anchors: readonly ZxAICollaborationAnchorResolutionResultV1[];
}
export declare const classifyAICollaborationDrift: (input: ZxAIClassifyCollaborationDriftInputV1) => ZxAICollaborationDriftResultV1;
//# sourceMappingURL=drift.d.ts.map