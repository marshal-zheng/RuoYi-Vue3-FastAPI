import { ZxAIProposalHistoricalEnvelopeV1 } from '../proposal-branch';
import { ZxAICollaborationAdmissionReceiptV1, ZxAICollaborationBaseBindingV1, ZxAICollaborationCommitCommandV1, ZxAICollaborationCommitIncidentProofV1, ZxAICollaborationCommitReceiptV1, ZxAICollaborationDiagnosticV1, ZxAICollaborationDriftResultV1, ZxAICollaborationGraphV1, ZxAICollaborationHostPolicyPortV1, ZxAIDurableReviewEntryV1, ZxAIYjsCollaborationAdapterV1 } from './contract';
import { ZxAIReviewAuthorityReconciliationResultV1, ZxAIReviewCommitResult, ZxAIReviewHistoricalEnvelopeV1, ZxAIReviewSidecarV1 } from '../review-runtime';
export interface ZxAICollaborationCommitCommandInputV1 {
    readonly commandId: string;
    readonly graph: ZxAICollaborationGraphV1;
    readonly reconciled: ZxAIReviewAuthorityReconciliationResultV1;
    readonly currentBinding: ZxAICollaborationBaseBindingV1;
    readonly drift: ZxAICollaborationDriftResultV1;
}
export interface ZxAICommitCollaborationReviewInputV1 extends ZxAICollaborationCommitCommandInputV1 {
    readonly principalRef: string;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
    readonly logicalSequence: number;
    readonly logicalTime: number;
    readonly createProposalEnvelope: (result: Extract<ZxAIReviewCommitResult, {
        readonly status: 'committed';
    }>) => ZxAIProposalHistoricalEnvelopeV1;
    readonly adapter: ZxAIYjsCollaborationAdapterV1;
    readonly policy: ZxAICollaborationHostPolicyPortV1;
    readonly runS4Commit: () => ZxAIReviewCommitResult;
    readonly authorizeTerminal: (input: {
        readonly command: ZxAICollaborationCommitCommandV1;
        readonly principalRef: string;
        readonly artifactFingerprint: string;
        readonly resultingSidecar: ZxAIReviewSidecarV1;
        readonly commitReceipt: ZxAICollaborationCommitReceiptV1;
        readonly historicalEnvelope: ZxAIReviewHistoricalEnvelopeV1;
        readonly logicalTime: number;
    }) => ZxAICollaborationAdmissionReceiptV1 | Promise<ZxAICollaborationAdmissionReceiptV1>;
}
export type ZxAICommitCollaborationReviewResultV1 = {
    readonly status: 'committed';
    readonly receipt: ZxAICollaborationCommitReceiptV1;
    readonly terminalEntry: ZxAIDurableReviewEntryV1;
    readonly incidentProof: null;
} | {
    readonly status: 'post-dispatch-incident';
    readonly receipt: ZxAICollaborationCommitReceiptV1 | null;
    readonly terminalEntry: ZxAIDurableReviewEntryV1 | null;
    readonly incidentProof: ZxAICollaborationCommitIncidentProofV1 | null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
} | {
    readonly status: 'pre-dispatch-failure' | 'pending-authorization' | 'denied' | 'rebase-required' | 'review-conflict' | 'unsupported-host' | 'commit-lost';
    readonly receipt: null;
    readonly terminalEntry: null;
    readonly incidentProof: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export declare const createAICollaborationCommitCommand: (input: ZxAICollaborationCommitCommandInputV1) => ZxAICollaborationCommitCommandV1 | null;
export declare const fingerprintAICollaborationCommitAdmissionArtifact: (input: {
    readonly command: ZxAICollaborationCommitCommandV1;
    readonly principalRef: string;
}) => string;
export declare const fingerprintAICollaborationCommitTerminalAdmissionArtifact: (input: {
    readonly command: ZxAICollaborationCommitCommandV1;
    readonly principalRef: string;
    readonly priorSidecarFingerprint: string;
    readonly resultingSidecarFingerprint: string;
    readonly dispatchAdmissionFingerprint: string;
    readonly commitReceiptFingerprint: string;
    readonly terminalArtifactFingerprint: string;
    readonly reviewArtifactFingerprint: string;
    readonly proposalHistoricalArtifactFingerprint: string;
    readonly terminalStatus: string;
    readonly logicalSequence: number;
}) => string;
export declare const commitAICollaborationReview: (input: ZxAICommitCollaborationReviewInputV1) => Promise<ZxAICommitCollaborationReviewResultV1>;
export declare const finalizeAICollaborationCommitIncident: (input: {
    readonly proof: ZxAICollaborationCommitIncidentProofV1;
    readonly adapter: ZxAIYjsCollaborationAdapterV1;
    readonly policy: ZxAICollaborationHostPolicyPortV1;
}) => Promise<"finalized" | "pending" | "invalid">;
//# sourceMappingURL=collaboration-commit.d.ts.map