import { ZxAICollaborationDiagnosticV1, ZxAICollaborationHostPolicyPortV1, ZxAIDurableReviewRecordV1, ZxAIDurableReviewRootV1, ZxAIDurableRootInputV1, ZxAIYjsCollaborationAdapterV1, ZxAIYjsRecordEnumerationV1 } from './contract';
export type ZxAIDurableRootCandidateResultV1 = {
    readonly status: 'success';
    readonly root: ZxAIDurableReviewRootV1;
    readonly admissionArtifactFingerprint: string;
} | {
    readonly status: 'failure';
    readonly root: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export type ZxAIDurableRootAdmissionArtifactInputV1 = Omit<ZxAIDurableRootInputV1, 'admission'>;
export type ZxAIDurableRootPublicationResultV1 = {
    readonly status: 'published' | 'idempotent';
    readonly root: ZxAIDurableReviewRootV1;
    readonly storageKey: string;
} | {
    readonly status: 'identity-conflict' | 'storage-conflict' | 'failure';
    readonly root: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export type ZxAIDurableRecordSetReadResultV1 = {
    readonly status: 'success';
    readonly records: readonly ZxAIDurableReviewRecordV1[];
    readonly roots: readonly ZxAIDurableReviewRootV1[];
    readonly candidateSetFingerprint: string;
} | {
    readonly status: 'storage-conflict' | 'resource-limit';
    readonly records: readonly [];
    readonly roots: readonly [];
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export declare const fingerprintAIDurableRootAdmissionArtifact: (input: ZxAIDurableRootAdmissionArtifactInputV1) => string;
export declare const createAIDurableReviewRootCandidate: (input: ZxAIDurableRootInputV1) => ZxAIDurableRootCandidateResultV1;
export declare const createAIDurableReviewRecordStorageKey: (record: ZxAIDurableReviewRecordV1) => string;
export declare const readAIDurableReviewRecordEnumeration: (enumeration: ZxAIYjsRecordEnumerationV1, expectedReviewId: string) => ZxAIDurableRecordSetReadResultV1;
export declare const publishAIDurableReviewRoot: (input: ZxAIDurableRootInputV1, adapter: ZxAIYjsCollaborationAdapterV1, verification: {
    readonly policy: ZxAICollaborationHostPolicyPortV1;
    readonly logicalTime: number;
}) => Promise<ZxAIDurableRootPublicationResultV1>;
export declare const exportAIDurableReviewRecords: (records: readonly ZxAIDurableReviewRecordV1[]) => string;
export declare const importAIDurableReviewRecords: (serialized: string, adapter: ZxAIYjsCollaborationAdapterV1) => Promise<{
    readonly status: "success";
    readonly recordCount: number;
} | {
    readonly status: "failure";
    readonly recordCount: 0;
}>;
//# sourceMappingURL=durable-root.d.ts.map