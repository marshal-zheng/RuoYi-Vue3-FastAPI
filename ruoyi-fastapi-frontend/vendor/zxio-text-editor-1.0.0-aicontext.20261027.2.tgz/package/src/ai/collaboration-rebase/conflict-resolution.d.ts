import { ZxAICollaborationAdmissionReceiptV1, ZxAICollaborationBaseBindingV1, ZxAICollaborationDiagnosticV1, ZxAICollaborationGraphV1, ZxAICollaborationHostPolicyPortV1 } from './contract';
export interface ZxAICollaborationConflictResolutionCommandV1 {
    readonly kind: 'zx-ai-collaboration-conflict-resolution-command-v1';
    readonly version: '1.0.0';
    readonly commandId: string;
    readonly reviewId: string;
    readonly sourceGraphFingerprint: string;
    readonly sourceRootFingerprint: string;
    readonly sourcePredecessorFingerprint: string;
    readonly forkEntryFingerprints: readonly string[];
    readonly disposition: 'rebase-from-current-document';
    readonly currentBaseBindingFingerprint: string;
    readonly regenerationHandoffFingerprint: string;
    readonly policyFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAICollaborationConflictResolutionAdmissionResultV1 = {
    readonly status: 'admitted';
    readonly command: ZxAICollaborationConflictResolutionCommandV1;
    readonly preservedAuditBranchRefs: readonly string[];
    readonly admissionFingerprint: string;
} | {
    readonly status: 'failure' | 'pending-authorization';
    readonly command: null;
    readonly diagnostic: ZxAICollaborationDiagnosticV1;
};
export declare const createAICollaborationConflictResolutionCommand: (input: {
    readonly commandId: string;
    readonly graph: ZxAICollaborationGraphV1;
    readonly currentBaseBinding: ZxAICollaborationBaseBindingV1;
    readonly regenerationHandoffFingerprint: string;
    readonly policyFingerprint: string;
}) => ZxAICollaborationConflictResolutionCommandV1;
export declare const fingerprintAIConflictResolutionAdmissionArtifact: (input: {
    readonly command: ZxAICollaborationConflictResolutionCommandV1;
    readonly currentBaseBinding: ZxAICollaborationBaseBindingV1;
}) => string;
export declare const admitAICollaborationConflictResolution: (input: {
    readonly graph: ZxAICollaborationGraphV1;
    readonly command: ZxAICollaborationConflictResolutionCommandV1;
    readonly currentBaseBinding: ZxAICollaborationBaseBindingV1;
    readonly admission: ZxAICollaborationAdmissionReceiptV1;
    readonly policy: ZxAICollaborationHostPolicyPortV1;
    readonly logicalTime: number;
}) => Promise<ZxAICollaborationConflictResolutionAdmissionResultV1>;
//# sourceMappingURL=conflict-resolution.d.ts.map