import { ZxAIContextPolicyV1 } from './contract';
export declare const createAIContextPolicy: (input: Omit<ZxAIContextPolicyV1, "fingerprint">) => ZxAIContextPolicyV1;
export declare const ZX_AI_WRITING_CONTEXT_POLICIES: {
    continuation: ZxAIContextPolicyV1;
    outline: ZxAIContextPolicyV1;
    brainstorm: ZxAIContextPolicyV1;
};
//# sourceMappingURL=context-policy.d.ts.map