import { JSONContent } from '@tiptap/core';
import { ZxExtensionDescriptorContract } from '../../core/ai-extension-capabilities';
import { ZxTextAnchor, ZxTextEditorDocument } from '../../document/types';
import { ZxAISnapshotPolicy } from '../contract';
export type ZxAIContextRole = 'document-identity' | 'outline' | 'elided-digest' | 'prefix' | 'suffix' | 'target';
export interface ZxAIContextSpanV1 {
    readonly blockId: string;
    readonly startOffset: number;
    readonly endOffset: number;
}
export interface ZxAIContextSourceV1 {
    readonly id: string;
    readonly text: string;
    readonly spans: readonly ZxAIContextSpanV1[];
    /** Private render coordinates, used only to trim and account for source spans. */
    readonly renderedSpans?: readonly {
        readonly start: number;
        readonly end: number;
        readonly span: ZxAIContextSpanV1;
    }[];
}
export interface ZxAIContextSourcesV1 {
    readonly kind: 'zx-ai-context-sources-v1';
    readonly sourceRevision: string;
    readonly sourceFingerprint: string;
    readonly targetFingerprint: string;
    readonly policyExcludedCount: number;
    readonly sourceBlockCount: number;
    readonly languageSample: string;
    readonly sources: Readonly<Record<ZxAIContextRole, readonly ZxAIContextSourceV1[]>>;
}
/**
 * The host's Markdown codec, usually `parseMarkdown` and `serializeMarkdown`
 * from `@zxio/text-editor/core` with the registry its editor uses. A port
 * keeps the AI facet free of the editor runtime the codec needs.
 */
export interface ZxAIMarkdownCodecV1 {
    readonly parse: (markdown: string) => JSONContent;
    readonly serialize: (content: JSONContent) => string;
}
export interface ZxAIProjectContextSourcesOptions {
    readonly document: ZxTextEditorDocument;
    readonly target: ZxTextAnchor;
    /** Renders complete non-prose blocks, such as lists and code. */
    readonly markdown: ZxAIMarkdownCodecV1;
    readonly targetFingerprint?: string;
    readonly policy?: ZxAISnapshotPolicy;
    readonly descriptors?: readonly ZxExtensionDescriptorContract[];
}
export interface ZxAIContextSegmentRuleV1 {
    readonly source: ZxAIContextRole;
    readonly priority: number;
    readonly placement: number;
    readonly minShare: number;
    readonly maxShare: number;
    readonly growWeight: number;
    readonly trim: 'head' | 'tail' | 'forbidden';
    readonly required: boolean;
    readonly completeness: 'exact' | 'partial';
    readonly emptyBehavior: 'omit' | 'error';
}
export interface ZxAIContextPolicyV1 {
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
    readonly rules: readonly ZxAIContextSegmentRuleV1[];
    readonly fallback: {
        readonly whenEmpty: ZxAIContextRole;
        readonly grow: ZxAIContextRole;
    };
}
export interface ZxAIContextTokenCounter {
    readonly id: string;
    readonly version: string;
    readonly count: (text: string) => number;
}
export interface ZxAIContextSegmentV1 {
    readonly role: ZxAIContextRole;
    readonly text: string;
    readonly spans: readonly ZxAIContextSpanV1[];
    readonly completeness: 'exact' | 'partial' | 'summary';
    readonly estimatedTokens: number;
    readonly bytes: number;
}
export interface ZxAIContextRoleReceiptV1 {
    readonly included: number;
    readonly partial: number;
    readonly omitted: number;
}
export interface ZxAIContextReceiptV1 {
    readonly sourceFingerprint: string;
    readonly policyFingerprint: string;
    readonly estimateMethod: string;
    readonly inputBudgetTokens: number;
    readonly bodyBudgetTokens: number;
    readonly estimatedTokens: number;
    readonly serializedBytes: number;
    readonly coverage: 'full-source' | 'summarized' | 'partial';
    readonly documentCovered: boolean;
    readonly sourceBlockCount: number;
    readonly includedBlockCount: number;
    readonly omittedBlockCount: number;
    readonly policyExcludedCount: number;
    readonly limitingConstraint: 'none' | 'tokens' | 'bytes';
    readonly roles: Readonly<Record<ZxAIContextRole, ZxAIContextRoleReceiptV1>>;
}
export interface ZxAIContextWindowV1 {
    readonly kind: 'zx-ai-context-window-v1';
    readonly version: 1;
    readonly sourceRevision: string;
    readonly sourceFingerprint: string;
    readonly targetFingerprint: string;
    readonly policyRef: {
        readonly id: string;
        readonly version: string;
        readonly fingerprint: string;
    };
    readonly segments: readonly ZxAIContextSegmentV1[];
    readonly receipt: ZxAIContextReceiptV1;
    readonly fingerprint: string;
}
export interface ZxAIBuildContextWindowOptions {
    readonly sources: ZxAIContextSourcesV1;
    readonly contextPolicy: ZxAIContextPolicyV1;
    readonly budget: {
        readonly bodyBudgetTokens: number;
        readonly inputBudgetTokens?: number;
        readonly maxBytes?: number;
    };
    readonly tokenCounter?: ZxAIContextTokenCounter;
}
export declare class ZxAIContextError extends Error {
    readonly code: 'context-anchor-invalid' | 'context-policy-invalid' | 'context-required-source-missing' | 'context-budget-exceeded';
    constructor(code: 'context-anchor-invalid' | 'context-policy-invalid' | 'context-required-source-missing' | 'context-budget-exceeded', message: string);
}
//# sourceMappingURL=contract.d.ts.map