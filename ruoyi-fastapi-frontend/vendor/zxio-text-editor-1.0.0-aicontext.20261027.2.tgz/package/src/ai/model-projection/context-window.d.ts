import { ZxAIBuildContextWindowOptions, ZxAIContextWindowV1 } from './contract';
export declare const buildAIContextWindow: (options: ZxAIBuildContextWindowOptions) => ZxAIContextWindowV1;
//# sourceMappingURL=context-window.d.ts.map