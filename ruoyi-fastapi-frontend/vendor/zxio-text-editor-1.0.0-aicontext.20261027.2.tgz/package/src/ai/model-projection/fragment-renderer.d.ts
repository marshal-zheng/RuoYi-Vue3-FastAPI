import { JSONContent } from '@tiptap/core';
import { ZxAIContextSourceV1, ZxAIContextSpanV1, ZxAIMarkdownCodecV1 } from './contract';
export declare const renderAIContextFragment: (node: JSONContent) => string;
export declare const renderAIContextBlock: (node: JSONContent, partial: boolean, markdown: ZxAIMarkdownCodecV1) => string;
export declare const renderAIContextSource: (node: JSONContent, partial: boolean, spans: readonly ZxAIContextSpanV1[], markdown: ZxAIMarkdownCodecV1) => Pick<ZxAIContextSourceV1, "text" | "renderedSpans">;
//# sourceMappingURL=fragment-renderer.d.ts.map