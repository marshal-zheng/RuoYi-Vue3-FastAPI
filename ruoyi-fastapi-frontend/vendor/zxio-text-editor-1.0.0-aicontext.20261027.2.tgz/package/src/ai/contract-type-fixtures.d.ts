import { ZxSemanticSnapshot } from './contract';
declare const descriptor: {
    readonly name: "typeFixture";
    readonly attrs: readonly ["tone"];
    readonly nodes: readonly ["customBlock"];
    readonly marks: readonly ["customMark"];
    readonly ai: {
        readonly nodes: {
            readonly customBlock: {
                readonly supported: true;
                readonly semanticName: "Custom block";
                readonly description: "Compile-time fixture for the complete node contract.";
                readonly addressability: "block";
                readonly readableAttrs: readonly ["tone"];
                readonly content: "mixed";
                readonly risk: "structural";
                readonly stream: "atomic";
            };
        };
        readonly marks: {
            readonly customMark: {
                readonly supported: false;
                readonly reasonCode: "requires-specialized-operation";
                readonly description: "Compile-time fixture for explicit unsupported marks.";
            };
        };
    };
};
export type ZxAIContractTypeFixture = {
    descriptor: typeof descriptor;
    snapshot: Pick<ZxSemanticSnapshot, 'contractVersion' | 'descriptorFingerprint' | 'documentRevision' | 'fingerprint' | 'manifest' | 'nodes' | 'scope' | 'selection'>;
};
export {};
//# sourceMappingURL=contract-type-fixtures.d.ts.map