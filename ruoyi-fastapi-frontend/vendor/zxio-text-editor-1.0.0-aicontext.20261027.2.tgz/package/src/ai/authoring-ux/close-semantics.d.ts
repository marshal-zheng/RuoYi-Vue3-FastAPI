export type ZxAIAuthoringEffectiveCloseStateV1 = 'composing' | 'streaming' | 'abort-requested' | 'awaiting-review' | 'error' | 'conflict' | 'anchor-lost';
export type ZxAIAuthoringCloseTriggerV1 = 'escape' | 'outside' | 'route-unmount' | 'editor-destroy';
export interface ZxAIAuthoringClosePresentationCommandV1 {
    readonly hideSurface: boolean;
    readonly discardDraft: boolean;
    readonly detachAdapter: boolean;
    readonly invalidateTarget: boolean;
    readonly requiresExplicitAbortPolicy: boolean;
    readonly preservePersistentIndicator: boolean;
    readonly authorityCommand: 'none';
}
export declare const isAIAuthoringIMEEvent: (event: {
    readonly isComposing?: boolean;
    readonly keyCode?: number;
}) => boolean;
export declare const reduceAIAuthoringClose: (input: {
    readonly state: ZxAIAuthoringEffectiveCloseStateV1;
    readonly trigger: ZxAIAuthoringCloseTriggerV1;
    readonly isComposing?: boolean;
    readonly keyCode?: number;
}) => ZxAIAuthoringClosePresentationCommandV1;
//# sourceMappingURL=close-semantics.d.ts.map