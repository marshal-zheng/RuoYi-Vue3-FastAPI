import { ZxAIAuthoringActionIdV1, ZxAIAuthoringErrorCategoryV1, ZxAIAuthoringErrorV1 } from './contract';
import { ZxAISessionArtifactV1 } from '../session-transport';
export declare const AI_AUTHORING_ACTION_IDS_V1: readonly ["submit", "stop", "retry", "restart", "supersede", "follow-up", "reveal", "review-previous", "review-next", "review-decide", "review-accept-all", "review-reject-all", "review-commit", "review-regenerate", "review-refine", "retry-review-refine", "close", "edit-prompt", "reselect-target", "narrow-scope", "choose-supported-command", "contact-host"];
export interface ZxAIAuthoringErrorInputV1 {
    readonly category: ZxAIAuthoringErrorCategoryV1;
    readonly code: string;
    readonly stage: string;
    readonly authorityRefs: readonly string[];
    readonly safeDetails?: Readonly<Record<string, string | number | boolean>>;
    readonly candidateActionIds?: readonly ZxAIAuthoringActionIdV1[];
    readonly availableActionIds: readonly ZxAIAuthoringActionIdV1[];
}
export declare const mapAIAuthoringError: (input: ZxAIAuthoringErrorInputV1) => {
    readonly status: "success";
    readonly error: ZxAIAuthoringErrorV1;
} | {
    readonly status: "failure";
    readonly code: "error-input-invalid";
};
export interface ZxAISessionTerminalErrorInputV1 {
    readonly session: ZxAISessionArtifactV1;
    readonly stage: string;
    readonly availableActionIds: readonly ZxAIAuthoringActionIdV1[];
}
/**
 * The one mapping from a Session terminal to the error a surface shows. It
 * reads the attempt the Session projection points at, so a later request
 * clears the error without host bookkeeping; attempt ids sort as strings, so
 * the last array entry is not the latest attempt. Returns `undefined` while
 * that attempt runs and for terminals that are not failures (`succeeded`,
 * `aborted`, `superseded`). Offered actions are candidates only; the
 * projection decides which of them the Session currently permits.
 */
export declare const mapAISessionTerminalToAuthoringErrorV1: (input: ZxAISessionTerminalErrorInputV1) => ZxAIAuthoringErrorV1 | undefined;
export declare const decodeAIAuthoringActionId: (input: unknown) => ZxAIAuthoringActionIdV1 | null;
export declare const isSafeAIAuthoringErrorCode: (value: unknown) => value is string;
//# sourceMappingURL=error-model.d.ts.map