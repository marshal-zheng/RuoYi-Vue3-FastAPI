import { ZxAIAuthoringGeometryAnchorV1, ZxAIAuthoringHostOwnerV1, ZxAIAuthoringInvocationContextV1, ZxAIAuthoringPresentationSnapshotV1, ZxAIAuthoringSurfaceV1 } from './contract';
import { ActionState } from '@zxio/keybindings/core';
/** Package default for descriptor documentation; UI renders effective runtime bindings. */
export declare const ASK_AI_SHORTCUT_CHORD_V1: string;
export declare const ASK_AI_BRIDGE_KIND_V1: "zx-ask-ai-bridge-v1";
export declare const ASK_AI_SLASH_CATALOG_ID_V1: "ai.ask";
export declare const ASK_AI_BUBBLE_CONTRIBUTION_ID_V1: "ai.ask.bubble";
export declare const ASK_AI_BLOCK_MENU_ITEM_ID_V1: "ai.ask";
export declare const ASK_AI_CLICK_DRAG_THRESHOLD_PX_V1: 4;
export interface ZxAskAIBridgeOpenInputV1 {
    readonly surface: ZxAIAuthoringSurfaceV1;
    readonly blockIds?: readonly string[];
    readonly geometry?: ZxAIAuthoringGeometryAnchorV1;
    readonly draftPrompt?: string;
    readonly invokerToken?: string;
}
export interface ZxAskAIBridgeCaptureInputV1 {
    readonly surface: ZxAIAuthoringSurfaceV1;
    readonly blockIds?: readonly string[];
}
export type ZxAskAIBridgeCaptureResultV1 = ZxAIAuthoringInvocationContextV1 | null | undefined;
export interface ZxAskAIBridgeOptionsV1 {
    readonly owner: ZxAIAuthoringHostOwnerV1;
    readonly captureContext: (input: ZxAskAIBridgeCaptureInputV1) => Promise<ZxAskAIBridgeCaptureResultV1> | ZxAskAIBridgeCaptureResultV1;
    readonly resolveInvokerToken?: (surface: ZxAIAuthoringSurfaceV1) => string;
    readonly nowLogical?: () => number;
}
export interface ZxAskAIBridgeV1 {
    readonly kind: typeof ASK_AI_BRIDGE_KIND_V1;
    getState(): ActionState;
    subscribe(listener: () => void): () => void;
    openInvocation(input: ZxAskAIBridgeOpenInputV1): Promise<ZxAIAuthoringPresentationSnapshotV1 | null>;
}
export declare const readAskAIBridge: (value: unknown) => ZxAskAIBridgeV1 | null;
/**
 * Thin chrome → S6 forwarder. Not a second command registry.
 * Capture stays host-owned; AI execution never goes through editor chain/dispatch.
 */
export declare const createAskAIBridge: (options: ZxAskAIBridgeOptionsV1) => ZxAskAIBridgeV1;
//# sourceMappingURL=ask-ai-bridge.d.ts.map