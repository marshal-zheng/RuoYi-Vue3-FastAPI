export interface ZxAIArtifactRefV1 {
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
}
export interface ZxAICommandExecutionV1 {
    readonly profileVersion: string;
    readonly parameterSchemaRef: ZxAIArtifactRefV1;
    readonly contextPolicyRef: ZxAIArtifactRefV1;
    readonly templateRef: ZxAIArtifactRefV1;
    readonly resultPolicyRef: ZxAIArtifactRefV1;
    readonly languagePolicy: 'explicit-document-prompt-ui';
    readonly generationDefaults: {
        readonly inputBudgetTokens: number;
        readonly maxOutputTokens: number;
        readonly temperature: number;
    };
}
export interface ZxAIWritingParametersV1 {
    readonly instruction: string;
    readonly language?: string;
    readonly depth?: number;
    readonly ideaCount?: number;
}
export interface ZxAIWritingParameterSchemaV1 {
    readonly id: string;
    readonly version: string;
    readonly depth?: {
        readonly min: number;
        readonly max: number;
        readonly default: number;
    };
    readonly ideaCount?: {
        readonly min: number;
        readonly max: number;
        readonly default: number;
    };
}
export interface ZxAIWritingLanguageV1 {
    readonly language: string;
    readonly reason: 'explicit' | 'document' | 'instruction' | 'locale';
}
/** One token check of the compiled messages: a counter, its count and its limit. */
export interface ZxAIWritingTokenCheckV1 {
    /** `${counter.id}:${counter.version}`. */
    readonly counterId: string;
    readonly estimatedTokens: number;
    readonly limitTokens: number;
}
/**
 * Two independent checks (C5). The target sizes the context with a typical,
 * optionally calibrated counter; the ceiling guards provider overflow with a
 * conservative counter, its safety margin already applied to the limit.
 */
export interface ZxAICompiledWritingBudgetV1 {
    readonly target: ZxAIWritingTokenCheckV1 & {
        /** The typical count before calibration, which usage is compared against. */
        readonly uncalibratedTokens: number;
        readonly calibration: {
            readonly factor: number;
            readonly samples: number;
        };
    };
    readonly ceiling: ZxAIWritingTokenCheckV1;
    readonly serializedBytes: number;
    /** The check that bounded the sent context, or `none` when all of it fit. */
    readonly limitingConstraint: 'none' | 'target' | 'ceiling' | 'bytes';
}
export interface ZxAICompiledWritingRequestV1 {
    readonly kind: 'zx-ai-compiled-writing-request-v1';
    readonly messages: readonly {
        readonly role: 'system' | 'user' | 'assistant';
        readonly content: string;
    }[];
    readonly outputFormat: 'prose' | 'nested-list' | 'numbered-list';
    readonly resultKind: 'message-only' | 'operation-envelope';
    readonly model: string;
    readonly maxOutputTokens: number;
    readonly temperature: number;
    readonly budget: ZxAICompiledWritingBudgetV1;
    readonly fingerprint: string;
}
export interface ZxAIWritingExecutionV1 {
    readonly kind: 'zx-ai-writing-execution-v1';
    readonly commandId: string;
    readonly descriptorFingerprint: string;
    readonly profile: ZxAICommandExecutionV1;
    readonly parameters: ZxAIWritingParametersV1;
    readonly sourceRevision: string;
    readonly sourceDocumentFingerprint: string;
    readonly targetFingerprint: string;
    readonly contextFingerprint: string;
    readonly language: ZxAIWritingLanguageV1;
    readonly compiledRequest: ZxAICompiledWritingRequestV1;
    readonly fingerprint: string;
}
export declare const publishWritingArtifactRef: (id: string, value: unknown, version?: string) => ZxAIArtifactRefV1;
export declare const validateAICommandExecution: (input: unknown) => input is ZxAICommandExecutionV1;
export declare const validateAIWritingParameters: (input: unknown, schema: ZxAIWritingParameterSchemaV1) => ZxAIWritingParametersV1;
export declare const publishWritingExecution: (input: Omit<ZxAIWritingExecutionV1, "fingerprint">) => ZxAIWritingExecutionV1;
export declare const validateWritingExecution: (input: unknown) => input is ZxAIWritingExecutionV1;
//# sourceMappingURL=execution-profile.d.ts.map