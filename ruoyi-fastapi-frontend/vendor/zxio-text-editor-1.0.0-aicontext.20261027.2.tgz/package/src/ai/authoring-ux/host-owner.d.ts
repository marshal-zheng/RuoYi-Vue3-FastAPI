import { ZxAIAuthoringHostOwnerOptionsV1, ZxAIAuthoringHostOwnerV1 } from './contract';
export declare const createAIAuthoringHostOwner: (options: ZxAIAuthoringHostOwnerOptionsV1) => ZxAIAuthoringHostOwnerV1;
//# sourceMappingURL=host-owner.d.ts.map