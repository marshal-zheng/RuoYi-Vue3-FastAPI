import { ZxSemanticSnapshot } from '../contract';
import { ZxAIContextWindowV1 } from '../model-projection';
import { ZxAICommandExecutionV1, ZxAIWritingExecutionV1 } from './execution-profile';
import { ZxAIProposalArtifactV1, ZxAIProposalLifecycleReceipt } from '../proposal-branch';
import { ZxAIReviewSidecarV1 } from '../review-runtime';
import { ZxAISessionArtifactV1, ZxAISessionEffectV1, ZxAISessionHandoffReceiptV1, ZxAISessionProjectionV1, ZxAISessionRequestInputV1, ZxAISessionRequestKindV1, ZxAITransportAdmissionReceiptV1, ZxAITransportDescriptorV1, ZxAITransportEventEnvelopeV1, ZxAITransportPortV1, ZxAITransportStartEffectV1 } from '../session-transport';
export declare const ZX_AI_AUTHORING_UX_CONTRACT_VERSION: "1.0.0";
export type ZxAIAuthoringContractVersion = typeof ZX_AI_AUTHORING_UX_CONTRACT_VERSION;
export type ZxAIAuthoringSurfaceV1 = 'bubble' | 'slash' | 'block-handle' | 'shortcut';
export type ZxAIAuthoringContextKindV1 = 'cursor' | 'selection' | 'block' | 'document';
export type ZxAIAuthoringProductScopeV1 = ZxAIAuthoringContextKindV1;
export interface ZxAIAuthoringCommandDescriptorV1 {
    readonly version: ZxAIAuthoringContractVersion;
    readonly commandId: string;
    readonly labelKey: string;
    readonly descriptionKey: string;
    readonly surfaces: readonly ZxAIAuthoringSurfaceV1[];
    readonly contextKinds: readonly ZxAIAuthoringContextKindV1[];
    readonly scopePolicyId: string;
    readonly capabilityPredicateId: string;
    readonly intentFactoryId: string;
    readonly execution?: ZxAICommandExecutionV1;
    readonly shortcut?: {
        readonly chord: string;
        readonly platformPolicy: 'mod';
    };
    readonly group: string;
    readonly order: number;
    readonly diagnosticTags: readonly string[];
    readonly fingerprint: string;
}
export type ZxAIAuthoringCommandAvailabilityV1 = {
    readonly status: 'enabled';
    readonly commandId: string;
} | {
    readonly status: 'disabled';
    readonly commandId: string;
    readonly reasonCode: string;
    readonly messageKey: string;
    readonly recoveryHintId?: string;
};
export interface ZxAIAuthoringCommandRegistryV1 {
    readonly kind: 'zx-ai-authoring-command-registry-v1';
    readonly version: ZxAIAuthoringContractVersion;
    readonly descriptors: readonly ZxAIAuthoringCommandDescriptorV1[];
    readonly fingerprint: string;
}
export interface ZxAIAuthoringTextPositionV1 {
    readonly blockId: string;
    readonly offset: number;
}
export type ZxAIAuthoringTargetBindingV1 = {
    readonly kind: 'selection';
    readonly editorBindingId: string;
    readonly semanticSnapshotFingerprint: string;
    readonly baseDocumentFingerprint: string;
    readonly start: ZxAIAuthoringTextPositionV1;
    readonly end: ZxAIAuthoringTextPositionV1;
    readonly collapsed: boolean;
    readonly blockIds: readonly string[];
    readonly fingerprint: string;
} | {
    readonly kind: 'blocks';
    readonly editorBindingId: string;
    readonly semanticSnapshotFingerprint: string;
    readonly baseDocumentFingerprint: string;
    readonly blockIds: readonly string[];
    readonly fingerprint: string;
} | {
    readonly kind: 'document';
    readonly editorBindingId: string;
    readonly semanticSnapshotFingerprint: string;
    readonly baseDocumentFingerprint: string;
    readonly documentTargetFingerprint: string;
    readonly fingerprint: string;
};
export type ZxAIAuthoringCapabilityReceiptV1 = {
    readonly kind: 'semantic-capability';
    readonly capabilityId: string;
    readonly status: 'supported';
    readonly sourceFingerprint: string;
    readonly fingerprint: string;
} | {
    readonly kind: 'runtime-review-prerequisite';
    readonly status: 'supported';
    readonly runtimeManifestFingerprint: string;
    readonly reviewPolicyFingerprint: string;
    readonly fingerprint: string;
} | {
    readonly kind: 'transport-capability';
    readonly receipt: ZxAITransportAdmissionReceiptV1;
    readonly fingerprint: string;
};
export interface ZxAIAuthoringInvocationContextV1 {
    readonly version: ZxAIAuthoringContractVersion;
    readonly editorBindingId: string;
    readonly productScope: ZxAIAuthoringProductScopeV1;
    readonly target: ZxAIAuthoringTargetBindingV1;
    readonly semanticSnapshotRef: ZxAISessionRequestInputV1['semanticSnapshotRef'];
    readonly scopeRef: ZxAISessionRequestInputV1['scopeRef'];
    readonly baseDocumentRef: ZxAISessionRequestInputV1['baseDocumentRef'];
    readonly locale: string;
    readonly capabilityReceipts: readonly ZxAIAuthoringCapabilityReceiptV1[];
    readonly fingerprint: string;
}
export interface ZxAIAuthoringSurfaceProvenanceV1 {
    readonly surface: ZxAIAuthoringSurfaceV1;
    readonly invokerToken: string;
    readonly capturedAtLogical: number;
}
export interface ZxAIAuthoringGeometryAnchorV1 {
    readonly kind: 'virtual-rect' | 'editor-fallback' | 'mobile-sheet';
    readonly left: number;
    readonly top: number;
    readonly width: number;
    readonly height: number;
}
export interface ZxAIAuthoringPreflightCheckV1 {
    readonly checkId: string;
    readonly status: 'passed' | 'unsupported' | 'failed';
    readonly receiptFingerprint?: string;
    readonly reasonCode?: string;
}
export interface ZxAIAuthoringPreflightReceiptV1 {
    readonly version: ZxAIAuthoringContractVersion;
    readonly commandId: string;
    readonly contextFingerprint: string;
    readonly targetFingerprint: string;
    readonly scopeSummary: {
        readonly productScope: ZxAIAuthoringProductScopeV1;
        readonly blockCount: number;
        readonly impactKey: string;
        readonly targetSummary: string;
        readonly expansionRequiresConfirmation: boolean;
    };
    readonly checks: readonly ZxAIAuthoringPreflightCheckV1[];
    readonly transportAdmissionFingerprint?: string;
    readonly fingerprint: string;
}
export interface ZxAIAuthoringIntentV1 {
    readonly version: ZxAIAuthoringContractVersion;
    readonly commandId: string;
    readonly requestKind: ZxAISessionRequestKindV1;
    readonly targetFingerprint: string;
    readonly promptDigest: string;
    readonly boundedOptions: Readonly<Record<string, string | number | boolean>>;
    readonly predecessorResultDigest?: string;
    readonly preflightFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAIAuthoringActionIdV1 = 'submit' | 'stop' | 'retry' | 'restart' | 'supersede' | 'follow-up' | 'reveal' | 'review-previous' | 'review-next' | 'review-decide' | 'review-accept-all' | 'review-reject-all' | 'review-commit' | 'review-regenerate' | 'review-refine' | 'retry-review-refine' | 'close' | 'edit-prompt' | 'reselect-target' | 'narrow-scope' | 'choose-supported-command' | 'contact-host';
export type ZxAIAuthoringReviewRefinementActionIdV1 = 'review-refine' | 'retry-review-refine';
export type ZxAIAuthoringReviewRefinementFailureCodeV1 = 'successor-admission-failed' | 'successor-start-failed' | 'authority-mismatch';
/**
 * S6-owned read-only projection of public S4/S5 refinement receipts.
 *
 * The projection contains identity metadata only. Prompt, source document and
 * candidate content remain behind the host resolver boundary.
 */
export type ZxAIAuthoringReviewRefinementProjectionV1 = {
    readonly status: 'superseding-review';
    readonly sourceReviewId: string;
    readonly commandId: string;
} | {
    readonly status: 'starting-successor';
    readonly sourceReviewId: string;
    readonly handoffFingerprint: string;
} | {
    readonly status: 'successor-start-failed';
    readonly sourceReviewId: string;
    readonly handoffFingerprint: string;
    readonly failureCode: ZxAIAuthoringReviewRefinementFailureCodeV1;
    readonly retryActionId: 'retry-review-refine';
};
export type ZxAIAuthoringErrorCategoryV1 = 'transport' | 'provider-adapter' | 'validation' | 'resource-limit' | 'unsupported' | 'anchor-lost' | 'conflict' | 'abort';
export interface ZxAIAuthoringErrorV1 {
    readonly version: ZxAIAuthoringContractVersion;
    readonly category: ZxAIAuthoringErrorCategoryV1;
    readonly code: string;
    readonly stage: string;
    readonly authorityRefs: readonly string[];
    readonly messageKey: string;
    readonly allowedActionIds: readonly ZxAIAuthoringActionIdV1[];
    readonly safeDetails: Readonly<Record<string, string | number | boolean>>;
    readonly fingerprint: string;
}
export interface ZxAIAuthoringReviewBundleV1 {
    readonly receipt: ZxAISessionHandoffReceiptV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly initialSidecarFingerprint: string;
    readonly transferFingerprint: string;
}
export interface ZxAIAuthoringProjectionV1 {
    readonly version: ZxAIAuthoringContractVersion;
    readonly editorBindingId: string;
    readonly state: 'idle' | 'composing' | 'prepared' | 'starting' | 'streaming' | 'abort-requested' | 'awaiting-review' | 'error' | 'conflict' | 'stopped' | 'completed' | 'detached';
    readonly sessionRef?: {
        readonly sessionId: string;
        readonly revision: number;
        readonly fingerprint: string;
        readonly requestId?: string;
        readonly attemptId?: string;
    };
    readonly reviewRef?: {
        readonly reviewId: string;
        readonly revision: number;
        readonly fingerprint: string;
    };
    /**
     * Present only between the Review terminal handoff and successor request
     * admission. It becomes undefined once S5 owns an active successor request.
     */
    readonly reviewRefinement?: ZxAIAuthoringReviewRefinementProjectionV1;
    /**
     * Exact in-flight public action owned by the host dispatcher. Consumers use
     * this for busy/duplicate-activation semantics instead of Vue-local flags.
     */
    readonly pendingActionId?: ZxAIAuthoringActionIdV1;
    readonly targetFingerprint?: string;
    readonly previewSegments: ZxAISessionProjectionV1['assistantSegments'];
    /**
     * Exact S5 projection truncation state. Consumers must not infer this from
     * the number or byte length of the published preview segments.
     */
    readonly previewTruncated: boolean;
    readonly error?: ZxAIAuthoringErrorV1;
    readonly actions: Readonly<Record<ZxAIAuthoringActionIdV1, boolean>>;
    readonly fingerprint: string;
}
export interface ZxAIAuthoringPresentationSnapshotV1 {
    readonly surfaceOpen: boolean;
    readonly adapterAttached: boolean;
    readonly draftPrompt: string;
    readonly surface?: ZxAIAuthoringSurfaceV1;
    readonly geometryKind?: ZxAIAuthoringGeometryAnchorV1['kind'];
    readonly persistentIndicator: boolean;
    readonly projection: ZxAIAuthoringProjectionV1;
}
export interface ZxAIAuthoringActionBindingV1 {
    readonly editorBindingId: string;
    readonly projectionFingerprint: string;
    readonly sessionId?: string;
    readonly sessionRevision?: number;
    readonly sessionFingerprint?: string;
    readonly requestId?: string;
    readonly attemptId?: string;
    readonly reviewId?: string;
    readonly reviewRevision?: number;
    readonly reviewFingerprint?: string;
}
export interface ZxAIAuthoringHostReceiptV1 {
    readonly status: 'accepted' | 'idempotent' | 'busy' | 'failure' | 'unsupported' | 'fresh-projection-required';
    readonly actionId: ZxAIAuthoringActionIdV1;
    readonly projection: ZxAIAuthoringProjectionV1;
    readonly error?: ZxAIAuthoringErrorV1;
}
export interface ZxAIAuthoringRequestContextKeyV1 {
    readonly editorBindingId: string;
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
    readonly inputFingerprint: string;
    readonly effectId: string;
    readonly correlationRef: string;
    readonly transportAdmissionFingerprint: string;
}
export interface ZxAIAuthoringSemanticRequestPayloadV1 {
    readonly kind: 'zx-ai-authoring-semantic-request-payload-v1';
    readonly prompt: string;
    readonly semanticSnapshot: ZxSemanticSnapshot;
    readonly target: ZxAIAuthoringTargetBindingV1;
    readonly options: Readonly<Record<string, string | number | boolean>>;
    /** Frozen model input. Only the content-free context receipt is public. */
    readonly execution?: ZxAIWritingExecutionV1;
    readonly contextWindow?: ZxAIContextWindowV1;
    readonly predecessorResultDigest?: string;
    /**
     * Private, bounded successor context resolved by the host. This never enters
     * public projections or receipts; it lets a provider refine the exact prior
     * candidate instead of silently regenerating from the frozen source text.
     */
    readonly predecessorCandidateText?: string;
    readonly fingerprint: string;
}
export interface ZxAIAuthoringResolvedRequestContextV1 {
    readonly key: ZxAIAuthoringRequestContextKeyV1;
    readonly intentFingerprint: string;
    readonly targetFingerprint: string;
    readonly payload: ZxAIAuthoringSemanticRequestPayloadV1;
    readonly byteLength: number;
    readonly fingerprint: string;
}
export interface ZxAIAuthoringRequestContextResolverV1 {
    prepare(input: {
        readonly editorBindingId: string;
        readonly sessionId: string;
        readonly requestId: string;
        readonly inputFingerprint: string;
        readonly intentFingerprint: string;
        readonly payload: Omit<ZxAIAuthoringSemanticRequestPayloadV1, 'fingerprint'>;
    }): {
        readonly status: 'accepted';
        readonly fingerprint: string;
    } | {
        readonly status: 'failure';
        readonly code: string;
    };
    bind(input: {
        readonly key: ZxAIAuthoringRequestContextKeyV1;
    }): {
        readonly status: 'accepted';
    } | {
        readonly status: 'failure';
        readonly code: string;
    };
    resolve(key: ZxAIAuthoringRequestContextKeyV1): {
        readonly status: 'success';
        readonly context: ZxAIAuthoringResolvedRequestContextV1;
    } | {
        readonly status: 'failure';
        readonly code: string;
    };
    retain(requestId: string): void;
    releaseAttempt(effectId: string): void;
    releaseRequest(requestId: string): void;
    inspect(): {
        readonly preparedRequestCount: number;
        readonly boundEffectCount: number;
        readonly aggregatePayloadBytes: number;
        readonly limits: {
            readonly maxPreparedRequests: number;
            readonly maxBoundEffects: number;
            readonly maxPayloadBytes: number;
            readonly maxAggregatePayloadBytes: number;
        };
    };
}
export type ZxAIAuthoringTargetFreshnessV1 = {
    readonly status: 'fresh';
    readonly targetFingerprint: string;
    readonly geometryStatus: 'available' | 'lost';
} | {
    readonly status: 'anchor-lost' | 'drift' | 'conflict';
    readonly targetFingerprint: string;
    readonly reasonCode: string;
};
export interface ZxAIAuthoringTransportStartMapInputV1 {
    readonly editorBindingId: string;
    readonly session: ZxAISessionArtifactV1;
    readonly effect: Extract<ZxAISessionEffectV1, {
        readonly kind: 'transport-start';
    }>;
    readonly admission: ZxAITransportAdmissionReceiptV1;
    readonly descriptor: ZxAITransportDescriptorV1;
}
export type ZxAIAuthoringTransportStartMapResultV1 = {
    readonly status: 'success';
    readonly editorBindingId: string;
    readonly bindingFingerprint: string;
    readonly effect: ZxAITransportStartEffectV1;
} | {
    readonly status: 'failure';
    readonly error: ZxAIAuthoringErrorV1;
};
export interface ZxAIAuthoringEffectPumpReceiptV1 {
    readonly status: 'completed' | 'failure' | 'already-started';
    readonly effectId: string;
    readonly acceptedEventCount: number;
    readonly lastEvent?: ZxAITransportEventEnvelopeV1;
    readonly error?: ZxAIAuthoringErrorV1;
}
export interface ZxAIAuthoringHostOwnerV1 {
    getProjection(): ZxAIAuthoringProjectionV1;
    getPresentationSnapshot(): ZxAIAuthoringPresentationSnapshotV1;
    subscribe(listener: () => void): () => void;
    openInvocation(input: {
        readonly context: ZxAIAuthoringInvocationContextV1;
        readonly surface: ZxAIAuthoringSurfaceProvenanceV1;
        readonly geometry?: ZxAIAuthoringGeometryAnchorV1;
        readonly draftPrompt?: string;
    }): ZxAIAuthoringPresentationSnapshotV1;
    dispatch(actionId: ZxAIAuthoringActionIdV1, binding: ZxAIAuthoringActionBindingV1): Promise<ZxAIAuthoringHostReceiptV1>;
    submit(input: {
        readonly binding: ZxAIAuthoringActionBindingV1;
    }): Promise<ZxAIAuthoringHostReceiptV1>;
    stop(binding: ZxAIAuthoringActionBindingV1): Promise<ZxAIAuthoringHostReceiptV1>;
    retry(binding: ZxAIAuthoringActionBindingV1): Promise<ZxAIAuthoringHostReceiptV1>;
    restart(input: {
        readonly binding: ZxAIAuthoringActionBindingV1;
    }): Promise<ZxAIAuthoringHostReceiptV1>;
    supersede(input: {
        readonly binding: ZxAIAuthoringActionBindingV1;
    }): Promise<ZxAIAuthoringHostReceiptV1>;
    followUp(input: {
        readonly binding: ZxAIAuthoringActionBindingV1;
    }): Promise<ZxAIAuthoringHostReceiptV1>;
    reviewRefine(input: {
        readonly binding: ZxAIAuthoringActionBindingV1;
    }): Promise<ZxAIAuthoringHostReceiptV1>;
    retryReviewRefine(binding: ZxAIAuthoringActionBindingV1): Promise<ZxAIAuthoringHostReceiptV1>;
    dispatchReview(input: {
        readonly actionId: Extract<ZxAIAuthoringActionIdV1, 'review-previous' | 'review-next' | 'review-decide' | 'review-accept-all' | 'review-reject-all' | 'review-commit' | 'review-regenerate'>;
        readonly binding: ZxAIAuthoringActionBindingV1;
    }): Promise<ZxAIAuthoringHostReceiptV1>;
    attachAdapter(token: string): ZxAIAuthoringPresentationSnapshotV1;
    detachAdapter(token: string): void;
    destroyEditor(input: {
        readonly editorBindingId: string;
        readonly logicalTime: number;
    }): Promise<void>;
}
export interface ZxAIAuthoringHostOwnerOptionsV1 {
    readonly editorBindingId: string;
    readonly getSession: () => ZxAISessionArtifactV1 | null;
    readonly getReviewBundles: () => readonly ZxAIAuthoringReviewBundleV1[];
    readonly getReviewRefinement?: () => ZxAIAuthoringReviewRefinementProjectionV1 | null;
    /**
     * Whether the host can refine this review at all. Prompt validation belongs
     * to the `review-refine` dispatch; gating on draft text hides the composer
     * that collects it.
     */
    readonly canReviewRefine?: (bundle: ZxAIAuthoringReviewBundleV1) => boolean;
    readonly getTargetFreshness?: () => ZxAIAuthoringTargetFreshnessV1 | undefined;
    readonly getError?: () => ZxAIAuthoringErrorV1 | undefined;
    readonly getReviewResolutionStatus?: (bundle: ZxAIAuthoringReviewBundleV1) => 'continue-review' | 'regeneration-required' | 'reject-intent-ready' | 'whole-accept-ready' | 'accepted-no-change' | 'rebase-required' | 'regenerate-view' | 'regenerate-current-runtime' | 'unsupported-host' | 'discarded' | 'conflict' | 'invalidated' | 'superseded' | 'failure' | undefined;
    readonly dispatchAction: (actionId: ZxAIAuthoringActionIdV1, binding: ZxAIAuthoringActionBindingV1) => Promise<{
        readonly status: 'accepted' | 'idempotent' | 'busy' | 'failure' | 'unsupported';
    }>;
    readonly port?: ZxAITransportPortV1;
}
//# sourceMappingURL=contract.d.ts.map