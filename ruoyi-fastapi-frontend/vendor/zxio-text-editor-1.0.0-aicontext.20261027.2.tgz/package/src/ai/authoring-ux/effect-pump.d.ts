import { ZxAIAuthoringEffectPumpReceiptV1 } from './contract';
import { ZxAISessionArtifactV1, ZxAISessionEffectV1, ZxAISessionReviewArtifactTransferV1, ZxAITransportAdmissionReceiptV1, ZxAITransportPortV1 } from '../session-transport';
export interface ZxAIAuthoringAtomicSessionSlotV1 {
    get(): ZxAISessionArtifactV1;
    compareAndSet(expectedFingerprint: string, session: ZxAISessionArtifactV1): boolean;
    installReview?(expectedFingerprint: string, session: ZxAISessionArtifactV1, transfer: ZxAISessionReviewArtifactTransferV1): boolean;
}
export interface ZxAIAuthoringEffectPumpV1 {
    run(input: {
        readonly editorBindingId: string;
        readonly effect: Extract<ZxAISessionEffectV1, {
            readonly kind: 'transport-start';
        }>;
        readonly admission: ZxAITransportAdmissionReceiptV1;
        readonly port: ZxAITransportPortV1;
        readonly slot: ZxAIAuthoringAtomicSessionSlotV1;
        readonly handoff?: (effect: Extract<ZxAISessionEffectV1, {
            readonly kind: 'proposal-handoff';
        }>) => Promise<{
            readonly status: 'awaiting-review';
            readonly transfer: ZxAISessionReviewArtifactTransferV1;
        } | {
            readonly status: 'failure';
        }>;
        /**
         * Observes a session only after the slot has installed it atomically.
         * Consumers must not publish the same session a second time.
         */
        readonly onAccepted?: (session: ZxAISessionArtifactV1) => void;
    }): Promise<ZxAIAuthoringEffectPumpReceiptV1>;
}
export declare const createAIAuthoringEffectPump: () => ZxAIAuthoringEffectPumpV1;
//# sourceMappingURL=effect-pump.d.ts.map