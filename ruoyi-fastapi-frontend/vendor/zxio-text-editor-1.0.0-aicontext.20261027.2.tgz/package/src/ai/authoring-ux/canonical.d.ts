export declare const AI_AUTHORING_CANONICAL_LIMITS_V1: {
    maxBytes: number;
    maxDepth: number;
    maxArrayEntries: number;
    maxObjectKeys: number;
    maxTotalObjectKeys: number;
};
export declare const isAIAuthoringRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasExactAIAuthoringKeys: (value: unknown, required: readonly string[], optional?: readonly string[]) => value is Record<string, unknown>;
export declare const isSafeAIAuthoringId: (value: unknown) => value is string;
export declare const isSafeAIAuthoringKey: (value: unknown) => value is string;
export declare const isAIAuthoringFingerprint: (value: unknown) => value is string;
export declare const isSafeAIAuthoringText: (value: unknown, maxLength?: number) => value is string;
export declare const inspectAIAuthoringValue: (value: unknown, path?: string, active?: Set<object>) => string | null;
export declare const cloneAIAuthoringValue: <TValue>(value: TValue) => TValue;
export declare const fingerprintAIAuthoringDomain: (domain: string, value: unknown) => string;
export declare const canonicalAIAuthoringEqual: (left: unknown, right: unknown) => boolean;
export declare const canonicalAIAuthoringByteLength: (value: unknown) => number;
export declare const withoutAIAuthoringFingerprint: <TValue extends {
    readonly fingerprint: unknown;
}>(value: TValue) => Omit<TValue, "fingerprint">;
export declare const canonicalizeAIAuthoringScalars: (value: Readonly<Record<string, string | number | boolean>>) => Readonly<Record<string, string | number | boolean>>;
//# sourceMappingURL=canonical.d.ts.map