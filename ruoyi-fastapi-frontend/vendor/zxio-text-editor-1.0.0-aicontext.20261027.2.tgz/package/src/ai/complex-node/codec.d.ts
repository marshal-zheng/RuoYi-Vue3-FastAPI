import { ZxAIComplexNodeApplyOperationV2 } from '../contract';
import { ZxAIClosedDecodeResult, ZxAIComplexNodeAdapterRefV1, ZxAIComplexNodePreconditionsV1, ZxAIComplexNodeResourceLimitsV1 } from './contract';
export declare const decodeComplexNodeAdapterRef: (input: unknown) => ZxAIClosedDecodeResult<ZxAIComplexNodeAdapterRefV1>;
export declare const decodeComplexNodePreconditions: (input: unknown) => ZxAIClosedDecodeResult<ZxAIComplexNodePreconditionsV1>;
export declare const decodeComplexNodeApplyOperation: (input: unknown, limits: ZxAIComplexNodeResourceLimitsV1) => ZxAIClosedDecodeResult<ZxAIComplexNodeApplyOperationV2>;
//# sourceMappingURL=codec.d.ts.map