import { deepFreeze } from '../../core/canonical-json';
import { ZxAIComplexNodeResourceLimitsV1 } from './contract';
export declare const isComplexPlainRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasExactComplexKeys: (value: Record<string, unknown>, required: readonly string[], optional?: readonly string[]) => boolean;
export declare const isComplexId: (value: unknown) => value is string;
export declare const isComplexFingerprint: (value: unknown) => value is string;
export declare const fingerprintComplexDomain: (domain: string, value: unknown) => string;
export declare const canonicalComplexBytes: (value: unknown) => Uint8Array;
export declare const canonicalComplexString: (value: unknown) => string;
export declare const assertComplexResourceBounds: (value: unknown, limits: ZxAIComplexNodeResourceLimitsV1, maxBytes?: number) => void;
export declare const cloneComplexCanonical: <TValue>(value: TValue) => TValue;
export { deepFreeze };
//# sourceMappingURL=canonical.d.ts.map