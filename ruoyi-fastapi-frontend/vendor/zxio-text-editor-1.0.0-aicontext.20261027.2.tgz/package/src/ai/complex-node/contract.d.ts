import { JSONContent } from '@tiptap/core';
import { ZxTextEditorDocument } from '../../document/types';
import { ZxAICapabilityRisk, ZxAIComplexNodeApplyOperationV2, ZxAIComplexNodeMutationPlanStepV2 } from '../contract';
import { ZxAICollaborationAnchorRefV1, ZxAICollaborationBaseBindingV1 } from '../collaboration-rebase';
export declare const ZX_AI_COMPLEX_NODE_CONTRACT_VERSION: 1;
export declare const ZX_AI_COMPLEX_NODE_PLAN_CONTRACT_VERSION: 1;
export type ZxAIComplexNodeFamily = 'table' | 'list' | 'code' | 'media' | 'custom';
export type ZxAIComplexNodeStreamPolicy = 'incremental' | 'atomic' | 'none';
export type ZxAIComplexNodeCollaborationPolicy = 'stable-rebase' | 'exact-snapshot';
export type ZxAIComplexNodeLocalType = 'row' | 'cell' | 'list-item' | 'code-text' | 'media' | 'custom';
export interface ZxAIComplexNodeComponentRefV1 {
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
}
export interface ZxAIComplexNodeCompilerRefV1 extends ZxAIComplexNodeComponentRefV1 {
    readonly kind: 'complex-node-compiler';
    readonly planContractVersion: typeof ZX_AI_COMPLEX_NODE_PLAN_CONTRACT_VERSION;
}
export interface ZxAIComplexNodeHostAdmissionRefV1 extends ZxAIComplexNodeComponentRefV1 {
    readonly kind: 'trusted-adapter-admission';
}
export interface ZxAIComplexNodeAdapterRefV1 {
    readonly descriptor: string;
    readonly descriptorFingerprint: string;
    readonly nodeType: string;
    readonly adapterId: string;
    readonly adapterVersion: string;
    readonly adapterFingerprint: string;
}
export interface ZxAIComplexNodeRelativeTextBindingV1 {
    readonly blockId: string;
    readonly localType: 'row' | 'cell' | 'list-item' | 'code-text' | 'custom';
    readonly localId: string;
    readonly semanticOffset: number;
    readonly affinity: 'forward' | 'backward';
    readonly anchor: ZxAICollaborationAnchorRefV1;
}
export interface ZxAIComplexNodeLocalStructureBindingV1 {
    readonly localId: string;
    readonly nodeTypeFingerprint: string;
    readonly contentFingerprint: string;
    readonly depth: number;
    readonly parentIds: readonly string[];
    readonly previousSiblingId: string | null;
    readonly nextSiblingId: string | null;
    readonly fingerprint: string;
}
export type ZxAIComplexNodeAddressV1 = {
    readonly kind: 'stable-local';
    readonly blockId: string;
    readonly localType: ZxAIComplexNodeLocalType;
    readonly localId: string;
    readonly relativeText?: ZxAIComplexNodeRelativeTextBindingV1;
    readonly structure?: ZxAIComplexNodeLocalStructureBindingV1;
} | {
    readonly kind: 'validated-path';
    readonly blockId: string;
    readonly path: readonly number[];
    readonly ancestorFingerprint: string;
    readonly nodeTypeFingerprint: string;
    readonly contentFingerprint: string;
    readonly shapeFingerprint: string;
    readonly sourceSnapshotFingerprint: string;
};
export interface ZxAIComplexNodePreconditionsV1 {
    readonly addressFingerprint: string;
    readonly blockId: string;
    readonly nodeType: string;
    readonly contentFingerprint: string;
    readonly shapeFingerprint: string;
    readonly capabilityFingerprint: string;
}
export interface ZxAIComplexNodeResourceLimitsV1 {
    readonly maxPayloadBytes: number;
    readonly maxDepth: number;
    readonly maxKeys: number;
    readonly maxArrayLength: number;
    readonly maxStringLength: number;
    readonly maxDiagnostics: number;
    readonly maxOutputBytes: number;
    readonly timeoutMs: number;
    readonly nodeBudget: {
        readonly kind: 'table';
        readonly maxCells: number;
        readonly maxRowSpan: number;
        readonly maxColSpan: number;
    } | {
        readonly kind: 'list';
        readonly maxItems: number;
        readonly maxDepth: number;
    } | {
        readonly kind: 'code';
        readonly maxChars: number;
        readonly maxLines: number;
    } | {
        readonly kind: 'media';
        readonly maxResources: number;
        readonly maxAttrBytes: number;
    } | {
        readonly kind: 'custom';
        readonly maxComplexity: number;
    };
}
export type ZxAIComplexNodeDiagnosticCode = 'complex-registry-invalid' | 'complex-adapter-not-found' | 'complex-adapter-fingerprint-mismatch' | 'complex-operation-unsupported' | 'complex-payload-invalid' | 'complex-limit-exceeded' | 'complex-address-invalid' | 'complex-anchor-lost' | 'complex-target-ambiguous' | 'complex-target-drifted' | 'complex-capability-drifted' | 'complex-schema-invalid' | 'complex-plan-nondeterministic' | 'complex-diff-unavailable' | 'complex-resource-not-staged' | 'complex-resource-policy-denied' | 'complex-resource-receipt-invalid' | 'complex-resource-host-failed' | 'complex-custom-admission-denied' | 'complex-collaboration-conflict' | 'complex-runner-timeout' | 'complex-runner-cancelled' | 'complex-runner-malformed' | 'complex-unsupported-host';
export type ZxAIComplexNodeDiagnosticStage = 'decode' | 'registry' | 'address' | 'precondition' | 'validation' | 'compile' | 'resource' | 'stream' | 'review' | 'collaboration';
export interface ZxAIComplexNodeDiagnosticV1 {
    readonly code: ZxAIComplexNodeDiagnosticCode;
    readonly stage: ZxAIComplexNodeDiagnosticStage;
    readonly path: string;
    readonly recovery: 'reject' | 'replan' | 'regenerate' | 'reauthorize' | 'install-adapter' | 'resolve-conflict';
    readonly count?: number;
    readonly fingerprintPrefix?: string;
}
export type ZxAIClosedDecodeResult<TValue> = {
    readonly valid: true;
    readonly value: TValue;
    readonly diagnostics: readonly [];
} | {
    readonly valid: false;
    readonly value: null;
    readonly diagnostics: readonly ZxAIComplexNodeDiagnosticV1[];
};
export interface ZxAIComplexNodeValidateInputV1<TPayload> {
    readonly document: ZxTextEditorDocument;
    readonly target: JSONContent;
    readonly address: ZxAIComplexNodeAddressV1;
    readonly preconditions: ZxAIComplexNodePreconditionsV1;
    readonly payload: TPayload;
    readonly operation: string;
    readonly baseBinding?: ZxAICollaborationBaseBindingV1;
}
export interface ZxAIComplexNodeReplaceBlockEffectV1 {
    readonly kind: 'replace-block';
    readonly blockId: string;
    readonly node: JSONContent;
}
export interface ZxAIComplexNodeReplaceTextEffectV1 {
    readonly kind: 'replace-text';
    readonly blockId: string;
    readonly startOffset: number;
    readonly endOffset: number;
    readonly text: string;
}
export type ZxAIComplexNodeSemanticEffectV1 = ZxAIComplexNodeReplaceBlockEffectV1 | ZxAIComplexNodeReplaceTextEffectV1;
export interface ZxAIComplexNodeSemanticPlanFragmentV1 {
    readonly contractVersion: typeof ZX_AI_COMPLEX_NODE_PLAN_CONTRACT_VERSION;
    readonly nodeFamily: ZxAIComplexNodeFamily;
    readonly operation: string;
    readonly atomicity: 'whole-operation' | 'declared-parts';
    readonly effect: ZxAIComplexNodeSemanticEffectV1;
    readonly targetFingerprint: string;
    readonly resultFingerprint: string;
    readonly assetsMetaUnchanged: boolean;
}
export type ZxAIComplexNodeValidateResultV1 = {
    readonly valid: true;
    readonly plan: ZxAIComplexNodeSemanticPlanFragmentV1;
    readonly diagnostics: readonly [];
} | {
    readonly valid: false;
    readonly plan: null;
    readonly diagnostics: readonly ZxAIComplexNodeDiagnosticV1[];
};
export interface ZxAIComplexNodePartialInputV1 {
    readonly sequence: number;
    readonly bytes: Uint8Array;
    readonly accumulatedBytes: number;
}
export type ZxAIComplexNodePartialResultV1 = {
    readonly valid: true;
    readonly projection: unknown;
} | {
    readonly valid: false;
    readonly projection: null;
    readonly diagnostics: readonly ZxAIComplexNodeDiagnosticV1[];
};
export type ZxAIComplexNodeReviewProjectionV1 = {
    readonly kind: 'hunks';
    readonly atomicity: 'whole-operation' | 'declared-parts';
    readonly hunks: readonly ZxAIComplexNodeReviewHunkV1[];
} | {
    readonly kind: 'unavailable';
    readonly reason: 'projector-missing' | 'projector-failed' | 'over-limit' | 'ambiguous';
    readonly summary: ZxAIComplexNodeWholeOperationSummaryV1;
};
export interface ZxAIComplexNodeReviewHunkV1 {
    readonly id: string;
    readonly localId: string;
    readonly kind: 'text' | 'attrs' | 'structure' | 'resource';
    readonly summary: string;
    readonly beforeFingerprint: string | null;
    readonly afterFingerprint: string | null;
}
export interface ZxAIComplexNodeWholeOperationSummaryV1 {
    readonly nodeFamily: ZxAIComplexNodeFamily;
    readonly operation: string;
    readonly risk: ZxAICapabilityRisk;
    readonly resource: {
        readonly status: 'none' | 'verified' | 'required';
    };
    readonly atomicity: 'whole-operation' | 'declared-parts';
    readonly actions: readonly ('accept' | 'reject')[];
}
export interface ZxAIComplexNodeReviewInputV1 {
    readonly source: JSONContent;
    readonly candidate: JSONContent;
    readonly plan: ZxAIComplexNodeSemanticPlanFragmentV1;
    readonly limits: ZxAIComplexNodeResourceLimitsV1;
}
export interface ZxAIComplexNodeOperationDescriptorV1<TPayload = unknown> {
    readonly name: string;
    readonly risk: ZxAICapabilityRisk;
    readonly stream: ZxAIComplexNodeStreamPolicy;
    readonly collaboration: ZxAIComplexNodeCollaborationPolicy;
    readonly limits: ZxAIComplexNodeResourceLimitsV1;
    readonly compiler: ZxAIComplexNodeCompilerRefV1;
    decodePayload(input: unknown): ZxAIClosedDecodeResult<TPayload>;
    validate(input: ZxAIComplexNodeValidateInputV1<TPayload>): ZxAIComplexNodeValidateResultV1;
    readonly validatePartial?: (input: ZxAIComplexNodePartialInputV1) => ZxAIComplexNodePartialResultV1;
    readonly deriveReview?: (input: ZxAIComplexNodeReviewInputV1) => ZxAIComplexNodeReviewProjectionV1;
}
export interface ZxAIComplexNodeAdapterDependencyV1 {
    readonly adapterId: string;
    readonly adapterVersion: string;
    readonly adapterFingerprint: string;
}
export interface ZxAIComplexNodeAddressPolicyV1 {
    readonly stableLocalTypes: readonly ZxAIComplexNodeLocalType[];
    readonly validatedPathFallback: boolean;
}
export interface ZxAIComplexNodeAdapterDescriptorV1 {
    readonly contractVersion: typeof ZX_AI_COMPLEX_NODE_CONTRACT_VERSION;
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
    readonly component: ZxAIComplexNodeComponentRefV1;
    readonly hostAdmission: ZxAIComplexNodeHostAdmissionRefV1;
    readonly descriptor: string;
    readonly descriptorFingerprint: string;
    readonly nodeType: string;
    readonly schemaJoinKey: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
    readonly family: ZxAIComplexNodeFamily;
    readonly dependencies: readonly ZxAIComplexNodeAdapterDependencyV1[];
    readonly address: ZxAIComplexNodeAddressPolicyV1;
    readonly operations: Readonly<Record<string, ZxAIComplexNodeOperationDescriptorV1>>;
}
export interface ZxAIComplexNodeRegistryEntryV1 {
    readonly adapter: ZxAIComplexNodeAdapterRefV1;
    readonly component: ZxAIComplexNodeComponentRefV1;
    readonly hostAdmission: ZxAIComplexNodeHostAdmissionRefV1;
    readonly compilerRefs: readonly ZxAIComplexNodeCompilerRefV1[];
    readonly schemaJoinKey: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
    readonly family: ZxAIComplexNodeFamily;
    readonly address: ZxAIComplexNodeAddressPolicyV1;
    readonly operations: readonly {
        readonly name: string;
        readonly risk: ZxAICapabilityRisk;
        readonly stream: ZxAIComplexNodeStreamPolicy;
        readonly collaboration: ZxAIComplexNodeCollaborationPolicy;
        readonly limits: ZxAIComplexNodeResourceLimitsV1;
        readonly compiler: ZxAIComplexNodeCompilerRefV1;
    }[];
    readonly dependencies: readonly ZxAIComplexNodeAdapterDependencyV1[];
}
export interface ZxAIComplexNodeRegistrySnapshotV1 {
    readonly contractVersion: typeof ZX_AI_COMPLEX_NODE_CONTRACT_VERSION;
    readonly schemaFingerprint: string;
    readonly descriptorFingerprint: string;
    readonly entries: readonly ZxAIComplexNodeRegistryEntryV1[];
    readonly fingerprint: string;
}
export type ZxAIComplexNodeRegistryResultV1 = {
    readonly valid: true;
    readonly snapshot: ZxAIComplexNodeRegistrySnapshotV1;
    readonly diagnostics: readonly [];
} | {
    readonly valid: false;
    readonly snapshot: null;
    readonly diagnostics: readonly ZxAIComplexNodeDiagnosticV1[];
};
export interface ZxAIComplexNodeResourceReceiptV1 {
    readonly kind: 'zx-ai-complex-node-resource-receipt-v1';
    readonly phase: 'proposal' | 'commit';
    readonly documentRevision: string;
    readonly assetId: string;
    readonly assetFingerprint: string;
    readonly principalFingerprint: string;
    readonly adapterFingerprint: string;
    readonly policyFingerprint: string;
    readonly expiresAt: number;
    readonly nonce: string;
    readonly fingerprint: string;
}
export interface ZxAIComplexNodeRuntimeDispatchV1 {
    readonly protocolVersion: 2;
    readonly registryFingerprint: string;
    readonly adapter: ZxAIComplexNodeAdapterRefV1;
    readonly compiler: ZxAIComplexNodeCompilerRefV1;
    readonly planFragmentFingerprint: string;
    readonly resourceProfileFingerprint: string;
}
export interface ZxAIComplexNodeBoundedRunnerV1 {
    readonly isolated: true;
    run(input: {
        readonly executionId: string;
        readonly component: ZxAIComplexNodeComponentRefV1;
        readonly canonicalInput: Uint8Array;
        readonly resourceProfileFingerprint: string;
        readonly timeoutMs: number;
        readonly maxOutputBytes: number;
    }): Promise<ZxAIComplexNodeBoundedRunnerResultV1>;
    terminate(executionId: string): void;
}
export type ZxAIComplexNodeBoundedRunnerResultV1 = {
    readonly status: 'success';
    readonly canonicalOutput: Uint8Array;
} | {
    readonly status: 'timeout' | 'cancelled' | 'failure' | 'malformed' | 'over-limit';
    readonly canonicalOutput: null;
};
export interface ZxAIComplexNodeKernelInputV1 {
    readonly document: ZxTextEditorDocument;
    readonly sourceSnapshotFingerprint: string;
    readonly sourceDocumentRevision: string;
    readonly sourceDescriptorFingerprint: string;
    readonly sourceRegistryFingerprint: string;
    readonly operation: ZxAIComplexNodeApplyOperationV2;
    readonly operationIndex: number;
    readonly resourceProfileFingerprint: string;
    readonly addressResolution?: {
        readonly resolveRelativeText: (binding: ZxAIComplexNodeRelativeTextBindingV1) => {
            readonly blockId: string;
            readonly localId: string;
            readonly semanticOffset: number;
        } | null;
    };
    readonly resourceAdmission?: {
        readonly phase: 'proposal' | 'commit';
        readonly receipt: ZxAIComplexNodeResourceReceiptV1;
        readonly logicalTime: number;
        readonly principalFingerprint: string;
        readonly policyFingerprint: string;
        readonly port: ZxAIComplexNodeResourceAdmissionPortV1;
    };
}
export interface ZxAIComplexNodeResourceAdmissionPortV1 {
    verify(input: {
        readonly receipt: ZxAIComplexNodeResourceReceiptV1;
        readonly expectedPhase: 'proposal' | 'commit';
        readonly expectedDocumentRevision: string;
        readonly expectedAssetId: string;
        readonly expectedAssetFingerprint: string;
        readonly expectedPrincipalFingerprint: string;
        readonly expectedAdapterFingerprint: string;
        readonly expectedPolicyFingerprint: string;
        readonly logicalTime: number;
    }): Promise<{
        readonly status: 'verified';
        readonly receiptFingerprint: string;
    } | {
        readonly status: 'invalid' | 'expired' | 'replayed' | 'unavailable';
    }>;
}
export interface ZxAIComplexNodeCommitResourceRequestV1 {
    readonly expectedPhase: 'commit';
    readonly operationIndex: number;
    readonly documentRevision: string;
    readonly assetId: string;
    readonly assetFingerprint: string;
    readonly principalFingerprint: string;
    readonly adapterFingerprint: string;
    readonly policyFingerprint: string;
    readonly logicalTime: number;
}
export type ZxAIComplexNodeCommitResourceFailureReasonV1 = 'current-base-mismatch' | 'media-binding-invalid' | 'receipt-request-failed' | 'receipt-invalid' | 'receipt-expired' | 'receipt-replayed' | 'receipt-unavailable';
export type ZxAIComplexNodeCommitDispatchResultV1<T> = {
    readonly status: 'dispatched';
    readonly result: T;
    readonly receiptFingerprints: readonly string[];
} | {
    readonly status: 'resource-rejected';
    readonly result: null;
    readonly reason: ZxAIComplexNodeCommitResourceFailureReasonV1;
    readonly operationIndex: number | null;
    readonly receiptFingerprints: readonly [];
};
export type ZxAIComplexNodeKernelResultV1 = {
    readonly valid: true;
    readonly step: ZxAIComplexNodeMutationPlanStepV2;
    readonly diagnostics: readonly [];
} | {
    readonly valid: false;
    readonly step: null;
    readonly diagnostics: readonly ZxAIComplexNodeDiagnosticV1[];
};
export interface ZxAIComplexNodeKernelV1 {
    readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
    validateAndPlan(input: ZxAIComplexNodeKernelInputV1, runner: ZxAIComplexNodeBoundedRunnerV1): Promise<ZxAIComplexNodeKernelResultV1>;
}
export interface ZxAIComplexNodeAuthoringCommandV1 {
    readonly id: string;
    readonly adapter: ZxAIComplexNodeAdapterRefV1;
    readonly operation: string;
    readonly enabled: {
        readonly value: true;
    } | {
        readonly value: false;
        readonly reason: 'capability-missing' | 'policy-disabled' | 'target-unsupported' | 'resource-unavailable' | 'session-terminal';
    };
}
//# sourceMappingURL=contract.d.ts.map