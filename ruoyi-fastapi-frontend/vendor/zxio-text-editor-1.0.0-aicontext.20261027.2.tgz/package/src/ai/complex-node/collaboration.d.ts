import { ZxAIClassifyCollaborationDriftInputV1 } from '../collaboration-rebase/drift';
import { ZxAICollaborationRebaseExecutionPortV1 } from '../collaboration-rebase/rebase-handoff';
import { ZxAICollaborationRebaseHandoffV1, ZxAICollaborationDriftResultV1, ZxAICollaborationRebaseExecutionResultV1 } from '../collaboration-rebase';
import { ZxAIComplexNodeAddressV1, ZxAIComplexNodeCollaborationPolicy } from './contract';
export declare const classifyComplexNodeCollaboration: (input: {
    readonly address: ZxAIComplexNodeAddressV1;
    readonly policy: ZxAIComplexNodeCollaborationPolicy;
    readonly s7: ZxAIClassifyCollaborationDriftInputV1;
}) => {
    status: "unchanged" | "conflict";
    drift: ZxAICollaborationDriftResultV1;
} | {
    status: "conflict" | "surviving" | "successor-required";
    drift: ZxAICollaborationDriftResultV1;
};
/** Delegates successor creation to the delivered S7 fresh lineage owner. */
export declare const executeComplexNodeRebaseSuccessor: (input: {
    readonly address: ZxAIComplexNodeAddressV1;
    readonly handoff: ZxAICollaborationRebaseHandoffV1;
    readonly port: ZxAICollaborationRebaseExecutionPortV1;
}) => Promise< ZxAICollaborationRebaseExecutionResultV1> | Promise<{
    status: "failure";
    diagnostic: {
        code: "collaboration-rebase-unsupported";
        severity: "error";
        stage: "rebase";
        path: string;
        recovery: "resolve-conflict";
    };
}>;
//# sourceMappingURL=collaboration.d.ts.map