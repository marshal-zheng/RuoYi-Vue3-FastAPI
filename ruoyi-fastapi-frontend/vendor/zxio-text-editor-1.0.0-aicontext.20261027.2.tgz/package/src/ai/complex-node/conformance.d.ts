import { JSONContent } from '@tiptap/core';
import { ZxTextEditorDocument } from '../../document/types';
import { ZxAIComplexNodeAdapterDescriptorV1, ZxAIComplexNodeAddressV1, ZxAIComplexNodeBoundedRunnerV1, ZxAIComplexNodePreconditionsV1, ZxAIComplexNodeRegistrySnapshotV1 } from './contract';
export interface ZxAIComplexNodeConformanceFixtureV1 {
    readonly operation: string;
    readonly payload: unknown;
    readonly document: ZxTextEditorDocument;
    readonly target: JSONContent;
    readonly address: ZxAIComplexNodeAddressV1;
    readonly preconditions: ZxAIComplexNodePreconditionsV1;
}
export interface ZxAIComplexNodeConformanceReportV1 {
    readonly valid: boolean;
    readonly adapterFingerprint: string;
    readonly coveredOperations: readonly string[];
    readonly checks: readonly {
        readonly id: 'codec-round-trip' | 'validation-determinism' | 'plan-canonical' | 'stable-identity-policy' | 'resource-limits' | 'stream-policy' | 'proposal-proof-shape' | 'review-fallback' | 'collaboration-policy' | 'zero-effect-validation' | 'forbidden-live-object' | 'public-runtime-proposal' | 'public-review-sidecar' | 'fresh-artifact-binding';
        readonly status: 'passed' | 'failed';
    }[];
    readonly fingerprint: string;
}
export declare const runComplexNodeAdapterConformance: (options: {
    readonly adapter: ZxAIComplexNodeAdapterDescriptorV1;
    readonly fixtures: readonly ZxAIComplexNodeConformanceFixtureV1[];
}) => ZxAIComplexNodeConformanceReportV1;
export declare const validateComplexNodeAdapterConformanceReport: (report: ZxAIComplexNodeConformanceReportV1) => boolean;
/**
 * Extends structural adapter conformance with a real custom node.apply through
 * the public S2 bounded runner, Runtime v2, S3 Proposal, and S4 Review path.
 * The candidate registry is live only for this exact in-memory S2 plan and is
 * never entered into the host admission catalog.
 */
export declare const runComplexNodeAdapterLifecycleConformance: (options: {
    readonly adapter: ZxAIComplexNodeAdapterDescriptorV1;
    readonly fixtures: readonly ZxAIComplexNodeConformanceFixtureV1[];
    readonly createRunner: (registry: ZxAIComplexNodeRegistrySnapshotV1) => ZxAIComplexNodeBoundedRunnerV1;
}) => Promise<ZxAIComplexNodeConformanceReportV1>;
//# sourceMappingURL=conformance.d.ts.map