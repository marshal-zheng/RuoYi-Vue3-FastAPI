import { createComplexNodeDiagnostic } from './diagnostic';
import { ZxAIClosedDecodeResult, ZxAIComplexNodeAddressV1, ZxAIComplexNodeLocalStructureBindingV1 } from './contract';
import { JSONContent } from '@tiptap/core';
export declare const createComplexNodeListItemStructureBinding: (root: JSONContent, localId: string) => ZxAIComplexNodeLocalStructureBindingV1 | null;
export declare const decodeComplexNodeAddress: (input: unknown) => ZxAIClosedDecodeResult<ZxAIComplexNodeAddressV1>;
export declare const encodeComplexNodeAddress: (address: ZxAIComplexNodeAddressV1) => Uint8Array;
export declare const fingerprintComplexNodeAddress: (address: ZxAIComplexNodeAddressV1) => string;
export declare const resolveComplexNodeStableTextAddress: (input: {
    readonly address: ZxAIComplexNodeAddressV1;
    readonly expectedBlockId: string;
    readonly expectedLocalId: string;
    readonly currentCapabilityFingerprint: string;
    readonly resolveAnchor: () => {
        readonly blockId: string;
        readonly semanticOffset: number;
        readonly localId: string;
    } | null;
}) => {
    readonly status: "surviving";
    readonly semanticOffset: number;
    readonly fingerprint: string;
} | {
    readonly status: "failure";
    readonly diagnostic: ReturnType<typeof createComplexNodeDiagnostic>;
};
//# sourceMappingURL=address.d.ts.map