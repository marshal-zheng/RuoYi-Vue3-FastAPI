import { ZxAIComplexNodeAuthoringCommandV1, ZxAIComplexNodeRegistrySnapshotV1 } from './contract';
import { ZxAIAuthoringRegistryPublishResultV1 } from '../authoring-ux';
export declare const createComplexNodeAuthoringCommands: (input: {
    readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
    readonly disabled?: Readonly<Record<string, ZxAIComplexNodeAuthoringCommandV1["enabled"]>>;
}) => readonly ZxAIComplexNodeAuthoringCommandV1[];
/** Publishes S8 capabilities through the delivered S6 command registry. */
export declare const publishComplexNodeAuthoringCommandRegistry: (input: {
    readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
}) => ZxAIAuthoringRegistryPublishResultV1;
//# sourceMappingURL=authoring.d.ts.map