import { JSONContent } from '@tiptap/core';
import { ZxAIComplexNodeAdapterDescriptorV1 } from '../../contract';
export interface ZxAIComplexTableGridV1 {
    readonly valid: boolean;
    readonly width: number;
    readonly height: number;
    readonly cellCount: number;
    readonly owners: readonly (readonly string[])[];
}
export declare const buildComplexTableOccupancyMap: (table: JSONContent, limits?: {
    maxPayloadBytes: number;
    maxDepth: number;
    maxKeys: number;
    maxArrayLength: number;
    maxStringLength: number;
    maxDiagnostics: number;
    maxOutputBytes: number;
    timeoutMs: number;
    nodeBudget: {
        kind: "table";
        maxCells: number;
        maxRowSpan: number;
        maxColSpan: number;
    };
}) => ZxAIComplexTableGridV1;
export declare const repairComplexTableIdentities: (options: {
    readonly table: JSONContent;
    readonly sourceSnapshotFingerprint: string;
    readonly currentSourceSnapshotFingerprint: string;
    readonly descriptorFingerprint: string;
    readonly currentDescriptorFingerprint: string;
    readonly sourceTableFingerprint: string;
}) => {
    readonly status: "success";
    readonly table: JSONContent;
    readonly changed: boolean;
} | {
    readonly status: "failure";
    readonly table: null;
};
export declare const createTableAIAdapter: (options: {
    readonly descriptorFingerprint: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
}) => ZxAIComplexNodeAdapterDescriptorV1;
//# sourceMappingURL=index.d.ts.map