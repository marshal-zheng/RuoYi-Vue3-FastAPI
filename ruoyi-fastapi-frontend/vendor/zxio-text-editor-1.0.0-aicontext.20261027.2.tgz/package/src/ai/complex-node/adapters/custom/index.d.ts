import { ZxAIComplexNodeAdapterDependencyV1, ZxAIComplexNodeAdapterDescriptorV1, ZxAIComplexNodeAddressPolicyV1, ZxAIComplexNodeHostAdmissionRefV1, ZxAIComplexNodeOperationDescriptorV1 } from '../../contract';
export interface ZxAITrustedCustomNodeAdapterContractV1 {
    readonly id: string;
    readonly version: string;
    readonly descriptor: string;
    readonly descriptorFingerprint: string;
    readonly nodeType: string;
    readonly schemaJoinKey: string;
    readonly schemaFingerprint: string;
    readonly componentFingerprint: string;
    readonly provenanceFingerprint: string;
    readonly hostAdmission: ZxAIComplexNodeHostAdmissionRefV1;
    readonly dependencies?: readonly ZxAIComplexNodeAdapterDependencyV1[];
    readonly address: ZxAIComplexNodeAddressPolicyV1;
    readonly operations: Readonly<Record<string, ZxAIComplexNodeOperationDescriptorV1>>;
}
export declare const createTrustedCustomNodeAdapter: (contract: ZxAITrustedCustomNodeAdapterContractV1) => ZxAIComplexNodeAdapterDescriptorV1;
export declare const createCustomNodeComponentFingerprint: (id: string, version: string) => string;
export declare const CUSTOM_NODE_DEFAULT_LIMITS_V1: {
    maxPayloadBytes: number;
    maxDepth: number;
    maxKeys: number;
    maxArrayLength: number;
    maxStringLength: number;
    maxDiagnostics: number;
    maxOutputBytes: number;
    timeoutMs: number;
    nodeBudget: {
        kind: "custom";
        maxComplexity: number;
    };
};
//# sourceMappingURL=index.d.ts.map