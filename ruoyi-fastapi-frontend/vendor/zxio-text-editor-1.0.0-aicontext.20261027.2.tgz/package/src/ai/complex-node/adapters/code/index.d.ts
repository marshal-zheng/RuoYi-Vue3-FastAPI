import { ZxAIComplexNodeAdapterDescriptorV1 } from '../../contract';
export declare const normalizeComplexCodeText: (value: string) => string;
export declare const createCodeBlockAIAdapter: (options: {
    readonly descriptorFingerprint: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
}) => ZxAIComplexNodeAdapterDescriptorV1;
//# sourceMappingURL=index.d.ts.map