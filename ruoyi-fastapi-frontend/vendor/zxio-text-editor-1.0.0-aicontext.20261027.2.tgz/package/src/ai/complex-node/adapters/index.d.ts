import { ZxAIComplexNodeAdapterDescriptorV1, ZxAIComplexNodeComponentRefV1 } from '../contract';
export { buildComplexTableOccupancyMap, createTableAIAdapter, repairComplexTableIdentities, } from './table';
export { createNestedListAIAdapter } from './list';
export { createCodeBlockAIAdapter, normalizeComplexCodeText } from './code';
export { COMPLEX_MEDIA_PROFILES_V1, createMediaAIAdapter, validateComplexMediaAsset, } from './media';
export { CUSTOM_NODE_DEFAULT_LIMITS_V1, createCustomNodeComponentFingerprint, createTrustedCustomNodeAdapter, } from './custom';
export type { ZxAITrustedCustomNodeAdapterContractV1 } from './custom';
export { COMPLEX_LIMITS, createAdapterDescriptor, createComplexCompilerRef, createComplexComponentRef, createFirstPartyComplexAdmissionRef, createReplacementPlan, createTextPlan, decodeExactObject, failedValidation, passedValidation, } from './shared';
export declare const createFirstPartyComplexNodeAdapters: (options: {
    readonly descriptorFingerprint: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
}) => readonly ZxAIComplexNodeAdapterDescriptorV1[];
export declare const getComplexNodeAdapterInstalledComponents: (adapters: readonly ZxAIComplexNodeAdapterDescriptorV1[]) => readonly ZxAIComplexNodeComponentRefV1[];
//# sourceMappingURL=index.d.ts.map