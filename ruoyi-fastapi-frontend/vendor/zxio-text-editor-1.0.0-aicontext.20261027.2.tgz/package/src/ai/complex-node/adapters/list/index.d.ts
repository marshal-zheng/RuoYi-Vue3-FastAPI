import { ZxAIComplexNodeAdapterDescriptorV1 } from '../../contract';
export declare const createNestedListAIAdapter: (options: {
    readonly descriptorFingerprint: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
    readonly nodeType?: "bulletList" | "orderedList";
}) => ZxAIComplexNodeAdapterDescriptorV1;
//# sourceMappingURL=index.d.ts.map