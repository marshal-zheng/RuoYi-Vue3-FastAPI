import { ZxAssetRef } from '../../../../document/types';
import { ZxAIComplexNodeAdapterDescriptorV1 } from '../../contract';
export type ZxAIComplexMediaProfileKind = 'image' | 'attachment' | 'video' | 'audio' | 'iframe' | 'embed';
export interface ZxAIComplexMediaProfileV1 {
    readonly kind: ZxAIComplexMediaProfileKind;
    readonly nodeType: string;
    readonly assetTypes: readonly ZxAssetRef['type'][];
    readonly allowedAttrs: readonly string[];
    readonly allowedMimePrefixes: readonly string[];
    readonly maximumBytes: number;
    readonly maximumDimension: number;
    readonly fingerprint: string;
}
export declare const COMPLEX_MEDIA_PROFILES_V1: {
    image: ZxAIComplexMediaProfileV1;
    attachment: ZxAIComplexMediaProfileV1;
    video: ZxAIComplexMediaProfileV1;
    audio: ZxAIComplexMediaProfileV1;
    iframe: ZxAIComplexMediaProfileV1;
    embed: ZxAIComplexMediaProfileV1;
};
export declare const validateComplexMediaAsset: (asset: ZxAssetRef, targetProfile: ZxAIComplexMediaProfileV1) => boolean;
export declare const createMediaAIAdapter: (options: {
    readonly descriptorFingerprint: string;
    readonly schemaFingerprint: string;
    readonly provenanceFingerprint: string;
    readonly profile: ZxAIComplexMediaProfileKind;
}) => ZxAIComplexNodeAdapterDescriptorV1;
//# sourceMappingURL=index.d.ts.map