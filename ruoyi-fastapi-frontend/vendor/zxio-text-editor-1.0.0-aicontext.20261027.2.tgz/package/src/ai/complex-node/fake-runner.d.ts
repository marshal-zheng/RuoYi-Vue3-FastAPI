import { ZxAIComplexNodeBoundedRunnerV1, ZxAIComplexNodeRegistrySnapshotV1 } from './contract';
/**
 * Deterministic conformance/test port. It models a hard-terminable host realm but
 * is not a production sandbox; live hosts must supply their own isolated runner.
 */
export declare const createDeterministicComplexNodeFakeRunner: (options: {
    readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
    readonly forcedStatus?: "timeout" | "cancelled" | "failure" | "malformed" | "over-limit";
}) => ZxAIComplexNodeBoundedRunnerV1;
//# sourceMappingURL=fake-runner.d.ts.map