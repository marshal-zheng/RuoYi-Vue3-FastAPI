import { JSONContent } from '@tiptap/core';
import { ZxTextAnchor, ZxTextEditorDocument } from '../document/types';
import { ZxExtensionDescriptorContract } from '../core/ai-extension-capabilities';
import { ZxAIComplexNodeAdapterRefV1, ZxAIComplexNodeAddressV1, ZxAIComplexNodePreconditionsV1, ZxAIComplexNodeDiagnosticCode, ZxAIComplexNodeDiagnosticV1, ZxAIComplexNodeSemanticPlanFragmentV1, ZxAIComplexNodeCompilerRefV1, ZxAIComplexNodeRegistrySnapshotV1, ZxAIComplexNodeBoundedRunnerV1, ZxAIComplexNodeKernelInputV1 } from './complex-node';
export declare const ZX_AI_SEMANTIC_CONTRACT_VERSION: 1;
export declare const ZX_AI_OPERATION_PROTOCOL_VERSION: 2;
export declare const ZX_AI_NO_COMPLEX_REGISTRY_FINGERPRINT: "sha256:0000000000000000000000000000000000000000000000000000000000000000";
export type ZxAICapabilityRisk = 'read-only' | 'textual' | 'structural' | 'external-resource' | 'sensitive';
export type ZxAIStreamPolicy = 'incremental' | 'atomic' | 'none';
export type ZxAINodeAddressability = 'block' | 'nearest-block' | 'none';
export type ZxAIMarkAddressability = 'block-range' | 'none';
export type ZxAIContentProjection = 'none' | 'text' | 'inline' | 'block' | 'mixed';
export type ZxAIUnsupportedReasonCode = 'external-resource-restricted' | 'not-addressable' | 'requires-specialized-operation' | 'sensitive-content' | 'unsafe-projection';
export interface ZxAISupportedCapability<TAddressability> {
    supported: true;
    semanticName: string;
    description: string;
    addressability: TAddressability;
    readableAttrs: readonly string[];
    content: ZxAIContentProjection;
    risk: ZxAICapabilityRisk;
    stream: ZxAIStreamPolicy;
}
export interface ZxAIUnsupportedCapability {
    supported: false;
    reasonCode: ZxAIUnsupportedReasonCode;
    description: string;
}
export type ZxAINodeCapability = ZxAISupportedCapability<ZxAINodeAddressability> | ZxAIUnsupportedCapability;
export type ZxAIMarkCapability = ZxAISupportedCapability<ZxAIMarkAddressability> | ZxAIUnsupportedCapability;
export interface ZxDescriptorAICapability {
    nodes: Readonly<Record<string, ZxAINodeCapability>>;
    marks: Readonly<Record<string, ZxAIMarkCapability>>;
}
export type ZxAISemanticDiagnosticCode = 'ai-capability-invalid' | 'ai-capability-missing' | 'ai-capability-orphan' | 'ai-descriptor-ownership-conflict' | 'ai-readable-attr-outside-descriptor' | 'crypto-unavailable' | 'document-format-invalid' | 'document-version-unsupported' | 'duplicate-block-id' | 'forbidden-entry-dependency' | 'invalid-block-id' | 'manifest-drift' | 'missing-block-id' | 'platform-descriptor-drift' | 'policy-async-result' | 'policy-decision-invalid' | 'policy-determinism-mismatch' | 'policy-result-not-canonical' | 'policy-threw' | 'scope-access-denied' | 'scope-block-duplicate' | 'scope-block-not-found' | 'scope-block-unsupported' | 'selection-anchor-invalid' | 'unknown-document-node' | 'unknown-document-mark';
export interface ZxAISemanticDiagnostic {
    code: ZxAISemanticDiagnosticCode;
    severity: 'error' | 'info';
    message: string;
    descriptor?: string;
    kind?: 'node' | 'mark';
    type?: string;
    blockId?: string | null;
    attr?: string;
    inputIndex?: number;
}
export interface ZxAISemanticContractReport {
    valid: boolean;
    issues: readonly ZxAISemanticDiagnostic[];
}
export interface ZxAICapabilityConformanceReport extends ZxAISemanticContractReport {
    descriptors: readonly string[];
    nodeTypes: readonly string[];
    markTypes: readonly string[];
    capabilityCanonicalForm: string;
}
export interface ZxAINodeSchemaEntry {
    descriptor: string;
    kind: 'node';
    type: string;
    semanticName: string;
    description: string;
    addressability: ZxAINodeAddressability;
    readableAttrs: readonly string[];
    content: ZxAIContentProjection;
    risk: ZxAICapabilityRisk;
    stream: ZxAIStreamPolicy;
}
export interface ZxAIMarkSchemaEntry {
    descriptor: string;
    kind: 'mark';
    type: string;
    semanticName: string;
    description: string;
    addressability: ZxAIMarkAddressability;
    readableAttrs: readonly string[];
    content: ZxAIContentProjection;
    risk: ZxAICapabilityRisk;
    stream: ZxAIStreamPolicy;
}
export interface ZxAIUnsupportedSchemaEntry {
    descriptor: string;
    kind: 'node' | 'mark';
    type: string;
    supported: false;
    reasonCode: ZxAIUnsupportedReasonCode;
    description: string;
}
export interface ZxAISchemaManifest {
    contractVersion: typeof ZX_AI_SEMANTIC_CONTRACT_VERSION;
    descriptorFingerprint: string;
    nodes: readonly ZxAINodeSchemaEntry[];
    marks: readonly ZxAIMarkSchemaEntry[];
    unsupported: readonly ZxAIUnsupportedSchemaEntry[];
}
export type ZxAISnapshotScope = {
    kind: 'document';
} | {
    kind: 'blocks';
    blockIds: readonly string[];
} | {
    kind: 'selection';
    anchor: ZxTextAnchor;
};
export interface ZxAINormalizedTextPosition {
    blockId: string;
    offset: number;
}
export interface ZxAINormalizedSelection {
    start: ZxAINormalizedTextPosition;
    end: ZxAINormalizedTextPosition;
    collapsed: boolean;
    blockIds: readonly string[];
}
export type ZxAINormalizedScope = {
    kind: 'document';
} | {
    kind: 'blocks';
    blockIds: readonly string[];
} | {
    kind: 'selection';
    selection: ZxAINormalizedSelection;
};
export interface ZxAISnapshotLocalRelation {
    addressable: false;
    ancestorBlockId: string | null;
    role: string;
    ordinal: number;
    persistence: 'snapshot-local';
}
export interface ZxAIBlockAddress {
    blockId: string;
}
export interface ZxAIBlockRangeAddress extends ZxAIBlockAddress {
    startOffset: number;
    endOffset: number;
}
export interface ZxAISemanticMark {
    type: string;
    semanticName: string;
    attrs: Readonly<Record<string, unknown>>;
    address: ZxAIBlockRangeAddress | null;
}
export interface ZxAISemanticNode {
    type: string;
    semanticName: string;
    operability: 'operable' | 'context-only';
    address: ZxAIBlockAddress | ZxAIBlockRangeAddress | null;
    relation: ZxAISnapshotLocalRelation | null;
    attrs: Readonly<Record<string, unknown>>;
    text?: string;
    marks: readonly ZxAISemanticMark[];
    children: readonly ZxAISemanticNode[];
}
export interface ZxSemanticSnapshot {
    contractVersion: typeof ZX_AI_SEMANTIC_CONTRACT_VERSION;
    documentVersion: 2;
    schemaVersion: string | null;
    documentRevision: string;
    fingerprint: string;
    descriptorFingerprint: string;
    scope: ZxAINormalizedScope;
    selection: ZxAINormalizedSelection | null;
    manifest: ZxAISchemaManifest;
    nodes: readonly ZxAISemanticNode[];
    operableBlockIds: readonly string[];
    diagnostics: readonly ZxAISemanticDiagnostic[];
}
export type ZxAINodePolicyDecision = {
    action: 'include';
} | {
    action: 'omit';
};
export type ZxAIAttrPolicyDecision = {
    action: 'include';
} | {
    action: 'omit';
} | {
    action: 'replace';
    value: unknown;
};
export type ZxAITextPolicyDecision = {
    action: 'include';
} | {
    action: 'omit';
} | {
    action: 'replace';
    value: string;
};
export interface ZxAINodePolicyContext {
    phase: 'manifest' | 'snapshot';
    descriptor: string;
    type: string;
    kind: 'node' | 'mark';
    blockId: string | null;
}
export interface ZxAIAttrPolicyContext extends ZxAINodePolicyContext {
    attr: string;
    value: unknown;
}
export interface ZxAITextPolicyContext {
    phase: 'snapshot';
    descriptor: string;
    type: string;
    blockId: string | null;
    value: string;
}
export interface ZxAISnapshotPolicy {
    id: string;
    version: string;
    node?: (context: ZxAINodePolicyContext) => ZxAINodePolicyDecision;
    attr?: (context: ZxAIAttrPolicyContext) => ZxAIAttrPolicyDecision;
    text?: (context: ZxAITextPolicyContext) => ZxAITextPolicyDecision;
}
export interface ZxAIBuildSemanticSnapshotOptions {
    document: ZxTextEditorDocument;
    scope: ZxAISnapshotScope;
    policy?: ZxAISnapshotPolicy;
    descriptors?: readonly ZxExtensionDescriptorContract[];
}
export interface ZxAIReferenceProvenance {
    id: string;
    repository: 'BlockNote' | 'Plate' | 'Novel';
    commit: string;
    sourcePath: string;
    decision: 'copy' | 'adapt' | 'reject';
    zxuiAdaptation: string;
    fixtureIds: readonly string[];
}
export type ZxAICanonicalDocumentNode = JSONContent;
export interface ZxAIOperationSource {
    snapshotFingerprint: string;
    documentRevision: string;
    descriptorFingerprint: string;
    registryFingerprint: string;
}
export interface ZxAIOperationBlockAddress {
    blockId: string;
}
export interface ZxAIOperationTextAddress extends ZxAIOperationBlockAddress {
    startOffset: number;
    endOffset: number;
}
export interface ZxAIOperationReferenceAddress extends ZxAIOperationBlockAddress {
    side: 'before' | 'after';
}
export interface ZxAIOperationPrecondition {
    blockId: string;
    type: string;
    contentFingerprint: string;
}
export interface ZxAITextReplaceOperation {
    kind: 'text.replace';
    target: ZxAIOperationTextAddress;
    precondition: ZxAIOperationPrecondition;
    text: string;
}
export interface ZxAIBlockInsertOperation {
    kind: 'block.insert';
    reference: ZxAIOperationReferenceAddress;
    precondition: ZxAIOperationPrecondition;
    block: ZxAICanonicalDocumentNode;
}
export interface ZxAIBlockReplaceOperation {
    kind: 'block.replace';
    target: ZxAIOperationBlockAddress;
    precondition: ZxAIOperationPrecondition;
    block: ZxAICanonicalDocumentNode;
}
export interface ZxAIBlockDeleteOperation {
    kind: 'block.delete';
    target: ZxAIOperationBlockAddress;
    precondition: ZxAIOperationPrecondition;
}
export interface ZxAIComplexNodeApplyOperationV2 {
    kind: 'node.apply';
    adapter: ZxAIComplexNodeAdapterRefV1;
    target: ZxAIComplexNodeAddressV1;
    preconditions: ZxAIComplexNodePreconditionsV1;
    operation: string;
    payload: unknown;
}
export type ZxAIDocumentOperation = ZxAITextReplaceOperation | ZxAIBlockInsertOperation | ZxAIBlockReplaceOperation | ZxAIBlockDeleteOperation | ZxAIComplexNodeApplyOperationV2;
export interface ZxAIOperationEnvelope {
    protocolVersion: typeof ZX_AI_OPERATION_PROTOCOL_VERSION;
    source: ZxAIOperationSource;
    operations: readonly ZxAIDocumentOperation[];
}
export type ZxAIOperationDiagnosticPhase = 'protocol' | 'shape' | 'source' | 'address' | 'precondition' | 'capability' | 'payload' | 'batch' | 'internal';
export type ZxAIOperationDiagnosticCode = 'protocol-envelope-invalid' | 'protocol-version-unsupported' | 'operation-kind-unsupported' | 'operation-shape-invalid' | 'snapshot-precondition-failed' | 'revision-precondition-failed' | 'descriptor-precondition-failed' | 'operation-target-not-found' | 'operation-target-not-operable' | 'operation-address-invalid' | 'operation-range-invalid' | 'operation-precondition-block-mismatch' | 'operation-type-precondition-failed' | 'operation-content-precondition-failed' | 'operation-capability-denied' | 'operation-payload-invalid' | 'operation-block-id-invalid' | 'operation-block-id-conflict' | 'operation-batch-conflict' | 'complex-node-validation-failed' | 'internal-validation-failed';
export interface ZxAIOperationDiagnostic {
    code: ZxAIOperationDiagnosticCode;
    severity: 'error';
    phase: ZxAIOperationDiagnosticPhase;
    message: string;
    operationIndex?: number;
    kind?: ZxAIDocumentOperation['kind'];
    blockId?: string;
    nodeType?: string;
    complexCode?: ZxAIComplexNodeDiagnosticCode;
    recovery?: ZxAIComplexNodeDiagnosticV1['recovery'];
}
export type ZxAIOperationPreconditionResult = {
    valid: true;
    precondition: ZxAIOperationPrecondition;
    diagnostics: readonly [];
} | {
    valid: false;
    precondition: null;
    diagnostics: readonly ZxAIOperationDiagnostic[];
};
export type ZxAITextReplaceMutationPlanStep = ZxAITextReplaceOperation & {
    operationIndex: number;
};
export type ZxAIBlockInsertMutationPlanStep = ZxAIBlockInsertOperation & {
    operationIndex: number;
};
export type ZxAIBlockReplaceMutationPlanStep = ZxAIBlockReplaceOperation & {
    operationIndex: number;
};
export type ZxAIBlockDeleteMutationPlanStep = ZxAIBlockDeleteOperation & {
    operationIndex: number;
};
export type ZxAIComplexNodeMutationPlanStepV2 = Omit<ZxAIComplexNodeApplyOperationV2, never> & {
    operationIndex: number;
    protocolVersion: 2;
    payloadFingerprint: string;
    planFragment: ZxAIComplexNodeSemanticPlanFragmentV1;
    planFragmentFingerprint: string;
    compiler: ZxAIComplexNodeCompilerRefV1;
    resourceProfileFingerprint: string;
};
export type ZxAIMutationPlanStep = ZxAITextReplaceMutationPlanStep | ZxAIBlockInsertMutationPlanStep | ZxAIBlockReplaceMutationPlanStep | ZxAIBlockDeleteMutationPlanStep | ZxAIComplexNodeMutationPlanStepV2;
export interface ZxAIMutationPlan {
    protocolVersion: typeof ZX_AI_OPERATION_PROTOCOL_VERSION;
    offsetEncoding: 'utf-16';
    source: ZxAIOperationSource;
    steps: readonly ZxAIMutationPlanStep[];
}
export type ZxAIOperationValidationResult = {
    valid: true;
    diagnostics: readonly [];
    plan: ZxAIMutationPlan;
} | {
    valid: false;
    diagnostics: readonly ZxAIOperationDiagnostic[];
    plan: null;
};
export interface ZxAIValidateOperationEnvelopeOptions {
    snapshot: ZxSemanticSnapshot;
    envelope: unknown;
    complex?: {
        readonly document: ZxTextEditorDocument;
        readonly registry: ZxAIComplexNodeRegistrySnapshotV1;
        readonly runner: ZxAIComplexNodeBoundedRunnerV1;
        readonly resourceProfileFingerprint: string;
        readonly addressResolution?: ZxAIComplexNodeKernelInputV1['addressResolution'];
        readonly resourceAdmissions?: Readonly<Record<number, NonNullable< ZxAIComplexNodeKernelInputV1['resourceAdmission']>>>;
    };
}
//# sourceMappingURL=contract.d.ts.map