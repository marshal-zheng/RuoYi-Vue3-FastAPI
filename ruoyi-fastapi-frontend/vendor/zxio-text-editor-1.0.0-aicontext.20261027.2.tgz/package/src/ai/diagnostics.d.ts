import { ZxAISemanticContractReport, ZxAISemanticDiagnostic } from './contract';
export declare const sortAISemanticDiagnostics: (diagnostics: readonly ZxAISemanticDiagnostic[]) => ZxAISemanticDiagnostic[];
export declare const createAISemanticContractReport: (issues: readonly ZxAISemanticDiagnostic[]) => ZxAISemanticContractReport;
export declare class ZxAISemanticContractError extends Error {
    readonly report: ZxAISemanticContractReport;
    constructor(report: ZxAISemanticContractReport);
}
export declare const throwAISemanticContractError: (issues: readonly ZxAISemanticDiagnostic[]) => never;
//# sourceMappingURL=diagnostics.d.ts.map