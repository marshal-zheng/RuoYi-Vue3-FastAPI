import { deepFreeze } from '../../core/canonical-json';
export declare const isReviewPresentationRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasExactReviewPresentationKeys: (value: unknown, required: readonly string[], optional?: readonly string[]) => value is Record<string, unknown>;
export declare const fingerprintReviewPresentationDomain: (domain: string, value: unknown) => string;
export declare const canonicalReviewPresentationEqual: (left: unknown, right: unknown) => boolean;
export declare const isDeepFrozenReviewPresentationValue: (value: unknown, seen?: Set<object>) => boolean;
export declare const hasWellFormedUnicode: (value: string) => boolean;
export declare const isUtf16Boundary: (value: string, offset: number) => boolean;
export { deepFreeze };
//# sourceMappingURL=canonical.d.ts.map