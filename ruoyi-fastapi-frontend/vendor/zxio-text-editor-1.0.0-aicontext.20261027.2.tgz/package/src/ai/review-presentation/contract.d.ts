import { ZxTextEditorDocument } from '../../document/types';
import { ZxSemanticSnapshot } from '../contract';
import { ZxAIAuthoringInvocationContextV1, ZxAIAuthoringProjectionV1, ZxAIAuthoringReviewBundleV1 } from '../authoring-ux/contract';
export declare const ZX_AI_REVIEW_PRESENTATION_CONTRACT_VERSION: "1.0.0";
export type ZxAIReviewPresentationBlockTypeV1 = 'paragraph' | 'heading' | 'list-paragraph';
export interface ZxAIReviewPresentationProfileV1 {
    readonly id: 'single-text-replace-v1';
    readonly version: typeof ZX_AI_REVIEW_PRESENTATION_CONTRACT_VERSION;
    readonly maxCandidateUtf16: 65_536;
    readonly maxSemanticTokens: 4_096;
    readonly maxEditGraphSteps: 1_000_000;
    readonly fingerprint: string;
}
export type ZxAIReviewPresentationSourceIdentityV1 = {
    readonly kind: 'provisional-attempt';
    readonly sessionId: string;
    readonly requestId: string;
    readonly attemptId: string;
} | {
    readonly kind: 'verified-review';
    readonly reviewId: string;
    readonly revision: number;
    readonly proposalId: string;
    readonly variantId: string;
    readonly proposalFingerprint: string;
};
export interface ZxAIReviewPresentationBaselineV1 {
    readonly kind: 'zx-ai-review-presentation-baseline-v1';
    readonly version: typeof ZX_AI_REVIEW_PRESENTATION_CONTRACT_VERSION;
    readonly editorBindingId: string;
    readonly invocationFingerprint: string;
    readonly targetFingerprint: string;
    readonly baseDocumentFingerprint: string;
    readonly blockId: string;
    readonly blockType: ZxAIReviewPresentationBlockTypeV1;
    readonly blockAttrsFingerprint: string;
    readonly blockText: string;
    readonly startOffset: number;
    readonly endOffset: number;
    readonly selectedText: string;
    readonly fingerprint: string;
}
export type ZxAIReviewPresentationSegmentV1 = {
    readonly kind: 'equal';
    readonly sourceStart: number;
    readonly sourceEnd: number;
    readonly text: string;
} | {
    readonly kind: 'removed';
    readonly sourceStart: number;
    readonly sourceEnd: number;
    readonly text: string;
} | {
    readonly kind: 'inserted';
    readonly atSourceOffset: number;
    readonly text: string;
};
export type ZxAIReviewPresentationReasonV1 = 'no-active-source' | 'no-active-candidate' | 'editor-binding-mismatch' | 'baseline-invalid' | 'unsupported-node' | 'collapsed-selection' | 'multi-block-selection' | 'source-identity-invalid' | 'projection-truncated' | 'explicit-line-break' | 'projection-budget-exceeded' | 'review-bundle-mismatch' | 'proposal-audit-failed' | 'plan-shape-unsupported' | 'target-mismatch' | 'base-verification-failed' | 'result-verification-failed' | 'operation-closure-failed' | 'rich-diff-unavailable' | 'reject-only';
export type ZxAIReviewPresentationProjectionV1 = {
    readonly status: 'empty';
    readonly reason: 'no-active-source' | 'no-active-candidate';
    readonly fingerprint: string;
} | {
    readonly status: 'provisional';
    readonly editorBindingId: string;
    readonly source: Extract<ZxAIReviewPresentationSourceIdentityV1, {
        readonly kind: 'provisional-attempt';
    }>;
    readonly baselineFingerprint: string;
    readonly candidateText: string;
    readonly segments: readonly ZxAIReviewPresentationSegmentV1[];
    readonly changeKind: 'replacement';
    readonly fingerprint: string;
} | {
    readonly status: 'verified';
    readonly editorBindingId: string;
    readonly source: Extract<ZxAIReviewPresentationSourceIdentityV1, {
        readonly kind: 'verified-review';
    }>;
    readonly baselineFingerprint: string;
    readonly candidateText: string;
    readonly segments: readonly ZxAIReviewPresentationSegmentV1[];
    readonly changeKind: 'replacement' | 'deletion' | 'no-change';
    readonly planDigest: string;
    readonly resultFingerprint: string;
    readonly fingerprint: string;
} | {
    readonly status: 'degraded';
    readonly editorBindingId: string;
    readonly source: Extract<ZxAIReviewPresentationSourceIdentityV1, {
        readonly kind: 'verified-review';
    }>;
    readonly baselineFingerprint: string;
    readonly reason: 'projection-budget-exceeded' | 'rich-diff-unavailable' | 'reject-only';
    readonly candidateText: string;
    readonly previewTruncated: true;
    readonly fingerprint: string;
} | {
    readonly status: 'unverified' | 'unsupported';
    readonly editorBindingId: string;
    readonly source: ZxAIReviewPresentationSourceIdentityV1 | {
        readonly kind: 'none';
    };
    readonly reason: Exclude<ZxAIReviewPresentationReasonV1, 'no-active-source' | 'no-active-candidate'>;
    readonly fingerprint: string;
};
export interface ZxAICreateReviewPresentationBaselineInputV1 {
    readonly exactInvocation: ZxAIAuthoringInvocationContextV1;
    readonly semanticSnapshot: ZxSemanticSnapshot;
    readonly baseDocument: ZxTextEditorDocument;
}
export type ZxAIReviewPresentationBaselineResultV1 = {
    readonly status: 'success';
    readonly baseline: ZxAIReviewPresentationBaselineV1;
} | {
    readonly status: 'failure' | 'unsupported';
    readonly reason: Exclude<ZxAIReviewPresentationReasonV1, 'no-active-source' | 'no-active-candidate'>;
};
export type ZxAIReviewPresentationChangeKindV1 = 'replacement' | 'deletion' | 'no-change';
export type ZxAIReviewPresentationSegmentationResultV1 = {
    readonly status: 'success';
    readonly changeKind: ZxAIReviewPresentationChangeKindV1;
    readonly segments: readonly ZxAIReviewPresentationSegmentV1[];
} | {
    readonly status: 'budget-exceeded';
    readonly reason: 'projection-budget-exceeded';
} | {
    readonly status: 'failure';
    readonly reason: 'baseline-invalid';
};
export interface ZxAIProjectReviewPresentationInputV1 {
    readonly profile: ZxAIReviewPresentationProfileV1;
    readonly baseline: ZxAIReviewPresentationBaselineV1;
    readonly authoring: ZxAIAuthoringProjectionV1;
    readonly exactInvocation: ZxAIAuthoringInvocationContextV1;
    readonly exactActiveReview: ZxAIAuthoringReviewBundleV1 | null;
}
//# sourceMappingURL=contract.d.ts.map