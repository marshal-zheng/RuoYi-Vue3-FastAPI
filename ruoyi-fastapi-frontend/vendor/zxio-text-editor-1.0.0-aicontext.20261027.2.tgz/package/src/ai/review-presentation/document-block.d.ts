import { ZxAIReviewPresentationBlockTypeV1 } from './contract';
export interface ZxAIReviewPresentationDocumentBlockV1 {
    readonly blockId: string;
    readonly nodeType: string;
    readonly presentationType: ZxAIReviewPresentationBlockTypeV1 | null;
    readonly attrsFingerprint: string;
    readonly text: string;
}
export declare const readReviewPresentationDocumentBlock: (document: unknown, expectedBlockId: string) => ZxAIReviewPresentationDocumentBlockV1 | null;
//# sourceMappingURL=document-block.d.ts.map