import { ZxAICreateReviewPresentationBaselineInputV1, ZxAIReviewPresentationBaselineResultV1, ZxAIReviewPresentationBaselineV1 } from './contract';
import { ZxAIAuthoringInvocationContextV1 } from '../authoring-ux';
export declare const readExactReviewPresentationInvocation: (input: unknown) => ZxAIAuthoringInvocationContextV1 | null;
export declare const createAIReviewPresentationBaselineV1: (input: ZxAICreateReviewPresentationBaselineInputV1) => ZxAIReviewPresentationBaselineResultV1;
export declare const readAIReviewPresentationBaselineV1: (input: unknown) => {
    readonly status: "success";
    readonly baseline: ZxAIReviewPresentationBaselineV1;
} | {
    readonly status: "failure";
    readonly reason: "baseline-invalid";
};
//# sourceMappingURL=baseline.d.ts.map