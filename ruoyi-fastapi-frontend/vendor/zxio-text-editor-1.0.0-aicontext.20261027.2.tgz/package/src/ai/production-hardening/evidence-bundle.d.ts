import { ProductionEvidenceBundleV1, ProductionEvidenceBindingV1, ProductionEvidenceRefV1 } from './contract';
export declare const buildProductionEvidenceBundleV1: (input: {
    readonly sourceClosure: unknown;
    readonly manifest: unknown;
    readonly receipts: readonly unknown[];
    readonly artifacts: readonly ProductionEvidenceRefV1[];
    readonly bindings: readonly ProductionEvidenceBindingV1[];
}) => ProductionEvidenceBundleV1;
export declare const verifyProductionEvidenceBundleV1: (input: unknown) => ProductionEvidenceBundleV1;
//# sourceMappingURL=evidence-bundle.d.ts.map