export type ProductionDecodeReasonV1 = 'contract-invalid' | 'fingerprint-mismatch' | 'source-closure-invalid';
export declare class ProductionContractError extends TypeError {
    readonly reason: ProductionDecodeReasonV1;
    constructor(reason: ProductionDecodeReasonV1);
}
export type ProductionRecord = Readonly<Record<string, unknown>>;
export declare const exactRecord: (input: unknown, keys: readonly string[]) => ProductionRecord;
export declare const asString: (value: unknown, options?: Readonly<{
    min?: number;
    max?: number;
    pattern?: RegExp;
}>) => string;
export declare const asNullableString: (value: unknown) => string | null;
export declare const asBoolean: (value: unknown) => boolean;
export declare const asInteger: (value: unknown, min?: number, max?: number) => number;
export declare const asNumber: (value: unknown, min?: number) => number;
export declare const asOneOf: <TValue extends string>(value: unknown, values: readonly TValue[]) => TValue;
export declare const asArray: <TValue>(value: unknown, decode: (entry: unknown, index: number) => TValue, max?: number) => readonly TValue[];
export declare const unique: <TValue>(values: readonly TValue[]) => readonly TValue[];
export declare const productionFingerprint: (domain: string, value: unknown) => string;
export declare const omitFingerprint: (record: ProductionRecord) => ProductionRecord;
export declare const verifyProductionFingerprint: (domain: string, record: ProductionRecord) => string;
export declare const decodeProductionInput: <TValue>(input: unknown, decode: (value: unknown) => TValue) => TValue;
export declare const withProductionFingerprint: <TValue extends Readonly<Record<string, unknown>>>(domain: string, value: TValue) => TValue & {
    readonly fingerprint: string;
};
//# sourceMappingURL=canonical.d.ts.map