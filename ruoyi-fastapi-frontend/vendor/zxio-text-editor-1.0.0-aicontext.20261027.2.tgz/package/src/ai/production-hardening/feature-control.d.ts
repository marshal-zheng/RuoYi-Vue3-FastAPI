import { ProductionGateIdV1 } from './contract';
import { ProductionEnvironmentClassV1 } from './workload';
export type ProductionFeatureKeyV1 = 'ai-entry' | 'session-stream' | 'review-commit' | 'collaboration-enhancement' | 'complex-node-ai' | 'telemetry-export';
export type ProductionFeatureValueV1 = 'enabled' | 'disabled';
export type ProductionFeatureScopeV1 = 'package-global' | 'host-environment' | 'opaque-cohort';
export type ProductionFeatureOwnerV1 = 'ai-platform' | 'release-operator';
export type ProductionFeatureReasonV1 = 'provider-valid' | 'provider-invalid' | 'provider-unavailable' | 'provider-expired' | 'context-mismatch';
export type ProductionFeatureAuditReasonV1 = 'incident-response' | 'reviewed-rollout' | 'scheduled-expiry';
export type ProductionApprovalSourceV1 = 'security-review' | 'release-review' | 'incident-commander';
export interface ProductionFeatureDefinitionV1 {
    readonly kind: 'zx.ai.production.feature-definition.v1';
    readonly key: ProductionFeatureKeyV1;
    readonly defaultValue: ProductionFeatureValueV1;
    readonly owner: ProductionFeatureOwnerV1;
    readonly scope: ProductionFeatureScopeV1;
    readonly temporary: boolean;
    readonly startsAtEpochSeconds: number;
    readonly expiresAtEpochSeconds: number | null;
    readonly affectedGates: readonly ProductionGateIdV1[];
    readonly fingerprint: string;
}
export interface ProductionFeatureEvaluationContextV1 {
    readonly environment: ProductionEnvironmentClassV1;
    readonly releaseChannel: 'development' | 'pr' | 'scheduled' | 'release';
    readonly cohortBucket?: string;
}
export interface ProductionFeatureDecisionReceiptV1 {
    readonly kind: 'zx.ai.production.feature-decision.v1';
    readonly definitionFingerprint: string;
    readonly hostBinding: string;
    readonly value: ProductionFeatureValueV1;
    readonly reason: ProductionFeatureReasonV1;
    readonly evaluatedAtEpochSeconds: number;
    readonly contextFingerprint: string;
    readonly fingerprint: string;
}
export interface ProductionFeatureAuditReceiptV1 {
    readonly kind: 'zx.ai.production.feature-audit.v1';
    readonly action: 'created' | 'restricted' | 'relaxed' | 'extended' | 'deleted';
    readonly key: ProductionFeatureKeyV1;
    readonly owner: ProductionFeatureOwnerV1;
    readonly reason: ProductionFeatureAuditReasonV1;
    readonly approvalSource: ProductionApprovalSourceV1;
    readonly startsAtEpochSeconds: number;
    readonly expiresAtEpochSeconds: number | null;
    readonly previousValue: ProductionFeatureValueV1 | null;
    readonly newValue: ProductionFeatureValueV1 | null;
    readonly affectedGates: readonly ProductionGateIdV1[];
    readonly fingerprint: string;
}
export interface ProductionFeatureEvaluationV1 {
    readonly kind: 'zx.ai.production.feature-evaluation.v1';
    readonly key: ProductionFeatureKeyV1;
    readonly value: ProductionFeatureValueV1;
    readonly reason: ProductionFeatureReasonV1;
    readonly providerReceiptFingerprint: string | null;
    readonly fingerprint: string;
}
export interface ProductionFeatureAuditChainVerificationV1 {
    readonly kind: 'zx.ai.production.feature-audit-chain-verification.v1';
    readonly key: ProductionFeatureKeyV1;
    readonly owner: ProductionFeatureOwnerV1;
    readonly currentValue: ProductionFeatureValueV1;
    readonly auditCount: number;
    readonly latestAuditFingerprint: string;
    readonly affectedGates: readonly ProductionGateIdV1[];
    readonly fingerprint: string;
}
export type ProductionFeaturePhaseV1 = 'pre-dispatch' | 'in-flight' | 'post-dispatch';
export interface ProductionFeaturePhaseDecisionV1 {
    readonly kind: 'zx.ai.production.feature-phase-decision.v1';
    readonly key: ProductionFeatureKeyV1;
    readonly phase: ProductionFeaturePhaseV1;
    readonly value: ProductionFeatureValueV1;
    readonly disposition: 'continue-authority-path' | 'cancel-before-dispatch' | 'abort-request' | 'stop-before-commit' | 'incident-fence';
    readonly fingerprint: string;
}
export declare const decodeProductionFeatureDefinitionV1: (input: unknown) => ProductionFeatureDefinitionV1;
export declare const decodeProductionFeatureDecisionReceiptV1: (input: unknown) => ProductionFeatureDecisionReceiptV1;
export declare const decodeProductionFeatureAuditReceiptV1: (input: unknown) => ProductionFeatureAuditReceiptV1;
export declare const verifyProductionFeatureAuditChainV1: (input: {
    readonly definition: unknown;
    readonly auditReceipts: readonly unknown[];
    readonly nowEpochSeconds: number;
}) => ProductionFeatureAuditChainVerificationV1;
export declare const evaluateProductionFeatureDecisionV1: (input: {
    readonly definition: ProductionFeatureDefinitionV1;
    readonly contextFingerprint: string;
    readonly hostBinding: string;
    readonly nowEpochSeconds: number;
    readonly providerReceipt: unknown | null;
}) => ProductionFeatureEvaluationV1;
export declare const evaluateProductionFeaturePhasePolicyV1: (input: {
    readonly key: ProductionFeatureKeyV1;
    readonly phase: ProductionFeaturePhaseV1;
    readonly value: ProductionFeatureValueV1;
}) => ProductionFeaturePhaseDecisionV1;
//# sourceMappingURL=feature-control.d.ts.map