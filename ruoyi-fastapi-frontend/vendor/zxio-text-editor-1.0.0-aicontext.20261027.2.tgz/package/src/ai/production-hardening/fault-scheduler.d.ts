export type ProductionFaultKindV1 = 'peer-connect' | 'peer-disconnect' | 'peer-restart' | 'message-delay' | 'message-reorder' | 'message-duplicate' | 'message-drop' | 'network-partition' | 'network-flush' | 'provider-gap' | 'provider-malformed' | 'provider-timeout' | 'page-offline' | 'page-online' | 'page-reload' | 'checkpoint' | 'compaction' | 'incident-fence' | 'kill-switch-transition';
export interface ProductionFaultStepV1 {
    readonly kind: 'zx.ai.production.fault-step.v1';
    readonly logicalTime: number;
    readonly fault: ProductionFaultKindV1;
    readonly peer: string | null;
    readonly inputRef: string;
    readonly outputRef: string;
    readonly fingerprint: string;
}
export interface ProductionFaultScheduleV1 {
    readonly kind: 'zx.ai.production.fault-schedule.v1';
    readonly seed: number;
    readonly steps: readonly ProductionFaultStepV1[];
    readonly fingerprint: string;
}
export interface ProductionFaultTerminalReceiptV1 {
    readonly kind: 'zx.ai.production.fault-terminal.v1';
    readonly scheduleFingerprint: string;
    readonly appliedSteps: number;
    readonly monotonicLogicalTime: boolean;
    readonly duplicateStepFingerprints: number;
    readonly stepReceipts: readonly ProductionFaultStepExecutionReceiptV1[];
    readonly authorityPreserved: boolean;
    readonly auditPreserved: boolean;
    readonly undoPreserved: boolean;
    readonly privacyPreserved: boolean;
    readonly terminalRef: string;
    readonly fingerprint: string;
}
export interface ProductionFaultStepExecutionReceiptV1 {
    readonly kind: 'zx.ai.production.fault-step-execution.v1';
    readonly stepFingerprint: string;
    readonly fault: ProductionFaultKindV1;
    readonly applied: boolean;
    readonly effect: string;
    readonly beforeFingerprint: string;
    readonly afterFingerprint: string;
    readonly terminalRef: string;
    readonly authorityPreserved: boolean;
    readonly auditPreserved: boolean;
    readonly undoPreserved: boolean;
    readonly privacyPreserved: boolean;
    readonly fingerprint: string;
}
export interface ProductionFaultExecutionPortV1 {
    apply(step: ProductionFaultStepV1): Promise<Readonly<{
        applied: boolean;
        effect: string;
        beforeFingerprint: string;
        afterFingerprint: string;
        terminalRef: string;
        authorityPreserved: boolean;
        auditPreserved: boolean;
        undoPreserved: boolean;
        privacyPreserved: boolean;
    }>>;
}
export declare const createDeterministicProductionFaultSchedulerV1: () => {
    create(input: {
        readonly seed: number;
        readonly faults: readonly ProductionFaultKindV1[];
        readonly peers: readonly string[];
        readonly inputRef: string;
    }): ProductionFaultScheduleV1;
    replay(scheduleInput: unknown): ProductionFaultTerminalReceiptV1;
    execute(scheduleInput: unknown, port: ProductionFaultExecutionPortV1): Promise<ProductionFaultTerminalReceiptV1>;
};
//# sourceMappingURL=fault-scheduler.d.ts.map