import { ProductionEvidenceManifestV1, ProductionEvidenceRefV1, ProductionGateExecutionReceiptV1, ProductionReleaseVerdictV1 } from './contract';
export declare const decodeProductionEvidenceRefV1: (input: unknown) => ProductionEvidenceRefV1;
export declare const decodeProductionEvidenceManifestV1: (input: unknown) => ProductionEvidenceManifestV1;
export declare const decodeProductionGateExecutionReceiptV1: (input: unknown) => ProductionGateExecutionReceiptV1;
export declare const evaluateProductionEvidenceV1: (input: Readonly<{
    manifest: ProductionEvidenceManifestV1;
    receipts: readonly ProductionGateExecutionReceiptV1[];
}>) => ProductionReleaseVerdictV1;
//# sourceMappingURL=gate-kernel.d.ts.map