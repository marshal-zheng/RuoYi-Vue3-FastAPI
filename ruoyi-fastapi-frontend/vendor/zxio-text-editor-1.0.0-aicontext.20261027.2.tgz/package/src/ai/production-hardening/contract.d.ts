export declare const ZX_AI_PRODUCTION_CONTRACT_VERSION: "1.0.0";
export declare const PRODUCTION_GATE_IDS_V1: readonly ["gate-0-baseline-authority", "gate-1-correctness-security", "gate-2-property-fuzz", "gate-3-collaboration-faults", "gate-4-performance-observability", "gate-5-rollout-dogfood-release"];
export type ProductionGateIdV1 = (typeof PRODUCTION_GATE_IDS_V1)[number];
export type ProductionGateStatusV1 = 'passed' | 'failed' | 'blocked' | 'not-applicable';
export type ProductionEvidenceClaimClassV1 = 'verified' | 'observation' | 'not-claimed';
export type ProductionClaimScopeV1 = 'package-candidate' | 'host-deployment';
export type ProductionReasonCodeV1 = 'all-assertions-satisfied' | 'applicability-excluded' | 'artifact-invalid' | 'assertion-failed' | 'environment-not-comparable' | 'evidence-missing' | 'feature-audit-invalid' | 'mandatory-receipt-missing' | 'receipt-conflict' | 'receipt-invalid' | 'rollout-threshold-not-met' | 'runner-blocked' | 'source-closure-invalid' | 'waiver-invalid';
export interface ProductionEvidenceRefV1 {
    readonly kind: 'zx.ai.production.evidence-ref.v1';
    readonly id: string;
    readonly mediaType: string;
    readonly bytes: number;
    readonly sha256: string;
    readonly retention: 'baseline' | 'regression-corpus' | 'run-artifact';
    readonly redaction: 'content-free' | 'redacted-and-scanned';
}
export interface ProductionRepositoryBindingV1 {
    readonly logicalName: string;
    readonly role: 'bound' | 'inventory';
    readonly pathClass: 'root' | 'independent-package';
    readonly commit: string | null;
    readonly clean: boolean | null;
    readonly dependencyReasons: readonly ('package-artifact' | 'runtime-import' | 'test-fixture' | 'evidence-tool')[];
}
export interface ProductionToolchainProfileV1 {
    readonly node: string;
    readonly pnpm: string;
    readonly platform: string;
    readonly arch: string;
    readonly runner: string;
    readonly browser: string | null;
}
export interface ProductionOwnerManifestBindingV1 {
    readonly owner: 'document' | 'schema' | 'operation' | 'runtime' | 'proposal' | 'review' | 'session' | 'collaboration' | 'complex-node';
    readonly version: string;
    readonly publicExport: string;
    readonly fingerprint: string;
}
export interface ProductionSourceClosureV1 {
    readonly kind: 'zx.ai.production.source-closure.v1';
    readonly root: ProductionRepositoryBindingV1;
    readonly textEditor: ProductionRepositoryBindingV1;
    readonly repositories: readonly ProductionRepositoryBindingV1[];
    readonly lockfileFingerprint: string;
    readonly artifactGraphFingerprint: string;
    readonly configurationFingerprint: string;
    readonly environmentProfile: string;
    readonly toolchain: ProductionToolchainProfileV1;
    readonly ownerManifests: readonly ProductionOwnerManifestBindingV1[];
    readonly fingerprint: string;
}
export interface ProductionGateResultV1 {
    readonly gate: ProductionGateIdV1;
    readonly status: ProductionGateStatusV1;
    readonly reason: ProductionReasonCodeV1;
    readonly claimScope: ProductionClaimScopeV1;
    readonly manifestFingerprint: string;
    readonly logicalStartedAt: number;
    readonly logicalFinishedAt: number;
    readonly previousGateArtifactSha256: string | null;
    readonly evidence: readonly ProductionEvidenceRefV1[];
    readonly fingerprint: string;
}
export interface ProductionEvidenceClaimV1 {
    readonly kind: 'zx.ai.production.evidence-claim.v1';
    readonly gate: ProductionGateIdV1;
    readonly claimClass: ProductionEvidenceClaimClassV1;
    readonly claimScope: ProductionClaimScopeV1;
    readonly reason: ProductionReasonCodeV1;
    readonly gateResultFingerprint: string;
    readonly fingerprint: string;
}
export interface ProductionWaiverV1 {
    readonly kind: 'zx.ai.production.waiver.v1';
    readonly gate: ProductionGateIdV1;
    readonly claimScope: ProductionClaimScopeV1;
    readonly owner: string;
    readonly risk: string;
    readonly compensation: string;
    readonly startsAtEpochSeconds: number;
    readonly expiresAtEpochSeconds: number;
    readonly fingerprint: string;
}
export interface ProductionGateDefinitionV1 {
    readonly gate: ProductionGateIdV1;
    readonly runnerId: ProductionRunnerIdV1;
    readonly mandatory: boolean;
    readonly claimScope: ProductionClaimScopeV1;
    readonly fingerprint: string;
}
export type ProductionRunnerIdV1 = 'zx-ai-production-baseline-v1' | 'zx-ai-production-correctness-v1' | 'zx-ai-production-property-v1' | 'zx-ai-production-collaboration-v1' | 'zx-ai-production-performance-v1' | 'zx-ai-production-release-v1';
export interface ProductionEvidenceManifestV1 {
    readonly kind: 'zx.ai.production.evidence-manifest.v1';
    readonly version: typeof ZX_AI_PRODUCTION_CONTRACT_VERSION;
    readonly runId: string;
    readonly claimScope: ProductionClaimScopeV1;
    readonly sourceClosureFingerprint: string;
    readonly gates: readonly ProductionGateDefinitionV1[];
    readonly applicabilityProfile: 'package-candidate-all-gates-v1' | 'host-deployment-not-claimed-v1';
    readonly applicability: readonly ProductionGateIdV1[];
    readonly waivers: readonly ProductionWaiverV1[];
    readonly evaluatedAtEpochSeconds: number;
    readonly fingerprint: string;
}
export interface ProductionRawReceiptBaseV1 {
    readonly gate: ProductionGateIdV1;
    readonly runnerId: ProductionRunnerIdV1;
    readonly runnerVersion: string;
    readonly manifestFingerprint: string;
    readonly sourceClosureFingerprint: string;
    readonly logicalStartedAt: number;
    readonly logicalFinishedAt: number;
    readonly artifactRefs: readonly ProductionEvidenceRefV1[];
    readonly previousGateArtifactSha256: string | null;
    readonly observationFingerprints: readonly string[];
    readonly measurementFacts: readonly ProductionMeasurementFactV1[];
    readonly runId: string;
    readonly runnerBlocked: boolean;
    readonly fingerprint: string;
}
export type ProductionMeasurementFactCategoryV1 = 'source-closure' | 'public-authority' | 'correctness-case' | 'resource-control' | 'security-control' | 'domain-property' | 'shrink-replay' | 'corpus-promotion' | 'fault-schedule' | 'terminal-state' | 'peer-convergence' | 'durable-recovery' | 'single-undo' | 'workload-stage' | 'performance-budget' | 'privacy-scan' | 'telemetry-cardinality' | 'rollout-shadow' | 'rollback-drill' | 'workbench-persona' | 'docs-contract' | 'independent-verifier';
export interface ProductionMeasurementFactV1 {
    readonly kind: 'zx.ai.production.measurement-fact.v1';
    readonly id: string;
    readonly category: ProductionMeasurementFactCategoryV1;
    readonly artifactRefId: string;
    readonly inputFingerprint: string;
    readonly outputFingerprint: string;
    readonly observedCount: number;
    readonly failureCount: number;
    readonly fingerprint: string;
}
export type ProductionEvidenceBindingCategoryV1 = 'workload-profile' | 'fixture' | 'seed-corpus' | 'feature-definition' | 'feature-decision' | 'feature-audit' | 'rollout-policy' | 'rollout-receipt' | 'rollout-decision' | 'rollback-drill' | 'reference-receipt' | 'fault-scenario' | 'workbench-receipt' | 'privacy-scan' | 'command';
export interface ProductionEvidenceBindingV1 {
    readonly kind: 'zx.ai.production.evidence-binding.v1';
    readonly category: ProductionEvidenceBindingCategoryV1;
    readonly id: string;
    readonly fingerprint: string;
}
export type ProductionGateReceiptKindV1 = 'zx.ai.production.gate-0.raw.v1' | 'zx.ai.production.gate-1.raw.v1' | 'zx.ai.production.gate-2.raw.v1' | 'zx.ai.production.gate-3.raw.v1' | 'zx.ai.production.gate-4.raw.v1' | 'zx.ai.production.gate-5.raw.v1';
export interface ProductionBaselineRawReceiptV1 extends ProductionRawReceiptBaseV1 {
    readonly kind: 'zx.ai.production.gate-0.raw.v1';
    readonly gate: 'gate-0-baseline-authority';
    readonly runnerId: 'zx-ai-production-baseline-v1';
    readonly repositoryBindingCount: number;
    readonly sourceClosureMatched: boolean;
    readonly publicAuthorityMatched: boolean;
    readonly sourceBoundaryViolationCount: number;
}
export interface ProductionCorrectnessSecurityRawReceiptV1 extends ProductionRawReceiptBaseV1 {
    readonly kind: 'zx.ai.production.gate-1.raw.v1';
    readonly gate: 'gate-1-correctness-security';
    readonly runnerId: 'zx-ai-production-correctness-v1';
    readonly caseCount: number;
    readonly correctnessFailureCount: number;
    readonly resourceControlFailureCount: number;
    readonly securityControlFailureCount: number;
}
export interface ProductionPropertyFuzzRawReceiptV1 extends ProductionRawReceiptBaseV1 {
    readonly kind: 'zx.ai.production.gate-2.raw.v1';
    readonly gate: 'gate-2-property-fuzz';
    readonly runnerId: 'zx-ai-production-property-v1';
    readonly seedCount: number;
    readonly propertyRunCount: number;
    readonly propertyFailureCount: number;
    readonly nonReproducibleFailureCount: number;
    readonly authorityPathFailureCount: number;
}
export interface ProductionCollaborationFaultRawReceiptV1 extends ProductionRawReceiptBaseV1 {
    readonly kind: 'zx.ai.production.gate-3.raw.v1';
    readonly gate: 'gate-3-collaboration-faults';
    readonly runnerId: 'zx-ai-production-collaboration-v1';
    readonly peerCount: number;
    readonly scheduleCount: number;
    readonly convergenceFailureCount: number;
    readonly recoveryFailureCount: number;
    readonly undoFailureCount: number;
}
export interface ProductionPerformanceObservabilityRawReceiptV1 extends ProductionRawReceiptBaseV1 {
    readonly kind: 'zx.ai.production.gate-4.raw.v1';
    readonly gate: 'gate-4-performance-observability';
    readonly runnerId: 'zx-ai-production-performance-v1';
    readonly profileCount: number;
    readonly environmentComparable: boolean;
    readonly authorityPathFailureCount: number;
    readonly budgetViolationCount: number;
    readonly privacyLeakCount: number;
    readonly cardinalityViolationCount: number;
}
export interface ProductionRolloutDogfoodRawReceiptV1 extends ProductionRawReceiptBaseV1 {
    readonly kind: 'zx.ai.production.gate-5.raw.v1';
    readonly gate: 'gate-5-rollout-dogfood-release';
    readonly runnerId: 'zx-ai-production-release-v1';
    readonly rolloutDecision: 'advance' | 'hold' | 'rollback' | 'blocked';
    readonly featureAuditValid: boolean;
    readonly rollbackDrillPassed: boolean;
    readonly workbenchPersonasPassed: number;
    readonly requiredWorkbenchPersonas: number;
    readonly docsValid: boolean;
    readonly independentVerifierValid: boolean;
}
export type ProductionGateExecutionReceiptV1 = ProductionBaselineRawReceiptV1 | ProductionCorrectnessSecurityRawReceiptV1 | ProductionPropertyFuzzRawReceiptV1 | ProductionCollaborationFaultRawReceiptV1 | ProductionPerformanceObservabilityRawReceiptV1 | ProductionRolloutDogfoodRawReceiptV1;
export interface ProductionReleaseVerdictV1 {
    readonly kind: 'zx.ai.production.release-verdict.v1';
    readonly claimScope: ProductionClaimScopeV1;
    readonly status: 'package-production-ready' | 'not-ready' | 'not-claimed';
    readonly gates: readonly ProductionGateResultV1[];
    readonly claims: readonly ProductionEvidenceClaimV1[];
    readonly manifestFingerprint: string;
    readonly sourceClosureFingerprint: string;
    readonly fingerprint: string;
}
export interface ProductionGateExecutorPortV1 {
    execute(input: Readonly<{
        gate: ProductionGateDefinitionV1;
        manifest: ProductionEvidenceManifestV1;
    }>): Promise<ProductionGateExecutionReceiptV1>;
}
export interface ProductionEvidenceBundleV1 {
    readonly kind: 'zx.ai.production.evidence-bundle.v1';
    readonly version: '1.0.0';
    readonly claimScope: ProductionClaimScopeV1;
    readonly sourceClosure: ProductionSourceClosureV1;
    readonly manifest: ProductionEvidenceManifestV1;
    readonly gates: readonly ProductionGateResultV1[];
    readonly claims: readonly ProductionEvidenceClaimV1[];
    readonly artifacts: readonly ProductionEvidenceRefV1[];
    readonly bindings: readonly ProductionEvidenceBindingV1[];
    readonly waivers: readonly ProductionWaiverV1[];
    readonly verdict: ProductionReleaseVerdictV1;
    readonly fingerprint: string;
}
//# sourceMappingURL=contract.d.ts.map