export declare const createSHA256Fingerprint: (value: unknown) => Promise<string>;
//# sourceMappingURL=fingerprint.d.ts.map