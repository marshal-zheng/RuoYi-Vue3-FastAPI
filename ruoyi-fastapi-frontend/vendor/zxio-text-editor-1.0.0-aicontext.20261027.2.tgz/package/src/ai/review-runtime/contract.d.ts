import { DerivedViewSourceBindingV2, DerivedViewUnavailableReasonV2, RuntimeComponentRefV2 } from '../../core/deterministic-runtime';
import { ZxTextEditorDocument } from '../../document/types';
import { ZxAIProposalArtifactV1, ZxAIProposalDiagnostic, ZxAIProposalDiscardIntent, ZxAIProposalHistoricalEnvelopeV1, ZxAIProposalIdentity, ZxAIProposalLifecycleReceipt, ZxAIProposalSemanticRecipeV1 } from '../proposal-branch';
export declare const ZX_AI_REVIEW_CONTRACT_VERSION: "1.0.0";
export interface ZxAIReviewIdentityV1 {
    readonly reviewId: string;
}
export interface ZxAIReviewPolicyRefV1 {
    readonly id: 'zx.ai.review-policy';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly fingerprint: string;
}
export interface ZxAIReviewProposalBindingV1 {
    readonly proposalId: string;
    readonly variantId: string;
    readonly proposalFingerprint: string;
    readonly operationCount: number;
    readonly operationProjectionFingerprint: string;
    readonly lifecycleRevision: number;
    readonly lifecycleFingerprint: string;
    readonly baseFingerprint: string;
    readonly documentRevision: string;
    readonly annotationFingerprint: string;
    readonly targetFingerprint: string;
    readonly planDigest: string;
    readonly resultFingerprint: string;
    readonly traceFingerprint: string;
    readonly mappingFingerprint: string;
    readonly effectFingerprint: string;
    readonly richDiffStatus: 'available' | 'unavailable';
    readonly richDiffSourceBinding: DerivedViewSourceBindingV2;
    readonly richDiffUnavailableReason: DerivedViewUnavailableReasonV2 | null;
    readonly richDiffFingerprint: string;
}
export interface ZxAIReviewHunkRefV1 {
    readonly hunkId: string;
    readonly ordinal: number;
    readonly kind: string;
    readonly fingerprint: string;
}
export interface ZxAIReviewAppendedAttributionRefV1 {
    readonly sequence: number;
    readonly pluginInstanceId: string;
    readonly documentChanged: boolean;
    readonly blockRefs: readonly string[];
    readonly safeEffectFingerprints: readonly string[];
    readonly fingerprint: string;
}
export interface ZxAIReviewItemV1 {
    readonly itemId: string;
    readonly operationIndex: number;
    readonly operationKind: string;
    readonly operationIntentDigest: string;
    readonly decisionKey: string;
    readonly dependencyOperationIndexes: readonly number[];
    readonly blockRefs: readonly string[];
    readonly hunkRefs: readonly ZxAIReviewHunkRefV1[];
    readonly appendedAttributionRefs: readonly ZxAIReviewAppendedAttributionRefV1[];
    readonly summary: string;
    readonly noOpReason: 'already-equal' | null;
    readonly fingerprint: string;
}
export type ZxAIReviewDecisionStateV1 = 'undecided' | 'accepted' | 'rejected' | 'regeneration-required';
export interface ZxAIReviewOperationDecisionV1 {
    readonly operationIndex: number;
    readonly operationIntentDigest: string;
    readonly dependencyOperationIndexes: readonly number[];
    readonly state: ZxAIReviewDecisionStateV1;
    readonly decidedAtRevision: number | null;
    readonly fingerprint: string;
}
export type ZxAIReviewDecisionKindV1 = 'accept-operation' | 'reject-operation' | 'accept-all' | 'reject-all' | 'regenerate';
export interface ZxAIReviewDecisionCommandBindingV1 {
    readonly commandId: string;
    readonly expectedRevision: number;
    readonly expectedSidecarFingerprint: string;
    readonly expectedProposalFingerprint: string;
    readonly expectedLifecycleFingerprint: string;
    readonly expectedPolicyFingerprint: string;
}
export type ZxAIReviewDecisionCommandV1 = (ZxAIReviewDecisionCommandBindingV1 & {
    readonly kind: 'accept-operation';
    readonly operationIndex: number;
}) | (ZxAIReviewDecisionCommandBindingV1 & {
    readonly kind: 'reject-operation';
    readonly operationIndex: number;
}) | (ZxAIReviewDecisionCommandBindingV1 & {
    readonly kind: 'accept-all' | 'reject-all' | 'regenerate';
});
export interface ZxAIReviewAuditEntryV1 {
    readonly sequence: number;
    readonly kind: 'sidecar-created' | ZxAIReviewDecisionKindV1 | 'regeneration-issued' | 'refinement-issued' | 'commit-reserved' | 'committed' | 'accepted-no-change' | 'reject-reserved' | 'rejected' | 'invalidated';
    readonly commandId: string | null;
    readonly previousSidecarFingerprint: string | null;
    readonly operationIndexes: readonly number[];
    readonly fingerprint: string;
}
export type ZxAIReviewTerminalStatusV1 = 'committed' | 'accepted-no-change' | 'rejected' | 'superseded' | 'invalidated';
export interface ZxAIReviewSidecarV1 {
    readonly kind: 'zx-ai-review-sidecar-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly identity: ZxAIReviewIdentityV1;
    readonly proposalBinding: ZxAIReviewProposalBindingV1;
    readonly policyRef: ZxAIReviewPolicyRefV1;
    readonly profileRef: RuntimeComponentRefV2;
    readonly revision: number;
    readonly status: 'active' | ZxAIReviewTerminalStatusV1;
    readonly capability: 'fine-review' | 'coarse-review-unavailable';
    readonly items: readonly ZxAIReviewItemV1[];
    readonly decisions: readonly ZxAIReviewOperationDecisionV1[];
    readonly auditEntries: readonly ZxAIReviewAuditEntryV1[];
    readonly fingerprint: string;
}
export type ZxAIReviewDiagnosticCode = 'review-input-invalid' | 'review-proposal-invalid' | 'review-lifecycle-invalid' | 'review-policy-invalid' | 'review-sidecar-invalid' | 'review-runtime-unsupported' | 'review-diff-unavailable' | 'review-item-index-invalid' | 'review-dependency-invalid' | 'review-dependency-conflict' | 'review-conflict' | 'review-terminal' | 'review-regeneration-invalid' | 'review-refinement-invalid' | 'review-recipe-invalid' | 'review-target-invalid' | 'review-pre-dispatch-failure' | 'review-post-dispatch-incident' | 'review-budget-exceeded';
export type ZxAIReviewDiagnosticStage = 'input' | 'sidecar' | 'codec' | 'items' | 'navigation' | 'decision' | 'policy' | 'regeneration' | 'refinement' | 'eligibility' | 'target' | 'runtime' | 'dispatch' | 'post-dispatch' | 'reject' | 'audit';
export interface ZxAIReviewDiagnostic {
    readonly code: ZxAIReviewDiagnosticCode;
    readonly stage: ZxAIReviewDiagnosticStage;
    readonly path: string;
    readonly count?: number;
    readonly fingerprintPrefix?: string;
    readonly reviewRef?: string;
    readonly proposalRef?: string;
    readonly operationRef?: string;
    readonly blockRef?: string;
    readonly hunkRef?: string;
}
export interface ZxAICreateReviewSidecarOptions {
    readonly identity: ZxAIReviewIdentityV1;
    readonly policyRef: ZxAIReviewPolicyRefV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
}
export type ZxAIReviewSidecarResult = {
    readonly status: 'active';
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'failure' | 'unsupported';
    readonly sidecar: null;
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export type ZxAIReviewSidecarReadResult = {
    readonly status: 'success';
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'review-sidecar-invalid' | 'review-runtime-unsupported';
    readonly sidecar: null;
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export type ZxAIReviewDecisionResult = {
    readonly status: 'success';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly affectedOperationIndexes: readonly number[];
} | {
    readonly status: 'dependency-conflict' | 'conflict' | 'terminal' | 'failure';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly requiredOperationIndexes?: readonly number[];
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export type ZxAIReviewDecisionCandidateResultV1 = {
    readonly status: 'candidate';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly affectedOperationIndexes: readonly number[];
} | {
    readonly status: 'dependency-conflict' | 'conflict' | 'terminal' | 'failure';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly requiredOperationIndexes?: readonly number[];
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export type ZxAIReviewDecisionTransitionVerificationV1 = {
    readonly status: 'verified';
    readonly resultingSidecarFingerprint: string;
} | {
    readonly status: 'mismatch' | 'failure';
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export interface ZxAIReviewVerifiedDecisionTransitionV1 {
    readonly previousSidecarFingerprint: string;
    readonly command: ZxAIReviewDecisionCommandV1;
    readonly resultingSidecar: ZxAIReviewSidecarV1;
}
export type ZxAIReviewAuthorityReconciliationResultV1 = {
    readonly status: 'reconciled' | 'idempotent';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly installedTransitionCount: number;
} | {
    readonly status: 'conflict' | 'failure';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export type ZxAIReviewNavigationKindV1 = 'first' | 'last' | 'next' | 'previous' | 'by-operation' | 'by-block';
export interface ZxAIReviewNavigationOptionsV1 {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly kind: ZxAIReviewNavigationKindV1;
    readonly currentItemId?: string;
    readonly operationIndex?: number;
    readonly blockRef?: string;
}
export interface ZxAIReviewNavigationSnapshotV1 {
    readonly itemId: string;
    readonly operationIndex: number;
    readonly blockRefs: readonly string[];
    readonly hunkRefs: readonly string[];
    readonly index: number;
    readonly total: number;
    readonly summary: string;
}
export type ZxAIReviewNavigationResult = {
    readonly status: 'found';
    readonly snapshot: ZxAIReviewNavigationSnapshotV1;
} | {
    readonly status: 'boundary' | 'not-found' | 'failure';
    readonly snapshot: null;
    readonly diagnostic?: ZxAIReviewDiagnostic;
};
export interface ZxAIReviewRegenerationHandoffV1 {
    readonly kind: 'zx-ai-review-regeneration-handoff-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly reviewFingerprint: string;
    readonly decisionFingerprint: string;
    readonly supersededProposalFingerprint: string;
    readonly latestBaseRequirement: {
        readonly required: true;
        readonly latestBaseFingerprint: string;
    };
    readonly operationIntentDigests: readonly string[];
    readonly plannerSeedFingerprint: string;
    readonly fingerprint: string;
}
/**
 * Versioned S4 terminal receipt for Review Refine.
 *
 * The artifact deliberately contains only bounded identities, refs and
 * digests. Prompt/candidate text remains behind the S6 host resolver.
 */
export interface ZxAIReviewRefinementHandoffV1 {
    readonly kind: 'zx-ai-review-refinement-handoff-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly exactKey: string;
    readonly commandId: string;
    readonly reviewId: string;
    readonly sourceReviewRevision: number;
    readonly sourceReviewFingerprint: string;
    readonly terminalSidecarFingerprint: string;
    readonly proposalId: string;
    readonly sourceVariantId: string;
    readonly nextVariantId: string;
    readonly proposalFingerprint: string;
    readonly lifecycleFingerprint: string;
    readonly targetFingerprint: string;
    readonly baseFingerprint: string;
    readonly predecessorResultDigest: string;
    readonly refinementPromptDigest: string;
    readonly operationIntentDigests: readonly string[];
    readonly lineageDigest: string;
    readonly fingerprint: string;
}
export interface ZxAICreateReviewRefinementHandoffOptionsV1 {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly commandId: string;
    readonly latestBaseFingerprint: string;
    readonly refinementPromptDigest: string;
    readonly nextVariantId: string;
}
export type ZxAIReviewRefinementHandoffResultV1 = {
    readonly status: 'refinement-issued';
    readonly handoff: ZxAIReviewRefinementHandoffV1;
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly idempotent: boolean;
} | {
    readonly status: 'conflict' | 'failure';
    readonly handoff: null;
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export type ZxAIReviewRefinementHandoffReadResultV1 = {
    readonly status: 'success';
    readonly handoff: ZxAIReviewRefinementHandoffV1;
} | {
    readonly status: 'review-refinement-handoff-invalid' | 'review-runtime-unsupported';
    readonly handoff: null;
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export interface ZxAICreateReviewRegenerationOptions {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly latestBaseDocument: ZxTextEditorDocument;
    readonly nextIdentity: ZxAIProposalIdentity;
}
export type ZxAIReviewRegenerationResult = {
    readonly status: 'regeneration-required';
    readonly handoff: ZxAIReviewRegenerationHandoffV1;
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'conflict' | 'failure';
    readonly handoff: null;
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly diagnostic: ZxAIReviewDiagnostic | ZxAIProposalDiagnostic;
};
export interface ZxAIResolveReviewOptions {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly currentDocument: ZxTextEditorDocument;
}
export type ZxAIReviewResolutionResult = {
    readonly status: 'continue-review';
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'regeneration-required';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly operationIntentDigests: readonly string[];
    readonly decisionFingerprint: string;
} | {
    readonly status: 'reject-intent-ready';
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'whole-accept-ready';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly recipe: ZxAIProposalSemanticRecipeV1;
} | {
    readonly status: 'accepted-no-change';
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'rebase-required' | 'regenerate-view' | 'regenerate-current-runtime' | 'unsupported-host' | 'discarded' | 'conflict' | 'invalidated' | 'superseded' | 'failure';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly diagnostic?: ZxAIReviewDiagnostic | ZxAIProposalDiagnostic;
};
export interface ZxAICommitReviewOptions {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
    readonly currentDocument: ZxTextEditorDocument;
    readonly targetEditor: object;
}
export interface ZxAIReviewCommittedReceiptV1 {
    readonly kind: 'zx-ai-review-committed-receipt-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly reviewId: string;
    readonly reviewRevision: number;
    readonly proposalFingerprint: string;
    readonly proposalLifecycleRevision: number;
    readonly proposalLifecycleFingerprint: string;
    readonly recipeFingerprint: string;
    readonly beforeFingerprint: string;
    readonly afterFingerprint: string;
    readonly freshOutcomeFingerprint: string;
    readonly dispatchAdmissionFingerprint: string;
    readonly rootTransactionFingerprint: string;
    readonly liveClosureFingerprint: string;
    readonly historyEventFingerprint: string;
    readonly terminalSidecarFingerprint: string;
    readonly fingerprint: string;
}
export type ZxAIReviewCommitResult = {
    readonly status: 'committed';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly receipt: ZxAIReviewCommittedReceiptV1;
} | {
    readonly status: 'accepted-no-change';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly receipt: null;
} | {
    readonly status: 'regeneration-required' | 'rebase-required' | 'unsupported-host' | 'conflict' | 'pre-dispatch-failure' | 'post-dispatch-incident' | 'failure';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly receipt: null;
    readonly diagnostic?: ZxAIReviewDiagnostic | ZxAIProposalDiagnostic;
};
export interface ZxAICreateReviewRejectIntentOptions {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
}
export interface ZxAIReviewRejectIntentV1 {
    readonly kind: 'zx-ai-review-reject-intent-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly reviewId: string;
    readonly expectedReviewRevision: number;
    readonly expectedReviewFingerprint: string;
    readonly proposalDiscardIntent: ZxAIProposalDiscardIntent;
    readonly fingerprint: string;
}
export type ZxAIReviewRejectIntentResult = {
    readonly status: 'reject-intent-ready';
    readonly intent: ZxAIReviewRejectIntentV1;
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'conflict' | 'failure';
    readonly intent: null;
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly diagnostic: ZxAIReviewDiagnostic | ZxAIProposalDiagnostic;
};
export interface ZxAIFinalizeReviewRejectionOptions {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly intent: ZxAIReviewRejectIntentV1;
    readonly discardedLifecycle: ZxAIProposalLifecycleReceipt & {
        readonly status: 'discarded';
    };
}
export type ZxAIReviewRejectResult = {
    readonly status: 'rejected';
    readonly sidecar: ZxAIReviewSidecarV1;
} | {
    readonly status: 'conflict' | 'failure';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly diagnostic: ZxAIReviewDiagnostic;
};
export interface ZxAIReviewHistoricalArtifactV1 {
    readonly kind: 'zx-ai-review-historical-artifact-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly reviewReaderRef: RuntimeComponentRefV2;
    readonly reviewId: string;
    readonly terminalSidecarFingerprint: string;
    readonly proposalId: string;
    readonly proposalVariantId: string;
    readonly proposalFingerprint: string;
    readonly proposalHistoricalArtifactFingerprint: string;
    readonly terminalStatus: ZxAIReviewTerminalStatusV1;
    readonly decisionFingerprints: readonly string[];
    readonly auditFingerprints: readonly string[];
    readonly fingerprint: string;
}
export interface ZxAIReviewHistoricalEnvelopeV1 {
    readonly kind: 'zx-ai-review-historical-envelope-v1';
    readonly version: typeof ZX_AI_REVIEW_CONTRACT_VERSION;
    readonly reviewReaderRef: RuntimeComponentRefV2;
    readonly reviewArtifact: ZxAIReviewHistoricalArtifactV1;
    readonly terminalSidecar: ZxAIReviewSidecarV1;
    readonly proposalEnvelope: ZxAIProposalHistoricalEnvelopeV1;
    readonly closureFingerprint: string;
}
export interface ZxAICreateReviewHistoricalEnvelopeOptions {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposalEnvelope: ZxAIProposalHistoricalEnvelopeV1;
}
export interface ZxAIAuditCurrentReviewOptions {
    readonly mode: 'exact-current';
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly proposal: ZxAIProposalArtifactV1;
    readonly lifecycle: ZxAIProposalLifecycleReceipt;
}
export interface ZxAIAuditHistoricalReviewOptions {
    readonly mode: 'historical';
    readonly envelope: ZxAIReviewHistoricalEnvelopeV1;
}
export type ZxAIAuditReviewOptions = ZxAIAuditCurrentReviewOptions | ZxAIAuditHistoricalReviewOptions;
export type ZxAIReviewAuditResult = {
    readonly status: 'audit-success';
    readonly fingerprint: string;
} | {
    readonly status: 'deterministic-mismatch' | 'review-runtime-unsupported' | 'failure';
    readonly diagnostics: readonly ZxAIReviewDiagnostic[];
};
export interface ZxAIReviewReferenceProvenanceV1 {
    readonly repository: 'BlockNote' | 'Plate' | 'Novel';
    readonly commit: string;
    readonly paths: readonly string[];
    readonly decisions: readonly {
        readonly decision: 'adapt' | 'reject';
        readonly boundary: string;
        readonly fixtureIds: readonly string[];
    }[];
}
//# sourceMappingURL=contract.d.ts.map