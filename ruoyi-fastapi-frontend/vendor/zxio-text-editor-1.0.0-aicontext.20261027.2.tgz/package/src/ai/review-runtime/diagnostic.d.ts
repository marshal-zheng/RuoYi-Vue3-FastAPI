import { ZxAIReviewDiagnostic, ZxAIReviewDiagnosticCode, ZxAIReviewDiagnosticStage } from './contract';
export declare const createAIReviewDiagnostic: (input: {
    readonly code: ZxAIReviewDiagnosticCode;
    readonly stage: ZxAIReviewDiagnosticStage;
    readonly path: string;
    readonly count?: number;
    readonly fingerprint?: string;
    readonly reviewRef?: string;
    readonly proposalRef?: string;
    readonly operationRef?: string;
    readonly blockRef?: string;
    readonly hunkRef?: string;
}) => ZxAIReviewDiagnostic;
export declare const createAIReviewDiagnosticSet: (values: readonly ZxAIReviewDiagnostic[]) => readonly ZxAIReviewDiagnostic[];
//# sourceMappingURL=diagnostic.d.ts.map