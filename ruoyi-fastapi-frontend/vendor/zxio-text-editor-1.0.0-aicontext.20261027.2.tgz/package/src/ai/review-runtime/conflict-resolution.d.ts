import { ZxAIReviewSidecarV1, ZxAIReviewDiagnostic } from './contract';
export declare const supersedeAIReviewConflictForRegeneration: (input: {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly commandId: string;
    readonly regenerationHandoffFingerprint: string;
}) => {
    status: "conflict";
    sidecar: ZxAIReviewSidecarV1;
    regenerationHandoffFingerprint: null;
    diagnostic: ZxAIReviewDiagnostic;
} | {
    status: "superseded";
    sidecar: ZxAIReviewSidecarV1;
    regenerationHandoffFingerprint: string;
    diagnostic: null;
};
//# sourceMappingURL=conflict-resolution.d.ts.map