import { RuntimeComponentRefV2 } from '../../core/deterministic-runtime';
import { ZxAIAuditReviewOptions, ZxAICreateReviewHistoricalEnvelopeOptions, ZxAIReviewAuditResult, ZxAIReviewHistoricalEnvelopeV1 } from './contract';
export declare const AI_REVIEW_HISTORICAL_READER_V1: RuntimeComponentRefV2;
export declare const createAIReviewHistoricalEnvelope: (options: ZxAICreateReviewHistoricalEnvelopeOptions) => ZxAIReviewHistoricalEnvelopeV1;
export declare const auditAIReview: (options: ZxAIAuditReviewOptions) => ZxAIReviewAuditResult;
//# sourceMappingURL=audit.d.ts.map