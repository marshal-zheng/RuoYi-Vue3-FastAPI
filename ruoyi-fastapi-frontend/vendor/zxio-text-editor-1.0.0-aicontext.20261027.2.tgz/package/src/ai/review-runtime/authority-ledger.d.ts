import { ZxAIReviewSidecarV1 } from './contract';
export declare const installAIReviewAuthority: (sidecar: ZxAIReviewSidecarV1) => boolean;
export declare const isAIReviewAuthorityCurrent: (sidecar: ZxAIReviewSidecarV1) => boolean;
export declare const compareAndSetAIReviewAuthority: (previous: ZxAIReviewSidecarV1, next: ZxAIReviewSidecarV1) => boolean;
export declare const reconcileAIReviewAuthoritySequence: (root: ZxAIReviewSidecarV1, sequence: readonly ZxAIReviewSidecarV1[]) => "reconciled" | "idempotent" | "conflict";
export declare const reserveAIReviewAuthority: (sidecar: ZxAIReviewSidecarV1, kind: "commit" | "reject") => boolean;
export declare const releaseAIReviewAuthorityReservation: (sidecar: ZxAIReviewSidecarV1, kind: "commit" | "reject") => void;
export declare const finalizeAIReviewAuthorityReservation: (previous: ZxAIReviewSidecarV1, next: ZxAIReviewSidecarV1, kind: "commit" | "reject") => boolean;
export declare const finalizeAIReviewAuthorityIncident: (previous: ZxAIReviewSidecarV1, invalidated: ZxAIReviewSidecarV1) => ZxAIReviewSidecarV1;
export declare const resetAIReviewAuthorityForTests: () => void;
//# sourceMappingURL=authority-ledger.d.ts.map