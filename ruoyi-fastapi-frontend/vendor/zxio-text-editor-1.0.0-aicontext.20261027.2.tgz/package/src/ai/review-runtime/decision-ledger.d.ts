import { ZxAIReviewAuthorityReconciliationResultV1, ZxAIReviewDecisionCandidateResultV1, ZxAIReviewDecisionCommandV1, ZxAIReviewDecisionResult, ZxAIReviewDecisionTransitionVerificationV1, ZxAIReviewSidecarV1, ZxAIReviewVerifiedDecisionTransitionV1 } from './contract';
export declare const applyAIReviewDecision: (options: {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly command: ZxAIReviewDecisionCommandV1;
}) => ZxAIReviewDecisionResult;
export declare const prepareAIReviewDecisionCandidate: (options: {
    readonly sidecar: ZxAIReviewSidecarV1;
    readonly command: ZxAIReviewDecisionCommandV1;
}) => ZxAIReviewDecisionCandidateResultV1;
export declare const verifyAIReviewDecisionTransition: (options: {
    readonly previous: ZxAIReviewSidecarV1;
    readonly command: ZxAIReviewDecisionCommandV1;
    readonly candidate: ZxAIReviewSidecarV1;
}) => ZxAIReviewDecisionTransitionVerificationV1;
export declare const reconcileAIReviewAuthorityPrefix: (options: {
    readonly root: ZxAIReviewSidecarV1;
    readonly entries: readonly ZxAIReviewVerifiedDecisionTransitionV1[];
    readonly expectedDurableHeadFingerprint: string;
}) => ZxAIReviewAuthorityReconciliationResultV1;
export declare const reconcileAIReviewHistoricalAuthoritySequence: (options: {
    readonly root: ZxAIReviewSidecarV1;
    readonly sequence: readonly ZxAIReviewSidecarV1[];
    readonly expectedDurableHeadFingerprint: string;
}) => ZxAIReviewAuthorityReconciliationResultV1;
//# sourceMappingURL=decision-ledger.d.ts.map