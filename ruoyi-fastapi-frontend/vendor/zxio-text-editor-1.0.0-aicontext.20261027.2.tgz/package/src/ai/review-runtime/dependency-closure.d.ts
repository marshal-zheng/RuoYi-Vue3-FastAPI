import { ZxAIProposalOperationProjectionV1 } from '../proposal-branch';
export interface AIReviewDependencyGraphV1 {
    readonly operationIndexes: readonly number[];
    readonly dependencies: readonly (readonly number[])[];
    readonly reverseDependencies: readonly (readonly number[])[];
    readonly fingerprintProjection: readonly {
        readonly operationIndex: number;
        readonly intentDigest: string;
        readonly dependencies: readonly number[];
    }[];
}
export declare const createAIReviewDependencyGraph: (operations: readonly ZxAIProposalOperationProjectionV1[]) => AIReviewDependencyGraphV1 | null;
export declare const collectAIReviewReverseDependencyClosure: (graph: AIReviewDependencyGraphV1, operationIndex: number) => readonly number[];
export declare const isAIReviewOperationSetDependencyClosed: (graph: AIReviewDependencyGraphV1, operationIndexes: readonly number[]) => boolean;
//# sourceMappingURL=dependency-closure.d.ts.map