import { ZxAIReviewSidecarReadResult, ZxAIReviewSidecarV1 } from './contract';
export declare const computeAIReviewSidecarFingerprint: (sidecar: Omit<ZxAIReviewSidecarV1, "fingerprint">) => string;
export declare const publishAIReviewSidecar: (sidecar: Omit<ZxAIReviewSidecarV1, "fingerprint">) => ZxAIReviewSidecarV1;
export declare const readAIReviewSidecar: (input: unknown) => ZxAIReviewSidecarReadResult;
export declare const serializeAIReviewSidecar: (sidecar: ZxAIReviewSidecarV1) => string;
//# sourceMappingURL=artifact-codec.d.ts.map