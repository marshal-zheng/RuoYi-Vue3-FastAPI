import { ZxTextEditorDocument } from '../document';
export type ZxExportBundleCompletionMode = 'strict-complete' | 'allow-staged';
export type ZxExportMemberKind = 'canonical-document' | 'annotation-thread' | 'asset' | 'subpage' | 'sidecar' | (string & {});
export type ZxExportMemberMaterializationState = 'materialized' | 'pending' | 'unresolved' | 'failed';
export interface ZxDocumentExportVariant {
    completion?: ZxExportBundleCompletionMode;
    includeComments?: boolean;
    includeAssets?: boolean;
    includeSubpages?: boolean;
    sidecars?: readonly string[];
}
export interface ZxExportMemberRef {
    id: string;
    kind: ZxExportMemberKind;
}
export type ZxExportRelationshipKind = 'references-asset' | 'anchors-comment' | 'contains-subpage' | 'links-to-document' | 'links-to-asset' | (string & {});
export interface ZxExportRelationship {
    from: ZxExportMemberRef;
    to: ZxExportMemberRef;
    kind: ZxExportRelationshipKind;
    resolution?: {
        state: 'resolved' | 'unresolved';
        missingEndpoint?: 'from' | 'to';
        reasonCode?: string;
    };
}
export interface ZxExportManifestMember {
    id: string;
    kind: ZxExportMemberKind;
    origin: 'snapshot' | 'provider' | 'materializer';
    required: boolean;
    materializationState: ZxExportMemberMaterializationState;
    sourceDocumentId?: string;
    diagnosticRefs?: readonly string[];
    path?: string;
    mediaType?: string;
    size?: number;
    digest?: string;
}
export type ZxExportSourceDocumentRole = 'root' | 'subpage' | 'reference';
export interface ZxExportSourceDocument {
    id: string;
    memberId: string;
    role: ZxExportSourceDocumentRole;
    origin: 'snapshot' | 'provider';
    documentVersion: ZxTextEditorDocument['version'];
    schemaVersion: string;
    revision?: string;
    parentId?: string;
    title?: string;
    updatedAt?: string;
    source?: ZxTextEditorDocument['meta']['source'];
}
export interface ZxExportRewriteRecord {
    memberId: string;
    sourceDocumentId: string;
    source: string;
    target: string;
    intent?: 'canonical-link' | 'asset-link' | 'embed-link' | 'anchor-link';
}
export interface ZxExportManifest {
    bundleId: string;
    snapshotId: string;
    schemaVersion: string;
    graphVersion: string;
    rewritePolicyVersion: string;
    completionMode: ZxExportBundleCompletionMode;
    sourceDocuments: readonly ZxExportSourceDocument[];
    members: readonly ZxExportManifestMember[];
    relationships: readonly ZxExportRelationship[];
    rewrites: readonly ZxExportRewriteRecord[];
    diagnosticRefs: readonly string[];
    integrity: {
        algorithm: 'sha256';
        manifestDigest: string;
    };
}
export interface ZxExportSnapshot {
    id: string;
    document: ZxTextEditorDocument;
    variant: ZxDocumentExportVariant;
    projections: {
        title?: string;
        excerpt?: string;
        outline?: readonly ZxExportSnapshotOutlineItem[];
        searchText?: string;
    };
    verification: {
        stableBlockIdentityIssues: readonly ZxExportSnapshotStableBlockIdentityIssue[];
        unresolvedAnnotations: number;
    };
}
export interface ZxExportSnapshotOutlineItem {
    label: string;
    level: number;
    blockId?: string;
}
export interface ZxExportSnapshotStableBlockIdentityIssue {
    code: 'missing-block-id' | 'duplicate-block-id' | 'invalid-block-id';
    message: string;
    nodeType: string;
    path: string;
    blockId: string | null;
}
export interface ZxDocumentExportBundle {
    snapshot: ZxExportSnapshot;
    manifest: ZxExportManifest;
}
export interface ZxExportDiagnostic {
    id?: string;
    code: string;
    message: string;
    severity?: 'error' | 'warning' | 'info';
    memberId?: string;
    sourceDocumentId?: string;
}
export interface ZxDocumentExportBundleResult {
    bundle: ZxDocumentExportBundle;
    sourceDocuments: readonly ZxExportSourceDocument[];
    cacheKey: string;
    diagnostics: readonly ZxExportDiagnostic[];
    diagnosticRefs: readonly string[];
    versions: {
        manifestSchemaVersion: string;
        graphVersion: string;
        rewritePolicyVersion: string;
    };
    integrity: {
        algorithm: 'sha256';
        manifestDigest: string;
    };
    statistics: {
        memberCount: number;
        materializedCount: number;
        pendingCount: number;
        unresolvedCount: number;
        failedCount: number;
    };
    completion: {
        mode: ZxExportBundleCompletionMode;
        state: 'complete' | 'staged';
        directlyDeliverable: boolean;
    };
}
export interface ZxCreateExportSnapshotOptions {
    variant?: ZxDocumentExportVariant;
    diagnostics?: ZxExportDiagnostic[];
}
//# sourceMappingURL=contract.d.ts.map