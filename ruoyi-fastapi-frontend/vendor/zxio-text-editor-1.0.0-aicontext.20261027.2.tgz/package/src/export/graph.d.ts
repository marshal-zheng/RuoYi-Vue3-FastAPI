import { ZxTextEditorDocument } from '../document';
import { ZxExportDiagnostic, ZxExportManifestMember, ZxExportRelationship, ZxExportSnapshot, ZxExportSourceDocument } from './contract';
export interface ZxExportRelatedDocument {
    id: string;
    document: ZxTextEditorDocument;
    relation: 'subpage' | 'reference';
    parentMemberId?: string;
}
export interface ZxExportAdditionalMember {
    id: string;
    kind: 'sidecar';
    label: string;
    payload: Record<string, unknown>;
}
export interface ZxExportGraphProvider {
    resolveRelatedDocuments?: (snapshot: ZxExportSnapshot) => Promise<readonly ZxExportRelatedDocument[]>;
    resolveSidecars?: (snapshot: ZxExportSnapshot) => Promise<readonly ZxExportAdditionalMember[]>;
}
export interface ZxExportResolvedSource {
    snapshot: ZxExportSnapshot;
    sourceDocument: ZxExportSourceDocument;
}
export interface ZxBuildExportGraphOptions {
    graphProvider?: ZxExportGraphProvider;
    diagnostics?: ZxExportDiagnostic[];
    rootDocumentId?: string;
    rootDocumentRevision?: string;
}
export interface ZxBuildExportGraphResult {
    members: readonly ZxExportManifestMember[];
    relationships: readonly ZxExportRelationship[];
    sources: readonly ZxExportResolvedSource[];
}
export declare const buildExportMemberGraph: (snapshot: ZxExportSnapshot, options?: ZxBuildExportGraphOptions) => Promise<ZxBuildExportGraphResult>;
//# sourceMappingURL=graph.d.ts.map