import { ZxDocumentExportVariant, ZxExportManifest, ZxExportManifestMember, ZxExportRelationship, ZxExportRewriteRecord, ZxExportSourceDocument } from './contract';
export declare const toStableSerializedValue: (value: unknown) => string;
export declare const computeSha256Hex: (value: string) => string;
export declare const computeSha256HexFromBytes: (value: Uint8Array) => string;
export interface ZxComputeExportManifestDigestOptions {
    bundleId: string;
    snapshotId: string;
    schemaVersion: string;
    graphVersion: string;
    rewritePolicyVersion: string;
    completionMode: ZxExportManifest['completionMode'];
    sourceDocuments: readonly ZxExportSourceDocument[];
    members: readonly ZxExportManifestMember[];
    relationships: readonly ZxExportRelationship[];
    rewrites: readonly ZxExportRewriteRecord[];
    diagnosticRefs: readonly string[];
}
export declare const computeExportManifestDigest: (options: ZxComputeExportManifestDigestOptions) => string;
export interface ZxExportStatistics {
    memberCount: number;
    materializedCount: number;
    pendingCount: number;
    unresolvedCount: number;
    failedCount: number;
}
export declare const computeExportStatistics: (members: readonly ZxExportManifestMember[]) => ZxExportStatistics;
export interface ZxComputeExportCacheKeyOptions {
    docId: string;
    docVersion: string;
    snapshotId: string;
    variant: ZxDocumentExportVariant;
    namespace?: string;
    memberGraphVersion?: string;
    rewritePolicy?: string;
}
export declare const computeExportCacheKey: (options: ZxComputeExportCacheKeyOptions) => string;
//# sourceMappingURL=integrity.d.ts.map