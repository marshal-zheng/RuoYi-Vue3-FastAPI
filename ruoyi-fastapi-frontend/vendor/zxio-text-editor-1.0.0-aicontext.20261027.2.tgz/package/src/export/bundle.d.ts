import { ZxTextEditorDocument } from '../document';
import { ZxDocumentExportVariant, ZxExportDiagnostic, ZxDocumentExportBundleResult } from './contract';
import { ZxExportGraphProvider } from './graph';
import { ZxExportMaterializerBundle } from './materialization';
import { ZxExportResolutionBundle } from './resolution';
export interface ZxBuildDocumentExportBundleOptions {
    variant?: ZxDocumentExportVariant;
    graphProvider?: ZxExportGraphProvider;
    materializers?: ZxExportMaterializerBundle;
    resolvers?: ZxExportResolutionBundle;
    diagnostics?: ZxExportDiagnostic[];
    schemaVersion?: string;
    cache?: {
        docId?: string;
        docVersion?: string;
        namespace?: string;
        memberGraphVersion?: string;
        rewritePolicy?: string;
    };
}
export declare const buildDocumentExportBundle: (document: ZxTextEditorDocument, options?: ZxBuildDocumentExportBundleOptions) => Promise< ZxDocumentExportBundleResult>;
//# sourceMappingURL=bundle.d.ts.map