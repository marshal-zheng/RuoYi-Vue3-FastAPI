import { Extension } from '@tiptap/core';
/**
 * CodeBlockExit Extension
 *
 * Provides keyboard shortcuts to exit code blocks:
 * - Escape: Move cursor to after the code block
 * - Mod+Enter: Exit code block and create new paragraph (already in ExtendedCodeBlock)
 *
 * @see Requirements 2.1, 2.2
 */
export declare const CodeBlockExit: Extension<any, any>;
export default CodeBlockExit;
//# sourceMappingURL=code-block-exit.d.ts.map