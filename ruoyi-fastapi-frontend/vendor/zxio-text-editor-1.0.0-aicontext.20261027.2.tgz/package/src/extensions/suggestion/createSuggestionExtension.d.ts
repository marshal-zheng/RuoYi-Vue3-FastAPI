import { Component as VueComponent } from 'vue';
import { Editor, Extension, Range } from '@tiptap/core';
import { SuggestionOptions, SuggestionProps } from '@tiptap/suggestion';
import { PluginKey } from '@tiptap/pm/state';
import { TextEditorThemeOwnerPort, TextEditorThemePortalBindingPort } from '../../core/theme-owner-port';
import { ChromeSpaceStep } from '../../utils/chrome-space';
export interface BaseSuggestionItem {
    title?: string;
    name?: string;
    [key: string]: any;
}
type NativeSuggestionOptions<TItem extends BaseSuggestionItem> = SuggestionOptions<TItem, TItem>;
export type TextEditorSuggestionInitialItems<TItem extends BaseSuggestionItem = BaseSuggestionItem> = TItem[] | (() => TItem[]);
export interface TextEditorSuggestionLoadingContext<TItem extends BaseSuggestionItem = BaseSuggestionItem> {
    editor: Editor;
    query: string;
    items: TItem[];
    loading: boolean;
}
export type TextEditorSuggestionLoading<TItem extends BaseSuggestionItem = BaseSuggestionItem> = boolean | ((context: TextEditorSuggestionLoadingContext<TItem>) => boolean);
export interface TextEditorSuggestionOptions<TItem extends BaseSuggestionItem = BaseSuggestionItem> {
    minQueryLength?: number;
    debounce?: number;
    initialItems?: TextEditorSuggestionInitialItems<TItem>;
    loading?: TextEditorSuggestionLoading<TItem>;
}
export type RuntimeSuggestionOptions<TItem extends BaseSuggestionItem> = Omit<NativeSuggestionOptions<TItem>, 'editor' | 'initialItems'> & TextEditorSuggestionOptions<TItem>;
export interface CreateSuggestionExtensionOptions<TItem extends BaseSuggestionItem> {
    name: string;
    char: string;
    pluginKey: PluginKey;
    items: (props: {
        query: string;
        editor: Editor;
        signal: AbortSignal;
    }) => TItem[] | Promise<TItem[]>;
    command: (props: {
        editor: Editor;
        range: Range;
        props: TItem;
    }) => void;
    component: VueComponent;
    placement?: NativeSuggestionOptions<TItem>['placement'];
    /** Anchor gap as a chrome spacing step; defaults to step 2 (4px at 100%). */
    gap?: ChromeSpaceStep;
    container?: NativeSuggestionOptions<TItem>['container'];
    flip?: NativeSuggestionOptions<TItem>['flip'];
    floatingUi?: NativeSuggestionOptions<TItem>['floatingUi'];
    dismissOnOutsideClick?: NativeSuggestionOptions<TItem>['dismissOnOutsideClick'];
    allowSpaces?: boolean;
    allowToIncludeChar?: boolean;
    allowedPrefixes?: NativeSuggestionOptions<TItem>['allowedPrefixes'];
    startOfLine?: boolean;
    decorationTag?: string;
    decorationClass?: string;
    decorationContent?: string;
    decorationEmptyClass?: string;
    minQueryLength?: number;
    debounce?: number;
    initialItems?: TextEditorSuggestionInitialItems<TItem>;
    shouldShow?: NativeSuggestionOptions<TItem>['shouldShow'];
    shouldResetDismissed?: NativeSuggestionOptions<TItem>['shouldResetDismissed'];
    allow?: NativeSuggestionOptions<TItem>['allow'];
    findSuggestionMatch?: NativeSuggestionOptions<TItem>['findSuggestionMatch'];
    themeOwner?: TextEditorThemeOwnerPort | null;
    addOptions?: () => Record<string, any>;
}
export type SuggestionPortalMount = {
    kind: 'theme';
    lease: TextEditorThemePortalBindingPort;
} | {
    kind: 'document';
} | {
    kind: 'unavailable';
};
type SuggestionPortalStorage = {
    disposed: boolean;
    portalLease: TextEditorThemePortalBindingPort | null;
    portalInFlight: Promise<SuggestionPortalMount> | null;
};
/**
 * Resolve where a suggestion popup should live.
 *
 * Theme-owned overlays must wait for a connected portal host. Falling through
 * to `document.body` when an owner exists paints unscoped tokens (transparent
 * surface, default light text) over themed canvases.
 */
export declare const resolveSuggestionPortalMount: (owner: TextEditorThemeOwnerPort | null | undefined, existing: TextEditorThemePortalBindingPort | null) => Promise<SuggestionPortalMount>;
export declare const resolveSuggestionRenderProps: <TItem extends BaseSuggestionItem>(props: SuggestionProps<TItem>, suggestion: RuntimeSuggestionOptions<TItem>) => SuggestionProps<TItem>;
export declare function createSuggestionExtension<TItem extends BaseSuggestionItem>(options: CreateSuggestionExtensionOptions<TItem>): Extension<Record<string, any> & {
    themeOwner: TextEditorThemeOwnerPort | null;
    suggestion: RuntimeSuggestionOptions<TItem>;
}, SuggestionPortalStorage>;
export {};
//# sourceMappingURL=createSuggestionExtension.d.ts.map