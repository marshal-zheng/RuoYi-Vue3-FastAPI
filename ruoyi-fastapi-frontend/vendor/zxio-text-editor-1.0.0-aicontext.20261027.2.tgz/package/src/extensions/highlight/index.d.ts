export { NamedHighlightExtension, HighlightEnterClearExtension, default, } from './highlight-extension';
export type { HighlightOptions } from './highlight-extension';
//# sourceMappingURL=index.d.ts.map