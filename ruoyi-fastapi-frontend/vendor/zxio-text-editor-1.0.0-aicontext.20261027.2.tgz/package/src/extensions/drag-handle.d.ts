import { Extension } from '@tiptap/core';
import { NodeRangeOptions } from '@tiptap/extension-node-range';
/**
 * Drag-handle companion range selection.
 *
 * Upstream TipTap `NodeRange` binds `Mod-a` to an invisible
 * `NodeRangeSelection` (`visible = false`) for multi-block drag. That breaks
 * authoring Cmd/Ctrl+A (no text highlight) and falsely opens selection AI
 * chrome. Keep Shift+Arrow range expansion; restore default select-all.
 *
 * Assembly still configures `key: null` (fingerprint-stable call site), but
 * upstream treats null as "always-on" mouse NodeRange: it hides ::selection,
 * paints block chrome, and converts cross-paragraph drags to invisible
 * NodeRangeSelection. Rewrite null → `Mod` when plugins are collected so plain
 * drag keeps TextSelection; Cmd/Ctrl+drag still opts into NodeRange.
 *
 * Exported as `NodeRange` so `createEditorRuntimeExtensions` source stays
 * fingerprint-stable for runtime-host authority admission.
 */
export declare const NodeRange: Extension<NodeRangeOptions, any>;
/** Explicit alias for the package-owned NodeRange override. */
export declare const ZxNodeRange: Extension<NodeRangeOptions, any>;
export { DragHandle } from '@tiptap/extension-drag-handle-vue-3';
//# sourceMappingURL=drag-handle.d.ts.map