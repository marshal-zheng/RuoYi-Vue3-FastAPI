import { Node } from '@tiptap/core';
import { HeadingOptions } from '@tiptap/extension-heading';
export declare const Heading: Node<HeadingOptions, any>;
//# sourceMappingURL=heading.d.ts.map