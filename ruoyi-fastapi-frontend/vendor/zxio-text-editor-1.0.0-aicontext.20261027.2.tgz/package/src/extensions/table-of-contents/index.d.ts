import { Editor } from '@tiptap/core';
import { Node as ProseMirrorNode } from '@tiptap/pm/model';
export { TableOfContents, TableOfContents as default, getHierarchicalIndexes, getLinearIndexes, } from '@tiptap/extension-table-of-contents';
/**
 * ToC Anchor data structure from the official extension
 */
export interface TocAnchor {
    /** DOM element of the heading */
    dom: HTMLElement;
    /** Editor instance */
    editor: Editor;
    /** Unique ID for the heading */
    id: string;
    /** Whether this heading is currently active (in viewport) */
    isActive: boolean;
    /** Whether this heading has been scrolled past */
    isScrolledOver: boolean;
    /** Index in the anchor list */
    itemIndex: number;
    /** Heading level (1-6) */
    level: number;
    /** Original heading level before any transformations */
    originalLevel: number;
    /** ProseMirror node */
    node: ProseMirrorNode;
    /** Position in the document */
    pos: number;
    /** Text content of the heading */
    textContent: string;
}
//# sourceMappingURL=index.d.ts.map