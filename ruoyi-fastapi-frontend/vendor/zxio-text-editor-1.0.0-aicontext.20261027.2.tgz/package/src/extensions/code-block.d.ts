import { CodeBlockLowlightOptions } from '@tiptap/extension-code-block-lowlight';
import { ZxCodeBlockUserPreferences } from '../code-block';
import { Node, Mark } from '@tiptap/core';
import { CodeOptions } from '@tiptap/extension-code';
export declare const inputRegex: RegExp;
export declare const CODE_BLOCK_FENCE_INPUT_REGEX: RegExp;
interface ExtendedCodeBlockOptions extends CodeBlockLowlightOptions {
    codeBlockPreferences: Partial<ZxCodeBlockUserPreferences> | null;
}
export declare const ExtendedCodeBlock: Node<ExtendedCodeBlockOptions, any>;
export declare const ExtendedCode: Mark<CodeOptions, any>;
export {};
//# sourceMappingURL=code-block.d.ts.map