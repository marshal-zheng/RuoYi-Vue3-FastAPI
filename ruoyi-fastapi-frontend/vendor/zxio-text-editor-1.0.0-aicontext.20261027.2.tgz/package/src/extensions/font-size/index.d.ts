/**
 * FontSize Extension
 *
 * Re-exports the official TipTap FontSize extension from @tiptap/extension-text-style.
 * This extension allows setting font size on selected text.
 *
 * @example
 * ```ts
 * import { TextStyle } from '@tiptap/extension-text-style'
 * import { FontSize } from '@zxio/text-editor'
 *
 * const editor = new Editor({
 *   extensions: [TextStyle, FontSize],
 * })
 *
 * // Set font size
 * editor.commands.setFontSize('16px')
 *
 * // Unset font size
 * editor.commands.unsetFontSize()
 *
 * // Check if font size is active
 * editor.isActive('textStyle', { fontSize: '16px' })
 * ```
 *
 * @see https://tiptap.dev/docs/editor/extensions/marks/text-style
 */
export { FontSize, FontSize as default } from '@tiptap/extension-text-style';
//# sourceMappingURL=index.d.ts.map