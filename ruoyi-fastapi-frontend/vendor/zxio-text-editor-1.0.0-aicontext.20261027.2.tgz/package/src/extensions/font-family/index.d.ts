/**
 * FontFamily Extension
 *
 * Re-exports the official TipTap FontFamily extension from @tiptap/extension-text-style.
 * This extension allows setting font family on selected text.
 *
 * @example
 * ```ts
 * import { TextStyle } from '@tiptap/extension-text-style'
 * import { FontFamily } from '@zxio/text-editor'
 *
 * const editor = new Editor({
 *   extensions: [TextStyle, FontFamily],
 * })
 *
 * // Set font family
 * editor.commands.setFontFamily('Inter')
 *
 * // Unset font family
 * editor.commands.unsetFontFamily()
 *
 * // Check if font family is active
 * // Note: Returns browser CSS computed value, may differ from expected
 * editor.isActive('textStyle', { fontFamily: 'Inter' })
 * ```
 *
 * @see https://tiptap.dev/docs/editor/extensions/marks/text-style
 */
export { FontFamily, FontFamily as default } from '@tiptap/extension-text-style';
//# sourceMappingURL=index.d.ts.map