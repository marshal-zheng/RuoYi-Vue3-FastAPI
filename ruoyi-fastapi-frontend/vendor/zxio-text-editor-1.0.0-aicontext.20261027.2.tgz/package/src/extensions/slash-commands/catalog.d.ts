import { Editor, Range } from '@tiptap/core';
import { Component } from 'vue';
import { SlashCommandItem } from '../../types';
/**
 * Shared structural command item; kept outside the Vue suggestion extension
 * so headless catalog consumers do not pull the UI extension declaration tree.
 */
export type CommandItem = SlashCommandItem & {
    name?: string;
    [key: string]: any;
};
export interface SlashCatalogContribution {
    /** Stable contribution id (e.g. `ai.ask`) */
    id: string;
    title: string;
    description?: string;
    icon?: Component | string;
    /** Filter keywords; query `ai` must hit Ask AI via keywords, not title.startsWith alone */
    keywords?: readonly string[];
    aliases?: readonly string[];
    shortcut?: string;
    shortcutBindingId?: string;
    group?: string;
    priority?: number;
    /** Editor capabilities the command needs; unmet contributions are not offered */
    requiredCapabilities?: readonly string[];
    command: (props: {
        editor: Editor;
        range: Range;
    }) => void;
}
export type SlashCatalogItem = CommandItem & {
    id?: string;
    keywords?: readonly string[];
    shortcut?: string;
    shortcutBindingId?: string;
    priority?: number;
};
export declare const matchesSlashCatalogQuery: (item: Pick<SlashCatalogItem, "title" | "aliases" | "keywords" | "description">, query: string) => boolean;
export declare const filterSlashCatalogItems: <T extends SlashCatalogItem>(items: readonly T[], query: string, capabilities?: ReadonlySet<string>) => T[];
export declare const contributionToSlashCatalogItem: (contribution: SlashCatalogContribution) => SlashCatalogItem;
/**
 * Merge built-in slash items with catalog contributions.
 * Contributions with the same `id` replace earlier entries (last wins).
 */
export declare const mergeSlashCatalogContributions: (builtIn: readonly SlashCommandItem[], contributions?: readonly SlashCatalogContribution[]) => SlashCatalogItem[];
//# sourceMappingURL=catalog.d.ts.map