import { Extension } from '@tiptap/core';
export interface EmbedResult {
    /** Heading title associated with this media */
    title: string;
    /** Entity name extracted from embed_name query param */
    name: string | null;
    /** Media URL */
    url: string;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        mediaDownload: {
            /** Get all media URLs from the document, returns EmbedResult[] */
            getEmbedUrls: () => ReturnType;
        };
    }
}
export interface MediaDownloadStorage {
    /** Cached results from last getEmbedUrls call */
    embedUrls: EmbedResult[];
}
export declare const MediaDownload: Extension<object, MediaDownloadStorage>;
export default MediaDownload;
//# sourceMappingURL=index.d.ts.map