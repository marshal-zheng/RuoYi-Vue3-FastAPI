import { Node } from '@tiptap/core';
import { CodeBlockLowlightOptions } from '@tiptap/extension-code-block-lowlight';
export declare const HeadlessCodeBlock: Node<CodeBlockLowlightOptions, any>;
export default HeadlessCodeBlock;
//# sourceMappingURL=code-block-render.d.ts.map