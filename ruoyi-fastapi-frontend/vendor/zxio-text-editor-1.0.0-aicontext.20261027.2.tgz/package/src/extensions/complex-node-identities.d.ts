import { Node } from '@tiptap/core';
import { TableRowOptions, TableCellOptions, TableHeaderOptions } from '@tiptap/extension-table';
export declare const StableComplexTableRow: Node<TableRowOptions, any>;
export declare const StableComplexTableCell: Node<TableCellOptions, any>;
export declare const StableComplexTableHeader: Node<TableHeaderOptions, any>;
//# sourceMappingURL=complex-node-identities.d.ts.map