import { Node } from '@tiptap/core';
import { TextEditorThemeOwnerPort } from '../../core/theme-owner-port';
export interface IframeOptions {
    themeOwner: TextEditorThemeOwnerPort | null;
    allowedDomains?: string[];
    blockedDomains?: string[];
    HTMLAttributes: Record<string, any>;
}
export interface SetIframeOptions {
    assetId?: string | null;
    src: string;
    width?: number;
    height?: number;
    title?: string;
    interactive?: boolean;
    align?: 'left' | 'center' | 'right';
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        iframe: {
            setIframe: (options: SetIframeOptions) => ReturnType;
            insertIframeURL: (url: string) => ReturnType;
            setIframeAlign: (align: 'left' | 'center' | 'right') => ReturnType;
            openIframeDialog: () => ReturnType;
        };
    }
}
export declare const IframeExtension: Node<IframeOptions, any>;
export default IframeExtension;
//# sourceMappingURL=iframe-extension.d.ts.map