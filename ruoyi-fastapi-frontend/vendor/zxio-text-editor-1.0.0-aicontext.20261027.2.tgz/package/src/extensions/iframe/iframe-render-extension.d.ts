import { Node } from '@tiptap/core';
export declare const IframeRenderExtension: Node<{
    HTMLAttributes: Record<string, unknown>;
}, any>;
export default IframeRenderExtension;
//# sourceMappingURL=iframe-render-extension.d.ts.map