export { Toggle, ToggleSummary, ToggleContent, type ToggleOptions, } from './toggle-extension';
//# sourceMappingURL=index.d.ts.map