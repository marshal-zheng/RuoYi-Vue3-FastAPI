import { Extension } from '@tiptap/core';
import { Plugin } from '@tiptap/pm/state';
import { Awareness, CollaborationUser, ConnectedUser } from '../../collaboration/types';
export interface CollaborationCursorOptions {
    /** Awareness instance */
    awareness: Awareness | null;
    /** Current user info */
    user: CollaborationUser;
    /** Custom cursor render function */
    render?: (user: CollaborationUser) => HTMLElement;
    /** Pre-loaded yCursorPlugin (for ESM compatibility) */
    yCursorPlugin?: (awareness: Awareness, options?: {
        cursorBuilder?: (user: CollaborationUser) => HTMLElement;
    }) => Plugin;
    /** Cursor position update throttle in ms (default: 50) */
    cursorThrottleMs?: number;
    /** Selection update throttle in ms (default: 100) */
    selectionThrottleMs?: number;
}
export interface CollaborationCursorStorage {
    /** Connected users list */
    users: ConnectedUser[];
    /** Whether collaboration is available */
    available: boolean;
    /** Cleanup function for awareness listener */
    cleanup: (() => void) | null;
    /** Throttled cursor update function */
    throttledCursorUpdate: ((cursor: unknown) => void) | null;
    /** Throttled selection update function */
    throttledSelectionUpdate: ((selection: unknown) => void) | null;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        collaborationCursor: {
            /** Update current user info */
            updateUser: (attributes: Partial<CollaborationUser>) => ReturnType;
            /** Update cursor position with throttling */
            updateCursor: (cursor: unknown) => ReturnType;
            /** Update selection with throttling */
            updateSelection: (selection: unknown) => ReturnType;
        };
    }
}
export declare const CollaborationCursor: Extension<CollaborationCursorOptions, CollaborationCursorStorage>;
export default CollaborationCursor;
//# sourceMappingURL=index.d.ts.map