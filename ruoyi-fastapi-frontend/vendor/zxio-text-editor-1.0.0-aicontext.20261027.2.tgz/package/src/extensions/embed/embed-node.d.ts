import { Node } from '@tiptap/core';
export declare const Embed: Node<{
    HTMLAttributes: Record<string, unknown>;
}, any>;
export default Embed;
//# sourceMappingURL=embed-node.d.ts.map