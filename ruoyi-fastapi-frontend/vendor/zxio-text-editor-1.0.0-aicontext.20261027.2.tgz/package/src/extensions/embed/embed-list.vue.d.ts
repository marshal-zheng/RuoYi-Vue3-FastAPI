import { EmbedDocument } from './index';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    items: EmbedDocument[];
    query: string;
    command: (item: EmbedDocument) => void;
};
declare const _default: DefineComponent<__VLS_Props, {
    onKeyDown: (event: KeyboardEvent) => boolean;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=embed-list.vue.d.ts.map