import { Node } from '@tiptap/core';
import { Component } from 'vue';
import { TextEditorThemeOwnerPort } from '../../core/theme-owner-port';
export interface EmbedDocument {
    /** Document identifier */
    name: string;
    /** Document title */
    title: string;
    /** Document URL */
    url: string;
    /** Optional icon */
    icon?: string;
}
export interface EmbedOptions {
    /** Runtime-derived owner for the suggestion portal. */
    themeOwner: TextEditorThemeOwnerPort | null;
    /** Function to get document list */
    getDocuments: (query: string) => Promise<EmbedDocument[]> | EmbedDocument[];
    /** Custom render component */
    component?: Component;
    /** Trigger character(s), default '[[' */
    trigger?: string;
    /** URL template function */
    urlTemplate?: (doc: EmbedDocument) => string;
    /** Allow interaction inside embedded content */
    interactive?: boolean;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        embed: {
            /** Insert an embedded document */
            insertEmbed: (doc: EmbedDocument) => ReturnType;
        };
    }
}
export declare const Embed: Node<EmbedOptions, any>;
export default Embed;
//# sourceMappingURL=index.d.ts.map