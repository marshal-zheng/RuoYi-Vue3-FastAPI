import { Extension } from '@tiptap/core';
import { TextEditorThemeOwnerPort } from '../core/theme-owner-port';
export interface ImageViewerExtensionOptions {
    themeOwner: TextEditorThemeOwnerPort | null;
}
interface ImageViewerExtensionStorage {
    destroyed: boolean;
    disposers: Set<() => void>;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        imageViewer: {
            /**
             * Open the image viewer
             */
            openImageViewer: (src: string) => ReturnType;
        };
    }
}
declare const _default: Extension<ImageViewerExtensionOptions, ImageViewerExtensionStorage>;
export default _default;
//# sourceMappingURL=image-viewer-extension.d.ts.map