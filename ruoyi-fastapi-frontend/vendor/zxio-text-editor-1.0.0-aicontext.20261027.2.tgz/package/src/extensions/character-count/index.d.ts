/**
 * CharacterCount Extension
 *
 * Re-exports the official TipTap CharacterCount extension.
 * This extension provides character and word counting functionality.
 *
 * @example
 * ```ts
 * import { CharacterCount } from '@zxio/text-editor'
 *
 * const editor = new Editor({
 *   extensions: [
 *     CharacterCount.configure({
 *       limit: 240,                    // Character limit (optional)
 *       mode: 'textSize',              // 'textSize' | 'nodeSize'
 *       textCounter: (text) => text.length,  // Custom character counter
 *       wordCounter: (text) => text.split(' ').filter(w => w !== '').length,
 *     }),
 *   ],
 * })
 *
 * // Get character count
 * editor.storage.characterCount.characters()
 * editor.storage.characterCount.characters({ node: someNode })
 * editor.storage.characterCount.characters({ mode: 'nodeSize' })
 *
 * // Get word count
 * editor.storage.characterCount.words()
 * editor.storage.characterCount.words({ node: someNode })
 * ```
 *
 * @see https://tiptap.dev/docs/editor/extensions/functionality/character-count
 */
export { CharacterCount, CharacterCount as default, } from '@tiptap/extension-character-count';
//# sourceMappingURL=index.d.ts.map