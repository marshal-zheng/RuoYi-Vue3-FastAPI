/**
 * Comment Extensions
 *
 * Provides comment functionality for the text editor:
 * - Comment: Mark extension for adding comments to text
 * - FloatingQuoteButton: Shows a button when text is selected in read-only mode
 */
export { Comment, Comment as default } from './comment-extension';
export type { CommentOptions } from './comment-extension';
export { FloatingQuoteButton } from './floating-quote-button';
export type { FloatingQuoteButtonOptions } from './floating-quote-button';
//# sourceMappingURL=index.d.ts.map