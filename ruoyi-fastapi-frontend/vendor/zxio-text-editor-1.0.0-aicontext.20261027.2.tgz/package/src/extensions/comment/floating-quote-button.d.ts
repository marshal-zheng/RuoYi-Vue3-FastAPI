import { Extension } from '@tiptap/core';
import { TextEditorThemeOwnerPort } from '../../core/theme-owner-port';
export interface FloatingQuoteButtonOptions {
    /** Runtime-derived owner for this selection surface. */
    themeOwner: TextEditorThemeOwnerPort | null;
    /** Callback when the button is clicked */
    onClick?: (selectedHTML: string) => void;
}
export declare const FloatingQuoteButton: Extension<FloatingQuoteButtonOptions, any>;
export default FloatingQuoteButton;
//# sourceMappingURL=floating-quote-button.d.ts.map