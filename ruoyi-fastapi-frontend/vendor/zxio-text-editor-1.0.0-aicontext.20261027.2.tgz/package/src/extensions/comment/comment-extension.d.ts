import { Mark } from '@tiptap/core';
export interface CommentOptions {
    HTMLAttributes: Record<string, unknown>;
    onCommentActivated?: (commentId: string | null) => void;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        comment: {
            /** Set a comment mark on selected text */
            setComment: (commentId: string) => ReturnType;
            /** Remove a comment mark by ID */
            unsetComment: (commentId: string) => ReturnType;
            /** Set the resolved state of a comment */
            resolveComment: (commentId: string, resolved?: boolean) => ReturnType;
        };
    }
}
export declare const Comment: Mark<CommentOptions, any>;
export default Comment;
//# sourceMappingURL=comment-extension.d.ts.map