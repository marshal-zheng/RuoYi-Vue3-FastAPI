import { Node } from '@tiptap/core';
export declare const AttachmentRenderExtension: Node<{
    HTMLAttributes: Record<string, unknown>;
}, any>;
export default AttachmentRenderExtension;
//# sourceMappingURL=attachment-render-extension.d.ts.map