import { Node } from '@tiptap/core';
import { ZxTextEditorDocument } from '../../document';
import { ZxAttachmentDisplayMode } from './shared';
export interface AttachmentExtensionOptions {
    /**
     * Editor-only bridge back to the current canonical document so the node view
     * can resolve `assetId -> document.assets` without persisting display attrs.
     */
    getCurrentDocument: (() => ZxTextEditorDocument) | null;
    HTMLAttributes: Record<string, unknown>;
}
export interface SetAttachmentOptions {
    assetId: string;
    display?: ZxAttachmentDisplayMode;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        attachment: {
            setAttachment: (options: SetAttachmentOptions) => ReturnType;
            setAttachmentDisplay: (display: ZxAttachmentDisplayMode) => ReturnType;
        };
    }
}
export declare const AttachmentExtension: Node<AttachmentExtensionOptions, any>;
export default AttachmentExtension;
//# sourceMappingURL=attachment-extension.d.ts.map