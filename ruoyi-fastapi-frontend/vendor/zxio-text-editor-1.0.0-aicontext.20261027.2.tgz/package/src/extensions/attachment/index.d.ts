export { AttachmentExtension, default } from './attachment-extension';
export type { AttachmentExtensionOptions, SetAttachmentOptions, } from './attachment-extension';
export type { ZxAttachmentDisplayData, ZxAttachmentDisplayMode, ZxAttachmentFileKind, } from './shared';
export { buildAttachmentDisplayData, buildAttachmentRenderAttributes, formatAttachmentSize, resolveAttachmentAsset, resolveAttachmentFileKind, resolveAttachmentIcon, } from './shared';
//# sourceMappingURL=index.d.ts.map