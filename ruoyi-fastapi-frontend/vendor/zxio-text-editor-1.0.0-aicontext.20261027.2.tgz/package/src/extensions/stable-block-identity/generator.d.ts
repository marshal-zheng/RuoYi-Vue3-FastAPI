import { UniqueIDGenerationContext } from '@tiptap/extension-unique-id';
import { Transaction } from '@tiptap/pm/state';
export interface StableBlockIdentityGeneratorContext {
    nodeType: string;
    nodeAttrs: Record<string, unknown>;
}
export interface StableBlockIdentityOptions {
    types?: string[];
    generateId?: (context: StableBlockIdentityGeneratorContext) => string;
    filterRemoteTransactions?: boolean;
}
export declare const STABLE_BLOCK_ID_ATTRIBUTE = "blockId";
export declare const STABLE_BLOCK_ID_DATA_ATTRIBUTE = "data-block-id";
export declare const DEFAULT_STABLE_BLOCK_ID_PREFIX: Record<string, string>;
export declare const DEFAULT_STABLE_BLOCK_TYPES: readonly string[];
export declare const STABLE_BLOCK_ID_PATTERN: RegExp;
export declare const getStableBlockIdPrefix: (nodeType: string) => string;
export declare const isValidStableBlockId: (value: unknown) => value is string;
export declare const resolveStableBlockIdentityTypes: (types?: string[]) => string[];
export declare const createDefaultStableBlockId: (nodeType: string) => string;
export declare const resolveStableBlockId: (nodeType: string, nodeAttrs: Record<string, unknown>, generateId?: StableBlockIdentityOptions["generateId"]) => string;
export declare const createStableBlockIdGenerator: (generateId?: StableBlockIdentityOptions["generateId"]) => ({ node }: UniqueIDGenerationContext) => string;
export declare const createUniqueStableBlockId: (context: StableBlockIdentityGeneratorContext, seenIds: Set<string>, generateId?: StableBlockIdentityOptions["generateId"]) => string;
export declare const isRemoteStableBlockIdentityTransaction: (transaction: Transaction) => boolean;
//# sourceMappingURL=generator.d.ts.map