import { Extension } from '@tiptap/core';
export interface StableBlockDomAttributesOptions {
    types: string[];
}
export declare const StableBlockDomAttributes: Extension<StableBlockDomAttributesOptions, any>;
//# sourceMappingURL=dom-attributes.d.ts.map