import { Extension } from '@tiptap/core';
import { PluginKey } from '@tiptap/pm/state';
import { StableBlockIdentityRepairSummary } from './repair';
import { StableBlockIdentityOptions } from './generator';
export interface StableBlockIdentityEngineOptions {
    types: string[];
    generateId?: StableBlockIdentityOptions['generateId'];
    filterRemoteTransactions: boolean;
}
export interface StableBlockIdentityEngineStorage {
    lastRepair: StableBlockIdentityRepairSummary | null;
}
interface StableBlockIdentityEngineStateValue {
    idCountByValue: Map<string, number>;
}
export declare const stableBlockIdentityEnginePluginKey: PluginKey<StableBlockIdentityEngineStateValue>;
export declare const StableBlockIdentityEngine: Extension<StableBlockIdentityEngineOptions, any>;
export default StableBlockIdentityEngine;
//# sourceMappingURL=engine.d.ts.map