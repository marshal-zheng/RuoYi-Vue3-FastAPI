export declare const STABLE_BLOCK_IDENTITY_HEADING_NODE_TYPE = "heading";
export declare const STABLE_BLOCK_HEADING_ID_ATTRIBUTE = "id";
export declare const STABLE_BLOCK_TOC_ID_ATTRIBUTE = "data-toc-id";
export type StableBlockIdentityAttrs = Record<string, unknown> | null | undefined;
export interface SyncStableBlockIdentityAttrsResult {
    attrs: Record<string, unknown>;
    blockIdChanged: boolean;
    headingIdentityChanged: boolean;
    changed: boolean;
}
export declare const getStableBlockIdFromAttrs: (attrs: StableBlockIdentityAttrs) => string | null;
export declare const isStableBlockIdentityHeadingNode: (nodeType: string) => nodeType is "heading";
export declare const syncStableBlockIdentityAttrs: (nodeType: string, inputAttrs: StableBlockIdentityAttrs, blockId: string) => SyncStableBlockIdentityAttrsResult;
//# sourceMappingURL=identity.d.ts.map