import { Extension } from '@tiptap/core';
import { StableBlockIdentityRepairSummary } from './repair';
import { Node as ProseMirrorNode } from '@tiptap/pm/model';
import { EditorView } from '@tiptap/pm/view';
import { StableBlockIdentityOptions } from './generator';
export type StableBlockIdentityIssueCode = 'missing-block-id' | 'duplicate-block-id' | 'invalid-block-id' | 'missing-block-dom-id' | 'heading-dom-id-mismatch';
export interface StableBlockIdentityIssue {
    code: StableBlockIdentityIssueCode;
    message: string;
    nodeType: string;
    pos: number;
    blockId: string | null;
}
export interface StableBlockIdentityDiagnosticsOptions {
    types: string[];
    generateId?: StableBlockIdentityOptions['generateId'];
    filterRemoteTransactions: boolean;
}
export interface StableBlockIdentityDiagnosticsStorage {
    issues: StableBlockIdentityIssue[];
    lastRepair: StableBlockIdentityRepairSummary | null;
    refresh: () => StableBlockIdentityIssue[];
}
export declare const collectStableBlockIdentityIssues: (doc: ProseMirrorNode, types: string[], view?: EditorView) => StableBlockIdentityIssue[];
export declare const StableBlockIdentityDiagnostics: Extension<StableBlockIdentityDiagnosticsOptions, any>;
//# sourceMappingURL=diagnostics.d.ts.map