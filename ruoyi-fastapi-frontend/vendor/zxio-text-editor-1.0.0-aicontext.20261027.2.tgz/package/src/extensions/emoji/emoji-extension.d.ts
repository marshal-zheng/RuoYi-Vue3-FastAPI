import { BaseSuggestionItem, RuntimeSuggestionOptions, SuggestionPortalMount } from '../suggestion/createSuggestionExtension';
import { Extension } from '@tiptap/core';
import { TextEditorThemeOwnerPort, TextEditorThemePortalBindingPort } from '../..';
export interface EmojiItem extends BaseSuggestionItem {
    name: string;
    emoji: string;
}
declare const _default: Extension<Record<string, any> & {
    themeOwner: TextEditorThemeOwnerPort | null;
    suggestion: RuntimeSuggestionOptions<EmojiItem>;
}, {
    disposed: boolean;
    portalLease: TextEditorThemePortalBindingPort | null;
    portalInFlight: Promise< SuggestionPortalMount> | null;
}>;
export default _default;
//# sourceMappingURL=emoji-extension.d.ts.map