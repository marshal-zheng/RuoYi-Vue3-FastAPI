import { PropType, DefineComponent, ExtractPropTypes, ComponentOptionsMixin, PublicProps, ComponentProvideOptions, ComponentInternalInstance, VNodeProps, AllowedComponentProps, ComponentCustomProps, Attrs, Slot, ComponentPublicInstance, ComponentOptionsBase, GlobalComponents, GlobalDirectives, DebuggerEvent, nextTick, WatchOptions, WatchStopHandle, ComponentCustomProperties } from 'vue';
import { Editor, Range } from '@tiptap/core';
import { BaseSuggestionItem } from '../suggestion/createSuggestionExtension';
import { EmojiItem } from './emoji-extension';
import { OnCleanup } from '@vue/reactivity';
declare const _default: DefineComponent<ExtractPropTypes<{
    items: {
        type: PropType<EmojiItem[]>;
        required: true;
    };
    editor: {
        type: PropType<Editor>;
        required: true;
    };
    range: {
        type: PropType<Range>;
        required: true;
    };
    command: {
        type: PropType<(item: EmojiItem) => void>;
        required: true;
    };
    loading: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {
    onKeyDown: ({ event }: {
        event: KeyboardEvent;
    }) => boolean;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly< ExtractPropTypes<{
    items: {
        type: PropType<EmojiItem[]>;
        required: true;
    };
    editor: {
        type: PropType<Editor>;
        required: true;
    };
    range: {
        type: PropType<Range>;
        required: true;
    };
    command: {
        type: PropType<(item: EmojiItem) => void>;
        required: true;
    };
    loading: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    loading: boolean;
}, {}, {}, {}, string, ComponentProvideOptions, true, {
    suggestionList: ({
        $: ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            loading: boolean;
            wide: boolean;
            showNoResults: boolean;
        }> & Omit<{
            readonly command: (item: BaseSuggestionItem) => void;
            readonly loading: boolean;
            readonly items: BaseSuggestionItem[];
            readonly wide: boolean;
            readonly showNoResults: boolean;
        } & VNodeProps & AllowedComponentProps & ComponentCustomProps, "loading" | "wide" | "showNoResults">;
        $attrs: Attrs;
        $refs: {
            [x: string]: unknown;
        } & {
            container: HTMLDivElement;
        };
        $slots: Readonly<{
            [name: string]: Slot<any> | undefined;
        }>;
        $root: ComponentPublicInstance | null;
        $parent: ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: string, ...args: any[]) => void;
        $el: any;
        $options: ComponentOptionsBase<Readonly< ExtractPropTypes<{
            items: {
                type: PropType<BaseSuggestionItem[]>;
                required: true;
            };
            command: {
                type: PropType<(item: BaseSuggestionItem) => void>;
                required: true;
            };
            wide: {
                type: BooleanConstructor;
                default: boolean;
            };
            showNoResults: {
                type: BooleanConstructor;
                default: boolean;
            };
            loading: {
                type: BooleanConstructor;
                default: boolean;
            };
        }>> & Readonly<{}>, {
            onKeyDown: ({ event }: {
                event: KeyboardEvent;
            }) => boolean;
        }, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, {
            loading: boolean;
            wide: boolean;
            showNoResults: boolean;
        }, {}, string, {}, GlobalComponents, GlobalDirectives, string, ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: DebuggerEvent) => void) | ((e: DebuggerEvent) => void)[];
            renderTriggered?: ((e: DebuggerEvent) => void) | ((e: DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, OnCleanup]) => any : (...args: [any, any, OnCleanup]) => any, options?: WatchOptions): WatchStopHandle;
    } & Readonly<{
        loading: boolean;
        wide: boolean;
        showNoResults: boolean;
    }> & Omit<Readonly< ExtractPropTypes<{
        items: {
            type: PropType<BaseSuggestionItem[]>;
            required: true;
        };
        command: {
            type: PropType<(item: BaseSuggestionItem) => void>;
            required: true;
        };
        wide: {
            type: BooleanConstructor;
            default: boolean;
        };
        showNoResults: {
            type: BooleanConstructor;
            default: boolean;
        };
        loading: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>> & Readonly<{}>, "onKeyDown" | ("loading" | "wide" | "showNoResults")> & {
        onKeyDown: ({ event }: {
            event: KeyboardEvent;
        }) => boolean;
    } & {} & ComponentCustomProperties & {} & {
        $slots: {
            default?(_: {
                item: BaseSuggestionItem;
                index: number;
            }): any;
        };
    }) | null;
}, any>;
export default _default;
//# sourceMappingURL=EmojiList.vue.d.ts.map