import { Extension } from '@tiptap/core';
/**
 * AutoLink Extension
 *
 * Automatically converts pasted URLs to clickable links.
 * Works both when:
 * 1. Pasting a URL with text selected (wraps selection in link)
 * 2. Pasting a URL without selection (inserts as link)
 *
 * Requirements: 4.2
 */
export declare const AutoLinkExtension: Extension<any, any>;
export default AutoLinkExtension;
//# sourceMappingURL=auto-link-extension.d.ts.map