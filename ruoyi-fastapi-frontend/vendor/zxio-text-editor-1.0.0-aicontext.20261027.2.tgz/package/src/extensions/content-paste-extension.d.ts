import { Extension } from '@tiptap/core';
import { ZxTextEditorFilePlatformRuntime } from '../file-platform';
import { ZxCodeBlockUserPreferences } from '../code-block';
export interface ContentPasteOptions {
    enabled: boolean;
    filePlatformRuntime: ZxTextEditorFilePlatformRuntime | null;
    codeBlockPreferences: Partial<ZxCodeBlockUserPreferences> | null;
}
export declare const ContentPasteExtension: Extension<ContentPasteOptions, any>;
//# sourceMappingURL=content-paste-extension.d.ts.map