import { DefineComponent, ExtractPropTypes, PropType, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
import { NodeViewProps } from '@tiptap/core';
declare const _default: DefineComponent<ExtractPropTypes<{
    editor: {
        type: PropType< NodeViewProps["editor"]>;
        required: true;
    };
    node: {
        type: PropType< NodeViewProps["node"]>;
        required: true;
    };
    decorations: {
        type: PropType< NodeViewProps["decorations"]>;
        required: true;
    };
    selected: {
        type: PropType< NodeViewProps["selected"]>;
        required: true;
    };
    extension: {
        type: PropType< NodeViewProps["extension"]>;
        required: true;
    };
    getPos: {
        type: PropType< NodeViewProps["getPos"]>;
        required: true;
    };
    updateAttributes: {
        type: PropType< NodeViewProps["updateAttributes"]>;
        required: true;
    };
    deleteNode: {
        type: PropType< NodeViewProps["deleteNode"]>;
        required: true;
    };
    view: {
        type: PropType< NodeViewProps["view"]>;
        required: true;
    };
    innerDecorations: {
        type: PropType< NodeViewProps["innerDecorations"]>;
        required: true;
    };
    HTMLAttributes: {
        type: PropType< NodeViewProps["HTMLAttributes"]>;
        required: true;
    };
}>, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly< ExtractPropTypes<{
    editor: {
        type: PropType< NodeViewProps["editor"]>;
        required: true;
    };
    node: {
        type: PropType< NodeViewProps["node"]>;
        required: true;
    };
    decorations: {
        type: PropType< NodeViewProps["decorations"]>;
        required: true;
    };
    selected: {
        type: PropType< NodeViewProps["selected"]>;
        required: true;
    };
    extension: {
        type: PropType< NodeViewProps["extension"]>;
        required: true;
    };
    getPos: {
        type: PropType< NodeViewProps["getPos"]>;
        required: true;
    };
    updateAttributes: {
        type: PropType< NodeViewProps["updateAttributes"]>;
        required: true;
    };
    deleteNode: {
        type: PropType< NodeViewProps["deleteNode"]>;
        required: true;
    };
    view: {
        type: PropType< NodeViewProps["view"]>;
        required: true;
    };
    innerDecorations: {
        type: PropType< NodeViewProps["innerDecorations"]>;
        required: true;
    };
    HTMLAttributes: {
        type: PropType< NodeViewProps["HTMLAttributes"]>;
        required: true;
    };
}>> & Readonly<{}>, {}, {}, {}, {}, string, ComponentProvideOptions, true, {
    containerRef: HTMLDivElement;
    imageRef: HTMLImageElement;
}, any>;
export default _default;
//# sourceMappingURL=ImageNodeView.vue.d.ts.map