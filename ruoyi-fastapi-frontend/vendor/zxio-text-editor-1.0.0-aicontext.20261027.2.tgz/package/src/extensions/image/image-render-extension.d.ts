import { Node as NodeExtension } from '@tiptap/core';
export declare const ImageRenderExtension: NodeExtension<{
    HTMLAttributes: Record<string, unknown>;
}, any>;
export default ImageRenderExtension;
//# sourceMappingURL=image-render-extension.d.ts.map