export { ImageExtension, type ImageExtensionOptions, type SetImageOptions, } from './image-extension';
//# sourceMappingURL=index.d.ts.map