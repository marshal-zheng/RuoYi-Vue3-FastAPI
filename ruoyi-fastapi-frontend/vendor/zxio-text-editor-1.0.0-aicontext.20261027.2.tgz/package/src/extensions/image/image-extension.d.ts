import { Node as NodeExtension } from '@tiptap/core';
import { ZxFileInputSource, ZxTextEditorFilePlatformRuntime } from '../../file-platform';
export interface ImageExtensionOptions {
    /**
     * Runtime bridge into the formal file intake and asset platform.
     * @default null
     */
    filePlatformRuntime: ZxTextEditorFilePlatformRuntime | null;
    /**
     * HTML attributes to add to the image element
     * @default {}
     */
    HTMLAttributes: Record<string, any>;
}
export interface SetImageOptions {
    assetId?: string | null;
    src: string;
    alt?: string;
    title?: string;
    width?: string | number | null;
    height?: string | number | null;
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        image: {
            /**
             * Insert an image
             */
            setImage: (options: SetImageOptions) => ReturnType;
            /**
             * Upload and insert an image through the unified file intake platform.
             */
            uploadImage: (file: File, source?: ZxFileInputSource) => ReturnType;
            /**
             * Select an image file using the file picker and upload it.
             */
            selectAndUploadImage: () => ReturnType;
            /**
             * Set image alignment
             */
            setImageAlign: (align: 'left' | 'center' | 'right') => ReturnType;
        };
    }
}
export declare const ImageExtension: NodeExtension<ImageExtensionOptions, any>;
//# sourceMappingURL=image-extension.d.ts.map