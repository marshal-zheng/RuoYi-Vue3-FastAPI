export { MentionExtension } from './mention-extension';
//# sourceMappingURL=index.d.ts.map