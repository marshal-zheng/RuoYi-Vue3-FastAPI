import { Node } from '@tiptap/core';
export declare const ImageGroupRenderExtension: Node<{
    HTMLAttributes: Record<string, unknown>;
}, any>;
export default ImageGroupRenderExtension;
//# sourceMappingURL=image-group-render-extension.d.ts.map