import { Node } from '@tiptap/core';
import { ZxTextEditorFilePlatformRuntime } from '../../file-platform';
import { TextEditorThemeOwnerPort } from '../../core/theme-owner-port';
export interface ImageGroupOptions {
    themeOwner: TextEditorThemeOwnerPort | null;
    /**
     * Runtime bridge into the formal file intake and asset platform.
     * @default null
     */
    filePlatformRuntime: ZxTextEditorFilePlatformRuntime | null;
    HTMLAttributes: Record<string, any>;
}
export interface ImageGroupAttrs {
    columns?: number;
    images: {
        src: string;
        alt?: string;
    }[];
}
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        imageGroup: {
            /**
             * Insert an image group/gallery node
             */
            setImageGroup: (attrs: {
                columns?: number;
                images: {
                    src: string;
                    alt?: string;
                }[];
            }) => ReturnType;
        };
    }
}
export declare const ImageGroup: Node<ImageGroupOptions, any>;
//# sourceMappingURL=image-group-extension.d.ts.map