import { PropType, DefineComponent, ExtractPropTypes, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
import { Editor } from '@tiptap/vue-3';
import { EditorPortalBindingView } from '../../theme-owner';
interface ExistingImage {
    src: string;
    alt: string;
}
declare const _default: DefineComponent<ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        required: true;
    };
    files: {
        type: PropType<File[]>;
        required: true;
    };
    editor: {
        type: PropType<Editor>;
        required: true;
    };
    mode: {
        type: PropType<"new" | "edit">;
        default: string;
    };
    existingImages: {
        type: PropType<ExistingImage[]>;
        default: undefined;
    };
    initialColumns: {
        type: NumberConstructor;
        default: undefined;
    };
    portalBinding: {
        type: PropType<EditorPortalBindingView>;
        required: true;
    };
}>, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    close: () => any;
    "update:modelValue": (value: boolean) => any;
    save: (value: {
        images: ExistingImage[];
        columns: number;
    }) => any;
    "update:files": (value: File[]) => any;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        required: true;
    };
    files: {
        type: PropType<File[]>;
        required: true;
    };
    editor: {
        type: PropType<Editor>;
        required: true;
    };
    mode: {
        type: PropType<"new" | "edit">;
        default: string;
    };
    existingImages: {
        type: PropType<ExistingImage[]>;
        default: undefined;
    };
    initialColumns: {
        type: NumberConstructor;
        default: undefined;
    };
    portalBinding: {
        type: PropType<EditorPortalBindingView>;
        required: true;
    };
}>> & Readonly<{
    onClose?: (() => any) | undefined;
    "onUpdate:modelValue"?: ((value: boolean) => any) | undefined;
    onSave?: ((value: {
        images: ExistingImage[];
        columns: number;
    }) => any) | undefined;
    "onUpdate:files"?: ((value: File[]) => any) | undefined;
}>, {
    mode: "new" | "edit";
    existingImages: ExistingImage[];
    initialColumns: number;
}, {}, {}, {}, string, ComponentProvideOptions, true, {}, any>;
export default _default;
//# sourceMappingURL=ImageGroupUploadDialog.vue.d.ts.map