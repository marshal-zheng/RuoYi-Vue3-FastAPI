import { InlineAiSkillDefinitionV1 } from './ai-authoring/inline-ai-surface';
import { InlineAiCapabilityDecisionV1, InlineAiCapabilityIdV1 } from './ai-authoring/inline-ai-interaction-coordinator';
import { InlineAiBubbleHandoffV1 } from './ai-authoring/inline-ai-bubble-handoff';
import { InlineAiBubbleEscapeChannelV1 } from './ai-authoring/inline-ai-bubble-escape-channel';
import { PropType, DefineComponent, ExtractPropTypes, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
import { EditorLike } from '../types';
import { EditorThemeOwner } from '../theme-owner';
/**
 * Notion-aligned selection bubble: Turn into + format grid + Skills + Edit with AI.
 * TipTap block/mark commands run in-menu; AI skills stay host-bridged.
 *
 * Prefer mounting inside TextEditor `#bottom` (or another in-editor slot) so the
 * TipTap BubbleMenu plugin registers against a live editor view.
 */
export declare const InlineAiBubbleMenu: DefineComponent<ExtractPropTypes<{
    themeOwner: {
        type: PropType<EditorThemeOwner | null>;
        default: null;
    };
    editor: {
        type: PropType<EditorLike | null>;
        default: null;
    };
    skills: {
        type: PropType<readonly InlineAiSkillDefinitionV1[]>;
        default: undefined;
    };
    disabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    capabilities: {
        type: PropType<Readonly<Record<InlineAiCapabilityIdV1, InlineAiCapabilityDecisionV1>> | null>;
        default: null;
    };
    /**
     * When true (e.g. product shell brewing/reviewing), hide the selection menu
     * so it does not stack under InlineAiSurface.
     */
    suppress: {
        type: BooleanConstructor;
        default: boolean;
    };
    /**
     * Optional per-editor state/action bridge for the catalog-owned Escape
     * adapter. The Bubble itself never registers a key listener.
     */
    escapeChannel: {
        type: PropType<InlineAiBubbleEscapeChannelV1 | null>;
        default: null;
    };
    options: {
        type: PropType<Record<string, unknown>>;
        default: () => {};
    };
    shouldShow: {
        type: PropType<((payload: {
            editor: unknown;
            state: unknown;
        }) => boolean) | null>;
        default: null;
    };
    pluginKey: {
        type: PropType<string | Record<string, unknown>>;
        default: "inlineAiBubbleMenu";
    };
}>, () => import("vue/jsx-runtime").JSX.Element | null, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    /**
     * `handoff` is the Bubble's receipt: hosts call `accept()` once their own
     * chrome takes over, or `reject(reason)` when the open fails closed so the
     * Bubble restores itself on the same selection with an inline notice.
     */
    'skill-invoke': (_skill: InlineAiSkillDefinitionV1, _target?: {
        readonly from: number;
        readonly to: number;
    } | null, _handoff?: InlineAiBubbleHandoffV1) => true;
    'edit-with-ai': (_target?: {
        readonly from: number;
        readonly to: number;
    } | null, _handoff?: InlineAiBubbleHandoffV1) => true;
    'prompt-submit': (_draft: string, _target?: {
        readonly from: number;
        readonly to: number;
    } | null, _handoff?: InlineAiBubbleHandoffV1) => true;
    'continue-review': () => true;
    'review-refine': (_draft: string) => true;
    'prompt-draft': (_draft: string) => true;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    themeOwner: {
        type: PropType<EditorThemeOwner | null>;
        default: null;
    };
    editor: {
        type: PropType<EditorLike | null>;
        default: null;
    };
    skills: {
        type: PropType<readonly InlineAiSkillDefinitionV1[]>;
        default: undefined;
    };
    disabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    capabilities: {
        type: PropType<Readonly<Record<InlineAiCapabilityIdV1, InlineAiCapabilityDecisionV1>> | null>;
        default: null;
    };
    /**
     * When true (e.g. product shell brewing/reviewing), hide the selection menu
     * so it does not stack under InlineAiSurface.
     */
    suppress: {
        type: BooleanConstructor;
        default: boolean;
    };
    /**
     * Optional per-editor state/action bridge for the catalog-owned Escape
     * adapter. The Bubble itself never registers a key listener.
     */
    escapeChannel: {
        type: PropType<InlineAiBubbleEscapeChannelV1 | null>;
        default: null;
    };
    options: {
        type: PropType<Record<string, unknown>>;
        default: () => {};
    };
    shouldShow: {
        type: PropType<((payload: {
            editor: unknown;
            state: unknown;
        }) => boolean) | null>;
        default: null;
    };
    pluginKey: {
        type: PropType<string | Record<string, unknown>>;
        default: "inlineAiBubbleMenu";
    };
}>> & Readonly<{
    "onContinue-review"?: (() => any) | undefined;
    "onReview-refine"?: ((_draft: string) => any) | undefined;
    "onEdit-with-ai"?: ((_target?: {
        readonly from: number;
        readonly to: number;
    } | null | undefined, _handoff?: InlineAiBubbleHandoffV1 | undefined) => any) | undefined;
    "onSkill-invoke"?: ((_skill: InlineAiSkillDefinitionV1, _target?: {
        readonly from: number;
        readonly to: number;
    } | null | undefined, _handoff?: InlineAiBubbleHandoffV1 | undefined) => any) | undefined;
    "onPrompt-submit"?: ((_draft: string, _target?: {
        readonly from: number;
        readonly to: number;
    } | null | undefined, _handoff?: InlineAiBubbleHandoffV1 | undefined) => any) | undefined;
    "onPrompt-draft"?: ((_draft: string) => any) | undefined;
}>, {
    editor: EditorLike | null;
    disabled: boolean;
    capabilities: Readonly<Record<InlineAiCapabilityIdV1, InlineAiCapabilityDecisionV1>> | null;
    options: Record<string, unknown>;
    pluginKey: string | Record<string, unknown>;
    shouldShow: ((payload: {
        editor: unknown;
        state: unknown;
    }) => boolean) | null;
    themeOwner: EditorThemeOwner | null;
    skills: readonly InlineAiSkillDefinitionV1[];
    suppress: boolean;
    escapeChannel: InlineAiBubbleEscapeChannelV1 | null;
}, {}, {}, {}, string, ComponentProvideOptions, true, {}, any>;
export default InlineAiBubbleMenu;
//# sourceMappingURL=inline-ai-bubble-menu.d.ts.map