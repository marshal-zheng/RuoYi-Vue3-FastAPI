import { DefineComponent, ExtractPropTypes, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
declare const _default: DefineComponent<ExtractPropTypes<{
    modelValue: {
        type: StringConstructor;
        required: true;
    };
    maxLength: {
        type: NumberConstructor;
        default: number;
    };
    placeholder: {
        type: StringConstructor;
        default: string;
    };
}>, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    "update:modelValue": (value: string) => any;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    modelValue: {
        type: StringConstructor;
        required: true;
    };
    maxLength: {
        type: NumberConstructor;
        default: number;
    };
    placeholder: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
}>, {
    placeholder: string;
    maxLength: number;
}, {}, {}, {}, string, ComponentProvideOptions, true, {
    inputRef: HTMLInputElement;
}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=code-block-title.vue.d.ts.map