import { ZxCodeBlockDisplayRow, ZxCodeBlockLocalEditRequest } from '../code-block';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    rows: readonly ZxCodeBlockDisplayRow[];
    code: string;
    language: string | null;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    "toggle-fold": (rangeKey: string) => any;
    "request-edit": (request: ZxCodeBlockLocalEditRequest) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onToggle-fold"?: ((rangeKey: string) => any) | undefined;
    "onRequest-edit"?: ((request: ZxCodeBlockLocalEditRequest) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLPreElement>;
export default _default;
//# sourceMappingURL=code-block-folded-projection.vue.d.ts.map