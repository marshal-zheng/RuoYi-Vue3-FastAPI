import { FloatingCommentsProps } from '../types/comment';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
import { ZxAnnotation } from '..';
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: {
        default?(_: {}): any;
    };
    refs: {};
    rootEl: HTMLDivElement;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: DefineComponent<FloatingCommentsProps, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    create: (data: {
        annotation: ZxAnnotation;
    }) => any;
    delete: (annotationId: string) => any;
    activate: (annotationId: string) => any;
    edit: (data: {
        annotationId: string;
        commentId: string;
        content: string;
    }) => any;
    resolve: (annotationId: string) => any;
    reply: (data: {
        annotationId: string;
        content: string;
    }) => any;
}, string, PublicProps, Readonly<FloatingCommentsProps> & Readonly<{
    onCreate?: ((data: {
        annotation: ZxAnnotation;
    }) => any) | undefined;
    onDelete?: ((annotationId: string) => any) | undefined;
    onActivate?: ((annotationId: string) => any) | undefined;
    onEdit?: ((data: {
        annotationId: string;
        commentId: string;
        content: string;
    }) => any) | undefined;
    onResolve?: ((annotationId: string) => any) | undefined;
    onReply?: ((data: {
        annotationId: string;
        content: string;
    }) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLDivElement>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
//# sourceMappingURL=floating-comments.vue.d.ts.map