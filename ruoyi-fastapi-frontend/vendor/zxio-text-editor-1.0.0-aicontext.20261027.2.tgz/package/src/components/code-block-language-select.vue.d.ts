import { PropType, DefineComponent, ExtractPropTypes, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
interface LanguageOption {
    label: string;
    value: string;
}
declare const _default: DefineComponent<ExtractPropTypes<{
    modelValue: {
        type: PropType<string | null>;
        required: true;
    };
    languageOptions: {
        type: PropType<LanguageOption[]>;
        default: undefined;
    };
    recentLanguages: {
        type: PropType<string[]>;
        default: () => never[];
    };
    defaultLanguage: {
        type: PropType<string | null>;
        default: null;
    };
}>, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    change: (value: string | null) => any;
    "update:modelValue": (value: string | null) => any;
    "dropdown-visible-change": (visible: boolean) => any;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    modelValue: {
        type: PropType<string | null>;
        required: true;
    };
    languageOptions: {
        type: PropType<LanguageOption[]>;
        default: undefined;
    };
    recentLanguages: {
        type: PropType<string[]>;
        default: () => never[];
    };
    defaultLanguage: {
        type: PropType<string | null>;
        default: null;
    };
}>> & Readonly<{
    onChange?: ((value: string | null) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | null) => any) | undefined;
    "onDropdown-visible-change"?: ((visible: boolean) => any) | undefined;
}>, {
    recentLanguages: string[];
    defaultLanguage: string | null;
    languageOptions: LanguageOption[];
}, {}, {}, {}, string, ComponentProvideOptions, true, {}, any>;
export default _default;
//# sourceMappingURL=code-block-language-select.vue.d.ts.map