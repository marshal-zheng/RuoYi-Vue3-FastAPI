import { ComputedRef, Ref } from 'vue';
export type InlineAiBubbleEscapeStageV1 = 'bubble' | 'selection' | null;
export interface InlineAiBubbleEscapeChannelV1 {
    /** Current progressive Escape layer owned by the connected selection session. */
    readonly stage: ComputedRef<InlineAiBubbleEscapeStageV1>;
    /** True while either the Bubble or its dismissed selection owns Escape. */
    readonly active: ComputedRef<boolean>;
    /**
     * Advance one Escape layer: Bubble -> selection -> inactive. The historical
     * V1 name is retained for API compatibility.
     */
    readonly dismiss: () => boolean;
}
interface InlineAiBubbleEscapeParticipantV1 {
    readonly stage: Readonly<Ref<InlineAiBubbleEscapeStageV1>>;
    readonly dismiss: () => void;
}
/**
 * Per-editor bridge between the selection Bubble's private session and the
 * catalog-owned shell Escape adapter. The channel exposes state/action only;
 * it never registers a DOM listener or creates a second shortcut owner.
 */
export declare const createInlineAiBubbleEscapeChannel: () => InlineAiBubbleEscapeChannelV1;
/**
 * Component-side ownership seam. A channel may bind one Bubble at a time;
 * duplicate mounts for the same editor are deterministic wiring errors.
 */
export declare const bindInlineAiBubbleEscapeChannel: (channel: InlineAiBubbleEscapeChannelV1, participant: InlineAiBubbleEscapeParticipantV1) => (() => void);
export {};
//# sourceMappingURL=inline-ai-bubble-escape-channel.d.ts.map