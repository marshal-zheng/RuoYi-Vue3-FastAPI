import { InlineReviewActions } from '../../shortcuts/inline-review-actions';
import { InlineDiffChromeBusyIntentV1, InlineDiffChromeControlsV1, InlineDiffChromeHunkReviewV1, InlineDiffChromeIntentV1, InlineDiffChromePresentationV1 } from './inline-diff-chrome';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    readonly presentation: InlineDiffChromePresentationV1;
    readonly controls: InlineDiffChromeControlsV1;
    readonly busyIntent?: InlineDiffChromeBusyIntentV1 | null;
    /** The instruction this diff answers (Cursor-style prompt echo). */
    readonly promptEcho?: string;
    /** Staged per-hunk verdicts (block diff): counts + primary button mode. */
    readonly hunkReview?: InlineDiffChromeHunkReviewV1 | null;
    /** Host-authored screen-reader announcement (verdict changes, focus). */
    readonly liveMessage?: string;
    readonly reviewActions?: InlineReviewActions | null;
};
declare const _default: DefineComponent<__VLS_Props, {
    /** Host focus target after the last hunk is decided (no pending left). */
    focusPrimary: () => void | undefined;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    intent: (intent: InlineDiffChromeIntentV1) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onIntent?: ((intent: InlineDiffChromeIntentV1) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    rootEl: HTMLElement;
}, any>;
export default _default;
//# sourceMappingURL=InlineDiffChrome.vue.d.ts.map