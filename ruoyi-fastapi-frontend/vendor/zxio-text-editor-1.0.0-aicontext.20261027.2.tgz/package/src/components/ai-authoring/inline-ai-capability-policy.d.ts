import { InlineAiCoordinatorInputV1, InlineAiCoordinatorProjectionV1, InlineAiPresentationSnapshotV1, InlineAiPromptGateV1, InlineAiRecoverySurfaceIdV1, InlineAiSurfaceIdV1, InlineAiTargetRelationV1, InlineAiTaskActivityV1 } from './inline-ai-interaction-contract';
import { ZxAIAuthoringActionIdV1, ZxAIAuthoringProjectionV1, ZxAIAuthoringReviewRefinementProjectionV1 } from '../../ai/authoring-ux';
export declare const isOpenInlineAiActivityV1: (activity: InlineAiTaskActivityV1) => activity is {
    readonly kind: "request";
    readonly requestId: string;
} | {
    readonly kind: "review";
    readonly reviewId: string;
} | {
    readonly kind: "review-refinement";
    readonly refinement: ZxAIAuthoringReviewRefinementProjectionV1;
};
export declare const deriveInlineAiTaskActivityV1: (input: InlineAiCoordinatorInputV1) => InlineAiTaskActivityV1;
export declare const deriveInlineAiVisibleSurfacesV1: (input: {
    readonly liveSelection: boolean;
    readonly presentation: InlineAiPresentationSnapshotV1;
    readonly activity: InlineAiTaskActivityV1;
    readonly authoringState: ZxAIAuthoringProjectionV1["state"];
}) => readonly InlineAiSurfaceIdV1[];
export declare const deriveInlineAiRecoverySurfacesV1: (input: {
    readonly activity: InlineAiTaskActivityV1;
    readonly presentation: InlineAiPresentationSnapshotV1;
    readonly liveSelection: boolean;
    readonly authoringState: ZxAIAuthoringProjectionV1["state"];
    readonly refinementRetryAvailable: boolean;
}) => readonly InlineAiRecoverySurfaceIdV1[];
export declare const deriveInlineAiCapabilitiesV1: (input: {
    readonly activity: InlineAiTaskActivityV1;
    readonly liveSelection: boolean;
    readonly targetRelation: InlineAiTargetRelationV1;
    readonly presentation: InlineAiPresentationSnapshotV1;
    readonly promptGate: InlineAiPromptGateV1;
    readonly actions: ZxAIAuthoringProjectionV1["actions"];
    readonly pendingActionId?: ZxAIAuthoringActionIdV1;
    readonly reviewPresentationGate: InlineAiCoordinatorInputV1["reviewPresentationGate"];
}) => InlineAiCoordinatorProjectionV1["capabilities"];
//# sourceMappingURL=inline-ai-capability-policy.d.ts.map