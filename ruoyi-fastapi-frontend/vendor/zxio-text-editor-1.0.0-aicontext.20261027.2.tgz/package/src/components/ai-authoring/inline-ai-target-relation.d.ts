import { ZxAIAuthoringTargetBindingV1 } from '../../ai/authoring-ux';
import { InlineAiTargetRelationV1 } from './inline-ai-interaction-contract';
export declare const relateInlineAiTargetsV1: (input: {
    readonly editorBindingId: string;
    readonly liveTarget?: ZxAIAuthoringTargetBindingV1;
    readonly activeTarget?: ZxAIAuthoringTargetBindingV1;
}) => InlineAiTargetRelationV1;
//# sourceMappingURL=inline-ai-target-relation.d.ts.map