import { ASK_AI_BLOCK_MENU_ITEM_ID_V1, ZxAskAIBridgeV1 } from '../../ai/authoring-ux/ask-ai-bridge';
import { SlashCatalogContribution } from '../../extensions/slash-commands/catalog';
import { TextEditorToolbarContribution } from '../../toolbar/registry';
import { InlineAiSkillDefinitionV1 } from './inline-ai-surface';
export interface ZxAskAIBlockMenuItemV1 {
    readonly id: typeof ASK_AI_BLOCK_MENU_ITEM_ID_V1;
    readonly label: string;
    readonly shortcutBindingId: 'textEditor.askAI.open';
}
export declare const ASK_AI_BLOCK_MENU_ITEMS_V1: readonly ZxAskAIBlockMenuItemV1[];
export declare const createAskAISlashCatalogContribution: (options: {
    readonly bridge: ZxAskAIBridgeV1;
    readonly label?: string;
    readonly description?: string;
}) => SlashCatalogContribution;
export interface CreateAskAIBubbleToolbarContributionOptions {
    readonly bridge: ZxAskAIBridgeV1;
    readonly label?: string;
    readonly disabled?: boolean | (() => boolean);
    readonly skills?: readonly InlineAiSkillDefinitionV1[];
    /**
     * Required named-Skill one-shot via S6 public path (IAS-C3).
     * Hosts must open + submit the mapped descriptor; the contribution never
     * silently degrades a Skill click to “open shell only”.
     */
    readonly onSkillInvoke: (skill: InlineAiSkillDefinitionV1) => void | Promise<void>;
    /** Edit with AI → inline prompt / user-input (not engineering PromptSurface). */
    readonly onEditWithAI?: () => void | Promise<void>;
}
/**
 * @deprecated Prefer `InlineAiBubbleMenu` + `InlineAiSelectionMenu` for the
 * Notion-aligned selection IA (Skills section + Edit with AI). Keep this
 * dropdown contribution only when embedding Skills inside a traditional
 * horizontal bubble toolbar.
 *
 * Bubble Skills IA: Skills dropdown + Edit with AI (IAS-C1).
 */
export declare const createAskAIBubbleToolbarContribution: (options: CreateAskAIBubbleToolbarContributionOptions) => TextEditorToolbarContribution;
//# sourceMappingURL=ask-ai-chrome.d.ts.map