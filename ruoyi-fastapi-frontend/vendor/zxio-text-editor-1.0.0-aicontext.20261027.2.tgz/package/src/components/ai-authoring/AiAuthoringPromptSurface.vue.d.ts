import { ZxAIAuthoringActionIdV1, ZxAIAuthoringCommandAvailabilityV1, ZxAIAuthoringCommandDescriptorV1, ZxAIAuthoringProductScopeV1, ZxAIAuthoringProjectionV1, ZxAIAuthoringContextKindV1 } from '../../ai/authoring-ux';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
interface AiAuthoringPromptSurfaceProps {
    readonly editorBindingId: string;
    readonly projection: ZxAIAuthoringProjectionV1;
    readonly commands: readonly {
        readonly descriptor: ZxAIAuthoringCommandDescriptorV1;
        readonly availability: ZxAIAuthoringCommandAvailabilityV1;
    }[];
    readonly productScope: ZxAIAuthoringProductScopeV1;
    readonly blockCount: number;
    readonly impactLabel: string;
    readonly targetSummary?: string;
    readonly allowedScopes?: readonly ZxAIAuthoringProductScopeV1[];
    readonly scopeExpansionRequiresConfirmation?: boolean;
    readonly scopeExpansionConfirmed?: boolean;
    readonly initialDraftPrompt?: string;
    readonly title?: string;
    readonly promptLabel?: string;
    readonly labelFor?: (key: string) => string;
}
declare const _default: DefineComponent<AiAuthoringPromptSurfaceProps, {
    focusPrompt: () => void | undefined;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    action: (actionId: ZxAIAuthoringActionIdV1) => any;
    "command-change": (commandId: string) => any;
    "draft-change": (draftPrompt: string) => any;
    "scope-change": (scope: ZxAIAuthoringContextKindV1) => any;
    "scope-expansion-change": (confirmed: boolean) => any;
}, string, PublicProps, Readonly<AiAuthoringPromptSurfaceProps> & Readonly<{
    onAction?: ((actionId: ZxAIAuthoringActionIdV1) => any) | undefined;
    "onCommand-change"?: ((commandId: string) => any) | undefined;
    "onDraft-change"?: ((draftPrompt: string) => any) | undefined;
    "onScope-change"?: ((scope: ZxAIAuthoringContextKindV1) => any) | undefined;
    "onScope-expansion-change"?: ((confirmed: boolean) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    shortcutRoot: HTMLElement;
    inputElement: HTMLInputElement;
}, HTMLElement>;
export default _default;
//# sourceMappingURL=AiAuthoringPromptSurface.vue.d.ts.map