export interface InlineAiFocusTokenV1 {
    readonly instanceId: string;
    readonly expiresAt: number;
    readonly revoked: boolean;
}
export interface InlineAiFocusTokenStoreV1 {
    readonly create: (ttlMs?: number) => InlineAiFocusTokenV1;
    readonly current: () => InlineAiFocusTokenV1 | null;
    readonly revoke: () => void;
    readonly isActive: (token?: InlineAiFocusTokenV1 | null) => boolean;
}
export declare const createInlineAiFocusTokenStoreV1: (instanceId?: string) => InlineAiFocusTokenStoreV1;
export declare const claimInlineAiFocusOnPointerDown: (input: {
    readonly event: PointerEvent | MouseEvent;
    readonly claim: () => void;
    readonly inputEl?: HTMLElement | null;
    readonly focusToken?: InlineAiFocusTokenStoreV1;
}) => void;
export declare const scheduleInlineAiLazyFocusV1: (input: {
    readonly claim: () => void;
    readonly focusToken: InlineAiFocusTokenStoreV1;
    readonly getInput: () => HTMLElement | null | undefined;
    readonly afterGeometry?: () => void | Promise<void>;
    readonly raf?: (cb: FrameRequestCallback) => number;
}) => InlineAiFocusTokenV1;
export declare const shouldIgnoreInlineAiFocusKeyV1: (event: KeyboardEvent) => boolean;
/**
 * Geometry / scroll / visualViewport changes must not close the selection
 * session. Hosts should call this instead of treating those as chrome blur.
 */
export declare const isInlineAiGeometryNoiseEventV1: (input: {
    readonly kind: "geometry" | "scroll" | "visualViewport" | "other";
}) => boolean;
//# sourceMappingURL=inline-ai-focus-protocol.d.ts.map