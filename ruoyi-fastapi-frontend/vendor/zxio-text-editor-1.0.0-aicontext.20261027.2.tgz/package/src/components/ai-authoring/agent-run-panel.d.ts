export type AgentRunPanelCommandV1 = {
    readonly kind: 'abort-run';
} | {
    readonly kind: 'approve-tool';
} | {
    readonly kind: 'deny-tool';
} | {
    readonly kind: 'cancel-tool';
} | {
    readonly kind: 'review-item';
    readonly ordinal: number;
} | {
    readonly kind: 'retry-item';
    readonly ordinal: number;
} | {
    readonly kind: 'reveal-citation';
    readonly ordinal: number;
};
//# sourceMappingURL=agent-run-panel.d.ts.map