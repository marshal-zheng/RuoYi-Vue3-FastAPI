/**
 * Single source of truth for one "selection AI" interaction.
 *
 * Before this existed, four things independently guessed whether the bubble was
 * open: TipTap's `shouldShow`, a mirrored `selectionUpdate` listener, the gray
 * retained decoration, and the host's live/decoration/bookmark precedence chain.
 * They drifted. Everything now derives from the session below:
 *
 * - visibility  → `active.phase !== 'dismissed'`
 * - chrome reset → `active.openId` used as a Vue `key` (dialog semantics)
 * - gray mark   → `active.owned`
 * - AI target   → `{ active.from, active.to }`
 *
 * The reducer is pure so the transitions are testable without a live editor.
 */
export interface InlineAiSelectionSessionV1 {
    /**
     * Monotonic across opens. TipTap keeps the bubble's Vue child mounted while
     * hidden, so a changing id is what makes hide→show start from a clean slate.
     */
    readonly openId: number;
    readonly from: number;
    readonly to: number;
    /**
     * Direction-preserving ProseMirror bookmark. Optional so the additive V1
     * contract still accepts older callers that only supplied `{ from, to }`.
     */
    readonly anchor?: number;
    readonly head?: number;
    /**
     * `dismissed` keeps the bookmark and mounted menu state, but suppresses the
     * Bubble until the user creates a genuinely new selection interaction.
     * Missing means `active` for backward-compatible V1 values.
     */
    readonly phase?: InlineAiSelectionSessionPhaseV1;
    /**
     * AI chrome (the Edit with AI input) holds focus. The editor selection has
     * collapsed as a side effect of that focus move, not because the user is done.
     */
    readonly owned: boolean;
}
export interface InlineAiSelectionSessionStateV1 {
    /** Kept across closes so consecutive opens never reuse an `openId`. */
    readonly openCount: number;
    /**
     * Historical V1 field name. It now means the current selection interaction,
     * whose phase can be either active or dismissed; `null` means fully ended.
     */
    readonly active: InlineAiSelectionSessionV1 | null;
}
export interface InlineAiSelectionRangeV1 {
    readonly from: number;
    readonly to: number;
    readonly anchor?: number;
    readonly head?: number;
}
export interface InlineAiSelectionBookmarkV1 {
    readonly anchor: number;
    readonly head: number;
    readonly from: number;
    readonly to: number;
}
export type InlineAiSelectionSessionPhaseV1 = 'active' | 'dismissed';
export type InlineAiSelectionSessionEventV1 = 
/** Editor state changed; `eligible` is TipTap's own `shouldShow` verdict. */
{
    readonly kind: 'selection-sync';
    readonly eligible: boolean;
    readonly range: InlineAiSelectionRangeV1 | null;
}
/** Focus moved into AI chrome — pin the session against selection collapse. */
 | {
    readonly kind: 'chrome-focus';
}
/** Escape: hide chrome but keep its bookmark and local prompt draft alive. */
 | {
    readonly kind: 'dismiss';
    /** Optional mapped bookmark when document transactions moved the range. */
    readonly range?: InlineAiSelectionRangeV1;
}
/** Terminal: click-outside, editor refocus, suppress, handoff, or new gesture. */
 | {
    readonly kind: 'end';
}
/**
 * A host declined the interaction it was handed (fail-closed open). Reopen
 * that exact interaction so the user is never left with a bare selection.
 */
 | {
    readonly kind: 'restore';
    readonly session: InlineAiSelectionSessionV1;
};
export declare const INLINE_AI_SELECTION_SESSION_INITIAL_V1: InlineAiSelectionSessionStateV1;
export declare const inlineAiSelectionSessionIsVisible: (state: InlineAiSelectionSessionStateV1) => boolean;
export declare const reduceInlineAiSelectionSession: (state: InlineAiSelectionSessionStateV1, event: InlineAiSelectionSessionEventV1) => InlineAiSelectionSessionStateV1;
export declare const inlineAiSelectionSessionRange: (state: InlineAiSelectionSessionStateV1) => InlineAiSelectionRangeV1 | null;
export declare const inlineAiSelectionSessionBookmark: (state: InlineAiSelectionSessionStateV1) => InlineAiSelectionBookmarkV1 | null;
/** Stable Vue `key`; only changes when a genuinely new session opens. */
export declare const inlineAiSelectionSessionKey: (state: InlineAiSelectionSessionStateV1) => number;
//# sourceMappingURL=inline-ai-selection-session.d.ts.map