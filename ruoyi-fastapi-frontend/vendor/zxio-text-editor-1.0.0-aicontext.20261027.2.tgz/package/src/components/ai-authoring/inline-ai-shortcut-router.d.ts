import { ZxAIAuthoringActionBindingV1, ZxAIAuthoringInvocationContextV1, ZxAIAuthoringProjectionV1 } from '../../ai/authoring-ux';
import { InlineAiCoordinatorProjectionV1 } from './inline-ai-interaction-contract';
export type InlineEditShortcutSelectionReasonV1 = 'selection-required' | 'collapsed-selection' | 'multi-block-selection' | 'unsupported-node' | 'baseline-invalid';
export type InlineEditShortcutSelectionPreflightV1 = {
    readonly status: 'valid';
    readonly invocationContext: ZxAIAuthoringInvocationContextV1;
} | {
    readonly status: 'invalid';
    readonly reason?: InlineEditShortcutSelectionReasonV1;
};
export type InlineEditShortcutClosedReasonV1 = 'task-open' | InlineEditShortcutSelectionReasonV1;
type InlineEditShortcutCoordinatorInputV1 = Pick<InlineAiCoordinatorProjectionV1, 'taskActivity' | 'capabilities'>;
type InlineEditShortcutAuthoringInputV1 = Pick<ZxAIAuthoringProjectionV1, 'editorBindingId' | 'fingerprint' | 'sessionRef' | 'reviewRef' | 'actions'>;
export interface InlineEditShortcutRouteInputV1 {
    readonly coordinator: InlineEditShortcutCoordinatorInputV1;
    readonly authoring: InlineEditShortcutAuthoringInputV1;
    readonly actionBinding?: ZxAIAuthoringActionBindingV1;
    readonly selectionPreflight: InlineEditShortcutSelectionPreflightV1;
}
export type InlineEditShortcutRouteV1 = {
    readonly kind: 'reveal';
    readonly actionId: 'reveal';
    readonly binding: ZxAIAuthoringActionBindingV1;
} | {
    readonly kind: 'open';
    readonly invocationContext: ZxAIAuthoringInvocationContextV1;
} | {
    readonly kind: 'closed';
    readonly reason: InlineEditShortcutClosedReasonV1;
};
/**
 * Closed, deterministic router for catalog `textEditor.inlineEdit.open`.
 *
 * It neither captures selection nor calls Host Owner. The Vue adapter executes
 * the returned route with the exact objects supplied by the latest projection.
 */
export declare const routeInlineEditShortcutV1: (input: InlineEditShortcutRouteInputV1) => InlineEditShortcutRouteV1;
export {};
//# sourceMappingURL=inline-ai-shortcut-router.d.ts.map