import { VirtualElement } from '@floating-ui/dom';
import { ZxAIAuthoringGeometryAnchorV1 } from '../../ai/authoring-ux';
export interface InlineAiAnchorRectV1 {
    readonly left: number;
    readonly top: number;
    readonly width: number;
    readonly height: number;
    readonly right: number;
    readonly bottom: number;
    readonly x: number;
    readonly y: number;
}
export interface InlineAiViewportRectV1 {
    readonly left: number;
    readonly top: number;
    readonly right: number;
    readonly bottom: number;
    readonly width: number;
    readonly height: number;
}
/** TipTap/ProseMirror selection bookmark — stable under scroll; re-resolve via coordsAtPos. */
export interface InlineAiSelectionPosAnchorV1 {
    readonly from: number;
    readonly to: number;
}
export interface InlineAiEditorViewLike {
    readonly state: {
        readonly selection: {
            readonly from: number;
            readonly to: number;
        };
    };
    coordsAtPos: (pos: number) => {
        left: number;
        right: number;
        top: number;
        bottom: number;
    };
}
export interface InlineAiWindowLike {
    readonly innerWidth: number;
    readonly innerHeight: number;
    readonly visualViewport?: {
        readonly offsetLeft: number;
        readonly offsetTop: number;
        readonly width: number;
        readonly height: number;
        addEventListener?: (type: 'resize' | 'scroll', listener: () => void) => void;
        removeEventListener?: (type: 'resize' | 'scroll', listener: () => void) => void;
    } | null;
}
/**
 * Resolve the visible viewport rect. Prefer visualViewport metrics; never use
 * documentElement.getBoundingClientRect (layout/document box ≠ visible viewport).
 */
export declare const resolveInlineAiViewportRectV1: (windowLike?: InlineAiWindowLike, paddingPx?: number) => InlineAiViewportRectV1;
export declare const prefersInlineAiReducedMotionV1: (matchMedia?: ((query: string) => {
    matches: boolean;
}) | undefined) => boolean;
export declare const applyInlineAiReducedMotionSurfaceV1: (element: HTMLElement) => void;
/**
 * One public size middleware contract for every Inline AI floating surface.
 * Keeping the CSS variables identical prevents Bubble / Prompt / Response
 * from drifting into separate viewport policies.
 */
export declare const applyInlineAiAvailableSizeV1: (input: {
    readonly availableWidth: number;
    readonly availableHeight: number;
    readonly elements: {
        readonly floating: HTMLElement;
    };
}) => void;
export declare const INLINE_AI_FLOATING_FLIP_OPTIONS_V1: Readonly<{
    fallbackPlacements: ["top-start"];
}>;
export declare const INLINE_AI_FLOATING_SHIFT_OPTIONS_V1: Readonly<{
    padding: 8;
    crossAxis: true;
}>;
export declare const INLINE_AI_FLOATING_SIZE_OPTIONS_V1: Readonly<{
    padding: 8;
    apply: (input: {
        readonly availableWidth: number;
        readonly availableHeight: number;
        readonly elements: {
            readonly floating: HTMLElement;
        };
    }) => void;
}>;
/** Capture selection/caret client rects from a TipTap/ProseMirror-like editor view. */
export declare const captureInlineAiSelectionAnchor: (input: {
    readonly view?: InlineAiEditorViewLike | null;
}) => ZxAIAuthoringGeometryAnchorV1 | undefined;
/** Bookmark TipTap selection positions for live re-anchoring across scroll. */
export declare const captureInlineAiSelectionPos: (input: {
    readonly view?: InlineAiEditorViewLike | null;
}) => InlineAiSelectionPosAnchorV1 | undefined;
/**
 * Resolve a fresh viewport rect from TipTap `coordsAtPos` for a bookmarked
 * selection. This is the scroll-safe path — not a one-shot frozen snapshot.
 */
export declare const resolveInlineAiSelectionAnchor: (input: {
    readonly view: InlineAiEditorViewLike;
    readonly selection: InlineAiSelectionPosAnchorV1;
}) => ZxAIAuthoringGeometryAnchorV1 | undefined;
export declare const inlineAiAnchorToClientRect: (anchor: ZxAIAuthoringGeometryAnchorV1) => InlineAiAnchorRectV1;
export declare const createInlineAiAnchorVirtualElement: (getAnchor: () => ZxAIAuthoringGeometryAnchorV1 | undefined) => VirtualElement;
/**
 * Shared fixed + visualViewport protocol for Bubble / Prompt / Response.
 */
export declare const computeInlineAiAnchorStyle: (input: {
    readonly anchor?: ZxAIAuthoringGeometryAnchorV1;
    readonly getAnchor?: () => ZxAIAuthoringGeometryAnchorV1 | undefined;
    readonly floating: HTMLElement;
}) => Promise<Record<string, string>>;
export type InlineAiAnchorAutoUpdateHandleV1 = (() => void) & {
    readonly ready: Promise<void>;
};
/**
 * Keep the product shell pinned to a live TipTap selection rect while open.
 * Also listens to visualViewport resize/scroll when available.
 * `ready` resolves after the first Floating UI computePosition (flip/shift/size) applies.
 */
export declare const bindInlineAiAnchorAutoUpdate: (input: {
    readonly getAnchor: () => ZxAIAuthoringGeometryAnchorV1 | undefined;
    readonly floating: HTMLElement;
    readonly onStyle: (style: Record<string, string>) => void;
    readonly windowLike?: InlineAiWindowLike;
}) => InlineAiAnchorAutoUpdateHandleV1;
/** Synchronous fallback when floating element is not measured yet. */
export declare const fallbackInlineAiAnchorStyle: (anchor: ZxAIAuthoringGeometryAnchorV1) => Record<string, string>;
//# sourceMappingURL=inline-ai-anchor.d.ts.map