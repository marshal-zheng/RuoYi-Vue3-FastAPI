import { AgentRunProjectionV1, ToolApprovalRequestV1 } from '../../agent-integration/contract';
import { AgentRunPanelCommandV1 } from './agent-run-panel';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    readonly projection: AgentRunProjectionV1;
    readonly toolApproval?: ToolApprovalRequestV1;
    readonly currentLogicalTime: number;
    readonly authorityBindingReady?: boolean;
    readonly principalBindingReady?: boolean;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    command: (command: AgentRunPanelCommandV1) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onCommand?: ((command: AgentRunPanelCommandV1) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    dialog: HTMLElement;
}, HTMLElement>;
export default _default;
//# sourceMappingURL=AgentRunPanel.vue.d.ts.map