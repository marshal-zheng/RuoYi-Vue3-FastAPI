import { InlineAiCommandInvocationV1, InlineAiContextReceiptV1, InlineAiPreferredModeV1, InlineAiResultApplicationV1, InlineAiSkillDefinitionV1 } from './inline-ai-surface';
import { ZxAIAuthoringActionIdV1, ZxAIAuthoringGeometryAnchorV1, ZxAIAuthoringProjectionV1, ZxAIAuthoringSurfaceV1 } from '../../ai/authoring-ux';
import { ZxAIReviewPresentationProjectionV1 } from '../../ai/review-presentation';
import { InlineDiffChromeIntentV1, InlineDiffChromeProjectionV1 } from './inline-diff-chrome';
import { EditorThemeOwner } from '../../theme-owner';
import { InlineReviewActions } from '../../shortcuts/inline-review-actions';
import { DefineComponent, Ref, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
interface InlineAiSurfaceProps {
    readonly themeOwner?: EditorThemeOwner | null;
    readonly projection: ZxAIAuthoringProjectionV1;
    readonly surfaceOpen: boolean;
    readonly surface?: ZxAIAuthoringSurfaceV1;
    readonly preferredMode?: InlineAiPreferredModeV1;
    readonly skills?: readonly InlineAiSkillDefinitionV1[];
    readonly contextReceipt?: InlineAiContextReceiptV1 | null;
    readonly resultApplication?: InlineAiResultApplicationV1;
    /** The host's clipboard write for this result was rejected. */
    readonly resultCopyFailed?: boolean;
    readonly followUpAvailable?: boolean;
    readonly initialDraft?: string;
    readonly composerNotice?: string;
    readonly hostStatusMessage?: string;
    readonly inlineDiffReview?: ZxAIReviewPresentationProjectionV1 | null;
    readonly inlineDiffChrome?: InlineDiffChromeProjectionV1 | null;
    /**
     * Block diff mode (Cursor form): the candidate already lives in the
     * document as insertion lines, so this shell renders only the composer
     * chrome and never the candidate text.
     */
    readonly documentDiffActive?: boolean;
    /** The instruction being answered — echoed in brewing and review chrome. */
    readonly promptEcho?: string;
    /** Screen-reader announcement for per-hunk verdict / focus changes. */
    readonly inlineDiffLiveMessage?: string;
    readonly reviewActions?: InlineReviewActions | null;
    /** Bump to re-measure the live anchor after an in-document repaint. */
    readonly anchorEpoch?: number;
    readonly anchor?: ZxAIAuthoringGeometryAnchorV1;
    /**
     * Live TipTap selection resolver (coordsAtPos). Prefer this over a frozen
     * `anchor` snapshot so the shell tracks scroll/resize.
     */
    readonly resolveAnchor?: () => ZxAIAuthoringGeometryAnchorV1 | undefined;
}
declare const _default: DefineComponent<InlineAiSurfaceProps, {
    rootElement: Ref<HTMLElement | undefined, HTMLElement | undefined>;
    shellState: Ref<"closed" | "skills" | "user-input" | "brewing" | "reviewing", "closed" | "skills" | "user-input" | "brewing" | "reviewing">;
    focusShell: () => Promise<void>;
    syncFloatingPosition: () => Promise<void>;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    action: (actionId: ZxAIAuthoringActionIdV1) => any;
    activate: () => any;
    "skill-invoke": (skill: InlineAiSkillDefinitionV1) => any;
    "draft-change": (draft: string) => any;
    "command-invoke": (invocation: InlineAiCommandInvocationV1) => any;
    "result-copy": (text: string) => any;
    "result-discard": () => any;
    "preferred-mode": (mode: InlineAiPreferredModeV1) => any;
    "inline-diff-intent": (intent: InlineDiffChromeIntentV1) => any;
}, string, PublicProps, Readonly<InlineAiSurfaceProps> & Readonly<{
    onAction?: ((actionId: ZxAIAuthoringActionIdV1) => any) | undefined;
    onActivate?: (() => any) | undefined;
    "onSkill-invoke"?: ((skill: InlineAiSkillDefinitionV1) => any) | undefined;
    "onDraft-change"?: ((draft: string) => any) | undefined;
    "onCommand-invoke"?: ((invocation: InlineAiCommandInvocationV1) => any) | undefined;
    "onResult-copy"?: ((text: string) => any) | undefined;
    "onResult-discard"?: (() => any) | undefined;
    "onPreferred-mode"?: ((mode: InlineAiPreferredModeV1) => any) | undefined;
    "onInline-diff-intent"?: ((intent: InlineDiffChromeIntentV1) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    rootEl: HTMLElement;
}, any>;
export default _default;
//# sourceMappingURL=InlineAiSurface.vue.d.ts.map