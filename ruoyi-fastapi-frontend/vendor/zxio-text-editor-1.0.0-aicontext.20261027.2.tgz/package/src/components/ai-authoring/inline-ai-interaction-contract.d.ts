import { ZxAIAuthoringProjectionV1, ZxAIAuthoringReviewBundleV1, ZxAIAuthoringReviewRefinementProjectionV1, ZxAIAuthoringTargetBindingV1 } from '../../ai/authoring-ux';
import { ZxAIReviewPresentationReasonV1 } from '../../ai/review-presentation';
import { ZxAISessionArtifactV1 } from '../../ai/session-transport';
export declare const INLINE_AI_VIEWPORT_PADDING_PX: 8;
export declare const INLINE_AI_MAX_SCROLL_DELTA_PX: 24;
export type InlineAiSelectionPhaseV1 = 'none' | 'live' | 'retained';
export interface InlineAiSelectionSnapshotV1 {
    readonly phase: InlineAiSelectionPhaseV1;
    readonly liveTarget?: ZxAIAuthoringTargetBindingV1;
    readonly retainedTarget?: ZxAIAuthoringTargetBindingV1;
}
export interface InlineAiPresentationSnapshotV1 {
    readonly selectionBubbleRequested: boolean;
    readonly selectionPromptVisible: boolean;
    readonly productComposerVisible: boolean;
    readonly responseVisible: boolean;
    readonly reviewPreviewVisible: boolean;
    readonly taskIndicatorVisible: boolean;
}
export interface InlineAiPromptGateV1 {
    readonly hasValidPrompt: boolean;
}
export interface InlineAiReviewPresentationGateV1 {
    readonly status: 'empty' | 'provisional' | 'verified' | 'degraded' | 'unverified' | 'unsupported';
    readonly sourceFingerprint?: string;
    readonly reason?: ZxAIReviewPresentationReasonV1;
}
export interface InlineAiCoordinatorInputV1 {
    readonly editorBindingId: string;
    readonly projection: ZxAIAuthoringProjectionV1;
    readonly session: ZxAISessionArtifactV1 | null;
    readonly exactActiveReview: ZxAIAuthoringReviewBundleV1 | null;
    readonly reviewRefinement: ZxAIAuthoringReviewRefinementProjectionV1 | null;
    readonly selection: InlineAiSelectionSnapshotV1;
    readonly presentation: InlineAiPresentationSnapshotV1;
    readonly promptGate: InlineAiPromptGateV1;
    readonly reviewPresentationGate: InlineAiReviewPresentationGateV1;
}
export type InlineAiTaskActivityV1 = {
    readonly kind: 'none';
} | {
    readonly kind: 'request';
    readonly requestId: string;
} | {
    readonly kind: 'review';
    readonly reviewId: string;
} | {
    readonly kind: 'review-refinement';
    readonly refinement: ZxAIAuthoringReviewRefinementProjectionV1;
} | {
    readonly kind: 'invalid';
    readonly reason: 'authority-mismatch';
};
export type InlineAiTargetRelationV1 = 'disjoint' | 'overlap' | 'unknown';
export type InlineAiSurfaceIdV1 = 'selection-bubble' | 'selection-prompt' | 'product-composer' | 'response' | 'review-preview' | 'task-indicator';
export type InlineAiCapabilityIdV1 = 'format' | 'startAi' | 'submit' | 'stop' | 'reveal' | 'continueReview' | 'accept' | 'reject' | 'reviewRefine' | 'retryRefinement';
export type InlineAiCapabilityReasonV1 = 'no-live-selection' | 'task-open' | 'empty-prompt' | 'composer-hidden' | 'target-overlap' | 'target-relation-unknown' | 'upstream-action-disabled' | 'authority-mismatch' | 'response-hidden' | 'no-open-task' | 'open-task-content-edit-conflict' | 'disposition-pending' | 'presentation-unverified' | 'presentation-unsupported';
export interface InlineAiCapabilityDecisionV1 {
    readonly enabled: boolean;
    readonly reason?: InlineAiCapabilityReasonV1;
}
export type InlineAiRecoverySurfaceIdV1 = 'task-indicator' | 'bubble-recovery';
export interface InlineAiCoordinatorProjectionV1 {
    readonly authoringState: ZxAIAuthoringProjectionV1['state'];
    readonly authoringActions: ZxAIAuthoringProjectionV1['actions'];
    readonly taskActivity: InlineAiTaskActivityV1;
    readonly liveSelection: boolean;
    readonly retainedReviewTarget: boolean;
    readonly targetRelation: InlineAiTargetRelationV1;
    readonly reviewPresentationGate: InlineAiReviewPresentationGateV1;
    readonly visibleSurfaces: readonly InlineAiSurfaceIdV1[];
    readonly recoverySurfaces: readonly InlineAiRecoverySurfaceIdV1[];
    readonly capabilities: Readonly<Record<InlineAiCapabilityIdV1, InlineAiCapabilityDecisionV1>>;
}
export type InlineAiStatusKeyV1 = `authoring.status.${ZxAIAuthoringProjectionV1['state']}`;
export declare const INLINE_AI_CAPABILITY_IDS_V1: readonly ["format", "startAi", "submit", "stop", "reveal", "continueReview", "accept", "reject", "reviewRefine", "retryRefinement"];
export declare const INLINE_AI_SURFACE_IDS_V1: readonly ["selection-bubble", "selection-prompt", "product-composer", "response", "review-preview", "task-indicator"];
export declare const INLINE_AI_CAPABILITY_REASONS_V1: readonly ["no-live-selection", "task-open", "empty-prompt", "composer-hidden", "target-overlap", "target-relation-unknown", "upstream-action-disabled", "authority-mismatch", "response-hidden", "no-open-task", "open-task-content-edit-conflict", "disposition-pending", "presentation-unverified", "presentation-unsupported"];
export type InlineAiReferenceDecisionV1 = 'copy' | 'adapt' | 'reject';
export interface InlineAiReferencePathProvenanceV1 {
    readonly path: string;
    readonly evidence: string;
    readonly decision: InlineAiReferenceDecisionV1;
    readonly zxuiBoundary: string;
    readonly fixtureIds: readonly string[];
}
export interface InlineAiReferenceProvenanceV1 {
    readonly repository: 'BlockNote' | 'Plate' | 'Novel';
    readonly commit: string;
    readonly equivalentCommit?: string;
    readonly evidence: 'source-and-tests' | 'source-only' | 'product-observation';
    readonly paths: readonly InlineAiReferencePathProvenanceV1[];
}
export declare const INLINE_AI_INTERACTION_REFERENCE_PROVENANCE_V1: readonly [Readonly<{
    repository: "BlockNote";
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53";
    equivalentCommit: "4e9e785530ff4c173f876fcac09cf334fe61b5dc";
    evidence: "source-and-tests";
    paths: readonly (Readonly<{
        path: "packages/xl-ai/src/components/AIMenu/AIMenuController.tsx:21-117";
        evidence: "flip, size, autoUpdate, focus manager no opening scroll";
        decision: "adapt";
        zxuiBoundary: "fixed/visualViewport in Vue adapter; close only changes presentation";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "packages/xl-ai/src/components/PromptSuggestionMenu/PromptSuggestionMenu.tsx:41-153";
        evidence: "input focus, keyboard/IME path";
        decision: "adapt";
        zxuiBoundary: "stable action ID; do not copy React state";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "tests/src/end-to-end/ai/ai-selection.test.tsx";
        evidence: "selection retention, open/focus/no-scroll";
        decision: "copy";
        zxuiBoundary: "rebuild with ZXUI public API + Vue editor";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "tests/src/end-to-end/ai/ai.test.tsx";
        evidence: "selection retention, open/focus/no-scroll";
        decision: "copy";
        zxuiBoundary: "rebuild with ZXUI public API + Vue editor";
        fixtureIds: readonly string[];
    }>)[];
}>, Readonly<{
    repository: "Plate";
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13";
    evidence: "source-and-tests";
    paths: readonly (Readonly<{
        path: "apps/www/src/registry/ui/ai-menu.tsx:65-250,278-611";
        evidence: "selection/cursor routing, menu geometry, Escape mix";
        decision: "adapt";
        zxuiBoundary: "S6 projection/actions sole authority; reject Escape→Stop";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "apps/www/src/registry/ui/ai-menu.spec.tsx:220-227";
        evidence: "missing anchor does not crash";
        decision: "copy";
        zxuiBoundary: "fallback must not retarget; no document rect";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "packages/ai/src/react/ai-chat/AIChatPlugin.ts";
        evidence: "local chat/plugin/stop truth";
        decision: "reject";
        zxuiBoundary: "no second controller/global plugin truth";
        fixtureIds: readonly string[];
    }>)[];
}>, Readonly<{
    repository: "Novel";
    commit: "fa95098e66476c466faebb8211baa5869c101a9c";
    evidence: "product-observation";
    paths: readonly (Readonly<{
        path: "apps/web/components/tailwind/advanced-editor.tsx";
        evidence: "real-page Bubble/selector/stream product composition";
        decision: "adapt";
        zxuiBoundary: "Docs/Workbench use public projection/action only; reject provider hooks";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "apps/web/components/tailwind/generative/ai-selector.tsx";
        evidence: "real-page Bubble/selector/stream product composition";
        decision: "adapt";
        zxuiBoundary: "Docs/Workbench use public projection/action only; reject provider hooks";
        fixtureIds: readonly string[];
    }> | Readonly<{
        path: "fixed-tree/package-scripts";
        evidence: "no upstream test/spec/script";
        decision: "reject";
        zxuiBoundary: "all adopted behaviors use ZXUI-owned fixtures only";
        fixtureIds: readonly string[];
    }>)[];
}>];
export declare const INLINE_AI_INTERACTION_SPEC_LINEAGE_V1: Readonly<{
    focusedBrief: "docs/initiatives/AIEDITOR-ai-document-runtime/briefs/AIEDITOR-inline-ai-interaction-coordinator.md";
    initiative: "docs/initiatives/AIEDITOR-ai-document-runtime/README.md#inline-ai-interaction-coordinator";
    requirements: "docs/specs/AIEDITOR-inline-ai-interaction-coordinator/requirements.md";
    design: "docs/specs/AIEDITOR-inline-ai-interaction-coordinator/design.md";
    supersededByThisSpec: readonly Readonly<{
        spec: "docs/specs/AIEDITOR-inline-ai-surface";
        clause: "Brewing/streaming Escape ≡ Stop";
        replacement: "Escape closes presentation only; Stop requires explicit authority action + Persistent Task Indicator recovery";
    }>[];
}>;
export declare const inlineAiStatusKeyV1: (state: ZxAIAuthoringProjectionV1["state"]) => InlineAiStatusKeyV1;
//# sourceMappingURL=inline-ai-interaction-contract.d.ts.map