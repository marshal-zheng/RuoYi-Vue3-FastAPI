import { InlineAiPrimaryInputFocusKeyV1 } from './use-inline-ai-primary-input-focus';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type InlineAiPromptComposerVariantV1 = 'selection' | 'surface' | 'slash';
type __VLS_Props = {
    readonly modelValue: string;
    readonly variant: InlineAiPromptComposerVariantV1;
    readonly activationKey?: InlineAiPrimaryInputFocusKeyV1;
    readonly submitEnabled?: boolean;
    readonly shortcut?: string;
    readonly inputAriaDisabled?: boolean | 'true' | 'false';
    /** Override the variant placeholder (e.g. "Add a follow-up…"). */
    readonly placeholder?: string;
    /** Override the variant accessible label when the placeholder changes. */
    readonly accessibleLabel?: string;
};
declare const _default: DefineComponent<__VLS_Props, {
    focus: () => void;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    submit: () => any;
    "update:modelValue": (value: string) => any;
    "focus-intent": () => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onSubmit?: (() => any) | undefined;
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
    "onFocus-intent"?: (() => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    inputEl: HTMLTextAreaElement;
}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=InlineAiPromptComposer.vue.d.ts.map