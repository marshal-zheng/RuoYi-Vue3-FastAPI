import { ZxAIAuthoringErrorV1, ZxAIAuthoringProjectionV1, ZxAIAuthoringSurfaceV1, ZxAIWritingDriftV1, ZxAIWritingResultInvalidReasonV1 } from '../../ai/authoring-ux';
/**
 * Package-owned Inline AI Product Shell states (adapt BlockNote AIMenu).
 * Presentation only — Session/Review authority stays on S6/S5/S4.
 */
export declare const INLINE_AI_SHELL_STATES_V1: readonly ["skills", "user-input", "brewing", "reviewing", "closed"];
export type InlineAiShellStateV1 = (typeof INLINE_AI_SHELL_STATES_V1)[number];
/**
 * Prevent fast transports from replacing the Generating shell before users
 * can perceive that their prompt was submitted. This delays presentation
 * only; Session/Review authority continues at transport speed.
 */
export declare const INLINE_AI_GENERATING_MIN_VISIBLE_MS_V1 = 500;
export declare const INLINE_AI_EDIT_WITH_AI_ID_V1: "edit-with-ai";
export interface InlineAiSkillDefinitionV1 {
    readonly skillId: string;
    /** Author-facing natural-language label (never `ai.command.*` as primary copy). */
    readonly label: string;
    /** Maps to an S6 command descriptor `commandId` — not a second registry. */
    readonly commandId: string;
    readonly description?: string;
}
/** Default Notion-aligned Skills set (IAS / q-inline-ai-skills-set). */
export declare const INLINE_AI_DEFAULT_SKILLS_V1: readonly InlineAiSkillDefinitionV1[];
export interface InlineAiSlashSuggestionV1 {
    readonly id: string;
    readonly label: string;
    readonly commandId: string;
    readonly parameters: Readonly<Record<string, string | number | boolean>>;
    readonly icon: string;
}
export interface InlineAiCommandInvocationV1 {
    readonly commandId: string;
    readonly parameters: Readonly<Record<string, string | number | boolean>>;
}
/** Safe coverage metadata only; document text never enters product chrome. */
export interface InlineAiContextReceiptV1 {
    readonly phase: 'planned' | 'submitted';
    readonly prefixBlocks: number;
    readonly suffixBlocks: number;
    readonly outline: boolean;
    readonly digest: boolean;
    readonly omittedBlocks: number;
    readonly coverage: 'full-source' | 'summarized' | 'partial';
    readonly policyExcludedCount: number;
    /**
     * Input tokens: the host's estimate for the compiled request and, once the
     * provider reports usage, the actual count.
     */
    readonly inputTokens?: {
        readonly estimated: number;
        readonly actual?: number;
    };
}
/** One outcome per result, in message precedence order. */
export type InlineAiResultOutcomeV1 = {
    readonly status: 'failed';
    readonly error: ZxAIAuthoringErrorV1;
} | {
    readonly status: 'truncated';
} | {
    readonly status: 'drifted';
    readonly drift: ZxAIWritingDriftV1;
} | {
    readonly status: 'invalid';
    readonly reason: ZxAIWritingResultInvalidReasonV1;
} | {
    readonly status: 'ready';
};
export interface InlineAiResultApplicationV1 {
    readonly outcome: InlineAiResultOutcomeV1;
    readonly mode: 'inline-at-caret' | 'blocks-at-anchor' | 'display-only';
    readonly actions: {
        readonly insert: boolean;
        readonly copy: boolean;
        readonly retry: boolean;
        readonly restart: boolean;
    };
    readonly primaryAction?: 'insert' | 'retry' | 'restart';
}
/**
 * Cursor-scoped Slash starts: generative intents only.
 * Selection editing remains owned by the Bubble Skills surface.
 */
export declare const INLINE_AI_SLASH_SUGGESTIONS_V1: readonly InlineAiSlashSuggestionV1[];
export type InlineAiPreferredModeV1 = 'skills' | 'user-input';
export interface DeriveInlineAiShellStateInputV1 {
    readonly surfaceOpen: boolean;
    readonly projectionState: ZxAIAuthoringProjectionV1['state'];
    readonly preferredMode?: InlineAiPreferredModeV1;
    /** Local UI dismiss for reviewing Escape — closes presentation only. */
    readonly uiDismissed?: boolean;
    /**
     * True when S5 previewSegments already have text. Used to bridge the brief
     * `completed` gap before the S4 review bundle is installed — otherwise the
     * response shell drops to composer and smooth-reveal replays from scratch.
     */
    readonly hasPreviewSegments?: boolean;
}
export declare const deriveInlineAiShellState: (input: DeriveInlineAiShellStateInputV1) => InlineAiShellStateV1;
/**
 * Resolve preferred shell mode from Ask AI surface provenance.
 * Bubble + selection → skills; slash/grip/shortcut → user-input.
 */
export declare const resolveInlineAiPreferredMode: (input: {
    readonly surface?: ZxAIAuthoringSurfaceV1;
    readonly hasSelection?: boolean;
}) => InlineAiPreferredModeV1;
export type InlineAiEscapeDispositionV1 = {
    readonly kind: 'close-idle';
}
/** @deprecated Superseded by close-presentation — Escape must not abort. */
 | {
    readonly kind: 'close-presentation';
} | {
    readonly kind: 'dismiss-review-ui';
} | {
    readonly kind: 'noop';
};
/**
 * Every package-owned presentation state that may own Escape. Selection Bubble
 * is intentionally outside `INLINE_AI_SHELL_STATES_V1`: it is a peer surface,
 * not a hidden product-shell mode.
 */
export type InlineAiEscapeOwnerStateV1 = InlineAiShellStateV1 | 'selection-bubble';
/**
 * Escape is presentation-close only for brewing/streaming/abort-requested.
 * Explicit Stop remains a separate authority action (AIEDITOR-inline-ai-interaction-coordinator).
 * Historical Brewing Escape≡Stop from AIEDITOR-inline-ai-surface is superseded.
 */
export declare const resolveInlineAiEscapeDisposition: (ownerState: InlineAiEscapeOwnerStateV1) => InlineAiEscapeDispositionV1;
/** Action IDs the product shell may dispatch — never invent Session/Review truth. */
export declare const INLINE_AI_SHELL_ACTION_IDS_V1: readonly ["submit", "stop", "retry", "restart", "follow-up", "close", "reveal", "review-accept-all", "review-reject-all", "review-commit", "review-regenerate", "review-refine", "retry-review-refine"];
export type InlineAiShellActionIdV1 = (typeof INLINE_AI_SHELL_ACTION_IDS_V1)[number];
export declare const isInlineAiShellActionId: (value: string) => value is InlineAiShellActionIdV1;
/** Split tokens so source scanners do not self-match this module. */
export declare const INLINE_AI_FORBIDDEN_IMPORT_PATTERNS_V1: readonly [string, string, string, string, string];
export interface InlineAiSurfaceMountOptionsV1 {
    readonly preferredMode?: InlineAiPreferredModeV1;
    readonly skills?: readonly InlineAiSkillDefinitionV1[];
    readonly followUpAvailable?: boolean;
}
/**
 * Public mount helper metadata — package-owned shell; hosts assemble explicitly.
 * Does not auto-mount on ZxTextEditor (IAS-C2 / R1.AC6).
 */
export declare const createInlineAiSurfaceMount: (options?: InlineAiSurfaceMountOptionsV1) => Readonly<{
    kind: "zx-inline-ai-surface-mount-v1";
    preferredMode: InlineAiPreferredModeV1;
    skills: readonly InlineAiSkillDefinitionV1[];
    followUpAvailable: boolean;
}>;
export type InlineAiSurfaceMountV1 = ReturnType<typeof createInlineAiSurfaceMount>;
//# sourceMappingURL=inline-ai-surface.d.ts.map