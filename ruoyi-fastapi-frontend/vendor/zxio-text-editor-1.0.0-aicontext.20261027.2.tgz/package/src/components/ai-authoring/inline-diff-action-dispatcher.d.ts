import { ZxAIAuthoringHostOwnerV1, ZxAIAuthoringHostReceiptV1, ZxAIAuthoringProjectionV1 } from '../../ai/authoring-ux';
export type InlineDiffDispositionIntentV1 = {
    readonly kind: 'accept';
    readonly changeKind: 'replacement' | 'deletion' | 'no-change';
} | {
    readonly kind: 'reject';
} | {
    readonly kind: 'review-refine';
} | {
    readonly kind: 'retry-review-refine';
} | {
    readonly kind: 'close';
}
/**
 * Reject when available, presentation close otherwise. For hosts whose
 * dismiss affordance must finish the review turn (no recovery surface):
 * on a broken review (`error`/`unverified`) `review-reject-all` is
 * unavailable or fails, and dismissal must still retire the chrome
 * instead of dead-locking behind the unavailable reject action.
 */
 | {
    readonly kind: 'dismiss';
};
export type InlineDiffDispositionResultV1 = {
    readonly status: 'accepted' | 'accepted-no-change' | 'idempotent';
    readonly receipts: readonly ZxAIAuthoringHostReceiptV1[];
    readonly projection: ZxAIAuthoringProjectionV1;
} | {
    readonly status: 'busy' | 'failure' | 'unsupported' | 'fresh-projection-required';
    readonly receipts: readonly ZxAIAuthoringHostReceiptV1[];
    readonly projection: ZxAIAuthoringProjectionV1;
};
/**
 * The only composite action in Inline Diff. It composes existing Host Owner
 * actions and rebuilds the exact binding after every receipt; it owns no
 * Review/Session state and never calls an editor command.
 */
export declare const dispatchInlineDiffDispositionV1: (input: {
    readonly owner: ZxAIAuthoringHostOwnerV1;
    readonly intent: InlineDiffDispositionIntentV1;
}) => Promise<InlineDiffDispositionResultV1>;
//# sourceMappingURL=inline-diff-action-dispatcher.d.ts.map