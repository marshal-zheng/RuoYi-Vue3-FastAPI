import { ZxAIAuthoringProjectionV1 } from '../../ai/authoring-ux';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    readonly projection: ZxAIAuthoringProjectionV1;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLElement>;
export default _default;
//# sourceMappingURL=AiAuthoringPreview.vue.d.ts.map