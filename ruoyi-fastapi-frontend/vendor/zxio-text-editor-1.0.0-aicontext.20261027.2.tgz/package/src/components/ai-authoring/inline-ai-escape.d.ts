import { InlineAiEscapeDispositionV1, InlineAiEscapeOwnerStateV1 } from './inline-ai-surface';
export type InlineAiEscapeHandlers = {
    readonly closeIdle: () => void;
    /** Hide presentation for brewing/streaming without aborting authority. */
    readonly closePresentation?: () => void;
    readonly dismissReviewUi: () => void;
};
/**
 * Pure Escape action executor. Does not receive DOM events — key/IME/repeat
 * and suppression belong to the public shortcut runtime.
 */
export declare const executeInlineAiEscapeDisposition: (input: {
    readonly shellState: InlineAiEscapeOwnerStateV1;
    readonly handlers: InlineAiEscapeHandlers;
}) => InlineAiEscapeDispositionV1;
//# sourceMappingURL=inline-ai-escape.d.ts.map