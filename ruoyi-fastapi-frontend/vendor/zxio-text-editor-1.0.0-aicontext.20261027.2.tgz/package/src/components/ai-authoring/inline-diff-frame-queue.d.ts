export interface InlineDiffProjectionFrameQueueV1<T> {
    schedule(value: T): void;
    cancel(): void;
    flushNow(value: T): void;
}
export interface CreateInlineDiffProjectionFrameQueueOptionsV1<T> {
    readonly onFlush: (value: T) => void;
    readonly requestFrame?: (callback: FrameRequestCallback) => number;
    readonly cancelFrame?: (handle: number) => void;
}
/**
 * Latest-only projection queue for presentation adapters.
 *
 * Streaming may publish multiple authority projections in one browser frame;
 * the adapter receives only the latest. `cancel` advances an identity epoch so
 * even a platform callback that races cancellation becomes a no-op.
 */
export declare const createInlineDiffProjectionFrameQueueV1: <T>(options: CreateInlineDiffProjectionFrameQueueOptionsV1<T>) => InlineDiffProjectionFrameQueueV1<T>;
//# sourceMappingURL=inline-diff-frame-queue.d.ts.map