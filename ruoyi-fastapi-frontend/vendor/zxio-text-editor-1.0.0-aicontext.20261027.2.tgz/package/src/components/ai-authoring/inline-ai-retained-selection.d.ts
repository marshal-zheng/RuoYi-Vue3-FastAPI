import { Plugin, PluginKey } from '@tiptap/pm/state';
import { DecorationSet } from '@tiptap/pm/view';
import { Editor } from '@tiptap/core';
export declare const INLINE_AI_RETAINED_SELECTION_PLUGIN_KEY_V1: PluginKey<DecorationSet>;
export declare const INLINE_AI_RETAINED_SELECTION_CLASS_V1: "zx-inline-ai-retained-selection";
export type InlineAiRetainedSelectionRangeV1 = {
    readonly from: number;
    readonly to: number;
};
export declare const createInlineAiRetainedSelectionPlugin: () => Plugin<DecorationSet>;
type EditorWithPlugins = Editor & {
    registerPlugin?: (plugin: Plugin) => void;
    unregisterPlugin?: (key: PluginKey | string) => void;
    isDestroyed?: boolean;
};
export declare const ensureInlineAiRetainedSelectionPlugin: (editor: EditorWithPlugins | null | undefined) => boolean;
export declare const setInlineAiRetainedSelection: (editor: EditorWithPlugins | null | undefined, range: InlineAiRetainedSelectionRangeV1 | null) => boolean;
export declare const clearInlineAiRetainedSelection: (editor: EditorWithPlugins | null | undefined) => boolean;
/** Read the currently painted Notion-gray retained range (if any). */
export declare const readInlineAiRetainedSelection: (editor: EditorWithPlugins | null | undefined) => InlineAiRetainedSelectionRangeV1 | null;
export declare const captureInlineAiRetainedSelectionFromEditor: (editor: EditorWithPlugins | null | undefined) => InlineAiRetainedSelectionRangeV1 | null;
export {};
//# sourceMappingURL=inline-ai-retained-selection.d.ts.map