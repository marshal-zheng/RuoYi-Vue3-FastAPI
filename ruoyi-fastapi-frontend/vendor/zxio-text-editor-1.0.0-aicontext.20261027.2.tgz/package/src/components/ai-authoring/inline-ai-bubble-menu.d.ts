import { EditorLike } from '../../types';
export type InlineAiBubbleMenuCoords = {
    readonly left: number;
    readonly right: number;
    readonly top: number;
    readonly bottom: number;
};
export type InlineAiBubbleMenuVirtualElement = {
    getBoundingClientRect: () => DOMRect;
    getClientRects: () => DOMRect[];
};
type InlineAiBubbleEditorLike = EditorLike & {
    readonly isDestroyed?: boolean;
    readonly view?: {
        readonly dom?: Node | null;
        readonly state: {
            readonly selection: {
                readonly from: number;
                readonly to: number;
            };
            readonly tr?: unknown;
        };
        coordsAtPos: (pos: number) => InlineAiBubbleMenuCoords;
        dispatch?: (tr: unknown) => void;
    };
};
/**
 * Notion-aligned selection bubble: hang from the selection *end*
 * (below the highlight's trailing edge), not the full-range start.
 * TipTap's default `posToDOMRect(from, to)` + `bottom-start` left-aligns
 * under the highlight start — wrong for end-of-line selections.
 *
 * Disable flip-to-top so dense Notion chrome stays under the caret (host
 * top toolbar remains fixed chrome; flipping up caused the "why above?" UX).
 */
/**
 * Shared fixed + visualViewport protocol with Result/Response surfaces.
 * (Supersedes historical absolute + flip:false Notion hang-from-end freeze.)
 */
export declare const INLINE_AI_BUBBLE_MENU_FLOATING_OPTIONS_V1: Readonly<{
    strategy: "fixed";
    placement: "bottom-start";
    offset: 8;
    flip: Readonly<{
        fallbackPlacements: ["top-start"];
    }>;
    shift: Readonly<{
        padding: 8;
        crossAxis: true;
    }>;
    size: Readonly<{
        padding: 8;
        apply: (input: {
            readonly availableWidth: number;
            readonly availableHeight: number;
            readonly elements: {
                readonly floating: HTMLElement;
            };
        }) => void;
    }>;
}>;
/**
 * Consumer extensions are applied first so the viewport protocol remains
 * non-overridable. This preserves compatible non-geometric Floating UI
 * options without allowing absolute positioning or disabled middleware.
 */
export declare const resolveInlineAiBubbleMenuFloatingOptionsV1: (options?: Readonly<Record<string, unknown>>) => Readonly<Record<string, unknown>>;
/**
 * Last visible text-line rect of a multi-line selection.
 * Prefer DOM `Range#getClientRects` over `coordsAtPos(to)` — select-all often
 * ends at a block boundary whose coords sit on the editor's far right edge.
 */
export declare const resolveInlineAiBubbleMenuSelectionEndClientRect: (clientRects: ArrayLike<DOMRect>) => DOMRect | null;
/**
 * Build a caret-sized virtual rect at the visual end of a selection.
 * Used as BubbleMenu `getReferencedVirtualElement` so `bottom-start`
 * opens just below the highlight end (Notion), not the range start.
 */
export declare const createInlineAiBubbleMenuSelectionEndRect: (input: {
    readonly from: number;
    readonly to: number;
    readonly coordsAtPos: (pos: number) => InlineAiBubbleMenuCoords;
    /** Optional DOM selection line boxes (preferred for multi-line / select-all). */
    readonly clientRects?: ArrayLike<DOMRect>;
}) => DOMRect;
/**
 * `getRange` lets the caller anchor to the session bookmark instead of the live
 * selection. Once AI chrome takes focus the editor selection collapses, and
 * anchoring to it would make the bubble jump to the caret.
 */
export declare const createInlineAiBubbleMenuReferencedVirtualElement: (editor: InlineAiBubbleEditorLike | null | undefined, getRange?: () => {
    readonly from: number;
    readonly to: number;
} | null) => (() => InlineAiBubbleMenuVirtualElement | null);
export declare const defaultShouldShowInlineAiBubbleMenu: ({ state, }: {
    state: any;
}) => boolean;
export declare const INLINE_AI_BUBBLE_MENU_PLUGIN_KEY_V1: "inlineAiBubbleMenu";
export declare const INLINE_AI_POINTER_SELECTION_SETTLE_MS_V1 = 140;
export declare const resolveInlineAiBubbleMenuShouldShow: (input: {
    readonly payload: {
        editor: unknown;
        state: unknown;
    };
    readonly suppress?: boolean;
    /**
     * True while the primary pointer is down for a drag/click selection. A
     * settled selection may still open before pointerup.
     */
    readonly pointerSelecting?: boolean;
    readonly pointerSelectionSettled?: boolean;
    readonly shouldShow?: ((payload: {
        editor: unknown;
        state: unknown;
    }) => boolean) | null;
}) => boolean;
/**
 * TipTap BubbleMenu only re-runs `shouldShow` on selection/doc changes.
 * When host `suppress` flips without a selection update, force hide/show via
 * plugin meta (`hide` / `show`) so the frozen selection chrome cannot stick.
 */
export declare const syncInlineAiBubbleMenuPluginVisibility: (input: {
    readonly editor: InlineAiBubbleEditorLike | null | undefined;
    readonly pluginKey?: string | Record<string, unknown>;
    readonly visible: boolean;
}) => void;
export type InlineAiBubbleMenuEditor = InlineAiBubbleEditorLike | null;
export {};
//# sourceMappingURL=inline-ai-bubble-menu.d.ts.map