import { InlineAiSkillDefinitionV1 } from './inline-ai-surface';
import { InlineAiBubbleHandoffRejectionV1 } from './inline-ai-bubble-handoff';
import { InlineAiSelectionEditorLike } from './inline-ai-selection-actions';
import { InlineAiCapabilityDecisionV1, InlineAiCapabilityIdV1 } from './inline-ai-interaction-coordinator';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions, CreateComponentPublicInstanceWithMixins, GlobalComponents, GlobalDirectives } from 'vue';
import { InlineAiPrimaryInputFocusKeyV1 } from './use-inline-ai-primary-input-focus';
type CapabilityMap = Readonly<Record<InlineAiCapabilityIdV1, InlineAiCapabilityDecisionV1>>;
type __VLS_Props = {
    skills?: readonly InlineAiSkillDefinitionV1[];
    editor?: InlineAiSelectionEditorLike | null;
    /**
     * Host detach/error fail-closed only. Must NOT be bound to hasOpenTask.
     */
    disabled?: boolean;
    capabilities?: CapabilityMap | null;
    /**
     * Opt-in only. Selecting text must not steal editor focus into Edit with AI;
     * click or an explicit host shortcut should focus the composer.
     */
    autoFocusPrompt?: boolean;
    /**
     * Why the host declined the last handoff. Rendered inline so a fail-closed
     * Skill / Edit with AI never silently drops the user back to bare text.
     */
    notice?: InlineAiBubbleHandoffRejectionV1 | null;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    "continue-review": () => any;
    "review-refine": (draft: string) => any;
    "edit-with-ai": () => any;
    "skill-invoke": (skill: InlineAiSkillDefinitionV1) => any;
    "prompt-submit": (draft: string) => any;
    "retain-selection": () => any;
    "prompt-draft": (draft: string) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onContinue-review"?: (() => any) | undefined;
    "onReview-refine"?: ((draft: string) => any) | undefined;
    "onEdit-with-ai"?: (() => any) | undefined;
    "onSkill-invoke"?: ((skill: InlineAiSkillDefinitionV1) => any) | undefined;
    "onPrompt-submit"?: ((draft: string) => any) | undefined;
    "onRetain-selection"?: (() => any) | undefined;
    "onPrompt-draft"?: ((draft: string) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    promptComposerRef: CreateComponentPublicInstanceWithMixins<Readonly<{
        readonly modelValue: string;
        readonly variant: "selection" | "slash" | "surface";
        readonly activationKey?: InlineAiPrimaryInputFocusKeyV1;
        readonly submitEnabled?: boolean;
        readonly shortcut?: string;
        readonly inputAriaDisabled?: boolean | "true" | "false";
        readonly placeholder?: string;
        readonly accessibleLabel?: string;
    }> & Readonly<{
        onSubmit?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        "onFocus-intent"?: (() => any) | undefined;
    }>, {
        focus: () => void;
    }, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
        submit: () => any;
        "update:modelValue": (value: string) => any;
        "focus-intent": () => any;
    }, PublicProps, {}, false, {}, {}, GlobalComponents, GlobalDirectives, string, {
        inputEl: HTMLTextAreaElement;
    }, HTMLDivElement, ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<{
        readonly modelValue: string;
        readonly variant: "selection" | "slash" | "surface";
        readonly activationKey?: InlineAiPrimaryInputFocusKeyV1;
        readonly submitEnabled?: boolean;
        readonly shortcut?: string;
        readonly inputAriaDisabled?: boolean | "true" | "false";
        readonly placeholder?: string;
        readonly accessibleLabel?: string;
    }> & Readonly<{
        onSubmit?: (() => any) | undefined;
        "onUpdate:modelValue"?: ((value: string) => any) | undefined;
        "onFocus-intent"?: (() => any) | undefined;
    }>, {
        focus: () => void;
    }, {}, {}, {}, {}> | null;
}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=InlineAiSelectionMenu.vue.d.ts.map