import { ZxAIAuthoringActionIdV1, ZxAIAuthoringProjectionV1 } from '../../ai/authoring-ux';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    readonly projection: ZxAIAuthoringProjectionV1;
    readonly forceVisible?: boolean;
    readonly continueReview?: boolean;
    readonly hideLineageActions?: boolean;
    readonly actionSummaries?: Partial<Record<Extract<ZxAIAuthoringActionIdV1, 'retry' | 'restart' | 'follow-up' | 'supersede' | 'retry-review-refine'>, string>>;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    action: (actionId: ZxAIAuthoringActionIdV1) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onAction?: ((actionId: ZxAIAuthoringActionIdV1) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;
export default _default;
//# sourceMappingURL=AiAuthoringTaskIndicator.vue.d.ts.map