import { ZxAIAuthoringActionIdV1, ZxAIAuthoringProjectionV1 } from '../../ai/authoring-ux';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    readonly projection: ZxAIAuthoringProjectionV1;
    /**
     * Host copy, tried first with the error's `messageKey` and with
     * `ai.authoring.action.<id>`; `undefined` falls back to the built-in catalog.
     */
    readonly messageFor?: (key: string) => string | undefined;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    action: (actionId: ZxAIAuthoringActionIdV1) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onAction?: ((actionId: ZxAIAuthoringActionIdV1) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;
export default _default;
//# sourceMappingURL=AiAuthoringErrorPanel.vue.d.ts.map