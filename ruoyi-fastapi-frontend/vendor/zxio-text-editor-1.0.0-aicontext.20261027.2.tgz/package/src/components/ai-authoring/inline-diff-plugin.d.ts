import { Plugin, PluginKey, EditorState } from '@tiptap/pm/state';
import { DecorationSet } from '@tiptap/pm/view';
import { InlineReviewActions } from '../../shortcuts/inline-review-actions';
import { ActionState, OwnerRef, ShortcutClient } from '@zxio/keybindings/core';
import { InlineDiffBlockTagV1, InlineDiffCandidateLineV1, InlineDiffHunkChangeKindV1, InlineDiffHunkDecisionV1 } from './inline-diff-block-projection';
export declare const INLINE_DIFF_PLUGIN_KEY_V1: PluginKey<InlineDiffPluginStateV1>;
/**
 * Per-hunk presentation facts shared by every decoration of one hunk group.
 * The plugin owns no verdict authority: it paints what the host stages and
 * reports pointer/keyboard intents back through `onHunkIntent`.
 */
export interface InlineDiffHunkPaintV1 {
    readonly hunkId: string;
    readonly ordinal: number;
    readonly total: number;
    readonly changeKind: InlineDiffHunkChangeKindV1;
    readonly decision: InlineDiffHunkDecisionV1;
    readonly dependsOn: readonly string[];
    /** Hunks restored together with this one when it is restored. */
    readonly dependants: readonly string[];
    /** Candidate text (folded stub when the hunk is restored). */
    readonly candidateText: string;
}
export type InlineDiffMappedDecorationV1 = 
/** Word-level in-paragraph diff (single text.replace, v1). */
{
    readonly kind: 'removed';
    readonly from: number;
    readonly to: number;
    readonly text: string;
} | {
    readonly kind: 'inserted';
    readonly pos: number;
    readonly text: string;
}
/**
 * Block diff (Cursor form): the source block becomes a deletion line and
 * the candidate paragraphs are rendered as insertion lines after it.
 */
 | {
    readonly kind: 'removed-block';
    readonly hunkId: string;
    /** Exact node range of the source block (node decoration). */
    readonly blockFrom: number;
    readonly blockTo: number;
    /** Selected text range inside the block (inline `del`). */
    readonly from: number;
    readonly to: number;
    readonly decision: InlineDiffHunkDecisionV1;
    readonly hunk: InlineDiffHunkPaintV1;
} | {
    readonly kind: 'removed-word';
    readonly from: number;
    readonly to: number;
} | {
    readonly kind: 'inserted-block';
    readonly hunkId: string;
    /** Position directly after the source block. */
    readonly pos: number;
    /** Widget ordering among hunks anchored at the same position. */
    readonly side: number;
    readonly tag: InlineDiffBlockTagV1;
    readonly lines: readonly InlineDiffCandidateLineV1[];
    readonly decision: InlineDiffHunkDecisionV1;
    /** Last streamed block: paints a live caret after the final line. */
    readonly streaming: boolean;
    readonly hunk: InlineDiffHunkPaintV1;
}
/**
 * Zero-height anchor painted before a hunk group. It hosts the per-hunk
 * toolbar (pending) or the verdict badge (kept / restored) at the group's
 * top-right corner without entering the text flow.
 */
 | {
    readonly kind: 'hunk-bar';
    readonly hunkId: string;
    readonly pos: number;
    readonly side: number;
    readonly hunk: InlineDiffHunkPaintV1;
};
export type InlineDiffHunkIntentV1 = {
    readonly kind: 'decide-hunk';
    readonly hunkId: string;
    readonly decision: InlineDiffHunkDecisionV1;
    readonly source: 'pointer' | 'keyboard';
} | {
    readonly kind: 'focus-hunk';
    readonly hunkId: string | null;
    readonly source: 'pointer' | 'keyboard';
} | {
    readonly kind: 'step-hunk';
    readonly direction: 'forward' | 'backward';
    readonly fromHunkId: string | null;
} | {
    readonly kind: 'commit';
};
/** Localized strings the painter needs; the host passes its locale copy. */
export interface InlineDiffHunkCopyV1 {
    readonly keep: string;
    readonly restore: string;
    readonly undo: string;
    readonly kept: string;
    readonly restored: string;
    readonly pending: string;
    readonly willDelete: string;
    readonly added: string;
    readonly hunkAria: (input: {
        readonly ordinal: number;
        readonly total: number;
        readonly state: string;
        readonly changeKind: InlineDiffHunkChangeKindV1;
    }) => string;
}
export declare const INLINE_DIFF_HUNK_COPY_EN_V1: InlineDiffHunkCopyV1;
export interface InlineDiffPluginStateV1 {
    readonly editorBindingId: string;
    readonly sourceFingerprint: string | null;
    readonly projectionFingerprint: string | null;
    readonly visible: boolean;
    readonly projectedDecorations: DecorationSet;
    /** Hunk groups in document order (block diff only). */
    readonly hunks: readonly InlineDiffHunkPaintV1[];
    /** Toolbars and keyboard verdicts are live only once the diff is exact. */
    readonly interactive: boolean;
    readonly focusedHunkId: string | null;
}
export type InlineDiffPluginMetaV1 = {
    readonly kind: 'set-projection';
    readonly editorBindingId: string;
    readonly sourceFingerprint: string;
    readonly projectionFingerprint: string;
    readonly decorations: readonly InlineDiffMappedDecorationV1[];
    readonly hunks?: readonly InlineDiffHunkPaintV1[];
    readonly interactive?: boolean;
} | {
    readonly kind: 'set-visible';
    readonly editorBindingId: string;
    readonly visible: boolean;
} | {
    readonly kind: 'focus-hunk';
    readonly editorBindingId: string;
    readonly hunkId: string | null;
} | {
    readonly kind: 'clear';
    readonly editorBindingId: string;
};
export interface InlineDiffPluginOptionsV1 {
    readonly editorBindingId: string;
    readonly onCanonicalDocumentChange?: () => void;
    readonly onHunkIntent?: (intent: InlineDiffHunkIntentV1) => unknown;
    readonly copy?: InlineDiffHunkCopyV1;
    readonly shortcutRuntime?: ShortcutClient;
    readonly shortcutParentOwner?: OwnerRef;
    /** Resolve after preceding PM plugin views have recreated their live owners. */
    readonly resolveShortcutContext?: () => {
        readonly runtime?: ShortcutClient;
        readonly parent?: OwnerRef;
    };
    readonly onReviewActionsChange?: (actions: InlineReviewActions | null) => void;
    readonly getReviewState?: () => ActionState;
    readonly getAcceptState?: () => ActionState;
    readonly subscribeReviewState?: (listener: () => void) => () => void;
}
/** The primary control of a hunk's toolbar/badge, for programmatic focus. */
export declare const inlineDiffHunkPrimaryControlV1: (root: HTMLElement, hunkId: string) => HTMLElement | null;
export declare const createInlineDiffPlugin: (options: InlineDiffPluginOptionsV1) => Plugin<InlineDiffPluginStateV1>;
/** Explicit bridge for a chrome sharing this exact PM review owner. */
export declare const getInlineDiffReviewActions: (state: EditorState) => InlineReviewActions | null;
//# sourceMappingURL=inline-diff-plugin.d.ts.map