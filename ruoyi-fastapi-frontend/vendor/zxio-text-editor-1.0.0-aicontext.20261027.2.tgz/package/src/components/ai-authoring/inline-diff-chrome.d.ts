import { ZxAIReviewPresentationProjectionV1 } from '../../ai/review-presentation';
import { ZxAIAuthoringActionIdV1, ZxAIAuthoringProjectionV1 } from '../../ai/authoring-ux';
import { InlineAiCoordinatorProjectionV1 } from './inline-ai-interaction-contract';
import { InlineDiffHunkDecisionV1, InlineDiffProjectionCountsV1 } from './inline-diff-block-projection';
export type InlineDiffChromeIntentV1 = 'accept' | 'reject' | 'close' | {
    readonly kind: 'add-follow-up';
    readonly prompt: string;
}
/** Per-hunk staged verdict (block diff). `undecided` withdraws it. */
 | {
    readonly kind: 'decide-hunk';
    readonly hunkId: string;
    readonly decision: InlineDiffHunkDecisionV1;
} | {
    readonly kind: 'focus-hunk';
    readonly hunkId: string | null;
}
/** ⌥↑ / ⌥↓ from the composer: enter per-hunk review. */
 | {
    readonly kind: 'step-hunk';
    readonly direction: 'forward' | 'backward';
};
export type InlineDiffChromeBusyIntentV1 = 'accept' | 'reject' | 'add-follow-up' | 'close';
export type InlineDiffChromePresentationV1 = 'replacement' | 'deletion' | 'no-change' | 'degraded' | 'conflict' | 'error';
export type InlineDiffChromeDisabledReasonV1 = 'disposition-pending' | 'presentation-unverified' | 'presentation-unsupported' | 'reject-only' | 'conflict' | 'action-unavailable';
/**
 * Render-only control projection supplied by the coordinator/host adapter.
 * This component never derives business capability from presentation state.
 */
export type InlineDiffChromeControlV1 = {
    readonly enabled: true;
    readonly disabledReason?: never;
} | {
    readonly enabled: false;
    readonly disabledReason: InlineDiffChromeDisabledReasonV1;
};
/** `addFollowUp: null` is the closed signal to omit that optional control. */
export interface InlineDiffChromeControlsV1 {
    readonly accept: InlineDiffChromeControlV1;
    readonly reject: InlineDiffChromeControlV1;
    readonly addFollowUp: InlineDiffChromeControlV1 | null;
    readonly close: InlineDiffChromeControlV1;
}
/**
 * What Accept does with the staged verdicts. The button always reads
 * "Accept": it keeps every hunk the user did not explicitly restore.
 * - `accept`: nothing restored — the whole proposal is kept (pending hunks
 *   count as kept), today's accept-all → commit;
 * - `commit-verdicts`: some hunks restored, the rest kept — the mixed path
 *   (ledger → regeneration successor → commit);
 * - `restore-all`: every hunk restored — equivalent to Reject, no empty
 *   commit.
 */
export type InlineDiffChromePrimaryModeV1 = 'accept' | 'commit-verdicts' | 'restore-all';
export interface InlineDiffChromeHunkReviewV1 {
    readonly counts: InlineDiffProjectionCountsV1;
    readonly primaryMode: InlineDiffChromePrimaryModeV1;
    readonly focusedHunkId: string | null;
    /** Hunk-level controls are live only for an exact (verified) diff. */
    readonly interactive: boolean;
}
export interface InlineDiffChromeProjectionV1 {
    readonly presentation: InlineDiffChromePresentationV1;
    readonly controls: InlineDiffChromeControlsV1;
    readonly busyIntent: InlineDiffChromeBusyIntentV1 | null;
    /** Present for block diffs; absent for the single-paragraph word diff. */
    readonly hunkReview?: InlineDiffChromeHunkReviewV1;
}
export declare const resolveInlineDiffPrimaryModeV1: (counts: InlineDiffProjectionCountsV1) => InlineDiffChromePrimaryModeV1;
interface InlineDiffChromeCopyV1 {
    readonly title: string;
    readonly description: string;
}
export declare const resolveInlineDiffChromePresentationCopyV1: (presentation: InlineDiffChromePresentationV1) => InlineDiffChromeCopyV1;
export declare const resolveInlineDiffChromeDisabledReasonV1: (reason: InlineDiffChromeDisabledReasonV1 | undefined) => string;
export declare const resolveInlineDiffChromeBusyCopyV1: (intent: InlineDiffChromeBusyIntentV1) => string;
/**
 * Presentation-only mapping from the latest Coordinator/Host projections.
 * It carries no action callbacks and owns no Review or Session state.
 */
export declare const projectInlineDiffChromeV1: (input: {
    readonly review: ZxAIReviewPresentationProjectionV1;
    readonly coordinator: InlineAiCoordinatorProjectionV1;
    readonly authoringState: ZxAIAuthoringProjectionV1["state"];
    readonly pendingActionId?: ZxAIAuthoringActionIdV1;
    readonly closeEnabled: boolean;
    readonly reviewRefineActionAvailable: boolean;
}) => InlineDiffChromeProjectionV1;
/**
 * Block-diff chrome (whole-paragraph / cross-paragraph rewrites). The Review
 * Presentation Kernel has no profile for multi-operation plans, so controls
 * come straight from the Host Owner action set; the document decorations
 * carry the diff itself.
 */
export declare const projectInlineDiffBlockChromeV1: (input: {
    readonly phase: "provisional" | "verified" | null;
    readonly authoringState: ZxAIAuthoringProjectionV1["state"];
    readonly actions: ZxAIAuthoringProjectionV1["actions"];
    readonly pendingActionId?: ZxAIAuthoringActionIdV1;
    readonly counts?: InlineDiffProjectionCountsV1;
    readonly focusedHunkId?: string | null;
    /** A mixed verdict is being regenerated and committed by the host. */
    readonly committingVerdicts?: boolean;
}) => InlineDiffChromeProjectionV1;
export {};
//# sourceMappingURL=inline-diff-chrome.d.ts.map