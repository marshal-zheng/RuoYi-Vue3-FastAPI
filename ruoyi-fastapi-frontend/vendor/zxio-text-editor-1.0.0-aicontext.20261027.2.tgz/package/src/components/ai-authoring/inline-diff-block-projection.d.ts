/**
 * Block-level Inline Diff projection (Cursor Quick Edit form).
 *
 * The selected paragraphs stay in the document as deletion lines and the
 * candidate paragraphs grow underneath them as insertion lines. Streaming
 * shows the coarse block diff; once the exact S4 Review is installed the same
 * projection is refined with word-level emphasis. This module is pure data:
 * no ProseMirror positions, no DOM, no Session or Review authority.
 */
export interface InlineDiffTextRangeV1 {
    readonly start: number;
    readonly end: number;
}
export type InlineDiffHunkDecisionV1 = 'undecided' | 'accepted' | 'rejected';
export type InlineDiffBlockTagV1 = 'paragraph' | 'heading-1' | 'heading-2' | 'heading-3' | 'heading-4' | 'heading-5' | 'heading-6';
/** One selected block range at capture time (the deletion side of a hunk). */
export interface InlineDiffBlockSegmentV1 {
    readonly blockId: string;
    /** Full block text at capture time; the adapter refuses to paint on drift. */
    readonly blockText: string;
    readonly startOffset: number;
    readonly endOffset: number;
}
export interface InlineDiffCandidateLineV1 {
    readonly text: string;
    /** Word-level emphasis (candidate-line offsets). Empty while streaming. */
    readonly insertedRanges: readonly InlineDiffTextRangeV1[];
}
/**
 * What a hunk does to the document if it is kept:
 * - `replace` swaps the selected range for the candidate lines;
 * - `delete` removes the selected range (the model wrote fewer paragraphs);
 * - `insert` adds a new paragraph after its anchor block (the model wrote
 *   more paragraphs than the selection had).
 */
export type InlineDiffHunkChangeKindV1 = 'replace' | 'delete' | 'insert';
export interface InlineDiffBlockHunkV1 {
    readonly hunkId: string;
    /** Proposal operation index once verified; `null` while provisional. */
    readonly operationIndex: number | null;
    readonly blockId: string;
    readonly blockText: string;
    readonly startOffset: number;
    readonly endOffset: number;
    /** Replacement lines for the selected range; empty means it is removed. */
    readonly candidateLines: readonly InlineDiffCandidateLineV1[];
    /** Word-level emphasis inside the removed range (block-text offsets). */
    readonly removedRanges: readonly InlineDiffTextRangeV1[];
    readonly decision: InlineDiffHunkDecisionV1;
    readonly changeKind: InlineDiffHunkChangeKindV1;
    /** 1-based position in the hunk list — the `2/5` pill on the toolbar. */
    readonly ordinal: number;
    /**
     * Hunks that must stay kept for this one to stay kept. Restoring a
     * dependency restores its dependants in the same staged step, so the
     * ledger never has to resolve a dependency conflict at commit time.
     */
    readonly dependsOn: readonly string[];
    /**
     * `insert` hunks share the anchor block with the hunk they follow, so the
     * painter has to stack their widgets in this order after that block.
     */
    readonly anchorOrder: number;
}
/** @deprecated Trailing paragraphs are their own `insert` hunks now. */
export interface InlineDiffTrailingLineV1 extends InlineDiffCandidateLineV1 {
    readonly operationIndex: number | null;
}
export interface InlineDiffProjectionCountsV1 {
    readonly total: number;
    readonly pending: number;
    readonly kept: number;
    readonly restored: number;
}
export interface InlineDiffBlockProjectionV1 {
    readonly kind: 'zx-inline-diff-block-projection-v1';
    readonly phase: 'provisional' | 'verified';
    readonly hunks: readonly InlineDiffBlockHunkV1[];
    /** Candidate paragraphs beyond the selection, inserted after the last hunk. */
    readonly trailingLines: readonly InlineDiffTrailingLineV1[];
    readonly counts: InlineDiffProjectionCountsV1;
    /** Cheap identity for change detection (not a security fingerprint). */
    readonly fingerprint: string;
}
export interface CreateInlineDiffBlockProjectionInputV1 {
    readonly phase: 'provisional' | 'verified';
    readonly segments: readonly InlineDiffBlockSegmentV1[];
    /**
     * Candidate paragraphs aligned with `segments` in order. `null` deletes the
     * segment's range; paragraphs beyond the segment count trail the last hunk.
     */
    readonly paragraphs: readonly (string | null)[];
    /** Per-segment operation index (verified only), then trailing entries. */
    readonly operationIndexes?: readonly (number | null)[];
    /** Ledger decisions aligned with `paragraphs` (verified only). */
    readonly decisions?: readonly InlineDiffHunkDecisionV1[];
    /**
     * Staged (not yet committed) verdicts keyed by hunk id. They fill in
     * wherever the ledger is still `undecided`; a ledger decision always wins.
     */
    readonly verdicts?: ReadonlyMap<string, InlineDiffHunkDecisionV1>;
    /** Refine similar lines with word-level emphasis (verified phase). */
    readonly wordLevel?: boolean;
}
/**
 * Below this share of unchanged text a rewrite reads as a whole-line
 * replacement (e.g. a translation) and word emphasis would only add noise.
 */
export declare const INLINE_DIFF_WORD_LEVEL_SIMILARITY_FLOOR_V1 = 0.35;
/**
 * Word-level refinement of one hunk: removed ranges in source offsets and
 * inserted ranges in candidate offsets. Returns empty ranges when the texts
 * are too different for emphasis to help, or when the diff budget is hit.
 */
export declare const refineInlineDiffHunkWordsV1: (input: {
    readonly sourceText: string;
    readonly candidateText: string;
}) => {
    readonly removedRanges: readonly InlineDiffTextRangeV1[];
    readonly insertedRanges: readonly InlineDiffTextRangeV1[];
};
export declare const createInlineDiffBlockProjectionV1: (input: CreateInlineDiffBlockProjectionInputV1) => InlineDiffBlockProjectionV1;
/**
 * Staged verdicts, closed over dependencies: restoring a hunk restores every
 * hunk that depends on it, and keeping a hunk keeps everything it needs.
 * The result is always a set the S4 ledger can accept without a dependency
 * conflict, which is what makes a mixed verdict committable in one turn.
 */
export declare const closeInlineDiffVerdictsV1: (input: {
    readonly hunks: readonly InlineDiffBlockHunkV1[];
    readonly hunkId: string;
    readonly decision: InlineDiffHunkDecisionV1;
    readonly current: ReadonlyMap<string, InlineDiffHunkDecisionV1>;
}) => ReadonlyMap<string, InlineDiffHunkDecisionV1>;
/** The next hunk to land on after deciding `fromHunkId` (pending first). */
export declare const nextInlineDiffPendingHunkV1: (input: {
    readonly hunks: readonly InlineDiffBlockHunkV1[];
    readonly fromHunkId?: string;
    readonly direction?: "forward" | "backward";
}) => InlineDiffBlockHunkV1 | undefined;
/** Plain neighbour step (⌥↑ / ⌥↓), regardless of verdict. */
export declare const stepInlineDiffHunkV1: (input: {
    readonly hunks: readonly InlineDiffBlockHunkV1[];
    readonly fromHunkId?: string;
    readonly direction: "forward" | "backward";
}) => InlineDiffBlockHunkV1 | undefined;
/** Text of every non-empty candidate line, in document order. */
export declare const inlineDiffBlockProjectionCandidateTextV1: (projection: InlineDiffBlockProjectionV1) => string;
//# sourceMappingURL=inline-diff-block-projection.d.ts.map