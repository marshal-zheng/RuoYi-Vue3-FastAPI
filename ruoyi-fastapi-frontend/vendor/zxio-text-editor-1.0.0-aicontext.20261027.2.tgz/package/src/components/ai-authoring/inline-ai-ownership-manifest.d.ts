export type InlineAiOwnedSourcePolicyV1 = 'authoring-authority' | 'headless-review-presentation' | 'presentation-adapter' | 'shortcut-routing' | 'public-facet';
export interface InlineAiOwnedSourceRootV1 {
    readonly path: string;
    readonly policy: InlineAiOwnedSourcePolicyV1;
}
/**
 * Versioned, topology-independent ownership closure for Inline AI production
 * source. Source gates enumerate these roots directly; Git history, worktree
 * dirt, branch shape and file counts never affect the scan.
 */
export declare const INLINE_AI_OWNERSHIP_MANIFEST_V1: Readonly<{
    version: 1;
    packageRoots: readonly (Readonly<{
        path: "src/ai/authoring-ux";
        policy: "authoring-authority";
    }> | Readonly<{
        path: "src/ai/review-presentation";
        policy: "headless-review-presentation";
    }> | Readonly<{
        path: "src/components/ai-authoring";
        policy: "presentation-adapter";
    }> | Readonly<{
        path: "src/components/inline-ai-bubble-menu.tsx";
        policy: "presentation-adapter";
    }> | Readonly<{
        path: "src/composables/use-ai-authoring.ts";
        policy: "presentation-adapter";
    }> | Readonly<{
        path: "src/shortcuts";
        policy: "shortcut-routing";
    }> | Readonly<{
        path: "src/extensions/link-extension.ts";
        policy: "shortcut-routing";
    }> | Readonly<{
        path: "src/extensions/link-editor-commands.ts";
        policy: "shortcut-routing";
    }> | Readonly<{
        path: "src/core/deterministic-runtime/manifest.ts";
        policy: "authoring-authority";
    }> | Readonly<{
        path: "src/core/deterministic-runtime/target-commit";
        policy: "authoring-authority";
    }> | Readonly<{
        path: "ai.ts";
        policy: "public-facet";
    }> | Readonly<{
        path: "authoring-ui.ts";
        policy: "public-facet";
    }> | Readonly<{
        path: "core.ts";
        policy: "public-facet";
    }> | Readonly<{
        path: "ui.ts";
        policy: "public-facet";
    }>)[];
    rootRepositoryRoots: readonly string[];
    sourceExtensions: readonly string[];
    forbiddenUniversalSnippets: readonly string[];
}>;
//# sourceMappingURL=inline-ai-ownership-manifest.d.ts.map