import { ActionState, ShortcutClient } from '@zxio/keybindings/core';
import { InlineReviewActions } from '../../shortcuts/inline-review-actions';
import { EditorState, Plugin, PluginKey } from '@tiptap/pm/state';
import { EditorView } from '@tiptap/pm/view';
import { ZxAIReviewPresentationBaselineV1, ZxAIReviewPresentationProjectionV1 } from '../../ai/review-presentation';
import { InlineDiffBlockProjectionV1 } from './inline-diff-block-projection';
import { InlineDiffHunkCopyV1, InlineDiffHunkIntentV1 } from './inline-diff-plugin';
export interface InlineDiffEditorV1 {
    readonly storage?: object;
    readonly state: EditorState;
    readonly view: EditorView;
    readonly isDestroyed?: boolean;
    readonly registerPlugin: (plugin: Plugin) => void;
    readonly unregisterPlugin: (key: PluginKey | string) => void;
}
export declare const isInlineDiffEditorV1: (value: unknown) => value is InlineDiffEditorV1;
export type InlineDiffAdapterApplyResultV1 = {
    readonly status: 'applied';
    readonly projectionFingerprint: string;
} | {
    readonly status: 'anchor-lost' | 'baseline-mismatch' | 'editor-binding-mismatch' | 'closed-projection' | 'destroyed';
};
export interface InlineDiffDecorationAdapterV1 {
    readonly reviewActions: InlineReviewActions | null;
    /** Immediate current value, then changes whenever PM replaces the plugin view. */
    readonly subscribeReviewActions: (listener: (actions: InlineReviewActions | null) => void) => () => void;
    readonly setProjection: (input: {
        readonly baseline: ZxAIReviewPresentationBaselineV1;
        readonly projection: ZxAIReviewPresentationProjectionV1;
    }) => InlineDiffAdapterApplyResultV1;
    /** Cursor-form block diff for whole-paragraph and cross-paragraph rewrites. */
    readonly setBlockProjection: (projection: InlineDiffBlockProjectionV1) => InlineDiffAdapterApplyResultV1;
    readonly setVisible: (visible: boolean) => boolean;
    /**
     * Make one hunk the current review target: paints the focus ring, moves
     * DOM focus onto its toolbar / badge, and scrolls it into view. `null`
     * clears hunk focus without touching DOM focus.
     */
    readonly focusHunk: (hunkId: string | null, options?: {
        readonly scroll?: boolean;
        readonly domFocus?: boolean;
    }) => boolean;
    readonly clear: () => boolean;
    readonly destroy: () => void;
}
export declare const createInlineDiffDecorationAdapter: (options: {
    readonly editor: InlineDiffEditorV1;
    readonly editorBindingId: string;
    readonly onCanonicalDocumentChange?: () => void;
    /** Per-hunk pointer/keyboard intents (block diff review). */
    readonly onHunkIntent?: (intent: InlineDiffHunkIntentV1) => unknown;
    readonly hunkCopy?: InlineDiffHunkCopyV1;
    readonly shortcutRuntime?: ShortcutClient;
    readonly getReviewState?: () => ActionState;
    readonly getAcceptState?: () => ActionState;
    readonly subscribeReviewState?: (listener: () => void) => () => void;
}) => InlineDiffDecorationAdapterV1;
//# sourceMappingURL=inline-diff-decoration-adapter.d.ts.map