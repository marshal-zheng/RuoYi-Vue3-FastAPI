import { InlineAiCoordinatorInputV1, InlineAiCoordinatorProjectionV1 } from './inline-ai-interaction-contract';
export * from './inline-ai-interaction-contract';
export { relateInlineAiTargetsV1 } from './inline-ai-target-relation';
/**
 * Pure composition boundary. Authority validation, target geometry and
 * capability policy live in focused modules so adapters cannot grow a second
 * lifecycle controller around this projector.
 */
export declare const projectInlineAiInteractionV1: (input: InlineAiCoordinatorInputV1) => InlineAiCoordinatorProjectionV1;
//# sourceMappingURL=inline-ai-interaction-coordinator.d.ts.map