import { InlineAiSelectionRangeV1 } from './inline-ai-selection-session';
/**
 * Why a host can decline a selection Bubble handoff. The vocabulary mirrors
 * the review-presentation baseline reasons so hosts forward kernel outcomes
 * without translating them; anything else collapses to `unavailable`.
 */
export declare const INLINE_AI_BUBBLE_HANDOFF_REJECT_REASONS_V1: readonly ["multi-block-selection", "explicit-line-break", "unsupported-node", "collapsed-selection", "task-open", "capture-failed", "unavailable"];
export type InlineAiBubbleHandoffRejectReasonV1 = (typeof INLINE_AI_BUBBLE_HANDOFF_REJECT_REASONS_V1)[number];
export interface InlineAiBubbleHandoffRejectionV1 {
    readonly reason: InlineAiBubbleHandoffRejectReasonV1;
    /** Host diagnostic (status text, kernel code). Never primary copy. */
    readonly detail?: string;
}
export type InlineAiBubbleHandoffOutcomeV1 = 'accepted' | 'rejected' | null;
export type InlineAiBubbleHandoffTargetV1 = Pick<InlineAiSelectionRangeV1, 'from' | 'to'>;
/**
 * Receipt handed to the host together with a Skill / Edit with AI /
 * prompt-submit event. The Bubble hides optimistically when it hands off;
 * the host settles the receipt so a fail-closed open restores the Bubble on
 * the same selection instead of stranding the user with bare highlighted
 * text. Settling is idempotent: the first outcome wins.
 */
export interface InlineAiBubbleHandoffV1 {
    readonly target: InlineAiBubbleHandoffTargetV1 | null;
    readonly outcome: InlineAiBubbleHandoffOutcomeV1;
    /** Host presents its own chrome; the Bubble stays retired. */
    accept(): boolean;
    /**
     * Host failed closed. Returns true when the Bubble came back on the exact
     * handed-off selection (so the host need not surface its own fallback).
     */
    reject(rejection: InlineAiBubbleHandoffRejectReasonV1 | InlineAiBubbleHandoffRejectionV1 | string): boolean;
}
/** Normalize host input (kernel reason, status text, receipt) to a rejection. */
export declare const resolveInlineAiBubbleHandoffRejectionV1: (input: unknown) => InlineAiBubbleHandoffRejectionV1;
/** Author-facing copy shown inside the restored Bubble. */
export declare const resolveInlineAiBubbleHandoffNoticeCopyV1: (rejection: InlineAiBubbleHandoffRejectionV1) => string;
export declare const createInlineAiBubbleHandoff: (input: {
    readonly target: InlineAiBubbleHandoffTargetV1 | null;
    readonly onAccept?: () => void;
    readonly onReject?: (rejection: InlineAiBubbleHandoffRejectionV1) => boolean;
}) => InlineAiBubbleHandoffV1;
//# sourceMappingURL=inline-ai-bubble-handoff.d.ts.map