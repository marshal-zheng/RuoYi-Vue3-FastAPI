export type InlineAiTurnIntoIdV1 = 'paragraph' | 'heading-1' | 'heading-2' | 'heading-3' | 'heading-4' | 'bullet-list' | 'ordered-list' | 'task-list' | 'blockquote' | 'code-block';
export interface InlineAiTurnIntoOptionV1 {
    readonly id: InlineAiTurnIntoIdV1;
    readonly label: string;
    /** Lucide icon id for ZxIcon (enterprise Notion-like chrome). */
    readonly icon: string;
}
/** Notion-aligned Turn into set backed by TipTap nodes we already ship. */
export declare const INLINE_AI_TURN_INTO_OPTIONS_V1: readonly InlineAiTurnIntoOptionV1[];
export type InlineAiFormatActionIdV1 = 'color' | 'bold' | 'italic' | 'underline' | 'clear' | 'link' | 'strike' | 'code';
export interface InlineAiFormatActionV1 {
    readonly id: InlineAiFormatActionIdV1;
    readonly label: string;
    readonly glyph: string;
}
/** Notion-like 2×4 format grid order (color / B I U Tx / link strike code). */
export declare const INLINE_AI_FORMAT_ACTIONS_V1: readonly InlineAiFormatActionV1[];
type Chainable = {
    focus: () => Chainable;
    setParagraph?: () => Chainable;
    toggleHeading?: (attrs: {
        level: number;
    }) => Chainable;
    toggleBulletList?: () => Chainable;
    toggleOrderedList?: () => Chainable;
    toggleTaskList?: () => Chainable;
    toggleBlockquote?: () => Chainable;
    toggleCodeBlock?: () => Chainable;
    toggleBold?: () => Chainable;
    toggleItalic?: () => Chainable;
    toggleUnderline?: () => Chainable;
    toggleStrike?: () => Chainable;
    toggleCode?: () => Chainable;
    unsetAllMarks?: () => Chainable;
    setColor?: (color: string) => Chainable;
    unsetColor?: () => Chainable;
    extendMarkRange?: (mark: string) => Chainable;
    setLink?: (attrs: {
        href: string;
    }) => Chainable;
    unsetLink?: () => Chainable;
    run: () => boolean;
};
export type InlineAiSelectionEditorLike = {
    readonly isActive?: (name: string, attrs?: Record<string, unknown>) => boolean;
    readonly chain?: () => Chainable;
    readonly getAttributes?: (name: string) => Record<string, unknown>;
};
export declare const resolveInlineAiBlockLabel: (editor: InlineAiSelectionEditorLike | null | undefined) => string;
export declare const resolveInlineAiTurnIntoId: (editor: InlineAiSelectionEditorLike | null | undefined) => InlineAiTurnIntoIdV1;
export declare const applyInlineAiTurnInto: (editor: InlineAiSelectionEditorLike | null | undefined, id: InlineAiTurnIntoIdV1) => boolean;
export declare const isInlineAiFormatActive: (editor: InlineAiSelectionEditorLike | null | undefined, id: InlineAiFormatActionIdV1) => boolean;
export declare const applyInlineAiFormatAction: (editor: InlineAiSelectionEditorLike | null | undefined, id: InlineAiFormatActionIdV1, promptHref?: () => string | null) => boolean;
export {};
//# sourceMappingURL=inline-ai-selection-actions.d.ts.map