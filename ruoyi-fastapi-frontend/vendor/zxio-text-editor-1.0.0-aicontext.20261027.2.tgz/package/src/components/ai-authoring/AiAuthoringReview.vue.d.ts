import { ZxAIAuthoringActionIdV1, ZxAIAuthoringProjectionV1, ZxAIAuthoringReviewBundleV1 } from '../../ai/authoring-ux';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    readonly editorBindingId: string;
    readonly projection: ZxAIAuthoringProjectionV1;
    readonly bundle: ZxAIAuthoringReviewBundleV1;
    readonly activeItemId?: string;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    action: (actionId: ZxAIAuthoringActionIdV1) => any;
    decision: (input: {
        readonly kind: "accept-operation" | "reject-operation";
        readonly operationIndex: number;
    }) => any;
    navigate: (input: {
        readonly kind: "previous" | "next";
        readonly currentItemId: string;
    }) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onAction?: ((actionId: ZxAIAuthoringActionIdV1) => any) | undefined;
    onDecision?: ((input: {
        readonly kind: "accept-operation" | "reject-operation";
        readonly operationIndex: number;
    }) => any) | undefined;
    onNavigate?: ((input: {
        readonly kind: "previous" | "next";
        readonly currentItemId: string;
    }) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    reviewRoot: HTMLElement;
}, HTMLElement>;
export default _default;
//# sourceMappingURL=AiAuthoringReview.vue.d.ts.map