import { PropType, DefineComponent, ExtractPropTypes, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
import { Editor } from '@tiptap/vue-3';
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: {
        default?(_: {
            isActive: boolean;
        }): any;
    };
    refs: {
        referenceRef: HTMLSpanElement;
        customColorInputRef: HTMLInputElement;
    };
    rootEl: any;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: DefineComponent<ExtractPropTypes<{
    editor: {
        type: PropType<Editor | null>;
        required: true;
    };
    mode: {
        type: PropType<"text" | "background" | "both">;
        default: string;
    };
}>, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly< ExtractPropTypes<{
    editor: {
        type: PropType<Editor | null>;
        required: true;
    };
    mode: {
        type: PropType<"text" | "background" | "both">;
        default: string;
    };
}>> & Readonly<{}>, {
    mode: "text" | "background" | "both";
}, {}, {}, {}, string, ComponentProvideOptions, true, {
    referenceRef: HTMLSpanElement;
    customColorInputRef: HTMLInputElement;
}, any>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
//# sourceMappingURL=font-color.vue.d.ts.map