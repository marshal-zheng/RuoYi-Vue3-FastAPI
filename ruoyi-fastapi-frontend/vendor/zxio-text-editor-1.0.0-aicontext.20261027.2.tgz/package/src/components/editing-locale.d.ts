export declare const useEditingLocale: () => {
    text: (key: string | undefined, fallback: string) => string;
};
//# sourceMappingURL=editing-locale.d.ts.map