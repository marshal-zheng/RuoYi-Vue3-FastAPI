import { EditorPortalBindingView } from '../theme-owner';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
interface ImageInfo {
    src: string;
    alt: string | null;
}
type __VLS_Props = {
    show: boolean;
    images: ImageInfo[];
    initialIndex: number;
    portalBinding: EditorPortalBindingView;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    "update:show": (value: boolean) => any;
    "terminal-close": () => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onUpdate:show"?: ((value: boolean) => any) | undefined;
    "onTerminal-close"?: (() => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    imageContainer: HTMLDivElement;
    backdropElement: HTMLDivElement;
    controlsBar: HTMLDivElement;
}, any>;
export default _default;
//# sourceMappingURL=image-viewer-modal.vue.d.ts.map