import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    lines: readonly string[];
    lineNumbers: readonly number[];
    totalLineCount: number;
    showLineNumbers: boolean;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {} & {
    "request-expand": () => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    "onRequest-expand"?: (() => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=code-block-collapsed-projection.vue.d.ts.map