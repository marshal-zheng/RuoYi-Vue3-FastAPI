import { ZxCodeBlockCopyMode, ZxCodeBlockWrap } from '../code-block';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    language: string | null;
    title: string;
    collapsed: boolean;
    codeContent: string;
    copyContent?: string;
    copyMode: ZxCodeBlockCopyMode;
    wrap: ZxCodeBlockWrap;
    showLineNumbers: boolean;
    canCopyPlain: boolean;
    canCopyMarkdown: boolean;
    copyDisabledReason?: string | null;
    settingsOpen: boolean;
    detectingLanguage?: boolean;
    recentLanguages?: string[];
    defaultLanguage?: string | null;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    [x: string]: any;
} & {
    [x: string]: any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: any) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=code-block-header.vue.d.ts.map