import { Editor } from '@tiptap/vue-3';
import { ZxAskAIBridgeV1 } from '../ai/authoring-ux/ask-ai-bridge';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    editor?: Editor | null;
    showPlus?: boolean;
    onPlusClick?: () => void;
    askAIBridge?: Pick<ZxAskAIBridgeV1, 'openInvocation'> | null;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    menuRef: HTMLDivElement;
    menuItemRefs: HTMLButtonElement[];
}, any>;
export default _default;
//# sourceMappingURL=drag-handle.vue.d.ts.map