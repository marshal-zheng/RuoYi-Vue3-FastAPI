import { ActionInvocation, ActionPort, ActionState, Disposer } from '@zxio/keybindings/core';
/** AI receipts are domain outcomes, including fulfilled promises carrying failure. */
export declare const createAIAuthoringActionPort: <A>(options: {
    getState(args: A): ActionState;
    subscribe(listener: () => void): Disposer;
    run(args: A, invocation: ActionInvocation): unknown;
}) => ActionPort<A, unknown>;
//# sourceMappingURL=authoring-action-port.d.ts.map