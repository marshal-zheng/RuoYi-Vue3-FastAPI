import { ActionRef, ActionState, Disposer, OwnerRef, ShortcutClient } from '@zxio/keybindings/core';
import { InlineReviewHunkDecisionArgs, InlineReviewStepArgs } from './actions';
export interface InlineReviewHunkTarget {
    readonly hunkId: string;
    readonly decision: InlineReviewHunkDecisionArgs['decision'];
}
export interface InlineReviewActions {
    readonly owner: OwnerRef;
    readonly accept: ActionRef<unknown>;
    readonly stepPrevious: ActionRef<unknown>;
    readonly stepNext: ActionRef<unknown>;
    decide(args: InlineReviewHunkDecisionArgs): ActionRef<unknown>;
    addRoot(root: Element): Disposer;
    dispatch(event: KeyboardEvent): boolean;
    setHunkFocus(focused: boolean): void;
    dispose(): void;
}
/** One review port set can own the editor's hunk controls and a teleported chrome. */
export declare const createInlineReviewActions: (options: {
    runtime: ShortcutClient;
    parent?: OwnerRef;
    root: Element;
    getState(): ActionState;
    getAcceptState?(): ActionState;
    getHunks(): readonly InlineReviewHunkTarget[];
    getTarget(): InlineReviewHunkTarget | null;
    subscribe(listener: () => void): Disposer;
    accept(): unknown;
    decide(args: InlineReviewHunkDecisionArgs, source: "action" | "keyboard"): unknown;
    step(args: InlineReviewStepArgs): unknown;
}) => InlineReviewActions;
//# sourceMappingURL=inline-review-actions.d.ts.map