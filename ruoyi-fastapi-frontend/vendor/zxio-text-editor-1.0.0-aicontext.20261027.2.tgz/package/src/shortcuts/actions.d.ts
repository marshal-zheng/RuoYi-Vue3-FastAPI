import { ContextKey, ActionToken, ShortcutContribution } from '@zxio/keybindings/core';
export declare const reviewHunkFocused: ContextKey<false>;
export declare const progressiveSelectAction: ActionToken<undefined, boolean>;
export declare const editLinkAction: ActionToken<undefined, boolean>;
export declare const openInlineEditAction: ActionToken<undefined, unknown>;
export declare const openAskAIAction: ActionToken<undefined, unknown>;
export declare const dismissInlineAIAction: ActionToken<undefined, unknown>;
export declare const acceptInlineReviewAction: ActionToken<undefined, unknown>;
export interface ReviewOperationArgs {
    readonly operationIndex: number;
    readonly kind: 'accept-operation' | 'reject-operation';
}
export declare const decideReviewOperationAction: ActionToken<ReviewOperationArgs, void>;
export declare const cancelToolApprovalAction: ActionToken<undefined, void>;
export interface InlineReviewHunkDecisionArgs {
    readonly hunkId: string;
    readonly decision: 'accepted' | 'rejected' | 'undecided';
}
export declare const decideInlineReviewHunkAction: ActionToken<InlineReviewHunkDecisionArgs, unknown>;
export interface InlineReviewStepArgs {
    readonly direction: 'forward' | 'backward';
}
export declare const stepInlineReviewAction: ActionToken<InlineReviewStepArgs, unknown>;
/** Pure package declarations. Instances attach domain ports to these tokens. */
export declare const textEditorShortcuts: ShortcutContribution;
//# sourceMappingURL=actions.d.ts.map