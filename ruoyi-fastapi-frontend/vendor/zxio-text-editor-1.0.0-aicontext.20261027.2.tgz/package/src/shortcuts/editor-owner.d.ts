import { Editor } from '@tiptap/core';
import { EditorView } from '@tiptap/pm/view';
import { ActionRef, OwnerRef, ShortcutClient } from '@zxio/keybindings/core';
export declare const TEXT_EDITOR_SHORTCUT_STORAGE = "textEditorShortcutKeymap";
export interface TextEditorShortcutOwnerOptions {
    readonly runtime?: ShortcutClient;
    readonly parent?: OwnerRef;
}
export interface TextEditorShortcutOwner {
    readonly runtime: ShortcutClient;
    readonly owner: OwnerRef;
    readonly editLink: ActionRef<boolean>;
    readonly progressiveSelect: ActionRef<boolean>;
    readonly dispatch: (event: KeyboardEvent) => boolean;
    readonly dispose: () => void;
}
/** An editor-owned adapter: commands stay in the editor; input stays in runtime. */
export declare const attachTextEditorShortcutOwner: (editor: Editor, view: EditorView, options?: TextEditorShortcutOwnerOptions) => TextEditorShortcutOwner;
/** The exact editor instance is the target, including after a toolbar takes focus. */
export declare const getTextEditorShortcutOwner: (editor: {
    readonly storage?: object;
} | null | undefined) => TextEditorShortcutOwner | null;
/** Follow the owner of the current PM plugin view, including register/unregister. */
export declare const subscribeTextEditorShortcutOwner: (editor: {
    readonly storage?: object;
} | null | undefined, listener: (owner: TextEditorShortcutOwner | null) => void) => (() => void);
//# sourceMappingURL=editor-owner.d.ts.map