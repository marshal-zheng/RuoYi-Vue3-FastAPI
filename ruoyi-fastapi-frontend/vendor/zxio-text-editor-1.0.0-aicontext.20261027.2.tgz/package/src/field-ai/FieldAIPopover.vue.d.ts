import { EditorThemeOwner } from '../theme-owner';
import { useFieldAI } from './use-field-ai';
import { DefineComponent, Ref, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    controller: ReturnType<typeof useFieldAI>;
    themeOwner: EditorThemeOwner | null;
    /** The field shell the card docks under and matches in width. */
    anchor: () => HTMLElement | null | undefined;
};
declare const _default: DefineComponent<__VLS_Props, {
    rootEl: Ref<HTMLElement | undefined, HTMLElement | undefined>;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    focusin: (args_0: FocusEvent) => any;
    focusout: (args_0: FocusEvent) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onFocusin?: ((args_0: FocusEvent) => any) | undefined;
    onFocusout?: ((args_0: FocusEvent) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    rootEl: HTMLElement;
}, any>;
export default _default;
//# sourceMappingURL=FieldAIPopover.vue.d.ts.map