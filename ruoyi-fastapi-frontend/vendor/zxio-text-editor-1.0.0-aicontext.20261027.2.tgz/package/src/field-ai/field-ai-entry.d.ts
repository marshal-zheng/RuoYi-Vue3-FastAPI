import { SlashCatalogContribution } from '../extensions/slash-commands/catalog';
import { TextEditorToolbarContribution } from '../toolbar/registry';
import { ZxTextEditorFieldAISuggestion } from './types';
/** Shared id: the slash item, the bubble item and their zh copy keys. */
export declare const FIELD_AI_ITEM_ID = "ai.ask";
/** `/` lists Ask AI first; the remaining items stay profile-filtered. */
export declare const createFieldAISlashContribution: (open: () => void) => SlashCatalogContribution;
/** Selection bubble: one AI dropdown with one-click revisions and a free prompt. */
export declare const createFieldAIBubbleContribution: (options: {
    readonly suggestions: () => readonly ZxTextEditorFieldAISuggestion[];
    readonly disabled: () => boolean;
    readonly open: (instruction?: string) => void;
}) => TextEditorToolbarContribution;
//# sourceMappingURL=field-ai-entry.d.ts.map