import { AIContextNotice, AIContextReceipt } from '@zxio/zxui/ai-context';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    choices: readonly {
        id: string;
        label: string;
        disabled: boolean;
    }[];
    selectedIds: readonly string[];
    receipt: AIContextReceipt | null;
    notices: readonly AIContextNotice[];
    disabled: boolean;
    busy: boolean;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    draft: () => any;
    "update:selectedIds": (args_0: string[]) => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onDraft?: (() => any) | undefined;
    "onUpdate:selectedIds"?: ((args_0: string[]) => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, any>;
export default _default;
//# sourceMappingURL=FieldAIContext.vue.d.ts.map