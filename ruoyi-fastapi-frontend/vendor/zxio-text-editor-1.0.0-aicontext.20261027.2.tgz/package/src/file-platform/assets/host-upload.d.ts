import { ZxFileInputSource, ZxResolvedAsset } from '../types';
import { ZxTextEditorFilePlatformRuntime } from '../platform';
export interface UploadAssetViaHostPlatformOptions {
    context?: Record<string, unknown>;
    expectedNodeKind?: ZxResolvedAsset['nodeKind'];
    file: File;
    filePlatformRuntime: ZxTextEditorFilePlatformRuntime | null;
    source?: ZxFileInputSource;
}
export declare class ZxHostAssetUploadError extends Error {
    code: string;
    constructor(code: string, message: string);
}
export declare const uploadAssetViaHostPlatform: ({ context, expectedNodeKind, file, filePlatformRuntime, source, }: UploadAssetViaHostPlatformOptions) => Promise<ZxResolvedAsset>;
//# sourceMappingURL=host-upload.d.ts.map