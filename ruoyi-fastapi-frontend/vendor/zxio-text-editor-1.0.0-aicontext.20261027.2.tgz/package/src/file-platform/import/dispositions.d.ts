import { ZxFileIntakeEvent, ZxImportDisposition, ZxImportedTextFileFormat, ZxTextEditorFilePlatform } from '../types';
import { ZxTextEditorDocument } from '../../document';
export interface ResolveImportDispositionOptions {
    currentDocument: ZxTextEditorDocument;
    event: ZxFileIntakeEvent;
    file: File;
    filePlatform?: ZxTextEditorFilePlatform | null;
    format: ZxImportedTextFileFormat;
}
export declare const resolveImportDisposition: ({ currentDocument, event, file, filePlatform, format, }: ResolveImportDispositionOptions) => Promise<ZxImportDisposition>;
//# sourceMappingURL=dispositions.d.ts.map