import { ZxFileIntakeEvent, ZxImportDisposition, ZxImportedTextFileFormat, ZxTextEditorFilePlatform } from '../types';
import { ZxTextEditorDocument } from '../../document';
export interface ExecuteTextFileImportOptions {
    applyImportedDocument: (document: ZxTextEditorDocument) => void;
    currentDocument: ZxTextEditorDocument;
    event: ZxFileIntakeEvent;
    file: File;
    filePlatform?: ZxTextEditorFilePlatform | null;
    format: ZxImportedTextFileFormat;
    insertImportedDocument?: (document: ZxTextEditorDocument, request: {
        event: ZxFileIntakeEvent;
        file: File;
        format: ZxImportedTextFileFormat;
    }) => void;
}
export interface ZxTextFileImportExecutionResult {
    disposition: ZxImportDisposition;
    document?: ZxTextEditorDocument;
    handled: boolean;
}
export declare const executeTextFileImport: ({ applyImportedDocument, currentDocument, event, file, filePlatform, format, insertImportedDocument, }: ExecuteTextFileImportOptions) => Promise<ZxTextFileImportExecutionResult>;
//# sourceMappingURL=coordinator.d.ts.map