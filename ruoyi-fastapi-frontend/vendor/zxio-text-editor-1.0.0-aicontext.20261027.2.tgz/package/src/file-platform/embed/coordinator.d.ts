import { Editor as CoreEditor } from '@tiptap/core';
import { ZxTextEditorDocument } from '../../document';
import { ZxFileIntakeEvent, ZxRemoteEmbedResolution, ZxTextEditorFilePlatform } from '../types';
interface ValueRef<T> {
    value: T;
}
export interface ExecuteRemoteEmbedOptions {
    anchorPos?: number | null;
    documentState: ValueRef<ZxTextEditorDocument>;
    editor: CoreEditor | null;
    event: ZxFileIntakeEvent;
    filePlatform?: ZxTextEditorFilePlatform | null;
    url: string;
}
export interface ExecuteRemoteEmbedResult {
    handled: boolean;
    resolution: ZxRemoteEmbedResolution;
}
export declare class ZxRemoteEmbedResolutionError extends Error {
    code: string;
    constructor(code: string, message: string);
}
export declare const executeRemoteEmbed: ({ anchorPos, documentState, editor, event, filePlatform, url, }: ExecuteRemoteEmbedOptions) => Promise<ExecuteRemoteEmbedResult>;
export {};
//# sourceMappingURL=coordinator.d.ts.map