import { AnyExtension } from '@tiptap/core';
import { ZxTextEditorFilePlatformRuntime } from '../../platform';
export interface CreateTextEditorFileHandlerExtensionOptions {
    filePlatformRuntime: ZxTextEditorFilePlatformRuntime | null;
}
export declare const createTextEditorFileHandlerExtension: ({ filePlatformRuntime, }: CreateTextEditorFileHandlerExtensionOptions) => AnyExtension;
//# sourceMappingURL=file-handler.d.ts.map