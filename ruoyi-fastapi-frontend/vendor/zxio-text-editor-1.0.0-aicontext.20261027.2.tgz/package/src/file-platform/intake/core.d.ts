import { Editor as CoreEditor } from '@tiptap/core';
import { ZxTextEditorAssetPipelineRuntime } from '../assets';
import { ZxTextEditorFileIntakeDispatcher, ZxTextEditorFilePlatformRuntime } from '../platform';
import { ZxFileIntakeEvent } from '../types';
import { ZxTextEditorDocument } from '../../document';
interface ValueRef<T> {
    value: T;
}
export interface CreateTextEditorFileIntakeDispatcherOptions {
    applyImportedDocument: (document: ZxTextEditorDocument) => void;
    assetPipelineRuntime: ZxTextEditorAssetPipelineRuntime;
    documentState: ValueRef<ZxTextEditorDocument>;
    editor: ValueRef<CoreEditor | null>;
    filePlatformRuntime: ZxTextEditorFilePlatformRuntime;
    getCurrentDocument: () => ZxTextEditorDocument;
    insertImportedDocument?: (document: ZxTextEditorDocument, request: {
        event: ZxFileIntakeEvent;
        file: File;
        format: 'markdown' | 'html' | 'json' | 'text';
    }) => void;
}
export declare const createTextEditorFileIntakeDispatcher: ({ applyImportedDocument, assetPipelineRuntime, documentState, editor, filePlatformRuntime, getCurrentDocument, insertImportedDocument, }: CreateTextEditorFileIntakeDispatcherOptions) => ZxTextEditorFileIntakeDispatcher;
export {};
//# sourceMappingURL=core.d.ts.map