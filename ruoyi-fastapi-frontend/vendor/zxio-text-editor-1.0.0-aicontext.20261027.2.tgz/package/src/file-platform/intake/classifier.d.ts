import { ZxFileIntakeDispatchResult, ZxFileIntakeEvent, ZxFileIntentDecision, ZxTextEditorFilePlatform } from '../types';
export interface ClassifyFileIntakeEventOptions {
    event: ZxFileIntakeEvent;
    filePlatform?: ZxTextEditorFilePlatform | null;
}
export declare const ZX_DEFAULT_IMPORT_EXTENSIONS: readonly string[];
export declare const classifyFileIntakeEvent: ({ event, filePlatform, }: ClassifyFileIntakeEventOptions) => Promise<ZxFileIntentDecision>;
export declare const createClassifiedDispatchResult: (event: ZxFileIntakeEvent, decision: ZxFileIntentDecision, handled: boolean) => ZxFileIntakeDispatchResult;
//# sourceMappingURL=classifier.d.ts.map