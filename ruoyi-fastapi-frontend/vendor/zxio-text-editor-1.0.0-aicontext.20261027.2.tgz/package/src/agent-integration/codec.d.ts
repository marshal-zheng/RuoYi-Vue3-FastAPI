import { AgentAuditNodeV1, AgentDecodeResultV1, AgentDependencySnapshotRefV1, AgentEffectIntentV1, AgentHostEventV1, AgentItemV1, AgentRunCreateInputV1, AgentRunStateV1, AgentSafeDiagnosticV1, AgentSourceRefV1 } from './contract';
export declare const decodeAgentDependencySnapshotRefV1: (input: unknown) => AgentDecodeResultV1<AgentDependencySnapshotRefV1>;
export declare const decodeAgentItemV1: (input: unknown) => AgentDecodeResultV1<AgentItemV1>;
export declare const decodeAgentRunCreateInputV1: (input: unknown) => AgentDecodeResultV1<AgentRunCreateInputV1>;
export declare const decodeAgentSourceRefV1: (input: unknown) => AgentDecodeResultV1<AgentSourceRefV1>;
export declare const decodeAgentHostEventV1: (input: unknown) => AgentDecodeResultV1<AgentHostEventV1>;
export declare const decodeAgentEffectIntentV1: (input: unknown) => AgentDecodeResultV1<AgentEffectIntentV1>;
export declare const decodeAgentSafeDiagnosticV1: (input: unknown) => AgentDecodeResultV1<AgentSafeDiagnosticV1>;
export declare const decodeAgentAuditNodeV1: (input: unknown) => AgentDecodeResultV1<AgentAuditNodeV1>;
export declare const decodeAgentRunV1: (input: unknown) => AgentDecodeResultV1<AgentRunStateV1>;
export declare const serializeAgentRunV1: (state: AgentRunStateV1) => string;
export declare const auditHistoricalAgentRunV1: (input: unknown) => {
    version: "1.0.0";
    status: "audit-only";
    diagnostic: AgentSafeDiagnosticV1;
    fingerprint: `sha256:${string}`;
};
//# sourceMappingURL=codec.d.ts.map