import { ZX_AGENT_INTEGRATION_CONTRACT_VERSION, AgentFingerprintV1, AgentHostDescriptorV1, AgentSafeDiagnosticV1 } from './contract';
export declare const AGENT_CONFORMANCE_FINDING_IDS_V1: Readonly<{
    readonly providerLeakage: "AGENT_PORT_PROVIDER_PRIVATE_LEAK";
    readonly packageSideEffect: "AGENT_PACKAGE_DIRECT_SIDE_EFFECT";
    readonly directMutation: "AGENT_DOCUMENT_DIRECT_MUTATION";
    readonly crossDocumentToken: "AGENT_CROSS_DOCUMENT_COMMIT_TOKEN";
    readonly fakeBypass: "AGENT_FAKE_ONLY_BYPASS";
    readonly receiptSubstitution: "AGENT_RECEIPT_AUTHORITY_SUBSTITUTION";
    readonly currentAdmissionRequired: "AGENT_HISTORICAL_ADMISSION_REJECTED";
    readonly citationDiagnosticLeak: "AGENT_CITATION_DIAGNOSTIC_LEAK";
}>;
export type AgentConformanceFindingIdV1 = (typeof AGENT_CONFORMANCE_FINDING_IDS_V1)[keyof typeof AGENT_CONFORMANCE_FINDING_IDS_V1];
export interface AgentConformanceResultV1 {
    readonly version: typeof ZX_AGENT_INTEGRATION_CONTRACT_VERSION;
    readonly status: 'admitted' | 'rejected';
    readonly descriptorFingerprint: AgentFingerprintV1;
    readonly suiteFingerprint: AgentFingerprintV1;
    readonly findingIds: readonly AgentConformanceFindingIdV1[];
    readonly diagnostics: readonly AgentSafeDiagnosticV1[];
    readonly scope: AgentHostDescriptorV1['scope'];
    readonly current: true;
    readonly fingerprint: AgentFingerprintV1;
}
export declare const runCurrentAgentHostConformanceV1: (input: {
    readonly descriptor: unknown;
    readonly events: readonly unknown[];
    readonly expectedPolicyFingerprint: string;
    readonly expectedSourceClosureFingerprint: string;
    readonly suiteFingerprint: string;
}) => AgentConformanceResultV1;
export declare const auditHistoricalAgentConformanceV1: (input: unknown) => {
    version: "1.0.0";
    status: "audit-only";
    inputFingerprint: `sha256:${string}`;
    diagnostic: AgentSafeDiagnosticV1;
};
//# sourceMappingURL=conformance.d.ts.map