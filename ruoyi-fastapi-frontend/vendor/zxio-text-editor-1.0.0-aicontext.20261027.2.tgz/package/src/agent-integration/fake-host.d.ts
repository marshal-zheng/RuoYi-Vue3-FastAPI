import { AgentHostDescriptorV1, AgentHostEventV1, AgentOpaqueRefV1 } from './contract';
export type AgentFakeHostEventInputV1 = Omit<AgentHostEventV1, 'version' | 'fingerprint'>;
export interface AgentFakeHostScheduleV1 {
    readonly seedRef: AgentOpaqueRefV1;
    readonly fixtureFingerprint: `sha256:${string}`;
    readonly events: readonly AgentFakeHostEventInputV1[];
}
export interface AgentFakeHostV1 {
    readonly descriptor: AgentHostDescriptorV1;
    readonly scheduleFingerprint: `sha256:${string}`;
    readonly events: readonly AgentHostEventV1[];
    readonly simulationOnly: true;
}
export declare const createAgentHostEventV1: (input: AgentFakeHostEventInputV1) => AgentHostEventV1;
export declare const createDeterministicAgentFakeHostV1: (input: {
    readonly hostRef: AgentOpaqueRefV1;
    readonly hostVersion: string;
    readonly policyFingerprint: `sha256:${string}`;
    readonly sourceClosureFingerprint: `sha256:${string}`;
    readonly schedule: AgentFakeHostScheduleV1;
}) => AgentFakeHostV1;
//# sourceMappingURL=fake-host.d.ts.map