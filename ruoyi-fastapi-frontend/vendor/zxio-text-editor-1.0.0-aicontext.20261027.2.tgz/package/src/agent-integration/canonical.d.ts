import { AgentFingerprintV1, AgentSafeDiagnosticV1 } from './contract';
export declare const isAgentRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasAgentExactKeys: (value: unknown, required: readonly string[], optional?: readonly string[]) => value is Record<string, unknown>;
export declare const isAgentSafeRef: (value: unknown) => value is string;
export declare const isAgentFingerprint: (value: unknown) => value is AgentFingerprintV1;
export declare const isAgentLogicalTime: (value: unknown) => value is number;
export declare const fingerprintAgentDomain: (domain: string, value: unknown) => AgentFingerprintV1;
export declare const canonicalAgentClone: <TValue>(value: TValue) => TValue;
export declare const canonicalAgentEqual: (left: unknown, right: unknown) => boolean;
export declare const rejectAgentForbiddenValue: (value: unknown) => AgentSafeDiagnosticV1 | null;
export declare const createAgentDiagnosticV1: (code: AgentSafeDiagnosticV1["code"], stage: AgentSafeDiagnosticV1["stage"], details?: {
    readonly ordinal?: number;
    readonly count?: number;
    readonly category?: string;
    readonly fingerprint?: string;
}) => AgentSafeDiagnosticV1;
export declare const withoutAgentFingerprint: <TValue extends {
    readonly fingerprint: unknown;
}>(value: TValue) => Omit<TValue, "fingerprint">;
//# sourceMappingURL=canonical.d.ts.map