export declare const ZX_AGENT_INTEGRATION_CONTRACT_VERSION: "1.0.0";
export type AgentIntegrationContractVersionV1 = typeof ZX_AGENT_INTEGRATION_CONTRACT_VERSION;
declare const opaqueAgentRefBrand: unique symbol;
declare const nominalToolDecisionBrand: unique symbol;
declare const nominalToolExecutionBrand: unique symbol;
declare const nominalReviewReceiptBrand: unique symbol;
declare const nominalDocumentCommitBrand: unique symbol;
export type AgentOpaqueRefV1 = string & {
    readonly [opaqueAgentRefBrand]: 'AgentOpaqueRefV1';
};
export type ToolApprovalDecisionReceiptRefV1 = AgentOpaqueRefV1 & {
    readonly [nominalToolDecisionBrand]: true;
};
export type ToolExecutionReceiptRefV1 = AgentOpaqueRefV1 & {
    readonly [nominalToolExecutionBrand]: true;
};
export type ReviewDecisionReceiptRefV1 = AgentOpaqueRefV1 & {
    readonly [nominalReviewReceiptBrand]: true;
};
export type DocumentCommitReceiptRefV1 = AgentOpaqueRefV1 & {
    readonly [nominalDocumentCommitBrand]: true;
};
export type AgentFingerprintV1 = `sha256:${string}`;
export type AgentLogicalTimeV1 = number;
export type AgentRunStatusV1 = 'prepared' | 'running' | 'waiting-tool-approval' | 'waiting-document-review' | 'pending-review' | 'aborting' | 'blocked' | 'terminal';
export type AgentRunOutcomeV1 = 'succeeded' | 'partially-succeeded' | 'failed' | 'aborted';
export type AgentItemKindV1 = 'document' | 'tool';
export type AgentItemStatusV1 = 'prepared' | 'running' | 'waiting-tool-approval' | 'waiting-document-review' | 'aborting' | 'blocked' | 'sealed';
export type AgentItemOutcomeV1 = 'succeeded' | 'failed' | 'aborted' | 'denied' | 'rejected' | 'refine-required' | 'conflict' | 'rebase-required' | 'revoked' | 'superseded';
export type AgentDependencyKindV1 = 'permission' | 'source' | 'context' | 'base-document' | 'descriptor' | 'runtime' | 'policy';
export interface AgentDependencySnapshotRefV1 {
    readonly kind: AgentDependencyKindV1;
    readonly ref: AgentOpaqueRefV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentDocumentAuthorityRefsV1 {
    readonly documentRef: AgentOpaqueRefV1;
    readonly baseDocumentFingerprint: AgentFingerprintV1;
    readonly baseRevisionRef: AgentOpaqueRefV1;
    readonly stateVectorRef: AgentOpaqueRefV1;
    readonly scopeRef: AgentOpaqueRefV1;
    readonly descriptorRef: AgentOpaqueRefV1;
    readonly runtimeRef: AgentOpaqueRefV1;
    readonly policyRef: AgentOpaqueRefV1;
    readonly intentFingerprint: AgentFingerprintV1;
}
export interface AgentItemV1 {
    readonly itemRef: AgentOpaqueRefV1;
    readonly kind: AgentItemKindV1;
    readonly required: boolean;
    readonly attemptRef: AgentOpaqueRefV1;
    readonly predecessorAttemptRef?: AgentOpaqueRefV1;
    readonly dependencies: readonly AgentDependencySnapshotRefV1[];
    readonly dependsOnItemRefs: readonly AgentOpaqueRefV1[];
    readonly status: AgentItemStatusV1;
    readonly outcome?: AgentItemOutcomeV1;
    readonly receiptRef?: AgentOpaqueRefV1;
    readonly receiptKind?: 'tool-execution' | 'document-review' | 'document-commit' | 'abort-acknowledgement' | 'zero-effect';
    readonly effectRef?: AgentOpaqueRefV1;
    readonly toolApprovalDecisionReceiptRef?: ToolApprovalDecisionReceiptRefV1;
    readonly toolApprovalDecisionFingerprint?: AgentFingerprintV1;
    readonly toolExecutionReceiptRef?: ToolExecutionReceiptRefV1;
    readonly toolExecutionFingerprint?: AgentFingerprintV1;
    readonly reviewDecisionReceiptRef?: ReviewDecisionReceiptRefV1;
    readonly reviewDecisionFingerprint?: AgentFingerprintV1;
    readonly documentCommitReceiptRef?: DocumentCommitReceiptRefV1;
    readonly documentCommitFingerprint?: AgentFingerprintV1;
    readonly undoReceiptRef?: AgentOpaqueRefV1;
    readonly originReceiptRef?: AgentOpaqueRefV1;
    readonly document?: AgentDocumentAuthorityRefsV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentSourceRefV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly ref: AgentOpaqueRefV1;
    readonly kind: 'source' | 'context' | 'citation' | 'provenance';
    readonly safeLabel: string;
    readonly redactionReceiptRef: AgentOpaqueRefV1;
    readonly sourceSnapshotFingerprint: AgentFingerprintV1;
    readonly permissionSnapshotFingerprint: AgentFingerprintV1;
    readonly dependencySnapshots: readonly AgentDependencySnapshotRefV1[];
    readonly resolverCapabilityRef: AgentOpaqueRefV1;
    readonly status: 'available' | 'unavailable' | 'revoked';
    readonly safeReason?: 'no-access' | 'deleted-source' | 'resolver-timeout' | 'citation-mismatch' | 'permission-revoked';
    readonly order: number;
    readonly dedupeKey: AgentFingerprintV1;
    readonly outcomeBindingRef: AgentOpaqueRefV1;
    readonly fingerprint: AgentFingerprintV1;
}
export type AgentDiagnosticCodeV1 = 'agent-input-invalid' | 'agent-version-unsupported' | 'agent-resource-exceeded' | 'agent-revision-conflict' | 'agent-event-gap' | 'agent-event-duplicate-conflict' | 'agent-event-late' | 'agent-authority-mismatch' | 'agent-dependency-revoked' | 'agent-capability-unavailable' | 'agent-summary-conflict' | 'agent-historical-audit-only';
export interface AgentSafeDiagnosticV1 {
    readonly code: AgentDiagnosticCodeV1;
    readonly stage: 'contract' | 'host-admission' | 'event' | 'authority' | 'projection' | 'recovery' | 'historical';
    readonly ordinal?: number;
    readonly count?: number;
    readonly category?: string;
    readonly fingerprintPrefix?: string;
}
export interface AgentEffectIntentV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly effectRef: AgentOpaqueRefV1;
    readonly idempotencyKey: AgentOpaqueRefV1;
    readonly expectedRunRevision: number;
    readonly itemRef: AgentOpaqueRefV1;
    readonly attemptRef: AgentOpaqueRefV1;
    readonly intentFingerprint: AgentFingerprintV1;
    readonly dependencySnapshots: readonly AgentDependencySnapshotRefV1[];
    readonly expiresAt: AgentLogicalTimeV1;
    readonly kind: 'request-tool-approval' | 'abort-tool-execution' | 'abort-document-operation' | 'request-citation-reveal' | 'request-missing-range' | 'request-current-checkpoint' | 'verify-terminal-root' | 'request-effect-status' | 'request-abort-status' | 'require-fresh-admission' | 'mark-unrecoverable';
    readonly recovery?: {
        readonly firstSequence: number;
        readonly lastSequence: number;
        readonly expectedPredecessorFingerprint: AgentFingerprintV1;
        readonly maxRetries: number;
    };
    readonly payloadFingerprint: AgentFingerprintV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentAuditNodeV1 {
    readonly eventRef: AgentOpaqueRefV1;
    readonly sequence: number;
    readonly revision: number;
    readonly attemptRef?: AgentOpaqueRefV1;
    readonly predecessorFingerprint: AgentFingerprintV1;
    readonly eventFingerprint: AgentFingerprintV1;
    readonly transition: 'accepted' | 'accepted-idempotent' | 'late-observation' | 'rejected';
    readonly logicalTime: AgentLogicalTimeV1;
    readonly authorityReceiptRoots: readonly AgentFingerprintV1[];
    readonly dependencySnapshotRoots: readonly AgentFingerprintV1[];
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentRunStateV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly runRef: AgentOpaqueRefV1;
    readonly runPrincipalRef: AgentOpaqueRefV1;
    readonly purposeDigest: AgentFingerprintV1;
    readonly policyRef: AgentOpaqueRefV1;
    readonly policyFingerprint: AgentFingerprintV1;
    readonly logicalTime: AgentLogicalTimeV1;
    readonly revision: number;
    readonly nextExpectedSequence: number;
    readonly status: AgentRunStatusV1;
    readonly outcome?: AgentRunOutcomeV1;
    readonly items: readonly AgentItemV1[];
    readonly citations: readonly AgentSourceRefV1[];
    readonly effects: readonly AgentEffectIntentV1[];
    readonly diagnostics: readonly AgentSafeDiagnosticV1[];
    readonly audit: readonly AgentAuditNodeV1[];
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentRunProjectionItemV1 {
    readonly ordinal: number;
    readonly kind: AgentItemKindV1;
    readonly status: AgentItemStatusV1;
    readonly outcome?: AgentItemOutcomeV1;
    readonly receiptAvailable: boolean;
    readonly allowedActions: readonly ('review' | 'retry' | 'rerun-as-new-item' | 'inspect-receipt')[];
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentRunProjectionV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly runRef: string;
    readonly status: AgentRunStatusV1;
    readonly outcome?: AgentRunOutcomeV1;
    readonly stage: string;
    readonly progress: {
        readonly sealed: number;
        readonly total: number;
    };
    readonly availableActions: readonly ('abort' | 'retry' | 'review')[];
    readonly diagnostics: readonly AgentSafeDiagnosticV1[];
    readonly items: readonly AgentRunProjectionItemV1[];
    readonly citations: readonly {
        readonly ordinal: number;
        readonly safeLabel: string;
        readonly status: AgentSourceRefV1['status'];
        readonly safeReason?: AgentSourceRefV1['safeReason'];
        readonly canReveal: boolean;
    }[];
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentRunCreateInputV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly runRef: AgentOpaqueRefV1;
    readonly runPrincipalRef: AgentOpaqueRefV1;
    readonly purposeDigest: AgentFingerprintV1;
    readonly policyRef: AgentOpaqueRefV1;
    readonly policyFingerprint: AgentFingerprintV1;
    readonly logicalTime: AgentLogicalTimeV1;
    readonly items: readonly Omit<AgentItemV1, 'status' | 'fingerprint'>[];
}
export type AgentEventKindV1 = 'run-started' | 'item-started' | 'tool-approval-requested' | 'tool-decision-observed' | 'tool-execution-observed' | 'document-review-observed' | 'document-commit-observed' | 'dependency-revoked' | 'citation-status-observed' | 'capability-unavailable' | 'abort-requested' | 'abort-acknowledged' | 'retry-item' | 'host-summary-observed' | 'checkpoint-observed';
export interface AgentHostEventV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly eventRef: AgentOpaqueRefV1;
    readonly runRef: AgentOpaqueRefV1;
    readonly runPrincipalRef: AgentOpaqueRefV1;
    readonly expectedRunRevision: number;
    readonly sequence: number;
    readonly logicalTime: AgentLogicalTimeV1;
    readonly predecessorFingerprint: AgentFingerprintV1;
    readonly kind: AgentEventKindV1;
    readonly itemRef?: AgentOpaqueRefV1;
    readonly dependencyFingerprint?: AgentFingerprintV1;
    readonly outcome?: AgentItemOutcomeV1 | AgentRunOutcomeV1;
    readonly receiptRef?: AgentOpaqueRefV1;
    readonly receiptFingerprint?: AgentFingerprintV1;
    readonly receiptKind?: AgentItemV1['receiptKind'];
    readonly approvalDecisionFingerprint?: AgentFingerprintV1;
    readonly reviewDecision?: 'accept' | 'reject' | 'refine' | 'supersede';
    readonly undoReceiptRef?: AgentOpaqueRefV1;
    readonly originReceiptRef?: AgentOpaqueRefV1;
    readonly citation?: AgentSourceRefV1;
    readonly freshAttemptRef?: AgentOpaqueRefV1;
    readonly freshDependencies?: readonly AgentDependencySnapshotRefV1[];
    readonly freshDocument?: AgentDocumentAuthorityRefsV1;
    readonly idempotencyKey?: AgentOpaqueRefV1;
    readonly expiresAt?: AgentLogicalTimeV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentReduceResultV1 {
    readonly status: 'accepted' | 'accepted-idempotent' | 'late-observation' | 'blocked' | 'rejected';
    readonly state: AgentRunStateV1;
    readonly effects: readonly AgentEffectIntentV1[];
    readonly projection: AgentRunProjectionV1;
    readonly diagnostic?: AgentSafeDiagnosticV1;
}
export type AgentDecodeResultV1<TValue> = {
    readonly ok: true;
    readonly value: TValue;
} | {
    readonly ok: false;
    readonly diagnostic: AgentSafeDiagnosticV1;
};
export interface ToolApprovalRequestV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly requestRef: AgentOpaqueRefV1;
    readonly runRef: AgentOpaqueRefV1;
    readonly runPrincipalRef: AgentOpaqueRefV1;
    readonly approvalActorRef: AgentOpaqueRefV1;
    readonly targetPrincipalRef: AgentOpaqueRefV1;
    readonly approvalAuthorityRef: AgentOpaqueRefV1;
    readonly effectRef: AgentOpaqueRefV1;
    readonly expectedRunRevision: number;
    readonly permissionSnapshotRef: AgentDependencySnapshotRefV1;
    readonly dependencySnapshots: readonly AgentDependencySnapshotRefV1[];
    readonly toolRef: AgentOpaqueRefV1;
    readonly toolVersion: string;
    readonly schemaFingerprint: AgentFingerprintV1;
    readonly intentDigest: AgentFingerprintV1;
    readonly risk: 'low' | 'medium' | 'high' | 'critical';
    readonly capability: 'read' | 'write' | 'send' | 'delete' | 'execute';
    readonly scopeRefs: readonly AgentOpaqueRefV1[];
    readonly targetRefs: readonly AgentOpaqueRefV1[];
    readonly safeDisplay: string;
    readonly redactionReceiptRef: AgentOpaqueRefV1;
    readonly expiresAt: AgentLogicalTimeV1;
    readonly oneShotKey: AgentOpaqueRefV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface ToolApprovalDecisionReceiptV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly receiptRef: ToolApprovalDecisionReceiptRefV1;
    readonly requestFingerprint: AgentFingerprintV1;
    readonly runRef: AgentOpaqueRefV1;
    readonly runPrincipalRef: AgentOpaqueRefV1;
    readonly approvalActorRef: AgentOpaqueRefV1;
    readonly targetPrincipalRef: AgentOpaqueRefV1;
    readonly approvalAuthorityRef: AgentOpaqueRefV1;
    readonly permissionSnapshotFingerprint: AgentFingerprintV1;
    readonly decision: 'approve' | 'deny' | 'cancel';
    readonly decidedAt: AgentLogicalTimeV1;
    readonly expiresAt: AgentLogicalTimeV1;
    readonly oneShotScope: AgentOpaqueRefV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface ToolExecutionReceiptV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly receiptRef: ToolExecutionReceiptRefV1;
    readonly approvalDecisionFingerprint: AgentFingerprintV1;
    readonly effectRef: AgentOpaqueRefV1;
    readonly idempotencyKey: AgentOpaqueRefV1;
    readonly expectedRunRevision: number;
    readonly runRef: AgentOpaqueRefV1;
    readonly runPrincipalRef: AgentOpaqueRefV1;
    readonly targetPrincipalRef: AgentOpaqueRefV1;
    readonly intentFingerprint: AgentFingerprintV1;
    readonly permissionSnapshotFingerprint: AgentFingerprintV1;
    readonly dependencySnapshots: readonly AgentDependencySnapshotRefV1[];
    readonly expiresAt: AgentLogicalTimeV1;
    readonly status: 'succeeded' | 'failed' | 'aborted';
    readonly terminalAt: AgentLogicalTimeV1;
    readonly safeResultDigest: AgentFingerprintV1;
    readonly simulationScope?: 'simulation';
    readonly fixtureFingerprint?: AgentFingerprintV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentHostDescriptorV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly hostRef: AgentOpaqueRefV1;
    readonly hostVersion: string;
    readonly capabilityRefs: readonly AgentOpaqueRefV1[];
    readonly policyFingerprint: AgentFingerprintV1;
    readonly sourceClosureFingerprint: AgentFingerprintV1;
    readonly supportedEventVersions: readonly AgentIntegrationContractVersionV1[];
    readonly supportedReceiptVersions: readonly AgentIntegrationContractVersionV1[];
    readonly scope: 'simulation' | 'package-conformance' | 'deployment';
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentHostAdmissionReceiptV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly hostRef: AgentOpaqueRefV1;
    readonly descriptorFingerprint: AgentFingerprintV1;
    readonly contractFingerprint: AgentFingerprintV1;
    readonly status: 'admitted' | 'rejected';
    readonly scope: AgentHostDescriptorV1['scope'];
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentAuditCompactionV1 {
    readonly version: AgentIntegrationContractVersionV1;
    readonly runRef: AgentOpaqueRefV1;
    readonly firstSequence: number;
    readonly lastSequence: number;
    readonly terminalItemRoots: readonly AgentFingerprintV1[];
    readonly authorityReceiptRoots: readonly AgentFingerprintV1[];
    readonly lateEventProofs: readonly AgentFingerprintV1[];
    readonly predecessorRoots: readonly AgentFingerprintV1[];
    readonly dependencySnapshotRoots: readonly AgentFingerprintV1[];
    readonly contractFingerprint: AgentFingerprintV1;
    readonly auditOnly: true;
    readonly fingerprint: AgentFingerprintV1;
}
export {};
//# sourceMappingURL=contract.d.ts.map