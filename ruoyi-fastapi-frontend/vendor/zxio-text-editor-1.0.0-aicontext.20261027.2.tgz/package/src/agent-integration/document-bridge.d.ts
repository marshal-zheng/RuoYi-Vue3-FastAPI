import { AgentDecodeResultV1, AgentDocumentAuthorityRefsV1, AgentFingerprintV1, AgentOpaqueRefV1, DocumentCommitReceiptRefV1, ReviewDecisionReceiptRefV1 } from './contract';
export interface AgentDocumentAuthorityHandoffV1 {
    readonly documentRef: AgentOpaqueRefV1;
    readonly operationReceiptFingerprint: AgentFingerprintV1;
    readonly detachedExecutionReceiptFingerprint: AgentFingerprintV1;
    readonly proposalRef: AgentOpaqueRefV1;
    readonly proposalFingerprint: AgentFingerprintV1;
    readonly proposalReceiptFingerprint: AgentFingerprintV1;
    readonly reviewRef: AgentOpaqueRefV1;
    readonly reviewReceiptRef: ReviewDecisionReceiptRefV1;
    readonly reviewFingerprint: AgentFingerprintV1;
    readonly reviewDecision: 'pending' | 'accept' | 'reject' | 'refine' | 'supersede';
    readonly commitStatus: 'awaiting-review' | 'committed' | 'conflict' | 'rebase-required' | 'rejected';
    readonly commitReceiptRef?: DocumentCommitReceiptRefV1;
    readonly commitFingerprint?: AgentFingerprintV1;
    readonly undoReceiptRef?: AgentOpaqueRefV1;
    readonly originReceiptRef?: AgentOpaqueRefV1;
    readonly fingerprint: AgentFingerprintV1;
}
export interface AgentPublicDocumentAuthorityHandoffInputV1 {
    readonly sealedResult: {
        readonly kind: string;
        readonly contentDigest: string;
    };
}
/**
 * Executes the existing public S2 validator -> Runtime v2 detached execution
 * -> S3 Proposal -> S4 Review handoff. No Agent-owned operation, proposal or
 * review callback participates in this authority path.
 */
export declare const advanceDocumentWorkItemThroughPublicAuthorityV1: (input: {
    readonly document: AgentDocumentAuthorityRefsV1;
    readonly operationFingerprint: AgentFingerprintV1;
    readonly handoff: AgentPublicDocumentAuthorityHandoffInputV1;
    readonly runtime?: unknown;
}) => Promise<AgentDecodeResultV1<AgentDocumentAuthorityHandoffV1>>;
/** Reads only a transfer already published by the existing public S2-S4 path. */
export declare const readDocumentWorkItemPublicAuthorityTransferV1: (input: {
    readonly document: AgentDocumentAuthorityRefsV1;
    readonly operationFingerprint: AgentFingerprintV1;
    readonly transfer: unknown;
}) => Promise<AgentDecodeResultV1<AgentDocumentAuthorityHandoffV1>>;
//# sourceMappingURL=document-bridge.d.ts.map