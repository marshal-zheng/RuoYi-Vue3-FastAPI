export { DEFAULT_TEXT_EDITOR_TYPOGRAPHY_CONTRACT, resolveTextEditorTypographyContract, TEXT_EDITOR_TYPOGRAPHY_BLOCK_KEYS, TEXT_EDITOR_TYPOGRAPHY_VALUE_SOURCES, } from './contract';
export { TEXT_EDITOR_TYPOGRAPHY_SURFACE_CLASS, resolveTextEditorTypographyContractFromEditor, resolveTextEditorTypographySurface, resolveTextEditorTypographySurfaceFromEditor, resolveTextEditorTypographySurfaceVars, } from './surface';
export type { TextEditorTypographyBlockKey, TextEditorTypographyContract, TextEditorTypographyFallbackConfig, } from './contract';
export type { TextEditorTypographySurfaceBindings, } from './surface';
export type { TextEditorTypographyTokens, TextEditorTypographyValueDefinition, TextEditorTypographyValueSource, } from './contract';
//# sourceMappingURL=index.d.ts.map