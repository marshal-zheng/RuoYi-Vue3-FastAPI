import { Extension } from '@tiptap/core';
import { TextEditorTypographyContract } from './contract';
export declare const TEXT_EDITOR_TYPOGRAPHY_STORAGE_KEY = "zxTextEditorTypography";
export interface TextEditorTypographyStorage {
    contract: TextEditorTypographyContract;
}
export interface TextEditorTypographyContractExtensionOptions {
    contract: TextEditorTypographyContract;
}
export declare const TextEditorTypographyContractExtension: Extension<TextEditorTypographyContractExtensionOptions, TextEditorTypographyStorage>;
//# sourceMappingURL=extension.d.ts.map