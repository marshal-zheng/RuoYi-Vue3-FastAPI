export declare const TEXT_EDITOR_TYPOGRAPHY_BLOCK_KEYS: readonly ["paragraph", "heading-1", "heading-2", "heading-3", "heading-4", "heading-5", "heading-6", "bullet-list", "ordered-list", "task-list", "blockquote", "code-block"];
export type TextEditorTypographyBlockKey = (typeof TEXT_EDITOR_TYPOGRAPHY_BLOCK_KEYS)[number];
export declare const TEXT_EDITOR_TYPOGRAPHY_VALUE_SOURCES: readonly ["none", "text-style", "stored-mark", "block-default", "fallback"];
export type TextEditorTypographyValueSource = (typeof TEXT_EDITOR_TYPOGRAPHY_VALUE_SOURCES)[number];
export interface TextEditorTypographyValueDefinition {
    cssValue: string | null;
    displayValue?: string | null;
}
export interface TextEditorTypographyTokens {
    fontSize?: TextEditorTypographyValueDefinition;
    fontFamily?: TextEditorTypographyValueDefinition;
}
export interface TextEditorTypographyFallbackConfig {
    allowUnknownNodeFallback: boolean;
}
export interface TextEditorTypographyContract {
    root: TextEditorTypographyTokens;
    blocks: Partial<Record<TextEditorTypographyBlockKey, TextEditorTypographyTokens>>;
    fallback: TextEditorTypographyFallbackConfig;
}
export declare const DEFAULT_TEXT_EDITOR_TYPOGRAPHY_CONTRACT: TextEditorTypographyContract;
export declare const resolveTextEditorTypographyContract: (options?: {
    base?: TextEditorTypographyContract;
    override?: Partial<TextEditorTypographyContract> | null;
}) => TextEditorTypographyContract;
//# sourceMappingURL=contract.d.ts.map