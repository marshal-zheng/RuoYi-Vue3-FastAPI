export { DEFAULT_TEXT_EDITOR_PLACEHOLDER_CONTRACT, resolveTextEditorPlaceholderContract, } from './contract';
export type { TextEditorPlaceholderContract } from './contract';
//# sourceMappingURL=index.d.ts.map