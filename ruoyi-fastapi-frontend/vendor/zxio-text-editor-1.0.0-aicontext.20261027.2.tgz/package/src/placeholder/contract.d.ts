export interface TextEditorPlaceholderContract {
    /** Placeholder for the very first paragraph block in the document */
    firstParagraph: string;
    /** Placeholders for heading levels 1-6 */
    headings: {
        1: string;
        2: string;
        3: string;
        4: string;
        5: string;
        6: string;
    };
    /** Placeholder for bullet list blocks */
    bulletList: string;
    /** Placeholder for ordered/numbered list blocks */
    orderedList: string;
    /** Placeholder for task list items */
    taskItem: string;
    /** Placeholder for blockquote blocks */
    blockquote: string;
    /** Placeholder for code blocks */
    codeBlock: string;
    /** Placeholder for toggle blocks */
    toggle: string;
}
export declare const DEFAULT_TEXT_EDITOR_PLACEHOLDER_CONTRACT: TextEditorPlaceholderContract;
export interface ResolveTextEditorPlaceholderContractOptions {
    /** Base contract to merge onto, defaults to DEFAULT_TEXT_EDITOR_PLACEHOLDER_CONTRACT */
    base?: TextEditorPlaceholderContract;
    /** Partial override. When null/undefined, base is returned as-is. */
    override?: Partial<TextEditorPlaceholderContract> | null;
}
export declare const resolveTextEditorPlaceholderContract: (options?: ResolveTextEditorPlaceholderContractOptions) => TextEditorPlaceholderContract;
//# sourceMappingURL=contract.d.ts.map