/**
 * Shared component-reference primitives retained for schema/render authority
 * descriptors. Runtime execution contracts live exclusively in
 * deterministic-runtime/contract.ts and are exported only from ./ai.
 */
export interface ZxComponentDependencyRef {
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
}
export interface ZxVersionedComponentRef extends ZxComponentDependencyRef {
    readonly dependencies: readonly ZxComponentDependencyRef[];
}
export interface ZxExactPackageImplementationRef extends ZxVersionedComponentRef {
    readonly packageName: string;
    readonly runtimeSpecifier: string;
    readonly resolvedVersion: string;
    readonly lockIntegrity: string;
    readonly apiContractFingerprint: string;
    readonly implementationFingerprint: string;
    readonly admittedSemverRanges: readonly string[];
}
//# sourceMappingURL=contract.d.ts.map