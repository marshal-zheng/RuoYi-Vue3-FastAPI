export declare const sha256Text: (text: string) => string;
export declare const sha256Fingerprint: (value: unknown) => string;
export declare const fingerprintPrefix: (value: string) => string;
//# sourceMappingURL=fingerprint.d.ts.map