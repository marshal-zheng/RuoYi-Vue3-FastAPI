import { ZxExactPackageImplementationRef } from './contract';
export declare const ZX_PROSEMIRROR_MODEL_EXACT_REF: ZxExactPackageImplementationRef;
export declare const ZX_PROSEMIRROR_TRANSFORM_EXACT_REF: ZxExactPackageImplementationRef;
export declare const ZX_PROSEMIRROR_STATE_EXACT_REF: ZxExactPackageImplementationRef;
//# sourceMappingURL=current-package-refs.d.ts.map