import { JSONContent } from '@tiptap/core';
import { ZxTextEditorDocument } from '../document/types';
import { ZxSchemaNodeContract, ZxSchemaMarkContract } from './schema-kernel';
export interface TextEditorContentLimits {
    characters: number;
    bytes: number;
    nodes: number;
    listDepth: number;
    treeDepth: number;
    containerDepth: number;
    href: number;
}
export type TextEditorContentProfile = 'full' | 'basic-rich-text';
export declare const BASIC_RICH_TEXT_LIMITS: Readonly<TextEditorContentLimits>;
/** Content colors are stored by name; each theme resolves `--prose-color-<name>`. */
export declare const BASIC_RICH_TEXT_TEXT_COLORS: readonly ["red", "orange", "green", "blue", "purple", "gray"];
export type BasicRichTextTextColor = (typeof BASIC_RICH_TEXT_TEXT_COLORS)[number];
export declare const BASIC_RICH_TEXT_PROFILE: Readonly<{
    id: "basic-rich-text";
    nodes: readonly ZxSchemaNodeContract[];
    marks: readonly ZxSchemaMarkContract[];
    limits: Readonly<TextEditorContentLimits>;
    textColors: readonly ["red", "orange", "green", "blue", "purple", "gray"];
    /** Toolbar, slash and shortcut surfaces offer only these interactions. */
    capabilities: readonly ["history", "history.undo", "history.redo", "format.bold", "format.italic", "text-color", "list.bullet", "list.ordered", "block-style.list", "block-style.paragraph", "insert.link"];
}>;
export declare const validateBasicRichTextHref: (href: unknown, max?: number) => string;
export declare const basicRichTextLiteral: (node: JSONContent) => string;
/** One A policy for persisted input, runtime commits and explicit paste import. */
export declare const validateBasicRichTextDocument: (value: unknown, overrides?: Partial<TextEditorContentLimits>) => ZxTextEditorDocument | null;
//# sourceMappingURL=basic-rich-text.d.ts.map