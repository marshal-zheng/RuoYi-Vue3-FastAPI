import { ZxRenderProfileName, ZxRenderStrictness, ZxRenderTargetName } from '../render/contract';
import { ZxExtensionDescriptor, ZxHTMLRenderTargetCapability, ZxReactRenderTargetCapability, ZxRenderProfileCapability, ZxRenderUnsupportedHandling, ZxTextRenderTargetCapability } from './extension-descriptors';
export type ZxDescriptorConformanceState = 'supported' | 'unsupported' | 'invalid';
export interface ZxDescriptorCapabilityStatus<TCapability> {
    state: ZxDescriptorConformanceState;
    declared: boolean;
    capability?: Readonly<TCapability>;
}
export type ZxDescriptorConformanceIssueCode = 'missing-target-declaration' | 'missing-html-contract' | 'missing-react-contract' | 'missing-text-contract' | 'orphan-html-contract' | 'orphan-react-contract' | 'orphan-text-contract' | 'profile-without-target' | 'unsupported-policy-mismatch' | 'assembly-semantics-mismatch';
export interface ZxDescriptorConformanceIssue {
    code: ZxDescriptorConformanceIssueCode;
    descriptor: string;
    severity: 'error';
    target?: ZxRenderTargetName;
    profile?: ZxRenderProfileName;
    node?: string;
    mark?: string;
    message: string;
}
type ZxDescriptorTargetCapabilitySummary = Readonly<{
    html: ZxDescriptorCapabilityStatus<ZxHTMLRenderTargetCapability>;
    react: ZxDescriptorCapabilityStatus<ZxReactRenderTargetCapability>;
    text: ZxDescriptorCapabilityStatus<ZxTextRenderTargetCapability>;
}>;
type ZxDescriptorProfileCapabilitySummary = Readonly<{
    [K in ZxRenderProfileName]: ZxDescriptorCapabilityStatus<ZxRenderProfileCapability>;
}>;
export interface ZxDescriptorConformanceSummary {
    descriptor: string;
    targets: ZxDescriptorTargetCapabilitySummary;
    profiles: ZxDescriptorProfileCapabilitySummary;
    issues: readonly ZxDescriptorConformanceIssue[];
    valid: boolean;
}
export interface ZxRenderCapabilityConformanceReport {
    descriptors: readonly ZxDescriptorConformanceSummary[];
    issues: readonly ZxDescriptorConformanceIssue[];
    valid: boolean;
    targetMatrix: Readonly<Record<ZxRenderTargetName, {
        strictness: ZxRenderStrictness;
        unsupportedHandling: ZxRenderUnsupportedHandling;
        descriptors: readonly string[];
        nodes: readonly string[];
        marks: readonly string[];
    }>>;
    profileMatrix: Readonly<Record<ZxRenderProfileName, {
        strictness: ZxRenderStrictness;
        unsupportedHandling: ZxRenderUnsupportedHandling;
        supportedDescriptors: readonly string[];
        supportedNodes: readonly string[];
        supportedMarks: readonly string[];
        semanticDegradeDescriptors: readonly string[];
        semanticDegradeNodes: readonly string[];
        semanticDegradeMarks: readonly string[];
    }>>;
}
export declare class ZxRenderConformanceError extends Error {
    readonly report: ZxRenderCapabilityConformanceReport;
    constructor(message: string, report: ZxRenderCapabilityConformanceReport);
}
export declare const resolveUnsupportedHandlingForStrictness: (strictness: ZxRenderStrictness) => ZxRenderUnsupportedHandling;
export declare const createRenderCapabilityConformanceReport: (descriptors?: readonly ZxExtensionDescriptor[]) => ZxRenderCapabilityConformanceReport;
export declare const createRenderCapabilityReport: (descriptors?: readonly ZxExtensionDescriptor[]) => ZxRenderCapabilityConformanceReport;
export {};
//# sourceMappingURL=extension-conformance.d.ts.map