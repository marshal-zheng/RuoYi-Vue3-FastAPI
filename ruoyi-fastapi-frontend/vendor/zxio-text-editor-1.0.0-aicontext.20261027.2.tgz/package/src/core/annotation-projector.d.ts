export interface ZxAnnotationProjectionPosition {
    readonly blockId: string;
    readonly offset: number;
}
export interface ZxAnnotationProjectionBlock {
    readonly blockId: string;
    readonly order: number;
    readonly text: string;
}
export interface ZxAnnotationTextProjection {
    readonly quote: string;
    readonly before: string;
    readonly after: string;
}
export declare const projectTextEditorAnnotationText: (blocks: readonly ZxAnnotationProjectionBlock[], start: ZxAnnotationProjectionPosition, end: ZxAnnotationProjectionPosition) => ZxAnnotationTextProjection | null;
//# sourceMappingURL=annotation-projector.d.ts.map