/** Storage key of the admission extension that publishes a profile's interactions. */
export declare const TEXT_EDITOR_CONTENT_PROFILE_STORAGE = "basicRichTextAdmission";
export interface TextEditorContentProfileBoundary {
    readonly capabilities: ReadonlySet<string>;
    readonly textColors: readonly string[];
}
/** Null for the full profile; interaction surfaces then keep every capability. */
export declare const resolveTextEditorContentProfileBoundary: (editor: unknown) => TextEditorContentProfileBoundary | null;
//# sourceMappingURL=content-profile-boundary.d.ts.map