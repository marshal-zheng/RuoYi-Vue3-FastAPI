import { ZxDescriptorAICapability } from '../../ai/contract';
import { ZxRenderAuthorityEntry } from '../render-authority';
import { ZxSchemaAdapterDescriptor, ZxSchemaAdapterEntry, ZxSchemaAdapterSurface, ZxSchemaParityDiagnostic, ZxSchemaParityResult } from './contract';
type AiAuthority = Readonly<Record<string, ZxDescriptorAICapability>>;
interface AuthorityJoinProjection {
    readonly valid: boolean;
    readonly entries: readonly ZxSchemaAdapterEntry[];
    readonly diagnostics: readonly ZxSchemaParityDiagnostic[];
}
export declare const projectTextEditorSchemaAuthorityJoinForConformance: (aiAuthority?: AiAuthority, renderEntries?: readonly ZxRenderAuthorityEntry[]) => AuthorityJoinProjection;
export declare const getTextEditorSchemaAdapterDescriptors: () => Readonly<Record<ZxSchemaAdapterSurface, ZxSchemaAdapterDescriptor>>;
export declare const verifyTextEditorSchemaAdapterParity: (adapters?: Readonly<Record<ZxSchemaAdapterSurface, ZxSchemaAdapterDescriptor>>) => ZxSchemaParityResult;
export {};
//# sourceMappingURL=adapters.d.ts.map