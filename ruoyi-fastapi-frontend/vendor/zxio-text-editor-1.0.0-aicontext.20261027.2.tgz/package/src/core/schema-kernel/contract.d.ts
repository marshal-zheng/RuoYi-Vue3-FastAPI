import { ZxComponentDependencyRef } from '../execution-abi/contract';
export type ZxSchemaAuthorityKind = 'document-v2' | 'schema-kernel' | 'ai-capability' | 'render-registry';
export interface ZxSchemaAuthorityRef extends ZxComponentDependencyRef {
    readonly authority: ZxSchemaAuthorityKind;
    readonly owner: string;
}
export interface ZxSchemaAttributeContract {
    readonly name: string;
    readonly default: unknown;
    readonly validator: ZxComponentDependencyRef;
}
export interface ZxSchemaNodeContract {
    readonly kind: 'node';
    readonly key: string;
    readonly joinKey: string;
    readonly order: number;
    readonly content: string | null;
    readonly group: string | null;
    readonly marks: string | null;
    readonly inline: boolean;
    readonly atom: boolean;
    readonly isolating: boolean;
    readonly defining: boolean;
    readonly selectable: boolean;
    readonly draggable: boolean;
    readonly code: boolean;
    readonly whitespace: 'normal' | 'pre' | null;
    readonly linebreakReplacement: boolean;
    readonly attrs: readonly ZxSchemaAttributeContract[];
}
export interface ZxSchemaMarkContract {
    readonly kind: 'mark';
    readonly key: string;
    readonly joinKey: string;
    readonly order: number;
    readonly group: string | null;
    readonly excludes: string | null;
    readonly inclusive: boolean;
    readonly spanning: boolean;
    readonly code: boolean;
    readonly attrs: readonly ZxSchemaAttributeContract[];
}
export interface ZxSchemaKernelDescriptor {
    readonly schemaKernelId: 'zx.text-editor.schema-kernel';
    readonly schemaKernelVersion: string;
    readonly schemaKernelFingerprint: string;
    readonly topNode: 'doc';
    readonly authorities: readonly ZxSchemaAuthorityRef[];
    readonly validators: readonly ZxComponentDependencyRef[];
    readonly nodes: readonly ZxSchemaNodeContract[];
    readonly marks: readonly ZxSchemaMarkContract[];
}
export type ZxSchemaAdapterSurface = 'editor' | 'render' | 'ai';
export type ZxSchemaAdapterBehaviorKind = 'command' | 'input-rule' | 'keymap' | 'node-view' | 'paste-drop' | 'renderer' | 'ui';
export interface ZxSchemaAdapterEntry {
    readonly joinKey: string;
    readonly kernelKey: string;
    readonly kernelVersion: string;
    readonly structuralProjectionFingerprint: string;
    readonly structuralSupport: 'supported';
    readonly aiSupport: 'supported' | 'pass-through' | 'unsupported';
    readonly renderSupport: 'supported' | 'pass-through' | 'unsupported';
    readonly renderSupportByTarget: Readonly<{
        readonly html: 'supported' | 'pass-through' | 'unsupported';
        readonly react: 'supported' | 'pass-through' | 'unsupported';
        readonly text: 'supported' | 'pass-through' | 'unsupported';
    }>;
    readonly passThroughTarget: string | null;
}
export interface ZxSchemaAdapterDescriptor {
    readonly adapterId: string;
    readonly adapterVersion: string;
    readonly adapterFingerprint: string;
    readonly surface: ZxSchemaAdapterSurface;
    readonly schemaKernel: ZxComponentDependencyRef;
    readonly authorityProjection: Readonly<{
        readonly aiCapability: ZxComponentDependencyRef;
        readonly renderRegistry: ZxComponentDependencyRef;
    }>;
    readonly entries: readonly ZxSchemaAdapterEntry[];
    readonly nonStructuralBehaviors: readonly ZxSchemaAdapterBehaviorKind[];
}
export type ZxSchemaParityDiagnosticCode = 'adapter-shape-invalid' | 'adapter-descriptor-mismatch' | 'adapter-entry-missing' | 'adapter-entry-unknown' | 'adapter-entry-duplicate' | 'adapter-kernel-version-mismatch' | 'adapter-structural-projection-mismatch' | 'authority-join-contradictory' | 'authority-join-unknown' | 'runtime-schema-parity-mismatch';
export interface ZxSchemaParityDiagnostic {
    readonly code: ZxSchemaParityDiagnosticCode;
    readonly path: string;
    readonly joinKey?: string;
}
export type ZxSchemaParityResult = {
    readonly valid: true;
    readonly diagnostics: readonly [];
} | {
    readonly valid: false;
    readonly diagnostics: readonly ZxSchemaParityDiagnostic[];
};
//# sourceMappingURL=contract.d.ts.map