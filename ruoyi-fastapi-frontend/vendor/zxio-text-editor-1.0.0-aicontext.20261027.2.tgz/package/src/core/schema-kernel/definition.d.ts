import { ZxSchemaKernelDescriptor } from './contract';
export declare const ZX_TEXT_EDITOR_SCHEMA_KERNEL_DESCRIPTOR: ZxSchemaKernelDescriptor;
export declare const getTextEditorSchemaKernelDescriptor: () => ZxSchemaKernelDescriptor;
//# sourceMappingURL=definition.d.ts.map