import { ZxHTMLMarkRenderer, ZxHTMLNodeRenderer } from './extension-descriptors';
export declare const ZX_SHARED_HTML_NODE_MAPPINGS: Record<string, ZxHTMLNodeRenderer>;
export declare const ZX_SHARED_HTML_MARK_MAPPINGS: Record<string, ZxHTMLMarkRenderer>;
//# sourceMappingURL=html-render-mappings.d.ts.map