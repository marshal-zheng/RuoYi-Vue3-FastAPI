import { ZxStableIdentityAnalysis } from './contract';
export declare const ZX_STABLE_BLOCK_ID_PATTERN: RegExp;
export declare const ZX_STABLE_BLOCK_ID_ATTRIBUTE = "blockId";
export declare const isValidPureStableBlockId: (value: unknown) => value is string;
export declare const analyzeTextEditorStableIdentity: (content: unknown) => ZxStableIdentityAnalysis;
export declare const getTextEditorStableIdentityAddressableTypes: () => readonly string[];
//# sourceMappingURL=engine.d.ts.map