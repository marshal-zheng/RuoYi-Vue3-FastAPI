export type ZxStableIdentityIssueCode = 'duplicate-block-id' | 'invalid-block-id' | 'missing-block-id';
export interface ZxStableIdentityIssue {
    readonly code: ZxStableIdentityIssueCode;
    readonly path: string;
    readonly nodeType: string;
    readonly blockId: string | null;
}
export interface ZxStableBlockIndexEntry {
    readonly blockId: string;
    readonly nodeType: string;
    readonly path: string;
    readonly order: number;
    readonly utf16TextLength: number;
    readonly nodeFingerprint: string;
    readonly subtreeFingerprint: string;
}
export interface ZxStableIdentityAttrSynchronizationProposal {
    readonly blockId: string;
    readonly path: string;
    readonly nodeType: string;
    readonly documentAttrs: Readonly<{
        blockId: string;
    }>;
    readonly renderAttrs: Readonly<{
        dataBlockId: string;
        domId: string | null;
    }>;
}
export interface ZxStableIdentityAnalysis {
    readonly valid: boolean;
    readonly issues: readonly ZxStableIdentityIssue[];
    readonly index: readonly ZxStableBlockIndexEntry[];
    readonly attrSynchronization: readonly ZxStableIdentityAttrSynchronizationProposal[];
    readonly canonicalFingerprint: string;
}
//# sourceMappingURL=contract.d.ts.map