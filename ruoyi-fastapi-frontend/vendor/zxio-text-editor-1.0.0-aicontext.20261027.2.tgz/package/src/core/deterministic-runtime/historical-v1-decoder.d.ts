export declare const HISTORICAL_V1_DECODER_BINDINGS: {
    schema: {
        id: string;
        version: string;
        fingerprint: string;
    };
    verifier: string;
    prosemirror: {
        model: string;
        transform: string;
    };
    stepCodec: string;
    plugin: string;
    mapping: string;
    transaction: string;
    resource: {
        id: string;
        version: string;
        limits: {
            canonicalBytes: number;
            nodes: number;
            steps: number;
            mappingRanges: number;
        };
    };
};
export interface HistoricalV1Payload {
    readonly baseDocument: unknown;
    readonly steps: readonly unknown[];
    readonly resultDocument: unknown;
    readonly resultFingerprint: string;
}
export declare const isHistoricalV1Payload: (value: unknown) => value is HistoricalV1Payload;
export declare const executeHistoricalV1AuditDecoder: (payload: HistoricalV1Payload) => {
    payloadCanonical: string;
    evidence: {
        schemaFingerprint: string;
        transactionCount: number;
        mappingRanges: readonly number[][];
        pluginState: {
            blockIds: string[];
        };
        resultFingerprint: string;
    };
    evidenceFingerprint: string;
};
//# sourceMappingURL=historical-v1-decoder.d.ts.map