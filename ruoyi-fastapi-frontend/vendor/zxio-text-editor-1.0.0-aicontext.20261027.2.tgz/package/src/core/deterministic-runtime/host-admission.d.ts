import { RuntimeAdmissionExpectationV2, RuntimeComponentRefV2, RuntimeDispatchAdmissionReceiptV2, RuntimeHostAdmissionOutcomeV2, RuntimeHostDescriptorV2 } from './contract';
export declare const classifyTextEditorRuntimeHostExtensionV2: (extension: unknown) => {
    classification: "external-host-extension";
    executionSemantic: "unknown";
    observational: "unknown";
    derivedView: "unknown";
    supported: false;
    fingerprint: string;
};
export declare const materializeCurrentTextEditorRuntimeHostV2: () => RuntimeHostDescriptorV2;
export declare const executeCertifiedObservationalDriftMatrixV2: () => {
    authority: "annotations" | "selection" | "document" | "stored-marks" | "semantic-plugin-state" | "effects" | "lifecycle";
    beforeSemanticFingerprint: string;
    afterSemanticFingerprint: string;
    semanticUnchanged: boolean;
    observationCountBefore: number;
    observationCountAfter: number;
    observationFingerprint: string;
}[];
export declare const CERTIFIED_OBSERVATIONAL_DRIFT_V2: {
    outcomeFingerprint: string;
    fingerprint: string;
    receiptRef: string;
    componentRef: RuntimeComponentRefV2;
    implementationSourceFingerprint: string;
    sourceReachabilityClosure: {
        implementationId: string;
        directRuntimeImports: string[];
        semanticComponentDependencies: readonly string[];
        reachableAuthorities: readonly ["observations"];
        unreachableAuthorities: readonly ["document", "selection", "stored-marks", "semantic-plugin-state", "effects", "annotations", "lifecycle"];
    };
    sourceReachabilityClosureFingerprint: string;
    fixtureCorpusFingerprint: string;
    observedResults: {
        authority: "annotations" | "selection" | "document" | "stored-marks" | "semantic-plugin-state" | "effects" | "lifecycle";
        beforeSemanticFingerprint: string;
        afterSemanticFingerprint: string;
        semanticUnchanged: boolean;
        observationCountBefore: number;
        observationCountAfter: number;
        observationFingerprint: string;
    }[];
    observedOutcomeFingerprint: string;
    forbiddenTrapCalls: 0;
    verificationAlgorithm: "execute-identity-reachability-fixtures-v2";
    unreachable: string[];
};
export declare const verifyCertifiedObservationalDriftV2: () => boolean;
export declare const admitCurrentTextEditorRuntimeHostV2: (expected: RuntimeAdmissionExpectationV2) => RuntimeHostAdmissionOutcomeV2;
export declare const recheckCurrentTextEditorRuntimeHostForDispatchV2: (expected: RuntimeAdmissionExpectationV2, currentBaseFingerprint: string, targetEditor: object) => RuntimeDispatchAdmissionReceiptV2;
//# sourceMappingURL=host-admission.d.ts.map