export { readTextEditorRuntimeHostCompositionForTargetV2, readTextEditorRuntimeHostCompositionV2, } from '#runtime-host-state';
export type { RuntimeHostAssemblyIntegrityProofV2, RuntimeHostCompositionBindingProofV2, RuntimeHostCompositionSnapshotV2, RuntimeHostExternalExtensionSnapshotV2, } from '#runtime-host-state';
//# sourceMappingURL=host-composition-registry.d.ts.map