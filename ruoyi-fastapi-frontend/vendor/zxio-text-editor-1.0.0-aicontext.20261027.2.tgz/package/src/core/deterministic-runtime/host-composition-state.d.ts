export { readTextEditorRuntimeHostCompositionForTargetV2, readTextEditorRuntimeHostCompositionV2, } from '#runtime-host-core-authority';
export type { RuntimeHostAssemblyIntegrityProofV2, RuntimeHostCompositionBindingProofV2, RuntimeHostCompositionSnapshotV2, RuntimeHostExternalExtensionSnapshotV2, } from '#runtime-host-core-authority';
//# sourceMappingURL=host-composition-state.d.ts.map