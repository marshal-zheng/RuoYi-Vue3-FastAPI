import { DerivedViewOutcomeV2, RuntimeDerivedViewRequestV2 } from './contract';
export declare const deriveTextEditorRuntimeViewV2: (request: RuntimeDerivedViewRequestV2) => DerivedViewOutcomeV2;
export declare const FINE_DIFF_UNAVAILABLE_SAFETY_POLICY_V2: {
    fineDiffAvailable: boolean;
    hunkPartialAccept: boolean;
    operationPartialAccept: boolean;
    hunkPartialReject: boolean;
    operationPartialReject: boolean;
    wholeProposalAcceptWithoutIndependentWholeReview: boolean;
    allowedWithoutIndependentWholeReview: readonly ["reject", "regenerate"];
    owner: string;
};
//# sourceMappingURL=derived-view.d.ts.map