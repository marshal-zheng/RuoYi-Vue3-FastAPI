import { EditorState, Transaction } from 'prosemirror-state';
import { RuntimeFailureCodeV2, RuntimeOperationSpanV2, RuntimePluginStateProjectionV2, RuntimeTransactionTraceEntryV2 } from './contract';
import { RuntimePluginDefinitionV2 } from './runtime-plugin-definitions';
import { RuntimeBudgetLedgerV2 } from './resource-profile';
export declare class RuntimeDriverFailureV2Error extends Error {
    readonly code: RuntimeFailureCodeV2;
    readonly path: string;
    constructor(code: RuntimeFailureCodeV2, path: string);
}
export interface FixedPointDriverResultV2 {
    readonly state: EditorState;
    readonly transactions: readonly Transaction[];
    readonly entries: readonly RuntimeTransactionTraceEntryV2[];
    readonly pluginState: readonly RuntimePluginStateProjectionV2[];
}
export declare const runFixedPointDriverV2: (initialState: EditorState, root: Transaction, spans: readonly RuntimeOperationSpanV2[], executionId: string, ledger: RuntimeBudgetLedgerV2, definitions?: readonly RuntimePluginDefinitionV2[]) => FixedPointDriverResultV2;
//# sourceMappingURL=fixed-point-driver.d.ts.map