import { HistoricalAuditOutcomeV2, HistoricalRuntimeArtifactV2, RuntimeDependencyRefV2 } from './contract';
import { ZxExactPackageImplementationRef } from '../execution-abi/contract';
export declare const HISTORICAL_V1_ARTIFACT_PARSER_REF: RuntimeDependencyRefV2;
export declare const HISTORICAL_V1_RUNTIME_REF: RuntimeDependencyRefV2;
export declare const HISTORICAL_V1_IMMUTABLE_CLOSURE: {
    closureFingerprint: string;
    parser: RuntimeDependencyRefV2;
    runtime: RuntimeDependencyRefV2;
    decoderSourceFingerprint: string;
    executableBundleSourceFingerprint: string;
    bindings: {
        exactPackageRefs: ZxExactPackageImplementationRef[];
        schema: {
            id: string;
            version: string;
            fingerprint: string;
        };
        verifier: string;
        prosemirror: {
            model: string;
            transform: string;
        };
        stepCodec: string;
        plugin: string;
        mapping: string;
        transaction: string;
        resource: {
            id: string;
            version: string;
            limits: {
                canonicalBytes: number;
                nodes: number;
                steps: number;
                mappingRanges: number;
            };
        };
        parser: string;
    };
    liveCapability: boolean;
};
export declare const HISTORICAL_V2_ARTIFACT_PARSER_REF: RuntimeDependencyRefV2;
export declare const HISTORICAL_V2_RUNTIME_REF: RuntimeDependencyRefV2;
export declare const HISTORICAL_V2_IMMUTABLE_CLOSURE: {
    closureFingerprint: string;
    parser: RuntimeDependencyRefV2;
    runtime: RuntimeDependencyRefV2;
    mode: string;
    liveCapability: boolean;
};
export declare const auditHistoricalTextEditorRuntimeArtifactV2: (artifact: HistoricalRuntimeArtifactV2) => HistoricalAuditOutcomeV2;
//# sourceMappingURL=historical-audit.d.ts.map