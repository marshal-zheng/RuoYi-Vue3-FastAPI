import { ZxAIMutationPlan } from '../../ai/contract';
import { ZxTextEditorDocument, ZxTextPosition } from '../../document/types';
export type RuntimeAuthorityKindV2 = 'schema-semantics' | 'operation-protocol' | 'execution-closure' | 'mapping-policy' | 'transaction-policy' | 'resource-profile' | 'derived-view-profile';
export interface RuntimeDependencyRefV2 {
    readonly kind: RuntimeAuthorityKindV2;
    readonly id: string;
    readonly version: string;
    readonly fingerprint: string;
}
export interface RuntimeComponentRefV2 extends RuntimeDependencyRefV2 {
    readonly dependencies: readonly RuntimeDependencyRefV2[];
}
export interface RuntimeManifestFingerprintsV2 {
    readonly runtimeManifestFingerprint: string;
    readonly executionSemanticsFingerprint: string;
    readonly observationalProfileFingerprint: string;
    readonly derivedViewFingerprint: string;
}
export interface RuntimeManifestRefV2 {
    readonly kind: 'zx-text-editor-runtime-manifest-v2';
    readonly version: '2.0.0';
    readonly fingerprint: string;
}
export interface RuntimeManifestV2 {
    readonly kind: 'zx-text-editor-runtime-manifest-v2';
    readonly version: '2.0.0';
    readonly schemaSemantics: RuntimeComponentRefV2;
    readonly operationProtocol: RuntimeComponentRefV2;
    readonly executionClosure: RuntimeComponentRefV2;
    readonly mappingPolicy: RuntimeComponentRefV2;
    readonly transactionPolicy: RuntimeComponentRefV2;
    readonly resourceProfile: RuntimeComponentRefV2;
    readonly derivedViewProfiles: readonly RuntimeComponentRefV2[];
    readonly fingerprints: RuntimeManifestFingerprintsV2;
}
export interface RuntimeExecutionContextV2 {
    readonly protocol: 'zx-runtime-execution-context-v1';
    readonly intentRef?: {
        readonly id: string;
        readonly version: string;
        readonly fingerprint: string;
    };
}
export interface ExecuteTextEditorMutationPlanV2Input {
    readonly runtime: RuntimeManifestRefV2;
    readonly baseDocument: ZxTextEditorDocument;
    readonly plan: ZxAIMutationPlan;
    readonly context: RuntimeExecutionContextV2;
}
export type RuntimeResourceCounterKeyV2 = 'inputBytes' | 'inputDepth' | 'inputKeys' | 'documentNodes' | 'documentMarks' | 'documentBlocks' | 'annotations' | 'planOperations' | 'executionPlugins' | 'rootSteps' | 'steps' | 'transactions' | 'filterCalls' | 'appendCalls' | 'appendRounds' | 'mappingMaps' | 'mappingRanges' | 'mappingBytes' | 'mappingMirrors' | 'mappingMirrorBytes' | 'metaBytes' | 'traceBytes' | 'pluginStateBytes' | 'safeDiagnosticCount' | 'safeDiagnosticBytes';
export type RuntimeResourceCountersV2 = Readonly<Record<RuntimeResourceCounterKeyV2, number>>;
export type RuntimeResourceLimitsV2 = Readonly<Record<RuntimeResourceCounterKeyV2, number>>;
export type RuntimeFailureCodeV2 = 'runtime-manifest-invalid' | 'runtime-component-unsupported' | 'runtime-fingerprint-mismatch' | 'document-invalid' | 'plan-invalid' | 'operation-compile-failed' | 'mark-policy-violation' | 'transaction-time-invalid' | 'transaction-meta-invalid' | 'transaction-attribution-invalid' | 'transaction-filter-rejected' | 'plugin-conformance-missing' | 'append-fixed-point-cycle' | 'annotation-invalidated' | 'mapping-policy-violation' | 'input-bytes-budget-exceeded' | 'input-depth-budget-exceeded' | 'input-keys-budget-exceeded' | 'document-node-budget-exceeded' | 'document-mark-budget-exceeded' | 'document-block-budget-exceeded' | 'annotation-budget-exceeded' | 'plan-operation-budget-exceeded' | 'execution-plugin-budget-exceeded' | 'root-step-budget-exceeded' | 'step-budget-exceeded' | 'transaction-budget-exceeded' | 'filter-call-budget-exceeded' | 'append-call-budget-exceeded' | 'append-round-budget-exceeded' | 'mapping-map-budget-exceeded' | 'mapping-range-budget-exceeded' | 'mapping-byte-budget-exceeded' | 'mapping-mirror-budget-exceeded' | 'mapping-mirror-byte-budget-exceeded' | 'meta-byte-budget-exceeded' | 'trace-byte-budget-exceeded' | 'plugin-state-byte-budget-exceeded' | 'safe-diagnostic-count-budget-exceeded' | 'safe-diagnostic-byte-budget-exceeded' | 'runtime-internal-failure';
export interface RuntimeSafeDiagnosticV2 {
    readonly code: RuntimeFailureCodeV2 | 'safety-watchdog-abort';
    readonly stage: string;
    readonly path: string;
    readonly profileId?: string;
    readonly componentId?: string;
    readonly operationIndex?: number;
    readonly sequence?: number;
    readonly pluginInstanceId?: string;
    readonly counter?: RuntimeResourceCounterKeyV2;
    readonly current?: number;
    readonly limit?: number;
    readonly fingerprintPrefix?: string;
}
export interface RuntimeOperationSpanV2 {
    readonly operationIndex: number;
    readonly stepStart: number;
    readonly stepEnd: number;
    readonly noOpReason?: 'already-equal';
}
export interface RuntimeCanonicalStepV2 {
    readonly json: Readonly<Record<string, unknown>>;
    readonly fingerprint: string;
    readonly mapFingerprint: string;
}
export interface RuntimeSourceAttributionV2 {
    readonly owner: 'operation-compiler' | 'certified-plugin';
    readonly pluginInstanceId: string | null;
    readonly pluginOrder: number | null;
    readonly visibleTransactionRange: readonly [number, number];
    readonly operationIndexes: readonly number[];
}
export interface RuntimePluginStateProjectionV2 {
    readonly pluginInstanceId: string;
    readonly projectorRef: RuntimeDependencyRefV2;
    readonly beforeFingerprint: string;
    readonly afterFingerprint: string;
    readonly value: unknown;
}
export interface RuntimeSafeEffectRecordV2 {
    readonly effectRef: RuntimeDependencyRefV2;
    readonly kind: 'observational';
    readonly fingerprint: string;
}
export interface RuntimeTransactionTraceEntryV2 {
    readonly kind: 'root' | 'appended';
    readonly sequence: number;
    readonly logicalTime: number;
    readonly rootExecutionId: string;
    readonly sourceAttribution: RuntimeSourceAttributionV2;
    readonly operationSpans: readonly RuntimeOperationSpanV2[];
    readonly steps: readonly RuntimeCanonicalStepV2[];
    readonly allowedMeta: Readonly<Record<string, unknown>>;
    readonly beforeDocumentFingerprint: string;
    readonly afterDocumentFingerprint: string;
    readonly selectionAndStoredMarksProof: {
        readonly selectionSet: false;
        readonly storedMarksSet: false;
    };
    readonly pluginState: readonly RuntimePluginStateProjectionV2[];
    readonly safeEffects: readonly RuntimeSafeEffectRecordV2[];
    readonly resourceDelta: RuntimeResourceCountersV2;
    readonly fingerprint: string;
}
export interface RuntimeMappedBoundaryEvidenceV2 {
    readonly original: ZxTextPosition;
    readonly mapped: ZxTextPosition;
    readonly assoc: 1 | -1;
    readonly deleted: boolean;
    readonly deletedBefore: boolean;
    readonly deletedAfter: boolean;
    readonly deletedAcross: boolean;
    readonly fingerprint: string;
}
export interface RuntimeAnnotationMappingV2 {
    readonly annotationId: string;
    readonly status: 'mapped';
    readonly start: RuntimeMappedBoundaryEvidenceV2;
    readonly end: RuntimeMappedBoundaryEvidenceV2;
    readonly quote: string;
    readonly beforeQuote: string;
    readonly afterQuote: string;
    readonly fingerprint: string;
}
export interface RuntimeMappingProjectionV2 {
    readonly policyRef: RuntimeComponentRefV2;
    readonly mapOrder: readonly string[];
    readonly mapRangeCounts: readonly number[];
    readonly mirrorPairs: readonly (readonly [number, number])[];
    readonly annotations: readonly RuntimeAnnotationMappingV2[];
    readonly fingerprint: string;
}
export interface RuntimeExecutionTraceV2 {
    readonly version: 'runtime-execution-trace-v2';
    readonly executionId: string;
    readonly manifest: RuntimeManifestFingerprintsV2;
    readonly entries: readonly RuntimeTransactionTraceEntryV2[];
    readonly mapping: RuntimeMappingProjectionV2;
    readonly resources: RuntimeResourceCountersV2;
    readonly resultFingerprint: string;
    readonly fingerprint: string;
}
export interface ResolvedRuntimeReceiptV2 {
    readonly manifestRef: RuntimeManifestRefV2;
    readonly executionSemanticsFingerprint: string;
    readonly observationalProfileFingerprint: string;
    readonly derivedViewFingerprint: string;
    readonly adapterRef: RuntimeComponentRefV2;
    readonly conformanceReceiptRefs: readonly string[];
    readonly conformanceEnvironmentReceiptRefs: readonly {
        readonly environment: string;
        readonly adapterExecutionIdentity: string;
        readonly matrixRowFingerprint: string;
    }[];
}
export type RuntimeExecutionOutcomeV2 = {
    readonly status: 'success';
    readonly runtime: ResolvedRuntimeReceiptV2;
    readonly resultDocument: ZxTextEditorDocument;
    readonly resultFingerprint: string;
    readonly trace: RuntimeExecutionTraceV2;
    readonly mapping: RuntimeMappingProjectionV2;
    readonly pluginState: readonly RuntimePluginStateProjectionV2[];
    readonly resources: RuntimeResourceCountersV2;
    readonly replayEligibility: 'exact-runtime-only';
} | {
    readonly status: 'failure';
    readonly code: RuntimeFailureCodeV2;
    readonly diagnostic: RuntimeSafeDiagnosticV2;
    readonly resultDocument: null;
    readonly trace: null;
    readonly replayEligibility: 'none';
} | {
    readonly status: 'safety-abort';
    readonly code: 'safety-watchdog-abort';
    readonly diagnostic: RuntimeSafeDiagnosticV2;
    readonly resultDocument: null;
    readonly trace: null;
    readonly replayEligibility: 'none';
};
export interface RuntimeOrderedComponentProofV2 {
    readonly order: number;
    readonly component: RuntimeDependencyRefV2;
}
export interface RuntimeHostDescriptorV2 {
    readonly manifestRef: RuntimeManifestRefV2;
    readonly executionSemanticsFingerprint: string;
    readonly observationalProfileFingerprint: string;
    readonly derivedViewFingerprint: string;
    readonly hostComposition: {
        readonly bindingState: 'unbound' | 'active-editor-bound';
        readonly activeEditorCount: number;
        readonly bindingProofFingerprints: readonly string[];
        readonly bindings: readonly {
            readonly bindingFingerprint: string;
            readonly assemblyComponentId: string;
            readonly assemblySourceFingerprint: string;
            readonly authoritySourceFingerprint: string;
            readonly registrySourceFingerprint: string;
            readonly stateSourceFingerprint: string;
            readonly externalExtensionsFingerprint: string;
        }[];
        readonly fingerprint: string;
    };
    readonly proofs: {
        readonly execution: readonly RuntimeOrderedComponentProofV2[];
        readonly observational: readonly RuntimeOrderedComponentProofV2[];
        readonly derivedView: readonly RuntimeOrderedComponentProofV2[];
    };
    readonly descriptorFingerprint: string;
}
export interface RuntimeAdmissionExpectationV2 {
    readonly manifestRef: RuntimeManifestRefV2;
    readonly executionSemanticsFingerprint: string;
    readonly observationalProfileFingerprint: string;
    readonly derivedViewFingerprint: string;
    readonly baseFingerprint: string;
}
export type RuntimeDerivedViewAdmissionEvidenceV2 = {
    readonly status: 'exact';
} | {
    readonly status: 'regenerate-view';
    readonly profileFingerprint: string;
} | {
    readonly status: 'unavailable';
    readonly reason: string;
};
export type RuntimeHostAdmissionOutcomeV2 = {
    readonly status: 'exact-admissible';
    readonly current: RuntimeHostDescriptorV2;
    readonly checkedBaseFingerprint: string;
    readonly derivedView: RuntimeDerivedViewAdmissionEvidenceV2;
} | {
    readonly status: 'admissible-observational-drift';
    readonly current: RuntimeHostDescriptorV2;
    readonly checkedBaseFingerprint: string;
    readonly driftProofRefs: readonly string[];
    readonly derivedView: RuntimeDerivedViewAdmissionEvidenceV2;
} | {
    readonly status: 'regenerate-current-runtime';
    readonly current: RuntimeHostDescriptorV2;
    readonly orderedDriftPaths: readonly string[];
} | {
    readonly status: 'unsupported-host';
    readonly current: RuntimeHostDescriptorV2 | null;
    readonly reasons: readonly RuntimeSafeDiagnosticV2[];
};
export interface RuntimeDispatchAdmissionReceiptV2 {
    readonly status: 'admissible' | 'not-admissible';
    readonly baseFingerprint: string;
    readonly descriptorFingerprint: string | null;
    readonly targetBindingFingerprint: string | null;
    readonly targetCompositionFingerprint: string;
    readonly admission: RuntimeHostAdmissionOutcomeV2;
    readonly fingerprint: string;
}
export interface DerivedViewSourceBindingV2 {
    readonly executionSemanticsFingerprint: string;
    readonly resultFingerprint: string;
    readonly traceFingerprint: string;
}
export type DerivedViewUnavailableReasonV2 = 'profile-not-installed' | 'unsupported-runtime' | 'resource-limit-exceeded' | 'derivation-failed';
export type DerivedViewOutcomeV2<TValue = unknown> = {
    readonly status: 'available';
    readonly profileRef: RuntimeComponentRefV2;
    readonly sourceBinding: DerivedViewSourceBindingV2;
    readonly value: TValue;
    readonly fingerprint: string;
} | {
    readonly status: 'unavailable';
    readonly profileRef: RuntimeComponentRefV2;
    readonly sourceBinding: DerivedViewSourceBindingV2;
    readonly reason: DerivedViewUnavailableReasonV2;
    readonly safeDiagnostic: RuntimeSafeDiagnosticV2;
};
export interface RuntimeDerivedViewRequestV2 {
    readonly profileRef: RuntimeDependencyRefV2;
    readonly execution: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }>;
}
export interface HistoricalRuntimeArtifactV2 {
    readonly artifactKind: 'zx-text-editor-runtime-artifact-v2' | 'zx-text-editor-execution-artifact-v1';
    readonly parserRef: RuntimeDependencyRefV2;
    readonly runtimeRef: RuntimeDependencyRefV2;
    readonly closureFingerprint: string;
    readonly payload: unknown;
}
export type HistoricalAuditOutcomeV2 = {
    readonly status: 'verified';
    readonly artifactKind: HistoricalRuntimeArtifactV2['artifactKind'];
    readonly auditFingerprint: string;
    readonly liveCapability: false;
} | {
    readonly status: 'historical-runtime-unsupported' | 'invalid-artifact';
    readonly diagnostic: RuntimeSafeDiagnosticV2;
    readonly liveCapability: false;
};
//# sourceMappingURL=contract.d.ts.map