import { RuntimeExecutionTraceV2, RuntimeManifestFingerprintsV2, RuntimeMappingProjectionV2, RuntimeTransactionTraceEntryV2 } from './contract';
import { RuntimeBudgetLedgerV2 } from './resource-profile';
export declare const publishRuntimeExecutionTraceV2: (input: {
    readonly executionId: string;
    readonly manifest: RuntimeManifestFingerprintsV2;
    readonly entries: readonly RuntimeTransactionTraceEntryV2[];
    readonly mapping: RuntimeMappingProjectionV2;
    readonly resultFingerprint: string;
}, ledger: RuntimeBudgetLedgerV2) => RuntimeExecutionTraceV2;
//# sourceMappingURL=execution-trace.d.ts.map