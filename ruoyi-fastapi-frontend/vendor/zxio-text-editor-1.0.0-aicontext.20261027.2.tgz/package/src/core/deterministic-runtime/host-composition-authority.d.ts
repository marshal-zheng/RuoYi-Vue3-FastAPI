export interface RuntimeHostExternalExtensionSnapshotV2 {
    readonly order: number;
    readonly runtimeType: 'function' | 'object' | 'other' | 'collaboration-transport';
}
export interface RuntimeHostAssemblyIntegrityProofV2 {
    readonly assemblyComponentId: 'zx.text-editor.editor-runtime-assembly';
    readonly assemblySourceFingerprint: string;
    readonly authoritySourceFingerprint: string;
    readonly registrySourceFingerprint: string;
    readonly stateSourceFingerprint: string;
}
export interface RuntimeHostCompositionBindingProofV2 {
    readonly bindingFingerprint: string;
    readonly assemblyIntegrity: RuntimeHostAssemblyIntegrityProofV2;
    readonly externalExtensionsFingerprint: string;
}
export interface RuntimeHostCompositionSnapshotV2 {
    readonly protocol: 'zx-text-editor-runtime-host-composition-v2';
    readonly bindingState: 'unbound' | 'active-editor-bound';
    readonly activeEditorCount: number;
    readonly bindings: readonly RuntimeHostCompositionBindingProofV2[];
    readonly externalExtensions: readonly RuntimeHostExternalExtensionSnapshotV2[];
    readonly fingerprint: string;
}
export declare const certifyRuntimeHostCollaborationTransportExtensionV2: (extension: object) => void;
/** @internal Package UI authority calls this after exact local construction. */
export declare const bindPackageTextEditorRuntimeHostEditorV2: (input: {
    readonly targetEditor: object;
    readonly externalExtensions: readonly unknown[];
}) => string | null;
export declare const readTextEditorRuntimeHostCompositionV2: () => RuntimeHostCompositionSnapshotV2;
export declare const readTextEditorRuntimeHostCompositionForTargetV2: (targetEditor: object) => RuntimeHostCompositionSnapshotV2;
//# sourceMappingURL=host-composition-authority.d.ts.map