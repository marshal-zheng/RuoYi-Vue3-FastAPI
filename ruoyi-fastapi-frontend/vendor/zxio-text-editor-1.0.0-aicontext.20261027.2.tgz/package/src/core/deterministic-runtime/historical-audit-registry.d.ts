import { HistoricalAuditOutcomeV2, HistoricalRuntimeArtifactV2 } from './contract';
export declare const auditHistoricalTextEditorRuntimeArtifactV2: (artifact: HistoricalRuntimeArtifactV2) => HistoricalAuditOutcomeV2;
//# sourceMappingURL=historical-audit-registry.d.ts.map