import { ZxAIComplexNodeBoundedRunnerV1, ZxAIComplexNodeComponentRefV1 } from '../../ai/complex-node/contract';
export interface RuntimeComplexNodeIsolateV2 {
    execute(input: {
        readonly canonicalInput: Uint8Array;
        readonly resourceProfileFingerprint: string;
        readonly maxOutputBytes: number;
    }): Promise<Uint8Array>;
    terminate(): void;
}
export interface RuntimeComplexNodeIsolateFactoryV2 {
    open(component: ZxAIComplexNodeComponentRefV1): RuntimeComplexNodeIsolateV2 | null;
}
/**
 * Runtime-owned watchdog around host-provided hard-terminable component realms.
 * A missing realm is a closed failure; execution never falls back in-process.
 */
export declare const createRuntimeComplexNodeBoundedRunnerV2: (factory: RuntimeComplexNodeIsolateFactoryV2) => ZxAIComplexNodeBoundedRunnerV1;
//# sourceMappingURL=complex-node-runner-v2.d.ts.map