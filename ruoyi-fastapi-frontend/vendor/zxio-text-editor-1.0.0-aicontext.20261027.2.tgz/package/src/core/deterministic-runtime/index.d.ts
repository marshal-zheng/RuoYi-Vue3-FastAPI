import { ExecuteTextEditorMutationPlanV2Input, RuntimeExecutionOutcomeV2 } from './contract';
export { getCurrentTextEditorRuntimeManifestV2, CURRENT_TEXT_EDITOR_RUNTIME_MANIFEST_REF_V2, RUNTIME_OPERATION_KINDS_V2, } from './manifest';
export { admitCurrentTextEditorRuntimeHostV2, recheckCurrentTextEditorRuntimeHostForDispatchV2, } from './host-admission';
export { deriveTextEditorRuntimeViewV2 } from './derived-view';
export { auditHistoricalTextEditorRuntimeArtifactV2 } from './historical-audit-registry';
export { commitTextEditorMutationPlanToTargetV2 } from './target-commit';
export declare const executeTextEditorMutationPlanV2: (input: ExecuteTextEditorMutationPlanV2Input) => RuntimeExecutionOutcomeV2;
export declare const createTextEditorRuntimeSafetyAbortV2: (watchdogClass: string) => RuntimeExecutionOutcomeV2;
export { createRuntimeComplexNodeBoundedRunnerV2 } from './complex-node-runner-v2';
export type { RuntimeComplexNodeIsolateFactoryV2, RuntimeComplexNodeIsolateV2, } from './complex-node-runner-v2';
export type { DerivedViewOutcomeV2, DerivedViewSourceBindingV2, DerivedViewUnavailableReasonV2, ExecuteTextEditorMutationPlanV2Input, HistoricalAuditOutcomeV2, HistoricalRuntimeArtifactV2, ResolvedRuntimeReceiptV2, RuntimeAdmissionExpectationV2, RuntimeComponentRefV2, RuntimeDependencyRefV2, RuntimeDerivedViewRequestV2, RuntimeDispatchAdmissionReceiptV2, RuntimeExecutionContextV2, RuntimeExecutionOutcomeV2, RuntimeExecutionTraceV2, RuntimeFailureCodeV2, RuntimeHostAdmissionOutcomeV2, RuntimeHostDescriptorV2, RuntimeManifestFingerprintsV2, RuntimeManifestRefV2, RuntimeManifestV2, RuntimeMappingProjectionV2, RuntimePluginStateProjectionV2, RuntimeResourceCountersV2, RuntimeSafeDiagnosticV2, } from './contract';
export type { CommitTextEditorMutationPlanToTargetV2Input, RuntimeHistorySnapshotV2, RuntimeTargetCommitDiagnosticV2, RuntimeTargetCommitOutcomeV2, RuntimeTargetCommitProofV2, RuntimeTargetDocumentBindingV2, } from './target-commit';
//# sourceMappingURL=index.d.ts.map