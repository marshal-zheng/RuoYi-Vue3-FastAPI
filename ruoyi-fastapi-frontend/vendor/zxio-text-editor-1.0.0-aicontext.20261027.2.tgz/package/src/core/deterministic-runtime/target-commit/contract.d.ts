import { ZxAIMutationPlan } from '../../../ai/contract';
import { ZxTextEditorDocument } from '../../../document/types';
import { RuntimeAdmissionExpectationV2, RuntimeDispatchAdmissionReceiptV2, RuntimeExecutionContextV2, RuntimeExecutionOutcomeV2, RuntimeManifestRefV2, RuntimeMappingProjectionV2, RuntimePluginStateProjectionV2 } from '../contract';
export interface RuntimeHistorySnapshotV2 {
    readonly undoDepth: number;
    readonly redoDepth: number;
    readonly fingerprint: string;
}
export interface RuntimeTargetDocumentBindingV2 {
    readonly targetEditor: WeakRef<object>;
    readonly bindingFingerprint: string;
    readonly authorityFingerprint: string;
    readonly hostBindingFingerprint: string;
    readonly readCanonicalDocument: () => ZxTextEditorDocument;
    readonly readHistoryState: () => RuntimeHistorySnapshotV2;
}
export interface RuntimeTargetCommitDiagnosticV2 {
    readonly code: 'target-binding-invalid' | 'target-document-invalid' | 'target-guard-rejected' | 'target-not-admissible' | 'target-runtime-failure' | 'target-fresh-mismatch' | 'target-materialization-invalid' | 'target-dispatch-failure' | 'target-post-dispatch-incident';
    readonly stage: 'binding' | 'guard' | 'admission' | 'execute' | 'materialize' | 'dispatch' | 'post-dispatch';
    readonly path: string;
    readonly fingerprintPrefix?: string;
}
export interface RuntimeTargetCommitProofV2 {
    readonly beforeDocumentFingerprint: string;
    readonly afterDocumentFingerprint: string;
    readonly annotationFingerprint: string;
    readonly assetsFingerprint: string;
    readonly metaFingerprint: string;
    readonly targetBindingFingerprint: string;
    readonly targetCompositionFingerprint: string;
    readonly freshOutcomeFingerprint: string;
    readonly materializedRootFingerprint: string;
    readonly livePluginProjectionFingerprint: string;
    readonly liveAppendedClosureFingerprint: string;
    readonly targetStateFingerprint: string;
    readonly historyBeforeFingerprint: string;
    readonly historyAfterFingerprint: string;
    readonly undoDepthDelta: 1;
    readonly fingerprint: string;
}
export interface CommitTextEditorMutationPlanToTargetV2Input {
    readonly runtime: RuntimeManifestRefV2;
    readonly plan: ZxAIMutationPlan;
    readonly context: RuntimeExecutionContextV2;
    readonly targetEditor: object;
    readonly runtimeExpectation: RuntimeAdmissionExpectationV2;
    readonly expectedResultFingerprint: string;
    readonly expectedTraceFingerprint: string;
    readonly expectedMappingFingerprint: string;
    readonly expectedResourcesFingerprint: string;
    readonly expectedPluginStateFingerprint: string;
    readonly expectedRuntimeReceiptFingerprint: string;
    readonly expectedReplayEligibility: 'exact-runtime-only';
    readonly expectedAnnotationFingerprint: string;
}
export type RuntimeTargetCommitOutcomeV2 = {
    readonly status: 'committed';
    readonly freshOutcome: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }>;
    readonly dispatchAdmission: RuntimeDispatchAdmissionReceiptV2;
    readonly mapping: RuntimeMappingProjectionV2;
    readonly pluginState: readonly RuntimePluginStateProjectionV2[];
    readonly proof: RuntimeTargetCommitProofV2;
} | {
    readonly status: 'accepted-no-change';
    readonly freshOutcome: Extract<RuntimeExecutionOutcomeV2, {
        status: 'success';
    }>;
    readonly dispatchAdmission: RuntimeDispatchAdmissionReceiptV2;
    readonly proof: null;
} | {
    readonly status: 'not-admissible' | 'runtime-failure' | 'safety-abort' | 'fresh-mismatch' | 'dispatch-failure' | 'post-dispatch-safety-incident';
    readonly freshOutcome: RuntimeExecutionOutcomeV2 | null;
    readonly dispatchAdmission: RuntimeDispatchAdmissionReceiptV2 | null;
    readonly proof: RuntimeTargetCommitProofV2 | null;
    readonly diagnostic: RuntimeTargetCommitDiagnosticV2;
};
//# sourceMappingURL=contract.d.ts.map