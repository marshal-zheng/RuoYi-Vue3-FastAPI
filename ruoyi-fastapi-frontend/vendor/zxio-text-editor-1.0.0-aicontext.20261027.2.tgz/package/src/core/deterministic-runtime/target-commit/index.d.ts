import { CommitTextEditorMutationPlanToTargetV2Input, RuntimeTargetCommitOutcomeV2 } from './contract';
export declare const commitTextEditorMutationPlanToTargetV2: (input: CommitTextEditorMutationPlanToTargetV2Input) => RuntimeTargetCommitOutcomeV2;
export type { CommitTextEditorMutationPlanToTargetV2Input, RuntimeHistorySnapshotV2, RuntimeTargetCommitDiagnosticV2, RuntimeTargetCommitOutcomeV2, RuntimeTargetCommitProofV2, RuntimeTargetDocumentBindingV2, } from './contract';
//# sourceMappingURL=index.d.ts.map