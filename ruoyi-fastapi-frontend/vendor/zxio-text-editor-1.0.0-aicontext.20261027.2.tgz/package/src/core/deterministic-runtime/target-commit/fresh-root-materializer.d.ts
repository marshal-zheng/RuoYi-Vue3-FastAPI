import { Transaction } from 'prosemirror-state';
import { RuntimeExecutionOutcomeV2 } from '../contract';
export interface FreshRootMaterializationV2 {
    readonly transaction: Transaction;
    readonly fingerprint: string;
}
export declare const materializeFreshRuntimeRootTransactionV2: (targetEditor: object, fresh: Extract<RuntimeExecutionOutcomeV2, {
    status: "success";
}>) => FreshRootMaterializationV2;
//# sourceMappingURL=fresh-root-materializer.d.ts.map