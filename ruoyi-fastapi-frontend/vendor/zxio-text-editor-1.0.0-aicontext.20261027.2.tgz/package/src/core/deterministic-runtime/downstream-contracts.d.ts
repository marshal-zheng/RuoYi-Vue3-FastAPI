export declare const RUNTIME_DOWNSTREAM_JOINT_CONTRACTS_V2: {
    S3: {
        accepts: string[];
        owns: string[];
        forbidden: string[];
    };
    S4: {
        accepts: string[];
        owns: string[];
        fineDiffUnavailableWithoutWholeReview: string[];
    };
    S7: {
        accepts: string[];
        reexecution: string;
        forbidden: string[];
    };
};
export declare const RUNTIME_DOWNSTREAM_APPLICABILITY_MATRIX_V2: ({
    spec: string;
    relationship: string;
    s2bOwns: string[];
    downstreamOwns: string[];
    legalConsumption?: undefined;
    forbidden?: undefined;
} | {
    spec: string;
    relationship: string;
    legalConsumption: string[];
    s2bOwns: string[];
    downstreamOwns: string[];
    forbidden: string[];
})[];
//# sourceMappingURL=downstream-contracts.d.ts.map