import { ZxDescriptorAICapability } from '../ai/contract';
export declare const ZX_TEXT_EDITOR_AI_CAPABILITIES: {
    builtinNodes: ZxDescriptorAICapability;
    builtinMarks: ZxDescriptorAICapability;
    attachment: ZxDescriptorAICapability;
    comment: ZxDescriptorAICapability;
    embed: ZxDescriptorAICapability;
    iframe: ZxDescriptorAICapability;
    image: ZxDescriptorAICapability;
    imageGroup: ZxDescriptorAICapability;
    mention: ZxDescriptorAICapability;
    namedColor: ZxDescriptorAICapability;
    namedHighlight: ZxDescriptorAICapability;
    tag: ZxDescriptorAICapability;
    toggle: ZxDescriptorAICapability;
    video: ZxDescriptorAICapability;
};
export interface ZxExtensionDescriptorContract {
    name: string;
    attrs?: readonly string[];
    nodes?: readonly string[];
    marks?: readonly string[];
    ai: ZxDescriptorAICapability;
}
export declare const ZX_TEXT_EDITOR_EXTENSION_DESCRIPTORS: ZxExtensionDescriptorContract[];
export declare const bindTextEditorExtensionDescriptorPlatform: (name: string, binding: Readonly<Record<string, unknown>>) => void;
//# sourceMappingURL=ai-extension-capabilities.d.ts.map