import { renderToHTMLString as renderToHTMLStringFn } from '@tiptap/static-renderer/pm/html-string';
import { ZxTextEditorFilePlatformRuntime } from '../file-platform';
import { ZxTextEditorDocument } from '../document';
import { ZxTextEditorFilePlatform } from '../file-platform/types';
import { MentionOptions, TagSuggestionItem, TextEditorSuggestionsOptions } from '../types';
import { ZxRenderProfileName } from '../render/contract';
import { ZxDescriptorAICapability } from '../ai/contract';
import { AnyExtension, JSONContent } from '@tiptap/core';
import { TextEditorThemeOwnerPort } from './theme-owner-port';
export type ZxRenderPath = readonly (number | string)[];
export type ZxHTMLChildren = string | string[];
type ZxHTMLStringRenderOptions = NonNullable<Parameters<typeof renderToHTMLStringFn>[0]['options']>;
type ZxHTMLStringNodeMapping = NonNullable<ZxHTMLStringRenderOptions['nodeMapping']>;
type ZxHTMLStringMarkMapping = NonNullable<ZxHTMLStringRenderOptions['markMapping']>;
export type ZxHTMLRenderStrategy = 'extension-render-html';
export type ZxTextRenderStrategy = 'children' | 'attribute' | 'literal' | 'preserve-text' | 'omit';
export type ZxEditorOnlyCapability = 'node-view' | 'suggestion' | 'upload' | 'annotation-activation';
export type ZxRenderProfileDegradeMode = 'none' | 'semantic';
export type ZxRenderUnsupportedHandling = 'fail' | 'semantic-degrade';
export type ZxReactRenderStrategy = 'dom-equivalent' | 'component';
export interface ZxTextChildrenRenderOptions {
    compactBlocks?: boolean;
}
export interface ZxNodeRenderContext {
    node: JSONContent;
    path: ZxRenderPath;
    includeHeadingBreaks: boolean;
    renderNode: (node: JSONContent, path: ZxRenderPath) => string;
    renderChildren: (nodes: JSONContent[] | undefined, path: ZxRenderPath, options?: ZxTextChildrenRenderOptions) => string;
    resolveAttribute: (name: string) => string | null;
    pushSemanticDegrade: (name: string, path?: ZxRenderPath) => void;
}
export interface ZxMarkRenderContext {
    path: ZxRenderPath;
}
export type ZxHTMLNodeRenderer = ZxHTMLStringNodeMapping[string];
export type ZxHTMLMarkRenderer = ZxHTMLStringMarkMapping[string];
export type ZxHTMLNodeRenderContext = Parameters<ZxHTMLNodeRenderer>[0];
export type ZxHTMLMarkRenderContext = Parameters<ZxHTMLMarkRenderer>[0];
export type ZxNodeTextSerializer = (context: ZxNodeRenderContext) => string;
export type ZxNodeExcerptSerializer = (context: ZxNodeRenderContext) => string;
export interface ZxReactRenderHelpers<TNode = unknown> {
    createElement: (type: unknown, props?: Record<string, unknown>, ...children: TNode[]) => TNode;
    createFragment: (key: string, ...children: TNode[]) => TNode;
    getBlockClass: (block: string) => string;
    resolveAlign: (value: unknown) => string | null;
    resolveBlockProps: (attrs: Record<string, unknown>) => Record<string, unknown>;
    resolveHeadingIdProps: (attrs: Record<string, unknown>) => Record<string, unknown>;
    resolveHighlightStyle: (value: unknown) => string | undefined;
    resolveTextStyleProps: (attrs: Record<string, unknown>) => Record<string, unknown>;
    sanitizeHref: (href: unknown) => string | undefined;
    sanitizeMediaSource: (tag: 'iframe' | 'img' | 'video', src: unknown) => string | undefined;
    toBooleanValue: (value: unknown) => boolean;
    toIntegerValue: (value: unknown) => number | null;
    toPathString: (path: ZxRenderPath) => string;
    toStringValue: (value: unknown) => string | null;
}
export interface ZxReactNodeRenderContext<TNode = unknown> {
    node: JSONContent;
    attrs: Record<string, unknown>;
    path: ZxRenderPath;
    children: TNode[];
    helpers: ZxReactRenderHelpers<TNode>;
    applyMarks: (node: JSONContent, child: TNode, path: ZxRenderPath) => TNode;
}
export interface ZxReactMarkRenderContext<TNode = unknown> {
    mark: NonNullable<JSONContent['marks']>[number];
    attrs: Record<string, unknown>;
    child: TNode;
    path: ZxRenderPath;
    helpers: ZxReactRenderHelpers<TNode>;
}
export type ZxReactNodeRenderer<TNode = unknown> = (context: ZxReactNodeRenderContext<TNode>) => TNode;
export type ZxReactMarkRenderer<TNode = unknown> = (context: ZxReactMarkRenderContext<TNode>) => TNode;
export type ZxExtensionBuildMode = 'render' | 'editor';
export interface ZxExtensionBuildContext {
    mode: ZxExtensionBuildMode;
    themeOwner?: TextEditorThemeOwnerPort | null;
    mentions?: MentionOptions;
    tags?: TagSuggestionItem[];
    suggestions?: TextEditorSuggestionsOptions;
    filePlatform?: ZxTextEditorFilePlatform | null;
    filePlatformRuntime?: ZxTextEditorFilePlatformRuntime | null;
    getCurrentDocument?: (() => ZxTextEditorDocument) | null;
}
export type ZxExtensionFactory = (context: ZxExtensionBuildContext) => AnyExtension | AnyExtension[];
export interface ZxNodeRenderContract {
    htmlStrategy: ZxHTMLRenderStrategy;
    textStrategy: ZxTextRenderStrategy;
    textAttrs?: readonly string[];
    textPrefix?: string;
    textSuffix?: string;
    textFallback?: string;
    excerptStrategy?: Exclude<ZxTextRenderStrategy, 'preserve-text'>;
}
export interface ZxMarkRenderContract {
    htmlStrategy: ZxHTMLRenderStrategy;
    textStrategy: Extract<ZxTextRenderStrategy, 'preserve-text' | 'omit'>;
}
export type ZxHTMLRenderTargetCapability = {
    supported: true;
    strategy: ZxHTMLRenderStrategy;
} | {
    supported: false;
    strategy?: ZxHTMLRenderStrategy;
};
export type ZxReactRenderTargetCapability = {
    supported: true;
    strategy: ZxReactRenderStrategy;
    componentKey?: string;
    rendersChildren?: boolean;
} | {
    supported: false;
    strategy?: ZxReactRenderStrategy;
    componentKey?: string;
    rendersChildren?: boolean;
};
export interface ZxTextRenderTargetCapability {
    supported: boolean;
}
export interface ZxDescriptorRenderTargetCapabilities {
    html?: ZxHTMLRenderTargetCapability;
    react?: ZxReactRenderTargetCapability;
    text?: ZxTextRenderTargetCapability;
}
export interface ZxRenderProfileCapability {
    supported: boolean;
    degrade?: ZxRenderProfileDegradeMode;
}
export interface ZxRenderUnsupportedDescriptorPolicy {
    node?: ZxRenderUnsupportedHandling;
    mark?: ZxRenderUnsupportedHandling;
    profiles?: Partial<Record<ZxRenderProfileName, ZxRenderUnsupportedHandling>>;
}
export interface ZxExtensionDescriptor {
    name: string;
    ai: ZxDescriptorAICapability;
    allowExternalOverride?: boolean;
    extensionNames?: readonly string[];
    attrs?: readonly string[];
    nodes?: readonly string[];
    marks?: readonly string[];
    core?: ZxExtensionFactory;
    editorOnly?: ZxExtensionFactory;
    editorOnlyCapabilities?: readonly ZxEditorOnlyCapability[];
    render?: {
        targets?: Partial<ZxDescriptorRenderTargetCapabilities>;
        profiles?: Partial<Record<ZxRenderProfileName, ZxRenderProfileCapability>>;
        unsupported?: ZxRenderUnsupportedDescriptorPolicy;
        nodes?: Record<string, ZxNodeRenderContract>;
        marks?: Record<string, ZxMarkRenderContract>;
        htmlNodeMapping?: Record<string, ZxHTMLNodeRenderer>;
        htmlMarkMapping?: Record<string, ZxHTMLMarkRenderer>;
        reactNodeMapping?: Record<string, ZxReactNodeRenderer>;
        reactMarkMapping?: Record<string, ZxReactMarkRenderer>;
        textSerializers?: Record<string, ZxNodeTextSerializer>;
        excerptSerializers?: Record<string, ZxNodeExcerptSerializer>;
    };
}
export declare const defineExtensionDescriptor: <T extends ZxExtensionDescriptor>(descriptor: T) => T;
export declare const toAnyExtensionArray: (value?: AnyExtension | AnyExtension[]) => AnyExtension[];
export declare const resolveDescriptorExtensionNames: (descriptor: ZxExtensionDescriptor) => string[];
export declare const materializeDescriptorUnsupportedPolicy: (unsupported?: ZxRenderUnsupportedDescriptorPolicy) => ZxRenderUnsupportedDescriptorPolicy;
export declare const ZX_TEXT_EDITOR_EXTENSION_DESCRIPTORS: readonly ZxExtensionDescriptor[];
export declare const createDescriptorExtensions: (context: ZxExtensionBuildContext, descriptors?: readonly ZxExtensionDescriptor[]) => AnyExtension[];
export {};
//# sourceMappingURL=extension-descriptors.d.ts.map