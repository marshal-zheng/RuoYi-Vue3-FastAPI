export declare class ZxCanonicalJSONError extends TypeError {
    readonly path: string;
    constructor(path: string, message: string);
}
export interface ZxCanonicalJSONResourceLimits {
    readonly maxBytes: number;
    readonly maxDepth: number;
    readonly maxArrayEntries: number;
    readonly maxObjectKeys: number;
    readonly maxTotalObjectKeys: number;
}
export interface ZxCanonicalJSONResourceUsage {
    readonly bytes: number;
    readonly depth: number;
    readonly arrayEntries: number;
    readonly maxKeysPerObject: number;
    readonly objectKeys: number;
}
export declare class ZxCanonicalJSONResourceError extends ZxCanonicalJSONError {
    readonly usage: Omit<ZxCanonicalJSONResourceUsage, 'bytes'> & {
        readonly bytes: number | null;
    };
    constructor(path: string, message: string, usage: Omit<ZxCanonicalJSONResourceUsage, 'bytes'> & {
        readonly bytes: number | null;
    });
}
export declare const canonicalJSONStringify: (value: unknown) => string;
export declare const canonicalJSONStringifyBounded: (value: unknown, limits: ZxCanonicalJSONResourceLimits) => {
    readonly canonical: string;
    readonly usage: ZxCanonicalJSONResourceUsage;
};
export declare const canonicalJSONBytes: (value: unknown) => Uint8Array;
export declare const deepFreeze: <TValue>(value: TValue) => TValue;
//# sourceMappingURL=canonical-json.d.ts.map