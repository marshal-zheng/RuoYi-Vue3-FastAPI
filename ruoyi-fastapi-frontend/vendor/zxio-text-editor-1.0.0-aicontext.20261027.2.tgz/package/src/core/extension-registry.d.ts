import { JSONContent } from '@tiptap/core';
import { ZxRenderProfileName, ZxRenderStrictness, ZxRenderTargetName } from '../render/contract';
import { ZxRenderDiagnostic } from '../render/diagnostics';
import { ZxRenderCapabilityConformanceReport } from './extension-conformance';
import { ZxDescriptorRenderTargetCapabilities, ZxExtensionDescriptor, ZxHTMLMarkRenderer, ZxHTMLNodeRenderer, ZxMarkRenderContract, ZxNodeExcerptSerializer, ZxNodeRenderContract, ZxNodeTextSerializer, ZxReactMarkRenderer, ZxReactNodeRenderer, ZxReactRenderTargetCapability, ZxRenderProfileCapability, ZxRenderUnsupportedDescriptorPolicy, ZxRenderUnsupportedHandling } from './extension-descriptors';
export interface ZxRenderRegistry {
    descriptors: ZxExtensionDescriptor[];
    report: ZxRenderCapabilityConformanceReport;
    htmlNodeMapping: Record<string, ZxHTMLNodeRenderer>;
    htmlMarkMapping: Record<string, ZxHTMLMarkRenderer>;
    reactNodeMapping: Record<string, ZxReactNodeRenderer>;
    reactMarkMapping: Record<string, ZxReactMarkRenderer>;
    textSerializers: Record<string, ZxNodeTextSerializer>;
    excerptSerializers: Record<string, ZxNodeExcerptSerializer>;
    nodeContracts: Record<string, ZxNodeRenderContract>;
    markContracts: Record<string, ZxMarkRenderContract>;
    supportedNodes: Set<string>;
    supportedMarks: Set<string>;
    targetCapabilityIndex: Record<ZxRenderTargetName, {
        strictness: ZxRenderStrictness;
        unsupportedHandling: ZxRenderUnsupportedHandling;
        descriptors: Set<string>;
        nodes: Set<string>;
        marks: Set<string>;
    }>;
    profileSupportMatrix: Record<ZxRenderProfileName, {
        strictness: ZxRenderStrictness;
        unsupportedHandling: ZxRenderUnsupportedHandling;
        supportedDescriptors: Set<string>;
        supportedNodes: Set<string>;
        supportedMarks: Set<string>;
        semanticDegradeDescriptors: Set<string>;
        semanticDegradeNodes: Set<string>;
        semanticDegradeMarks: Set<string>;
    }>;
    descriptorTargetCapabilities: ReadonlyMap<string, Partial<ZxDescriptorRenderTargetCapabilities>>;
    descriptorProfileCapabilities: ReadonlyMap<string, Partial<Record<ZxRenderProfileName, ZxRenderProfileCapability>>>;
    descriptorUnsupportedPolicies: ReadonlyMap<string, ZxRenderUnsupportedDescriptorPolicy>;
    nodeDescriptorOwners: ReadonlyMap<string, string>;
    markDescriptorOwners: ReadonlyMap<string, string>;
    reactComponentKeys: Map<string, {
        descriptor: ZxExtensionDescriptor;
        nodeNames: readonly string[];
        strategy: ZxReactRenderTargetCapability['strategy'];
    }>;
    nodeReactComponentKeys: Map<string, string>;
}
export interface ZxRenderRegistryStrictnessOptions {
    builtinNodes?: Iterable<string>;
    builtinMarks?: Iterable<string>;
    target?: ZxRenderTargetName;
    profile?: ZxRenderProfileName;
}
export interface CreateRenderRegistryOptions {
    descriptors?: readonly ZxExtensionDescriptor[];
    validation?: 'enforce' | 'report-only';
}
export declare function createRenderRegistry(descriptors?: readonly ZxExtensionDescriptor[]): ZxRenderRegistry;
export declare function createRenderRegistry(options?: CreateRenderRegistryOptions): ZxRenderRegistry;
export declare const collectRenderDiagnostics: (content: JSONContent, registry?: ZxRenderRegistry, options?: ZxRenderRegistryStrictnessOptions) => ZxRenderDiagnostic[];
export declare const assertRenderRegistryCoverage: (content: JSONContent, registry?: ZxRenderRegistry, options?: ZxRenderRegistryStrictnessOptions) => ZxRenderDiagnostic[];
export declare const createTextEditorRenderRegistry: () => ZxRenderRegistry;
//# sourceMappingURL=extension-registry.d.ts.map