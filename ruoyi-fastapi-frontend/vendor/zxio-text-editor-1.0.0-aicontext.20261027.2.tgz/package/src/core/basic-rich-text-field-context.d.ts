import { InjectionKey } from 'vue';
import { TextEditorContentLimits } from './basic-rich-text';
import { ZxTextEditorDocument } from '..';
/** Private to the controlled field: retained typing can be rendered to correct it. */
export declare const basicRichTextFieldContext: InjectionKey<boolean>;
export declare const validateBasicRichTextDraft: (value: unknown, limits?: Partial<TextEditorContentLimits>) => ZxTextEditorDocument | null;
//# sourceMappingURL=basic-rich-text-field-context.d.ts.map