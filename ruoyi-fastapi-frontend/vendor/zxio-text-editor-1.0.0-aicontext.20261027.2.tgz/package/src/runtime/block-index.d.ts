import { Editor, JSONContent } from '@tiptap/core';
export interface BlockTextRange {
    from: number;
    to: number;
    offsetStart: number;
    offsetEnd: number;
}
export interface BlockIndexEntry {
    blockId: string;
    nodeType: string;
    pos: number;
    nodeSize: number;
    dom: HTMLElement | null;
    textLength: number;
    textRanges: BlockTextRange[];
}
export type BlockIndex = Map<string, BlockIndexEntry>;
export interface BlockTextPosition {
    blockId: string;
    offset: number;
}
export declare const buildBlockIndexFromContent: (content: JSONContent) => BlockIndex;
export declare const buildBlockIndex: (editor: Editor) => BlockIndex;
export declare const getBlockIndexEntryFromIndex: (index: BlockIndex, blockId: string) => BlockIndexEntry | null;
export declare const getBlockIndexEntry: (editor: Editor, blockId: string) => BlockIndexEntry | null;
export declare const resolveDocumentPositionToBlockPositionInIndex: (index: BlockIndex, position: number) => BlockTextPosition | null;
export declare const resolveDocumentPositionToBlockPosition: (editor: Editor, position: number) => BlockTextPosition | null;
export declare const resolveBlockOffsetToDocumentPositionInIndex: (index: BlockIndex, blockId: string, offset: number) => number | null;
export declare const resolveBlockOffsetToDocumentPosition: (editor: Editor, blockId: string, offset: number) => number | null;
//# sourceMappingURL=block-index.d.ts.map