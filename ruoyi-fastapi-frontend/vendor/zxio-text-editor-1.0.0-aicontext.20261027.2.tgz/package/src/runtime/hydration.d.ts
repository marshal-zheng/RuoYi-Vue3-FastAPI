import { JSONContent } from '@tiptap/core';
import { ZxDocumentMeta, ZxTextEditorContentType, ZxTextEditorDocument } from '../document';
import { StableBlockIdentityCanonicalizationOptions } from './stable-block-ids';
export interface ZxHydrationSource {
    baseDocument?: ZxTextEditorDocument | null;
    content?: string | null;
    hydrateAnnotations?: boolean;
    modelValue?: unknown;
    documentValue?: ZxTextEditorDocument | null;
    contentType?: ZxTextEditorContentType;
    stableBlockIdentity?: StableBlockIdentityCanonicalizationOptions;
}
export interface ZxHydratedEditorState {
    content: string | JSONContent;
    sourceType: ZxTextEditorContentType;
    document: ZxTextEditorDocument;
}
export declare const migrateLegacyHtmlToHydratedEditorState: (html: string, meta?: Partial<ZxDocumentMeta>, stableBlockIdentity?: StableBlockIdentityCanonicalizationOptions) => ZxHydratedEditorState;
export declare const migrateLegacyJsonToHydratedEditorState: (jsonContent: JSONContent, meta?: Partial<ZxDocumentMeta>, baseDocument?: ZxTextEditorDocument | null, stableBlockIdentity?: StableBlockIdentityCanonicalizationOptions) => ZxHydratedEditorState;
export declare const resolveHydratedEditorState: (source: ZxHydrationSource) => ZxHydratedEditorState;
//# sourceMappingURL=hydration.d.ts.map