import { Editor, JSONContent } from '@tiptap/core';
import { ZxMarkdownExportMode, ZxTextEditorContentType, ZxTextEditorDocument } from '../document';
export interface ZxExportOptions {
    outputType: ZxTextEditorContentType;
    markdownExportMode?: ZxMarkdownExportMode;
    document?: ZxTextEditorDocument;
}
export declare const buildEditorDocument: (editor: Editor, baseDocument?: ZxTextEditorDocument, _options?: {
    markdownExportMode?: ZxMarkdownExportMode;
}) => ZxTextEditorDocument;
export { buildDocumentFromJSONContent } from '../document';
export declare const exportEditorValue: (editor: Editor, options: ZxExportOptions) => string | JSONContent | ZxTextEditorDocument;
//# sourceMappingURL=export.d.ts.map