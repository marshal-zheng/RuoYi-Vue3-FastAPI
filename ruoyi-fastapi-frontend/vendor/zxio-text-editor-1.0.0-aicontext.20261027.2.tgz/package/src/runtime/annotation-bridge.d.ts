import { JSONContent } from '@tiptap/core';
import { ZxAnnotation, ZxTextEditorDocument } from '../document';
export interface ZxAnnotationBridgeState {
    annotations: ZxAnnotation[];
}
export declare const syncAnnotationBridgeStateFromContent: (content: JSONContent, state: ZxAnnotationBridgeState) => ZxAnnotationBridgeState;
export declare const applyAnnotationBridgeStateToContent: (content: JSONContent, state: ZxAnnotationBridgeState) => JSONContent;
export declare const createAnnotationBridgeState: (document?: Pick<ZxTextEditorDocument, "annotations"> | null) => ZxAnnotationBridgeState;
export declare const mergeAnnotationBridgeState: (document: ZxTextEditorDocument, state: ZxAnnotationBridgeState) => ZxTextEditorDocument;
//# sourceMappingURL=annotation-bridge.d.ts.map