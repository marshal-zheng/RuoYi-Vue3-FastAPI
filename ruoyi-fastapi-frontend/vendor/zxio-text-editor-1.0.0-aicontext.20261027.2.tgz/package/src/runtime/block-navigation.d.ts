import { Editor } from '@tiptap/core';
export interface NavigateToBlockOptions {
    focus?: boolean;
    scrollBehavior?: ScrollBehavior;
    align?: 'start' | 'center' | 'nearest';
}
export declare const getBlockElement: (editor: Editor, blockId: string) => HTMLElement | null;
export declare const navigateToBlock: (editor: Editor, blockId: string, options?: NavigateToBlockOptions) => boolean;
//# sourceMappingURL=block-navigation.d.ts.map