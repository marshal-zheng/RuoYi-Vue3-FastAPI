import { ZxBinaryExportArtifact } from '../result';
interface ZxStoredBinaryExportArtifactRecord {
    artifact: ZxBinaryExportArtifact;
    payload: Uint8Array | null;
}
export interface ZxBinaryExportArtifactStore {
    put(jobId: string, artifact: ZxBinaryExportArtifact, payload?: Uint8Array | null): Promise<void>;
    get(jobId: string, artifactId: string): Promise<ZxBinaryExportArtifact | null>;
    readPayload(jobId: string, artifactId: string): Promise<Uint8Array | null>;
    list(jobId: string): Promise<readonly ZxBinaryExportArtifact[]>;
    reset(jobId: string): Promise<void>;
}
export interface ZxInMemoryBinaryExportArtifactStoreState {
    byJob: Map<string, Map<string, ZxStoredBinaryExportArtifactRecord>>;
}
export interface ZxCreateInMemoryBinaryExportArtifactStoreOptions {
    state?: ZxInMemoryBinaryExportArtifactStoreState;
}
export declare const createInMemoryBinaryExportArtifactStore: (options?: ZxCreateInMemoryBinaryExportArtifactStoreOptions) => ZxBinaryExportArtifactStore;
export {};
//# sourceMappingURL=artifacts.d.ts.map