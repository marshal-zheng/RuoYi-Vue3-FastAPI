import { ZxBinaryExportFormat } from './contract';
export declare const ZX_BINARY_EXPORT_DIAGNOSTIC_SEVERITIES: readonly ["error", "warning", "info"];
export type ZxBinaryExportDiagnosticSeverity = (typeof ZX_BINARY_EXPORT_DIAGNOSTIC_SEVERITIES)[number];
export declare const ZX_BINARY_EXPORT_DIAGNOSTIC_PHASES: readonly ["eligibility", "composition", "capability", "lowering", "backend", "artifact", "result"];
export type ZxBinaryExportDiagnosticPhase = (typeof ZX_BINARY_EXPORT_DIAGNOSTIC_PHASES)[number];
export interface ZxBinaryExportDiagnostic {
    id?: string;
    code: string;
    message: string;
    severity?: ZxBinaryExportDiagnosticSeverity;
    phase?: ZxBinaryExportDiagnosticPhase;
    format?: ZxBinaryExportFormat;
    adapterId?: string;
    backendId?: string;
    bundleId?: string;
    planId?: string;
    jobId?: string;
    target?: string;
}
export declare class ZxBinaryExportError extends Error {
    readonly diagnostics: ZxBinaryExportDiagnostic[];
    constructor(message: string, diagnostics?: ZxBinaryExportDiagnostic[]);
}
export declare const createBinaryExportDiagnostics: (diagnostics?: ZxBinaryExportDiagnostic[]) => ZxBinaryExportDiagnostic[];
export declare const hasBinaryExportDiagnostic: (diagnostics: readonly ZxBinaryExportDiagnostic[], diagnostic: Pick<ZxBinaryExportDiagnostic, "code" | "target" | "phase">) => boolean;
export declare const pushBinaryExportDiagnostic: (diagnostics: ZxBinaryExportDiagnostic[], diagnostic: ZxBinaryExportDiagnostic) => ZxBinaryExportDiagnostic[];
export declare const pushUniqueBinaryExportDiagnostic: (diagnostics: ZxBinaryExportDiagnostic[], diagnostic: ZxBinaryExportDiagnostic) => ZxBinaryExportDiagnostic[];
export declare const describeBinaryExportDiagnostic: (diagnostic: ZxBinaryExportDiagnostic) => string;
//# sourceMappingURL=diagnostics.d.ts.map