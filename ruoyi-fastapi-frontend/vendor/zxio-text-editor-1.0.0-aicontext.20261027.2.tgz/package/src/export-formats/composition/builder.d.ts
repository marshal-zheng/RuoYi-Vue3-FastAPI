import { ZxDocumentExportBundleResult } from '../../export';
import { ZxBinaryExportDiagnostic } from '../diagnostics';
import { ZxBinaryCompositionPlan, ZxBuildBinaryCompositionPlanOptions } from './types';
export interface ZxBuildBinaryCompositionPlanRuntimeOptions extends ZxBuildBinaryCompositionPlanOptions {
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export declare const buildBinaryCompositionPlan: (bundleResult: ZxDocumentExportBundleResult, options?: ZxBuildBinaryCompositionPlanRuntimeOptions) => ZxBinaryCompositionPlan;
//# sourceMappingURL=builder.d.ts.map