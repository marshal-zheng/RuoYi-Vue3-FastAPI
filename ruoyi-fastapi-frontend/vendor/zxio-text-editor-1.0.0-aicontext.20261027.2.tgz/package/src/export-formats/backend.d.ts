import { ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityMatrix, ZxBinaryExportCapabilityValue } from './capabilities';
import { ZxBinaryExportFormat } from './contract';
import { ZxBinaryExportDiagnostic } from './diagnostics';
export declare const ZX_BINARY_EXPORT_FORBIDDEN_FALLBACKS: readonly ["html-first", "browser-print-path", "remote-webpage-conversion", "consumer-shadow-exporter"];
export type ZxBinaryExportForbiddenFallback = (typeof ZX_BINARY_EXPORT_FORBIDDEN_FALLBACKS)[number];
export type ZxBinaryExportBackendRuntime = 'local-process' | 'self-hosted-service' | 'saas-service';
export type ZxBinaryExportBackendTrustLevel = 'trusted-local' | 'trusted-self-hosted' | 'explicit-saas-opt-in';
export interface ZxBinaryExportBackendConstraint {
    code: string;
    message: string;
}
export interface ZxBinaryExportBackendDescriptor {
    id: string;
    format: ZxBinaryExportFormat;
    runtime: ZxBinaryExportBackendRuntime;
    trustLevel: ZxBinaryExportBackendTrustLevel;
    enabledByDefault: boolean;
    allowStagedBundle: boolean;
    forbiddenFallbacks: readonly ZxBinaryExportForbiddenFallback[];
    capability: ZxBinaryExportCapabilityMatrix;
    constraints: readonly ZxBinaryExportBackendConstraint[];
}
export interface ZxBinaryExportAdapterDescriptor {
    id: string;
    format: ZxBinaryExportFormat;
    defaultBackendId: string;
    backends: readonly ZxBinaryExportBackendDescriptor[];
}
export interface ZxBinaryExportAdapterRegistryState {
    adapters: Readonly<Record<ZxBinaryExportFormat, ZxBinaryExportAdapterDescriptor>>;
}
export interface ZxCreateBinaryExportBackendDescriptorOptions {
    id: string;
    format: ZxBinaryExportFormat;
    runtime: ZxBinaryExportBackendRuntime;
    trustLevel: ZxBinaryExportBackendTrustLevel;
    adapterId: string;
    enabledByDefault?: boolean;
    allowStagedBundle?: boolean;
    forbiddenFallbacks?: readonly ZxBinaryExportForbiddenFallback[];
    businessReady?: Partial<Record<ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue>>;
    constraints?: readonly ZxBinaryExportBackendConstraint[];
}
export interface ZxCreateBinaryExportAdapterDescriptorOptions {
    id: string;
    format: ZxBinaryExportFormat;
    defaultBackendId: string;
    backends: readonly ZxBinaryExportBackendDescriptor[];
}
export interface ZxResolveBinaryBackendOptions {
    backendId?: string;
    allowSaaSOptIn?: boolean;
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export declare const createBinaryExportBackendDescriptor: (options: ZxCreateBinaryExportBackendDescriptorOptions) => ZxBinaryExportBackendDescriptor;
export declare const createBinaryExportAdapterDescriptor: (options: ZxCreateBinaryExportAdapterDescriptorOptions) => ZxBinaryExportAdapterDescriptor;
export declare const ZX_BLESSED_DEFAULT_BINARY_EXPORT_ADAPTERS: readonly [ZxBinaryExportAdapterDescriptor, ZxBinaryExportAdapterDescriptor];
export declare const createBinaryExportAdapterRegistry: (adapters?: readonly ZxBinaryExportAdapterDescriptor[]) => ZxBinaryExportAdapterRegistryState;
export declare const resolveBinaryExportAdapter: (registry: ZxBinaryExportAdapterRegistryState, format: ZxBinaryExportFormat) => ZxBinaryExportAdapterDescriptor;
export declare const resolveBinaryExportBackend: (adapter: ZxBinaryExportAdapterDescriptor, options?: ZxResolveBinaryBackendOptions) => ZxBinaryExportBackendDescriptor;
export interface ZxRegisterBinaryExportBackendOptions {
    format: ZxBinaryExportFormat;
    backend: ZxBinaryExportBackendDescriptor;
}
export declare const registerBinaryExportBackend: (registry: ZxBinaryExportAdapterRegistryState, options: ZxRegisterBinaryExportBackendOptions) => ZxBinaryExportAdapterRegistryState;
export interface ZxRegisterBinaryExportBackendCapabilityOptions {
    format: ZxBinaryExportFormat;
    backendId: string;
    businessReady: Partial<Record<ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue>>;
}
export declare const registerBinaryExportBackendCapability: (registry: ZxBinaryExportAdapterRegistryState, options: ZxRegisterBinaryExportBackendCapabilityOptions) => ZxBinaryExportAdapterRegistryState;
export declare const collectBackendConstraintDiagnostics: (backend: ZxBinaryExportBackendDescriptor, diagnostics?: ZxBinaryExportDiagnostic[]) => ZxBinaryExportDiagnostic[];
//# sourceMappingURL=backend.d.ts.map