import { ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue } from '../../capabilities';
import { ZxBinaryExportBackendConstraint, ZxBinaryExportBackendDescriptor } from '../../backend';
import { ZxDocxCapabilityProfile, ZxDocxExportBackend } from './contract';
export declare const ZX_DOCX_ADAPTER_ID = "docx-adapter";
export declare const ZX_DOCX_DEFAULT_BACKEND_ID = "docx-local-openxml";
export declare const ZX_DOCX_DEFAULT_BACKEND_CONSTRAINTS: readonly ZxBinaryExportBackendConstraint[];
export declare const ZX_DEFAULT_DOCX_CAPABILITY_PROFILE: ZxDocxCapabilityProfile;
export interface ZxCreateDefaultDocxBackendOptions {
    allowStagedBundle?: boolean;
    businessReady?: Partial<Record<ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue>>;
    constraints?: readonly ZxBinaryExportBackendConstraint[];
}
export declare const resolveDocxCapabilityProfile: (descriptor: ZxBinaryExportBackendDescriptor) => ZxDocxCapabilityProfile;
export declare const createDefaultDocxBackendDescriptor: (options?: ZxCreateDefaultDocxBackendOptions) => ZxBinaryExportBackendDescriptor;
export declare const createDefaultDocxExportBackend: (options?: ZxCreateDefaultDocxBackendOptions) => ZxDocxExportBackend;
//# sourceMappingURL=default-backend.d.ts.map