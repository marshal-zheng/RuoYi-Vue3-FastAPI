import { ZxBinaryExportBackendDescriptor } from '../../backend';
import { ZxBinaryExportSupportLevel } from '../../capabilities';
import { ZxBinaryCompositionInline, ZxBinaryCompositionMetadata, ZxBinaryCompositionPlan, ZxBinaryCompositionSection } from '../../composition';
import { ZxBinaryCompositionCodeBlock } from '../../../code-block';
import { ZxBinaryExportDocxFormatOptions, ZxBinaryExportPageMargins, ZxBinaryExportPageOrientation, ZxBinaryExportPageSize, ZxBinaryExportFidelityMode, ZxBinaryExportFidelityTier } from '../../contract';
import { ZxBinaryExportDiagnostic } from '../../diagnostics';
import { ZxBinaryExportFidelityReport } from '../../result';
export declare const ZX_DOCX_PACKAGE_MODEL_VERSION = "docx-package-model/v1";
export type ZxDocxPageSize = ZxBinaryExportPageSize;
export type ZxDocxPageOrientation = ZxBinaryExportPageOrientation;
export type ZxDocxPageNumberingMode = 'inherit' | 'restart-1' | 'hidden';
export type ZxDocxPageMargins = ZxBinaryExportPageMargins;
export interface ZxDocxSectionSettings {
    size: ZxDocxPageSize;
    width?: number;
    height?: number;
    orientation: ZxDocxPageOrientation;
    margins: ZxDocxPageMargins;
    headerFooterRole: 'default' | 'first-page' | 'none';
    pageNumbering: ZxDocxPageNumberingMode;
    headerText?: string;
    footerText?: string;
    firstHeaderText?: string;
    firstFooterText?: string;
}
export type ZxDocxFormatOptions = Required<ZxBinaryExportDocxFormatOptions>;
export interface ZxDocxStyleRoleMapping {
    role: string;
    paragraphStyleId: string;
    runStyleId?: string;
}
export interface ZxDocxRunModel {
    text: string;
    marks: readonly string[];
    href?: string;
    annotationId?: string;
}
export interface ZxDocxBlockModel {
    id: string;
    kind: string;
    depth: number;
    styleRole?: string;
    text?: string;
    inlines: readonly ZxDocxRunModel[];
    codeBlock?: ZxBinaryCompositionCodeBlock;
    table?: {
        rowCount: number;
        columnCount: number;
        cells: readonly {
            row: number;
            column: number;
            text: string;
        }[];
    };
}
export interface ZxDocxSectionModel {
    id: string;
    order: number;
    sourceSectionId: string;
    sectionBreak: ZxBinaryCompositionSection['intent']['sectionBreak'];
    settings: ZxDocxSectionSettings;
    blocks: readonly ZxDocxBlockModel[];
}
export interface ZxDocxCommentProjection {
    id: string;
    threadId: string;
    targetBlockId?: string;
    resolved: boolean;
    commentCount: number;
}
export interface ZxDocxBookmarkProjection {
    id: string;
    label: string;
    level: number;
    targetBlockId?: string;
}
export interface ZxDocxTocProjection {
    id: string;
    label: string;
    level: number;
    targetBlockId?: string;
}
export interface ZxDocxPackageModel {
    id: string;
    version: typeof ZX_DOCX_PACKAGE_MODEL_VERSION;
    source: 'composition-plan';
    planId: string;
    metadata: ZxBinaryCompositionMetadata;
    formatOptions: ZxDocxFormatOptions;
    sections: readonly ZxDocxSectionModel[];
    styles: readonly ZxDocxStyleRoleMapping[];
    comments: readonly ZxDocxCommentProjection[];
    bookmarks: readonly ZxDocxBookmarkProjection[];
    toc: readonly ZxDocxTocProjection[];
    unsupportedSemanticCodes: readonly string[];
}
export interface ZxDocxCapabilityProfile {
    wordStructure: ZxBinaryExportSupportLevel;
    styleRoleMapping: ZxBinaryExportSupportLevel;
    sectionSettings: ZxBinaryExportSupportLevel;
    bookmarks: ZxBinaryExportSupportLevel;
    commentsProjection: ZxBinaryExportSupportLevel;
    tocProjection: ZxBinaryExportSupportLevel;
    metadataProjection: ZxBinaryExportSupportLevel;
}
export interface ZxLowerDocxPackageModelOptions {
    formatOptions?: Partial<ZxDocxFormatOptions>;
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export interface ZxDocxBackendExecutionOptions {
    plan: ZxBinaryCompositionPlan;
    fidelityTier?: ZxBinaryExportFidelityTier;
    fidelityMode?: ZxBinaryExportFidelityMode;
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export type ZxDocxArtifactKind = 'primary' | 'sidecar' | 'preview';
export type ZxDocxArtifactLocatorKind = 'inline-bytes' | 'artifact-store-ref' | 'file-ref';
export interface ZxDocxArtifact {
    id: string;
    format: 'docx';
    kind: ZxDocxArtifactKind;
    mediaType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' | 'application/json';
    locator: {
        kind: ZxDocxArtifactLocatorKind;
        value: string;
    };
    sectionCount?: number;
    size?: number;
    digest?: string;
    payload?: Uint8Array;
}
export interface ZxDocxBackendExecutionResult {
    backendId: string;
    artifacts: readonly ZxDocxArtifact[];
    diagnostics: readonly ZxBinaryExportDiagnostic[];
    fidelity: ZxBinaryExportFidelityReport;
}
export interface ZxDocxExportBackend {
    descriptor: ZxBinaryExportBackendDescriptor;
    execute: (model: ZxDocxPackageModel, options: ZxDocxBackendExecutionOptions) => ZxDocxBackendExecutionResult;
}
export declare const toDocxRunModel: (inline: ZxBinaryCompositionInline) => ZxDocxRunModel;
//# sourceMappingURL=contract.d.ts.map