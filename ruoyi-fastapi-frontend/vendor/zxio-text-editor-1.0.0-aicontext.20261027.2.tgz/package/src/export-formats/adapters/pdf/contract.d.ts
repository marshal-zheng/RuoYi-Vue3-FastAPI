import { ZxBinaryExportBackendDescriptor } from '../../backend';
import { ZxBinaryExportSupportLevel } from '../../capabilities';
import { ZxBinaryCompositionMetadata, ZxBinaryCompositionPlan } from '../../composition';
import { ZxBinaryExportPageMargins, ZxBinaryExportPageOrientation, ZxBinaryExportPageSize, ZxBinaryExportPdfFormatOptions, ZxBinaryExportPdfPageNumberingMode, ZxBinaryExportFidelityMode, ZxBinaryExportFidelityTier } from '../../contract';
import { ZxBinaryExportDiagnostic } from '../../diagnostics';
import { ZxBinaryExportFidelityReport } from '../../result';
export declare const ZX_PDF_RENDER_MODEL_VERSION = "pdf-render-model/v1";
export type ZxPdfPaperSize = ZxBinaryExportPageSize;
export type ZxPdfOrientation = ZxBinaryExportPageOrientation;
export type ZxPdfPageNumberingMode = ZxBinaryExportPdfPageNumberingMode;
export type ZxPdfPageMargins = ZxBinaryExportPageMargins;
export interface ZxPdfPageSettings {
    size: ZxPdfPaperSize;
    width?: number;
    height?: number;
    orientation: ZxPdfOrientation;
    margins: ZxPdfPageMargins;
}
export interface ZxPdfHeaderFooterSettings {
    enabled: boolean;
    showHeader: boolean;
    showFooter: boolean;
    pageNumbering: ZxPdfPageNumberingMode;
    headerText?: string;
    footerText?: string;
}
export type ZxPdfFormatOptions = Required<ZxBinaryExportPdfFormatOptions>;
export interface ZxPdfCapabilityProfile {
    physicalPagination: ZxBinaryExportSupportLevel;
    printLayout: ZxBinaryExportSupportLevel;
    headerFooter: ZxBinaryExportSupportLevel;
    pageNumbering: ZxBinaryExportSupportLevel;
    bookmarks: ZxBinaryExportSupportLevel;
    commentsProjection: ZxBinaryExportSupportLevel;
    metadataProjection: ZxBinaryExportSupportLevel;
}
export interface ZxPdfPageIntent {
    id: string;
    sectionId: string;
    pageNumber: number;
    settings: ZxPdfPageSettings;
    headerFooter: ZxPdfHeaderFooterSettings;
    blockRefs: readonly string[];
}
export interface ZxPdfOutlineItem {
    id: string;
    label: string;
    level: number;
    targetBlockId?: string;
}
export interface ZxPdfCommentProjection {
    id: string;
    threadId: string;
    targetBlockId?: string;
    resolved: boolean;
    commentCount: number;
}
export interface ZxPdfRenderModel {
    id: string;
    version: typeof ZX_PDF_RENDER_MODEL_VERSION;
    source: 'composition-plan';
    planId: string;
    metadata: ZxBinaryCompositionMetadata;
    formatOptions: ZxPdfFormatOptions;
    pages: readonly ZxPdfPageIntent[];
    outline: readonly ZxPdfOutlineItem[];
    comments: readonly ZxPdfCommentProjection[];
    unsupportedSemanticCodes: readonly string[];
}
export interface ZxLowerPdfRenderModelOptions {
    formatOptions?: Partial<ZxPdfFormatOptions>;
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export interface ZxPdfBackendExecutionOptions {
    plan: ZxBinaryCompositionPlan;
    fidelityTier?: ZxBinaryExportFidelityTier;
    fidelityMode?: ZxBinaryExportFidelityMode;
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export type ZxPdfArtifactKind = 'primary' | 'sidecar' | 'preview';
export type ZxPdfArtifactLocatorKind = 'inline-bytes' | 'artifact-store-ref' | 'file-ref';
export interface ZxPdfArtifact {
    id: string;
    format: 'pdf';
    kind: ZxPdfArtifactKind;
    mediaType: 'application/pdf' | 'application/json';
    locator: {
        kind: ZxPdfArtifactLocatorKind;
        value: string;
    };
    pageCount?: number;
    size?: number;
    digest?: string;
    payload?: Uint8Array;
}
export interface ZxPdfBackendExecutionResult {
    backendId: string;
    artifacts: readonly ZxPdfArtifact[];
    diagnostics: readonly ZxBinaryExportDiagnostic[];
    fidelity: ZxBinaryExportFidelityReport;
}
export interface ZxPdfExportBackend {
    descriptor: ZxBinaryExportBackendDescriptor;
    execute: (model: ZxPdfRenderModel, options: ZxPdfBackendExecutionOptions) => ZxPdfBackendExecutionResult;
}
//# sourceMappingURL=contract.d.ts.map