import { ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue } from '../../capabilities';
import { ZxBinaryExportBackendConstraint, ZxBinaryExportBackendDescriptor } from '../../backend';
import { ZxPdfCapabilityProfile, ZxPdfExportBackend } from './contract';
export declare const ZX_PDF_ADAPTER_ID = "pdf-adapter";
export declare const ZX_PDF_DEFAULT_BACKEND_ID = "pdf-local-compositor";
export declare const ZX_PDF_DEFAULT_BACKEND_CONSTRAINTS: readonly ZxBinaryExportBackendConstraint[];
export declare const ZX_DEFAULT_PDF_CAPABILITY_PROFILE: ZxPdfCapabilityProfile;
export interface ZxCreateDefaultPdfBackendOptions {
    allowStagedBundle?: boolean;
    businessReady?: Partial<Record<ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue>>;
    constraints?: readonly ZxBinaryExportBackendConstraint[];
}
export declare const resolvePdfCapabilityProfile: (descriptor: ZxBinaryExportBackendDescriptor) => ZxPdfCapabilityProfile;
export declare const createDefaultPdfBackendDescriptor: (options?: ZxCreateDefaultPdfBackendOptions) => ZxBinaryExportBackendDescriptor;
export declare const createDefaultPdfExportBackend: (options?: ZxCreateDefaultPdfBackendOptions) => ZxPdfExportBackend;
//# sourceMappingURL=default-backend.d.ts.map