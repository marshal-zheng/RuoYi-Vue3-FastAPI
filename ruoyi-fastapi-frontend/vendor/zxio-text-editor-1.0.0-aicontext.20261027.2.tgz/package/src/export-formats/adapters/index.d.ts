export * from './pdf';
export * from './docx';
//# sourceMappingURL=index.d.ts.map