export declare const encodeUtf8: (value: string) => Uint8Array;
export declare const concatUint8Arrays: (chunks: readonly Uint8Array[]) => Uint8Array;
export declare const uint16ToLittleEndian: (value: number) => Uint8Array;
export declare const uint32ToLittleEndian: (value: number) => Uint8Array;
export declare const cloneUint8Array: (value: Uint8Array) => Uint8Array;
//# sourceMappingURL=binary.d.ts.map