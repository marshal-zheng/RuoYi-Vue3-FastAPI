import { ZxBinaryCompositionPlan } from './composition';
import { ZxBinaryExportFidelityMode, ZxBinaryExportFidelityTier, ZxBinaryExportFormat } from './contract';
import { ZxBinaryExportDiagnostic } from './diagnostics';
export declare const ZX_BINARY_EXPORT_SUPPORT_LEVELS: readonly ["supported", "partially-supported", "unsupported", "conditional"];
export type ZxBinaryExportSupportLevel = (typeof ZX_BINARY_EXPORT_SUPPORT_LEVELS)[number];
export interface ZxBinaryExportCapabilityValue {
    level: ZxBinaryExportSupportLevel;
    reason?: string;
}
export declare const ZX_BINARY_BUSINESS_READY_CAPABILITY_NAMES: readonly ["headings", "lists", "tables", "images", "links", "inlineMarks", "metadata", "comments", "bookmarks", "toc", "headerFooter", "pageNumbering", "sectionSettings", "stagedBundleInput"];
export type ZxBinaryBusinessReadyCapabilityName = (typeof ZX_BINARY_BUSINESS_READY_CAPABILITY_NAMES)[number];
export interface ZxBinaryExportBusinessReadyCapabilities {
    headings: ZxBinaryExportCapabilityValue;
    lists: ZxBinaryExportCapabilityValue;
    tables: ZxBinaryExportCapabilityValue;
    images: ZxBinaryExportCapabilityValue;
    links: ZxBinaryExportCapabilityValue;
    inlineMarks: ZxBinaryExportCapabilityValue;
    metadata: ZxBinaryExportCapabilityValue;
    comments: ZxBinaryExportCapabilityValue;
    bookmarks: ZxBinaryExportCapabilityValue;
    toc: ZxBinaryExportCapabilityValue;
    headerFooter: ZxBinaryExportCapabilityValue;
    pageNumbering: ZxBinaryExportCapabilityValue;
    sectionSettings: ZxBinaryExportCapabilityValue;
    stagedBundleInput: ZxBinaryExportCapabilityValue;
}
export interface ZxBinaryExportCapabilityMatrix {
    format: ZxBinaryExportFormat;
    adapterId: string;
    backendId: string;
    businessReady: ZxBinaryExportBusinessReadyCapabilities;
}
export type ZxBinaryFidelityIssueSeverity = 'blocking' | 'downgrade' | 'info';
export interface ZxBinaryFidelityIssue {
    code: string;
    severity: ZxBinaryFidelityIssueSeverity;
    message: string;
    target?: string;
}
export interface ZxBinaryFidelityDowngradeReason {
    code: string;
    message: string;
    target?: string;
}
export interface ZxBinaryFidelityEvaluation {
    tier: ZxBinaryExportFidelityTier;
    mode: ZxBinaryExportFidelityMode;
    status: 'passed' | 'degraded' | 'blocked';
    issues: readonly ZxBinaryFidelityIssue[];
    downgradeReasons: readonly ZxBinaryFidelityDowngradeReason[];
    directlyDeliverable: boolean;
}
export interface ZxCreateBinaryExportCapabilityMatrixOptions {
    format: ZxBinaryExportFormat;
    adapterId: string;
    backendId: string;
    businessReady?: Partial<Record<ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue>>;
}
export interface ZxEvaluateBinaryFidelityOptions {
    tier?: ZxBinaryExportFidelityTier;
    mode?: ZxBinaryExportFidelityMode;
    diagnostics?: ZxBinaryExportDiagnostic[];
}
export declare const createBusinessReadyCapabilities: (overrides?: Partial<Record<ZxBinaryBusinessReadyCapabilityName, ZxBinaryExportCapabilityValue>>) => ZxBinaryExportBusinessReadyCapabilities;
export declare const createBinaryExportCapabilityMatrix: (options: ZxCreateBinaryExportCapabilityMatrixOptions) => ZxBinaryExportCapabilityMatrix;
export declare const ZX_DEFAULT_BINARY_EXPORT_CAPABILITY_MATRICES: Readonly<Record<ZxBinaryExportFormat, ZxBinaryExportCapabilityMatrix>>;
export declare const resolveDefaultBinaryExportCapabilityMatrix: (format: ZxBinaryExportFormat) => ZxBinaryExportCapabilityMatrix;
export declare const evaluateBinaryFidelityGate: (plan: ZxBinaryCompositionPlan, matrix: ZxBinaryExportCapabilityMatrix, options?: ZxEvaluateBinaryFidelityOptions) => ZxBinaryFidelityEvaluation;
export declare const assertBinaryFidelityGate: (plan: ZxBinaryCompositionPlan, matrix: ZxBinaryExportCapabilityMatrix, options?: ZxEvaluateBinaryFidelityOptions) => ZxBinaryFidelityEvaluation;
//# sourceMappingURL=capabilities.d.ts.map