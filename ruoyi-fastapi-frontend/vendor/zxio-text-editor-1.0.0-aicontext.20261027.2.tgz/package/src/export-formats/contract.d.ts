import { ZxDocumentExportBundleResult } from '../export';
import { ZxDocumentPageMargins, ZxDocumentPageOrientation, ZxDocumentPageSize } from '../document';
export declare const ZX_BINARY_EXPORT_FORMATS: readonly ["pdf", "docx"];
export type ZxBinaryExportFormat = (typeof ZX_BINARY_EXPORT_FORMATS)[number];
export declare const ZX_BINARY_EXPORT_FIDELITY_TIERS: readonly ["business-ready"];
export type ZxBinaryExportFidelityTier = (typeof ZX_BINARY_EXPORT_FIDELITY_TIERS)[number];
export declare const ZX_BINARY_EXPORT_FIDELITY_MODES: readonly ["fidelity-strict", "best-effort"];
export type ZxBinaryExportFidelityMode = (typeof ZX_BINARY_EXPORT_FIDELITY_MODES)[number];
export declare const ZX_BINARY_EXPORT_JOB_STATES: readonly ["accepted", "planning", "queued", "running", "completed", "failed"];
export type ZxBinaryExportJobState = (typeof ZX_BINARY_EXPORT_JOB_STATES)[number];
export declare const ZX_BINARY_EXPORT_EXECUTION_MODES: readonly ["auto", "force-async", "prefer-sync"];
export type ZxBinaryExportExecutionMode = (typeof ZX_BINARY_EXPORT_EXECUTION_MODES)[number];
export type ZxBinaryExportPageSize = ZxDocumentPageSize;
export type ZxBinaryExportPageOrientation = ZxDocumentPageOrientation;
export type ZxBinaryExportPageMargins = ZxDocumentPageMargins;
export type ZxBinaryExportPdfPageNumberingMode = 'none' | 'document' | 'section';
export interface ZxBinaryExportPdfFormatOptions {
    page?: Partial<{
        size: ZxBinaryExportPageSize;
        width: number;
        height: number;
        orientation: ZxBinaryExportPageOrientation;
        margins: ZxBinaryExportPageMargins;
    }>;
    headerFooter?: Partial<{
        enabled: boolean;
        showHeader: boolean;
        showFooter: boolean;
        pageNumbering: ZxBinaryExportPdfPageNumberingMode;
    }>;
    includeComments?: boolean;
    includeBookmarks?: boolean;
}
export interface ZxBinaryExportDocxFormatOptions {
    includeComments?: boolean;
    includeBookmarks?: boolean;
    includeToc?: boolean;
    preserveSectionPageSettings?: boolean;
}
export interface ZxBinaryExportFormatOptionsMap {
    pdf?: ZxBinaryExportPdfFormatOptions;
    docx?: ZxBinaryExportDocxFormatOptions;
}
export interface ZxBinaryExportRequest {
    format: ZxBinaryExportFormat;
    fidelityTier?: ZxBinaryExportFidelityTier;
    fidelityMode?: ZxBinaryExportFidelityMode;
    backend?: string;
    execution?: ZxBinaryExportExecutionMode;
    namespace?: string;
    formatOptions?: ZxBinaryExportFormatOptionsMap;
}
export interface ZxResolvedBinaryExportRequest extends ZxBinaryExportRequest {
    fidelityTier: ZxBinaryExportFidelityTier;
    fidelityMode: ZxBinaryExportFidelityMode;
    execution: ZxBinaryExportExecutionMode;
}
/**
 * Binary export is a pure consumer of phase-3 export bundle truth.
 */
export interface ZxBinaryExportInput {
    bundle: ZxDocumentExportBundleResult;
    request: ZxBinaryExportRequest;
}
export interface ZxBinaryExportAdapterRegistration {
    id: string;
    format: ZxBinaryExportFormat;
    defaultBackendId: string;
    backendIds: readonly string[];
}
export type ZxBinaryExportAdapterRegistry = Partial<Record<ZxBinaryExportFormat, ZxBinaryExportAdapterRegistration>>;
export declare const resolveBinaryExportRequest: (request: ZxBinaryExportRequest) => ZxResolvedBinaryExportRequest;
export declare const resolveBinaryExportFormatOptionsForRequest: (request: Pick<ZxResolvedBinaryExportRequest, "format" | "formatOptions">) => ZxBinaryExportPdfFormatOptions | ZxBinaryExportDocxFormatOptions | undefined;
//# sourceMappingURL=contract.d.ts.map