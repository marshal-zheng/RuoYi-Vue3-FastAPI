import { Placement } from '@floating-ui/dom';
export interface FloatingPopupOptions {
    placement?: Placement;
    appendTo: HTMLElement | (() => HTMLElement);
    interactive?: boolean;
    onClickOutside?: () => void;
}
export interface FloatingPopupInstance {
    show: () => void;
    hide: () => void;
    destroy: () => void;
    setProps: (props: {
        getReferenceClientRect?: () => DOMRect;
    }) => void;
    element: HTMLElement;
}
export declare function createFloatingPopup(content: HTMLElement, getReferenceClientRect: () => DOMRect | {
    [key: string]: any;
}, options: FloatingPopupOptions): FloatingPopupInstance;
//# sourceMappingURL=floating-popup.d.ts.map