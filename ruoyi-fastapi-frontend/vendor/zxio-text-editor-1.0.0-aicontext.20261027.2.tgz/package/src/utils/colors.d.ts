/**
 * Material Design Color Palette
 * Professional color system for text editor
 */
export interface ColorShade {
    base: string;
    lighten5: string;
    lighten4: string;
    lighten3: string;
    lighten2: string;
    lighten1: string;
    darken1: string;
    darken2: string;
    darken3: string;
    darken4: string;
    accent1?: string;
    accent2?: string;
    accent3?: string;
    accent4?: string;
}
export declare const red: ColorShade;
export declare const pink: ColorShade;
export declare const purple: ColorShade;
export declare const deepPurple: ColorShade;
export declare const indigo: ColorShade;
export declare const blue: ColorShade;
export declare const lightBlue: ColorShade;
export declare const cyan: ColorShade;
export declare const teal: ColorShade;
export declare const green: ColorShade;
export declare const lightGreen: ColorShade;
export declare const lime: ColorShade;
export declare const yellow: ColorShade;
export declare const amber: ColorShade;
export declare const orange: ColorShade;
export declare const deepOrange: ColorShade;
export declare const brown: Omit<ColorShade, 'accent1' | 'accent2' | 'accent3' | 'accent4'>;
export declare const blueGrey: Omit<ColorShade, 'accent1' | 'accent2' | 'accent3' | 'accent4'>;
export declare const grey: Omit<ColorShade, 'accent1' | 'accent2' | 'accent3' | 'accent4'>;
export declare const shades: {
    black: string;
    white: string;
    transparent: string;
};
/**
 * Generate color matrix for color picker
 * Returns a 2D array of colors organized by hue and lightness
 */
export declare function generateColorMatrix(): string[][];
/**
 * Generate a compact color matrix (fewer colors, better for quick selection)
 */
export declare function generateCompactColorMatrix(): string[][];
/**
 * Check if a color is light (for determining text color on backgrounds)
 */
export declare function isLightColor(color: string): boolean;
/**
 * Get the closest named color for editor extension
 */
export declare function getNamedColor(hexColor: string): string | null;
declare const _default: {
    red: ColorShade;
    pink: ColorShade;
    purple: ColorShade;
    deepPurple: ColorShade;
    indigo: ColorShade;
    blue: ColorShade;
    lightBlue: ColorShade;
    cyan: ColorShade;
    teal: ColorShade;
    green: ColorShade;
    lightGreen: ColorShade;
    lime: ColorShade;
    yellow: ColorShade;
    amber: ColorShade;
    orange: ColorShade;
    deepOrange: ColorShade;
    brown: Omit<ColorShade, "accent1" | "accent2" | "accent3" | "accent4">;
    blueGrey: Omit<ColorShade, "accent1" | "accent2" | "accent3" | "accent4">;
    grey: Omit<ColorShade, "accent1" | "accent2" | "accent3" | "accent4">;
    shades: {
        black: string;
        white: string;
        transparent: string;
    };
    generateColorMatrix: typeof generateColorMatrix;
    generateCompactColorMatrix: typeof generateCompactColorMatrix;
    isLightColor: typeof isLightColor;
    getNamedColor: typeof getNamedColor;
};
export default _default;
//# sourceMappingURL=colors.d.ts.map