export declare const isTextEditorDebugEnabled: (scope: string) => boolean;
export declare const debugTextEditorLog: (scope: string, message: string, payload?: unknown) => void;
export declare const startTextEditorDebugTimer: (scope: string, label: string, payload?: unknown) => {
    end(result?: unknown): void;
} | null;
//# sourceMappingURL=debug.d.ts.map