/**
 * Detect if the current platform is macOS
 */
export declare function isMac(): boolean;
/**
 * Format keyboard shortcut for display
 * Converts modifier keys to platform-specific symbols
 *
 * @param shortcut - Shortcut string (e.g., "Mod+B", "Mod+Shift+K")
 * @returns Formatted shortcut string
 *
 * @example
 * ```ts
 * formatShortcut('Mod+B') // => '⌘B' on Mac, 'Ctrl+B' on Windows
 * formatShortcut('Mod+Shift+K') // => '⌘⇧K' on Mac, 'Ctrl+Shift+K' on Windows
 * ```
 */
export declare function formatShortcut(shortcut: string): string;
/**
 * Generate aria-label with optional keyboard shortcut
 *
 * @param label - Base label text
 * @param shortcut - Optional keyboard shortcut
 * @returns Combined aria-label string
 *
 * @example
 * ```ts
 * getAriaLabel('Bold') // => 'Bold'
 * getAriaLabel('Bold', 'Mod+B') // => 'Bold (⌘B)' on Mac
 * ```
 */
export declare function getAriaLabel(label: string, shortcut?: string): string;
/**
 * Create an aria-live region for screen reader announcements
 * Only creates one region per page (singleton pattern)
 *
 * @returns The live region element
 */
export declare function createLiveRegion(): HTMLElement;
/**
 * Remove the live region from DOM
 */
export declare function removeLiveRegion(): void;
/**
 * Announce a message to screen readers via aria-live region
 *
 * @param message - Message to announce
 * @param region - Optional specific region element (uses global if not provided)
 *
 * @example
 * ```ts
 * announce('Bold formatting applied')
 * announce('Link inserted', customRegion)
 * ```
 */
export declare function announce(message: string, region?: HTMLElement): void;
/**
 * Get ARIA pressed state for toggle buttons
 *
 * @param isActive - Whether the toggle is active
 * @returns 'true' | 'false' string for aria-pressed
 */
export declare function getAriaPressed(isActive: boolean): 'true' | 'false';
/**
 * Generate unique ID for ARIA relationships
 *
 * @param prefix - ID prefix
 * @returns Unique ID string
 */
export declare function generateAriaId(prefix: string): string;
/**
 * Common formatting state labels for announcements
 */
export declare const FORMATTING_LABELS: Record<string, {
    on: string;
    off: string;
}>;
/**
 * Get announcement message for formatting state change
 *
 * @param format - Format type (bold, italic, etc.)
 * @param isActive - Whether the format is now active
 * @returns Announcement message
 */
export declare function getFormattingAnnouncement(format: string, isActive: boolean): string;
//# sourceMappingURL=accessibility.d.ts.map