import { Middleware } from '@floating-ui/dom';
/** Steps of the chrome spacing scale (`--text-editor-space-*`). */
export type ChromeSpaceStep = 1 | 2 | 3 | 4 | 5 | 6 | 8;
/**
 * Reads a chrome spacing step in pixels from the element's scope. The steps
 * are registered lengths (style/display-tokens.css), so their computed value
 * is absolute. Without a computed value it falls back to office / 100%.
 */
export declare const readChromeSpace: (element: Element | null | undefined, step: ChromeSpaceStep) => number;
/** Floating UI offset whose anchor gap follows the chrome spacing scale. */
export declare const chromeGap: (step: ChromeSpaceStep) => Middleware;
/** Floating UI shift whose viewport padding follows the chrome spacing scale. */
export declare const chromeShift: (step: ChromeSpaceStep) => Middleware;
//# sourceMappingURL=chrome-space.d.ts.map