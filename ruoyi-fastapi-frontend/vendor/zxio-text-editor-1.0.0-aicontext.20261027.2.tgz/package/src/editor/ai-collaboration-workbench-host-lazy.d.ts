type HostFactory = typeof import('./ai-collaboration-workbench-host')['createAICollaborationWorkbenchCommitHost'];
type CanonicalDocumentReader = typeof import('./ai-collaboration-workbench-host')['readAICollaborationWorkbenchCanonicalDocument'];
export declare const createAICollaborationWorkbenchCommitHost: (input: Parameters<HostFactory>[0]) => Promise<ReturnType<HostFactory>>;
export declare const readAICollaborationWorkbenchCanonicalDocument: (input: Parameters<CanonicalDocumentReader>[0]) => Promise<ReturnType<CanonicalDocumentReader>>;
export {};
//# sourceMappingURL=ai-collaboration-workbench-host-lazy.d.ts.map