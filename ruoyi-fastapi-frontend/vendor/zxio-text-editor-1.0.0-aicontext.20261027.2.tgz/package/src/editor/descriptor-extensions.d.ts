import { ZxExtensionBuildContext, ZxExtensionDescriptor } from '../core/extension-descriptors';
import { AnyExtension } from '@tiptap/core';
type ZxEditorDescriptorBuildContext = Omit<ZxExtensionBuildContext, 'mode'> & {
    mode?: 'editor';
};
export declare const createEditorDescriptorExtensions: (context?: ZxEditorDescriptorBuildContext, descriptors?: readonly ZxExtensionDescriptor[]) => AnyExtension[];
export {};
//# sourceMappingURL=descriptor-extensions.d.ts.map