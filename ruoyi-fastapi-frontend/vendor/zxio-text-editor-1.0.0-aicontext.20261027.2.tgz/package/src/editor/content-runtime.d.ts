import { ZxMarkdownExportMode, ZxTextEditorContentType, ZxTextEditorDocument } from '../document';
import { ZxAnnotationBridgeState, ZxHydratedEditorState, ZxHydrationSource } from '../runtime';
import { Editor as CoreEditor, JSONContent } from '@tiptap/core';
import { ZxExcerptOptions, ZxTextRenderOptions } from '../render';
import { TextEditorRuntimeStatus } from '../runtime/status';
import { StableBlockIdentityCanonicalizationOptions } from '../runtime/stable-block-ids';
interface ValueRef<T> {
    value: T;
}
export interface CreateTextEditorContentRuntimeOptions {
    editor: ValueRef<CoreEditor | null>;
    documentState: ValueRef<ZxTextEditorDocument>;
    annotationBridgeState: ValueRef<ZxAnnotationBridgeState>;
    hasCommentExtension: ValueRef<boolean>;
    isApplyingExternalContent: ValueRef<boolean>;
    getMarkdownExportMode: () => ZxMarkdownExportMode;
    getStableBlockIdentityOptions: () => StableBlockIdentityCanonicalizationOptions;
}
export interface ExportEditorContentValueOptions {
    editor: CoreEditor;
    document?: ZxTextEditorDocument;
    outputType: ZxTextEditorContentType;
}
export interface SetEditorContentOptions {
    contentType?: ZxTextEditorContentType;
}
export interface ZxEditorContentRuntime {
    getCurrentDocument: (editor?: CoreEditor | null) => ZxTextEditorDocument;
    resolveHydratedState: (source: ZxHydrationSource) => ZxHydratedEditorState;
    isHydratedStateSynced: (state: ZxHydratedEditorState) => boolean;
    applyHydratedEditorState: (state: ZxHydratedEditorState) => void;
    exportEditorContentValue: (options: ExportEditorContentValueOptions) => string | JSONContent | ZxTextEditorDocument;
    getHTML: () => string;
    getMarkdown: (options?: {
        mode?: ZxMarkdownExportMode;
    }) => string;
    getJSON: () => JSONContent;
    getDocument: () => ZxTextEditorDocument;
    getText: (options?: ZxTextRenderOptions) => string;
    getExcerpt: (options?: ZxExcerptOptions) => string;
    setContent: (value: unknown, options?: SetEditorContentOptions) => void;
    setHTML: (value: string) => void;
    setMarkdown: (value: string) => void;
    setJSON: (value: JSONContent) => void;
    setDocument: (value: ZxTextEditorDocument) => void;
    getRuntimeStatus: () => TextEditorRuntimeStatus;
}
export declare const createEditorAnnotationBridgeState: (document?: ZxTextEditorDocument) => ZxAnnotationBridgeState;
export declare const createTextEditorContentRuntime: (options: CreateTextEditorContentRuntimeOptions) => ZxEditorContentRuntime;
export {};
//# sourceMappingURL=content-runtime.d.ts.map