import { ZxAISessionReviewArtifactTransferV1 } from '../ai/session-transport';
import { ZxAIReviewSidecarV1, ZxAIReviewCommitResult, ZxAIReviewHistoricalEnvelopeV1 } from '../ai/review-runtime';
import { ZxTextEditorDocument } from '../document/types';
import { Extension } from '@tiptap/core';
import { CollaborationOptions, CollaborationStorage } from '@tiptap/extension-collaboration';
import { ZxAIProposalHistoricalEnvelopeV1 } from '../ai/proposal-branch';
import type * as Y from 'yjs';
export declare const readAICollaborationWorkbenchCanonicalDocument: (input: {
    readonly doc: Y.Doc;
    readonly rootSharedType: string;
    readonly baseDocument: ZxTextEditorDocument;
}) => ZxTextEditorDocument;
export declare const createAICollaborationWorkbenchCommitHost: (input: {
    readonly doc: Y.Doc;
    readonly rootSharedType: string;
    readonly baseDocument: ZxTextEditorDocument;
    readonly transfer: ZxAISessionReviewArtifactTransferV1;
    readonly sidecar: ZxAIReviewSidecarV1;
}) => Readonly<{
    documentGuid: string;
    createVisibleEditorExtension: () => Extension<CollaborationOptions, CollaborationStorage>;
    runS4Commit: () => ZxAIReviewCommitResult;
    createProposalEnvelope: () => ZxAIProposalHistoricalEnvelopeV1;
    createReviewHistoricalEnvelope: (sidecar: ZxAIReviewSidecarV1) => ZxAIReviewHistoricalEnvelopeV1;
    readCanonicalDocument: () => ZxTextEditorDocument;
    destroy(): void;
}>;
//# sourceMappingURL=ai-collaboration-workbench-host.d.ts.map