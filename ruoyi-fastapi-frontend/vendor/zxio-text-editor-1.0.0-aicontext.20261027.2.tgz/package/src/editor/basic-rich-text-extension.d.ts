import { AnyExtension, Extension } from '@tiptap/core';
import { TextEditorContentLimits } from '../core/basic-rich-text';
import { TextEditorContentProfileBoundary } from '../core/content-profile-boundary';
/** Keep the authoritative schema; remove non-profile plugins, rules and views. */
export declare const basicRichTextInteractions: (extension: AnyExtension) => AnyExtension;
export declare function projectBasicRichTextPaste(html: string): {
    html: string;
    dropped: boolean;
};
export declare const createBasicRichTextAdmission: (options: {
    limits?: Partial<TextEditorContentLimits>;
    issue?: (message: string) => void;
}) => Extension<unknown, TextEditorContentProfileBoundary>;
//# sourceMappingURL=basic-rich-text-extension.d.ts.map