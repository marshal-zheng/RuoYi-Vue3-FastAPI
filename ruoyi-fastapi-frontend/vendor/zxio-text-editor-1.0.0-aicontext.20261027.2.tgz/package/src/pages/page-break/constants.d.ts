export declare const ZX_PAGE_BREAK_NODE_NAME = "pageBreak";
export declare const ZX_PAGE_BREAK_DATA_ATTRIBUTE = "data-zx-page-break";
export declare const ZX_PAGE_BREAK_DOM_CLASS: string;
export declare const ZX_PAGE_BREAK_MARKDOWN_SENTINEL = "<!-- zx-page-break -->";
//# sourceMappingURL=constants.d.ts.map