import { Node, CommandProps } from '@tiptap/core';
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        pageBreak: {
            insertPageBreak: () => ReturnType;
        };
    }
}
export declare const insertPageBreakCommand: (props: CommandProps) => boolean;
export declare const TextEditorPageBreakExtension: Node<any, any>;
export default TextEditorPageBreakExtension;
//# sourceMappingURL=extension.d.ts.map