import { Extension, AnyExtension } from '@tiptap/core';
import { ZxDocumentPagesHeaderFooterContract, ZxPagesHeaderFooterDiagnostic, ZxPagesHeaderFooterTarget } from './contract';
import { ZxTextEditorDocument } from '../../document';
export declare const TEXT_EDITOR_PAGES_HEADER_FOOTER_EXTENSION_NAME = "pagesHeaderFooter";
export interface ZxPagesHeaderFooterExtensionOptions {
    getCurrentDocument?: (() => ZxTextEditorDocument | null | undefined) | null;
    initialHeaderFooter?: ZxDocumentPagesHeaderFooterContract | null;
    editable?: boolean | (() => boolean);
    headerFooterExtensions?: readonly AnyExtension[];
    onCloseGuard?: (target: ZxPagesHeaderFooterTarget) => boolean | Promise<boolean>;
}
interface ZxPagesHeaderFooterExtensionStorage {
    diagnostics: ZxPagesHeaderFooterDiagnostic[];
}
export declare const TextEditorPagesHeaderFooterExtension: Extension<ZxPagesHeaderFooterExtensionOptions, ZxPagesHeaderFooterExtensionStorage>;
export {};
//# sourceMappingURL=extension.d.ts.map