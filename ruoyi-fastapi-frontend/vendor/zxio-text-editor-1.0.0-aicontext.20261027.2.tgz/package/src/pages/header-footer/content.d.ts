import { AnyExtension } from '@tiptap/core';
import { ZxPagesHeaderFooterContentValue, ZxPagesHeaderFooterDiagnostic, ZxPagesHeaderFooterInput, ZxPagesHeaderFooterInputFormat, ZxPagesHeaderFooterKind, ZxPagesHeaderFooterSlot } from './contract';
export interface ZxPagesHeaderFooterNormalizeOptions {
    inputFormat?: ZxPagesHeaderFooterInputFormat;
    kind?: ZxPagesHeaderFooterKind;
    slot?: ZxPagesHeaderFooterSlot;
    headerFooterExtensions?: readonly AnyExtension[];
}
export interface ZxPagesHeaderFooterNormalizeResult {
    ok: boolean;
    value?: ZxPagesHeaderFooterContentValue;
    diagnostics: ZxPagesHeaderFooterDiagnostic[];
}
export declare const normalizeHeaderFooterInput: (input: ZxPagesHeaderFooterInput, options?: ZxPagesHeaderFooterNormalizeOptions) => ZxPagesHeaderFooterNormalizeResult;
//# sourceMappingURL=content.d.ts.map