import { JSONContent } from '@tiptap/core';
import { ZxDocumentPageNumberingMode } from '../../document/types';
import { ZxPagesDiagnostic } from '../diagnostics';
export declare const ZX_PAGES_HEADER_FOOTER_SLOTS: readonly ["default", "firstPage", "oddPage", "evenPage"];
export declare const ZX_PAGES_HEADER_FOOTER_KINDS: readonly ["header", "footer"];
export type ZxPagesHeaderFooterKind = 'header' | 'footer';
export type ZxPagesHeaderFooterSlot = 'default' | 'firstPage' | 'oddPage' | 'evenPage';
export type ZxPagesHeaderFooterInputFormat = 'text' | 'html' | 'json';
export type ZxPagesHeaderFooterSetMode = 'set' | 'empty' | 'unset';
export type ZxPagesHeaderFooterInput = string | JSONContent;
export interface ZxPagesHeaderFooterContentValue {
    /**
     * A missing slot key means "unset" and may fallback to default.
     * `{ state: 'empty' }` means the user explicitly cleared the slot.
     */
    state: 'content' | 'empty';
    content?: JSONContent;
}
export type ZxPagesHeaderFooterSlotMap = Partial<Record<ZxPagesHeaderFooterSlot, ZxPagesHeaderFooterContentValue>>;
export interface ZxPagesHeaderFooterSectionOverride {
    sectionId: string;
    startBlockId?: string;
    differentFirstPage?: boolean;
    differentOddEven?: boolean;
    header?: ZxPagesHeaderFooterSlotMap;
    footer?: ZxPagesHeaderFooterSlotMap;
}
export interface ZxDocumentPagesHeaderFooterContract {
    version: 1;
    differentFirstPage: boolean;
    differentOddEven: boolean;
    headerTopMargin?: number;
    footerBottomMargin?: number;
    header?: ZxPagesHeaderFooterSlotMap;
    footer?: ZxPagesHeaderFooterSlotMap;
    sections?: readonly ZxPagesHeaderFooterSectionOverride[];
}
export interface ZxPagesHeaderFooterTarget {
    kind: ZxPagesHeaderFooterKind;
    slot: ZxPagesHeaderFooterSlot;
}
export interface ZxPagesHeaderFooterPageContext {
    pageIndex: number;
    pageNumber?: number | null;
    totalPages?: number | null;
    sectionId?: string | null;
    sectionStartPageIndex?: number | null;
    pageNumbering?: ZxDocumentPageNumberingMode | null;
    layoutReady?: boolean;
    layoutPartial?: boolean;
}
export interface ZxPagesHeaderFooterAnchorRect {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface ZxPagesHeaderFooterActiveEditor extends ZxPagesHeaderFooterTarget, ZxPagesHeaderFooterPageContext {
    anchorRect?: ZxPagesHeaderFooterAnchorRect | null;
    content: ZxPagesHeaderFooterContentValue;
}
export interface ZxPagesHeaderFooterOpenInput {
    pageIndex?: number;
    slot?: ZxPagesHeaderFooterSlot;
}
export interface ZxPagesHeaderFooterSetOptions {
    slot?: ZxPagesHeaderFooterSlot;
    inputFormat?: ZxPagesHeaderFooterInputFormat;
    mode?: ZxPagesHeaderFooterSetMode;
}
export interface ZxPagesResolvedHeaderFooterSlot extends ZxPagesHeaderFooterTarget {
    value: ZxPagesHeaderFooterContentValue | null;
    source: ZxPagesHeaderFooterSlot | null;
    explicitEmpty: boolean;
    fallbackApplied: boolean;
}
export interface ZxPagesResolvedHeaderFooterPair {
    header: ZxPagesResolvedHeaderFooterSlot;
    footer: ZxPagesResolvedHeaderFooterSlot;
}
export interface ZxPagesHeaderFooterCapabilities {
    inlineRich: true;
    complexBlocks: false;
    wholeSlotCollaboration: true;
    fineGrainedCollaboration: false;
}
export type ZxPagesHeaderFooterAvailabilityStatus = 'ready' | 'readonly' | 'unavailable';
export interface ZxPagesHeaderFooterDiagnostic extends ZxPagesDiagnostic {
    kind?: ZxPagesHeaderFooterKind;
    slot?: ZxPagesHeaderFooterSlot;
}
export interface ZxPagesHeaderFooterStorage {
    available: boolean;
    status: ZxPagesHeaderFooterAvailabilityStatus;
    unavailableReason?: string;
    contract: ZxDocumentPagesHeaderFooterContract;
    activeEditor: ZxPagesHeaderFooterActiveEditor | null;
    availableSlots: readonly ZxPagesHeaderFooterSlot[];
    capabilities: ZxPagesHeaderFooterCapabilities;
    diagnostics: ZxPagesHeaderFooterDiagnostic[];
}
export declare const isPagesHeaderFooterKind: (value: unknown) => value is ZxPagesHeaderFooterKind;
export declare const isPagesHeaderFooterSlot: (value: unknown) => value is ZxPagesHeaderFooterSlot;
export declare const createEmptyPagesHeaderFooterContract: () => ZxDocumentPagesHeaderFooterContract;
export declare const clonePagesHeaderFooterContentValue: (value: ZxPagesHeaderFooterContentValue) => ZxPagesHeaderFooterContentValue;
export declare const clonePagesHeaderFooterSlotMap: (value: ZxPagesHeaderFooterSlotMap | undefined) => ZxPagesHeaderFooterSlotMap | undefined;
export declare const normalizeDocumentPagesHeaderFooterContract: (input?: Partial<ZxDocumentPagesHeaderFooterContract> | null | undefined) => ZxDocumentPagesHeaderFooterContract;
export declare const createDocumentPagesHeaderFooterContract: (input?: Partial<ZxDocumentPagesHeaderFooterContract> | null | undefined) => ZxDocumentPagesHeaderFooterContract;
export declare const freezeDocumentPagesHeaderFooterContract: (input?: Partial<ZxDocumentPagesHeaderFooterContract> | null | undefined) => ZxDocumentPagesHeaderFooterContract;
//# sourceMappingURL=contract.d.ts.map