import { Extension } from '@tiptap/core';
import { ZxPagesCurrentPage, ZxPagesLayoutDebugSnapshot, ZxPagesLayoutInvalidationReason, ZxPagesLayoutStatus, ZxPagesOverlayModel, ZxPagesPageBoundary, ZxPagesPageMapEntry } from './layout';
import { ZxDocumentPageOrientation, ZxTextEditorDocument } from '../document';
import { ZxDocumentPagesContract, ZxPagesFormatId, ZxPagesMargins, ZxPagesPageFormat, ZxPagesResolvedPageSettings } from './contract';
import { ZxPagesDiagnostic } from './diagnostics';
import { ZxPagesHeaderFooterInput, ZxPagesHeaderFooterOpenInput, ZxPagesHeaderFooterSetOptions, ZxPagesHeaderFooterStorage } from './header-footer/contract';
import { ZxPagesBlockSafetyStorage } from './block-safety';
export declare const TEXT_EDITOR_PAGES_STORAGE_KEY = "pages";
export interface ZxPagesStorage {
    pageFormat: ZxPagesPageFormat;
    pageSettings: ZxPagesResolvedPageSettings;
    zoom: number;
    pageGap: number;
    pageGapBackground: string;
    layoutStatus: ZxPagesLayoutStatus;
    pageCount: number | null;
    pageMap: readonly ZxPagesPageMapEntry[] | null;
    pageBoundaries: readonly ZxPagesPageBoundary[] | null;
    overlayModel: ZxPagesOverlayModel | null;
    getCurrentPage: () => ZxPagesCurrentPage | null;
    getPagesDebugSnapshot: () => ZxPagesLayoutDebugSnapshot;
    requestLayoutUpdate?: (reason: ZxPagesLayoutInvalidationReason) => void;
    headerFooter?: ZxPagesHeaderFooterStorage;
    blockSafety?: ZxPagesBlockSafetyStorage;
    diagnostics: ZxPagesDiagnostic[];
}
export interface ZxPagesExtensionOptions {
    getCurrentDocument?: (() => ZxTextEditorDocument | null | undefined) | null;
    initialPages?: ZxDocumentPagesContract | null;
    zoom: number;
    pageGap: number;
    pageGapBackground: string;
}
declare module '@tiptap/core' {
    interface Storage {
        pages: ZxPagesStorage;
    }
    interface Commands<ReturnType> {
        pages: {
            setPageFormat: (format: ZxPagesFormatId | ZxPagesPageFormat, options?: {
                orientation?: ZxDocumentPageOrientation;
                margins?: Partial<ZxPagesMargins>;
            }) => ReturnType;
            setZoom: (zoom: number) => ReturnType;
            setPageGap: (gap: number) => ReturnType;
            setPageGapBackground: (background: string) => ReturnType;
            setHeader: (content: ZxPagesHeaderFooterInput, options?: ZxPagesHeaderFooterSetOptions) => ReturnType;
            setFooter: (content: ZxPagesHeaderFooterInput, options?: ZxPagesHeaderFooterSetOptions) => ReturnType;
            setDifferentFirstPage: (value: boolean) => ReturnType;
            setDifferentOddEven: (value: boolean) => ReturnType;
            openHeaderEditor: (input?: ZxPagesHeaderFooterOpenInput) => ReturnType;
            openFooterEditor: (input?: ZxPagesHeaderFooterOpenInput) => ReturnType;
            closeHeaderFooterEditors: () => ReturnType;
        };
    }
}
export declare const TextEditorPagesContractExtension: Extension<ZxPagesExtensionOptions, ZxPagesStorage>;
//# sourceMappingURL=extension.d.ts.map