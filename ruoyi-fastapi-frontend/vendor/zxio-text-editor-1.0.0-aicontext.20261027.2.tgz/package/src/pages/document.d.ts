import { ZxDocumentBinaryExportContract, ZxDocumentMeta, ZxTextEditorDocument } from '../document/types';
import { ZxDocumentPagesContract, ZxDocumentPagesPageRef, ZxDocumentPagesPageSettings, ZxPagesMargins, ZxPagesPageFormat, ZxPagesResolvedPageSettings } from './contract';
import { ZxPagesHeaderFooterContentValue, ZxPagesHeaderFooterKind, ZxPagesHeaderFooterSetMode, ZxPagesHeaderFooterSlot } from './header-footer/contract';
export declare const resolveDocumentPagesPageFormat: (pageFormat: ZxDocumentPagesPageRef, options?: {
    unknownFormatFallback?: ZxPagesPageFormat | null;
}) => ZxPagesPageFormat;
export declare const createDocumentPagesContract: (input?: Partial<ZxDocumentPagesContract>) => ZxDocumentPagesContract;
export declare const normalizeDocumentPagesContract: (documentOrMeta: ZxTextEditorDocument | ZxDocumentMeta) => ZxDocumentPagesContract;
export declare const mergeDocumentPagesDefaults: (current: ZxDocumentPagesContract, patch: Omit<Partial<ZxDocumentPagesPageSettings>, "margins"> & {
    margins?: Partial<ZxPagesMargins>;
}) => ZxDocumentPagesContract;
export declare const mergeDocumentPagesHeaderFooterSlot: (current: ZxDocumentPagesContract, input: {
    kind: ZxPagesHeaderFooterKind;
    slot: ZxPagesHeaderFooterSlot;
    mode?: ZxPagesHeaderFooterSetMode;
    value?: ZxPagesHeaderFooterContentValue;
}) => ZxDocumentPagesContract;
export declare const mergeDocumentPagesHeaderFooterOptions: (current: ZxDocumentPagesContract, patch: {
    differentFirstPage?: boolean;
    differentOddEven?: boolean;
}) => ZxDocumentPagesContract;
export declare const resolveDocumentPagesPageSettings: (settings: ZxDocumentPagesPageSettings) => ZxPagesResolvedPageSettings;
export declare const projectPagesToBinaryExportContract: (pages: ZxDocumentPagesContract) => ZxDocumentBinaryExportContract;
export declare const resolveDocumentPagesForBinaryExport: (document: ZxTextEditorDocument) => ZxDocumentBinaryExportContract | undefined;
//# sourceMappingURL=document.d.ts.map