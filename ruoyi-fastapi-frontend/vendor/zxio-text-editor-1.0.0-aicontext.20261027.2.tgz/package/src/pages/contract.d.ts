import { ZxDocumentBinaryExportSectionIntent, ZxDocumentPageOrientation } from '../document/types';
import { ZxDocumentPagesHeaderFooterContract } from './header-footer';
export type ZxPagesBuiltInFormatId = 'a4' | 'a3' | 'a5' | 'letter' | 'legal' | 'tabloid';
export type ZxPagesFormatId = ZxPagesBuiltInFormatId | (string & {});
export interface ZxPagesMargins {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
export type ZxPagesPageFormatMetadataValue = string | number | boolean;
export interface ZxPagesPageFormat {
    id: ZxPagesFormatId;
    label: string;
    /** Page width in CSS pixels. */
    width: number;
    /** Page height in CSS pixels. */
    height: number;
    /** Default page margins in CSS pixels. */
    defaultMargins: ZxPagesMargins;
    metadata?: Record<string, ZxPagesPageFormatMetadataValue>;
}
export interface ZxDocumentPagesPageRef {
    id: ZxPagesFormatId;
    label?: string;
    /** Custom page width in CSS pixels. */
    width?: number;
    /** Custom page height in CSS pixels. */
    height?: number;
}
export interface ZxDocumentPagesPageSettings {
    pageFormat: ZxDocumentPagesPageRef;
    orientation: ZxDocumentPageOrientation;
    /** Page margins in CSS pixels. */
    margins: ZxPagesMargins;
}
export interface ZxDocumentPagesSectionDefinition {
    id: string;
    startBlockId: string;
    page?: Partial<ZxDocumentPagesPageSettings>;
    intent?: ZxDocumentBinaryExportSectionIntent;
}
export interface ZxDocumentPagesContract {
    version: 1;
    defaults: {
        page: ZxDocumentPagesPageSettings;
        intent?: ZxDocumentBinaryExportSectionIntent;
    };
    sections?: readonly ZxDocumentPagesSectionDefinition[];
    headerFooter?: ZxDocumentPagesHeaderFooterContract;
}
export interface ZxPagesResolvedPageSettings extends ZxDocumentPagesPageSettings {
    pageFormat: ZxPagesPageFormat;
}
//# sourceMappingURL=contract.d.ts.map