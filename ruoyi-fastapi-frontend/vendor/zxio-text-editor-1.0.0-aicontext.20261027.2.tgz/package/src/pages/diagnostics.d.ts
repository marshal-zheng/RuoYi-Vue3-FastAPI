export type ZxPagesDiagnosticSeverity = 'info' | 'warning' | 'error';
export type ZxPagesDiagnosticCode = 'pages.format.unknown' | 'pages.format.invalid' | 'pages.unit.invalid' | 'pages.margins.invalid' | 'pages.command.invalid' | 'pages.headerFooter.contract-missing' | 'pages.headerFooter.content-invalid' | 'pages.headerFooter.content-unsupported' | 'pages.headerFooter.html-parse-failed' | 'pages.headerFooter.link-unsafe' | 'pages.headerFooter.placeholder-hidden' | 'pages.headerFooter.placeholder-unresolved' | 'pages.headerFooter.readonly' | 'pages.headerFooter.schema-incompatible' | 'pages.headerFooter.slot-invalid' | 'pages.headerFooter.slot-unsupported' | 'pages.headerFooter.unavailable' | 'pages.pageBreak.command-invalid' | 'pages.pageBreak.schema-missing' | 'pages.pageBreak.readonly' | 'pages.blockSafety.unknown' | 'pages.blockSafety.unsupported' | 'pages.blockSafety.table-non-splittable' | 'pages.blockSafety.async-sized' | 'pages.blockSafety.export-fidelity-risk' | 'pages.layout.contract-missing' | 'pages.layout.dom-missing' | 'pages.layout.measurement-failed' | 'pages.layout.block-identity-missing' | 'pages.layout.block-oversize' | 'pages.layout.block-unsupported' | 'pages.layout.loop-guard' | 'pages.layout.performance-budget' | 'pages.layout.page-settings-invalid' | 'pages.layout.destroyed';
export interface ZxPagesDiagnostic {
    code: ZxPagesDiagnosticCode;
    severity: ZxPagesDiagnosticSeverity;
    message: string;
    target?: string;
    path?: string;
    recoveryHint?: string;
    blockId?: string;
    pos?: number;
    nodeType?: string;
}
export declare class ZxPagesContractError extends Error {
    readonly diagnostic: ZxPagesDiagnostic;
    constructor(diagnostic: ZxPagesDiagnostic);
}
export declare const createPagesDiagnostic: (diagnostic: ZxPagesDiagnostic) => ZxPagesDiagnostic;
export declare const pushPagesDiagnostic: (diagnostics: ZxPagesDiagnostic[], diagnostic: ZxPagesDiagnostic) => void;
export declare const createPagesContractError: (diagnostic: ZxPagesDiagnostic) => ZxPagesContractError;
export declare const isZxPagesContractError: (value: unknown) => value is ZxPagesContractError;
//# sourceMappingURL=diagnostics.d.ts.map