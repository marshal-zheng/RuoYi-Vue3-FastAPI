import { ZxPagesBuiltInFormatId, ZxPagesFormatId, ZxPagesMargins, ZxPagesPageFormat } from './contract';
export declare const ZX_PAGES_BUILT_IN_FORMATS: ReadonlyMap<ZxPagesBuiltInFormatId, ZxPagesPageFormat>;
export declare const isZxPagesBuiltInFormatId: (id: ZxPagesFormatId) => id is ZxPagesBuiltInFormatId;
export declare const getZxPagesPageFormat: (id: ZxPagesFormatId) => ZxPagesPageFormat | null;
export declare const validateZxPagesMargins: (margins: ZxPagesMargins, page: Pick<ZxPagesPageFormat, "width" | "height">) => ZxPagesMargins;
export declare const normalizeZxPagesPageFormat: (value: ZxPagesFormatId | ZxPagesPageFormat) => ZxPagesPageFormat;
export declare const createZxPagesMargins: (margins?: Partial<ZxPagesMargins>, fallback?: ZxPagesMargins) => ZxPagesMargins;
//# sourceMappingURL=formats.d.ts.map