import { Extension } from '@tiptap/core';
import { ZxPagesBlockSafetyRule, ZxPagesBlockSafetyRuleOverride, ZxPagesBlockSafetySnapshot } from './types';
import { ZxPagesDiagnostic } from '../diagnostics';
export interface ZxPagesBlockSafetyExtensionOptions {
    rules?: readonly ZxPagesBlockSafetyRuleOverride[];
}
export interface ZxPagesBlockSafetyStorage {
    registry: ZxPagesBlockSafetySnapshot;
    diagnostics: readonly ZxPagesDiagnostic[];
    resolveRule: (nodeType: string) => ZxPagesBlockSafetyRule;
}
declare module '@tiptap/core' {
    interface Storage {
        pagesBlockSafety?: ZxPagesBlockSafetyStorage;
    }
}
export declare const TextEditorPagesBlockSafetyExtension: Extension<ZxPagesBlockSafetyExtensionOptions, ZxPagesBlockSafetyStorage>;
export default TextEditorPagesBlockSafetyExtension;
//# sourceMappingURL=extension.d.ts.map