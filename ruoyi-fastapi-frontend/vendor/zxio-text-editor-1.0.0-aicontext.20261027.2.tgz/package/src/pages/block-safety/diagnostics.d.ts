import { ZxPagesDiagnostic } from '../diagnostics';
import { ZxPagesBlockSafetyRule } from './types';
export interface CreatePagesBlockSafetyDiagnosticOptions {
    blockId?: string;
    pos?: number;
    target?: string;
    pageIndex?: number;
    message?: string;
    recoveryHint?: string;
}
export declare const createPagesBlockSafetyDiagnostic: (rule: ZxPagesBlockSafetyRule, options?: CreatePagesBlockSafetyDiagnosticOptions) => ZxPagesDiagnostic;
//# sourceMappingURL=diagnostics.d.ts.map