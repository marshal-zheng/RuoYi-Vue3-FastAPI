import { Editor } from '@tiptap/core';
import { ZxPagesDiagnostic } from '../diagnostics';
import { ZxPagesMeasuredBlock } from './pagination';
import { ZxPagesTopLevelFlowBlock } from './top-level-blocks';
export interface ZxPagesViewportSnapshot {
    scrollTop: number;
    scrollLeft: number;
    viewportHeight: number;
    viewportWidth: number;
}
export interface ZxPagesLayoutAdapter {
    getContentRoot: () => HTMLElement | null;
    getScrollContainer: () => HTMLElement | Window | null;
    getOverlayHost?: () => HTMLElement | null;
    getViewportSnapshot?: () => ZxPagesViewportSnapshot | null;
    resolveBlockElement?: (block: ZxPagesTopLevelFlowBlock) => HTMLElement | null;
    onDebugEvent?: (event: ZxPagesLayoutDebugEvent) => void;
}
export interface ZxPagesLayoutDebugEvent {
    type: 'scheduled' | 'measured' | 'current-page' | 'diagnostic' | 'destroyed';
    payload?: Record<string, unknown>;
}
export interface ZxPagesMeasurementContext {
    blocks: readonly ZxPagesTopLevelFlowBlock[];
    contentRoot: HTMLElement;
}
export interface ZxPagesMeasurementResult {
    blocks: readonly ZxPagesMeasuredBlock[];
    diagnostics: readonly ZxPagesDiagnostic[];
}
export type ZxPagesMeasurementProvider = (context: ZxPagesMeasurementContext) => ZxPagesMeasurementResult | Promise<ZxPagesMeasurementResult>;
export declare const isPagesLayoutHTMLElement: (value: unknown) => value is HTMLElement;
export declare const createDefaultPagesLayoutAdapter: (editor: Editor) => ZxPagesLayoutAdapter;
export declare const measureTopLevelFlowBlocks: ZxPagesMeasurementProvider;
//# sourceMappingURL=adapter.d.ts.map