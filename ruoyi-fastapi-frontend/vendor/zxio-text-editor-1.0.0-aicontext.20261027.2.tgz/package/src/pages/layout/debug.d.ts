import { ZxPagesDiagnostic } from '../diagnostics';
import { ZxPagesLayoutMetrics } from './metrics';
import { ZxPagesPageMapEntry, ZxPagesMeasuredBlock } from './pagination';
import { ZxPagesDirtyRange, ZxPagesSchedulerSnapshot } from './scheduler';
import { ZxPagesLayoutStatus } from './storage';
export interface ZxPagesLayoutDebugSnapshot {
    status: ZxPagesLayoutStatus;
    metrics: ZxPagesLayoutMetrics | null;
    measuredBlocks: readonly ZxPagesMeasuredBlock[];
    dirtyRange: ZxPagesDirtyRange | null;
    scheduler: ZxPagesSchedulerSnapshot;
    diagnostics: readonly ZxPagesDiagnostic[];
    pageMap: readonly ZxPagesPageMapEntry[];
}
export declare const createPagesLayoutDebugSnapshot: (snapshot: ZxPagesLayoutDebugSnapshot) => ZxPagesLayoutDebugSnapshot;
//# sourceMappingURL=debug.d.ts.map