import { Extension, Editor } from '@tiptap/core';
import { ZxPagesLayoutAdapter, ZxPagesMeasurementProvider } from './adapter';
import { ZxPagesDirtyRange, ZxPagesLayoutInvalidationReason, ZxPagesLayoutScheduler } from './scheduler';
import { ZxPagesLayoutStatus } from './storage';
import { Transaction } from '@tiptap/pm/state';
import { ZxPagesDiagnostic } from '../diagnostics';
export interface ZxPagesLayoutExtensionOptions {
    adapter?: ZxPagesLayoutAdapter | null;
    scheduler?: ZxPagesLayoutScheduler | null;
    measurement?: ZxPagesMeasurementProvider | null;
    diagnosticsLimit?: number;
    maxSynchronousBlocks?: number;
    pageWindow?: {
        before: number;
        after: number;
    };
    debug?: boolean;
}
declare class PagesLayoutController {
    private readonly editor;
    private readonly options;
    private readonly adapter;
    private readonly measurement;
    private readonly scheduler;
    private readonly loopGuard;
    private readonly cleanupCallbacks;
    private destroyed;
    private state;
    constructor(editor: Editor, options: ZxPagesLayoutExtensionOptions);
    install(): void;
    invalidate(reason: ZxPagesLayoutInvalidationReason, dirtyRange?: ZxPagesDirtyRange | null): void;
    handleTransaction(transaction: Transaction): void;
    destroy(): void;
    private measure;
    private updateVisualState;
    private updateCurrentPage;
    private resolveCurrentPage;
    private setStatus;
    private pushDiagnostics;
    private writeStorage;
    private createDebugSnapshot;
    private attachDomListeners;
}
declare module '@tiptap/core' {
    interface Storage {
        pagesLayout?: {
            controller: PagesLayoutController | null;
            layoutStatus: ZxPagesLayoutStatus;
            diagnostics: readonly ZxPagesDiagnostic[];
        };
    }
}
export declare const TextEditorPagesLayoutExtension: Extension<ZxPagesLayoutExtensionOptions, any>;
export {};
//# sourceMappingURL=extension.d.ts.map