/**
 * Collaboration Module
 *
 * Provides real-time collaboration capabilities for the text editor.
 * Uses YJS for CRDT-based conflict resolution.
 */
export type { YDoc, YXmlFragment, YText, YArray, YMap, CollaborationProvider, Awareness, CollaborationUser, ConnectedUser, AuthConfig, AuthError, AuthErrorCode, AuthenticatedProvider, ConnectionStatus, ReconnectConfig, SnapshotStorage, SnapshotData, SnapshotDiff, UndoManagerOptions, UndoManagerInstance, } from './types';
export { createWebRTCProvider } from './webrtc-provider';
export type { WebRTCProviderOptions } from './webrtc-provider';
export { createWebSocketProvider } from './websocket-provider';
export type { WebSocketProviderOptions } from './websocket-provider';
export { createSnapshotManager } from './snapshot';
export type { Snapshot, SnapshotManagerOptions, SnapshotManager, } from './snapshot';
export { createUndoManager, createUndoManagerFromProvider, } from './undo-manager';
//# sourceMappingURL=index.d.ts.map