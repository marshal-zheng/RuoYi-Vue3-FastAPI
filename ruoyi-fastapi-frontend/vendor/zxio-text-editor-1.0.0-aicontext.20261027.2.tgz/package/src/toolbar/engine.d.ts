import { EditorLike } from '../types';
import { TextEditorToolbarItemContext, TextEditorToolbarItemDefinition, TextEditorToolbarItemState, TextEditorToolbarItemValue, TextEditorToolbarStateSnapshot, TextEditorToolbarSurface } from './schema';
import { TextEditorToolbarContribution, TextEditorToolbarRegisteredItem, TextEditorToolbarRegistry } from './registry';
export interface TextEditorToolbarResolvedItem {
    contributionId: string;
    definition: Readonly<TextEditorToolbarItemDefinition>;
    resolved: Readonly<TextEditorToolbarItemState>;
}
export interface TextEditorToolbarPreparedSurface {
    surface: TextEditorToolbarSurface;
    items: readonly TextEditorToolbarRegisteredItem[];
}
export interface TextEditorToolbarSurfaceSnapshot {
    surface: TextEditorToolbarSurface;
    state: Readonly<TextEditorToolbarStateSnapshot>;
    items: readonly TextEditorToolbarResolvedItem[];
}
export interface ResolveTextEditorToolbarSurfaceOptions {
    editor?: EditorLike | null;
    state?: TextEditorToolbarStateSnapshot;
    includeHidden?: boolean;
    filter?: (item: TextEditorToolbarRegisteredItem, context: TextEditorToolbarItemContext) => boolean;
}
export interface ResolveTextEditorToolbarPreparedSurfaceOptions {
    editor?: EditorLike | null;
    state?: TextEditorToolbarStateSnapshot;
    includeHidden?: boolean;
}
export interface CreateTextEditorToolbarEngineOptions {
    contributions?: TextEditorToolbarContribution[];
    registry?: TextEditorToolbarRegistry;
}
export interface TextEditorToolbarEngine {
    registry: TextEditorToolbarRegistry;
    registerContribution(contribution: TextEditorToolbarContribution): () => void;
    resolveState(editor?: EditorLike | null): TextEditorToolbarStateSnapshot;
    prepareSurface(surface: TextEditorToolbarSurface, options?: ResolveTextEditorToolbarSurfaceOptions): TextEditorToolbarPreparedSurface;
    resolvePreparedSurface(preparedSurface: TextEditorToolbarPreparedSurface, options?: ResolveTextEditorToolbarPreparedSurfaceOptions): TextEditorToolbarSurfaceSnapshot;
    resolveSurface(surface: TextEditorToolbarSurface, options?: ResolveTextEditorToolbarSurfaceOptions): TextEditorToolbarSurfaceSnapshot;
}
export declare const resolveTextEditorToolbarItemState: <TValue extends TextEditorToolbarItemValue>(definition: TextEditorToolbarItemDefinition, context: TextEditorToolbarItemContext) => TextEditorToolbarItemState<TValue>;
export declare const prepareTextEditorToolbarSurface: (surface: TextEditorToolbarSurface, registry?: TextEditorToolbarRegistry, options?: ResolveTextEditorToolbarSurfaceOptions) => TextEditorToolbarPreparedSurface;
export declare const resolveTextEditorToolbarPreparedSurface: (preparedSurface: TextEditorToolbarPreparedSurface, options?: ResolveTextEditorToolbarPreparedSurfaceOptions) => TextEditorToolbarSurfaceSnapshot;
export declare const resolveTextEditorToolbarSurface: (surface: TextEditorToolbarSurface, registry?: TextEditorToolbarRegistry, options?: ResolveTextEditorToolbarSurfaceOptions) => TextEditorToolbarSurfaceSnapshot;
export declare const createTextEditorToolbarEngine: (options?: CreateTextEditorToolbarEngineOptions) => TextEditorToolbarEngine;
//# sourceMappingURL=engine.d.ts.map