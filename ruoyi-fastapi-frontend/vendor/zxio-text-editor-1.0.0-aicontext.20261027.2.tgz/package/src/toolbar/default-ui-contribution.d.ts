import { CreateDefaultTextEditorToolbarContributionOptions } from './default-contribution';
import { TextEditorToolbarContribution } from './registry';
/** Renderer assembly belongs to the UI facet; the core contribution stays data-only. */
export declare const createDefaultTextEditorToolbarUIContribution: (options?: CreateDefaultTextEditorToolbarContributionOptions) => TextEditorToolbarContribution;
//# sourceMappingURL=default-ui-contribution.d.ts.map