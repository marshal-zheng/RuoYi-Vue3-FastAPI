import { EditorLike } from '../types';
export type TextEditorToolbarColorMode = 'text' | 'highlight';
export interface TextEditorToolbarFontFamilyOption {
    label: string;
    value: string;
}
export declare const TEXT_EDITOR_TOOLBAR_FONT_SIZE_OPTIONS: readonly ["9px", "10px", "10.5px", "11px", "12px", "14px", "16px", "18px", "20px", "22px", "24px", "26px", "28px", "36px", "42px", "48px", "72px"];
export declare const TEXT_EDITOR_TOOLBAR_FONT_FAMILY_OPTIONS: readonly [{
    readonly label: "宋体";
    readonly value: "SimSun, serif";
}, {
    readonly label: "黑体";
    readonly value: "SimHei, sans-serif";
}, {
    readonly label: "微软雅黑";
    readonly value: "Microsoft YaHei, sans-serif";
}, {
    readonly label: "Arial";
    readonly value: "Arial, sans-serif";
}, {
    readonly label: "Times New Roman";
    readonly value: "Times New Roman, serif";
}, {
    readonly label: "Courier New";
    readonly value: "Courier New, monospace";
}];
export declare const TEXT_EDITOR_TOOLBAR_TEXT_COLOR_SWATCHES: readonly ["#000000", "#434343", "#666666", "#999999", "#b7b7b7", "#cccccc", "#d9d9d9", "#efefef", "#f3f3f3", "#ffffff", "#980000", "#ff0000", "#ff9900", "#ffff00", "#00ff00", "#00ffff", "#4a86e8", "#0000ff", "#9900ff", "#ff00ff", "#e6b8af", "#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#c9daf8", "#cfe2f3", "#d9d2e9", "#ead1dc", "#dd7e6b", "#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#a4c2f4", "#9fc5e8", "#b4a7d6", "#d5a6bd", "#cc4125", "#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6d9eeb", "#6fa8dc", "#8e7cc3", "#c27ba0", "#a61c00", "#cc0000", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3c78d8", "#3d85c6", "#674ea7", "#a64d79", "#85200c", "#990000", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#1155cc", "#0b5394", "#351c75", "#741b47", "#5b0f00", "#660000", "#783f04", "#7f6000", "#274e13", "#0c343d", "#1c4587", "#073763", "#20124d", "#4c1130"];
export declare const TEXT_EDITOR_TOOLBAR_HIGHLIGHT_COLOR_SWATCHES: readonly ["#000000", "#434343", "#666666", "#999999", "#b7b7b7", "#cccccc", "#d9d9d9", "#efefef", "#f3f3f3", "#ffffff", "#980000", "#ff0000", "#ff9900", "#ffff00", "#00ff00", "#00ffff", "#4a86e8", "#0000ff", "#9900ff", "#ff00ff", "#e6b8af", "#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#c9daf8", "#cfe2f3", "#d9d2e9", "#ead1dc", "#dd7e6b", "#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#a4c2f4", "#9fc5e8", "#b4a7d6", "#d5a6bd", "#cc4125", "#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6d9eeb", "#6fa8dc", "#8e7cc3", "#c27ba0", "#a61c00", "#cc0000", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3c78d8", "#3d85c6", "#674ea7", "#a64d79", "#85200c", "#990000", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#1155cc", "#0b5394", "#351c75", "#741b47", "#5b0f00", "#660000", "#783f04", "#7f6000", "#274e13", "#0c343d", "#1c4587", "#073763", "#20124d", "#4c1130"];
export declare const TEXT_EDITOR_TOOLBAR_TEXT_COLOR_NAME_TO_HEX: Readonly<Record<string, string>>;
export declare const TEXT_EDITOR_TOOLBAR_HIGHLIGHT_COLOR_NAME_TO_HEX: Readonly<Record<string, string>>;
export declare const normalizeTextEditorToolbarColorValue: (raw: unknown, mode: TextEditorToolbarColorMode) => string | null;
export declare const setTextEditorToolbarLastHighlightColor: (color: string) => void;
export declare const getTextEditorToolbarColorIndicator: (editor: EditorLike, mode: TextEditorToolbarColorMode) => string;
export declare const applyTextEditorToolbarColorValue: (editor: EditorLike | null, options: {
    mode: TextEditorToolbarColorMode;
    value: string;
    selection?: {
        from: number;
        to: number;
    } | null;
}) => boolean;
export declare const clearTextEditorToolbarColorValue: (editor: EditorLike | null, options: {
    mode: TextEditorToolbarColorMode;
    selection?: {
        from: number;
        to: number;
    } | null;
}) => boolean;
//# sourceMappingURL=default-controls.d.ts.map