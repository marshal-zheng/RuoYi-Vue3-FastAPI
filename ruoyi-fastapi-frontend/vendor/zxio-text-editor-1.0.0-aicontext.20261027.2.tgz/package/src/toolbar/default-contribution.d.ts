import { TextEditorToolbarContribution } from './registry';
import { TextEditorToolbarCustomItemDefinition } from './schema';
export declare const TEXT_EDITOR_TOOLBAR_BLOCK_STYLE_OPTIONS: readonly [{
    readonly id: "paragraph";
    readonly label: "Normal";
    readonly value: "paragraph";
}, {
    readonly id: "heading-1";
    readonly label: "Heading 1";
    readonly value: "heading-1";
}, {
    readonly id: "heading-2";
    readonly label: "Heading 2";
    readonly value: "heading-2";
}, {
    readonly id: "heading-3";
    readonly label: "Heading 3";
    readonly value: "heading-3";
}, {
    readonly id: "heading-4";
    readonly label: "Heading 4";
    readonly value: "heading-4";
}, {
    readonly id: "heading-5";
    readonly label: "Heading 5";
    readonly value: "heading-5";
}, {
    readonly id: "heading-6";
    readonly label: "Heading 6";
    readonly value: "heading-6";
}, {
    readonly id: "bullet-list";
    readonly label: "Bulleted list";
    readonly value: "bullet-list";
}, {
    readonly id: "ordered-list";
    readonly label: "Numbered list";
    readonly value: "ordered-list";
}, {
    readonly id: "task-list";
    readonly label: "Checklist";
    readonly value: "task-list";
}, {
    readonly id: "blockquote";
    readonly label: "Blockquote";
    readonly value: "blockquote";
}, {
    readonly id: "code-block";
    readonly label: "Code block";
    readonly value: "code-block";
}];
export interface CreateDefaultTextEditorToolbarContributionOptions {
    id?: string;
    renderers?: Partial<Record<'insert.link' | 'insert.image' | 'insert.video' | 'insert.iframe' | 'table.menu', TextEditorToolbarCustomItemDefinition['render']>>;
}
export declare const createDefaultTextEditorToolbarContribution: (options?: CreateDefaultTextEditorToolbarContributionOptions) => TextEditorToolbarContribution;
//# sourceMappingURL=default-contribution.d.ts.map