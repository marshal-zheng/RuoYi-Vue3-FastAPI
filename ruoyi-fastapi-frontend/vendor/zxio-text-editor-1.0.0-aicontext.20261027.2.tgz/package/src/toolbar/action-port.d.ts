import { ActionPort, ActionState, Disposer } from '@zxio/keybindings/core';
import { TextEditorToolbarItemContext, TextEditorToolbarItemDefinition } from './schema';
export interface TextEditorToolbarActionPortOptions {
    getDefinition(): Readonly<TextEditorToolbarItemDefinition> | null;
    getContext(): TextEditorToolbarItemContext;
    subscribe(listener: () => void): Disposer;
}
export declare const getTextEditorToolbarActionState: (definition: Readonly<TextEditorToolbarItemDefinition> | null, context: TextEditorToolbarItemContext) => ActionState;
/** The renderer and public port call the same qualified domain entry point. */
export declare const runTextEditorToolbarAction: (definition: Readonly<TextEditorToolbarItemDefinition> | null, context: TextEditorToolbarItemContext) => void | Promise<void>;
export declare const createTextEditorToolbarActionPort: (options: TextEditorToolbarActionPortOptions) => ActionPort<undefined, void>;
//# sourceMappingURL=action-port.d.ts.map