import { JSONContent } from '@tiptap/core';
import { ZxMarkdownExportMode } from '../document';
import { ZxCodeBlockDiagnostic } from '../code-block';
import { ZxMarkdownRegistry } from './registry';
export interface ZxMarkdownCodecOptions {
    registry?: ZxMarkdownRegistry;
    mode?: ZxMarkdownExportMode;
    diagnostics?: ZxCodeBlockDiagnostic[];
}
export declare const parseMarkdown: (markdown: string, options?: ZxMarkdownCodecOptions) => JSONContent;
export declare const serializeMarkdown: (content: JSONContent, options?: ZxMarkdownCodecOptions) => string;
//# sourceMappingURL=codec.d.ts.map