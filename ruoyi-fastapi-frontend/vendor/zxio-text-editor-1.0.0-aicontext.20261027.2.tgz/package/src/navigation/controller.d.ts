import { CreateNavigationControllerOptions, TextEditorNavigationController } from './types';
export declare const createTextEditorNavigationController: (options?: CreateNavigationControllerOptions) => TextEditorNavigationController;
//# sourceMappingURL=controller.d.ts.map