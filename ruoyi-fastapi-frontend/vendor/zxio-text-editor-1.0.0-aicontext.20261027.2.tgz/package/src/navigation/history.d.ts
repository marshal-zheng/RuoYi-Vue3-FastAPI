import { NavigationHistoryAdapter, NavigationTarget, ShareableNavigationTarget } from './types';
export declare const createNavigationFragment: (target: NavigationTarget) => string | null;
export declare const parseNavigationFragment: (fragment: string | null | undefined) => ShareableNavigationTarget | null;
export declare const getNavigationFragmentFromLocation: (fragment?: string) => string | null;
export declare const createBrowserNavigationHistoryAdapter: () => NavigationHistoryAdapter;
//# sourceMappingURL=history.d.ts.map