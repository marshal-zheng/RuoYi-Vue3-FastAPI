import { NavigationDebugSnapshot, NavigationSnapshot, NavigationTarget } from './types';
export declare const formatNavigationTarget: (target: NavigationTarget | null | undefined) => string | null;
export declare const createNavigationDebugSnapshot: (snapshot: NavigationSnapshot) => NavigationDebugSnapshot;
//# sourceMappingURL=debug.d.ts.map