import { ZxTextAnchor } from '../../document/types';
import { EphemeralNavigationTarget, NavigationTargetProvider } from '../types';
export interface EphemeralNavigationRecord<TKind extends EphemeralNavigationTarget['kind'] = EphemeralNavigationTarget['kind']> {
    kind: TKind;
    id: string;
    label: string;
    blockId?: string;
    offset?: number;
    anchor?: ZxTextAnchor;
    dom?: HTMLElement | null;
    pos?: number;
    selection?: {
        from: number;
        to: number;
    };
}
export interface CreateEphemeralNavigationProviderOptions<TKind extends EphemeralNavigationTarget['kind']> {
    kind: TKind;
    getEntries: (() => readonly EphemeralNavigationRecord<TKind>[] | null | undefined) | (() => Promise<readonly EphemeralNavigationRecord<TKind>[] | null | undefined>);
}
type EphemeralTargetOfKind<TKind extends EphemeralNavigationTarget['kind']> = Extract<EphemeralNavigationTarget, {
    kind: TKind;
}>;
export declare const createEphemeralNavigationProvider: <TKind extends EphemeralNavigationTarget["kind"]>({ kind, getEntries, }: CreateEphemeralNavigationProviderOptions<TKind>) => NavigationTargetProvider<EphemeralTargetOfKind<TKind>>;
export {};
//# sourceMappingURL=ephemeral-provider.d.ts.map