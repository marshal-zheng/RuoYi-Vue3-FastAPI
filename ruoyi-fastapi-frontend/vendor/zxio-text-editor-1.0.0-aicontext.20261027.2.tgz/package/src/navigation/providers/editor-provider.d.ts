import { NavigationTarget, NavigationTargetProvider } from '../types';
type EditorNavigationTarget = Extract<NavigationTarget, {
    kind: 'heading' | 'block' | 'range';
}>;
export declare const createEditorNavigationProvider: () => NavigationTargetProvider<EditorNavigationTarget>;
export declare const createEditorNavigationProviders: () => Array<NavigationTargetProvider<EditorNavigationTarget>>;
export {};
//# sourceMappingURL=editor-provider.d.ts.map