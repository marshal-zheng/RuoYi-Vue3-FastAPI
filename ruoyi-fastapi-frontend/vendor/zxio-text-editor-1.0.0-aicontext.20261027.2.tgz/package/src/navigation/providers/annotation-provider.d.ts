import { NavigationTargetProvider, NavigationTarget } from '../types';
export declare const createAnnotationNavigationProvider: () => NavigationTargetProvider<Extract< NavigationTarget, {
    kind: "annotation";
}>>;
//# sourceMappingURL=annotation-provider.d.ts.map