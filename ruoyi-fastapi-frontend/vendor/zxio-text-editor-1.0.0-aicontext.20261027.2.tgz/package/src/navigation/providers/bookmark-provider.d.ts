import { ZxTextAnchor } from '../../document/types';
import { NavigationTargetProvider, NavigationTarget } from '../types';
export interface NavigationBookmarkRecord {
    bookmarkId: string;
    label: string;
    blockId?: string;
    offset?: number;
    anchor?: ZxTextAnchor;
    dom?: HTMLElement | null;
    pos?: number;
    selection?: {
        from: number;
        to: number;
    };
}
export interface CreateBookmarkNavigationProviderOptions {
    getBookmarks: (() => readonly NavigationBookmarkRecord[] | null | undefined) | (() => Promise<readonly NavigationBookmarkRecord[] | null | undefined>);
}
export declare const createBookmarkNavigationProvider: ({ getBookmarks, }: CreateBookmarkNavigationProviderOptions) => NavigationTargetProvider<Extract< NavigationTarget, {
    kind: "bookmark";
}>>;
//# sourceMappingURL=bookmark-provider.d.ts.map