import { a as sn, d as D, s as Y, Z as q, b as on, c as xe } from "./definition-DiwrtpbT.mjs";
const ke = D({
  maxBytes: 2e6,
  maxDepth: 128,
  maxArrayEntries: 5e4,
  maxObjectKeys: 1024,
  maxTotalObjectKeys: 3e5,
  maxComponents: 256,
  maxDependencies: 1024,
  maxNodes: 5e4,
  maxMarks: 2e5,
  maxPlugins: 128,
  maxSteps: 1e4,
  maxReaderEntries: 64
}), Fe = {
  id: "zx.text-editor.execution-resource-profile",
  version: "1.0.0",
  limits: ke
};
D({
  id: Fe.id,
  version: Fe.version,
  fingerprint: Y(Fe),
  dependencies: []
});
const wt = (r) => sn(r, ke), Ye = (r, e) => {
  if (e <= 0 || e >= r.length) return !1;
  const t = r.charCodeAt(e - 1), n = r.charCodeAt(e);
  return t >= 55296 && t <= 56319 && n >= 56320 && n <= 57343;
}, an = (r, e, t) => {
  const n = [...r].sort((c, p) => c.order - p.order), i = new Map(
    n.map((c, p) => [c.blockId, p])
  );
  if (i.size !== n.length || new Set(n.map((c) => c.order)).size !== n.length)
    return null;
  const s = i.get(e.blockId), o = i.get(t.blockId);
  if (s === void 0 || o === void 0 || s > o)
    return null;
  const a = n[s], l = n[o];
  return !Number.isInteger(e.offset) || !Number.isInteger(t.offset) || e.offset < 0 || t.offset < 0 || e.offset > a.text.length || t.offset > l.text.length || Ye(a.text, e.offset) || Ye(l.text, t.offset) || s === o && e.offset >= t.offset ? null : {
    quote: s === o ? a.text.slice(e.offset, t.offset) : n.slice(s, o + 1).map((c, p, f) => {
      const d = p === 0 ? e.offset : 0, u = p === f.length - 1 ? t.offset : c.text.length;
      return c.text.slice(d, u);
    }).join(`
`),
    before: a.text.slice(0, e.offset),
    after: l.text.slice(t.offset)
  };
};
function A(r) {
  this.content = r;
}
A.prototype = {
  constructor: A,
  find: function(r) {
    for (var e = 0; e < this.content.length; e += 2)
      if (this.content[e] === r) return e;
    return -1;
  },
  // :: (string) → ?any
  // Retrieve the value stored under `key`, or return undefined when
  // no such key exists.
  get: function(r) {
    var e = this.find(r);
    return e == -1 ? void 0 : this.content[e + 1];
  },
  // :: (string, any, ?string) → OrderedMap
  // Create a new map by replacing the value of `key` with a new
  // value, or adding a binding to the end of the map. If `newKey` is
  // given, the key of the binding will be replaced with that key.
  update: function(r, e, t) {
    var n = t && t != r ? this.remove(t) : this, i = n.find(r), s = n.content.slice();
    return i == -1 ? s.push(t || r, e) : (s[i + 1] = e, t && (s[i] = t)), new A(s);
  },
  // :: (string) → OrderedMap
  // Return a map with the given key removed, if it existed.
  remove: function(r) {
    var e = this.find(r);
    if (e == -1) return this;
    var t = this.content.slice();
    return t.splice(e, 2), new A(t);
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the start of the map.
  addToStart: function(r, e) {
    return new A([r, e].concat(this.remove(r).content));
  },
  // :: (string, any) → OrderedMap
  // Add a new key to the end of the map.
  addToEnd: function(r, e) {
    var t = this.remove(r).content.slice();
    return t.push(r, e), new A(t);
  },
  // :: (string, string, any) → OrderedMap
  // Add a key after the given key. If `place` is not found, the new
  // key is added to the end.
  addBefore: function(r, e, t) {
    var n = this.remove(e), i = n.content.slice(), s = n.find(r);
    return i.splice(s == -1 ? i.length : s, 0, e, t), new A(i);
  },
  // :: ((key: string, value: any))
  // Call the given function for each key/value pair in the map, in
  // order.
  forEach: function(r) {
    for (var e = 0; e < this.content.length; e += 2)
      r(this.content[e], this.content[e + 1]);
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by prepending the keys in this map that don't
  // appear in `map` before the keys in `map`.
  prepend: function(r) {
    return r = A.from(r), r.size ? new A(r.content.concat(this.subtract(r).content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a new map by appending the keys in this map that don't
  // appear in `map` after the keys in `map`.
  append: function(r) {
    return r = A.from(r), r.size ? new A(this.subtract(r).content.concat(r.content)) : this;
  },
  // :: (union<Object, OrderedMap>) → OrderedMap
  // Create a map containing all the keys in this map that don't
  // appear in `map`.
  subtract: function(r) {
    var e = this;
    r = A.from(r);
    for (var t = 0; t < r.content.length; t += 2)
      e = e.remove(r.content[t]);
    return e;
  },
  // :: () → Object
  // Turn ordered map into a plain object.
  toObject: function() {
    var r = {};
    return this.forEach(function(e, t) {
      r[e] = t;
    }), r;
  },
  // :: number
  // The amount of keys in this map.
  get size() {
    return this.content.length >> 1;
  }
};
A.from = function(r) {
  if (r instanceof A) return r;
  var e = [];
  if (r) for (var t in r) e.push(t, r[t]);
  return new A(e);
};
function xt(r, e, t) {
  for (let n = 0; ; n++) {
    if (n == r.childCount || n == e.childCount)
      return r.childCount == e.childCount ? null : t;
    let i = r.child(n), s = e.child(n);
    if (i == s) {
      t += i.nodeSize;
      continue;
    }
    if (!i.sameMarkup(s))
      return t;
    if (i.isText && i.text != s.text) {
      let o = i.text, a = s.text, l = 0;
      for (; o[l] == a[l]; l++)
        t++;
      return l && l < o.length && l < a.length && St(o.charCodeAt(l - 1)) && bt(o.charCodeAt(l)) && t--, t;
    }
    if (i.content.size || s.content.size) {
      let o = xt(i.content, s.content, t + 1);
      if (o != null)
        return o;
    }
    t += i.nodeSize;
  }
}
function kt(r, e, t, n) {
  for (let i = r.childCount, s = e.childCount; ; ) {
    if (i == 0 || s == 0)
      return i == s ? null : { a: t, b: n };
    let o = r.child(--i), a = e.child(--s), l = o.nodeSize;
    if (o == a) {
      t -= l, n -= l;
      continue;
    }
    if (!o.sameMarkup(a))
      return { a: t, b: n };
    if (o.isText && o.text != a.text) {
      let h = o.text, c = a.text, p = h.length, f = c.length;
      for (; p > 0 && f > 0 && h[p - 1] == c[f - 1]; )
        p--, f--, t--, n--;
      return p && f && p < h.length && St(h.charCodeAt(p - 1)) && bt(h.charCodeAt(p)) && (t++, n++), { a: t, b: n };
    }
    if (o.content.size || a.content.size) {
      let h = kt(o.content, a.content, t - 1, n - 1);
      if (h)
        return h;
    }
    t -= l, n -= l;
  }
}
function bt(r) {
  return r >= 56320 && r < 57344;
}
function St(r) {
  return r >= 55296 && r < 56320;
}
class m {
  /**
  @internal
  */
  constructor(e, t) {
    if (this.content = e, this.size = t || 0, t == null)
      for (let n = 0; n < e.length; n++)
        this.size += e[n].nodeSize;
  }
  /**
  Invoke a callback for all descendant nodes between the given two
  positions (relative to start of this fragment). Doesn't descend
  into a node when the callback returns `false`.
  */
  nodesBetween(e, t, n, i = 0, s) {
    for (let o = 0, a = 0; a < t; o++) {
      let l = this.content[o], h = a + l.nodeSize;
      if (h > e && n(l, i + a, s || null, o) !== !1 && l.content.size) {
        let c = a + 1;
        l.nodesBetween(Math.max(0, e - c), Math.min(l.content.size, t - c), n, i + c);
      }
      a = h;
    }
  }
  /**
  Call the given callback for every descendant node. `pos` will be
  relative to the start of the fragment. The callback may return
  `false` to prevent traversal of a given node's children.
  */
  descendants(e) {
    this.nodesBetween(0, this.size, e);
  }
  /**
  Extract the text between `from` and `to`. See the same method on
  [`Node`](https://prosemirror.net/docs/ref/#model.Node.textBetween).
  */
  textBetween(e, t, n, i) {
    let s = "", o = !0;
    return this.nodesBetween(e, t, (a, l) => {
      let h = a.isText ? a.text.slice(Math.max(e, l) - l, t - l) : a.isLeaf ? i ? typeof i == "function" ? i(a) : i : a.type.spec.leafText ? a.type.spec.leafText(a) : "" : "";
      a.isBlock && (a.isLeaf && h || a.isTextblock) && n && (o ? o = !1 : s += n), s += h;
    }, 0), s;
  }
  /**
  Create a new fragment containing the combined content of this
  fragment and the other.
  */
  append(e) {
    if (!e.size)
      return this;
    if (!this.size)
      return e;
    let t = this.lastChild, n = e.firstChild, i = this.content.slice(), s = 0;
    for (t.isText && t.sameMarkup(n) && (i[i.length - 1] = t.withText(t.text + n.text), s = 1); s < e.content.length; s++)
      i.push(e.content[s]);
    return new m(i, this.size + e.size);
  }
  /**
  Cut out the sub-fragment between the two given positions.
  */
  cut(e, t = this.size) {
    if (e == 0 && t == this.size)
      return this;
    let n = [], i = 0;
    if (t > e)
      for (let s = 0, o = 0; o < t; s++) {
        let a = this.content[s], l = o + a.nodeSize;
        l > e && ((o < e || l > t) && (a.isText ? a = a.cut(Math.max(0, e - o), Math.min(a.text.length, t - o)) : a = a.cut(Math.max(0, e - o - 1), Math.min(a.content.size, t - o - 1))), n.push(a), i += a.nodeSize), o = l;
      }
    return new m(n, i);
  }
  /**
  @internal
  */
  cutByIndex(e, t) {
    return e == t ? m.empty : e == 0 && t == this.content.length ? this : new m(this.content.slice(e, t));
  }
  /**
  Create a new fragment in which the node at the given index is
  replaced by the given node.
  */
  replaceChild(e, t) {
    let n = this.content[e];
    if (n == t)
      return this;
    let i = this.content.slice(), s = this.size + t.nodeSize - n.nodeSize;
    return i[e] = t, new m(i, s);
  }
  /**
  Create a new fragment by prepending the given node to this
  fragment.
  */
  addToStart(e) {
    return new m([e].concat(this.content), this.size + e.nodeSize);
  }
  /**
  Create a new fragment by appending the given node to this
  fragment.
  */
  addToEnd(e) {
    return new m(this.content.concat(e), this.size + e.nodeSize);
  }
  /**
  Compare this fragment to another one.
  */
  eq(e) {
    if (this.content.length != e.content.length)
      return !1;
    for (let t = 0; t < this.content.length; t++)
      if (!this.content[t].eq(e.content[t]))
        return !1;
    return !0;
  }
  /**
  The first child of the fragment, or `null` if it is empty.
  */
  get firstChild() {
    return this.content.length ? this.content[0] : null;
  }
  /**
  The last child of the fragment, or `null` if it is empty.
  */
  get lastChild() {
    return this.content.length ? this.content[this.content.length - 1] : null;
  }
  /**
  The number of child nodes in this fragment.
  */
  get childCount() {
    return this.content.length;
  }
  /**
  Get the child node at the given index. Raise an error when the
  index is out of range.
  */
  child(e) {
    let t = this.content[e];
    if (!t)
      throw new RangeError("Index " + e + " out of range for " + this);
    return t;
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content[e] || null;
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    for (let t = 0, n = 0; t < this.content.length; t++) {
      let i = this.content[t];
      e(i, n, t), n += i.nodeSize;
    }
  }
  /**
  Find the first position at which this fragment and another
  fragment differ, or `null` if they are the same.
  */
  findDiffStart(e, t = 0) {
    return xt(this, e, t);
  }
  /**
  Find the first position, searching from the end, at which this
  fragment and the given fragment differ, or `null` if they are
  the same. Since this position will not be the same in both
  nodes, an object with two separate positions is returned.
  */
  findDiffEnd(e, t = this.size, n = e.size) {
    return kt(this, e, t, n);
  }
  /**
  Find the index and inner offset corresponding to a given relative
  position in this fragment. The result object will be reused
  (overwritten) the next time the function is called. @internal
  */
  findIndex(e) {
    if (e == 0)
      return de(0, e);
    if (e == this.size)
      return de(this.content.length, e);
    if (e > this.size || e < 0)
      throw new RangeError(`Position ${e} outside of fragment (${this})`);
    for (let t = 0, n = 0; ; t++) {
      let i = this.child(t), s = n + i.nodeSize;
      if (s >= e)
        return s == e ? de(t + 1, s) : de(t, n);
      n = s;
    }
  }
  /**
  Return a debugging string that describes this fragment.
  */
  toString() {
    return "<" + this.toStringInner() + ">";
  }
  /**
  @internal
  */
  toStringInner() {
    return this.content.join(", ");
  }
  /**
  Create a JSON-serializeable representation of this fragment.
  */
  toJSON() {
    return this.content.length ? this.content.map((e) => e.toJSON()) : null;
  }
  /**
  Deserialize a fragment from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return m.empty;
    if (!Array.isArray(t))
      throw new RangeError("Invalid input for Fragment.fromJSON");
    return m.fromArray(t.map(e.nodeFromJSON));
  }
  /**
  Build a fragment from an array of nodes. Ensures that adjacent
  text nodes with the same marks are joined together.
  */
  static fromArray(e) {
    if (!e.length)
      return m.empty;
    let t, n = 0;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      n += s.nodeSize, i && s.isText && e[i - 1].sameMarkup(s) ? (t || (t = e.slice(0, i)), t[t.length - 1] = s.withText(t[t.length - 1].text + s.text)) : t && t.push(s);
    }
    return new m(t || e, n);
  }
  /**
  Create a fragment from something that can be interpreted as a
  set of nodes. For `null`, it returns the empty fragment. For a
  fragment, the fragment itself. For a node or array of nodes, a
  fragment containing those nodes.
  */
  static from(e) {
    if (!e)
      return m.empty;
    if (e instanceof m)
      return e;
    if (Array.isArray(e))
      return this.fromArray(e);
    if (e.attrs)
      return new m([e], e.nodeSize);
    throw new RangeError("Can not convert " + e + " to a Fragment" + (e.nodesBetween ? " (looks like multiple versions of prosemirror-model were loaded)" : ""));
  }
}
m.empty = new m([], 0);
const De = { index: 0, offset: 0 };
function de(r, e) {
  return De.index = r, De.offset = e, De;
}
function be(r, e) {
  if (r === e)
    return !0;
  if (!(r && typeof r == "object") || !(e && typeof e == "object"))
    return !1;
  let t = Array.isArray(r);
  if (Array.isArray(e) != t)
    return !1;
  if (t) {
    if (r.length != e.length)
      return !1;
    for (let n = 0; n < r.length; n++)
      if (!be(r[n], e[n]))
        return !1;
  } else {
    for (let n in r)
      if (!(n in e) || !be(r[n], e[n]))
        return !1;
    for (let n in e)
      if (!(n in r))
        return !1;
  }
  return !0;
}
class S {
  /**
  @internal
  */
  constructor(e, t) {
    this.type = e, this.attrs = t;
  }
  /**
  Given a set of marks, create a new set which contains this one as
  well, in the right position. If this mark is already in the set,
  the set itself is returned. If any marks that are set to be
  [exclusive](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) with this mark are present,
  those are replaced by this one.
  */
  addToSet(e) {
    let t, n = !1;
    for (let i = 0; i < e.length; i++) {
      let s = e[i];
      if (this.eq(s))
        return e;
      if (this.type.excludes(s.type))
        t || (t = e.slice(0, i));
      else {
        if (s.type.excludes(this.type))
          return e;
        !n && s.type.rank > this.type.rank && (t || (t = e.slice(0, i)), t.push(this), n = !0), t && t.push(s);
      }
    }
    return t || (t = e.slice()), n || t.push(this), t;
  }
  /**
  Remove this mark from the given set, returning a new set. If this
  mark is not in the set, the set itself is returned.
  */
  removeFromSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return e.slice(0, t).concat(e.slice(t + 1));
    return e;
  }
  /**
  Test whether this mark is in the given set of marks.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (this.eq(e[t]))
        return !0;
    return !1;
  }
  /**
  Test whether this mark has the same type and attributes as
  another mark.
  */
  eq(e) {
    return this == e || this.type == e.type && be(this.attrs, e.attrs);
  }
  /**
  Convert this mark to a JSON-serializeable representation.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return e;
  }
  /**
  Deserialize a mark from JSON.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Mark.fromJSON");
    let n = e.marks[t.type];
    if (!n)
      throw new RangeError(`There is no mark type ${t.type} in this schema`);
    return n.create(t.attrs);
  }
  /**
  Test whether two sets of marks are identical.
  */
  static sameSet(e, t) {
    if (e == t)
      return !0;
    if (e.length != t.length)
      return !1;
    for (let n = 0; n < e.length; n++)
      if (!e[n].eq(t[n]))
        return !1;
    return !0;
  }
  /**
  Create a properly sorted mark set from null, a single mark, or an
  unsorted array of marks.
  */
  static setFrom(e) {
    if (!e || Array.isArray(e) && e.length == 0)
      return S.none;
    if (e instanceof S)
      return [e];
    let t = e.slice();
    return t.sort((n, i) => n.type.rank - i.type.rank), t;
  }
}
S.none = [];
class he extends Error {
}
class g {
  /**
  Create a slice. When specifying a non-zero open depth, you must
  make sure that there are nodes of at least that depth at the
  appropriate side of the fragment—i.e. if the fragment is an
  empty paragraph node, `openStart` and `openEnd` can't be greater
  than 1.
  
  It is not necessary for the content of open nodes to conform to
  the schema's content constraints, though it should be a valid
  start/end/middle for such a node, depending on which sides are
  open.
  */
  constructor(e, t, n) {
    this.content = e, this.openStart = t, this.openEnd = n;
  }
  /**
  The size this slice would add when inserted into a document.
  */
  get size() {
    return this.content.size - this.openStart - this.openEnd;
  }
  /**
  @internal
  */
  insertAt(e, t) {
    let n = Et(this.content, e + this.openStart, t, this.openStart + 1, this.openEnd + 1);
    return n && new g(n, this.openStart, this.openEnd);
  }
  /**
  @internal
  */
  removeBetween(e, t) {
    return new g(Ot(this.content, e + this.openStart, t + this.openStart), this.openStart, this.openEnd);
  }
  /**
  Tests whether this slice is equal to another slice.
  */
  eq(e) {
    return this.content.eq(e.content) && this.openStart == e.openStart && this.openEnd == e.openEnd;
  }
  /**
  @internal
  */
  toString() {
    return this.content + "(" + this.openStart + "," + this.openEnd + ")";
  }
  /**
  Convert a slice to a JSON-serializable representation.
  */
  toJSON() {
    if (!this.content.size)
      return null;
    let e = { content: this.content.toJSON() };
    return this.openStart > 0 && (e.openStart = this.openStart), this.openEnd > 0 && (e.openEnd = this.openEnd), e;
  }
  /**
  Deserialize a slice from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      return g.empty;
    let n = t.openStart || 0, i = t.openEnd || 0;
    if (typeof n != "number" || typeof i != "number")
      throw new RangeError("Invalid input for Slice.fromJSON");
    return new g(m.fromJSON(e, t.content), n, i);
  }
  /**
  Create a slice from a fragment by taking the maximum possible
  open value on both side of the fragment.
  */
  static maxOpen(e, t = !0) {
    let n = 0, i = 0;
    for (let s = e.firstChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.firstChild)
      n++;
    for (let s = e.lastChild; s && !s.isLeaf && (t || !s.type.spec.isolating); s = s.lastChild)
      i++;
    return new g(e, n, i);
  }
}
g.empty = new g(m.empty, 0, 0);
function Ot(r, e, t) {
  let { index: n, offset: i } = r.findIndex(e), s = r.maybeChild(n), { index: o, offset: a } = r.findIndex(t);
  if (i == e || s.isText) {
    if (a != t && !r.child(o).isText)
      throw new RangeError("Removing non-flat range");
    return r.cut(0, e).append(r.cut(t));
  }
  if (n != o)
    throw new RangeError("Removing non-flat range");
  return r.replaceChild(n, s.copy(Ot(s.content, e - i - 1, t - i - 1)));
}
function Et(r, e, t, n, i, s) {
  let { index: o, offset: a } = r.findIndex(e), l = r.maybeChild(o);
  if (a == e || l.isText)
    return s && n <= 0 && i <= 0 && !s.canReplace(o, o, t) ? null : r.cut(0, e).append(t).append(r.cut(e));
  let h = Et(l.content, e - a - 1, t, o == 0 ? n - 1 : 0, o == r.childCount - 1 ? i - 1 : 0, l);
  return h && r.replaceChild(o, l.copy(h));
}
function ln(r, e, t) {
  if (t.openStart > r.depth)
    throw new he("Inserted content deeper than insertion position");
  if (r.depth - t.openStart != e.depth - t.openEnd)
    throw new he("Inconsistent open depths");
  return It(r, e, t, 0);
}
function It(r, e, t, n) {
  let i = r.index(n), s = r.node(n);
  if (i == e.index(n) && n < r.depth - t.openStart) {
    let o = It(r, e, t, n + 1);
    return s.copy(s.content.replaceChild(i, o));
  } else if (t.content.size)
    if (!t.openStart && !t.openEnd && r.depth == n && e.depth == n) {
      let o = r.parent, a = o.content;
      return U(o, a.cut(0, r.parentOffset).append(t.content).append(a.cut(e.parentOffset)));
    } else {
      let { start: o, end: a } = hn(t, r);
      return U(s, Tt(r, o, a, e, n));
    }
  else return U(s, Se(r, e, n));
}
function vt(r, e) {
  if (!e.type.compatibleContent(r.type))
    throw new he("Cannot join " + e.type.name + " onto " + r.type.name);
}
function Ve(r, e, t) {
  let n = r.node(t);
  return vt(n, e.node(t)), n;
}
function K(r, e) {
  let t = e.length - 1;
  t >= 0 && r.isText && r.sameMarkup(e[t]) ? e[t] = r.withText(e[t].text + r.text) : e.push(r);
}
function le(r, e, t, n) {
  let i = (e || r).node(t), s = 0, o = e ? e.index(t) : i.childCount;
  r && (s = r.index(t), r.depth > t ? s++ : r.textOffset && (K(r.nodeAfter, n), s++));
  for (let a = s; a < o; a++)
    K(i.child(a), n);
  e && e.depth == t && e.textOffset && K(e.nodeBefore, n);
}
function U(r, e) {
  if (!r.type.validContent(e))
    throw new he("Invalid content for node " + r.type.name);
  return r.copy(e);
}
function Tt(r, e, t, n, i) {
  let s = r.depth > i && Ve(r, e, i + 1), o = n.depth > i && Ve(t, n, i + 1), a = [];
  return le(null, r, i, a), s && o && e.index(i) == t.index(i) ? (vt(s, o), K(U(s, Tt(r, e, t, n, i + 1)), a)) : (s && K(U(s, Se(r, e, i + 1)), a), le(e, t, i, a), o && K(U(o, Se(t, n, i + 1)), a)), le(n, null, i, a), new m(a);
}
function Se(r, e, t) {
  let n = [];
  if (le(null, r, t, n), r.depth > t) {
    let i = Ve(r, e, t + 1);
    K(U(i, Se(r, e, t + 1)), n);
  }
  return le(e, null, t, n), new m(n);
}
function hn(r, e) {
  let t = e.depth - r.openStart, i = e.node(t).copy(r.content);
  for (let s = t - 1; s >= 0; s--)
    i = e.node(s).copy(m.from(i));
  return {
    start: i.resolveNoCache(r.openStart + t),
    end: i.resolveNoCache(i.content.size - r.openEnd - t)
  };
}
class ce {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.pos = e, this.path = t, this.parentOffset = n, this.depth = t.length / 3 - 1;
  }
  /**
  @internal
  */
  resolveDepth(e) {
    return e == null ? this.depth : e < 0 ? this.depth + e : e;
  }
  /**
  The parent node that the position points into. Note that even if
  a position points into a text node, that node is not considered
  the parent—text nodes are ‘flat’ in this model, and have no content.
  */
  get parent() {
    return this.node(this.depth);
  }
  /**
  The root node in which the position was resolved.
  */
  get doc() {
    return this.node(0);
  }
  /**
  The ancestor node at the given level. `p.node(p.depth)` is the
  same as `p.parent`.
  */
  node(e) {
    return this.path[this.resolveDepth(e) * 3];
  }
  /**
  The index into the ancestor at the given level. If this points
  at the 3rd node in the 2nd paragraph on the top level, for
  example, `p.index(0)` is 1 and `p.index(1)` is 2.
  */
  index(e) {
    return this.path[this.resolveDepth(e) * 3 + 1];
  }
  /**
  The index pointing after this position into the ancestor at the
  given level.
  */
  indexAfter(e) {
    return e = this.resolveDepth(e), this.index(e) + (e == this.depth && !this.textOffset ? 0 : 1);
  }
  /**
  The (absolute) position at the start of the node at the given
  level.
  */
  start(e) {
    return e = this.resolveDepth(e), e == 0 ? 0 : this.path[e * 3 - 1] + 1;
  }
  /**
  The (absolute) position at the end of the node at the given
  level.
  */
  end(e) {
    return e = this.resolveDepth(e), this.start(e) + this.node(e).content.size;
  }
  /**
  The (absolute) position directly before the wrapping node at the
  given level, or, when `depth` is `this.depth + 1`, the original
  position.
  */
  before(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position before the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1];
  }
  /**
  The (absolute) position directly after the wrapping node at the
  given level, or the original position when `depth` is `this.depth + 1`.
  */
  after(e) {
    if (e = this.resolveDepth(e), !e)
      throw new RangeError("There is no position after the top-level node");
    return e == this.depth + 1 ? this.pos : this.path[e * 3 - 1] + this.path[e * 3].nodeSize;
  }
  /**
  When this position points into a text node, this returns the
  distance between the position and the start of the text node.
  Will be zero for positions that point between nodes.
  */
  get textOffset() {
    return this.pos - this.path[this.path.length - 1];
  }
  /**
  Get the node directly after the position, if any. If the position
  points into a text node, only the part of that node after the
  position is returned.
  */
  get nodeAfter() {
    let e = this.parent, t = this.index(this.depth);
    if (t == e.childCount)
      return null;
    let n = this.pos - this.path[this.path.length - 1], i = e.child(t);
    return n ? e.child(t).cut(n) : i;
  }
  /**
  Get the node directly before the position, if any. If the
  position points into a text node, only the part of that node
  before the position is returned.
  */
  get nodeBefore() {
    let e = this.index(this.depth), t = this.pos - this.path[this.path.length - 1];
    return t ? this.parent.child(e).cut(0, t) : e == 0 ? null : this.parent.child(e - 1);
  }
  /**
  Get the position at the given index in the parent node at the
  given depth (which defaults to `this.depth`).
  */
  posAtIndex(e, t) {
    t = this.resolveDepth(t);
    let n = this.path[t * 3], i = t == 0 ? 0 : this.path[t * 3 - 1] + 1;
    for (let s = 0; s < e; s++)
      i += n.child(s).nodeSize;
    return i;
  }
  /**
  Get the marks at this position, factoring in the surrounding
  marks' [`inclusive`](https://prosemirror.net/docs/ref/#model.MarkSpec.inclusive) property. If the
  position is at the start of a non-empty node, the marks of the
  node after it (if any) are returned.
  */
  marks() {
    let e = this.parent, t = this.index();
    if (e.content.size == 0)
      return S.none;
    if (this.textOffset)
      return e.child(t).marks;
    let n = e.maybeChild(t - 1), i = e.maybeChild(t);
    if (!n) {
      let a = n;
      n = i, i = a;
    }
    let s = n.marks;
    for (var o = 0; o < s.length; o++)
      s[o].type.spec.inclusive === !1 && (!i || !s[o].isInSet(i.marks)) && (s = s[o--].removeFromSet(s));
    return s;
  }
  /**
  Get the marks after the current position, if any, except those
  that are non-inclusive and not present at position `$end`. This
  is mostly useful for getting the set of marks to preserve after a
  deletion. Will return `null` if this position is at the end of
  its parent node or its parent node isn't a textblock (in which
  case no marks should be preserved).
  */
  marksAcross(e) {
    let t = this.parent.maybeChild(this.index());
    if (!t || !t.isInline)
      return null;
    let n = t.marks, i = e.parent.maybeChild(e.index());
    for (var s = 0; s < n.length; s++)
      n[s].type.spec.inclusive === !1 && (!i || !n[s].isInSet(i.marks)) && (n = n[s--].removeFromSet(n));
    return n;
  }
  /**
  The depth up to which this position and the given (non-resolved)
  position share the same parent nodes.
  */
  sharedDepth(e) {
    for (let t = this.depth; t > 0; t--)
      if (this.start(t) <= e && this.end(t) >= e)
        return t;
    return 0;
  }
  /**
  Returns a range based on the place where this position and the
  given position diverge around block content. If both point into
  the same textblock, for example, a range around that textblock
  will be returned. If they point into different blocks, the range
  around those blocks in their shared ancestor is returned. You can
  pass in an optional predicate that will be called with a parent
  node to see if a range into that parent is acceptable.
  */
  blockRange(e = this, t) {
    if (e.pos < this.pos)
      return e.blockRange(this);
    for (let n = this.depth - (this.parent.inlineContent || this.pos == e.pos ? 1 : 0); n >= 0; n--)
      if (e.pos <= this.end(n) && (!t || t(this.node(n))))
        return new pn(this, e, n);
    return null;
  }
  /**
  Query whether the given position shares the same parent node.
  */
  sameParent(e) {
    return this.pos - this.parentOffset == e.pos - e.parentOffset;
  }
  /**
  Return the greater of this and the given position.
  */
  max(e) {
    return e.pos > this.pos ? e : this;
  }
  /**
  Return the smaller of this and the given position.
  */
  min(e) {
    return e.pos < this.pos ? e : this;
  }
  /**
  @internal
  */
  toString() {
    let e = "";
    for (let t = 1; t <= this.depth; t++)
      e += (e ? "/" : "") + this.node(t).type.name + "_" + this.index(t - 1);
    return e + ":" + this.parentOffset;
  }
  /**
  @internal
  */
  static resolve(e, t) {
    if (!(t >= 0 && t <= e.content.size))
      throw new RangeError("Position " + t + " out of range");
    let n = [], i = 0, s = t;
    for (let o = e; ; ) {
      let { index: a, offset: l } = o.content.findIndex(s), h = s - l;
      if (n.push(o, a, i + l), !h || (o = o.child(a), o.isText))
        break;
      s = h - 1, i += l + 1;
    }
    return new ce(t, n, s);
  }
  /**
  @internal
  */
  static resolveCached(e, t) {
    let n = et.get(e);
    if (n)
      for (let s = 0; s < n.elts.length; s++) {
        let o = n.elts[s];
        if (o.pos == t)
          return o;
      }
    else
      et.set(e, n = new cn());
    let i = n.elts[n.i] = ce.resolve(e, t);
    return n.i = (n.i + 1) % fn, i;
  }
}
class cn {
  constructor() {
    this.elts = [], this.i = 0;
  }
}
const fn = 12, et = /* @__PURE__ */ new WeakMap();
class pn {
  /**
  Construct a node range. `$from` and `$to` should point into the
  same node until at least the given `depth`, since a node range
  denotes an adjacent set of nodes in a single parent node.
  */
  constructor(e, t, n) {
    this.$from = e, this.$to = t, this.depth = n;
  }
  /**
  The position at the start of the range.
  */
  get start() {
    return this.$from.before(this.depth + 1);
  }
  /**
  The position at the end of the range.
  */
  get end() {
    return this.$to.after(this.depth + 1);
  }
  /**
  The parent node that the range points into.
  */
  get parent() {
    return this.$from.node(this.depth);
  }
  /**
  The start index of the range in the parent node.
  */
  get startIndex() {
    return this.$from.index(this.depth);
  }
  /**
  The end index of the range in the parent node.
  */
  get endIndex() {
    return this.$to.indexAfter(this.depth);
  }
}
const dn = /* @__PURE__ */ Object.create(null);
class P {
  /**
  @internal
  */
  constructor(e, t, n, i = S.none) {
    this.type = e, this.attrs = t, this.marks = i, this.content = n || m.empty;
  }
  /**
  The array of this node's child nodes.
  */
  get children() {
    return this.content.content;
  }
  /**
  The size of this node, as defined by the integer-based [indexing
  scheme](https://prosemirror.net/docs/guide/#doc.indexing). For text nodes, this is the
  amount of characters. For other leaf nodes, it is one. For
  non-leaf nodes, it is the size of the content plus two (the
  start and end token).
  */
  get nodeSize() {
    return this.isLeaf ? 1 : 2 + this.content.size;
  }
  /**
  The number of children that the node has.
  */
  get childCount() {
    return this.content.childCount;
  }
  /**
  Get the child node at the given index. Raises an error when the
  index is out of range.
  */
  child(e) {
    return this.content.child(e);
  }
  /**
  Get the child node at the given index, if it exists.
  */
  maybeChild(e) {
    return this.content.maybeChild(e);
  }
  /**
  Call `f` for every child node, passing the node, its offset
  into this parent node, and its index.
  */
  forEach(e) {
    this.content.forEach(e);
  }
  /**
  Invoke a callback for all descendant nodes recursively overlapping
  the given two positions that are relative to start of this
  node's content. This includes all ancestors of the nodes
  containing the two positions. The callback is invoked with the
  node, its position relative to the original node (method receiver),
  its parent node, and its child index. When the callback returns
  false for a given node, that node's children will not be
  recursed over. The last parameter can be used to specify a
  starting position to count from.
  */
  nodesBetween(e, t, n, i = 0) {
    this.content.nodesBetween(e, t, n, i, this);
  }
  /**
  Call the given callback for every descendant node. Doesn't
  descend into a node when the callback returns `false`.
  */
  descendants(e) {
    this.nodesBetween(0, this.content.size, e);
  }
  /**
  Concatenates all the text nodes found in this fragment and its
  children.
  */
  get textContent() {
    return this.isLeaf && this.type.spec.leafText ? this.type.spec.leafText(this) : this.textBetween(0, this.content.size, "");
  }
  /**
  Get all text between positions `from` and `to`. When
  `blockSeparator` is given, it will be inserted to separate text
  from different block nodes. If `leafText` is given, it'll be
  inserted for every non-text leaf node encountered, otherwise
  [`leafText`](https://prosemirror.net/docs/ref/#model.NodeSpec.leafText) will be used.
  */
  textBetween(e, t, n, i) {
    return this.content.textBetween(e, t, n, i);
  }
  /**
  Returns this node's first child, or `null` if there are no
  children.
  */
  get firstChild() {
    return this.content.firstChild;
  }
  /**
  Returns this node's last child, or `null` if there are no
  children.
  */
  get lastChild() {
    return this.content.lastChild;
  }
  /**
  Test whether two nodes represent the same piece of document.
  */
  eq(e) {
    return this == e || this.sameMarkup(e) && this.content.eq(e.content);
  }
  /**
  Compare the markup (type, attributes, and marks) of this node to
  those of another. Returns `true` if both have the same markup.
  */
  sameMarkup(e) {
    return this.hasMarkup(e.type, e.attrs, e.marks);
  }
  /**
  Check whether this node's markup correspond to the given type,
  attributes, and marks.
  */
  hasMarkup(e, t, n) {
    return this.type == e && be(this.attrs, t || e.defaultAttrs || dn) && S.sameSet(this.marks, n || S.none);
  }
  /**
  Create a new node with the same markup as this node, containing
  the given content (or empty, if no content is given).
  */
  copy(e = null) {
    return e == this.content ? this : new P(this.type, this.attrs, e, this.marks);
  }
  /**
  Create a copy of this node, with the given set of marks instead
  of the node's own marks.
  */
  mark(e) {
    return e == this.marks ? this : new P(this.type, this.attrs, this.content, e);
  }
  /**
  Create a copy of this node with only the content between the
  given positions. If `to` is not given, it defaults to the end of
  the node.
  */
  cut(e, t = this.content.size) {
    return e == 0 && t == this.content.size ? this : this.copy(this.content.cut(e, t));
  }
  /**
  Cut out the part of the document between the given positions, and
  return it as a `Slice` object.
  */
  slice(e, t = this.content.size, n = !1) {
    if (e == t)
      return g.empty;
    let i = this.resolve(e), s = this.resolve(t), o = n ? 0 : i.sharedDepth(t), a = i.start(o), h = i.node(o).content.cut(i.pos - a, s.pos - a);
    return new g(h, i.depth - o, s.depth - o);
  }
  /**
  Replace the part of the document between the given positions with
  the given slice. The slice must 'fit', meaning its open sides
  must be able to connect to the surrounding content, and its
  content nodes must be valid children for the node they are placed
  into. If any of this is violated, an error of type
  [`ReplaceError`](https://prosemirror.net/docs/ref/#model.ReplaceError) is thrown.
  */
  replace(e, t, n) {
    return ln(this.resolve(e), this.resolve(t), n);
  }
  /**
  Find the node directly after the given position.
  */
  nodeAt(e) {
    for (let t = this; ; ) {
      let { index: n, offset: i } = t.content.findIndex(e);
      if (t = t.maybeChild(n), !t)
        return null;
      if (i == e || t.isText)
        return t;
      e -= i + 1;
    }
  }
  /**
  Find the (direct) child node after the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childAfter(e) {
    let { index: t, offset: n } = this.content.findIndex(e);
    return { node: this.content.maybeChild(t), index: t, offset: n };
  }
  /**
  Find the (direct) child node before the given offset, if any,
  and return it along with its index and offset relative to this
  node.
  */
  childBefore(e) {
    if (e == 0)
      return { node: null, index: 0, offset: 0 };
    let { index: t, offset: n } = this.content.findIndex(e);
    if (n < e)
      return { node: this.content.child(t), index: t, offset: n };
    let i = this.content.child(t - 1);
    return { node: i, index: t - 1, offset: n - i.nodeSize };
  }
  /**
  Resolve the given position in the document, returning an
  [object](https://prosemirror.net/docs/ref/#model.ResolvedPos) with information about its context.
  */
  resolve(e) {
    return ce.resolveCached(this, e);
  }
  /**
  @internal
  */
  resolveNoCache(e) {
    return ce.resolve(this, e);
  }
  /**
  Test whether a given mark or mark type occurs in this document
  between the two given positions.
  */
  rangeHasMark(e, t, n) {
    let i = !1;
    return t > e && this.nodesBetween(e, t, (s) => (n.isInSet(s.marks) && (i = !0), !i)), i;
  }
  /**
  True when this is a block (non-inline node)
  */
  get isBlock() {
    return this.type.isBlock;
  }
  /**
  True when this is a textblock node, a block node with inline
  content.
  */
  get isTextblock() {
    return this.type.isTextblock;
  }
  /**
  True when this node allows inline content.
  */
  get inlineContent() {
    return this.type.inlineContent;
  }
  /**
  True when this is an inline node (a text node or a node that can
  appear among text).
  */
  get isInline() {
    return this.type.isInline;
  }
  /**
  True when this is a text node.
  */
  get isText() {
    return this.type.isText;
  }
  /**
  True when this is a leaf node.
  */
  get isLeaf() {
    return this.type.isLeaf;
  }
  /**
  True when this is an atom, i.e. when it does not have directly
  editable content. This is usually the same as `isLeaf`, but can
  be configured with the [`atom` property](https://prosemirror.net/docs/ref/#model.NodeSpec.atom)
  on a node's spec (typically used when the node is displayed as
  an uneditable [node view](https://prosemirror.net/docs/ref/#view.NodeView)).
  */
  get isAtom() {
    return this.type.isAtom;
  }
  /**
  Return a string representation of this node for debugging
  purposes.
  */
  toString() {
    if (this.type.spec.toDebugString)
      return this.type.spec.toDebugString(this);
    let e = this.type.name;
    return this.content.size && (e += "(" + this.content.toStringInner() + ")"), At(this.marks, e);
  }
  /**
  Get the content match in this node at the given index.
  */
  contentMatchAt(e) {
    let t = this.type.contentMatch.matchFragment(this.content, 0, e);
    if (!t)
      throw new Error("Called contentMatchAt on a node with invalid content");
    return t;
  }
  /**
  Test whether replacing the range between `from` and `to` (by
  child index) with the given replacement fragment (which defaults
  to the empty fragment) would leave the node's content valid. You
  can optionally pass `start` and `end` indices into the
  replacement fragment.
  */
  canReplace(e, t, n = m.empty, i = 0, s = n.childCount) {
    let o = this.contentMatchAt(e).matchFragment(n, i, s), a = o && o.matchFragment(this.content, t);
    if (!a || !a.validEnd)
      return !1;
    for (let l = i; l < s; l++)
      if (!this.type.allowsMarks(n.child(l).marks))
        return !1;
    return !0;
  }
  /**
  Test whether replacing the range `from` to `to` (by index) with
  a node of the given type would leave the node's content valid.
  */
  canReplaceWith(e, t, n, i) {
    if (i && !this.type.allowsMarks(i))
      return !1;
    let s = this.contentMatchAt(e).matchType(n), o = s && s.matchFragment(this.content, t);
    return o ? o.validEnd : !1;
  }
  /**
  Test whether the given node's content could be appended to this
  node. If that node is empty, this will only return true if there
  is at least one node type that can appear in both nodes (to avoid
  merging completely incompatible nodes).
  */
  canAppend(e) {
    return e.content.size ? this.canReplace(this.childCount, this.childCount, e.content) : this.type.compatibleContent(e.type);
  }
  /**
  Check whether this node and its descendants conform to the
  schema, and raise an exception when they do not.
  */
  check() {
    this.type.checkContent(this.content), tt(this.type.attrs, this.attrs, "node", this.type.name);
    let e = S.none;
    for (let t = 0; t < this.marks.length; t++) {
      let n = this.marks[t];
      tt(n.type.attrs, n.attrs, "mark", n.type.name), e = n.addToSet(e);
    }
    if (!S.sameSet(e, this.marks))
      throw new RangeError(`Invalid collection of marks for node ${this.type.name}: ${this.marks.map((t) => t.type.name)}`);
    this.content.forEach((t) => t.check());
  }
  /**
  Return a JSON-serializeable representation of this node.
  */
  toJSON() {
    let e = { type: this.type.name };
    for (let t in this.attrs) {
      e.attrs = this.attrs;
      break;
    }
    return this.content.size && (e.content = this.content.toJSON()), this.marks.length && (e.marks = this.marks.map((t) => t.toJSON())), e;
  }
  /**
  Deserialize a node from its JSON representation.
  */
  static fromJSON(e, t) {
    if (!t)
      throw new RangeError("Invalid input for Node.fromJSON");
    let n;
    if (t.marks) {
      if (!Array.isArray(t.marks))
        throw new RangeError("Invalid mark data for Node.fromJSON");
      n = t.marks.map(e.markFromJSON);
    }
    if (t.type == "text") {
      if (typeof t.text != "string")
        throw new RangeError("Invalid text node in JSON");
      return e.text(t.text, n);
    }
    let i = m.fromJSON(e, t.content);
    return e.nodeType(t.type).create(t.attrs, i, n);
  }
}
P.prototype.text = void 0;
class Oe extends P {
  /**
  @internal
  */
  constructor(e, t, n, i) {
    if (super(e, t, null, i), !n)
      throw new RangeError("Empty text nodes are not allowed");
    this.text = n;
  }
  toString() {
    return this.type.spec.toDebugString ? this.type.spec.toDebugString(this) : At(this.marks, JSON.stringify(this.text));
  }
  get textContent() {
    return this.text;
  }
  textBetween(e, t) {
    return this.text.slice(e, t);
  }
  get nodeSize() {
    return this.text.length;
  }
  mark(e) {
    return e == this.marks ? this : new Oe(this.type, this.attrs, this.text, e);
  }
  withText(e) {
    return e == this.text ? this : new Oe(this.type, this.attrs, e, this.marks);
  }
  cut(e = 0, t = this.text.length) {
    return e == 0 && t == this.text.length ? this : this.withText(this.text.slice(e, t));
  }
  eq(e) {
    return this.sameMarkup(e) && this.text == e.text;
  }
  toJSON() {
    let e = super.toJSON();
    return e.text = this.text, e;
  }
}
function At(r, e) {
  for (let t = r.length - 1; t >= 0; t--)
    e = r[t].type.name + "(" + e + ")";
  return e;
}
function tt(r, e, t, n) {
  for (let i in e)
    if (!(i in r))
      throw new RangeError(`Unsupported attribute ${i} for ${t} of type ${n}`);
  for (let i in r)
    r[i].validate && r[i].validate(e[i]);
}
class Q {
  /**
  @internal
  */
  constructor(e) {
    this.validEnd = e, this.next = [], this.wrapCache = [];
  }
  /**
  @internal
  */
  static parse(e, t) {
    let n = new un(e, t);
    if (n.next == null)
      return Q.empty;
    let i = Mt(n);
    n.next && n.err("Unexpected trailing text");
    let s = bn(kn(i));
    return Sn(s, n), s;
  }
  /**
  Match a node type, returning a match after that node if
  successful.
  */
  matchType(e) {
    for (let t = 0; t < this.next.length; t++)
      if (this.next[t].type == e)
        return this.next[t].next;
    return null;
  }
  /**
  Try to match a fragment. Returns the resulting match when
  successful.
  */
  matchFragment(e, t = 0, n = e.childCount) {
    let i = this;
    for (let s = t; i && s < n; s++)
      i = i.matchType(e.child(s).type);
    return i;
  }
  /**
  @internal
  */
  get inlineContent() {
    return this.next.length != 0 && this.next[0].type.isInline;
  }
  /**
  Get the first matching node type at this match position that can
  be generated.
  */
  get defaultType() {
    for (let e = 0; e < this.next.length; e++) {
      let { type: t } = this.next[e];
      if (!(t.isText || t.hasRequiredAttrs()))
        return t;
    }
    return null;
  }
  /**
  @internal
  */
  compatible(e) {
    for (let t = 0; t < this.next.length; t++)
      for (let n = 0; n < e.next.length; n++)
        if (this.next[t].type == e.next[n].type)
          return !0;
    return !1;
  }
  /**
  Try to match the given fragment, and if that fails, see if it can
  be made to match by inserting nodes in front of it. When
  successful, return a fragment of inserted nodes (which may be
  empty if nothing had to be inserted). When `toEnd` is true, only
  return a fragment if the resulting match goes to the end of the
  content expression.
  */
  fillBefore(e, t = !1, n = 0) {
    let i = [this];
    function s(o, a) {
      let l = o.matchFragment(e, n);
      if (l && (!t || l.validEnd))
        return m.from(a.map((h) => h.createAndFill()));
      for (let h = 0; h < o.next.length; h++) {
        let { type: c, next: p } = o.next[h];
        if (!(c.isText || c.hasRequiredAttrs()) && i.indexOf(p) == -1) {
          i.push(p);
          let f = s(p, a.concat(c));
          if (f)
            return f;
        }
      }
      return null;
    }
    return s(this, []);
  }
  /**
  Find a set of wrapping node types that would allow a node of the
  given type to appear at this position. The result may be empty
  (when it fits directly) and will be null when no such wrapping
  exists.
  */
  findWrapping(e) {
    for (let n = 0; n < this.wrapCache.length; n += 2)
      if (this.wrapCache[n] == e)
        return this.wrapCache[n + 1];
    let t = this.computeWrapping(e);
    return this.wrapCache.push(e, t), t;
  }
  /**
  @internal
  */
  computeWrapping(e) {
    let t = /* @__PURE__ */ Object.create(null), n = [{ match: this, type: null, via: null }];
    for (; n.length; ) {
      let i = n.shift(), s = i.match;
      if (s.matchType(e)) {
        let o = [];
        for (let a = i; a.type; a = a.via)
          o.push(a.type);
        return o.reverse();
      }
      for (let o = 0; o < s.next.length; o++) {
        let { type: a, next: l } = s.next[o];
        !a.isLeaf && !a.hasRequiredAttrs() && !(a.name in t) && (!i.type || l.validEnd) && (n.push({ match: a.contentMatch, type: a, via: i }), t[a.name] = !0);
      }
    }
    return null;
  }
  /**
  The number of outgoing edges this node has in the finite
  automaton that describes the content expression.
  */
  get edgeCount() {
    return this.next.length;
  }
  /**
  Get the _n_​th outgoing edge from this node in the finite
  automaton that describes the content expression.
  */
  edge(e) {
    if (e >= this.next.length)
      throw new RangeError(`There's no ${e}th edge in this content match`);
    return this.next[e];
  }
  /**
  @internal
  */
  toString() {
    let e = [];
    function t(n) {
      e.push(n);
      for (let i = 0; i < n.next.length; i++)
        e.indexOf(n.next[i].next) == -1 && t(n.next[i].next);
    }
    return t(this), e.map((n, i) => {
      let s = i + (n.validEnd ? "*" : " ") + " ";
      for (let o = 0; o < n.next.length; o++)
        s += (o ? ", " : "") + n.next[o].type.name + "->" + e.indexOf(n.next[o].next);
      return s;
    }).join(`
`);
  }
}
Q.empty = new Q(!0);
class un {
  constructor(e, t) {
    this.string = e, this.nodeTypes = t, this.inline = null, this.pos = 0, this.tokens = e.split(/\s*(?=\b|\W|$)/), this.tokens[this.tokens.length - 1] == "" && this.tokens.pop(), this.tokens[0] == "" && this.tokens.shift();
  }
  get next() {
    return this.tokens[this.pos];
  }
  eat(e) {
    return this.next == e && (this.pos++ || !0);
  }
  err(e) {
    throw new SyntaxError(e + " (in content expression '" + this.string + "')");
  }
}
function Mt(r) {
  let e = [];
  do
    e.push(mn(r));
  while (r.eat("|"));
  return e.length == 1 ? e[0] : { type: "choice", exprs: e };
}
function mn(r) {
  let e = [];
  do
    e.push(gn(r));
  while (r.next && r.next != ")" && r.next != "|");
  return e.length == 1 ? e[0] : { type: "seq", exprs: e };
}
function gn(r) {
  let e = xn(r);
  for (; ; )
    if (r.eat("+"))
      e = { type: "plus", expr: e };
    else if (r.eat("*"))
      e = { type: "star", expr: e };
    else if (r.eat("?"))
      e = { type: "opt", expr: e };
    else if (r.eat("{"))
      e = yn(r, e);
    else
      break;
  return e;
}
function nt(r) {
  /\D/.test(r.next) && r.err("Expected number, got '" + r.next + "'");
  let e = Number(r.next);
  return r.pos++, e;
}
function yn(r, e) {
  let t = nt(r), n = t;
  return r.eat(",") && (r.next != "}" ? n = nt(r) : n = -1), r.eat("}") || r.err("Unclosed braced range"), { type: "range", min: t, max: n, expr: e };
}
function wn(r, e) {
  let t = r.nodeTypes, n = t[e];
  if (n)
    return [n];
  let i = [];
  for (let s in t) {
    let o = t[s];
    o.isInGroup(e) && i.push(o);
  }
  return i.length == 0 && r.err("No node type or group '" + e + "' found"), i;
}
function xn(r) {
  if (r.eat("(")) {
    let e = Mt(r);
    return r.eat(")") || r.err("Missing closing paren"), e;
  } else if (/\W/.test(r.next))
    r.err("Unexpected token '" + r.next + "'");
  else {
    let e = wn(r, r.next).map((t) => (r.inline == null ? r.inline = t.isInline : r.inline != t.isInline && r.err("Mixing inline and block content"), { type: "name", value: t }));
    return r.pos++, e.length == 1 ? e[0] : { type: "choice", exprs: e };
  }
}
function kn(r) {
  let e = [[]];
  return i(s(r, 0), t()), e;
  function t() {
    return e.push([]) - 1;
  }
  function n(o, a, l) {
    let h = { term: l, to: a };
    return e[o].push(h), h;
  }
  function i(o, a) {
    o.forEach((l) => l.to = a);
  }
  function s(o, a) {
    if (o.type == "choice")
      return o.exprs.reduce((l, h) => l.concat(s(h, a)), []);
    if (o.type == "seq")
      for (let l = 0; ; l++) {
        let h = s(o.exprs[l], a);
        if (l == o.exprs.length - 1)
          return h;
        i(h, a = t());
      }
    else if (o.type == "star") {
      let l = t();
      return n(a, l), i(s(o.expr, l), l), [n(l)];
    } else if (o.type == "plus") {
      let l = t();
      return i(s(o.expr, a), l), i(s(o.expr, l), l), [n(l)];
    } else {
      if (o.type == "opt")
        return [n(a)].concat(s(o.expr, a));
      if (o.type == "range") {
        let l = a;
        for (let h = 0; h < o.min; h++) {
          let c = t();
          i(s(o.expr, l), c), l = c;
        }
        if (o.max == -1)
          i(s(o.expr, l), l);
        else
          for (let h = o.min; h < o.max; h++) {
            let c = t();
            n(l, c), i(s(o.expr, l), c), l = c;
          }
        return [n(l)];
      } else {
        if (o.type == "name")
          return [n(a, void 0, o.value)];
        throw new Error("Unknown expr type");
      }
    }
  }
}
function Ct(r, e) {
  return e - r;
}
function rt(r, e) {
  let t = [];
  return n(e), t.sort(Ct);
  function n(i) {
    let s = r[i];
    if (s.length == 1 && !s[0].term)
      return n(s[0].to);
    t.push(i);
    for (let o = 0; o < s.length; o++) {
      let { term: a, to: l } = s[o];
      !a && t.indexOf(l) == -1 && n(l);
    }
  }
}
function bn(r) {
  let e = /* @__PURE__ */ Object.create(null);
  return t(rt(r, 0));
  function t(n) {
    let i = [];
    n.forEach((o) => {
      r[o].forEach(({ term: a, to: l }) => {
        if (!a)
          return;
        let h;
        for (let c = 0; c < i.length; c++)
          i[c][0] == a && (h = i[c][1]);
        rt(r, l).forEach((c) => {
          h || i.push([a, h = []]), h.indexOf(c) == -1 && h.push(c);
        });
      });
    });
    let s = e[n.join(",")] = new Q(n.indexOf(r.length - 1) > -1);
    for (let o = 0; o < i.length; o++) {
      let a = i[o][1].sort(Ct);
      s.next.push({ type: i[o][0], next: e[a.join(",")] || t(a) });
    }
    return s;
  }
}
function Sn(r, e) {
  for (let t = 0, n = [r]; t < n.length; t++) {
    let i = n[t], s = !i.validEnd, o = [];
    for (let a = 0; a < i.next.length; a++) {
      let { type: l, next: h } = i.next[a];
      o.push(l.name), s && !(l.isText || l.hasRequiredAttrs()) && (s = !1), n.indexOf(h) == -1 && n.push(h);
    }
    s && e.err("Only non-generatable nodes (" + o.join(", ") + ") in a required position (see https://prosemirror.net/docs/guide/#generatable)");
  }
}
function Nt(r) {
  let e = /* @__PURE__ */ Object.create(null);
  for (let t in r) {
    let n = r[t];
    if (!n.hasDefault)
      return null;
    e[t] = n.default;
  }
  return e;
}
function Rt(r, e) {
  let t = /* @__PURE__ */ Object.create(null);
  for (let n in r) {
    let i = r[n], s = e && e[n];
    if (s === void 0)
      if (i.hasDefault)
        s = i.default;
      else
        throw new RangeError("No value supplied for attribute " + n);
    else i.validate && i.validate(s);
    t[n] = s;
  }
  return t;
}
function zt(r, e) {
  let t = /* @__PURE__ */ Object.create(null);
  if (e)
    for (let n in e)
      t[n] = new En(r, n, e[n]);
  return t;
}
class Ee {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.name = e, this.schema = t, this.spec = n, this.markSet = null, this.groups = n.group ? n.group.split(" ") : [], this.attrs = zt(e, n.attrs), this.defaultAttrs = Nt(this.attrs), this.contentMatch = null, this.inlineContent = null, this.isBlock = !(n.inline || e == "text"), this.isText = e == "text";
  }
  /**
  True if this is an inline type.
  */
  get isInline() {
    return !this.isBlock;
  }
  /**
  True if this is a textblock type, a block that contains inline
  content.
  */
  get isTextblock() {
    return this.isBlock && this.inlineContent;
  }
  /**
  True for node types that allow no content.
  */
  get isLeaf() {
    return this.contentMatch == Q.empty;
  }
  /**
  True when this node is an atom, i.e. when it does not have
  directly editable content.
  */
  get isAtom() {
    return this.isLeaf || !!this.spec.atom;
  }
  /**
  Return true when this node type is part of the given
  [group](https://prosemirror.net/docs/ref/#model.NodeSpec.group).
  */
  isInGroup(e) {
    return this.groups.indexOf(e) > -1;
  }
  /**
  The node type's [whitespace](https://prosemirror.net/docs/ref/#model.NodeSpec.whitespace) option.
  */
  get whitespace() {
    return this.spec.whitespace || (this.spec.code ? "pre" : "normal");
  }
  /**
  Tells you whether this node type has any required attributes.
  */
  hasRequiredAttrs() {
    for (let e in this.attrs)
      if (this.attrs[e].isRequired)
        return !0;
    return !1;
  }
  /**
  Indicates whether this node allows some of the same content as
  the given node type.
  */
  compatibleContent(e) {
    return this == e || this.contentMatch.compatible(e.contentMatch);
  }
  /**
  @internal
  */
  computeAttrs(e) {
    return !e && this.defaultAttrs ? this.defaultAttrs : Rt(this.attrs, e);
  }
  /**
  Create a `Node` of this type. The given attributes are
  checked and defaulted (you can pass `null` to use the type's
  defaults entirely, if no required attributes exist). `content`
  may be a `Fragment`, a node, an array of nodes, or
  `null`. Similarly `marks` may be `null` to default to the empty
  set of marks.
  */
  create(e = null, t, n) {
    if (this.isText)
      throw new Error("NodeType.create can't construct text nodes");
    return new P(this, this.computeAttrs(e), m.from(t), S.setFrom(n));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but check the given content
  against the node type's content restrictions, and throw an error
  if it doesn't match.
  */
  createChecked(e = null, t, n) {
    return t = m.from(t), this.checkContent(t), new P(this, this.computeAttrs(e), t, S.setFrom(n));
  }
  /**
  Like [`create`](https://prosemirror.net/docs/ref/#model.NodeType.create), but see if it is
  necessary to add nodes to the start or end of the given fragment
  to make it fit the node. If no fitting wrapping can be found,
  return null. Note that, due to the fact that required nodes can
  always be created, this will always succeed if you pass null or
  `Fragment.empty` as content.
  */
  createAndFill(e = null, t, n) {
    if (e = this.computeAttrs(e), t = m.from(t), t.size) {
      let o = this.contentMatch.fillBefore(t);
      if (!o)
        return null;
      t = o.append(t);
    }
    let i = this.contentMatch.matchFragment(t), s = i && i.fillBefore(m.empty, !0);
    return s ? new P(this, e, t.append(s), S.setFrom(n)) : null;
  }
  /**
  Returns true if the given fragment is valid content for this node
  type.
  */
  validContent(e) {
    let t = this.contentMatch.matchFragment(e);
    if (!t || !t.validEnd)
      return !1;
    for (let n = 0; n < e.childCount; n++)
      if (!this.allowsMarks(e.child(n).marks))
        return !1;
    return !0;
  }
  /**
  Throws a RangeError if the given fragment is not valid content for this
  node type.
  @internal
  */
  checkContent(e) {
    if (!this.validContent(e))
      throw new RangeError(`Invalid content for node ${this.name}: ${e.toString().slice(0, 50)}`);
  }
  /**
  @internal no longer useful, but called by old prosemirror-view versions
  */
  checkAttrs(e) {
  }
  /**
  Check whether the given mark type is allowed in this node.
  */
  allowsMarkType(e) {
    return this.markSet == null || this.markSet.indexOf(e) > -1;
  }
  /**
  Test whether the given set of marks are allowed in this node.
  */
  allowsMarks(e) {
    if (this.markSet == null)
      return !0;
    for (let t = 0; t < e.length; t++)
      if (!this.allowsMarkType(e[t].type))
        return !1;
    return !0;
  }
  /**
  Removes the marks that are not allowed in this node from the given set.
  */
  allowedMarks(e) {
    if (this.markSet == null)
      return e;
    let t;
    for (let n = 0; n < e.length; n++)
      this.allowsMarkType(e[n].type) ? t && t.push(e[n]) : t || (t = e.slice(0, n));
    return t ? t.length ? t : S.none : e;
  }
  /**
  @internal
  */
  static compile(e, t) {
    let n = /* @__PURE__ */ Object.create(null);
    e.forEach((s, o) => n[s] = new Ee(s, t, o));
    let i = t.spec.topNode || "doc";
    if (!n[i])
      throw new RangeError("Schema is missing its top node type ('" + i + "')");
    if (!n.text)
      throw new RangeError("Every schema needs a 'text' type");
    for (let s in n.text.attrs)
      throw new RangeError("The text node type should not have attributes");
    return n;
  }
}
function On(r, e, t) {
  let n = t.split("|");
  return (i) => {
    let s = i === null ? "null" : typeof i;
    if (n.indexOf(s) < 0)
      throw new RangeError(`Expected value of type ${n} for attribute ${e} on type ${r}, got ${s}`);
  };
}
class En {
  constructor(e, t, n) {
    this.hasDefault = Object.prototype.hasOwnProperty.call(n, "default"), this.default = n.default, this.validate = typeof n.validate == "string" ? On(e, t, n.validate) : n.validate;
  }
  get isRequired() {
    return !this.hasDefault;
  }
}
class Ne {
  /**
  @internal
  */
  constructor(e, t, n, i) {
    this.name = e, this.rank = t, this.schema = n, this.spec = i, this.attrs = zt(e, i.attrs), this.excluded = null;
    let s = Nt(this.attrs);
    this.instance = s ? new S(this, s) : null;
  }
  /**
  Create a mark of this type. `attrs` may be `null` or an object
  containing only some of the mark's attributes. The others, if
  they have defaults, will be added.
  */
  create(e = null) {
    return !e && this.instance ? this.instance : new S(this, Rt(this.attrs, e));
  }
  /**
  @internal
  */
  static compile(e, t) {
    let n = /* @__PURE__ */ Object.create(null), i = 0;
    return e.forEach((s, o) => n[s] = new Ne(s, i++, t, o)), n;
  }
  /**
  When there is a mark of this type in the given set, a new set
  without it is returned. Otherwise, the input set is returned.
  */
  removeFromSet(e) {
    for (var t = 0; t < e.length; t++)
      e[t].type == this && (e = e.slice(0, t).concat(e.slice(t + 1)), t--);
    return e;
  }
  /**
  Tests whether there is a mark of this type in the given set.
  */
  isInSet(e) {
    for (let t = 0; t < e.length; t++)
      if (e[t].type == this)
        return e[t];
  }
  /**
  Queries whether a given mark type is
  [excluded](https://prosemirror.net/docs/ref/#model.MarkSpec.excludes) by this one.
  */
  excludes(e) {
    return this.excluded.indexOf(e) > -1;
  }
}
class In {
  /**
  Construct a schema from a schema [specification](https://prosemirror.net/docs/ref/#model.SchemaSpec).
  */
  constructor(e) {
    this.linebreakReplacement = null, this.cached = /* @__PURE__ */ Object.create(null);
    let t = this.spec = {};
    for (let i in e)
      t[i] = e[i];
    t.nodes = A.from(e.nodes), t.marks = A.from(e.marks || {}), this.nodes = Ee.compile(this.spec.nodes, this), this.marks = Ne.compile(this.spec.marks, this);
    let n = /* @__PURE__ */ Object.create(null);
    for (let i in this.nodes) {
      if (i in this.marks)
        throw new RangeError(i + " can not be both a node and a mark");
      let s = this.nodes[i], o = s.spec.content || "", a = s.spec.marks;
      if (s.contentMatch = n[o] || (n[o] = Q.parse(o, this.nodes)), s.inlineContent = s.contentMatch.inlineContent, s.spec.linebreakReplacement) {
        if (this.linebreakReplacement)
          throw new RangeError("Multiple linebreak nodes defined");
        if (!s.isInline || !s.isLeaf)
          throw new RangeError("Linebreak replacement nodes must be inline leaf nodes");
        this.linebreakReplacement = s;
      }
      s.markSet = a == "_" ? null : a ? it(this, a.split(" ")) : a == "" || !s.inlineContent ? [] : null;
    }
    for (let i in this.marks) {
      let s = this.marks[i], o = s.spec.excludes;
      s.excluded = o == null ? [s] : o == "" ? [] : it(this, o.split(" "));
    }
    this.nodeFromJSON = (i) => P.fromJSON(this, i), this.markFromJSON = (i) => S.fromJSON(this, i), this.topNodeType = this.nodes[this.spec.topNode || "doc"], this.cached.wrappings = /* @__PURE__ */ Object.create(null);
  }
  /**
  Create a node in this schema. The `type` may be a string or a
  `NodeType` instance. Attributes will be extended with defaults,
  `content` may be a `Fragment`, `null`, a `Node`, or an array of
  nodes.
  */
  node(e, t = null, n, i) {
    if (typeof e == "string")
      e = this.nodeType(e);
    else if (e instanceof Ee) {
      if (e.schema != this)
        throw new RangeError("Node type from different schema used (" + e.name + ")");
    } else throw new RangeError("Invalid node type: " + e);
    return e.createChecked(t, n, i);
  }
  /**
  Create a text node in the schema. Empty text nodes are not
  allowed.
  */
  text(e, t) {
    let n = this.nodes.text;
    return new Oe(n, n.defaultAttrs, e, S.setFrom(t));
  }
  /**
  Create a mark with the given type and attributes.
  */
  mark(e, t) {
    return typeof e == "string" && (e = this.marks[e]), e.create(t);
  }
  /**
  @internal
  */
  nodeType(e) {
    let t = this.nodes[e];
    if (!t)
      throw new RangeError("Unknown node type: " + e);
    return t;
  }
}
function it(r, e) {
  let t = [];
  for (let n = 0; n < e.length; n++) {
    let i = e[n], s = r.marks[i], o = s;
    if (s)
      t.push(s);
    else
      for (let a in r.marks) {
        let l = r.marks[a];
        (i == "_" || l.spec.group && l.spec.group.split(" ").indexOf(i) > -1) && t.push(o = l);
      }
    if (!o)
      throw new SyntaxError("Unknown mark type: '" + e[n] + "'");
  }
  return t;
}
const Ie = (r) => r.length === 0 ? void 0 : Object.fromEntries(
  r.map((e) => [
    e.name,
    {
      default: e.default,
      validate: on(e.validator)
    }
  ])
), vn = (r) => ({
  ...r.content !== null ? { content: r.content } : {},
  ...r.group !== null ? { group: r.group } : {},
  ...r.marks !== null ? { marks: r.marks } : {},
  ...r.inline ? { inline: !0 } : {},
  ...r.atom ? { atom: !0 } : {},
  ...r.isolating ? { isolating: !0 } : {},
  ...r.defining ? { defining: !0 } : {},
  ...r.selectable ? {} : { selectable: !1 },
  ...r.draggable ? { draggable: !0 } : {},
  ...r.code ? { code: !0 } : {},
  ...r.whitespace !== null ? { whitespace: r.whitespace } : {},
  ...r.linebreakReplacement ? { linebreakReplacement: !0 } : {},
  ...Ie(r.attrs) ? { attrs: Ie(r.attrs) } : {}
}), Tn = (r) => ({
  ...r.group !== null ? { group: r.group } : {},
  ...r.excludes !== null ? { excludes: r.excludes } : {},
  ...r.inclusive ? {} : { inclusive: !1 },
  ...r.spanning ? {} : { spanning: !1 },
  ...Ie(r.attrs) ? { attrs: Ie(r.attrs) } : {},
  ...r.code ? { code: !0 } : {}
}), An = new In({
  topNode: q.topNode,
  nodes: Object.fromEntries(
    q.nodes.map((r) => [
      r.key,
      vn(r)
    ])
  ),
  marks: Object.fromEntries(
    q.marks.map((r) => [
      r.key,
      Tn(r)
    ])
  )
}), Mn = () => An, Cn = /^[a-z][a-z0-9]*_[a-z0-9]+$/, Qr = "blockId", Nn = (r) => typeof r == "string" && r.length > 3 && r.length <= 64 && Cn.test(r), Ft = new Set(
  q.nodes.filter((r) => r.attrs.some((e) => e.name === "blockId")).map((r) => r.key)
), ge = (r) => !!r && typeof r == "object" && !Array.isArray(r), Rn = (r) => r.length === 0 ? "$.body.content" : `$.body.content.${r.map((e) => `content[${e}]`).join(".")}`, Dt = (r) => typeof r.text == "string" ? r.text.length : r.type === "hardBreak" ? 1 : Array.isArray(r.content) ? r.content.reduce(
  (e, t) => e + (ge(t) ? Dt(t) : 0),
  0
) : 0, zn = (r) => {
  wt(r);
  const e = [], t = [], n = [], i = /* @__PURE__ */ new Set();
  let s = 0;
  const o = (a, l) => {
    const h = typeof a.type == "string" ? a.type : "unknown", c = Rn(l);
    if (Ft.has(h)) {
      const p = ge(a.attrs) ? a.attrs : {}, f = typeof p.blockId == "string" ? p.blockId : null, d = f ? Nn(f) ? i.has(f) ? "duplicate-block-id" : null : "invalid-block-id" : "missing-block-id";
      if (d)
        e.push({ code: d, path: c, nodeType: h, blockId: f });
      else if (f) {
        i.add(f);
        const { content: u, ...x } = a;
        t.push({
          blockId: f,
          nodeType: h,
          path: c,
          order: s++,
          utf16TextLength: Dt(a),
          nodeFingerprint: Y(x),
          subtreeFingerprint: Y(a)
        }), n.push({
          blockId: f,
          path: c,
          nodeType: h,
          documentAttrs: { blockId: f },
          renderAttrs: {
            dataBlockId: f,
            domId: h === "heading" ? f : null
          }
        });
      }
    }
    Array.isArray(a.content) && a.content.forEach((p, f) => {
      ge(p) && o(p, [...l, f]);
    });
  };
  return ge(r) && o(r, []), D({
    valid: e.length === 0,
    issues: e,
    index: t,
    attrSynchronization: n,
    canonicalFingerprint: Y({ index: t, attrSynchronization: n })
  });
}, Zr = () => D([...Ft]), Fn = 2, Dn = "stable-block-identity/v2", Be = {
  id: "zx.text-editor.document-v2-verifier",
  version: "2.1.0",
  schemaKernel: {
    id: q.schemaKernelId,
    version: q.schemaKernelVersion,
    fingerprint: q.schemaKernelFingerprint
  },
  pipeline: [
    "bounded-canonical-input",
    "exact-envelope-shape",
    "exact-node-mark-shape",
    "prosemirror-node-from-json",
    "stable-identity",
    "annotation-utf16-cross-block-lf-quote-context",
    "exact-asset-recursive-pages-header-footer-binary-export-meta-contract",
    "full-envelope-canonical-roundtrip"
  ],
  diagnosticAggregation: "continue-safe-independent-checks-after-exact-structural-admission"
}, Bn = D({
  id: Be.id,
  version: Be.version,
  fingerprint: Y(Be)
}), w = (r) => !!r && typeof r == "object" && !Array.isArray(r), k = (r, e, t = []) => {
  const n = Object.keys(r), i = /* @__PURE__ */ new Set([...e, ...t]);
  return e.every((s) => Object.hasOwn(r, s)) && n.every((s) => i.has(s));
}, y = (r, e, t, n = {}) => ({ code: r, path: e, message: t, ...n }), Jn = (r) => r.reduce(
  (e, t) => (e[t.code] = (e[t.code] ?? 0) + 1, e),
  {}
), re = (r, e) => D({
  valid: r.length === 0,
  issueCount: r.length,
  issues: [...r],
  unresolvedAnnotations: r.filter(
    (t) => t.code === "annotation-unresolved"
  ).length,
  headingIdentityViolations: r.filter(
    (t) => t.code === "heading-identity-uninferable"
  ).length,
  counts: Jn(r),
  documentFingerprint: e,
  verifier: Bn
}), jn = new Map(
  q.nodes.map((r) => [
    r.key,
    r
  ])
), Pn = new Map(
  q.marks.map((r) => [
    r.key,
    r
  ])
), Ln = (r, e, t) => {
  if (!w(r) || !k(r, ["type"], ["attrs"])) {
    t.push(y("document-shape-invalid", e, "Mark shape is invalid."));
    return;
  }
  const n = typeof r.type == "string" ? Pn.get(r.type) : void 0;
  if (!n) {
    t.push(
      y("document-schema-invalid", `${e}.type`, "Unknown mark type.")
    );
    return;
  }
  const i = n.attrs.map((s) => s.name);
  if (i.length === 0) {
    Object.hasOwn(r, "attrs") && t.push(
      y(
        "document-shape-invalid",
        `${e}.attrs`,
        "Mark has no attributes."
      )
    );
    return;
  }
  (!w(r.attrs) || !k(r.attrs, i)) && t.push(
    y(
      "document-shape-invalid",
      `${e}.attrs`,
      "Mark attributes are not exact."
    )
  );
}, Bt = (r, e, t, n) => {
  if (n.nodes += 1, n.nodes > ke.maxNodes) {
    t.push(
      y(
        "document-resource-limit-exceeded",
        e,
        "Document node count exceeds the package limit.",
        { count: n.nodes }
      )
    );
    return;
  }
  if (!w(r)) {
    t.push(
      y("document-shape-invalid", e, "Node must be an object.")
    );
    return;
  }
  const i = typeof r.type == "string" ? r.type : null, s = i ? jn.get(i) : void 0;
  if (!s) {
    t.push(
      y("document-schema-invalid", `${e}.type`, "Unknown node type.")
    );
    return;
  }
  const o = i === "text", a = o ? ["type", "text", "marks"] : ["type", "attrs", "content", "marks"];
  (!Object.hasOwn(r, "type") || Object.keys(r).some((h) => !a.includes(h))) && t.push(
    y("document-shape-invalid", e, "Node properties are not exact.")
  ), o ? (typeof r.text != "string" || r.text.length === 0) && t.push(
    y(
      "document-shape-invalid",
      `${e}.text`,
      "Text must be non-empty."
    )
  ) : Object.hasOwn(r, "text") && t.push(
    y(
      "document-shape-invalid",
      `${e}.text`,
      "Only text nodes may contain text."
    )
  );
  const l = s.attrs.map((h) => h.name);
  l.length > 0 ? (!w(r.attrs) || !k(r.attrs, l)) && t.push(
    y(
      "document-shape-invalid",
      `${e}.attrs`,
      "Node attributes are not exact."
    )
  ) : Object.hasOwn(r, "attrs") && t.push(
    y(
      "document-shape-invalid",
      `${e}.attrs`,
      "Node has no attributes."
    )
  ), Object.hasOwn(r, "marks") && (Array.isArray(r.marks) ? (n.marks += r.marks.length, n.marks > ke.maxMarks ? t.push(
    y(
      "document-resource-limit-exceeded",
      `${e}.marks`,
      "Document mark count exceeds the package limit.",
      { count: n.marks }
    )
  ) : r.marks.forEach(
    (h, c) => Ln(h, `${e}.marks[${c}]`, t)
  )) : t.push(
    y(
      "document-shape-invalid",
      `${e}.marks`,
      "Marks must be an array."
    )
  )), Object.hasOwn(r, "content") && (Array.isArray(r.content) ? r.content.forEach(
    (h, c) => Bt(h, `${e}.content[${c}]`, t, n)
  ) : t.push(
    y(
      "document-shape-invalid",
      `${e}.content`,
      "Content must be an array."
    )
  ));
}, qn = (r, e, t, n) => {
  if (!w(r) || !k(
    r,
    ["id", "type", "src"],
    ["title", "mimeType", "meta"]
  ) || typeof r.id != "string" || !r.id || !["image", "video", "embed", "file"].includes(String(r.type)) || typeof r.src != "string" || Object.hasOwn(r, "title") && typeof r.title != "string" || Object.hasOwn(r, "mimeType") && typeof r.mimeType != "string") {
    n.push(
      y("asset-contract-invalid", e, "Asset contract is invalid.")
    );
    return;
  }
  t.has(r.id) && n.push(
    y("asset-contract-invalid", `${e}.id`, "Asset id is duplicated.")
  ), t.add(r.id), Object.hasOwn(r, "meta") && (!w(r.meta) || Object.values(r.meta).some(
    (i) => !["string", "number", "boolean"].includes(typeof i)
  )) && n.push(
    y(
      "asset-contract-invalid",
      `${e}.meta`,
      "Asset metadata is invalid."
    )
  );
}, _ = (r) => typeof r == "string" && r.length > 0, He = (r) => typeof r == "number" && Number.isFinite(r) && r >= 0, ve = (r) => typeof r == "number" && Number.isFinite(r) && r > 0, Jt = (r) => w(r) && k(r, ["top", "right", "bottom", "left"]) && ["top", "right", "bottom", "left"].every(
  (e) => He(r[e])
), Te = (r) => w(r) && k(
  r,
  [],
  ["sectionBreak", "pageBreakBefore", "headerFooterRole", "pageNumbering"]
) && (!Object.hasOwn(r, "sectionBreak") || ["document-start", "continuous", "next-page"].includes(
  String(r.sectionBreak)
)) && (!Object.hasOwn(r, "pageBreakBefore") || typeof r.pageBreakBefore == "boolean") && (!Object.hasOwn(r, "headerFooterRole") || ["default", "first-page", "none"].includes(
  String(r.headerFooterRole)
)) && (!Object.hasOwn(r, "pageNumbering") || ["inherit", "restart-1", "hidden"].includes(String(r.pageNumbering))), $n = (r) => w(r) && k(r, ["id"], ["label", "width", "height"]) && _(r.id) && (!Object.hasOwn(r, "label") || typeof r.label == "string") && (!Object.hasOwn(r, "width") || ve(r.width)) && (!Object.hasOwn(r, "height") || ve(r.height)), st = (r, e) => {
  if (!w(r)) return !1;
  const t = ["pageFormat", "orientation", "margins"];
  return k(r, e ? [] : t, e ? t : []) ? (!Object.hasOwn(r, "pageFormat") || $n(r.pageFormat)) && (!Object.hasOwn(r, "orientation") || r.orientation === "portrait" || r.orientation === "landscape") && (!Object.hasOwn(r, "margins") || Jt(r.margins)) : !1;
}, Wn = /* @__PURE__ */ new Set([
  "bold",
  "italic",
  "underline",
  "strike",
  "code",
  "link"
]), Vn = /* @__PURE__ */ new Set([
  "http:",
  "https:",
  "mailto:",
  "tel:"
]), Hn = (r) => {
  if (typeof r != "string" || r.length === 0 || r !== r.trim())
    return !1;
  try {
    const e = new URL(r, "https://zx.local");
    return Vn.has(e.protocol) || e.protocol === "https:" && !/^[a-z][a-z0-9+.-]*:/i.test(r);
  } catch {
    return !1;
  }
}, _n = (r) => !w(r) || typeof r.type != "string" || !Wn.has(r.type) ? !1 : r.type !== "link" ? k(r, ["type"]) : k(r, ["type", "attrs"]) && w(r.attrs) && k(r.attrs, ["href"]) && Hn(r.attrs.href), Kn = (r) => !w(r) || typeof r.type != "string" ? !1 : r.type === "hardBreak" ? k(r, ["type"]) : r.type === "text" && k(r, ["type", "text"], ["marks"]) && typeof r.text == "string" && (!Object.hasOwn(r, "marks") || Array.isArray(r.marks) && r.marks.every(_n)), Un = (r) => w(r) && r.type === "doc" && k(r, ["type"], ["content"]) && (!Object.hasOwn(r, "content") || Array.isArray(r.content) && r.content.every(
  (e) => w(e) && e.type === "paragraph" && k(e, ["type"], ["content"]) && (!Object.hasOwn(e, "content") || Array.isArray(e.content) && e.content.every(Kn))
)), Xn = (r) => w(r) && (r.state === "empty" && k(r, ["state"]) || r.state === "content" && k(r, ["state", "content"]) && Un(r.content)), Qn = ["default", "firstPage", "oddPage", "evenPage"], ue = (r) => w(r) && k(r, [], Qn) && Object.values(r).every(Xn), Zn = (r) => !w(r) || !k(
  r,
  ["version", "differentFirstPage", "differentOddEven"],
  ["headerTopMargin", "footerBottomMargin", "header", "footer", "sections"]
) || r.version !== 1 || typeof r.differentFirstPage != "boolean" || typeof r.differentOddEven != "boolean" || Object.hasOwn(r, "headerTopMargin") && !He(r.headerTopMargin) || Object.hasOwn(r, "footerBottomMargin") && !He(r.footerBottomMargin) || Object.hasOwn(r, "header") && !ue(r.header) || Object.hasOwn(r, "footer") && !ue(r.footer) || Object.hasOwn(r, "sections") && !Array.isArray(r.sections) ? !1 : !Array.isArray(r.sections) || r.sections.every(
  (e) => w(e) && k(
    e,
    ["sectionId"],
    [
      "startBlockId",
      "differentFirstPage",
      "differentOddEven",
      "header",
      "footer"
    ]
  ) && _(e.sectionId) && (!Object.hasOwn(e, "startBlockId") || _(e.startBlockId)) && (!Object.hasOwn(e, "differentFirstPage") || typeof e.differentFirstPage == "boolean") && (!Object.hasOwn(e, "differentOddEven") || typeof e.differentOddEven == "boolean") && (!Object.hasOwn(e, "header") || ue(e.header)) && (!Object.hasOwn(e, "footer") || ue(e.footer))
), Gn = (r) => {
  if (!w(r) || !k(
    r,
    ["version", "defaults"],
    ["sections", "headerFooter"]
  ) || r.version !== 1 || !w(r.defaults) || !k(r.defaults, ["page"], ["intent"]) || !st(r.defaults.page, !1) || Object.hasOwn(r.defaults, "intent") && !Te(r.defaults.intent) || Object.hasOwn(r, "headerFooter") && !Zn(r.headerFooter) || Object.hasOwn(r, "sections") && !Array.isArray(r.sections))
    return !1;
  const e = /* @__PURE__ */ new Set();
  return !Array.isArray(r.sections) || r.sections.every((t) => !w(t) || !k(t, ["id", "startBlockId"], ["page", "intent"]) || !_(t.id) || e.has(t.id) || !_(t.startBlockId) || Object.hasOwn(t, "page") && !st(t.page, !0) || Object.hasOwn(t, "intent") && !Te(t.intent) ? !1 : (e.add(t.id), !0));
}, ot = (r) => w(r) && k(
  r,
  [],
  ["size", "label", "width", "height", "orientation", "margins"]
) && (!Object.hasOwn(r, "size") || _(r.size)) && (!Object.hasOwn(r, "label") || typeof r.label == "string") && (!Object.hasOwn(r, "width") || ve(r.width)) && (!Object.hasOwn(r, "height") || ve(r.height)) && (!Object.hasOwn(r, "orientation") || r.orientation === "portrait" || r.orientation === "landscape") && (!Object.hasOwn(r, "margins") || Jt(r.margins)), Yn = (r) => {
  if (!w(r) || !k(r, [], ["defaults", "sections"]) || Object.hasOwn(r, "defaults") && (!w(r.defaults) || !k(r.defaults, [], ["page", "intent"]) || Object.hasOwn(r.defaults, "page") && !ot(r.defaults.page) || Object.hasOwn(r.defaults, "intent") && !Te(r.defaults.intent)) || Object.hasOwn(r, "sections") && !Array.isArray(r.sections))
    return !1;
  const e = /* @__PURE__ */ new Set();
  return !Array.isArray(r.sections) || r.sections.every((t) => !w(t) || !k(t, ["id", "startBlockId"], ["page", "intent"]) || !_(t.id) || e.has(t.id) || !_(t.startBlockId) || Object.hasOwn(t, "page") && !ot(t.page) || Object.hasOwn(t, "intent") && !Te(t.intent) ? !1 : (e.add(t.id), !0));
}, er = (r, e) => {
  if (!w(r) || !k(
    r,
    [],
    [
      "title",
      "author",
      "createdAt",
      "updatedAt",
      "source",
      "schemaVersion",
      "pages",
      "binaryExport"
    ]
  )) {
    e.push(
      y(
        "meta-contract-invalid",
        "$.meta",
        "Document metadata shape is invalid."
      )
    );
    return;
  }
  ["title", "author", "createdAt", "updatedAt", "schemaVersion"].forEach(
    (t) => {
      Object.hasOwn(r, t) && typeof r[t] != "string" && e.push(
        y(
          "meta-contract-invalid",
          `$.meta.${t}`,
          "Metadata field must be a string."
        )
      );
    }
  ), Object.hasOwn(r, "source") && r.source !== "editor" && r.source !== "import" && e.push(
    y(
      "meta-contract-invalid",
      "$.meta.source",
      "Metadata source is invalid."
    )
  ), ["pages", "binaryExport"].forEach((t) => {
    const n = t === "pages" ? Gn(r[t]) : Yn(r[t]);
    Object.hasOwn(r, t) && !n && e.push(
      y(
        "meta-contract-invalid",
        `$.meta.${t}`,
        "Metadata contract field must be an object."
      )
    );
  });
}, tr = (r, e, t) => {
  const n = /* @__PURE__ */ new Map();
  e.forEach((a) => {
    w(a) && typeof a.id == "string" && n.set(a.id, a);
  });
  const i = /* @__PURE__ */ new Set(), s = {
    attachment: "file",
    embed: "embed",
    iframe: "embed",
    image: "image",
    video: "video"
  }, o = (a, l) => {
    const h = w(a.attrs) ? a.attrs : null, c = typeof a.type == "string" ? a.type : "", p = typeof (h == null ? void 0 : h.assetId) == "string" ? h.assetId : null;
    if (p) {
      const f = n.get(p);
      if (!f || f.type !== s[c])
        t.push(
          y(
            "asset-contract-invalid",
            `${l}.attrs.assetId`,
            "Asset reference is unresolved or has the wrong type."
          )
        );
      else {
        i.add(p);
        const d = typeof (h == null ? void 0 : h.src) == "string" ? h.src : typeof (h == null ? void 0 : h.url) == "string" ? h.url : null;
        d !== null && d !== f.src && t.push(
          y(
            "asset-contract-invalid",
            `${l}.attrs.assetId`,
            "Asset reference source does not match the asset table."
          )
        );
      }
    }
    Array.isArray(a.content) && a.content.forEach((f, d) => {
      w(f) && o(f, `${l}.content[${d}]`);
    });
  };
  w(r) && o(r, "$.body.content"), e.forEach((a, l) => {
    w(a) && typeof a.id == "string" && a.type !== "file" && !i.has(a.id) && t.push(
      y(
        "asset-contract-invalid",
        `$.assets[${l}].id`,
        "Non-file asset is not referenced by the document."
      )
    );
  });
}, nr = (r) => {
  const e = /* @__PURE__ */ new Map(), t = (i) => typeof i.text == "string" ? i.text : i.type === "hardBreak" ? `
` : Array.isArray(i.content) ? i.content.map((s) => w(s) ? t(s) : "").join("") : "", n = (i) => {
    const s = w(i.attrs) ? i.attrs : null;
    typeof (s == null ? void 0 : s.blockId) == "string" && e.set(s.blockId, t(i)), Array.isArray(i.content) && i.content.forEach((o) => w(o) && n(o));
  };
  return w(r) && n(r), e;
}, rr = (r, e, t, n) => {
  const i = new Map(e.map((l) => [l.blockId, l])), s = nr(t), o = e.map((l) => ({
    blockId: l.blockId,
    order: l.order,
    text: s.get(l.blockId) ?? ""
  })), a = /* @__PURE__ */ new Set();
  r.forEach((l, h) => {
    const c = `$.annotations[${h}]`;
    if (!w(l) || !k(l, ["id", "type", "anchor", "resolved", "payload"]) || typeof l.id != "string" || !l.id || l.type !== "comment" || typeof l.resolved != "boolean" || !w(l.anchor) || !k(
      l.anchor,
      ["start", "end"],
      ["quote", "beforeQuote", "afterQuote"]
    ) || !w(l.payload) || !k(l.payload, ["threadId", "comments"]) || typeof l.payload.threadId != "string" || !Array.isArray(l.payload.comments)) {
      n.push(
        y(
          "annotation-contract-invalid",
          c,
          "Annotation contract is invalid."
        )
      );
      return;
    }
    a.has(l.id) && n.push(
      y(
        "annotation-contract-invalid",
        `${c}.id`,
        "Annotation id is duplicated."
      )
    ), a.add(l.id), l.payload.comments.forEach((b, pe) => {
      (!w(b) || !k(
        b,
        ["id", "content", "createdAt"],
        ["authorId", "updatedAt"]
      ) || ["id", "content", "createdAt"].some(
        (rn) => typeof b[rn] != "string"
      ) || Object.hasOwn(b, "authorId") && typeof b.authorId != "string" || Object.hasOwn(b, "updatedAt") && typeof b.updatedAt != "string") && n.push(
        y(
          "annotation-contract-invalid",
          `${c}.payload.comments[${pe}]`,
          "Annotation comment is invalid."
        )
      );
    });
    const p = l.anchor, f = (b) => w(b) && k(b, ["blockId", "offset"]) && typeof b.blockId == "string" && Number.isInteger(b.offset) && b.offset >= 0 ? { blockId: b.blockId, offset: b.offset } : null, d = f(p.start), u = f(p.end), x = d ? i.get(d.blockId) : void 0, O = u ? i.get(u.blockId) : void 0;
    if (!d || !u || !x || !O || d.offset > x.utf16TextLength || u.offset > O.utf16TextLength || x.order > O.order || d.blockId === u.blockId && d.offset >= u.offset) {
      n.push(
        y(
          "annotation-unresolved",
          `${c}.anchor`,
          "Annotation anchor is unresolved.",
          {
            annotationId: l.id,
            blockId: (d == null ? void 0 : d.blockId) ?? (u == null ? void 0 : u.blockId) ?? null
          }
        )
      );
      return;
    }
    ["quote", "beforeQuote", "afterQuote"].forEach((b) => {
      Object.hasOwn(p, b) && typeof p[b] != "string" && n.push(
        y(
          "annotation-contract-invalid",
          `${c}.anchor.${b}`,
          "Quote context must be a string."
        )
      );
    });
    const N = an(
      o,
      d,
      u
    );
    if (!N) {
      n.push(
        y(
          "annotation-unresolved",
          `${c}.anchor`,
          "Annotation text projection is unresolved.",
          {
            annotationId: l.id,
            blockId: d.blockId
          }
        )
      );
      return;
    }
    typeof p.quote == "string" && p.quote !== N.quote && n.push(
      y(
        "annotation-quote-mismatch",
        `${c}.anchor.quote`,
        "Annotation quote does not match UTF-16 range."
      )
    ), typeof p.beforeQuote == "string" && !N.before.endsWith(p.beforeQuote) && n.push(
      y(
        "annotation-quote-mismatch",
        `${c}.anchor.beforeQuote`,
        "Annotation leading context does not match."
      )
    ), typeof p.afterQuote == "string" && !N.after.startsWith(p.afterQuote) && n.push(
      y(
        "annotation-quote-mismatch",
        `${c}.anchor.afterQuote`,
        "Annotation trailing context does not match."
      )
    );
  });
}, ir = (r) => {
  let e;
  try {
    e = wt(r).canonical;
  } catch (l) {
    const h = l instanceof Error && l.name === "ZxCanonicalJSONResourceError";
    return re(
      [
        y(
          h ? "document-resource-limit-exceeded" : "document-content-invalid",
          "$",
          h ? "Document exceeds package resource limits." : "Document is not canonical JSON."
        )
      ],
      null
    );
  }
  const t = [];
  if (!w(r) || !k(r, ["version", "body", "annotations", "assets", "meta"]))
    return re(
      [
        y(
          "document-shape-invalid",
          "$",
          "Document v2 envelope is not exact."
        )
      ],
      null
    );
  if (r.version !== Fn && t.push(
    y(
      "document-version-mismatch",
      "$.version",
      "Document version is unsupported."
    )
  ), !w(r.body) || !k(r.body, ["format", "content"]) ? t.push(
    y("document-shape-invalid", "$.body", "Document body is not exact.")
  ) : (r.body.format !== "json" && t.push(
    y(
      "document-format-mismatch",
      "$.body.format",
      "Document body format must be json."
    )
  ), w(r.body.content) ? Bt(r.body.content, "$.body.content", t, {
    nodes: 0,
    marks: 0
  }) : t.push(
    y(
      "document-content-invalid",
      "$.body.content",
      "Document body content must be a node object."
    )
  )), Array.isArray(r.annotations) || t.push(
    y(
      "document-shape-invalid",
      "$.annotations",
      "Annotations must be an array."
    )
  ), !Array.isArray(r.assets))
    t.push(
      y("document-shape-invalid", "$.assets", "Assets must be an array.")
    );
  else {
    const l = /* @__PURE__ */ new Set();
    r.assets.forEach(
      (h, c) => qn(h, `$.assets[${c}]`, l, t)
    );
  }
  er(r.meta, t), w(r.meta) && r.meta.schemaVersion !== Dn && t.push(
    y(
      "document-schema-version-mismatch",
      "$.meta.schemaVersion",
      "Document schema version is unsupported."
    )
  );
  const n = /* @__PURE__ */ new Set([
    "document-content-invalid",
    "document-resource-limit-exceeded",
    "document-schema-invalid",
    "document-shape-invalid"
  ]);
  if (!w(r.body) || t.some((l) => n.has(l.code)))
    return re(t, null);
  let i;
  try {
    const l = Mn().nodeFromJSON(r.body.content);
    l.check(), i = l.toJSON();
  } catch {
    return re(
      [
        ...t,
        y(
          "document-schema-invalid",
          "$.body.content",
          "Document does not satisfy the exact schema kernel."
        )
      ],
      null
    );
  }
  const s = zn(i);
  s.issues.forEach((l) => {
    t.push(
      y(l.code, l.path, "Stable block identity is invalid.", {
        blockId: l.blockId
      })
    ), l.nodeType === "heading" && t.push(
      y(
        "heading-identity-uninferable",
        l.path,
        "Heading identity cannot be inferred.",
        {
          blockId: l.blockId
        }
      )
    );
  }), Array.isArray(r.assets) && tr(i, r.assets, t), Array.isArray(r.annotations) && rr(
    r.annotations,
    s.index,
    i,
    t
  );
  const o = {
    version: 2,
    body: { format: "json", content: i },
    annotations: r.annotations,
    assets: r.assets,
    meta: r.meta
  };
  return xe(o) !== e && t.push(
    y(
      "document-roundtrip-mismatch",
      "$",
      "Full document envelope is not canonical round-trip equivalent."
    )
  ), re(
    t,
    t.length === 0 ? Y(o) : null
  );
}, Gr = ir, jt = 65535, Pt = Math.pow(2, 16);
function sr(r, e) {
  return r + e * Pt;
}
function at(r) {
  return r & jt;
}
function or(r) {
  return (r - (r & jt)) / Pt;
}
const Lt = 1, qt = 2, ye = 4, $t = 8;
class _e {
  /**
  @internal
  */
  constructor(e, t, n) {
    this.pos = e, this.delInfo = t, this.recover = n;
  }
  /**
  Tells you whether the position was deleted, that is, whether the
  step removed the token on the side queried (via the `assoc`)
  argument from the document.
  */
  get deleted() {
    return (this.delInfo & $t) > 0;
  }
  /**
  Tells you whether the token before the mapped position was deleted.
  */
  get deletedBefore() {
    return (this.delInfo & (Lt | ye)) > 0;
  }
  /**
  True when the token after the mapped position was deleted.
  */
  get deletedAfter() {
    return (this.delInfo & (qt | ye)) > 0;
  }
  /**
  Tells whether any of the steps mapped through deletes across the
  position (including both the token before and after the
  position).
  */
  get deletedAcross() {
    return (this.delInfo & ye) > 0;
  }
}
class C {
  /**
  Create a position map. The modifications to the document are
  represented as an array of numbers, in which each group of three
  represents a modified chunk as `[start, oldSize, newSize]`.
  */
  constructor(e, t = !1) {
    if (this.ranges = e, this.inverted = t, !e.length && C.empty)
      return C.empty;
  }
  /**
  @internal
  */
  recover(e) {
    let t = 0, n = at(e);
    if (!this.inverted)
      for (let i = 0; i < n; i++)
        t += this.ranges[i * 3 + 2] - this.ranges[i * 3 + 1];
    return this.ranges[n * 3] + t + or(e);
  }
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  map(e, t = 1) {
    return this._map(e, t, !0);
  }
  /**
  @internal
  */
  _map(e, t, n) {
    let i = 0, s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let l = this.ranges[a] - (this.inverted ? i : 0);
      if (l > e)
        break;
      let h = this.ranges[a + s], c = this.ranges[a + o], p = l + h;
      if (e <= p) {
        let f = h ? e == l ? -1 : e == p ? 1 : t : t, d = l + i + (f < 0 ? 0 : c);
        if (n)
          return d;
        let u = e == (t < 0 ? l : p) ? null : sr(a / 3, e - l), x = 0;
        return h && (x |= e == l ? qt : e == p ? Lt : ye, (t < 0 ? e != l : e != p) && (x |= $t)), new _e(d, x, u);
      }
      i += c - h;
    }
    return n ? e + i : new _e(e + i, 0, null);
  }
  /**
  @internal
  */
  touches(e, t) {
    let n = 0, i = at(t), s = this.inverted ? 2 : 1, o = this.inverted ? 1 : 2;
    for (let a = 0; a < this.ranges.length; a += 3) {
      let l = this.ranges[a] - (this.inverted ? n : 0);
      if (l > e)
        break;
      let h = this.ranges[a + s], c = l + h;
      if (e <= c && a == i * 3)
        return !0;
      n += this.ranges[a + o] - h;
    }
    return !1;
  }
  /**
  Calls the given function on each of the changed ranges included in
  this map.
  */
  forEach(e) {
    let t = this.inverted ? 2 : 1, n = this.inverted ? 1 : 2;
    for (let i = 0, s = 0; i < this.ranges.length; i += 3) {
      let o = this.ranges[i], a = o - (this.inverted ? s : 0), l = o + (this.inverted ? 0 : s), h = this.ranges[i + t], c = this.ranges[i + n];
      e(a, a + h, l, l + c), s += c - h;
    }
  }
  /**
  Create an inverted version of this map. The result can be used to
  map positions in the post-step document to the pre-step document.
  */
  invert() {
    return new C(this.ranges, !this.inverted);
  }
  /**
  @internal
  */
  toString() {
    return (this.inverted ? "-" : "") + JSON.stringify(this.ranges);
  }
  /**
  Create a map that moves all positions by offset `n` (which may be
  negative). This can be useful when applying steps meant for a
  sub-document to a larger document, or vice-versa.
  */
  static offset(e) {
    return e == 0 ? C.empty : new C(e < 0 ? [0, -e, 0] : [0, 0, e]);
  }
}
C.empty = new C([]);
class te {
  /**
  Create a new mapping with the given position maps.
  */
  constructor(e, t, n = 0, i = e ? e.length : 0) {
    this.mirror = t, this.from = n, this.to = i, this._maps = e || [], this.ownData = !(e || t);
  }
  /**
  The step maps in this mapping.
  */
  get maps() {
    return this._maps;
  }
  /**
  Create a mapping that maps only through a part of this one.
  */
  slice(e = 0, t = this.maps.length) {
    return new te(this._maps, this.mirror, e, t);
  }
  /**
  Add a step map to the end of this mapping. If `mirrors` is
  given, it should be the index of the step map that is the mirror
  image of this one.
  */
  appendMap(e, t) {
    this.ownData || (this._maps = this._maps.slice(), this.mirror = this.mirror && this.mirror.slice(), this.ownData = !0), this.to = this._maps.push(e), t != null && this.setMirror(this._maps.length - 1, t);
  }
  /**
  Add all the step maps in a given mapping to this one (preserving
  mirroring information).
  */
  appendMapping(e) {
    for (let t = 0, n = this._maps.length; t < e._maps.length; t++) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t], i != null && i < t ? n + i : void 0);
    }
  }
  /**
  Finds the offset of the step map that mirrors the map at the
  given offset, in this mapping (as per the second argument to
  `appendMap`).
  */
  getMirror(e) {
    if (this.mirror) {
      for (let t = 0; t < this.mirror.length; t++)
        if (this.mirror[t] == e)
          return this.mirror[t + (t % 2 ? -1 : 1)];
    }
  }
  /**
  @internal
  */
  setMirror(e, t) {
    this.mirror || (this.mirror = []), this.mirror.push(e, t);
  }
  /**
  Append the inverse of the given mapping to this one.
  */
  appendMappingInverted(e) {
    for (let t = e.maps.length - 1, n = this._maps.length + e._maps.length; t >= 0; t--) {
      let i = e.getMirror(t);
      this.appendMap(e._maps[t].invert(), i != null && i > t ? n - i - 1 : void 0);
    }
  }
  /**
  Create an inverted version of this mapping.
  */
  invert() {
    let e = new te();
    return e.appendMappingInverted(this), e;
  }
  /**
  Map a position through this mapping.
  */
  map(e, t = 1) {
    if (this.mirror)
      return this._map(e, t, !0);
    for (let n = this.from; n < this.to; n++)
      e = this._maps[n].map(e, t);
    return e;
  }
  /**
  Map a position through this mapping, returning a mapping
  result.
  */
  mapResult(e, t = 1) {
    return this._map(e, t, !1);
  }
  /**
  @internal
  */
  _map(e, t, n) {
    let i = 0;
    for (let s = this.from; s < this.to; s++) {
      let o = this._maps[s], a = o.mapResult(e, t);
      if (a.recover != null) {
        let l = this.getMirror(s);
        if (l != null && l > s && l < this.to) {
          s = l, e = this._maps[l].recover(a.recover);
          continue;
        }
      }
      i |= a.delInfo, e = a.pos;
    }
    return n ? e : new _e(e, i, null);
  }
}
const Je = /* @__PURE__ */ Object.create(null);
class M {
  /**
  Get the step map that represents the changes made by this step,
  and which can be used to transform between positions in the old
  and the new document.
  */
  getMap() {
    return C.empty;
  }
  /**
  Try to merge this step with another one, to be applied directly
  after it. Returns the merged step when possible, null if the
  steps can't be merged.
  */
  merge(e) {
    return null;
  }
  /**
  Deserialize a step from its JSON representation. Will call
  through to the step class' own implementation of this method.
  */
  static fromJSON(e, t) {
    if (!t || !t.stepType)
      throw new RangeError("Invalid input for Step.fromJSON");
    let n = Je[t.stepType];
    if (!n)
      throw new RangeError(`No step type ${t.stepType} defined`);
    return n.fromJSON(e, t);
  }
  /**
  To be able to serialize steps to JSON, each step needs a string
  ID to attach to its JSON representation. Use this method to
  register an ID for your step classes. Try to pick something
  that's unlikely to clash with steps from other modules.
  */
  static jsonID(e, t) {
    if (e in Je)
      throw new RangeError("Duplicate use of step JSON ID " + e);
    return Je[e] = t, t.prototype.jsonID = e, t;
  }
}
class I {
  /**
  @internal
  */
  constructor(e, t) {
    this.doc = e, this.failed = t;
  }
  /**
  Create a successful step result.
  */
  static ok(e) {
    return new I(e, null);
  }
  /**
  Create a failed step result.
  */
  static fail(e) {
    return new I(null, e);
  }
  /**
  Call [`Node.replace`](https://prosemirror.net/docs/ref/#model.Node.replace) with the given
  arguments. Create a successful result if it succeeds, and a
  failed one if it throws a `ReplaceError`.
  */
  static fromReplace(e, t, n, i) {
    try {
      return I.ok(e.replace(t, n, i));
    } catch (s) {
      if (s instanceof he)
        return I.fail(s.message);
      throw s;
    }
  }
}
function Ue(r, e, t) {
  let n = [];
  for (let i = 0; i < r.childCount; i++) {
    let s = r.child(i);
    s.content.size && (s = s.copy(Ue(s.content, e, s))), s.isInline && (s = e(s, t, i)), n.push(s);
  }
  return m.fromArray(n);
}
class V extends M {
  /**
  Create a mark step.
  */
  constructor(e, t, n) {
    super(), this.from = e, this.to = t, this.mark = n;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), n = e.resolve(this.from), i = n.node(n.sharedDepth(this.to)), s = new g(Ue(t.content, (o, a) => !o.isAtom || !a.type.allowsMarkType(this.mark.type) ? o : o.mark(this.mark.addToSet(o.marks)), i), t.openStart, t.openEnd);
    return I.fromReplace(e, this.from, this.to, s);
  }
  invert() {
    return new J(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1);
    return t.deleted && n.deleted || t.pos >= n.pos ? null : new V(t.pos, n.pos, this.mark);
  }
  merge(e) {
    return e instanceof V && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new V(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "addMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for AddMarkStep.fromJSON");
    return new V(t.from, t.to, e.markFromJSON(t.mark));
  }
}
M.jsonID("addMark", V);
class J extends M {
  /**
  Create a mark-removing step.
  */
  constructor(e, t, n) {
    super(), this.from = e, this.to = t, this.mark = n;
  }
  apply(e) {
    let t = e.slice(this.from, this.to), n = new g(Ue(t.content, (i) => i.mark(this.mark.removeFromSet(i.marks)), e), t.openStart, t.openEnd);
    return I.fromReplace(e, this.from, this.to, n);
  }
  invert() {
    return new V(this.from, this.to, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1);
    return t.deleted && n.deleted || t.pos >= n.pos ? null : new J(t.pos, n.pos, this.mark);
  }
  merge(e) {
    return e instanceof J && e.mark.eq(this.mark) && this.from <= e.to && this.to >= e.from ? new J(Math.min(this.from, e.from), Math.max(this.to, e.to), this.mark) : null;
  }
  toJSON() {
    return {
      stepType: "removeMark",
      mark: this.mark.toJSON(),
      from: this.from,
      to: this.to
    };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for RemoveMarkStep.fromJSON");
    return new J(t.from, t.to, e.markFromJSON(t.mark));
  }
}
M.jsonID("removeMark", J);
class H extends M {
  /**
  Create a node mark step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return I.fail("No node at mark step's position");
    let n = t.type.create(t.attrs, null, this.mark.addToSet(t.marks));
    return I.fromReplace(e, this.pos, this.pos + 1, new g(m.from(n), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    if (t) {
      let n = this.mark.addToSet(t.marks);
      if (n.length == t.marks.length) {
        for (let i = 0; i < t.marks.length; i++)
          if (!t.marks[i].isInSet(n))
            return new H(this.pos, t.marks[i]);
        return new H(this.pos, this.mark);
      }
    }
    return new Z(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new H(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "addNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for AddNodeMarkStep.fromJSON");
    return new H(t.pos, e.markFromJSON(t.mark));
  }
}
M.jsonID("addNodeMark", H);
class Z extends M {
  /**
  Create a mark-removing step.
  */
  constructor(e, t) {
    super(), this.pos = e, this.mark = t;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return I.fail("No node at mark step's position");
    let n = t.type.create(t.attrs, null, this.mark.removeFromSet(t.marks));
    return I.fromReplace(e, this.pos, this.pos + 1, new g(m.from(n), 0, t.isLeaf ? 0 : 1));
  }
  invert(e) {
    let t = e.nodeAt(this.pos);
    return !t || !this.mark.isInSet(t.marks) ? this : new H(this.pos, this.mark);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new Z(t.pos, this.mark);
  }
  toJSON() {
    return { stepType: "removeNodeMark", pos: this.pos, mark: this.mark.toJSON() };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.pos != "number")
      throw new RangeError("Invalid input for RemoveNodeMarkStep.fromJSON");
    return new Z(t.pos, e.markFromJSON(t.mark));
  }
}
M.jsonID("removeNodeMark", Z);
class v extends M {
  /**
  The given `slice` should fit the 'gap' between `from` and
  `to`—the depths must line up, and the surrounding nodes must be
  able to be joined with the open sides of the slice. When
  `structure` is true, the step will fail if the content between
  from and to is not just a sequence of closing and then opening
  tokens (this is to guard against rebased replace steps
  overwriting something they weren't supposed to).
  */
  constructor(e, t, n, i = !1) {
    super(), this.from = e, this.to = t, this.slice = n, this.structure = i;
  }
  apply(e) {
    return this.structure && Ke(e, this.from, this.to) ? I.fail("Structure replace would overwrite content") : I.fromReplace(e, this.from, this.to, this.slice);
  }
  getMap() {
    return new C([this.from, this.to - this.from, this.slice.size]);
  }
  invert(e) {
    return new v(this.from, this.from + this.slice.size, e.slice(this.from, this.to));
  }
  map(e) {
    let t = e.mapResult(this.to, -1), n = this.from == this.to && v.MAP_BIAS < 0 ? t : e.mapResult(this.from, 1);
    return n.deletedAcross && t.deletedAcross ? null : new v(n.pos, Math.max(n.pos, t.pos), this.slice, this.structure);
  }
  merge(e) {
    if (!(e instanceof v) || e.structure || this.structure)
      return null;
    if (this.from + this.slice.size == e.from && !this.slice.openEnd && !e.slice.openStart) {
      let t = this.slice.size + e.slice.size == 0 ? g.empty : new g(this.slice.content.append(e.slice.content), this.slice.openStart, e.slice.openEnd);
      return new v(this.from, this.to + (e.to - e.from), t, this.structure);
    } else if (e.to == this.from && !this.slice.openStart && !e.slice.openEnd) {
      let t = this.slice.size + e.slice.size == 0 ? g.empty : new g(e.slice.content.append(this.slice.content), e.slice.openStart, this.slice.openEnd);
      return new v(e.from, this.to, t, this.structure);
    } else
      return null;
  }
  toJSON() {
    let e = { stepType: "replace", from: this.from, to: this.to };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number")
      throw new RangeError("Invalid input for ReplaceStep.fromJSON");
    return new v(t.from, t.to, g.fromJSON(e, t.slice), !!t.structure);
  }
}
v.MAP_BIAS = 1;
M.jsonID("replace", v);
class F extends M {
  /**
  Create a replace-around step with the given range and gap.
  `insert` should be the point in the slice into which the content
  of the gap should be moved. `structure` has the same meaning as
  it has in the [`ReplaceStep`](https://prosemirror.net/docs/ref/#transform.ReplaceStep) class.
  */
  constructor(e, t, n, i, s, o, a = !1) {
    super(), this.from = e, this.to = t, this.gapFrom = n, this.gapTo = i, this.slice = s, this.insert = o, this.structure = a;
  }
  apply(e) {
    if (this.structure && (Ke(e, this.from, this.gapFrom) || Ke(e, this.gapTo, this.to)))
      return I.fail("Structure gap-replace would overwrite content");
    let t = e.slice(this.gapFrom, this.gapTo);
    if (t.openStart || t.openEnd)
      return I.fail("Gap is not a flat range");
    let n = this.slice.insertAt(this.insert, t.content);
    return n ? I.fromReplace(e, this.from, this.to, n) : I.fail("Content does not fit in gap");
  }
  getMap() {
    return new C([
      this.from,
      this.gapFrom - this.from,
      this.insert,
      this.gapTo,
      this.to - this.gapTo,
      this.slice.size - this.insert
    ]);
  }
  invert(e) {
    let t = this.gapTo - this.gapFrom;
    return new F(this.from, this.from + this.slice.size + t, this.from + this.insert, this.from + this.insert + t, e.slice(this.from, this.to).removeBetween(this.gapFrom - this.from, this.gapTo - this.from), this.gapFrom - this.from, this.structure);
  }
  map(e) {
    let t = e.mapResult(this.from, 1), n = e.mapResult(this.to, -1), i = this.from == this.gapFrom ? t.pos : e.map(this.gapFrom, -1), s = this.to == this.gapTo ? n.pos : e.map(this.gapTo, 1);
    return t.deletedAcross && n.deletedAcross || i < t.pos || s > n.pos ? null : new F(t.pos, n.pos, i, s, this.slice, this.insert, this.structure);
  }
  toJSON() {
    let e = {
      stepType: "replaceAround",
      from: this.from,
      to: this.to,
      gapFrom: this.gapFrom,
      gapTo: this.gapTo,
      insert: this.insert
    };
    return this.slice.size && (e.slice = this.slice.toJSON()), this.structure && (e.structure = !0), e;
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.from != "number" || typeof t.to != "number" || typeof t.gapFrom != "number" || typeof t.gapTo != "number" || typeof t.insert != "number")
      throw new RangeError("Invalid input for ReplaceAroundStep.fromJSON");
    return new F(t.from, t.to, t.gapFrom, t.gapTo, g.fromJSON(e, t.slice), t.insert, !!t.structure);
  }
}
M.jsonID("replaceAround", F);
function Ke(r, e, t) {
  let n = r.resolve(e), i = t - e, s = n.depth;
  for (; i > 0 && s > 0 && n.indexAfter(s) == n.node(s).childCount; )
    s--, i--;
  if (i > 0) {
    let o = n.node(s).maybeChild(n.indexAfter(s));
    for (; i > 0; ) {
      if (!o || o.isLeaf)
        return !0;
      o = o.firstChild, i--;
    }
  }
  return !1;
}
function ar(r, e, t, n) {
  let i = [], s = [], o, a;
  r.doc.nodesBetween(e, t, (l, h, c) => {
    if (!l.isInline)
      return;
    let p = l.marks;
    if (!n.isInSet(p) && c.type.allowsMarkType(n.type)) {
      let f = Math.max(h, e), d = Math.min(h + l.nodeSize, t), u = n.addToSet(p);
      for (let x = 0; x < p.length; x++)
        p[x].isInSet(u) || (o && o.to == f && o.mark.eq(p[x]) ? o.to = d : i.push(o = new J(f, d, p[x])));
      a && a.to == f ? a.to = d : s.push(a = new V(f, d, n));
    }
  }), i.forEach((l) => r.step(l)), s.forEach((l) => r.step(l));
}
function lr(r, e, t, n) {
  let i = [], s = 0;
  r.doc.nodesBetween(e, t, (o, a) => {
    if (!o.isInline)
      return;
    s++;
    let l = null;
    if (n instanceof Ne) {
      let h = o.marks, c;
      for (; c = n.isInSet(h); )
        (l || (l = [])).push(c), h = c.removeFromSet(h);
    } else n ? n.isInSet(o.marks) && (l = [n]) : l = o.marks;
    if (l && l.length) {
      let h = Math.min(a + o.nodeSize, t);
      for (let c = 0; c < l.length; c++) {
        let p = l[c], f;
        for (let d = 0; d < i.length; d++) {
          let u = i[d];
          u.step == s - 1 && p.eq(i[d].style) && (f = u);
        }
        f ? (f.to = h, f.step = s) : i.push({ style: p, from: Math.max(a, e), to: h, step: s });
      }
    }
  }), i.forEach((o) => r.step(new J(o.from, o.to, o.style)));
}
function Xe(r, e, t, n = t.contentMatch, i = !0) {
  let s = r.doc.nodeAt(e), o = [], a = e + 1;
  for (let l = 0; l < s.childCount; l++) {
    let h = s.child(l), c = a + h.nodeSize, p = n.matchType(h.type);
    if (!p)
      o.push(new v(a, c, g.empty));
    else {
      n = p;
      for (let f = 0; f < h.marks.length; f++)
        t.allowsMarkType(h.marks[f].type) || r.step(new J(a, c, h.marks[f]));
      if (i && h.isText && t.whitespace != "pre") {
        let f, d = /\r?\n|\r/g, u;
        for (; f = d.exec(h.text); )
          u || (u = new g(m.from(t.schema.text(" ", t.allowedMarks(h.marks))), 0, 0)), o.push(new v(a + f.index, a + f.index + f[0].length, u));
      }
    }
    a = c;
  }
  if (!n.validEnd) {
    let l = n.fillBefore(m.empty, !0);
    r.replace(a, a, new g(l, 0, 0));
  }
  for (let l = o.length - 1; l >= 0; l--)
    r.step(o[l]);
}
function hr(r, e, t) {
  let { $from: n, $to: i, depth: s } = e, o = n.before(s + 1), a = i.after(s + 1), l = o, h = a, c = m.empty, p = 0;
  for (let u = s, x = !1; u > t; u--)
    x || n.index(u) > 0 ? (x = !0, c = m.from(n.node(u).copy(c)), p++) : l--;
  let f = m.empty, d = 0;
  for (let u = s, x = !1; u > t; u--)
    x || i.after(u + 1) < i.end(u) ? (x = !0, f = m.from(i.node(u).copy(f)), d++) : h++;
  r.step(new F(l, h, o, a, new g(c.append(f), p, d), c.size - p, !0));
}
function cr(r, e, t) {
  let n = m.empty;
  for (let o = t.length - 1; o >= 0; o--) {
    if (n.size) {
      let a = t[o].type.contentMatch.matchFragment(n);
      if (!a || !a.validEnd)
        throw new RangeError("Wrapper type given to Transform.wrap does not form valid content of its parent wrapper");
    }
    n = m.from(t[o].type.create(t[o].attrs, n));
  }
  let i = e.start, s = e.end;
  r.step(new F(i, s, i, s, new g(n, 0, 0), t.length, !0));
}
function fr(r, e, t, n, i) {
  if (!n.isTextblock)
    throw new RangeError("Type given to setBlockType should be a textblock");
  let s = r.steps.length;
  r.doc.nodesBetween(e, t, (o, a) => {
    let l = typeof i == "function" ? i(o) : i;
    if (o.isTextblock && !o.hasMarkup(n, l) && pr(r.doc, r.mapping.slice(s).map(a), n)) {
      let h = null;
      if (n.schema.linebreakReplacement) {
        let d = n.whitespace == "pre", u = !!n.contentMatch.matchType(n.schema.linebreakReplacement);
        d && !u ? h = !1 : !d && u && (h = !0);
      }
      h === !1 && Vt(r, o, a, s), Xe(r, r.mapping.slice(s).map(a, 1), n, void 0, h === null);
      let c = r.mapping.slice(s), p = c.map(a, 1), f = c.map(a + o.nodeSize, 1);
      return r.step(new F(p, f, p + 1, f - 1, new g(m.from(n.create(l, null, o.marks)), 0, 0), 1, !0)), h === !0 && Wt(r, o, a, s), !1;
    }
  });
}
function Wt(r, e, t, n) {
  e.forEach((i, s) => {
    if (i.isText) {
      let o, a = /\r?\n|\r/g;
      for (; o = a.exec(i.text); ) {
        let l = r.mapping.slice(n).map(t + 1 + s + o.index);
        r.replaceWith(l, l + 1, e.type.schema.linebreakReplacement.create());
      }
    }
  });
}
function Vt(r, e, t, n) {
  e.forEach((i, s) => {
    if (i.type == i.type.schema.linebreakReplacement) {
      let o = r.mapping.slice(n).map(t + 1 + s);
      r.replaceWith(o, o + 1, e.type.schema.text(`
`));
    }
  });
}
function pr(r, e, t) {
  let n = r.resolve(e), i = n.index();
  return n.parent.canReplaceWith(i, i + 1, t);
}
function dr(r, e, t, n, i) {
  let s = r.doc.nodeAt(e);
  if (!s)
    throw new RangeError("No node at given position");
  t || (t = s.type);
  let o = t.create(n, null, i || s.marks);
  if (s.isLeaf)
    return r.replaceWith(e, e + s.nodeSize, o);
  if (!t.validContent(s.content))
    throw new RangeError("Invalid content for node type " + t.name);
  r.step(new F(e, e + s.nodeSize, e + 1, e + s.nodeSize - 1, new g(m.from(o), 0, 0), 1, !0));
}
function ur(r, e, t = 1, n) {
  let i = r.doc.resolve(e), s = m.empty, o = m.empty;
  for (let a = i.depth, l = i.depth - t, h = t - 1; a > l; a--, h--) {
    s = m.from(i.node(a).copy(s));
    let c = n && n[h];
    o = m.from(c ? c.type.create(c.attrs, o) : i.node(a).copy(o));
  }
  r.step(new v(e, e, new g(s.append(o), t, t), !0));
}
function mr(r, e, t) {
  let n = null, { linebreakReplacement: i } = r.doc.type.schema, s = r.doc.resolve(e - t), o = s.node().type;
  if (i && o.inlineContent) {
    let c = o.whitespace == "pre", p = !!o.contentMatch.matchType(i);
    c && !p ? n = !1 : !c && p && (n = !0);
  }
  let a = r.steps.length;
  if (n === !1) {
    let c = r.doc.resolve(e + t);
    Vt(r, c.node(), c.before(), a);
  }
  o.inlineContent && Xe(r, e + t - 1, o, s.node().contentMatchAt(s.index()), n == null);
  let l = r.mapping.slice(a), h = l.map(e - t);
  if (r.step(new v(h, l.map(e + t, -1), g.empty, !0)), n === !0) {
    let c = r.doc.resolve(h);
    Wt(r, c.node(), c.before(), r.steps.length);
  }
  return r;
}
function gr(r, e, t) {
  let n = r.resolve(e);
  if (n.parent.canReplaceWith(n.index(), n.index(), t))
    return e;
  if (n.parentOffset == 0)
    for (let i = n.depth - 1; i >= 0; i--) {
      let s = n.index(i);
      if (n.node(i).canReplaceWith(s, s, t))
        return n.before(i + 1);
      if (s > 0)
        return null;
    }
  if (n.parentOffset == n.parent.content.size)
    for (let i = n.depth - 1; i >= 0; i--) {
      let s = n.indexAfter(i);
      if (n.node(i).canReplaceWith(s, s, t))
        return n.after(i + 1);
      if (s < n.node(i).childCount)
        return null;
    }
  return null;
}
function yr(r, e, t = e, n = g.empty) {
  if (e == t && !n.size)
    return null;
  let i = r.resolve(e), s = r.resolve(t);
  return Ht(i, s, n) ? new v(e, t, n) : new wr(i, s, n).fit();
}
function Ht(r, e, t) {
  return !t.openStart && !t.openEnd && r.start() == e.start() && r.parent.canReplace(r.index(), e.index(), t.content);
}
class wr {
  constructor(e, t, n) {
    this.$from = e, this.$to = t, this.unplaced = n, this.frontier = [], this.placed = m.empty;
    for (let i = 0; i <= e.depth; i++) {
      let s = e.node(i);
      this.frontier.push({
        type: s.type,
        match: s.contentMatchAt(e.indexAfter(i))
      });
    }
    for (let i = e.depth; i > 0; i--)
      this.placed = m.from(e.node(i).copy(this.placed));
  }
  get depth() {
    return this.frontier.length - 1;
  }
  fit() {
    for (; this.unplaced.size; ) {
      let h = this.findFittable();
      h ? this.placeNodes(h) : this.openMore() || this.dropNode();
    }
    let e = this.mustMoveInline(), t = this.placed.size - this.depth - this.$from.depth, n = this.$from, i = this.close(e < 0 ? this.$to : n.doc.resolve(e));
    if (!i)
      return null;
    let s = this.placed, o = n.depth, a = i.depth;
    for (; o && a && s.childCount == 1; )
      s = s.firstChild.content, o--, a--;
    let l = new g(s, o, a);
    return e > -1 ? new F(n.pos, e, this.$to.pos, this.$to.end(), l, t) : l.size || n.pos != this.$to.pos ? new v(n.pos, i.pos, l) : null;
  }
  // Find a position on the start spine of `this.unplaced` that has
  // content that can be moved somewhere on the frontier. Returns two
  // depths, one for the slice and one for the frontier.
  findFittable() {
    let e = this.unplaced.openStart;
    for (let t = this.unplaced.content, n = 0, i = this.unplaced.openEnd; n < e; n++) {
      let s = t.firstChild;
      if (t.childCount > 1 && (i = 0), s.type.spec.isolating && i <= n) {
        e = n;
        break;
      }
      t = s.content;
    }
    for (let t = 1; t <= 2; t++)
      for (let n = t == 1 ? e : this.unplaced.openStart; n >= 0; n--) {
        let i, s = null;
        n ? (s = lt(this.unplaced.content, n - 1).firstChild, i = s.content) : i = this.unplaced.content;
        let o = i.firstChild;
        for (let a = this.depth; a >= 0; a--) {
          let { type: l, match: h } = this.frontier[a], c, p = null;
          if (t == 1 && (o ? h.matchType(o.type) || (p = h.fillBefore(m.from(o), !1)) : s && l.compatibleContent(s.type)))
            return { sliceDepth: n, frontierDepth: a, parent: s, inject: p };
          if (t == 2 && o && (c = h.findWrapping(o.type)))
            return { sliceDepth: n, frontierDepth: a, parent: s, wrap: c };
          if (s && h.matchType(s.type))
            break;
        }
      }
  }
  openMore() {
    let { content: e, openStart: t, openEnd: n } = this.unplaced;
    return ht(e, -1) <= t ? !1 : (this.unplaced.size > 1 && ht(e, 1) > n && n++, this.unplaced = new g(e, t + 1, n), !0);
  }
  dropNode() {
    let { content: e, openStart: t, openEnd: n } = this.unplaced, i = lt(e, t);
    if (i.childCount <= 1 && t > 0) {
      let s = e.size - t <= t + i.size;
      this.unplaced = new g(ie(e, t - 1, 1), t - 1, s ? t - 1 : n);
    } else
      this.unplaced = new g(ie(e, t, 1), t, n);
  }
  // Move content from the unplaced slice at `sliceDepth` to the
  // frontier node at `frontierDepth`. Close that frontier node when
  // applicable.
  placeNodes({ sliceDepth: e, frontierDepth: t, parent: n, inject: i, wrap: s }) {
    for (; this.depth > t; )
      this.closeFrontierNode();
    if (s)
      for (let x = 0; x < s.length; x++)
        this.openFrontierNode(s[x]);
    let o = this.unplaced, a = n ? n.content : o.content, l = o.openStart - e, h = 0, c = [], { match: p, type: f } = this.frontier[t];
    if (i) {
      for (let x = 0; x < i.childCount; x++)
        c.push(i.child(x));
      p = p.matchFragment(i);
    }
    let d = a.size + e - (o.content.size - o.openEnd);
    for (; h < a.childCount; ) {
      let x = a.child(h), O = p.matchType(x.type);
      if (!O)
        break;
      h++, (h > 1 || l == 0 || x.content.size) && (p = O, c.push(_t(x.mark(f.allowedMarks(x.marks)), h == 1 ? l : 0, h == a.childCount ? d : -1)));
    }
    let u = h == a.childCount;
    u || (d = -1), this.placed = se(this.placed, t, m.from(c)), this.frontier[t].match = p, u && d < 0 && n && n.type == this.frontier[this.depth].type && this.frontier.length > 1 && this.closeFrontierNode();
    for (let x = 0, O = a; x < d; x++) {
      let N = O.lastChild;
      this.frontier.push({ type: N.type, match: N.contentMatchAt(N.childCount) }), O = N.content;
    }
    this.unplaced = u ? e == 0 ? g.empty : new g(ie(o.content, e - 1, 1), e - 1, d < 0 ? o.openEnd : e - 1) : new g(ie(o.content, e, h), o.openStart, o.openEnd);
  }
  mustMoveInline() {
    if (!this.$to.parent.isTextblock)
      return -1;
    let e = this.frontier[this.depth], t;
    if (!e.type.isTextblock || !je(this.$to, this.$to.depth, e.type, e.match, !1) || this.$to.depth == this.depth && (t = this.findCloseLevel(this.$to)) && t.depth == this.depth)
      return -1;
    let { depth: n } = this.$to, i = this.$to.after(n);
    for (; n > 1 && i == this.$to.end(--n); )
      ++i;
    return i;
  }
  findCloseLevel(e) {
    e: for (let t = Math.min(this.depth, e.depth); t >= 0; t--) {
      let { match: n, type: i } = this.frontier[t], s = t < e.depth && e.end(t + 1) == e.pos + (e.depth - (t + 1)), o = je(e, t, i, n, s);
      if (o) {
        for (let a = t - 1; a >= 0; a--) {
          let { match: l, type: h } = this.frontier[a], c = je(e, a, h, l, !0);
          if (!c || c.childCount)
            continue e;
        }
        return { depth: t, fit: o, move: s ? e.doc.resolve(e.after(t + 1)) : e };
      }
    }
  }
  close(e) {
    let t = this.findCloseLevel(e);
    if (!t)
      return null;
    for (; this.depth > t.depth; )
      this.closeFrontierNode();
    t.fit.childCount && (this.placed = se(this.placed, t.depth, t.fit)), e = t.move;
    for (let n = t.depth + 1; n <= e.depth; n++) {
      let i = e.node(n), s = i.type.contentMatch.fillBefore(i.content, !0, e.index(n));
      this.openFrontierNode(i.type, i.attrs, s);
    }
    return e;
  }
  openFrontierNode(e, t = null, n) {
    let i = this.frontier[this.depth];
    i.match = i.match.matchType(e), this.placed = se(this.placed, this.depth, m.from(e.create(t, n))), this.frontier.push({ type: e, match: e.contentMatch });
  }
  closeFrontierNode() {
    let t = this.frontier.pop().match.fillBefore(m.empty, !0);
    t.childCount && (this.placed = se(this.placed, this.frontier.length, t));
  }
}
function ie(r, e, t) {
  return e == 0 ? r.cutByIndex(t, r.childCount) : r.replaceChild(0, r.firstChild.copy(ie(r.firstChild.content, e - 1, t)));
}
function se(r, e, t) {
  return e == 0 ? r.append(t) : r.replaceChild(r.childCount - 1, r.lastChild.copy(se(r.lastChild.content, e - 1, t)));
}
function lt(r, e) {
  for (let t = 0; t < e; t++)
    r = r.firstChild.content;
  return r;
}
function _t(r, e, t) {
  if (e <= 0)
    return r;
  let n = r.content;
  return e > 1 && (n = n.replaceChild(0, _t(n.firstChild, e - 1, n.childCount == 1 ? t - 1 : 0))), e > 0 && (n = r.type.contentMatch.fillBefore(n).append(n), t <= 0 && (n = n.append(r.type.contentMatch.matchFragment(n).fillBefore(m.empty, !0)))), r.copy(n);
}
function je(r, e, t, n, i) {
  let s = r.node(e), o = i ? r.indexAfter(e) : r.index(e);
  if (o == s.childCount && !t.compatibleContent(s.type))
    return null;
  let a = n.fillBefore(s.content, !0, o);
  return a && !xr(t, s.content, o) ? a : null;
}
function xr(r, e, t) {
  for (let n = t; n < e.childCount; n++)
    if (!r.allowsMarks(e.child(n).marks))
      return !0;
  return !1;
}
function kr(r) {
  return r.spec.defining || r.spec.definingForContent;
}
function ht(r, e) {
  for (let t = 0; ; t++) {
    let n = e < 0 ? r.firstChild : r.lastChild;
    if (!n || n.isAtom)
      return t;
    r = n.content;
  }
}
function br(r, e, t, n) {
  if (!n.size)
    return r.deleteRange(e, t);
  let i = r.doc.resolve(e), s = r.doc.resolve(t);
  if (Ht(i, s, n))
    return r.step(new v(e, t, n));
  let o = Ut(i, s);
  o[o.length - 1] == 0 && o.pop();
  let a = -(i.depth + 1);
  o.unshift(a);
  for (let f = i.depth, d = i.pos - 1; f > 0; f--, d--) {
    let u = i.node(f).type.spec;
    if (u.defining || u.definingAsContext || u.isolating)
      break;
    o.indexOf(f) > -1 ? a = f : i.before(f) == d && o.splice(1, 0, -f);
  }
  let l = o.indexOf(a), h = [], c = n.openStart;
  for (let f = n.content, d = 0; ; d++) {
    let u = f.firstChild;
    if (h.push(u), d == n.openStart)
      break;
    f = u.content;
  }
  for (let f = c - 1; f >= 0; f--) {
    let d = h[f], u = kr(d.type);
    if (u && !d.sameMarkup(i.node(Math.abs(a) - 1)))
      c = f;
    else if (u || !d.type.isTextblock)
      break;
  }
  for (let f = n.openStart; f >= 0; f--) {
    let d = (f + c + 1) % (n.openStart + 1), u = h[d];
    if (u)
      for (let x = 0; x < o.length; x++) {
        let O = o[(x + l) % o.length], N = !0;
        O < 0 && (N = !1, O = -O);
        let b = i.node(O - 1), pe = i.index(O - 1);
        if (b.canReplaceWith(pe, pe, u.type, u.marks))
          return r.replace(i.before(O), N ? s.after(O) : t, new g(Kt(n.content, 0, n.openStart, d), d, n.openEnd));
      }
  }
  let p = r.steps.length;
  for (let f = o.length - 1; f >= 0 && (r.replace(e, t, n), !(r.steps.length > p)); f--) {
    let d = o[f];
    d < 0 || (e = i.before(d), t = s.after(d));
  }
}
function Kt(r, e, t, n, i) {
  if (e < t) {
    let s = r.firstChild;
    r = r.replaceChild(0, s.copy(Kt(s.content, e + 1, t, n, s)));
  }
  if (e > n) {
    let s = i.contentMatchAt(0), o = s.fillBefore(r).append(r);
    r = o.append(s.matchFragment(o).fillBefore(m.empty, !0));
  }
  return r;
}
function Sr(r, e, t, n) {
  if (!n.isInline && e == t && r.doc.resolve(e).parent.content.size) {
    let i = gr(r.doc, e, n.type);
    i != null && (e = t = i);
  }
  r.replaceRange(e, t, new g(m.from(n), 0, 0));
}
function Or(r, e, t) {
  let n = r.doc.resolve(e), i = r.doc.resolve(t);
  if (n.parent.isTextblock && i.parent.isTextblock && n.start() != i.start() && n.parentOffset == 0 && i.parentOffset == 0) {
    let o = n.sharedDepth(t), a = !1;
    for (let l = n.depth; l > o; l--)
      n.node(l).type.spec.isolating && (a = !0);
    for (let l = i.depth; l > o; l--)
      i.node(l).type.spec.isolating && (a = !0);
    if (!a) {
      for (let l = n.depth; l > 0 && e == n.start(l); l--)
        e = n.before(l);
      for (let l = i.depth; l > 0 && t == i.start(l); l--)
        t = i.before(l);
      n = r.doc.resolve(e), i = r.doc.resolve(t);
    }
  }
  let s = Ut(n, i);
  for (let o = 0; o < s.length; o++) {
    let a = s[o], l = o == s.length - 1;
    if (l && a == 0 || n.node(a).type.contentMatch.validEnd)
      return r.delete(n.start(a), i.end(a));
    if (a > 0 && (l || n.node(a - 1).canReplace(n.index(a - 1), i.indexAfter(a - 1))))
      return r.delete(n.before(a), i.after(a));
  }
  for (let o = 1; o <= n.depth && o <= i.depth; o++)
    if (e - n.start(o) == n.depth - o && t > n.end(o) && i.end(o) - t != i.depth - o && n.start(o - 1) == i.start(o - 1) && n.node(o - 1).canReplace(n.index(o - 1), i.index(o - 1)))
      return r.delete(n.before(o), t);
  r.delete(e, t);
}
function Ut(r, e) {
  let t = [], n = Math.min(r.depth, e.depth);
  for (let i = n; i >= 0; i--) {
    let s = r.start(i);
    if (s < r.pos - (r.depth - i) || e.end(i) > e.pos + (e.depth - i) || r.node(i).type.spec.isolating || e.node(i).type.spec.isolating)
      break;
    (s == e.start(i) || i == r.depth && i == e.depth && r.parent.inlineContent && e.parent.inlineContent && i && e.start(i - 1) == s - 1) && t.push(i);
  }
  return t;
}
class ee extends M {
  /**
  Construct an attribute step.
  */
  constructor(e, t, n) {
    super(), this.pos = e, this.attr = t, this.value = n;
  }
  apply(e) {
    let t = e.nodeAt(this.pos);
    if (!t)
      return I.fail("No node at attribute step's position");
    let n = /* @__PURE__ */ Object.create(null);
    for (let s in t.attrs)
      n[s] = t.attrs[s];
    n[this.attr] = this.value;
    let i = t.type.create(n, null, t.marks);
    return I.fromReplace(e, this.pos, this.pos + 1, new g(m.from(i), 0, t.isLeaf ? 0 : 1));
  }
  getMap() {
    return C.empty;
  }
  invert(e) {
    return new ee(this.pos, this.attr, e.nodeAt(this.pos).attrs[this.attr]);
  }
  map(e) {
    let t = e.mapResult(this.pos, 1);
    return t.deletedAfter ? null : new ee(t.pos, this.attr, this.value);
  }
  toJSON() {
    return { stepType: "attr", pos: this.pos, attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.pos != "number" || typeof t.attr != "string")
      throw new RangeError("Invalid input for AttrStep.fromJSON");
    return new ee(t.pos, t.attr, t.value);
  }
}
M.jsonID("attr", ee);
class fe extends M {
  /**
  Construct an attribute step.
  */
  constructor(e, t) {
    super(), this.attr = e, this.value = t;
  }
  apply(e) {
    let t = /* @__PURE__ */ Object.create(null);
    for (let i in e.attrs)
      t[i] = e.attrs[i];
    t[this.attr] = this.value;
    let n = e.type.create(t, e.content, e.marks);
    return I.ok(n);
  }
  getMap() {
    return C.empty;
  }
  invert(e) {
    return new fe(this.attr, e.attrs[this.attr]);
  }
  map(e) {
    return this;
  }
  toJSON() {
    return { stepType: "docAttr", attr: this.attr, value: this.value };
  }
  static fromJSON(e, t) {
    if (typeof t.attr != "string")
      throw new RangeError("Invalid input for DocAttrStep.fromJSON");
    return new fe(t.attr, t.value);
  }
}
M.jsonID("docAttr", fe);
let ne = class extends Error {
};
ne = function r(e) {
  let t = Error.call(this, e);
  return t.__proto__ = r.prototype, t;
};
ne.prototype = Object.create(Error.prototype);
ne.prototype.constructor = ne;
ne.prototype.name = "TransformError";
class Er {
  /**
  Create a transform that starts with the given document.
  */
  constructor(e) {
    this.doc = e, this.steps = [], this.docs = [], this.mapping = new te();
  }
  /**
  The starting document.
  */
  get before() {
    return this.docs.length ? this.docs[0] : this.doc;
  }
  /**
  Apply a new step in this transform, saving the result. Throws an
  error when the step fails.
  */
  step(e) {
    let t = this.maybeStep(e);
    if (t.failed)
      throw new ne(t.failed);
    return this;
  }
  /**
  Try to apply a step in this transformation, ignoring it if it
  fails. Returns the step result.
  */
  maybeStep(e) {
    let t = e.apply(this.doc);
    return t.failed || this.addStep(e, t.doc), t;
  }
  /**
  True when the document has been changed (when there are any
  steps).
  */
  get docChanged() {
    return this.steps.length > 0;
  }
  /**
  Return a single range, in post-transform document positions,
  that covers all content changed by this transform. Returns null
  if no replacements are made. Note that this will ignore changes
  that add/remove marks without replacing the underlying content.
  */
  changedRange() {
    let e = 1e9, t = -1e9;
    for (let n = 0; n < this.mapping.maps.length; n++) {
      let i = this.mapping.maps[n];
      n && (e = i.map(e, 1), t = i.map(t, -1)), i.forEach((s, o, a, l) => {
        e = Math.min(e, a), t = Math.max(t, l);
      });
    }
    return e == 1e9 ? null : { from: e, to: t };
  }
  /**
  @internal
  */
  addStep(e, t) {
    this.docs.push(this.doc), this.steps.push(e), this.mapping.appendMap(e.getMap()), this.doc = t;
  }
  /**
  Replace the part of the document between `from` and `to` with the
  given `slice`.
  */
  replace(e, t = e, n = g.empty) {
    let i = yr(this.doc, e, t, n);
    return i && this.step(i), this;
  }
  /**
  Replace the given range with the given content, which may be a
  fragment, node, or array of nodes.
  */
  replaceWith(e, t, n) {
    return this.replace(e, t, new g(m.from(n), 0, 0));
  }
  /**
  Delete the content between the given positions.
  */
  delete(e, t) {
    return this.replace(e, t, g.empty);
  }
  /**
  Insert the given content at the given position.
  */
  insert(e, t) {
    return this.replaceWith(e, e, t);
  }
  /**
  Replace a range of the document with a given slice, using
  `from`, `to`, and the slice's
  [`openStart`](https://prosemirror.net/docs/ref/#model.Slice.openStart) property as hints, rather
  than fixed start and end points. This method may grow the
  replaced area or close open nodes in the slice in order to get a
  fit that is more in line with WYSIWYG expectations, by dropping
  fully covered parent nodes of the replaced region when they are
  marked [non-defining as
  context](https://prosemirror.net/docs/ref/#model.NodeSpec.definingAsContext), or including an
  open parent node from the slice that _is_ marked as [defining
  its content](https://prosemirror.net/docs/ref/#model.NodeSpec.definingForContent).
  
  This is the method, for example, to handle paste. The similar
  [`replace`](https://prosemirror.net/docs/ref/#transform.Transform.replace) method is a more
  primitive tool which will _not_ move the start and end of its given
  range, and is useful in situations where you need more precise
  control over what happens.
  */
  replaceRange(e, t, n) {
    return br(this, e, t, n), this;
  }
  /**
  Replace the given range with a node, but use `from` and `to` as
  hints, rather than precise positions. When from and to are the same
  and are at the start or end of a parent node in which the given
  node doesn't fit, this method may _move_ them out towards a parent
  that does allow the given node to be placed. When the given range
  completely covers a parent node, this method may completely replace
  that parent node.
  */
  replaceRangeWith(e, t, n) {
    return Sr(this, e, t, n), this;
  }
  /**
  Delete the given range, expanding it to cover fully covered
  parent nodes until a valid replace is found.
  */
  deleteRange(e, t) {
    return Or(this, e, t), this;
  }
  /**
  Split the content in the given range off from its parent, if there
  is sibling content before or after it, and move it up the tree to
  the depth specified by `target`. You'll probably want to use
  [`liftTarget`](https://prosemirror.net/docs/ref/#transform.liftTarget) to compute `target`, to make
  sure the lift is valid.
  */
  lift(e, t) {
    return hr(this, e, t), this;
  }
  /**
  Join the blocks around the given position. If depth is 2, their
  last and first siblings are also joined, and so on.
  */
  join(e, t = 1) {
    return mr(this, e, t), this;
  }
  /**
  Wrap the given [range](https://prosemirror.net/docs/ref/#model.NodeRange) in the given set of wrappers.
  The wrappers are assumed to be valid in this position, and should
  probably be computed with [`findWrapping`](https://prosemirror.net/docs/ref/#transform.findWrapping).
  */
  wrap(e, t) {
    return cr(this, e, t), this;
  }
  /**
  Set the type of all textblocks (partly) between `from` and `to` to
  the given node type with the given attributes.
  */
  setBlockType(e, t = e, n, i = null) {
    return fr(this, e, t, n, i), this;
  }
  /**
  Change the type, attributes, and/or marks of the node at `pos`.
  When `type` isn't given, the existing node type is preserved,
  */
  setNodeMarkup(e, t, n = null, i) {
    return dr(this, e, t, n, i), this;
  }
  /**
  Set a single attribute on a given node to a new value.
  The `pos` addresses the document content. Use `setDocAttribute`
  to set attributes on the document itself.
  */
  setNodeAttribute(e, t, n) {
    return this.step(new ee(e, t, n)), this;
  }
  /**
  Set a single attribute on the document to a new value.
  */
  setDocAttribute(e, t) {
    return this.step(new fe(e, t)), this;
  }
  /**
  Add a mark to the node at position `pos`.
  */
  addNodeMark(e, t) {
    return this.step(new H(e, t)), this;
  }
  /**
  Remove a mark (or all marks of the given type) from the node at
  position `pos`.
  */
  removeNodeMark(e, t) {
    let n = this.doc.nodeAt(e);
    if (!n)
      throw new RangeError("No node at position " + e);
    if (t instanceof S)
      t.isInSet(n.marks) && this.step(new Z(e, t));
    else {
      let i = n.marks, s, o = [];
      for (; s = t.isInSet(i); )
        o.push(new Z(e, s)), i = s.removeFromSet(i);
      for (let a = o.length - 1; a >= 0; a--)
        this.step(o[a]);
    }
    return this;
  }
  /**
  Split the node at the given position, and optionally, if `depth` is
  greater than one, any number of nodes above that. By default, the
  parts split off will inherit the node type of the original node.
  This can be changed by passing an array of types and attributes to
  use after the split (with the outermost nodes coming first).
  */
  split(e, t = 1, n) {
    return ur(this, e, t, n), this;
  }
  /**
  Add the given mark to the inline content between `from` and `to`.
  */
  addMark(e, t, n) {
    return ar(this, e, t, n), this;
  }
  /**
  Remove marks from inline nodes between `from` and `to`. When
  `mark` is a single mark, remove precisely that mark. When it is
  a mark type, remove all marks of that type. When it is null,
  remove all marks of any type.
  */
  removeMark(e, t, n) {
    return lr(this, e, t, n), this;
  }
  /**
  Removes all marks and nodes from the content of the node at
  `pos` that don't match the given new parent node type. Accepts
  an optional starting [content match](https://prosemirror.net/docs/ref/#model.ContentMatch) as
  third argument.
  */
  clearIncompatible(e, t, n) {
    return Xe(this, e, t, n), this;
  }
}
const Pe = /* @__PURE__ */ Object.create(null);
class E {
  /**
  Initialize a selection with the head and anchor and ranges. If no
  ranges are given, constructs a single range across `$anchor` and
  `$head`.
  */
  constructor(e, t, n) {
    this.$anchor = e, this.$head = t, this.ranges = n || [new Ir(e.min(t), e.max(t))];
  }
  /**
  The selection's anchor, as an unresolved position.
  */
  get anchor() {
    return this.$anchor.pos;
  }
  /**
  The selection's head.
  */
  get head() {
    return this.$head.pos;
  }
  /**
  The lower bound of the selection's main range.
  */
  get from() {
    return this.$from.pos;
  }
  /**
  The upper bound of the selection's main range.
  */
  get to() {
    return this.$to.pos;
  }
  /**
  The resolved lower  bound of the selection's main range.
  */
  get $from() {
    return this.ranges[0].$from;
  }
  /**
  The resolved upper bound of the selection's main range.
  */
  get $to() {
    return this.ranges[0].$to;
  }
  /**
  Indicates whether the selection contains any content.
  */
  get empty() {
    let e = this.ranges;
    for (let t = 0; t < e.length; t++)
      if (e[t].$from.pos != e[t].$to.pos)
        return !1;
    return !0;
  }
  /**
  Get the content of this selection as a slice.
  */
  content() {
    return this.$from.doc.slice(this.from, this.to, !0);
  }
  /**
  Replace the selection with a slice or, if no slice is given,
  delete the selection. Will append to the given transaction.
  */
  replace(e, t = g.empty) {
    let n = t.content.lastChild, i = null;
    for (let a = 0; a < t.openEnd; a++)
      i = n, n = n.lastChild;
    let s = e.steps.length, o = this.ranges;
    for (let a = 0; a < o.length; a++) {
      let { $from: l, $to: h } = o[a], c = e.mapping.slice(s);
      e.replaceRange(c.map(l.pos), c.map(h.pos), a ? g.empty : t), a == 0 && pt(e, s, (n ? n.isInline : i && i.isTextblock) ? -1 : 1);
    }
  }
  /**
  Replace the selection with the given node, appending the changes
  to the given transaction.
  */
  replaceWith(e, t) {
    let n = e.steps.length, i = this.ranges;
    for (let s = 0; s < i.length; s++) {
      let { $from: o, $to: a } = i[s], l = e.mapping.slice(n), h = l.map(o.pos), c = l.map(a.pos);
      s ? e.deleteRange(h, c) : (e.replaceRangeWith(h, c, t), pt(e, n, t.isInline ? -1 : 1));
    }
  }
  /**
  Find a valid cursor or leaf node selection starting at the given
  position and searching back if `dir` is negative, and forward if
  positive. When `textOnly` is true, only consider cursor
  selections. Will return null when no valid selection position is
  found.
  */
  static findFrom(e, t, n = !1) {
    let i = e.parent.inlineContent ? new j(e) : G(e.node(0), e.parent, e.pos, e.index(), t, n);
    if (i)
      return i;
    for (let s = e.depth - 1; s >= 0; s--) {
      let o = t < 0 ? G(e.node(0), e.node(s), e.before(s + 1), e.index(s), t, n) : G(e.node(0), e.node(s), e.after(s + 1), e.index(s) + 1, t, n);
      if (o)
        return o;
    }
    return null;
  }
  /**
  Find a valid cursor or leaf node selection near the given
  position. Searches forward first by default, but if `bias` is
  negative, it will search backwards first.
  */
  static near(e, t = 1) {
    return this.findFrom(e, t) || this.findFrom(e, -t) || new $(e.node(0));
  }
  /**
  Find the cursor or leaf node selection closest to the start of
  the given document. Will return an
  [`AllSelection`](https://prosemirror.net/docs/ref/#state.AllSelection) if no valid position
  exists.
  */
  static atStart(e) {
    return G(e, e, 0, 0, 1) || new $(e);
  }
  /**
  Find the cursor or leaf node selection closest to the end of the
  given document.
  */
  static atEnd(e) {
    return G(e, e, e.content.size, e.childCount, -1) || new $(e);
  }
  /**
  Deserialize the JSON representation of a selection. Must be
  implemented for custom classes (as a static class method).
  */
  static fromJSON(e, t) {
    if (!t || !t.type)
      throw new RangeError("Invalid input for Selection.fromJSON");
    let n = Pe[t.type];
    if (!n)
      throw new RangeError(`No selection type ${t.type} defined`);
    return n.fromJSON(e, t);
  }
  /**
  To be able to deserialize selections from JSON, custom selection
  classes must register themselves with an ID string, so that they
  can be disambiguated. Try to pick something that's unlikely to
  clash with classes from other modules.
  */
  static jsonID(e, t) {
    if (e in Pe)
      throw new RangeError("Duplicate use of selection JSON ID " + e);
    return Pe[e] = t, t.prototype.jsonID = e, t;
  }
  /**
  Get a [bookmark](https://prosemirror.net/docs/ref/#state.SelectionBookmark) for this selection,
  which is a value that can be mapped without having access to a
  current document, and later resolved to a real selection for a
  given document again. (This is used mostly by the history to
  track and restore old selections.) The default implementation of
  this method just converts the selection to a text selection and
  returns the bookmark for that.
  */
  getBookmark() {
    return j.between(this.$anchor, this.$head).getBookmark();
  }
}
E.prototype.visible = !0;
class Ir {
  /**
  Create a range.
  */
  constructor(e, t) {
    this.$from = e, this.$to = t;
  }
}
let ct = !1;
function ft(r) {
  !ct && !r.parent.inlineContent && (ct = !0, console.warn("TextSelection endpoint not pointing into a node with inline content (" + r.parent.type.name + ")"));
}
class j extends E {
  /**
  Construct a text selection between the given points.
  */
  constructor(e, t = e) {
    ft(e), ft(t), super(e, t);
  }
  /**
  Returns a resolved position if this is a cursor selection (an
  empty text selection), and null otherwise.
  */
  get $cursor() {
    return this.$anchor.pos == this.$head.pos ? this.$head : null;
  }
  map(e, t) {
    let n = e.resolve(t.map(this.head));
    if (!n.parent.inlineContent)
      return E.near(n);
    let i = e.resolve(t.map(this.anchor));
    return new j(i.parent.inlineContent ? i : n, n);
  }
  replace(e, t = g.empty) {
    if (super.replace(e, t), t == g.empty) {
      let n = this.$from.marksAcross(this.$to);
      n && e.ensureMarks(n);
    }
  }
  eq(e) {
    return e instanceof j && e.anchor == this.anchor && e.head == this.head;
  }
  getBookmark() {
    return new Re(this.anchor, this.head);
  }
  toJSON() {
    return { type: "text", anchor: this.anchor, head: this.head };
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number" || typeof t.head != "number")
      throw new RangeError("Invalid input for TextSelection.fromJSON");
    return new j(e.resolve(t.anchor), e.resolve(t.head));
  }
  /**
  Create a text selection from non-resolved positions.
  */
  static create(e, t, n = t) {
    let i = e.resolve(t);
    return new this(i, n == t ? i : e.resolve(n));
  }
  /**
  Return a text selection that spans the given positions or, if
  they aren't text positions, find a text selection near them.
  `bias` determines whether the method searches forward (default)
  or backwards (negative number) first. Will fall back to calling
  [`Selection.near`](https://prosemirror.net/docs/ref/#state.Selection^near) when the document
  doesn't contain a valid text position.
  */
  static between(e, t, n) {
    let i = e.pos - t.pos;
    if ((!n || i) && (n = i >= 0 ? 1 : -1), !t.parent.inlineContent) {
      let s = E.findFrom(t, n, !0) || E.findFrom(t, -n, !0);
      if (s)
        t = s.$head;
      else
        return E.near(t, n);
    }
    return e.parent.inlineContent || (i == 0 ? e = t : (e = (E.findFrom(e, -n, !0) || E.findFrom(e, n, !0)).$anchor, e.pos < t.pos != i < 0 && (e = t))), new j(e, t);
  }
}
E.jsonID("text", j);
class Re {
  constructor(e, t) {
    this.anchor = e, this.head = t;
  }
  map(e) {
    return new Re(e.map(this.anchor), e.map(this.head));
  }
  resolve(e) {
    return j.between(e.resolve(this.anchor), e.resolve(this.head));
  }
}
class z extends E {
  /**
  Create a node selection. Does not verify the validity of its
  argument.
  */
  constructor(e) {
    let t = e.nodeAfter, n = e.node(0).resolve(e.pos + t.nodeSize);
    super(e, n), this.node = t;
  }
  map(e, t) {
    let { deleted: n, pos: i } = t.mapResult(this.anchor), s = e.resolve(i);
    return n ? E.near(s) : new z(s);
  }
  content() {
    return new g(m.from(this.node), 0, 0);
  }
  eq(e) {
    return e instanceof z && e.anchor == this.anchor;
  }
  toJSON() {
    return { type: "node", anchor: this.anchor };
  }
  getBookmark() {
    return new Qe(this.anchor);
  }
  /**
  @internal
  */
  static fromJSON(e, t) {
    if (typeof t.anchor != "number")
      throw new RangeError("Invalid input for NodeSelection.fromJSON");
    return new z(e.resolve(t.anchor));
  }
  /**
  Create a node selection from non-resolved positions.
  */
  static create(e, t) {
    return new z(e.resolve(t));
  }
  /**
  Determines whether the given node may be selected as a node
  selection.
  */
  static isSelectable(e) {
    return !e.isText && e.type.spec.selectable !== !1;
  }
}
z.prototype.visible = !1;
E.jsonID("node", z);
class Qe {
  constructor(e) {
    this.anchor = e;
  }
  map(e) {
    let { deleted: t, pos: n } = e.mapResult(this.anchor);
    return t ? new Re(n, n) : new Qe(n);
  }
  resolve(e) {
    let t = e.resolve(this.anchor), n = t.nodeAfter;
    return n && z.isSelectable(n) ? new z(t) : E.near(t);
  }
}
class $ extends E {
  /**
  Create an all-selection over the given document.
  */
  constructor(e) {
    super(e.resolve(0), e.resolve(e.content.size));
  }
  replace(e, t = g.empty) {
    if (t == g.empty) {
      e.delete(0, e.doc.content.size);
      let n = E.atStart(e.doc);
      n.eq(e.selection) || e.setSelection(n);
    } else
      super.replace(e, t);
  }
  toJSON() {
    return { type: "all" };
  }
  /**
  @internal
  */
  static fromJSON(e) {
    return new $(e);
  }
  map(e) {
    return new $(e);
  }
  eq(e) {
    return e instanceof $;
  }
  getBookmark() {
    return vr;
  }
}
E.jsonID("all", $);
const vr = {
  map() {
    return this;
  },
  resolve(r) {
    return new $(r);
  }
};
function G(r, e, t, n, i, s = !1) {
  if (e.inlineContent)
    return j.create(r, t);
  for (let o = n - (i > 0 ? 0 : 1); i > 0 ? o < e.childCount : o >= 0; o += i) {
    let a = e.child(o);
    if (a.isAtom) {
      if (!s && z.isSelectable(a))
        return z.create(r, t - (i < 0 ? a.nodeSize : 0));
    } else {
      let l = G(r, a, t + i, i < 0 ? a.childCount : 0, i, s);
      if (l)
        return l;
    }
    t += a.nodeSize * i;
  }
  return null;
}
function pt(r, e, t) {
  let n = r.steps.length - 1;
  if (n < e)
    return;
  let i = r.steps[n];
  if (!(i instanceof v || i instanceof F))
    return;
  let s = r.mapping.maps[n], o;
  s.forEach((a, l, h, c) => {
    o == null && (o = c);
  }), r.setSelection(E.near(r.doc.resolve(o), t));
}
const dt = 1, me = 2, ut = 4;
class Xt extends Er {
  /**
  @internal
  */
  constructor(e) {
    super(e.doc), this.curSelectionFor = 0, this.updated = 0, this.meta = /* @__PURE__ */ Object.create(null), this.time = Date.now(), this.curSelection = e.selection, this.storedMarks = e.storedMarks;
  }
  /**
  The transaction's current selection. This defaults to the editor
  selection [mapped](https://prosemirror.net/docs/ref/#state.Selection.map) through the steps in the
  transaction, but can be overwritten with
  [`setSelection`](https://prosemirror.net/docs/ref/#state.Transaction.setSelection).
  */
  get selection() {
    return this.curSelectionFor < this.steps.length && (this.curSelection = this.curSelection.map(this.doc, this.mapping.slice(this.curSelectionFor)), this.curSelectionFor = this.steps.length), this.curSelection;
  }
  /**
  Update the transaction's current selection. Will determine the
  selection that the editor gets when the transaction is applied.
  */
  setSelection(e) {
    if (e.$from.doc != this.doc)
      throw new RangeError("Selection passed to setSelection must point at the current document");
    return this.curSelection = e, this.curSelectionFor = this.steps.length, this.updated = (this.updated | dt) & ~me, this.storedMarks = null, this;
  }
  /**
  Whether the selection was explicitly updated by this transaction.
  */
  get selectionSet() {
    return (this.updated & dt) > 0;
  }
  /**
  Set the current stored marks.
  */
  setStoredMarks(e) {
    return this.storedMarks = e, this.updated |= me, this;
  }
  /**
  Make sure the current stored marks or, if that is null, the marks
  at the selection, match the given set of marks. Does nothing if
  this is already the case.
  */
  ensureMarks(e) {
    return S.sameSet(this.storedMarks || this.selection.$from.marks(), e) || this.setStoredMarks(e), this;
  }
  /**
  Add a mark to the set of stored marks.
  */
  addStoredMark(e) {
    return this.ensureMarks(e.addToSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Remove a mark or mark type from the set of stored marks.
  */
  removeStoredMark(e) {
    return this.ensureMarks(e.removeFromSet(this.storedMarks || this.selection.$head.marks()));
  }
  /**
  Whether the stored marks were explicitly set for this transaction.
  */
  get storedMarksSet() {
    return (this.updated & me) > 0;
  }
  /**
  @internal
  */
  addStep(e, t) {
    super.addStep(e, t), this.updated = this.updated & ~me, this.storedMarks = null;
  }
  /**
  Update the timestamp for the transaction.
  */
  setTime(e) {
    return this.time = e, this;
  }
  /**
  Replace the current selection with the given slice.
  */
  replaceSelection(e) {
    return this.selection.replace(this, e), this;
  }
  /**
  Replace the selection with the given node. When `inheritMarks` is
  true and the content is inline, it inherits the marks from the
  place where it is inserted.
  */
  replaceSelectionWith(e, t = !0) {
    let n = this.selection;
    return t && (e = e.mark(this.storedMarks || (n.empty ? n.$from.marks() : n.$from.marksAcross(n.$to) || S.none))), n.replaceWith(this, e), this;
  }
  /**
  Delete the selection.
  */
  deleteSelection() {
    return this.selection.replace(this), this;
  }
  /**
  Replace the given range, or the selection if no range is given,
  with a text node containing the given string.
  */
  insertText(e, t, n) {
    let i = this.doc.type.schema;
    if (t == null)
      return e ? this.replaceSelectionWith(i.text(e), !0) : this.deleteSelection();
    {
      if (n == null && (n = t), !e)
        return this.deleteRange(t, n);
      let s = this.storedMarks;
      if (!s) {
        let o = this.doc.resolve(t);
        s = n == t ? o.marks() : o.marksAcross(this.doc.resolve(n));
      }
      return this.replaceRangeWith(t, n, i.text(e, s)), !this.selection.empty && this.selection.to == t + e.length && this.setSelection(E.near(this.selection.$to)), this;
    }
  }
  /**
  Store a metadata property in this transaction, keyed either by
  name or by plugin.
  */
  setMeta(e, t) {
    return this.meta[typeof e == "string" ? e : e.key] = t, this;
  }
  /**
  Retrieve a metadata property for a given name or plugin.
  */
  getMeta(e) {
    return this.meta[typeof e == "string" ? e : e.key];
  }
  /**
  Returns true if this transaction doesn't contain any metadata,
  and can thus safely be extended.
  */
  get isGeneric() {
    for (let e in this.meta)
      return !1;
    return !0;
  }
  /**
  Indicate that the editor should scroll the selection into view
  when updated to the state produced by this transaction.
  */
  scrollIntoView() {
    return this.updated |= ut, this;
  }
  /**
  True when this transaction has had `scrollIntoView` called on it.
  */
  get scrolledIntoView() {
    return (this.updated & ut) > 0;
  }
}
function mt(r, e) {
  return !e || !r ? r : r.bind(e);
}
class oe {
  constructor(e, t, n) {
    this.name = e, this.init = mt(t.init, n), this.apply = mt(t.apply, n);
  }
}
const Tr = [
  new oe("doc", {
    init(r) {
      return r.doc || r.schema.topNodeType.createAndFill();
    },
    apply(r) {
      return r.doc;
    }
  }),
  new oe("selection", {
    init(r, e) {
      return r.selection || E.atStart(e.doc);
    },
    apply(r) {
      return r.selection;
    }
  }),
  new oe("storedMarks", {
    init(r) {
      return r.storedMarks || null;
    },
    apply(r, e, t, n) {
      return n.selection.$cursor ? r.storedMarks : null;
    }
  }),
  new oe("scrollToSelection", {
    init() {
      return 0;
    },
    apply(r, e) {
      return r.scrolledIntoView ? e + 1 : e;
    }
  })
];
class Le {
  constructor(e, t) {
    this.schema = e, this.plugins = [], this.pluginsByKey = /* @__PURE__ */ Object.create(null), this.fields = Tr.slice(), t && t.forEach((n) => {
      if (this.pluginsByKey[n.key])
        throw new RangeError("Adding different instances of a keyed plugin (" + n.key + ")");
      this.plugins.push(n), this.pluginsByKey[n.key] = n, n.spec.state && this.fields.push(new oe(n.key, n.spec.state, n));
    });
  }
}
class ae {
  /**
  @internal
  */
  constructor(e) {
    this.config = e;
  }
  /**
  The schema of the state's document.
  */
  get schema() {
    return this.config.schema;
  }
  /**
  The plugins that are active in this state.
  */
  get plugins() {
    return this.config.plugins;
  }
  /**
  Apply the given transaction to produce a new state.
  */
  apply(e) {
    return this.applyTransaction(e).state;
  }
  /**
  @internal
  */
  filterTransaction(e, t = -1) {
    for (let n = 0; n < this.config.plugins.length; n++)
      if (n != t) {
        let i = this.config.plugins[n];
        if (i.spec.filterTransaction && !i.spec.filterTransaction.call(i, e, this))
          return !1;
      }
    return !0;
  }
  /**
  Verbose variant of [`apply`](https://prosemirror.net/docs/ref/#state.EditorState.apply) that
  returns the precise transactions that were applied (which might
  be influenced by the [transaction
  hooks](https://prosemirror.net/docs/ref/#state.PluginSpec.filterTransaction) of
  plugins) along with the new state.
  */
  applyTransaction(e) {
    if (!this.filterTransaction(e))
      return { state: this, transactions: [] };
    let t = [e], n = this.applyInner(e), i = null;
    for (; ; ) {
      let s = !1;
      for (let o = 0; o < this.config.plugins.length; o++) {
        let a = this.config.plugins[o];
        if (a.spec.appendTransaction) {
          let l = i ? i[o].n : 0, h = i ? i[o].state : this, c = l < t.length && a.spec.appendTransaction.call(a, l ? t.slice(l) : t, h, n);
          if (c && n.filterTransaction(c, o)) {
            if (c.setMeta("appendedTransaction", e), !i) {
              i = [];
              for (let p = 0; p < this.config.plugins.length; p++)
                i.push(p < o ? { state: n, n: t.length } : { state: this, n: 0 });
            }
            t.push(c), n = n.applyInner(c), s = !0;
          }
          i && (i[o] = { state: n, n: t.length });
        }
      }
      if (!s)
        return { state: n, transactions: t };
    }
  }
  /**
  @internal
  */
  applyInner(e) {
    if (!e.before.eq(this.doc))
      throw new RangeError("Applying a mismatched transaction");
    let t = new ae(this.config), n = this.config.fields;
    for (let i = 0; i < n.length; i++) {
      let s = n[i];
      t[s.name] = s.apply(e, this[s.name], this, t);
    }
    return t;
  }
  /**
  Accessor that constructs and returns a new [transaction](https://prosemirror.net/docs/ref/#state.Transaction) from this state.
  */
  get tr() {
    return new Xt(this);
  }
  /**
  Create a new state.
  */
  static create(e) {
    let t = new Le(e.doc ? e.doc.type.schema : e.schema, e.plugins), n = new ae(t);
    for (let i = 0; i < t.fields.length; i++)
      n[t.fields[i].name] = t.fields[i].init(e, n);
    return n;
  }
  /**
  Create a new state based on this one, but with an adjusted set
  of active plugins. State fields that exist in both sets of
  plugins are kept unchanged. Those that no longer exist are
  dropped, and those that are new are initialized using their
  [`init`](https://prosemirror.net/docs/ref/#state.StateField.init) method, passing in the new
  configuration object..
  */
  reconfigure(e) {
    let t = new Le(this.schema, e.plugins), n = t.fields, i = new ae(t);
    for (let s = 0; s < n.length; s++) {
      let o = n[s].name;
      i[o] = this.hasOwnProperty(o) ? this[o] : n[s].init(e, i);
    }
    return i;
  }
  /**
  Serialize this state to JSON. If you want to serialize the state
  of plugins, pass an object mapping property names to use in the
  resulting JSON object to plugin objects. The argument may also be
  a string or number, in which case it is ignored, to support the
  way `JSON.stringify` calls `toString` methods.
  */
  toJSON(e) {
    let t = { doc: this.doc.toJSON(), selection: this.selection.toJSON() };
    if (this.storedMarks && (t.storedMarks = this.storedMarks.map((n) => n.toJSON())), e && typeof e == "object")
      for (let n in e) {
        if (n == "doc" || n == "selection")
          throw new RangeError("The JSON fields `doc` and `selection` are reserved");
        let i = e[n], s = i.spec.state;
        s && s.toJSON && (t[n] = s.toJSON.call(i, this[i.key]));
      }
    return t;
  }
  /**
  Deserialize a JSON representation of a state. `config` should
  have at least a `schema` field, and should contain array of
  plugins to initialize the state with. `pluginFields` can be used
  to deserialize the state of plugins, by associating plugin
  instances with the property names they use in the JSON object.
  */
  static fromJSON(e, t, n) {
    if (!t)
      throw new RangeError("Invalid input for EditorState.fromJSON");
    if (!e.schema)
      throw new RangeError("Required config field 'schema' missing");
    let i = new Le(e.schema, e.plugins), s = new ae(i);
    return i.fields.forEach((o) => {
      if (o.name == "doc")
        s.doc = P.fromJSON(e.schema, t.doc);
      else if (o.name == "selection")
        s.selection = E.fromJSON(s.doc, t.selection);
      else if (o.name == "storedMarks")
        t.storedMarks && (s.storedMarks = t.storedMarks.map(e.schema.markFromJSON));
      else {
        if (n)
          for (let a in n) {
            let l = n[a], h = l.spec.state;
            if (l.key == o.name && h && h.fromJSON && Object.prototype.hasOwnProperty.call(t, a)) {
              s[o.name] = h.fromJSON.call(l, e, t[a], s);
              return;
            }
          }
        s[o.name] = o.init(e, s);
      }
    }), s;
  }
}
function Qt(r, e, t) {
  for (let n in r) {
    let i = r[n];
    i instanceof Function ? i = i.bind(e) : n == "handleDOMEvents" && (i = Qt(i, e, {})), t[n] = i;
  }
  return t;
}
class Ar {
  /**
  Create a plugin.
  */
  constructor(e) {
    this.spec = e, this.props = {}, e.props && Qt(e.props, this, this.props), this.key = e.key ? e.key.key : Zt("plugin");
  }
  /**
  Extract the plugin's state field from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const qe = /* @__PURE__ */ Object.create(null);
function Zt(r) {
  return r in qe ? r + "$" + ++qe[r] : (qe[r] = 0, r + "$");
}
class Gt {
  /**
  Create a plugin key.
  */
  constructor(e = "key") {
    this.key = Zt(e);
  }
  /**
  Get the active plugin with this key, if any, from an editor
  state.
  */
  get(e) {
    return e.config.pluginsByKey[this.key];
  }
  /**
  Get the plugin's state from an editor state.
  */
  getState(e) {
    return e[this.key];
  }
}
const Ze = "zx.runtime.root.v2", Ae = "zx.runtime.appended.v2", Ge = (r) => r.meta, Mr = (r) => {
  if (Object.keys(Ge(r)).length !== 0)
    throw new TypeError("transaction-meta-invalid");
}, Me = (r, e) => {
  const t = Object.keys(r).sort(), n = [...e].sort();
  return t.length === n.length && t.every((i, s) => i === n[s]);
}, X = (r) => Number.isSafeInteger(r) && r >= 0, Cr = (r) => Array.isArray(r) && r.every((e, t) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const n = e;
  return !Me(n, ["operationIndex", "stepStart", "stepEnd"]) && (!Me(n, [
    "operationIndex",
    "stepStart",
    "stepEnd",
    "noOpReason"
  ]) || n.noOpReason !== "already-equal") ? !1 : n.operationIndex === t && X(n.stepStart) && X(n.stepEnd) && n.stepEnd >= n.stepStart;
}), Nr = (r) => Array.isArray(r) && r.every(
  (e, t) => X(e) && (t === 0 || e > r[t - 1])
), Rr = (r, e) => {
  if (!X(e))
    throw new TypeError("transaction-time-invalid");
  const t = Object.create(Xt.prototype), n = t;
  return n.doc = r.doc, n.steps = [], n.docs = [], n.mapping = new te(), n.time = e, n.curSelection = r.selection, n.curSelectionFor = 0, n.updated = 0, n.meta = /* @__PURE__ */ Object.create(null), n.storedMarks = r.storedMarks, t;
}, zr = (r, e, t) => Me(r, [
  "protocol",
  "executionId",
  "sequence",
  "compilerRef",
  "operationSpans"
]) && r.protocol === "zx-runtime-root-meta-v2" && r.executionId === t && r.sequence === e && r.compilerRef === "zx.text-editor.operation-compiler-adapter-v2@2.0.0" && Cr(r.operationSpans), Fr = (r, e, t) => {
  if (!Me(r, [
    "protocol",
    "rootExecutionId",
    "sequence",
    "pluginInstanceId",
    "pluginOrder",
    "visibleTransactionRange",
    "operationIndexes"
  ]) || r.protocol !== "zx-runtime-appended-meta-v2" || r.rootExecutionId !== t || r.sequence !== e || typeof r.pluginInstanceId != "string" || r.pluginInstanceId.length === 0 || !X(r.pluginOrder) || !Nr(r.operationIndexes) || !Array.isArray(r.visibleTransactionRange) || r.visibleTransactionRange.length !== 2)
    return !1;
  const [n, i] = r.visibleTransactionRange;
  return X(n) && X(i) && n <= i && i < e;
}, Yr = (r) => Rr(r, 0), ei = (r, e, t) => (Mr(r), r.setMeta(
  Ze,
  D({
    protocol: "zx-runtime-root-meta-v2",
    executionId: e,
    sequence: 0,
    compilerRef: "zx.text-editor.operation-compiler-adapter-v2@2.0.0",
    operationSpans: t
  })
), r), ti = (r, e) => {
  if (r.time !== e.sequence)
    throw new TypeError("transaction-time-invalid");
  const t = D({
    protocol: "zx-runtime-appended-meta-v2",
    rootExecutionId: e.executionId,
    sequence: e.sequence,
    pluginInstanceId: e.pluginInstanceId,
    pluginOrder: e.pluginOrder,
    visibleTransactionRange: e.visibleTransactionRange,
    operationIndexes: e.operationIndexes
  }), n = Ge(r);
  if (Object.keys(n).length) {
    if (Object.keys(n).length === 1 && xe(n[Ae]) === xe(t))
      return r;
    throw new TypeError("transaction-meta-invalid");
  }
  return r.setMeta(Ae, t), r;
}, ni = (r, e, t, n) => {
  const i = Ge(r), s = Object.keys(i), o = e === "root" ? Ze : Ae;
  if (r.time !== t)
    throw new TypeError("transaction-time-invalid");
  if (s.length !== 1 || s[0] !== o)
    throw new TypeError("transaction-meta-invalid");
  const a = i[o];
  if (xe(a), !a || typeof a != "object" || Array.isArray(a))
    throw new TypeError("transaction-meta-invalid");
  const l = a;
  if (e === "root" && !zr(l, t, n) || e === "appended" && !Fr(l, t, n))
    throw new TypeError("transaction-attribution-invalid");
  if (r.selectionSet || r.storedMarksSet)
    throw new TypeError("transaction-attribution-invalid");
  return D({ [o]: a });
}, ri = (r, e) => {
  if (e === "root") {
    const n = r.getMeta(Ze);
    return D({
      owner: "operation-compiler",
      pluginInstanceId: null,
      pluginOrder: null,
      visibleTransactionRange: [0, 0],
      operationIndexes: n.operationSpans.map((i) => i.operationIndex)
    });
  }
  const t = r.getMeta(Ae);
  return D({
    owner: "certified-plugin",
    pluginInstanceId: t.pluginInstanceId,
    pluginOrder: t.pluginOrder,
    visibleTransactionRange: t.visibleTransactionRange,
    operationIndexes: t.operationIndexes
  });
};
var Ce = 200, T = function() {
};
T.prototype.append = function(e) {
  return e.length ? (e = T.from(e), !this.length && e || e.length < Ce && this.leafAppend(e) || this.length < Ce && e.leafPrepend(this) || this.appendInner(e)) : this;
};
T.prototype.prepend = function(e) {
  return e.length ? T.from(e).append(this) : this;
};
T.prototype.appendInner = function(e) {
  return new Dr(this, e);
};
T.prototype.slice = function(e, t) {
  return e === void 0 && (e = 0), t === void 0 && (t = this.length), e >= t ? T.empty : this.sliceInner(Math.max(0, e), Math.min(this.length, t));
};
T.prototype.get = function(e) {
  if (!(e < 0 || e >= this.length))
    return this.getInner(e);
};
T.prototype.forEach = function(e, t, n) {
  t === void 0 && (t = 0), n === void 0 && (n = this.length), t <= n ? this.forEachInner(e, t, n, 0) : this.forEachInvertedInner(e, t, n, 0);
};
T.prototype.map = function(e, t, n) {
  t === void 0 && (t = 0), n === void 0 && (n = this.length);
  var i = [];
  return this.forEach(function(s, o) {
    return i.push(e(s, o));
  }, t, n), i;
};
T.from = function(e) {
  return e instanceof T ? e : e && e.length ? new Yt(e) : T.empty;
};
var Yt = /* @__PURE__ */ (function(r) {
  function e(n) {
    r.call(this), this.values = n;
  }
  r && (e.__proto__ = r), e.prototype = Object.create(r && r.prototype), e.prototype.constructor = e;
  var t = { length: { configurable: !0 }, depth: { configurable: !0 } };
  return e.prototype.flatten = function() {
    return this.values;
  }, e.prototype.sliceInner = function(i, s) {
    return i == 0 && s == this.length ? this : new e(this.values.slice(i, s));
  }, e.prototype.getInner = function(i) {
    return this.values[i];
  }, e.prototype.forEachInner = function(i, s, o, a) {
    for (var l = s; l < o; l++)
      if (i(this.values[l], a + l) === !1)
        return !1;
  }, e.prototype.forEachInvertedInner = function(i, s, o, a) {
    for (var l = s - 1; l >= o; l--)
      if (i(this.values[l], a + l) === !1)
        return !1;
  }, e.prototype.leafAppend = function(i) {
    if (this.length + i.length <= Ce)
      return new e(this.values.concat(i.flatten()));
  }, e.prototype.leafPrepend = function(i) {
    if (this.length + i.length <= Ce)
      return new e(i.flatten().concat(this.values));
  }, t.length.get = function() {
    return this.values.length;
  }, t.depth.get = function() {
    return 0;
  }, Object.defineProperties(e.prototype, t), e;
})(T);
T.empty = new Yt([]);
var Dr = /* @__PURE__ */ (function(r) {
  function e(t, n) {
    r.call(this), this.left = t, this.right = n, this.length = t.length + n.length, this.depth = Math.max(t.depth, n.depth) + 1;
  }
  return r && (e.__proto__ = r), e.prototype = Object.create(r && r.prototype), e.prototype.constructor = e, e.prototype.flatten = function() {
    return this.left.flatten().concat(this.right.flatten());
  }, e.prototype.getInner = function(n) {
    return n < this.left.length ? this.left.get(n) : this.right.get(n - this.left.length);
  }, e.prototype.forEachInner = function(n, i, s, o) {
    var a = this.left.length;
    if (i < a && this.left.forEachInner(n, i, Math.min(s, a), o) === !1 || s > a && this.right.forEachInner(n, Math.max(i - a, 0), Math.min(this.length, s) - a, o + a) === !1)
      return !1;
  }, e.prototype.forEachInvertedInner = function(n, i, s, o) {
    var a = this.left.length;
    if (i > a && this.right.forEachInvertedInner(n, i - a, Math.max(s, a) - a, o + a) === !1 || s < a && this.left.forEachInvertedInner(n, Math.min(i, a), s, o) === !1)
      return !1;
  }, e.prototype.sliceInner = function(n, i) {
    if (n == 0 && i == this.length)
      return this;
    var s = this.left.length;
    return i <= s ? this.left.slice(n, i) : n >= s ? this.right.slice(n - s, i - s) : this.left.slice(n, s).append(this.right.slice(0, i - s));
  }, e.prototype.leafAppend = function(n) {
    var i = this.right.leafAppend(n);
    if (i)
      return new e(this.left, i);
  }, e.prototype.leafPrepend = function(n) {
    var i = this.left.leafPrepend(n);
    if (i)
      return new e(i, this.right);
  }, e.prototype.appendInner = function(n) {
    return this.left.depth >= Math.max(this.right.depth, n.depth) + 1 ? new e(this.left, new e(this.right, n)) : new e(this, n);
  }, e;
})(T);
const Br = 500;
class R {
  constructor(e, t) {
    this.items = e, this.eventCount = t;
  }
  // Pop the latest event off the branch's history and apply it
  // to a document transform.
  popEvent(e, t) {
    if (this.eventCount == 0)
      return null;
    let n = this.items.length;
    for (; ; n--)
      if (this.items.get(n - 1).selection) {
        --n;
        break;
      }
    let i, s;
    t && (i = this.remapping(n, this.items.length), s = i.maps.length);
    let o = e.tr, a, l, h = [], c = [];
    return this.items.forEach((p, f) => {
      if (!p.step) {
        i || (i = this.remapping(n, f + 1), s = i.maps.length), s--, c.push(p);
        return;
      }
      if (i) {
        c.push(new B(p.map));
        let d = p.step.map(i.slice(s)), u;
        d && o.maybeStep(d).doc && (u = o.mapping.maps[o.mapping.maps.length - 1], h.push(new B(u, void 0, void 0, h.length + c.length))), s--, u && i.appendMap(u, s);
      } else
        o.maybeStep(p.step);
      if (p.selection)
        return a = i ? p.selection.map(i.slice(s)) : p.selection, l = new R(this.items.slice(0, n).append(c.reverse().concat(h)), this.eventCount - 1), !1;
    }, this.items.length, 0), { remaining: l, transform: o, selection: a };
  }
  // Create a new branch with the given transform added.
  addTransform(e, t, n, i) {
    let s = [], o = this.eventCount, a = this.items, l = !i && a.length ? a.get(a.length - 1) : null;
    for (let c = 0; c < e.steps.length; c++) {
      let p = e.steps[c].invert(e.docs[c]), f = new B(e.mapping.maps[c], p, t), d;
      (d = l && l.merge(f)) && (f = d, c ? s.pop() : a = a.slice(0, a.length - 1)), s.push(f), t && (o++, t = void 0), i || (l = f);
    }
    let h = o - n.depth;
    return h > jr && (a = Jr(a, h), o -= h), new R(a.append(s), o);
  }
  remapping(e, t) {
    let n = new te();
    return this.items.forEach((i, s) => {
      let o = i.mirrorOffset != null && s - i.mirrorOffset >= e ? n.maps.length - i.mirrorOffset : void 0;
      n.appendMap(i.map, o);
    }, e, t), n;
  }
  addMaps(e) {
    return this.eventCount == 0 ? this : new R(this.items.append(e.map((t) => new B(t))), this.eventCount);
  }
  // When the collab module receives remote changes, the history has
  // to know about those, so that it can adjust the steps that were
  // rebased on top of the remote changes, and include the position
  // maps for the remote changes in its array of items.
  rebased(e, t) {
    if (!this.eventCount)
      return this;
    t = Math.min(this.items.length, t);
    let n = [], i = this.items.length - t, s = e.mapping, o = e.steps.length, a = this.eventCount;
    this.items.forEach((f) => {
      f.selection && a--;
    }, i);
    let l = t;
    this.items.forEach((f) => {
      let d = s.getMirror(--l);
      if (d == null)
        return;
      o = Math.min(o, d);
      let u = s.maps[d];
      if (f.step) {
        let x = e.steps[d].invert(e.docs[d]), O = f.selection && f.selection.map(s.slice(l + 1, d));
        O && a++, n.push(new B(u, x, O));
      } else
        n.push(new B(u));
    }, i);
    let h = [];
    for (let f = t; f < o; f++)
      h.push(new B(s.maps[f]));
    let c = this.items.slice(0, i).append(h).append(n), p = new R(c, a);
    return p.emptyItemCount() > Br && (p = p.compress(this.items.length - n.length)), p;
  }
  emptyItemCount() {
    let e = 0;
    return this.items.forEach((t) => {
      t.step || e++;
    }), e;
  }
  // Compressing a branch means rewriting it to push the air (map-only
  // items) out. During collaboration, these naturally accumulate
  // because each remote change adds one. The `upto` argument is used
  // to ensure that only the items below a given level are compressed,
  // because `rebased` relies on a clean, untouched set of items in
  // order to associate old items with rebased steps.
  compress(e = this.items.length) {
    let t = this.remapping(0, e), n = t.maps.length, i = [], s = 0;
    return this.items.forEach((o, a) => {
      if (a >= e)
        i.push(o), o.selection && s++;
      else if (o.step) {
        let l = o.step.map(t.slice(n)), h = l && l.getMap();
        if (n--, h && t.appendMap(h, n), l) {
          let c = o.selection && o.selection.map(t.slice(n));
          c && s++;
          let p = new B(h.invert(), l, c), f, d = i.length - 1;
          (f = i.length && i[d].merge(p)) ? i[d] = f : i.push(p);
        }
      } else o.map && n--;
    }, this.items.length, 0), new R(T.from(i.reverse()), s);
  }
}
R.empty = new R(T.empty, 0);
function Jr(r, e) {
  let t;
  return r.forEach((n, i) => {
    if (n.selection && e-- == 0)
      return t = i, !1;
  }), r.slice(t);
}
class B {
  constructor(e, t, n, i) {
    this.map = e, this.step = t, this.selection = n, this.mirrorOffset = i;
  }
  merge(e) {
    if (this.step && e.step && !e.selection) {
      let t = e.step.merge(this.step);
      if (t)
        return new B(t.getMap().invert(), t, this.selection);
    }
  }
}
class W {
  constructor(e, t, n, i, s) {
    this.done = e, this.undone = t, this.prevRanges = n, this.prevTime = i, this.prevComposition = s;
  }
}
const jr = 20;
function Pr(r, e, t, n) {
  let i = t.getMeta(L), s;
  if (i)
    return i.historyState;
  t.getMeta(en) && (r = new W(r.done, r.undone, null, 0, -1));
  let o = t.getMeta("appendedTransaction");
  if (t.steps.length == 0)
    return r;
  if (o && o.getMeta(L))
    return o.getMeta(L).redo ? new W(r.done.addTransform(t, void 0, n, we(e)), r.undone, gt(t.mapping.maps), r.prevTime, r.prevComposition) : new W(r.done, r.undone.addTransform(t, void 0, n, we(e)), null, r.prevTime, r.prevComposition);
  if (t.getMeta("addToHistory") !== !1 && !(o && o.getMeta("addToHistory") === !1)) {
    let a = t.getMeta("composition"), l = r.prevTime == 0 || !o && r.prevComposition != a && (r.prevTime < (t.time || 0) - n.newGroupDelay || !Lr(t, r.prevRanges)), h = o ? $e(r.prevRanges, t.mapping) : gt(t.mapping.maps);
    return new W(r.done.addTransform(t, l ? e.selection.getBookmark() : void 0, n, we(e)), R.empty, h, t.time, a ?? r.prevComposition);
  } else return (s = t.getMeta("rebased")) ? new W(r.done.rebased(t, s), r.undone.rebased(t, s), $e(r.prevRanges, t.mapping), r.prevTime, r.prevComposition) : new W(r.done.addMaps(t.mapping.maps), r.undone.addMaps(t.mapping.maps), $e(r.prevRanges, t.mapping), r.prevTime, r.prevComposition);
}
function Lr(r, e) {
  if (!e)
    return !1;
  if (!r.docChanged)
    return !0;
  let t = !1;
  return r.mapping.maps[0].forEach((n, i) => {
    for (let s = 0; s < e.length; s += 2)
      n <= e[s + 1] && i >= e[s] && (t = !0);
  }), t;
}
function gt(r) {
  let e = [];
  for (let t = r.length - 1; t >= 0 && e.length == 0; t--)
    r[t].forEach((n, i, s, o) => e.push(s, o));
  return e;
}
function $e(r, e) {
  if (!r)
    return null;
  let t = [];
  for (let n = 0; n < r.length; n += 2) {
    let i = e.map(r[n], 1), s = e.map(r[n + 1], -1);
    i <= s && t.push(i, s);
  }
  return t;
}
function qr(r, e, t) {
  let n = we(e), i = L.get(e).spec.config, s = (t ? r.undone : r.done).popEvent(e, n);
  if (!s)
    return null;
  let o = s.selection.resolve(s.transform.doc), a = (t ? r.done : r.undone).addTransform(s.transform, e.selection.getBookmark(), i, n), l = new W(t ? a : s.remaining, t ? s.remaining : a, null, 0, -1);
  return s.transform.setSelection(o).setMeta(L, { redo: t, historyState: l });
}
let We = !1, yt = null;
function we(r) {
  let e = r.plugins;
  if (yt != e) {
    We = !1, yt = e;
    for (let t = 0; t < e.length; t++)
      if (e[t].spec.historyPreserveItems) {
        We = !0;
        break;
      }
  }
  return We;
}
function $r(r) {
  return r.setMeta(en, !0);
}
const L = new Gt("history"), en = new Gt("closeHistory");
function Wr(r = {}) {
  return r = {
    depth: r.depth || 100,
    newGroupDelay: r.newGroupDelay || 500
  }, new Ar({
    key: L,
    state: {
      init() {
        return new W(R.empty, R.empty, null, 0, -1);
      },
      apply(e, t, n) {
        return Pr(t, n, e, r);
      }
    },
    config: r,
    props: {
      handleDOMEvents: {
        beforeinput(e, t) {
          let n = t.inputType, i = n == "historyUndo" ? tn : n == "historyRedo" ? nn : null;
          return !i || !e.editable ? !1 : (t.preventDefault(), i(e.state, e.dispatch));
        }
      }
    }
  });
}
function ze(r, e) {
  return (t, n) => {
    let i = L.getState(t);
    if (!i || (r ? i.undone : i.done).eventCount == 0)
      return !1;
    if (n) {
      let s = qr(i, t, r);
      s && n(e ? s.scrollIntoView() : s);
    }
    return !0;
  };
}
const tn = ze(!1, !0), nn = ze(!0, !0), Vr = ze(!1, !1), Hr = ze(!0, !1);
function _r(r) {
  let e = L.getState(r);
  return e ? e.done.eventCount : 0;
}
function Kr(r) {
  let e = L.getState(r);
  return e ? e.undone.eventCount : 0;
}
function Ur(r) {
  return r.getMeta(L) != null;
}
const ii = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  closeHistory: $r,
  history: Wr,
  isHistoryTransaction: Ur,
  redo: nn,
  redoDepth: Kr,
  redoNoScroll: Hr,
  undo: tn,
  undoDepth: _r,
  undoNoScroll: Vr
}, Symbol.toStringTag, { value: "Module" }));
export {
  Ae as A,
  ae as E,
  te as M,
  P as N,
  A as O,
  Gt as P,
  Ze as R,
  E as S,
  Qr as Z,
  Ar as a,
  ii as b,
  wt as c,
  ir as d,
  Rr as e,
  ti as f,
  ri as g,
  Zr as h,
  Nn as i,
  Yr as j,
  ei as k,
  Mn as l,
  M as m,
  ni as r,
  Gr as v
};
//# sourceMappingURL=index-nP4BAjUw.mjs.map
