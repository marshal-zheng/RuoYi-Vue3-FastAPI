import { readTextEditorRuntimeHostCompositionForTargetV2 as t, readTextEditorRuntimeHostCompositionV2 as i } from "#runtime-host-core-authority";
export {
  t as readTextEditorRuntimeHostCompositionForTargetV2,
  i as readTextEditorRuntimeHostCompositionV2
};
//# sourceMappingURL=runtime-host-state.mjs.map
