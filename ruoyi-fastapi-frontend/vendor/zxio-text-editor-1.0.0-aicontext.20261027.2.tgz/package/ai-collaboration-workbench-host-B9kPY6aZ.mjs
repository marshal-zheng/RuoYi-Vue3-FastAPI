import a from "@tiptap/extension-collaboration";
import { e as b, A as s } from "./actions-Sd62WBGv.mjs";
import { c as f } from "./runtime-host-editor-factory-CuJeZzsy.mjs";
import { b0 as c, N as g, L as p, w as d, C as y, b2 as l, b3 as E } from "./yjs-adapter-CNLpxPX5.mjs";
import { g as D } from "./runtime-plugin-definitions-DN_cDAJZ.mjs";
import { readRuntimeTargetDocumentBindingV2 as u } from "#runtime-target-document-authority";
const m = (e) => {
  const t = D();
  return b({
    artifactKind: "zx-text-editor-runtime-artifact-v2",
    parserRef: E,
    runtimeRef: l.runtime,
    closureFingerprint: l.closureFingerprint,
    payload: {
      baseDocument: e.base.document,
      baseDocumentFingerprint: s(e.base.document),
      planDigest: e.base.planDigest,
      resultDocument: e.runtimeExecution.resultDocument,
      resultFingerprint: e.runtimeExecution.resultFingerprint,
      traceFingerprint: e.runtimeExecution.trace.fingerprint,
      mappingFingerprint: e.runtimeExecution.mapping.fingerprint,
      runtimeReceiptFingerprint: s(
        e.runtimeExecution.runtime
      ),
      runtimeManifestFingerprint: t.fingerprints.runtimeManifestFingerprint
    }
  });
}, S = (e) => {
  const t = a.configure({
    document: e.doc,
    field: e.rootSharedType
  });
  c({
    doc: e.doc,
    rootSharedType: e.rootSharedType,
    extension: t
  });
  let r;
  const i = () => ({
    ...e.baseDocument,
    body: {
      format: "json",
      content: r ? r.state.doc.toJSON() : e.baseDocument.body.content
    }
  });
  r = f(
    { content: e.baseDocument.body.content },
    {
      getCurrentDocument: i,
      pages: !1,
      extensions: [t]
    }
  );
  try {
    const n = u(r);
    if (!n)
      throw new TypeError("collaboration-workbench-target-binding-invalid");
    return n.readCanonicalDocument();
  } finally {
    r.destroy();
  }
}, F = (e) => {
  const t = a.configure({
    document: e.doc,
    field: e.rootSharedType
  });
  c({
    doc: e.doc,
    rootSharedType: e.rootSharedType,
    extension: t
  });
  let r;
  const i = () => ({
    ...e.baseDocument,
    body: {
      format: "json",
      content: r ? r.state.doc.toJSON() : e.baseDocument.body.content
    }
  });
  r = f(
    { content: e.baseDocument.body.content },
    {
      getCurrentDocument: i,
      pages: !1,
      extensions: [t]
    }
  );
  const n = () => {
    const o = u(r);
    if (!o)
      throw new TypeError("collaboration-workbench-target-binding-invalid");
    return o.readCanonicalDocument();
  };
  return Object.freeze({
    documentGuid: e.doc.guid,
    createVisibleEditorExtension: () => {
      const o = a.configure({
        document: e.doc,
        field: e.rootSharedType
      });
      return c({
        doc: e.doc,
        rootSharedType: e.rootSharedType,
        extension: o
      }), o;
    },
    runS4Commit: () => p({
      sidecar: e.sidecar,
      proposal: e.transfer.proposal,
      lifecycle: e.transfer.lifecycle,
      currentDocument: n(),
      targetEditor: r
    }),
    createProposalEnvelope: () => {
      const o = y(
        e.transfer.proposal.identity.proposalId
      );
      if (!o)
        throw new TypeError("collaboration-workbench-lifecycle-missing");
      return d({
        sourceProposal: e.transfer.proposal,
        lifecycle: o,
        runtimeArtifact: m(
          e.transfer.proposal
        )
      });
    },
    createReviewHistoricalEnvelope: (o) => g({
      sidecar: o,
      proposalEnvelope: d({
        sourceProposal: e.transfer.proposal,
        lifecycle: e.transfer.lifecycle,
        runtimeArtifact: m(
          e.transfer.proposal
        )
      })
    }),
    readCanonicalDocument: n,
    destroy() {
      r == null || r.destroy(), r = void 0;
    }
  });
};
export {
  F as createAICollaborationWorkbenchCommitHost,
  S as readAICollaborationWorkbenchCanonicalDocument
};
//# sourceMappingURL=ai-collaboration-workbench-host-B9kPY6aZ.mjs.map
