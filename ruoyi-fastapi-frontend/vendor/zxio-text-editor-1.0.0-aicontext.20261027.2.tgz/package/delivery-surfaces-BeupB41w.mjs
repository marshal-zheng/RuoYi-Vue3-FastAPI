function Ie(e) {
  return `zx-${e}`;
}
function Tt(e, t) {
  return `zx-${e}__${t}`;
}
const De = "pageBreak", At = "data-zx-page-break", zt = Ie("text-editor-page-break"), Nt = "<!-- zx-page-break -->", F = (e) => !e || typeof e != "object" ? e : Array.isArray(e) ? (e.forEach((t) => F(t)), Object.freeze(e)) : (Object.values(e).forEach((t) => F(t)), Object.freeze(e)), L = (e) => F({
  ...e,
  table: e.table ? { ...e.table } : void 0
}), u = (e) => L(e), $ = (e, t = `Pages layout can paginate "${e}" at top-level block boundaries.`) => u({
  nodeType: e,
  split: "block-boundary",
  atomic: !1,
  nonSplittable: !1,
  asyncSized: !1,
  measurable: !0,
  exportSensitive: !1,
  risk: "safe",
  defaultSeverity: "info",
  diagnosticCode: "pages.blockSafety.unsupported",
  message: t,
  recoveryHint: "Continue using automatic Pages layout; no block-specific action is required."
}), b = (e, t, r = `Pages layout treats top-level "${e}" as one non-splittable block in this phase.`) => u({
  nodeType: e,
  split: "block-boundary",
  atomic: !1,
  nonSplittable: !0,
  asyncSized: !1,
  measurable: !0,
  exportSensitive: !1,
  risk: "partial",
  defaultSeverity: "warning",
  diagnosticCode: "pages.blockSafety.unsupported",
  message: r,
  recoveryHint: t
}), ne = u({
  nodeType: "*",
  split: "unsupported",
  atomic: !0,
  nonSplittable: !0,
  asyncSized: !1,
  measurable: !1,
  exportSensitive: !0,
  risk: "unsupported",
  defaultSeverity: "warning",
  diagnosticCode: "pages.blockSafety.unknown",
  message: "Pages layout encountered an unknown top-level block and is using a conservative partial page map.",
  recoveryHint: "Register an explicit block safety rule before treating this custom block as safely splittable."
}), Re = F([
  $("paragraph"),
  $("heading"),
  $("blockquote"),
  b(
    "bulletList",
    "Split long lists into smaller sections if page boundaries need to be exact."
  ),
  b(
    "orderedList",
    "Split long lists into smaller sections if page boundaries need to be exact."
  ),
  b(
    "taskList",
    "Split long task lists into smaller sections if page boundaries need to be exact."
  ),
  b(
    "toggle",
    "Move or split toggle content when it must align with page boundaries."
  ),
  u({
    nodeType: "table",
    split: "future-row-boundary",
    atomic: !1,
    nonSplittable: !0,
    asyncSized: !1,
    measurable: !0,
    exportSensitive: !0,
    risk: "unsupported",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.table-non-splittable",
    message: "Tables are paginated as one non-splittable top-level block in this phase.",
    recoveryHint: "Move the table, reduce its height, or split it manually; row splitting is reserved for a later phase.",
    table: {
      rowSplitting: "not-supported",
      hasRowMetadata: !0
    }
  }),
  b(
    "image",
    "Reduce the image size, move it to a new page, or adjust page settings."
  ),
  b(
    "imageGroup",
    "Split the image group, reduce image sizes, or adjust page settings."
  ),
  u({
    nodeType: "video",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !0,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.async-sized",
    message: "Video blocks depend on async media sizing and remain non-splittable.",
    recoveryHint: "Wait for media load remeasurement, reduce the block size, or move it to a dedicated page."
  }),
  u({
    nodeType: "iframe",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !0,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.async-sized",
    message: "Iframe blocks depend on async embed sizing and remain non-splittable.",
    recoveryHint: "Wait for iframe load remeasurement, reduce the embed size, or move it to a dedicated page."
  }),
  u({
    nodeType: "embed",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !0,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.async-sized",
    message: "Embed blocks may depend on async content sizing and remain non-splittable.",
    recoveryHint: "Wait for embed load remeasurement, reduce the embed size, or move it to a dedicated page."
  }),
  b(
    "codeBlock",
    "Split large code blocks manually; inline-level code splitting is not enabled in this phase."
  ),
  u({
    nodeType: "attachment",
    split: "unsupported",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !1,
    measurable: !0,
    exportSensitive: !0,
    risk: "partial",
    defaultSeverity: "warning",
    diagnosticCode: "pages.blockSafety.unsupported",
    message: "Attachment blocks are treated as atomic non-splittable content.",
    recoveryHint: "Move oversized attachments or accept a partial page map for the affected page."
  }),
  u({
    nodeType: De,
    split: "manual-boundary",
    atomic: !0,
    nonSplittable: !0,
    asyncSized: !1,
    measurable: !1,
    exportSensitive: !1,
    risk: "safe",
    defaultSeverity: "info",
    diagnosticCode: "pages.pageBreak.command-invalid",
    message: "PageBreak creates a user-authored forced page boundary.",
    recoveryHint: "Keep PageBreak nodes in the document when explicit page boundaries are required."
  })
]), Z = (e, t) => L({
  ...e,
  ...t,
  table: t.table || e.table ? {
    ...e.table ?? {
      rowSplitting: "not-supported",
      hasRowMetadata: !1
    },
    ...t.table ?? {}
  } : void 0
}), je = (e, t) => F({
  version: 1,
  rules: Array.from(e, L),
  unknownRule: L(t)
}), It = (e = []) => {
  const t = /* @__PURE__ */ new Map();
  Re.forEach((a) => {
    t.set(a.nodeType, L(a));
  });
  let r = L(ne);
  return e.forEach((a) => {
    if (!a.nodeType)
      return;
    if (a.nodeType === "*" || a.nodeType === "unknown") {
      r = Z(r, {
        ...a,
        nodeType: "*"
      });
      return;
    }
    const o = t.get(a.nodeType);
    t.set(
      a.nodeType,
      Z(o || {
        ...ne,
        nodeType: a.nodeType
      }, a)
    );
  }), F({
    resolveRule: (a) => L(t.get(a) ?? { ...r, nodeType: a }),
    getSnapshot: () => je(t.values(), r)
  });
}, Dt = (e, t) => e.resolveRule(t), Rt = (e) => e.getSnapshot();
class he extends Error {
  constructor(t) {
    super(t.message), this.name = "ZxPagesContractError", this.diagnostic = t;
  }
}
const Ve = (e) => ({ ...e }), jt = (e, t) => {
  e.push(Ve(t));
}, y = (e) => new he(e), Vt = (e) => e instanceof he, h = 96, ye = 2.54, be = 72, c = (e, t = "value") => {
  if (!Number.isFinite(e))
    throw y({
      code: "pages.unit.invalid",
      severity: "error",
      message: `Pages ${t} must be a finite number.`,
      target: t
    });
  return e;
}, k = (e) => c(e, "inches") * h, x = (e) => c(e, "centimeters") / ye * h, we = (e) => c(e, "pixels") / h, Ht = (e) => we(e) * ye, C = (e) => we(e) * be, _ = (e) => c(e, "printPoints") / be * h, Le = {
  top: h,
  right: h,
  bottom: h,
  left: h
}, Se = (e) => ({
  top: e.top,
  right: e.right,
  bottom: e.bottom,
  left: e.left
}), Pe = (e) => ({
  id: e.id,
  label: e.label,
  width: e.width,
  height: e.height,
  defaultMargins: Se(e.defaultMargins),
  ...e.metadata ? { metadata: { ...e.metadata } } : {}
}), He = (e) => (e.metadata && Object.freeze(e.metadata), Object.freeze(e.defaultMargins), Object.freeze(e)), E = (e, t, r, a) => He({
  id: e,
  label: t,
  width: r,
  height: a,
  defaultMargins: Se(Le)
}), f = /* @__PURE__ */ new Map([
  ["a4", E("a4", "A4", x(21), x(29.7))],
  ["a3", E("a3", "A3", x(29.7), x(42))],
  ["a5", E("a5", "A5", x(14.8), x(21))],
  [
    "letter",
    E(
      "letter",
      "Letter",
      k(8.5),
      k(11)
    )
  ],
  [
    "legal",
    E(
      "legal",
      "Legal",
      k(8.5),
      k(14)
    )
  ],
  [
    "tabloid",
    E(
      "tabloid",
      "Tabloid",
      k(11),
      k(17)
    )
  ]
]);
class Ue {
  get size() {
    return f.size;
  }
  [Symbol.iterator]() {
    return this.entries();
  }
  entries() {
    return f.entries();
  }
  forEach(t, r) {
    f.forEach(
      (a, o) => t.call(r, a, o, this)
    );
  }
  get(t) {
    return f.get(t);
  }
  has(t) {
    return f.has(t);
  }
  keys() {
    return f.keys();
  }
  values() {
    return f.values();
  }
}
const $e = Object.freeze(new Ue()), Ut = (e) => $e.has(e), W = (e) => {
  const t = f.get(e);
  return t ? Pe(t) : null;
}, Y = (e, t) => {
  const r = {
    top: c(e.top, "margin.top"),
    right: c(e.right, "margin.right"),
    bottom: c(e.bottom, "margin.bottom"),
    left: c(e.left, "margin.left")
  }, a = Object.entries(r).find(([, o]) => o < 0);
  if (a)
    throw y({
      code: "pages.margins.invalid",
      severity: "error",
      message: `Pages margin "${a[0]}" must be non-negative.`,
      path: `margins.${a[0]}`
    });
  if (r.left + r.right >= t.width)
    throw y({
      code: "pages.margins.invalid",
      severity: "error",
      message: "Pages horizontal margins must be smaller than page width.",
      path: "margins.left+right"
    });
  if (r.top + r.bottom >= t.height)
    throw y({
      code: "pages.margins.invalid",
      severity: "error",
      message: "Pages vertical margins must be smaller than page height.",
      path: "margins.top+bottom"
    });
  return r;
}, q = (e) => {
  if (typeof e == "string") {
    const n = W(e);
    if (!n)
      throw y({
        code: "pages.format.unknown",
        severity: "error",
        message: `Unknown Pages page format "${e}".`,
        target: e
      });
    return n;
  }
  const t = typeof e.id == "string" ? e.id.trim() : "", r = typeof e.label == "string" ? e.label.trim() : "", a = c(e.width, "page.width"), o = c(e.height, "page.height");
  if (!t || !r || a <= 0 || o <= 0)
    throw y({
      code: "pages.format.invalid",
      severity: "error",
      message: "Custom Pages page formats require id, label, positive width and positive height.",
      target: t || void 0
    });
  const i = {
    id: t,
    label: r,
    width: a,
    height: o,
    defaultMargins: Y(e.defaultMargins, {
      width: a,
      height: o
    }),
    ...e.metadata ? { metadata: { ...e.metadata } } : {}
  };
  return Pe(i);
}, D = (e = {}, t = Le) => ({
  top: e.top ?? t.top,
  right: e.right ?? t.right,
  bottom: e.bottom ?? t.bottom,
  left: e.left ?? t.left
}), Q = [
  "default",
  "firstPage",
  "oddPage",
  "evenPage"
], Ze = ["header", "footer"], ve = (e) => JSON.parse(JSON.stringify(e)), S = (e) => typeof e == "object" && e !== null && !Array.isArray(e), le = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0, $t = (e) => typeof e == "string" && Ze.includes(e), Zt = (e) => typeof e == "string" && Q.includes(e), Gt = () => ({
  version: 1,
  differentFirstPage: !1,
  differentOddEven: !1
}), ke = (e) => e.state === "empty" ? { state: "empty" } : {
  state: "content",
  ...e.content ? { content: ve(e.content) } : {}
}, Ge = (e) => {
  if (S(e)) {
    if (e.state === "empty")
      return { state: "empty" };
    if (e.state === "content" && S(e.content))
      return {
        state: "content",
        content: ve(e.content)
      };
  }
}, Ke = (e) => {
  if (!e)
    return;
  const t = {};
  return Q.forEach((r) => {
    const a = e[r];
    a && (t[r] = ke(a));
  }), Object.keys(t).length ? t : void 0;
}, R = (e) => {
  if (!S(e))
    return;
  const t = {};
  return Q.forEach((r) => {
    const a = Ge(e[r]);
    a && (t[r] = a);
  }), Object.keys(t).length ? t : void 0;
}, Xe = (e) => {
  if (!Array.isArray(e))
    return;
  const t = e.filter(
    (r) => S(r) && typeof r.sectionId == "string" && !!r.sectionId.trim()
  ).map((r) => {
    const a = R(r.header), o = R(r.footer);
    return {
      sectionId: r.sectionId.trim(),
      ...typeof r.startBlockId == "string" && r.startBlockId.trim() ? { startBlockId: r.startBlockId.trim() } : {},
      ...typeof r.differentFirstPage == "boolean" ? { differentFirstPage: r.differentFirstPage } : {},
      ...typeof r.differentOddEven == "boolean" ? { differentOddEven: r.differentOddEven } : {},
      ...a ? { header: a } : {},
      ...o ? { footer: o } : {}
    };
  });
  return t.length ? t : void 0;
}, P = (e = {}) => {
  const t = S(e) ? e : {}, r = R(t.header), a = R(t.footer), o = Xe(t.sections);
  return {
    version: 1,
    differentFirstPage: t.differentFirstPage === !0,
    differentOddEven: t.differentOddEven === !0,
    ...le(t.headerTopMargin) ? { headerTopMargin: t.headerTopMargin } : {},
    ...le(t.footerBottomMargin) ? { footerBottomMargin: t.footerBottomMargin } : {},
    ...r ? { header: r } : {},
    ...a ? { footer: a } : {},
    ...o ? { sections: o } : {}
  };
}, Kt = P, xe = (e) => !S(e) && !Array.isArray(e) ? e : (Object.values(e).forEach((t) => {
  (S(t) || Array.isArray(t)) && xe(t);
}), Object.freeze(e)), Xt = (e = {}) => xe(P(e)), j = "a4", Ee = "portrait", v = (e) => JSON.parse(JSON.stringify(e)), p = (e) => typeof e == "object" && e !== null && !Array.isArray(e), qe = (e) => !("meta" in e), Je = (e) => qe(e) ? e : e.meta, ee = (e, t = Ee) => e === "portrait" || e === "landscape" ? e : t, O = (e) => typeof e == "number" && Number.isFinite(e) && e > 0, te = (e, t = { id: j }) => typeof e == "string" && e.trim() ? { id: e.trim() } : !p(e) || typeof e.id != "string" || !e.id.trim() ? { ...t } : {
  id: e.id.trim(),
  ...typeof e.label == "string" && e.label.trim() ? { label: e.label.trim() } : {},
  ...typeof e.width == "number" && Number.isFinite(e.width) ? { width: e.width } : {},
  ...typeof e.height == "number" && Number.isFinite(e.height) ? { height: e.height } : {}
}, A = (e, t = {}) => {
  const r = W(e.id);
  if (r && e.width === void 0 && e.height === void 0)
    return r;
  if (O(e.width) && O(e.height))
    return q({
      id: e.id,
      label: e.label ?? e.id,
      width: e.width,
      height: e.height,
      defaultMargins: (r == null ? void 0 : r.defaultMargins) ?? z().defaultMargins
    });
  if (r)
    return r;
  const a = t.unknownFormatFallback;
  if (!a)
    throw y({
      code: "pages.format.unknown",
      severity: "error",
      message: `Unknown Pages page format "${e.id}" requires width and height.`,
      target: e.id,
      path: "pageFormat"
    });
  return q({
    id: e.id,
    label: e.label ?? e.id,
    width: a.width,
    height: a.height,
    defaultMargins: a.defaultMargins,
    metadata: {
      fallback: !0
    }
  });
}, Ce = (e) => A(e, {
  unknownFormatFallback: z()
}), z = () => q(j), re = (e, t, r) => {
  const a = p(e) ? D(
    {
      top: typeof e.top == "number" ? e.top : void 0,
      right: typeof e.right == "number" ? e.right : void 0,
      bottom: typeof e.bottom == "number" ? e.bottom : void 0,
      left: typeof e.left == "number" ? e.left : void 0
    },
    t
  ) : D({}, t);
  return Y(a, r);
}, _e = (e, t) => {
  if (p(e))
    return D(
      {
        ...typeof e.top == "number" ? { top: _(e.top) } : {},
        ...typeof e.right == "number" ? { right: _(e.right) } : {},
        ...typeof e.bottom == "number" ? { bottom: _(e.bottom) } : {},
        ...typeof e.left == "number" ? { left: _(e.left) } : {}
      },
      t
    );
}, We = (e) => ({
  top: C(e.top),
  right: C(e.right),
  bottom: C(e.bottom),
  left: C(e.left)
}), Be = (e, t) => {
  const r = p(e) ? e : {}, a = typeof r.size == "string" && r.size.trim() ? r.size.trim() : t.id, o = typeof r.label == "string" && r.label.trim() ? r.label.trim() : t.label, i = O(r.width) ? _(r.width) : void 0, n = O(r.height) ? _(r.height) : void 0;
  if (i !== void 0 && n !== void 0)
    return {
      id: a,
      ...o ? { label: o } : {},
      width: i,
      height: n
    };
  if (W(a))
    return {
      id: a,
      ...o ? { label: o } : {}
    };
  const s = Ce(t);
  return {
    id: a,
    label: o ?? a,
    width: s.width,
    height: s.height
  };
}, Ye = (e, t) => {
  const r = (t == null ? void 0 : t.pageFormat) ?? { id: j }, a = te(
    p(e) ? e.pageFormat : void 0,
    r
  ), o = A(a), i = (t == null ? void 0 : t.margins) ?? o.defaultMargins ?? z().defaultMargins;
  return {
    pageFormat: a,
    orientation: ee(
      p(e) ? e.orientation : void 0,
      t == null ? void 0 : t.orientation
    ),
    margins: re(
      p(e) ? e.margins : void 0,
      i,
      o
    )
  };
}, Qe = (e, t) => {
  const r = { id: j }, a = p(e) ? e : {}, o = Be(e, r), i = Ce(o), n = i.defaultMargins ?? z().defaultMargins, s = _e(
    a.margins,
    n
  );
  return {
    pageFormat: o,
    orientation: ee(
      a.orientation,
      t == null ? void 0 : t.orientation
    ),
    margins: re(s, n, i)
  };
}, et = (e, t) => {
  if (!p(e))
    return;
  const r = "pageFormat" in e, a = "orientation" in e, o = "margins" in e;
  if (!r && !a && !o)
    return;
  const i = r ? te(e.pageFormat, t.pageFormat) : t.pageFormat, n = A(i), s = {};
  return r && (s.pageFormat = i), a && (s.orientation = ee(
    e.orientation,
    t.orientation
  )), o && (s.margins = re(
    e.margins,
    t.margins,
    n
  )), s;
}, tt = (e, t) => {
  const r = e.page ? et(e.page, t) : void 0;
  return {
    id: e.id,
    startBlockId: e.startBlockId,
    ...r ? { page: r } : {},
    ...e.intent ? { intent: v(e.intent) } : {}
  };
}, rt = (e, t) => {
  if (!Array.isArray(e))
    return;
  const r = e.filter(
    (a) => p(a) && typeof a.id == "string" && !!a.id.trim() && typeof a.startBlockId == "string" && !!a.startBlockId.trim()
  ).map(
    (a) => tt(
      {
        ...a,
        id: a.id.trim(),
        startBlockId: a.startBlockId.trim()
      },
      t
    )
  );
  return r.length ? r : void 0;
}, at = (e, t) => {
  if (e != null && e.length)
    return e.map((r) => ({
      id: r.id,
      startBlockId: r.startBlockId,
      ...r.page ? {
        page: {
          ...r.page.size ? {
            pageFormat: Be(
              r.page,
              t.pageFormat
            )
          } : {},
          ...r.page.orientation ? { orientation: r.page.orientation } : {},
          ...r.page.margins ? {
            margins: _e(
              r.page.margins,
              t.margins
            )
          } : {}
        }
      } : {},
      ...r.intent ? { intent: v(r.intent) } : {}
    }));
}, g = (e = {}) => {
  var n, s;
  const t = z(), r = {
    pageFormat: {
      id: t.id
    },
    orientation: Ee,
    margins: t.defaultMargins
  }, a = Ye((n = e.defaults) == null ? void 0 : n.page, r), o = rt(e.sections, a), i = e.headerFooter ? P(e.headerFooter) : void 0;
  return {
    version: 1,
    defaults: {
      page: a,
      ...(s = e.defaults) != null && s.intent ? { intent: v(e.defaults.intent) } : {}
    },
    ...o ? { sections: o } : {},
    ...i ? { headerFooter: i } : {}
  };
}, ot = (e) => {
  var a, o;
  const t = Je(e);
  if (t.pages)
    return g(t.pages);
  const r = t.binaryExport;
  if (r) {
    const i = Qe((a = r.defaults) == null ? void 0 : a.page), n = at(
      r.sections,
      i
    );
    return g({
      defaults: {
        page: i,
        ...(o = r.defaults) != null && o.intent ? { intent: v(r.defaults.intent) } : {}
      },
      ...n ? { sections: n } : {}
    });
  }
  return g();
}, qt = (e, t) => {
  const r = g(e), a = r.defaults.page, o = t.pageFormat ? te(t.pageFormat, a.pageFormat) : a.pageFormat, i = A(o), n = Y(
    D(t.margins, a.margins),
    i
  );
  return g({
    ...r,
    defaults: {
      ...r.defaults,
      page: {
        pageFormat: o,
        orientation: t.orientation ?? a.orientation,
        margins: n
      }
    }
  });
}, it = (e, t) => t === "header" ? e.header : e.footer, st = (e, t, r) => t === "header" ? {
  ...e,
  ...r ? { header: r } : { header: void 0 }
} : {
  ...e,
  ...r ? { footer: r } : { footer: void 0 }
}, Jt = (e, t) => {
  const r = t.mode ?? "set", a = g(e), o = P(
    a.headerFooter
  ), i = {
    ...Ke(
      it(o, t.kind)
    ) ?? {}
  };
  if (r === "unset")
    delete i[t.slot];
  else if (r === "empty")
    i[t.slot] = { state: "empty" };
  else if (t.value)
    i[t.slot] = ke(t.value);
  else
    throw y({
      code: "pages.headerFooter.content-invalid",
      severity: "error",
      message: "Header/footer slot replacement requires content value.",
      target: `${t.kind}.${t.slot}`,
      path: `headerFooter.${t.kind}.${t.slot}`,
      recoveryHint: 'Pass a normalized content value, use mode "empty", or use mode "unset".'
    });
  const n = st(
    o,
    t.kind,
    Object.keys(i).length ? i : void 0
  );
  return g({
    ...a,
    headerFooter: P(n)
  });
}, Wt = (e, t) => {
  const r = g(e), a = P(
    r.headerFooter
  );
  return g({
    ...r,
    headerFooter: P({
      ...a,
      ...typeof t.differentFirstPage == "boolean" ? { differentFirstPage: t.differentFirstPage } : {},
      ...typeof t.differentOddEven == "boolean" ? { differentOddEven: t.differentOddEven } : {}
    })
  });
}, de = (e) => {
  const t = e.pageFormat;
  return {
    ...t != null && t.id ? { size: t.id } : {},
    ...t != null && t.label ? { label: t.label } : {},
    ...O(t == null ? void 0 : t.width) && O(t == null ? void 0 : t.height) ? {
      width: C(t.width),
      height: C(t.height)
    } : {},
    ...e.orientation ? { orientation: e.orientation } : {},
    ...e.margins ? { margins: We(e.margins) } : {}
  };
}, Yt = (e) => ({
  ...e,
  pageFormat: A(e.pageFormat)
}), nt = (e) => {
  var r;
  const t = g(e);
  return {
    defaults: {
      page: de(t.defaults.page),
      ...t.defaults.intent ? { intent: v(t.defaults.intent) } : {}
    },
    ...(r = t.sections) != null && r.length ? {
      sections: t.sections.map((a) => ({
        id: a.id,
        startBlockId: a.startBlockId,
        ...a.page ? { page: de(a.page) } : {},
        ...a.intent ? { intent: v(a.intent) } : {}
      }))
    } : {}
  };
}, Qt = (e) => e.meta.pages ? nt(
  ot(e)
) : e.meta.binaryExport ? v(e.meta.binaryExport) : void 0, ae = "zx-code-block/v2", er = [
  "platform-default",
  "user-preference",
  "node-explicit",
  "migration"
], lt = (e = "platform-default") => ({
  contractVersion: "platform-default",
  language: e,
  detectedLanguage: "platform-default",
  filename: e,
  caption: e,
  showLineNumbers: e,
  startLine: e,
  wrap: e,
  collapsed: e,
  previewLines: e,
  heightMode: e,
  height: e,
  theme: e,
  highlightLines: e,
  copyMode: e,
  variant: e,
  groupId: e,
  tabLabel: e
}), dt = (e = "platform-default") => ({
  contractVersion: ae,
  language: null,
  detectedLanguage: null,
  filename: "",
  caption: "",
  showLineNumbers: !0,
  startLine: 1,
  wrap: "inherit",
  collapsed: !1,
  previewLines: null,
  heightMode: "max",
  height: null,
  theme: null,
  highlightLines: [],
  copyMode: "plain",
  variant: "code",
  groupId: null,
  tabLabel: "",
  defaultSource: lt(e)
}), tr = [
  {
    field: "contractVersion",
    type: "'zx-code-block/v2'",
    defaultValue: ae,
    sourcePolicy: "platform-default/generated",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Migration idempotency marker"
  },
  {
    field: "language",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Normalized language id"
  },
  {
    field: "detectedLanguage",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved for language detection"
  },
  {
    field: "filename",
    type: "string",
    defaultValue: "",
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Display filename or migrated legacy title"
  },
  {
    field: "caption",
    type: "string",
    defaultValue: "",
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Optional prose caption"
  },
  {
    field: "showLineNumbers",
    type: "boolean",
    defaultValue: !0,
    sourcePolicy: "node-explicit | user-preference | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Line number display state"
  },
  {
    field: "startLine",
    type: "number",
    defaultValue: 1,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "First rendered line number"
  },
  {
    field: "wrap",
    type: "'inherit' | 'off' | 'on'",
    defaultValue: "inherit",
    sourcePolicy: "node-explicit | user-preference | markdown-sidecar | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Wrap preference state"
  },
  {
    field: "collapsed",
    type: "boolean",
    defaultValue: !1,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Collapsed display state"
  },
  {
    field: "previewLines",
    type: "number | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | user-preference | markdown-sidecar | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Preview line count when collapsed"
  },
  {
    field: "heightMode",
    type: "'auto' | 'max' | 'fixed'",
    defaultValue: "max",
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Height semantics for current and later UI"
  },
  {
    field: "height",
    type: "number | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | migration | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Fixed or max height value in pixels"
  },
  {
    field: "theme",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | user-preference | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved highlighter theme preference"
  },
  {
    field: "highlightLines",
    type: "ZxCodeBlockLineRange[]",
    defaultValue: [],
    sourcePolicy: "node-explicit | markdown-sidecar | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Line highlight ranges"
  },
  {
    field: "copyMode",
    type: "'plain' | 'markdown'",
    defaultValue: "plain",
    sourcePolicy: "node-explicit | user-preference | platform-default",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Copy behavior preference"
  },
  {
    field: "variant",
    type: "'code'",
    defaultValue: "code",
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved variant discriminator"
  },
  {
    field: "groupId",
    type: "string | null",
    defaultValue: null,
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved multilingual group id"
  },
  {
    field: "tabLabel",
    type: "string",
    defaultValue: "",
    sourcePolicy: "node-explicit | platform-default",
    lifecycle: "reserved",
    persisted: !0,
    headless: !1,
    descriptor: !0,
    notes: "Reserved multilingual tab label"
  },
  {
    field: "defaultSource",
    type: "field source map",
    defaultValue: "generated",
    sourcePolicy: "generated from normalization",
    lifecycle: "implemented",
    persisted: !0,
    headless: !0,
    descriptor: !0,
    notes: "Per-field source provenance"
  }
], ct = (e) => e, m = (e, t) => {
  e.some(
    (a) => a.code === t.code && a.path === t.path && a.message === t.message
  ) || e.push(t);
}, Me = Object.freeze({
  js: "javascript",
  javascript: "javascript",
  jsx: "javascript",
  ts: "typescript",
  typescript: "typescript",
  tsx: "typescript",
  sh: "bash",
  bash: "bash",
  shell: "bash",
  zsh: "bash",
  plaintext: "plaintext",
  "plain text": "plaintext",
  plain: "plaintext",
  text: "plaintext",
  txt: "plaintext",
  json: "json",
  html: "html",
  css: "css",
  scss: "scss",
  yaml: "yaml",
  yml: "yaml",
  markdown: "markdown",
  md: "markdown"
}), Fe = new Set(
  Object.values(Me)
), pt = (e) => typeof e != "string" ? null : e.trim().toLowerCase().replace(/\s+/g, " ") || null, J = (e, t = {}) => {
  const r = pt(e), a = t.source ?? (r ? "explicit" : "fallback"), o = t.supportedLanguages ?? Fe;
  if (!r)
    return {
      id: null,
      original: null,
      source: "fallback",
      supported: !0,
      diagnostics: []
    };
  const i = Me[r] ?? r;
  return o.has(i) ? {
    id: i,
    original: (e == null ? void 0 : e.trim()) || null,
    source: a,
    supported: !0,
    diagnostics: []
  } : {
    id: "plaintext",
    original: (e == null ? void 0 : e.trim()) || null,
    source: "fallback",
    supported: !1,
    diagnostics: [
      ct({
        code: "codeBlock.highlighter.unsupportedLanguage",
        severity: "warning",
        path: "attrs.language",
        message: `Language "${e}" is not supported and was downgraded to plaintext.`
      })
    ]
  };
}, gt = (e = {}) => () => {
  const t = e.supportedLanguages ?? Fe;
  return {
    normalizeLanguage: (r) => J(r, { supportedLanguages: t }),
    getLanguageSupport: (r) => {
      const a = J(r, {
        supportedLanguages: t
      });
      return {
        supported: a.supported !== !1,
        reason: a.supported === !1 ? "Language is not in the highlighter capability map." : void 0
      };
    },
    getThemeSupport: (r) => ({
      supported: r == null || r === "",
      reason: r ? "Theme support is reserved for a later highlighter adapter." : void 0
    })
  };
}, ut = /* @__PURE__ */ new Set(["inherit", "off", "on"]), mt = /* @__PURE__ */ new Set([
  "auto",
  "max",
  "fixed"
]), ft = /* @__PURE__ */ new Set(["plain", "markdown"]), ht = /* @__PURE__ */ new Set(["code"]), Oe = (e) => typeof e == "object" && e !== null, l = (e, t) => Object.prototype.hasOwnProperty.call(e, t), ce = (e, t) => e === "platform-default" || e === "user-preference" || e === "node-explicit" || e === "migration" ? e : t, G = (e) => typeof e == "string" && e.trim() ? e.trim() : null, K = (e) => typeof e == "string" ? e.trim() : "", pe = (e, t, r, a) => typeof e == "boolean" ? e : (e === void 0 || m(a, {
  code: "codeBlock.attr.invalid",
  severity: "warning",
  path: r,
  message: "Expected a boolean value; fallback was used."
}), t), yt = (e, t, r, a, o = {}) => {
  const i = typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null;
  return i !== null && i >= 1 ? i : (e === void 0 || m(a, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: r,
    message: o.nullable === !1 ? "Expected a positive integer; fallback was used." : "Expected a positive integer or null; fallback was used."
  }), t);
}, ge = (e, t, r, a) => {
  if (e == null || e === "") return t;
  const o = typeof e == "number" && Number.isFinite(e) ? Math.round(e) : typeof e == "string" && /^-?\d+$/.test(e.trim()) ? Number.parseInt(e.trim(), 10) : null;
  return o !== null && o >= 1 ? o : (m(a, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: r,
    message: "Expected a positive integer or null; fallback was used."
  }), t);
}, I = (e, t, r, a, o) => typeof e == "string" && t.has(e) ? e : (e === void 0 || m(o, {
  code: "codeBlock.attr.invalid",
  severity: "warning",
  path: a,
  message: `Unknown enum value "${String(e)}"; fallback was used.`
}), r), bt = (e, t) => e === void 0 ? [] : Array.isArray(e) ? e.flatMap((r, a) => {
  if (!Oe(r))
    return m(t, {
      code: "codeBlock.attr.invalid",
      severity: "warning",
      path: `attrs.highlightLines.${a}`,
      message: "Expected highlight range to be an object."
    }), [];
  const o = typeof r.from == "number" && Number.isFinite(r.from) ? Math.round(r.from) : null, i = r.to === void 0 || r.to === null ? void 0 : typeof r.to == "number" && Number.isFinite(r.to) ? Math.round(r.to) : null;
  return !o || o < 1 || i === null || i !== void 0 && i < o ? (m(t, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: `attrs.highlightLines.${a}`,
    message: "Invalid highlight range was discarded."
  }), []) : i === void 0 ? [{ from: o }] : [{ from: o, to: i }];
}) : (m(t, {
  code: "codeBlock.attr.invalid",
  severity: "warning",
  path: "attrs.highlightLines",
  message: "Expected highlightLines to be an array; fallback was used."
}), []), wt = (e = {}, t = {}) => {
  const r = [], a = t.source ?? "node-explicit", o = {
    ...dt(),
    ...t.defaults ?? {}
  }, i = new Set(t.explicitKeys ?? Object.keys(e)), n = Oe(e.defaultSource) ? e.defaultSource : {}, s = (U, Ne = a) => i.has(U) ? ce(n[U], Ne) : ce(o.defaultSource[U], "platform-default"), ie = l(e, "language") ? e.language : o.language, V = J(
    typeof ie == "string" ? ie : null
  );
  r.push(...V.diagnostics);
  const Ae = l(e, "height") ? e.height : o.height, H = ge(
    Ae,
    o.height,
    "attrs.height",
    r
  ), ze = l(e, "heightMode") ? e.heightMode : o.heightMode;
  let N = I(
    ze,
    mt,
    o.heightMode,
    "attrs.heightMode",
    r
  );
  H !== null && !l(e, "heightMode") && (N = "fixed"), N === "fixed" && H === null && (m(r, {
    code: "codeBlock.attr.invalid",
    severity: "warning",
    path: "attrs.heightMode",
    message: "Fixed height mode requires a valid height; max mode was used."
  }), N = "max");
  const se = {
    contractVersion: ae,
    language: V.id,
    detectedLanguage: G(
      l(e, "detectedLanguage") ? e.detectedLanguage : o.detectedLanguage
    ),
    filename: K(
      l(e, "filename") ? e.filename : o.filename
    ),
    caption: K(
      l(e, "caption") ? e.caption : o.caption
    ),
    showLineNumbers: pe(
      l(e, "showLineNumbers") ? e.showLineNumbers : o.showLineNumbers,
      o.showLineNumbers,
      "attrs.showLineNumbers",
      r
    ),
    startLine: yt(
      l(e, "startLine") ? e.startLine : o.startLine,
      o.startLine,
      "attrs.startLine",
      r,
      { nullable: !1 }
    ),
    wrap: I(
      l(e, "wrap") ? e.wrap : o.wrap,
      ut,
      o.wrap,
      "attrs.wrap",
      r
    ),
    collapsed: pe(
      l(e, "collapsed") ? e.collapsed : o.collapsed,
      o.collapsed,
      "attrs.collapsed",
      r
    ),
    previewLines: ge(
      l(e, "previewLines") ? e.previewLines : o.previewLines,
      o.previewLines,
      "attrs.previewLines",
      r
    ),
    heightMode: N,
    height: H,
    theme: G(l(e, "theme") ? e.theme : o.theme),
    highlightLines: bt(
      l(e, "highlightLines") ? e.highlightLines : o.highlightLines,
      r
    ),
    copyMode: I(
      l(e, "copyMode") ? e.copyMode : o.copyMode,
      ft,
      o.copyMode,
      "attrs.copyMode",
      r
    ),
    variant: I(
      l(e, "variant") ? e.variant : o.variant,
      ht,
      o.variant,
      "attrs.variant",
      r
    ),
    groupId: G(
      l(e, "groupId") ? e.groupId : o.groupId
    ),
    tabLabel: K(
      l(e, "tabLabel") ? e.tabLabel : o.tabLabel
    ),
    defaultSource: {}
  };
  return se.defaultSource = {
    contractVersion: "platform-default",
    language: s("language", V.source === "fallback" ? "platform-default" : a),
    detectedLanguage: s("detectedLanguage"),
    filename: s("filename"),
    caption: s("caption"),
    showLineNumbers: s("showLineNumbers"),
    startLine: s("startLine"),
    wrap: s("wrap"),
    collapsed: s("collapsed"),
    previewLines: s("previewLines"),
    heightMode: s("heightMode"),
    height: s("height"),
    theme: s("theme"),
    highlightLines: s("highlightLines"),
    copyMode: s("copyMode"),
    variant: s("variant"),
    groupId: s("groupId"),
    tabLabel: s("tabLabel")
  }, { attrs: se, diagnostics: r };
}, Lt = (e) => e.replace(/\r\n/g, `
`).replace(/\r/g, `
`), St = (e, t) => {
  const r = Lt(e), a = r === "" ? [""] : r.split(`
`), o = a.length, i = Array.from(
    { length: o },
    (n, s) => t + s
  );
  return {
    normalizedText: r,
    visualLines: a,
    visualLineCount: o,
    lineNumbers: i
  };
}, Pt = (e, t) => e === null ? t : Math.min(Math.max(e, 1), t), vt = (e) => e.filename || e.tabLabel || e.language || "Code", kt = (e) => {
  const t = wt(e.attrs, {
    defaults: e.defaults
  }), r = t.attrs, o = (e.highlighter ?? gt()()).normalizeLanguage(r.language), i = St(e.code, r.startLine), n = Pt(r.previewLines, i.visualLineCount);
  return {
    attrs: r,
    language: o,
    lines: i,
    display: {
      showLineNumbers: r.showLineNumbers,
      wrap: r.wrap,
      collapsed: r.collapsed,
      previewFrom: 1,
      previewTo: n,
      heightMode: r.heightMode,
      height: r.height
    },
    copy: {
      mode: r.copyMode,
      text: e.code
    },
    summary: {
      label: vt(r),
      lineCount: i.visualLineCount
    },
    diagnostics: [...t.diagnostics, ...o.diagnostics]
  };
}, xt = "text-editor.code-block-descriptor/v2", Et = (e) => e.lines.visualLines.slice(0, e.display.previewTo).join(`
`), ue = (e, t, r) => ({
  code: e,
  severity: "info",
  path: t,
  message: r
}), Ct = (e) => {
  var o;
  const t = kt(e), r = [...t.diagnostics], a = (o = e.highlighter) == null ? void 0 : o.getThemeSupport(t.attrs.theme);
  return t.attrs.copyMode === "markdown" && r.push(
    ue(
      "codeBlock.delivery.partial",
      "attrs.copyMode",
      "copyMode markdown is preserved in the descriptor but plain text remains the stable copy payload."
    )
  ), t.attrs.theme && (a == null ? void 0 : a.supported) === !1 && r.push(
    ue(
      "codeBlock.delivery.partial",
      "attrs.theme",
      a.reason ?? "Theme support is partial for this delivery surface."
    )
  ), {
    version: xt,
    nodeType: "codeBlock",
    attrs: t.attrs,
    code: e.code,
    language: t.language,
    displayLabel: t.summary.label,
    display: {
      filename: t.attrs.filename,
      caption: t.attrs.caption,
      showLineNumbers: t.display.showLineNumbers,
      startLine: t.attrs.startLine,
      wrap: t.display.wrap,
      collapsed: t.display.collapsed,
      previewFrom: t.display.previewFrom,
      previewTo: t.display.previewTo,
      heightMode: t.display.heightMode,
      height: t.display.height,
      highlightLines: t.attrs.highlightLines,
      theme: t.attrs.theme
    },
    lines: t.lines,
    copy: t.copy,
    summary: {
      text: e.code,
      previewText: Et(t),
      lineCount: t.summary.lineCount
    },
    capabilities: {
      highlight: t.language.supported === !1 ? "unsupported" : "partial",
      markdownMeta: "supported",
      binaryExport: r.some(
        (i) => i.code === "codeBlock.delivery.partial"
      ) ? "partial" : "supported"
    },
    diagnostics: r
  };
}, rr = [
  "public-read-page",
  "ssr-fragment-html",
  "ssr-fragment-react",
  "markdown-serializer",
  "markdown-parser",
  "html-serializer",
  "html-parser",
  "search-record",
  "excerpt-summary",
  "pdf-composition",
  "docx-composition"
], ar = [
  "code",
  "language",
  "display",
  "lines",
  "copy",
  "summary",
  "capabilities",
  "diagnostics"
], or = [
  "codeBlock.delivery.contractRepairRequired",
  "codeBlock.delivery.fieldPartial",
  "codeBlock.delivery.fieldUnsupported",
  "codeBlock.delivery.securityRedacted",
  "codeBlock.delivery.legacyFallbackForbidden",
  "codeBlock.delivery.htmlFirstForbidden"
], d = {
  code: "supported",
  language: "supported",
  display: "supported",
  lines: "supported",
  copy: "supported",
  summary: "supported",
  capabilities: "supported",
  diagnostics: "supported"
}, _t = {
  "public-read-page": {
    ...d,
    summary: "partial"
  },
  "ssr-fragment-html": {
    ...d,
    summary: "partial"
  },
  "ssr-fragment-react": {
    ...d,
    summary: "partial"
  },
  "markdown-serializer": {
    ...d,
    language: "partial",
    lines: "partial",
    copy: "partial",
    summary: "not-emitted"
  },
  "markdown-parser": {
    ...d,
    language: "partial"
  },
  "html-serializer": {
    ...d,
    lines: "partial",
    copy: "not-emitted",
    summary: "not-emitted"
  },
  "html-parser": d,
  "search-record": {
    ...d,
    language: "not-emitted",
    display: "not-emitted",
    lines: "not-emitted",
    copy: "not-emitted"
  },
  "excerpt-summary": {
    ...d,
    code: "partial",
    language: "not-emitted",
    display: "not-emitted",
    lines: "not-emitted",
    copy: "not-emitted"
  },
  "pdf-composition": {
    ...d,
    display: "partial",
    lines: "partial",
    copy: "partial",
    summary: "partial"
  },
  "docx-composition": {
    ...d,
    display: "partial",
    lines: "partial",
    copy: "partial",
    summary: "partial"
  }
}, B = (e) => typeof e == "object" && e !== null, me = (e, t) => B(e[t]), X = (e, t) => typeof e[t] == "string", Te = (e) => typeof e.text == "string" ? e.text : e.type === "hardBreak" ? `
` : (e.content ?? []).map(Te).join(""), Bt = (e) => {
  if (typeof e == "object" && e !== null && "toJSON" in e && typeof e.toJSON == "function")
    return e.toJSON();
  if (!B(e))
    return {};
  const t = B(e.type) ? typeof e.type.name == "string" ? e.type.name : void 0 : typeof e.type == "string" ? e.type : void 0, r = Array.isArray(e.content) ? e.content : typeof e.textContent == "string" ? [
    {
      type: "text",
      text: e.textContent
    }
  ] : void 0;
  return {
    ...t ? { type: t } : {},
    ...B(e.attrs) ? { attrs: e.attrs } : {},
    ...typeof e.text == "string" ? { text: e.text } : {},
    ...r ? { content: r } : {}
  };
}, T = (e, t, r, a) => ({
  code: e,
  severity: t,
  path: r,
  message: a
}), w = (e, t) => T(
  "codeBlock.delivery.contractRepairRequired",
  "error",
  e,
  t
), M = (e, t) => {
  t.forEach(
    (r) => m(e, r)
  );
}, ir = (e) => {
  const t = Bt(e);
  return Ct({
    code: Te(t),
    attrs: B(t.attrs) ? t.attrs : {}
  });
}, Mt = (e) => {
  const t = [];
  return B(e) ? (X(e, "version") || t.push(
    w(
      "descriptor.version",
      "Code block descriptor version is required."
    )
  ), e.nodeType !== "codeBlock" && t.push(
    w(
      "descriptor.nodeType",
      'Code block descriptor nodeType must be "codeBlock".'
    )
  ), X(e, "code") || t.push(
    w(
      "descriptor.code",
      "Descriptor code text is required."
    )
  ), (!me(e, "language") || !X(e, "displayLabel")) && t.push(
    w(
      "descriptor.language",
      "Descriptor language and displayLabel fields are required."
    )
  ), [
    "display",
    "lines",
    "copy",
    "summary",
    "capabilities"
  ].forEach((a) => {
    me(e, a) || t.push(
      w(
        `descriptor.${a}`,
        `Descriptor field group "${a}" is required.`
      )
    );
  }), Array.isArray(e.diagnostics) || t.push(
    w(
      "descriptor.diagnostics",
      "Descriptor diagnostics array is required."
    )
  ), {
    ok: t.every((a) => a.severity !== "error"),
    diagnostics: t
  }) : (t.push(
    w(
      "descriptor",
      "Code block delivery descriptor must be an object."
    )
  ), {
    ok: !1,
    diagnostics: t
  });
}, Ft = (e, t) => Object.entries(t).flatMap(([r, a]) => a !== "partial" && a !== "unsupported" ? [] : [
  T(
    a === "partial" ? "codeBlock.delivery.fieldPartial" : "codeBlock.delivery.fieldUnsupported",
    a === "partial" ? "warning" : "error",
    `${e}.${r}`,
    `Code block descriptor field group "${r}" is ${a} on "${e}".`
  )
]), oe = (e) => {
  const t = e.lines.visualLineCount, r = Math.max(e.display.previewFrom, 1), a = Math.min(
    Math.max(e.display.previewTo, r),
    t
  ), o = e.display.collapsed || a < t, i = o ? r - 1 : 0, n = o ? a : t;
  return {
    lines: e.lines.visualLines.slice(i, n),
    lineNumbers: e.lines.lineNumbers.slice(i, n),
    previewed: o,
    previewFrom: o ? r : 1,
    previewTo: o ? a : t,
    totalLineCount: t
  };
}, fe = (e) => {
  const t = Mt(e.descriptor), r = {
    ..._t[e.surface]
  }, a = [];
  return M(a, e.descriptor.diagnostics), M(a, t.diagnostics), M(
    a,
    Ft(e.surface, r)
  ), {
    surface: e.surface,
    descriptorVersion: e.descriptor.version,
    descriptor: e.descriptor,
    fieldSupport: r,
    diagnostics: a,
    code: e.descriptor.code,
    language: e.descriptor.language,
    displayLabel: e.descriptor.displayLabel,
    display: e.descriptor.display,
    lines: e.descriptor.lines,
    visibleLines: oe(e.descriptor),
    copy: e.descriptor.copy,
    summary: e.descriptor.summary,
    capabilities: e.descriptor.capabilities
  };
}, sr = (e) => e.summary.text || e.code, nr = (e) => e.summary.previewText || e.summary.text || e.code, Ot = (e) => {
  const t = [];
  return oe(e).previewed && t.push(
    T(
      "codeBlock.binary.interactionPartial",
      "warning",
      "display.collapsed",
      "Binary formats cannot preserve interactive collapsed or preview state; full code text remains in the composition plan."
    )
  ), (e.display.showLineNumbers || e.display.wrap !== "inherit" || e.display.highlightLines.length > 0 || e.display.theme) && t.push(
    T(
      "codeBlock.binary.lineModelPartial",
      "warning",
      "lines",
      "Binary lowering preserves code block line intent, while final wrapping/highlight layout is adapter-owned."
    )
  ), e.copy.mode !== "plain" && t.push(
    T(
      "codeBlock.binary.copyModeUnsupported",
      "warning",
      "copy.mode",
      "Binary formats keep full code text but do not preserve editor copyMode interaction."
    )
  ), t;
}, lr = (e) => {
  const t = fe({
    surface: "pdf-composition",
    descriptor: e
  }), r = fe({
    surface: "docx-composition",
    descriptor: e
  }), a = [];
  return M(a, t.diagnostics), M(a, r.diagnostics), M(
    a,
    Ot(e)
  ), {
    kind: "code-block",
    descriptorVersion: e.version,
    code: e.code,
    language: {
      id: e.language.id,
      displayLabel: e.displayLabel,
      supported: e.language.supported
    },
    title: {
      filename: e.display.filename,
      caption: e.display.caption
    },
    display: {
      showLineNumbers: e.display.showLineNumbers,
      startLine: e.display.startLine,
      wrap: e.display.wrap,
      collapsed: e.display.collapsed,
      previewFrom: e.display.previewFrom,
      previewTo: e.display.previewTo,
      previewed: oe(e).previewed,
      heightMode: e.display.heightMode,
      height: e.display.height,
      highlightLines: e.display.highlightLines,
      theme: e.display.theme
    },
    lines: e.lines,
    copy: e.copy,
    capabilities: e.capabilities,
    diagnostics: a,
    fieldSupport: {
      pdf: t.fieldSupport,
      docx: r.fieldSupport
    }
  };
};
export {
  Ze as $,
  It as A,
  Dt as B,
  Rt as C,
  Re as D,
  he as E,
  Ve as F,
  jt as G,
  y as H,
  Vt as I,
  A as J,
  g as K,
  ot as L,
  qt as M,
  Jt as N,
  Wt as O,
  Yt as P,
  nt as Q,
  Qt as R,
  $e as S,
  Ut as T,
  ne as U,
  W as V,
  Y as W,
  q as X,
  D as Y,
  ae as Z,
  Q as _,
  er as a,
  $t as a0,
  Zt as a1,
  Gt as a2,
  ke as a3,
  Ke as a4,
  P as a5,
  Kt as a6,
  Xt as a7,
  De as a8,
  At as a9,
  zt as aa,
  Nt as ab,
  h as ac,
  ye as ad,
  be as ae,
  c as af,
  k as ag,
  x as ah,
  we as ai,
  Ht as aj,
  C as ak,
  _ as al,
  Ie as am,
  Tt as an,
  dt as b,
  lt as c,
  tr as d,
  ct as e,
  Me as f,
  Fe as g,
  J as h,
  gt as i,
  Lt as j,
  kt as k,
  xt as l,
  Ct as m,
  wt as n,
  rr as o,
  m as p,
  ar as q,
  or as r,
  _t as s,
  ir as t,
  Mt as u,
  oe as v,
  fe as w,
  sr as x,
  nr as y,
  lr as z
};
//# sourceMappingURL=delivery-surfaces-BeupB41w.mjs.map
