var wn = Object.defineProperty;
var vn = (r, i, l) => i in r ? wn(r, i, { enumerable: !0, configurable: !0, writable: !0, value: l }) : r[i] = l;
var qe = (r, i, l) => vn(r, typeof i != "symbol" ? i + "" : i, l);
import { O as En, m as Cn, i as bt, e as mt, f as $t, c as Xe, g as qt, h as Rn, d as Sn, b as Tn, a as kn, s as ft } from "./error-Di1d9d9R.mjs";
import { g as Ue, n as An, z as xn, B as _t, C as On, D as Ln, E as Wt, F as Nn, G as In, H as Qe, I as Dn, J as Mn, K as Pn, M as Ot, L as Lt, N as jn, O as Fn, P as Un, a as Ht, y as dt, Q as wt, d as Ne, t as oe, R as Bn, S as Nt, T as $n, j as ie, k as vt, w as ae, b as Vt, e as He, c as qn, f as It, s as Wn, h as Hn, U as Yt, u as Vn, V as Yn, A as Gn, W as zn, r as Kn, X as Jn, x as Xn, q as Qn, v as Zn, p as er, Y as tr } from "./awareness-Do0nkEFk.mjs";
import { r as Et, a as nr } from "./promise-CnVnurMX.mjs";
import "yjs";
import { bN as de, bO as rr } from "./link-paste-handler-COpsSlXB.mjs";
const ir = 1200, sr = 2500, Ve = 3e4, pt = (r) => {
  if (r.shouldConnect && r.ws === null) {
    const i = new WebSocket(r.url), l = r.binaryType;
    let O = null;
    l && (i.binaryType = l), r.ws = i, r.connecting = !0, r.connected = !1, i.onmessage = (I) => {
      r.lastMessageReceived = Ue();
      const m = I.data, u = typeof m == "string" ? JSON.parse(m) : m;
      u && u.type === "pong" && (clearTimeout(O), O = setTimeout(_, Ve / 2)), r.emit("message", [u, r]);
    };
    const N = (I) => {
      r.ws !== null && (r.ws = null, r.connecting = !1, r.connected ? (r.connected = !1, r.emit("disconnect", [{ type: "disconnect", error: I }, r])) : r.unsuccessfulReconnects++, setTimeout(pt, An(xn(r.unsuccessfulReconnects + 1) * ir, sr), r)), clearTimeout(O);
    }, _ = () => {
      r.ws === i && r.send({
        type: "ping"
      });
    };
    i.onclose = () => N(null), i.onerror = (I) => N(I), i.onopen = () => {
      r.lastMessageReceived = Ue(), r.connecting = !1, r.connected = !0, r.unsuccessfulReconnects = 0, r.emit("connect", [{ type: "connect" }, r]), O = setTimeout(_, Ve / 2);
    };
  }
};
class or extends En {
  /**
   * @param {string} url
   * @param {object} opts
   * @param {'arraybuffer' | 'blob' | null} [opts.binaryType] Set `ws.binaryType`
   */
  constructor(i, { binaryType: l } = {}) {
    super(), this.url = i, this.ws = null, this.binaryType = l || null, this.connected = !1, this.connecting = !1, this.unsuccessfulReconnects = 0, this.lastMessageReceived = 0, this.shouldConnect = !0, this._checkInterval = setInterval(() => {
      this.connected && Ve < Ue() - this.lastMessageReceived && this.ws.close();
    }, Ve / 2), pt(this);
  }
  /**
   * @param {any} message
   */
  send(i) {
    this.ws && this.ws.send(JSON.stringify(i));
  }
  destroy() {
    clearInterval(this._checkInterval), this.disconnect(), super.destroy();
  }
  disconnect() {
    this.shouldConnect = !1, this.ws !== null && this.ws.close();
  }
  connect() {
    this.shouldConnect = !0, !this.connected && this.ws === null && pt(this);
  }
}
const ar = crypto.getRandomValues.bind(crypto), cr = Math.random, ur = () => ar(new Uint32Array(1))[0], lr = "10000000-1000-4000-8000" + -1e11, hr = () => lr.replace(
  /[018]/g,
  /** @param {number} c */
  (r) => (r ^ ur() & 15 >> r / 4).toString(16)
);
class fr {
  /**
   * @param {L} left
   * @param {R} right
   */
  constructor(i, l) {
    this.left = i, this.right = l;
  }
}
const pe = (r, i) => new fr(r, i), Dt = (r) => r.next() >= 0.5, ot = (r, i, l) => _t(r.next() * (l + 1 - i) + i), Gt = (r, i, l) => _t(r.next() * (l + 1 - i) + i), Ct = (r, i, l) => Gt(r, i, l), dr = (r) => On(Ct(r, 97, 122)), pr = (r, i = 0, l = 20) => {
  const O = Ct(r, i, l);
  let N = "";
  for (let _ = 0; _ < O; _++)
    N += dr(r);
  return N;
}, at = (r, i) => i[Ct(r, 0, i.length - 1)], gr = Symbol("0schema");
class yr {
  constructor() {
    this._rerrs = [];
  }
  /**
   * @param {string?} path
   * @param {string} expected
   * @param {string} has
   * @param {string?} message
   */
  extend(i, l, O, N = null) {
    this._rerrs.push({ path: i, expected: l, has: O, message: N });
  }
  toString() {
    const i = [];
    for (let l = this._rerrs.length - 1; l > 0; l--) {
      const O = this._rerrs[l];
      i.push(Mn(" ", (this._rerrs.length - l) * 2) + `${O.path != null ? `[${O.path}] ` : ""}${O.has} doesn't match ${O.expected}. ${O.message}`);
    }
    return i.join(`
`);
  }
}
const gt = (r, i) => r === i ? !0 : r == null || i == null || r.constructor !== i.constructor ? !1 : r[Wt] ? Nn(r, i) : bt(r) ? mt(
  r,
  (l) => $t(i, (O) => gt(l, O))
) : In(r) ? Qe(
  r,
  (l, O) => gt(l, i[O])
) : !1;
class ne {
  /**
   * @param {Schema<any>} other
   */
  extends(i) {
    let [l, O] = [
      /** @type {any} */
      this.shape,
      /** @type {any} */
      i.shape
    ];
    return (
      /** @type {typeof Schema<any>} */
      this.constructor._dilutes && ([O, l] = [l, O]), gt(l, O)
    );
  }
  /**
   * Overwrite this when necessary. By default, we only check the `shape` property which every shape
   * should have.
   * @param {Schema<any>} other
   */
  equals(i) {
    return this.constructor === i.constructor && Ln(this.shape, i.shape);
  }
  [gr]() {
    return !0;
  }
  /**
   * @param {object} other
   */
  [Wt](i) {
    return this.equals(
      /** @type {any} */
      i
    );
  }
  /**
   * Use `schema.validate(obj)` with a typed parameter that is already of typed to be an instance of
   * Schema. Validate will check the structure of the parameter and return true iff the instance
   * really is an instance of Schema.
   *
   * @param {T} o
   * @return {boolean}
   */
  validate(i) {
    return this.check(i);
  }
  /* c8 ignore start */
  /**
   * Similar to validate, but this method accepts untyped parameters.
   *
   * @param {any} _o
   * @param {ValidationError} [_err]
   * @return {_o is T}
   */
  check(i, l) {
    Cn();
  }
  /* c8 ignore stop */
  /**
   * @type {Schema<T?>}
   */
  get nullable() {
    return Me(this, rt);
  }
  /**
   * @type {$Optional<Schema<T>>}
   */
  get optional() {
    return new Jt(
      /** @type {Schema<T>} */
      this
    );
  }
  /**
   * Cast a variable to a specific type. Returns the casted value, or throws an exception otherwise.
   * Use this if you know that the type is of a specific type and you just want to convince the type
   * system.
   *
   * **Do not rely on these error messages!**
   * Performs an assertion check only if not in a production environment.
   *
   * @template OO
   * @param {OO} o
   * @return {Extract<OO, T> extends never ? T : (OO extends Array<never> ? T : Extract<OO,T>)}
   */
  cast(i) {
    return Mt(i, this), /** @type {any} */
    i;
  }
  /**
   * EXPECTO PATRONUM!! 🪄
   * This function protects against type errors. Though it may not work in the real world.
   *
   * "After all this time?"
   * "Always." - Snape, talking about type safety
   *
   * Ensures that a variable is a a specific type. Returns the value, or throws an exception if the assertion check failed.
   * Use this if you know that the type is of a specific type and you just want to convince the type
   * system.
   *
   * Can be useful when defining lambdas: `s.lambda(s.$number, s.$void).expect((n) => n + 1)`
   *
   * **Do not rely on these error messages!**
   * Performs an assertion check if not in a production environment.
   *
   * @param {T} o
   * @return {o extends T ? T : never}
   */
  expect(i) {
    return Mt(i, this), i;
  }
}
// this.shape must not be defined on Schema. Otherwise typecheck on metatypes (e.g. $$object) won't work as expected anymore
/**
 * If true, the more things are added to the shape the more objects this schema will accept (e.g.
 * union). By default, the more objects are added, the the fewer objects this schema will accept.
 * @protected
 */
qe(ne, "_dilutes", !1);
class Rt extends ne {
  /**
   * @param {C} c
   * @param {((o:Instance<C>)=>boolean)|null} check
   */
  constructor(i, l) {
    super(), this.shape = i, this._c = l;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is C extends ((...args:any[]) => infer T) ? T : (C extends (new (...args:any[]) => any) ? InstanceType<C> : never)} o
   */
  check(i, l = void 0) {
    const O = (i == null ? void 0 : i.constructor) === this.shape && (this._c == null || this._c(i));
    return !O && (l == null || l.extend(null, this.shape.name, i == null ? void 0 : i.constructor.name, (i == null ? void 0 : i.constructor) !== this.shape ? "Constructor match failed" : "Check failed")), O;
  }
}
const Q = (r, i = null) => new Rt(r, i);
Q(Rt);
class St extends ne {
  /**
   * @param {(o:any) => boolean} check
   */
  constructor(i) {
    super(), this.shape = i;
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is any}
   */
  check(i, l) {
    const O = this.shape(i);
    return !O && (l == null || l.extend(null, "custom prop", i == null ? void 0 : i.constructor.name, "failed to check custom prop")), O;
  }
}
const ee = (r) => new St(r);
Q(St);
class Ze extends ne {
  /**
   * @param {Array<T>} literals
   */
  constructor(i) {
    super(), this.shape = i;
  }
  /**
   *
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is T}
   */
  check(i, l) {
    const O = this.shape.some((N) => N === i);
    return !O && (l == null || l.extend(null, this.shape.join(" | "), i.toString())), O;
  }
}
const et = (...r) => new Ze(r), zt = Q(Ze), br = (
  /** @type {any} */
  RegExp.escape || /** @type {(str:string) => string} */
  ((r) => r.replace(/[().|&,$^[\]]/g, (i) => "\\" + i))
), Kt = (r) => {
  if (Ie.check(r))
    return [br(r)];
  if (zt.check(r))
    return (
      /** @type {Array<string|number>} */
      r.shape.map((i) => i + "")
    );
  if (on.check(r))
    return ["[+-]?\\d+.?\\d*"];
  if (an.check(r))
    return [".*"];
  if (Ge.check(r))
    return r.shape.map(Kt).flat(1);
  qt();
};
class mr extends ne {
  /**
   * @param {T} shape
   */
  constructor(i) {
    super(), this.shape = i, this._r = new RegExp("^" + i.map(Kt).map((l) => `(${l.join("|")})`).join("") + "$");
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is CastStringTemplateArgsToTemplate<T>}
   */
  check(i, l) {
    const O = this._r.exec(i) != null;
    return !O && (l == null || l.extend(null, this._r.toString(), i.toString(), "String doesn't match string template.")), O;
  }
}
Q(mr);
const _r = Symbol("optional");
class Jt extends ne {
  /**
   * @param {S} shape
   */
  constructor(i) {
    super(), this.shape = i;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is (Unwrap<S>|undefined)}
   */
  check(i, l) {
    const O = i === void 0 || this.shape.check(i);
    return !O && (l == null || l.extend(null, "undefined (optional)", "()")), O;
  }
  get [_r]() {
    return !0;
  }
}
const wr = Q(Jt);
class vr extends ne {
  /**
   * @param {any} _o
   * @param {ValidationError} [err]
   * @return {_o is never}
   */
  check(i, l) {
    return l == null || l.extend(null, "never", typeof i), !1;
  }
}
Q(vr);
const Je = class Je extends ne {
  /**
   * @param {S} shape
   * @param {boolean} partial
   */
  constructor(i, l = !1) {
    super(), this.shape = i, this._isPartial = l;
  }
  /**
   * @type {Schema<Partial<$ObjectToType<S>>>}
   */
  get partial() {
    return new Je(this.shape, !0);
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is $ObjectToType<S>}
   */
  check(i, l) {
    return i == null ? (l == null || l.extend(null, "object", "null"), !1) : Qe(this.shape, (O, N) => {
      const _ = this._isPartial && !Pn(i, N) || O.check(i[N], l);
      return !_ && (l == null || l.extend(N.toString(), O.toString(), typeof i[N], "Object property does not match")), _;
    });
  }
};
qe(Je, "_dilutes", !0);
let Ye = Je;
const Er = (r) => (
  /** @type {any} */
  new Ye(r)
), Cr = Q(Ye), Rr = ee((r) => r != null && (r.constructor === Object || r.constructor == null));
class Xt extends ne {
  /**
   * @param {Keys} keys
   * @param {Values} values
   */
  constructor(i, l) {
    super(), this.shape = {
      keys: i,
      values: l
    };
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is { [key in Unwrap<Keys>]: Unwrap<Values> }}
   */
  check(i, l) {
    return i != null && Qe(i, (O, N) => {
      const _ = this.shape.keys.check(N, l);
      return !_ && (l == null || l.extend(N + "", "Record", typeof i, _ ? "Key doesn't match schema" : "Value doesn't match value")), _ && this.shape.values.check(O, l);
    });
  }
}
const Qt = (r, i) => new Xt(r, i), Sr = Q(Xt);
class Zt extends ne {
  /**
   * @param {S} shape
   */
  constructor(i) {
    super(), this.shape = i;
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is { [K in keyof S]: S[K] extends Schema<infer Type> ? Type : never }}
   */
  check(i, l) {
    return i != null && Qe(this.shape, (O, N) => {
      const _ = (
        /** @type {Schema<any>} */
        O.check(i[N], l)
      );
      return !_ && (l == null || l.extend(N.toString(), "Tuple", typeof O)), _;
    });
  }
}
const Tr = (...r) => new Zt(r);
Q(Zt);
class en extends ne {
  /**
   * @param {Array<S>} v
   */
  constructor(i) {
    super(), this.shape = i.length === 1 ? i[0] : new tt(i);
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is Array<S extends Schema<infer T> ? T : never>} o
   */
  check(i, l) {
    const O = bt(i) && mt(i, (N) => this.shape.check(N));
    return !O && (l == null || l.extend(null, "Array", "")), O;
  }
}
const tn = (...r) => new en(r), kr = Q(en), Ar = ee((r) => bt(r));
class nn extends ne {
  /**
   * @param {new (...args:any) => T} constructor
   * @param {((o:T) => boolean)|null} check
   */
  constructor(i, l) {
    super(), this.shape = i, this._c = l;
  }
  /**
   * @param {any} o
   * @param {ValidationError} err
   * @return {o is T}
   */
  check(i, l) {
    const O = i instanceof this.shape && (this._c == null || this._c(i));
    return !O && (l == null || l.extend(null, this.shape.name, i == null ? void 0 : i.constructor.name)), O;
  }
}
const xr = (r, i = null) => new nn(r, i);
Q(nn);
const Or = xr(ne);
class Lr extends ne {
  /**
   * @param {Args} args
   */
  constructor(i) {
    super(), this.len = i.length - 1, this.args = Tr(...i.slice(-1)), this.res = i[this.len];
  }
  /**
   * @param {any} f
   * @param {ValidationError} err
   * @return {f is _LArgsToLambdaDef<Args>}
   */
  check(i, l) {
    const O = i.constructor === Function && i.length <= this.len;
    return !O && (l == null || l.extend(null, "function", typeof i)), O;
  }
}
const Nr = Q(Lr), Ir = ee((r) => typeof r == "function");
class Dr extends ne {
  /**
   * @param {T} v
   */
  constructor(i) {
    super(), this.shape = i;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is Intersect<UnwrapArray<T>>}
   */
  check(i, l) {
    const O = mt(this.shape, (N) => N.check(i, l));
    return !O && (l == null || l.extend(null, "Intersectinon", typeof i)), O;
  }
}
Q(Dr, (r) => r.shape.length > 0);
class tt extends ne {
  /**
   * @param {Array<Schema<S>>} v
   */
  constructor(i) {
    super(), this.shape = i;
  }
  /**
   * @param {any} o
   * @param {ValidationError} [err]
   * @return {o is S}
   */
  check(i, l) {
    const O = $t(this.shape, (N) => N.check(i, l));
    return l == null || l.extend(null, "Union", typeof i), O;
  }
}
qe(tt, "_dilutes", !0);
const Me = (...r) => r.findIndex((i) => Ge.check(i)) >= 0 ? Me(...r.map((i) => Be(i)).map((i) => Ge.check(i) ? i.shape : [i]).flat(1)) : r.length === 1 ? r[0] : new tt(r), Ge = (
  /** @type {Schema<$Union<any>>} */
  Q(tt)
), rn = () => !0, ze = ee(rn), Mr = (
  /** @type {Schema<Schema<any>>} */
  Q(St, (r) => r.shape === rn)
), Tt = ee((r) => typeof r == "bigint"), Pr = (
  /** @type {Schema<Schema<BigInt>>} */
  ee((r) => r === Tt)
), sn = ee((r) => typeof r == "symbol");
ee((r) => r === sn);
const Oe = ee((r) => typeof r == "number"), on = (
  /** @type {Schema<Schema<number>>} */
  ee((r) => r === Oe)
), Ie = ee((r) => typeof r == "string"), an = (
  /** @type {Schema<Schema<string>>} */
  ee((r) => r === Ie)
), nt = ee((r) => typeof r == "boolean"), jr = (
  /** @type {Schema<Schema<Boolean>>} */
  ee((r) => r === nt)
), cn = et(void 0);
Q(Ze, (r) => r.shape.length === 1 && r.shape[0] === void 0);
et(void 0);
const rt = et(null), Fr = (
  /** @type {Schema<Schema<null>>} */
  Q(Ze, (r) => r.shape.length === 1 && r.shape[0] === null)
);
Q(Uint8Array);
Q(Rt, (r) => r.shape === Uint8Array);
const Ur = Me(Oe, Ie, rt, cn, Tt, nt, sn);
(() => {
  const r = (
    /** @type {$Array<$any>} */
    tn(ze)
  ), i = (
    /** @type {$Record<$string,$any>} */
    Qt(Ie, ze)
  ), l = Me(Oe, Ie, rt, nt, r, i);
  return r.shape = l, i.shape.values = l, l;
})();
const Be = (r) => {
  if (Or.check(r))
    return (
      /** @type {any} */
      r
    );
  if (Rr.check(r)) {
    const i = {};
    for (const l in r)
      i[l] = Be(r[l]);
    return (
      /** @type {any} */
      Er(i)
    );
  } else {
    if (Ar.check(r))
      return (
        /** @type {any} */
        Me(...r.map(Be))
      );
    if (Ur.check(r))
      return (
        /** @type {any} */
        et(r)
      );
    if (Ir.check(r))
      return (
        /** @type {any} */
        Q(
          /** @type {any} */
          r
        )
      );
  }
  qt();
}, Mt = Dn ? () => {
} : (r, i) => {
  const l = new yr();
  if (!i.check(r, l))
    throw Xe(`Expected value to be of type ${i.constructor.name}.
${l.toString()}`);
};
class Br {
  /**
   * @param {Schema<State>} [$state]
   */
  constructor(i) {
    this.patterns = [], this.$state = i;
  }
  /**
   * @template P
   * @template R
   * @param {P} pattern
   * @param {(o:NoInfer<Unwrap<ReadSchema<P>>>,s:State)=>R} handler
   * @return {PatternMatcher<State,Patterns|Pattern<Unwrap<ReadSchema<P>>,R>>}
   */
  if(i, l) {
    return this.patterns.push({ if: Be(i), h: l }), this;
  }
  /**
   * @template R
   * @param {(o:any,s:State)=>R} h
   */
  else(i) {
    return this.if(ze, i);
  }
  /**
   * @return {State extends undefined
   *   ? <In extends Unwrap<Patterns['if']>>(o:In,state?:undefined)=>PatternMatchResult<Patterns,In>
   *   : <In extends Unwrap<Patterns['if']>>(o:In,state:State)=>PatternMatchResult<Patterns,In>}
   */
  done() {
    return (
      /** @type {any} */
      (i, l) => {
        for (let O = 0; O < this.patterns.length; O++) {
          const N = this.patterns[O];
          if (N.if.check(i))
            return N.h(i, l);
        }
        throw Xe("Unhandled pattern");
      }
    );
  }
}
const $r = (r) => new Br(
  /** @type {any} */
  r
), un = (
  /** @type {any} */
  $r(
    /** @type {Schema<prng.PRNG>} */
    ze
  ).if(on, (r, i) => ot(i, Lt, Ot)).if(an, (r, i) => pr(i)).if(jr, (r, i) => Dt(i)).if(Pr, (r, i) => BigInt(ot(i, Lt, Ot))).if(Ge, (r, i) => xe(i, at(i, r.shape))).if(Cr, (r, i) => {
    const l = {};
    for (const O in r.shape) {
      let N = r.shape[O];
      if (wr.check(N)) {
        if (Dt(i))
          continue;
        N = N.shape;
      }
      l[O] = un(N, i);
    }
    return l;
  }).if(kr, (r, i) => {
    const l = [], O = Gt(i, 0, 42);
    for (let N = 0; N < O; N++)
      l.push(xe(i, r.shape));
    return l;
  }).if(zt, (r, i) => at(i, r.shape)).if(Fr, (r, i) => null).if(Nr, (r, i) => {
    const l = xe(i, r.res);
    return () => l;
  }).if(Mr, (r, i) => xe(i, at(i, [
    Oe,
    Ie,
    rt,
    cn,
    Tt,
    nt,
    tn(Oe),
    Qt(Me("a", "b", "c"), Oe)
  ]))).if(Sr, (r, i) => {
    const l = {}, O = ot(i, 0, 3);
    for (let N = 0; N < O; N++) {
      const _ = xe(i, r.shape.keys), I = xe(i, r.shape.values);
      l[_] = I;
    }
    return l;
  }).done()
), xe = (r, i) => (
  /** @type {any} */
  un(Be(i), r)
), it = (
  /** @type {Document} */
  typeof document < "u" ? document : {}
);
ee((r) => r.nodeType === Yr);
typeof DOMParser < "u" && new DOMParser();
ee((r) => r.nodeType === Wr);
ee((r) => r.nodeType === Hr);
const qr = (r) => Rn(r, (i, l) => `${l}:${i};`).join(""), Wr = it.ELEMENT_NODE, Hr = it.TEXT_NODE, Vr = it.DOCUMENT_NODE, Yr = it.DOCUMENT_FRAGMENT_NODE;
ee((r) => r.nodeType === Vr);
const Gr = JSON.stringify, ge = Symbol, fe = ge(), De = ge(), ln = ge(), kt = ge(), hn = ge(), zr = ge(), fn = ge(), dn = ge(), st = ge(), Kr = (r) => {
  var N;
  r.length === 1 && ((N = r[0]) == null ? void 0 : N.constructor) === Function && (r = /** @type {Array<string|Symbol|Object|number>} */
  /** @type {[function]} */
  r[0]());
  const i = [], l = [];
  let O = 0;
  for (; O < r.length; O++) {
    const _ = r[O];
    if (_ === void 0)
      break;
    if (_.constructor === String || _.constructor === Number)
      i.push(_);
    else if (_.constructor === Object)
      break;
  }
  for (O > 0 && l.push(i.join("")); O < r.length; O++) {
    const _ = r[O];
    _ instanceof Symbol || l.push(_);
  }
  return l;
}, Pt = [hn, fn, dn, ln];
let ct = 0, jt = Ue();
const Jr = (r, i) => {
  const l = Pt[ct], O = jn("log"), N = O !== null && (O === "*" || O === "true" || new RegExp(O, "gi").test(i));
  return ct = (ct + 1) % Pt.length, i += ": ", N ? (..._) => {
    var u;
    _.length === 1 && ((u = _[0]) == null ? void 0 : u.constructor) === Function && (_ = _[0]());
    const I = Ue(), m = I - jt;
    jt = I, r(
      l,
      i,
      st,
      ..._.map((S) => {
        switch (S != null && S.constructor === Uint8Array && (S = Array.from(S)), typeof S) {
          case "string":
          case "symbol":
            return S;
          default:
            return Gr(S);
        }
      }),
      l,
      " +" + m + "ms"
    );
  } : Fn;
}, Xr = {
  [fe]: pe("font-weight", "bold"),
  [De]: pe("font-weight", "normal"),
  [ln]: pe("color", "blue"),
  [hn]: pe("color", "green"),
  [kt]: pe("color", "grey"),
  [zr]: pe("color", "red"),
  [fn]: pe("color", "purple"),
  [dn]: pe("color", "orange"),
  // not well supported in chrome when debugging node with inspector - TODO: deprecate
  [st]: pe("color", "black")
}, Qr = (r) => {
  var I;
  r.length === 1 && ((I = r[0]) == null ? void 0 : I.constructor) === Function && (r = /** @type {Array<string|Symbol|Object|number>} */
  /** @type {[function]} */
  r[0]());
  const i = [], l = [], O = Tn();
  let N = [], _ = 0;
  for (; _ < r.length; _++) {
    const m = r[_], u = Xr[m];
    if (u !== void 0)
      O.set(u.left, u.right);
    else {
      if (m === void 0)
        break;
      if (m.constructor === String || m.constructor === Number) {
        const S = qr(O);
        _ > 0 || S.length > 0 ? (i.push("%c" + m), l.push(S)) : i.push(m);
      } else
        break;
    }
  }
  for (_ > 0 && (N = l, N.unshift(i.join(""))); _ < r.length; _++) {
    const m = r[_];
    m instanceof Symbol || N.push(m);
  }
  return N;
}, Zr = Un ? Qr : Kr, ei = (...r) => {
  console.log(...Zr(r)), ti.forEach((i) => i.print(r));
}, ti = Sn(), ni = (r) => Jr(ei, r), ri = () => {
  let r = !0;
  return (i, l) => {
    if (r) {
      r = !1;
      try {
        i();
      } finally {
        r = !0;
      }
    } else l !== void 0 && l();
  };
};
function We(r) {
  throw new Error('Could not dynamically require "' + r + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.');
}
var ut = { exports: {} }, Ft;
function ii() {
  return Ft || (Ft = 1, (function(r, i) {
    (function(l) {
      r.exports = l();
    })(function() {
      var l = Math.floor, O = Math.abs, N = Math.pow;
      return (/* @__PURE__ */ (function() {
        function _(I, m, u) {
          function S(f, y) {
            if (!m[f]) {
              if (!I[f]) {
                var c = typeof We == "function" && We;
                if (!y && c) return c(f, !0);
                if (L) return L(f, !0);
                var w = new Error("Cannot find module '" + f + "'");
                throw w.code = "MODULE_NOT_FOUND", w;
              }
              var P = m[f] = { exports: {} };
              I[f][0].call(P.exports, function(k) {
                var D = I[f][1][k];
                return S(D || k);
              }, P, P.exports, _, I, m, u);
            }
            return m[f].exports;
          }
          for (var L = typeof We == "function" && We, s = 0; s < u.length; s++) S(u[s]);
          return S;
        }
        return _;
      })())({ 1: [function(_, I, m) {
        function u(h) {
          var d = h.length;
          if (0 < d % 4) throw new Error("Invalid string. Length must be a multiple of 4");
          var E = h.indexOf("=");
          E === -1 && (E = d);
          var g = E === d ? 0 : 4 - E % 4;
          return [E, g];
        }
        function S(h, d, E) {
          return 3 * (d + E) / 4 - E;
        }
        function L(h) {
          var d, E, g = u(h), T = g[0], M = g[1], b = new P(S(h, T, M)), C = 0, j = 0 < M ? T - 4 : T;
          for (E = 0; E < j; E += 4) d = w[h.charCodeAt(E)] << 18 | w[h.charCodeAt(E + 1)] << 12 | w[h.charCodeAt(E + 2)] << 6 | w[h.charCodeAt(E + 3)], b[C++] = 255 & d >> 16, b[C++] = 255 & d >> 8, b[C++] = 255 & d;
          return M === 2 && (d = w[h.charCodeAt(E)] << 2 | w[h.charCodeAt(E + 1)] >> 4, b[C++] = 255 & d), M === 1 && (d = w[h.charCodeAt(E)] << 10 | w[h.charCodeAt(E + 1)] << 4 | w[h.charCodeAt(E + 2)] >> 2, b[C++] = 255 & d >> 8, b[C++] = 255 & d), b;
        }
        function s(h) {
          return c[63 & h >> 18] + c[63 & h >> 12] + c[63 & h >> 6] + c[63 & h];
        }
        function f(h, d, E) {
          for (var g, T = [], M = d; M < E; M += 3) g = (16711680 & h[M] << 16) + (65280 & h[M + 1] << 8) + (255 & h[M + 2]), T.push(s(g));
          return T.join("");
        }
        function y(h) {
          for (var d, E = h.length, g = E % 3, T = [], M = 16383, b = 0, C = E - g; b < C; b += M) T.push(f(h, b, b + M > C ? C : b + M));
          return g === 1 ? (d = h[E - 1], T.push(c[d >> 2] + c[63 & d << 4] + "==")) : g === 2 && (d = (h[E - 2] << 8) + h[E - 1], T.push(c[d >> 10] + c[63 & d >> 4] + c[63 & d << 2] + "=")), T.join("");
        }
        m.byteLength = function(h) {
          var d = u(h), E = d[0], g = d[1];
          return 3 * (E + g) / 4 - g;
        }, m.toByteArray = L, m.fromByteArray = y;
        for (var c = [], w = [], P = typeof Uint8Array > "u" ? Array : Uint8Array, k = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", D = 0, o = k.length; D < o; ++D) c[D] = k[D], w[k.charCodeAt(D)] = D;
        w[45] = 62, w[95] = 63;
      }, {}], 2: [function() {
      }, {}], 3: [function(_, I, m) {
        (function() {
          (function() {
            var u = String.fromCharCode, S = Math.min;
            function L(e) {
              if (2147483647 < e) throw new RangeError('The value "' + e + '" is invalid for option "size"');
              var t = new Uint8Array(e);
              return t.__proto__ = s.prototype, t;
            }
            function s(e, t, n) {
              if (typeof e == "number") {
                if (typeof t == "string") throw new TypeError('The "string" argument must be of type string. Received type number');
                return w(e);
              }
              return f(e, t, n);
            }
            function f(e, t, n) {
              if (typeof e == "string") return P(e, t);
              if (ArrayBuffer.isView(e)) return k(e);
              if (e == null) throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
              if (R(e, ArrayBuffer) || e && R(e.buffer, ArrayBuffer)) return D(e, t, n);
              if (typeof e == "number") throw new TypeError('The "value" argument must not be of type number. Received type number');
              var p = e.valueOf && e.valueOf();
              if (p != null && p !== e) return s.from(p, t, n);
              var v = o(e);
              if (v) return v;
              if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof e[Symbol.toPrimitive] == "function") return s.from(e[Symbol.toPrimitive]("string"), t, n);
              throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
            }
            function y(e) {
              if (typeof e != "number") throw new TypeError('"size" argument must be of type number');
              if (0 > e) throw new RangeError('The value "' + e + '" is invalid for option "size"');
            }
            function c(e, t, n) {
              return y(e), 0 >= e || t === void 0 ? L(e) : typeof n == "string" ? L(e).fill(t, n) : L(e).fill(t);
            }
            function w(e) {
              return y(e), L(0 > e ? 0 : 0 | h(e));
            }
            function P(e, t) {
              if ((typeof t != "string" || t === "") && (t = "utf8"), !s.isEncoding(t)) throw new TypeError("Unknown encoding: " + t);
              var n = 0 | d(e, t), p = L(n), v = p.write(e, t);
              return v !== n && (p = p.slice(0, v)), p;
            }
            function k(e) {
              for (var t = 0 > e.length ? 0 : 0 | h(e.length), n = L(t), p = 0; p < t; p += 1) n[p] = 255 & e[p];
              return n;
            }
            function D(e, t, n) {
              if (0 > t || e.byteLength < t) throw new RangeError('"offset" is outside of buffer bounds');
              if (e.byteLength < t + (n || 0)) throw new RangeError('"length" is outside of buffer bounds');
              var p;
              return p = t === void 0 && n === void 0 ? new Uint8Array(e) : n === void 0 ? new Uint8Array(e, t) : new Uint8Array(e, t, n), p.__proto__ = s.prototype, p;
            }
            function o(e) {
              if (s.isBuffer(e)) {
                var t = 0 | h(e.length), n = L(t);
                return n.length === 0 || e.copy(n, 0, 0, t), n;
              }
              return e.length === void 0 ? e.type === "Buffer" && Array.isArray(e.data) ? k(e.data) : void 0 : typeof e.length != "number" || A(e.length) ? L(0) : k(e);
            }
            function h(e) {
              if (e >= 2147483647) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x7fffffff bytes");
              return 0 | e;
            }
            function d(e, t) {
              if (s.isBuffer(e)) return e.length;
              if (ArrayBuffer.isView(e) || R(e, ArrayBuffer)) return e.byteLength;
              if (typeof e != "string") throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof e);
              var n = e.length, p = 2 < arguments.length && arguments[2] === !0;
              if (!p && n === 0) return 0;
              for (var v = !1; ; ) switch (t) {
                case "ascii":
                case "latin1":
                case "binary":
                  return n;
                case "utf8":
                case "utf-8":
                  return Ee(e).length;
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return 2 * n;
                case "hex":
                  return n >>> 1;
                case "base64":
                  return le(e).length;
                default:
                  if (v) return p ? -1 : Ee(e).length;
                  t = ("" + t).toLowerCase(), v = !0;
              }
            }
            function E(e, t, n) {
              var p = !1;
              if ((t === void 0 || 0 > t) && (t = 0), t > this.length || ((n === void 0 || n > this.length) && (n = this.length), 0 >= n) || (n >>>= 0, t >>>= 0, n <= t)) return "";
              for (e || (e = "utf8"); ; ) switch (e) {
                case "hex":
                  return ce(this, t, n);
                case "utf8":
                case "utf-8":
                  return Z(this, t, n);
                case "ascii":
                  return q(this, t, n);
                case "latin1":
                case "binary":
                  return Se(this, t, n);
                case "base64":
                  return z(this, t, n);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return ye(this, t, n);
                default:
                  if (p) throw new TypeError("Unknown encoding: " + e);
                  e = (e + "").toLowerCase(), p = !0;
              }
            }
            function g(e, t, n) {
              var p = e[t];
              e[t] = e[n], e[n] = p;
            }
            function T(e, t, n, p, v) {
              if (e.length === 0) return -1;
              if (typeof n == "string" ? (p = n, n = 0) : 2147483647 < n ? n = 2147483647 : -2147483648 > n && (n = -2147483648), n = +n, A(n) && (n = v ? 0 : e.length - 1), 0 > n && (n = e.length + n), n >= e.length) {
                if (v) return -1;
                n = e.length - 1;
              } else if (0 > n) if (v) n = 0;
              else return -1;
              if (typeof t == "string" && (t = s.from(t, p)), s.isBuffer(t)) return t.length === 0 ? -1 : M(e, t, n, p, v);
              if (typeof t == "number") return t &= 255, typeof Uint8Array.prototype.indexOf == "function" ? v ? Uint8Array.prototype.indexOf.call(e, t, n) : Uint8Array.prototype.lastIndexOf.call(e, t, n) : M(e, [t], n, p, v);
              throw new TypeError("val must be string, number or Buffer");
            }
            function M(e, t, n, p, v) {
              function x(Te, Fe) {
                return B === 1 ? Te[Fe] : Te.readUInt16BE(Fe * B);
              }
              var B = 1, Y = e.length, J = t.length;
              if (p !== void 0 && (p = (p + "").toLowerCase(), p === "ucs2" || p === "ucs-2" || p === "utf16le" || p === "utf-16le")) {
                if (2 > e.length || 2 > t.length) return -1;
                B = 2, Y /= 2, J /= 2, n /= 2;
              }
              var G;
              if (v) {
                var V = -1;
                for (G = n; G < Y; G++) if (x(e, G) !== x(t, V === -1 ? 0 : G - V)) V !== -1 && (G -= G - V), V = -1;
                else if (V === -1 && (V = G), G - V + 1 === J) return V * B;
              } else for (n + J > Y && (n = Y - J), G = n; 0 <= G; G--) {
                for (var te = !0, Ce = 0; Ce < J; Ce++) if (x(e, G + Ce) !== x(t, Ce)) {
                  te = !1;
                  break;
                }
                if (te) return G;
              }
              return -1;
            }
            function b(e, t, n, p) {
              n = +n || 0;
              var v = e.length - n;
              p ? (p = +p, p > v && (p = v)) : p = v;
              var x = t.length;
              p > x / 2 && (p = x / 2);
              for (var B, Y = 0; Y < p; ++Y) {
                if (B = parseInt(t.substr(2 * Y, 2), 16), A(B)) return Y;
                e[n + Y] = B;
              }
              return Y;
            }
            function C(e, t, n, p) {
              return he(Ee(t, e.length - n), e, n, p);
            }
            function j(e, t, n, p) {
              return he(je(t), e, n, p);
            }
            function U(e, t, n, p) {
              return j(e, t, n, p);
            }
            function W(e, t, n, p) {
              return he(le(t), e, n, p);
            }
            function H(e, t, n, p) {
              return he(_e(t, e.length - n), e, n, p);
            }
            function z(e, t, n) {
              return t === 0 && n === e.length ? F.fromByteArray(e) : F.fromByteArray(e.slice(t, n));
            }
            function Z(e, t, n) {
              n = S(e.length, n);
              for (var p = [], v = t; v < n; ) {
                var x = e[v], B = null, Y = 239 < x ? 4 : 223 < x ? 3 : 191 < x ? 2 : 1;
                if (v + Y <= n) {
                  var J, G, V, te;
                  Y === 1 ? 128 > x && (B = x) : Y === 2 ? (J = e[v + 1], (192 & J) == 128 && (te = (31 & x) << 6 | 63 & J, 127 < te && (B = te))) : Y === 3 ? (J = e[v + 1], G = e[v + 2], (192 & J) == 128 && (192 & G) == 128 && (te = (15 & x) << 12 | (63 & J) << 6 | 63 & G, 2047 < te && (55296 > te || 57343 < te) && (B = te))) : Y === 4 && (J = e[v + 1], G = e[v + 2], V = e[v + 3], (192 & J) == 128 && (192 & G) == 128 && (192 & V) == 128 && (te = (15 & x) << 18 | (63 & J) << 12 | (63 & G) << 6 | 63 & V, 65535 < te && 1114112 > te && (B = te)));
                }
                B === null ? (B = 65533, Y = 1) : 65535 < B && (B -= 65536, p.push(55296 | 1023 & B >>> 10), B = 56320 | 1023 & B), p.push(B), v += Y;
              }
              return re(p);
            }
            function re(e) {
              var t = e.length;
              if (t <= 4096) return u.apply(String, e);
              for (var n = "", p = 0; p < t; ) n += u.apply(String, e.slice(p, p += 4096));
              return n;
            }
            function q(e, t, n) {
              var p = "";
              n = S(e.length, n);
              for (var v = t; v < n; ++v) p += u(127 & e[v]);
              return p;
            }
            function Se(e, t, n) {
              var p = "";
              n = S(e.length, n);
              for (var v = t; v < n; ++v) p += u(e[v]);
              return p;
            }
            function ce(e, t, n) {
              var p = e.length;
              (!t || 0 > t) && (t = 0), (!n || 0 > n || n > p) && (n = p);
              for (var v = "", x = t; x < n; ++x) v += ve(e[x]);
              return v;
            }
            function ye(e, t, n) {
              for (var p = e.slice(t, n), v = "", x = 0; x < p.length; x += 2) v += u(p[x] + 256 * p[x + 1]);
              return v;
            }
            function X(e, t, n) {
              if (e % 1 != 0 || 0 > e) throw new RangeError("offset is not uint");
              if (e + t > n) throw new RangeError("Trying to access beyond buffer length");
            }
            function K(e, t, n, p, v, x) {
              if (!s.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
              if (t > v || t < x) throw new RangeError('"value" argument is out of bounds');
              if (n + p > e.length) throw new RangeError("Index out of range");
            }
            function ue(e, t, n, p) {
              if (n + p > e.length) throw new RangeError("Index out of range");
              if (0 > n) throw new RangeError("Index out of range");
            }
            function be(e, t, n, p, v) {
              return t = +t, n >>>= 0, v || ue(e, t, n, 4), $.write(e, t, n, p, 23, 4), n + 4;
            }
            function me(e, t, n, p, v) {
              return t = +t, n >>>= 0, v || ue(e, t, n, 8), $.write(e, t, n, p, 52, 8), n + 8;
            }
            function Pe(e) {
              if (e = e.split("=")[0], e = e.trim().replace(a, ""), 2 > e.length) return "";
              for (; e.length % 4 != 0; ) e += "=";
              return e;
            }
            function ve(e) {
              return 16 > e ? "0" + e.toString(16) : e.toString(16);
            }
            function Ee(e, t) {
              t = t || 1 / 0;
              for (var n, p = e.length, v = null, x = [], B = 0; B < p; ++B) {
                if (n = e.charCodeAt(B), 55295 < n && 57344 > n) {
                  if (!v) {
                    if (56319 < n) {
                      -1 < (t -= 3) && x.push(239, 191, 189);
                      continue;
                    } else if (B + 1 === p) {
                      -1 < (t -= 3) && x.push(239, 191, 189);
                      continue;
                    }
                    v = n;
                    continue;
                  }
                  if (56320 > n) {
                    -1 < (t -= 3) && x.push(239, 191, 189), v = n;
                    continue;
                  }
                  n = (v - 55296 << 10 | n - 56320) + 65536;
                } else v && -1 < (t -= 3) && x.push(239, 191, 189);
                if (v = null, 128 > n) {
                  if (0 > (t -= 1)) break;
                  x.push(n);
                } else if (2048 > n) {
                  if (0 > (t -= 2)) break;
                  x.push(192 | n >> 6, 128 | 63 & n);
                } else if (65536 > n) {
                  if (0 > (t -= 3)) break;
                  x.push(224 | n >> 12, 128 | 63 & n >> 6, 128 | 63 & n);
                } else if (1114112 > n) {
                  if (0 > (t -= 4)) break;
                  x.push(240 | n >> 18, 128 | 63 & n >> 12, 128 | 63 & n >> 6, 128 | 63 & n);
                } else throw new Error("Invalid code point");
              }
              return x;
            }
            function je(e) {
              for (var t = [], n = 0; n < e.length; ++n) t.push(255 & e.charCodeAt(n));
              return t;
            }
            function _e(e, t) {
              for (var n, p, v, x = [], B = 0; B < e.length && !(0 > (t -= 2)); ++B) n = e.charCodeAt(B), p = n >> 8, v = n % 256, x.push(v), x.push(p);
              return x;
            }
            function le(e) {
              return F.toByteArray(Pe(e));
            }
            function he(e, t, n, p) {
              for (var v = 0; v < p && !(v + n >= t.length || v >= e.length); ++v) t[v + n] = e[v];
              return v;
            }
            function R(e, t) {
              return e instanceof t || e != null && e.constructor != null && e.constructor.name != null && e.constructor.name === t.name;
            }
            function A(e) {
              return e !== e;
            }
            var F = _("base64-js"), $ = _("ieee754");
            m.Buffer = s, m.SlowBuffer = function(e) {
              return +e != e && (e = 0), s.alloc(+e);
            }, m.INSPECT_MAX_BYTES = 50, m.kMaxLength = 2147483647, s.TYPED_ARRAY_SUPPORT = (function() {
              try {
                var e = new Uint8Array(1);
                return e.__proto__ = { __proto__: Uint8Array.prototype, foo: function() {
                  return 42;
                } }, e.foo() === 42;
              } catch {
                return !1;
              }
            })(), s.TYPED_ARRAY_SUPPORT || typeof console > "u" || typeof console.error != "function" || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(s.prototype, "parent", { enumerable: !0, get: function() {
              return s.isBuffer(this) ? this.buffer : void 0;
            } }), Object.defineProperty(s.prototype, "offset", { enumerable: !0, get: function() {
              return s.isBuffer(this) ? this.byteOffset : void 0;
            } }), typeof Symbol < "u" && Symbol.species != null && s[Symbol.species] === s && Object.defineProperty(s, Symbol.species, { value: null, configurable: !0, enumerable: !1, writable: !1 }), s.poolSize = 8192, s.from = function(e, t, n) {
              return f(e, t, n);
            }, s.prototype.__proto__ = Uint8Array.prototype, s.__proto__ = Uint8Array, s.alloc = function(e, t, n) {
              return c(e, t, n);
            }, s.allocUnsafe = function(e) {
              return w(e);
            }, s.allocUnsafeSlow = function(e) {
              return w(e);
            }, s.isBuffer = function(e) {
              return e != null && e._isBuffer === !0 && e !== s.prototype;
            }, s.compare = function(e, t) {
              if (R(e, Uint8Array) && (e = s.from(e, e.offset, e.byteLength)), R(t, Uint8Array) && (t = s.from(t, t.offset, t.byteLength)), !s.isBuffer(e) || !s.isBuffer(t)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
              if (e === t) return 0;
              for (var n = e.length, p = t.length, v = 0, x = S(n, p); v < x; ++v) if (e[v] !== t[v]) {
                n = e[v], p = t[v];
                break;
              }
              return n < p ? -1 : p < n ? 1 : 0;
            }, s.isEncoding = function(e) {
              switch ((e + "").toLowerCase()) {
                case "hex":
                case "utf8":
                case "utf-8":
                case "ascii":
                case "latin1":
                case "binary":
                case "base64":
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return !0;
                default:
                  return !1;
              }
            }, s.concat = function(e, t) {
              if (!Array.isArray(e)) throw new TypeError('"list" argument must be an Array of Buffers');
              if (e.length === 0) return s.alloc(0);
              var n;
              if (t === void 0) for (t = 0, n = 0; n < e.length; ++n) t += e[n].length;
              var p = s.allocUnsafe(t), v = 0;
              for (n = 0; n < e.length; ++n) {
                var x = e[n];
                if (R(x, Uint8Array) && (x = s.from(x)), !s.isBuffer(x)) throw new TypeError('"list" argument must be an Array of Buffers');
                x.copy(p, v), v += x.length;
              }
              return p;
            }, s.byteLength = d, s.prototype._isBuffer = !0, s.prototype.swap16 = function() {
              var e = this.length;
              if (e % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
              for (var t = 0; t < e; t += 2) g(this, t, t + 1);
              return this;
            }, s.prototype.swap32 = function() {
              var e = this.length;
              if (e % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
              for (var t = 0; t < e; t += 4) g(this, t, t + 3), g(this, t + 1, t + 2);
              return this;
            }, s.prototype.swap64 = function() {
              var e = this.length;
              if (e % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
              for (var t = 0; t < e; t += 8) g(this, t, t + 7), g(this, t + 1, t + 6), g(this, t + 2, t + 5), g(this, t + 3, t + 4);
              return this;
            }, s.prototype.toString = function() {
              var e = this.length;
              return e === 0 ? "" : arguments.length === 0 ? Z(this, 0, e) : E.apply(this, arguments);
            }, s.prototype.toLocaleString = s.prototype.toString, s.prototype.equals = function(e) {
              if (!s.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
              return this === e || s.compare(this, e) === 0;
            }, s.prototype.inspect = function() {
              var e = "", t = m.INSPECT_MAX_BYTES;
              return e = this.toString("hex", 0, t).replace(/(.{2})/g, "$1 ").trim(), this.length > t && (e += " ... "), "<Buffer " + e + ">";
            }, s.prototype.compare = function(e, t, n, p, v) {
              if (R(e, Uint8Array) && (e = s.from(e, e.offset, e.byteLength)), !s.isBuffer(e)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof e);
              if (t === void 0 && (t = 0), n === void 0 && (n = e ? e.length : 0), p === void 0 && (p = 0), v === void 0 && (v = this.length), 0 > t || n > e.length || 0 > p || v > this.length) throw new RangeError("out of range index");
              if (p >= v && t >= n) return 0;
              if (p >= v) return -1;
              if (t >= n) return 1;
              if (t >>>= 0, n >>>= 0, p >>>= 0, v >>>= 0, this === e) return 0;
              for (var x = v - p, B = n - t, Y = S(x, B), J = this.slice(p, v), G = e.slice(t, n), V = 0; V < Y; ++V) if (J[V] !== G[V]) {
                x = J[V], B = G[V];
                break;
              }
              return x < B ? -1 : B < x ? 1 : 0;
            }, s.prototype.includes = function(e, t, n) {
              return this.indexOf(e, t, n) !== -1;
            }, s.prototype.indexOf = function(e, t, n) {
              return T(this, e, t, n, !0);
            }, s.prototype.lastIndexOf = function(e, t, n) {
              return T(this, e, t, n, !1);
            }, s.prototype.write = function(e, t, n, p) {
              if (t === void 0) p = "utf8", n = this.length, t = 0;
              else if (n === void 0 && typeof t == "string") p = t, n = this.length, t = 0;
              else if (isFinite(t)) t >>>= 0, isFinite(n) ? (n >>>= 0, p === void 0 && (p = "utf8")) : (p = n, n = void 0);
              else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
              var v = this.length - t;
              if ((n === void 0 || n > v) && (n = v), 0 < e.length && (0 > n || 0 > t) || t > this.length) throw new RangeError("Attempt to write outside buffer bounds");
              p || (p = "utf8");
              for (var x = !1; ; ) switch (p) {
                case "hex":
                  return b(this, e, t, n);
                case "utf8":
                case "utf-8":
                  return C(this, e, t, n);
                case "ascii":
                  return j(this, e, t, n);
                case "latin1":
                case "binary":
                  return U(this, e, t, n);
                case "base64":
                  return W(this, e, t, n);
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                  return H(this, e, t, n);
                default:
                  if (x) throw new TypeError("Unknown encoding: " + p);
                  p = ("" + p).toLowerCase(), x = !0;
              }
            }, s.prototype.toJSON = function() {
              return { type: "Buffer", data: Array.prototype.slice.call(this._arr || this, 0) };
            }, s.prototype.slice = function(e, t) {
              var n = this.length;
              e = ~~e, t = t === void 0 ? n : ~~t, 0 > e ? (e += n, 0 > e && (e = 0)) : e > n && (e = n), 0 > t ? (t += n, 0 > t && (t = 0)) : t > n && (t = n), t < e && (t = e);
              var p = this.subarray(e, t);
              return p.__proto__ = s.prototype, p;
            }, s.prototype.readUIntLE = function(e, t, n) {
              e >>>= 0, t >>>= 0, n || X(e, t, this.length);
              for (var p = this[e], v = 1, x = 0; ++x < t && (v *= 256); ) p += this[e + x] * v;
              return p;
            }, s.prototype.readUIntBE = function(e, t, n) {
              e >>>= 0, t >>>= 0, n || X(e, t, this.length);
              for (var p = this[e + --t], v = 1; 0 < t && (v *= 256); ) p += this[e + --t] * v;
              return p;
            }, s.prototype.readUInt8 = function(e, t) {
              return e >>>= 0, t || X(e, 1, this.length), this[e];
            }, s.prototype.readUInt16LE = function(e, t) {
              return e >>>= 0, t || X(e, 2, this.length), this[e] | this[e + 1] << 8;
            }, s.prototype.readUInt16BE = function(e, t) {
              return e >>>= 0, t || X(e, 2, this.length), this[e] << 8 | this[e + 1];
            }, s.prototype.readUInt32LE = function(e, t) {
              return e >>>= 0, t || X(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3];
            }, s.prototype.readUInt32BE = function(e, t) {
              return e >>>= 0, t || X(e, 4, this.length), 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
            }, s.prototype.readIntLE = function(e, t, n) {
              e >>>= 0, t >>>= 0, n || X(e, t, this.length);
              for (var p = this[e], v = 1, x = 0; ++x < t && (v *= 256); ) p += this[e + x] * v;
              return v *= 128, p >= v && (p -= N(2, 8 * t)), p;
            }, s.prototype.readIntBE = function(e, t, n) {
              e >>>= 0, t >>>= 0, n || X(e, t, this.length);
              for (var p = t, v = 1, x = this[e + --p]; 0 < p && (v *= 256); ) x += this[e + --p] * v;
              return v *= 128, x >= v && (x -= N(2, 8 * t)), x;
            }, s.prototype.readInt8 = function(e, t) {
              return e >>>= 0, t || X(e, 1, this.length), 128 & this[e] ? -1 * (255 - this[e] + 1) : this[e];
            }, s.prototype.readInt16LE = function(e, t) {
              e >>>= 0, t || X(e, 2, this.length);
              var n = this[e] | this[e + 1] << 8;
              return 32768 & n ? 4294901760 | n : n;
            }, s.prototype.readInt16BE = function(e, t) {
              e >>>= 0, t || X(e, 2, this.length);
              var n = this[e + 1] | this[e] << 8;
              return 32768 & n ? 4294901760 | n : n;
            }, s.prototype.readInt32LE = function(e, t) {
              return e >>>= 0, t || X(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
            }, s.prototype.readInt32BE = function(e, t) {
              return e >>>= 0, t || X(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
            }, s.prototype.readFloatLE = function(e, t) {
              return e >>>= 0, t || X(e, 4, this.length), $.read(this, e, !0, 23, 4);
            }, s.prototype.readFloatBE = function(e, t) {
              return e >>>= 0, t || X(e, 4, this.length), $.read(this, e, !1, 23, 4);
            }, s.prototype.readDoubleLE = function(e, t) {
              return e >>>= 0, t || X(e, 8, this.length), $.read(this, e, !0, 52, 8);
            }, s.prototype.readDoubleBE = function(e, t) {
              return e >>>= 0, t || X(e, 8, this.length), $.read(this, e, !1, 52, 8);
            }, s.prototype.writeUIntLE = function(e, t, n, p) {
              if (e = +e, t >>>= 0, n >>>= 0, !p) {
                var v = N(2, 8 * n) - 1;
                K(this, e, t, n, v, 0);
              }
              var x = 1, B = 0;
              for (this[t] = 255 & e; ++B < n && (x *= 256); ) this[t + B] = 255 & e / x;
              return t + n;
            }, s.prototype.writeUIntBE = function(e, t, n, p) {
              if (e = +e, t >>>= 0, n >>>= 0, !p) {
                var v = N(2, 8 * n) - 1;
                K(this, e, t, n, v, 0);
              }
              var x = n - 1, B = 1;
              for (this[t + x] = 255 & e; 0 <= --x && (B *= 256); ) this[t + x] = 255 & e / B;
              return t + n;
            }, s.prototype.writeUInt8 = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 1, 255, 0), this[t] = 255 & e, t + 1;
            }, s.prototype.writeUInt16LE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 2, 65535, 0), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2;
            }, s.prototype.writeUInt16BE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 2, 65535, 0), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2;
            }, s.prototype.writeUInt32LE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 4, 4294967295, 0), this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = 255 & e, t + 4;
            }, s.prototype.writeUInt32BE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 4, 4294967295, 0), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4;
            }, s.prototype.writeIntLE = function(e, t, n, p) {
              if (e = +e, t >>>= 0, !p) {
                var v = N(2, 8 * n - 1);
                K(this, e, t, n, v - 1, -v);
              }
              var x = 0, B = 1, Y = 0;
              for (this[t] = 255 & e; ++x < n && (B *= 256); ) 0 > e && Y === 0 && this[t + x - 1] !== 0 && (Y = 1), this[t + x] = 255 & (e / B >> 0) - Y;
              return t + n;
            }, s.prototype.writeIntBE = function(e, t, n, p) {
              if (e = +e, t >>>= 0, !p) {
                var v = N(2, 8 * n - 1);
                K(this, e, t, n, v - 1, -v);
              }
              var x = n - 1, B = 1, Y = 0;
              for (this[t + x] = 255 & e; 0 <= --x && (B *= 256); ) 0 > e && Y === 0 && this[t + x + 1] !== 0 && (Y = 1), this[t + x] = 255 & (e / B >> 0) - Y;
              return t + n;
            }, s.prototype.writeInt8 = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 1, 127, -128), 0 > e && (e = 255 + e + 1), this[t] = 255 & e, t + 1;
            }, s.prototype.writeInt16LE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 2, 32767, -32768), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2;
            }, s.prototype.writeInt16BE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 2, 32767, -32768), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2;
            }, s.prototype.writeInt32LE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 4, 2147483647, -2147483648), this[t] = 255 & e, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24, t + 4;
            }, s.prototype.writeInt32BE = function(e, t, n) {
              return e = +e, t >>>= 0, n || K(this, e, t, 4, 2147483647, -2147483648), 0 > e && (e = 4294967295 + e + 1), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4;
            }, s.prototype.writeFloatLE = function(e, t, n) {
              return be(this, e, t, !0, n);
            }, s.prototype.writeFloatBE = function(e, t, n) {
              return be(this, e, t, !1, n);
            }, s.prototype.writeDoubleLE = function(e, t, n) {
              return me(this, e, t, !0, n);
            }, s.prototype.writeDoubleBE = function(e, t, n) {
              return me(this, e, t, !1, n);
            }, s.prototype.copy = function(e, t, n, p) {
              if (!s.isBuffer(e)) throw new TypeError("argument should be a Buffer");
              if (n || (n = 0), p || p === 0 || (p = this.length), t >= e.length && (t = e.length), t || (t = 0), 0 < p && p < n && (p = n), p === n || e.length === 0 || this.length === 0) return 0;
              if (0 > t) throw new RangeError("targetStart out of bounds");
              if (0 > n || n >= this.length) throw new RangeError("Index out of range");
              if (0 > p) throw new RangeError("sourceEnd out of bounds");
              p > this.length && (p = this.length), e.length - t < p - n && (p = e.length - t + n);
              var v = p - n;
              if (this === e && typeof Uint8Array.prototype.copyWithin == "function") this.copyWithin(t, n, p);
              else if (this === e && n < t && t < p) for (var x = v - 1; 0 <= x; --x) e[x + t] = this[x + n];
              else Uint8Array.prototype.set.call(e, this.subarray(n, p), t);
              return v;
            }, s.prototype.fill = function(e, t, n, p) {
              if (typeof e == "string") {
                if (typeof t == "string" ? (p = t, t = 0, n = this.length) : typeof n == "string" && (p = n, n = this.length), p !== void 0 && typeof p != "string") throw new TypeError("encoding must be a string");
                if (typeof p == "string" && !s.isEncoding(p)) throw new TypeError("Unknown encoding: " + p);
                if (e.length === 1) {
                  var v = e.charCodeAt(0);
                  (p === "utf8" && 128 > v || p === "latin1") && (e = v);
                }
              } else typeof e == "number" && (e &= 255);
              if (0 > t || this.length < t || this.length < n) throw new RangeError("Out of range index");
              if (n <= t) return this;
              t >>>= 0, n = n === void 0 ? this.length : n >>> 0, e || (e = 0);
              var x;
              if (typeof e == "number") for (x = t; x < n; ++x) this[x] = e;
              else {
                var B = s.isBuffer(e) ? e : s.from(e, p), Y = B.length;
                if (Y === 0) throw new TypeError('The value "' + e + '" is invalid for argument "value"');
                for (x = 0; x < n - t; ++x) this[x + t] = B[x % Y];
              }
              return this;
            };
            var a = /[^+/0-9A-Za-z-_]/g;
          }).call(this);
        }).call(this, _("buffer").Buffer);
      }, { "base64-js": 1, buffer: 3, ieee754: 9 }], 4: [function(_, I, m) {
        (function(u) {
          (function() {
            function S() {
              let s;
              try {
                s = m.storage.getItem("debug");
              } catch {
              }
              return !s && typeof u < "u" && "env" in u && (s = u.env.DEBUG), s;
            }
            m.formatArgs = function(s) {
              if (s[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + s[0] + (this.useColors ? "%c " : " ") + "+" + I.exports.humanize(this.diff), !this.useColors) return;
              const f = "color: " + this.color;
              s.splice(1, 0, f, "color: inherit");
              let y = 0, c = 0;
              s[0].replace(/%[a-zA-Z%]/g, (w) => {
                w === "%%" || (y++, w === "%c" && (c = y));
              }), s.splice(c, 0, f);
            }, m.save = function(s) {
              try {
                s ? m.storage.setItem("debug", s) : m.storage.removeItem("debug");
              } catch {
              }
            }, m.load = S, m.useColors = function() {
              return !!(typeof window < "u" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) || !(typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) && (typeof document < "u" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || typeof window < "u" && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && 31 <= parseInt(RegExp.$1, 10) || typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/));
            }, m.storage = (function() {
              try {
                return localStorage;
              } catch {
              }
            })(), m.destroy = /* @__PURE__ */ (() => {
              let s = !1;
              return () => {
                s || (s = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
              };
            })(), m.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], m.log = console.debug || console.log || (() => {
            }), I.exports = _("./common")(m);
            const { formatters: L } = I.exports;
            L.j = function(s) {
              try {
                return JSON.stringify(s);
              } catch (f) {
                return "[UnexpectedJSONParseError]: " + f.message;
              }
            };
          }).call(this);
        }).call(this, _("_process"));
      }, { "./common": 5, _process: 12 }], 5: [function(_, I) {
        I.exports = function(m) {
          function u(s) {
            function f(...w) {
              if (!f.enabled) return;
              const P = f, k = +/* @__PURE__ */ new Date(), D = k - (y || k);
              P.diff = D, P.prev = y, P.curr = k, y = k, w[0] = u.coerce(w[0]), typeof w[0] != "string" && w.unshift("%O");
              let o = 0;
              w[0] = w[0].replace(/%([a-zA-Z%])/g, (d, E) => {
                if (d === "%%") return "%";
                o++;
                const g = u.formatters[E];
                if (typeof g == "function") {
                  const T = w[o];
                  d = g.call(P, T), w.splice(o, 1), o--;
                }
                return d;
              }), u.formatArgs.call(P, w), (P.log || u.log).apply(P, w);
            }
            let y, c = null;
            return f.namespace = s, f.useColors = u.useColors(), f.color = u.selectColor(s), f.extend = S, f.destroy = u.destroy, Object.defineProperty(f, "enabled", { enumerable: !0, configurable: !1, get: () => c === null ? u.enabled(s) : c, set: (w) => {
              c = w;
            } }), typeof u.init == "function" && u.init(f), f;
          }
          function S(s, f) {
            const y = u(this.namespace + (typeof f > "u" ? ":" : f) + s);
            return y.log = this.log, y;
          }
          function L(s) {
            return s.toString().substring(2, s.toString().length - 2).replace(/\.\*\?$/, "*");
          }
          return u.debug = u, u.default = u, u.coerce = function(s) {
            return s instanceof Error ? s.stack || s.message : s;
          }, u.disable = function() {
            const s = [...u.names.map(L), ...u.skips.map(L).map((f) => "-" + f)].join(",");
            return u.enable(""), s;
          }, u.enable = function(s) {
            u.save(s), u.names = [], u.skips = [];
            let f;
            const y = (typeof s == "string" ? s : "").split(/[\s,]+/), c = y.length;
            for (f = 0; f < c; f++) y[f] && (s = y[f].replace(/\*/g, ".*?"), s[0] === "-" ? u.skips.push(new RegExp("^" + s.substr(1) + "$")) : u.names.push(new RegExp("^" + s + "$")));
          }, u.enabled = function(s) {
            if (s[s.length - 1] === "*") return !0;
            let f, y;
            for (f = 0, y = u.skips.length; f < y; f++) if (u.skips[f].test(s)) return !1;
            for (f = 0, y = u.names.length; f < y; f++) if (u.names[f].test(s)) return !0;
            return !1;
          }, u.humanize = _("ms"), u.destroy = function() {
            console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
          }, Object.keys(m).forEach((s) => {
            u[s] = m[s];
          }), u.names = [], u.skips = [], u.formatters = {}, u.selectColor = function(s) {
            let f = 0;
            for (let y = 0; y < s.length; y++) f = (f << 5) - f + s.charCodeAt(y), f |= 0;
            return u.colors[O(f) % u.colors.length];
          }, u.enable(u.load()), u;
        };
      }, { ms: 11 }], 6: [function(_, I) {
        function m(u, S) {
          for (const L in S) Object.defineProperty(u, L, { value: S[L], enumerable: !0, configurable: !0 });
          return u;
        }
        I.exports = function(u, S, L) {
          if (!u || typeof u == "string") throw new TypeError("Please pass an Error to err-code");
          L || (L = {}), typeof S == "object" && (L = S, S = ""), S && (L.code = S);
          try {
            return m(u, L);
          } catch {
            L.message = u.message, L.stack = u.stack;
            const f = function() {
            };
            return f.prototype = Object.create(Object.getPrototypeOf(u)), m(new f(), L);
          }
        };
      }, {}], 7: [function(_, I) {
        function m(b) {
          console && console.warn && console.warn(b);
        }
        function u() {
          u.init.call(this);
        }
        function S(b) {
          if (typeof b != "function") throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof b);
        }
        function L(b) {
          return b._maxListeners === void 0 ? u.defaultMaxListeners : b._maxListeners;
        }
        function s(b, C, j, U) {
          var W, H, z;
          if (S(j), H = b._events, H === void 0 ? (H = b._events = /* @__PURE__ */ Object.create(null), b._eventsCount = 0) : (H.newListener !== void 0 && (b.emit("newListener", C, j.listener ? j.listener : j), H = b._events), z = H[C]), z === void 0) z = H[C] = j, ++b._eventsCount;
          else if (typeof z == "function" ? z = H[C] = U ? [j, z] : [z, j] : U ? z.unshift(j) : z.push(j), W = L(b), 0 < W && z.length > W && !z.warned) {
            z.warned = !0;
            var Z = new Error("Possible EventEmitter memory leak detected. " + z.length + " " + (C + " listeners added. Use emitter.setMaxListeners() to increase limit"));
            Z.name = "MaxListenersExceededWarning", Z.emitter = b, Z.type = C, Z.count = z.length, m(Z);
          }
          return b;
        }
        function f() {
          if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
        }
        function y(b, C, j) {
          var U = { fired: !1, wrapFn: void 0, target: b, type: C, listener: j }, W = f.bind(U);
          return W.listener = j, U.wrapFn = W, W;
        }
        function c(b, C, j) {
          var U = b._events;
          if (U === void 0) return [];
          var W = U[C];
          return W === void 0 ? [] : typeof W == "function" ? j ? [W.listener || W] : [W] : j ? D(W) : P(W, W.length);
        }
        function w(b) {
          var C = this._events;
          if (C !== void 0) {
            var j = C[b];
            if (typeof j == "function") return 1;
            if (j !== void 0) return j.length;
          }
          return 0;
        }
        function P(b, C) {
          for (var j = Array(C), U = 0; U < C; ++U) j[U] = b[U];
          return j;
        }
        function k(b, C) {
          for (; C + 1 < b.length; C++) b[C] = b[C + 1];
          b.pop();
        }
        function D(b) {
          for (var C = Array(b.length), j = 0; j < C.length; ++j) C[j] = b[j].listener || b[j];
          return C;
        }
        function o(b, C, j) {
          typeof b.on == "function" && h(b, "error", C, j);
        }
        function h(b, C, j, U) {
          if (typeof b.on == "function") U.once ? b.once(C, j) : b.on(C, j);
          else if (typeof b.addEventListener == "function") b.addEventListener(C, function W(H) {
            U.once && b.removeEventListener(C, W), j(H);
          });
          else throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof b);
        }
        var d, E = typeof Reflect == "object" ? Reflect : null, g = E && typeof E.apply == "function" ? E.apply : function(b, C, j) {
          return Function.prototype.apply.call(b, C, j);
        };
        d = E && typeof E.ownKeys == "function" ? E.ownKeys : Object.getOwnPropertySymbols ? function(b) {
          return Object.getOwnPropertyNames(b).concat(Object.getOwnPropertySymbols(b));
        } : function(b) {
          return Object.getOwnPropertyNames(b);
        };
        var T = Number.isNaN || function(b) {
          return b !== b;
        };
        I.exports = u, I.exports.once = function(b, C) {
          return new Promise(function(j, U) {
            function W(z) {
              b.removeListener(C, H), U(z);
            }
            function H() {
              typeof b.removeListener == "function" && b.removeListener("error", W), j([].slice.call(arguments));
            }
            h(b, C, H, { once: !0 }), C !== "error" && o(b, W, { once: !0 });
          });
        }, u.EventEmitter = u, u.prototype._events = void 0, u.prototype._eventsCount = 0, u.prototype._maxListeners = void 0;
        var M = 10;
        Object.defineProperty(u, "defaultMaxListeners", { enumerable: !0, get: function() {
          return M;
        }, set: function(b) {
          if (typeof b != "number" || 0 > b || T(b)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + b + ".");
          M = b;
        } }), u.init = function() {
          (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
        }, u.prototype.setMaxListeners = function(b) {
          if (typeof b != "number" || 0 > b || T(b)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + b + ".");
          return this._maxListeners = b, this;
        }, u.prototype.getMaxListeners = function() {
          return L(this);
        }, u.prototype.emit = function(b) {
          for (var C = [], j = 1; j < arguments.length; j++) C.push(arguments[j]);
          var U = b === "error", W = this._events;
          if (W !== void 0) U = U && W.error === void 0;
          else if (!U) return !1;
          if (U) {
            var H;
            if (0 < C.length && (H = C[0]), H instanceof Error) throw H;
            var z = new Error("Unhandled error." + (H ? " (" + H.message + ")" : ""));
            throw z.context = H, z;
          }
          var Z = W[b];
          if (Z === void 0) return !1;
          if (typeof Z == "function") g(Z, this, C);
          else for (var re = Z.length, q = P(Z, re), j = 0; j < re; ++j) g(q[j], this, C);
          return !0;
        }, u.prototype.addListener = function(b, C) {
          return s(this, b, C, !1);
        }, u.prototype.on = u.prototype.addListener, u.prototype.prependListener = function(b, C) {
          return s(this, b, C, !0);
        }, u.prototype.once = function(b, C) {
          return S(C), this.on(b, y(this, b, C)), this;
        }, u.prototype.prependOnceListener = function(b, C) {
          return S(C), this.prependListener(b, y(this, b, C)), this;
        }, u.prototype.removeListener = function(b, C) {
          var j, U, W, H, z;
          if (S(C), U = this._events, U === void 0) return this;
          if (j = U[b], j === void 0) return this;
          if (j === C || j.listener === C) --this._eventsCount == 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete U[b], U.removeListener && this.emit("removeListener", b, j.listener || C));
          else if (typeof j != "function") {
            for (W = -1, H = j.length - 1; 0 <= H; H--) if (j[H] === C || j[H].listener === C) {
              z = j[H].listener, W = H;
              break;
            }
            if (0 > W) return this;
            W === 0 ? j.shift() : k(j, W), j.length === 1 && (U[b] = j[0]), U.removeListener !== void 0 && this.emit("removeListener", b, z || C);
          }
          return this;
        }, u.prototype.off = u.prototype.removeListener, u.prototype.removeAllListeners = function(b) {
          var C, j, U;
          if (j = this._events, j === void 0) return this;
          if (j.removeListener === void 0) return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : j[b] !== void 0 && (--this._eventsCount == 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete j[b]), this;
          if (arguments.length === 0) {
            var W, H = Object.keys(j);
            for (U = 0; U < H.length; ++U) W = H[U], W !== "removeListener" && this.removeAllListeners(W);
            return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
          }
          if (C = j[b], typeof C == "function") this.removeListener(b, C);
          else if (C !== void 0) for (U = C.length - 1; 0 <= U; U--) this.removeListener(b, C[U]);
          return this;
        }, u.prototype.listeners = function(b) {
          return c(this, b, !0);
        }, u.prototype.rawListeners = function(b) {
          return c(this, b, !1);
        }, u.listenerCount = function(b, C) {
          return typeof b.listenerCount == "function" ? b.listenerCount(C) : w.call(b, C);
        }, u.prototype.listenerCount = w, u.prototype.eventNames = function() {
          return 0 < this._eventsCount ? d(this._events) : [];
        };
      }, {}], 8: [function(_, I) {
        I.exports = function() {
          if (typeof globalThis > "u") return null;
          var m = { RTCPeerConnection: globalThis.RTCPeerConnection || globalThis.mozRTCPeerConnection || globalThis.webkitRTCPeerConnection, RTCSessionDescription: globalThis.RTCSessionDescription || globalThis.mozRTCSessionDescription || globalThis.webkitRTCSessionDescription, RTCIceCandidate: globalThis.RTCIceCandidate || globalThis.mozRTCIceCandidate || globalThis.webkitRTCIceCandidate };
          return m.RTCPeerConnection ? m : null;
        };
      }, {}], 9: [function(_, I, m) {
        /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
        m.read = function(u, S, L, s, f) {
          var y, c, w = 8 * f - s - 1, P = (1 << w) - 1, k = P >> 1, D = -7, o = L ? f - 1 : 0, h = L ? -1 : 1, d = u[S + o];
          for (o += h, y = d & (1 << -D) - 1, d >>= -D, D += w; 0 < D; y = 256 * y + u[S + o], o += h, D -= 8) ;
          for (c = y & (1 << -D) - 1, y >>= -D, D += s; 0 < D; c = 256 * c + u[S + o], o += h, D -= 8) ;
          if (y === 0) y = 1 - k;
          else {
            if (y === P) return c ? NaN : (d ? -1 : 1) * (1 / 0);
            c += N(2, s), y -= k;
          }
          return (d ? -1 : 1) * c * N(2, y - s);
        }, m.write = function(u, S, L, s, f, y) {
          var c, w, P, k = Math.LN2, D = Math.log, o = 8 * y - f - 1, h = (1 << o) - 1, d = h >> 1, E = f === 23 ? N(2, -24) - N(2, -77) : 0, g = s ? 0 : y - 1, T = s ? 1 : -1, M = 0 > S || S === 0 && 0 > 1 / S ? 1 : 0;
          for (S = O(S), isNaN(S) || S === 1 / 0 ? (w = isNaN(S) ? 1 : 0, c = h) : (c = l(D(S) / k), 1 > S * (P = N(2, -c)) && (c--, P *= 2), S += 1 <= c + d ? E / P : E * N(2, 1 - d), 2 <= S * P && (c++, P /= 2), c + d >= h ? (w = 0, c = h) : 1 <= c + d ? (w = (S * P - 1) * N(2, f), c += d) : (w = S * N(2, d - 1) * N(2, f), c = 0)); 8 <= f; u[L + g] = 255 & w, g += T, w /= 256, f -= 8) ;
          for (c = c << f | w, o += f; 0 < o; u[L + g] = 255 & c, g += T, c /= 256, o -= 8) ;
          u[L + g - T] |= 128 * M;
        };
      }, {}], 10: [function(_, I) {
        I.exports = typeof Object.create == "function" ? function(m, u) {
          u && (m.super_ = u, m.prototype = Object.create(u.prototype, { constructor: { value: m, enumerable: !1, writable: !0, configurable: !0 } }));
        } : function(m, u) {
          if (u) {
            m.super_ = u;
            var S = function() {
            };
            S.prototype = u.prototype, m.prototype = new S(), m.prototype.constructor = m;
          }
        };
      }, {}], 11: [function(_, I) {
        var m = Math.round;
        function u(f) {
          if (f += "", !(100 < f.length)) {
            var y = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(f);
            if (y) {
              var c = parseFloat(y[1]), w = (y[2] || "ms").toLowerCase();
              return w === "years" || w === "year" || w === "yrs" || w === "yr" || w === "y" ? 315576e5 * c : w === "weeks" || w === "week" || w === "w" ? 6048e5 * c : w === "days" || w === "day" || w === "d" ? 864e5 * c : w === "hours" || w === "hour" || w === "hrs" || w === "hr" || w === "h" ? 36e5 * c : w === "minutes" || w === "minute" || w === "mins" || w === "min" || w === "m" ? 6e4 * c : w === "seconds" || w === "second" || w === "secs" || w === "sec" || w === "s" ? 1e3 * c : w === "milliseconds" || w === "millisecond" || w === "msecs" || w === "msec" || w === "ms" ? c : void 0;
            }
          }
        }
        function S(f) {
          var y = O(f);
          return 864e5 <= y ? m(f / 864e5) + "d" : 36e5 <= y ? m(f / 36e5) + "h" : 6e4 <= y ? m(f / 6e4) + "m" : 1e3 <= y ? m(f / 1e3) + "s" : f + "ms";
        }
        function L(f) {
          var y = O(f);
          return 864e5 <= y ? s(f, y, 864e5, "day") : 36e5 <= y ? s(f, y, 36e5, "hour") : 6e4 <= y ? s(f, y, 6e4, "minute") : 1e3 <= y ? s(f, y, 1e3, "second") : f + " ms";
        }
        function s(f, y, c, w) {
          return m(f / c) + " " + w + (y >= 1.5 * c ? "s" : "");
        }
        I.exports = function(f, y) {
          y = y || {};
          var c = typeof f;
          if (c == "string" && 0 < f.length) return u(f);
          if (c === "number" && isFinite(f)) return y.long ? L(f) : S(f);
          throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(f));
        };
      }, {}], 12: [function(_, I) {
        function m() {
          throw new Error("setTimeout has not been defined");
        }
        function u() {
          throw new Error("clearTimeout has not been defined");
        }
        function S(E) {
          if (w === setTimeout) return setTimeout(E, 0);
          if ((w === m || !w) && setTimeout) return w = setTimeout, setTimeout(E, 0);
          try {
            return w(E, 0);
          } catch {
            try {
              return w.call(null, E, 0);
            } catch {
              return w.call(this, E, 0);
            }
          }
        }
        function L(E) {
          if (P === clearTimeout) return clearTimeout(E);
          if ((P === u || !P) && clearTimeout) return P = clearTimeout, clearTimeout(E);
          try {
            return P(E);
          } catch {
            try {
              return P.call(null, E);
            } catch {
              return P.call(this, E);
            }
          }
        }
        function s() {
          h && D && (h = !1, D.length ? o = D.concat(o) : d = -1, o.length && f());
        }
        function f() {
          if (!h) {
            var E = S(s);
            h = !0;
            for (var g = o.length; g; ) {
              for (D = o, o = []; ++d < g; ) D && D[d].run();
              d = -1, g = o.length;
            }
            D = null, h = !1, L(E);
          }
        }
        function y(E, g) {
          this.fun = E, this.array = g;
        }
        function c() {
        }
        var w, P, k = I.exports = {};
        (function() {
          try {
            w = typeof setTimeout == "function" ? setTimeout : m;
          } catch {
            w = m;
          }
          try {
            P = typeof clearTimeout == "function" ? clearTimeout : u;
          } catch {
            P = u;
          }
        })();
        var D, o = [], h = !1, d = -1;
        k.nextTick = function(E) {
          var g = Array(arguments.length - 1);
          if (1 < arguments.length) for (var T = 1; T < arguments.length; T++) g[T - 1] = arguments[T];
          o.push(new y(E, g)), o.length !== 1 || h || S(f);
        }, y.prototype.run = function() {
          this.fun.apply(null, this.array);
        }, k.title = "browser", k.browser = !0, k.env = {}, k.argv = [], k.version = "", k.versions = {}, k.on = c, k.addListener = c, k.once = c, k.off = c, k.removeListener = c, k.removeAllListeners = c, k.emit = c, k.prependListener = c, k.prependOnceListener = c, k.listeners = function() {
          return [];
        }, k.binding = function() {
          throw new Error("process.binding is not supported");
        }, k.cwd = function() {
          return "/";
        }, k.chdir = function() {
          throw new Error("process.chdir is not supported");
        }, k.umask = function() {
          return 0;
        };
      }, {}], 13: [function(_, I) {
        (function(m) {
          (function() {
            /*! queue-microtask. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
            let u;
            I.exports = typeof queueMicrotask == "function" ? queueMicrotask.bind(typeof window > "u" ? m : window) : (S) => (u || (u = Promise.resolve())).then(S).catch((L) => setTimeout(() => {
              throw L;
            }, 0));
          }).call(this);
        }).call(this, typeof de > "u" ? typeof self > "u" ? typeof window > "u" ? {} : window : self : de);
      }, {}], 14: [function(_, I) {
        (function(m, u) {
          (function() {
            var S = _("safe-buffer").Buffer, L = u.crypto || u.msCrypto;
            I.exports = L && L.getRandomValues ? function(s, f) {
              if (s > 4294967295) throw new RangeError("requested too many random bytes");
              var y = S.allocUnsafe(s);
              if (0 < s) if (65536 < s) for (var c = 0; c < s; c += 65536) L.getRandomValues(y.slice(c, c + 65536));
              else L.getRandomValues(y);
              return typeof f == "function" ? m.nextTick(function() {
                f(null, y);
              }) : y;
            } : function() {
              throw new Error(`Secure random number generation is not supported by this browser.
Use Chrome, Firefox or Internet Explorer 11`);
            };
          }).call(this);
        }).call(this, _("_process"), typeof de > "u" ? typeof self > "u" ? typeof window > "u" ? {} : window : self : de);
      }, { _process: 12, "safe-buffer": 30 }], 15: [function(_, I) {
        function m(c, w) {
          c.prototype = Object.create(w.prototype), c.prototype.constructor = c, c.__proto__ = w;
        }
        function u(c, w, P) {
          function k(o, h, d) {
            return typeof w == "string" ? w : w(o, h, d);
          }
          P || (P = Error);
          var D = (function(o) {
            function h(d, E, g) {
              return o.call(this, k(d, E, g)) || this;
            }
            return m(h, o), h;
          })(P);
          D.prototype.name = P.name, D.prototype.code = c, y[c] = D;
        }
        function S(c, w) {
          if (Array.isArray(c)) {
            var P = c.length;
            return c = c.map(function(k) {
              return k + "";
            }), 2 < P ? "one of ".concat(w, " ").concat(c.slice(0, P - 1).join(", "), ", or ") + c[P - 1] : P === 2 ? "one of ".concat(w, " ").concat(c[0], " or ").concat(c[1]) : "of ".concat(w, " ").concat(c[0]);
          }
          return "of ".concat(w, " ").concat(c + "");
        }
        function L(c, w, P) {
          return c.substr(0, w.length) === w;
        }
        function s(c, w, P) {
          return (P === void 0 || P > c.length) && (P = c.length), c.substring(P - w.length, P) === w;
        }
        function f(c, w, P) {
          return typeof P != "number" && (P = 0), !(P + w.length > c.length) && c.indexOf(w, P) !== -1;
        }
        var y = {};
        u("ERR_INVALID_OPT_VALUE", function(c, w) {
          return 'The value "' + w + '" is invalid for option "' + c + '"';
        }, TypeError), u("ERR_INVALID_ARG_TYPE", function(c, w, P) {
          var k;
          typeof w == "string" && L(w, "not ") ? (k = "must not be", w = w.replace(/^not /, "")) : k = "must be";
          var D;
          if (s(c, " argument")) D = "The ".concat(c, " ").concat(k, " ").concat(S(w, "type"));
          else {
            var o = f(c, ".") ? "property" : "argument";
            D = 'The "'.concat(c, '" ').concat(o, " ").concat(k, " ").concat(S(w, "type"));
          }
          return D += ". Received type ".concat(typeof P), D;
        }, TypeError), u("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF"), u("ERR_METHOD_NOT_IMPLEMENTED", function(c) {
          return "The " + c + " method is not implemented";
        }), u("ERR_STREAM_PREMATURE_CLOSE", "Premature close"), u("ERR_STREAM_DESTROYED", function(c) {
          return "Cannot call " + c + " after a stream was destroyed";
        }), u("ERR_MULTIPLE_CALLBACK", "Callback called multiple times"), u("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable"), u("ERR_STREAM_WRITE_AFTER_END", "write after end"), u("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError), u("ERR_UNKNOWN_ENCODING", function(c) {
          return "Unknown encoding: " + c;
        }, TypeError), u("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event"), I.exports.codes = y;
      }, {}], 16: [function(_, I) {
        (function(m) {
          (function() {
            function u(k) {
              return this instanceof u ? (f.call(this, k), y.call(this, k), this.allowHalfOpen = !0, void (k && (k.readable === !1 && (this.readable = !1), k.writable === !1 && (this.writable = !1), k.allowHalfOpen === !1 && (this.allowHalfOpen = !1, this.once("end", S))))) : new u(k);
            }
            function S() {
              this._writableState.ended || m.nextTick(L, this);
            }
            function L(k) {
              k.end();
            }
            var s = Object.keys || function(k) {
              var D = [];
              for (var o in k) D.push(o);
              return D;
            };
            I.exports = u;
            var f = _("./_stream_readable"), y = _("./_stream_writable");
            _("inherits")(u, f);
            for (var c, w = s(y.prototype), P = 0; P < w.length; P++) c = w[P], u.prototype[c] || (u.prototype[c] = y.prototype[c]);
            Object.defineProperty(u.prototype, "writableHighWaterMark", { enumerable: !1, get: function() {
              return this._writableState.highWaterMark;
            } }), Object.defineProperty(u.prototype, "writableBuffer", { enumerable: !1, get: function() {
              return this._writableState && this._writableState.getBuffer();
            } }), Object.defineProperty(u.prototype, "writableLength", { enumerable: !1, get: function() {
              return this._writableState.length;
            } }), Object.defineProperty(u.prototype, "destroyed", { enumerable: !1, get: function() {
              return this._readableState !== void 0 && this._writableState !== void 0 && this._readableState.destroyed && this._writableState.destroyed;
            }, set: function(k) {
              this._readableState === void 0 || this._writableState === void 0 || (this._readableState.destroyed = k, this._writableState.destroyed = k);
            } });
          }).call(this);
        }).call(this, _("_process"));
      }, { "./_stream_readable": 18, "./_stream_writable": 20, _process: 12, inherits: 10 }], 17: [function(_, I) {
        function m(S) {
          return this instanceof m ? void u.call(this, S) : new m(S);
        }
        I.exports = m;
        var u = _("./_stream_transform");
        _("inherits")(m, u), m.prototype._transform = function(S, L, s) {
          s(null, S);
        };
      }, { "./_stream_transform": 19, inherits: 10 }], 18: [function(_, I) {
        (function(m, u) {
          (function() {
            function S(a) {
              return ye.from(a);
            }
            function L(a) {
              return ye.isBuffer(a) || a instanceof X;
            }
            function s(a, e, t) {
              return typeof a.prependListener == "function" ? a.prependListener(e, t) : void (a._events && a._events[e] ? Array.isArray(a._events[e]) ? a._events[e].unshift(t) : a._events[e] = [t, a._events[e]] : a.on(e, t));
            }
            function f(a, e, t) {
              re = re || _("./_stream_duplex"), a = a || {}, typeof t != "boolean" && (t = e instanceof re), this.objectMode = !!a.objectMode, t && (this.objectMode = this.objectMode || !!a.readableObjectMode), this.highWaterMark = je(this, a, "readableHighWaterMark", t), this.buffer = new Pe(), this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.paused = !0, this.emitClose = a.emitClose !== !1, this.autoDestroy = !!a.autoDestroy, this.destroyed = !1, this.defaultEncoding = a.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, a.encoding && (!ue && (ue = _("string_decoder/").StringDecoder), this.decoder = new ue(a.encoding), this.encoding = a.encoding);
            }
            function y(a) {
              if (re = re || _("./_stream_duplex"), !(this instanceof y)) return new y(a);
              var e = this instanceof re;
              this._readableState = new f(a, this, e), this.readable = !0, a && (typeof a.read == "function" && (this._read = a.read), typeof a.destroy == "function" && (this._destroy = a.destroy)), ce.call(this);
            }
            function c(a, e, t, n, p) {
              q("readableAddChunk", e);
              var v = a._readableState;
              if (e === null) v.reading = !1, o(a, v);
              else {
                var x;
                if (p || (x = P(v, e)), x) F(a, x);
                else if (!(v.objectMode || e && 0 < e.length)) n || (v.reading = !1, E(a, v));
                else if (typeof e == "string" || v.objectMode || Object.getPrototypeOf(e) === ye.prototype || (e = S(e)), n) v.endEmitted ? F(a, new A()) : w(a, v, e, !0);
                else if (v.ended) F(a, new he());
                else {
                  if (v.destroyed) return !1;
                  v.reading = !1, v.decoder && !t ? (e = v.decoder.write(e), v.objectMode || e.length !== 0 ? w(a, v, e, !1) : E(a, v)) : w(a, v, e, !1);
                }
              }
              return !v.ended && (v.length < v.highWaterMark || v.length === 0);
            }
            function w(a, e, t, n) {
              e.flowing && e.length === 0 && !e.sync ? (e.awaitDrain = 0, a.emit("data", t)) : (e.length += e.objectMode ? 1 : t.length, n ? e.buffer.unshift(t) : e.buffer.push(t), e.needReadable && h(a)), E(a, e);
            }
            function P(a, e) {
              var t;
              return L(e) || typeof e == "string" || e === void 0 || a.objectMode || (t = new le("chunk", ["string", "Buffer", "Uint8Array"], e)), t;
            }
            function k(a) {
              return 1073741824 <= a ? a = 1073741824 : (a--, a |= a >>> 1, a |= a >>> 2, a |= a >>> 4, a |= a >>> 8, a |= a >>> 16, a++), a;
            }
            function D(a, e) {
              return 0 >= a || e.length === 0 && e.ended ? 0 : e.objectMode ? 1 : a === a ? (a > e.highWaterMark && (e.highWaterMark = k(a)), a <= e.length ? a : e.ended ? e.length : (e.needReadable = !0, 0)) : e.flowing && e.length ? e.buffer.head.data.length : e.length;
            }
            function o(a, e) {
              if (q("onEofChunk"), !e.ended) {
                if (e.decoder) {
                  var t = e.decoder.end();
                  t && t.length && (e.buffer.push(t), e.length += e.objectMode ? 1 : t.length);
                }
                e.ended = !0, e.sync ? h(a) : (e.needReadable = !1, !e.emittedReadable && (e.emittedReadable = !0, d(a)));
              }
            }
            function h(a) {
              var e = a._readableState;
              q("emitReadable", e.needReadable, e.emittedReadable), e.needReadable = !1, e.emittedReadable || (q("emitReadable", e.flowing), e.emittedReadable = !0, m.nextTick(d, a));
            }
            function d(a) {
              var e = a._readableState;
              q("emitReadable_", e.destroyed, e.length, e.ended), !e.destroyed && (e.length || e.ended) && (a.emit("readable"), e.emittedReadable = !1), e.needReadable = !e.flowing && !e.ended && e.length <= e.highWaterMark, U(a);
            }
            function E(a, e) {
              e.readingMore || (e.readingMore = !0, m.nextTick(g, a, e));
            }
            function g(a, e) {
              for (; !e.reading && !e.ended && (e.length < e.highWaterMark || e.flowing && e.length === 0); ) {
                var t = e.length;
                if (q("maybeReadMore read 0"), a.read(0), t === e.length) break;
              }
              e.readingMore = !1;
            }
            function T(a) {
              return function() {
                var e = a._readableState;
                q("pipeOnDrain", e.awaitDrain), e.awaitDrain && e.awaitDrain--, e.awaitDrain === 0 && Se(a, "data") && (e.flowing = !0, U(a));
              };
            }
            function M(a) {
              var e = a._readableState;
              e.readableListening = 0 < a.listenerCount("readable"), e.resumeScheduled && !e.paused ? e.flowing = !0 : 0 < a.listenerCount("data") && a.resume();
            }
            function b(a) {
              q("readable nexttick read 0"), a.read(0);
            }
            function C(a, e) {
              e.resumeScheduled || (e.resumeScheduled = !0, m.nextTick(j, a, e));
            }
            function j(a, e) {
              q("resume", e.reading), e.reading || a.read(0), e.resumeScheduled = !1, a.emit("resume"), U(a), e.flowing && !e.reading && a.read(0);
            }
            function U(a) {
              var e = a._readableState;
              for (q("flow", e.flowing); e.flowing && a.read() !== null; ) ;
            }
            function W(a, e) {
              if (e.length === 0) return null;
              var t;
              return e.objectMode ? t = e.buffer.shift() : !a || a >= e.length ? (t = e.decoder ? e.buffer.join("") : e.buffer.length === 1 ? e.buffer.first() : e.buffer.concat(e.length), e.buffer.clear()) : t = e.buffer.consume(a, e.decoder), t;
            }
            function H(a) {
              var e = a._readableState;
              q("endReadable", e.endEmitted), e.endEmitted || (e.ended = !0, m.nextTick(z, e, a));
            }
            function z(a, e) {
              if (q("endReadableNT", a.endEmitted, a.length), !a.endEmitted && a.length === 0 && (a.endEmitted = !0, e.readable = !1, e.emit("end"), a.autoDestroy)) {
                var t = e._writableState;
                (!t || t.autoDestroy && t.finished) && e.destroy();
              }
            }
            function Z(a, e) {
              for (var t = 0, n = a.length; t < n; t++) if (a[t] === e) return t;
              return -1;
            }
            I.exports = y;
            var re;
            y.ReadableState = f;
            var q;
            _("events").EventEmitter;
            var Se = function(a, e) {
              return a.listeners(e).length;
            }, ce = _("./internal/streams/stream"), ye = _("buffer").Buffer, X = u.Uint8Array || function() {
            }, K = _("util");
            q = K && K.debuglog ? K.debuglog("stream") : function() {
            };
            var ue, be, me, Pe = _("./internal/streams/buffer_list"), ve = _("./internal/streams/destroy"), Ee = _("./internal/streams/state"), je = Ee.getHighWaterMark, _e = _("../errors").codes, le = _e.ERR_INVALID_ARG_TYPE, he = _e.ERR_STREAM_PUSH_AFTER_EOF, R = _e.ERR_METHOD_NOT_IMPLEMENTED, A = _e.ERR_STREAM_UNSHIFT_AFTER_END_EVENT;
            _("inherits")(y, ce);
            var F = ve.errorOrDestroy, $ = ["error", "close", "destroy", "pause", "resume"];
            Object.defineProperty(y.prototype, "destroyed", { enumerable: !1, get: function() {
              return this._readableState !== void 0 && this._readableState.destroyed;
            }, set: function(a) {
              this._readableState && (this._readableState.destroyed = a);
            } }), y.prototype.destroy = ve.destroy, y.prototype._undestroy = ve.undestroy, y.prototype._destroy = function(a, e) {
              e(a);
            }, y.prototype.push = function(a, e) {
              var t, n = this._readableState;
              return n.objectMode ? t = !0 : typeof a == "string" && (e = e || n.defaultEncoding, e !== n.encoding && (a = ye.from(a, e), e = ""), t = !0), c(this, a, e, !1, t);
            }, y.prototype.unshift = function(a) {
              return c(this, a, null, !0, !1);
            }, y.prototype.isPaused = function() {
              return this._readableState.flowing === !1;
            }, y.prototype.setEncoding = function(a) {
              ue || (ue = _("string_decoder/").StringDecoder);
              var e = new ue(a);
              this._readableState.decoder = e, this._readableState.encoding = this._readableState.decoder.encoding;
              for (var t = this._readableState.buffer.head, n = ""; t !== null; ) n += e.write(t.data), t = t.next;
              return this._readableState.buffer.clear(), n !== "" && this._readableState.buffer.push(n), this._readableState.length = n.length, this;
            }, y.prototype.read = function(a) {
              q("read", a), a = parseInt(a, 10);
              var e = this._readableState, t = a;
              if (a !== 0 && (e.emittedReadable = !1), a === 0 && e.needReadable && ((e.highWaterMark === 0 ? 0 < e.length : e.length >= e.highWaterMark) || e.ended)) return q("read: emitReadable", e.length, e.ended), e.length === 0 && e.ended ? H(this) : h(this), null;
              if (a = D(a, e), a === 0 && e.ended) return e.length === 0 && H(this), null;
              var n = e.needReadable;
              q("need readable", n), (e.length === 0 || e.length - a < e.highWaterMark) && (n = !0, q("length less than watermark", n)), e.ended || e.reading ? (n = !1, q("reading or ended", n)) : n && (q("do read"), e.reading = !0, e.sync = !0, e.length === 0 && (e.needReadable = !0), this._read(e.highWaterMark), e.sync = !1, !e.reading && (a = D(t, e)));
              var p;
              return p = 0 < a ? W(a, e) : null, p === null ? (e.needReadable = e.length <= e.highWaterMark, a = 0) : (e.length -= a, e.awaitDrain = 0), e.length === 0 && (!e.ended && (e.needReadable = !0), t !== a && e.ended && H(this)), p !== null && this.emit("data", p), p;
            }, y.prototype._read = function() {
              F(this, new R("_read()"));
            }, y.prototype.pipe = function(a, e) {
              function t(ke, Ae) {
                q("onunpipe"), ke === G && Ae && Ae.hasUnpiped === !1 && (Ae.hasUnpiped = !0, p());
              }
              function n() {
                q("onend"), a.end();
              }
              function p() {
                q("cleanup"), a.removeListener("close", B), a.removeListener("finish", Y), a.removeListener("drain", Te), a.removeListener("error", x), a.removeListener("unpipe", t), G.removeListener("end", n), G.removeListener("end", J), G.removeListener("data", v), Fe = !0, V.awaitDrain && (!a._writableState || a._writableState.needDrain) && Te();
              }
              function v(ke) {
                q("ondata");
                var Ae = a.write(ke);
                q("dest.write", Ae), Ae === !1 && ((V.pipesCount === 1 && V.pipes === a || 1 < V.pipesCount && Z(V.pipes, a) !== -1) && !Fe && (q("false write response, pause", V.awaitDrain), V.awaitDrain++), G.pause());
              }
              function x(ke) {
                q("onerror", ke), J(), a.removeListener("error", x), Se(a, "error") === 0 && F(a, ke);
              }
              function B() {
                a.removeListener("finish", Y), J();
              }
              function Y() {
                q("onfinish"), a.removeListener("close", B), J();
              }
              function J() {
                q("unpipe"), G.unpipe(a);
              }
              var G = this, V = this._readableState;
              switch (V.pipesCount) {
                case 0:
                  V.pipes = a;
                  break;
                case 1:
                  V.pipes = [V.pipes, a];
                  break;
                default:
                  V.pipes.push(a);
              }
              V.pipesCount += 1, q("pipe count=%d opts=%j", V.pipesCount, e);
              var te = (!e || e.end !== !1) && a !== m.stdout && a !== m.stderr, Ce = te ? n : J;
              V.endEmitted ? m.nextTick(Ce) : G.once("end", Ce), a.on("unpipe", t);
              var Te = T(G);
              a.on("drain", Te);
              var Fe = !1;
              return G.on("data", v), s(a, "error", x), a.once("close", B), a.once("finish", Y), a.emit("pipe", G), V.flowing || (q("pipe resume"), G.resume()), a;
            }, y.prototype.unpipe = function(a) {
              var e = this._readableState, t = { hasUnpiped: !1 };
              if (e.pipesCount === 0) return this;
              if (e.pipesCount === 1) return a && a !== e.pipes ? this : (a || (a = e.pipes), e.pipes = null, e.pipesCount = 0, e.flowing = !1, a && a.emit("unpipe", this, t), this);
              if (!a) {
                var n = e.pipes, p = e.pipesCount;
                e.pipes = null, e.pipesCount = 0, e.flowing = !1;
                for (var v = 0; v < p; v++) n[v].emit("unpipe", this, { hasUnpiped: !1 });
                return this;
              }
              var x = Z(e.pipes, a);
              return x === -1 ? this : (e.pipes.splice(x, 1), e.pipesCount -= 1, e.pipesCount === 1 && (e.pipes = e.pipes[0]), a.emit("unpipe", this, t), this);
            }, y.prototype.on = function(a, e) {
              var t = ce.prototype.on.call(this, a, e), n = this._readableState;
              return a === "data" ? (n.readableListening = 0 < this.listenerCount("readable"), n.flowing !== !1 && this.resume()) : a == "readable" && !n.endEmitted && !n.readableListening && (n.readableListening = n.needReadable = !0, n.flowing = !1, n.emittedReadable = !1, q("on readable", n.length, n.reading), n.length ? h(this) : !n.reading && m.nextTick(b, this)), t;
            }, y.prototype.addListener = y.prototype.on, y.prototype.removeListener = function(a, e) {
              var t = ce.prototype.removeListener.call(this, a, e);
              return a === "readable" && m.nextTick(M, this), t;
            }, y.prototype.removeAllListeners = function(a) {
              var e = ce.prototype.removeAllListeners.apply(this, arguments);
              return (a === "readable" || a === void 0) && m.nextTick(M, this), e;
            }, y.prototype.resume = function() {
              var a = this._readableState;
              return a.flowing || (q("resume"), a.flowing = !a.readableListening, C(this, a)), a.paused = !1, this;
            }, y.prototype.pause = function() {
              return q("call pause flowing=%j", this._readableState.flowing), this._readableState.flowing !== !1 && (q("pause"), this._readableState.flowing = !1, this.emit("pause")), this._readableState.paused = !0, this;
            }, y.prototype.wrap = function(a) {
              var e = this, t = this._readableState, n = !1;
              for (var p in a.on("end", function() {
                if (q("wrapped end"), t.decoder && !t.ended) {
                  var x = t.decoder.end();
                  x && x.length && e.push(x);
                }
                e.push(null);
              }), a.on("data", function(x) {
                if (q("wrapped data"), t.decoder && (x = t.decoder.write(x)), !(t.objectMode && x == null) && (t.objectMode || x && x.length)) {
                  var B = e.push(x);
                  B || (n = !0, a.pause());
                }
              }), a) this[p] === void 0 && typeof a[p] == "function" && (this[p] = /* @__PURE__ */ (function(x) {
                return function() {
                  return a[x].apply(a, arguments);
                };
              })(p));
              for (var v = 0; v < $.length; v++) a.on($[v], this.emit.bind(this, $[v]));
              return this._read = function(x) {
                q("wrapped _read", x), n && (n = !1, a.resume());
              }, this;
            }, typeof Symbol == "function" && (y.prototype[Symbol.asyncIterator] = function() {
              return be === void 0 && (be = _("./internal/streams/async_iterator")), be(this);
            }), Object.defineProperty(y.prototype, "readableHighWaterMark", { enumerable: !1, get: function() {
              return this._readableState.highWaterMark;
            } }), Object.defineProperty(y.prototype, "readableBuffer", { enumerable: !1, get: function() {
              return this._readableState && this._readableState.buffer;
            } }), Object.defineProperty(y.prototype, "readableFlowing", { enumerable: !1, get: function() {
              return this._readableState.flowing;
            }, set: function(a) {
              this._readableState && (this._readableState.flowing = a);
            } }), y._fromList = W, Object.defineProperty(y.prototype, "readableLength", { enumerable: !1, get: function() {
              return this._readableState.length;
            } }), typeof Symbol == "function" && (y.from = function(a, e) {
              return me === void 0 && (me = _("./internal/streams/from")), me(y, a, e);
            });
          }).call(this);
        }).call(this, _("_process"), typeof de > "u" ? typeof self > "u" ? typeof window > "u" ? {} : window : self : de);
      }, { "../errors": 15, "./_stream_duplex": 16, "./internal/streams/async_iterator": 21, "./internal/streams/buffer_list": 22, "./internal/streams/destroy": 23, "./internal/streams/from": 25, "./internal/streams/state": 27, "./internal/streams/stream": 28, _process: 12, buffer: 3, events: 7, inherits: 10, "string_decoder/": 31, util: 2 }], 19: [function(_, I) {
        function m(k, D) {
          var o = this._transformState;
          o.transforming = !1;
          var h = o.writecb;
          if (h === null) return this.emit("error", new y());
          o.writechunk = null, o.writecb = null, D != null && this.push(D), h(k);
          var d = this._readableState;
          d.reading = !1, (d.needReadable || d.length < d.highWaterMark) && this._read(d.highWaterMark);
        }
        function u(k) {
          return this instanceof u ? (P.call(this, k), this._transformState = { afterTransform: m.bind(this), needTransform: !1, transforming: !1, writecb: null, writechunk: null, writeencoding: null }, this._readableState.needReadable = !0, this._readableState.sync = !1, k && (typeof k.transform == "function" && (this._transform = k.transform), typeof k.flush == "function" && (this._flush = k.flush)), void this.on("prefinish", S)) : new u(k);
        }
        function S() {
          var k = this;
          typeof this._flush != "function" || this._readableState.destroyed ? L(this, null, null) : this._flush(function(D, o) {
            L(k, D, o);
          });
        }
        function L(k, D, o) {
          if (D) return k.emit("error", D);
          if (o != null && k.push(o), k._writableState.length) throw new w();
          if (k._transformState.transforming) throw new c();
          return k.push(null);
        }
        I.exports = u;
        var s = _("../errors").codes, f = s.ERR_METHOD_NOT_IMPLEMENTED, y = s.ERR_MULTIPLE_CALLBACK, c = s.ERR_TRANSFORM_ALREADY_TRANSFORMING, w = s.ERR_TRANSFORM_WITH_LENGTH_0, P = _("./_stream_duplex");
        _("inherits")(u, P), u.prototype.push = function(k, D) {
          return this._transformState.needTransform = !1, P.prototype.push.call(this, k, D);
        }, u.prototype._transform = function(k, D, o) {
          o(new f("_transform()"));
        }, u.prototype._write = function(k, D, o) {
          var h = this._transformState;
          if (h.writecb = o, h.writechunk = k, h.writeencoding = D, !h.transforming) {
            var d = this._readableState;
            (h.needTransform || d.needReadable || d.length < d.highWaterMark) && this._read(d.highWaterMark);
          }
        }, u.prototype._read = function() {
          var k = this._transformState;
          k.writechunk === null || k.transforming ? k.needTransform = !0 : (k.transforming = !0, this._transform(k.writechunk, k.writeencoding, k.afterTransform));
        }, u.prototype._destroy = function(k, D) {
          P.prototype._destroy.call(this, k, function(o) {
            D(o);
          });
        };
      }, { "../errors": 15, "./_stream_duplex": 16, inherits: 10 }], 20: [function(_, I) {
        (function(m, u) {
          (function() {
            function S(R) {
              var A = this;
              this.next = null, this.entry = null, this.finish = function() {
                H(A, R);
              };
            }
            function L(R) {
              return q.from(R);
            }
            function s(R) {
              return q.isBuffer(R) || R instanceof Se;
            }
            function f() {
            }
            function y(R, A, F) {
              z = z || _("./_stream_duplex"), R = R || {}, typeof F != "boolean" && (F = A instanceof z), this.objectMode = !!R.objectMode, F && (this.objectMode = this.objectMode || !!R.writableObjectMode), this.highWaterMark = X(this, R, "writableHighWaterMark", F), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
              var $ = R.decodeStrings === !1;
              this.decodeStrings = !$, this.defaultEncoding = R.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(a) {
                E(A, a);
              }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.emitClose = R.emitClose !== !1, this.autoDestroy = !!R.autoDestroy, this.bufferedRequestCount = 0, this.corkedRequestsFree = new S(this);
            }
            function c(R) {
              z = z || _("./_stream_duplex");
              var A = this instanceof z;
              return A || he.call(c, this) ? (this._writableState = new y(R, this, A), this.writable = !0, R && (typeof R.write == "function" && (this._write = R.write), typeof R.writev == "function" && (this._writev = R.writev), typeof R.destroy == "function" && (this._destroy = R.destroy), typeof R.final == "function" && (this._final = R.final)), void re.call(this)) : new c(R);
            }
            function w(R, A) {
              var F = new je();
              le(R, F), m.nextTick(A, F);
            }
            function P(R, A, F, $) {
              var a;
              return F === null ? a = new Ee() : typeof F != "string" && !A.objectMode && (a = new ue("chunk", ["string", "Buffer"], F)), !a || (le(R, a), m.nextTick($, a), !1);
            }
            function k(R, A, F) {
              return R.objectMode || R.decodeStrings === !1 || typeof A != "string" || (A = q.from(A, F)), A;
            }
            function D(R, A, F, $, a, e) {
              if (!F) {
                var t = k(A, $, a);
                $ !== t && (F = !0, a = "buffer", $ = t);
              }
              var n = A.objectMode ? 1 : $.length;
              A.length += n;
              var p = A.length < A.highWaterMark;
              if (p || (A.needDrain = !0), A.writing || A.corked) {
                var v = A.lastBufferedRequest;
                A.lastBufferedRequest = { chunk: $, encoding: a, isBuf: F, callback: e, next: null }, v ? v.next = A.lastBufferedRequest : A.bufferedRequest = A.lastBufferedRequest, A.bufferedRequestCount += 1;
              } else o(R, A, !1, n, $, a, e);
              return p;
            }
            function o(R, A, F, $, a, e, t) {
              A.writelen = $, A.writecb = t, A.writing = !0, A.sync = !0, A.destroyed ? A.onwrite(new ve("write")) : F ? R._writev(a, A.onwrite) : R._write(a, e, A.onwrite), A.sync = !1;
            }
            function h(R, A, F, $, a) {
              --A.pendingcb, F ? (m.nextTick(a, $), m.nextTick(U, R, A), R._writableState.errorEmitted = !0, le(R, $)) : (a($), R._writableState.errorEmitted = !0, le(R, $), U(R, A));
            }
            function d(R) {
              R.writing = !1, R.writecb = null, R.length -= R.writelen, R.writelen = 0;
            }
            function E(R, A) {
              var F = R._writableState, $ = F.sync, a = F.writecb;
              if (typeof a != "function") throw new me();
              if (d(F), A) h(R, F, $, A, a);
              else {
                var e = b(F) || R.destroyed;
                e || F.corked || F.bufferProcessing || !F.bufferedRequest || M(R, F), $ ? m.nextTick(g, R, F, e, a) : g(R, F, e, a);
              }
            }
            function g(R, A, F, $) {
              F || T(R, A), A.pendingcb--, $(), U(R, A);
            }
            function T(R, A) {
              A.length === 0 && A.needDrain && (A.needDrain = !1, R.emit("drain"));
            }
            function M(R, A) {
              A.bufferProcessing = !0;
              var F = A.bufferedRequest;
              if (R._writev && F && F.next) {
                var $ = A.bufferedRequestCount, a = Array($), e = A.corkedRequestsFree;
                e.entry = F;
                for (var t = 0, n = !0; F; ) a[t] = F, F.isBuf || (n = !1), F = F.next, t += 1;
                a.allBuffers = n, o(R, A, !0, A.length, a, "", e.finish), A.pendingcb++, A.lastBufferedRequest = null, e.next ? (A.corkedRequestsFree = e.next, e.next = null) : A.corkedRequestsFree = new S(A), A.bufferedRequestCount = 0;
              } else {
                for (; F; ) {
                  var p = F.chunk, v = F.encoding, x = F.callback, B = A.objectMode ? 1 : p.length;
                  if (o(R, A, !1, B, p, v, x), F = F.next, A.bufferedRequestCount--, A.writing) break;
                }
                F === null && (A.lastBufferedRequest = null);
              }
              A.bufferedRequest = F, A.bufferProcessing = !1;
            }
            function b(R) {
              return R.ending && R.length === 0 && R.bufferedRequest === null && !R.finished && !R.writing;
            }
            function C(R, A) {
              R._final(function(F) {
                A.pendingcb--, F && le(R, F), A.prefinished = !0, R.emit("prefinish"), U(R, A);
              });
            }
            function j(R, A) {
              A.prefinished || A.finalCalled || (typeof R._final != "function" || A.destroyed ? (A.prefinished = !0, R.emit("prefinish")) : (A.pendingcb++, A.finalCalled = !0, m.nextTick(C, R, A)));
            }
            function U(R, A) {
              var F = b(A);
              if (F && (j(R, A), A.pendingcb === 0 && (A.finished = !0, R.emit("finish"), A.autoDestroy))) {
                var $ = R._readableState;
                (!$ || $.autoDestroy && $.endEmitted) && R.destroy();
              }
              return F;
            }
            function W(R, A, F) {
              A.ending = !0, U(R, A), F && (A.finished ? m.nextTick(F) : R.once("finish", F)), A.ended = !0, R.writable = !1;
            }
            function H(R, A, F) {
              var $ = R.entry;
              for (R.entry = null; $; ) {
                var a = $.callback;
                A.pendingcb--, a(F), $ = $.next;
              }
              A.corkedRequestsFree.next = R;
            }
            I.exports = c;
            var z;
            c.WritableState = y;
            var Z = { deprecate: _("util-deprecate") }, re = _("./internal/streams/stream"), q = _("buffer").Buffer, Se = u.Uint8Array || function() {
            }, ce = _("./internal/streams/destroy"), ye = _("./internal/streams/state"), X = ye.getHighWaterMark, K = _("../errors").codes, ue = K.ERR_INVALID_ARG_TYPE, be = K.ERR_METHOD_NOT_IMPLEMENTED, me = K.ERR_MULTIPLE_CALLBACK, Pe = K.ERR_STREAM_CANNOT_PIPE, ve = K.ERR_STREAM_DESTROYED, Ee = K.ERR_STREAM_NULL_VALUES, je = K.ERR_STREAM_WRITE_AFTER_END, _e = K.ERR_UNKNOWN_ENCODING, le = ce.errorOrDestroy;
            _("inherits")(c, re), y.prototype.getBuffer = function() {
              for (var R = this.bufferedRequest, A = []; R; ) A.push(R), R = R.next;
              return A;
            }, (function() {
              try {
                Object.defineProperty(y.prototype, "buffer", { get: Z.deprecate(function() {
                  return this.getBuffer();
                }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003") });
              } catch {
              }
            })();
            var he;
            typeof Symbol == "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] == "function" ? (he = Function.prototype[Symbol.hasInstance], Object.defineProperty(c, Symbol.hasInstance, { value: function(R) {
              return !!he.call(this, R) || this === c && R && R._writableState instanceof y;
            } })) : he = function(R) {
              return R instanceof this;
            }, c.prototype.pipe = function() {
              le(this, new Pe());
            }, c.prototype.write = function(R, A, F) {
              var $ = this._writableState, a = !1, e = !$.objectMode && s(R);
              return e && !q.isBuffer(R) && (R = L(R)), typeof A == "function" && (F = A, A = null), e ? A = "buffer" : !A && (A = $.defaultEncoding), typeof F != "function" && (F = f), $.ending ? w(this, F) : (e || P(this, $, R, F)) && ($.pendingcb++, a = D(this, $, e, R, A, F)), a;
            }, c.prototype.cork = function() {
              this._writableState.corked++;
            }, c.prototype.uncork = function() {
              var R = this._writableState;
              R.corked && (R.corked--, !R.writing && !R.corked && !R.bufferProcessing && R.bufferedRequest && M(this, R));
            }, c.prototype.setDefaultEncoding = function(R) {
              if (typeof R == "string" && (R = R.toLowerCase()), !(-1 < ["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((R + "").toLowerCase()))) throw new _e(R);
              return this._writableState.defaultEncoding = R, this;
            }, Object.defineProperty(c.prototype, "writableBuffer", { enumerable: !1, get: function() {
              return this._writableState && this._writableState.getBuffer();
            } }), Object.defineProperty(c.prototype, "writableHighWaterMark", { enumerable: !1, get: function() {
              return this._writableState.highWaterMark;
            } }), c.prototype._write = function(R, A, F) {
              F(new be("_write()"));
            }, c.prototype._writev = null, c.prototype.end = function(R, A, F) {
              var $ = this._writableState;
              return typeof R == "function" ? (F = R, R = null, A = null) : typeof A == "function" && (F = A, A = null), R != null && this.write(R, A), $.corked && ($.corked = 1, this.uncork()), $.ending || W(this, $, F), this;
            }, Object.defineProperty(c.prototype, "writableLength", { enumerable: !1, get: function() {
              return this._writableState.length;
            } }), Object.defineProperty(c.prototype, "destroyed", { enumerable: !1, get: function() {
              return this._writableState !== void 0 && this._writableState.destroyed;
            }, set: function(R) {
              this._writableState && (this._writableState.destroyed = R);
            } }), c.prototype.destroy = ce.destroy, c.prototype._undestroy = ce.undestroy, c.prototype._destroy = function(R, A) {
              A(R);
            };
          }).call(this);
        }).call(this, _("_process"), typeof de > "u" ? typeof self > "u" ? typeof window > "u" ? {} : window : self : de);
      }, { "../errors": 15, "./_stream_duplex": 16, "./internal/streams/destroy": 23, "./internal/streams/state": 27, "./internal/streams/stream": 28, _process: 12, buffer: 3, inherits: 10, "util-deprecate": 32 }], 21: [function(_, I) {
        (function(m) {
          (function() {
            function u(T, M, b) {
              return M in T ? Object.defineProperty(T, M, { value: b, enumerable: !0, configurable: !0, writable: !0 }) : T[M] = b, T;
            }
            function S(T, M) {
              return { value: T, done: M };
            }
            function L(T) {
              var M = T[w];
              if (M !== null) {
                var b = T[d].read();
                b !== null && (T[o] = null, T[w] = null, T[P] = null, M(S(b, !1)));
              }
            }
            function s(T) {
              m.nextTick(L, T);
            }
            function f(T, M) {
              return function(b, C) {
                T.then(function() {
                  return M[D] ? void b(S(void 0, !0)) : void M[h](b, C);
                }, C);
              };
            }
            var y, c = _("./end-of-stream"), w = Symbol("lastResolve"), P = Symbol("lastReject"), k = Symbol("error"), D = Symbol("ended"), o = Symbol("lastPromise"), h = Symbol("handlePromise"), d = Symbol("stream"), E = Object.getPrototypeOf(function() {
            }), g = Object.setPrototypeOf((y = { get stream() {
              return this[d];
            }, next: function() {
              var T = this, M = this[k];
              if (M !== null) return Promise.reject(M);
              if (this[D]) return Promise.resolve(S(void 0, !0));
              if (this[d].destroyed) return new Promise(function(U, W) {
                m.nextTick(function() {
                  T[k] ? W(T[k]) : U(S(void 0, !0));
                });
              });
              var b, C = this[o];
              if (C) b = new Promise(f(C, this));
              else {
                var j = this[d].read();
                if (j !== null) return Promise.resolve(S(j, !1));
                b = new Promise(this[h]);
              }
              return this[o] = b, b;
            } }, u(y, Symbol.asyncIterator, function() {
              return this;
            }), u(y, "return", function() {
              var T = this;
              return new Promise(function(M, b) {
                T[d].destroy(null, function(C) {
                  return C ? void b(C) : void M(S(void 0, !0));
                });
              });
            }), y), E);
            I.exports = function(T) {
              var M, b = Object.create(g, (M = {}, u(M, d, { value: T, writable: !0 }), u(M, w, { value: null, writable: !0 }), u(M, P, { value: null, writable: !0 }), u(M, k, { value: null, writable: !0 }), u(M, D, { value: T._readableState.endEmitted, writable: !0 }), u(M, h, { value: function(C, j) {
                var U = b[d].read();
                U ? (b[o] = null, b[w] = null, b[P] = null, C(S(U, !1))) : (b[w] = C, b[P] = j);
              }, writable: !0 }), M));
              return b[o] = null, c(T, function(C) {
                if (C && C.code !== "ERR_STREAM_PREMATURE_CLOSE") {
                  var j = b[P];
                  return j !== null && (b[o] = null, b[w] = null, b[P] = null, j(C)), void (b[k] = C);
                }
                var U = b[w];
                U !== null && (b[o] = null, b[w] = null, b[P] = null, U(S(void 0, !0))), b[D] = !0;
              }), T.on("readable", s.bind(null, b)), b;
            };
          }).call(this);
        }).call(this, _("_process"));
      }, { "./end-of-stream": 24, _process: 12 }], 22: [function(_, I) {
        function m(o, h) {
          var d = Object.keys(o);
          if (Object.getOwnPropertySymbols) {
            var E = Object.getOwnPropertySymbols(o);
            h && (E = E.filter(function(g) {
              return Object.getOwnPropertyDescriptor(o, g).enumerable;
            })), d.push.apply(d, E);
          }
          return d;
        }
        function u(o) {
          for (var h, d = 1; d < arguments.length; d++) h = arguments[d] == null ? {} : arguments[d], d % 2 ? m(Object(h), !0).forEach(function(E) {
            S(o, E, h[E]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o, Object.getOwnPropertyDescriptors(h)) : m(Object(h)).forEach(function(E) {
            Object.defineProperty(o, E, Object.getOwnPropertyDescriptor(h, E));
          });
          return o;
        }
        function S(o, h, d) {
          return h in o ? Object.defineProperty(o, h, { value: d, enumerable: !0, configurable: !0, writable: !0 }) : o[h] = d, o;
        }
        function L(o, h) {
          if (!(o instanceof h)) throw new TypeError("Cannot call a class as a function");
        }
        function s(o, h) {
          for (var d, E = 0; E < h.length; E++) d = h[E], d.enumerable = d.enumerable || !1, d.configurable = !0, "value" in d && (d.writable = !0), Object.defineProperty(o, d.key, d);
        }
        function f(o, h, d) {
          return h && s(o.prototype, h), o;
        }
        function y(o, h, d) {
          w.prototype.copy.call(o, h, d);
        }
        var c = _("buffer"), w = c.Buffer, P = _("util"), k = P.inspect, D = k && k.custom || "inspect";
        I.exports = (function() {
          function o() {
            L(this, o), this.head = null, this.tail = null, this.length = 0;
          }
          return f(o, [{ key: "push", value: function(h) {
            var d = { data: h, next: null };
            0 < this.length ? this.tail.next = d : this.head = d, this.tail = d, ++this.length;
          } }, { key: "unshift", value: function(h) {
            var d = { data: h, next: this.head };
            this.length === 0 && (this.tail = d), this.head = d, ++this.length;
          } }, { key: "shift", value: function() {
            if (this.length !== 0) {
              var h = this.head.data;
              return this.head = this.length === 1 ? this.tail = null : this.head.next, --this.length, h;
            }
          } }, { key: "clear", value: function() {
            this.head = this.tail = null, this.length = 0;
          } }, { key: "join", value: function(h) {
            if (this.length === 0) return "";
            for (var d = this.head, E = "" + d.data; d = d.next; ) E += h + d.data;
            return E;
          } }, { key: "concat", value: function(h) {
            if (this.length === 0) return w.alloc(0);
            for (var d = w.allocUnsafe(h >>> 0), E = this.head, g = 0; E; ) y(E.data, d, g), g += E.data.length, E = E.next;
            return d;
          } }, { key: "consume", value: function(h, d) {
            var E;
            return h < this.head.data.length ? (E = this.head.data.slice(0, h), this.head.data = this.head.data.slice(h)) : h === this.head.data.length ? E = this.shift() : E = d ? this._getString(h) : this._getBuffer(h), E;
          } }, { key: "first", value: function() {
            return this.head.data;
          } }, { key: "_getString", value: function(h) {
            var d = this.head, E = 1, g = d.data;
            for (h -= g.length; d = d.next; ) {
              var T = d.data, M = h > T.length ? T.length : h;
              if (g += M === T.length ? T : T.slice(0, h), h -= M, h === 0) {
                M === T.length ? (++E, this.head = d.next ? d.next : this.tail = null) : (this.head = d, d.data = T.slice(M));
                break;
              }
              ++E;
            }
            return this.length -= E, g;
          } }, { key: "_getBuffer", value: function(h) {
            var d = w.allocUnsafe(h), E = this.head, g = 1;
            for (E.data.copy(d), h -= E.data.length; E = E.next; ) {
              var T = E.data, M = h > T.length ? T.length : h;
              if (T.copy(d, d.length - h, 0, M), h -= M, h === 0) {
                M === T.length ? (++g, this.head = E.next ? E.next : this.tail = null) : (this.head = E, E.data = T.slice(M));
                break;
              }
              ++g;
            }
            return this.length -= g, d;
          } }, { key: D, value: function(h, d) {
            return k(this, u({}, d, { depth: 0, customInspect: !1 }));
          } }]), o;
        })();
      }, { buffer: 3, util: 2 }], 23: [function(_, I) {
        (function(m) {
          (function() {
            function u(s, f) {
              L(s, f), S(s);
            }
            function S(s) {
              s._writableState && !s._writableState.emitClose || s._readableState && !s._readableState.emitClose || s.emit("close");
            }
            function L(s, f) {
              s.emit("error", f);
            }
            I.exports = { destroy: function(s, f) {
              var y = this, c = this._readableState && this._readableState.destroyed, w = this._writableState && this._writableState.destroyed;
              return c || w ? (f ? f(s) : s && (this._writableState ? !this._writableState.errorEmitted && (this._writableState.errorEmitted = !0, m.nextTick(L, this, s)) : m.nextTick(L, this, s)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(s || null, function(P) {
                !f && P ? y._writableState ? y._writableState.errorEmitted ? m.nextTick(S, y) : (y._writableState.errorEmitted = !0, m.nextTick(u, y, P)) : m.nextTick(u, y, P) : f ? (m.nextTick(S, y), f(P)) : m.nextTick(S, y);
              }), this);
            }, undestroy: function() {
              this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1);
            }, errorOrDestroy: function(s, f) {
              var y = s._readableState, c = s._writableState;
              y && y.autoDestroy || c && c.autoDestroy ? s.destroy(f) : s.emit("error", f);
            } };
          }).call(this);
        }).call(this, _("_process"));
      }, { _process: 12 }], 24: [function(_, I) {
        function m(f) {
          var y = !1;
          return function() {
            if (!y) {
              y = !0;
              for (var c = arguments.length, w = Array(c), P = 0; P < c; P++) w[P] = arguments[P];
              f.apply(this, w);
            }
          };
        }
        function u() {
        }
        function S(f) {
          return f.setHeader && typeof f.abort == "function";
        }
        function L(f, y, c) {
          if (typeof y == "function") return L(f, null, y);
          y || (y = {}), c = m(c || u);
          var w = y.readable || y.readable !== !1 && f.readable, P = y.writable || y.writable !== !1 && f.writable, k = function() {
            f.writable || o();
          }, D = f._writableState && f._writableState.finished, o = function() {
            P = !1, D = !0, w || c.call(f);
          }, h = f._readableState && f._readableState.endEmitted, d = function() {
            w = !1, h = !0, P || c.call(f);
          }, E = function(M) {
            c.call(f, M);
          }, g = function() {
            var M;
            return w && !h ? (f._readableState && f._readableState.ended || (M = new s()), c.call(f, M)) : P && !D ? (f._writableState && f._writableState.ended || (M = new s()), c.call(f, M)) : void 0;
          }, T = function() {
            f.req.on("finish", o);
          };
          return S(f) ? (f.on("complete", o), f.on("abort", g), f.req ? T() : f.on("request", T)) : P && !f._writableState && (f.on("end", k), f.on("close", k)), f.on("end", d), f.on("finish", o), y.error !== !1 && f.on("error", E), f.on("close", g), function() {
            f.removeListener("complete", o), f.removeListener("abort", g), f.removeListener("request", T), f.req && f.req.removeListener("finish", o), f.removeListener("end", k), f.removeListener("close", k), f.removeListener("finish", o), f.removeListener("end", d), f.removeListener("error", E), f.removeListener("close", g);
          };
        }
        var s = _("../../../errors").codes.ERR_STREAM_PREMATURE_CLOSE;
        I.exports = L;
      }, { "../../../errors": 15 }], 25: [function(_, I) {
        I.exports = function() {
          throw new Error("Readable.from is not available in the browser");
        };
      }, {}], 26: [function(_, I) {
        function m(D) {
          var o = !1;
          return function() {
            o || (o = !0, D.apply(void 0, arguments));
          };
        }
        function u(D) {
          if (D) throw D;
        }
        function S(D) {
          return D.setHeader && typeof D.abort == "function";
        }
        function L(D, o, h, d) {
          d = m(d);
          var E = !1;
          D.on("close", function() {
            E = !0;
          }), c === void 0 && (c = _("./end-of-stream")), c(D, { readable: o, writable: h }, function(T) {
            return T ? d(T) : (E = !0, void d());
          });
          var g = !1;
          return function(T) {
            if (!E) return g ? void 0 : (g = !0, S(D) ? D.abort() : typeof D.destroy == "function" ? D.destroy() : void d(T || new k("pipe")));
          };
        }
        function s(D) {
          D();
        }
        function f(D, o) {
          return D.pipe(o);
        }
        function y(D) {
          return D.length && typeof D[D.length - 1] == "function" ? D.pop() : u;
        }
        var c, w = _("../../../errors").codes, P = w.ERR_MISSING_ARGS, k = w.ERR_STREAM_DESTROYED;
        I.exports = function() {
          for (var D = arguments.length, o = Array(D), h = 0; h < D; h++) o[h] = arguments[h];
          var d = y(o);
          if (Array.isArray(o[0]) && (o = o[0]), 2 > o.length) throw new P("streams");
          var E, g = o.map(function(T, M) {
            var b = M < o.length - 1;
            return L(T, b, 0 < M, function(C) {
              E || (E = C), C && g.forEach(s), b || (g.forEach(s), d(E));
            });
          });
          return o.reduce(f);
        };
      }, { "../../../errors": 15, "./end-of-stream": 24 }], 27: [function(_, I) {
        function m(S, L, s) {
          return S.highWaterMark == null ? L ? S[s] : null : S.highWaterMark;
        }
        var u = _("../../../errors").codes.ERR_INVALID_OPT_VALUE;
        I.exports = { getHighWaterMark: function(S, L, s, f) {
          var y = m(L, f, s);
          if (y != null) {
            if (!(isFinite(y) && l(y) === y) || 0 > y) {
              var c = f ? s : "highWaterMark";
              throw new u(c, y);
            }
            return l(y);
          }
          return S.objectMode ? 16 : 16384;
        } };
      }, { "../../../errors": 15 }], 28: [function(_, I) {
        I.exports = _("events").EventEmitter;
      }, { events: 7 }], 29: [function(_, I, m) {
        m = I.exports = _("./lib/_stream_readable.js"), m.Stream = m, m.Readable = m, m.Writable = _("./lib/_stream_writable.js"), m.Duplex = _("./lib/_stream_duplex.js"), m.Transform = _("./lib/_stream_transform.js"), m.PassThrough = _("./lib/_stream_passthrough.js"), m.finished = _("./lib/internal/streams/end-of-stream.js"), m.pipeline = _("./lib/internal/streams/pipeline.js");
      }, { "./lib/_stream_duplex.js": 16, "./lib/_stream_passthrough.js": 17, "./lib/_stream_readable.js": 18, "./lib/_stream_transform.js": 19, "./lib/_stream_writable.js": 20, "./lib/internal/streams/end-of-stream.js": 24, "./lib/internal/streams/pipeline.js": 26 }], 30: [function(_, I, m) {
        function u(f, y) {
          for (var c in f) y[c] = f[c];
        }
        function S(f, y, c) {
          return s(f, y, c);
        }
        /*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        var L = _("buffer"), s = L.Buffer;
        s.from && s.alloc && s.allocUnsafe && s.allocUnsafeSlow ? I.exports = L : (u(L, m), m.Buffer = S), S.prototype = Object.create(s.prototype), u(s, S), S.from = function(f, y, c) {
          if (typeof f == "number") throw new TypeError("Argument must not be a number");
          return s(f, y, c);
        }, S.alloc = function(f, y, c) {
          if (typeof f != "number") throw new TypeError("Argument must be a number");
          var w = s(f);
          return y === void 0 ? w.fill(0) : typeof c == "string" ? w.fill(y, c) : w.fill(y), w;
        }, S.allocUnsafe = function(f) {
          if (typeof f != "number") throw new TypeError("Argument must be a number");
          return s(f);
        }, S.allocUnsafeSlow = function(f) {
          if (typeof f != "number") throw new TypeError("Argument must be a number");
          return L.SlowBuffer(f);
        };
      }, { buffer: 3 }], 31: [function(_, I, m) {
        function u(g) {
          if (!g) return "utf8";
          for (var T; ; ) switch (g) {
            case "utf8":
            case "utf-8":
              return "utf8";
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
              return "utf16le";
            case "latin1":
            case "binary":
              return "latin1";
            case "base64":
            case "ascii":
            case "hex":
              return g;
            default:
              if (T) return;
              g = ("" + g).toLowerCase(), T = !0;
          }
        }
        function S(g) {
          var T = u(g);
          if (typeof T != "string" && (d.isEncoding === E || !E(g))) throw new Error("Unknown encoding: " + g);
          return T || g;
        }
        function L(g) {
          this.encoding = S(g);
          var T;
          switch (this.encoding) {
            case "utf16le":
              this.text = w, this.end = P, T = 4;
              break;
            case "utf8":
              this.fillLast = c, T = 4;
              break;
            case "base64":
              this.text = k, this.end = D, T = 3;
              break;
            default:
              return this.write = o, void (this.end = h);
          }
          this.lastNeed = 0, this.lastTotal = 0, this.lastChar = d.allocUnsafe(T);
        }
        function s(g) {
          return 127 >= g ? 0 : g >> 5 == 6 ? 2 : g >> 4 == 14 ? 3 : g >> 3 == 30 ? 4 : g >> 6 == 2 ? -1 : -2;
        }
        function f(g, T, M) {
          var b = T.length - 1;
          if (b < M) return 0;
          var C = s(T[b]);
          return 0 <= C ? (0 < C && (g.lastNeed = C - 1), C) : --b < M || C === -2 ? 0 : (C = s(T[b]), 0 <= C ? (0 < C && (g.lastNeed = C - 2), C) : --b < M || C === -2 ? 0 : (C = s(T[b]), 0 <= C ? (0 < C && (C === 2 ? C = 0 : g.lastNeed = C - 3), C) : 0));
        }
        function y(g, T) {
          if ((192 & T[0]) != 128) return g.lastNeed = 0, "�";
          if (1 < g.lastNeed && 1 < T.length) {
            if ((192 & T[1]) != 128) return g.lastNeed = 1, "�";
            if (2 < g.lastNeed && 2 < T.length && (192 & T[2]) != 128) return g.lastNeed = 2, "�";
          }
        }
        function c(g) {
          var T = this.lastTotal - this.lastNeed, M = y(this, g);
          return M === void 0 ? this.lastNeed <= g.length ? (g.copy(this.lastChar, T, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal)) : (g.copy(this.lastChar, T, 0, g.length), void (this.lastNeed -= g.length)) : M;
        }
        function w(g, T) {
          if ((g.length - T) % 2 == 0) {
            var M = g.toString("utf16le", T);
            if (M) {
              var b = M.charCodeAt(M.length - 1);
              if (55296 <= b && 56319 >= b) return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = g[g.length - 2], this.lastChar[1] = g[g.length - 1], M.slice(0, -1);
            }
            return M;
          }
          return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = g[g.length - 1], g.toString("utf16le", T, g.length - 1);
        }
        function P(g) {
          var T = g && g.length ? this.write(g) : "";
          if (this.lastNeed) {
            var M = this.lastTotal - this.lastNeed;
            return T + this.lastChar.toString("utf16le", 0, M);
          }
          return T;
        }
        function k(g, T) {
          var M = (g.length - T) % 3;
          return M == 0 ? g.toString("base64", T) : (this.lastNeed = 3 - M, this.lastTotal = 3, M == 1 ? this.lastChar[0] = g[g.length - 1] : (this.lastChar[0] = g[g.length - 2], this.lastChar[1] = g[g.length - 1]), g.toString("base64", T, g.length - M));
        }
        function D(g) {
          var T = g && g.length ? this.write(g) : "";
          return this.lastNeed ? T + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : T;
        }
        function o(g) {
          return g.toString(this.encoding);
        }
        function h(g) {
          return g && g.length ? this.write(g) : "";
        }
        var d = _("safe-buffer").Buffer, E = d.isEncoding || function(g) {
          switch (g = "" + g, g && g.toLowerCase()) {
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
            case "raw":
              return !0;
            default:
              return !1;
          }
        };
        m.StringDecoder = L, L.prototype.write = function(g) {
          if (g.length === 0) return "";
          var T, M;
          if (this.lastNeed) {
            if (T = this.fillLast(g), T === void 0) return "";
            M = this.lastNeed, this.lastNeed = 0;
          } else M = 0;
          return M < g.length ? T ? T + this.text(g, M) : this.text(g, M) : T || "";
        }, L.prototype.end = function(g) {
          var T = g && g.length ? this.write(g) : "";
          return this.lastNeed ? T + "�" : T;
        }, L.prototype.text = function(g, T) {
          var M = f(this, g, T);
          if (!this.lastNeed) return g.toString("utf8", T);
          this.lastTotal = M;
          var b = g.length - (M - this.lastNeed);
          return g.copy(this.lastChar, 0, b), g.toString("utf8", T, b);
        }, L.prototype.fillLast = function(g) {
          return this.lastNeed <= g.length ? (g.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal)) : (g.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, g.length), void (this.lastNeed -= g.length));
        };
      }, { "safe-buffer": 30 }], 32: [function(_, I) {
        (function(m) {
          (function() {
            function u(S) {
              try {
                if (!m.localStorage) return !1;
              } catch {
                return !1;
              }
              var L = m.localStorage[S];
              return L != null && (L + "").toLowerCase() === "true";
            }
            I.exports = function(S, L) {
              function s() {
                if (!f) {
                  if (u("throwDeprecation")) throw new Error(L);
                  u("traceDeprecation") ? console.trace(L) : console.warn(L), f = !0;
                }
                return S.apply(this, arguments);
              }
              if (u("noDeprecation")) return S;
              var f = !1;
              return s;
            };
          }).call(this);
        }).call(this, typeof de > "u" ? typeof self > "u" ? typeof window > "u" ? {} : window : self : de);
      }, {}], "/": [function(_, I) {
        function m(D) {
          return D.replace(/a=ice-options:trickle\s\n/g, "");
        }
        function u(D) {
          console.warn(D);
        }
        /*! simple-peer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
        const S = _("debug")("simple-peer"), L = _("get-browser-rtc"), s = _("randombytes"), f = _("readable-stream"), y = _("queue-microtask"), c = _("err-code"), { Buffer: w } = _("buffer"), P = 65536;
        class k extends f.Duplex {
          constructor(o) {
            if (o = Object.assign({ allowHalfOpen: !1 }, o), super(o), this._id = s(4).toString("hex").slice(0, 7), this._debug("new peer %o", o), this.channelName = o.initiator ? o.channelName || s(20).toString("hex") : null, this.initiator = o.initiator || !1, this.channelConfig = o.channelConfig || k.channelConfig, this.channelNegotiated = this.channelConfig.negotiated, this.config = Object.assign({}, k.config, o.config), this.offerOptions = o.offerOptions || {}, this.answerOptions = o.answerOptions || {}, this.sdpTransform = o.sdpTransform || ((h) => h), this.streams = o.streams || (o.stream ? [o.stream] : []), this.trickle = o.trickle === void 0 || o.trickle, this.allowHalfTrickle = o.allowHalfTrickle !== void 0 && o.allowHalfTrickle, this.iceCompleteTimeout = o.iceCompleteTimeout || 5e3, this.destroyed = !1, this.destroying = !1, this._connected = !1, this.remoteAddress = void 0, this.remoteFamily = void 0, this.remotePort = void 0, this.localAddress = void 0, this.localFamily = void 0, this.localPort = void 0, this._wrtc = o.wrtc && typeof o.wrtc == "object" ? o.wrtc : L(), !this._wrtc) throw c(typeof window > "u" ? new Error("No WebRTC support: Specify `opts.wrtc` option in this environment") : new Error("No WebRTC support: Not a supported browser"), "ERR_WEBRTC_SUPPORT");
            this._pcReady = !1, this._channelReady = !1, this._iceComplete = !1, this._iceCompleteTimer = null, this._channel = null, this._pendingCandidates = [], this._isNegotiating = !1, this._firstNegotiation = !0, this._batchedNegotiation = !1, this._queuedNegotiation = !1, this._sendersAwaitingStable = [], this._senderMap = /* @__PURE__ */ new Map(), this._closingInterval = null, this._remoteTracks = [], this._remoteStreams = [], this._chunk = null, this._cb = null, this._interval = null;
            try {
              this._pc = new this._wrtc.RTCPeerConnection(this.config);
            } catch (h) {
              return void this.destroy(c(h, "ERR_PC_CONSTRUCTOR"));
            }
            this._isReactNativeWebrtc = typeof this._pc._peerConnectionId == "number", this._pc.oniceconnectionstatechange = () => {
              this._onIceStateChange();
            }, this._pc.onicegatheringstatechange = () => {
              this._onIceStateChange();
            }, this._pc.onconnectionstatechange = () => {
              this._onConnectionStateChange();
            }, this._pc.onsignalingstatechange = () => {
              this._onSignalingStateChange();
            }, this._pc.onicecandidate = (h) => {
              this._onIceCandidate(h);
            }, typeof this._pc.peerIdentity == "object" && this._pc.peerIdentity.catch((h) => {
              this.destroy(c(h, "ERR_PC_PEER_IDENTITY"));
            }), this.initiator || this.channelNegotiated ? this._setupData({ channel: this._pc.createDataChannel(this.channelName, this.channelConfig) }) : this._pc.ondatachannel = (h) => {
              this._setupData(h);
            }, this.streams && this.streams.forEach((h) => {
              this.addStream(h);
            }), this._pc.ontrack = (h) => {
              this._onTrack(h);
            }, this._debug("initial negotiation"), this._needsNegotiation(), this._onFinishBound = () => {
              this._onFinish();
            }, this.once("finish", this._onFinishBound);
          }
          get bufferSize() {
            return this._channel && this._channel.bufferedAmount || 0;
          }
          get connected() {
            return this._connected && this._channel.readyState === "open";
          }
          address() {
            return { port: this.localPort, family: this.localFamily, address: this.localAddress };
          }
          signal(o) {
            if (!this.destroying) {
              if (this.destroyed) throw c(new Error("cannot signal after peer is destroyed"), "ERR_DESTROYED");
              if (typeof o == "string") try {
                o = JSON.parse(o);
              } catch {
                o = {};
              }
              this._debug("signal()"), o.renegotiate && this.initiator && (this._debug("got request to renegotiate"), this._needsNegotiation()), o.transceiverRequest && this.initiator && (this._debug("got request for transceiver"), this.addTransceiver(o.transceiverRequest.kind, o.transceiverRequest.init)), o.candidate && (this._pc.remoteDescription && this._pc.remoteDescription.type ? this._addIceCandidate(o.candidate) : this._pendingCandidates.push(o.candidate)), o.sdp && this._pc.setRemoteDescription(new this._wrtc.RTCSessionDescription(o)).then(() => {
                this.destroyed || (this._pendingCandidates.forEach((h) => {
                  this._addIceCandidate(h);
                }), this._pendingCandidates = [], this._pc.remoteDescription.type === "offer" && this._createAnswer());
              }).catch((h) => {
                this.destroy(c(h, "ERR_SET_REMOTE_DESCRIPTION"));
              }), o.sdp || o.candidate || o.renegotiate || o.transceiverRequest || this.destroy(c(new Error("signal() called with invalid signal data"), "ERR_SIGNALING"));
            }
          }
          _addIceCandidate(o) {
            const h = new this._wrtc.RTCIceCandidate(o);
            this._pc.addIceCandidate(h).catch((d) => {
              !h.address || h.address.endsWith(".local") ? u("Ignoring unsupported ICE candidate.") : this.destroy(c(d, "ERR_ADD_ICE_CANDIDATE"));
            });
          }
          send(o) {
            if (!this.destroying) {
              if (this.destroyed) throw c(new Error("cannot send after peer is destroyed"), "ERR_DESTROYED");
              this._channel.send(o);
            }
          }
          addTransceiver(o, h) {
            if (!this.destroying) {
              if (this.destroyed) throw c(new Error("cannot addTransceiver after peer is destroyed"), "ERR_DESTROYED");
              if (this._debug("addTransceiver()"), this.initiator) try {
                this._pc.addTransceiver(o, h), this._needsNegotiation();
              } catch (d) {
                this.destroy(c(d, "ERR_ADD_TRANSCEIVER"));
              }
              else this.emit("signal", { type: "transceiverRequest", transceiverRequest: { kind: o, init: h } });
            }
          }
          addStream(o) {
            if (!this.destroying) {
              if (this.destroyed) throw c(new Error("cannot addStream after peer is destroyed"), "ERR_DESTROYED");
              this._debug("addStream()"), o.getTracks().forEach((h) => {
                this.addTrack(h, o);
              });
            }
          }
          addTrack(o, h) {
            if (this.destroying) return;
            if (this.destroyed) throw c(new Error("cannot addTrack after peer is destroyed"), "ERR_DESTROYED");
            this._debug("addTrack()");
            const d = this._senderMap.get(o) || /* @__PURE__ */ new Map();
            let E = d.get(h);
            if (!E) E = this._pc.addTrack(o, h), d.set(h, E), this._senderMap.set(o, d), this._needsNegotiation();
            else throw E.removed ? c(new Error("Track has been removed. You should enable/disable tracks that you want to re-add."), "ERR_SENDER_REMOVED") : c(new Error("Track has already been added to that stream."), "ERR_SENDER_ALREADY_ADDED");
          }
          replaceTrack(o, h, d) {
            if (this.destroying) return;
            if (this.destroyed) throw c(new Error("cannot replaceTrack after peer is destroyed"), "ERR_DESTROYED");
            this._debug("replaceTrack()");
            const E = this._senderMap.get(o), g = E ? E.get(d) : null;
            if (!g) throw c(new Error("Cannot replace track that was never added."), "ERR_TRACK_NOT_ADDED");
            h && this._senderMap.set(h, E), g.replaceTrack == null ? this.destroy(c(new Error("replaceTrack is not supported in this browser"), "ERR_UNSUPPORTED_REPLACETRACK")) : g.replaceTrack(h);
          }
          removeTrack(o, h) {
            if (this.destroying) return;
            if (this.destroyed) throw c(new Error("cannot removeTrack after peer is destroyed"), "ERR_DESTROYED");
            this._debug("removeSender()");
            const d = this._senderMap.get(o), E = d ? d.get(h) : null;
            if (!E) throw c(new Error("Cannot remove track that was never added."), "ERR_TRACK_NOT_ADDED");
            try {
              E.removed = !0, this._pc.removeTrack(E);
            } catch (g) {
              g.name === "NS_ERROR_UNEXPECTED" ? this._sendersAwaitingStable.push(E) : this.destroy(c(g, "ERR_REMOVE_TRACK"));
            }
            this._needsNegotiation();
          }
          removeStream(o) {
            if (!this.destroying) {
              if (this.destroyed) throw c(new Error("cannot removeStream after peer is destroyed"), "ERR_DESTROYED");
              this._debug("removeSenders()"), o.getTracks().forEach((h) => {
                this.removeTrack(h, o);
              });
            }
          }
          _needsNegotiation() {
            this._debug("_needsNegotiation"), this._batchedNegotiation || (this._batchedNegotiation = !0, y(() => {
              this._batchedNegotiation = !1, this.initiator || !this._firstNegotiation ? (this._debug("starting batched negotiation"), this.negotiate()) : this._debug("non-initiator initial negotiation request discarded"), this._firstNegotiation = !1;
            }));
          }
          negotiate() {
            if (!this.destroying) {
              if (this.destroyed) throw c(new Error("cannot negotiate after peer is destroyed"), "ERR_DESTROYED");
              this.initiator ? this._isNegotiating ? (this._queuedNegotiation = !0, this._debug("already negotiating, queueing")) : (this._debug("start negotiation"), setTimeout(() => {
                this._createOffer();
              }, 0)) : this._isNegotiating ? (this._queuedNegotiation = !0, this._debug("already negotiating, queueing")) : (this._debug("requesting negotiation from initiator"), this.emit("signal", { type: "renegotiate", renegotiate: !0 })), this._isNegotiating = !0;
            }
          }
          destroy(o) {
            this._destroy(o, () => {
            });
          }
          _destroy(o, h) {
            this.destroyed || this.destroying || (this.destroying = !0, this._debug("destroying (error: %s)", o && (o.message || o)), y(() => {
              if (this.destroyed = !0, this.destroying = !1, this._debug("destroy (error: %s)", o && (o.message || o)), this.readable = this.writable = !1, this._readableState.ended || this.push(null), this._writableState.finished || this.end(), this._connected = !1, this._pcReady = !1, this._channelReady = !1, this._remoteTracks = null, this._remoteStreams = null, this._senderMap = null, clearInterval(this._closingInterval), this._closingInterval = null, clearInterval(this._interval), this._interval = null, this._chunk = null, this._cb = null, this._onFinishBound && this.removeListener("finish", this._onFinishBound), this._onFinishBound = null, this._channel) {
                try {
                  this._channel.close();
                } catch {
                }
                this._channel.onmessage = null, this._channel.onopen = null, this._channel.onclose = null, this._channel.onerror = null;
              }
              if (this._pc) {
                try {
                  this._pc.close();
                } catch {
                }
                this._pc.oniceconnectionstatechange = null, this._pc.onicegatheringstatechange = null, this._pc.onsignalingstatechange = null, this._pc.onicecandidate = null, this._pc.ontrack = null, this._pc.ondatachannel = null;
              }
              this._pc = null, this._channel = null, o && this.emit("error", o), this.emit("close"), h();
            }));
          }
          _setupData(o) {
            if (!o.channel) return this.destroy(c(new Error("Data channel event is missing `channel` property"), "ERR_DATA_CHANNEL"));
            this._channel = o.channel, this._channel.binaryType = "arraybuffer", typeof this._channel.bufferedAmountLowThreshold == "number" && (this._channel.bufferedAmountLowThreshold = P), this.channelName = this._channel.label, this._channel.onmessage = (d) => {
              this._onChannelMessage(d);
            }, this._channel.onbufferedamountlow = () => {
              this._onChannelBufferedAmountLow();
            }, this._channel.onopen = () => {
              this._onChannelOpen();
            }, this._channel.onclose = () => {
              this._onChannelClose();
            }, this._channel.onerror = (d) => {
              const E = d.error instanceof Error ? d.error : new Error(`Datachannel error: ${d.message} ${d.filename}:${d.lineno}:${d.colno}`);
              this.destroy(c(E, "ERR_DATA_CHANNEL"));
            };
            let h = !1;
            this._closingInterval = setInterval(() => {
              this._channel && this._channel.readyState === "closing" ? (h && this._onChannelClose(), h = !0) : h = !1;
            }, 5e3);
          }
          _read() {
          }
          _write(o, h, d) {
            if (this.destroyed) return d(c(new Error("cannot write after peer is destroyed"), "ERR_DATA_CHANNEL"));
            if (this._connected) {
              try {
                this.send(o);
              } catch (E) {
                return this.destroy(c(E, "ERR_DATA_CHANNEL"));
              }
              this._channel.bufferedAmount > P ? (this._debug("start backpressure: bufferedAmount %d", this._channel.bufferedAmount), this._cb = d) : d(null);
            } else this._debug("write before connect"), this._chunk = o, this._cb = d;
          }
          _onFinish() {
            if (!this.destroyed) {
              const o = () => {
                setTimeout(() => this.destroy(), 1e3);
              };
              this._connected ? o() : this.once("connect", o);
            }
          }
          _startIceCompleteTimeout() {
            this.destroyed || this._iceCompleteTimer || (this._debug("started iceComplete timeout"), this._iceCompleteTimer = setTimeout(() => {
              this._iceComplete || (this._iceComplete = !0, this._debug("iceComplete timeout completed"), this.emit("iceTimeout"), this.emit("_iceComplete"));
            }, this.iceCompleteTimeout));
          }
          _createOffer() {
            this.destroyed || this._pc.createOffer(this.offerOptions).then((o) => {
              if (this.destroyed) return;
              this.trickle || this.allowHalfTrickle || (o.sdp = m(o.sdp)), o.sdp = this.sdpTransform(o.sdp);
              const h = () => {
                if (!this.destroyed) {
                  const d = this._pc.localDescription || o;
                  this._debug("signal"), this.emit("signal", { type: d.type, sdp: d.sdp });
                }
              };
              this._pc.setLocalDescription(o).then(() => {
                this._debug("createOffer success"), this.destroyed || (this.trickle || this._iceComplete ? h() : this.once("_iceComplete", h));
              }).catch((d) => {
                this.destroy(c(d, "ERR_SET_LOCAL_DESCRIPTION"));
              });
            }).catch((o) => {
              this.destroy(c(o, "ERR_CREATE_OFFER"));
            });
          }
          _requestMissingTransceivers() {
            this._pc.getTransceivers && this._pc.getTransceivers().forEach((o) => {
              o.mid || !o.sender.track || o.requested || (o.requested = !0, this.addTransceiver(o.sender.track.kind));
            });
          }
          _createAnswer() {
            this.destroyed || this._pc.createAnswer(this.answerOptions).then((o) => {
              if (this.destroyed) return;
              this.trickle || this.allowHalfTrickle || (o.sdp = m(o.sdp)), o.sdp = this.sdpTransform(o.sdp);
              const h = () => {
                if (!this.destroyed) {
                  const d = this._pc.localDescription || o;
                  this._debug("signal"), this.emit("signal", { type: d.type, sdp: d.sdp }), this.initiator || this._requestMissingTransceivers();
                }
              };
              this._pc.setLocalDescription(o).then(() => {
                this.destroyed || (this.trickle || this._iceComplete ? h() : this.once("_iceComplete", h));
              }).catch((d) => {
                this.destroy(c(d, "ERR_SET_LOCAL_DESCRIPTION"));
              });
            }).catch((o) => {
              this.destroy(c(o, "ERR_CREATE_ANSWER"));
            });
          }
          _onConnectionStateChange() {
            this.destroyed || this._pc.connectionState === "failed" && this.destroy(c(new Error("Connection failed."), "ERR_CONNECTION_FAILURE"));
          }
          _onIceStateChange() {
            if (this.destroyed) return;
            const o = this._pc.iceConnectionState, h = this._pc.iceGatheringState;
            this._debug("iceStateChange (connection: %s) (gathering: %s)", o, h), this.emit("iceStateChange", o, h), (o === "connected" || o === "completed") && (this._pcReady = !0, this._maybeReady()), o === "failed" && this.destroy(c(new Error("Ice connection failed."), "ERR_ICE_CONNECTION_FAILURE")), o === "closed" && this.destroy(c(new Error("Ice connection closed."), "ERR_ICE_CONNECTION_CLOSED"));
          }
          getStats(o) {
            const h = (d) => (Object.prototype.toString.call(d.values) === "[object Array]" && d.values.forEach((E) => {
              Object.assign(d, E);
            }), d);
            this._pc.getStats.length === 0 || this._isReactNativeWebrtc ? this._pc.getStats().then((d) => {
              const E = [];
              d.forEach((g) => {
                E.push(h(g));
              }), o(null, E);
            }, (d) => o(d)) : 0 < this._pc.getStats.length ? this._pc.getStats((d) => {
              if (this.destroyed) return;
              const E = [];
              d.result().forEach((g) => {
                const T = {};
                g.names().forEach((M) => {
                  T[M] = g.stat(M);
                }), T.id = g.id, T.type = g.type, T.timestamp = g.timestamp, E.push(h(T));
              }), o(null, E);
            }, (d) => o(d)) : o(null, []);
          }
          _maybeReady() {
            if (this._debug("maybeReady pc %s channel %s", this._pcReady, this._channelReady), this._connected || this._connecting || !this._pcReady || !this._channelReady) return;
            this._connecting = !0;
            const o = () => {
              this.destroyed || this.getStats((h, d) => {
                if (this.destroyed) return;
                h && (d = []);
                const E = {}, g = {}, T = {};
                let M = !1;
                d.forEach((C) => {
                  (C.type === "remotecandidate" || C.type === "remote-candidate") && (E[C.id] = C), (C.type === "localcandidate" || C.type === "local-candidate") && (g[C.id] = C), (C.type === "candidatepair" || C.type === "candidate-pair") && (T[C.id] = C);
                });
                const b = (C) => {
                  M = !0;
                  let j = g[C.localCandidateId];
                  j && (j.ip || j.address) ? (this.localAddress = j.ip || j.address, this.localPort = +j.port) : j && j.ipAddress ? (this.localAddress = j.ipAddress, this.localPort = +j.portNumber) : typeof C.googLocalAddress == "string" && (j = C.googLocalAddress.split(":"), this.localAddress = j[0], this.localPort = +j[1]), this.localAddress && (this.localFamily = this.localAddress.includes(":") ? "IPv6" : "IPv4");
                  let U = E[C.remoteCandidateId];
                  U && (U.ip || U.address) ? (this.remoteAddress = U.ip || U.address, this.remotePort = +U.port) : U && U.ipAddress ? (this.remoteAddress = U.ipAddress, this.remotePort = +U.portNumber) : typeof C.googRemoteAddress == "string" && (U = C.googRemoteAddress.split(":"), this.remoteAddress = U[0], this.remotePort = +U[1]), this.remoteAddress && (this.remoteFamily = this.remoteAddress.includes(":") ? "IPv6" : "IPv4"), this._debug("connect local: %s:%s remote: %s:%s", this.localAddress, this.localPort, this.remoteAddress, this.remotePort);
                };
                if (d.forEach((C) => {
                  C.type === "transport" && C.selectedCandidatePairId && b(T[C.selectedCandidatePairId]), (C.type === "googCandidatePair" && C.googActiveConnection === "true" || (C.type === "candidatepair" || C.type === "candidate-pair") && C.selected) && b(C);
                }), !M && (!Object.keys(T).length || Object.keys(g).length)) return void setTimeout(o, 100);
                if (this._connecting = !1, this._connected = !0, this._chunk) {
                  try {
                    this.send(this._chunk);
                  } catch (j) {
                    return this.destroy(c(j, "ERR_DATA_CHANNEL"));
                  }
                  this._chunk = null, this._debug('sent chunk from "write before connect"');
                  const C = this._cb;
                  this._cb = null, C(null);
                }
                typeof this._channel.bufferedAmountLowThreshold != "number" && (this._interval = setInterval(() => this._onInterval(), 150), this._interval.unref && this._interval.unref()), this._debug("connect"), this.emit("connect");
              });
            };
            o();
          }
          _onInterval() {
            this._cb && this._channel && !(this._channel.bufferedAmount > P) && this._onChannelBufferedAmountLow();
          }
          _onSignalingStateChange() {
            this.destroyed || (this._pc.signalingState === "stable" && (this._isNegotiating = !1, this._debug("flushing sender queue", this._sendersAwaitingStable), this._sendersAwaitingStable.forEach((o) => {
              this._pc.removeTrack(o), this._queuedNegotiation = !0;
            }), this._sendersAwaitingStable = [], this._queuedNegotiation ? (this._debug("flushing negotiation queue"), this._queuedNegotiation = !1, this._needsNegotiation()) : (this._debug("negotiated"), this.emit("negotiated"))), this._debug("signalingStateChange %s", this._pc.signalingState), this.emit("signalingStateChange", this._pc.signalingState));
          }
          _onIceCandidate(o) {
            this.destroyed || (o.candidate && this.trickle ? this.emit("signal", { type: "candidate", candidate: { candidate: o.candidate.candidate, sdpMLineIndex: o.candidate.sdpMLineIndex, sdpMid: o.candidate.sdpMid } }) : !o.candidate && !this._iceComplete && (this._iceComplete = !0, this.emit("_iceComplete")), o.candidate && this._startIceCompleteTimeout());
          }
          _onChannelMessage(o) {
            if (this.destroyed) return;
            let h = o.data;
            h instanceof ArrayBuffer && (h = w.from(h)), this.push(h);
          }
          _onChannelBufferedAmountLow() {
            if (!this.destroyed && this._cb) {
              this._debug("ending backpressure: bufferedAmount %d", this._channel.bufferedAmount);
              const o = this._cb;
              this._cb = null, o(null);
            }
          }
          _onChannelOpen() {
            this._connected || this.destroyed || (this._debug("on channel open"), this._channelReady = !0, this._maybeReady());
          }
          _onChannelClose() {
            this.destroyed || (this._debug("on channel close"), this.destroy());
          }
          _onTrack(o) {
            this.destroyed || o.streams.forEach((h) => {
              this._debug("on track"), this.emit("track", o.track, h), this._remoteTracks.push({ track: o.track, stream: h }), this._remoteStreams.some((d) => d.id === h.id) || (this._remoteStreams.push(h), y(() => {
                this._debug("on stream"), this.emit("stream", h);
              }));
            });
          }
          _debug() {
            const o = [].slice.call(arguments);
            o[0] = "[" + this._id + "] " + o[0], S.apply(null, o);
          }
        }
        k.WEBRTC_SUPPORT = !!L(), k.config = { iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:global.stun.twilio.com:3478"] }], sdpSemantics: "unified-plan" }, k.channelConfig = {}, I.exports = k;
      }, { buffer: 3, debug: 4, "err-code": 6, "get-browser-rtc": 8, "queue-microtask": 13, randombytes: 14, "readable-stream": 29 }] }, {}, [])("/");
    });
  })(ut)), ut.exports;
}
var si = ii();
const oi = /* @__PURE__ */ rr(si), ai = (r, i) => {
  const l = Nt(r).buffer, O = Nt(i).buffer;
  return crypto.subtle.importKey(
    "raw",
    l,
    "PBKDF2",
    !1,
    ["deriveKey"]
  ).then(
    (N) => crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: O,
        iterations: 1e5,
        hash: "SHA-256"
      },
      N,
      {
        name: "AES-GCM",
        length: 256
      },
      !0,
      ["encrypt", "decrypt"]
    )
  );
}, pn = (r, i) => {
  if (!i)
    return (
      /** @type {PromiseLike<Uint8Array>} */
      Et(r)
    );
  const l = crypto.getRandomValues(new Uint8Array(12));
  return crypto.subtle.encrypt(
    {
      name: "AES-GCM",
      iv: l
    },
    i,
    r
  ).then((O) => {
    const N = ie();
    return wt(N, "AES-GCM"), Ne(N, l), Ne(N, new Uint8Array(O)), oe(N);
  });
}, ci = (r, i) => {
  const l = ie();
  return $n(l, r), pn(oe(l), i);
}, gn = (r, i) => {
  if (!i)
    return (
      /** @type {PromiseLike<Uint8Array>} */
      Et(r)
    );
  const l = vt(r);
  Ht(l) !== "AES-GCM" && nr(Xe("Unknown encryption algorithm"));
  const N = dt(l), _ = dt(l);
  return crypto.subtle.decrypt(
    {
      name: "AES-GCM",
      iv: N
    },
    i,
    _
  ).then((I) => new Uint8Array(I));
}, ui = (r, i) => gn(r, i).then(
  (l) => Bn(vt(new Uint8Array(l)))
), se = ni("y-webrtc"), Le = 0, yn = 3, $e = 1, At = 4, Ke = /* @__PURE__ */ new Map(), Re = /* @__PURE__ */ new Map(), bn = (r) => {
  let i = !0;
  r.webrtcConns.forEach((l) => {
    l.synced || (i = !1);
  }), (!i && r.synced || i && !r.synced) && (r.synced = i, r.provider.emit("synced", [{ synced: i }]), se("synced ", fe, r.name, De, " with all peers"));
}, mn = (r, i, l) => {
  const O = vt(i), N = ie(), _ = Kn(O);
  if (r === void 0)
    return null;
  const I = r.awareness, m = r.doc;
  let u = !1;
  switch (_) {
    case Le: {
      ae(N, Le);
      const S = Qn(O, N, m, r);
      S === Zn && !r.synced && l(), S === tr && (u = !0);
      break;
    }
    case yn:
      ae(N, $e), Ne(N, He(I, Array.from(I.getStates().keys()))), u = !0;
      break;
    case $e:
      Xn(I, dt(O), r);
      break;
    case At: {
      const S = Jn(O) === 1, L = Ht(O);
      if (L !== r.peerId && (r.bcConns.has(L) && !S || !r.bcConns.has(L) && S)) {
        const s = [], f = [];
        S ? (r.bcConns.add(L), f.push(L)) : (r.bcConns.delete(L), s.push(L)), r.provider.emit("peers", [{
          added: f,
          removed: s,
          webrtcPeers: Array.from(r.webrtcConns.keys()),
          bcPeers: Array.from(r.bcConns)
        }]), _n(r);
      }
      break;
    }
    default:
      return console.error("Unable to compute message"), N;
  }
  return u ? N : null;
}, li = (r, i) => {
  const l = r.room;
  return se("received message from ", fe, r.remotePeerId, kt, " (", l.name, ")", De, st), mn(l, i, () => {
    r.synced = !0, se("synced ", fe, l.name, De, " with ", fe, r.remotePeerId), bn(l);
  });
}, lt = (r, i) => {
  se("send message to ", fe, r.remotePeerId, De, kt, " (", r.room.name, ")", st);
  try {
    r.peer.send(oe(i));
  } catch {
  }
}, hi = (r, i) => {
  se("broadcast message in ", fe, r.name, De), r.webrtcConns.forEach((l) => {
    try {
      l.peer.send(i);
    } catch {
    }
  });
};
class Ut {
  /**
   * @param {SignalingConn} signalingConn
   * @param {boolean} initiator
   * @param {string} remotePeerId
   * @param {Room} room
   */
  constructor(i, l, O, N) {
    se("establishing connection to ", fe, O), this.room = N, this.remotePeerId = O, this.glareToken = void 0, this.closed = !1, this.connected = !1, this.synced = !1, this.peer = new oi({ initiator: l, ...N.provider.peerOpts }), this.peer.on("signal", (_) => {
      this.glareToken === void 0 && (this.glareToken = Date.now() + Math.random()), xt(i, N, { to: O, from: N.peerId, type: "signal", token: this.glareToken, signal: _ });
    }), this.peer.on("connect", () => {
      se("connected to ", fe, O), this.connected = !0;
      const I = N.provider.doc, m = N.awareness, u = ie();
      ae(u, Le), Vt(u, I), lt(this, u);
      const S = m.getStates();
      if (S.size > 0) {
        const L = ie();
        ae(L, $e), Ne(L, He(m, Array.from(S.keys()))), lt(this, L);
      }
    }), this.peer.on("close", () => {
      this.connected = !1, this.closed = !0, N.webrtcConns.has(this.remotePeerId) && (N.webrtcConns.delete(this.remotePeerId), N.provider.emit("peers", [{
        removed: [this.remotePeerId],
        added: [],
        webrtcPeers: Array.from(N.webrtcConns.keys()),
        bcPeers: Array.from(N.bcConns)
      }])), bn(N), this.peer.destroy(), se("closed connection to ", fe, O), yt(N);
    }), this.peer.on("error", (_) => {
      se("Error in connection to ", fe, O, ": ", _), yt(N);
    }), this.peer.on("data", (_) => {
      const I = li(this, _);
      I !== null && lt(this, I);
    });
  }
  destroy() {
    this.peer.destroy();
  }
}
const we = (r, i) => pn(i, r.key).then(
  (l) => r.mux(
    () => er(r.name, l)
  )
), Bt = (r, i) => {
  r.bcconnected && we(r, i), hi(r, i);
}, yt = (r) => {
  Ke.forEach((i) => {
    i.connected && (i.send({ type: "subscribe", topics: [r.name] }), r.webrtcConns.size < r.provider.maxConns && xt(i, r, { type: "announce", from: r.peerId }));
  });
}, _n = (r) => {
  if (r.provider.filterBcConns) {
    const i = ie();
    ae(i, At), Yt(i, 1), wt(i, r.peerId), we(r, oe(i));
  }
};
class fi {
  /**
   * @param {Y.Doc} doc
   * @param {WebrtcProvider} provider
   * @param {string} name
   * @param {CryptoKey|null} key
   */
  constructor(i, l, O, N) {
    this.peerId = hr(), this.doc = i, this.awareness = l.awareness, this.provider = l, this.synced = !1, this.name = O, this.key = N, this.webrtcConns = /* @__PURE__ */ new Map(), this.bcConns = /* @__PURE__ */ new Set(), this.mux = ri(), this.bcconnected = !1, this._bcSubscriber = (_) => gn(new Uint8Array(_), N).then(
      (I) => this.mux(() => {
        const m = mn(this, I, () => {
        });
        m && we(this, oe(m));
      })
    ), this._docUpdateHandler = (_, I) => {
      const m = ie();
      ae(m, Le), qn(m, _), Bt(this, oe(m));
    }, this._awarenessUpdateHandler = ({ added: _, updated: I, removed: m }, u) => {
      const S = _.concat(I).concat(m), L = ie();
      ae(L, $e), Ne(L, He(this.awareness, S)), Bt(this, oe(L));
    }, this._beforeUnloadHandler = () => {
      It(this.awareness, [i.clientID], "window unload"), Re.forEach((_) => {
        _.disconnect();
      });
    }, typeof window < "u" ? window.addEventListener("beforeunload", this._beforeUnloadHandler) : typeof process < "u" && process.on("exit", this._beforeUnloadHandler);
  }
  connect() {
    this.doc.on("update", this._docUpdateHandler), this.awareness.on("update", this._awarenessUpdateHandler), yt(this);
    const i = this.name;
    Wn(i, this._bcSubscriber), this.bcconnected = !0, _n(this);
    const l = ie();
    ae(l, Le), Vt(l, this.doc), we(this, oe(l));
    const O = ie();
    ae(O, Le), Hn(O, this.doc), we(this, oe(O));
    const N = ie();
    ae(N, yn), we(this, oe(N));
    const _ = ie();
    ae(_, $e), Ne(_, He(this.awareness, [this.doc.clientID])), we(this, oe(_));
  }
  disconnect() {
    Ke.forEach((l) => {
      l.connected && l.send({ type: "unsubscribe", topics: [this.name] });
    }), It(this.awareness, [this.doc.clientID], "disconnect");
    const i = ie();
    ae(i, At), Yt(i, 0), wt(i, this.peerId), we(this, oe(i)), Vn(this.name, this._bcSubscriber), this.bcconnected = !1, this.doc.off("update", this._docUpdateHandler), this.awareness.off("update", this._awarenessUpdateHandler), this.webrtcConns.forEach((l) => l.destroy());
  }
  destroy() {
    this.disconnect(), typeof window < "u" ? window.removeEventListener("beforeunload", this._beforeUnloadHandler) : typeof process < "u" && process.off("exit", this._beforeUnloadHandler);
  }
}
const di = (r, i, l, O) => {
  if (Re.has(l))
    throw Xe(`A Yjs Doc connected to room "${l}" already exists!`);
  const N = new fi(r, i, l, O);
  return Re.set(
    l,
    /** @type {Room} */
    N
  ), N;
}, xt = (r, i, l) => {
  i.key ? ci(l, i.key).then((O) => {
    r.send({ type: "publish", topic: i.name, data: zn(O) });
  }) : r.send({ type: "publish", topic: i.name, data: l });
};
class pi extends or {
  constructor(i) {
    super(i), this.providers = /* @__PURE__ */ new Set(), this.on("connect", () => {
      se(`connected (${i})`);
      const l = Array.from(Re.keys());
      this.send({ type: "subscribe", topics: l }), Re.forEach(
        (O) => xt(this, O, { type: "announce", from: O.peerId })
      );
    }), this.on("message", (l) => {
      switch (l.type) {
        case "publish": {
          const O = l.topic, N = Re.get(O);
          if (N == null || typeof O != "string")
            return;
          const _ = (I) => {
            const m = N.webrtcConns, u = N.peerId;
            if (I == null || I.from === u || I.to !== void 0 && I.to !== u || N.bcConns.has(I.from))
              return;
            const S = m.has(I.from) ? () => {
            } : () => N.provider.emit("peers", [{
              removed: [],
              added: [I.from],
              webrtcPeers: Array.from(N.webrtcConns.keys()),
              bcPeers: Array.from(N.bcConns)
            }]);
            switch (I.type) {
              case "announce":
                m.size < N.provider.maxConns && (ft(m, I.from, () => new Ut(this, !0, I.from, N)), S());
                break;
              case "signal":
                if (I.signal.type === "offer") {
                  const L = m.get(I.from);
                  if (L) {
                    const s = I.token, f = L.glareToken;
                    if (f && f > s) {
                      se("offer rejected: ", I.from);
                      return;
                    }
                    L.glareToken = void 0;
                  }
                }
                if (I.signal.type === "answer") {
                  se("offer answered by: ", I.from);
                  const L = m.get(I.from);
                  L.glareToken = void 0;
                }
                I.to === u && (ft(m, I.from, () => new Ut(this, !1, I.from, N)).peer.signal(I.signal), S());
                break;
            }
          };
          N.key ? typeof l.data == "string" && ui(Yn(l.data), N.key).then(_) : _(l.data);
        }
      }
    }), this.on("disconnect", () => se(`disconnect (${i})`));
  }
}
const ht = (r) => {
  r.emit("status", [{
    connected: r.connected
  }]);
};
class vi extends kn {
  /**
   * @param {string} roomName
   * @param {Y.Doc} doc
   * @param {ProviderOptions?} opts
   */
  constructor(i, l, {
    signaling: O = ["wss://y-webrtc-eu.fly.dev"],
    password: N = null,
    awareness: _ = new Gn(l),
    maxConns: I = 20 + _t(cr() * 15),
    // the random factor reduces the chance that n clients form a cluster
    filterBcConns: m = !0,
    peerOpts: u = {}
    // simple-peer options. See https://github.com/feross/simple-peer#peer--new-peeropts
  } = {}) {
    super(), this.roomName = i, this.doc = l, this.filterBcConns = m, this.awareness = _, this.shouldConnect = !1, this.signalingUrls = O, this.signalingConns = [], this.maxConns = I, this.peerOpts = u, this.key = N ? ai(N, i) : (
      /** @type {PromiseLike<null>} */
      Et(null)
    ), this.room = null, this.key.then((S) => {
      this.room = di(l, this, i, S), this.shouldConnect ? this.room.connect() : this.room.disconnect(), ht(this);
    }), this.connect(), this.destroy = this.destroy.bind(this), l.on("destroy", this.destroy);
  }
  /**
   * Indicates whether the provider is looking for other peers.
   *
   * Other peers can be found via signaling servers or via broadcastchannel (cross browser-tab
   * communication). You never know when you are connected to all peers. You also don't know if
   * there are other peers. connected doesn't mean that you are connected to any physical peers
   * working on the same resource as you. It does not change unless you call provider.disconnect()
   *
   * `this.on('status', (event) => { console.log(event.connected) })`
   *
   * @type {boolean}
   */
  get connected() {
    return this.room !== null && this.shouldConnect;
  }
  connect() {
    this.shouldConnect = !0, this.signalingUrls.forEach((i) => {
      const l = ft(Ke, i, () => new pi(i));
      this.signalingConns.push(l), l.providers.add(this);
    }), this.room && (this.room.connect(), ht(this));
  }
  disconnect() {
    this.shouldConnect = !1, this.signalingConns.forEach((i) => {
      i.providers.delete(this), i.providers.size === 0 && (i.destroy(), Ke.delete(i.url));
    }), this.room && (this.room.disconnect(), ht(this));
  }
  destroy() {
    this.doc.off("destroy", this.destroy), this.key.then(() => {
      this.room.destroy(), Re.delete(this.roomName);
    }), super.destroy();
  }
}
export {
  fi as Room,
  pi as SignalingConn,
  Ut as WebrtcConn,
  vi as WebrtcProvider
};
//# sourceMappingURL=y-webrtc-BRK-1-Tt.mjs.map
