import { readTextEditorRuntimeHostCompositionForTargetV2 as t, readTextEditorRuntimeHostCompositionV2 as i } from "#runtime-host-state";
export {
  t as readTextEditorRuntimeHostCompositionForTargetV2,
  i as readTextEditorRuntimeHostCompositionV2
};
//# sourceMappingURL=runtime-host-registry.mjs.map
