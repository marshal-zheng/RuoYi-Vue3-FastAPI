import { e as c, A as pe, F as ke, I as es, K as $i, G as Br, c as sa, i as Wr, M as oa, N as ts } from "./actions-Sd62WBGv.mjs";
import { x as Kt, l as aa, C as kr } from "./runtime-plugin-definitions-DN_cDAJZ.mjs";
import { au as Ue, ag as ca, ah as da, as as Sr, b4 as rs, b5 as Gi, Q as Te, b6 as is, b7 as rt, b8 as it, b9 as ns, G as Wi, ba as Yi, bb as si, bc as fr, bd as Zr, be as Lt, bf as la, B as oi, bg as pa, s as ua, bh as ss, bi as os, o as Xi, bj as fa, bk as ga, bl as as, bm as ji, v as Zi, p as cs, y as ds, O as ls, I as Ar, aG as ma, L as va, M as ha, u as ya, S as Ia, at as Le, aY as ae, aZ as ne, bn as ps, K as or, aT as ye, aV as P, aU as C, bo as Se, aO as pt, aW as ai, aS as B, aP as Ge, bp as ba, a_ as Ct, aN as Fa, aQ as ar, N as xa, bq as Er, a$ as us, br as wa, e as ci, d as Di, Z as fs, a as gs, Y as Ra, av as ka, _ as ms, aK as xn, aJ as wn, a0 as Sa, aL as Aa, a3 as Ea, bs as Ca, bt as Rn, bu as qa, bv as Ta } from "./yjs-adapter-CNLpxPX5.mjs";
import { f as re, d as Ve, h as Y, j as U, e as X, l as ht, c as Ji, L as Jr, J as Ba, k as Qt, a as Ot, b as Pa, w as vs, P as Mt, M as $a } from "./inline-ai-shortcut-router-a-QG5h2e.mjs";
import { h as kn, e as ja } from "./projection-r_4Na96h.mjs";
import * as Nt from "yjs";
import { prosemirrorJSONToYXmlFragment as Da } from "y-prosemirror";
const Ut = (e, t, r, i) => c({
  status: "unavailable",
  profileRef: e,
  sourceBinding: t,
  reason: r,
  safeDiagnostic: {
    code: i,
    stage: "derived-view",
    path: "$.derivedView",
    componentId: e.id
  }
}), za = (e) => c({ ...e.profileRef, dependencies: [] }), fu = (e) => {
  if (!e || typeof e != "object" || !e.profileRef || typeof e.profileRef != "object" || !e.execution || typeof e.execution != "object" || e.execution.status !== "success" || !e.execution.runtime || !e.execution.trace)
    return Ut(
      Kt,
      c({
        executionSemanticsFingerprint: "sha256:unavailable",
        resultFingerprint: "sha256:unavailable",
        traceFingerprint: "sha256:unavailable"
      }),
      "unsupported-runtime",
      "runtime-component-unsupported"
    );
  const t = e.execution, r = c({
    executionSemanticsFingerprint: t.runtime.executionSemanticsFingerprint,
    resultFingerprint: t.resultFingerprint,
    traceFingerprint: t.trace.fingerprint
  });
  if (!(e.profileRef.kind === Kt.kind && e.profileRef.id === Kt.id && e.profileRef.version === Kt.version && e.profileRef.fingerprint === Kt.fingerprint))
    return Ut(
      za(e),
      r,
      "profile-not-installed",
      "runtime-component-unsupported"
    );
  const n = Kt;
  if (t.runtime.executionSemanticsFingerprint !== aa.fingerprints.executionSemanticsFingerprint)
    return Ut(
      n,
      r,
      "unsupported-runtime",
      "runtime-component-unsupported"
    );
  if (!Object.isFrozen(t) || !Object.isFrozen(t.resultDocument) || !Object.isFrozen(t.trace))
    return Ut(
      n,
      r,
      "derivation-failed",
      "runtime-fingerprint-mismatch"
    );
  const { fingerprint: s, ...o } = t.trace;
  if (pe(t.resultDocument) !== t.resultFingerprint || pe(o) !== t.trace.fingerprint || t.trace.resultFingerprint !== t.resultFingerprint)
    return Ut(
      n,
      r,
      "derivation-failed",
      "runtime-fingerprint-mismatch"
    );
  if (new TextEncoder().encode(
    ke({
      runtime: t.runtime,
      result: t.resultDocument,
      trace: t.trace
    })
  ).byteLength > 8e6)
    return Ut(
      n,
      r,
      "resource-limit-exceeded",
      "trace-byte-budget-exceeded"
    );
  const d = c({
    transactionCount: t.trace.entries.length,
    stepCount: t.trace.entries.reduce(
      (g, u) => g + u.steps.length,
      0
    ),
    annotationCount: t.mapping.annotations.length
  }), l = pe({ profile: n, sourceBinding: r, value: d });
  return c({
    status: "available",
    profileRef: n,
    sourceBinding: r,
    value: d,
    fingerprint: l
  });
};
c({
  fineDiffAvailable: !1,
  hunkPartialAccept: !1,
  operationPartialAccept: !1,
  hunkPartialReject: !1,
  operationPartialReject: !1,
  wholeProposalAcceptWithoutIndependentWholeReview: !1,
  allowedWithoutIndependentWholeReview: ["reject", "regenerate"],
  owner: "S4-versioned-review-policy"
});
const gu = (e) => {
  const t = /* @__PURE__ */ new Map();
  return {
    isolated: !0,
    async run(r) {
      if (t.has(r.executionId))
        return c({ status: "failure", canonicalOutput: null });
      const i = e.open(r.component);
      if (!i)
        return c({ status: "failure", canonicalOutput: null });
      t.set(r.executionId, i);
      let n, s = !1;
      const o = () => {
        s || (s = !0, i.terminate());
      };
      try {
        const a = await Promise.race([
          i.execute({
            canonicalInput: r.canonicalInput,
            resourceProfileFingerprint: r.resourceProfileFingerprint,
            maxOutputBytes: r.maxOutputBytes
          }).then(
            (d) => d.byteLength <= r.maxOutputBytes ? { status: "success", canonicalOutput: d } : { status: "over-limit", canonicalOutput: null }
          ),
          new Promise((d) => {
            n = setTimeout(() => {
              o(), d({ status: "timeout", canonicalOutput: null });
            }, r.timeoutMs);
          })
        ]);
        return a.status !== "success" && o(), c(a);
      } catch {
        return o(), c({ status: "failure", canonicalOutput: null });
      } finally {
        n !== void 0 && clearTimeout(n), t.delete(r.executionId);
      }
    },
    terminate(r) {
      var i;
      (i = t.get(r)) == null || i.terminate(), t.delete(r);
    }
  };
}, mu = c([
  {
    repository: "BlockNote",
    commit: "4e9e785530ff4c173f876fcac09cf334fe61b5dc",
    paths: [
      "packages/core/src/yjs/extensions/ForkYDoc.ts",
      "packages/core/src/yjs/extensions/ForkYDoc.test.ts",
      "packages/xl-ai/src/prosemirror/changeset.ts",
      "packages/xl-ai/src/prosemirror/changeset.test.ts"
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "isolation and discard invariants only; proposal execution remains Runtime v2-owned",
        fixtureIds: ["REF-BN-ISOLATE-01"]
      },
      {
        decision: "adapt",
        boundary: "marks, attrs and table cases become derived-view fixtures without execution authority",
        fixtureIds: ["REF-BN-DIFF-MARK-03", "REF-BN-DIFF-TABLE-04"]
      },
      {
        decision: "reject",
        boundary: "Yjs fork and merge belong to S7 collaboration authority",
        fixtureIds: ["REF-BN-YJS-REJECT-02"]
      }
    ]
  },
  {
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    paths: [
      "packages/ai/src/lib/transforms/aiStreamSnapshot.ts",
      "packages/ai/src/lib/transforms/aiStreamSnapshot.spec.ts",
      "packages/ai/src/lib/transforms/diffToSuggestions.ts"
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "snapshot, zero-write, batch and granularity cases are pure proposal fixtures",
        fixtureIds: ["REF-PLATE-ZERO-WRITE-01", "REF-PLATE-DIFF-02"]
      },
      {
        decision: "reject",
        boundary: "Slate, React and review ownership remain outside S3",
        fixtureIds: ["REF-PLATE-REVIEW-REJECT-03"]
      }
    ]
  },
  {
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    paths: [
      "apps/web/components/tailwind/generative/ai-completion-command.tsx",
      "apps/web/components/tailwind/generative/ai-selector-commands.tsx"
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "generate, replace, regenerate and discard cadence uses public plan to Runtime to proposal APIs",
        fixtureIds: ["REF-NOVEL-FLOW-01"]
      },
      {
        decision: "reject",
        boundary: "React, provider SDK and direct editor writes are forbidden",
        fixtureIds: ["REF-NOVEL-DIRECT-WRITE-REJECT-02"]
      }
    ]
  }
]), vu = "1.0.0", Oa = [
  "eval",
  ["Func", "tion"].join(""),
  ["Web", "Assembly"].join(""),
  ["Editor", "View"].join(""),
  ["Editor", "State"].join(""),
  ["Node", "View"].join(""),
  ["Y", "Doc"].join("."),
  "fetch",
  ["XML", "HttpRequest"].join("")
], Na = (e) => Oa.some((t) => e.includes(t)) || /import\s*\(/.test(e), _a = (e) => {
  if (!Sr(e.id) || !Sr(e.version) || !Sr(e.nodeType) || e.operations === null || Object.keys(e.operations).length === 0 || Object.entries(e.operations).some(
    ([t, r]) => t !== r.name || r.limits.nodeBudget.kind !== "custom" || [
      r.decodePayload,
      r.validate,
      r.validatePartial,
      r.deriveReview
    ].filter(Boolean).some(
      (i) => Na(
        Function.prototype.toString.call(i)
      )
    )
  ))
    throw new TypeError("complex-custom-admission-denied");
}, hu = (e) => {
  _a(e);
  const t = da({
    id: e.id,
    version: e.version,
    descriptor: e.descriptor,
    descriptorFingerprint: e.descriptorFingerprint,
    nodeType: e.nodeType,
    schemaJoinKey: e.schemaJoinKey,
    schemaFingerprint: e.schemaFingerprint,
    provenanceFingerprint: e.provenanceFingerprint,
    family: "custom",
    hostAdmission: e.hostAdmission,
    dependencies: e.dependencies,
    address: e.address,
    operations: e.operations
  });
  if (t.component.fingerprint !== e.componentFingerprint)
    throw new TypeError("complex-custom-admission-denied");
  return t;
}, yu = (e, t) => Ue("component-ref", {
  id: `${e}.component`,
  version: t
}), Iu = c(ca.custom), bu = "1.0.0", Fu = (e, t, r = "1.0.0") => ({
  id: e,
  version: r,
  fingerprint: re("zx-ai-writing-artifact:v1", {
    id: e,
    version: r,
    value: t
  })
}), hs = (e) => {
  if (!Y(e, [
    "profileVersion",
    "parameterSchemaRef",
    "contextPolicyRef",
    "templateRef",
    "resultPolicyRef",
    "languagePolicy",
    "generationDefaults"
  ]) || e.profileVersion !== "1.0.0" || e.languagePolicy !== "explicit-document-prompt-ui")
    return !1;
  for (const r of [
    "parameterSchemaRef",
    "contextPolicyRef",
    "templateRef",
    "resultPolicyRef"
  ]) {
    const i = e[r];
    if (!Y(i, ["id", "version", "fingerprint"]) || !U(i.id) || !U(i.version) || !X(i.fingerprint))
      return !1;
  }
  const t = e.generationDefaults;
  return Y(t, [
    "inputBudgetTokens",
    "maxOutputTokens",
    "temperature"
  ]) && Number.isSafeInteger(t.inputBudgetTokens) && Number(t.inputBudgetTokens) > 0 && Number(t.inputBudgetTokens) <= 128e3 && Number.isSafeInteger(t.maxOutputTokens) && Number(t.maxOutputTokens) > 0 && Number(t.maxOutputTokens) <= 8192 && typeof t.temperature == "number" && Number.isFinite(t.temperature) && t.temperature >= 0 && t.temperature <= 2;
}, La = (e, t) => {
  if (!Y(
    e,
    [],
    [
      "instruction",
      "language",
      ...t.depth ? ["depth"] : [],
      ...t.ideaCount ? ["ideaCount"] : []
    ]
  ))
    throw new TypeError("writing-parameters-invalid");
  const r = e.instruction ?? "";
  if (!ht(r, 4e3) || e.language !== void 0 && (typeof e.language != "string" || !/^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8}){0,3}$/.test(e.language)))
    throw new TypeError("writing-parameters-invalid");
  const i = {
    instruction: r,
    ...e.language ? { language: e.language } : {}
  };
  for (const n of ["depth", "ideaCount"]) {
    const s = t[n];
    if (!s) continue;
    const o = e[n] ?? s.default;
    if (!Number.isSafeInteger(o) || Number(o) < s.min || Number(o) > s.max)
      throw new TypeError("writing-parameters-invalid");
    i[n] = o;
  }
  return Ve(i);
}, xu = (e) => Ve({
  ...e,
  fingerprint: re(
    "zx-ai-writing-execution:v1",
    e
  )
}), Cr = (e) => Number.isSafeInteger(e) && Number(e) >= 0, Sn = (e) => ht(e.counterId, 128) && Cr(e.estimatedTokens) && Cr(e.limitTokens) && e.estimatedTokens <= e.limitTokens, Va = (e) => {
  if (!Y(e, [
    "target",
    "ceiling",
    "serializedBytes",
    "limitingConstraint"
  ]) || !Y(e.target, [
    "counterId",
    "estimatedTokens",
    "limitTokens",
    "uncalibratedTokens",
    "calibration"
  ]) || !Y(e.ceiling, [
    "counterId",
    "estimatedTokens",
    "limitTokens"
  ]) || !Y(e.target.calibration, ["factor", "samples"]))
    return !1;
  const { factor: t, samples: r } = e.target.calibration;
  return Sn(e.target) && Sn(e.ceiling) && Cr(e.target.uncalibratedTokens) && typeof t == "number" && Number.isFinite(t) && t > 0 && Cr(r) && Cr(e.serializedBytes) && ["none", "target", "ceiling", "bytes"].includes(
    String(e.limitingConstraint)
  );
}, Ha = (e) => {
  if (!Y(e, [
    "kind",
    "commandId",
    "descriptorFingerprint",
    "profile",
    "parameters",
    "sourceRevision",
    "sourceDocumentFingerprint",
    "targetFingerprint",
    "contextFingerprint",
    "language",
    "compiledRequest",
    "fingerprint"
  ]) || e.kind !== "zx-ai-writing-execution-v1" || !U(e.commandId) || !ht(e.sourceRevision, 256) || !hs(e.profile) || !Y(
    e.parameters,
    ["instruction"],
    ["language", "depth", "ideaCount"]
  ) || !Y(e.language, ["language", "reason"]) || !ht(e.language.language, 64) || !["explicit", "document", "instruction", "locale"].includes(
    String(e.language.reason)
  ))
    return !1;
  for (const r of [
    "descriptorFingerprint",
    "sourceDocumentFingerprint",
    "targetFingerprint",
    "contextFingerprint",
    "fingerprint"
  ])
    if (!X(e[r])) return !1;
  const t = e.compiledRequest;
  if (!Y(t, [
    "kind",
    "messages",
    "outputFormat",
    "resultKind",
    "model",
    "maxOutputTokens",
    "temperature",
    "budget",
    "fingerprint"
  ]) || t.kind !== "zx-ai-compiled-writing-request-v1" || !Array.isArray(t.messages) || t.messages.length < 1 || t.messages.length > 32 || !t.messages.every(
    (r) => Y(r, ["role", "content"]) && ["system", "user", "assistant"].includes(String(r.role)) && ht(r.content, 131072)
  ) || !["message-only", "operation-envelope"].includes(
    String(t.resultKind)
  ) || !["prose", "nested-list", "numbered-list"].includes(
    String(t.outputFormat)
  ) || !U(t.model) || t.maxOutputTokens !== e.profile.generationDefaults.maxOutputTokens || t.temperature !== e.profile.generationDefaults.temperature || !Va(t.budget))
    return !1;
  try {
    La(e.parameters, {
      id: "execution-validation",
      version: "1.0.0",
      ...Object.hasOwn(e.parameters, "depth") ? { depth: { min: 1, max: 3, default: 2 } } : {},
      ...Object.hasOwn(e.parameters, "ideaCount") ? { ideaCount: { min: 1, max: 10, default: 5 } } : {}
    });
    const r = Ve(
      e
    );
    return Ji(r) <= 128 * 1024 && r.compiledRequest.fingerprint === re(
      "zx-ai-compiled-writing-request:v1",
      Jr(r.compiledRequest)
    ) && r.fingerprint === re(
      "zx-ai-writing-execution:v1",
      Jr(r)
    );
  } catch {
    return !1;
  }
}, wu = c({
  "continue-prose-v1": {
    format: "prose",
    modes: ["inline-at-caret", "display-only"]
  },
  "outline-list-v1": {
    format: "nested-list",
    modes: ["blocks-at-anchor", "display-only"]
  },
  "brainstorm-list-v1": {
    format: "numbered-list",
    modes: ["blocks-at-anchor", "display-only"]
  }
}), Ka = (e) => ({
  type: "paragraph",
  content: e.split(/\r?\n/).flatMap((t, r) => [
    ...r > 0 ? [{ type: "hardBreak" }] : [],
    ...t ? [{ type: "text", text: t }] : []
  ])
}), ys = /* @__PURE__ */ new Set(["bulletList", "orderedList"]), Ma = /* @__PURE__ */ new Set([
  "paragraph",
  "bulletList",
  "orderedList",
  "listItem",
  "text",
  "hardBreak"
]), Ua = /* @__PURE__ */ new Set(["bold", "italic", "strike", "code"]), Is = (e) => {
  var r;
  if (!Ma.has(e.type ?? "")) throw new Error("unsupported-node");
  const t = (r = e.marks) == null ? void 0 : r.map((i) => {
    var n;
    if (Ua.has(i.type)) return { type: i.type };
    if (i.type === "link" && typeof ((n = i.attrs) == null ? void 0 : n.href) == "string" && /^(https?:\/\/|mailto:|#)/i.test(i.attrs.href))
      return { type: "link", attrs: { href: i.attrs.href } };
    throw new Error("unsupported-mark");
  });
  return {
    type: e.type,
    ...e.text !== void 0 ? { text: e.text } : {},
    ...t != null && t.length ? { marks: t } : {},
    ...e.content ? { content: e.content.map(Is) } : {},
    ...e.type === "orderedList" ? { attrs: { start: 1 } } : {}
  };
}, bs = (e) => (ys.has(e.type ?? "") ? 1 : 0) + Math.max(0, ...(e.content ?? []).map(bs)), Fs = (e) => e.text ?? (e.content ?? []).map(Fs).join(" "), Ru = (e) => {
  var i, n, s;
  if (e.completion !== "complete")
    return { status: "invalid", reason: "incomplete-result" };
  if (!e.text.trim()) return { status: "invalid", reason: "empty-result" };
  let t;
  if (e.policy.format === "prose")
    t = e.text.split(/\r?\n\r?\n/).map(Ka);
  else {
    try {
      t = (e.markdown.parse(e.text).content ?? []).map(
        Is
      );
    } catch {
      return { status: "invalid", reason: "invalid-structure" };
    }
    if (!t.length || t.some((o) => !ys.has(o.type ?? "")))
      return { status: "invalid", reason: "invalid-structure" };
    if (e.policy.format === "nested-list" && ((i = e.parameters) == null ? void 0 : i.depth) !== void 0 && Math.max(...t.map(bs)) > e.parameters.depth)
      return { status: "invalid", reason: "outline-depth-exceeded" };
    if (e.policy.format === "numbered-list") {
      if (t.length !== 1 || t[0].type !== "orderedList")
        return { status: "invalid", reason: "invalid-structure" };
      if (((n = e.parameters) == null ? void 0 : n.ideaCount) !== void 0 && ((s = t[0].content) == null ? void 0 : s.length) !== e.parameters.ideaCount)
        return { status: "invalid", reason: "idea-count-mismatch" };
      const o = (t[0].content ?? []).map(
        (a) => Fs(a).trim().replace(/\s+/g, " ").toLowerCase()
      );
      if (o.some((a) => !a))
        return { status: "invalid", reason: "invalid-structure" };
      if (new Set(o).size !== o.length)
        return { status: "invalid", reason: "duplicate-ideas" };
    }
  }
  const r = {
    binding: e.binding,
    policy: e.policy,
    completion: "complete",
    candidateDigest: re(
      "zx-ai-writing-candidate:v1",
      e.text
    ),
    text: e.text,
    content: t
  };
  return {
    status: "valid",
    result: c({
      ...r,
      fingerprint: re(
        "zx-ai-writing-result:v1",
        r
      )
    })
  };
}, ku = (e) => e.result.policy.modes.includes(e.mode) ? {
  status: "ready",
  plan: c({
    ...e,
    fingerprint: re(
      "zx-ai-writing-application:v1",
      e
    )
  })
} : { status: "unsupported", reason: "mode-unavailable" }, Ga = Object.freeze({
  changedContextBlocks: 0,
  removedContextBlocks: 0,
  insertedBlocksInContext: 0,
  changedSummaryBlocks: 0
}), Wa = () => new Set(
  es.flatMap(
    (e) => Object.entries(e.ai.nodes).filter(
      ([, t]) => t.supported && t.addressability === "block"
    ).map(([t]) => t)
  )
), Pr = (e, t) => {
  var r;
  return (r = e.get(t)) == null ? void 0 : r.textSegments.map((i) => i.node.text ?? `
`).join("");
}, An = (e, t, r) => {
  var i, n;
  return ((i = e.get(r)) == null ? void 0 : i.nodeType) === ((n = t.get(r)) == null ? void 0 : n.nodeType) && Pr(e, r) === Pr(t, r);
}, Ya = /^[\uD800-\uDBFF][\uDC00-\uDFFF]$/, Rr = (e, t) => t <= 0 || t >= e.length || !Ya.test(e.slice(t - 1, t + 1)), Xa = (e, t, r) => {
  let i = 0;
  const n = Math.min(e.length, t.length);
  for (; i < n && e[i] === t[i]; ) i += 1;
  for (; i > 0 && !(Rr(e, i) && Rr(t, i)); )
    i -= 1;
  let s = 0;
  const o = n - i;
  for (; s < o && e[e.length - 1 - s] === t[t.length - 1 - s]; )
    s += 1;
  for (; s > 0 && !(Rr(e, e.length - s) && Rr(t, t.length - s)); )
    s -= 1;
  const a = e.length - s, d = t.length - s;
  return r < i ? { offset: r, removedBefore: "" } : r > a ? {
    offset: r + t.length - e.length,
    removedBefore: ""
  } : i === a ? { offset: d, removedBefore: "" } : r === i ? { offset: i, removedBefore: "" } : r === a ? { offset: d, removedBefore: e.slice(i, a) } : null;
}, xs = (e) => [...e.keys()], Za = (e, t, r, i) => {
  var a, d;
  const n = xs(t), s = /* @__PURE__ */ new Set();
  for (let l = ((a = t.get(r)) == null ? void 0 : a.parentBlockId) ?? null; l; l = ((d = t.get(l)) == null ? void 0 : d.parentBlockId) ?? null)
    s.add(l);
  const o = (l) => {
    for (let g = n.indexOf(r) + l; g >= 0 && g < n.length; g += l)
      if (!s.has(n[g])) return n[g];
  };
  return [o(-1), o(1)].some(
    (l) => l !== void 0 && !e.has(l) && Pr(t, l).includes(i)
  );
}, Su = (e) => {
  let t, r;
  try {
    const v = Wa();
    t = kn(e.baseDocument, v), r = kn(e.liveDocument, v);
  } catch {
    return { status: "anchor-lost", summary: Ga };
  }
  const i = /* @__PURE__ */ new Set([e.anchor.blockId]), n = /* @__PURE__ */ new Set();
  for (const v of e.contextWindow.segments)
    for (const F of v.spans)
      (v.completeness === "summary" ? n : i).add(
        F.blockId
      );
  i.forEach((v) => n.delete(v));
  const s = [...i].filter(
    (v) => t.has(v) && !r.has(v)
  ), o = [...i].filter(
    (v) => t.has(v) && r.has(v)
  ), a = new Set(
    o.filter((v) => !An(t, r, v))
  ), d = (v) => [...o].sort(
    (F, w) => v.get(F).order - v.get(w).order
  ), l = d(r);
  d(t).forEach((v, F) => {
    l[F] !== v && a.add(v);
  });
  const g = (v) => {
    if (o.length === 0) return [];
    const F = o.map((w) => v.get(w).order);
    return xs(v).slice(Math.min(...F), Math.max(...F) + 1);
  }, u = new Set(g(t)), p = g(r).filter((v) => !u.has(v)), f = {
    changedContextBlocks: a.size,
    removedContextBlocks: s.length,
    insertedBlocksInContext: p.length,
    changedSummaryBlocks: [...n].filter(
      (v) => t.has(v) && (!r.has(v) || !An(t, r, v))
    ).length
  }, m = Pr(t, e.anchor.blockId), y = Pr(r, e.anchor.blockId);
  if (m === void 0 || y === void 0 || !Number.isInteger(e.anchor.offset) || e.anchor.offset < 0 || e.anchor.offset > m.length || !Rr(m, e.anchor.offset))
    return { status: "anchor-lost", summary: f };
  const I = Xa(m, y, e.anchor.offset);
  return !I || I.removedBefore && Za(
    t,
    r,
    e.anchor.blockId,
    I.removedBefore
  ) ? { status: "anchor-lost", summary: f } : {
    status: s.length > 0 || a.size > 0 || p.length > 0 ? "context-changed" : "shifted",
    anchor: { blockId: e.anchor.blockId, offset: I.offset },
    summary: f
  };
}, nt = "1.0.0", N = c({
  maxBytes: 2e6,
  maxDepth: 64,
  maxArrayEntries: 8e3,
  maxObjectKeys: 48,
  maxTotalObjectKeys: 8e4,
  maxRequests: 32,
  maxAttempts: 64,
  maxEventsPerAttempt: 2048,
  maxChunkBytes: 4096,
  maxProjectionTextBytes: 64e3,
  maxProjectionSegments: 256,
  maxToolSummaries: 64,
  maxAuditEntries: 2048,
  maxCheckpointBytes: 512e3,
  maxDiagnostics: 32,
  maxRetries: 3,
  maxHandoffs: 32,
  maxIdLength: 160,
  maxDiagnosticPathLength: 240,
  maxLogicalDuration: 86400
}), qr = c({
  id: "zx.ai.session-policy",
  version: nt,
  limits: N,
  retryableTerminalReasons: [
    "transport-failed",
    "transport-disconnected",
    "resource-exceeded",
    "malformed"
  ],
  resumeCapability: "resume:same-attempt-checkpoint-v1",
  oneActiveRequest: !0
}), qe = c({
  id: qr.id,
  version: qr.version,
  fingerprint: pe({
    domain: "zx-ai-session/v1/policy",
    value: qr
  })
}), En = c({
  maxBytes: N.maxBytes,
  maxDepth: N.maxDepth,
  maxArrayEntries: N.maxArrayEntries,
  maxObjectKeys: N.maxObjectKeys,
  maxTotalObjectKeys: N.maxTotalObjectKeys
}), Ja = /* @__PURE__ */ new Set([
  "editor",
  "view",
  "state",
  "transaction",
  "dispatch",
  "abortController",
  "signal",
  "socket",
  "websocket",
  "fetch",
  "client",
  "sdk",
  "apiKey",
  "secret",
  "token",
  "password",
  "callback",
  "onChunk",
  "onFinish"
]), ws = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), T = (e, t, r = []) => ws(e) && t.every((i) => Object.hasOwn(e, i)) && Object.keys(e).every(
  (i) => t.includes(i) || r.includes(i)
), _t = (e) => typeof e == "string" && e.trim().length > 0, L = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, q = (e) => typeof e == "string" && e.length > 0 && e.length <= N.maxIdLength && /^[A-Za-z0-9_.:-]+$/.test(e), Pe = (e) => typeof e == "string" && e.length > 7 && e.length <= N.maxIdLength * 2 && /^sha256:[A-Za-z0-9_.:-]+$/.test(e), fe = (e, t) => pe({ domain: e, value: t }), Ae = (e) => {
  Ba(e, En);
  const { canonical: t } = Br(
    e,
    En
  );
  return c(JSON.parse(t));
}, Rs = (e, t) => {
  try {
    return ke(e) === ke(t);
  } catch {
    return !1;
  }
}, Qa = (e) => new TextEncoder().encode(ke(e)).byteLength, be = (e) => {
  const { fingerprint: t, ...r } = e;
  return r;
}, ec = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, Ii = /^[A-Za-z0-9_.:-]{1,160}$/, b = (e) => {
  const t = (r) => r && Ii.test(r) ? $i(
    pe({ domain: "zx-ai-session-safe-ref:v1", value: r })
  ) : void 0;
  return c({
    code: e.code,
    stage: e.stage,
    path: ec.test(e.path) ? e.path.slice(0, N.maxDiagnosticPathLength) : "$",
    ...Number.isSafeInteger(e.count) && e.count >= 0 ? { count: Math.min(e.count, 1e6) } : {},
    ...typeof e.fingerprint == "string" ? { fingerprintPrefix: $i(e.fingerprint) } : {},
    ...t(e.sessionRef) ? { sessionRef: t(e.sessionRef) } : {},
    ...t(e.requestRef) ? { requestRef: t(e.requestRef) } : {},
    ...t(e.attemptRef) ? { attemptRef: t(e.attemptRef) } : {},
    ...e.capability && Ii.test(e.capability) ? { capability: e.capability.slice(0, 160) } : {},
    ...e.terminalReason && Ii.test(e.terminalReason) ? { terminalReason: e.terminalReason.slice(0, 160) } : {}
  });
}, zi = (e, t, r, i) => {
  if (e == null) return null;
  if (typeof e == "function")
    return b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (typeof e != "object") return null;
  if (i > N.maxDepth || r.active.has(e))
    return b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (r.active.add(e), typeof e.nodeType == "number" || typeof globalThis.Element == "function") {
    const s = globalThis.Element;
    if (s && e instanceof s)
      return b({
        code: "session-input-invalid",
        stage: "contract",
        path: t
      });
  }
  if (typeof AbortController < "u" && e instanceof AbortController)
    return b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (typeof AbortSignal < "u" && e instanceof AbortSignal)
    return b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)
    return b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  if (Array.isArray(e)) {
    if (r.totalArrayEntries += e.length, e.length > N.maxArrayEntries || r.totalArrayEntries > N.maxArrayEntries)
      return b({
        code: "session-resource-exceeded",
        stage: "contract",
        path: t,
        count: r.totalArrayEntries
      });
    for (const [s, o] of e.entries()) {
      const a = zi(
        o,
        `${t}[${s}]`,
        r,
        i + 1
      );
      if (a)
        return r.active.delete(e), a;
    }
    return r.active.delete(e), null;
  }
  if (!ws(e))
    return r.active.delete(e), b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  const n = Object.entries(e);
  if (r.totalKeys += n.length, n.length > N.maxObjectKeys || r.totalKeys > N.maxTotalObjectKeys)
    return b({
      code: "session-resource-exceeded",
      stage: "contract",
      path: t,
      count: r.totalKeys
    });
  for (const [s, o] of n) {
    if (Ja.has(s) || s === "__proto__" || s === "constructor" || s === "prototype")
      return r.active.delete(e), b({
        code: "session-input-invalid",
        stage: "contract",
        path: `${t}.${s}`
      });
    const a = zi(
      o,
      `${t}.${s}`,
      r,
      i + 1
    );
    if (a)
      return r.active.delete(e), a;
  }
  return r.active.delete(e), null;
}, ze = (e, t = "$") => {
  try {
    return zi(
      e,
      t,
      { active: /* @__PURE__ */ new Set(), totalKeys: 0, totalArrayEntries: 0 },
      0
    );
  } catch {
    return b({
      code: "session-input-invalid",
      stage: "contract",
      path: t
    });
  }
}, tc = [
  "attempt-started",
  "assistant-delta",
  "progress",
  "tool-summary",
  "checkpoint",
  "abort-acknowledged",
  "attempt-succeeded",
  "attempt-failed",
  "transport-disconnected"
], Cn = {
  "transport-failed": "session-transport-failure",
  "transport-disconnected": "session-transport-failure",
  "resource-exceeded": "session-resource-exceeded",
  malformed: "session-malformed",
  "safety-abort": "session-safety-abort"
}, qn = c({
  "transport-failed": [
    "network",
    "provider-unavailable",
    "rate-limited",
    "auth-failed",
    "quota-exceeded",
    "request-rejected",
    "internal"
  ],
  "transport-disconnected": ["network"],
  "resource-exceeded": ["context-overflow", "output-truncated"],
  "safety-abort": ["content-filtered"],
  malformed: ["empty-output", "protocol"]
}), ks = (e, t) => Object.hasOwn(qn, String(e)) && qn[e].includes(t), Ss = (e) => fe("zx-ai-session/v1/event-payload", e), As = (e) => fe("zx-ai-session/v1/event", e), rc = (e) => fe("zx-ai-session/v1/sealed-result", e), Qi = (e) => fe("zx-ai-session/v1/sealed-content", {
  kind: e.kind,
  ...e.kind === "operation-envelope" ? { operationEnvelope: e.operationEnvelope } : {},
  ...e.kind === "message-only" ? { messageDigest: e.messageDigest } : {}
}), zr = (e) => {
  const t = Qi(e), r = {
    ...e,
    contentDigest: t
  };
  return c({
    ...r,
    fingerprint: rc(r)
  });
}, ic = (e, t) => {
  const r = ze(t, "$.payload");
  if (r) return { ok: !1, diagnostic: r };
  if (!T(t, ["kind"], []) && _t(t == null ? void 0 : t.kind), !Oi(t) || t.kind !== e)
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$.payload.kind"
      })
    };
  switch (e) {
    case "attempt-started":
      if (!T(t, [
        "kind",
        "transportAdmissionFingerprint",
        "transportExecutionReceiptRef"
      ]) || !Pe(t.transportAdmissionFingerprint) || !q(t.transportExecutionReceiptRef))
        return xe("$.payload");
      break;
    case "assistant-delta":
      if (!T(t, ["kind", "text", "encoding"]) || typeof t.text != "string" || t.encoding !== "utf-8-delta" || new TextEncoder().encode(t.text).byteLength > N.maxChunkBytes)
        return xe("$.payload.text");
      break;
    case "progress":
      if (!T(t, ["kind", "stage", "code", "count"]) || !q(t.stage) || !q(t.code) || !L(t.count))
        return xe("$.payload");
      break;
    case "tool-summary":
      if (!T(t, [
        "kind",
        "toolKind",
        "status",
        "digest",
        "count"
      ]) || !q(t.toolKind) || !["started", "completed", "failed"].includes(String(t.status)) || !Pe(t.digest) || !L(t.count))
        return xe("$.payload");
      break;
    case "checkpoint":
      if (!T(t, ["kind", "checkpointRef", "checkpointDigest"]) || !q(t.checkpointRef) || !Pe(t.checkpointDigest))
        return xe("$.payload");
      break;
    case "abort-acknowledged":
      if (!T(t, [
        "kind",
        "abortIntentId",
        "effectId",
        "transportAdmissionFingerprint",
        "receiptKind"
      ]) || !q(t.abortIntentId) || !q(t.effectId) || !Pe(t.transportAdmissionFingerprint) || !["acknowledged", "unsupported", "failed"].includes(
        String(t.receiptKind)
      ))
        return xe("$.payload");
      break;
    case "attempt-succeeded":
      if (!T(t, ["kind", "result"]) || !Oi(t.result))
        return xe("$.payload.result");
      {
        const i = Es(
          t
        );
        if (!i.ok) return i;
      }
      break;
    case "attempt-failed":
      if (!T(t, [
        "kind",
        "reason",
        "diagnosticCode",
        "failureClass"
      ]) || !Object.hasOwn(Cn, String(t.reason)) || t.diagnosticCode !== Cn[t.reason] || !ks(t.reason, t.failureClass))
        return xe("$.payload");
      break;
    case "transport-disconnected":
      if (!T(
        t,
        ["kind", "reason"],
        ["checkpointDigest", "logicalTime"]
      ) || !["disconnected", "timeout"].includes(String(t.reason)) || t.checkpointDigest !== void 0 && !Pe(t.checkpointDigest) || (t.reason === "timeout" ? !L(t.logicalTime) : t.logicalTime !== void 0))
        return xe("$.payload");
      break;
    default:
      return xe("$.kind");
  }
  try {
    if (Qa(t) > N.maxChunkBytes * 4)
      return {
        ok: !1,
        diagnostic: b({
          code: "session-resource-exceeded",
          stage: "event",
          path: "$.payload"
        })
      };
  } catch {
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$.payload"
      })
    };
  }
  return { ok: !0, value: t };
}, Oi = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), xe = (e) => ({
  ok: !1,
  diagnostic: b({
    code: "session-malformed",
    stage: "event",
    path: e
  })
}), nc = (e) => {
  try {
    return sc(e);
  } catch {
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$"
      })
    };
  }
}, sc = (e) => {
  const t = ze(e, "$");
  if (t) return { ok: !1, diagnostic: t };
  if (!T(
    e,
    [
      "version",
      "sessionId",
      "requestId",
      "attemptId",
      "sequence",
      "kind",
      "payload",
      "payloadFingerprint",
      "fingerprint"
    ],
    ["previousEventFingerprint"]
  ))
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$"
      })
    };
  if (e.version !== "1.0.0")
    return {
      ok: !1,
      diagnostic: b({
        code: "session-unsupported",
        stage: "event",
        path: "$.version"
      })
    };
  if (!q(e.sessionId) || !q(e.requestId) || !q(e.attemptId) || !L(e.sequence) || !tc.includes(e.kind) || e.previousEventFingerprint !== void 0 && !Pe(e.previousEventFingerprint) || !Pe(e.payloadFingerprint) || !Pe(e.fingerprint))
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$.identity"
      })
    };
  const r = ic(String(e.kind), e.payload);
  if (!r.ok) return r;
  const i = Ss(
    r.value
  );
  if (e.payloadFingerprint !== i)
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$.payloadFingerprint",
        fingerprint: i
      })
    };
  const n = {
    version: e.version,
    sessionId: e.sessionId,
    requestId: e.requestId,
    attemptId: e.attemptId,
    sequence: e.sequence,
    kind: e.kind,
    ...e.previousEventFingerprint ? { previousEventFingerprint: e.previousEventFingerprint } : {},
    payload: r.value,
    payloadFingerprint: i
  }, s = As(
    n
  );
  return e.fingerprint !== s ? {
    ok: !1,
    diagnostic: b({
      code: "session-malformed",
      stage: "event",
      path: "$.fingerprint",
      fingerprint: s
    })
  } : {
    ok: !0,
    value: c({
      ...n,
      fingerprint: s
    })
  };
}, oc = (e, t, r) => {
  var n;
  if (r.sessionId !== e.identity.sessionId || r.requestId !== t.requestId || r.attemptId !== t.attemptId)
    return {
      ok: !1,
      diagnostic: b({
        code: "session-identity-invalid",
        stage: "event",
        path: "$.event.identity",
        attemptRef: t.attemptId
      })
    };
  const i = e.recentEventProofs.find(
    (s) => s.attemptId === r.attemptId && s.sequence === r.sequence
  );
  if (i)
    return i.fingerprint === r.fingerprint ? { ok: !0, mode: "idempotent" } : {
      ok: !1,
      diagnostic: b({
        code: "session-event-duplicate-conflict",
        stage: "event",
        path: "$.event.sequence",
        attemptRef: t.attemptId,
        count: r.sequence
      })
    };
  if (r.sequence !== t.expectedSequence)
    return r.sequence < t.expectedSequence ? {
      ok: !1,
      diagnostic: b({
        code: "session-event-out-of-order",
        stage: "event",
        path: "$.event.sequence",
        count: r.sequence
      })
    } : {
      ok: !1,
      diagnostic: b({
        code: "session-event-gap",
        stage: "event",
        path: "$.event.sequence",
        count: r.sequence
      })
    };
  if (t.expectedSequence === 0) {
    if (r.previousEventFingerprint)
      return {
        ok: !1,
        diagnostic: b({
          code: "session-malformed",
          stage: "event",
          path: "$.previousEventFingerprint"
        })
      };
  } else if (r.previousEventFingerprint !== t.lastEventFingerprint)
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "event",
        path: "$.previousEventFingerprint"
      })
    };
  return t.status === "succeeded" || t.status === "failed" || t.status === "aborted" || t.status === "superseded" ? {
    ok: !1,
    diagnostic: b({
      code: "session-event-after-terminal",
      stage: "event",
      path: "$.event",
      attemptRef: t.attemptId,
      terminalReason: (n = t.terminal) == null ? void 0 : n.reason
    })
  } : r.sequence >= N.maxEventsPerAttempt ? {
    ok: !1,
    diagnostic: b({
      code: "session-resource-exceeded",
      stage: "event",
      path: "$.event.sequence",
      count: r.sequence
    })
  } : { ok: !0, mode: "accept" };
}, Es = (e) => {
  const t = e.result;
  if (!T(
    t,
    ["kind", "contentDigest", "resourceTotals"],
    ["operationEnvelope", "messageDigest", "fingerprint"]
  ))
    return xe("$.payload.result");
  if (!["message-only", "operation-envelope", "no-change"].includes(
    String(t.kind)
  ))
    return xe("$.payload.result.kind");
  if (!Pe(t.contentDigest))
    return xe("$.payload.result.contentDigest");
  if (!T(t.resourceTotals, [
    "eventCount",
    "textBytes",
    "toolSummaryCount"
  ]) || !L(t.resourceTotals.eventCount) || !L(t.resourceTotals.textBytes) || !L(t.resourceTotals.toolSummaryCount))
    return xe("$.payload.result.resourceTotals");
  if (t.kind === "operation-envelope" && (!Oi(t.operationEnvelope) || !rs(t.operationEnvelope)))
    return xe("$.payload.result.operationEnvelope");
  if (t.kind !== "operation-envelope" && Object.hasOwn(t, "operationEnvelope") || t.kind === "message-only" && !Pe(t.messageDigest) || t.kind !== "message-only" && Object.hasOwn(t, "messageDigest"))
    return xe("$.payload.result");
  const r = Qi({
    kind: t.kind,
    ...t.operationEnvelope !== void 0 ? { operationEnvelope: t.operationEnvelope } : {},
    ...typeof t.messageDigest == "string" ? { messageDigest: t.messageDigest } : {}
  });
  if (t.contentDigest !== r)
    return xe("$.payload.result.contentDigest");
  const i = zr({
    kind: t.kind,
    resourceTotals: t.resourceTotals,
    ...t.operationEnvelope !== void 0 ? { operationEnvelope: t.operationEnvelope } : {},
    ...typeof t.messageDigest == "string" ? { messageDigest: t.messageDigest } : {}
  });
  return Object.hasOwn(t, "fingerprint") && (!Pe(t.fingerprint) || t.fingerprint !== i.fingerprint) ? xe("$.payload.result.fingerprint") : { ok: !0, value: i };
}, en = (e) => {
  const t = e.kind === "attempt-succeeded" && e.payload.kind === "attempt-succeeded" ? c({
    kind: "attempt-succeeded",
    result: "fingerprint" in e.payload.result && "contentDigest" in e.payload.result ? e.payload.result : zr(e.payload.result)
  }) : e.payload, r = Ss(t), i = {
    version: "1.0.0",
    sessionId: e.sessionId,
    requestId: e.requestId,
    attemptId: e.attemptId,
    sequence: e.sequence,
    kind: e.kind,
    ...e.previousEventFingerprint ? { previousEventFingerprint: e.previousEventFingerprint } : {},
    payload: t,
    payloadFingerprint: r
  };
  return c({
    ...i,
    fingerprint: As(i)
  });
}, gr = (e = {}) => {
  const t = {
    requestId: null,
    attemptId: null,
    requestStatus: "idle",
    attemptStatus: "idle",
    assistantSegments: [],
    assistantTextBytes: 0,
    truncated: !1,
    progress: null,
    toolSummaries: [],
    capabilities: {
      canAbort: !1,
      canRetry: !1,
      canResume: !1,
      canSupersede: !1
    },
    lastDiagnostic: null,
    diagnostics: [],
    proposalRef: null,
    reviewRef: null,
    ...e
  };
  return c({
    ...t,
    fingerprint: fe(
      "zx-ai-session/v1/projection",
      be({
        ...t,
        fingerprint: ""
      })
    )
  });
}, Cs = (e) => fe("zx-ai-session/v1/artifact", e), ac = (e) => {
  const { activeAttemptId: t, publishedHandoffFingerprint: r, ...i } = e;
  return {
    ...i,
    ...t !== void 0 ? { activeAttemptId: t } : {},
    ...r !== void 0 ? { publishedHandoffFingerprint: r } : {}
  };
}, cc = (e) => {
  const {
    predecessorAttemptId: t,
    lastEventFingerprint: r,
    checkpointFingerprint: i,
    abortIntent: n,
    terminal: s,
    ...o
  } = e;
  return {
    ...o,
    ...t !== void 0 ? { predecessorAttemptId: t } : {},
    ...r !== void 0 ? { lastEventFingerprint: r } : {},
    ...i !== void 0 ? { checkpointFingerprint: i } : {},
    ...n !== void 0 ? { abortIntent: n } : {},
    ...s !== void 0 ? { terminal: s } : {}
  };
}, dc = (e) => {
  const { activeRequestId: t, sealedResult: r, ...i } = e;
  return {
    ...i,
    requests: e.requests.map(ac),
    attempts: e.attempts.map(cc),
    ...t !== void 0 ? { activeRequestId: t } : {},
    ...r !== void 0 ? { sealedResult: r } : {}
  };
}, Zt = (e) => {
  const t = dc(e);
  return Ae({
    ...t,
    fingerprint: Cs(t)
  });
}, tn = (e) => fe("zx-ai-session/v1/request-input", e), rn = (e) => {
  const t = ze(e, "$.input");
  if (t) return { ok: !1, diagnostic: t };
  if (!T(
    e,
    [
      "kind",
      "semanticSnapshotRef",
      "scopeRef",
      "baseDocumentRef",
      "intentRef"
    ],
    ["presentationContextFingerprint"]
  ))
    return {
      ok: !1,
      diagnostic: b({
        code: "session-input-invalid",
        stage: "contract",
        path: "$.input"
      })
    };
  if (![
    "selection",
    "cursor",
    "block",
    "long-running",
    "improve",
    "fix",
    "shorter",
    "longer",
    "continue",
    "follow-up"
  ].includes(String(e.kind)))
    return {
      ok: !1,
      diagnostic: b({
        code: "session-input-invalid",
        stage: "contract",
        path: "$.input.kind"
      })
    };
  const i = [
    ["semanticSnapshotRef", e.semanticSnapshotRef, "semantic-snapshot"],
    ["scopeRef", e.scopeRef, "scope"],
    ["baseDocumentRef", e.baseDocumentRef, "base-document"],
    ["intentRef", e.intentRef, "intent"]
  ];
  for (const [n, s, o] of i)
    if (!T(s, ["kind", "fingerprint"], ["revision"]) || s.kind !== o || !Pe(s.fingerprint) || s.revision !== void 0 && !q(s.revision))
      return {
        ok: !1,
        diagnostic: b({
          code: "session-input-invalid",
          stage: "contract",
          path: `$.input.${n}`
        })
      };
  return e.presentationContextFingerprint !== void 0 && !Pe(e.presentationContextFingerprint) ? {
    ok: !1,
    diagnostic: b({
      code: "session-input-invalid",
      stage: "contract",
      path: "$.input.presentationContextFingerprint"
    })
  } : {
    ok: !0,
    value: Ae(e)
  };
}, ut = (e, t) => e.requests.find((r) => r.requestId === t), lt = (e, t) => e.attempts.find((r) => r.attemptId === t), qs = (e, t) => {
  const r = ut(e, t);
  if (r != null && r.activeAttemptId)
    return lt(e, r.activeAttemptId);
}, Ts = (e) => {
  if (!q(e.identity.sessionId))
    return b({
      code: "session-identity-invalid",
      stage: "identity",
      path: "$.identity.sessionId"
    });
  if (e.requests.length > N.maxRequests)
    return b({
      code: "session-resource-exceeded",
      stage: "identity",
      path: "$.requests",
      count: e.requests.length
    });
  if (e.attempts.length > N.maxAttempts)
    return b({
      code: "session-resource-exceeded",
      stage: "identity",
      path: "$.attempts",
      count: e.attempts.length
    });
  const t = /* @__PURE__ */ new Set(), r = new Map(
    e.requests.map((f) => [f.requestId, f])
  ), i = [...r.keys()].sort();
  if (e.requests.some(
    (f, m) => f.requestId !== i[m]
  ))
    return b({
      code: "session-lineage-invalid",
      stage: "identity",
      path: "$.requests"
    });
  for (const f of e.requests) {
    if (f.sessionId !== e.identity.sessionId)
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.requests",
        requestRef: f.requestId
      });
    if (t.has(f.requestId))
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.requests",
        requestRef: f.requestId
      });
    t.add(f.requestId);
    for (const m of [
      f.lineage.restartedFromRequestId,
      f.lineage.supersededRequestId
    ]) {
      if (!m) continue;
      const y = r.get(m);
      if (!y || y.requestId === f.requestId || y.sessionId !== f.sessionId)
        return b({
          code: "session-lineage-invalid",
          stage: "identity",
          path: "$.requests.lineage",
          requestRef: f.requestId
        });
    }
    if (f.inputFingerprint !== tn(f.input))
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.requests.inputFingerprint",
        requestRef: f.requestId
      });
    if (f.policyFingerprint !== qe.fingerprint)
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.requests.policyFingerprint",
        requestRef: f.requestId
      });
  }
  const n = /* @__PURE__ */ new Map(), s = (f) => {
    const m = n.get(f);
    if (m === "visiting") return !1;
    if (m === "visited") return !0;
    n.set(f, "visiting");
    const y = r.get(f);
    for (const I of [
      y.lineage.restartedFromRequestId,
      y.lineage.supersededRequestId
    ])
      if (I && !s(I)) return !1;
    return n.set(f, "visited"), !0;
  };
  for (const f of i)
    if (!s(f))
      return b({
        code: "session-lineage-invalid",
        stage: "identity",
        path: "$.requests.cycle",
        requestRef: f
      });
  for (const f of e.requests)
    for (const m of [
      f.lineage.restartedFromRequestId,
      f.lineage.supersededRequestId
    ])
      if (m && r.get(m).logicalCreatedAt >= f.logicalCreatedAt)
        return b({
          code: "session-lineage-invalid",
          stage: "identity",
          path: "$.requests.logicalCreatedAt",
          requestRef: f.requestId
        });
  const o = /* @__PURE__ */ new Set(), a = new Map(
    e.attempts.map((f) => [f.attemptId, f])
  ), d = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), g = [...a.keys()].sort();
  if (e.attempts.some(
    (f, m) => f.attemptId !== g[m]
  ))
    return b({
      code: "session-lineage-invalid",
      stage: "identity",
      path: "$.attempts"
    });
  for (const f of e.attempts) {
    if (o.has(f.attemptId))
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.attempts",
        attemptRef: f.attemptId
      });
    if (o.add(f.attemptId), !t.has(f.requestId))
      return b({
        code: "session-lineage-invalid",
        stage: "identity",
        path: "$.attempts.requestId",
        attemptRef: f.attemptId
      });
    if (f.predecessorAttemptId) {
      const y = a.get(f.predecessorAttemptId);
      if (!y || y.attemptId === f.attemptId || y.requestId !== f.requestId || !y.terminal || f.retryCount !== y.retryCount + 1)
        return b({
          code: "session-lineage-invalid",
          stage: "identity",
          path: "$.attempts.predecessorAttemptId",
          attemptRef: f.attemptId
        });
      d.set(
        f.predecessorAttemptId,
        (d.get(f.predecessorAttemptId) ?? 0) + 1
      );
    } else {
      if (f.retryCount !== 0)
        return b({
          code: "session-lineage-invalid",
          stage: "identity",
          path: "$.attempts.retryCount",
          attemptRef: f.attemptId
        });
      l.set(
        f.requestId,
        (l.get(f.requestId) ?? 0) + 1
      );
    }
    if (!L(f.expectedSequence) || f.sequenceOrigin !== 0 || !L(f.acceptedTextBytes) || !L(f.acceptedToolSummaryCount) || !L(f.retryCount) || f.retryCount > N.maxRetries)
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.attempts.expectedSequence",
        attemptRef: f.attemptId
      });
    const m = e.requests.find(
      (y) => y.requestId === f.requestId
    );
    if (!m || f.transportAdmission.sessionId !== e.identity.sessionId || f.transportAdmission.requestId !== m.requestId || f.transportAdmission.requestKind !== m.input.kind || f.transportAdmission.requestInputFingerprint !== m.inputFingerprint || f.transportAdmission.policyFingerprint !== m.policyFingerprint)
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.attempts.transportAdmission",
        attemptRef: f.attemptId
      });
  }
  for (const f of e.requests)
    if (e.attempts.filter(
      (y) => y.requestId === f.requestId
    ).length > 0 && l.get(f.requestId) !== 1 || e.attempts.some(
      (y) => y.requestId === f.requestId && (d.get(y.attemptId) ?? 0) > 1
    ))
      return b({
        code: "session-lineage-invalid",
        stage: "identity",
        path: "$.attempts.retryLineage",
        requestRef: f.requestId
      });
  const u = /* @__PURE__ */ new Map(), p = (f) => {
    const m = u.get(f);
    if (m === "visiting") return !1;
    if (m === "visited") return !0;
    u.set(f, "visiting");
    const y = a.get(f).predecessorAttemptId;
    return y && !p(y) ? !1 : (u.set(f, "visited"), !0);
  };
  for (const f of g)
    if (!p(f))
      return b({
        code: "session-lineage-invalid",
        stage: "identity",
        path: "$.attempts.cycle",
        attemptRef: f
      });
  if (e.activeRequestId) {
    const f = r.get(e.activeRequestId);
    if (!f || !["prepared", "active"].includes(f.status))
      return b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.activeRequestId"
      });
  }
  if (e.status === "closing") {
    const f = e.activeRequestId ? r.get(e.activeRequestId) : void 0, m = f != null && f.activeAttemptId ? a.get(f.activeAttemptId) : void 0;
    if (!f || f.status !== "active" || !m || m.requestId !== f.requestId || m.status !== "abort-requested" || m.abortIntent === void 0 || m.terminal !== void 0)
      return b({
        code: "session-lineage-invalid",
        stage: "identity",
        path: "$.status"
      });
  }
  return e.status === "closed" && (e.activeRequestId !== void 0 || e.requests.some(
    (f) => ![
      "awaiting-review",
      "succeeded",
      "failed",
      "aborted",
      "superseded"
    ].includes(f.status)
  )) ? b({
    code: "session-lineage-invalid",
    stage: "identity",
    path: "$.status"
  }) : null;
}, nn = (e) => e === "succeeded" || e === "failed" || e === "aborted" || e === "superseded", Qr = (e) => e === "created" || e === "starting" || e === "streaming" || e === "abort-requested" || e === "suspended", Vr = (e) => new TextEncoder().encode(e).byteLength, Bs = (e) => fe("zx-ai-session/v1/projection", e), Tt = (e) => {
  const t = e.diagnostics.slice(
    -N.maxDiagnostics
  ), r = {
    ...e,
    diagnostics: t,
    lastDiagnostic: t[t.length - 1] ?? null
  };
  return c({
    ...r,
    fingerprint: Bs(r)
  });
}, lc = (e, t) => Tt({
  ...be(e),
  diagnostics: [...e.diagnostics, t]
}), pc = (e, t) => {
  if (Vr(t) > N.maxChunkBytes)
    return {
      ok: !1,
      diagnostic: b({
        code: "session-resource-exceeded",
        stage: "projection",
        path: "$.payload.text",
        count: Vr(t)
      })
    };
  const r = e.assistantTextBytes + Vr(t);
  let i = e.truncated, n = [...e.assistantSegments], s = e.assistantTextBytes;
  if (r > N.maxProjectionTextBytes || n.length >= N.maxProjectionSegments)
    i = !0;
  else {
    const o = c({
      ordinal: n.length,
      text: t,
      byteLength: Vr(t)
    });
    n = [...n, o], s = r;
  }
  return {
    ok: !0,
    projection: Tt({
      ...be(e),
      assistantSegments: n,
      assistantTextBytes: s,
      truncated: i
    })
  };
}, uc = (e, t) => Tt({
  ...be(e),
  progress: c({
    stage: t.stage.slice(0, 64),
    code: t.code.slice(0, 64),
    count: Math.min(Math.max(0, t.count), 1e6)
  })
}), fc = (e, t) => e.toolSummaries.length >= N.maxToolSummaries ? {
  ok: !1,
  diagnostic: b({
    code: "session-resource-exceeded",
    stage: "projection",
    path: "$.toolSummaries",
    count: e.toolSummaries.length + 1
  })
} : {
  ok: !0,
  projection: Tt({
    ...be(e),
    toolSummaries: [...e.toolSummaries, c(t)]
  })
}, Or = (e, t, r, i, n = e.lastDiagnostic) => Tt({
  ...be(e),
  requestId: (t == null ? void 0 : t.requestId) ?? null,
  attemptId: (r == null ? void 0 : r.attemptId) ?? null,
  requestStatus: (t == null ? void 0 : t.status) ?? "idle",
  attemptStatus: (r == null ? void 0 : r.status) ?? "idle",
  capabilities: i,
  lastDiagnostic: n
}), Ps = (e, t, r) => Tt({
  requestId: e.requestId,
  attemptId: (t == null ? void 0 : t.attemptId) ?? null,
  requestStatus: e.status,
  attemptStatus: (t == null ? void 0 : t.status) ?? "idle",
  assistantSegments: [],
  assistantTextBytes: 0,
  truncated: !1,
  progress: null,
  toolSummaries: [],
  capabilities: r,
  lastDiagnostic: null,
  diagnostics: [],
  proposalRef: null,
  reviewRef: null
}), gc = (e, t) => {
  switch (t.payload.kind) {
    case "assistant-delta":
      return pc(e, t.payload.text);
    case "progress":
      return {
        ok: !0,
        projection: uc(e, t.payload)
      };
    case "tool-summary":
      return fc(e, {
        toolKind: t.payload.toolKind,
        status: t.payload.status,
        digest: t.payload.digest,
        count: t.payload.count
      });
    default:
      return { ok: !0, projection: e };
  }
}, S = (e, t = "session-input-invalid", r = "contract") => ({
  ok: !1,
  diagnostic: b({ code: t, stage: r, path: e })
}), M = (e) => _t(e) && e.length <= N.maxIdLength * 2, $r = (e) => e === null || M(e), $s = /* @__PURE__ */ new Set([
  "prepared",
  "active",
  "awaiting-review",
  "succeeded",
  "failed",
  "aborted",
  "superseded"
]), js = /* @__PURE__ */ new Set([
  "created",
  "starting",
  "streaming",
  "abort-requested",
  "suspended",
  "succeeded",
  "failed",
  "aborted",
  "superseded"
]), mc = /* @__PURE__ */ new Set([
  "open",
  "closing",
  "closed",
  "corrupt",
  "unsupported"
]), vc = /* @__PURE__ */ new Set([
  "succeeded",
  "transport-failed",
  "transport-disconnected",
  "aborted",
  "abort-unsupported",
  "resource-exceeded",
  "malformed",
  "superseded",
  "handoff-failure",
  "safety-abort",
  "timeout"
]), di = /* @__PURE__ */ new Set([
  "message-only",
  "operation-envelope",
  "no-change"
]), hc = /* @__PURE__ */ new Set([
  "message-only",
  "no-change",
  "awaiting-review",
  "handoff-failure"
]), yc = /* @__PURE__ */ new Set([
  "create-request",
  "start-attempt",
  "accept-event",
  "request-abort",
  "acknowledge-abort",
  "retry",
  "resume",
  "restart",
  "supersede",
  "publish-handoff",
  "close-session"
]), Ic = /* @__PURE__ */ new Set([
  "attempt-started",
  "assistant-delta",
  "progress",
  "tool-summary",
  "checkpoint",
  "abort-acknowledged",
  "attempt-succeeded",
  "attempt-failed",
  "transport-disconnected"
]), bc = /* @__PURE__ */ new Set([
  "session-created",
  "command-accepted",
  "command-idempotent",
  "event-accepted",
  "event-idempotent",
  "late-event",
  "effect-published",
  "handoff-published",
  "checkpoint",
  "compaction",
  "session-closed"
]), Fc = /* @__PURE__ */ new Set([
  "session",
  "request",
  "attempt",
  "event",
  "effect",
  "terminal",
  "sealed-result",
  "handoff",
  "proposal",
  "review",
  "lifecycle",
  "policy",
  "checkpoint",
  "transport",
  "command",
  "compaction"
]), Ds = /* @__PURE__ */ new Set([
  "session-input-invalid",
  "session-identity-invalid",
  "session-lineage-invalid",
  "session-revision-conflict",
  "session-busy",
  "session-terminal",
  "session-unsupported",
  "session-malformed",
  "session-resource-exceeded",
  "session-event-gap",
  "session-event-duplicate-conflict",
  "session-event-out-of-order",
  "session-event-after-terminal",
  "session-abort-race",
  "session-retry-ineligible",
  "session-resume-conflict",
  "session-handoff-failure",
  "session-safety-abort",
  "session-historical-unsupported",
  "session-transport-unsupported",
  "session-transport-failure",
  "session-checkpoint-invalid",
  "session-replay-invalid"
]), xc = /* @__PURE__ */ new Set([
  "contract",
  "identity",
  "command",
  "event",
  "projection",
  "transport-admission",
  "checkpoint",
  "replay",
  "handoff",
  "historical"
]), wc = /^\$(?:\.[A-Za-z][A-Za-z0-9_-]*|\[\d+\])*$/, Rc = /^[A-Za-z0-9_.:-]{1,160}$/, sn = [
  "selection",
  "cursor",
  "block",
  "long-running",
  "improve",
  "fix",
  "shorter",
  "longer",
  "continue",
  "follow-up"
], kc = (e, t) => !T(e, ["start", "abort", "resume", "requestKinds"]) || e.start !== !0 || typeof e.abort != "boolean" || ![!1, "resume:same-attempt-checkpoint-v1"].includes(
  e.resume
) || !Array.isArray(e.requestKinds) || e.requestKinds.length === 0 || new Set(e.requestKinds).size !== e.requestKinds.length || e.requestKinds.some(
  (r) => !sn.includes(r)
) ? S(t, "session-transport-unsupported", "transport-admission") : {
  ok: !0,
  value: Ae(e)
}, Sc = (e, t = "$") => !T(e, ["id", "version", "fingerprint"]) || e.id !== qe.id || e.version !== qe.version || e.fingerprint !== qe.fingerprint ? S(t, "session-unsupported", "contract") : {
  ok: !0,
  value: Ae(e)
}, zs = (e) => fe("zx-ai-session/v1/checkpoint", e), Ac = (e) => {
  try {
    const t = ze(e, "$");
    if (t) return { ok: !1, diagnostic: t };
    if (!T(e, [
      "kind",
      "version",
      "sessionId",
      "requestId",
      "attemptId",
      "revision",
      "sessionFingerprint",
      "lastSequence",
      "lastEventFingerprint",
      "projectionFingerprint",
      "policyFingerprint",
      "capabilityFingerprint",
      "auditHead",
      "fingerprint"
    ]) || e.kind !== "zx-ai-session-checkpoint-v1" || e.version !== nt || !q(e.sessionId) || !q(e.requestId) || !q(e.attemptId) || !L(e.revision) || !M(e.sessionFingerprint) || !L(e.lastSequence) || !$r(e.lastEventFingerprint) || !M(e.projectionFingerprint) || e.policyFingerprint !== qe.fingerprint || !M(e.capabilityFingerprint) || !T(e.auditHead, ["sequence", "fingerprint"]) || !L(e.auditHead.sequence) || !$r(e.auditHead.fingerprint) || !M(e.fingerprint))
      return S("$", "session-checkpoint-invalid", "checkpoint");
    const { fingerprint: r, ...i } = e, n = zs(
      i
    );
    if (e.fingerprint !== n)
      return S("$.fingerprint", "session-checkpoint-invalid", "checkpoint");
    const s = Ae({
      ...i,
      fingerprint: n
    });
    return new TextEncoder().encode(JSON.stringify(s)).byteLength > N.maxCheckpointBytes ? S("$", "session-resource-exceeded", "checkpoint") : { ok: !0, value: s };
  } catch {
    return S("$", "session-checkpoint-invalid", "checkpoint");
  }
}, Os = (e) => fe("zx-ai-session/v1/transport-admission", e), li = (e, t = "$") => {
  if (!T(e, [
    "kind",
    "sessionId",
    "sourceRevision",
    "sourceSessionFingerprint",
    "requestId",
    "requestKind",
    "requestInputFingerprint",
    "policyFingerprint",
    "transportId",
    "version",
    "descriptorFingerprint",
    "capabilities",
    "fingerprint"
  ]) || e.kind !== "zx-ai-transport-admission-receipt-v1" || e.version !== nt || !q(e.sessionId) || !L(e.sourceRevision) || !M(e.sourceSessionFingerprint) || !q(e.requestId) || !sn.includes(
    e.requestKind
  ) || !M(e.requestInputFingerprint) || !M(e.policyFingerprint) || !q(e.transportId) || !M(e.descriptorFingerprint) || !M(e.fingerprint))
    return S(t, "session-transport-unsupported", "transport-admission");
  const r = kc(
    e.capabilities,
    `${t}.capabilities`
  );
  if (!r.ok) return r;
  if (!r.value.requestKinds.includes(
    e.requestKind
  ))
    return S(
      `${t}.capabilities.requestKinds`,
      "session-transport-unsupported",
      "transport-admission"
    );
  const i = {
    kind: e.kind,
    sessionId: e.sessionId,
    sourceRevision: e.sourceRevision,
    sourceSessionFingerprint: e.sourceSessionFingerprint,
    requestId: e.requestId,
    requestKind: e.requestKind,
    requestInputFingerprint: e.requestInputFingerprint,
    policyFingerprint: e.policyFingerprint,
    transportId: e.transportId,
    version: e.version,
    descriptorFingerprint: e.descriptorFingerprint,
    capabilities: r.value
  }, n = Os(i);
  return e.fingerprint !== n ? S(
    `${t}.fingerprint`,
    "session-transport-unsupported",
    "transport-admission"
  ) : {
    ok: !0,
    value: Ae({ ...i, fingerprint: n })
  };
}, Hr = [
  "effectId",
  "kind",
  "sessionId",
  "requestId",
  "attemptId",
  "sourceRevision",
  "sourceFingerprint",
  "idempotencyKey"
], Ec = (e, t = "$") => {
  try {
    const r = ze(e, t);
    if (r) return { ok: !1, diagnostic: r };
    if (!e || typeof e != "object" || Array.isArray(e))
      return S(t, "session-input-invalid", "transport-admission");
    const i = e;
    if (!(q(i.effectId) && q(i.sessionId) && q(i.requestId) && q(i.attemptId) && L(i.sourceRevision) && M(i.sourceFingerprint) && q(i.idempotencyKey)))
      return S(t, "session-input-invalid", "transport-admission");
    if (i.kind === "transport-start") {
      if (!T(i, [
        ...Hr,
        "transportAdmission",
        "requestProjection"
      ]) || !T(i.requestProjection, [
        "inputFingerprint",
        "kind",
        "policyFingerprint"
      ]) || !M(i.requestProjection.inputFingerprint) || !sn.includes(
        i.requestProjection.kind
      ) || !M(i.requestProjection.policyFingerprint))
        return S(t, "session-input-invalid", "transport-admission");
    } else if (i.kind === "transport-abort") {
      if (!T(i, [
        ...Hr,
        "abortIntentId",
        "transportAdmission"
      ]) || !q(i.abortIntentId))
        return S(t, "session-input-invalid", "transport-admission");
    } else if (i.kind === "transport-resume") {
      if (!T(i, [
        ...Hr,
        "checkpointFingerprint",
        "expectedSequence",
        "transportAdmission"
      ]) || !M(i.checkpointFingerprint) || !L(i.expectedSequence))
        return S(t, "session-input-invalid", "transport-admission");
    } else return i.kind === "proposal-handoff" ? !T(i, [
      ...Hr,
      "sealedResultFingerprint",
      "resultKind"
    ]) || !M(i.sealedResultFingerprint) || !di.has(String(i.resultKind)) ? S(t, "session-input-invalid", "transport-admission") : {
      ok: !0,
      value: Ae(i)
    } : S(`${t}.kind`, "session-unsupported", "transport-admission");
    const s = li(
      i.transportAdmission,
      `${t}.transportAdmission`
    );
    return s.ok ? {
      ok: !0,
      value: Ae({
        ...i,
        transportAdmission: s.value
      })
    } : s;
  } catch {
    return S(t, "session-input-invalid", "transport-admission");
  }
}, Ns = (e) => fe("zx-ai-session/v1/handoff-receipt", e), on = (e, t = "$") => {
  if (!T(
    e,
    [
      "kind",
      "version",
      "handoffId",
      "effectId",
      "sourceRevision",
      "sourceSessionFingerprint",
      "sessionId",
      "requestId",
      "attemptId",
      "resultKind",
      "sealedResultFingerprint",
      "outcome",
      "fingerprint"
    ],
    [
      "proposalId",
      "proposalFingerprint",
      "reviewId",
      "reviewFingerprint",
      "lifecycleFingerprint"
    ]
  ) || e.kind !== "zx-ai-session-handoff-receipt-v1" || e.version !== nt || !q(e.handoffId) || !M(e.effectId) || !L(e.sourceRevision) || !M(e.sourceSessionFingerprint) || !q(e.sessionId) || !q(e.requestId) || !q(e.attemptId) || !di.has(String(e.resultKind)) || !M(e.sealedResultFingerprint) || !hc.has(String(e.outcome)) || !M(e.fingerprint))
    return S(t, "session-handoff-failure", "handoff");
  for (const s of [
    "proposalId",
    "proposalFingerprint",
    "reviewId",
    "reviewFingerprint",
    "lifecycleFingerprint"
  ])
    if (Object.hasOwn(e, s) && (s.endsWith("Id") ? !q(e[s]) : !M(e[s])))
      return S(`${t}.${s}`, "session-handoff-failure", "handoff");
  if (e.outcome !== "awaiting-review" || e.resultKind !== "operation-envelope" || !e.proposalId || !e.proposalFingerprint || !e.reviewId || !e.reviewFingerprint || !e.lifecycleFingerprint)
    return S(`${t}.outcome`, "session-handoff-failure", "handoff");
  const { fingerprint: r, ...i } = e, n = Ns(
    i
  );
  return e.fingerprint !== n ? S(`${t}.fingerprint`, "session-handoff-failure", "handoff") : {
    ok: !0,
    value: Ae({
      ...i,
      fingerprint: n
    })
  };
}, Rt = (e) => fe("zx-ai-session/v1/terminal", {
  attemptId: e.attemptId,
  ...e.terminal
}), Cc = (e, t = "$") => {
  if (!T(
    e,
    ["kind", "contentDigest", "resourceTotals", "fingerprint"],
    ["operationEnvelope", "messageDigest"]
  ) || !di.has(String(e.kind)) || !M(e.contentDigest) || !M(e.fingerprint) || !T(e.resourceTotals, [
    "eventCount",
    "textBytes",
    "toolSummaryCount"
  ]) || !L(e.resourceTotals.eventCount) || !L(e.resourceTotals.textBytes) || !L(e.resourceTotals.toolSummaryCount) || e.kind === "operation-envelope" !== Object.hasOwn(e, "operationEnvelope") || e.kind === "message-only" !== Object.hasOwn(e, "messageDigest") || e.messageDigest !== void 0 && !M(e.messageDigest) || e.kind === "operation-envelope" && !rs(e.operationEnvelope))
    return S(t, "session-malformed", "identity");
  const r = Qi({
    kind: e.kind,
    ...e.kind === "operation-envelope" ? { operationEnvelope: e.operationEnvelope } : {},
    ...e.kind === "message-only" ? { messageDigest: e.messageDigest } : {}
  });
  if (e.contentDigest !== r)
    return S(`${t}.contentDigest`, "session-identity-invalid", "identity");
  const { fingerprint: i, ...n } = e, s = fe(
    "zx-ai-session/v1/sealed-result",
    n
  );
  return e.fingerprint !== s ? S(`${t}.fingerprint`, "session-identity-invalid", "identity") : {
    ok: !0,
    value: Ae(e)
  };
}, an = (e, t = "$") => {
  try {
    return Cc(e, t);
  } catch {
    return S(t, "session-malformed", "identity");
  }
}, Tn = (e, t) => {
  if (!T(
    e,
    ["code", "stage", "path"],
    [
      "count",
      "fingerprintPrefix",
      "sessionRef",
      "requestRef",
      "attemptRef",
      "capability",
      "terminalReason"
    ]
  ) || !Ds.has(String(e.code)) || !xc.has(String(e.stage)) || typeof e.path != "string" || e.path.length > N.maxDiagnosticPathLength || !wc.test(e.path) || e.count !== void 0 && (!L(e.count) || e.count > 1e6))
    return S(t, "session-identity-invalid", "identity");
  for (const r of [
    "fingerprintPrefix",
    "sessionRef",
    "requestRef",
    "attemptRef",
    "capability",
    "terminalReason"
  ])
    if (e[r] !== void 0 && (typeof e[r] != "string" || !Rc.test(e[r])))
      return S(`${t}.${r}`, "session-identity-invalid", "identity");
  return {
    ok: !0,
    value: Ae(e)
  };
}, qc = (e) => {
  if (!T(e, [
    "requestId",
    "attemptId",
    "requestStatus",
    "attemptStatus",
    "assistantSegments",
    "assistantTextBytes",
    "truncated",
    "progress",
    "toolSummaries",
    "capabilities",
    "lastDiagnostic",
    "diagnostics",
    "proposalRef",
    "reviewRef",
    "fingerprint"
  ]) || !(e.requestId === null || q(e.requestId)) || !(e.attemptId === null || q(e.attemptId)) || ![...$s, "idle"].includes(String(e.requestStatus)) || ![...js, "idle"].includes(String(e.attemptStatus)) || !Array.isArray(e.assistantSegments) || e.assistantSegments.length > N.maxProjectionSegments || !L(e.assistantTextBytes) || typeof e.truncated != "boolean" || !Array.isArray(e.toolSummaries) || e.toolSummaries.length > N.maxToolSummaries || !Array.isArray(e.diagnostics) || e.diagnostics.length > N.maxDiagnostics || !T(e.capabilities, [
    "canAbort",
    "canRetry",
    "canResume",
    "canSupersede"
  ]) || Object.values(e.capabilities).some(
    (s) => typeof s != "boolean"
  ) || !(e.proposalRef === null || q(e.proposalRef)) || !(e.reviewRef === null || q(e.reviewRef)) || !M(e.fingerprint))
    return S("$.projection", "session-identity-invalid", "identity");
  let t = 0;
  for (const [s, o] of e.assistantSegments.entries()) {
    if (!T(o, ["ordinal", "text", "byteLength"]) || o.ordinal !== s || typeof o.text != "string" || !L(o.byteLength) || new TextEncoder().encode(o.text).byteLength !== o.byteLength)
      return S(
        `$.projection.assistantSegments[${s}]`,
        "session-identity-invalid",
        "identity"
      );
    t += o.byteLength;
  }
  if (t !== e.assistantTextBytes)
    return S(
      "$.projection.assistantTextBytes",
      "session-identity-invalid",
      "identity"
    );
  for (const [s, o] of e.toolSummaries.entries())
    if (!T(o, ["toolKind", "status", "digest", "count"]) || !_t(o.toolKind) || !["started", "completed", "failed"].includes(String(o.status)) || !M(o.digest) || !L(o.count))
      return S(
        `$.projection.toolSummaries[${s}]`,
        "session-identity-invalid",
        "identity"
      );
  if (e.progress !== null && (!T(e.progress, ["stage", "code", "count"]) || !_t(e.progress.stage) || !_t(e.progress.code) || !L(e.progress.count)))
    return S("$.projection.progress", "session-identity-invalid", "identity");
  const r = [];
  for (const [s, o] of e.diagnostics.entries()) {
    const a = Tn(
      o,
      `$.projection.diagnostics[${s}]`
    );
    if (!a.ok) return a;
    r.push(a.value);
  }
  if (e.lastDiagnostic === null) {
    if (r.length > 0)
      return S(
        "$.projection.lastDiagnostic",
        "session-identity-invalid",
        "identity"
      );
  } else {
    const s = Tn(
      e.lastDiagnostic,
      "$.projection.lastDiagnostic"
    );
    if (!s.ok || r.length === 0 || !Rs(s.value, r[r.length - 1]))
      return S(
        "$.projection.lastDiagnostic",
        "session-identity-invalid",
        "identity"
      );
  }
  const { fingerprint: i, ...n } = e;
  return e.fingerprint !== Bs(
    n
  ) ? S(
    "$.projection.fingerprint",
    "session-identity-invalid",
    "identity"
  ) : {
    ok: !0,
    value: Ae(e)
  };
}, Tc = (e, t) => {
  if (!Array.isArray(e) || e.length > N.maxAuditEntries || !T(t, ["sequence", "fingerprint"]) || !L(t.sequence) || !$r(t.fingerprint))
    return S("$.auditEntries", "session-identity-invalid", "identity");
  let r = null, i = 0;
  for (const [n, s] of e.entries()) {
    if (!T(
      s,
      ["sequence", "kind", "previousFingerprint", "refs", "fingerprint"],
      [
        "commandKind",
        "eventKind",
        "eventSequence",
        "requestId",
        "attemptId",
        "effectId",
        "compaction"
      ]
    ) || !L(s.sequence) || !bc.has(String(s.kind)) || !$r(s.previousFingerprint) || !Array.isArray(s.refs) || !M(s.fingerprint) || s.commandKind !== void 0 && !yc.has(String(s.commandKind)) || s.eventKind !== void 0 && !Ic.has(String(s.eventKind)) || s.eventSequence !== void 0 && !L(s.eventSequence) || s.eventKind === void 0 != (s.eventSequence === void 0) || s.requestId !== void 0 && !q(s.requestId) || s.attemptId !== void 0 && !q(s.attemptId) || s.effectId !== void 0 && !q(s.effectId) || s.kind === "compaction" && s.compaction === void 0 || s.kind !== "compaction" && s.compaction !== void 0)
      return S(
        `$.auditEntries[${n}]`,
        "session-identity-invalid",
        "identity"
      );
    const o = n === 0 && s.kind === "compaction";
    if (!o && (s.sequence !== i + 1 || s.previousFingerprint !== r) || o && (s.previousFingerprint !== null || !T(s.compaction, [
      "priorHead",
      "droppedStartSequence",
      "droppedEndSequence",
      "droppedCount",
      "leftBoundaryFingerprint",
      "rightBoundaryFingerprint",
      "preservedTerminalRoots",
      "preservedHandoffRoots",
      "preservedLateEventProofs"
    ])))
      return S(
        `$.auditEntries[${n}].previousFingerprint`,
        "session-identity-invalid",
        "identity"
      );
    if (o) {
      const f = s.compaction;
      if (!T(f.priorHead, ["sequence", "fingerprint"]) || !L(f.priorHead.sequence) || !M(f.priorHead.fingerprint) || !L(f.droppedStartSequence) || !L(f.droppedEndSequence) || !L(f.droppedCount) || f.droppedCount === 0 || f.droppedEndSequence < f.droppedStartSequence || f.droppedCount !== f.droppedEndSequence - f.droppedStartSequence + 1 || f.priorHead.sequence !== f.droppedEndSequence || s.sequence !== f.priorHead.sequence + 1 || !M(f.leftBoundaryFingerprint) || !M(f.rightBoundaryFingerprint) || f.rightBoundaryFingerprint !== f.priorHead.fingerprint || !Array.isArray(f.preservedTerminalRoots) || !Array.isArray(f.preservedHandoffRoots) || !Array.isArray(f.preservedLateEventProofs) || f.preservedLateEventProofs.length > N.maxAuditEntries || f.preservedTerminalRoots.some(
        (I) => !M(I)
      ) || f.preservedHandoffRoots.some(
        (I) => !M(I)
      ) || new Set(f.preservedTerminalRoots).size !== f.preservedTerminalRoots.length || new Set(f.preservedHandoffRoots).size !== f.preservedHandoffRoots.length)
        return S(
          `$.auditEntries[${n}].compaction`,
          "session-identity-invalid",
          "identity"
        );
      const m = /* @__PURE__ */ new Set();
      let y = null;
      for (const [
        I,
        h
      ] of f.preservedLateEventProofs.entries()) {
        if (!T(h, ["attemptId", "sequence", "fingerprint"]) || !q(h.attemptId) || !L(h.sequence) || h.sequence >= N.maxEventsPerAttempt || !M(h.fingerprint))
          return S(
            `$.auditEntries[${n}].compaction.preservedLateEventProofs[${I}]`,
            "session-identity-invalid",
            "identity"
          );
        const v = `${h.attemptId}\0${h.sequence.toString().padStart(10, "0")}`;
        if (m.has(v) || y !== null && v <= y)
          return S(
            `$.auditEntries[${n}].compaction.preservedLateEventProofs`,
            "session-lineage-invalid",
            "identity"
          );
        m.add(v), y = v;
      }
    }
    const a = s.refs;
    for (const [f, m] of a.entries())
      if (!T(m, ["id", "type"]) || !_t(m.id) || m.id.length > N.maxIdLength * 2 || !Fc.has(String(m.type)) || a.findIndex(
        (y) => T(y, ["id", "type"]) && y.id === m.id && y.type === m.type
      ) !== f)
        return S(
          `$.auditEntries[${n}].refs[${f}]`,
          "session-identity-invalid",
          "identity"
        );
    const d = (f, m) => a.some(
      (y) => y.type === f && (m === void 0 || y.id === m)
    );
    if (s.kind === "session-created" && (s.commandKind !== void 0 || s.eventKind !== void 0 || s.eventSequence !== void 0 || s.requestId !== void 0 || s.attemptId !== void 0 || s.effectId !== void 0 || !d("session")) || s.kind === "command-accepted" && s.commandKind === void 0 || s.kind === "command-idempotent" && s.commandKind === void 0 || s.kind === "event-accepted" && (!["accept-event", "acknowledge-abort"].includes(
      String(s.commandKind)
    ) || s.eventKind === void 0 || s.eventSequence === void 0 || s.requestId === void 0 || s.attemptId === void 0 || !d("event")) || s.kind === "event-idempotent" && (s.eventKind === void 0 || s.eventSequence === void 0 || s.requestId === void 0 || s.attemptId === void 0 || !d("event")) || s.kind === "late-event" && (s.eventKind === void 0 || s.eventSequence === void 0 || s.requestId === void 0 || s.attemptId === void 0 || !d("event")) || s.kind === "effect-published" && (s.commandKind === void 0 || s.effectId === void 0 || !d("effect", s.effectId)) || s.kind === "handoff-published" && (s.commandKind !== "publish-handoff" || s.requestId === void 0 || s.attemptId === void 0 || !d("handoff")) || s.kind === "checkpoint" && (s.eventKind !== "checkpoint" || s.eventSequence === void 0 || s.requestId === void 0 || s.attemptId === void 0 || !d("checkpoint")) || s.kind === "compaction" && (s.commandKind !== void 0 || s.eventKind !== void 0 || s.eventSequence !== void 0 || s.requestId !== void 0 || s.attemptId !== void 0 || s.effectId !== void 0 || !d("compaction")) || s.kind === "session-closed" && (s.commandKind !== "close-session" || !d("session")) || s.requestId !== void 0 && !d("request", s.requestId) || s.attemptId !== void 0 && !d("attempt", s.attemptId))
      return S(
        `$.auditEntries[${n}]`,
        "session-identity-invalid",
        "identity"
      );
    const { fingerprint: g, ...u } = s, p = fe("zx-ai-session/v1/audit", u);
    if (s.fingerprint !== p)
      return S(
        `$.auditEntries[${n}].fingerprint`,
        "session-identity-invalid",
        "identity"
      );
    r = s.fingerprint, i = s.sequence;
  }
  return e.length === 0 && (t.sequence !== 0 || t.fingerprint !== null) || e.length > 0 && (t.sequence !== i || t.fingerprint !== r) ? S("$.auditHead", "session-identity-invalid", "identity") : {
    ok: !0,
    value: Ae(
      e
    )
  };
}, Bc = (e) => {
  var p, f, m, y;
  const t = new Map(
    e.requests.map((I) => [I.requestId, I])
  ), r = new Map(
    e.attempts.map((I) => [I.attemptId, I])
  ), i = new Map(
    e.attempts.flatMap(
      (I) => I.terminal ? [[I.terminal.fingerprint, I]] : []
    )
  ), n = /* @__PURE__ */ new Map();
  for (const I of e.attempts) {
    const h = (p = I.terminal) == null ? void 0 : p.sealedResultFingerprint;
    h && n.set(h, [
      ...n.get(h) ?? [],
      I
    ]);
  }
  const s = new Map(
    e.handoffs.map((I) => [I.fingerprint, I])
  ), o = new Map(
    e.recentEventProofs.map((I) => [
      `${I.attemptId}:${I.sequence}`,
      I.fingerprint
    ])
  ), a = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), l = (I, h) => I.refs.some(
    (v) => v.type === "attempt" && v.id === h.attemptId
  ) && I.refs.some(
    (v) => v.type === "request" && v.id === h.requestId
  ), g = (I) => I.refs.flatMap((h) => {
    if (h.type !== "handoff") return [];
    const v = s.get(h.id);
    return v ? [v] : [];
  }), u = (I, h, v) => g(I).some((F) => h === "proposal" ? F.proposalFingerprint === v : h === "review" ? F.reviewFingerprint === v : F.lifecycleFingerprint === v);
  for (const [I, h] of e.auditEntries.entries()) {
    const v = h.refs.filter((w) => w.type === "event"), F = g(h);
    for (const [w, x] of h.refs.entries()) {
      let j = x.type === "session" && x.id === e.identity.sessionId || x.type === "policy" && x.id === e.policyRef.fingerprint || x.type === "request" && t.has(x.id) || x.type === "attempt" && r.has(x.id) || x.type === "terminal" && !!i.get(x.id) && l(
        h,
        i.get(x.id)
      ) || x.type === "sealed-result" && (n.get(x.id) ?? []).some(
        (_) => l(h, _)
      ) || x.type === "handoff" && !!s.get(x.id) || x.type === "proposal" && u(h, "proposal", x.id) || x.type === "review" && u(h, "review", x.id) || x.type === "lifecycle" && u(h, "lifecycle", x.id) || x.type === "effect" && h.effectId === x.id || x.type === "event" && h.eventKind !== void 0 && h.eventSequence !== void 0 && h.requestId !== void 0 && h.attemptId !== void 0 || x.type === "checkpoint" && h.kind === "checkpoint" && h.attemptId !== void 0 && ((f = r.get(h.attemptId)) == null ? void 0 : f.checkpointFingerprint) === x.id || x.type === "transport" && h.attemptId !== void 0 && [
        (m = r.get(h.attemptId)) == null ? void 0 : m.transportAdmission.fingerprint,
        (y = r.get(h.attemptId)) == null ? void 0 : y.transportAdmission.descriptorFingerprint
      ].includes(x.id) || x.type === "compaction" && h.kind === "compaction";
      if (x.type === "command" && (j = !1), !j)
        return S(
          `$.auditEntries[${I}].refs[${w}]`,
          "session-identity-invalid",
          "identity"
        );
    }
    if (h.requestId && h.attemptId) {
      const w = r.get(h.attemptId);
      if (!w || w.requestId !== h.requestId)
        return S(
          `$.auditEntries[${I}].attemptId`,
          "session-lineage-invalid",
          "identity"
        );
    }
    if (h.kind === "handoff-published" && F.length !== 1 || h.kind !== "handoff-published" && F.length > 0)
      return S(
        `$.auditEntries[${I}].refs`,
        "session-lineage-invalid",
        "identity"
      );
    for (const w of F) {
      const x = r.get(w.attemptId);
      if (!x || !l(h, x) || h.requestId !== void 0 && h.requestId !== w.requestId || h.attemptId !== void 0 && h.attemptId !== w.attemptId)
        return S(
          `$.auditEntries[${I}].refs`,
          "session-lineage-invalid",
          "identity"
        );
      for (const [j, _] of [
        ["proposal", w.proposalFingerprint],
        ["review", w.reviewFingerprint],
        ["lifecycle", w.lifecycleFingerprint]
      ]) {
        const G = h.refs.some(
          (ie) => ie.type === j && ie.id === _
        );
        if (_ !== void 0 !== G)
          return S(
            `$.auditEntries[${I}].refs`,
            "session-identity-invalid",
            "identity"
          );
      }
      a.set(
        w.fingerprint,
        (a.get(w.fingerprint) ?? 0) + 1
      );
    }
    if (h.eventKind !== void 0) {
      if (v.length !== 1 || h.eventSequence === void 0 || h.attemptId === void 0)
        return S(
          `$.auditEntries[${I}].refs`,
          "session-identity-invalid",
          "identity"
        );
      const w = o.get(
        `${h.attemptId}:${h.eventSequence}`
      );
      if (w !== void 0 && w !== v[0].id)
        return S(
          `$.auditEntries[${I}].refs`,
          "session-identity-invalid",
          "identity"
        );
      if (h.kind === "late-event") {
        const x = `${h.attemptId}:${h.eventSequence}`;
        if (d.has(x))
          return S(
            `$.auditEntries[${I}]`,
            "session-lineage-invalid",
            "identity"
          );
        d.set(x, v[0].id);
      }
    } else if (v.length > 0)
      return S(
        `$.auditEntries[${I}].refs`,
        "session-identity-invalid",
        "identity"
      );
    if (h.compaction) {
      if (h.compaction.preservedTerminalRoots.some(
        (w) => !i.has(w) && !n.has(w)
      ) || h.compaction.preservedHandoffRoots.some(
        (w) => !s.has(w)
      ) || h.compaction.preservedLateEventProofs.some(
        (w) => !r.has(w.attemptId)
      ))
        return S(
          `$.auditEntries[${I}].compaction`,
          "session-identity-invalid",
          "identity"
        );
      for (const w of h.compaction.preservedHandoffRoots)
        a.set(
          w,
          (a.get(w) ?? 0) + 1
        );
      for (const w of h.compaction.preservedLateEventProofs) {
        const x = `${w.attemptId}:${w.sequence}`;
        if (d.has(x))
          return S(
            `$.auditEntries[${I}].compaction.preservedLateEventProofs`,
            "session-lineage-invalid",
            "identity"
          );
        d.set(x, w.fingerprint);
      }
    }
  }
  for (const I of e.handoffs)
    if (a.get(I.fingerprint) !== 1)
      return S("$.handoffs", "session-lineage-invalid", "identity");
  return null;
}, Pc = (e) => {
  var a;
  const t = e.projection.requestId ? e.requests.find(
    (d) => d.requestId === e.projection.requestId
  ) : void 0, r = e.projection.attemptId ? e.attempts.find(
    (d) => d.attemptId === e.projection.attemptId
  ) : void 0;
  if (e.projection.requestId === null != (e.projection.requestStatus === "idle") || e.projection.attemptId === null != (e.projection.attemptStatus === "idle") || t && t.status !== e.projection.requestStatus || r && (r.status !== e.projection.attemptStatus || r.requestId !== e.projection.requestId) || e.projection.requestId !== null && !t || e.projection.attemptId !== null && !r)
    return S("$.projection", "session-lineage-invalid", "identity");
  const i = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), s = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
  for (const [d, l] of e.handoffs.entries()) {
    const g = e.requests.find(
      (p) => p.requestId === l.requestId
    ), u = e.attempts.find(
      (p) => p.attemptId === l.attemptId
    );
    if (i.has(l.handoffId) || n.has(l.fingerprint) || s.has(l.requestId) || o.has(l.attemptId) || !g || !u || u.requestId !== g.requestId || g.publishedHandoffFingerprint !== l.fingerprint || ((a = u.terminal) == null ? void 0 : a.sealedResultFingerprint) !== l.sealedResultFingerprint || u.terminal.resultKind !== l.resultKind || l.sourceRevision >= e.revision)
      return S(`$.handoffs[${d}]`, "session-lineage-invalid", "identity");
    i.add(l.handoffId), n.add(l.fingerprint), s.add(l.requestId), o.add(l.attemptId);
  }
  return e.projection.proposalRef === null != (e.projection.reviewRef === null) || e.projection.proposalRef !== null && !e.handoffs.some(
    (d) => d.requestId === e.projection.requestId && d.proposalId === e.projection.proposalRef && d.reviewId === e.projection.reviewRef
  ) ? S(
    "$.projection.proposalRef",
    "session-lineage-invalid",
    "identity"
  ) : e.sealedResult && !e.attempts.some(
    (d) => {
      var l;
      return ((l = d.terminal) == null ? void 0 : l.reason) === "succeeded" && d.terminal.resultKind === e.sealedResult.kind && d.terminal.sealedResultFingerprint === e.sealedResult.fingerprint;
    }
  ) ? S("$.sealedResult", "session-lineage-invalid", "identity") : null;
}, Bt = (e) => {
  try {
    const t = ze(e, "$");
    if (t) return { ok: !1, diagnostic: t };
    if (!T(
      e,
      [
        "kind",
        "version",
        "identity",
        "revision",
        "policyRef",
        "status",
        "requests",
        "attempts",
        "projection",
        "handoffs",
        "auditHead",
        "auditEntries",
        "recentEventProofs",
        "fingerprint"
      ],
      ["activeRequestId", "sealedResult"]
    ) || e.kind !== "zx-ai-session-artifact-v1" || e.version !== nt || !T(e.identity, ["sessionId"]) || !q(e.identity.sessionId) || !L(e.revision) || !T(e.policyRef, ["id", "version", "fingerprint"]) || e.policyRef.id !== qe.id || e.policyRef.version !== qe.version || e.policyRef.fingerprint !== qe.fingerprint || !mc.has(String(e.status)) || !Array.isArray(e.requests) || e.requests.length > N.maxRequests || !Array.isArray(e.attempts) || e.attempts.length > N.maxAttempts || !Array.isArray(e.handoffs) || e.handoffs.length > N.maxHandoffs || !Array.isArray(e.recentEventProofs) || !M(e.fingerprint))
      return S("$", "session-identity-invalid", "identity");
    if (Object.hasOwn(e, "activeRequestId") && !q(e.activeRequestId))
      return S("$.activeRequestId", "session-identity-invalid", "identity");
    for (const [g, u] of e.requests.entries()) {
      if (!T(
        u,
        [
          "requestId",
          "sessionId",
          "lineage",
          "input",
          "inputFingerprint",
          "policyFingerprint",
          "logicalCreatedAt",
          "status"
        ],
        ["activeAttemptId", "publishedHandoffFingerprint"]
      ) || !q(u.requestId) || u.sessionId !== e.identity.sessionId || !T(
        u.lineage,
        [],
        ["restartedFromRequestId", "supersededRequestId"]
      ) || Object.values(u.lineage).some((f) => !q(f)) || !M(u.inputFingerprint) || u.inputFingerprint !== tn(u.input) || u.policyFingerprint !== qe.fingerprint || !L(u.logicalCreatedAt) || !$s.has(String(u.status)) || u.activeAttemptId !== void 0 && !q(u.activeAttemptId) || u.publishedHandoffFingerprint !== void 0 && !M(u.publishedHandoffFingerprint))
        return S(
          `$.requests[${g}]`,
          "session-identity-invalid",
          "identity"
        );
      const p = rn(u.input);
      if (!p.ok) return p;
    }
    for (const [g, u] of e.attempts.entries()) {
      if (!T(
        u,
        [
          "attemptId",
          "requestId",
          "transportAdmission",
          "status",
          "expectedSequence",
          "sequenceOrigin",
          "acceptedTextBytes",
          "acceptedToolSummaryCount",
          "retryCount"
        ],
        [
          "predecessorAttemptId",
          "lastEventFingerprint",
          "checkpointFingerprint",
          "abortIntent",
          "terminal"
        ]
      ) || !q(u.attemptId) || !q(u.requestId) || !js.has(String(u.status)) || !L(u.expectedSequence) || u.sequenceOrigin !== 0 || !L(u.acceptedTextBytes) || !L(u.acceptedToolSummaryCount) || !L(u.retryCount) || u.retryCount > N.maxRetries || u.predecessorAttemptId !== void 0 && !q(u.predecessorAttemptId) || u.lastEventFingerprint !== void 0 && !M(u.lastEventFingerprint) || u.checkpointFingerprint !== void 0 && !M(u.checkpointFingerprint))
        return S(
          `$.attempts[${g}]`,
          "session-identity-invalid",
          "identity"
        );
      const p = li(
        u.transportAdmission,
        `$.attempts[${g}].transportAdmission`
      );
      if (!p.ok) return p;
      if (p.value.sessionId !== e.identity.sessionId || p.value.requestId !== u.requestId)
        return S(
          `$.attempts[${g}].transportAdmission`,
          "session-identity-invalid",
          "identity"
        );
      if (u.abortIntent !== void 0) {
        if (!T(u.abortIntent, [
          "intentId",
          "revision",
          "logicalRequestedAt",
          "effectId",
          "fingerprint"
        ]) || !q(u.abortIntent.intentId) || !L(u.abortIntent.revision) || !L(u.abortIntent.logicalRequestedAt) || !M(u.abortIntent.effectId) || !M(u.abortIntent.fingerprint))
          return S(
            `$.attempts[${g}].abortIntent`,
            "session-identity-invalid",
            "identity"
          );
        const f = fe(
          "zx-ai-session/v1/abort-intent",
          {
            intentId: u.abortIntent.intentId,
            attemptId: u.attemptId,
            revision: u.abortIntent.revision,
            transportAdmissionFingerprint: p.value.fingerprint
          }
        );
        if (u.abortIntent.fingerprint !== f)
          return S(
            `$.attempts[${g}].abortIntent.fingerprint`,
            "session-identity-invalid",
            "identity"
          );
      }
      if (u.terminal !== void 0) {
        if (!T(
          u.terminal,
          ["reason", "fingerprint"],
          [
            "resultKind",
            "sealedResultFingerprint",
            "diagnosticCode",
            "failureClass"
          ]
        ) || u.terminal.failureClass !== void 0 && !ks(
          u.terminal.reason,
          u.terminal.failureClass
        ) || !vc.has(String(u.terminal.reason)) || !M(u.terminal.fingerprint) || u.terminal.resultKind !== void 0 && !di.has(String(u.terminal.resultKind)) || u.terminal.sealedResultFingerprint !== void 0 && !M(u.terminal.sealedResultFingerprint) || u.terminal.diagnosticCode !== void 0 && (typeof u.terminal.diagnosticCode != "string" || !Ds.has(u.terminal.diagnosticCode)))
          return S(
            `$.attempts[${g}].terminal`,
            "session-identity-invalid",
            "identity"
          );
        const { fingerprint: f, ...m } = u.terminal;
        if (u.terminal.fingerprint !== Rt({
          attemptId: u.attemptId,
          terminal: m
        }))
          return S(
            `$.attempts[${g}].terminal.fingerprint`,
            "session-identity-invalid",
            "identity"
          );
      }
    }
    const r = qc(e.projection);
    if (!r.ok) return r;
    for (const [g, u] of e.handoffs.entries()) {
      const p = on(u, `$.handoffs[${g}]`);
      if (!p.ok) return p;
      if (p.value.sessionId !== e.identity.sessionId)
        return S(
          `$.handoffs[${g}].sessionId`,
          "session-identity-invalid",
          "identity"
        );
    }
    if (e.sealedResult !== void 0) {
      const g = an(
        e.sealedResult,
        "$.sealedResult"
      );
      if (!g.ok) return g;
    }
    const i = Tc(e.auditEntries, e.auditHead);
    if (!i.ok) return i;
    const n = /* @__PURE__ */ new Set();
    for (const [g, u] of e.recentEventProofs.entries()) {
      if (!T(u, ["attemptId", "sequence", "fingerprint"]) || !q(u.attemptId) || !L(u.sequence) || !M(u.fingerprint) || n.has(`${u.attemptId}:${u.sequence}`))
        return S(
          `$.recentEventProofs[${g}]`,
          "session-identity-invalid",
          "identity"
        );
      n.add(`${u.attemptId}:${u.sequence}`);
    }
    const s = Ae(
      e
    ), o = Bc(s);
    if (o) return o;
    const a = Cs(
      be(s)
    );
    if (s.fingerprint !== a)
      return S("$.fingerprint", "session-identity-invalid", "identity");
    const d = Ts(s);
    if (d) return { ok: !1, diagnostic: d };
    const l = Pc(s);
    if (l) return l;
    for (const g of s.requests) {
      const u = s.attempts.filter(
        (p) => p.requestId === g.requestId
      );
      if (g.activeAttemptId && !u.some(
        (p) => p.attemptId === g.activeAttemptId
      ))
        return S(
          "$.requests.activeAttemptId",
          "session-lineage-invalid",
          "identity"
        );
      if (g.publishedHandoffFingerprint && !s.handoffs.some(
        (p) => p.requestId === g.requestId && p.fingerprint === g.publishedHandoffFingerprint
      ))
        return S(
          "$.requests.publishedHandoffFingerprint",
          "session-lineage-invalid",
          "identity"
        );
    }
    return { ok: !0, value: s };
  } catch {
    return S("$", "session-input-invalid", "contract");
  }
}, $c = [
  "kind",
  "sessionId",
  "expectedRevision",
  "expectedSessionFingerprint"
], Xe = (e, t, r = []) => T(
  e,
  [...$c, ...t],
  ["logicalTime", ...r]
), jc = (e) => !q(e.sessionId) || !L(e.expectedRevision) || !M(e.expectedSessionFingerprint) || e.logicalTime !== void 0 && !L(e.logicalTime) ? S("$", "session-input-invalid", "command") : null, Dc = (e) => {
  try {
    const t = ze(e, "$");
    if (t) return { ok: !1, diagnostic: t };
    if (!e || typeof e != "object" || Array.isArray(e))
      return S("$", "session-input-invalid", "command");
    const r = { ...e }, i = r.kind;
    let n = !1;
    switch (i) {
      case "create-request":
        n = Xe(
          r,
          ["requestId", "input", "logicalCreatedAt"],
          ["restartedFromRequestId"]
        );
        break;
      case "restart":
        n = Xe(r, [
          "requestId",
          "input",
          "logicalCreatedAt",
          "restartedFromRequestId"
        ]);
        break;
      case "supersede":
        n = Xe(r, [
          "requestId",
          "input",
          "logicalCreatedAt",
          "supersededRequestId"
        ]);
        break;
      case "start-attempt":
        n = Xe(r, [
          "requestId",
          "attemptId",
          "transportAdmission"
        ]);
        break;
      case "accept-event":
        n = Xe(r, ["event"]);
        break;
      case "acknowledge-abort":
        n = Xe(r, ["requestId", "attemptId", "event"]);
        break;
      case "request-abort":
        n = Xe(r, [
          "requestId",
          "attemptId",
          "intentId",
          "logicalRequestedAt"
        ]);
        break;
      case "retry":
        n = Xe(r, [
          "requestId",
          "attemptId",
          "predecessorAttemptId",
          "transportAdmission"
        ]);
        break;
      case "resume":
        n = Xe(r, [
          "requestId",
          "attemptId",
          "checkpointFingerprint",
          "expectedSequence",
          "expectedEventFingerprint",
          "expectedAuditHead"
        ]);
        break;
      case "publish-handoff":
        n = Xe(r, ["requestId", "attemptId", "receipt"]);
        break;
      case "close-session":
        n = Xe(r, [], ["force"]);
        break;
      default:
        return S("$.kind", "session-unsupported", "command");
    }
    if (!n) return S("$", "session-input-invalid", "command");
    const s = jc(r);
    if (s) return s;
    if (["create-request", "restart", "supersede"].includes(String(i))) {
      if (!q(r.requestId) || !L(r.logicalCreatedAt) || r.restartedFromRequestId !== void 0 && !q(r.restartedFromRequestId) || r.supersededRequestId !== void 0 && !q(r.supersededRequestId))
        return S("$", "session-input-invalid", "command");
      const o = rn(r.input);
      if (!o.ok) return o;
      r.input = o.value;
    }
    if (i === "start-attempt" || i === "retry") {
      if (!q(r.requestId) || !q(r.attemptId) || i === "retry" && !q(r.predecessorAttemptId))
        return S("$", "session-input-invalid", "command");
      const o = li(
        r.transportAdmission,
        "$.transportAdmission"
      );
      if (!o.ok) return o;
      r.transportAdmission = o.value;
    }
    if (i === "accept-event" || i === "acknowledge-abort") {
      const o = nc(r.event);
      if (!o.ok) return o;
      if (i === "acknowledge-abort" && (o.value.kind !== "abort-acknowledged" || !q(r.requestId) || !q(r.attemptId)))
        return S("$.event.kind", "session-input-invalid", "command");
      r.event = o.value;
    }
    if (i === "request-abort" && (!q(r.requestId) || !q(r.attemptId) || !q(r.intentId) || !L(r.logicalRequestedAt)) || i === "resume" && (!q(r.requestId) || !q(r.attemptId) || !M(r.checkpointFingerprint) || !L(r.expectedSequence) || !M(r.expectedEventFingerprint) || !$r(r.expectedAuditHead)))
      return S("$", "session-input-invalid", "command");
    if (i === "publish-handoff") {
      if (!q(r.requestId) || !q(r.attemptId))
        return S("$", "session-input-invalid", "command");
      const o = on(r.receipt, "$.receipt");
      if (!o.ok) return o;
      r.receipt = o.value;
    }
    return i === "close-session" && r.force !== void 0 && typeof r.force != "boolean" ? S("$.force", "session-input-invalid", "command") : {
      ok: !0,
      value: Ae(r)
    };
  } catch {
    return S("$", "session-input-invalid", "command");
  }
}, _s = (e) => c({
  ...e,
  fingerprint: fe("zx-ai-session/v1/audit", e)
}), Bn = (e) => e.kind === "session-created" || e.kind === "handoff-published" || e.kind === "session-closed" || e.kind === "compaction" || e.refs.some(
  (t) => t.type === "handoff" || t.type === "terminal" || t.type === "sealed-result"
), zc = (e, t) => {
  var h;
  const r = Math.max(
    1,
    N.maxAuditEntries - t
  );
  if (e.length <= r)
    return { entries: e, compacted: !1, droppedCount: 0 };
  const i = ((h = e[0]) == null ? void 0 : h.kind) === "compaction" ? e[0].compaction : void 0, n = [
    ...(i == null ? void 0 : i.preservedTerminalRoots) ?? [],
    ...e.filter(Bn).flatMap(
      (v) => v.refs.filter(
        (F) => F.type === "terminal" || F.type === "sealed-result"
      ).map((F) => F.id)
    )
  ], s = [
    ...(i == null ? void 0 : i.preservedHandoffRoots) ?? [],
    ...e.filter(Bn).flatMap(
      (v) => v.refs.filter((F) => F.type === "handoff").map((F) => F.id)
    )
  ], o = [...new Set(n)].sort(), a = [...new Set(s)].sort(), d = /* @__PURE__ */ new Map();
  for (const v of (i == null ? void 0 : i.preservedLateEventProofs) ?? [])
    d.set(`${v.attemptId}:${v.sequence}`, v);
  for (const v of e) {
    if (v.kind !== "late-event" || v.attemptId === void 0 || v.eventSequence === void 0)
      continue;
    const F = v.refs.find((j) => j.type === "event");
    if (!F) continue;
    const w = `${v.attemptId}:${v.eventSequence}`, x = d.get(w);
    if (x && x.fingerprint !== F.id)
      return { entries: e, compacted: !1, droppedCount: 0 };
    d.set(w, {
      attemptId: v.attemptId,
      sequence: v.eventSequence,
      fingerprint: F.id
    });
  }
  const l = [...d.values()].sort(
    (v, F) => {
      const w = `${v.attemptId}\0${v.sequence.toString().padStart(10, "0")}`, x = `${F.attemptId}\0${F.sequence.toString().padStart(10, "0")}`;
      return w < x ? -1 : w > x ? 1 : 0;
    }
  );
  if (o.length + a.length + l.length > N.maxAuditEntries - t)
    return { entries: e, compacted: !1, droppedCount: 0 };
  const g = e[0], u = e[e.length - 1], p = (i == null ? void 0 : i.droppedStartSequence) ?? g.sequence, f = u.sequence - p + 1, m = u.sequence + 1, I = [_s({
    sequence: m,
    kind: "compaction",
    previousFingerprint: null,
    refs: [
      { id: `dropped:${f}`, type: "compaction" },
      {
        id: `terminal-roots:${o.length}`,
        type: "compaction"
      },
      {
        id: `handoff-roots:${a.length}`,
        type: "compaction"
      },
      {
        id: `late-event-proofs:${l.length}`,
        type: "compaction"
      }
    ],
    compaction: {
      priorHead: {
        sequence: u.sequence,
        fingerprint: u.fingerprint
      },
      droppedStartSequence: p,
      droppedEndSequence: u.sequence,
      droppedCount: f,
      leftBoundaryFingerprint: (i == null ? void 0 : i.leftBoundaryFingerprint) ?? g.fingerprint,
      rightBoundaryFingerprint: u.fingerprint,
      preservedTerminalRoots: o,
      preservedHandoffRoots: a,
      preservedLateEventProofs: l
    }
  })];
  return I.length > r ? { entries: e, compacted: !1, droppedCount: 0 } : c({
    entries: I,
    compacted: !0,
    droppedCount: f
  });
}, Ls = (e, t) => {
  let r = e.auditEntries, i = e.auditHead, n = !1;
  if (r.length >= N.maxAuditEntries) {
    const d = zc(r, 1);
    if (!d.compacted || d.entries.length >= N.maxAuditEntries)
      return c({
        ok: !1,
        diagnostic: b({
          code: "session-resource-exceeded",
          stage: "command",
          path: "$.auditEntries",
          count: r.length + 1
        }),
        head: i,
        entries: r
      });
    r = d.entries;
    const l = r[r.length - 1];
    i = c({
      sequence: l.sequence,
      fingerprint: l.fingerprint
    }), n = !0;
  }
  const s = i.sequence + 1, o = _s({
    sequence: s,
    kind: t.kind,
    ...t.commandKind ? { commandKind: t.commandKind } : {},
    ...t.eventKind ? { eventKind: t.eventKind } : {},
    ...t.eventSequence !== void 0 ? { eventSequence: t.eventSequence } : {},
    ...t.requestId ? { requestId: t.requestId } : {},
    ...t.attemptId ? { attemptId: t.attemptId } : {},
    ...t.effectId ? { effectId: t.effectId } : {},
    previousFingerprint: i.fingerprint,
    refs: [...t.refs]
  }), a = c({
    sequence: s,
    fingerprint: o.fingerprint
  });
  return c({
    ok: !0,
    head: a,
    entries: [...r, o],
    compacted: n
  });
}, Au = c({
  id: "zx-ai-session-host-persistence-v1",
  storageOwner: "host",
  codecOnly: !0,
  casFields: ["fingerprint", "revision", "auditHead.fingerprint"],
  forbidAutoUpgrade: !0,
  forbidLiveResumeFromHistorical: !0,
  historicalMode: "audit-only"
}), Eu = (e) => {
  var n, s;
  const t = ze(e, "$");
  if (t || !T(e, ["session"], ["mode"]) || e.mode !== void 0 && !["current", "historical"].includes(e.mode))
    return c({
      status: "failure",
      entries: [],
      head: { sequence: 0, fingerprint: null },
      diagnostic: t ?? b({
        code: "session-input-invalid",
        stage: "contract",
        path: "$"
      })
    });
  if (e.mode === "historical" && ((n = e.session) == null ? void 0 : n.version) !== "1.0.0")
    return c({
      status: "unsupported",
      entries: [],
      head: ((s = e.session) == null ? void 0 : s.auditHead) ?? { sequence: 0, fingerprint: null },
      diagnostic: b({
        code: "session-historical-unsupported",
        stage: "historical",
        path: "$.version"
      })
    });
  const r = Bt(e.session);
  if (!r.ok)
    return c({
      status: "failure",
      entries: [],
      head: { sequence: 0, fingerprint: null },
      diagnostic: r.diagnostic
    });
  const i = r.value;
  return e.mode === "historical" ? i.version !== "1.0.0" ? c({
    status: "unsupported",
    entries: [],
    head: i.auditHead,
    diagnostic: b({
      code: "session-historical-unsupported",
      stage: "historical",
      path: "$.version"
    })
  }) : c({
    status: "success",
    entries: i.auditEntries,
    head: i.auditHead,
    diagnostic: null
  }) : c({
    status: "success",
    entries: i.auditEntries,
    head: i.auditHead,
    diagnostic: null
  });
}, Oc = [
  "create-request",
  "start-attempt",
  "accept-event",
  "request-abort",
  "acknowledge-abort",
  "retry",
  "resume",
  "restart",
  "supersede",
  "publish-handoff",
  "close-session"
], mr = (e) => c(
  Object.fromEntries(Oc.map((t) => [t, e]))
), Nc = c({
  open: mr("evaluate"),
  closing: {
    ...mr("conflict"),
    "accept-event": "evaluate",
    "acknowledge-abort": "evaluate",
    "close-session": "evaluate"
  },
  closed: {
    ...mr("conflict"),
    "close-session": "evaluate"
  },
  corrupt: {
    ...mr("conflict"),
    "close-session": "evaluate"
  },
  unsupported: {
    ...mr("conflict"),
    "close-session": "evaluate"
  }
}), _c = [
  "attempt-started",
  "assistant-delta",
  "progress",
  "tool-summary",
  "checkpoint",
  "abort-acknowledged",
  "attempt-succeeded",
  "attempt-failed",
  "transport-disconnected"
], gt = (e) => Object.fromEntries(_c.map((t) => [t, e])), Lc = c({
  created: {
    ...gt("failure"),
    "attempt-started": "evaluate",
    "attempt-failed": "evaluate",
    "transport-disconnected": "evaluate"
  },
  starting: {
    ...gt("failure"),
    "attempt-started": "evaluate",
    "attempt-failed": "evaluate",
    "transport-disconnected": "evaluate"
  },
  streaming: {
    ...gt("evaluate"),
    "attempt-started": "failure",
    "abort-acknowledged": "failure"
  },
  "abort-requested": gt("evaluate"),
  suspended: gt("failure"),
  succeeded: gt("failure"),
  failed: gt("failure"),
  aborted: gt("failure"),
  superseded: gt("failure")
}), vr = (e, t, r = "session-terminal") => ({
  outcome: "reject",
  status: e,
  diagnostic: b({
    code: r,
    stage: "command",
    path: t
  })
}), Vc = (e, t) => {
  if (Nc[e.status][t.kind] !== "evaluate")
    return vr("conflict", "$.status");
  if (t.kind === "start-attempt") {
    const i = e.requests.find(
      (n) => n.requestId === t.requestId
    );
    if (!i || i.status !== "prepared")
      return vr("conflict", "$.request.status");
  }
  if (t.kind === "resume" && !e.attempts.find(
    (n) => n.attemptId === t.attemptId
  ))
    return vr("conflict", "$.attempt.status");
  if (t.kind === "accept-event" || t.kind === "acknowledge-abort") {
    const i = t.event;
    if (e.status === "closing" && ![
      "abort-acknowledged",
      "attempt-failed",
      "transport-disconnected"
    ].includes(i.kind))
      return vr("failure", "$.event.kind", "session-event-after-terminal");
    const n = e.attempts.find(
      (a) => a.attemptId === i.attemptId
    );
    if (!n)
      return { outcome: "evaluate" };
    if (e.recentEventProofs.some(
      (a) => a.attemptId === i.attemptId && a.sequence === i.sequence
    )) return { outcome: "evaluate" };
    if (Lc[n.status][i.kind] === "failure")
      return vr("failure", "$.event.kind", "session-event-after-terminal");
  }
  return { outcome: "evaluate" };
}, Hc = (e) => fe("zx-ai-session/v1/receipt", e), yt = (e) => c({
  ...e,
  fingerprint: Hc(e)
}), H = (e, t, r) => c({
  status: t,
  session: e,
  diagnostic: r
}), Kc = (e, t) => t.sessionId !== e.identity.sessionId ? b({
  code: "session-identity-invalid",
  stage: "command",
  path: "$.sessionId"
}) : t.expectedRevision !== e.revision || t.expectedSessionFingerprint !== e.fingerprint ? b({
  code: "session-revision-conflict",
  stage: "command",
  path: "$.expectedRevision",
  count: t.expectedRevision,
  fingerprint: e.fingerprint
}) : null, Mc = (e, t) => {
  if (t.logicalTime === void 0 || e.requests.length === 0)
    return null;
  const r = e.activeRequestId ? ut(e, e.activeRequestId) : void 0, i = e.requests.reduce(
    (s, o) => Math.max(s, o.logicalCreatedAt),
    0
  ), n = (r == null ? void 0 : r.logicalCreatedAt) ?? i;
  return t.logicalTime < n ? {
    status: "conflict",
    diagnostic: b({
      code: "session-revision-conflict",
      stage: "command",
      path: "$.logicalTime",
      count: t.logicalTime
    })
  } : t.logicalTime - n > N.maxLogicalDuration ? {
    status: "failure",
    diagnostic: b({
      code: "session-resource-exceeded",
      stage: "command",
      path: "$.logicalTime",
      count: t.logicalTime - n
    })
  } : null;
}, Nr = (e, t) => [
  ...e.requests.filter(
    (r) => r.requestId !== t.requestId
  ),
  t
].sort(
  (r, i) => r.requestId < i.requestId ? -1 : r.requestId > i.requestId ? 1 : 0
), Vt = (e, t) => [
  ...e.attempts.filter(
    (r) => r.attemptId !== t.attemptId
  ),
  t
].sort(
  (r, i) => r.attemptId < i.attemptId ? -1 : r.attemptId > i.attemptId ? 1 : 0
), Vs = (e, t) => [
  ...e.recentEventProofs.filter(
    (r) => !(r.attemptId === t.attemptId && r.sequence === t.sequence)
  ),
  c({
    attemptId: t.attemptId,
    sequence: t.sequence,
    fingerprint: t.fingerprint
  })
].slice(-N.maxEventsPerAttempt), Ht = (e, t, r, i, n) => fe("zx-ai-session/v1/effect-id", {
  kind: e,
  sessionId: t,
  requestId: r,
  attemptId: i,
  revision: n
}).slice(0, 48), qt = (e, t, r) => {
  const i = r ? nn(r.status) : !1, n = !!(r && e.attempts.some(
    (o) => o.predecessorAttemptId === r.attemptId && o.requestId === r.requestId
  )), s = i && !!(r != null && r.terminal) && qr.retryableTerminalReasons.includes(
    r.terminal.reason
  ) && !(t != null && t.publishedHandoffFingerprint) && !n && ((r == null ? void 0 : r.retryCount) ?? 0) < N.maxRetries;
  return {
    canAbort: !!(r && Qr(r.status) && r.status !== "abort-requested"),
    canRetry: !!s,
    canResume: !!(r && r.status === "suspended" && r.checkpointFingerprint && r.transportAdmission.capabilities.resume === "resume:same-attempt-checkpoint-v1"),
    canSupersede: !!(t && t.status === "active")
  };
}, Cu = (e) => {
  const t = ze(e, "$");
  if (t)
    return c({
      status: "failure",
      session: Zt({
        kind: "zx-ai-session-artifact-v1",
        version: "1.0.0",
        identity: { sessionId: "invalid" },
        revision: 0,
        policyRef: qe,
        status: "corrupt",
        requests: [],
        attempts: [],
        projection: gr(),
        handoffs: [],
        auditHead: { sequence: 0, fingerprint: null },
        auditEntries: [],
        recentEventProofs: []
      }),
      diagnostic: t
    });
  if (!T(e, ["sessionId"], ["policyRef", "logicalCreatedAt"]) || !q(e.sessionId))
    return c({
      status: "failure",
      session: Zt({
        kind: "zx-ai-session-artifact-v1",
        version: "1.0.0",
        identity: { sessionId: "invalid" },
        revision: 0,
        policyRef: qe,
        status: "corrupt",
        requests: [],
        attempts: [],
        projection: gr(),
        handoffs: [],
        auditHead: { sequence: 0, fingerprint: null },
        auditEntries: [],
        recentEventProofs: []
      }),
      diagnostic: b({
        code: "session-input-invalid",
        stage: "contract",
        path: "$.sessionId"
      })
    });
  if (e.policyRef !== void 0) {
    const s = Sc(
      e.policyRef,
      "$.policyRef"
    );
    if (!s.ok)
      return c({
        status: "unsupported",
        session: Zt({
          kind: "zx-ai-session-artifact-v1",
          version: "1.0.0",
          identity: { sessionId: e.sessionId },
          revision: 0,
          policyRef: qe,
          status: "unsupported",
          requests: [],
          attempts: [],
          projection: gr(),
          handoffs: [],
          auditHead: { sequence: 0, fingerprint: null },
          auditEntries: [],
          recentEventProofs: []
        }),
        diagnostic: s.diagnostic
      });
  }
  const r = Zt({
    kind: "zx-ai-session-artifact-v1",
    version: "1.0.0",
    identity: { sessionId: e.sessionId },
    revision: 0,
    policyRef: qe,
    status: "open",
    requests: [],
    attempts: [],
    projection: gr(),
    handoffs: [],
    auditHead: { sequence: 0, fingerprint: null },
    auditEntries: [],
    recentEventProofs: []
  }), i = Ls(r, {
    kind: "session-created",
    refs: [{ id: e.sessionId, type: "session" }]
  });
  if (!i.ok)
    return c({
      status: "failure",
      session: r,
      diagnostic: i.diagnostic
    });
  const n = Zt({
    kind: "zx-ai-session-artifact-v1",
    version: "1.0.0",
    identity: { sessionId: e.sessionId },
    revision: 0,
    policyRef: qe,
    status: "open",
    requests: [],
    attempts: [],
    projection: gr(),
    handoffs: [],
    auditHead: i.head,
    auditEntries: i.entries,
    recentEventProofs: []
  });
  return c({
    status: "accepted",
    session: n,
    receipt: yt({
      commandKind: "create-request",
      status: "accepted",
      sessionId: n.identity.sessionId,
      revision: n.revision,
      sessionFingerprint: n.fingerprint,
      effectIds: []
    }),
    effects: []
  });
}, dt = (e, t, r, i, n = "command-accepted", s = {}) => {
  var h, v;
  const o = {
    ...t,
    revision: e.revision + 1
  }, a = s.attemptId ? o.attempts.find(
    (F) => F.attemptId === s.attemptId
  ) : void 0, d = o.attempts.filter(
    (F) => {
      var w, x;
      return F.terminal && ((x = (w = lt(e, F.attemptId)) == null ? void 0 : w.terminal) == null ? void 0 : x.fingerprint) !== F.terminal.fingerprint;
    }
  ), l = r.kind === "publish-handoff" ? r.receipt : void 0, g = i.length > 0 && n === "command-accepted" ? "effect-published" : n, u = s.effectId ?? ((h = i[0]) == null ? void 0 : h.effectId), p = [
    { id: e.identity.sessionId, type: "session" },
    { id: o.policyRef.fingerprint, type: "policy" },
    ...s.requestId ? [{ id: s.requestId, type: "request" }] : [],
    ...s.attemptId ? [{ id: s.attemptId, type: "attempt" }] : [],
    ...d.flatMap((F) => [
      { id: F.requestId, type: "request" },
      { id: F.attemptId, type: "attempt" }
    ]),
    ..."event" in r ? [{ id: r.event.fingerprint, type: "event" }] : [],
    ...i.map((F) => ({ id: F.effectId, type: "effect" })),
    ...a != null && a.terminal ? [{ id: a.terminal.fingerprint, type: "terminal" }] : [],
    ...(v = a == null ? void 0 : a.terminal) != null && v.sealedResultFingerprint ? [
      {
        id: a.terminal.sealedResultFingerprint,
        type: "sealed-result"
      }
    ] : [],
    ...d.flatMap((F) => [
      { id: F.terminal.fingerprint, type: "terminal" },
      ...F.terminal.sealedResultFingerprint ? [
        {
          id: F.terminal.sealedResultFingerprint,
          type: "sealed-result"
        }
      ] : []
    ]),
    ...l ? [
      { id: l.fingerprint, type: "handoff" },
      ...l.proposalFingerprint ? [{ id: l.proposalFingerprint, type: "proposal" }] : [],
      ...l.reviewFingerprint ? [{ id: l.reviewFingerprint, type: "review" }] : [],
      ...l.lifecycleFingerprint ? [
        {
          id: l.lifecycleFingerprint,
          type: "lifecycle"
        }
      ] : []
    ] : [],
    ...s.refs ?? []
  ].filter(
    (F, w, x) => x.findIndex(
      (j) => j.type === F.type && j.id === F.id
    ) === w
  ).sort((F, w) => {
    const x = `${F.type}\0${F.id}`, j = `${w.type}\0${w.id}`;
    return x < j ? -1 : x > j ? 1 : 0;
  }), f = Ls(o, {
    kind: g,
    commandKind: r.kind,
    ...s,
    ...u ? { effectId: u } : {},
    ..."event" in r ? { eventSequence: r.event.sequence } : {},
    refs: p
  });
  if (!f.ok)
    return H(e, "failure", f.diagnostic);
  const m = Zt({
    ...o,
    auditHead: f.head,
    auditEntries: f.entries
  }), y = Ts(m);
  if (y)
    return H(e, "failure", y);
  const I = i.map(
    (F) => c({
      ...F,
      sourceRevision: m.revision,
      sourceFingerprint: m.fingerprint
    })
  );
  return c({
    status: "accepted",
    session: m,
    receipt: yt({
      commandKind: r.kind,
      status: "accepted",
      sessionId: m.identity.sessionId,
      revision: m.revision,
      sessionFingerprint: m.fingerprint,
      ...s.requestId ? { requestId: s.requestId } : {},
      ...s.attemptId ? { attemptId: s.attemptId } : {},
      effectIds: I.map((F) => F.effectId)
    }),
    effects: I
  });
}, Uc = (e, t) => {
  if (e.activeRequestId && t.kind !== "supersede")
    return H(
      e,
      "busy",
      b({
        code: "session-busy",
        stage: "command",
        path: "$.activeRequestId",
        requestRef: e.activeRequestId
      })
    );
  if (e.requests.some((d) => d.requestId === t.requestId))
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.requestId",
        requestRef: t.requestId
      })
    );
  if (e.requests.length >= N.maxRequests)
    return H(
      e,
      "failure",
      b({
        code: "session-resource-exceeded",
        stage: "command",
        path: "$.requests",
        count: e.requests.length + 1
      })
    );
  const r = rn(t.input);
  if (!r.ok) return H(e, "failure", r.diagnostic);
  let i = e.requests, n = e.attempts, s = [], o = e.projection;
  if (t.kind === "supersede") {
    const d = ut(e, t.supersededRequestId);
    if (!d || e.activeRequestId !== t.supersededRequestId)
      return H(
        e,
        "conflict",
        b({
          code: "session-revision-conflict",
          stage: "command",
          path: "$.supersededRequestId",
          requestRef: t.supersededRequestId
        })
      );
    const l = qs(e, d.requestId), g = c({
      ...d,
      status: "superseded",
      activeAttemptId: void 0
    });
    if (i = Nr(e, g), l && Qr(l.status)) {
      const u = c({
        ...l,
        status: "superseded",
        terminal: {
          reason: "superseded",
          fingerprint: Rt({
            attemptId: l.attemptId,
            terminal: { reason: "superseded" }
          })
        }
      });
      if (n = Vt({ ...e, attempts: n }, u), l.abortIntent == null) {
        const p = Ht(
          "transport-abort",
          e.identity.sessionId,
          d.requestId,
          l.attemptId,
          e.revision + 1
        );
        s = [
          c({
            effectId: p,
            kind: "transport-abort",
            sessionId: e.identity.sessionId,
            requestId: d.requestId,
            attemptId: l.attemptId,
            sourceRevision: e.revision + 1,
            sourceFingerprint: e.fingerprint,
            idempotencyKey: p,
            abortIntentId: `supersede:${l.attemptId}`,
            transportAdmission: l.transportAdmission
          })
        ];
      }
    }
  }
  const a = c({
    requestId: t.requestId,
    sessionId: e.identity.sessionId,
    lineage: {
      ...t.kind === "restart" ? { restartedFromRequestId: t.restartedFromRequestId } : {},
      ...t.kind === "create-request" && t.restartedFromRequestId ? { restartedFromRequestId: t.restartedFromRequestId } : {},
      ...t.kind === "supersede" ? { supersededRequestId: t.supersededRequestId } : {}
    },
    input: r.value,
    inputFingerprint: tn(r.value),
    policyFingerprint: qe.fingerprint,
    logicalCreatedAt: t.logicalCreatedAt,
    status: "prepared"
  });
  return i = [
    ...i.filter((d) => d.requestId !== a.requestId),
    a
  ].sort(
    (d, l) => d.requestId < l.requestId ? -1 : d.requestId > l.requestId ? 1 : 0
  ), o = Ps(
    a,
    null,
    qt(e, a, null)
  ), dt(
    e,
    {
      ...be(e),
      activeRequestId: a.requestId,
      requests: i,
      attempts: n,
      projection: o
    },
    t,
    s,
    "command-accepted",
    { requestId: a.requestId }
  );
}, Hs = (e, t) => {
  var g;
  const r = ut(e, t.requestId);
  if (!r || r.sessionId !== e.identity.sessionId)
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "command",
        path: "$.requestId",
        requestRef: t.requestId
      })
    );
  if (e.activeRequestId && e.activeRequestId !== r.requestId)
    return H(
      e,
      "busy",
      b({
        code: "session-busy",
        stage: "command",
        path: "$.activeRequestId"
      })
    );
  if (r.status !== "prepared" && r.status !== "active" && r.status !== "failed")
    return H(
      e,
      "conflict",
      b({
        code: "session-terminal",
        stage: "command",
        path: "$.request.status",
        requestRef: r.requestId
      })
    );
  if (lt(e, t.attemptId))
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "identity",
        path: "$.attemptId",
        attemptRef: t.attemptId
      })
    );
  const i = t.transportAdmission;
  if (i.sessionId !== e.identity.sessionId || i.sourceRevision !== e.revision || i.sourceSessionFingerprint !== e.fingerprint || i.requestId !== r.requestId || i.requestKind !== r.input.kind || i.requestInputFingerprint !== r.inputFingerprint || i.policyFingerprint !== r.policyFingerprint)
    return H(
      e,
      "conflict",
      b({
        code: "session-transport-unsupported",
        stage: "transport-admission",
        path: "$.transportAdmission"
      })
    );
  if (e.attempts.length >= N.maxAttempts)
    return H(
      e,
      "failure",
      b({
        code: "session-resource-exceeded",
        stage: "command",
        path: "$.attempts",
        count: e.attempts.length + 1
      })
    );
  const n = t.kind === "retry" ? t.predecessorAttemptId : void 0, s = c({
    attemptId: t.attemptId,
    requestId: r.requestId,
    ...n ? { predecessorAttemptId: n } : {},
    transportAdmission: i,
    status: "starting",
    expectedSequence: 0,
    sequenceOrigin: 0,
    acceptedTextBytes: 0,
    acceptedToolSummaryCount: 0,
    retryCount: n ? (((g = lt(e, n)) == null ? void 0 : g.retryCount) ?? 0) + 1 : 0
  }), o = c({
    ...r,
    status: "active",
    activeAttemptId: s.attemptId
  }), a = Ht(
    "transport-start",
    e.identity.sessionId,
    r.requestId,
    s.attemptId,
    e.revision + 1
  ), d = c({
    effectId: a,
    kind: "transport-start",
    sessionId: e.identity.sessionId,
    requestId: r.requestId,
    attemptId: s.attemptId,
    sourceRevision: e.revision + 1,
    sourceFingerprint: e.fingerprint,
    idempotencyKey: a,
    transportAdmission: i,
    requestProjection: {
      inputFingerprint: r.inputFingerprint,
      kind: r.input.kind,
      policyFingerprint: r.policyFingerprint
    }
  }), l = Or(
    Ps(
      o,
      s,
      qt(e, o, s)
    ),
    o,
    s,
    qt(e, o, s)
  );
  return dt(
    e,
    {
      ...be(e),
      activeRequestId: r.requestId,
      requests: Nr(e, o),
      attempts: Vt(e, s),
      projection: l
    },
    t,
    [d],
    "effect-published",
    { requestId: r.requestId, attemptId: s.attemptId, effectId: a }
  );
}, Pn = (e, t, r, i, n) => {
  const s = e.auditEntries.find(
    (d) => d.kind === "late-event" && d.attemptId === i.attemptId && d.eventSequence === n.sequence
  ), o = e.auditEntries.flatMap((d) => {
    var l;
    return ((l = d.compaction) == null ? void 0 : l.preservedLateEventProofs) ?? [];
  }).find(
    (d) => d.attemptId === i.attemptId && d.sequence === n.sequence
  );
  if (s || o)
    return (s ? s.refs.some(
      (l) => l.type === "event" && l.id === n.fingerprint
    ) : o.fingerprint === n.fingerprint) ? c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        requestId: r.requestId,
        attemptId: i.attemptId,
        effectIds: []
      })
    }) : H(
      e,
      "failure",
      b({
        code: "session-event-duplicate-conflict",
        stage: "event",
        path: "$.event.sequence",
        count: n.sequence,
        attemptRef: i.attemptId
      })
    );
  const a = c({
    ...i,
    expectedSequence: i.expectedSequence + 1,
    lastEventFingerprint: n.fingerprint
  });
  return dt(
    e,
    {
      ...be(e),
      attempts: Vt(e, a),
      recentEventProofs: Vs(e, n)
    },
    t,
    [],
    "late-event",
    {
      requestId: r.requestId,
      attemptId: i.attemptId,
      eventKind: n.kind,
      eventSequence: n.sequence
    }
  );
}, Gc = (e, t) => {
  var I;
  const r = t.event;
  if (r.sessionId !== e.identity.sessionId)
    return H(
      e,
      "failure",
      b({
        code: "session-identity-invalid",
        stage: "event",
        path: "$.sessionId",
        sessionRef: r.sessionId
      })
    );
  const i = lt(e, r.attemptId);
  if (!i)
    return H(
      e,
      "failure",
      b({
        code: "session-identity-invalid",
        stage: "event",
        path: "$.attemptId",
        attemptRef: r.attemptId
      })
    );
  if (r.requestId !== i.requestId)
    return H(
      e,
      "failure",
      b({
        code: "session-identity-invalid",
        stage: "event",
        path: "$.requestId",
        requestRef: r.requestId
      })
    );
  const n = ut(e, i.requestId);
  if (!n || n.sessionId !== e.identity.sessionId)
    return H(
      e,
      "failure",
      b({
        code: "session-identity-invalid",
        stage: "event",
        path: "$.requestId",
        requestRef: i.requestId
      })
    );
  if (t.kind === "acknowledge-abort" && (t.requestId !== n.requestId || t.attemptId !== i.attemptId))
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "command",
        path: "$.attemptId"
      })
    );
  const s = oc(e, i, r);
  if (!s.ok)
    return s.diagnostic.code === "session-event-after-terminal" && r.kind === "abort-acknowledged" ? Pn(e, t, n, i, r) : H(e, "failure", s.diagnostic);
  if (s.mode === "idempotent")
    return c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        requestId: n.requestId,
        attemptId: i.attemptId,
        effectIds: []
      })
    });
  if (i.status === "abort-requested" && r.kind !== "abort-acknowledged" && r.kind !== "attempt-failed" && r.kind !== "transport-disconnected")
    return Pn(e, t, n, i, r);
  let o = {
    ...i,
    expectedSequence: i.expectedSequence + 1,
    lastEventFingerprint: r.fingerprint,
    acceptedTextBytes: i.acceptedTextBytes + (r.payload.kind === "assistant-delta" ? new TextEncoder().encode(r.payload.text).byteLength : 0),
    acceptedToolSummaryCount: i.acceptedToolSummaryCount + (r.payload.kind === "tool-summary" ? 1 : 0)
  }, a = n, d = e.projection, l = null, g = e.sealedResult, u = [];
  const p = e.handoffs;
  if (r.payload.kind === "attempt-started") {
    if (i.status !== "starting" || r.payload.transportAdmissionFingerprint !== i.transportAdmission.fingerprint)
      return H(
        e,
        "conflict",
        b({
          code: "session-transport-unsupported",
          stage: "transport-admission",
          path: "$.payload.transportAdmissionFingerprint"
        })
      );
    o = { ...o, status: "streaming" };
  } else if (r.payload.kind === "checkpoint")
    o = {
      ...o,
      checkpointFingerprint: r.payload.checkpointDigest,
      status: o.status === "streaming" ? "streaming" : o.status
    };
  else if (r.payload.kind === "abort-acknowledged") {
    if (!i.abortIntent || i.abortIntent.intentId !== r.payload.abortIntentId || i.abortIntent.effectId !== r.payload.effectId || i.transportAdmission.fingerprint !== r.payload.transportAdmissionFingerprint)
      return H(
        e,
        "conflict",
        b({
          code: "session-abort-race",
          stage: "event",
          path: "$.payload.abortIntentId",
          attemptRef: i.attemptId
        })
      );
    r.payload.receiptKind === "acknowledged" ? (o = {
      ...o,
      status: "aborted",
      terminal: {
        reason: "aborted",
        fingerprint: Rt({
          attemptId: i.attemptId,
          terminal: { reason: "aborted" }
        })
      }
    }, a = {
      ...n,
      status: "aborted",
      activeAttemptId: void 0
    }) : r.payload.receiptKind === "unsupported" ? (o = {
      ...o,
      status: "failed",
      terminal: {
        reason: "abort-unsupported",
        fingerprint: Rt({
          attemptId: i.attemptId,
          terminal: { reason: "abort-unsupported" }
        })
      }
    }, a = { ...n, status: "failed", activeAttemptId: void 0 }, l = b({
      code: "session-transport-unsupported",
      stage: "event",
      path: "$.payload.receiptKind",
      attemptRef: i.attemptId,
      terminalReason: "abort-unsupported"
    })) : (o = {
      ...o,
      status: "failed",
      terminal: {
        reason: "transport-failed",
        diagnosticCode: "session-transport-failure",
        fingerprint: Rt({
          attemptId: i.attemptId,
          terminal: {
            reason: "transport-failed",
            diagnosticCode: "session-transport-failure"
          }
        })
      }
    }, a = { ...n, status: "failed", activeAttemptId: void 0 }, l = b({
      code: "session-transport-failure",
      stage: "event",
      path: "$.payload.receiptKind",
      attemptRef: i.attemptId,
      terminalReason: "transport-failed"
    }));
  } else if (r.payload.kind === "attempt-failed")
    o = {
      ...o,
      status: "failed",
      terminal: {
        reason: r.payload.reason,
        diagnosticCode: r.payload.diagnosticCode,
        failureClass: r.payload.failureClass,
        fingerprint: Rt({
          attemptId: i.attemptId,
          terminal: {
            reason: r.payload.reason,
            diagnosticCode: r.payload.diagnosticCode,
            failureClass: r.payload.failureClass
          }
        })
      }
    }, a = { ...n, status: "failed", activeAttemptId: void 0 }, l = b({
      code: r.payload.diagnosticCode,
      stage: "event",
      path: "$.payload",
      attemptRef: i.attemptId,
      terminalReason: r.payload.reason
    });
  else if (r.payload.kind === "transport-disconnected") {
    if (r.payload.reason === "timeout" && (r.payload.logicalTime < n.logicalCreatedAt || r.payload.logicalTime - n.logicalCreatedAt < N.maxLogicalDuration))
      return H(
        e,
        "conflict",
        b({
          code: "session-revision-conflict",
          stage: "event",
          path: "$.payload.logicalTime",
          count: r.payload.logicalTime
        })
      );
    if (r.payload.reason === "disconnected" && i.transportAdmission.capabilities.resume === "resume:same-attempt-checkpoint-v1" && (o.checkpointFingerprint || r.payload.checkpointDigest))
      o = {
        ...o,
        status: "suspended",
        checkpointFingerprint: r.payload.checkpointDigest ?? o.checkpointFingerprint
      };
    else {
      const h = r.payload.reason === "timeout" ? "timeout" : "transport-disconnected";
      o = {
        ...o,
        status: "failed",
        terminal: {
          reason: h,
          fingerprint: Rt({
            attemptId: i.attemptId,
            terminal: { reason: h }
          })
        }
      }, a = { ...n, status: "failed", activeAttemptId: void 0 }, l = b({
        code: "session-transport-failure",
        stage: "event",
        path: "$.payload.reason",
        attemptRef: i.attemptId,
        terminalReason: h
      });
    }
  } else if (r.payload.kind === "attempt-succeeded") {
    const h = Es(r.payload);
    if (!h.ok) return H(e, "failure", h.diagnostic);
    if (h.value.resourceTotals.eventCount !== r.sequence + 1 || h.value.resourceTotals.textBytes !== o.acceptedTextBytes || h.value.resourceTotals.toolSummaryCount !== o.acceptedToolSummaryCount)
      return H(
        e,
        "failure",
        b({
          code: "session-malformed",
          stage: "event",
          path: "$.payload.result.resourceTotals"
        })
      );
    if (o = {
      ...o,
      status: "succeeded",
      terminal: {
        reason: "succeeded",
        resultKind: h.value.kind,
        sealedResultFingerprint: h.value.fingerprint,
        fingerprint: Rt({
          attemptId: i.attemptId,
          terminal: {
            reason: "succeeded",
            resultKind: h.value.kind,
            sealedResultFingerprint: h.value.fingerprint
          }
        })
      }
    }, g = h.value, h.value.kind === "operation-envelope") {
      const v = Ht(
        "proposal-handoff",
        e.identity.sessionId,
        n.requestId,
        i.attemptId,
        e.revision + 1
      );
      u = [
        c({
          effectId: v,
          kind: "proposal-handoff",
          sessionId: e.identity.sessionId,
          requestId: n.requestId,
          attemptId: i.attemptId,
          sourceRevision: e.revision + 1,
          sourceFingerprint: e.fingerprint,
          idempotencyKey: v,
          sealedResultFingerprint: h.value.fingerprint,
          resultKind: h.value.kind
        })
      ], a = { ...n, status: "active", activeAttemptId: void 0 };
    } else
      a = {
        ...n,
        status: (h.value.kind === "no-change", "succeeded"),
        activeAttemptId: void 0
      };
  } else {
    const h = gc(d, r);
    if (!h.ok) return H(e, "failure", h.diagnostic);
    d = h.projection;
  }
  l && (d = lc(d, l));
  const f = c(o), m = c(a);
  d = Or(
    d,
    m,
    f,
    qt(e, m, f),
    d.lastDiagnostic
  );
  const y = Vs(e, r);
  return dt(
    e,
    {
      ...be(e),
      status: e.status === "closing" && nn(f.status) ? "closed" : e.status,
      activeRequestId: m.status === "active" || m.status === "prepared" ? m.requestId : e.activeRequestId === m.requestId ? void 0 : e.activeRequestId,
      requests: Nr(e, m),
      attempts: Vt(e, f),
      projection: d,
      sealedResult: g,
      handoffs: p,
      recentEventProofs: y
    },
    t,
    u,
    u.length > 0 ? "effect-published" : "event-accepted",
    {
      requestId: m.requestId,
      attemptId: f.attemptId,
      eventKind: r.kind,
      effectId: (I = u[0]) == null ? void 0 : I.effectId
    }
  );
}, Wc = (e, t) => {
  const r = lt(e, t.attemptId), i = ut(e, t.requestId);
  if (!r || !i || r.requestId !== i.requestId)
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "command",
        path: "$.attemptId",
        attemptRef: t.attemptId
      })
    );
  if (nn(r.status))
    return c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        requestId: i.requestId,
        attemptId: r.attemptId,
        effectIds: []
      })
    });
  if (r.status === "abort-requested" && r.abortIntent)
    return c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        requestId: i.requestId,
        attemptId: r.attemptId,
        effectIds: [r.abortIntent.effectId]
      })
    });
  const n = Ht(
    "transport-abort",
    e.identity.sessionId,
    i.requestId,
    r.attemptId,
    e.revision + 1
  ), s = c({
    intentId: t.intentId,
    revision: e.revision + 1,
    logicalRequestedAt: t.logicalRequestedAt,
    effectId: n,
    fingerprint: fe("zx-ai-session/v1/abort-intent", {
      intentId: t.intentId,
      attemptId: r.attemptId,
      revision: e.revision + 1,
      transportAdmissionFingerprint: r.transportAdmission.fingerprint
    })
  }), o = c({
    ...r,
    status: "abort-requested",
    abortIntent: s
  }), a = c({
    effectId: n,
    kind: "transport-abort",
    sessionId: e.identity.sessionId,
    requestId: i.requestId,
    attemptId: r.attemptId,
    sourceRevision: e.revision + 1,
    sourceFingerprint: e.fingerprint,
    idempotencyKey: n,
    abortIntentId: s.intentId,
    transportAdmission: r.transportAdmission
  }), d = Or(
    e.projection,
    i,
    o,
    qt(e, i, o)
  );
  return dt(
    e,
    {
      ...be(e),
      attempts: Vt(e, o),
      projection: d
    },
    t,
    [a],
    "effect-published",
    {
      requestId: i.requestId,
      attemptId: r.attemptId,
      effectId: n
    }
  );
}, Yc = (e, t) => {
  const r = ut(e, t.requestId), i = lt(e, t.predecessorAttemptId);
  return !r || !i || i.requestId !== r.requestId ? H(
    e,
    "conflict",
    b({
      code: "session-identity-invalid",
      stage: "command",
      path: "$.predecessorAttemptId"
    })
  ) : r.publishedHandoffFingerprint ? H(
    e,
    "conflict",
    b({
      code: "session-retry-ineligible",
      stage: "command",
      path: "$.publishedHandoffFingerprint",
      requestRef: r.requestId
    })
  ) : i.terminal ? e.attempts.some(
    (n) => n.requestId === r.requestId && n.predecessorAttemptId === i.attemptId
  ) ? H(
    e,
    "conflict",
    b({
      code: "session-retry-ineligible",
      stage: "command",
      path: "$.predecessorAttemptId",
      attemptRef: i.attemptId
    })
  ) : qr.retryableTerminalReasons.includes(
    i.terminal.reason
  ) ? i.retryCount >= N.maxRetries ? H(
    e,
    "failure",
    b({
      code: "session-resource-exceeded",
      stage: "command",
      path: "$.retryCount",
      count: i.retryCount + 1
    })
  ) : lt(e, t.attemptId) ? H(
    e,
    "conflict",
    b({
      code: "session-identity-invalid",
      stage: "identity",
      path: "$.attemptId",
      attemptRef: t.attemptId
    })
  ) : Hs(e, t) : H(
    e,
    "unsupported",
    b({
      code: "session-retry-ineligible",
      stage: "command",
      path: "$.terminal.reason",
      terminalReason: i.terminal.reason
    })
  ) : H(
    e,
    "conflict",
    b({
      code: "session-retry-ineligible",
      stage: "command",
      path: "$.terminal",
      attemptRef: i.attemptId
    })
  );
}, Xc = (e, t) => {
  const r = lt(e, t.attemptId), i = ut(e, t.requestId);
  if (!r || !i || r.requestId !== i.requestId)
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "command",
        path: "$.attemptId"
      })
    );
  if (r.transportAdmission.capabilities.resume !== "resume:same-attempt-checkpoint-v1")
    return H(
      e,
      "unsupported",
      b({
        code: "session-transport-unsupported",
        stage: "transport-admission",
        path: "$.transportAdmission.capabilities.resume",
        capability: "resume:same-attempt-checkpoint-v1"
      })
    );
  if (r.status !== "suspended")
    return H(
      e,
      "conflict",
      b({
        code: "session-resume-conflict",
        stage: "command",
        path: "$.attempt.status",
        attemptRef: r.attemptId
      })
    );
  if (r.checkpointFingerprint !== t.checkpointFingerprint || r.expectedSequence !== t.expectedSequence || (r.lastEventFingerprint ?? null) !== t.expectedEventFingerprint || e.auditHead.fingerprint !== t.expectedAuditHead)
    return H(
      e,
      "conflict",
      b({
        code: "session-resume-conflict",
        stage: "checkpoint",
        path: "$.checkpoint",
        attemptRef: r.attemptId
      })
    );
  const n = Ht(
    "transport-resume",
    e.identity.sessionId,
    i.requestId,
    r.attemptId,
    e.revision + 1
  ), s = c({
    ...r,
    status: "streaming"
  }), o = c({
    effectId: n,
    kind: "transport-resume",
    sessionId: e.identity.sessionId,
    requestId: i.requestId,
    attemptId: r.attemptId,
    sourceRevision: e.revision + 1,
    sourceFingerprint: e.fingerprint,
    idempotencyKey: n,
    checkpointFingerprint: t.checkpointFingerprint,
    expectedSequence: t.expectedSequence,
    transportAdmission: r.transportAdmission
  });
  return dt(
    e,
    {
      ...be(e),
      attempts: Vt(e, s),
      projection: Or(
        e.projection,
        i,
        s,
        qt(e, i, s)
      )
    },
    t,
    [o],
    "effect-published",
    {
      requestId: i.requestId,
      attemptId: r.attemptId,
      effectId: n
    }
  );
}, Zc = (e, t) => {
  var d, l;
  const r = ut(e, t.requestId), i = lt(e, t.attemptId);
  if (!r || !i)
    return H(
      e,
      "conflict",
      b({
        code: "session-identity-invalid",
        stage: "handoff",
        path: "$.requestId"
      })
    );
  const n = t.receipt;
  if (r.publishedHandoffFingerprint)
    return r.publishedHandoffFingerprint !== n.fingerprint ? H(
      e,
      "conflict",
      b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.receipt.fingerprint"
      })
    ) : c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        requestId: r.requestId,
        attemptId: i.attemptId,
        effectIds: []
      })
    });
  const s = Ht(
    "proposal-handoff",
    e.identity.sessionId,
    r.requestId,
    i.attemptId,
    e.revision
  );
  if (i.requestId !== r.requestId || i.status !== "succeeded" || ((d = i.terminal) == null ? void 0 : d.reason) !== "succeeded" || i.terminal.resultKind !== "operation-envelope" || !i.terminal.sealedResultFingerprint || ((l = e.sealedResult) == null ? void 0 : l.kind) !== "operation-envelope" || e.sealedResult.fingerprint !== i.terminal.sealedResultFingerprint || n.kind !== "zx-ai-session-handoff-receipt-v1" || n.sessionId !== e.identity.sessionId || n.requestId !== r.requestId || n.attemptId !== i.attemptId || n.effectId !== s || n.sourceRevision !== e.revision || n.sourceSessionFingerprint !== e.fingerprint || n.resultKind !== "operation-envelope" || n.sealedResultFingerprint !== e.sealedResult.fingerprint || n.outcome !== "awaiting-review")
    return H(
      e,
      "conflict",
      b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.receipt"
      })
    );
  if (e.handoffs.length >= N.maxHandoffs)
    return H(
      e,
      "failure",
      b({
        code: "session-resource-exceeded",
        stage: "handoff",
        path: "$.handoffs",
        count: e.handoffs.length + 1
      })
    );
  const o = c({
    ...r,
    status: "awaiting-review",
    publishedHandoffFingerprint: n.fingerprint,
    activeAttemptId: void 0
  }), a = Tt({
    ...be(e.projection),
    requestStatus: o.status,
    proposalRef: n.proposalId ?? null,
    reviewRef: n.reviewId ?? null,
    capabilities: qt(e, o, i)
  });
  return dt(
    e,
    {
      ...be(e),
      activeRequestId: void 0,
      requests: Nr(e, o),
      handoffs: [...e.handoffs, n],
      projection: a
    },
    t,
    [],
    "handoff-published",
    { requestId: r.requestId, attemptId: i.attemptId }
  );
}, Jc = (e, t) => {
  if (e.status === "closed")
    return c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        effectIds: []
      })
    });
  if (e.status === "closing")
    return c({
      status: "idempotent",
      session: e,
      receipt: yt({
        commandKind: t.kind,
        status: "idempotent",
        sessionId: e.identity.sessionId,
        revision: e.revision,
        sessionFingerprint: e.fingerprint,
        effectIds: []
      })
    });
  const r = e.activeRequestId ? ut(e, e.activeRequestId) : void 0, i = r ? qs(e, r.requestId) : void 0;
  if (r && !i && !t.force)
    return H(
      e,
      "conflict",
      b({
        code: "session-busy",
        stage: "command",
        path: "$.activeRequestId",
        requestRef: r.requestId
      })
    );
  if (i && Qr(i.status) && !t.force)
    return H(
      e,
      "conflict",
      b({
        code: "session-busy",
        stage: "command",
        path: "$.activeRequestId",
        requestRef: r == null ? void 0 : r.requestId
      })
    );
  if (r && i && Qr(i.status)) {
    const n = Ht(
      "transport-abort",
      e.identity.sessionId,
      r.requestId,
      i.attemptId,
      e.revision + 1
    ), s = c({
      intentId: `close:${i.attemptId}`,
      revision: e.revision + 1,
      logicalRequestedAt: t.logicalTime ?? e.revision + 1,
      effectId: n,
      fingerprint: fe("zx-ai-session/v1/abort-intent", {
        intentId: `close:${i.attemptId}`,
        attemptId: i.attemptId,
        revision: e.revision + 1,
        transportAdmissionFingerprint: i.transportAdmission.fingerprint
      })
    }), o = c({
      ...i,
      status: "abort-requested",
      abortIntent: s
    }), a = c({
      effectId: n,
      kind: "transport-abort",
      sessionId: e.identity.sessionId,
      requestId: r.requestId,
      attemptId: i.attemptId,
      sourceRevision: e.revision + 1,
      sourceFingerprint: e.fingerprint,
      idempotencyKey: n,
      abortIntentId: s.intentId,
      transportAdmission: i.transportAdmission
    });
    return dt(
      e,
      {
        ...be(e),
        status: "closing",
        attempts: Vt(e, o),
        projection: Or(
          e.projection,
          r,
          o,
          qt(e, r, o)
        )
      },
      t,
      [a],
      "effect-published",
      {
        requestId: r.requestId,
        attemptId: i.attemptId,
        effectId: n
      }
    );
  }
  if (r && !i) {
    const n = c({
      ...r,
      status: "aborted",
      activeAttemptId: void 0
    });
    return dt(
      e,
      {
        ...be(e),
        status: "closed",
        activeRequestId: void 0,
        requests: Nr(e, n),
        projection: Tt({
          ...be(e.projection),
          requestStatus: "aborted",
          capabilities: {
            canAbort: !1,
            canRetry: !1,
            canResume: !1,
            canSupersede: !1
          }
        })
      },
      t,
      [],
      "session-closed",
      { requestId: r.requestId }
    );
  }
  return dt(
    e,
    {
      ...be(e),
      status: "closed",
      activeRequestId: void 0
    },
    t,
    [],
    "session-closed"
  );
}, Qc = (e, t) => {
  const r = Kc(e, t);
  if (r) return H(e, "conflict", r);
  const i = Mc(e, t);
  if (i)
    return H(e, i.status, i.diagnostic);
  const n = Vc(e, t);
  if (n.outcome === "reject")
    return H(e, n.status, n.diagnostic);
  switch (t.kind) {
    case "create-request":
    case "restart":
    case "supersede":
      return Uc(e, t);
    case "start-attempt":
      return Hs(e, t);
    case "accept-event":
    case "acknowledge-abort":
      return Gc(e, t);
    case "request-abort":
      return Wc(e, t);
    case "retry":
      return Yc(e, t);
    case "resume":
      return Xc(e, t);
    case "publish-handoff":
      return Zc(e, t);
    case "close-session":
      return Jc(e, t);
    default:
      return H(
        e,
        "unsupported",
        b({
          code: "session-unsupported",
          stage: "command",
          path: "$.kind"
        })
      );
  }
};
function Ni(e, t) {
  const r = Bt(e);
  if (!r.ok)
    return c({
      status: "failure",
      session: null,
      diagnostic: r.diagnostic
    });
  const i = Dc(t);
  return i.ok ? Qc(r.value, i.value) : H(r.value, "failure", i.diagnostic);
}
const qu = (e) => {
  if (ze(e, "$") || !T(e, ["session", "requestId", "attemptId"]) || !q(e.requestId) || !q(e.attemptId))
    return null;
  const r = Bt(e.session);
  if (!r.ok) return null;
  const i = r.value, n = i.attempts.find(
    (a) => a.attemptId === e.attemptId
  ), s = i.requests.find(
    (a) => a.requestId === e.requestId
  );
  if (!n || !s || n.requestId !== s.requestId)
    return null;
  const o = {
    kind: "zx-ai-session-checkpoint-v1",
    version: nt,
    sessionId: i.identity.sessionId,
    requestId: e.requestId,
    attemptId: e.attemptId,
    revision: i.revision,
    sessionFingerprint: i.fingerprint,
    lastSequence: Math.max(0, n.expectedSequence - 1),
    lastEventFingerprint: n.lastEventFingerprint ?? null,
    projectionFingerprint: i.projection.fingerprint,
    policyFingerprint: i.policyRef.fingerprint,
    capabilityFingerprint: n.transportAdmission.fingerprint,
    auditHead: i.auditHead
  };
  return Ae({
    ...o,
    fingerprint: zs(o)
  });
}, ed = (e) => {
  if (e && typeof e == "object" && !Array.isArray(e) && "version" in e && e.version !== nt)
    return c({
      status: "unsupported",
      checkpoint: null,
      diagnostic: b({
        code: "session-unsupported",
        stage: "checkpoint",
        path: "$.version"
      })
    });
  const t = Ac(e);
  return t.ok ? c({
    status: "success",
    checkpoint: t.value,
    diagnostic: null
  }) : c({
    status: "failure",
    checkpoint: null,
    diagnostic: t.diagnostic
  });
}, Tu = (e) => {
  const t = ze(e, "$");
  if (t || !T(e, ["checkpoint", "session", "events"]) || !Array.isArray(e.events))
    return c({
      status: "failure",
      session: null,
      diagnostic: t ?? b({
        code: "session-replay-invalid",
        stage: "replay",
        path: "$"
      })
    });
  const r = Bt(e.session);
  if (!r.ok)
    return c({
      status: "failure",
      session: null,
      diagnostic: r.diagnostic
    });
  const i = ed(e.checkpoint);
  if (i.status !== "success" || !i.checkpoint)
    return c({
      status: "failure",
      session: null,
      diagnostic: i.diagnostic ?? b({
        code: "session-replay-invalid",
        stage: "replay",
        path: "$.checkpoint"
      })
    });
  const n = i.checkpoint, s = r.value, o = s.requests.find(
    (l) => l.requestId === n.requestId
  ), a = s.attempts.find(
    (l) => l.attemptId === n.attemptId
  );
  if (s.identity.sessionId !== n.sessionId || s.fingerprint !== n.sessionFingerprint || s.revision !== n.revision || !o || !a || a.requestId !== o.requestId || n.lastSequence !== Math.max(0, a.expectedSequence - 1) || n.lastEventFingerprint !== (a.lastEventFingerprint ?? null) || n.projectionFingerprint !== s.projection.fingerprint || n.policyFingerprint !== s.policyRef.fingerprint || n.capabilityFingerprint !== a.transportAdmission.fingerprint || !Rs(n.auditHead, s.auditHead))
    return c({
      status: "failure",
      session: null,
      diagnostic: b({
        code: "session-replay-invalid",
        stage: "replay",
        path: "$.session"
      })
    });
  let d = s;
  for (const l of e.events) {
    if (!l || typeof l != "object" || Array.isArray(l) || l.sessionId !== n.sessionId || l.requestId !== n.requestId || l.attemptId !== n.attemptId)
      return c({
        status: "failure",
        session: null,
        diagnostic: b({
          code: "session-replay-invalid",
          stage: "replay",
          path: "$.events"
        })
      });
    const g = Ni(d, {
      kind: "accept-event",
      sessionId: d.identity.sessionId,
      expectedRevision: d.revision,
      expectedSessionFingerprint: d.fingerprint,
      event: l
    });
    if (g.status !== "accepted" && g.status !== "idempotent")
      return c({
        status: "failure",
        session: null,
        diagnostic: g.diagnostic
      });
    d = g.session;
  }
  return c({
    status: "success",
    session: d,
    diagnostic: null
  });
}, Ks = (e) => fe("zx-ai-session/v1/transport-capability", e), Ms = (e) => {
  const t = {
    transportId: e.transportId,
    version: e.version,
    capabilities: {
      start: e.capabilities.start,
      abort: e.capabilities.abort,
      resume: e.capabilities.resume,
      requestKinds: [...e.capabilities.requestKinds]
    },
    policyFingerprint: e.policyFingerprint
  };
  return c({
    ...t,
    fingerprint: Ks(t)
  });
}, Us = (e, t = "$.descriptor") => {
  if (!T(e, [
    "transportId",
    "version",
    "capabilities",
    "policyFingerprint",
    "fingerprint"
  ]) || !q(e.transportId) || e.version !== nt || !T(e.capabilities, [
    "start",
    "abort",
    "resume",
    "requestKinds"
  ]) || e.capabilities.start !== !0 || typeof e.capabilities.abort != "boolean" || ![!1, "resume:same-attempt-checkpoint-v1"].includes(
    e.capabilities.resume
  ) || !Array.isArray(e.capabilities.requestKinds) || e.capabilities.requestKinds.length === 0 || new Set(e.capabilities.requestKinds).size !== e.capabilities.requestKinds.length || e.capabilities.requestKinds.some(
    (n) => ![
      "selection",
      "cursor",
      "block",
      "long-running",
      "improve",
      "fix",
      "shorter",
      "longer",
      "continue",
      "follow-up"
    ].includes(String(n))
  ) || !_t(e.policyFingerprint))
    return {
      ok: !1,
      diagnostic: b({
        code: "session-transport-unsupported",
        stage: "transport-admission",
        path: t
      })
    };
  const r = {
    transportId: e.transportId,
    version: e.version,
    capabilities: e.capabilities,
    policyFingerprint: e.policyFingerprint
  }, i = Ks(r);
  return e.fingerprint !== i ? {
    ok: !1,
    diagnostic: b({
      code: "session-transport-unsupported",
      stage: "transport-admission",
      path: `${t}.fingerprint`,
      fingerprint: i
    })
  } : {
    ok: !0,
    value: Ms(r)
  };
}, Bu = (e) => {
  const t = ze(e, "$");
  if (t || !T(e, ["descriptor", "session", "requestId"]) || !q(e.requestId))
    return {
      status: "failure",
      diagnostic: t ?? b({
        code: "session-input-invalid",
        stage: "transport-admission",
        path: "$"
      })
    };
  const r = Bt(e.session);
  if (!r.ok)
    return {
      status: "failure",
      diagnostic: r.diagnostic
    };
  const i = r.value, n = i.requests.find(
    (l) => l.requestId === e.requestId
  );
  if (!n || n.sessionId !== i.identity.sessionId || !["prepared", "failed"].includes(n.status))
    return {
      status: "failure",
      diagnostic: b({
        code: "session-identity-invalid",
        stage: "transport-admission",
        path: "$.requestId",
        requestRef: e.requestId
      })
    };
  const s = Us(e.descriptor);
  if (!s.ok)
    return {
      status: "unsupported",
      diagnostic: s.diagnostic
    };
  const o = s.value, a = i.policyRef.fingerprint;
  if (o.policyFingerprint !== a)
    return {
      status: "unsupported",
      diagnostic: b({
        code: "session-transport-unsupported",
        stage: "transport-admission",
        path: "$.policyFingerprint"
      })
    };
  if (!o.capabilities.requestKinds.includes(n.input.kind))
    return {
      status: "unsupported",
      diagnostic: b({
        code: "session-transport-unsupported",
        stage: "transport-admission",
        path: "$.requestKind",
        capability: n.input.kind
      })
    };
  const d = {
    kind: "zx-ai-transport-admission-receipt-v1",
    sessionId: i.identity.sessionId,
    sourceRevision: i.revision,
    sourceSessionFingerprint: i.fingerprint,
    requestId: n.requestId,
    requestKind: n.input.kind,
    requestInputFingerprint: n.inputFingerprint,
    policyFingerprint: n.policyFingerprint,
    transportId: o.transportId,
    version: o.version,
    descriptorFingerprint: o.fingerprint,
    capabilities: o.capabilities
  };
  return {
    status: "accepted",
    receipt: c({
      ...d,
      fingerprint: Os(d)
    })
  };
}, td = (e) => {
  const t = ze(e, "$");
  if (t) return t;
  if (!T(e, [], []) && e && typeof e == "object") {
    const r = e;
    for (const i of Object.keys(r))
      if (/secret|apiKey|token|password|authorization|header/i.test(i) || typeof r[i] == "function")
        return b({
          code: "session-input-invalid",
          stage: "transport-admission",
          path: `$.${i}`
        });
  }
  return e && typeof e == "object" && "providerOptions" in e ? b({
    code: "session-input-invalid",
    stage: "transport-admission",
    path: "$.providerOptions"
  }) : null;
}, rd = (e, t) => {
  if (typeof e == "boolean")
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "transport-admission",
        path: "$.abort.boolean"
      })
    };
  if (e instanceof Error || e && typeof e == "object" && "name" in e && e.name === "AbortError")
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "transport-admission",
        path: "$.abort.AbortError"
      })
    };
  if (!e || typeof e != "object")
    return {
      ok: !1,
      diagnostic: b({
        code: "session-malformed",
        stage: "transport-admission",
        path: "$.abort"
      })
    };
  const r = e;
  return !T(
    r,
    ["status", "abortIntentId", "effectId", "transportAdmissionFingerprint"],
    ["receiptKind", "code"]
  ) || r.abortIntentId !== t.abortIntentId || r.effectId !== t.effectId || r.transportAdmissionFingerprint !== t.transportAdmissionFingerprint ? {
    ok: !1,
    diagnostic: b({
      code: "session-abort-race",
      stage: "transport-admission",
      path: "$.abort.binding"
    })
  } : r.status === "accepted" && r.receiptKind === "acknowledged" ? {
    ok: !0,
    abort: c({
      status: "accepted",
      receiptKind: "acknowledged",
      abortIntentId: t.abortIntentId,
      effectId: t.effectId,
      transportAdmissionFingerprint: t.transportAdmissionFingerprint
    })
  } : r.status === "unsupported" ? {
    ok: !0,
    abort: c({
      status: "unsupported",
      abortIntentId: t.abortIntentId,
      effectId: t.effectId,
      transportAdmissionFingerprint: t.transportAdmissionFingerprint
    })
  } : r.status === "failed" && typeof r.code == "string" ? {
    ok: !0,
    abort: c({
      status: "failed",
      abortIntentId: t.abortIntentId,
      effectId: t.effectId,
      transportAdmissionFingerprint: t.transportAdmissionFingerprint,
      code: r.code
    })
  } : {
    ok: !1,
    diagnostic: b({
      code: "session-malformed",
      stage: "transport-admission",
      path: "$.abort.status"
    })
  };
}, id = (e) => {
  if (!e || typeof e != "object") return null;
  const t = e;
  for (const r of Object.keys(t))
    if (/^(?:providerMeta|providerOptions|usage|rawToolCall|tool_calls|openai|anthropic)$/i.test(
      r
    ))
      return b({
        code: "session-input-invalid",
        stage: "transport-admission",
        path: `$.${r}`
      });
  return null;
}, Pu = (e = {}) => {
  let t = 0, r = null;
  const i = [];
  let n = null;
  const s = [...e.steps ?? []], o = Ms({
    transportId: e.transportId ?? "deterministic-fake-v1",
    version: "1.0.0",
    capabilities: {
      start: !0,
      abort: e.abort ?? !0,
      resume: e.resume ?? "resume:same-attempt-checkpoint-v1",
      requestKinds: e.requestKinds ?? [
        "selection",
        "cursor",
        "block",
        "long-running",
        "improve",
        "fix",
        "shorter",
        "longer",
        "continue",
        "follow-up"
      ]
    },
    policyFingerprint: qe.fingerprint
  }), a = () => {
    for (; t < s.length; ) {
      const l = s[t];
      if (l.kind === "wait-for-effect") {
        r = l.effectKind;
        return;
      }
      if (l.kind === "reject-port-call") {
        n = l.code, t += 1;
        return;
      }
      if (l.kind === "complete") {
        t += 1;
        return;
      }
      l.kind === "emit" && (i.push(l.event), t += 1);
    }
  }, d = (l) => {
    r === l && (r = null, t += 1, a());
  };
  return a(), {
    descriptor: o,
    steps: c(s),
    advance() {
      a();
    },
    pendingEffectKind() {
      return r;
    },
    async *start(l) {
      if (n) {
        const g = n;
        throw n = null, new Error(g);
      }
      for (d("transport-start"); ; ) {
        for (; i.length > 0; )
          yield i.shift();
        if (r !== null || t >= s.length) return;
        const g = t;
        if (a(), i.length === 0 && t === g) return;
      }
    },
    async abort(l) {
      if (n) {
        const g = n;
        return n = null, c({
          status: "failed",
          abortIntentId: l.abortIntentId,
          effectId: l.effectId,
          transportAdmissionFingerprint: l.transportAdmission.fingerprint,
          code: g
        });
      }
      return d("transport-abort"), o.capabilities.abort ? c({
        status: "accepted",
        receiptKind: "acknowledged",
        abortIntentId: l.abortIntentId,
        effectId: l.effectId,
        transportAdmissionFingerprint: l.transportAdmission.fingerprint
      }) : c({
        status: "unsupported",
        abortIntentId: l.abortIntentId,
        effectId: l.effectId,
        transportAdmissionFingerprint: l.transportAdmission.fingerprint
      });
    },
    async *resume(l) {
      if (o.capabilities.resume !== "resume:same-attempt-checkpoint-v1")
        throw new Error("resume-unsupported");
      if (n) {
        const g = n;
        throw n = null, new Error(g);
      }
      for (d("transport-resume"); i.length > 0; )
        yield i.shift();
    }
  };
}, nd = (e) => !rt(
  e,
  [
    "kind",
    "commandId",
    "expectedRevision",
    "expectedSidecarFingerprint",
    "expectedProposalFingerprint",
    "expectedLifecycleFingerprint",
    "expectedPolicyFingerprint"
  ],
  ["operationIndex"]
) || ![
  "accept-operation",
  "reject-operation",
  "accept-all",
  "reject-all",
  "regenerate"
].includes(e.kind) || !fr(e.commandId) || !Zr(e.expectedRevision) || !fr(e.expectedSidecarFingerprint) || !fr(e.expectedProposalFingerprint) || !fr(e.expectedLifecycleFingerprint) || !fr(e.expectedPolicyFingerprint) ? !1 : e.kind === "accept-operation" || e.kind === "reject-operation" ? Object.hasOwn(e, "operationIndex") && Zr(e.operationIndex) : !Object.hasOwn(e, "operationIndex"), hr = (e, t, r) => {
  const i = {
    operationIndex: e.operationIndex,
    operationIntentDigest: e.operationIntentDigest,
    dependencyOperationIndexes: [...e.dependencyOperationIndexes],
    state: t,
    decidedAtRevision: r
  };
  return c({
    ...i,
    fingerprint: Lt(
      "zx-ai-review-operation-decision:v1",
      i
    )
  });
}, Ke = (e, t, r, i) => c({
  status: e,
  sidecar: t,
  ...i ? { requiredOperationIndexes: i } : {},
  diagnostic: it({
    code: e === "dependency-conflict" ? "review-dependency-conflict" : e === "terminal" ? "review-terminal" : e === "conflict" ? "review-conflict" : "review-input-invalid",
    stage: "decision",
    path: r,
    reviewRef: t.identity.reviewId
  })
}), sd = (e, t) => {
  const r = /* @__PURE__ */ new Set([t]), i = [t];
  for (; i.length; ) {
    const n = i.shift();
    for (const s of e)
      !r.has(s.operationIndex) && s.dependencyOperationIndexes.includes(n) && (r.add(s.operationIndex), i.push(s.operationIndex));
  }
  return c([...r].sort((n, s) => n - s));
}, cn = (e, t) => {
  if (!rt(e, ["sidecar", "command"])) {
    const l = e.sidecar;
    if (l && typeof l == "object")
      return Ke("failure", l, "$");
    throw new TypeError("review-input-invalid");
  }
  const r = Te(e.sidecar);
  if (r.status !== "success")
    return Ke("failure", e.sidecar, "$.sidecar");
  const i = r.sidecar, n = e.command;
  if (!nd(n)) return Ke("failure", i, "$.command");
  if (i.status !== "active")
    return Ke("terminal", i, "$.sidecar.status");
  if (i.auditEntries.length >= Wi.maxAuditEntries)
    return c({
      status: "failure",
      sidecar: i,
      diagnostic: it({
        code: "review-budget-exceeded",
        stage: "decision",
        path: "$.sidecar.auditEntries",
        count: i.auditEntries.length
      })
    });
  if (n.expectedRevision !== i.revision || n.expectedSidecarFingerprint !== i.fingerprint || n.expectedProposalFingerprint !== i.proposalBinding.proposalFingerprint || n.expectedLifecycleFingerprint !== i.proposalBinding.lifecycleFingerprint || n.expectedPolicyFingerprint !== i.policyRef.fingerprint || i.auditEntries.some(
    (l) => l.commandId === n.commandId
  ) || t && !Yi(i))
    return Ke("conflict", i, "$.command.expectedRevision");
  if (i.capability === "coarse-review-unavailable" && n.kind !== "reject-all" && n.kind !== "regenerate")
    return Ke("failure", i, "$.command.kind");
  const s = i.revision + 1;
  let o = [], a = i.decisions;
  if (n.kind === "accept-operation") {
    const l = a[n.operationIndex];
    if (!l || l.state !== "undecided")
      return Ke("conflict", i, "$.command.operationIndex");
    const g = l.dependencyOperationIndexes.filter(
      (u) => {
        var p;
        return ((p = a[u]) == null ? void 0 : p.state) !== "accepted";
      }
    );
    if (g.length)
      return Ke(
        "dependency-conflict",
        i,
        "$.command.operationIndex",
        g
      );
    o = [n.operationIndex], a = a.map(
      (u) => u.operationIndex === n.operationIndex ? hr(u, "accepted", s) : u
    );
  } else if (n.kind === "reject-operation") {
    const l = a[n.operationIndex];
    if (!l || l.state === "rejected")
      return Ke("conflict", i, "$.command.operationIndex");
    o = sd(a, n.operationIndex), a = a.map(
      (g) => o.includes(g.operationIndex) ? hr(
        g,
        g.operationIndex === n.operationIndex ? "rejected" : "regeneration-required",
        s
      ) : g
    );
  } else if (n.kind === "accept-all") {
    if (a.some(
      (l) => l.state === "rejected" || l.state === "regeneration-required"
    ))
      return Ke("conflict", i, "$.command.kind");
    o = a.map((l) => l.operationIndex), a = a.map(
      (l) => hr(l, "accepted", s)
    );
  } else if (n.kind === "reject-all") {
    if (a.some(
      (l) => l.state === "accepted" || l.state === "regeneration-required"
    ))
      return Ke("conflict", i, "$.command.kind");
    o = a.map((l) => l.operationIndex), a = a.map(
      (l) => hr(l, "rejected", s)
    );
  } else
    o = a.filter((l) => l.state === "undecided").map((l) => l.operationIndex), a = a.map(
      (l) => l.state === "undecided" ? hr(l, "regeneration-required", s) : l
    );
  const d = si(i, {
    decisions: a,
    auditKind: n.kind,
    commandId: n.commandId,
    operationIndexes: o
  });
  return c({
    status: "success",
    sidecar: d,
    affectedOperationIndexes: o
  });
}, od = (e) => {
  const t = cn(e, !0);
  return t.status !== "success" || Gi(e.sidecar, t.sidecar) ? t : Ke("conflict", e.sidecar, "$.command.expectedRevision");
}, ad = (e) => {
  const t = cn(e, !0);
  return t.status === "success" ? c({
    status: "candidate",
    sidecar: t.sidecar,
    affectedOperationIndexes: t.affectedOperationIndexes
  }) : t;
}, dn = (e) => {
  if (!rt(e, ["previous", "command", "candidate"]))
    return c({
      status: "failure",
      diagnostic: it({
        code: "review-input-invalid",
        stage: "decision",
        path: "$"
      })
    });
  const t = cn(
    { sidecar: e.previous, command: e.command },
    !1
  );
  return t.status !== "success" ? c({
    status: "failure",
    diagnostic: t.diagnostic
  }) : ns(t.sidecar, e.candidate) ? c({
    status: "verified",
    resultingSidecarFingerprint: t.sidecar.fingerprint
  }) : c({
    status: "mismatch",
    diagnostic: it({
      code: "review-conflict",
      stage: "decision",
      path: "$.candidate",
      reviewRef: e.previous.identity.reviewId
    })
  });
}, kt = (e, t, r) => c({
  status: e,
  sidecar: t,
  diagnostic: it({
    code: e === "conflict" ? "review-conflict" : "review-input-invalid",
    stage: "decision",
    path: r,
    reviewRef: t.identity.reviewId
  })
}), cd = (e) => {
  if (!rt(e, [
    "root",
    "entries",
    "expectedDurableHeadFingerprint"
  ]))
    throw new TypeError("review-input-invalid");
  const t = Te(e.root);
  if (t.status !== "success")
    return kt("failure", e.root, "$.root");
  let r = t.sidecar;
  const i = [];
  for (let s = 0; s < e.entries.length; s += 1) {
    const o = e.entries[s];
    if (!rt(o, [
      "previousSidecarFingerprint",
      "command",
      "resultingSidecar"
    ]) || o.previousSidecarFingerprint !== r.fingerprint)
      return kt("conflict", r, `$.entries[${s}]`);
    const a = dn({
      previous: r,
      command: o.command,
      candidate: o.resultingSidecar
    });
    if (a.status !== "verified")
      return c({
        status: "conflict",
        sidecar: r,
        diagnostic: a.diagnostic
      });
    r = o.resultingSidecar, i.push(r);
  }
  if (r.fingerprint !== e.expectedDurableHeadFingerprint)
    return kt(
      "conflict",
      r,
      "$.expectedDurableHeadFingerprint"
    );
  const n = is(t.sidecar, i);
  return n === "conflict" ? kt("conflict", r, "$.entries") : c({
    status: n,
    sidecar: r,
    installedTransitionCount: i.length
  });
}, dd = (e) => {
  const t = Te(e.root);
  if (t.status !== "success")
    return kt("failure", e.root, "$.root");
  let r = t.sidecar;
  for (let n = 0; n < e.sequence.length; n += 1) {
    const s = Te(e.sequence[n]);
    if (s.status !== "success" || s.sidecar.identity.reviewId !== r.identity.reviewId || s.sidecar.revision !== r.revision + 1 || r.status !== "active" || n < e.sequence.length - 1 && s.sidecar.status !== "active")
      return kt("conflict", r, `$.sequence[${n}]`);
    r = s.sidecar;
  }
  if (r.fingerprint !== e.expectedDurableHeadFingerprint)
    return kt(
      "conflict",
      r,
      "$.expectedDurableHeadFingerprint"
    );
  const i = is(
    t.sidecar,
    e.sequence
  );
  return i === "conflict" ? kt("conflict", r, "$.sequence") : c({
    status: i,
    sidecar: r,
    installedTransitionCount: e.sequence.length
  });
}, ld = (e, t, r) => c({
  itemId: e.itemId,
  operationIndex: e.operationIndex,
  blockRefs: [...e.blockRefs],
  hunkRefs: e.hunkRefs.map((i) => i.hunkId),
  index: t,
  total: r,
  summary: la(e.summary)
}), pd = (e) => {
  if (!rt(
    e,
    ["sidecar", "kind"],
    ["currentItemId", "operationIndex", "blockRef"]
  ) || !["first", "last", "next", "previous", "by-operation", "by-block"].includes(
    e.kind
  ))
    return c({
      status: "failure",
      snapshot: null,
      diagnostic: it({
        code: "review-input-invalid",
        stage: "navigation",
        path: "$"
      })
    });
  const t = Te(e.sidecar);
  if (t.status !== "success")
    return c({
      status: "failure",
      snapshot: null,
      diagnostic: t.diagnostic
    });
  const r = t.sidecar.items;
  if (!r.length) return c({ status: "not-found", snapshot: null });
  let i = -1;
  if (e.kind === "first") i = 0;
  else if (e.kind === "last") i = r.length - 1;
  else if (e.kind === "by-operation") {
    if (!Zr(e.operationIndex))
      return c({ status: "not-found", snapshot: null });
    i = r.findIndex(
      (n) => n.operationIndex === e.operationIndex
    );
  } else if (e.kind === "by-block")
    i = r.findIndex(
      (n) => n.blockRefs.includes(e.blockRef ?? "")
    );
  else {
    const n = r.findIndex(
      (s) => s.itemId === e.currentItemId
    );
    if (n < 0) return c({ status: "not-found", snapshot: null });
    i = e.kind === "next" ? n + 1 : n - 1;
  }
  return i < 0 || i >= r.length ? c({ status: "boundary", snapshot: null }) : c({
    status: "found",
    snapshot: ld(r[i], i, r.length)
  });
}, ud = /^[A-Za-z0-9_.:-]{1,160}$/, fd = /^sha256:[a-f0-9]{64}$/i, $u = (e) => {
  const t = Te(e.sidecar);
  if (t.status !== "success" || t.sidecar.status !== "active" || !Yi(t.sidecar) || !ud.test(e.commandId) || !fd.test(e.regenerationHandoffFingerprint))
    return c({
      status: "conflict",
      sidecar: e.sidecar,
      regenerationHandoffFingerprint: null,
      diagnostic: it({
        code: "review-conflict",
        stage: "regeneration",
        path: "$.sidecar",
        reviewRef: e.sidecar.identity.reviewId,
        proposalRef: e.sidecar.proposalBinding.proposalId
      })
    });
  const r = si(t.sidecar, {
    status: "superseded",
    auditKind: "regeneration-issued",
    commandId: e.commandId,
    operationIndexes: []
  });
  return Gi(t.sidecar, r) ? c({
    status: "superseded",
    sidecar: r,
    regenerationHandoffFingerprint: e.regenerationHandoffFingerprint,
    diagnostic: null
  }) : c({
    status: "conflict",
    sidecar: t.sidecar,
    regenerationHandoffFingerprint: null,
    diagnostic: it({
      code: "review-conflict",
      stage: "regeneration",
      path: "$.sidecar.revision",
      reviewRef: t.sidecar.identity.reviewId,
      proposalRef: t.sidecar.proposalBinding.proposalId
    })
  });
}, rr = (e, t) => it({
  code: "review-conflict",
  stage: "reject",
  path: t,
  reviewRef: e.identity.reviewId,
  proposalRef: e.proposalBinding.proposalId
}), gd = (e) => {
  if (!rt(e, ["sidecar", "proposal", "lifecycle"]))
    return c({
      status: "failure",
      intent: null,
      sidecar: e.sidecar,
      diagnostic: rr(e.sidecar, "$")
    });
  const t = Te(e.sidecar), r = oi(e.proposal);
  if (t.status !== "success" || r.status !== "success" || r.cacheStatus !== "exact" || t.sidecar.status !== "active" || t.sidecar.proposalBinding.proposalFingerprint !== r.proposal.fingerprint || t.sidecar.proposalBinding.lifecycleFingerprint !== e.lifecycle.fingerprint || t.sidecar.decisions.some(
    (o) => o.state !== "rejected"
  ))
    return c({
      status: "conflict",
      intent: null,
      sidecar: t.status === "success" ? t.sidecar : e.sidecar,
      diagnostic: rr(e.sidecar, "$.sidecar")
    });
  const i = t.sidecar;
  if (!pa(i, "reject"))
    return c({
      status: "conflict",
      intent: null,
      sidecar: i,
      diagnostic: rr(i, "$.sidecar.revision")
    });
  const n = ua({
    lifecycle: e.lifecycle
  });
  if (n.status !== "success")
    return ss(i, "reject"), c({
      status: n.status,
      intent: null,
      sidecar: i,
      diagnostic: n.diagnostic
    });
  const s = {
    kind: "zx-ai-review-reject-intent-v1",
    version: "1.0.0",
    reviewId: i.identity.reviewId,
    expectedReviewRevision: i.revision,
    expectedReviewFingerprint: i.fingerprint,
    proposalDiscardIntent: n.intent
  };
  return c({
    status: "reject-intent-ready",
    sidecar: i,
    intent: {
      ...s,
      fingerprint: Lt(
        "zx-ai-review-reject-intent:v1",
        s
      )
    }
  });
}, md = (e) => {
  if (!rt(e, ["sidecar", "intent", "discardedLifecycle"]) || !rt(e.intent, [
    "kind",
    "version",
    "reviewId",
    "expectedReviewRevision",
    "expectedReviewFingerprint",
    "proposalDiscardIntent",
    "fingerprint"
  ]))
    return c({
      status: "failure",
      sidecar: e.sidecar,
      diagnostic: rr(e.sidecar, "$")
    });
  const t = Te(e.sidecar), r = t.status === "success" ? t.sidecar : e.sidecar, i = {
    kind: e.intent.kind,
    version: e.intent.version,
    reviewId: e.intent.reviewId,
    expectedReviewRevision: e.intent.expectedReviewRevision,
    expectedReviewFingerprint: e.intent.expectedReviewFingerprint,
    proposalDiscardIntent: e.intent.proposalDiscardIntent
  }, n = e.discardedLifecycle;
  if (t.status !== "success" || r.status !== "active" || e.intent.fingerprint !== Lt(
    "zx-ai-review-reject-intent:v1",
    i
  ) || e.intent.reviewId !== r.identity.reviewId || e.intent.expectedReviewRevision !== r.revision || e.intent.expectedReviewFingerprint !== r.fingerprint || n.status !== "discarded" || !os(n) || n.proposalId !== r.proposalBinding.proposalId || n.revision !== e.intent.proposalDiscardIntent.candidateRevision || n.fingerprint !== Xi({
    proposalId: n.proposalId,
    revision: n.revision,
    status: n.status
  }) || !ns(
    {
      proposalId: e.intent.proposalDiscardIntent.proposalId,
      expectedRevision: e.intent.proposalDiscardIntent.expectedRevision,
      expectedFingerprint: e.intent.proposalDiscardIntent.expectedFingerprint
    },
    {
      proposalId: r.proposalBinding.proposalId,
      expectedRevision: r.proposalBinding.lifecycleRevision,
      expectedFingerprint: r.proposalBinding.lifecycleFingerprint
    }
  ))
    return ss(r, "reject"), c({
      status: "conflict",
      sidecar: r,
      diagnostic: rr(r, "$.discardedLifecycle")
    });
  const s = si(r, {
    status: "rejected",
    auditKind: "rejected",
    operationIndexes: r.decisions.map(
      (o) => o.operationIndex
    )
  });
  return fa(r, s, "reject") ? c({ status: "rejected", sidecar: s }) : c({
    status: "conflict",
    sidecar: r,
    diagnostic: rr(r, "$.sidecar.revision")
  });
}, ei = /^sha256:[a-f0-9]{64}$/i, Dt = /^[A-Za-z0-9_.:-]{1,160}$/, _i = /* @__PURE__ */ new Map(), vd = (e, t, r) => it({
  code: e,
  stage: "refinement",
  path: t,
  reviewRef: r.identity.reviewId,
  proposalRef: r.proposalBinding.proposalId
}), yr = (e, t, r, i) => c({
  status: e,
  handoff: null,
  sidecar: t.sidecar,
  diagnostic: vd(r, i, t.sidecar)
}), hd = (e) => {
  const t = Te(e.sidecar), r = oi(e.proposal);
  if (t.status !== "success" || r.status !== "success" || t.sidecar.status !== "active" || !Yi(t.sidecar))
    return !1;
  const i = t.sidecar, n = r.proposal, s = e.lifecycle;
  return s.status === "active" && os(s) && s.proposalId === n.identity.proposalId && s.revision === n.lifecycle.revision && s.fingerprint === n.lifecycle.fingerprint && s.fingerprint === Xi({
    proposalId: s.proposalId,
    revision: s.revision,
    status: s.status
  }) && i.proposalBinding.proposalId === n.identity.proposalId && i.proposalBinding.variantId === n.identity.variantId && i.proposalBinding.proposalFingerprint === n.fingerprint && i.proposalBinding.lifecycleRevision === s.revision && i.proposalBinding.lifecycleFingerprint === s.fingerprint && i.proposalBinding.baseFingerprint === n.base.fingerprint && i.proposalBinding.targetFingerprint === n.base.targetFingerprint && i.proposalBinding.planDigest === n.base.planDigest && i.proposalBinding.resultFingerprint === n.runtimeExecution.resultFingerprint && i.proposalBinding.operationCount === n.operationProjection.length && e.latestBaseFingerprint === n.base.fingerprint;
}, yd = (e) => Lt("zx-ai-review-refinement-exact-key:v1", {
  commandId: e.commandId,
  reviewId: e.sidecar.identity.reviewId,
  reviewRevision: e.sidecar.revision,
  reviewFingerprint: e.sidecar.fingerprint,
  proposalFingerprint: e.proposal.fingerprint,
  lifecycleFingerprint: e.lifecycle.fingerprint,
  targetFingerprint: e.proposal.base.targetFingerprint,
  baseFingerprint: e.latestBaseFingerprint,
  predecessorResultDigest: e.proposal.runtimeExecution.resultFingerprint,
  refinementPromptDigest: e.refinementPromptDigest,
  nextVariantId: e.nextVariantId
}), Id = (e) => {
  if (!rt(e, [
    "sidecar",
    "proposal",
    "lifecycle",
    "commandId",
    "latestBaseFingerprint",
    "refinementPromptDigest",
    "nextVariantId"
  ]) || !Dt.test(e.commandId) || !Dt.test(e.nextVariantId) || !ei.test(e.latestBaseFingerprint) || !ei.test(e.refinementPromptDigest))
    return yr("failure", e, "review-input-invalid", "$");
  const t = yd(e), r = _i.get(e.sidecar.identity.reviewId);
  if (r)
    return r.exactKey === t ? c({ ...r.result, idempotent: !0 }) : yr("conflict", e, "review-conflict", "$.commandId");
  if (e.nextVariantId === e.proposal.identity.variantId || !hd(e))
    return yr("conflict", e, "review-conflict", "$.sidecar");
  const i = ga(
    e.proposal.operationProjection
  );
  if (!i)
    return yr(
      "failure",
      e,
      "review-refinement-invalid",
      "$.proposal.operationProjection"
    );
  const n = i.fingerprintProjection.map(
    ({ intentDigest: g }) => g
  ), s = si(e.sidecar, {
    status: "superseded",
    auditKind: "refinement-issued",
    commandId: e.commandId,
    operationIndexes: i.operationIndexes
  });
  if (!Gi(e.sidecar, s))
    return yr("conflict", e, "review-conflict", "$.sidecar.revision");
  const o = Lt(
    "zx-ai-review-refinement-lineage:v1",
    {
      proposalId: e.proposal.identity.proposalId,
      sourceVariantId: e.proposal.identity.variantId,
      nextVariantId: e.nextVariantId,
      predecessorResultDigest: e.proposal.runtimeExecution.resultFingerprint,
      operationIntentDigests: n
    }
  ), a = {
    kind: "zx-ai-review-refinement-handoff-v1",
    version: "1.0.0",
    exactKey: t,
    commandId: e.commandId,
    reviewId: e.sidecar.identity.reviewId,
    sourceReviewRevision: e.sidecar.revision,
    sourceReviewFingerprint: e.sidecar.fingerprint,
    terminalSidecarFingerprint: s.fingerprint,
    proposalId: e.proposal.identity.proposalId,
    sourceVariantId: e.proposal.identity.variantId,
    nextVariantId: e.nextVariantId,
    proposalFingerprint: e.proposal.fingerprint,
    lifecycleFingerprint: e.lifecycle.fingerprint,
    targetFingerprint: e.proposal.base.targetFingerprint,
    baseFingerprint: e.proposal.base.fingerprint,
    predecessorResultDigest: e.proposal.runtimeExecution.resultFingerprint,
    refinementPromptDigest: e.refinementPromptDigest,
    operationIntentDigests: n,
    lineageDigest: o
  }, d = as({
    ...a,
    fingerprint: Lt(
      "zx-ai-review-refinement-handoff:v1",
      a
    )
  }), l = c({
    status: "refinement-issued",
    handoff: d,
    sidecar: s,
    idempotent: !1
  });
  return _i.set(e.sidecar.identity.reviewId, {
    exactKey: t,
    result: l
  }), l;
}, Gt = (e, t) => c({
  status: e,
  handoff: null,
  diagnostic: it({
    code: e === "review-runtime-unsupported" ? "review-runtime-unsupported" : "review-refinement-invalid",
    stage: "codec",
    path: t
  })
}), bd = (e) => rt(e, [
  "kind",
  "version",
  "exactKey",
  "commandId",
  "reviewId",
  "sourceReviewRevision",
  "sourceReviewFingerprint",
  "terminalSidecarFingerprint",
  "proposalId",
  "sourceVariantId",
  "nextVariantId",
  "proposalFingerprint",
  "lifecycleFingerprint",
  "targetFingerprint",
  "baseFingerprint",
  "predecessorResultDigest",
  "refinementPromptDigest",
  "operationIntentDigests",
  "lineageDigest",
  "fingerprint"
]) && e.kind === "zx-ai-review-refinement-handoff-v1" && e.version === "1.0.0" && Dt.test(String(e.commandId)) && Dt.test(String(e.reviewId)) && Dt.test(String(e.proposalId)) && Dt.test(String(e.sourceVariantId)) && Dt.test(String(e.nextVariantId)) && Zr(e.sourceReviewRevision) && [
  e.exactKey,
  e.sourceReviewFingerprint,
  e.terminalSidecarFingerprint,
  e.proposalFingerprint,
  e.lifecycleFingerprint,
  e.targetFingerprint,
  e.baseFingerprint,
  e.predecessorResultDigest,
  e.refinementPromptDigest,
  e.lineageDigest,
  e.fingerprint
].every((t) => ei.test(String(t))) && Array.isArray(e.operationIntentDigests) && e.operationIntentDigests.length > 0 && e.operationIntentDigests.length <= Wi.maxItems && e.operationIntentDigests.every(
  (t) => typeof t == "string" && ei.test(t)
), Fd = (e) => {
  let t = e;
  try {
    if (typeof e == "string" && (new TextEncoder().encode(e).byteLength > Wi.maxBytes || (t = JSON.parse(e), Br(t, ji).canonical !== e)))
      return Gt("review-refinement-handoff-invalid", "$");
    Br(t, ji);
  } catch {
    return Gt("review-refinement-handoff-invalid", "$");
  }
  if (t && typeof t == "object" && !Array.isArray(t) && t.kind === "zx-ai-review-refinement-handoff-v1" && t.version !== "1.0.0")
    return Gt("review-runtime-unsupported", "$.version");
  if (!bd(t))
    return Gt("review-refinement-handoff-invalid", "$");
  const { fingerprint: r, ...i } = t;
  return r !== Lt("zx-ai-review-refinement-handoff:v1", i) ? Gt("review-refinement-handoff-invalid", "$.fingerprint") : c({
    status: "success",
    handoff: as(t)
  });
}, ju = (e) => {
  const t = Fd(e);
  if (t.status !== "success")
    throw new TypeError("review-refinement-handoff-invalid");
  return Br(t.handoff, ji).canonical;
}, Du = () => {
  _i.clear();
}, zu = c([
  {
    repository: "BlockNote",
    commit: "4e9e785530ff4c173f876fcac09cf334fe61b5dc",
    paths: [
      "packages/xl-ai/src/AIExtension.ts",
      "packages/xl-ai/src/prosemirror/changeset.ts",
      "packages/core/src/yjs/extensions/ForkYDoc.ts",
      "packages/core/src/yjs/extensions/ForkYDoc.test.ts"
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "accept/reject cadence, one-undo exact-base recovery, and marks/attrs/table cases become review behavior fixtures",
        fixtureIds: ["REF-S4-BN-UNDO-01", "REF-S4-BN-DIFF-04"]
      },
      {
        decision: "reject",
        boundary: "direct editor rollback/replacement, AI SDK execution, and Yjs merge are outside S4 authority",
        fixtureIds: ["REF-S4-BN-REJECT-02", "REF-S4-BN-YJS-REJECT-03"]
      }
    ]
  },
  {
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    paths: [
      "packages/suggestion/src/lib/transforms/acceptSuggestion.tsx",
      "packages/suggestion/src/lib/transforms/acceptSuggestion.spec.tsx",
      "packages/suggestion/src/lib/transforms/rejectSuggestion.tsx",
      "packages/suggestion/src/lib/transforms/rejectSuggestion.spec.tsx",
      "packages/suggestion/src/lib/diffToSuggestions.ts",
      "packages/suggestion/src/lib/diffToSuggestions.spec.ts",
      "packages/ai/src/react/ai-chat/utils/applyAISuggestions.ts",
      "packages/ai/src/react/ai-chat/utils/rejectAISuggestions.ts"
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "insert/remove/update/line-break/table/multi-suggestion cases become operation-decision and regeneration fixtures",
        fixtureIds: [
          "REF-S4-PLATE-INSERT-01",
          "REF-S4-PLATE-REMOVE-02",
          "REF-S4-PLATE-UPDATE-03",
          "REF-S4-PLATE-LINE-04"
        ]
      },
      {
        decision: "reject",
        boundary: "Slate mutation, React ownership, and suggestion-as-document-truth remain outside S4",
        fixtureIds: []
      }
    ]
  },
  {
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    paths: [
      "apps/web/components/tailwind/generative/ai-completion-command.tsx",
      "apps/web/components/tailwind/generative/ai-selector-commands.tsx"
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "replace/insert/discard/continue cadence and whole-review naming become headless S4 fixtures",
        fixtureIds: ["REF-S4-NOVEL-CADENCE-01"]
      },
      {
        decision: "reject",
        boundary: "raw positions, Markdown/provider/UI coupling, and direct editor writes remain outside S4",
        fixtureIds: ["REF-S4-NOVEL-DIRECT-WRITE-REJECT-02"]
      }
    ]
  }
]), Ou = "1.0.0", Ce = (e, t) => c({ status: "successor-failure", reason: e, path: t }), bi = (e) => {
  if (!e || typeof e != "object") return pe(e);
  const { operationIndex: t, ...r } = e;
  return pe(r);
}, Nu = (e) => b({
  code: "session-handoff-failure",
  stage: "handoff",
  path: `${e.path}#${e.reason}`
}), Gs = /* @__PURE__ */ new WeakSet(), Ws = (e) => c({
  ...e,
  fingerprint: Ns(e)
}), Ys = (e) => fe("zx-ai-session/v1/review-artifact-transfer", e), Ft = (e) => c({
  status: "failure",
  diagnostic: b({
    code: "session-handoff-failure",
    stage: "handoff",
    path: e
  })
}), Pt = (e) => {
  var l, g, u, p;
  if (typeof e == "object" && e !== null && Gs.has(e))
    return c({
      status: "success",
      transfer: e
    });
  if (!T(e, [
    "kind",
    "version",
    "receipt",
    "proposal",
    "lifecycle",
    "sidecar",
    "fingerprint"
  ]) || e.kind !== "zx-ai-session-review-artifact-transfer-v1" || e.version !== "1.0.0" || !Pe(e.fingerprint))
    return Ft("$");
  const t = on(e.receipt, "$.receipt");
  if (!t.ok) return Ft(t.diagnostic.path);
  const r = oi(e.proposal);
  if (r.status !== "success")
    return Ft("$.proposal");
  const i = Te(e.sidecar);
  if (i.status !== "success")
    return Ft("$.sidecar");
  if (!T(e.lifecycle, [
    "proposalId",
    "revision",
    "status",
    "fingerprint"
  ]) || !q(e.lifecycle.proposalId) || !L(e.lifecycle.revision) || !["active", "committed", "discarded"].includes(
    String(e.lifecycle.status)
  ) || !Pe(e.lifecycle.fingerprint))
    return Ft("$.lifecycle");
  const n = c({
    proposalId: e.lifecycle.proposalId,
    revision: e.lifecycle.revision,
    status: e.lifecycle.status,
    fingerprint: e.lifecycle.fingerprint
  });
  if (n.fingerprint !== Xi({
    proposalId: n.proposalId,
    revision: n.revision,
    status: n.status
  }))
    return Ft("$.lifecycle.fingerprint");
  const s = t.value, o = r.proposal, a = i.sidecar;
  if (s.outcome !== "awaiting-review" || s.proposalId !== o.identity.proposalId || s.proposalFingerprint !== o.fingerprint || s.lifecycleFingerprint !== n.fingerprint || n.proposalId !== o.identity.proposalId || n.fingerprint !== o.lifecycle.fingerprint || s.reviewId !== a.identity.reviewId || s.reviewFingerprint !== a.fingerprint || a.proposalBinding.proposalId !== o.identity.proposalId || a.proposalBinding.variantId !== o.identity.variantId || a.proposalBinding.proposalFingerprint !== o.fingerprint || a.proposalBinding.lifecycleFingerprint !== n.fingerprint || o.provenance.sourceId !== s.sessionId || ((l = o.provenance.refs[0]) == null ? void 0 : l.id) !== s.requestId || ((g = o.provenance.refs[0]) == null ? void 0 : g.type) !== "plan" || ((u = o.provenance.refs[1]) == null ? void 0 : u.id) !== s.attemptId || ((p = o.provenance.refs[1]) == null ? void 0 : p.type) !== "activity")
    return Ft("$.receipt");
  const d = Ys({
    receiptFingerprint: s.fingerprint,
    proposalFingerprint: o.fingerprint,
    lifecycleFingerprint: n.fingerprint,
    sidecarFingerprint: a.fingerprint
  });
  return e.fingerprint !== d ? Ft("$.fingerprint") : c({
    status: "success",
    transfer: {
      kind: "zx-ai-session-review-artifact-transfer-v1",
      version: "1.0.0",
      receipt: s,
      proposal: o,
      lifecycle: n,
      sidecar: a,
      fingerprint: d
    }
  });
}, Xs = (e) => {
  const t = {
    kind: "zx-ai-session-review-artifact-transfer-v1",
    version: "1.0.0",
    ...e,
    fingerprint: Ys({
      receiptFingerprint: e.receipt.fingerprint,
      proposalFingerprint: e.proposal.fingerprint,
      lifecycleFingerprint: e.lifecycle.fingerprint,
      sidecarFingerprint: e.sidecar.fingerprint
    })
  }, r = Pt(t);
  if (r.status !== "success")
    throw new TypeError("session-review-artifact-transfer-invalid");
  return Gs.add(r.transfer), r.transfer;
}, ln = async (e, t = {}) => {
  var y, I, h, v, F, w, x, j;
  const r = ze(e, "$");
  if (r || !T(
    e,
    ["sealedResult"],
    [
      "effect",
      "snapshot",
      "baseDocument",
      "proposalId",
      "variantId",
      "reviewId",
      "documentSentinel"
    ]
  ))
    return c({
      status: "handoff-failure",
      diagnostic: r ?? b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$"
      })
    });
  const i = an(
    e.sealedResult,
    "$.sealedResult"
  );
  if (!i.ok)
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: i.diagnostic.path
      })
    });
  const n = i.value;
  if (n.kind === "message-only")
    return c({ status: "message-only" });
  if (n.kind === "no-change")
    return c({ status: "no-change" });
  const { effect: s } = e;
  if (!T(s, [
    "effectId",
    "kind",
    "sessionId",
    "requestId",
    "attemptId",
    "sourceRevision",
    "sourceFingerprint",
    "idempotencyKey",
    "sealedResultFingerprint",
    "resultKind"
  ]) || s.kind !== "proposal-handoff" || !q(s.effectId) || !q(s.sessionId) || !q(s.requestId) || !q(s.attemptId) || !L(s.sourceRevision) || typeof s.sourceFingerprint != "string" || !q(s.idempotencyKey) || s.idempotencyKey !== s.effectId || s.resultKind !== "operation-envelope" || s.sealedResultFingerprint !== n.fingerprint)
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.effect"
      })
    });
  if (!e.snapshot || !e.baseDocument)
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.snapshot"
      })
    });
  await ((y = t.yieldControl) == null ? void 0 : y.call(t));
  const o = e.documentSentinel, a = await Zi({
    snapshot: e.snapshot,
    envelope: n.operationEnvelope,
    complex: t.complex
  });
  if (!a.valid || !a.plan)
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.validateAIOperationEnvelope",
        count: a.diagnostics.length
      })
    });
  await ((I = t.yieldControl) == null ? void 0 : I.call(t));
  const d = e.proposalId ?? `proposal:${s.requestId}`, l = e.variantId ?? `variant:${s.attemptId}`, g = cs({
    proposalId: d,
    revision: 0
  }), u = ds({
    runtime: kr,
    baseDocument: e.baseDocument,
    plan: a.plan,
    identity: { proposalId: d, variantId: l },
    lifecycle: g,
    provenance: {
      sourceId: s.sessionId,
      sequence: 1,
      refs: [
        { id: s.requestId, type: "plan" },
        { id: s.attemptId, type: "activity" }
      ]
    },
    runtimeContext: { protocol: "zx-runtime-execution-context-v1" }
  });
  if (u.status !== "success") {
    const _ = u.status === "runtime-failure" || u.status === "safety-abort" ? ((v = (h = u.runtimeOutcome) == null ? void 0 : h.diagnostic) == null ? void 0 : v.path) ?? ((F = u.runtimeOutcome) == null ? void 0 : F.code) : ((w = u.diagnostic) == null ? void 0 : w.path) ?? u.status;
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: typeof _ == "string" && _.length > 0 ? _.startsWith("$.") ? `$.executeAIProposal${_.slice(1)}` : `$.executeAIProposal/${_}` : "$.executeAIProposal"
      })
    });
  }
  await ((x = t.yieldControl) == null ? void 0 : x.call(t));
  const p = e.reviewId ?? `review:${s.requestId}`, f = ls({
    identity: { reviewId: p },
    policyRef: Ar,
    proposal: u.proposal,
    lifecycle: u.proposal.lifecycle
  });
  if (f.status !== "active")
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-handoff-failure",
        stage: "handoff",
        path: "$.createAIReviewSidecar"
      })
    });
  if (await ((j = t.yieldControl) == null ? void 0 : j.call(t)), e.documentSentinel !== void 0 && JSON.stringify(e.documentSentinel) !== JSON.stringify(o))
    return c({
      status: "handoff-failure",
      diagnostic: b({
        code: "session-safety-abort",
        stage: "handoff",
        path: "$.documentSentinel"
      })
    });
  const m = Ws({
    kind: "zx-ai-session-handoff-receipt-v1",
    version: "1.0.0",
    handoffId: `handoff:${s.effectId}`,
    effectId: s.effectId,
    sourceRevision: s.sourceRevision,
    sourceSessionFingerprint: s.sourceFingerprint,
    sessionId: s.sessionId,
    requestId: s.requestId,
    attemptId: s.attemptId,
    resultKind: "operation-envelope",
    sealedResultFingerprint: n.fingerprint,
    proposalId: u.proposal.identity.proposalId,
    proposalFingerprint: u.proposal.fingerprint,
    reviewId: f.sidecar.identity.reviewId,
    reviewFingerprint: f.sidecar.fingerprint,
    lifecycleFingerprint: u.proposal.lifecycle.fingerprint,
    outcome: "awaiting-review"
  });
  return c({
    status: "awaiting-review",
    receipt: m,
    transfer: Xs({
      receipt: m,
      proposal: u.proposal,
      lifecycle: u.proposal.lifecycle,
      sidecar: f.sidecar
    })
  });
}, _u = async (e, t = {}) => {
  var ie, O, R;
  if (!T(
    e,
    [
      "handoff",
      "superseded",
      "sealedResult",
      "snapshot",
      "baseDocument",
      "nextIdentity"
    ],
    ["reviewId"]
  ) || !T(e.superseded, ["receipt", "proposal", "sidecar"]) || !T(e.nextIdentity, [
    "proposalId",
    "variantId",
    "parentVariantId"
  ]))
    return Ce("input-invalid", "$");
  const { handoff: r, superseded: i, nextIdentity: n } = e;
  if (r.kind !== "zx-ai-review-regeneration-handoff-v1" || !Array.isArray(r.operationIntentDigests) || r.operationIntentDigests.length === 0)
    return Ce("input-invalid", "$.handoff");
  const s = oi(i.proposal), o = Te(i.sidecar);
  if (s.status !== "success" || o.status !== "success")
    return Ce("input-invalid", "$.superseded");
  const a = s.proposal, d = o.sidecar;
  if (r.supersededProposalFingerprint !== a.fingerprint || r.reviewFingerprint !== d.fingerprint || d.status !== "superseded" || i.receipt.proposalFingerprint !== a.fingerprint || i.receipt.reviewId !== d.identity.reviewId)
    return Ce("handoff-mismatch", "$.superseded");
  if (n.proposalId !== a.identity.proposalId || n.parentVariantId !== a.identity.variantId || n.variantId === a.identity.variantId)
    return Ce("handoff-mismatch", "$.nextIdentity");
  const l = an(
    e.sealedResult,
    "$.sealedResult"
  );
  if (!l.ok || l.value.kind !== "operation-envelope" || l.value.fingerprint !== i.receipt.sealedResultFingerprint)
    return Ce("envelope-mismatch", "$.sealedResult");
  const g = l.value.operationEnvelope;
  if (g.operations.length !== a.operationProjection.length || a.operationProjection.some(
    (E, D) => E.operationIndex !== D
  ) || a.base.plan.steps.length !== g.operations.length || a.base.plan.steps.some(
    (E, D) => E.operationIndex !== D
  ))
    return Ce(
      "envelope-mismatch",
      "$.sealedResult.operationEnvelope"
    );
  if (pe(e.baseDocument) !== r.latestBaseRequirement.latestBaseFingerprint)
    return Ce("base-mismatch", "$.baseDocument");
  const u = new Map(
    a.operationProjection.map((E) => [
      E.intentDigest,
      E.operationIndex
    ])
  ), p = /* @__PURE__ */ new Set();
  for (const E of r.operationIntentDigests) {
    const D = u.get(E);
    if (D === void 0)
      return Ce(
        "handoff-mismatch",
        "$.handoff.operationIntentDigests"
      );
    p.add(D);
  }
  const f = [...p].sort((E, D) => E - D);
  for (const E of f)
    if (a.operationProjection[E].dependencyOperationIndexes.some((K) => !p.has(K)))
      return Ce(
        "dependency-conflict",
        `$.operations[${E}]`
      );
  await ((ie = t.yieldControl) == null ? void 0 : ie.call(t));
  const m = {
    protocolVersion: g.protocolVersion,
    source: g.source,
    operations: f.map((E) => g.operations[E])
  }, y = await Zi({
    snapshot: e.snapshot,
    envelope: m,
    complex: t.complex
  });
  if (!y.valid || !y.plan)
    return Ce(
      "validation-failed",
      "$.validateAIOperationEnvelope"
    );
  const I = f.map(
    (E) => bi(a.base.plan.steps[E])
  ), h = y.plan.steps.map(
    (E) => bi(E)
  );
  if (I.length !== h.length || I.some((E, D) => E !== h[D]))
    return Ce("exactness-failed", "$.plan.steps");
  await ((O = t.yieldControl) == null ? void 0 : O.call(t));
  const v = cs({
    proposalId: n.proposalId,
    revision: 0
  }), F = ds({
    runtime: kr,
    baseDocument: e.baseDocument,
    plan: y.plan,
    identity: {
      proposalId: n.proposalId,
      variantId: n.variantId,
      parentVariantId: n.parentVariantId
    },
    lifecycle: v,
    provenance: {
      sourceId: i.receipt.sessionId,
      sequence: a.provenance.sequence + 1,
      refs: [
        { id: i.receipt.requestId, type: "plan" },
        { id: i.receipt.attemptId, type: "activity" }
      ]
    },
    runtimeContext: { protocol: "zx-runtime-execution-context-v1" }
  });
  if (F.status !== "success")
    return Ce("execution-failed", "$.executeAIProposal");
  const w = F.proposal;
  if (w.operationProjection.length !== f.length || w.base.plan.steps.some(
    (E, D) => bi(E) !== I[D]
  ) || w.base.fingerprint !== pe(e.baseDocument))
    return Ce("exactness-failed", "$.proposal");
  await ((R = t.yieldControl) == null ? void 0 : R.call(t));
  const x = e.reviewId ?? `review:${n.variantId}:successor`, j = ls({
    identity: { reviewId: x },
    policyRef: Ar,
    proposal: w,
    lifecycle: w.lifecycle
  });
  if (j.status !== "active")
    return Ce("review-failed", "$.createAIReviewSidecar");
  const _ = Ws({
    kind: "zx-ai-session-handoff-receipt-v1",
    version: "1.0.0",
    // Safe-id budget: the variant id is unique per successor on its own.
    handoffId: `handoff:${n.variantId}:successor`,
    effectId: i.receipt.effectId,
    sourceRevision: i.receipt.sourceRevision,
    sourceSessionFingerprint: i.receipt.sourceSessionFingerprint,
    sessionId: i.receipt.sessionId,
    requestId: i.receipt.requestId,
    attemptId: i.receipt.attemptId,
    resultKind: "operation-envelope",
    sealedResultFingerprint: i.receipt.sealedResultFingerprint,
    proposalId: w.identity.proposalId,
    proposalFingerprint: w.fingerprint,
    reviewId: j.sidecar.identity.reviewId,
    reviewFingerprint: j.sidecar.fingerprint,
    lifecycleFingerprint: w.lifecycle.fingerprint,
    outcome: "awaiting-review"
  });
  let G;
  try {
    G = Xs({
      receipt: _,
      proposal: w,
      lifecycle: w.lifecycle,
      sidecar: j.sidecar
    });
  } catch {
    return Ce("review-failed", "$.transfer");
  }
  return c({ status: "awaiting-review", receipt: _, transfer: G });
}, xd = "zx-ai-session-historical-reader-v1", Lu = (e) => {
  if (e && typeof e == "object" && !Array.isArray(e) && "version" in e && e.version !== nt)
    return c({
      status: "unsupported",
      session: null,
      diagnostic: b({
        code: "session-historical-unsupported",
        stage: "historical",
        path: "$.version"
      })
    });
  const t = Bt(e);
  return t.ok ? c({
    status: "success",
    session: t.value,
    diagnostic: null
  }) : c({
    status: "failure",
    session: null,
    diagnostic: t.diagnostic
  });
}, wd = (e) => {
  const t = Bt(e);
  if (!t.ok)
    throw new TypeError(t.diagnostic.code);
  return Ae(t.value);
}, Vu = (e) => {
  if (e.version !== nt)
    return {
      status: "unsupported",
      diagnostic: b({
        code: "session-historical-unsupported",
        stage: "historical",
        path: "$.version"
      })
    };
  const t = Bt(e);
  if (!t.ok)
    return {
      status: "failure",
      diagnostic: t.diagnostic
    };
  const r = {
    kind: "zx-ai-session-historical-envelope-v1",
    reader: xd,
    version: nt,
    artifact: wd(t.value),
    mode: "audit-only"
  };
  return {
    status: "success",
    envelope: c({
      ...r,
      fingerprint: fe(
        "zx-ai-session/v1/historical",
        r
      )
    })
  };
}, Hu = c([
  {
    repository: "BlockNote",
    commit: "4e9e785530ff4c173f876fcac09cf334fe61b5dc",
    paths: [
      "packages/xl-ai/src/api/aiRequest/types.ts",
      "packages/xl-ai/src/api/aiRequest/builder.ts",
      "packages/xl-ai/src/api/aiRequest/sendMessageWithAIRequest.ts",
      "packages/xl-ai/src/AIExtension.ts",
      "packages/xl-ai/src/streamTool/StreamToolExecutor.ts",
      "packages/xl-ai/src/streamTool/streamTool.ts",
      "packages/xl-ai/src/streamTool/vercelAiSdk/util/appendableStream.ts",
      "packages/xl-ai/src/streamTool/vercelAiSdk/util/appendableStream.test.ts",
      "packages/xl-ai/src/streamTool/vercelAiSdk/util/chatHandlers.ts",
      "packages/xl-ai/src/streamTool/vercelAiSdk/util/chatHandlers.test.ts",
      "packages/xl-ai/src/streamTool/vercelAiSdk/clientside/ClientSideTransport.ts"
    ],
    decisions: [
      {
        decision: "copy",
        boundary: "sequential append, cancel/no-hang, error propagation, already-aborted fixtures become normalized event/fake-transport tests",
        fixtureIds: ["REF-BN-01", "REF-BN-02", "REF-BN-03", "REF-BN-04"]
      },
      {
        decision: "adapt",
        boundary: "request builder selection/cursor/document snapshot and appendable stream order become Session request input + event chain",
        fixtureIds: ["REF-BN-01", "REF-BN-02"]
      },
      {
        decision: "reject",
        boundary: "Chat/Vercel AI SDK as session truth, partial tool editor execution, prompt-based retry, unimplemented resume",
        fixtureIds: []
      }
    ]
  },
  {
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    paths: [
      "packages/ai/src/react/ai-chat/AIChatPlugin.ts",
      "packages/ai/src/react/ai-chat/utils/submitAIChat.ts",
      "packages/ai/src/react/ai-chat/hooks/useChatChunk.ts",
      "packages/ai/src/react/ai-chat/utils/resetAIChat.ts",
      "packages/ai/src/react/copilot/utils/callCompletionApi.ts",
      "packages/ai/src/lib/BaseAIPlugin.ts",
      "packages/ai/src/react/ai-chat/AIChatPlugin.spec.ts",
      "packages/ai/src/react/ai-chat/utils/submitAIChat.slow.ts",
      "apps/www/src/__tests__/package-integration/ai-chat-streaming/streamHistory.slow.tsx"
    ],
    decisions: [
      {
        decision: "copy",
        boundary: "stop cleanup, context parity, stream not in history, accept single-undo become ZXUI public fixtures",
        fixtureIds: ["REF-PL-01", "REF-PL-02", "REF-PL-03", "REF-PL-04"]
      },
      {
        decision: "adapt",
        boundary: "cumulative response delta, stop/reset invariants, stream zero-write + downstream single undo",
        fixtureIds: ["REF-PL-02", "REF-PL-03", "REF-PL-04"]
      },
      {
        decision: "reject",
        boundary: "React/Slate/UseChatHelpers mutable state, stream direct editor writes, provider fetch in core",
        fixtureIds: []
      }
    ]
  },
  {
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    paths: [
      "apps/web/components/tailwind/generative/ai-selector.tsx",
      "apps/web/components/tailwind/generative/ai-selector-commands.tsx",
      "apps/web/components/tailwind/generative/ai-completion-command.tsx",
      "packages/headless/src/extensions/ai-highlight.ts"
    ],
    decisions: [
      {
        decision: "copy",
        boundary: "improve/fix/shorter/longer/continue and loading/stop/retry/follow-up intent table as headless request-kind fixtures",
        fixtureIds: ["REF-NV-01", "REF-NV-02", "REF-NV-03", "REF-NV-04"]
      },
      {
        decision: "adapt",
        boundary: "loading/stop/retry/continue/follow-up become projection capability and new-request lineage fixtures",
        fixtureIds: ["REF-NV-01", "REF-NV-02", "REF-NV-03"]
      },
      {
        decision: "reject",
        boundary: "Vercel useCompletion lifecycle, raw Markdown, Tiptap command/highlight direct editor writes",
        fixtureIds: ["REF-NV-04"]
      }
    ]
  }
]), Rd = (e) => {
  let t = "";
  return e.forEach((r) => {
    t += String.fromCharCode(r);
  }), btoa(t);
}, er = (e) => c({
  ...e,
  fingerprint: Ue("stream-state", e)
}), kd = (e) => er({
  kind: "zx-ai-complex-node-stream-state-v1",
  adapter: e.adapter,
  operation: e.operation,
  policy: e.policy,
  status: "receiving",
  nextSequence: 0,
  chunks: [],
  byteLength: 0,
  attempt: 1,
  diagnostic: null
}), Fi = (e, t) => er({
  ...e,
  status: "failed",
  chunks: [],
  byteLength: 0,
  diagnostic: ma(t, "stream", "$.event")
}), Sd = (e, t, r) => {
  if (t.kind === "retry")
    return e.status !== "failed" && e.status !== "aborted" ? e : er({
      ...e,
      status: "receiving",
      nextSequence: 0,
      chunks: [],
      byteLength: 0,
      attempt: e.attempt + 1,
      diagnostic: null
    });
  if (e.status !== "receiving" || t.sequence !== e.nextSequence)
    return Fi(e, "complex-payload-invalid");
  if (t.kind === "abort")
    return er({
      ...e,
      status: "aborted",
      nextSequence: e.nextSequence + 1,
      chunks: [],
      byteLength: 0,
      diagnostic: null
    });
  if (t.kind === "close")
    return Fi(e, "complex-payload-invalid");
  if (t.kind === "complete")
    return er({
      ...e,
      status: "complete-candidate",
      nextSequence: e.nextSequence + 1,
      diagnostic: null
    });
  const i = e.byteLength + t.bytes.byteLength;
  return e.policy !== "incremental" || i > r.maxBytes || r.validatePartial && !r.validatePartial({
    sequence: t.sequence,
    bytes: t.bytes,
    accumulatedBytes: i
  }) ? Fi(e, "complex-limit-exceeded") : er({
    ...e,
    nextSequence: e.nextSequence + 1,
    chunks: [...e.chunks, Rd(t.bytes)],
    byteLength: i,
    diagnostic: null
  });
}, Ad = (e) => {
  if (e.status !== "receiving" && e.status !== "complete-candidate")
    return null;
  const t = {
    kind: "complex-node-transient-preview-v1",
    executable: !1,
    durable: !1,
    adapterFingerprint: e.adapter.adapterFingerprint,
    operation: e.operation,
    byteLength: e.byteLength,
    status: e.status
  };
  return c({
    ...t,
    fingerprint: Ue("stream-preview", t)
  });
}, Ed = (e) => {
  if (e.status !== "complete-candidate") return null;
  const t = [];
  return e.chunks.forEach((r) => {
    const i = atob(r);
    for (let n = 0; n < i.length; n += 1)
      t.push(i.charCodeAt(n));
  }), new Uint8Array(t);
}, Zs = (e) => c({
  ...e,
  fingerprint: fe(
    "zx-ai-session/v1/complex-node-stream",
    e
  )
}), Ku = (e) => {
  if (!q(e.requestId) || !q(e.attemptId))
    throw new TypeError("session-identity-invalid");
  return Zs({
    kind: "zx-ai-session-complex-node-stream-v1",
    requestId: e.requestId,
    attemptId: e.attemptId,
    stream: kd(e)
  });
}, Mu = (e, t, r) => Zs({
  kind: e.kind,
  requestId: e.requestId,
  attemptId: e.attemptId,
  stream: Sd(e.stream, t, r)
}), Uu = (e) => Ad(e.stream), Gu = (e) => Ed(e.stream), Wu = async (e) => {
  const t = [];
  if (!T(e, ["port", "effect"]))
    return c({
      status: "failure",
      events: t,
      diagnostic: b({
        code: "session-input-invalid",
        stage: "transport-admission",
        path: "$"
      })
    });
  const r = Ec(e.effect, "$.effect");
  if (!r.ok)
    return c({
      status: "failure",
      events: t,
      diagnostic: r.diagnostic
    });
  const i = td(r.value);
  if (i)
    return c({
      status: "failure",
      events: t,
      diagnostic: i
    });
  const n = e.port, s = r.value;
  if (s.kind === "proposal-handoff")
    return c({
      status: "failure",
      events: t,
      diagnostic: b({
        code: "session-unsupported",
        stage: "transport-admission",
        path: "$.effect.kind"
      })
    });
  const o = li(
    s.transportAdmission,
    "$.effect.transportAdmission"
  ), a = Us(
    n.descriptor,
    "$.port.descriptor"
  );
  if (!a.ok || !o.ok || o.value.descriptorFingerprint !== a.value.fingerprint || o.value.transportId !== a.value.transportId || o.value.version !== a.value.version || o.value.sessionId !== s.sessionId || o.value.requestId !== s.requestId || !a.value.capabilities.requestKinds.includes(
    o.value.requestKind
  ) || a.value.policyFingerprint !== o.value.policyFingerprint || o.value.capabilities.start !== a.value.capabilities.start || o.value.capabilities.abort !== a.value.capabilities.abort || o.value.capabilities.resume !== a.value.capabilities.resume || o.value.capabilities.requestKinds.length !== a.value.capabilities.requestKinds.length || o.value.capabilities.requestKinds.some(
    (d, l) => d !== a.value.capabilities.requestKinds[l]
  ))
    return c({
      status: "failure",
      events: t,
      diagnostic: b({
        code: "session-transport-unsupported",
        stage: "transport-admission",
        path: "$.port.descriptor"
      })
    });
  try {
    if (s.kind === "transport-start") {
      if (s.requestProjection.inputFingerprint !== o.value.requestInputFingerprint || s.requestProjection.kind !== o.value.requestKind || s.requestProjection.policyFingerprint !== o.value.policyFingerprint)
        return c({
          status: "failure",
          events: t,
          diagnostic: b({
            code: "session-transport-unsupported",
            stage: "transport-admission",
            path: "$.effect.requestProjection"
          })
        });
      for await (const d of n.start({
        effectId: s.effectId,
        sessionId: s.sessionId,
        requestId: s.requestId,
        attemptId: s.attemptId,
        requestProjection: s.requestProjection,
        policyFingerprint: s.requestProjection.policyFingerprint,
        correlationRef: s.idempotencyKey,
        transportAdmission: o.value
      }))
        t.push(d);
      return c({ status: "events", events: t });
    }
    if (s.kind === "transport-abort") {
      if (!a.value.capabilities.abort)
        return c({
          status: "abort-outcome",
          abort: {
            status: "unsupported",
            abortIntentId: s.abortIntentId,
            effectId: s.effectId,
            transportAdmissionFingerprint: o.value.fingerprint
          }
        });
      const d = await n.abort({
        effectId: s.effectId,
        sessionId: s.sessionId,
        requestId: s.requestId,
        attemptId: s.attemptId,
        abortIntentId: s.abortIntentId,
        transportAdmission: o.value
      }), l = rd(d, {
        abortIntentId: s.abortIntentId,
        effectId: s.effectId,
        transportAdmissionFingerprint: o.value.fingerprint
      });
      if (!l.ok)
        return c({
          status: "failure",
          events: t,
          diagnostic: l.diagnostic
        });
      const g = id(d);
      return g ? c({
        status: "failure",
        events: t,
        diagnostic: g
      }) : c({ status: "abort-outcome", abort: l.abort });
    }
    if (s.kind === "transport-resume") {
      if (a.value.capabilities.resume !== "resume:same-attempt-checkpoint-v1" || typeof n.resume != "function")
        return c({
          status: "failure",
          events: t,
          diagnostic: b({
            code: "session-transport-unsupported",
            stage: "transport-admission",
            path: "$.resume",
            capability: "resume:same-attempt-checkpoint-v1"
          })
        });
      for await (const d of n.resume({
        effectId: s.effectId,
        sessionId: s.sessionId,
        requestId: s.requestId,
        attemptId: s.attemptId,
        checkpointFingerprint: s.checkpointFingerprint,
        expectedSequence: s.expectedSequence,
        transportAdmission: o.value
      }))
        t.push(d);
      return c({ status: "events", events: t });
    }
    return c({
      status: "failure",
      events: t,
      diagnostic: b({
        code: "session-unsupported",
        stage: "transport-admission",
        path: "$.effect.kind"
      })
    });
  } catch {
    const d = t[t.length - 1], l = en({
      sessionId: s.sessionId,
      requestId: s.requestId,
      attemptId: s.attemptId,
      sequence: d ? d.sequence + 1 : s.kind === "transport-resume" ? s.expectedSequence : 0,
      ...d ? { previousEventFingerprint: d.fingerprint } : {},
      kind: "attempt-failed",
      payload: {
        kind: "attempt-failed",
        reason: "transport-failed",
        diagnosticCode: "session-transport-failure",
        failureClass: "internal"
      }
    });
    return c({
      status: "failure",
      events: t,
      diagnostic: b({
        code: "session-transport-failure",
        stage: "transport-admission",
        path: "$.port"
      }),
      failureEvent: l
    });
  }
}, pi = c([
  "submit",
  "stop",
  "retry",
  "restart",
  "supersede",
  "follow-up",
  "reveal",
  "review-previous",
  "review-next",
  "review-decide",
  "review-accept-all",
  "review-reject-all",
  "review-commit",
  "review-regenerate",
  "review-refine",
  "retry-review-refine",
  "close",
  "edit-prompt",
  "reselect-target",
  "narrow-scope",
  "choose-supported-command",
  "contact-host"
]), Li = new Set(pi), Cd = /* @__PURE__ */ new Set([
  "transport",
  "provider-adapter",
  "validation",
  "resource-limit",
  "unsupported",
  "anchor-lost",
  "conflict",
  "abort"
]), Js = c({
  transport: ["retry", "restart"],
  "provider-adapter": ["retry", "contact-host"],
  validation: ["edit-prompt", "reselect-target"],
  "resource-limit": ["narrow-scope", "restart"],
  unsupported: ["choose-supported-command", "narrow-scope"],
  "anchor-lost": ["reselect-target", "restart"],
  conflict: ["review-regenerate", "restart", "review-reject-all", "close"],
  abort: ["retry"]
}), qd = c({
  ...Js,
  "provider-adapter": ["retry", "contact-host", "restart"],
  "resource-limit": ["narrow-scope", "restart", "retry"]
}), Td = /* @__PURE__ */ new Set([
  "attemptCount",
  "blockCount",
  "byteCount",
  "limit",
  "retryAfterLogical"
]), Bd = /* @__PURE__ */ new Set([
  "abort-acknowledged",
  "admission-mismatch",
  "anchor-lost",
  "conflict",
  "disconnect",
  "editor-destroyed",
  "resource-limit",
  "target-drift",
  "timeout",
  "transport-disconnected",
  "transport-failed",
  "unknown-node",
  "unsupported"
]), Pd = /* @__PURE__ */ new Set([
  "attempts",
  "blocks",
  "events",
  "requests",
  "text-bytes",
  "tool-summaries"
]), jr = (e) => {
  if (!Cd.has(e.category) || !Qt(e.code) || !Qt(e.stage) || e.authorityRefs.length > 16 || !e.authorityRefs.every(X))
    return c({ status: "failure", code: "error-input-invalid" });
  const t = {};
  for (const [a, d] of Object.entries(e.safeDetails ?? {})) {
    const l = Td.has(a) && typeof d == "number" && Number.isSafeInteger(d) && d >= 0, g = a === "reasonCode" && typeof d == "string" && Bd.has(d), u = a === "resource" && typeof d == "string" && Pd.has(d);
    if (!l && !g && !u)
      return c({ status: "failure", code: "error-input-invalid" });
    t[a] = d;
  }
  const r = e.candidateActionIds ?? Js[e.category];
  if (!r.every((a) => Li.has(a)) || !e.availableActionIds.every((a) => Li.has(a)))
    return c({ status: "failure", code: "error-input-invalid" });
  const i = new Set(qd[e.category]), n = new Set(e.availableActionIds), s = r.filter(
    (a, d) => i.has(a) && n.has(a) && r.indexOf(a) === d
  ), o = {
    version: "1.0.0",
    category: e.category,
    code: e.code,
    stage: e.stage,
    authorityRefs: [...e.authorityRefs],
    messageKey: `ai.authoring.error.${e.category}.${e.code}`,
    allowedActionIds: s,
    safeDetails: t
  };
  return c({
    status: "success",
    error: {
      ...o,
      fingerprint: re(
        "zx-ai-authoring-error:v1",
        o
      )
    }
  });
}, $d = c({
  network: {
    category: "transport",
    code: "network",
    candidateActionIds: ["retry", "restart"]
  },
  "provider-unavailable": {
    category: "transport",
    code: "provider-unavailable",
    candidateActionIds: ["retry", "restart"]
  },
  "rate-limited": {
    category: "transport",
    code: "rate-limited",
    candidateActionIds: ["retry", "restart"]
  },
  "auth-failed": {
    category: "provider-adapter",
    code: "auth-failed",
    candidateActionIds: ["contact-host"]
  },
  "quota-exceeded": {
    category: "provider-adapter",
    code: "quota-exceeded",
    candidateActionIds: ["contact-host"]
  },
  "request-rejected": {
    category: "provider-adapter",
    code: "request-rejected",
    candidateActionIds: ["restart", "contact-host"]
  },
  "context-overflow": {
    category: "resource-limit",
    code: "context-overflow",
    candidateActionIds: ["narrow-scope", "restart"]
  },
  "output-truncated": {
    category: "resource-limit",
    code: "output-truncated",
    candidateActionIds: ["retry", "restart"]
  },
  "content-filtered": {
    category: "validation",
    code: "content-filtered",
    candidateActionIds: ["edit-prompt", "reselect-target"]
  },
  "empty-output": {
    category: "provider-adapter",
    code: "empty-output",
    candidateActionIds: ["retry", "restart"]
  },
  protocol: {
    category: "provider-adapter",
    code: "protocol",
    candidateActionIds: ["retry", "contact-host"]
  },
  internal: {
    category: "provider-adapter",
    code: "internal",
    candidateActionIds: ["restart", "contact-host"]
  }
}), jd = c({
  "transport-failed": { category: "transport", code: "transport-failed" },
  "transport-disconnected": {
    category: "transport",
    code: "transport-disconnected"
  },
  timeout: { category: "transport", code: "timeout" },
  "resource-exceeded": { category: "resource-limit", code: "resource-limit" },
  malformed: { category: "provider-adapter", code: "protocol" },
  "safety-abort": { category: "validation", code: "content-filtered" },
  "handoff-failure": { category: "provider-adapter", code: "handoff-failure" },
  "abort-unsupported": { category: "abort", code: "abort-unsupported" }
}), Yu = (e) => {
  var s;
  const { session: t } = e, r = (s = t.attempts.find(
    ({ attemptId: o }) => o === t.projection.attemptId
  )) == null ? void 0 : s.terminal;
  if (!r) return;
  const i = r.failureClass ? $d[r.failureClass] : jd[r.reason];
  if (!i) return;
  const n = jr({
    ...i,
    stage: e.stage,
    authorityRefs: [t.fingerprint, r.fingerprint],
    availableActionIds: e.availableActionIds
  });
  if (n.status !== "success")
    throw new TypeError("ai-authoring-terminal-error-invalid");
  return n.error;
}, Xu = (e) => typeof e == "string" && Li.has(e) ? e : null, Dd = (e) => {
  var s;
  let t = !1;
  try {
    const { session: o, effect: a, admission: d, descriptor: l } = e;
    t = U(e.editorBindingId) && a.kind === "transport-start" && a.sessionId === o.identity.sessionId && a.sourceRevision === o.revision && a.sourceFingerprint === o.fingerprint && a.requestId === d.requestId && a.requestProjection.inputFingerprint === d.requestInputFingerprint && a.requestProjection.kind === d.requestKind && a.requestProjection.policyFingerprint === d.policyFingerprint && a.transportAdmission.fingerprint === d.fingerprint && Ot(a.transportAdmission, d) && d.transportId === l.transportId && d.version === l.version && d.descriptorFingerprint === l.fingerprint && Ot(d.capabilities, l.capabilities);
  } catch {
    t = !1;
  }
  if (!t) {
    const o = (s = e == null ? void 0 : e.session) == null ? void 0 : s.fingerprint, a = X(o) ? o : re(
      "zx-ai-authoring-invalid-transport-map-input:v1",
      {
        editorBindingId: U(
          e == null ? void 0 : e.editorBindingId
        ) ? e.editorBindingId : "invalid-editor-binding"
      }
    ), d = jr({
      category: "validation",
      code: "transport-start-binding-invalid",
      stage: "transport-map",
      authorityRefs: [a],
      availableActionIds: ["retry", "restart", "contact-host"],
      candidateActionIds: ["contact-host"]
    });
    return d.status !== "success" ? c({
      status: "failure",
      error: {
        version: "1.0.0",
        category: "validation",
        code: "transport-start-binding-invalid",
        stage: "transport-map",
        authorityRefs: [a],
        messageKey: "ai.authoring.error.validation.transport-start-binding-invalid",
        allowedActionIds: [],
        safeDetails: {},
        fingerprint: re(
          "zx-ai-authoring-error:v1",
          {
            version: "1.0.0",
            category: "validation",
            code: "transport-start-binding-invalid",
            stage: "transport-map",
            authorityRefs: [a],
            messageKey: "ai.authoring.error.validation.transport-start-binding-invalid",
            allowedActionIds: [],
            safeDetails: {}
          }
        )
      }
    }) : c({ status: "failure", error: d.error });
  }
  const { session: r, effect: i, admission: n } = e;
  return c({
    status: "success",
    editorBindingId: e.editorBindingId,
    bindingFingerprint: re(
      "zx-ai-authoring-transport-start-binding:v1",
      {
        editorBindingId: e.editorBindingId,
        sessionFingerprint: r.fingerprint,
        effectId: i.effectId,
        admissionFingerprint: n.fingerprint
      }
    ),
    effect: {
      effectId: i.effectId,
      sessionId: i.sessionId,
      requestId: i.requestId,
      attemptId: i.attemptId,
      requestProjection: i.requestProjection,
      policyFingerprint: i.requestProjection.policyFingerprint,
      correlationRef: i.idempotencyKey,
      transportAdmission: n
    }
  });
}, Zu = () => {
  const e = /* @__PURE__ */ new Set(), t = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map(), i = (s, o, a) => {
    for (let d = 0; d < 3; d += 1) {
      const l = s.get(), g = Ni(l, {
        kind: "accept-event",
        sessionId: l.identity.sessionId,
        expectedRevision: l.revision,
        expectedSessionFingerprint: l.fingerprint,
        event: o
      });
      if (g.status === "idempotent")
        return { status: "idempotent", effects: [] };
      if (g.status !== "accepted") return { status: "failure" };
      if (s.compareAndSet(l.fingerprint, g.session))
        return a == null || a(g.session), { status: "accepted", effects: g.effects };
    }
    return { status: "failure" };
  }, n = (s, o) => {
    var a;
    if (!s.slot.installReview) return !1;
    for (let d = 0; d < 3; d += 1) {
      const l = s.slot.get(), g = Ni(l, {
        kind: "publish-handoff",
        sessionId: l.identity.sessionId,
        expectedRevision: l.revision,
        expectedSessionFingerprint: l.fingerprint,
        requestId: o.effect.requestId,
        attemptId: o.effect.attemptId,
        receipt: o.transfer.receipt
      });
      if (g.status !== "accepted" && g.status !== "idempotent")
        return !1;
      const u = g.status === "accepted" ? g.session : l;
      if (s.slot.installReview(l.fingerprint, u, o.transfer))
        return g.status === "accepted" && ((a = s.onAccepted) == null || a.call(s, u)), t.add(o.effect.effectId), !0;
    }
    return !1;
  };
  return {
    async run(s) {
      const o = r.get(s.effect.effectId);
      if (o) {
        if (!n(s, o)) {
          const g = jr({
            category: "conflict",
            code: "handoff-install-recovery-failed",
            stage: "handoff-install",
            authorityRefs: [
              s.slot.get().fingerprint,
              o.transfer.fingerprint
            ],
            availableActionIds: ["retry", "reveal", "close"]
          });
          return c({
            status: "failure",
            effectId: s.effect.effectId,
            acceptedEventCount: o.acceptedEventCount,
            ...o.lastEvent ? { lastEvent: o.lastEvent } : {},
            ...g.status === "success" ? { error: g.error } : {}
          });
        }
        return r.delete(s.effect.effectId), c({
          status: "completed",
          effectId: s.effect.effectId,
          acceptedEventCount: o.acceptedEventCount,
          ...o.lastEvent ? { lastEvent: o.lastEvent } : {}
        });
      }
      if (e.has(s.effect.effectId))
        return c({
          status: "already-started",
          effectId: s.effect.effectId,
          acceptedEventCount: 0
        });
      const a = Dd({
        editorBindingId: s.editorBindingId,
        session: s.slot.get(),
        effect: s.effect,
        admission: s.admission,
        descriptor: s.port.descriptor
      });
      if (a.status !== "success")
        return c({
          status: "failure",
          effectId: s.effect.effectId,
          acceptedEventCount: 0,
          error: a.error
        });
      e.add(s.effect.effectId);
      let d = 0, l;
      try {
        for await (const g of s.port.start(a.effect)) {
          l = g;
          const u = i(s.slot, g, s.onAccepted);
          if (u.status === "failure")
            throw new TypeError("ai-authoring-event-rejected");
          u.status === "accepted" && (d += 1);
          for (const p of u.effects) {
            if (p.kind !== "proposal-handoff" || !s.handoff || t.has(p.effectId))
              continue;
            const f = await s.handoff(p);
            if (f.status !== "awaiting-review")
              throw new TypeError("ai-authoring-handoff-failed");
            const m = Pt(f.transfer);
            if (m.status !== "success")
              throw new TypeError("ai-authoring-handoff-transfer-invalid");
            const y = {
              effect: p,
              transfer: m.transfer,
              acceptedEventCount: d,
              ...l ? { lastEvent: l } : {}
            };
            if (r.set(s.effect.effectId, y), !n(s, y))
              throw new TypeError("ai-authoring-publish-cas-failed");
            r.delete(s.effect.effectId);
          }
        }
        return c({
          status: "completed",
          effectId: s.effect.effectId,
          acceptedEventCount: d,
          ...l ? { lastEvent: l } : {}
        });
      } catch {
        const g = s.slot.get(), u = g.attempts.find(
          ({ attemptId: f }) => f === s.effect.attemptId
        );
        if (u && !u.terminal) {
          const f = en({
            sessionId: s.effect.sessionId,
            requestId: s.effect.requestId,
            attemptId: s.effect.attemptId,
            sequence: u.expectedSequence,
            ...u.lastEventFingerprint ? {
              previousEventFingerprint: u.lastEventFingerprint
            } : {},
            kind: "attempt-failed",
            payload: {
              kind: "attempt-failed",
              reason: "transport-failed",
              diagnosticCode: "session-transport-failure",
              failureClass: "internal"
            }
          });
          i(s.slot, f, s.onAccepted);
        }
        const p = jr({
          category: "transport",
          code: "effect-pump-failed",
          stage: "transport-pump",
          authorityRefs: [g.fingerprint],
          availableActionIds: ["retry", "restart"]
        });
        if (p.status !== "success")
          throw new TypeError("ai-authoring-pump-error-invalid");
        return c({
          status: "failure",
          effectId: s.effect.effectId,
          acceptedEventCount: d,
          ...l ? { lastEvent: l } : {},
          error: p.error
        });
      }
    }
  };
}, zd = () => Object.fromEntries(
  pi.map((e) => [e, !1])
), Od = (e, t) => e.handoffs.some(
  (r) => r.fingerprint === t.receipt.fingerprint && r.reviewId === t.sidecar.identity.reviewId && r.reviewFingerprint === t.initialSidecarFingerprint && r.proposalId === t.proposal.identity.proposalId && r.proposalFingerprint === t.proposal.fingerprint && r.lifecycleFingerprint === t.lifecycle.fingerprint
) && t.sidecar.proposalBinding.proposalFingerprint === t.proposal.fingerprint && t.sidecar.proposalBinding.lifecycleFingerprint === t.lifecycle.fingerprint, Nd = (e) => {
  var w;
  const t = zd();
  t.close = !0;
  const r = e.session, i = e.invocation !== void 0 && e.invocation.editorBindingId !== e.editorBindingId, n = e.reviewBundles.find(
    ({ sidecar: x }) => x.status === "active"
  ), s = e.reviewRefinement ?? void 0, o = !(r != null && r.activeRequestId) && n === void 0 && s === void 0 && e.reviewBundles.some(
    ({ sidecar: x }) => ["committed", "accepted-no-change", "rejected"].includes(x.status)
  ), a = e.targetFreshness !== void 0 && e.targetFreshness.status !== "fresh" && !o, d = r == null ? void 0 : r.requests.find(
    ({ requestId: x }) => x === r.activeRequestId
  ), l = r == null ? void 0 : r.attempts.find(
    ({ attemptId: x }) => x === (d == null ? void 0 : d.activeAttemptId)
  ), g = r && n ? Od(r, n) : !1, u = s !== void 0 && (s.status === "superseding-review" && (!n || !g || n.sidecar.identity.reviewId !== s.sourceReviewId) || s.status !== "superseding-review" && n !== void 0), p = (s == null ? void 0 : s.status) === "successor-start-failed" && (d == null ? void 0 : d.status) === "prepared" && d.activeAttemptId === void 0, f = s !== void 0 && s.status !== "starting-successor" && !!(r != null && r.activeRequestId) && !p, m = !(r != null && r.activeRequestId) && n === void 0, y = m && ((w = r == null ? void 0 : r.projection.capabilities) == null ? void 0 : w.canRetry) === !0;
  let I = "idle";
  if (i || a || n && !g || u || f)
    I = "conflict", t["reselect-target"] = !0, t.restart = m, t["review-reject-all"] = !!n, t.stop = !!l && !(l != null && l.terminal) && (r == null ? void 0 : r.projection.capabilities.canAbort) === !0;
  else if (e.error) {
    I = e.error.category === "conflict" || e.error.category === "anchor-lost" ? "conflict" : "error";
    for (const x of e.error.allowedActionIds) t[x] = !0;
    t.retry && (t.retry = y), t.restart && (t.restart = m);
  } else if (s)
    t.reveal = !e.adapterAttached || e.surfaceVisible === !1, s.status === "superseding-review" ? I = e.adapterAttached ? "awaiting-review" : "detached" : s.status === "starting-successor" ? I = e.adapterAttached ? "starting" : "detached" : (I = "error", t["retry-review-refine"] = !0);
  else if (n && g) {
    I = e.adapterAttached ? "awaiting-review" : "detached";
    const x = n.sidecar.capability === "fine-review", j = e.pendingActionId === "review-accept-all" || e.pendingActionId === "review-reject-all" || e.pendingActionId === "review-commit" || e.pendingActionId === "review-refine";
    t.reveal = !e.adapterAttached || e.surfaceVisible === !1, t["review-previous"] = x, t["review-next"] = x, t["review-decide"] = x, t["review-accept-all"] = x && !j, t["review-commit"] = x && !j && e.reviewResolutionStatus === "whole-accept-ready", t["review-reject-all"] = !j, t["review-regenerate"] = !0, t["review-refine"] = e.reviewRefineAvailable === !0 && !j;
  } else l ? l.status === "abort-requested" ? (I = e.adapterAttached ? "abort-requested" : "detached", t.reveal = !e.adapterAttached || e.surfaceVisible === !1) : l.status === "starting" || l.status === "created" ? (I = e.adapterAttached ? "starting" : "detached", t.stop = (r == null ? void 0 : r.projection.capabilities.canAbort) === !0, t.supersede = (r == null ? void 0 : r.projection.capabilities.canSupersede) === !0, t.reveal = !e.adapterAttached || e.surfaceVisible === !1) : l.status === "streaming" ? (I = e.adapterAttached ? "streaming" : "detached", t.stop = (r == null ? void 0 : r.projection.capabilities.canAbort) === !0, t.supersede = (r == null ? void 0 : r.projection.capabilities.canSupersede) === !0, t.reveal = !e.adapterAttached || e.surfaceVisible === !1) : l.status === "aborted" ? (I = "stopped", t.retry = y) : l.status === "failed" ? (I = "error", t.retry = y) : l.status === "succeeded" && (I = "completed") : (d == null ? void 0 : d.status) === "prepared" ? (I = "prepared", t.submit = !0) : r && !r.activeRequestId && e.reviewBundles.every(({ sidecar: x }) => x.status !== "active") ? (I = "completed", t.restart = r.requests.length > 0, t["follow-up"] = r.requests.length > 0) : (e.invocation || e.hasLocalDraft) && (I = "composing", t.submit = !!e.invocation, t["edit-prompt"] = !0);
  const h = r ? {
    sessionId: r.identity.sessionId,
    revision: r.revision,
    fingerprint: r.fingerprint,
    ...d ? { requestId: d.requestId } : {},
    ...l ? { attemptId: l.attemptId } : {}
  } : void 0, v = n ? {
    reviewId: n.sidecar.identity.reviewId,
    revision: n.sidecar.revision,
    fingerprint: n.sidecar.fingerprint
  } : void 0, F = {
    version: "1.0.0",
    editorBindingId: e.editorBindingId,
    state: I,
    ...h ? { sessionRef: h } : {},
    ...v ? { reviewRef: v } : {},
    ...s ? { reviewRefinement: s } : {},
    ...e.pendingActionId ? { pendingActionId: e.pendingActionId } : {},
    ...e.invocation ? { targetFingerprint: e.invocation.target.fingerprint } : {},
    previewSegments: (r == null ? void 0 : r.projection.assistantSegments) ?? [],
    previewTruncated: (r == null ? void 0 : r.projection.truncated) ?? !1,
    ...e.error ? { error: e.error } : {},
    actions: t
  };
  return c({
    ...F,
    fingerprint: re(
      "zx-ai-authoring-projection:v1",
      F
    )
  });
}, $n = /* @__PURE__ */ new Set([
  "prepared",
  "starting",
  "streaming",
  "abort-requested",
  "awaiting-review",
  "detached"
]), Ju = (e) => {
  let t, r, i, n = "", s = !1, o = !1, a;
  const d = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set([
    "review-accept-all",
    "review-reject-all",
    "review-refine",
    "review-commit"
  ]), g = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Set(), p = () => {
    var v;
    return o && t ? c({
      status: "anchor-lost",
      targetFingerprint: t.target.fingerprint,
      reasonCode: "editor-destroyed"
    }) : (v = e.getTargetFreshness) == null ? void 0 : v.call(e);
  }, f = () => {
    var _, G, ie;
    const v = e.getReviewBundles(), F = v.find(
      ({ sidecar: O }) => O.status === "active"
    ), w = ((_ = e.getReviewRefinement) == null ? void 0 : _.call(e)) ?? null, x = p(), j = (G = e.getError) == null ? void 0 : G.call(e);
    return Nd({
      editorBindingId: e.editorBindingId,
      session: e.getSession(),
      reviewBundles: v,
      ...w ? { reviewRefinement: w } : {},
      reviewRefineAvailable: F !== void 0 && ((ie = e.canReviewRefine) == null ? void 0 : ie.call(e, F)) === !0,
      ...a ? { pendingActionId: a } : {},
      ...t ? { invocation: t } : {},
      hasLocalDraft: n.length > 0,
      adapterAttached: g.size > 0,
      surfaceVisible: s,
      ...x ? { targetFreshness: x } : {},
      ...j ? { error: j } : {},
      ...F && e.getReviewResolutionStatus ? {
        reviewResolutionStatus: e.getReviewResolutionStatus(F)
      } : {}
    });
  }, m = () => {
    const v = f();
    return c({
      surfaceOpen: s,
      adapterAttached: g.size > 0,
      draftPrompt: n,
      ...r ? { surface: r.surface } : {},
      ...i ? { geometryKind: i.kind } : {},
      persistentIndicator: !s && ($n.has(v.state) || v.actions.reveal === !0),
      projection: v
    });
  }, y = () => {
    for (const v of [...u]) v();
  }, I = (v, F, w) => {
    const x = f(), j = jr({
      category: F === "fresh-projection-required" ? "conflict" : "validation",
      code: w,
      stage: "host-owner",
      authorityRefs: [x.fingerprint],
      availableActionIds: ["reveal", "close", "retry", "restart"]
    });
    return c({
      status: F,
      actionId: v,
      projection: x,
      ...j.status === "success" ? { error: j.error } : {}
    });
  }, h = async (v, F) => {
    const w = v === "close" || v === "reveal", x = v === "stop";
    if (d.has(v) || d.size > 0 && !w && !x || a !== void 0 && !w)
      return c({
        status: "busy",
        actionId: v,
        projection: f()
      });
    const j = f(), _ = j.sessionRef, G = j.reviewRef;
    if (F.editorBindingId !== e.editorBindingId || F.projectionFingerprint !== j.fingerprint || F.sessionId !== (_ == null ? void 0 : _.sessionId) || F.sessionRevision !== (_ == null ? void 0 : _.revision) || F.sessionFingerprint !== (_ == null ? void 0 : _.fingerprint) || F.requestId !== (_ == null ? void 0 : _.requestId) || F.attemptId !== (_ == null ? void 0 : _.attemptId) || F.reviewId !== (G == null ? void 0 : G.reviewId) || F.reviewRevision !== (G == null ? void 0 : G.revision) || F.reviewFingerprint !== (G == null ? void 0 : G.fingerprint))
      return I(
        v,
        "fresh-projection-required",
        "action-binding-stale"
      );
    if (!j.actions[v])
      return I(v, "unsupported", "action-not-available");
    if (v === "reveal")
      return s = !0, y(), c({
        status: "accepted",
        actionId: v,
        projection: f()
      });
    if (v === "close")
      return s = !1, j.state === "composing" && (n = ""), y(), c({
        status: "accepted",
        actionId: v,
        projection: f()
      });
    d.add(v), l.has(v) && (a = v, y());
    let ie;
    try {
      ie = await e.dispatchAction(v, F);
    } finally {
      d.delete(v), a === v && (a = void 0, y());
    }
    return c({
      status: ie.status,
      actionId: v,
      projection: f()
    });
  };
  return {
    getProjection: f,
    getPresentationSnapshot: m,
    subscribe(v) {
      return u.add(v), () => u.delete(v);
    },
    openInvocation(v) {
      const F = f();
      return $n.has(F.state) ? (s = !0, y(), m()) : (o || v.context.editorBindingId !== e.editorBindingId || v.context.target.editorBindingId !== e.editorBindingId || (t = v.context, r = c({ ...v.surface }), i = v.geometry ? c({ ...v.geometry }) : void 0, n = (v.draftPrompt ?? "").slice(0, 16384), s = !0, y()), m());
    },
    dispatch: h,
    submit: ({ binding: v }) => h("submit", v),
    stop: (v) => h("stop", v),
    retry: (v) => h("retry", v),
    restart: ({ binding: v }) => h("restart", v),
    supersede: ({ binding: v }) => h("supersede", v),
    followUp: ({ binding: v }) => h("follow-up", v),
    reviewRefine: ({ binding: v }) => h("review-refine", v),
    retryReviewRefine: (v) => h("retry-review-refine", v),
    dispatchReview: ({ actionId: v, binding: F }) => h(v, F),
    attachAdapter(v) {
      return !o && v.length > 0 && g.add(v), y(), m();
    },
    detachAdapter(v) {
      g.delete(v), s = !1, i = void 0, y();
    },
    async destroyEditor(v) {
      var w;
      if (v.editorBindingId !== e.editorBindingId) return;
      const F = f();
      o = !0, s = !1, i = void 0, g.clear(), F.sessionRef && ((w = e.getSession()) != null && w.activeRequestId) && await e.dispatchAction("stop", {
        editorBindingId: e.editorBindingId,
        projectionFingerprint: F.fingerprint,
        sessionId: F.sessionRef.sessionId,
        sessionRevision: F.sessionRef.revision,
        sessionFingerprint: F.sessionRef.fingerprint,
        requestId: F.sessionRef.requestId,
        attemptId: F.sessionRef.attemptId,
        ...F.reviewRef ? {
          reviewId: F.reviewRef.reviewId,
          reviewRevision: F.reviewRef.revision,
          reviewFingerprint: F.reviewRef.fingerprint
        } : {}
      }), y();
    }
  };
}, Kr = (e) => ({
  sessionId: e.identity.sessionId,
  expectedRevision: e.revision,
  expectedSessionFingerprint: e.fingerprint
}), xi = (e) => e.every(({ sidecar: t }) => t.status !== "active"), Qu = (e) => {
  const { session: t } = e;
  if (e.kind === "retry") {
    const r = t.requests.find(
      ({ requestId: n }) => n === e.requestId
    ), i = t.attempts.find(
      ({ attemptId: n }) => n === e.predecessorAttemptId
    );
    return !r || !(i != null && i.terminal) || i.requestId !== r.requestId || t.activeRequestId !== void 0 || !xi(e.reviewBundles) || !t.projection.capabilities.canRetry || e.transportAdmission.requestId !== r.requestId || e.transportAdmission.requestInputFingerprint !== r.inputFingerprint ? c({ status: "failure", code: "retry-ineligible" }) : c({
      status: "success",
      source: "original-input",
      sideEffect: "new-attempt",
      command: {
        ...Kr(t),
        kind: "retry",
        requestId: r.requestId,
        attemptId: e.attemptId,
        predecessorAttemptId: i.attemptId,
        transportAdmission: e.transportAdmission
      }
    });
  }
  return e.kind === "supersede" ? t.activeRequestId !== e.supersededRequestId || !xi(e.reviewBundles) || !t.projection.capabilities.canSupersede ? c({ status: "failure", code: "supersede-ineligible" }) : c({
    status: "success",
    source: "active-request",
    sideEffect: "supersede-active-request",
    command: {
      ...Kr(t),
      kind: "supersede",
      requestId: e.requestId,
      input: e.input,
      logicalCreatedAt: e.logicalCreatedAt,
      supersededRequestId: e.supersededRequestId
    }
  }) : t.activeRequestId || !xi(e.reviewBundles) ? c({
    status: "failure",
    code: e.kind === "restart" ? "restart-ineligible" : "follow-up-ineligible"
  }) : e.kind === "restart" ? t.requests.some(
    ({ requestId: r }) => r === e.restartedFromRequestId
  ) ? c({
    status: "success",
    source: "latest-document",
    sideEffect: "new-request",
    command: {
      ...Kr(t),
      kind: "restart",
      requestId: e.requestId,
      input: e.input,
      logicalCreatedAt: e.logicalCreatedAt,
      restartedFromRequestId: e.restartedFromRequestId
    }
  }) : c({ status: "failure", code: "restart-ineligible" }) : !/^sha256:[a-f0-9]{64}$/i.test(e.predecessorResultDigest) || e.input.kind !== "follow-up" ? c({ status: "failure", code: "follow-up-ineligible" }) : c({
    status: "success",
    source: "previous-result",
    sideEffect: "new-request",
    command: {
      ...Kr(t),
      kind: "create-request",
      requestId: e.requestId,
      input: e.input,
      logicalCreatedAt: e.logicalCreatedAt
    }
  });
}, _d = (e) => e.kind === "document" ? "Document · all operable blocks" : e.kind === "blocks" ? `Blocks · ${e.blockIds.length} · ${e.blockIds.join(", ")}` : `${e.collapsed ? "Cursor" : "Selection"} · ${e.blockIds.length} · ${e.start.blockId}:${e.start.offset} → ${e.end.blockId}:${e.end.offset}`, Ld = (e) => {
  const { source: t, target: r } = e;
  if (t.editorBindingId !== r.editorBindingId) return !0;
  if (t.kind === "document") return !1;
  if (r.kind === "document") return !0;
  if (t.kind === "selection" && r.kind === "blocks")
    return r.blockIds.some((i) => !t.blockIds.includes(i));
  if (t.kind === "blocks" && r.kind === "selection") return !1;
  if (t.kind === "blocks" && r.kind === "blocks")
    return r.blockIds.some((i) => !t.blockIds.includes(i));
  if (t.kind === "selection" && r.kind === "selection") {
    const i = r.blockIds.some(
      (g) => !t.blockIds.includes(g)
    ), n = t.blockIds.indexOf(r.start.blockId), s = t.blockIds.indexOf(r.end.blockId), o = t.blockIds.indexOf(t.start.blockId), a = t.blockIds.indexOf(t.end.blockId), d = n >= 0 && (n < o || n === o && r.start.offset < t.start.offset), l = s >= 0 && (s > a || s === a && r.end.offset > t.end.offset);
    return i || n < 0 || s < 0 || d || l;
  }
  return !1;
}, Vd = (e) => e, Qs = (e) => {
  if (!e || typeof e != "object" || !Object.hasOwn(e, "kind") || !Object.hasOwn(e, "fingerprint"))
    return c({
      status: "failure",
      code: "target-artifact-invalid"
    });
  const t = e, r = U(t.editorBindingId) && X(t.semanticSnapshotFingerprint) && X(t.baseDocumentFingerprint) && X(t.fingerprint);
  let i;
  if (t.kind === "selection" && Y(t, [
    "kind",
    "editorBindingId",
    "semanticSnapshotFingerprint",
    "baseDocumentFingerprint",
    "start",
    "end",
    "collapsed",
    "blockIds",
    "fingerprint"
  ]) && r && Y(t.start, ["blockId", "offset"]) && Y(t.end, ["blockId", "offset"]) && U(t.start.blockId) && U(t.end.blockId) && Number.isSafeInteger(t.start.offset) && t.start.offset >= 0 && Number.isSafeInteger(t.end.offset) && t.end.offset >= 0 && typeof t.collapsed == "boolean" && Array.isArray(t.blockIds) && t.blockIds.length > 0 && t.blockIds.every(U) && new Set(t.blockIds).size === t.blockIds.length && t.start.blockId === t.blockIds[0] && t.end.blockId === t.blockIds[t.blockIds.length - 1] && (!t.collapsed || t.start.blockId === t.end.blockId && t.start.offset === t.end.offset))
    i = {
      kind: "selection",
      editorBindingId: t.editorBindingId,
      semanticSnapshotFingerprint: t.semanticSnapshotFingerprint,
      baseDocumentFingerprint: t.baseDocumentFingerprint,
      start: {
        blockId: t.start.blockId,
        offset: t.start.offset
      },
      end: {
        blockId: t.end.blockId,
        offset: t.end.offset
      },
      collapsed: t.collapsed,
      blockIds: t.blockIds
    };
  else if (t.kind === "blocks" && Y(t, [
    "kind",
    "editorBindingId",
    "semanticSnapshotFingerprint",
    "baseDocumentFingerprint",
    "blockIds",
    "fingerprint"
  ]) && r && Array.isArray(t.blockIds) && t.blockIds.length > 0 && t.blockIds.every(U) && new Set(t.blockIds).size === t.blockIds.length)
    i = {
      kind: "blocks",
      editorBindingId: t.editorBindingId,
      semanticSnapshotFingerprint: t.semanticSnapshotFingerprint,
      baseDocumentFingerprint: t.baseDocumentFingerprint,
      blockIds: t.blockIds
    };
  else if (t.kind === "document" && Y(t, [
    "kind",
    "editorBindingId",
    "semanticSnapshotFingerprint",
    "baseDocumentFingerprint",
    "documentTargetFingerprint",
    "fingerprint"
  ]) && r && X(t.documentTargetFingerprint))
    i = {
      kind: "document",
      editorBindingId: t.editorBindingId,
      semanticSnapshotFingerprint: t.semanticSnapshotFingerprint,
      baseDocumentFingerprint: t.baseDocumentFingerprint,
      documentTargetFingerprint: t.documentTargetFingerprint
    };
  else
    return c({
      status: "failure",
      code: "target-artifact-invalid"
    });
  const n = re(
    "zx-ai-authoring-target-binding:v1",
    i
  );
  return t.fingerprint !== n ? c({
    status: "failure",
    code: "target-artifact-invalid"
  }) : c({
    status: "success",
    target: Ve({
      ...i,
      fingerprint: n
    })
  });
}, ef = (e) => {
  if (!Y(
    e,
    [
      "editorBindingId",
      "productScope",
      "semanticSnapshot",
      "baseDocumentFingerprint"
    ],
    ["blockIds", "documentTargetFingerprint"]
  ) || !U(e.editorBindingId) || !["cursor", "selection", "block", "document"].includes(
    String(e.productScope)
  ) || !X(e.semanticSnapshot.fingerprint) || !X(e.baseDocumentFingerprint))
    return c({ status: "failure", code: "target-input-invalid" });
  let t;
  if (e.productScope === "cursor" || e.productScope === "selection") {
    const r = e.semanticSnapshot.selection;
    if (!r || r.collapsed !== (e.productScope === "cursor") || r.blockIds.length === 0 || !r.blockIds.every(U))
      return c({
        status: "failure",
        code: e.productScope === "cursor" ? "cursor-binding-invalid" : "selection-binding-invalid"
      });
    if (t = {
      kind: "selection",
      editorBindingId: e.editorBindingId,
      semanticSnapshotFingerprint: e.semanticSnapshot.fingerprint,
      baseDocumentFingerprint: e.baseDocumentFingerprint,
      start: {
        blockId: r.start.blockId,
        offset: r.start.offset
      },
      end: {
        blockId: r.end.blockId,
        offset: r.end.offset
      },
      collapsed: r.collapsed,
      blockIds: [...r.blockIds]
    }, t.start.blockId !== t.blockIds[0] || t.end.blockId !== t.blockIds[t.blockIds.length - 1] || t.collapsed && (t.start.blockId !== t.end.blockId || t.start.offset !== t.end.offset))
      return c({
        status: "failure",
        code: "selection-binding-invalid"
      });
  } else if (e.productScope === "block") {
    if (!Array.isArray(e.blockIds) || e.blockIds.length === 0 || !e.blockIds.every(U) || new Set(e.blockIds).size !== e.blockIds.length)
      return c({ status: "failure", code: "block-binding-invalid" });
    const r = new Set(e.blockIds), i = e.semanticSnapshot.operableBlockIds.filter(
      (n) => r.has(n)
    );
    if (i.length !== e.blockIds.length || i.some((n, s) => {
      var o;
      return n !== ((o = e.blockIds) == null ? void 0 : o[s]);
    }))
      return c({
        status: "failure",
        code: "block-order-noncanonical"
      });
    t = {
      kind: "blocks",
      editorBindingId: e.editorBindingId,
      semanticSnapshotFingerprint: e.semanticSnapshot.fingerprint,
      baseDocumentFingerprint: e.baseDocumentFingerprint,
      blockIds: i
    };
  } else {
    if (!X(e.documentTargetFingerprint))
      return c({
        status: "failure",
        code: "document-target-invalid"
      });
    t = {
      kind: "document",
      editorBindingId: e.editorBindingId,
      semanticSnapshotFingerprint: e.semanticSnapshot.fingerprint,
      baseDocumentFingerprint: e.baseDocumentFingerprint,
      documentTargetFingerprint: e.documentTargetFingerprint
    };
  }
  try {
    const r = Ve(Vd(t)), i = c({
      status: "success",
      target: {
        ...r,
        fingerprint: re(
          "zx-ai-authoring-target-binding:v1",
          r
        )
      }
    });
    return Qs(i.target);
  } catch {
    return c({ status: "failure", code: "target-input-invalid" });
  }
}, Hd = (e) => {
  const t = Qs(e.target);
  if (!Y(e, [
    "editorBindingId",
    "productScope",
    "target",
    "semanticSnapshotRef",
    "scopeRef",
    "baseDocumentRef",
    "locale",
    "capabilityReceipts"
  ]) || t.status !== "success" || e.editorBindingId !== e.target.editorBindingId || !ht(e.locale, 64) || !/^[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(e.locale) || e.semanticSnapshotRef.kind !== "semantic-snapshot" || e.scopeRef.kind !== "scope" || e.baseDocumentRef.kind !== "base-document" || !Y(
    e.semanticSnapshotRef,
    ["kind", "fingerprint"],
    ["revision"]
  ) || !Y(
    e.scopeRef,
    ["kind", "fingerprint"],
    ["revision"]
  ) || !Y(
    e.baseDocumentRef,
    ["kind", "fingerprint"],
    ["revision"]
  ) || !X(e.semanticSnapshotRef.fingerprint) || !X(e.scopeRef.fingerprint) || !X(e.baseDocumentRef.fingerprint) || e.semanticSnapshotRef.fingerprint !== e.target.semanticSnapshotFingerprint || e.baseDocumentRef.fingerprint !== e.target.baseDocumentFingerprint || !Array.isArray(e.capabilityReceipts) || !e.capabilityReceipts.every(Kd))
    return c({ status: "failure", code: "context-binding-invalid" });
  try {
    const r = Ve({
      version: "1.0.0",
      editorBindingId: e.editorBindingId,
      productScope: e.productScope,
      target: e.target,
      semanticSnapshotRef: e.semanticSnapshotRef,
      scopeRef: e.scopeRef,
      baseDocumentRef: e.baseDocumentRef,
      locale: e.locale,
      capabilityReceipts: e.capabilityReceipts
    });
    return c({
      status: "success",
      context: {
        ...r,
        fingerprint: re(
          "zx-ai-authoring-invocation-context:v1",
          r
        )
      }
    });
  } catch {
    return c({ status: "failure", code: "context-binding-invalid" });
  }
}, Kd = (e) => e.kind === "semantic-capability" ? Y(e, [
  "kind",
  "capabilityId",
  "status",
  "sourceFingerprint",
  "fingerprint"
]) && U(e.capabilityId) && e.status === "supported" && X(e.sourceFingerprint) && e.fingerprint === re(
  "zx-ai-authoring-semantic-capability-receipt:v1",
  {
    kind: e.kind,
    capabilityId: e.capabilityId,
    status: e.status,
    sourceFingerprint: e.sourceFingerprint
  }
) : e.kind === "runtime-review-prerequisite" ? Y(e, [
  "kind",
  "status",
  "runtimeManifestFingerprint",
  "reviewPolicyFingerprint",
  "fingerprint"
]) && e.status === "supported" && X(e.runtimeManifestFingerprint) && X(e.reviewPolicyFingerprint) && e.fingerprint === re(
  "zx-ai-authoring-runtime-review-prerequisite-receipt:v1",
  {
    kind: e.kind,
    status: e.status,
    runtimeManifestFingerprint: e.runtimeManifestFingerprint,
    reviewPolicyFingerprint: e.reviewPolicyFingerprint
  }
) : Y(e, ["kind", "receipt", "fingerprint"]) && X(e.receipt.fingerprint) && e.fingerprint === re(
  "zx-ai-authoring-transport-capability-receipt:v1",
  { receiptFingerprint: e.receipt.fingerprint }
), tf = (e) => {
  if (e.kind === "semantic-capability") {
    const t = Ve(e);
    return c({
      ...t,
      fingerprint: re(
        "zx-ai-authoring-semantic-capability-receipt:v1",
        t
      )
    });
  }
  if (e.kind === "runtime-review-prerequisite") {
    const t = Ve(e);
    return c({
      ...t,
      fingerprint: re(
        "zx-ai-authoring-runtime-review-prerequisite-receipt:v1",
        t
      )
    });
  }
  return c({
    kind: "transport-capability",
    receipt: Ve(e.receipt),
    fingerprint: re(
      "zx-ai-authoring-transport-capability-receipt:v1",
      { receiptFingerprint: e.receipt.fingerprint }
    )
  });
}, rf = (e) => {
  const t = (r, i) => c({
    status: r,
    targetFingerprint: e.target.fingerprint,
    reasonCode: i
  });
  if (e.editorBindingId !== e.target.editorBindingId)
    return t("conflict", "editor-binding-mismatch");
  if (e.currentBaseDocumentFingerprint !== e.target.baseDocumentFingerprint)
    return t("drift", "base-document-drift");
  if (e.target.kind === "selection") {
    const r = e.currentSnapshot.selection;
    if (!r || r.start.blockId !== e.target.start.blockId || r.start.offset !== e.target.start.offset || r.end.blockId !== e.target.end.blockId || r.end.offset !== e.target.end.offset || r.collapsed !== e.target.collapsed || r.blockIds.join("\0") !== e.target.blockIds.join("\0"))
      return t("anchor-lost", "selection-anchor-lost");
  } else if (e.target.kind === "blocks") {
    const r = e.target;
    if (e.currentSnapshot.operableBlockIds.filter(
      (n) => r.blockIds.includes(n)
    ).join("\0") !== r.blockIds.join("\0"))
      return t("anchor-lost", "stable-block-lost-or-reordered");
  } else if (e.currentDocumentTargetFingerprint !== e.target.documentTargetFingerprint)
    return t("conflict", "document-target-drift");
  return c({
    status: "fresh",
    targetFingerprint: e.target.fingerprint,
    geometryStatus: e.geometryAvailable ? "available" : "lost"
  });
}, Ze = (e, t, r, i) => c({
  checkId: e,
  status: t,
  ...i ? { receiptFingerprint: i } : {},
  ...r ? { reasonCode: r } : {}
}), nf = (e) => {
  const t = e.context.target, r = e.context.productScope === "cursor" && t.kind === "selection" && t.collapsed || e.context.productScope === "selection" && t.kind === "selection" && !t.collapsed || e.context.productScope === "block" && t.kind === "blocks" || e.context.productScope === "document" && t.kind === "document", i = e.snapshot.diagnostics.some(
    ({ code: m }) => m === "unknown-document-node" || m === "unknown-document-mark"
  ), n = e.sourceTarget ? Ld({
    source: e.sourceTarget,
    target: t
  }) : !1, s = n && e.command.scopePolicyId === "exact-target", o = n && e.command.scopePolicyId === "allow-expansion-with-confirmation", a = e.context.capabilityReceipts.find(
    (m) => m.kind === "transport-capability"
  ), d = e.snapshot.fingerprint === e.context.semanticSnapshotRef.fingerprint && e.snapshot.fingerprint === t.semanticSnapshotFingerprint && e.context.baseDocumentRef.fingerprint === t.baseDocumentFingerprint && (e.context.semanticSnapshotRef.revision === void 0 || e.context.semanticSnapshotRef.revision === e.snapshot.documentRevision) && (e.context.baseDocumentRef.revision === void 0 || e.context.baseDocumentRef.revision === e.snapshot.documentRevision), l = [
    Ze(
      "context-binding",
      e.context.editorBindingId === e.editorBindingId && t.editorBindingId === e.editorBindingId ? "passed" : "failed",
      "editor-binding-mismatch"
    ),
    Ze(
      "product-scope-invariant",
      r ? "passed" : "failed",
      "scope-target-mismatch"
    ),
    Ze(
      "command-capability",
      e.availability.commandId === e.command.commandId && e.availability.status === "enabled" ? "passed" : "unsupported",
      e.availability.commandId !== e.command.commandId ? "command-availability-mismatch" : e.availability.status === "disabled" ? e.availability.reasonCode : void 0
    ),
    Ze(
      "snapshot-reference-binding",
      d ? "passed" : "failed",
      "snapshot-reference-mismatch"
    ),
    Ze(
      "semantic-node-capability",
      i ? "unsupported" : "passed",
      "unknown-node-or-mark"
    ),
    Ze(
      "target-freshness",
      e.targetFreshness.targetFingerprint === t.fingerprint && e.targetFreshness.status === "fresh" ? "passed" : "failed",
      e.targetFreshness.targetFingerprint !== t.fingerprint ? "target-freshness-mismatch" : e.targetFreshness.status === "fresh" ? void 0 : e.targetFreshness.reasonCode
    ),
    Ze(
      "resource-limits",
      e.resourceStatus === "within-limits" ? "passed" : "failed",
      "resource-limit"
    ),
    Ze(
      "transport-capability",
      e.transportStatus === "supported" ? "passed" : "unsupported",
      "transport-unsupported",
      a == null ? void 0 : a.fingerprint
    ),
    Ze(
      "runtime-review-prerequisite",
      e.runtimeReviewStatus === "supported" && e.context.capabilityReceipts.some(
        (m) => m.kind === "runtime-review-prerequisite"
      ) ? "passed" : "unsupported",
      "runtime-review-unsupported"
    ),
    Ze(
      "scope-expansion-confirmation",
      s ? "unsupported" : !o || e.scopeExpansionConfirmed ? "passed" : "failed",
      s ? "scope-expansion-unsupported" : "scope-expansion-confirmation-required"
    ),
    Ze(
      "open-authoring-task",
      e.openAuthoringTask ? "failed" : "passed",
      "authoring-task-open"
    )
  ], g = t.kind === "document" ? e.snapshot.operableBlockIds.length : t.blockIds.length, u = {
    version: "1.0.0",
    commandId: e.command.commandId,
    contextFingerprint: e.context.fingerprint,
    targetFingerprint: t.fingerprint,
    scopeSummary: {
      productScope: e.context.productScope,
      blockCount: g,
      impactKey: `ai.authoring.impact.${e.context.productScope}`,
      targetSummary: _d(t),
      expansionRequiresConfirmation: o
    },
    checks: l,
    ...a ? { transportAdmissionFingerprint: a.fingerprint } : {}
  }, p = c({
    ...u,
    fingerprint: re(
      "zx-ai-authoring-preflight-receipt:v1",
      u
    )
  }), f = l.find(({ status: m }) => m !== "passed");
  return f ? c({
    status: "rejected",
    receipt: p,
    reasonCode: f.reasonCode ?? "preflight-rejected"
  }) : c({ status: "accepted", receipt: p });
}, sf = (e) => e.preflight.contextFingerprint !== e.context.fingerprint || e.preflight.targetFingerprint !== e.context.target.fingerprint || e.intent.preflightFingerprint !== e.preflight.fingerprint || e.intent.targetFingerprint !== e.context.target.fingerprint || !e.preflight.checks.every(({ status: t }) => t === "passed") || !X(e.intent.fingerprint) ? c({
  status: "failure",
  code: "request-input-binding-invalid"
}) : c({
  status: "success",
  requestInput: {
    kind: e.intent.requestKind,
    semanticSnapshotRef: e.context.semanticSnapshotRef,
    scopeRef: e.context.scopeRef,
    baseDocumentRef: e.context.baseDocumentRef,
    intentRef: {
      kind: "intent",
      fingerprint: e.intent.fingerprint
    }
  }
}), of = c([
  {
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    equivalentCommit: "4e9e785530ff4c173f876fcac09cf334fe61b5dc",
    evidence: "source-and-tests",
    paths: [
      "packages/xl-ai/src/AIExtension.ts",
      "packages/xl-ai/src/components/AIMenu/AIMenuController.tsx",
      "packages/xl-ai/src/components/PromptSuggestionMenu/PromptSuggestionMenu.tsx",
      "packages/xl-ai/src/components/AIMenu/getDefaultAIMenuItems.tsx",
      "tests/src/end-to-end/ai/ai-selection.test.tsx",
      "tests/src/end-to-end/ai/ai.test.tsx"
    ],
    pathDecisions: [
      {
        path: "packages/xl-ai/src/AIExtension.ts",
        decision: "reject",
        boundary: "Chat/plugin lifecycle cannot own S5 or S4 authority.",
        fixtureIds: ["AUTH-01"]
      },
      {
        path: "packages/xl-ai/src/AIExtension.ts",
        decision: "adapt",
        boundary: "Visible composing, streaming, review and Stop affordances are projected from S5/S4.",
        fixtureIds: ["BN-04"]
      },
      {
        path: "packages/xl-ai/src/components/AIMenu/AIMenuController.tsx",
        decision: "adapt",
        boundary: "Menu lifecycle becomes a per-editor ZXUI host owner.",
        fixtureIds: ["BN-03", "CLOSE-01"]
      },
      {
        path: "packages/xl-ai/src/components/AIMenu/AIMenuController.tsx",
        decision: "reject",
        boundary: "Close never implies reject, abort or canonical mutation.",
        fixtureIds: ["CLOSE-01"]
      },
      {
        path: "packages/xl-ai/src/components/PromptSuggestionMenu/PromptSuggestionMenu.tsx",
        decision: "adapt",
        boundary: "Suggestions become closed registry command IDs.",
        fixtureIds: ["BN-04", "A11Y-01"]
      },
      {
        path: "packages/xl-ai/src/components/AIMenu/getDefaultAIMenuItems.tsx",
        decision: "adapt",
        boundary: "Command grouping is data-only and mutation-free.",
        fixtureIds: ["BN-04"]
      },
      {
        path: "packages/xl-ai/src/components/AIMenu/getDefaultAIMenuItems.tsx",
        decision: "reject",
        boundary: "Live callbacks cannot enter registry descriptors.",
        fixtureIds: ["LINEAGE-01"]
      },
      {
        path: "tests/src/end-to-end/ai/ai-selection.test.tsx",
        decision: "copy",
        boundary: "Selection retention is rebuilt with canonical targets.",
        fixtureIds: ["BN-01"]
      },
      {
        path: "tests/src/end-to-end/ai/ai.test.tsx",
        decision: "copy",
        boundary: "Open/focus/no-scroll behavior is rebuilt in Vue.",
        fixtureIds: ["BN-02"]
      }
    ],
    decisions: [
      {
        decision: "copy",
        boundary: "selection retention and open/focus/no-scroll are rebuilt through ZXUI public target and Vue fixtures",
        fixtureIds: ["BN-01", "BN-02"]
      },
      {
        decision: "adapt",
        boundary: "IME, focus, geometry and action grouping become presentation-only closed-ID behavior",
        fixtureIds: ["BN-03", "BN-04", "A11Y-01", "CLOSE-01"]
      },
      {
        decision: "reject",
        boundary: "chat/plugin lifecycle and direct ProseMirror mutation never enter S6 authority",
        fixtureIds: ["AUTH-01"]
      }
    ]
  },
  {
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    evidence: "source-and-tests",
    paths: [
      "apps/www/src/registry/ui/ai-menu.tsx",
      "apps/www/src/registry/ui/ai-menu.spec.tsx",
      "packages/ai/src/react/ai-chat/AIChatPlugin.ts",
      "packages/ai/src/react/ai-chat/AIChatPlugin.spec.ts",
      "packages/ai/src/react/ai-chat/hooks/useEditorChat.ts",
      "packages/ai/src/react/ai-chat/hooks/useChatChunk.ts",
      "packages/ai/src/lib/transforms/aiStreamSnapshot.ts",
      "packages/ai/src/lib/transforms/aiStreamSnapshot.spec.ts"
    ],
    pathDecisions: [
      {
        path: "apps/www/src/registry/ui/ai-menu.tsx",
        decision: "adapt",
        boundary: "Entry routing consumes one S5-derived projection.",
        fixtureIds: ["PL-01"]
      },
      {
        path: "apps/www/src/registry/ui/ai-menu.tsx",
        decision: "reject",
        boundary: "Direct editor callbacks and Escape-as-Stop are excluded from authority.",
        fixtureIds: ["PL-03", "CLOSE-01"]
      },
      {
        path: "apps/www/src/registry/ui/ai-menu.spec.tsx",
        decision: "copy",
        boundary: "Focus and missing-geometry expectations are retained.",
        fixtureIds: ["PL-02", "PL-05"]
      },
      {
        path: "packages/ai/src/react/ai-chat/AIChatPlugin.ts",
        decision: "reject",
        boundary: "React chat state cannot become package authority.",
        fixtureIds: ["AUTH-01"]
      },
      {
        path: "packages/ai/src/react/ai-chat/AIChatPlugin.spec.ts",
        decision: "adapt",
        boundary: "Observable behavior is rebuilt through public APIs.",
        fixtureIds: ["PL-03"]
      },
      {
        path: "packages/ai/src/react/ai-chat/AIChatPlugin.spec.ts",
        decision: "reject",
        boundary: "Local Stop flags are not accepted as S5 authority.",
        fixtureIds: ["PL-04", "ABORT-01"]
      },
      {
        path: "packages/ai/src/react/ai-chat/hooks/useEditorChat.ts",
        decision: "reject",
        boundary: "Live callback and editor mutation ownership are forbidden.",
        fixtureIds: ["AUTH-01"]
      },
      {
        path: "packages/ai/src/react/ai-chat/hooks/useEditorChat.ts",
        decision: "adapt",
        boundary: "Selection, cursor and block precedence becomes a canonical target.",
        fixtureIds: ["PL-01", "TARGET-01"]
      },
      {
        path: "packages/ai/src/react/ai-chat/hooks/useChatChunk.ts",
        decision: "reject",
        boundary: "Cumulative duplicate streams are forbidden.",
        fixtureIds: ["STREAM-01"]
      },
      {
        path: "packages/ai/src/lib/transforms/aiStreamSnapshot.ts",
        decision: "reject",
        boundary: "Partial stream preview cannot mutate the live editor.",
        fixtureIds: ["AUTH-01", "STREAM-01"]
      },
      {
        path: "packages/ai/src/lib/transforms/aiStreamSnapshot.ts",
        decision: "copy",
        boundary: "Selection restoration and single-undo outcomes are rebuilt at S4/Runtime v2.",
        fixtureIds: ["PL-05", "UNDO-01"]
      },
      {
        path: "packages/ai/src/lib/transforms/aiStreamSnapshot.spec.ts",
        decision: "copy",
        boundary: "Single-undo expectations are retained at Runtime v2.",
        fixtureIds: ["UNDO-01"]
      }
    ],
    decisions: [
      {
        decision: "copy",
        boundary: "missing geometry, focus restore and single-undo expectations become public ZXUI fixtures",
        fixtureIds: ["PL-02", "PL-05", "ANCHOR-01", "UNDO-01"]
      },
      {
        decision: "adapt",
        boundary: "entry routing and requesting-stop feedback map to canonical targets and S5 projection",
        fixtureIds: ["PL-01", "PL-03", "PL-04", "ABORT-01"]
      },
      {
        decision: "reject",
        boundary: "React chat state, cumulative duplicate streams and direct editor writes are forbidden",
        fixtureIds: ["AUTH-01", "STREAM-01"]
      }
    ]
  },
  {
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    evidence: "source-only",
    paths: [
      "apps/web/components/tailwind/advanced-editor.tsx",
      "apps/web/components/tailwind/generative/generative-menu-switch.tsx",
      "apps/web/components/tailwind/generative/ai-selector.tsx",
      "apps/web/components/tailwind/generative/ai-selector-commands.tsx",
      "apps/web/components/tailwind/generative/ai-completion-command.tsx",
      "packages/headless/src/extensions/slash-command.tsx",
      "packages/headless/src/extensions/editor-command.tsx",
      "packages/headless/src/extensions/ai-highlight.tsx",
      "apps/web/app/api/generate/route.ts"
    ],
    pathDecisions: [
      {
        path: "apps/web/components/tailwind/advanced-editor.tsx",
        decision: "adapt",
        boundary: "Real-page composition is rebuilt in the ZXUI Workbench.",
        fixtureIds: ["NV-01", "WORKBENCH-01"]
      },
      {
        path: "apps/web/components/tailwind/generative/generative-menu-switch.tsx",
        decision: "adapt",
        boundary: "Mode switching becomes closed registry selection.",
        fixtureIds: ["NV-02"]
      },
      {
        path: "apps/web/components/tailwind/generative/generative-menu-switch.tsx",
        decision: "reject",
        boundary: "Direct highlight and close mutation are forbidden.",
        fixtureIds: ["AUTH-01", "CLOSE-01"]
      },
      {
        path: "apps/web/components/tailwind/generative/ai-selector.tsx",
        decision: "adapt",
        boundary: "Selector behavior becomes an accessible combobox.",
        fixtureIds: ["NV-02", "A11Y-01"]
      },
      {
        path: "apps/web/components/tailwind/generative/ai-selector.tsx",
        decision: "reject",
        boundary: "Provider hooks cannot own transport or projection truth.",
        fixtureIds: ["STREAM-01", "PORT-01"]
      },
      {
        path: "apps/web/components/tailwind/generative/ai-selector-commands.tsx",
        decision: "adapt",
        boundary: "Command taxonomy becomes pure descriptor data.",
        fixtureIds: ["NV-02"]
      },
      {
        path: "apps/web/components/tailwind/generative/ai-selector-commands.tsx",
        decision: "reject",
        boundary: "Command descriptors cannot read a live editor.",
        fixtureIds: ["REGISTRY-01", "AUTH-01"]
      },
      {
        path: "apps/web/components/tailwind/generative/ai-completion-command.tsx",
        decision: "reject",
        boundary: "Direct editor completion mutations are forbidden.",
        fixtureIds: ["NV-03", "AUTH-01"]
      },
      {
        path: "packages/headless/src/extensions/slash-command.tsx",
        decision: "adapt",
        boundary: "Slash is presentation provenance, not request identity.",
        fixtureIds: ["NV-01"]
      },
      {
        path: "packages/headless/src/extensions/editor-command.tsx",
        decision: "reject",
        boundary: "Global DOM command routing is forbidden.",
        fixtureIds: ["ISOLATION-01"]
      },
      {
        path: "packages/headless/src/extensions/ai-highlight.tsx",
        decision: "adapt",
        boundary: "Highlight is disposable presentation geometry only.",
        fixtureIds: ["ANCHOR-01"]
      },
      {
        path: "apps/web/app/api/generate/route.ts",
        decision: "reject",
        boundary: "Provider SDK, prompt parsing and secrets stay host-side.",
        fixtureIds: ["SECRET-01"]
      },
      {
        path: "apps/web/app/api/generate/route.ts",
        decision: "adapt",
        boundary: "Only a credentialless provider-neutral host endpoint boundary is retained.",
        fixtureIds: ["PORT-01"]
      }
    ],
    decisions: [
      {
        decision: "adapt",
        boundary: "real-page composition, command taxonomy and follow-up flow use one registry, S5 projection and injected port",
        fixtureIds: ["NV-01", "NV-02", "WORKBENCH-01"]
      },
      {
        decision: "reject",
        boundary: "provider hooks, global DOM, direct Tiptap mutation and browser secrets remain outside package core",
        fixtureIds: ["NV-03", "SECRET-01", "ISOLATION-01"]
      },
      {
        decision: "reject",
        boundary: "the fixed tree has no test/spec path or test script and is never claimed as upstream test evidence",
        fixtureIds: ["NV-04"]
      }
    ]
  }
]), af = c([
  {
    id: "APG-combobox",
    url: "https://www.w3.org/WAI/ARIA/apg/patterns/combobox/",
    fixtureIds: ["A11Y-01", "A11Y-02"]
  },
  {
    id: "APG-dialog-modal",
    url: "https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/",
    fixtureIds: ["A11Y-02", "CLOSE-01"]
  },
  {
    id: "APG-keyboard-interface",
    url: "https://www.w3.org/WAI/ARIA/apg/practices/keyboard-interface/",
    fixtureIds: ["A11Y-01", "A11Y-02", "A11Y-04"]
  },
  {
    id: "WAI-ARIA-busy-status",
    url: "https://www.w3.org/TR/wai-aria-1.2/#aria-busy",
    fixtureIds: ["A11Y-03"]
  },
  {
    id: "WAI-ARIA-status-role",
    url: "https://www.w3.org/TR/wai-aria-1.2/#status",
    fixtureIds: ["A11Y-03"]
  },
  {
    id: "WCAG-2.4.11-focus-not-obscured",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html",
    fixtureIds: ["A11Y-04"]
  },
  {
    id: "WCAG-2.4.7-focus-visible",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/focus-visible.html",
    fixtureIds: ["A11Y-04"]
  },
  {
    id: "WCAG-2.4.13-focus-appearance",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance.html",
    fixtureIds: ["A11Y-04"]
  },
  {
    id: "WCAG-1.4.11-non-text-contrast",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html",
    fixtureIds: ["A11Y-04", "A11Y-07"]
  },
  {
    id: "WCAG-1.4.10-reflow",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/reflow.html",
    fixtureIds: ["A11Y-05"]
  },
  {
    id: "WCAG-2.5.8-target-size-minimum",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html",
    fixtureIds: ["A11Y-06"]
  },
  {
    id: "WCAG-2.5.2-pointer-cancellation",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/pointer-cancellation.html",
    fixtureIds: ["A11Y-06"]
  },
  {
    id: "WCAG-2.3.3-animation-from-interactions",
    url: "https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html",
    fixtureIds: ["A11Y-07"]
  }
]), eo = /* @__PURE__ */ new Set([
  "bubble",
  "slash",
  "block-handle",
  "shortcut"
]), Md = /* @__PURE__ */ new Set([
  "cursor",
  "selection",
  "block",
  "document"
]), Ud = /* @__PURE__ */ new Set([
  "exact-target",
  "allow-expansion-with-confirmation"
]), Gd = /* @__PURE__ */ new Set([
  "always",
  "requires-selection",
  "requires-supported-target"
]), to = c({
  "selection-request": "selection",
  "cursor-request": "cursor",
  "block-request": "block",
  "long-form-request": "long-running",
  "follow-up-request": "follow-up"
}), jn = (e, t) => e < t ? -1 : e > t ? 1 : 0, Wd = (e) => ({
  version: e.version,
  commandId: e.commandId,
  labelKey: e.labelKey,
  descriptionKey: e.descriptionKey,
  surfaces: e.surfaces,
  contextKinds: e.contextKinds,
  scopePolicyId: e.scopePolicyId,
  capabilityPredicateId: e.capabilityPredicateId,
  intentFactoryId: e.intentFactoryId,
  ...e.execution ? { execution: e.execution } : {},
  ...e.shortcut ? { shortcut: e.shortcut } : {},
  group: e.group,
  order: e.order,
  diagnosticTags: e.diagnosticTags
}), Yd = (e) => {
  const t = Ve(Wd(e));
  return c({
    ...t,
    fingerprint: re(
      "zx-ai-authoring-command-descriptor:v1",
      t
    )
  });
}, Xd = (e) => {
  if (!Y(
    e,
    [
      "version",
      "commandId",
      "labelKey",
      "descriptionKey",
      "surfaces",
      "contextKinds",
      "scopePolicyId",
      "capabilityPredicateId",
      "intentFactoryId",
      "group",
      "order",
      "diagnosticTags",
      "fingerprint"
    ],
    ["shortcut", "execution"]
  ) || e.version !== "1.0.0" || !U(e.commandId) || !Qt(e.labelKey) || !Qt(e.descriptionKey) || !Array.isArray(e.surfaces) || e.surfaces.length === 0 || !e.surfaces.every(
    (t) => eo.has(t)
  ) || new Set(e.surfaces).size !== e.surfaces.length || !Array.isArray(e.contextKinds) || e.contextKinds.length === 0 || !e.contextKinds.every(
    (t) => Md.has(t)
  ) || new Set(e.contextKinds).size !== e.contextKinds.length || !Ud.has(String(e.scopePolicyId)) || !Gd.has(String(e.capabilityPredicateId)) || !Object.hasOwn(to, String(e.intentFactoryId)) || e.execution !== void 0 && !hs(e.execution) || !Qt(e.group) || !Number.isSafeInteger(e.order) || !Array.isArray(e.diagnosticTags) || e.diagnosticTags.length > 16 || !e.diagnosticTags.every(Qt) || new Set(e.diagnosticTags).size !== e.diagnosticTags.length || !X(e.fingerprint) || Object.hasOwn(e, "shortcut") && (!Y(e.shortcut, ["chord", "platformPolicy"]) || !U(e.shortcut.chord) || e.shortcut.platformPolicy !== "mod"))
    return null;
  try {
    const t = Ve(
      e
    ), r = Jr(t);
    return t.fingerprint === re(
      "zx-ai-authoring-command-descriptor:v1",
      r
    ) ? t : null;
  } catch {
    return null;
  }
}, Zd = (e) => {
  if (!Y(e, ["descriptors"]) || !Array.isArray(e.descriptors) || e.descriptors.length > 128)
    return c({ status: "failure", code: "descriptor-invalid" });
  const t = [];
  for (const s of e.descriptors) {
    const o = Xd(s);
    if (!o)
      return c({ status: "failure", code: "descriptor-invalid" });
    t.push(o);
  }
  if (new Set(t.map(({ commandId: s }) => s)).size !== t.length)
    return c({ status: "failure", code: "duplicate-command" });
  const r = t.filter(
    (s) => !!s.shortcut
  ).map(({ shortcut: s }) => `${s.platformPolicy}:${s.chord}`);
  if (new Set(r).size !== r.length)
    return c({ status: "failure", code: "shortcut-conflict" });
  const n = {
    kind: "zx-ai-authoring-command-registry-v1",
    version: "1.0.0",
    descriptors: [...t].sort(
      (s, o) => jn(s.group, o.group) || s.order - o.order || jn(s.commandId, o.commandId)
    )
  };
  return c({
    status: "success",
    registry: {
      ...n,
      fingerprint: re(
        "zx-ai-authoring-command-registry:v1",
        n
      )
    }
  });
}, Mr = (e, t, r) => c({
  status: "disabled",
  commandId: e,
  reasonCode: t,
  messageKey: `ai.authoring.disabled.${t}`,
  ...r ? { recoveryHintId: r } : {}
}), cf = (e) => eo.has(e.surface) ? c(
  e.registry.descriptors.filter((t) => t.surfaces.includes(e.surface)).map((t) => {
    let r;
    return t.contextKinds.includes(e.context.productScope) ? e.hasOpenAuthoringTask ? r = Mr(
      t.commandId,
      "authoring-task-open",
      "reveal"
    ) : t.capabilityPredicateId === "requires-selection" && (e.context.target.kind !== "selection" || e.context.target.collapsed) ? r = Mr(
      t.commandId,
      "selection-required",
      "reselect-target"
    ) : t.capabilityPredicateId === "requires-supported-target" && !e.context.capabilityReceipts.some(
      (i) => i.kind === "semantic-capability" && i.status === "supported"
    ) ? r = Mr(
      t.commandId,
      "target-unsupported",
      "choose-supported-command"
    ) : r = c({
      status: "enabled",
      commandId: t.commandId
    }) : r = Mr(t.commandId, "context-unsupported"), c({ descriptor: t, availability: r });
  })
) : c([]), df = (e) => {
  const t = to[e.descriptor.intentFactoryId];
  if (!t || e.preflight.commandId !== e.descriptor.commandId || e.preflight.contextFingerprint !== e.context.fingerprint || !X(e.promptDigest) || e.predecessorResultDigest !== void 0 && !X(e.predecessorResultDigest))
    return c({ status: "failure", code: "intent-input-invalid" });
  try {
    const r = {
      version: "1.0.0",
      commandId: e.descriptor.commandId,
      requestKind: t,
      targetFingerprint: e.context.target.fingerprint,
      promptDigest: e.promptDigest,
      boundedOptions: Pa(e.options),
      ...e.predecessorResultDigest ? { predecessorResultDigest: e.predecessorResultDigest } : {},
      preflightFingerprint: e.preflight.fingerprint
    };
    return c({
      status: "success",
      intent: {
        ...r,
        fingerprint: re(
          "zx-ai-authoring-intent:v1",
          r
        )
      }
    });
  } catch {
    return c({ status: "failure", code: "intent-input-invalid" });
  }
}, ti = (e) => new TextEncoder().encode(e).byteLength, Jd = (e) => {
  let t = 0, r = "";
  for (const i of e)
    /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}]/u.test(
      i
    ) ? t += 1 : r += i;
  return Math.ceil(t * 1.5 + ti(r) / 3);
}, Qd = Object.freeze({
  id: "cjk-utf8-estimate",
  version: "1",
  count: Jd
}), wi = [
  "document-identity",
  "outline",
  "elided-digest",
  "prefix",
  "suffix",
  "target"
], Ir = (e) => Number.isSafeInteger(e) && Number(e) >= 0, el = (e) => {
  if (!Y(e, [
    "kind",
    "version",
    "sourceRevision",
    "sourceFingerprint",
    "targetFingerprint",
    "policyRef",
    "segments",
    "receipt",
    "fingerprint"
  ]) || e.kind !== "zx-ai-context-window-v1" || e.version !== 1 || ![
    "sourceRevision",
    "sourceFingerprint",
    "targetFingerprint",
    "fingerprint"
  ].every((i) => X(e[i])) || !Y(e.policyRef, [
    "id",
    "version",
    "fingerprint"
  ]) || !U(e.policyRef.id) || !U(e.policyRef.version) || !X(e.policyRef.fingerprint) || !Array.isArray(e.segments) || e.segments.length > wi.length)
    return !1;
  const t = /* @__PURE__ */ new Set();
  for (const i of e.segments) {
    if (!Y(i, [
      "role",
      "text",
      "spans",
      "completeness",
      "estimatedTokens",
      "bytes"
    ]) || !wi.includes(String(i.role)) || t.has(String(i.role)) || typeof i.text != "string" || !["exact", "partial", "summary"].includes(String(i.completeness)) || !Ir(i.estimatedTokens) || i.bytes !== ti(i.text) || !Array.isArray(i.spans) || !i.spans.every(
      (n) => Y(n, [
        "blockId",
        "startOffset",
        "endOffset"
      ]) && U(n.blockId) && Ir(n.startOffset) && Ir(n.endOffset) && Number(n.startOffset) <= Number(n.endOffset)
    ))
      return !1;
    t.add(String(i.role));
  }
  const r = e.receipt;
  if (!Y(r, [
    "sourceFingerprint",
    "policyFingerprint",
    "estimateMethod",
    "inputBudgetTokens",
    "bodyBudgetTokens",
    "estimatedTokens",
    "serializedBytes",
    "coverage",
    "documentCovered",
    "sourceBlockCount",
    "includedBlockCount",
    "omittedBlockCount",
    "policyExcludedCount",
    "limitingConstraint",
    "roles"
  ]) || r.sourceFingerprint !== e.sourceFingerprint || r.policyFingerprint !== e.policyRef.fingerprint || typeof r.estimateMethod != "string" || ![
    "inputBudgetTokens",
    "bodyBudgetTokens",
    "estimatedTokens",
    "serializedBytes",
    "sourceBlockCount",
    "includedBlockCount",
    "omittedBlockCount",
    "policyExcludedCount"
  ].every((i) => Ir(r[i])) || typeof r.documentCovered != "boolean" || !["full-source", "summarized", "partial"].includes(
    String(r.coverage)
  ) || !["none", "tokens", "bytes"].includes(String(r.limitingConstraint)) || !Y(r.roles, wi) || !Object.values(r.roles).every(
    (i) => Y(i, ["included", "partial", "omitted"]) && Object.values(i).every(Ir)
  ) || Number(r.estimatedTokens) > Number(r.bodyBudgetTokens))
    return !1;
  try {
    const i = e;
    return i.receipt.serializedBytes === Ji(i) && i.receipt.estimatedTokens === i.segments.reduce(
      (n, s) => n + s.estimatedTokens,
      0
    ) && i.fingerprint === re(
      "zx-ai-context-window:v1",
      Jr(i)
    );
  } catch {
    return !1;
  }
}, $t = c({
  maxPreparedRequests: 32,
  maxBoundEffects: 64,
  maxPayloadBytes: 256 * 1024,
  maxAggregatePayloadBytes: 2 * 1024 * 1024,
  maxPredecessorCandidateUtf16: 65536,
  maxContextWindowBytes: 64 * 1024
}), Dn = (e) => U(e.editorBindingId) && U(e.sessionId) && U(e.requestId) && U(e.attemptId) && X(e.inputFingerprint) && U(e.effectId) && e.correlationRef === e.effectId && X(e.transportAdmissionFingerprint), lf = () => {
  const e = /* @__PURE__ */ new Map(), t = /* @__PURE__ */ new Map();
  let r = 0;
  return {
    prepare(i) {
      if (!U(i.editorBindingId) || !U(i.sessionId) || !U(i.requestId) || !X(i.inputFingerprint) || !X(i.intentFingerprint) || !ht(i.payload.prompt, 16384) || i.payload.kind !== "zx-ai-authoring-semantic-request-payload-v1" || i.payload.target.editorBindingId !== i.editorBindingId || i.payload.predecessorResultDigest !== void 0 && !X(i.payload.predecessorResultDigest) || i.payload.predecessorCandidateText !== void 0 && !ht(
        i.payload.predecessorCandidateText,
        $t.maxPredecessorCandidateUtf16
      ) || i.payload.predecessorCandidateText !== void 0 != (i.payload.predecessorResultDigest !== void 0) || i.payload.execution !== void 0 != (i.payload.contextWindow !== void 0))
        return c({
          status: "failure",
          code: "resolver-input-invalid"
        });
      try {
        const n = Ve(i.payload);
        if (n.execution && n.contextWindow) {
          const {
            execution: g,
            contextWindow: u,
            target: p,
            semanticSnapshot: f,
            options: m
          } = n;
          if (!Ha(g) || !el(u))
            return c({
              status: "failure",
              code: "resolver-execution-invalid"
            });
          if (u.receipt.serializedBytes > $t.maxContextWindowBytes)
            return c({
              status: "failure",
              code: "resolver-context-window-limit-exceeded"
            });
          if (g.sourceRevision !== f.documentRevision || u.sourceRevision !== g.sourceRevision || p.semanticSnapshotFingerprint !== f.fingerprint || g.sourceDocumentFingerprint !== p.baseDocumentFingerprint || g.targetFingerprint !== p.fingerprint || u.targetFingerprint !== p.fingerprint || g.contextFingerprint !== u.fingerprint || !Ot(
            g.profile.contextPolicyRef,
            u.policyRef
          ) || m.executionFingerprint !== g.fingerprint || m.commandId !== g.commandId)
            return c({
              status: "failure",
              code: "resolver-execution-binding-mismatch"
            });
        }
        const s = c({
          ...n,
          fingerprint: re(
            "zx-ai-authoring-semantic-request-payload:v1",
            n
          )
        }), o = Ji(s);
        if (o > $t.maxPayloadBytes)
          return c({
            status: "failure",
            code: "resolver-payload-limit-exceeded"
          });
        const a = e.get(i.requestId), d = {
          editorBindingId: i.editorBindingId,
          sessionId: i.sessionId,
          requestId: i.requestId,
          inputFingerprint: i.inputFingerprint,
          intentFingerprint: i.intentFingerprint,
          payload: s,
          byteLength: o,
          retainCount: (a == null ? void 0 : a.retainCount) ?? 0
        };
        if (a && !Ot(
          { ...a, retainCount: 0 },
          { ...d, retainCount: 0 }
        ))
          return c({
            status: "failure",
            code: "resolver-request-binding-mismatch"
          });
        if (!a && e.size >= $t.maxPreparedRequests)
          return c({
            status: "failure",
            code: "resolver-prepared-request-limit-exceeded"
          });
        const l = r - ((a == null ? void 0 : a.byteLength) ?? 0) + o;
        return l > $t.maxAggregatePayloadBytes ? c({
          status: "failure",
          code: "resolver-aggregate-payload-limit-exceeded"
        }) : (e.set(i.requestId, d), r = l, c({
          status: "accepted",
          fingerprint: s.fingerprint
        }));
      } catch {
        return c({
          status: "failure",
          code: "resolver-payload-invalid"
        });
      }
    },
    bind({ key: i }) {
      if (!Dn(i))
        return c({
          status: "failure",
          code: "resolver-key-invalid"
        });
      const n = e.get(i.requestId);
      if (!n || n.editorBindingId !== i.editorBindingId || n.sessionId !== i.sessionId || n.inputFingerprint !== i.inputFingerprint)
        return c({
          status: "failure",
          code: "resolver-request-binding-missing-or-mismatch"
        });
      const s = t.get(i.effectId);
      return s && !Ot(s, i) ? c({
        status: "failure",
        code: "resolver-effect-binding-mismatch"
      }) : !s && t.size >= $t.maxBoundEffects ? c({
        status: "failure",
        code: "resolver-bound-effect-limit-exceeded"
      }) : (t.set(i.effectId, Ve(i)), c({ status: "accepted" }));
    },
    resolve(i) {
      if (!Dn(i))
        return c({
          status: "failure",
          code: "resolver-key-invalid"
        });
      const n = t.get(i.effectId), s = e.get(i.requestId);
      if (!n || !s || !Ot(n, i) || s.editorBindingId !== i.editorBindingId || s.sessionId !== i.sessionId || s.inputFingerprint !== i.inputFingerprint)
        return c({
          status: "failure",
          code: "resolver-binding-missing-or-mismatch"
        });
      const o = {
        key: n,
        intentFingerprint: s.intentFingerprint,
        targetFingerprint: s.payload.target.fingerprint,
        payload: s.payload,
        byteLength: s.byteLength
      };
      return c({
        status: "success",
        context: {
          ...o,
          fingerprint: re(
            "zx-ai-authoring-resolved-request-context:v1",
            o
          )
        }
      });
    },
    retain(i) {
      const n = e.get(i);
      n && (n.retainCount += 1);
    },
    releaseAttempt(i) {
      t.delete(i);
    },
    releaseRequest(i) {
      const n = e.get(i);
      if (n && (n.retainCount = Math.max(0, n.retainCount - 1), n.retainCount === 0)) {
        e.delete(i), r -= n.byteLength;
        for (const [s, o] of t)
          o.requestId === i && t.delete(s);
      }
    },
    inspect() {
      return c({
        preparedRequestCount: e.size,
        boundEffectCount: t.size,
        aggregatePayloadBytes: r,
        limits: $t
      });
    }
  };
}, pf = (e) => c({
  descriptor: e.descriptor,
  start(t) {
    const r = {
      editorBindingId: e.editorBindingId,
      sessionId: t.sessionId,
      requestId: t.requestId,
      attemptId: t.attemptId,
      inputFingerprint: t.requestProjection.inputFingerprint,
      effectId: t.effectId,
      correlationRef: t.correlationRef,
      transportAdmissionFingerprint: t.transportAdmission.fingerprint
    }, i = e.resolver.resolve(r);
    return i.status !== "success" ? (async function* () {
      yield en({
        sessionId: t.sessionId,
        requestId: t.requestId,
        attemptId: t.attemptId,
        sequence: 0,
        kind: "attempt-failed",
        payload: {
          kind: "attempt-failed",
          reason: "transport-failed",
          diagnosticCode: "session-transport-failure",
          failureClass: "internal"
        }
      });
    })() : e.startResolved(t, i.context);
  },
  abort(t) {
    return e.abort(t);
  },
  ...e.resume ? { resume: e.resume } : {}
}), uf = (e) => {
  const t = Pt(e);
  return t.status !== "success" ? c({ status: "failure" }) : c({
    status: "success",
    bundle: {
      receipt: t.transfer.receipt,
      proposal: t.transfer.proposal,
      lifecycle: t.transfer.lifecycle,
      sidecar: t.transfer.sidecar,
      initialSidecarFingerprint: t.transfer.sidecar.fingerprint,
      transferFingerprint: t.transfer.fingerprint
    }
  });
}, cr = (e, t, r) => e.sidecar.fingerprint !== t || r.identity.reviewId !== e.sidecar.identity.reviewId || r.proposalBinding.proposalFingerprint !== e.proposal.fingerprint || r.proposalBinding.lifecycleFingerprint !== e.lifecycle.fingerprint ? c({ status: "conflict" }) : c({
  status: "success",
  bundle: {
    ...e,
    sidecar: r
  }
}), ff = (e) => pd({
  sidecar: e.bundle.sidecar,
  kind: e.kind,
  ...e.currentItemId ? { currentItemId: e.currentItemId } : {}
}), gf = (e) => {
  const t = Te(e.bundle.sidecar);
  if (t.status !== "success" || t.sidecar.capability === "coarse-review-unavailable" && e.kind !== "reject-all" && e.kind !== "regenerate")
    return c({ status: "failure" });
  const r = t.sidecar, i = {
    commandId: e.commandId,
    expectedRevision: r.revision,
    expectedSidecarFingerprint: r.fingerprint,
    expectedProposalFingerprint: r.proposalBinding.proposalFingerprint,
    expectedLifecycleFingerprint: r.proposalBinding.lifecycleFingerprint,
    expectedPolicyFingerprint: r.policyRef.fingerprint
  };
  let n;
  if (e.kind === "accept-operation" || e.kind === "reject-operation") {
    if (!Number.isSafeInteger(e.operationIndex))
      return c({ status: "failure" });
    n = {
      ...i,
      kind: e.kind,
      operationIndex: e.operationIndex
    };
  } else
    n = { ...i, kind: e.kind };
  const s = od({ sidecar: r, command: n });
  return s.status !== "success" ? c({
    status: s.status === "conflict" ? "conflict" : "failure"
  }) : cr(e.bundle, r.fingerprint, s.sidecar);
}, mf = (e) => {
  const t = Ia({
    sidecar: e.bundle.sidecar,
    proposal: e.bundle.proposal,
    lifecycle: e.bundle.lifecycle,
    currentDocument: e.currentDocument
  }), r = cr(
    e.bundle,
    e.bundle.sidecar.fingerprint,
    t.sidecar
  );
  return c({ result: t, replacement: r });
}, vf = (e) => {
  const t = ha({
    sidecar: e.bundle.sidecar,
    proposal: e.bundle.proposal,
    lifecycle: e.bundle.lifecycle,
    latestBaseDocument: e.latestBaseDocument,
    nextIdentity: e.nextIdentity
  }), r = t.status === "regeneration-required" ? cr(
    e.bundle,
    e.bundle.sidecar.fingerprint,
    t.sidecar
  ) : c({ status: "conflict" });
  return c({ result: t, replacement: r });
}, tl = (e) => {
  const t = Id({
    sidecar: e.bundle.sidecar,
    proposal: e.bundle.proposal,
    lifecycle: e.bundle.lifecycle,
    commandId: e.commandId,
    latestBaseFingerprint: e.latestBaseFingerprint,
    refinementPromptDigest: e.refinementPromptDigest,
    nextVariantId: e.nextVariantId
  }), r = t.status === "refinement-issued" ? cr(
    e.bundle,
    e.bundle.sidecar.fingerprint,
    t.sidecar
  ) : c({ status: "conflict" });
  return c({ result: t, replacement: r });
}, hf = (e) => {
  const t = gd({
    sidecar: e.bundle.sidecar,
    proposal: e.bundle.proposal,
    lifecycle: e.bundle.lifecycle
  });
  if (t.status !== "reject-intent-ready")
    return c({ status: "failure", result: t });
  const r = ya({
    intent: t.intent.proposalDiscardIntent
  });
  if (r.status !== "discarded")
    return c({ status: "failure", result: r });
  const i = md({
    sidecar: t.sidecar,
    intent: t.intent,
    discardedLifecycle: r.lifecycle
  }), n = i.status === "rejected" ? cr(
    e.bundle,
    e.bundle.sidecar.fingerprint,
    i.sidecar
  ) : c({ status: "conflict" });
  return c({ status: i.status, result: i, replacement: n });
}, yf = (e) => {
  const t = va({
    sidecar: e.bundle.sidecar,
    proposal: e.bundle.proposal,
    lifecycle: e.bundle.lifecycle,
    currentDocument: e.currentDocument,
    targetEditor: e.targetEditor
  }), r = t.status === "committed" || t.status === "accepted-no-change" ? cr(
    e.bundle,
    e.bundle.sidecar.fingerprint,
    t.sidecar
  ) : c({ status: "conflict" });
  return c({ result: t, replacement: r });
}, If = (e) => {
  let t = null, r, i = !1, n;
  const s = (d) => {
    var l;
    t = d ? c({ ...d }) : null, (l = e.onProjectionChange) == null || l.call(e, t);
  }, o = (d) => {
    if (!r)
      return c({
        status: "failure",
        projection: t,
        reasonCode: d
      });
    const l = {
      status: "successor-start-failed",
      sourceReviewId: r.handoff.reviewId,
      handoffFingerprint: r.handoff.fingerprint,
      failureCode: d,
      retryActionId: "retry-review-refine"
    };
    return s(l), c({
      status: "failure",
      projection: l,
      reasonCode: d
    });
  }, a = async (d) => {
    if (!r)
      return c({
        status: "unsupported",
        projection: t,
        reasonCode: "refinement-review-missing"
      });
    s({
      status: "starting-successor",
      sourceReviewId: r.handoff.reviewId,
      handoffFingerprint: r.handoff.fingerprint
    });
    const l = await e.startSuccessor({
      handoff: r.handoff,
      prompt: r.prompt,
      retry: d
    });
    if (l !== "successor-active") return o(l);
    const g = r.handoff.fingerprint;
    return n = {
      commandId: r.handoff.commandId,
      handoffFingerprint: g
    }, r = void 0, s(null), c({
      status: "accepted",
      projection: null,
      handoffFingerprint: g
    });
  };
  return {
    getProjection: () => t,
    async reviewRefine(d) {
      if ((n == null ? void 0 : n.commandId) === d.commandId)
        return c({
          status: "idempotent",
          projection: null,
          handoffFingerprint: n.handoffFingerprint
        });
      if (i || r)
        return c({
          status: "busy",
          projection: t,
          reasonCode: "refinement-busy"
        });
      const l = d.prompt.trim();
      if (!U(d.commandId) || !U(d.nextVariantId) || l.length === 0 || !ht(l, 16384))
        return c({
          status: "unsupported",
          projection: t,
          reasonCode: "refinement-prompt-invalid"
        });
      const g = e.getActiveReview();
      if (!g)
        return c({
          status: "unsupported",
          projection: t,
          reasonCode: "refinement-review-missing"
        });
      const u = e.getTargetFreshness(), p = e.getCanonicalTargetFingerprint();
      if ((u == null ? void 0 : u.status) !== "fresh" || !p || u.targetFingerprint !== p)
        return c({
          status: "conflict",
          projection: t,
          reasonCode: "refinement-target-stale",
          diagnosticPath: `$.targetFreshness.${(u == null ? void 0 : u.status) ?? "missing"}${u && "reasonCode" in u ? `.${u.reasonCode}` : ""}`
        });
      i = !0, s({
        status: "superseding-review",
        sourceReviewId: g.sidecar.identity.reviewId,
        commandId: d.commandId
      });
      try {
        const f = tl({
          bundle: g,
          commandId: d.commandId,
          latestBaseFingerprint: g.sidecar.proposalBinding.baseFingerprint,
          refinementPromptDigest: re(
            "zx-ai-authoring-review-refinement-prompt:v1",
            l
          ),
          nextVariantId: d.nextVariantId
        });
        return f.result.status !== "refinement-issued" ? (s(null), c({
          status: "conflict",
          projection: null,
          reasonCode: "refinement-authority-conflict",
          ..."diagnostic" in f.result ? { diagnosticPath: f.result.diagnostic.path } : {}
        })) : f.replacement.status !== "success" || !e.replaceReviewBundle({
          expectedReviewId: g.sidecar.identity.reviewId,
          terminalBundle: f.replacement.bundle
        }) ? (s(null), c({
          status: "conflict",
          projection: null,
          reasonCode: "refinement-authority-conflict",
          diagnosticPath: "$.sidecar.replacement"
        })) : (r = {
          handoff: f.result.handoff,
          prompt: l
        }, await a(!1));
      } finally {
        i = !1;
      }
    },
    async retryReviewRefine() {
      if (i)
        return c({
          status: "busy",
          projection: t,
          reasonCode: "refinement-busy"
        });
      if (!r || (t == null ? void 0 : t.status) !== "successor-start-failed")
        return c({
          status: "unsupported",
          projection: t,
          reasonCode: "refinement-review-missing"
        });
      i = !0;
      try {
        return await a(!0);
      } finally {
        i = !1;
      }
    }
  };
}, bf = (e) => c(
  e.registry.entries.flatMap(
    (t) => t.operations.map((r) => {
      var n;
      const i = `complex:${t.adapter.adapterId}:${r.name}`;
      return {
        id: i,
        adapter: t.adapter,
        operation: r.name,
        enabled: ((n = e.disabled) == null ? void 0 : n[i]) ?? { value: !0 }
      };
    })
  )
), Ff = (e) => Zd({
  descriptors: e.registry.entries.flatMap(
    (t, r) => t.operations.map(
      (i, n) => Yd({
        version: "1.0.0",
        commandId: `complex.${t.adapter.adapterId}.${i.name}`,
        labelKey: `ai.complex.${t.family}.${i.name}.label`,
        descriptionKey: `ai.complex.${t.family}.${i.name}.description`,
        surfaces: ["slash", "block-handle"],
        contextKinds: ["block"],
        scopePolicyId: "exact-target",
        capabilityPredicateId: "requires-supported-target",
        intentFactoryId: "block-request",
        group: "ai.complex-node",
        order: r * 100 + n,
        diagnosticTags: [
          "complex-node",
          t.family,
          i.risk,
          i.stream
        ]
      })
    )
  )
}), ct = () => c({ status: "failure", binding: null }), xf = async (e) => {
  const t = await e.port.decodeCompletePayload(e.fullPayload);
  if (t.status !== "success") return ct();
  const r = await e.port.validateAndPlan(t.payload);
  if (r.status !== "success" || !Le(r.planFingerprint))
    return ct();
  const i = await e.port.executeRuntime(r.planFingerprint);
  if (i.status !== "success" || !Le(i.runtimeReceiptFingerprint))
    return ct();
  const n = await e.port.createProposal({
    planFingerprint: r.planFingerprint,
    runtimeReceiptFingerprint: i.runtimeReceiptFingerprint
  });
  if (n.status !== "success" || !Le(n.proposalFingerprint))
    return ct();
  const s = await e.port.createReview(n.proposalFingerprint);
  return s.status !== "success" || !Le(s.reviewFingerprint) ? ct() : c({
    status: "success",
    binding: {
      planFingerprint: r.planFingerprint,
      runtimeReceiptFingerprint: i.runtimeReceiptFingerprint,
      proposalFingerprint: n.proposalFingerprint,
      reviewFingerprint: s.reviewFingerprint
    }
  });
}, wf = async (e) => {
  if (!Le(e.sourceArtifactFingerprint)) return ct();
  const t = await e.port.regenerateCurrent(
    e.sourceArtifactFingerprint
  );
  if (t.status !== "success" || !Object.values(t.binding).every(Le)) return ct();
  const i = await e.port.reconcileS4(t.binding);
  if (i.status !== "success" || !Le(i.decisionFingerprint))
    return ct();
  const n = await e.port.admitS7({
    binding: t.binding,
    decisionFingerprint: i.decisionFingerprint
  });
  return n.status === "success" && Le(n.commitCommandFingerprint) ? c({
    status: "success",
    binding: t.binding,
    decisionFingerprint: i.decisionFingerprint,
    commitCommandFingerprint: n.commitCommandFingerprint
  }) : ct();
}, ce = (e) => {
  var t;
  return c({
    code: e.code,
    stage: e.stage,
    path: e.path,
    recovery: e.recovery ?? "none",
    ...e.reviewRef ? { reviewRef: e.reviewRef } : {},
    ...e.commandRef ? { commandRef: e.commandRef } : {},
    ...e.branchRefs && e.branchRefs.length <= ae.maxBranchRefs ? { branchRefs: [...e.branchRefs] } : {},
    ...e.count !== void 0 || (((t = e.branchRefs) == null ? void 0 : t.length) ?? 0) > ae.maxBranchRefs ? { count: e.count ?? e.branchRefs.length } : {},
    ...e.fingerprint ? { fingerprintPrefix: $i(e.fingerprint) } : {}
  });
}, Z = (e, t = "invalid") => c({
  status: t,
  artifact: null,
  diagnostic: ce({
    code: t === "unsupported" ? "collaboration-runtime-unsupported" : "collaboration-artifact-invalid",
    stage: "codec",
    path: e
  })
}), st = (e) => e.version === ne, He = (e, t, r = []) => e.fingerprint === B(
  t,
  ba(e),
  r
), Ri = (e) => ye(e, ["id", "version", "fingerprint"]) && P(e.id) && P(e.version) && C(e.fingerprint), We = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "principalRef",
    "documentId",
    "namespace",
    "action",
    "commandFingerprint",
    "artifactFingerprint",
    "policyFingerprint",
    "issuedAtLogicalTime",
    "expiresAtLogicalTime",
    "verifierEvidenceFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-admission-receipt-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  if (!P(e.principalRef) || !P(e.documentId) || e.namespace !== "zx-ai-review-v1" || ![
    "publish-root",
    "decision",
    "reject",
    "rebase",
    "resolve-conflict",
    "commit",
    "compact"
  ].includes(String(e.action)) || !C(e.commandFingerprint) || !C(e.artifactFingerprint) || !C(e.policyFingerprint) || !Se(e.issuedAtLogicalTime) || !Se(e.expiresAtLogicalTime) || e.expiresAtLogicalTime < e.issuedAtLogicalTime || !C(e.verifierEvidenceFingerprint) || !C(e.fingerprint))
    return Z("$");
  const t = e;
  return He(t, "admission") ? c({
    status: "success",
    artifact: pt(t)
  }) : Z("$.fingerprint");
}, rl = (e) => !ye(e, [
  "kind",
  "blockId",
  "semanticOffset",
  "affinity",
  "relativePosition",
  "capabilityFingerprint",
  "fingerprint"
]) || !["selection-endpoint", "block-boundary"].includes(String(e.kind)) || !P(e.blockId) || !Se(e.semanticOffset) || !["left", "right"].includes(String(e.affinity)) || !C(e.capabilityFingerprint) || !C(e.fingerprint) || ai(e.relativePosition, "relative-position").status !== "success" ? !1 : He(
  e,
  "anchor",
  [
    e.relativePosition.fingerprint
  ]
), il = (e, t) => {
  if (!ye(
    e,
    [
      "kind",
      "commandId",
      "expectedRevision",
      "expectedSidecarFingerprint",
      "expectedProposalFingerprint",
      "expectedLifecycleFingerprint",
      "expectedPolicyFingerprint"
    ],
    ["operationIndex"]
  ) || ![
    "accept-operation",
    "reject-operation",
    "accept-all",
    "reject-all",
    "regenerate"
  ].includes(String(e.kind)) || !P(e.commandId) || !Se(e.expectedRevision) || ![
    e.expectedSidecarFingerprint,
    e.expectedProposalFingerprint,
    e.expectedLifecycleFingerprint,
    e.expectedPolicyFingerprint,
    t
  ].every(C))
    return !1;
  const r = ["accept-operation", "reject-operation"].includes(
    String(e.kind)
  );
  return r !== Object.hasOwn(e, "operationIndex") || r && !Se(e.operationIndex) ? !1 : t === B("review-command", e, [
    e.expectedSidecarFingerprint,
    e.expectedProposalFingerprint,
    e.expectedLifecycleFingerprint,
    e.expectedPolicyFingerprint
  ]);
}, nl = (e, t) => !ye(e, [
  "kind",
  "version",
  "commandId",
  "documentId",
  "reviewId",
  "rootFingerprint",
  "durableHeadFingerprint",
  "expectedReviewRevision",
  "expectedSidecarFingerprint",
  "currentBindingFingerprint",
  "currentDocumentFingerprint",
  "currentStateVectorFingerprint",
  "driftFingerprint",
  "policyFingerprint",
  "fingerprint"
]) || e.kind !== "zx-ai-collaboration-commit-command-v1" || !st(e) || !P(e.commandId) || !P(e.documentId) || !P(e.reviewId) || !Se(e.expectedReviewRevision) || ![
  e.rootFingerprint,
  e.durableHeadFingerprint,
  e.expectedSidecarFingerprint,
  e.currentBindingFingerprint,
  e.currentDocumentFingerprint,
  e.currentStateVectorFingerprint,
  e.driftFingerprint,
  e.policyFingerprint,
  e.fingerprint
].every(C) || e.fingerprint !== t ? !1 : He(
  e,
  "commit-command",
  [
    e.rootFingerprint,
    e.durableHeadFingerprint,
    e.expectedSidecarFingerprint,
    e.currentBindingFingerprint,
    e.currentStateVectorFingerprint,
    e.driftFingerprint,
    e.policyFingerprint
  ]
), sl = (e, t) => !ye(e, [
  "kind",
  "version",
  "commandId",
  "reviewId",
  "sourceGraphFingerprint",
  "sourceRootFingerprint",
  "sourcePredecessorFingerprint",
  "forkEntryFingerprints",
  "disposition",
  "currentBaseBindingFingerprint",
  "regenerationHandoffFingerprint",
  "policyFingerprint",
  "fingerprint"
]) || e.kind !== "zx-ai-collaboration-conflict-resolution-command-v1" || !st(e) || !P(e.commandId) || !P(e.reviewId) || e.disposition !== "rebase-from-current-document" || !Array.isArray(e.forkEntryFingerprints) || e.forkEntryFingerprints.length < 2 || e.forkEntryFingerprints.length > ae.maxBranchRefs || new Set(e.forkEntryFingerprints).size !== e.forkEntryFingerprints.length || !e.forkEntryFingerprints.every(C) || ![
  e.sourceGraphFingerprint,
  e.sourceRootFingerprint,
  e.sourcePredecessorFingerprint,
  e.currentBaseBindingFingerprint,
  e.regenerationHandoffFingerprint,
  e.policyFingerprint,
  e.fingerprint
].every(C) || e.fingerprint !== t ? !1 : He(
  e,
  "conflict-resolution-command",
  [
    e.sourceGraphFingerprint,
    e.sourceRootFingerprint,
    e.sourcePredecessorFingerprint,
    ...e.forkEntryFingerprints,
    e.currentBaseBindingFingerprint,
    e.regenerationHandoffFingerprint,
    e.policyFingerprint
  ]
), ol = (e, t, r, i) => {
  if (!ye(e, [
    "kind",
    "version",
    "entryKind",
    "sourceRootFingerprint",
    "sourceHeadFingerprint",
    "sourcePredecessorFingerprint",
    "sourceHandoffFingerprint",
    "successorIdentityFingerprint",
    "successorRootFingerprint",
    "currentBaseBindingFingerprint",
    "resolutionCommandFingerprint",
    "preservedBranchFingerprints",
    "terminalArtifactFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-terminal-lineage-v1" || !st(e) || e.entryKind !== t || e.sourceRootFingerprint !== r || e.terminalArtifactFingerprint !== i || ![
    e.sourceRootFingerprint,
    e.sourceHeadFingerprint,
    e.sourcePredecessorFingerprint,
    e.terminalArtifactFingerprint,
    e.fingerprint
  ].every(C) || !(e.sourceHandoffFingerprint === null || C(e.sourceHandoffFingerprint)) || !(e.successorIdentityFingerprint === null || C(e.successorIdentityFingerprint)) || !(e.successorRootFingerprint === null || C(e.successorRootFingerprint)) || !(e.currentBaseBindingFingerprint === null || C(e.currentBaseBindingFingerprint)) || !(e.resolutionCommandFingerprint === null || C(e.resolutionCommandFingerprint)) || !Array.isArray(e.preservedBranchFingerprints) || e.preservedBranchFingerprints.length > ae.maxBranchRefs || new Set(e.preservedBranchFingerprints).size !== e.preservedBranchFingerprints.length || !e.preservedBranchFingerprints.every(C))
    return !1;
  const n = e;
  return He(n, "terminal-lineage", [
    n.sourceRootFingerprint,
    n.sourceHeadFingerprint,
    n.sourcePredecessorFingerprint,
    ...n.sourceHandoffFingerprint ? [n.sourceHandoffFingerprint] : [],
    ...n.successorIdentityFingerprint ? [n.successorIdentityFingerprint] : [],
    ...n.successorRootFingerprint ? [n.successorRootFingerprint] : [],
    ...n.currentBaseBindingFingerprint ? [n.currentBaseBindingFingerprint] : [],
    ...n.resolutionCommandFingerprint ? [n.resolutionCommandFingerprint] : [],
    ...n.preservedBranchFingerprints,
    n.terminalArtifactFingerprint
  ]);
}, ro = (e) => {
  try {
    return or({ mode: "historical", envelope: e }).status === "audit-success";
  } catch {
    return !1;
  }
}, zn = (e) => {
  if (!ro(e.envelope)) return !1;
  const t = e.envelope;
  return t.terminalSidecar.identity.reviewId === e.reviewId && t.reviewArtifact.reviewId === e.reviewId && t.terminalSidecar.fingerprint === e.resultingSidecarFingerprint && t.reviewArtifact.terminalSidecarFingerprint === e.resultingSidecarFingerprint && t.terminalSidecar.status === e.terminalStatus && t.reviewArtifact.terminalStatus === e.terminalStatus && Ge(
    t.reviewArtifact.decisionFingerprints,
    t.terminalSidecar.decisions.map((r) => r.fingerprint)
  ) && Ge(
    t.reviewArtifact.auditFingerprints,
    t.terminalSidecar.auditEntries.map((r) => r.fingerprint)
  );
}, al = (e) => {
  const t = {
    kind: "zx-ai-collaboration-terminal-entry-admission-artifact-v1",
    version: ne,
    rootFingerprint: e.rootFingerprint,
    commandFingerprint: e.commandFingerprint,
    priorSidecarFingerprint: e.priorSidecarFingerprint,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    terminalArtifactFingerprint: e.terminalHistoricalEnvelope.closureFingerprint,
    reviewArtifactFingerprint: e.terminalHistoricalEnvelope.reviewArtifact.fingerprint,
    proposalHistoricalArtifactFingerprint: e.terminalHistoricalEnvelope.reviewArtifact.proposalHistoricalArtifactFingerprint,
    terminalStatus: e.terminalHistoricalEnvelope.reviewArtifact.terminalStatus,
    lineageFingerprint: e.terminalLineage.fingerprint,
    admissionPolicyFingerprint: e.admissionPolicyFingerprint
  };
  return B(
    "terminal-entry-admission-artifact",
    t,
    [
      t.rootFingerprint,
      t.commandFingerprint,
      t.priorSidecarFingerprint,
      t.resultingSidecarFingerprint,
      t.terminalArtifactFingerprint,
      t.reviewArtifactFingerprint,
      t.proposalHistoricalArtifactFingerprint,
      t.lineageFingerprint,
      t.admissionPolicyFingerprint
    ]
  );
}, cl = (e) => B(
  "commit-terminal-admission-artifact",
  {
    kind: "zx-ai-collaboration-commit-terminal-admission-artifact-v1",
    version: ne,
    ...e
  },
  [
    e.commandFingerprint,
    e.priorSidecarFingerprint,
    e.resultingSidecarFingerprint,
    e.dispatchAdmissionFingerprint,
    e.commitReceiptFingerprint,
    e.terminalArtifactFingerprint,
    e.reviewArtifactFingerprint,
    e.proposalHistoricalArtifactFingerprint
  ]
), io = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "reviewId",
    "durableHeadFingerprint",
    "s4CommittedReceiptFingerprint",
    "terminalSidecarFingerprint",
    "beforeDocumentFingerprint",
    "afterDocumentFingerprint",
    "beforeStateVectorFingerprint",
    "afterStateVectorFingerprint",
    "contentUpdateFingerprint",
    "contentUpdateByteLength",
    "originKind",
    "observedOriginProofFingerprint",
    "historyProofFingerprint",
    "admissionFingerprint",
    "commitReservationFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-commit-receipt-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  if (!P(e.reviewId) || e.originKind !== "ai-content" || !Se(e.contentUpdateByteLength) || ![
    e.durableHeadFingerprint,
    e.s4CommittedReceiptFingerprint,
    e.terminalSidecarFingerprint,
    e.beforeDocumentFingerprint,
    e.afterDocumentFingerprint,
    e.beforeStateVectorFingerprint,
    e.afterStateVectorFingerprint,
    e.contentUpdateFingerprint,
    e.observedOriginProofFingerprint,
    e.historyProofFingerprint,
    e.admissionFingerprint,
    e.commitReservationFingerprint,
    e.fingerprint
  ].every(C))
    return Z("$");
  const t = e;
  return He(t, "commit-receipt", [
    t.durableHeadFingerprint,
    t.s4CommittedReceiptFingerprint,
    t.terminalSidecarFingerprint,
    t.beforeDocumentFingerprint,
    t.afterDocumentFingerprint,
    t.beforeStateVectorFingerprint,
    t.afterStateVectorFingerprint,
    t.contentUpdateFingerprint,
    t.observedOriginProofFingerprint,
    t.historyProofFingerprint,
    t.admissionFingerprint,
    t.commitReservationFingerprint
  ]) ? c({
    status: "success",
    artifact: pt(t)
  }) : Z("$.fingerprint");
}, De = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "documentId",
    "rootSharedType",
    "documentRevision",
    "documentFingerprint",
    "baseFingerprint",
    "targetFingerprint",
    "stableBlockIds",
    "anchors",
    "documentScope",
    "stateVector",
    "schemaRef",
    "runtimeRef",
    "policyRef",
    "sessionId",
    "requestId",
    "attemptId",
    "handoffFingerprint",
    "sessionTransferFingerprint",
    "proposalId",
    "variantId",
    "proposalFingerprint",
    "lifecycleFingerprint",
    "reviewId",
    "sidecarFingerprint",
    "capturedAtLogicalTime",
    "captureProofFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-base-binding-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  if (!P(e.documentId) || !P(e.rootSharedType) || !P(e.documentRevision) || !P(e.proposalId) || !P(e.variantId) || !P(e.reviewId) || !P(e.sessionId) || !P(e.requestId) || !P(e.attemptId) || !Array.isArray(e.stableBlockIds) || new Set(e.stableBlockIds).size !== e.stableBlockIds.length || !e.stableBlockIds.every(P) || !Array.isArray(e.anchors) || e.anchors.length > ae.maxAnchors || !e.anchors.every(rl) || !Ri(e.schemaRef) || !Ri(e.runtimeRef) || !Ri(e.policyRef) || !Se(e.capturedAtLogicalTime) || ![
    e.documentFingerprint,
    e.baseFingerprint,
    e.targetFingerprint,
    e.handoffFingerprint,
    e.sessionTransferFingerprint,
    e.proposalFingerprint,
    e.lifecycleFingerprint,
    e.sidecarFingerprint,
    e.captureProofFingerprint,
    e.fingerprint
  ].every(C)) return Z("$");
  if (!ye(e.stateVector, [
    "codec",
    "bytes",
    "fingerprint"
  ]) || e.stateVector.codec !== "yjs-state-vector-v1" || ai(e.stateVector.bytes, "state-vector").status !== "success" || !C(e.stateVector.fingerprint) || e.stateVector.fingerprint !== B(
    "state-vector",
    {
      codec: e.stateVector.codec,
      bytes: e.stateVector.bytes
    },
    [e.stateVector.bytes.fingerprint]
  ))
    return Z("$.stateVector");
  if (!(e.documentScope === null || ye(e.documentScope, [
    "kind",
    "localAnchor",
    "fingerprint"
  ]) && e.documentScope.kind === "document-scope" && e.documentScope.localAnchor === null && C(e.documentScope.fingerprint) && He(
    e.documentScope,
    "document-scope"
  ))) return Z("$.documentScope");
  const n = e;
  return He(n, "base-binding", [
    n.stateVector.fingerprint,
    ...n.anchors.map((s) => s.fingerprint)
  ]) ? c({
    status: "success",
    artifact: pt(n)
  }) : Z("$.fingerprint");
}, _r = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "reviewId",
    "sessionTransferFingerprint",
    "proposalFingerprint",
    "lifecycleFingerprint",
    "initialSidecarFingerprint",
    "initialSidecar",
    "baseBindingFingerprint",
    "creatorPrincipalRef",
    "policyFingerprint",
    "admission",
    "admissionFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-durable-review-root-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  const t = Te(e.initialSidecar), r = We(e.admission);
  if (t.status !== "success" || r.status !== "success" || r.artifact.fingerprint !== e.admissionFingerprint || r.artifact.principalRef !== e.creatorPrincipalRef || r.artifact.policyFingerprint !== e.policyFingerprint || r.artifact.action !== "publish-root" || !P(e.reviewId) || t.sidecar.identity.reviewId !== e.reviewId || t.sidecar.fingerprint !== e.initialSidecarFingerprint || !P(e.creatorPrincipalRef) || ![
    e.sessionTransferFingerprint,
    e.proposalFingerprint,
    e.lifecycleFingerprint,
    e.initialSidecarFingerprint,
    e.baseBindingFingerprint,
    e.policyFingerprint,
    e.admissionFingerprint,
    e.fingerprint
  ].every(C))
    return Z("$");
  const i = e;
  return He(i, "durable-root", [
    i.sessionTransferFingerprint,
    i.proposalFingerprint,
    i.initialSidecarFingerprint,
    i.baseBindingFingerprint,
    i.admissionFingerprint
  ]) ? c({
    status: "success",
    artifact: pt(i)
  }) : Z("$.fingerprint");
}, dr = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "reviewId",
    "rootFingerprint",
    "commandId",
    "entryKind",
    "priorReviewRevision",
    "priorSidecarFingerprint",
    "priorEntryFingerprint",
    "command",
    "commandFingerprint",
    "principalRef",
    "admission",
    "resultingSidecar",
    "resultingSidecarFingerprint",
    "resultReceiptFingerprint",
    "collaborationDispatchAdmission",
    "collaborationCommitReceipt",
    "terminalCurrentBaseBinding",
    "terminalHistoricalEnvelope",
    "terminalLineage",
    "logicalSequence",
    "fingerprint"
  ]) || e.kind !== "zx-ai-durable-review-entry-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  const t = We(e.admission), r = Te(e.resultingSidecar), i = e.entryKind === "conflict-resolution" ? "resolve-conflict" : e.entryKind;
  if (t.status !== "success" || r.status !== "success" || r.sidecar.fingerprint !== e.resultingSidecarFingerprint || r.sidecar.identity.reviewId !== e.reviewId || t.artifact.principalRef !== e.principalRef || t.artifact.action !== i || t.artifact.commandFingerprint !== e.commandFingerprint || !P(e.reviewId) || !P(e.commandId) || !P(e.principalRef) || !["decision", "rebase", "commit", "reject", "conflict-resolution"].includes(
    String(e.entryKind)
  ) || !Se(e.priorReviewRevision) || !Se(e.logicalSequence) || ![
    e.rootFingerprint,
    e.priorSidecarFingerprint,
    e.commandFingerprint,
    e.resultingSidecarFingerprint,
    e.fingerprint
  ].every(C) || !(e.priorEntryFingerprint === null || C(e.priorEntryFingerprint)) || !(e.resultReceiptFingerprint === null || C(e.resultReceiptFingerprint)) || (e.entryKind === "decision" ? !il(e.command, e.commandFingerprint) || e.terminalHistoricalEnvelope !== null || e.terminalLineage !== null || e.resultReceiptFingerprint !== null || e.collaborationDispatchAdmission !== null || e.collaborationCommitReceipt !== null || e.terminalCurrentBaseBinding !== null || r.sidecar.revision !== e.priorReviewRevision + 1 || e.command.expectedRevision !== e.priorReviewRevision || e.command.expectedSidecarFingerprint !== e.priorSidecarFingerprint : e.entryKind === "commit" ? !nl(e.command, e.commandFingerprint) || We(
    e.collaborationDispatchAdmission
  ).status !== "success" || io(e.collaborationCommitReceipt).status !== "success" || e.terminalCurrentBaseBinding !== null || e.resultReceiptFingerprint !== e.collaborationCommitReceipt.fingerprint || e.terminalHistoricalEnvelope === null || !zn({
    envelope: e.terminalHistoricalEnvelope,
    reviewId: e.reviewId,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    terminalStatus: r.sidecar.status
  }) || e.collaborationCommitReceipt.reviewId !== e.reviewId || e.collaborationCommitReceipt.durableHeadFingerprint !== e.priorEntryFingerprint || e.collaborationCommitReceipt.terminalSidecarFingerprint !== e.resultingSidecarFingerprint || e.collaborationCommitReceipt.admissionFingerprint !== e.collaborationDispatchAdmission.fingerprint || e.collaborationDispatchAdmission.principalRef !== e.principalRef || e.collaborationDispatchAdmission.action !== "commit" || e.collaborationDispatchAdmission.commandFingerprint !== e.commandFingerprint || e.collaborationDispatchAdmission.artifactFingerprint !== B(
    "commit-admission-artifact",
    {
      kind: "zx-ai-collaboration-commit-admission-artifact-v1",
      version: ne,
      commandFingerprint: e.commandFingerprint,
      principalRef: e.principalRef
    },
    [e.commandFingerprint]
  ) || t.artifact.artifactFingerprint !== cl({
    commandFingerprint: e.commandFingerprint,
    principalRef: e.principalRef,
    priorSidecarFingerprint: e.priorSidecarFingerprint,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    dispatchAdmissionFingerprint: e.collaborationDispatchAdmission.fingerprint,
    commitReceiptFingerprint: e.collaborationCommitReceipt.fingerprint,
    terminalArtifactFingerprint: e.terminalHistoricalEnvelope.closureFingerprint,
    reviewArtifactFingerprint: e.terminalHistoricalEnvelope.reviewArtifact.fingerprint,
    proposalHistoricalArtifactFingerprint: e.terminalHistoricalEnvelope.reviewArtifact.proposalHistoricalArtifactFingerprint,
    terminalStatus: e.terminalHistoricalEnvelope.reviewArtifact.terminalStatus,
    logicalSequence: e.logicalSequence
  }) || !["committed", "accepted-no-change"].includes(
    r.sidecar.status
  ) || r.sidecar.revision !== e.priorReviewRevision + 1 || e.command.expectedReviewRevision !== e.priorReviewRevision || e.command.expectedSidecarFingerprint !== e.priorSidecarFingerprint || e.terminalLineage !== null : (e.entryKind === "conflict-resolution" ? !sl(
    e.command,
    e.commandFingerprint
  ) || De(e.terminalCurrentBaseBinding).status !== "success" : e.command !== null || e.terminalCurrentBaseBinding !== null) || e.collaborationDispatchAdmission !== null || e.collaborationCommitReceipt !== null || e.terminalHistoricalEnvelope === null || !zn({
    envelope: e.terminalHistoricalEnvelope,
    reviewId: e.reviewId,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    terminalStatus: r.sidecar.status
  }) || !ol(
    e.terminalLineage,
    e.entryKind,
    e.rootFingerprint,
    e.terminalHistoricalEnvelope.closureFingerprint
  ) || t.artifact.artifactFingerprint !== al({
    rootFingerprint: e.rootFingerprint,
    commandFingerprint: e.commandFingerprint,
    priorSidecarFingerprint: e.priorSidecarFingerprint,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    terminalHistoricalEnvelope: e.terminalHistoricalEnvelope,
    terminalLineage: e.terminalLineage,
    admissionPolicyFingerprint: t.artifact.policyFingerprint
  }) || e.resultReceiptFingerprint !== e.terminalLineage.fingerprint || e.terminalLineage.sourcePredecessorFingerprint !== (e.priorEntryFingerprint ?? e.rootFingerprint) || (e.entryKind === "conflict-resolution" ? e.terminalLineage.currentBaseBindingFingerprint !== e.terminalCurrentBaseBinding.fingerprint || e.terminalLineage.resolutionCommandFingerprint !== e.command.fingerprint || e.terminalLineage.sourceHandoffFingerprint !== e.command.regenerationHandoffFingerprint || e.command.sourcePredecessorFingerprint !== (e.priorEntryFingerprint ?? e.rootFingerprint) || !Ge(
    e.terminalLineage.preservedBranchFingerprints,
    e.command.forkEntryFingerprints
  ) : e.terminalLineage.currentBaseBindingFingerprint !== null || e.terminalLineage.resolutionCommandFingerprint !== null) || r.sidecar.revision !== e.priorReviewRevision + 1 || (e.entryKind === "reject" ? r.sidecar.status !== "rejected" || e.terminalLineage.sourceHandoffFingerprint !== null || e.terminalLineage.successorIdentityFingerprint !== null || e.terminalLineage.successorRootFingerprint !== null : r.sidecar.status !== "superseded" || e.terminalLineage.sourceHandoffFingerprint === null || e.terminalLineage.successorIdentityFingerprint === null || e.terminalLineage.successorRootFingerprint === null)))
    return Z("$");
  const n = e;
  return He(n, "durable-entry", [
    n.rootFingerprint,
    n.priorEntryFingerprint ?? n.rootFingerprint,
    n.commandFingerprint,
    n.resultingSidecarFingerprint,
    n.admission.fingerprint
  ]) ? c({
    status: "success",
    artifact: pt(n)
  }) : Z("$.fingerprint");
}, ui = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "reviewId",
    "rootFingerprint",
    "compactedPrefixFingerprints",
    "terminalEntryFingerprint",
    "terminalArtifactFingerprint",
    "terminalHistoricalEnvelope",
    "auditHeadFingerprint",
    "suffixBoundaryFingerprint",
    "compactionAdmission",
    "compactionAdmissionFingerprint",
    "hostCompactionAdmissionFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-durable-review-checkpoint-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  const t = We(
    e.compactionAdmission
  );
  if (t.status !== "success" || t.artifact.action !== "compact" || t.artifact.fingerprint !== e.compactionAdmissionFingerprint || !ro(e.terminalHistoricalEnvelope) || e.terminalHistoricalEnvelope.closureFingerprint !== e.terminalArtifactFingerprint || !P(e.reviewId) || !Array.isArray(e.compactedPrefixFingerprints) || e.compactedPrefixFingerprints.length === 0 || e.compactedPrefixFingerprints.length > ae.maxCheckpointPrefixRefs || new Set(e.compactedPrefixFingerprints).size !== e.compactedPrefixFingerprints.length || !e.compactedPrefixFingerprints.every(C) || ![
    e.rootFingerprint,
    e.terminalEntryFingerprint,
    e.terminalArtifactFingerprint,
    e.auditHeadFingerprint,
    e.compactionAdmissionFingerprint,
    e.hostCompactionAdmissionFingerprint,
    e.fingerprint
  ].every(C) || !(e.suffixBoundaryFingerprint === null || C(e.suffixBoundaryFingerprint)))
    return Z("$");
  const r = e;
  return He(r, "checkpoint", [
    r.rootFingerprint,
    ...r.compactedPrefixFingerprints,
    r.terminalEntryFingerprint,
    r.terminalArtifactFingerprint,
    r.auditHeadFingerprint,
    r.compactionAdmissionFingerprint,
    r.hostCompactionAdmissionFingerprint
  ]) ? c({
    status: "success",
    artifact: pt(r)
  }) : Z("$.fingerprint");
}, Dr = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "reviewId",
    "rootFingerprint",
    "sourceReviewId",
    "sourceRootFingerprint",
    "sourceHeadFingerprint",
    "sourceEntryFingerprint",
    "sourceReviewFingerprint",
    "sourceTerminalEntryFingerprint",
    "sourceTerminalSidecarFingerprint",
    "sourceTerminalArtifactFingerprint",
    "sourceTerminalLineageFingerprint",
    "sourceHandoffFingerprint",
    "sourceResolutionCommandFingerprint",
    "sourceProposalFingerprint",
    "sourceBaseBindingFingerprint",
    "currentBaseBindingFingerprint",
    "successorIdentityFingerprint",
    "successorTransferFingerprint",
    "successorProposalFingerprint",
    "successorLifecycleFingerprint",
    "successorSidecarFingerprint",
    "successorBaseBindingFingerprint",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-successor-lineage-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  if (!P(e.reviewId) || !P(e.sourceReviewId) || ![
    e.rootFingerprint,
    e.sourceRootFingerprint,
    e.sourceHeadFingerprint,
    e.sourceReviewFingerprint,
    e.sourceTerminalEntryFingerprint,
    e.sourceTerminalSidecarFingerprint,
    e.sourceTerminalArtifactFingerprint,
    e.sourceTerminalLineageFingerprint,
    e.sourceHandoffFingerprint,
    e.sourceProposalFingerprint,
    e.sourceBaseBindingFingerprint,
    e.currentBaseBindingFingerprint,
    e.successorIdentityFingerprint,
    e.successorTransferFingerprint,
    e.successorProposalFingerprint,
    e.successorLifecycleFingerprint,
    e.successorSidecarFingerprint,
    e.successorBaseBindingFingerprint,
    e.fingerprint
  ].every(C) || !(e.sourceResolutionCommandFingerprint === null || C(e.sourceResolutionCommandFingerprint)) || !(e.sourceEntryFingerprint === null || C(e.sourceEntryFingerprint)))
    return Z("$");
  const t = e;
  return He(t, "successor-lineage", [
    t.rootFingerprint,
    t.sourceRootFingerprint,
    t.sourceHeadFingerprint,
    ...t.sourceEntryFingerprint ? [t.sourceEntryFingerprint] : [],
    t.sourceReviewFingerprint,
    t.sourceTerminalEntryFingerprint,
    t.sourceTerminalSidecarFingerprint,
    t.sourceTerminalArtifactFingerprint,
    t.sourceTerminalLineageFingerprint,
    t.sourceHandoffFingerprint,
    ...t.sourceResolutionCommandFingerprint ? [t.sourceResolutionCommandFingerprint] : [],
    t.sourceProposalFingerprint,
    t.sourceBaseBindingFingerprint,
    t.currentBaseBindingFingerprint,
    t.successorIdentityFingerprint,
    t.successorTransferFingerprint,
    t.successorProposalFingerprint,
    t.successorLifecycleFingerprint,
    t.successorSidecarFingerprint,
    t.successorBaseBindingFingerprint
  ]) ? c({
    status: "success",
    artifact: pt(t)
  }) : Z("$.fingerprint");
}, pn = (e) => {
  if (!ye(e, [
    "kind",
    "version",
    "sourceRootFingerprint",
    "sourceEntryFingerprint",
    "sourceProposalFingerprint",
    "sourceReviewFingerprint",
    "sourceDecisionFingerprint",
    "sourceBaseBindingFingerprint",
    "currentBaseBindingFingerprint",
    "survivingAnchorFingerprints",
    "operationIntentDigests",
    "latestSemanticSnapshotFingerprint",
    "regenerationHandoffFingerprint",
    "sourceTerminalSidecarFingerprint",
    "policyFingerprint",
    "admission",
    "admissionFingerprint",
    "nextProposalId",
    "nextVariantId",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-rebase-handoff-v1")
    return Z("$");
  if (!st(e)) return Z("$.version", "unsupported");
  const t = We(e.admission);
  if (t.status !== "success" || t.artifact.action !== "rebase" || t.artifact.fingerprint !== e.admissionFingerprint || t.artifact.commandFingerprint !== e.regenerationHandoffFingerprint || t.artifact.policyFingerprint !== e.policyFingerprint || !P(e.nextProposalId) || !P(e.nextVariantId) || !Array.isArray(e.survivingAnchorFingerprints) || e.survivingAnchorFingerprints.length > ae.maxAnchors || new Set(e.survivingAnchorFingerprints).size !== e.survivingAnchorFingerprints.length || !e.survivingAnchorFingerprints.every(C) || !Array.isArray(e.operationIntentDigests) || e.operationIntentDigests.length === 0 || e.operationIntentDigests.length > ae.maxArrayEntries || new Set(e.operationIntentDigests).size !== e.operationIntentDigests.length || !e.operationIntentDigests.every(C) || ![
    e.sourceRootFingerprint,
    e.sourceProposalFingerprint,
    e.sourceReviewFingerprint,
    e.sourceDecisionFingerprint,
    e.sourceBaseBindingFingerprint,
    e.currentBaseBindingFingerprint,
    e.latestSemanticSnapshotFingerprint,
    e.regenerationHandoffFingerprint,
    e.sourceTerminalSidecarFingerprint,
    e.policyFingerprint,
    e.admissionFingerprint,
    e.fingerprint
  ].every(C) || !(e.sourceEntryFingerprint === null || C(e.sourceEntryFingerprint)))
    return Z("$");
  const r = e;
  return He(r, "rebase-handoff", [
    r.sourceRootFingerprint,
    ...r.sourceEntryFingerprint ? [r.sourceEntryFingerprint] : [],
    r.sourceProposalFingerprint,
    r.sourceReviewFingerprint,
    r.sourceDecisionFingerprint,
    r.sourceBaseBindingFingerprint,
    r.currentBaseBindingFingerprint,
    ...r.survivingAnchorFingerprints,
    ...r.operationIntentDigests,
    r.latestSemanticSnapshotFingerprint,
    r.regenerationHandoffFingerprint,
    r.sourceTerminalSidecarFingerprint,
    r.policyFingerprint,
    r.admissionFingerprint
  ]) ? c({
    status: "success",
    artifact: pt(r)
  }) : Z("$.fingerprint");
}, fi = (e) => !ps(e) || typeof e.kind != "string" ? Z("$") : e.kind === "zx-ai-durable-review-root-v1" ? _r(e) : e.kind === "zx-ai-durable-review-entry-v1" ? dr(e) : e.kind === "zx-ai-durable-review-checkpoint-v1" ? ui(e) : e.kind === "zx-ai-collaboration-successor-lineage-v1" ? Dr(e) : Z("$.kind"), dl = (e) => {
  const t = pt(e);
  return JSON.stringify(t);
}, Rf = c({
  kind: "zx-ai-collaboration-historical-reader-v1",
  version: ne,
  mode: "audit-only",
  supportsLiveRestore: !1
}), kf = (e) => {
  if (ps(e) && typeof e.kind == "string" && [
    "zx-ai-durable-review-root-v1",
    "zx-ai-durable-review-entry-v1",
    "zx-ai-durable-review-checkpoint-v1"
  ].includes(e.kind) && e.version !== ne)
    return c({ status: "unsupported", liveRestoreAllowed: !1 });
  const t = fi(e);
  if (t.status !== "success")
    return c({ status: "invalid", liveRestoreAllowed: !1 });
  const r = t.artifact, i = r.kind === "zx-ai-durable-review-checkpoint-v1" || r.kind === "zx-ai-durable-review-entry-v1" && r.entryKind !== "decision" ? r.terminalHistoricalEnvelope : null;
  if (!i)
    return c({ status: "not-terminal", liveRestoreAllowed: !1 });
  let n;
  try {
    n = or({ mode: "historical", envelope: i });
  } catch {
    return c({ status: "invalid", liveRestoreAllowed: !1 });
  }
  return n.status !== "audit-success" ? c({ status: "invalid", liveRestoreAllowed: !1 }) : c({
    status: "audit-success",
    recordFingerprint: r.fingerprint,
    terminalArtifactFingerprint: i.closureFingerprint,
    auditFingerprint: n.fingerprint,
    liveRestoreAllowed: !1
  });
}, br = (e) => ce({
  code: e === "pending-authorization" ? "collaboration-authorization-unavailable" : e === "denied" ? "collaboration-denied" : "collaboration-admission-invalid",
  stage: "authorization",
  path: "$.admission",
  recovery: e === "pending-authorization" ? "retry-verification" : "reject"
}), On = (e) => {
  if (!P(e.principalRef) || !P(e.documentId) || ![
    "publish-root",
    "decision",
    "reject",
    "rebase",
    "resolve-conflict",
    "commit",
    "compact"
  ].includes(e.action) || ![
    e.commandFingerprint,
    e.artifactFingerprint,
    e.policyFingerprint,
    e.verifierEvidenceFingerprint
  ].every(C) || !Se(e.issuedAtLogicalTime) || !Se(e.expiresAtLogicalTime) || e.expiresAtLogicalTime < e.issuedAtLogicalTime)
    throw new TypeError("collaboration-admission-input-invalid");
  const t = {
    kind: "zx-ai-collaboration-admission-receipt-v1",
    version: ne,
    principalRef: e.principalRef,
    documentId: e.documentId,
    namespace: Ct,
    action: e.action,
    commandFingerprint: e.commandFingerprint,
    artifactFingerprint: e.artifactFingerprint,
    policyFingerprint: e.policyFingerprint,
    issuedAtLogicalTime: e.issuedAtLogicalTime,
    expiresAtLogicalTime: e.expiresAtLogicalTime,
    verifierEvidenceFingerprint: e.verifierEvidenceFingerprint
  };
  return c({
    ...t,
    fingerprint: B("admission", t)
  });
}, ll = (e) => ye(e, ["status"], ["receiptFingerprint"]) ? e.status === "verified" ? C(e.receiptFingerprint) && Object.keys(e).length === 2 ? {
  status: "verified",
  receiptFingerprint: e.receiptFingerprint
} : null : ["denied", "invalid", "unavailable"].includes(String(e.status)) && Object.keys(e).length === 1 ? { status: e.status } : null : null, no = async (e) => {
  const t = We(e.receipt);
  if (t.status !== "success")
    return c({
      status: "invalid",
      receipt: null,
      diagnostic: br("invalid")
    });
  let r;
  try {
    r = await (e.mode === "historical" ? e.port.verifyHistoricalAdmission : e.port.verifyAdmission)({
      receipt: t.artifact,
      expectedDocumentId: e.expectedDocumentId,
      expectedAction: e.expectedAction,
      expectedCommandFingerprint: e.expectedCommandFingerprint,
      expectedArtifactFingerprint: e.expectedArtifactFingerprint,
      expectedPolicyFingerprint: e.expectedPolicyFingerprint,
      logicalTime: e.logicalTime
    });
  } catch {
    return c({
      status: "pending-authorization",
      receipt: null,
      diagnostic: br("pending-authorization")
    });
  }
  const i = ll(r);
  if (!i)
    return c({
      status: "invalid",
      receipt: null,
      diagnostic: br("invalid")
    });
  if (i.status === "verified")
    return i.receiptFingerprint === t.artifact.fingerprint ? c({ status: "verified", receipt: t.artifact }) : c({
      status: "invalid",
      receipt: null,
      diagnostic: br("invalid")
    });
  const n = i.status === "unavailable" ? "pending-authorization" : i.status;
  return c({
    status: n,
    receipt: null,
    diagnostic: br(n)
  });
}, It = async (e) => no({ ...e, mode: "fresh" }), ki = async (e) => no({ ...e, mode: "historical" }), Wt = (e, t) => `${e}\0${t}`, Sf = (e) => {
  if (!P(e.documentId) || !C(e.policyFingerprint) || new Set(e.principals.map((p) => p.principalRef)).size !== e.principals.length || !e.principals.every(
    (p) => P(p.principalRef) && new Set(p.actions).size === p.actions.length && p.actions.every(
      (f) => [
        "publish-root",
        "decision",
        "reject",
        "rebase",
        "resolve-conflict",
        "commit",
        "compact"
      ].includes(f)
    )
  ) || !(e.historicallyAcceptedAdmissionFingerprints ?? []).every(
    C
  ) || !(e.historicallyAcceptedPolicyFingerprints ?? []).every(
    C
  ))
    throw new TypeError("collaboration-host-policy-input-invalid");
  const t = new Map(
    e.principals.map((p) => [
      p.principalRef,
      new Set(p.actions)
    ])
  ), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map();
  let n = !1, s = e.enumerationComplete ?? !0, o = e.policyFingerprint;
  const a = /* @__PURE__ */ new Set([
    e.policyFingerprint,
    ...e.historicallyAcceptedPolicyFingerprints ?? []
  ]), d = new Set(
    e.historicallyAcceptedAdmissionFingerprints ?? []
  ), l = e.supportsGlobalCommitReservation ?? !0, g = async (p, f) => {
    var I;
    if (n) return c({ status: "unavailable" });
    const m = We(p.receipt);
    if (m.status !== "success") return c({ status: "invalid" });
    const y = m.artifact;
    return p.expectedDocumentId !== e.documentId || y.documentId !== p.expectedDocumentId || y.action !== p.expectedAction || y.commandFingerprint !== p.expectedCommandFingerprint || y.artifactFingerprint !== p.expectedArtifactFingerprint || y.policyFingerprint !== p.expectedPolicyFingerprint || (f ? !a.has(p.expectedPolicyFingerprint) || p.expectedPolicyFingerprint !== o && !d.has(y.fingerprint) : p.expectedPolicyFingerprint !== o) ? c({ status: "invalid" }) : p.logicalTime < y.issuedAtLogicalTime || p.logicalTime > y.expiresAtLogicalTime || r.has(y.principalRef) || !((I = t.get(y.principalRef)) != null && I.has(y.action)) ? c({ status: "denied" }) : c({
      status: "verified",
      receiptFingerprint: y.fingerprint
    });
  };
  return {
    port: {
      verifyAdmission: (p) => g(p, !1),
      verifyHistoricalAdmission: (p) => g(p, !0),
      async recordAcceptedAdmission(p) {
        if (n) return "unavailable";
        const f = We(p.receipt);
        return f.status !== "success" || p.documentId !== e.documentId || f.artifact.documentId !== p.documentId || !P(p.reviewId) || !C(p.recordFingerprint) ? "denied" : d.has(f.artifact.fingerprint) ? "idempotent" : f.artifact.policyFingerprint !== o ? "denied" : (d.add(f.artifact.fingerprint), a.add(f.artifact.policyFingerprint), "recorded");
      },
      async verifyEnumeration(p) {
        if (n) return c({ status: "pending" });
        if (!s || p.documentId !== e.documentId || p.namespace !== Ct || !a.has(p.policyFingerprint) || !P(p.reviewId) || !C(p.stateVectorFingerprint) || !C(p.recordSetFingerprint))
          return c({
            status: s ? "invalid" : "pending"
          });
        const f = {
          kind: "zx-ai-collaboration-enumeration-proof-v1",
          version: ne,
          documentId: p.documentId,
          namespace: Ct,
          reviewId: p.reviewId,
          stateVectorFingerprint: p.stateVectorFingerprint,
          recordSetFingerprint: p.recordSetFingerprint,
          policyFingerprint: p.policyFingerprint,
          complete: !0
        }, m = c({
          ...f,
          fingerprint: B(
            "enumeration-proof",
            f,
            [
              f.stateVectorFingerprint,
              f.recordSetFingerprint,
              f.policyFingerprint
            ]
          )
        });
        return c({ status: "complete", proof: m });
      },
      async reserveCommit(p) {
        if (!l)
          return c({ status: "unsupported-host" });
        if (n) return c({ status: "unavailable" });
        if (p.documentId !== e.documentId || p.policyFingerprint !== o || !P(p.reviewId) || ![
          p.durableHeadFingerprint,
          p.stateVectorFingerprint,
          p.policyFingerprint
        ].every(C))
          return c({ status: "lost" });
        const f = Wt(p.documentId, p.reviewId);
        if (i.has(f)) return c({ status: "lost" });
        const m = {
          kind: "zx-ai-collaboration-commit-reservation-v1",
          version: ne,
          reservationId: B("reservation-id", p),
          documentId: p.documentId,
          reviewId: p.reviewId,
          durableHeadFingerprint: p.durableHeadFingerprint,
          stateVectorFingerprint: p.stateVectorFingerprint,
          policyFingerprint: p.policyFingerprint,
          status: "reserved"
        }, y = c({
          ...m,
          fingerprint: B(
            "commit-reservation",
            m,
            [
              m.durableHeadFingerprint,
              m.stateVectorFingerprint,
              m.policyFingerprint
            ]
          )
        });
        return i.set(f, { reservation: y, status: "reserved" }), c({ status: "reserved", reservation: y });
      },
      async releaseCommit(p) {
        const f = Wt(
          p.reservation.documentId,
          p.reservation.reviewId
        ), m = i.get(f);
        return !m || m.status !== "reserved" || m.reservation.fingerprint !== p.reservation.fingerprint ? !1 : (i.delete(f), !0);
      },
      async finalizeCommit(p) {
        if (!C(p.terminalEntryFingerprint))
          return !1;
        const f = i.get(
          Wt(p.reservation.documentId, p.reservation.reviewId)
        ), m = (f == null ? void 0 : f.status) === "incident" && C(p.incidentProofFingerprint) && f.incidentProofFingerprint === p.incidentProofFingerprint;
        return !f || f.status !== "reserved" && !m || f.reservation.fingerprint !== p.reservation.fingerprint ? !1 : (f.status = "terminal", !0);
      },
      async finalizeCommitIncident(p) {
        if (!C(p.proofFingerprint)) return !1;
        const f = i.get(
          Wt(p.reservation.documentId, p.reservation.reviewId)
        );
        return !f || f.status !== "reserved" || f.reservation.fingerprint !== p.reservation.fingerprint ? !1 : (f.status = "incident", f.incidentProofFingerprint = p.proofFingerprint, !0);
      },
      async verifyCommitFence(p) {
        if (n) return "unavailable";
        const f = i.get(Wt(p.documentId, p.reviewId));
        return (f == null ? void 0 : f.status) ?? "open";
      },
      async admitCompaction(p) {
        return n ? c({ status: "unavailable" }) : !e.compactionAllowed || !P(p.reviewId) || !C(p.terminalEntryFingerprint) || !C(p.prefixFingerprint) ? c({ status: "denied" }) : c({
          status: "admitted",
          admissionFingerprint: B(
            "compaction-admission",
            p,
            [p.terminalEntryFingerprint, p.prefixFingerprint]
          )
        });
      }
    },
    setUnavailable(p) {
      n = p;
    },
    setEnumerationComplete(p) {
      s = p;
    },
    setPolicyFingerprint(p) {
      if (!C(p))
        throw new TypeError("collaboration-policy-fingerprint-invalid");
      o = p, a.add(p);
    },
    revokePrincipal(p) {
      r.add(p);
    },
    restorePrincipal(p) {
      r.delete(p);
    },
    readFence(p, f) {
      var m;
      return ((m = i.get(Wt(p, f))) == null ? void 0 : m.status) ?? "open";
    },
    readAcceptedAdmissionFingerprints() {
      return Object.freeze([...d].sort());
    },
    readAcceptedPolicyFingerprints() {
      return Object.freeze([...a].sort());
    }
  };
}, et = (e, t, r) => ce({
  code: e,
  stage: e === "collaboration-input-invalid" ? "input" : "storage",
  path: t,
  count: r,
  recovery: e === "collaboration-resource-limit" ? "reject" : "resolve-conflict"
}), pl = (e) => ({
  kind: "zx-ai-durable-review-root-admission-artifact-v1",
  version: ne,
  documentId: e.baseBinding.documentId,
  reviewId: e.transfer.sidecar.identity.reviewId,
  sessionTransferFingerprint: e.transfer.fingerprint,
  proposalFingerprint: e.transfer.proposal.fingerprint,
  lifecycleFingerprint: e.transfer.lifecycle.fingerprint,
  initialSidecarFingerprint: e.transfer.sidecar.fingerprint,
  baseBindingFingerprint: e.baseBinding.fingerprint,
  creatorPrincipalRef: e.creatorPrincipalRef,
  policyFingerprint: e.baseBinding.policyRef.fingerprint
}), so = (e) => {
  const t = pl(e);
  return B(
    "durable-root-admission-artifact",
    t,
    [
      t.sessionTransferFingerprint,
      t.proposalFingerprint,
      t.lifecycleFingerprint,
      t.initialSidecarFingerprint,
      t.baseBindingFingerprint,
      t.policyFingerprint
    ]
  );
}, ul = (e) => {
  const t = Pt(e.transfer), r = De(e.baseBinding), i = We(e.admission);
  if (t.status !== "success" || r.status !== "success" || i.status !== "success" || !P(e.creatorPrincipalRef))
    return c({
      status: "failure",
      root: null,
      diagnostic: et("collaboration-input-invalid", "$")
    });
  const n = t.transfer, s = r.artifact, o = so(e);
  if (s.sessionTransferFingerprint !== n.fingerprint || s.handoffFingerprint !== n.receipt.fingerprint || s.sessionId !== n.receipt.sessionId || s.requestId !== n.receipt.requestId || s.attemptId !== n.receipt.attemptId || s.proposalFingerprint !== n.proposal.fingerprint || s.lifecycleFingerprint !== n.lifecycle.fingerprint || s.reviewId !== n.sidecar.identity.reviewId || s.sidecarFingerprint !== n.sidecar.fingerprint || i.artifact.action !== "publish-root" || i.artifact.namespace !== Ct || i.artifact.documentId !== s.documentId || i.artifact.principalRef !== e.creatorPrincipalRef || i.artifact.policyFingerprint !== s.policyRef.fingerprint || i.artifact.artifactFingerprint !== o)
    return c({
      status: "failure",
      root: null,
      diagnostic: et("collaboration-input-invalid", "$.binding")
    });
  const a = {
    kind: "zx-ai-durable-review-root-v1",
    version: ne,
    reviewId: n.sidecar.identity.reviewId,
    sessionTransferFingerprint: n.fingerprint,
    proposalFingerprint: n.proposal.fingerprint,
    lifecycleFingerprint: n.lifecycle.fingerprint,
    initialSidecarFingerprint: n.sidecar.fingerprint,
    initialSidecar: n.sidecar,
    baseBindingFingerprint: s.fingerprint,
    creatorPrincipalRef: e.creatorPrincipalRef,
    policyFingerprint: s.policyRef.fingerprint,
    admission: i.artifact,
    admissionFingerprint: i.artifact.fingerprint
  }, d = c({
    ...a,
    fingerprint: B("durable-root", a, [
      a.sessionTransferFingerprint,
      a.proposalFingerprint,
      a.initialSidecarFingerprint,
      a.baseBindingFingerprint,
      a.admissionFingerprint
    ])
  }), l = _r(d);
  return l.status === "success" ? c({
    status: "success",
    root: l.artifact,
    admissionArtifactFingerprint: o
  }) : c({
    status: "failure",
    root: null,
    diagnostic: et("collaboration-input-invalid", "$.root")
  });
}, fl = (e) => B("stored-record-value", e, [
  e.fingerprint
]), ft = (e) => {
  const t = fl(e);
  return e.kind === "zx-ai-durable-review-root-v1" ? `record/v1/root/${e.reviewId}/${e.fingerprint}/${t}` : e.kind === "zx-ai-durable-review-entry-v1" ? `record/v1/entry/${e.reviewId}/${e.rootFingerprint}/${e.commandId}/${e.priorEntryFingerprint ?? e.rootFingerprint}/${t}` : e.kind === "zx-ai-collaboration-successor-lineage-v1" ? `record/v1/lineage/${e.reviewId}/${e.rootFingerprint}/${e.sourceTerminalEntryFingerprint}/${t}` : `record/v1/checkpoint/${e.reviewId}/${e.rootFingerprint}/${e.terminalEntryFingerprint}/${t}`;
}, gl = (e) => B(
  "record-set",
  e.map((t) => ({
    storageKey: t.storageKey,
    valueFingerprint: B(
      "stored-record-value",
      t.value
    )
  }))
), un = (e, t) => {
  if (!P(t) || e.records.length > ae.maxRecordsPerReview)
    return c({
      status: "resource-limit",
      records: [],
      roots: [],
      diagnostic: et(
        "collaboration-resource-limit",
        "$.records",
        e.records.length
      )
    });
  const r = [...e.records].sort(
    (s, o) => s.storageKey.localeCompare(o.storageKey)
  );
  if (r.some(
    (s, o) => {
      var a;
      return s.storageKey !== ((a = e.records[o]) == null ? void 0 : a.storageKey) || o > 0 && s.storageKey === r[o - 1].storageKey || Fa(s.value) > ae.maxRecordBytes;
    }
  ) || gl(r) !== e.candidateSetDigest)
    return c({
      status: "storage-conflict",
      records: [],
      roots: [],
      diagnostic: et("collaboration-storage-conflict", "$.records")
    });
  const i = [];
  for (const s of r) {
    const o = fi(s.value);
    if (o.status !== "success" || o.artifact.reviewId !== t || ft(o.artifact) !== s.storageKey)
      return c({
        status: "storage-conflict",
        records: [],
        roots: [],
        diagnostic: et(
          "collaboration-storage-conflict",
          "$.records.storageKey"
        )
      });
    i.push(o.artifact);
  }
  const n = i.filter(
    (s) => s.kind === "zx-ai-durable-review-root-v1"
  );
  return n.length > 1 ? c({
    status: "storage-conflict",
    records: [],
    roots: [],
    diagnostic: et(
      "collaboration-identity-conflict",
      "$.records.root",
      n.length
    )
  }) : c({
    status: "success",
    records: i,
    roots: n,
    candidateSetFingerprint: e.candidateSetDigest
  });
}, Af = async (e, t, r) => {
  const i = ul(e);
  if (i.status !== "success") return i;
  if (t.documentId !== e.baseBinding.documentId)
    return c({
      status: "failure",
      root: null,
      diagnostic: et("collaboration-input-invalid", "$.documentId")
    });
  const n = await It({
    port: r.policy,
    receipt: i.root.admission,
    expectedDocumentId: e.baseBinding.documentId,
    expectedAction: "publish-root",
    expectedCommandFingerprint: i.root.admission.commandFingerprint,
    expectedArtifactFingerprint: i.admissionArtifactFingerprint,
    expectedPolicyFingerprint: i.root.policyFingerprint,
    logicalTime: r.logicalTime
  });
  if (n.status !== "verified")
    return c({
      status: "failure",
      root: null,
      diagnostic: n.diagnostic
    });
  const s = ft(i.root), o = await t.appendRecord({
    storageKey: s,
    value: i.root,
    originKind: "log"
  });
  if (o.status === "conflict")
    return c({
      status: "storage-conflict",
      root: null,
      diagnostic: et("collaboration-storage-conflict", "$.append")
    });
  if (!["appended", "idempotent"].includes(o.status))
    return c({
      status: "failure",
      root: null,
      diagnostic: et("collaboration-storage-conflict", "$.append")
    });
  const a = await t.enumerateRecords({
    documentId: t.documentId,
    reviewId: i.root.reviewId
  }), d = un(
    a,
    i.root.reviewId
  );
  return d.status !== "success" || d.roots.length !== 1 || !Ge(d.roots[0], i.root) ? c({
    status: "storage-conflict",
    root: null,
    diagnostic: et("collaboration-storage-conflict", "$.reread")
  }) : c({
    status: o.status === "appended" ? "published" : "idempotent",
    root: i.root,
    storageKey: s
  });
}, Ef = (e) => dl(e), Cf = async (e, t) => {
  let r;
  try {
    r = JSON.parse(e);
  } catch {
    return c({ status: "failure", recordCount: 0 });
  }
  if (!Array.isArray(r) || r.length > ae.maxRecordsPerReview)
    return c({ status: "failure", recordCount: 0 });
  const i = [];
  for (const n of r) {
    const s = fi(n);
    if (s.status !== "success")
      return c({ status: "failure", recordCount: 0 });
    i.push(pt(s.artifact));
  }
  for (const n of i) {
    const s = await t.appendRecord({
      storageKey: ft(n),
      value: n,
      originKind: "log"
    });
    if (!["appended", "idempotent"].includes(s.status))
      return c({ status: "failure", recordCount: 0 });
  }
  return c({ status: "success", recordCount: i.length });
}, Jt = (e, t) => ce({
  code: e === "post-dispatch-incident" ? "collaboration-post-dispatch-incident" : e === "pending-authorization" ? "collaboration-authorization-unavailable" : e === "review-conflict" ? "collaboration-review-conflict" : e === "rebase-required" ? "collaboration-rebase-required" : e === "unsupported-host" ? "collaboration-runtime-unsupported" : e === "denied" ? "collaboration-denied" : "collaboration-invariant-violation",
  stage: e === "pending-authorization" ? "authorization" : "commit",
  path: t,
  recovery: e === "post-dispatch-incident" ? "finalize-proof" : e === "rebase-required" ? "replan" : e === "review-conflict" ? "resolve-conflict" : e === "pending-authorization" ? "retry-verification" : "reject"
}), jt = (e, t) => c({
  status: e,
  receipt: null,
  terminalEntry: null,
  incidentProof: null,
  diagnostic: Jt(e, t)
}), oo = (e) => {
  var t, r;
  return ((t = e.graph.acceptedEntries.at(-1)) == null ? void 0 : t.resultingSidecar) ?? ((r = e.graph.root) == null ? void 0 : r.initialSidecar) ?? null;
}, ao = (e) => {
  const t = De(e.currentBinding), r = oo(e), i = e.graph.acceptedHeadFingerprint;
  if (t.status !== "success" || !r || !i || !e.graph.root || e.graph.status !== "accepted" || e.graph.forkEntryFingerprints.length !== 0 || e.graph.pendingEntryFingerprints.length !== 0 || e.graph.invalidEntryFingerprints.length !== 0 || !["reconciled", "idempotent"].includes(e.reconciled.status) || e.reconciled.sidecar.fingerprint !== r.fingerprint || !["unchanged", "replication-coordinate-changed"].includes(
    e.drift.disposition
  ) || t.artifact.reviewId !== e.graph.root.reviewId || t.artifact.documentId.length === 0 || !P(e.commandId))
    return null;
  const n = {
    kind: "zx-ai-collaboration-commit-command-v1",
    version: ne,
    commandId: e.commandId,
    documentId: t.artifact.documentId,
    reviewId: e.graph.root.reviewId,
    rootFingerprint: e.graph.root.fingerprint,
    durableHeadFingerprint: i,
    expectedReviewRevision: r.revision,
    expectedSidecarFingerprint: r.fingerprint,
    currentBindingFingerprint: t.artifact.fingerprint,
    currentDocumentFingerprint: t.artifact.documentFingerprint,
    currentStateVectorFingerprint: t.artifact.stateVector.fingerprint,
    driftFingerprint: e.drift.fingerprint,
    policyFingerprint: e.graph.root.policyFingerprint
  };
  return c({
    ...n,
    fingerprint: B("commit-command", n, [
      n.rootFingerprint,
      n.durableHeadFingerprint,
      n.expectedSidecarFingerprint,
      n.currentBindingFingerprint,
      n.currentStateVectorFingerprint,
      n.driftFingerprint,
      n.policyFingerprint
    ])
  });
}, co = (e) => B(
  "commit-admission-artifact",
  {
    kind: "zx-ai-collaboration-commit-admission-artifact-v1",
    version: ne,
    commandFingerprint: e.command.fingerprint,
    principalRef: e.principalRef
  },
  [e.command.fingerprint]
), lo = (e) => B(
  "commit-terminal-admission-artifact",
  {
    kind: "zx-ai-collaboration-commit-terminal-admission-artifact-v1",
    version: ne,
    commandFingerprint: e.command.fingerprint,
    principalRef: e.principalRef,
    priorSidecarFingerprint: e.priorSidecarFingerprint,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    dispatchAdmissionFingerprint: e.dispatchAdmissionFingerprint,
    commitReceiptFingerprint: e.commitReceiptFingerprint,
    terminalArtifactFingerprint: e.terminalArtifactFingerprint,
    reviewArtifactFingerprint: e.reviewArtifactFingerprint,
    proposalHistoricalArtifactFingerprint: e.proposalHistoricalArtifactFingerprint,
    terminalStatus: e.terminalStatus,
    logicalSequence: e.logicalSequence
  },
  [
    e.command.fingerprint,
    e.priorSidecarFingerprint,
    e.resultingSidecarFingerprint,
    e.dispatchAdmissionFingerprint,
    e.commitReceiptFingerprint,
    e.terminalArtifactFingerprint,
    e.reviewArtifactFingerprint,
    e.proposalHistoricalArtifactFingerprint
  ]
), Nn = (e) => {
  const t = ar(e, "state-vector");
  return B(
    "state-vector",
    {
      codec: "yjs-state-vector-v1",
      bytes: t
    },
    [t.fingerprint]
  );
}, Vi = (e) => {
  const t = {
    kind: "zx-ai-collaboration-commit-incident-proof-v1",
    version: ne,
    ...e
  };
  return c({
    ...t,
    fingerprint: B(
      "commit-incident-proof",
      t,
      [
        e.reservation.fingerprint,
        e.receipt.fingerprint,
        e.terminalEntry.fingerprint
      ]
    )
  });
}, ml = async (e) => {
  const t = ao(e);
  if (!t)
    return jt(
      e.graph.status === "review-conflict" ? "review-conflict" : "rebase-required",
      "$.authority"
    );
  if (!P(e.principalRef) || !Se(e.logicalSequence) || e.logicalSequence === 0 || e.adapter.documentId !== t.documentId || e.adapter.rootSharedType !== e.currentBinding.rootSharedType)
    return jt("pre-dispatch-failure", "$.input");
  const r = co({
    command: t,
    principalRef: e.principalRef
  }), i = await It({
    port: e.policy,
    receipt: e.admission,
    expectedDocumentId: t.documentId,
    expectedAction: "commit",
    expectedCommandFingerprint: t.fingerprint,
    expectedArtifactFingerprint: r,
    expectedPolicyFingerprint: t.policyFingerprint,
    logicalTime: e.logicalTime
  });
  if (i.status !== "verified")
    return jt(
      i.status === "pending-authorization" ? "pending-authorization" : i.status === "denied" ? "denied" : "pre-dispatch-failure",
      "$.admission"
    );
  const n = ai(
    e.currentBinding.stateVector.bytes,
    "state-vector"
  );
  if (n.status !== "success")
    return jt("pre-dispatch-failure", "$.stateVector");
  const s = await e.policy.reserveCommit({
    documentId: t.documentId,
    reviewId: t.reviewId,
    durableHeadFingerprint: t.durableHeadFingerprint,
    stateVectorFingerprint: t.currentStateVectorFingerprint,
    policyFingerprint: t.policyFingerprint
  });
  if (s.status !== "reserved")
    return jt(
      s.status === "unsupported-host" ? "unsupported-host" : s.status === "unavailable" ? "pending-authorization" : "commit-lost",
      "$.reservation"
    );
  const o = e.adapter.runContentCommit({
    expectedStateVector: n.bytes,
    run: e.runS4Commit
  });
  if (o.status !== "success" || !o.proof || !o.value)
    return o.dispatchStatus === "not-started" ? (await e.policy.releaseCommit({
      reservation: s.reservation
    }), jt(
      o.status === "unsupported-host" ? "unsupported-host" : "pre-dispatch-failure",
      "$.contentCommit"
    )) : (await e.policy.finalizeCommitIncident({
      reservation: s.reservation,
      proofFingerprint: B(
        "content-dispatch-incident",
        {
          reservationFingerprint: s.reservation.fingerprint,
          dispatchStatus: o.dispatchStatus,
          effectStatus: o.effectStatus,
          adapterStatus: o.status
        },
        [s.reservation.fingerprint]
      )
    }), c({
      status: "post-dispatch-incident",
      receipt: null,
      terminalEntry: null,
      incidentProof: null,
      diagnostic: Jt("post-dispatch-incident", "$.contentCommit")
    }));
  const a = o.value;
  if (a.status !== "committed") {
    if (a.status !== "post-dispatch-incident")
      return await e.policy.releaseCommit({ reservation: s.reservation }), jt("pre-dispatch-failure", "$.s4Commit");
    const E = B(
      "s4-post-dispatch-incident",
      {
        reservationFingerprint: s.reservation.fingerprint,
        sidecarFingerprint: a.sidecar.fingerprint
      },
      [s.reservation.fingerprint, a.sidecar.fingerprint]
    );
    return await e.policy.finalizeCommitIncident({
      reservation: s.reservation,
      proofFingerprint: E
    }), c({
      status: "post-dispatch-incident",
      receipt: null,
      terminalEntry: null,
      incidentProof: null,
      diagnostic: Jt("post-dispatch-incident", "$.s4Commit")
    });
  }
  const d = o.proof, l = Nn(
    d.beforeStateVector
  ), g = Nn(d.afterStateVector), u = ar(
    d.contentUpdate,
    "content-update"
  ), p = l === t.currentStateVectorFingerprint && a.receipt.beforeFingerprint === t.currentDocumentFingerprint && a.receipt.terminalSidecarFingerprint === a.sidecar.fingerprint && d.observedOriginExact && d.historyAfter === d.historyBefore + 1 && d.redoAfter === 0 && u.byteLength > 0, f = B(
    "observed-content-origin-proof",
    {
      observedOriginExact: d.observedOriginExact,
      beforeStateVectorFingerprint: l,
      afterStateVectorFingerprint: g,
      contentUpdateFingerprint: u.fingerprint
    },
    [l, g, u.fingerprint]
  ), m = B(
    "content-history-proof",
    {
      historyBefore: d.historyBefore,
      historyAfter: d.historyAfter,
      redoBefore: d.redoBefore,
      redoAfter: d.redoAfter,
      remoteHistoryDelta: d.remoteHistoryDelta
    }
  ), y = {
    kind: "zx-ai-collaboration-commit-receipt-v1",
    version: ne,
    reviewId: t.reviewId,
    durableHeadFingerprint: t.durableHeadFingerprint,
    s4CommittedReceiptFingerprint: a.receipt.fingerprint,
    terminalSidecarFingerprint: a.sidecar.fingerprint,
    beforeDocumentFingerprint: a.receipt.beforeFingerprint,
    afterDocumentFingerprint: a.receipt.afterFingerprint,
    beforeStateVectorFingerprint: l,
    afterStateVectorFingerprint: g,
    contentUpdateFingerprint: u.fingerprint,
    contentUpdateByteLength: u.byteLength,
    originKind: "ai-content",
    observedOriginProofFingerprint: f,
    historyProofFingerprint: m,
    admissionFingerprint: i.receipt.fingerprint,
    commitReservationFingerprint: s.reservation.fingerprint
  }, I = c({
    ...y,
    fingerprint: B(
      "commit-receipt",
      y,
      [
        y.durableHeadFingerprint,
        y.s4CommittedReceiptFingerprint,
        y.terminalSidecarFingerprint,
        y.beforeDocumentFingerprint,
        y.afterDocumentFingerprint,
        y.beforeStateVectorFingerprint,
        y.afterStateVectorFingerprint,
        y.contentUpdateFingerprint,
        y.observedOriginProofFingerprint,
        y.historyProofFingerprint,
        y.admissionFingerprint,
        y.commitReservationFingerprint
      ]
    )
  });
  let h;
  try {
    h = xa({
      sidecar: a.sidecar,
      proposalEnvelope: e.createProposalEnvelope(a)
    });
  } catch {
    h = null;
  }
  const v = oo(e), F = h ? lo({
    command: t,
    principalRef: e.principalRef,
    priorSidecarFingerprint: v.fingerprint,
    resultingSidecarFingerprint: a.sidecar.fingerprint,
    dispatchAdmissionFingerprint: i.receipt.fingerprint,
    commitReceiptFingerprint: I.fingerprint,
    terminalArtifactFingerprint: h.closureFingerprint,
    reviewArtifactFingerprint: h.reviewArtifact.fingerprint,
    proposalHistoricalArtifactFingerprint: h.reviewArtifact.proposalHistoricalArtifactFingerprint,
    terminalStatus: h.reviewArtifact.terminalStatus,
    logicalSequence: e.logicalSequence
  }) : null;
  let w = null;
  if (p && h && F)
    try {
      w = await e.authorizeTerminal({
        command: t,
        principalRef: e.principalRef,
        artifactFingerprint: F,
        resultingSidecar: a.sidecar,
        commitReceipt: I,
        historicalEnvelope: h,
        logicalTime: e.logicalTime
      });
    } catch {
      w = null;
    }
  const x = w ? await It({
    port: e.policy,
    receipt: w,
    expectedDocumentId: t.documentId,
    expectedAction: "commit",
    expectedCommandFingerprint: t.fingerprint,
    expectedArtifactFingerprint: F,
    expectedPolicyFingerprint: t.policyFingerprint,
    logicalTime: e.logicalTime
  }) : null, j = h && (x == null ? void 0 : x.status) === "verified" ? {
    kind: "zx-ai-durable-review-entry-v1",
    version: ne,
    reviewId: t.reviewId,
    rootFingerprint: t.rootFingerprint,
    commandId: t.commandId,
    entryKind: "commit",
    priorReviewRevision: v.revision,
    priorSidecarFingerprint: v.fingerprint,
    priorEntryFingerprint: t.durableHeadFingerprint,
    command: t,
    commandFingerprint: t.fingerprint,
    principalRef: e.principalRef,
    admission: x.receipt,
    resultingSidecar: a.sidecar,
    resultingSidecarFingerprint: a.sidecar.fingerprint,
    resultReceiptFingerprint: I.fingerprint,
    collaborationDispatchAdmission: i.receipt,
    collaborationCommitReceipt: I,
    terminalCurrentBaseBinding: null,
    terminalHistoricalEnvelope: h,
    terminalLineage: null,
    logicalSequence: e.logicalSequence
  } : null, _ = j ? c({
    ...j,
    fingerprint: B(
      "durable-entry",
      j,
      [
        j.rootFingerprint,
        j.priorEntryFingerprint,
        j.commandFingerprint,
        j.resultingSidecarFingerprint,
        j.admission.fingerprint
      ]
    )
  }) : null, G = _ ? dr(_) : null;
  if (!p || !_ || (G == null ? void 0 : G.status) !== "success") {
    const E = _ ? Vi({
      reservation: s.reservation,
      receipt: I,
      terminalEntry: _
    }) : null;
    return await e.policy.finalizeCommitIncident({
      reservation: s.reservation,
      proofFingerprint: (E == null ? void 0 : E.fingerprint) ?? B(
        "unfinalizable-content-proof",
        {
          reservationFingerprint: s.reservation.fingerprint,
          receiptFingerprint: I.fingerprint
        },
        [s.reservation.fingerprint, I.fingerprint]
      )
    }), c({
      status: "post-dispatch-incident",
      receipt: I,
      terminalEntry: _,
      incidentProof: E,
      diagnostic: Jt("post-dispatch-incident", "$.proof")
    });
  }
  const ie = Vi({
    reservation: s.reservation,
    receipt: I,
    terminalEntry: G.artifact
  }), O = await e.adapter.appendRecord({
    storageKey: ft(G.artifact),
    value: G.artifact,
    originKind: "log"
  });
  return ["appended", "idempotent"].includes(O.status) ? await e.policy.finalizeCommit({
    reservation: s.reservation,
    terminalEntryFingerprint: G.artifact.fingerprint
  }) ? c({
    status: "committed",
    receipt: I,
    terminalEntry: G.artifact,
    incidentProof: null
  }) : (await e.policy.finalizeCommitIncident({
    reservation: s.reservation,
    proofFingerprint: ie.fingerprint
  }), c({
    status: "post-dispatch-incident",
    receipt: I,
    terminalEntry: G.artifact,
    incidentProof: ie,
    diagnostic: Jt("post-dispatch-incident", "$.fenceFinalize")
  })) : (await e.policy.finalizeCommitIncident({
    reservation: s.reservation,
    proofFingerprint: ie.fingerprint
  }), c({
    status: "post-dispatch-incident",
    receipt: I,
    terminalEntry: G.artifact,
    incidentProof: ie,
    diagnostic: Jt("post-dispatch-incident", "$.metadataAppend")
  }));
}, qf = async (e) => {
  if (Vi({
    reservation: e.proof.reservation,
    receipt: e.proof.receipt,
    terminalEntry: e.proof.terminalEntry
  }).fingerprint !== e.proof.fingerprint || io(e.proof.receipt).status !== "success" || dr(e.proof.terminalEntry).status !== "success")
    return "invalid";
  const r = await e.policy.verifyCommitFence({
    documentId: e.proof.reservation.documentId,
    reviewId: e.proof.reservation.reviewId
  });
  if (r !== "incident" && r !== "reserved") return "invalid";
  const i = await e.adapter.appendRecord({
    storageKey: ft(
      e.proof.terminalEntry
    ),
    value: e.proof.terminalEntry,
    originKind: "log"
  });
  return ["appended", "idempotent"].includes(i.status) && await e.policy.finalizeCommit({
    reservation: e.proof.reservation,
    terminalEntryFingerprint: e.proof.terminalEntry.fingerprint,
    incidentProofFingerprint: e.proof.fingerprint
  }) ? "finalized" : "pending";
}, Fr = (e) => c({
  status: "failure",
  binding: null,
  diagnostic: ce({
    code: "collaboration-input-invalid",
    stage: "capture",
    path: e
  })
}), vl = () => {
  const e = {
    kind: "document-scope",
    localAnchor: null
  };
  return c({
    ...e,
    fingerprint: B("document-scope", e)
  });
}, hl = (e, t) => {
  const r = ar(
    t.captureRelativePosition(e),
    "relative-position"
  ), i = {
    kind: "selection-endpoint",
    blockId: e.blockId,
    semanticOffset: e.semanticOffset,
    affinity: e.affinity,
    relativePosition: r,
    capabilityFingerprint: e.capabilityFingerprint
  };
  return c({
    ...i,
    fingerprint: B("anchor", i, [
      r.fingerprint
    ])
  });
}, po = (e, t, r) => {
  const i = Pt(e.transfer);
  if (i.status !== "success") return Fr("$.transfer");
  const n = i.transfer;
  if (t.documentId !== e.documentId || t.rootSharedType !== e.rootSharedType || !P(e.documentId) || !P(e.rootSharedType) || !P(e.documentRevision) || !C(e.documentFingerprint) || !C(e.baseFingerprint) || !C(e.targetFingerprint) || !C(e.captureProofFingerprint) || !Se(e.capturedAtLogicalTime) || e.anchors.length > ae.maxAnchors || !e.stableBlockIds.every(P) || !e.anchors.every(
    (p) => P(p.blockId) && Se(p.semanticOffset) && C(p.capabilityFingerprint)
  ))
    return Fr("$");
  if (r === "proposal-base" && (n.proposal.base.fingerprint !== e.baseFingerprint || n.proposal.base.documentRevision !== e.documentRevision || n.proposal.base.targetFingerprint !== e.targetFingerprint) || n.sidecar.proposalBinding.baseFingerprint !== e.baseFingerprint || n.sidecar.proposalBinding.targetFingerprint !== e.targetFingerprint || n.sidecar.proposalBinding.proposalFingerprint !== n.proposal.fingerprint || n.sidecar.proposalBinding.lifecycleFingerprint !== n.lifecycle.fingerprint)
    return Fr("$.transfer");
  if (e.scopeKind === "document" ? e.anchors.length !== 0 : e.anchors.length === 0)
    return Fr("$.anchors");
  const s = ar(
    t.captureStateVector(),
    "state-vector"
  ), o = {
    codec: "yjs-state-vector-v1",
    bytes: s
  }, a = c({
    ...o,
    fingerprint: B(
      "state-vector",
      o,
      [s.fingerprint]
    )
  }), d = e.anchors.map((p) => hl(p, t)), l = {
    kind: "zx-ai-collaboration-base-binding-v1",
    version: ne,
    documentId: e.documentId,
    rootSharedType: e.rootSharedType,
    documentRevision: e.documentRevision,
    documentFingerprint: e.documentFingerprint,
    baseFingerprint: e.baseFingerprint,
    targetFingerprint: e.targetFingerprint,
    stableBlockIds: Er(e.stableBlockIds),
    anchors: d,
    documentScope: e.scopeKind === "document" ? vl() : null,
    stateVector: a,
    schemaRef: e.schemaRef,
    runtimeRef: e.runtimeRef,
    policyRef: e.policyRef,
    sessionId: n.receipt.sessionId,
    requestId: n.receipt.requestId,
    attemptId: n.receipt.attemptId,
    handoffFingerprint: n.receipt.fingerprint,
    sessionTransferFingerprint: n.fingerprint,
    proposalId: n.proposal.identity.proposalId,
    variantId: n.proposal.identity.variantId,
    proposalFingerprint: n.proposal.fingerprint,
    lifecycleFingerprint: n.lifecycle.fingerprint,
    reviewId: n.sidecar.identity.reviewId,
    sidecarFingerprint: n.sidecar.fingerprint,
    capturedAtLogicalTime: e.capturedAtLogicalTime,
    captureProofFingerprint: e.captureProofFingerprint
  }, g = c({
    ...l,
    fingerprint: B("base-binding", l, [
      a.fingerprint,
      ...d.map((p) => p.fingerprint)
    ])
  }), u = De(g);
  return u.status === "success" ? c({ status: "success", binding: u.artifact }) : Fr(u.diagnostic.path);
}, Tf = (e, t) => po(e, t, "proposal-base"), Bf = (e, t) => po(e, t, "current"), Pf = (e, t) => e.documentId === t.documentId && e.reviewId === t.reviewId && Ge(e, t) ? "idempotent" : "identity-conflict", uo = (e) => B(
  "checkpoint-prefix",
  e,
  e
), $f = (e) => {
  const t = ui(e.checkpoint);
  if (t.status !== "success") return null;
  const r = t.artifact;
  let i;
  try {
    i = or({
      mode: "historical",
      envelope: r.terminalHistoricalEnvelope
    });
  } catch {
    return null;
  }
  if (i.status !== "audit-success" || i.fingerprint !== r.auditHeadFingerprint)
    return null;
  const n = {
    kind: "zx-ai-collaboration-checkpoint-command-v1",
    version: ne,
    reviewId: r.reviewId,
    rootFingerprint: r.rootFingerprint,
    terminalEntryFingerprint: r.terminalEntryFingerprint,
    compactedPrefixFingerprints: r.compactedPrefixFingerprints,
    terminalArtifactFingerprint: r.terminalArtifactFingerprint,
    auditHeadFingerprint: r.auditHeadFingerprint,
    suffixBoundaryFingerprint: r.suffixBoundaryFingerprint,
    policyFingerprint: r.compactionAdmission.policyFingerprint
  }, s = B(
    "checkpoint-command",
    n,
    r.compactedPrefixFingerprints
  );
  return c({
    commandFingerprint: s,
    artifactFingerprint: B(
      "checkpoint-admission-artifact",
      { ...n, commandFingerprint: s },
      [...r.compactedPrefixFingerprints, s]
    ),
    compactedPrefixFingerprints: r.compactedPrefixFingerprints
  });
}, yl = (e, t) => ce({
  code: e === "pending-authorization" ? "collaboration-authorization-unavailable" : e === "denied" ? "collaboration-denied" : e === "storage-conflict" ? "collaboration-storage-conflict" : e === "conflict" ? "collaboration-review-conflict" : "collaboration-checkpoint-invalid",
  stage: e.includes("authorization") ? "authorization" : "checkpoint",
  path: t,
  recovery: e === "pending-authorization" ? "retry-verification" : e === "conflict" ? "resolve-conflict" : "reject"
}), xt = (e, t) => c({
  status: e,
  checkpoint: null,
  diagnostic: yl(e, t)
}), Il = async (e) => {
  if (!e.graph.root) return !1;
  const t = await e.adapter.enumerateRecords({
    documentId: e.documentId,
    reviewId: e.graph.root.reviewId
  }), r = un(
    t,
    e.graph.root.reviewId
  );
  if (r.status !== "success") return !1;
  const i = ar(
    t.stateVector,
    "state-vector"
  ), n = B(
    "enumerated-state-vector",
    i,
    [i.fingerprint]
  ), s = {
    documentId: e.documentId,
    namespace: Ct,
    reviewId: e.graph.root.reviewId,
    stateVectorFingerprint: n,
    recordSetFingerprint: r.candidateSetFingerprint,
    policyFingerprint: e.graph.root.policyFingerprint
  };
  let o;
  try {
    o = await e.policy.verifyEnumeration(s);
  } catch {
    return !1;
  }
  if (!ye(o, ["status"], ["proof"]) || o.status !== "complete" || !ye(o.proof, [
    "kind",
    "version",
    "documentId",
    "namespace",
    "reviewId",
    "stateVectorFingerprint",
    "recordSetFingerprint",
    "policyFingerprint",
    "complete",
    "fingerprint"
  ]))
    return !1;
  const a = {
    kind: o.proof.kind,
    version: o.proof.version,
    documentId: o.proof.documentId,
    namespace: o.proof.namespace,
    reviewId: o.proof.reviewId,
    stateVectorFingerprint: o.proof.stateVectorFingerprint,
    recordSetFingerprint: o.proof.recordSetFingerprint,
    policyFingerprint: o.proof.policyFingerprint,
    complete: o.proof.complete
  };
  if (o.proof.documentId !== s.documentId || o.proof.namespace !== s.namespace || o.proof.reviewId !== s.reviewId || o.proof.stateVectorFingerprint !== s.stateVectorFingerprint || o.proof.recordSetFingerprint !== s.recordSetFingerprint || o.proof.policyFingerprint !== s.policyFingerprint || o.proof.complete !== !0 || o.proof.fingerprint !== B("enumeration-proof", a, [
    s.stateVectorFingerprint,
    s.recordSetFingerprint,
    s.policyFingerprint
  ]))
    return !1;
  const d = r.records.filter(
    (g) => g.kind === "zx-ai-durable-review-entry-v1"
  );
  return r.records.filter(
    (g) => g.kind === "zx-ai-durable-review-checkpoint-v1"
  ).length === 0 && r.roots.length === 1 && r.roots[0].fingerprint === e.graph.root.fingerprint && d.length === e.graph.acceptedEntries.length && d.every(
    (g) => e.graph.acceptedEntries.findIndex(
      (u) => u.fingerprint === g.fingerprint
    ) >= 0
  ) && e.graph.acceptedEntries.every(
    (g, u) => u === 0 ? g.priorEntryFingerprint === null : g.priorEntryFingerprint === e.graph.acceptedEntries[u - 1].fingerprint
  );
}, fo = (e) => {
  const t = e.graph.acceptedEntries.at(-1);
  if (e.graph.status !== "accepted" || !e.graph.root || !t || !["commit", "reject", "rebase"].includes(t.entryKind) || t.terminalHistoricalEnvelope === null || e.graph.acceptedHeadFingerprint !== t.fingerprint || e.graph.forkEntryFingerprints.length !== 0 || e.graph.pendingEntryFingerprints.length !== 0 || e.graph.invalidEntryFingerprints.length !== 0 || e.suffixBoundaryFingerprint !== null && !C(e.suffixBoundaryFingerprint))
    return null;
  let r;
  try {
    r = or({
      mode: "historical",
      envelope: t.terminalHistoricalEnvelope
    });
  } catch {
    return null;
  }
  if (r.status !== "audit-success") return null;
  const i = [
    e.graph.root.fingerprint,
    ...e.graph.acceptedEntries.map((o) => o.fingerprint)
  ], n = {
    kind: "zx-ai-collaboration-checkpoint-command-v1",
    version: ne,
    reviewId: e.graph.root.reviewId,
    rootFingerprint: e.graph.root.fingerprint,
    terminalEntryFingerprint: t.fingerprint,
    compactedPrefixFingerprints: i,
    terminalArtifactFingerprint: t.terminalHistoricalEnvelope.closureFingerprint,
    auditHeadFingerprint: r.fingerprint,
    suffixBoundaryFingerprint: e.suffixBoundaryFingerprint,
    policyFingerprint: e.graph.root.policyFingerprint
  }, s = B(
    "checkpoint-command",
    n,
    i
  );
  return c({
    commandFingerprint: s,
    artifactFingerprint: B(
      "checkpoint-admission-artifact",
      { ...n, commandFingerprint: s },
      [...i, s]
    ),
    compactedPrefixFingerprints: i
  });
}, jf = async (e) => {
  const t = fo(e), r = e.graph.acceptedEntries.at(-1);
  if (!t || !r || !e.graph.root)
    return xt("not-terminal", "$.graph");
  const i = await It({
    port: e.policy,
    receipt: e.admission,
    expectedDocumentId: e.documentId,
    expectedAction: "compact",
    expectedCommandFingerprint: t.commandFingerprint,
    expectedArtifactFingerprint: t.artifactFingerprint,
    expectedPolicyFingerprint: e.graph.root.policyFingerprint,
    logicalTime: e.logicalTime
  });
  if (i.status !== "verified")
    return xt(
      i.status === "pending-authorization" ? "pending-authorization" : i.status === "denied" ? "denied" : "failure",
      "$.admission"
    );
  const n = await e.policy.admitCompaction({
    reviewId: e.graph.root.reviewId,
    terminalEntryFingerprint: r.fingerprint,
    prefixFingerprint: uo(
      t.compactedPrefixFingerprints
    )
  });
  if (n.status !== "admitted")
    return xt(
      n.status === "unavailable" ? "pending-authorization" : "denied",
      "$.hostCompactionAdmission"
    );
  if (!await Il(e))
    return xt("conflict", "$.checkpointFreeCompletePrefix");
  const s = r.terminalHistoricalEnvelope, o = or({ mode: "historical", envelope: s });
  if (o.status !== "audit-success") return xt("failure", "$.audit");
  const a = {
    kind: "zx-ai-durable-review-checkpoint-v1",
    version: ne,
    reviewId: e.graph.root.reviewId,
    rootFingerprint: e.graph.root.fingerprint,
    compactedPrefixFingerprints: t.compactedPrefixFingerprints,
    terminalEntryFingerprint: r.fingerprint,
    terminalArtifactFingerprint: s.closureFingerprint,
    terminalHistoricalEnvelope: s,
    auditHeadFingerprint: o.fingerprint,
    suffixBoundaryFingerprint: e.suffixBoundaryFingerprint,
    compactionAdmission: i.receipt,
    compactionAdmissionFingerprint: i.receipt.fingerprint,
    hostCompactionAdmissionFingerprint: n.admissionFingerprint
  }, d = c({
    ...a,
    fingerprint: B("checkpoint", a, [
      a.rootFingerprint,
      ...a.compactedPrefixFingerprints,
      a.terminalEntryFingerprint,
      a.terminalArtifactFingerprint,
      a.auditHeadFingerprint,
      a.compactionAdmissionFingerprint,
      a.hostCompactionAdmissionFingerprint
    ])
  }), l = ui(d);
  if (l.status !== "success") return xt("failure", "$.checkpoint");
  const g = await e.adapter.appendRecord({
    storageKey: ft(l.artifact),
    value: l.artifact,
    originKind: "log"
  });
  return g.status === "conflict" ? xt("storage-conflict", "$.append") : ["appended", "idempotent"].includes(g.status) ? c({
    status: g.status === "appended" ? "published" : "idempotent",
    checkpoint: l.artifact
  }) : xt("failure", "$.append");
}, bl = (e) => {
  const t = ui(e.checkpoint);
  if (t.status !== "success")
    return c({
      status: "invalid",
      auditRedundantFingerprints: [],
      incidentFingerprints: []
    });
  const r = new Set(t.artifact.compactedPrefixFingerprints), i = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
  for (const a of e.records) {
    const d = fi(a);
    if (d.status !== "success") continue;
    const l = d.artifact;
    l.reviewId === t.artifact.reviewId && (r.has(l.fingerprint) ? i.add(l.fingerprint) : l.kind !== "zx-ai-durable-review-checkpoint-v1" && n.add(l.fingerprint));
  }
  const s = [...i].sort(), o = [...n].sort();
  return c({
    status: o.length ? "incident" : "dominated",
    auditRedundantFingerprints: s,
    incidentFingerprints: o,
    fingerprint: B(
      "checkpoint-dominance",
      {
        checkpointFingerprint: t.artifact.fingerprint,
        auditRedundantFingerprints: s,
        incidentFingerprints: o
      },
      [
        t.artifact.fingerprint,
        ...s,
        ...o
      ]
    )
  });
}, Si = (e, t) => c({
  status: e,
  prepared: null,
  diagnostic: ce({
    code: e === "conflict" ? "collaboration-review-conflict" : "collaboration-input-invalid",
    stage: "reconcile",
    path: t,
    recovery: e === "conflict" ? "resolve-conflict" : "reject"
  })
}), go = (e) => B("review-command", e, [
  e.expectedSidecarFingerprint,
  e.expectedProposalFingerprint,
  e.expectedLifecycleFingerprint,
  e.expectedPolicyFingerprint
]), Fl = (e) => ({
  kind: "zx-ai-durable-review-entry-admission-artifact-v1",
  version: ne,
  entryKind: "decision",
  ...e
}), mo = (e) => {
  const t = Fl(e);
  return B(
    "durable-entry-admission-artifact",
    t,
    [
      t.rootFingerprint,
      t.priorEntryFingerprint ?? t.rootFingerprint,
      t.commandFingerprint,
      t.priorSidecarFingerprint,
      t.resultingSidecarFingerprint,
      t.admissionPolicyFingerprint
    ]
  );
}, vo = (e) => {
  const t = _r(e.root);
  if (t.status !== "success" || !P(e.principalRef) || !Se(e.logicalSequence) || e.logicalSequence === 0 || e.previousSidecar.identity.reviewId !== e.root.reviewId || e.previousSidecar.revision !== e.command.expectedRevision || e.previousSidecar.fingerprint !== e.command.expectedSidecarFingerprint)
    return Si("failure", "$");
  const r = ad({
    sidecar: e.previousSidecar,
    command: e.command
  });
  if (r.status !== "candidate")
    return Si(
      r.status === "conflict" ? "conflict" : "failure",
      "$.command"
    );
  const i = go(e.command), n = e.admissionPolicyFingerprint ?? e.root.policyFingerprint;
  if (!C(n))
    return Si("failure", "$.admissionPolicyFingerprint");
  const s = {
    rootFingerprint: e.root.fingerprint,
    reviewId: e.root.reviewId,
    commandId: e.command.commandId,
    commandFingerprint: i,
    priorReviewRevision: e.previousSidecar.revision,
    priorSidecarFingerprint: e.previousSidecar.fingerprint,
    priorEntryFingerprint: e.priorEntryFingerprint,
    principalRef: e.principalRef,
    resultingSidecarFingerprint: r.sidecar.fingerprint,
    logicalSequence: e.logicalSequence,
    admissionPolicyFingerprint: n
  };
  return c({
    status: "candidate",
    prepared: {
      kind: "zx-ai-prepared-durable-review-decision-entry-v1",
      root: t.artifact,
      previousSidecar: e.previousSidecar,
      priorEntryFingerprint: e.priorEntryFingerprint,
      command: e.command,
      commandFingerprint: i,
      principalRef: e.principalRef,
      resultingSidecar: r.sidecar,
      logicalSequence: e.logicalSequence,
      admissionPolicyFingerprint: n,
      admissionArtifactFingerprint: mo(s)
    }
  });
}, ho = (e, t) => {
  const r = _r(e.root), i = We(t), n = dn({
    previous: e.previousSidecar,
    command: e.command,
    candidate: e.resultingSidecar
  });
  if (r.status !== "success" || i.status !== "success" || n.status !== "verified" || i.artifact.action !== "decision" || i.artifact.principalRef !== e.principalRef || i.artifact.commandFingerprint !== e.commandFingerprint || i.artifact.artifactFingerprint !== e.admissionArtifactFingerprint || i.artifact.policyFingerprint !== e.admissionPolicyFingerprint || i.artifact.documentId !== e.root.admission.documentId)
    return c({
      status: "failure",
      entry: null,
      diagnostic: ce({
        code: "collaboration-input-invalid",
        stage: "reconcile",
        path: "$.admission",
        recovery: "reject"
      })
    });
  const s = {
    kind: "zx-ai-durable-review-entry-v1",
    version: ne,
    reviewId: e.root.reviewId,
    rootFingerprint: e.root.fingerprint,
    commandId: e.command.commandId,
    entryKind: "decision",
    priorReviewRevision: e.previousSidecar.revision,
    priorSidecarFingerprint: e.previousSidecar.fingerprint,
    priorEntryFingerprint: e.priorEntryFingerprint,
    command: e.command,
    commandFingerprint: e.commandFingerprint,
    principalRef: e.principalRef,
    admission: i.artifact,
    resultingSidecar: e.resultingSidecar,
    resultingSidecarFingerprint: e.resultingSidecar.fingerprint,
    resultReceiptFingerprint: null,
    collaborationDispatchAdmission: null,
    collaborationCommitReceipt: null,
    terminalCurrentBaseBinding: null,
    terminalHistoricalEnvelope: null,
    terminalLineage: null,
    logicalSequence: e.logicalSequence
  }, o = c({
    ...s,
    fingerprint: B("durable-entry", s, [
      s.rootFingerprint,
      s.priorEntryFingerprint ?? s.rootFingerprint,
      s.commandFingerprint,
      s.resultingSidecarFingerprint,
      s.admission.fingerprint
    ])
  }), a = dr(o);
  return a.status === "success" ? c({ status: "success", entry: a.artifact }) : c({
    status: "failure",
    entry: null,
    diagnostic: ce({
      code: "collaboration-artifact-invalid",
      stage: "codec",
      path: "$.entry",
      recovery: "reject"
    })
  });
}, Ai = (e, t) => c({
  status: e,
  entry: null,
  diagnostic: ce({
    code: e === "pending-authorization" ? "collaboration-authorization-unavailable" : e === "denied" ? "collaboration-denied" : e === "storage-conflict" ? "collaboration-storage-conflict" : "collaboration-invariant-violation",
    stage: e === "pending-authorization" || e === "denied" ? "authorization" : "reconcile",
    path: t,
    recovery: e === "pending-authorization" ? "retry-verification" : e === "storage-conflict" ? "resolve-conflict" : "reject"
  })
}), xl = (e) => {
  const t = {
    kind: "zx-ai-collaboration-terminal-lineage-v1",
    version: ne,
    ...e,
    preservedBranchFingerprints: [...e.preservedBranchFingerprints].sort()
  };
  return c({
    ...t,
    fingerprint: B(
      "terminal-lineage",
      t,
      [
        t.sourceRootFingerprint,
        t.sourceHeadFingerprint,
        t.sourcePredecessorFingerprint,
        ...t.sourceHandoffFingerprint ? [t.sourceHandoffFingerprint] : [],
        ...t.successorIdentityFingerprint ? [t.successorIdentityFingerprint] : [],
        ...t.successorRootFingerprint ? [t.successorRootFingerprint] : [],
        ...t.currentBaseBindingFingerprint ? [t.currentBaseBindingFingerprint] : [],
        ...t.resolutionCommandFingerprint ? [t.resolutionCommandFingerprint] : [],
        ...t.preservedBranchFingerprints,
        t.terminalArtifactFingerprint
      ]
    )
  });
}, yo = (e) => {
  var r, i, n, s;
  if (!e.terminalLineage) return null;
  const t = {
    kind: "zx-ai-collaboration-terminal-entry-admission-artifact-v1",
    version: ne,
    rootFingerprint: e.rootFingerprint,
    commandFingerprint: e.commandFingerprint,
    priorSidecarFingerprint: e.priorSidecarFingerprint,
    resultingSidecarFingerprint: e.resultingSidecarFingerprint,
    terminalArtifactFingerprint: ((r = e.terminalHistoricalEnvelope) == null ? void 0 : r.closureFingerprint) ?? null,
    reviewArtifactFingerprint: ((i = e.terminalHistoricalEnvelope) == null ? void 0 : i.reviewArtifact.fingerprint) ?? null,
    proposalHistoricalArtifactFingerprint: ((n = e.terminalHistoricalEnvelope) == null ? void 0 : n.reviewArtifact.proposalHistoricalArtifactFingerprint) ?? null,
    terminalStatus: ((s = e.terminalHistoricalEnvelope) == null ? void 0 : s.reviewArtifact.terminalStatus) ?? null,
    lineageFingerprint: e.terminalLineage.fingerprint,
    admissionPolicyFingerprint: e.admission.policyFingerprint
  };
  return B(
    "terminal-entry-admission-artifact",
    t,
    [
      t.rootFingerprint,
      t.commandFingerprint,
      t.priorSidecarFingerprint,
      t.resultingSidecarFingerprint,
      ...t.terminalArtifactFingerprint ? [t.terminalArtifactFingerprint] : [],
      ...t.reviewArtifactFingerprint ? [t.reviewArtifactFingerprint] : [],
      ...t.proposalHistoricalArtifactFingerprint ? [t.proposalHistoricalArtifactFingerprint] : [],
      t.lineageFingerprint,
      t.admissionPolicyFingerprint
    ]
  );
}, Df = (e) => {
  var f, m;
  const t = e.graph.root, r = e.entryKind === "conflict-resolution", i = ((f = e.graph.acceptedEntries.at(-1)) == null ? void 0 : f.resultingSidecar) ?? (t == null ? void 0 : t.initialSidecar), n = ((m = e.graph.acceptedEntries.at(-1)) == null ? void 0 : m.fingerprint) ?? (t == null ? void 0 : t.fingerprint), s = [
    ...e.preservedBranchFingerprints
  ].sort(), o = e.resolutionCommand ?? null, a = e.currentBaseBinding ?? null, d = e.successorRootFingerprint ?? null;
  if (!t || !i || !n || (r ? e.graph.status !== "review-conflict" || s.length < 2 || JSON.stringify(s) !== JSON.stringify([...e.graph.forkEntryFingerprints].sort()) : e.graph.status !== "accepted" || e.graph.forkEntryFingerprints.length !== 0 || e.graph.pendingEntryFingerprints.length !== 0 || s.length !== 0) || s.length > ae.maxBranchRefs || !P(e.commandId) || !P(e.principalRef) || !Se(e.logicalSequence) || e.logicalSequence === 0 || !C(e.admissionPolicyFingerprint) || e.resultingSidecar.identity.reviewId !== t.reviewId || e.resultingSidecar.revision !== i.revision + 1 || (e.entryKind === "reject" ? e.resultingSidecar.status !== "rejected" || e.sourceHandoffFingerprint !== null || e.successorIdentityFingerprint !== null || d !== null || o !== null || a !== null : e.resultingSidecar.status !== "superseded" || !C(e.sourceHandoffFingerprint) || !C(e.successorIdentityFingerprint) || !C(d)) || (r ? o === null || a === null || o.commandId !== e.commandId || o.reviewId !== t.reviewId || o.sourceGraphFingerprint !== e.graph.fingerprint || o.sourceRootFingerprint !== t.fingerprint || o.sourcePredecessorFingerprint !== n || o.currentBaseBindingFingerprint !== a.fingerprint || o.regenerationHandoffFingerprint !== e.sourceHandoffFingerprint || o.policyFingerprint !== e.admissionPolicyFingerprint || JSON.stringify(o.forkEntryFingerprints) !== JSON.stringify(s) : o !== null || a !== null))
    return null;
  const l = xl({
    entryKind: e.entryKind,
    sourceRootFingerprint: t.fingerprint,
    sourceHeadFingerprint: n,
    sourcePredecessorFingerprint: n,
    sourceHandoffFingerprint: e.sourceHandoffFingerprint,
    successorIdentityFingerprint: e.successorIdentityFingerprint,
    successorRootFingerprint: d,
    currentBaseBindingFingerprint: (a == null ? void 0 : a.fingerprint) ?? null,
    resolutionCommandFingerprint: (o == null ? void 0 : o.fingerprint) ?? null,
    preservedBranchFingerprints: s,
    terminalArtifactFingerprint: e.terminalHistoricalEnvelope.closureFingerprint
  }), g = {
    entryKind: e.entryKind,
    commandId: e.commandId,
    reviewId: t.reviewId,
    lineageFingerprint: l.fingerprint
  }, u = (o == null ? void 0 : o.fingerprint) ?? B("terminal-command", g, [
    l.fingerprint
  ]), p = yo({
    rootFingerprint: t.fingerprint,
    commandFingerprint: u,
    priorSidecarFingerprint: i.fingerprint,
    resultingSidecarFingerprint: e.resultingSidecar.fingerprint,
    terminalHistoricalEnvelope: e.terminalHistoricalEnvelope,
    terminalLineage: l,
    admission: { policyFingerprint: e.admissionPolicyFingerprint }
  });
  return c({
    graph: e.graph,
    entryKind: e.entryKind,
    commandId: e.commandId,
    principalRef: e.principalRef,
    sourceSidecar: i,
    resultingSidecar: e.resultingSidecar,
    terminalHistoricalEnvelope: e.terminalHistoricalEnvelope,
    terminalLineage: l,
    resolutionCommand: o,
    currentBaseBinding: a,
    logicalSequence: e.logicalSequence,
    commandFingerprint: u,
    admissionPolicyFingerprint: e.admissionPolicyFingerprint,
    admissionArtifactFingerprint: p
  });
}, zf = (e, t) => {
  var a;
  const r = e.graph.root, i = e.entryKind === "conflict-resolution", n = We(t);
  if (!r || n.status !== "success" || n.artifact.principalRef !== e.principalRef || n.artifact.action !== (i ? "resolve-conflict" : e.entryKind) || n.artifact.commandFingerprint !== e.commandFingerprint || n.artifact.artifactFingerprint !== e.admissionArtifactFingerprint || n.artifact.policyFingerprint !== e.admissionPolicyFingerprint || n.artifact.documentId !== r.admission.documentId)
    return null;
  const s = {
    kind: "zx-ai-durable-review-entry-v1",
    version: ne,
    reviewId: r.reviewId,
    rootFingerprint: r.fingerprint,
    commandId: e.commandId,
    entryKind: e.entryKind,
    priorReviewRevision: e.sourceSidecar.revision,
    priorSidecarFingerprint: e.sourceSidecar.fingerprint,
    priorEntryFingerprint: ((a = e.graph.acceptedEntries.at(-1)) == null ? void 0 : a.fingerprint) ?? null,
    command: e.resolutionCommand,
    commandFingerprint: e.commandFingerprint,
    principalRef: e.principalRef,
    admission: n.artifact,
    resultingSidecar: e.resultingSidecar,
    resultingSidecarFingerprint: e.resultingSidecar.fingerprint,
    resultReceiptFingerprint: e.terminalLineage.fingerprint,
    collaborationDispatchAdmission: null,
    collaborationCommitReceipt: null,
    terminalCurrentBaseBinding: e.currentBaseBinding,
    terminalHistoricalEnvelope: e.terminalHistoricalEnvelope,
    terminalLineage: e.terminalLineage,
    logicalSequence: e.logicalSequence
  }, o = c({
    ...s,
    fingerprint: B("durable-entry", s, [
      s.rootFingerprint,
      s.priorEntryFingerprint ?? s.rootFingerprint,
      s.commandFingerprint,
      s.resultingSidecarFingerprint,
      s.admission.fingerprint
    ])
  });
  return dr(o).status === "success" ? c({
    entry: o,
    admissionArtifactFingerprint: e.admissionArtifactFingerprint
  }) : null;
}, Of = async (e) => {
  const t = e.prepared.entry, r = await It({
    port: e.policy,
    receipt: t.admission,
    expectedDocumentId: t.admission.documentId,
    expectedAction: t.entryKind === "conflict-resolution" ? "resolve-conflict" : t.entryKind,
    expectedCommandFingerprint: t.commandFingerprint,
    expectedArtifactFingerprint: e.prepared.admissionArtifactFingerprint,
    expectedPolicyFingerprint: t.admission.policyFingerprint,
    logicalTime: e.logicalTime
  });
  if (r.status !== "verified")
    return Ai(
      r.status === "pending-authorization" ? "pending-authorization" : r.status === "denied" ? "denied" : "failure",
      "$.admission"
    );
  const i = await e.adapter.appendRecord({
    storageKey: ft(t),
    value: t,
    originKind: "log"
  });
  return i.status === "conflict" ? Ai("storage-conflict", "$.append") : ["appended", "idempotent"].includes(i.status) ? c({
    status: i.status === "appended" ? "published" : "idempotent",
    entry: t
  }) : Ai("failure", "$.append");
}, Ei = async (e) => {
  try {
    const t = await e.policy.recordAcceptedAdmission({
      receipt: e.record.admission,
      documentId: e.documentId,
      reviewId: e.reviewId,
      recordFingerprint: e.record.fingerprint
    });
    return t === "recorded" || t === "idempotent" ? "accepted" : t === "unavailable" ? "pending" : "invalid";
  } catch {
    return "pending";
  }
}, ve = (e, t, r) => ce({
  code: e,
  stage: e === "collaboration-storage-conflict" ? "storage" : e.includes("admission") || e.includes("denied") || e.includes("authorization") ? "authorization" : "graph",
  path: t,
  commandRef: r == null ? void 0 : r.commandId,
  reviewRef: r == null ? void 0 : r.reviewId,
  recovery: e === "collaboration-authorization-unavailable" || e === "collaboration-pending-sync" ? "retry-verification" : e === "collaboration-pending-predecessor" ? "reconnect" : e === "collaboration-review-conflict" ? "resolve-conflict" : "reject"
}), wl = (e, t) => {
  if (!ye(e, [
    "kind",
    "version",
    "documentId",
    "namespace",
    "reviewId",
    "stateVectorFingerprint",
    "recordSetFingerprint",
    "policyFingerprint",
    "complete",
    "fingerprint"
  ]) || e.kind !== "zx-ai-collaboration-enumeration-proof-v1" || e.version !== "1.0.0" || e.namespace !== Ct || e.complete !== !0 || e.documentId !== t.documentId || e.reviewId !== t.reviewId || e.stateVectorFingerprint !== t.stateVectorFingerprint || e.recordSetFingerprint !== t.recordSetFingerprint || e.policyFingerprint !== t.policyFingerprint || !C(e.fingerprint))
    return !1;
  const r = {
    kind: e.kind,
    version: e.version,
    documentId: e.documentId,
    namespace: e.namespace,
    reviewId: e.reviewId,
    stateVectorFingerprint: e.stateVectorFingerprint,
    recordSetFingerprint: e.recordSetFingerprint,
    policyFingerprint: e.policyFingerprint,
    complete: e.complete
  };
  return e.fingerprint === B("enumeration-proof", r, [
    t.stateVectorFingerprint,
    t.recordSetFingerprint,
    t.policyFingerprint
  ]);
}, Fe = (e) => {
  var d, l, g, u, p, f, m, y, I, h, v;
  const t = Math.max(
    ((d = e.acceptedEntries) == null ? void 0 : d.length) ?? 0,
    ((l = e.forkEntryFingerprints) == null ? void 0 : l.length) ?? 0,
    ((g = e.pendingEntryFingerprints) == null ? void 0 : g.length) ?? 0,
    ((u = e.invalidEntryFingerprints) == null ? void 0 : u.length) ?? 0,
    ((p = e.diagnostics) == null ? void 0 : p.length) ?? 0
  );
  if ((((f = e.forkEntryFingerprints) == null ? void 0 : f.length) ?? 0) > ae.maxBranchRefs || (((m = e.pendingEntryFingerprints) == null ? void 0 : m.length) ?? 0) > ae.maxBranchRefs || (((y = e.invalidEntryFingerprints) == null ? void 0 : y.length) ?? 0) > ae.maxBranchRefs || (((I = e.diagnostics) == null ? void 0 : I.length) ?? 0) > ae.maxDiagnostics) {
    const F = [
      ce({
        code: "collaboration-resource-limit",
        stage: "graph",
        path: "$.graphProjection",
        count: t,
        recovery: "reject"
      })
    ], w = {
      status: "invalid",
      rootFingerprint: ((h = e.root) == null ? void 0 : h.fingerprint) ?? null,
      acceptedEntryFingerprints: [],
      acceptedHeadFingerprint: null,
      forkEntryFingerprints: [],
      pendingEntryFingerprints: [],
      invalidEntryFingerprints: [],
      diagnostics: F
    };
    return c({
      status: "invalid",
      root: e.root,
      acceptedEntries: [],
      acceptedHeadFingerprint: null,
      forkEntryFingerprints: [],
      pendingEntryFingerprints: [],
      invalidEntryFingerprints: [],
      diagnostics: F,
      fingerprint: B(
        "candidate-graph",
        w,
        w.rootFingerprint ? [w.rootFingerprint] : []
      )
    });
  }
  const r = [...e.acceptedEntries ?? []], i = [...e.forkEntryFingerprints ?? []].sort(), n = [
    ...e.pendingEntryFingerprints ?? []
  ].sort(), s = [
    ...e.invalidEntryFingerprints ?? []
  ].sort(), o = [...e.diagnostics ?? []].sort(
    (F, w) => `${F.code}\0${F.path}\0${F.commandRef ?? ""}`.localeCompare(
      `${w.code}\0${w.path}\0${w.commandRef ?? ""}`
    )
  ), a = {
    status: e.status,
    rootFingerprint: ((v = e.root) == null ? void 0 : v.fingerprint) ?? null,
    acceptedEntryFingerprints: r.map(
      (F) => F.fingerprint
    ),
    acceptedHeadFingerprint: e.acceptedHeadFingerprint ?? null,
    forkEntryFingerprints: i,
    pendingEntryFingerprints: n,
    invalidEntryFingerprints: s,
    diagnostics: o
  };
  return c({
    status: e.status,
    root: e.root,
    acceptedEntries: r,
    acceptedHeadFingerprint: a.acceptedHeadFingerprint,
    forkEntryFingerprints: i,
    pendingEntryFingerprints: n,
    invalidEntryFingerprints: s,
    diagnostics: o,
    fingerprint: B("candidate-graph", a, [
      ...a.rootFingerprint ? [a.rootFingerprint] : [],
      ...a.acceptedEntryFingerprints,
      ...i,
      ...n,
      ...s
    ])
  });
}, Rl = (e) => {
  const t = ar(e, "state-vector");
  return B("enumerated-state-vector", t, [
    t.fingerprint
  ]);
}, fn = async (e) => {
  var Oe, lr, Ne, Lr, Fn;
  const t = Pt(e.transfer), r = De(e.baseBinding);
  if (t.status !== "success" || r.status !== "success")
    return Fe({
      status: "invalid",
      root: null,
      diagnostics: [
        ve("collaboration-invariant-violation", "$.bindings")
      ]
    });
  const i = t.transfer.sidecar.identity.reviewId, n = un(
    e.enumeration,
    i
  );
  if (n.status !== "success")
    return Fe({
      status: "storage-conflict",
      root: null,
      diagnostics: [
        ve("collaboration-storage-conflict", "$.enumeration")
      ]
    });
  const s = {
    documentId: r.artifact.documentId,
    reviewId: i,
    stateVectorFingerprint: Rl(
      e.enumeration.stateVector
    ),
    recordSetFingerprint: n.candidateSetFingerprint,
    policyFingerprint: r.artifact.policyRef.fingerprint
  };
  let o;
  try {
    o = await e.policy.verifyEnumeration({
      ...s,
      namespace: Ct
    });
  } catch {
    o = { status: "pending" };
  }
  if (!ye(o, ["status"], ["proof"]) || o.status !== "complete" || !wl(o.proof, s))
    return Fe({
      status: "pending",
      root: n.roots[0] ?? null,
      pendingEntryFingerprints: n.records.filter(
        (A) => A.kind === "zx-ai-durable-review-entry-v1"
      ).map((A) => A.fingerprint),
      diagnostics: [
        ve("collaboration-pending-sync", "$.enumerationProof")
      ]
    });
  const a = n.roots[0] ?? null;
  if (!a)
    return Fe({
      status: "pending",
      root: null,
      diagnostics: [ve("collaboration-pending-sync", "$.root")]
    });
  if (a.sessionTransferFingerprint !== t.transfer.fingerprint || a.proposalFingerprint !== t.transfer.proposal.fingerprint || a.lifecycleFingerprint !== t.transfer.lifecycle.fingerprint || a.initialSidecarFingerprint !== t.transfer.sidecar.fingerprint || a.baseBindingFingerprint !== r.artifact.fingerprint || r.artifact.reviewId !== a.reviewId)
    return Fe({
      status: "invalid",
      root: a,
      diagnostics: [
        ve("collaboration-invariant-violation", "$.root.bindings")
      ]
    });
  const d = so({
    transfer: t.transfer,
    baseBinding: r.artifact,
    creatorPrincipalRef: a.creatorPrincipalRef
  }), l = B(
    "publish-root-command",
    {
      documentId: r.artifact.documentId,
      reviewId: a.reviewId
    }
  ), g = await ki({
    port: e.policy,
    receipt: a.admission,
    expectedDocumentId: r.artifact.documentId,
    expectedAction: "publish-root",
    expectedCommandFingerprint: l,
    expectedArtifactFingerprint: d,
    expectedPolicyFingerprint: a.policyFingerprint,
    logicalTime: e.logicalTime
  });
  if (g.status !== "verified")
    return Fe({
      status: g.status === "pending-authorization" ? "pending" : "invalid",
      root: a,
      diagnostics: [g.diagnostic]
    });
  const u = await Ei({
    policy: e.policy,
    documentId: r.artifact.documentId,
    reviewId: a.reviewId,
    record: a
  });
  if (u !== "accepted")
    return Fe({
      status: u,
      root: a,
      diagnostics: [
        ve(
          u === "pending" ? "collaboration-authorization-unavailable" : "collaboration-admission-invalid",
          "$.root.acceptance"
        )
      ]
    });
  const p = n.records.filter(
    (A) => A.kind === "zx-ai-durable-review-entry-v1"
  ), f = /* @__PURE__ */ new Set([
    a.creatorPrincipalRef,
    ...p.map((A) => A.principalRef)
  ]);
  if (f.size > ae.maxPrincipalRefs)
    return Fe({
      status: "invalid",
      root: a,
      diagnostics: [
        ce({
          code: "collaboration-resource-limit",
          stage: "graph",
          path: "$.principalRefs",
          count: f.size,
          recovery: "reject"
        })
      ]
    });
  const m = [], y = /* @__PURE__ */ new Set(), I = /* @__PURE__ */ new Set(), h = [];
  for (const A of p) {
    const le = A.entryKind === "decision" ? A.command : null, $e = A.entryKind === "decision" && le !== null || A.entryKind === "commit" && ((Oe = A.command) == null ? void 0 : Oe.kind) === "zx-ai-collaboration-commit-command-v1" || ["reject", "rebase"].includes(A.entryKind) && A.command === null && A.terminalLineage !== null || A.entryKind === "conflict-resolution" && ((lr = A.command) == null ? void 0 : lr.kind) === "zx-ai-collaboration-conflict-resolution-command-v1" && A.terminalCurrentBaseBinding !== null && A.terminalLineage !== null;
    if (A.rootFingerprint !== a.fingerprint || A.reviewId !== a.reviewId || !$e || le !== null && A.commandFingerprint !== go(le)) {
      y.add(A.fingerprint), h.push(
        ve("collaboration-invariant-violation", "$.entry", A)
      );
      continue;
    }
    const ot = [
      "reject",
      "rebase",
      "conflict-resolution"
    ].includes(A.entryKind) ? yo(A) : A.entryKind === "commit" && A.collaborationDispatchAdmission && A.collaborationCommitReceipt && A.terminalHistoricalEnvelope ? lo({
      command: A.command,
      principalRef: A.principalRef,
      priorSidecarFingerprint: A.priorSidecarFingerprint,
      resultingSidecarFingerprint: A.resultingSidecarFingerprint,
      dispatchAdmissionFingerprint: A.collaborationDispatchAdmission.fingerprint,
      commitReceiptFingerprint: A.collaborationCommitReceipt.fingerprint,
      terminalArtifactFingerprint: A.terminalHistoricalEnvelope.closureFingerprint,
      reviewArtifactFingerprint: A.terminalHistoricalEnvelope.reviewArtifact.fingerprint,
      proposalHistoricalArtifactFingerprint: A.terminalHistoricalEnvelope.reviewArtifact.proposalHistoricalArtifactFingerprint,
      terminalStatus: A.terminalHistoricalEnvelope.reviewArtifact.terminalStatus,
      logicalSequence: A.logicalSequence
    }) : mo({
      rootFingerprint: A.rootFingerprint,
      reviewId: A.reviewId,
      commandId: A.commandId,
      commandFingerprint: A.commandFingerprint,
      priorReviewRevision: A.priorReviewRevision,
      priorSidecarFingerprint: A.priorSidecarFingerprint,
      priorEntryFingerprint: A.priorEntryFingerprint,
      principalRef: A.principalRef,
      resultingSidecarFingerprint: A.resultingSidecarFingerprint,
      logicalSequence: A.logicalSequence,
      admissionPolicyFingerprint: A.admission.policyFingerprint
    });
    if (!ot) {
      y.add(A.fingerprint), h.push(
        ve("collaboration-invariant-violation", "$.entry", A)
      );
      continue;
    }
    const at = await ki({
      port: e.policy,
      receipt: A.admission,
      expectedDocumentId: r.artifact.documentId,
      expectedAction: A.entryKind === "conflict-resolution" ? "resolve-conflict" : A.entryKind === "commit" ? "commit" : A.entryKind === "decision" ? "decision" : A.entryKind,
      expectedCommandFingerprint: A.commandFingerprint,
      expectedArtifactFingerprint: ot,
      expectedPolicyFingerprint: A.admission.policyFingerprint,
      logicalTime: e.logicalTime
    });
    at.status === "verified" ? m.push(A) : at.status === "pending-authorization" ? (I.add(A.fingerprint), h.push(at.diagnostic)) : (y.add(A.fingerprint), h.push(at.diagnostic));
  }
  const v = /* @__PURE__ */ new Map();
  for (const A of m) {
    const le = A.priorEntryFingerprint ?? a.fingerprint, $e = v.get(le) ?? [];
    $e.push(A), v.set(le, $e);
  }
  const F = [...v.entries()].find(
    ([, A]) => A.length > ae.maxSuccessorsPerPredecessor
  );
  if (F)
    return Fe({
      status: "invalid",
      root: a,
      diagnostics: [
        ce({
          code: "collaboration-resource-limit",
          stage: "graph",
          path: "$.successors",
          count: F[1].length,
          recovery: "reject"
        })
      ]
    });
  const w = n.records.filter(
    (A) => A.kind === "zx-ai-durable-review-checkpoint-v1"
  ), x = [], j = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Set(), G = /* @__PURE__ */ new Set();
  let ie = a.fingerprint, O = a.initialSidecar, R = 1;
  for (; ; ) {
    const A = (v.get(ie) ?? []).sort(
      (ee, pr) => ee.fingerprint.localeCompare(pr.fingerprint)
    ), le = [], $e = [];
    for (const ee of A) {
      if (G.add(ee.fingerprint), ee.entryKind === "conflict-resolution") {
        $e.push(ee);
        continue;
      }
      !(ee.entryKind === "decision" ? dn({
        previous: O,
        command: ee.command,
        candidate: ee.resultingSidecar
      }).status === "verified" : ee.entryKind === "commit" ? ((Ne = ee.command) == null ? void 0 : Ne.kind) === "zx-ai-collaboration-commit-command-v1" && ee.command.expectedReviewRevision === O.revision && ee.command.expectedSidecarFingerprint === O.fingerprint && ee.command.durableHeadFingerprint === ie && ["committed", "accepted-no-change"].includes(
        ee.resultingSidecar.status
      ) : ["reject", "rebase"].includes(ee.entryKind) && ((Lr = ee.terminalLineage) == null ? void 0 : Lr.sourceHeadFingerprint) === ie && (ee.entryKind === "reject" ? ee.resultingSidecar.status === "rejected" : ee.resultingSidecar.status === "superseded")) || ee.priorReviewRevision !== O.revision || ee.priorSidecarFingerprint !== O.fingerprint || ee.logicalSequence !== R ? (y.add(ee.fingerprint), h.push(
        ve(
          "collaboration-invariant-violation",
          "$.transition",
          ee
        )
      )) : le.push(ee);
    }
    if (le.length === 0) {
      for (const ee of $e)
        y.add(ee.fingerprint), h.push(
          ve(
            "collaboration-invariant-violation",
            "$.resolutionWithoutFork",
            ee
          )
        );
      break;
    }
    if (le.length > 1) {
      const ee = le.map((se) => se.fingerprint).sort(), pr = ve(
        "collaboration-review-conflict",
        "$.successors"
      ), na = Fe({
        status: "review-conflict",
        root: a,
        acceptedEntries: x,
        acceptedHeadFingerprint: null,
        forkEntryFingerprints: ee,
        invalidEntryFingerprints: [...y],
        diagnostics: [...h, pr]
      }), yi = $e.filter((se) => {
        const Ee = se.command;
        return (Ee == null ? void 0 : Ee.kind) === "zx-ai-collaboration-conflict-resolution-command-v1" && se.terminalCurrentBaseBinding !== null && se.terminalLineage !== null && se.priorReviewRevision === O.revision && se.priorSidecarFingerprint === O.fingerprint && se.logicalSequence === R && se.resultingSidecar.status === "superseded" && se.terminalLineage.sourceHeadFingerprint === ie && se.terminalLineage.sourcePredecessorFingerprint === ie && se.terminalLineage.currentBaseBindingFingerprint === se.terminalCurrentBaseBinding.fingerprint && se.terminalLineage.resolutionCommandFingerprint === Ee.fingerprint && se.terminalLineage.sourceHandoffFingerprint === Ee.regenerationHandoffFingerprint && Ee.sourceGraphFingerprint === na.fingerprint && Ee.sourceRootFingerprint === a.fingerprint && Ee.sourcePredecessorFingerprint === ie && Ee.currentBaseBindingFingerprint === se.terminalCurrentBaseBinding.fingerprint && Ge(
          Ee.forkEntryFingerprints,
          ee
        ) && Ge(
          se.terminalLineage.preservedBranchFingerprints,
          ee
        );
      });
      if (yi.length === 1) {
        ee.forEach(
          (ur) => _.add(ur)
        );
        for (const ur of $e)
          ur.fingerprint !== yi[0].fingerprint && (y.add(ur.fingerprint), h.push(
            ve(
              "collaboration-invariant-violation",
              "$.resolution",
              ur
            )
          ));
        const se = yi[0], Ee = await Ei({
          policy: e.policy,
          documentId: r.artifact.documentId,
          reviewId: a.reviewId,
          record: se
        });
        if (Ee !== "accepted")
          return Fe({
            status: Ee,
            root: a,
            acceptedEntries: x,
            acceptedHeadFingerprint: null,
            pendingEntryFingerprints: Ee === "pending" ? [se.fingerprint] : [],
            invalidEntryFingerprints: Ee === "invalid" ? [se.fingerprint] : [],
            diagnostics: [
              ...h,
              ve(
                Ee === "pending" ? "collaboration-authorization-unavailable" : "collaboration-admission-invalid",
                "$.entry.acceptance",
                se
              )
            ]
          });
        x.push(se), ie = se.fingerprint, O = se.resultingSidecar, R += 1;
        break;
      }
      le.forEach((se) => j.add(se.fingerprint)), $e.forEach((se) => j.add(se.fingerprint)), h.push(pr);
      break;
    }
    if ($e.length > 0)
      for (const ee of $e)
        y.add(ee.fingerprint), h.push(
          ve(
            "collaboration-invariant-violation",
            "$.resolutionWithoutFork",
            ee
          )
        );
    const ot = le[0], at = await Ei({
      policy: e.policy,
      documentId: r.artifact.documentId,
      reviewId: a.reviewId,
      record: ot
    });
    if (at !== "accepted")
      return Fe({
        status: at,
        root: a,
        acceptedEntries: x,
        acceptedHeadFingerprint: null,
        pendingEntryFingerprints: at === "pending" ? [ot.fingerprint] : [],
        invalidEntryFingerprints: at === "invalid" ? [ot.fingerprint] : [],
        diagnostics: [
          ...h,
          ve(
            at === "pending" ? "collaboration-authorization-unavailable" : "collaboration-admission-invalid",
            "$.entry.acceptance",
            ot
          )
        ]
      });
    if (x.push(ot), ie = ot.fingerprint, O = ot.resultingSidecar, R += 1, O.status !== "active") break;
  }
  for (const A of m)
    !x.some(
      (le) => le.fingerprint === A.fingerprint
    ) && !j.has(A.fingerprint) && !y.has(A.fingerprint) && !G.has(A.fingerprint) && (I.add(A.fingerprint), h.push(
      ve(
        "collaboration-pending-predecessor",
        "$.predecessor",
        A
      )
    ));
  if (O.status !== "active" && x.length > 0) {
    const A = /* @__PURE__ */ new Set([
      a.fingerprint,
      ...x.map((le) => le.fingerprint)
    ]);
    for (const le of m)
      !x.some(
        ($e) => $e.fingerprint === le.fingerprint
      ) && !_.has(le.fingerprint) && A.has(le.priorEntryFingerprint ?? a.fingerprint) && !y.has(le.fingerprint) && (j.add(x.at(-1).fingerprint), j.add(le.fingerprint), I.delete(le.fingerprint), h.push(
        ve(
          "collaboration-review-conflict",
          "$.postTerminalSuccessor",
          le
        )
      ));
  }
  if (j.size > 0)
    return Fe({
      status: "review-conflict",
      root: a,
      acceptedEntries: x,
      acceptedHeadFingerprint: null,
      forkEntryFingerprints: [...j],
      pendingEntryFingerprints: [...I],
      invalidEntryFingerprints: [...y],
      diagnostics: h
    });
  const E = I.size > 0 ? "pending" : y.size > 0 && x.length === 0 ? "invalid" : "accepted", D = Fe({
    status: E,
    root: a,
    acceptedEntries: x,
    acceptedHeadFingerprint: ((Fn = x.at(-1)) == null ? void 0 : Fn.fingerprint) ?? a.fingerprint,
    pendingEntryFingerprints: [...I],
    invalidEntryFingerprints: [...y],
    diagnostics: h
  });
  if (D.status !== "accepted" || w.length === 0) return D;
  if (w.length > 1)
    return Fe({
      ...D,
      status: "storage-conflict",
      diagnostics: [
        ...D.diagnostics,
        ve("collaboration-storage-conflict", "$.checkpoints")
      ]
    });
  const K = w[0], te = fo({
    graph: D,
    suffixBoundaryFingerprint: K.suffixBoundaryFingerprint
  });
  if (!te || K.rootFingerprint !== a.fingerprint || K.terminalEntryFingerprint !== D.acceptedHeadFingerprint || !Ge(
    K.compactedPrefixFingerprints,
    te.compactedPrefixFingerprints
  ))
    return Fe({
      ...D,
      status: "invalid",
      invalidEntryFingerprints: [
        ...D.invalidEntryFingerprints,
        K.fingerprint
      ],
      diagnostics: [
        ...D.diagnostics,
        ve("collaboration-invariant-violation", "$.checkpoint")
      ]
    });
  const de = await ki({
    port: e.policy,
    receipt: K.compactionAdmission,
    expectedDocumentId: r.artifact.documentId,
    expectedAction: "compact",
    expectedCommandFingerprint: te.commandFingerprint,
    expectedArtifactFingerprint: te.artifactFingerprint,
    expectedPolicyFingerprint: K.compactionAdmission.policyFingerprint,
    logicalTime: e.logicalTime
  }), V = await e.policy.admitCompaction({
    reviewId: a.reviewId,
    terminalEntryFingerprint: K.terminalEntryFingerprint,
    prefixFingerprint: uo(
      K.compactedPrefixFingerprints
    )
  }), me = bl({
    checkpoint: K,
    records: n.records
  });
  return de.status !== "verified" || V.status !== "admitted" || V.admissionFingerprint !== K.hostCompactionAdmissionFingerprint ? Fe({
    ...D,
    status: de.status === "pending-authorization" || V.status === "unavailable" ? "pending" : "invalid",
    pendingEntryFingerprints: de.status === "pending-authorization" || V.status === "unavailable" ? [...D.pendingEntryFingerprints, K.fingerprint] : D.pendingEntryFingerprints,
    invalidEntryFingerprints: de.status === "pending-authorization" || V.status === "unavailable" ? D.invalidEntryFingerprints : [...D.invalidEntryFingerprints, K.fingerprint],
    diagnostics: [
      ...D.diagnostics,
      de.status === "pending-authorization" ? de.diagnostic : ve(
        "collaboration-invariant-violation",
        "$.checkpointAdmission"
      )
    ]
  }) : me.status === "incident" ? Fe({
    ...D,
    status: "review-conflict",
    acceptedHeadFingerprint: null,
    forkEntryFingerprints: [
      ...D.forkEntryFingerprints,
      ...me.incidentFingerprints
    ],
    diagnostics: [
      ...D.diagnostics,
      ve(
        "collaboration-review-conflict",
        "$.checkpointDominance"
      )
    ]
  }) : D;
}, ri = (e) => {
  var i, n;
  if (e.status !== "accepted" || !e.root) return null;
  const t = e.acceptedEntries.filter(
    (s) => s.entryKind === "decision"
  );
  if (e.acceptedEntries.some((s) => s.entryKind !== "decision")) {
    const s = ((i = e.acceptedEntries.at(-1)) == null ? void 0 : i.resultingSidecar) ?? e.root.initialSidecar;
    return dd({
      root: e.root.initialSidecar,
      sequence: e.acceptedEntries.map((o) => o.resultingSidecar),
      expectedDurableHeadFingerprint: s.fingerprint
    });
  }
  const r = cd({
    root: e.root.initialSidecar,
    entries: t.map((s) => ({
      previousSidecarFingerprint: s.priorSidecarFingerprint,
      command: s.command,
      resultingSidecar: s.resultingSidecar
    })),
    expectedDurableHeadFingerprint: ((n = t.at(-1)) == null ? void 0 : n.resultingSidecarFingerprint) ?? e.root.initialSidecarFingerprint
  });
  return ["reconciled", "idempotent"].includes(r.status), r;
}, Nf = async (e) => {
  var p, f;
  const t = ["prepare"], r = e.graph.root, i = ((p = e.graph.acceptedEntries.at(-1)) == null ? void 0 : p.resultingSidecar) ?? (r == null ? void 0 : r.initialSidecar);
  if (e.graph.status !== "accepted" || !r || !i || i.status !== "active")
    return c({
      status: "invalid-input",
      entry: null,
      graph: e.graph,
      reconciled: null,
      stageTrace: t
    });
  const n = vo({
    root: r,
    previousSidecar: i,
    priorEntryFingerprint: ((f = e.graph.acceptedEntries.at(-1)) == null ? void 0 : f.fingerprint) ?? null,
    command: e.command,
    principalRef: e.principalRef,
    logicalSequence: e.logicalSequence,
    admissionPolicyFingerprint: e.admissionPolicyFingerprint
  });
  if (n.status !== "candidate")
    return c({
      status: "invalid-input",
      entry: null,
      graph: e.graph,
      reconciled: null,
      stageTrace: t
    });
  t.push("fresh-admission");
  let s = null;
  try {
    s = await e.authorize({ prepared: n.prepared });
  } catch {
    s = null;
  }
  if (!s)
    return c({
      status: "pending-authorization",
      entry: null,
      graph: e.graph,
      reconciled: null,
      stageTrace: t
    });
  const o = await It({
    port: e.policy,
    receipt: s,
    expectedDocumentId: e.baseBinding.documentId,
    expectedAction: "decision",
    expectedCommandFingerprint: n.prepared.commandFingerprint,
    expectedArtifactFingerprint: n.prepared.admissionArtifactFingerprint,
    expectedPolicyFingerprint: e.admissionPolicyFingerprint,
    logicalTime: e.logicalTime
  });
  if (o.status !== "verified")
    return c({
      status: o.status === "pending-authorization" ? "pending-authorization" : "denied",
      entry: null,
      graph: e.graph,
      reconciled: null,
      stageTrace: t
    });
  const a = ho(
    n.prepared,
    o.receipt
  );
  if (a.status !== "success")
    return c({
      status: "invalid-input",
      entry: null,
      graph: e.graph,
      reconciled: null,
      stageTrace: t
    });
  t.push("append");
  const d = await e.adapter.appendRecord({
    storageKey: ft(a.entry),
    value: a.entry,
    originKind: "log"
  });
  if (!["appended", "idempotent"].includes(d.status))
    return c({
      status: "storage-conflict",
      entry: null,
      graph: e.graph,
      reconciled: null,
      stageTrace: t
    });
  t.push("complete-reread");
  const l = await e.adapter.enumerateRecords({
    documentId: e.baseBinding.documentId,
    reviewId: r.reviewId
  });
  t.push("graph");
  const g = await fn({
    enumeration: l,
    transfer: e.transfer,
    baseBinding: e.baseBinding,
    policy: e.policy,
    logicalTime: e.logicalTime
  });
  if (g.status !== "accepted" || g.acceptedHeadFingerprint !== a.entry.fingerprint)
    return c({
      status: "graph-conflict",
      entry: null,
      graph: g,
      reconciled: null,
      stageTrace: t
    });
  t.push("reconcile");
  const u = ri(g);
  return !u || !["reconciled", "idempotent"].includes(u.status) ? c({
    status: "reconcile-failure",
    entry: null,
    graph: g,
    reconciled: null,
    stageTrace: t
  }) : c({
    status: "submitted",
    entry: a.entry,
    graph: g,
    reconciled: u,
    stageTrace: t
  });
}, Ur = (e, t) => c({
  status: e,
  command: null,
  diagnostic: ce({
    code: e === "pending-authorization" ? "collaboration-authorization-unavailable" : "collaboration-review-conflict",
    stage: e === "pending-authorization" ? "authorization" : "graph",
    path: t,
    recovery: e === "pending-authorization" ? "retry-verification" : "resolve-conflict"
  })
}), kl = (e) => {
  var i;
  const t = De(e.currentBaseBinding);
  if (!P(e.commandId) || e.graph.status !== "review-conflict" || !e.graph.root || e.graph.forkEntryFingerprints.length < 2 || t.status !== "success" || !C(e.regenerationHandoffFingerprint) || !C(e.policyFingerprint))
    throw new TypeError("collaboration-conflict-resolution-input-invalid");
  const r = {
    kind: "zx-ai-collaboration-conflict-resolution-command-v1",
    version: ne,
    commandId: e.commandId,
    reviewId: e.graph.root.reviewId,
    sourceGraphFingerprint: e.graph.fingerprint,
    sourceRootFingerprint: e.graph.root.fingerprint,
    sourcePredecessorFingerprint: ((i = e.graph.acceptedEntries.at(-1)) == null ? void 0 : i.fingerprint) ?? e.graph.root.fingerprint,
    forkEntryFingerprints: [...e.graph.forkEntryFingerprints].sort(),
    disposition: "rebase-from-current-document",
    currentBaseBindingFingerprint: t.artifact.fingerprint,
    regenerationHandoffFingerprint: e.regenerationHandoffFingerprint,
    policyFingerprint: e.policyFingerprint
  };
  return c({
    ...r,
    fingerprint: B(
      "conflict-resolution-command",
      r,
      [
        r.sourceGraphFingerprint,
        r.sourceRootFingerprint,
        r.sourcePredecessorFingerprint,
        ...r.forkEntryFingerprints,
        r.currentBaseBindingFingerprint,
        r.regenerationHandoffFingerprint,
        r.policyFingerprint
      ]
    )
  });
}, Sl = (e) => B(
  "conflict-resolution-admission-artifact",
  {
    commandFingerprint: e.command.fingerprint,
    reviewId: e.command.reviewId,
    currentBaseBindingFingerprint: e.currentBaseBinding.fingerprint,
    regenerationHandoffFingerprint: e.command.regenerationHandoffFingerprint
  },
  [
    e.command.fingerprint,
    e.currentBaseBinding.fingerprint,
    e.command.regenerationHandoffFingerprint
  ]
), _f = async (e) => {
  var s;
  const t = De(e.currentBaseBinding);
  let r;
  try {
    r = kl({
      commandId: e.command.commandId,
      graph: e.graph,
      currentBaseBinding: e.currentBaseBinding,
      regenerationHandoffFingerprint: e.command.regenerationHandoffFingerprint,
      policyFingerprint: e.command.policyFingerprint
    });
  } catch {
    return Ur("failure", "$.command");
  }
  if (t.status !== "success" || r.fingerprint !== e.command.fingerprint || JSON.stringify(r.forkEntryFingerprints) !== JSON.stringify(e.command.forkEntryFingerprints) || e.command.currentBaseBindingFingerprint !== t.artifact.fingerprint || e.command.policyFingerprint !== ((s = e.graph.root) == null ? void 0 : s.policyFingerprint))
    return Ur("failure", "$.forkEntryFingerprints");
  const i = Sl({
    command: r,
    currentBaseBinding: t.artifact
  }), n = await It({
    port: e.policy,
    receipt: e.admission,
    expectedDocumentId: t.artifact.documentId,
    expectedAction: "resolve-conflict",
    expectedCommandFingerprint: r.fingerprint,
    expectedArtifactFingerprint: i,
    expectedPolicyFingerprint: r.policyFingerprint,
    logicalTime: e.logicalTime
  });
  return n.status !== "verified" ? n.status === "pending-authorization" ? Ur("pending-authorization", "$.admission") : Ur("failure", "$.admission") : c({
    status: "admitted",
    command: r,
    preservedAuditBranchRefs: [...e.graph.forkEntryFingerprints].sort(),
    admissionFingerprint: n.receipt.fingerprint
  });
}, Je = (e, t, r, i) => {
  const n = t.filter((d) => d.status === "surviving").map((d) => d.anchor.fingerprint).sort(), s = t.some(
    (d) => d.status === "surviving" && d.targetMoved
  ), o = r ? ce({
    code: r,
    stage: e === "anchor-lost" || e === "capability-changed" ? "anchor" : e === "review-conflict" ? "graph" : "rebase",
    path: i,
    recovery: e === "replan-required" || e === "capability-changed" ? "replan" : e === "review-conflict" || e === "anchor-lost" ? "resolve-conflict" : "reject"
  }) : null, a = {
    disposition: e,
    targetMoved: s,
    survivingAnchorFingerprints: n,
    diagnostic: o
  };
  return c({
    ...a,
    fingerprint: B("drift-result", a, [
      ...n
    ])
  });
}, Io = (e) => {
  const t = De(e.baseBinding), r = De(e.currentBinding);
  if (t.status !== "success" || r.status !== "success")
    return Je(
      "invariant-violation",
      e.anchors,
      "collaboration-invariant-violation",
      "$.binding"
    );
  if (e.graph.status === "review-conflict")
    return Je(
      "review-conflict",
      e.anchors,
      "collaboration-review-conflict",
      "$.graph"
    );
  if (e.graph.status !== "accepted" || e.policyStatus !== "verified")
    return Je(
      "unsupported",
      e.anchors,
      e.policyStatus === "pending" ? "collaboration-authorization-unavailable" : "collaboration-denied",
      "$.policy"
    );
  if (!e.schemaCompatible || !e.runtimeCompatible)
    return Je(
      "unsupported",
      e.anchors,
      "collaboration-runtime-unsupported",
      "$.runtime"
    );
  if (e.capabilityCompatible === "unknown")
    return Je(
      "unsupported",
      e.anchors,
      "collaboration-runtime-unsupported",
      "$.capability"
    );
  if (!e.capabilityCompatible || e.anchors.some((s) => s.status === "capability-changed"))
    return Je(
      "capability-changed",
      e.anchors,
      "collaboration-capability-changed",
      "$.capability"
    );
  if (e.anchors.some(
    (s) => s.status === "anchor-lost" || s.status === "anchor-ambiguous"
  ))
    return Je(
      "anchor-lost",
      e.anchors,
      "collaboration-anchor-lost",
      "$.anchors"
    );
  const i = t.artifact.stateVector.fingerprint === r.artifact.stateVector.fingerprint, n = t.artifact.documentFingerprint === r.artifact.documentFingerprint;
  return i && !n ? Je(
    "invariant-violation",
    e.anchors,
    "collaboration-invariant-violation",
    "$.stateVector"
  ) : !n || t.artifact.baseFingerprint !== r.artifact.baseFingerprint || t.artifact.targetFingerprint !== r.artifact.targetFingerprint || !e.currentTargetAdmissible ? Je(
    "replan-required",
    e.anchors,
    "collaboration-rebase-required",
    "$.document"
  ) : i ? Je("unchanged", e.anchors, null, "$") : Je(
    "replication-coordinate-changed",
    e.anchors,
    null,
    "$.stateVector"
  );
}, Lf = () => {
  const e = /* @__PURE__ */ new Map();
  return {
    put(t) {
      const r = `${t.command.commandId}:${t.predecessorFingerprint}`, i = e.get(r);
      return i ? Ge(i, t) ? "idempotent" : "identity-conflict" : e.size >= ae.maxPendingCommands ? "resource-limit" : (e.set(r, t), "stored");
    },
    resolve(t) {
      const r = [...e.values()].find(
        (n) => n.command.commandId === t.commandId
      );
      if (!r) return c({ status: "missing" });
      const i = `${r.command.commandId}:${r.predecessorFingerprint}`;
      return t.durableEntryCandidateFingerprints.includes(
        r.candidate.fingerprint
      ) ? (e.delete(i), c({ status: "idempotent" })) : t.durableHeadFingerprint !== r.predecessorFingerprint ? (e.delete(i), c({ status: "superseded-before-publish" })) : c({ status: "retry", pending: r });
    },
    size: () => e.size,
    clear: () => e.clear()
  };
}, Vf = (() => {
  const e = {
    regionRole: "region",
    reviewRole: "group",
    statusRole: "status",
    keyboardCommands: [
      { key: "Enter", action: "activate" },
      { key: "Escape", action: "hide" },
      { key: "ArrowLeft", action: "previous" },
      { key: "ArrowRight", action: "next" }
    ],
    visibleFocus: !0,
    nonColorStateIndicators: !0,
    liveRegionMode: "status-changes-only",
    announcesIncrementalContent: !1
  };
  return c({
    ...e,
    fingerprint: B(
      "presentation-contract",
      e
    )
  });
})(), Hf = (e) => c({
  visible: !1,
  reason: e.reason,
  durable: e.durable
}), Al = [
  "decision",
  "commit",
  "reject",
  "rebase",
  "resolve-conflict",
  "compact"
], El = (e) => {
  var i;
  if (e.policyStatus !== "verified" || ["incident", "reserved", "unavailable"].includes(e.commitFenceStatus))
    return [];
  if (e.graph.status === "review-conflict")
    return ["resolve-conflict"];
  if (e.graph.status !== "accepted" || !e.graph.root) return [];
  if (["replan-required", "capability-changed", "anchor-lost"].includes(
    e.drift.disposition
  ))
    return ["reject", "rebase"];
  if (!["unchanged", "replication-coordinate-changed"].includes(
    e.drift.disposition
  ))
    return [];
  const t = ((i = e.graph.acceptedEntries.at(-1)) == null ? void 0 : i.resultingSidecar) ?? e.graph.root.initialSidecar;
  if (t.status !== "active")
    return e.commitFenceStatus === "terminal" ? ["compact"] : [];
  const r = t.decisions.length > 0 && t.decisions.every((n) => n.state === "accepted");
  return Al.filter(
    (n) => r ? ["commit", "reject", "rebase"].includes(n) : ["decision", "reject", "rebase"].includes(n)
  );
}, Cl = (e) => {
  var v, F, w;
  const t = De(e.baseBinding), r = De(e.currentBinding), i = ((v = e.graph.root) == null ? void 0 : v.reviewId) ?? e.currentBinding.reviewId, n = ((F = e.graph.root) == null ? void 0 : F.policyFingerprint) ?? e.currentBinding.policyRef.fingerprint, s = t.status === "success" && r.status === "success" && t.artifact.reviewId === r.artifact.reviewId && r.artifact.reviewId === i, o = Er(
    e.graph.forkEntryFingerprints
  ), a = Er(
    e.graph.pendingEntryFingerprints
  ), d = [
    ...e.graph.diagnostics,
    ...e.drift.diagnostic ? [e.drift.diagnostic] : [],
    ...e.policyStatus === "pending" ? [
      ce({
        code: "collaboration-authorization-unavailable",
        stage: "projection",
        path: "$.policy",
        recovery: "retry-verification"
      })
    ] : [],
    ...e.commitFenceStatus === "incident" ? [
      ce({
        code: "collaboration-post-dispatch-incident",
        stage: "projection",
        path: "$.commitFence",
        recovery: "finalize-proof"
      })
    ] : []
  ], l = d.length <= ae.maxDiagnostics ? d : [
    ce({
      code: "collaboration-resource-limit",
      stage: "projection",
      path: "$.diagnostics",
      count: d.length,
      recovery: "reject"
    })
  ], g = e.commitFenceStatus === "incident" || l.some(
    (x) => x.code === "collaboration-post-dispatch-incident" || x.path.includes("postTerminal") || x.path.includes("checkpointDominance")
  ), u = e.drift.disposition === "anchor-lost" ? "lost" : e.drift.survivingAnchorFingerprints.length > 0 || e.currentBinding.documentScope ? "valid" : "unknown", p = Er(
    [
      (w = e.graph.root) == null ? void 0 : w.creatorPrincipalRef,
      ...e.graph.acceptedEntries.map((x) => x.principalRef)
    ].filter((x) => !!x).map(
      (x) => B("actor-display-ref", { principalRef: x })
    )
  ), f = p.length <= ae.maxPrincipalRefs ? p : [], m = p.length > ae.maxPrincipalRefs || d.length > ae.maxDiagnostics, y = p.length > ae.maxPrincipalRefs ? [
    ce({
      code: "collaboration-resource-limit",
      stage: "projection",
      path: "$.actorDisplayRefs",
      count: p.length,
      recovery: "reject"
    })
  ] : l, I = s && !m ? El(e) : [], h = {
    reviewId: i,
    graphFingerprint: e.graph.fingerprint,
    policyFingerprint: n,
    currentBindingFingerprint: e.currentBinding.fingerprint,
    commitFenceStatus: e.commitFenceStatus,
    graphStatus: e.graph.status,
    acceptedHeadFingerprint: e.graph.acceptedHeadFingerprint,
    branchRefs: o,
    pendingRefs: a,
    incident: g,
    anchorState: u,
    rebaseDisposition: e.drift.disposition,
    actorDisplayRefs: f,
    allowedActions: I,
    diagnostics: y
  };
  return c({
    ...h,
    fingerprint: B(
      "durable-projection",
      h,
      [
        e.graph.fingerprint,
        n,
        e.currentBinding.fingerprint,
        e.drift.fingerprint,
        ...o,
        ...a,
        ...f
      ]
    )
  });
}, _n = (e) => {
  const r = (e.actors.length <= ae.maxPrincipalRefs ? e.actors : []).filter(
    (n) => P(n.actorRef)
  ), i = Er(
    r.map((n) => n.actorRef).filter(P).map(
      (n) => B("online-actor-ref", { actorRef: n })
    )
  );
  return c({
    providerStatus: e.providerStatus,
    onlineActorRefs: i,
    cursorCount: r.filter((n) => n.cursorVisible === !0).length,
    reviewerTyping: r.some((n) => n.reviewerTyping === !0)
  });
}, Ln = (e) => c({ durable: e.durable, ephemeral: e.ephemeral }), ql = () => {
  const e = /* @__PURE__ */ new Map();
  return {
    enqueue(t) {
      if (!P(t.commandId) || !P(t.principalRef) || !["accept-all", "reject-all", "regenerate"].includes(t.kind))
        return "invalid";
      const r = e.get(t.commandId);
      return r ? Ge(r, t) ? "idempotent" : "identity-conflict" : e.size >= ae.maxPendingCommands ? "resource-limit" : (e.set(t.commandId, c({ ...t })), "stored");
    },
    async reconnect(t) {
      var l;
      const r = ["sync"], i = (g, u, p) => c({
        status: g,
        graph: u,
        replayedCommandIds: [...p],
        stageTrace: [...r]
      });
      if (!t.fullySynced) return i("pending-sync", null, []);
      const n = async () => {
        r.push("enumeration");
        const g = await t.adapter.enumerateRecords({
          documentId: t.documentId,
          reviewId: t.transfer.sidecar.identity.reviewId
        });
        return r.push("verification", "graph"), fn({
          enumeration: g,
          transfer: t.transfer,
          baseBinding: t.baseBinding,
          policy: t.policy,
          logicalTime: t.logicalTime
        });
      };
      let s;
      try {
        s = await n();
      } catch {
        return i("failure", null, []);
      }
      if (s.status === "review-conflict")
        return i("review-conflict", s, []);
      if (s.status === "pending")
        return i("pending-authorization", s, []);
      if (s.status !== "accepted" || !s.root)
        return i(
          s.status === "storage-conflict" ? "storage-conflict" : "rebase-required",
          s,
          []
        );
      r.push("reconcile");
      const o = ri(s);
      if (!o || !["reconciled", "idempotent"].includes(o.status))
        return i("review-conflict", s, []);
      const a = s.root, d = [];
      r.push("replay");
      for (const g of [...e.values()]) {
        const u = ((l = s.acceptedEntries.at(-1)) == null ? void 0 : l.resultingSidecar) ?? a.initialSidecar;
        if (u.status !== "active")
          return i("rebase-required", s, d);
        const p = {
          kind: g.kind,
          commandId: g.commandId,
          expectedRevision: u.revision,
          expectedSidecarFingerprint: u.fingerprint,
          expectedProposalFingerprint: u.proposalBinding.proposalFingerprint,
          expectedLifecycleFingerprint: u.proposalBinding.lifecycleFingerprint,
          expectedPolicyFingerprint: u.policyRef.fingerprint
        }, f = vo({
          root: a,
          previousSidecar: u,
          priorEntryFingerprint: s.acceptedHeadFingerprint,
          command: p,
          principalRef: g.principalRef,
          logicalSequence: s.acceptedEntries.length + 1,
          admissionPolicyFingerprint: t.admissionPolicyFingerprint
        });
        if (f.status !== "candidate")
          return i("rebase-required", s, d);
        let m;
        try {
          m = await t.admit({
            intent: g,
            prepared: f.prepared
          });
        } catch {
          m = null;
        }
        if (!m)
          return i("pending-authorization", s, d);
        const y = await It({
          port: t.policy,
          receipt: m,
          expectedDocumentId: t.documentId,
          expectedAction: "decision",
          expectedCommandFingerprint: f.prepared.commandFingerprint,
          expectedArtifactFingerprint: f.prepared.admissionArtifactFingerprint,
          expectedPolicyFingerprint: t.admissionPolicyFingerprint,
          logicalTime: t.logicalTime
        });
        if (y.status !== "verified")
          return i("pending-authorization", s, d);
        const I = ho(
          f.prepared,
          y.receipt
        );
        if (I.status !== "success")
          return i("failure", s, d);
        const h = await t.adapter.appendRecord({
          storageKey: ft(I.entry),
          value: I.entry,
          originKind: "log"
        });
        if (!["appended", "idempotent"].includes(h.status))
          return i(
            h.status === "conflict" ? "storage-conflict" : "failure",
            s,
            d
          );
        try {
          s = await n();
        } catch {
          return i("failure", s, d);
        }
        if (s.status !== "accepted" || s.acceptedHeadFingerprint !== I.entry.fingerprint)
          return i(
            s.status === "review-conflict" ? "review-conflict" : "rebase-required",
            s,
            d
          );
        r.push("reconcile");
        const v = ri(s);
        if (!v || !["reconciled", "idempotent"].includes(v.status))
          return i("review-conflict", s, d);
        e.delete(g.commandId), d.push(g.commandId);
      }
      return r.push("projection"), i(
        d.length ? "replayed" : "no-pending",
        s,
        d
      );
    },
    size: () => e.size,
    clear: () => e.clear()
  };
}, Tl = (e) => typeof e == "object" && e !== null && e.kind === "remote", Kf = (e) => {
  if (!P(e.peerId) || !P(e.guid) || [e.initialText, e.initialDocument, e.initialUpdate].filter(
    (i) => i !== void 0
  ).length > 1 || e.initialUpdate !== void 0 && !(e.initialUpdate instanceof Uint8Array))
    throw new TypeError("collaboration-connector-peer-invalid");
  const t = wa({
    guid: e.guid,
    gc: e.gc,
    initialUpdate: e.initialUpdate
  });
  e.initialText && t.getText("prosemirror").insert(0, e.initialText), e.initialDocument && Da(
    sa(),
    e.initialDocument.body.content,
    t.getXmlFragment("prosemirror")
  );
  const r = t;
  return Object.freeze({
    peerId: e.peerId,
    doc: t,
    setStatus: e.setStatus ?? (() => {
    }),
    destroy() {
      r.destroy();
    }
  });
}, Mf = (e) => {
  if (e.peers.length < 2 || e.peers.length > 3 || new Set(e.peers.map((u) => u.peerId)).size !== e.peers.length || e.peers.some((u) => !P(u.peerId)))
    throw new TypeError("collaboration-connector-input-invalid");
  const t = new Map(e.peers.map((u) => [u.peerId, u])), r = /* @__PURE__ */ new Set(), i = [], n = [];
  let s = 0, o = !1;
  const a = (u) => {
    const p = t.get(u);
    if (!p) throw new TypeError("collaboration-connector-peer-unknown");
    return p;
  }, d = (u, p, f, m = !1) => {
    if (f.byteLength === 0) return "";
    const y = ++s, I = `connector-message:${y}`;
    return i.push({
      messageId: I,
      sourcePeerId: u,
      targetPeerId: p,
      logicalSequence: y,
      byteLength: f.byteLength,
      delayed: m,
      update: f.slice()
    }), I;
  }, l = () => {
    for (const u of r) {
      const p = i.some(
        (f) => r.has(f.sourcePeerId) && r.has(f.targetPeerId) && (f.sourcePeerId === u || f.targetPeerId === u)
      );
      a(u).setStatus(p ? "connected" : "synced");
    }
  };
  for (const u of e.peers) {
    const p = u.doc, f = (m, y) => {
      if (!(o || Tl(y) || !r.has(u.peerId))) {
        for (const I of r)
          I !== u.peerId && d(u.peerId, I, m);
        l();
      }
    };
    p.on("update", f), n.push(() => p.off("update", f));
  }
  const g = (u, p) => {
    if (o) return 0;
    const f = (p == null ? void 0 : p.limit) ?? Number.MAX_SAFE_INTEGER;
    if (!Number.isSafeInteger(f) || f < 0)
      throw new TypeError("collaboration-connector-limit-invalid");
    p != null && p.targetPeerId && a(p.targetPeerId);
    let m = 0;
    const y = i.map((I, h) => ({ message: I, index: h })).filter(
      ({ message: I }) => !I.delayed && r.has(I.sourcePeerId) && r.has(I.targetPeerId) && (!(p != null && p.targetPeerId) || I.targetPeerId === p.targetPeerId)
    );
    u && y.reverse();
    for (const I of y.slice(0, f)) {
      const h = i.indexOf(I.message);
      h < 0 || (i.splice(h, 1), us(
        a(I.message.targetPeerId).doc,
        I.message.update
      ), m += 1);
    }
    return l(), m;
  };
  return {
    connect(u) {
      if (o || r.has(u)) return;
      const p = a(u);
      p.setStatus("connecting"), r.add(u), p.setStatus("connected");
      for (const f of r) {
        if (f === u) continue;
        const m = a(f);
        d(
          f,
          u,
          Nt.encodeStateAsUpdate(m.doc, Nt.encodeStateVector(p.doc))
        ), d(
          u,
          f,
          Nt.encodeStateAsUpdate(p.doc, Nt.encodeStateVector(m.doc))
        );
      }
      l();
    },
    disconnect(u) {
      if (o) return;
      const p = a(u);
      r.delete(u), p.setStatus("disconnected"), l();
    },
    duplicate(u) {
      const p = i.find((f) => f.messageId === u);
      if (!p)
        throw new TypeError("collaboration-connector-message-unknown");
      return d(
        p.sourcePeerId,
        p.targetPeerId,
        p.update,
        p.delayed
      );
    },
    delay(u) {
      const p = i.findIndex(
        (f) => f.messageId === u
      );
      if (p < 0)
        throw new TypeError("collaboration-connector-message-unknown");
      i[p] = { ...i[p], delayed: !0 }, l();
    },
    drop(u) {
      const p = i.findIndex(
        (f) => f.messageId === u
      );
      if (p < 0)
        throw new TypeError("collaboration-connector-message-unknown");
      i.splice(p, 1), l();
    },
    releaseDelayed(u) {
      let p = !1;
      for (let f = 0; f < i.length; f += 1)
        (!u || i[f].messageId === u) && (i[f] = { ...i[f], delayed: !1 }, p = !0);
      if (u && !p)
        throw new TypeError("collaboration-connector-message-unknown");
      l();
    },
    flushFIFO: (u) => g(!1, u),
    flushReverse: (u) => g(!0, u),
    pending: () => i.map(({ update: u, ...p }) => Object.freeze(p)),
    isConnected: (u) => r.has(a(u).peerId),
    destroy() {
      if (!o) {
        o = !0, n.splice(0).forEach((u) => u()), i.splice(0);
        for (const u of r)
          a(u).setStatus("disconnected");
        r.clear();
      }
    }
  };
}, Uf = (e) => {
  const t = Nt.encodeStateVector(e.doc);
  return Object.freeze({
    kind: "zx-ai-deterministic-peer-state-vector-v1",
    peerId: e.peerId,
    byteLength: t.byteLength,
    fingerprint: B(
      "deterministic-peer-state-vector",
      Array.from(t)
    )
  });
}, Gf = (e, t) => {
  if (!P(t.key) || t.value.length === 0 || t.value.length > 96)
    throw new TypeError("collaboration-connector-mutation-invalid");
  e.doc.getMap("production-faults").set(t.key, t.value);
}, Wf = (e) => {
  if (e.length === 0 || e.length > 3 || new Set(e.map((t) => t.peerId)).size !== e.length)
    throw new TypeError("collaboration-connector-checkpoint-invalid");
  return Nt.mergeUpdates(e.map((t) => Nt.encodeStateAsUpdate(t.doc)));
}, Yf = (e, t) => {
  if (e.length === 0 || e.length > 3 || !(t instanceof Uint8Array) || t.byteLength === 0)
    throw new TypeError("collaboration-connector-checkpoint-invalid");
  e.forEach(
    (r) => us(r.doc, t)
  );
}, Xf = (e) => {
  const t = ai(
    e.anchor.relativePosition,
    "relative-position"
  ), r = t.status === "success" ? e.adapter.resolveRelativePosition(t.bytes) : null, i = e.currentBlockIds.filter(
    (o) => o === e.anchor.blockId
  ).length, n = (o, a) => c({
    status: o,
    anchor: e.anchor,
    diagnostic: ce({
      code: o === "anchor-ambiguous" ? "collaboration-anchor-ambiguous" : o === "capability-changed" ? "collaboration-capability-changed" : "collaboration-anchor-lost",
      stage: "anchor",
      path: a,
      recovery: o === "capability-changed" ? "replan" : "resolve-conflict"
    })
  });
  if (!r) return n("anchor-lost", "$.relativePosition");
  if (i !== 1 || r.rootSharedType !== e.expectedRootSharedType || r.blockId !== e.anchor.blockId)
    return n(
      i > 1 ? "anchor-ambiguous" : "anchor-lost",
      "$.blockId"
    );
  if (r.semanticOffset < 0 || r.semanticOffset > e.maximumSemanticOffset)
    return n("anchor-lost", "$.semanticOffset");
  if (e.currentCapabilityFingerprint !== e.anchor.capabilityFingerprint)
    return n("capability-changed", "$.capabilityFingerprint");
  const s = {
    anchorFingerprint: e.anchor.fingerprint,
    rootSharedType: r.rootSharedType,
    blockId: r.blockId,
    semanticOffset: r.semanticOffset,
    absolutePosition: r.absolutePosition
  };
  return c({
    status: "surviving",
    anchor: e.anchor,
    resolved: r,
    targetMoved: r.absolutePosition !== e.originalAbsolutePosition,
    fingerprint: B("resolved-anchor", s, [
      e.anchor.fingerprint
    ])
  });
}, Ci = (e) => c({
  ...e,
  fingerprint: B("reference-provenance", e)
}), Vn = c([
  Ci({
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    decisions: [
      {
        sourcePath: "packages/core/src/yjs/extensions/ForkYDoc.ts",
        sourceTestPath: "packages/core/src/yjs/extensions/ForkYDoc.test.ts",
        decision: "adapt",
        boundary: "Use isolated Y.Doc and state-vector-relative deltas only as sandbox/proof fixtures; S3 detached proposal remains the proposal owner.",
        difference: "ZXUI never hot-swaps the extension, retains upstream undo-stack references, or merges a fork update into live content.",
        fixtureIds: [
          "BN-01 fork-zero-pollution",
          "BN-02 delta-proof-no-live-apply",
          "BN-03 discard-keep-lineage"
        ]
      },
      {
        sourcePath: "packages/core/src/yjs/extensions/ForkYDoc.ts",
        sourceTestPath: "packages/core/src/yjs/extensions/ForkYDoc.test.ts",
        decision: "reject",
        boundary: "Blind applyUpdate merge, extension replacement and upstream undoStack coupling cannot cross the S7 content-authority boundary.",
        difference: "Rebase carries operation-intent digests and current semantic references through S2, Runtime v2, S3 and S4 instead.",
        fixtureIds: ["BN-02 delta-proof-no-live-apply"]
      },
      {
        sourcePath: "packages/core/src/yjs/extensions/RelativePositionMapping.ts",
        sourceTestPath: "packages/core/src/yjs/extensions/RelativePositionMapping.test.ts",
        decision: "adapt",
        boundary: "Use y-prosemirror relative mapping only when stable block identity, semantic UTF-16 offset, capability and shared root all revalidate.",
        difference: "ZXUI fails closed on GC/null, cross-block ambiguity and capability drift; absolute position is never durable authority.",
        fixtureIds: [
          "BN-04 affinity-insert",
          "BN-05 remote-delete",
          "BN-06 gc-null-fail-closed",
          "BN-07 cross-block-reject"
        ]
      },
      {
        sourcePath: "packages/core/src/yjs/comments/YjsThreadStoreBase.ts;packages/core/src/yjs/comments/YjsThreadStore.ts",
        sourceTestPath: "packages/core/src/yjs/comments/YjsThreadStore.test.ts",
        decision: "adapt",
        boundary: "Reuse shared-map observation and replication fixtures only; authoritative review data is a content-addressed immutable record set.",
        difference: "ZXUI adds complete enumeration, key/payload binding, fresh admission and storage-conflict behavior rather than mutable thread-map truth.",
        fixtureIds: [
          "BN-08 replicated-record-notify",
          "BN-09 unauthenticated-write-zero-effect",
          "BN-10 overwrite-storage-conflict"
        ]
      },
      {
        sourcePath: "packages/core/src/yjs/comments/YjsThreadStoreBase.ts;packages/core/src/yjs/comments/YjsThreadStore.ts",
        sourceTestPath: "packages/core/src/yjs/comments/YjsThreadStore.test.ts",
        decision: "reject",
        boundary: "Mutable unauthenticated thread maps, Date/uuid ordering and arbitrary client author writes are not review or authorization truth.",
        difference: "S7 verifies every persisted admission on every peer and preserves conflicting immutable siblings.",
        fixtureIds: ["BN-09 unauthenticated-write-zero-effect"]
      },
      {
        sourcePath: "packages/xl-ai/src/prosemirror/rebaseTool.ts",
        sourceTestPath: "packages/xl-ai/src/prosemirror/rebaseTool.test.ts",
        decision: "reject",
        boundary: "Retain only the invariant that changed current content requires intent reprojection; never invert/map old ProseMirror steps into live content.",
        difference: "ZXUI creates a new proposal/review lineage from current Semantic Snapshot and Runtime v2 admission.",
        fixtureIds: [
          "BN-11 old-step-replay-source-gate",
          "BN-12 current-base-replan"
        ]
      }
    ]
  }),
  Ci({
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    decisions: [
      {
        sourcePath: "packages/yjs/src/lib/withPlateYjs.ts",
        sourceTestPath: "packages/yjs/src/lib/withPlateYjs.spec.ts",
        decision: "adapt",
        boundary: "Preserve explicit shared type and Yjs/cursor/history ordering principles while actual y-prosemirror origins and Y.UndoManager are package-owned.",
        difference: "ZXUI is Vue/Tiptap/document-v2 and keeps awareness ephemeral; it does not adopt Slate editor/plugin runtime.",
        fixtureIds: [
          "PL-01 origin-history-order",
          "PL-02 awareness-disabled-authority-stable"
        ]
      },
      {
        sourcePath: "packages/yjs/src/lib/withPlateYjs.ts",
        sourceTestPath: "packages/yjs/src/lib/withPlateYjs.spec.ts",
        decision: "reject",
        boundary: "Slate runtime, cursor position origins and optional awareness cannot become S7 durable or authorization authority.",
        difference: "Private Yjs content/log origins and closed durable projection replace framework-specific plugin state.",
        fixtureIds: ["PL-02 awareness-disabled-authority-stable"]
      },
      {
        sourcePath: "packages/yjs/src/utils/slateToDeterministicYjsState.ts",
        sourceTestPath: "packages/yjs/src/utils/slateToDeterministicYjsState.spec.ts",
        decision: "adapt",
        boundary: "Use deterministic bootstrap as a fixture principle only; production Yjs client identifiers remain Yjs-owned.",
        difference: "ZXUI separately validates document-v2 fingerprints and state vectors, including same content with different replication coordinates.",
        fixtureIds: [
          "PL-03 deterministic-bootstrap",
          "PL-04 same-content-different-vector"
        ]
      },
      {
        sourcePath: "packages/yjs/src/lib/__tests__/collaboration/harness.ts",
        sourceTestPath: "packages/yjs/src/lib/__tests__/collaboration/index.slow.ts",
        decision: "copy",
        boundary: "Copy the explicit queued connector shape, then keep it deterministic and test/workbench-only with real Y.Doc peers.",
        difference: "ZXUI removes random providers and wall-clock sleeps and adds reverse, duplicate, delayed, selective target, three-peer, GC and logical scheduling controls.",
        fixtureIds: [
          "PL-05 fifo-reverse-convergence",
          "PL-06 offline-reconnect",
          "PL-07 duplicate-delayed",
          "PL-08 multi-provider-status"
        ]
      },
      {
        sourcePath: "packages/suggestion/src/lib/BaseSuggestionPlugin.ts;packages/suggestion/src/lib/types.ts",
        sourceTestPath: "packages/suggestion/src/lib/BaseSuggestionPlugin.spec.ts",
        decision: "adapt",
        boundary: "Adapt bounded actor attribution and non-color state presentation only.",
        difference: "Durable decisions come exclusively from the S4 entry graph; no suggestion node/mark or Slate transform stores authority.",
        fixtureIds: [
          "PL-09 actor-presentation",
          "PL-10 suggestion-node-source-gate"
        ]
      },
      {
        sourcePath: "packages/suggestion/src/lib/BaseSuggestionPlugin.ts;packages/suggestion/src/lib/types.ts",
        sourceTestPath: "packages/suggestion/src/lib/BaseSuggestionPlugin.spec.ts",
        decision: "reject",
        boundary: "Date/any/currentUser fields, Slate transforms and suggestion schema metadata are presentation inputs only and cannot be review truth.",
        difference: "ZXUI uses immutable review entries plus ephemeral awareness projection.",
        fixtureIds: ["PL-10 suggestion-node-source-gate"]
      }
    ]
  }),
  Ci({
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    decisions: [
      {
        sourcePath: "packages/headless/src/components/editor.tsx;packages/headless/src/components/editor-command.tsx",
        sourceTestPath: null,
        decision: "adapt",
        boundary: "Adapt progressive command composition and low-interruption presentation only.",
        difference: "ZXUI uses Vue public projections; React, Jotai, tunnel-rat and Tiptap EditorProvider are not collaboration runtime owners.",
        fixtureIds: [
          "NV-01 headless-projection",
          "NV-02 close-keeps-durable-state"
        ]
      },
      {
        sourcePath: "packages/headless/src/extensions/ai-highlight.ts",
        sourceTestPath: null,
        decision: "reject",
        boundary: "Use non-invasive visual-state intent only; reject AI highlight mark and HTML attributes as proposal, review or durable truth.",
        difference: "S7 projection is closed data and writes no suggestion/highlight metadata into document v2.",
        fixtureIds: [
          "NV-03 highlight-zero-authority",
          "NV-04 no-document-mark"
        ]
      },
      {
        sourcePath: "packages/headless/src/extensions/slash-command.tsx",
        sourceTestPath: null,
        decision: "adapt",
        boundary: "Adapt concise conflict/rebase/reconnect command taxonomy and Escape behavior only.",
        difference: "ZXUI commands call exact host owner admission; live editor callbacks and ReactRenderer do not mutate content directly.",
        fixtureIds: ["NV-05 recovery-command-routing"]
      },
      {
        sourcePath: "packages/headless/src",
        sourceTestPath: null,
        decision: "reject",
        boundary: "The fixed repository tree contains no Yjs, rebase or durable-review implementation, so Novel contributes no safety/concurrency mechanism.",
        difference: "Only product-interaction relatedness is claimed; all collaboration authority and executable safety evidence is ZXUI, BlockNote-study or Plate-study derived.",
        fixtureIds: ["NV-06 provenance-relatedness-rejection"]
      }
    ]
  })
]), oe = (e, t, r) => e.map((i) => ({
  fixtureId: i,
  testPath: t,
  evidenceTestTitle: r
})), Zf = c([
  ...oe(
    ["BN-01 fork-zero-pollution"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-01 proves an isolated fork has zero live-document pollution"
  ),
  ...oe(
    ["BN-02 delta-proof-no-live-apply"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-02 proves the relative fork delta is evidence and is never applied to live content"
  ),
  ...oe(
    ["BN-03 discard-keep-lineage"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-03 proves fork discard keeps live content while retained isolated lineage reconstructs exactly"
  ),
  ...oe(
    ["BN-04 affinity-insert"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-04 proves a same-block insert resolves the captured relative anchor with affinity"
  ),
  ...oe(
    ["BN-05 remote-delete"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-05 proves remote deletion preserves a resolvable same-block coordinate"
  ),
  ...oe(
    ["BN-06 gc-null-fail-closed"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-06 proves a GC-null or foreign relative coordinate fails closed"
  ),
  ...oe(
    ["BN-07 cross-block-reject"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-07 proves a coordinate captured from another shared root is rejected"
  ),
  ...oe(
    ["BN-08 replicated-record-notify"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-08 proves immutable record append emits replicated shared-map notification"
  ),
  ...oe(
    ["BN-09 unauthenticated-write-zero-effect"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-09 proves an unauthenticated principal has zero durable write authority"
  ),
  ...oe(
    ["BN-10 overwrite-storage-conflict"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-10 proves an immutable key payload overwrite becomes storage conflict"
  ),
  ...oe(
    ["BN-11 old-step-replay-source-gate"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-11 proves old ProseMirror Step Mapping and snapshot replay have no live owner"
  ),
  ...oe(
    ["BN-12 current-base-replan"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "BN-12 proves changed current content selects a fresh current-base replan"
  ),
  ...oe(
    ["PL-01 origin-history-order"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-01 proves private AI content origin creates one undo item while log origin creates none"
  ),
  ...oe(
    ["PL-02 awareness-disabled-authority-stable"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-02 proves awareness disabled noisy or lost never changes durable authority"
  ),
  ...oe(
    ["PL-03 deterministic-bootstrap"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-03 proves deterministic bootstrap gives peers identical content and state vectors"
  ),
  ...oe(
    ["PL-04 same-content-different-vector"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-04 proves equal content can retain different Yjs replication coordinates"
  ),
  ...oe(
    ["PL-05 fifo-reverse-convergence"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-05 proves queued FIFO and reverse delivery converge deterministic real Yjs peers"
  ),
  ...oe(
    ["PL-06 offline-reconnect"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-06 proves offline reconnect syncs before the peer is marked converged"
  ),
  ...oe(
    ["PL-07 duplicate-delayed"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-07 proves duplicate and delayed updates remain idempotent and converge"
  ),
  ...oe(
    ["PL-08 multi-provider-status"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-08 proves per-provider status remains ephemeral and peer-specific"
  ),
  ...oe(
    ["PL-09 actor-presentation"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-09 proves actor presentation is bounded hashed and never durable identity truth"
  ),
  ...oe(
    ["PL-10 suggestion-node-source-gate"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "PL-10 proves Slate suggestion nodes transforms and currentUser never enter S7 authority"
  ),
  ...oe(
    ["NV-01 headless-projection"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "NV-01 proves the headless surface receives only frozen closed projection data"
  ),
  ...oe(
    ["NV-02 close-keeps-durable-state"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "NV-02 proves Escape hide closes presentation while durable state stays identical"
  ),
  ...oe(
    ["NV-03 highlight-zero-authority"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "NV-03 proves AI highlight state has zero proposal review or durable authority"
  ),
  ...oe(
    ["NV-04 no-document-mark"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "NV-04 proves collaboration never writes highlight or suggestion marks into document v2"
  ),
  ...oe(
    ["NV-05 recovery-command-routing"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "NV-05 proves recovery commands route through closed host-owned action names"
  ),
  ...oe(
    ["NV-06 provenance-relatedness-rejection"],
    "__tests__/ai-collaboration-reference-fixtures.test.ts",
    "NV-06 proves Novel is rejected as a collaboration safety mechanism and kept product-related only"
  )
]), Jf = (e) => Ge(e, Vn) ? c({
  status: "success",
  fingerprints: Vn.map(
    (t) => t.fingerprint
  )
}) : c({
  status: "failure",
  code: "collaboration-reference-provenance-invalid"
}), Bl = (e, t) => c({
  status: e,
  prepared: null,
  diagnostic: ce({
    code: "collaboration-rebase-unsupported",
    stage: "rebase",
    path: t,
    recovery: "replan"
  })
}), bo = (e) => {
  var t;
  return {
    kind: "zx-ai-collaboration-rebase-admission-artifact-v1",
    version: ne,
    sourceGraphFingerprint: e.graph.fingerprint,
    sourceRootFingerprint: e.graph.root.fingerprint,
    sourceEntryFingerprint: ((t = e.graph.acceptedEntries.at(-1)) == null ? void 0 : t.fingerprint) ?? null,
    sourceReviewFingerprint: e.sourceSidecar.fingerprint,
    sourceDecisionFingerprint: e.regenerationHandoff.decisionFingerprint,
    sourceBaseBindingFingerprint: e.graph.root.baseBindingFingerprint,
    currentBaseBindingFingerprint: e.currentBaseBinding.fingerprint,
    survivingAnchorFingerprints: e.drift.survivingAnchorFingerprints,
    operationIntentDigests: e.regenerationHandoff.operationIntentDigests,
    latestSemanticSnapshotFingerprint: e.latestSemanticSnapshotFingerprint,
    regenerationHandoffFingerprint: e.regenerationHandoff.fingerprint,
    sourceTerminalSidecarFingerprint: e.sourceTerminalSidecar.fingerprint,
    nextProposalId: e.nextProposalId,
    nextVariantId: e.nextVariantId,
    policyFingerprint: e.policyFingerprint
  };
}, Qf = (e) => {
  var o;
  const t = De(e.currentBaseBinding), r = Te(e.sourceSidecar), i = Te(e.sourceTerminalSidecar);
  if (e.graph.status !== "accepted" || !e.graph.root || t.status !== "success" || r.status !== "success" || i.status !== "success" || e.drift.disposition !== "replan-required" || i.sidecar.status !== "superseded" || e.regenerationHandoff.reviewFingerprint !== r.sidecar.fingerprint || (((o = e.graph.acceptedEntries.at(-1)) == null ? void 0 : o.resultingSidecarFingerprint) ?? e.graph.root.initialSidecarFingerprint) !== r.sidecar.fingerprint || e.regenerationHandoff.supersededProposalFingerprint !== e.graph.root.proposalFingerprint || i.sidecar.identity.reviewId !== e.graph.root.reviewId || t.artifact.documentId !== e.graph.root.admission.documentId || ![
    e.latestSemanticSnapshotFingerprint,
    e.regenerationHandoff.fingerprint,
    e.policyFingerprint
  ].every(C) || !P(e.nextProposalId) || !P(e.nextVariantId))
    return Bl("failure", "$");
  const n = {
    graph: e.graph,
    currentBaseBinding: t.artifact,
    sourceSidecar: r.sidecar,
    sourceTerminalSidecar: i.sidecar,
    drift: e.drift,
    latestSemanticSnapshotFingerprint: e.latestSemanticSnapshotFingerprint,
    regenerationHandoff: e.regenerationHandoff,
    nextProposalId: e.nextProposalId,
    nextVariantId: e.nextVariantId,
    policyFingerprint: e.policyFingerprint
  }, s = bo(n);
  return c({
    status: "candidate",
    prepared: {
      ...n,
      admissionArtifactFingerprint: B(
        "rebase-admission-artifact",
        s,
        [
          s.sourceGraphFingerprint,
          s.sourceRootFingerprint,
          ...s.sourceEntryFingerprint ? [s.sourceEntryFingerprint] : [],
          s.sourceReviewFingerprint,
          s.sourceDecisionFingerprint,
          s.sourceBaseBindingFingerprint,
          s.currentBaseBindingFingerprint,
          ...s.survivingAnchorFingerprints,
          ...s.operationIntentDigests,
          s.latestSemanticSnapshotFingerprint,
          s.regenerationHandoffFingerprint,
          s.sourceTerminalSidecarFingerprint,
          s.policyFingerprint
        ]
      )
    }
  });
}, Pl = (e, t) => {
  const r = We(t), i = bo(e);
  if (r.status !== "success" || r.artifact.action !== "rebase" || r.artifact.artifactFingerprint !== e.admissionArtifactFingerprint || r.artifact.commandFingerprint !== e.regenerationHandoff.fingerprint || r.artifact.policyFingerprint !== e.policyFingerprint || r.artifact.documentId !== e.currentBaseBinding.documentId)
    return c({
      status: "failure",
      handoff: null,
      diagnostic: ce({
        code: "collaboration-admission-invalid",
        stage: "authorization",
        path: "$.admission",
        recovery: "reject"
      })
    });
  const n = {
    kind: "zx-ai-collaboration-rebase-handoff-v1",
    version: ne,
    sourceRootFingerprint: i.sourceRootFingerprint,
    sourceEntryFingerprint: i.sourceEntryFingerprint,
    sourceProposalFingerprint: e.graph.root.proposalFingerprint,
    sourceReviewFingerprint: i.sourceReviewFingerprint,
    sourceDecisionFingerprint: i.sourceDecisionFingerprint,
    sourceBaseBindingFingerprint: i.sourceBaseBindingFingerprint,
    currentBaseBindingFingerprint: i.currentBaseBindingFingerprint,
    survivingAnchorFingerprints: i.survivingAnchorFingerprints,
    operationIntentDigests: i.operationIntentDigests,
    latestSemanticSnapshotFingerprint: i.latestSemanticSnapshotFingerprint,
    regenerationHandoffFingerprint: i.regenerationHandoffFingerprint,
    sourceTerminalSidecarFingerprint: i.sourceTerminalSidecarFingerprint,
    policyFingerprint: e.policyFingerprint,
    admission: r.artifact,
    admissionFingerprint: r.artifact.fingerprint,
    nextProposalId: i.nextProposalId,
    nextVariantId: i.nextVariantId
  }, s = c({
    ...n,
    fingerprint: B(
      "rebase-handoff",
      n,
      [
        n.sourceRootFingerprint,
        ...n.sourceEntryFingerprint ? [n.sourceEntryFingerprint] : [],
        n.sourceProposalFingerprint,
        n.sourceReviewFingerprint,
        n.sourceDecisionFingerprint,
        n.sourceBaseBindingFingerprint,
        n.currentBaseBindingFingerprint,
        ...n.survivingAnchorFingerprints,
        ...n.operationIntentDigests,
        n.latestSemanticSnapshotFingerprint,
        n.regenerationHandoffFingerprint,
        n.sourceTerminalSidecarFingerprint,
        n.policyFingerprint,
        n.admissionFingerprint
      ]
    )
  }), o = pn(s);
  return o.status === "success" ? c({ status: "success", handoff: o.artifact }) : c({
    status: "failure",
    handoff: null,
    diagnostic: o.diagnostic
  });
}, eg = async (e) => {
  const t = await It({
    port: e.policy,
    receipt: e.admission,
    expectedDocumentId: e.prepared.currentBaseBinding.documentId,
    expectedAction: "rebase",
    expectedCommandFingerprint: e.prepared.regenerationHandoff.fingerprint,
    expectedArtifactFingerprint: e.prepared.admissionArtifactFingerprint,
    expectedPolicyFingerprint: e.prepared.policyFingerprint,
    logicalTime: e.logicalTime
  });
  return t.status === "verified" ? Pl(e.prepared, t.receipt) : c({
    status: "failure",
    handoff: null,
    diagnostic: t.diagnostic
  });
}, tg = (e, t) => e.sourceRootFingerprint === t.sourceRootFingerprint && e.sourceEntryFingerprint === t.sourceEntryFingerprint && e.fingerprint === t.fingerprint ? "idempotent" : "identity-conflict", wt = (e) => c({
  status: "failure",
  diagnostic: ce({
    code: "collaboration-rebase-unsupported",
    stage: "rebase",
    path: e,
    recovery: "replan"
  })
}), $l = async (e) => {
  const t = pn(e.handoff);
  if (t.status !== "success") return wt("$.handoff");
  const r = t.artifact, i = B(
    "rebase-successor-identity",
    {
      handoffFingerprint: r.fingerprint,
      nextProposalId: r.nextProposalId,
      nextVariantId: r.nextVariantId
    },
    [r.fingerprint]
  ), n = await e.port.publishSourceTerminalEntry({
    handoffFingerprint: r.fingerprint,
    sourceRootFingerprint: r.sourceRootFingerprint,
    sourceEntryFingerprint: r.sourceEntryFingerprint,
    sourceTerminalSidecarFingerprint: r.sourceTerminalSidecarFingerprint,
    successorIdentityFingerprint: i
  });
  if (n.status !== "success" || !C(n.terminalEntryFingerprint))
    return wt("$.sourceTerminalEntry");
  const s = await e.port.regenerateS2({
    handoffFingerprint: r.fingerprint,
    latestSemanticSnapshotFingerprint: r.latestSemanticSnapshotFingerprint,
    operationIntentDigests: r.operationIntentDigests
  });
  if (s.status !== "success" || !C(s.operationEnvelopeFingerprint))
    return wt("$.s2");
  const o = await e.port.validateS2({
    handoffFingerprint: r.fingerprint,
    operationEnvelopeFingerprint: s.operationEnvelopeFingerprint
  });
  if (o.status !== "success" || !C(o.validatedEnvelopeFingerprint))
    return wt("$.s2Validation");
  const a = await e.port.executeRuntimeV2({
    handoffFingerprint: r.fingerprint,
    validatedEnvelopeFingerprint: o.validatedEnvelopeFingerprint,
    currentBaseBindingFingerprint: r.currentBaseBindingFingerprint
  });
  if (a.status !== "success" || !C(a.runtimeReceiptFingerprint))
    return wt("$.runtimeV2");
  const d = await e.port.createS3Successor({
    handoffFingerprint: r.fingerprint,
    runtimeReceiptFingerprint: a.runtimeReceiptFingerprint,
    nextProposalId: r.nextProposalId,
    nextVariantId: r.nextVariantId
  });
  if (d.status !== "success" || d.proposalId !== r.nextProposalId || d.variantId !== r.nextVariantId || !C(d.proposalFingerprint) || !C(d.lifecycleFingerprint))
    return wt("$.s3");
  const l = await e.port.createS4Successor({
    handoffFingerprint: r.fingerprint,
    proposalFingerprint: d.proposalFingerprint,
    lifecycleFingerprint: d.lifecycleFingerprint
  });
  if (l.status !== "success" || !P(l.reviewId) || !C(l.sidecarFingerprint))
    return wt("$.s4");
  const g = await e.port.publishSuccessorRoot({
    handoffFingerprint: r.fingerprint,
    sourceRootFingerprint: r.sourceRootFingerprint,
    proposalFingerprint: d.proposalFingerprint,
    lifecycleFingerprint: d.lifecycleFingerprint,
    reviewId: l.reviewId,
    sidecarFingerprint: l.sidecarFingerprint,
    sourceTerminalEntryFingerprint: n.terminalEntryFingerprint
  });
  if (g.status !== "success" || !C(g.rootFingerprint))
    return wt("$.successorRoot");
  const u = {
    sourceHandoffFingerprint: r.fingerprint,
    sourceTerminalEntryFingerprint: n.terminalEntryFingerprint,
    sourceRootFingerprint: r.sourceRootFingerprint,
    successorRootFingerprint: g.rootFingerprint,
    proposalFingerprint: d.proposalFingerprint,
    lifecycleFingerprint: d.lifecycleFingerprint,
    reviewId: l.reviewId,
    sidecarFingerprint: l.sidecarFingerprint
  };
  return c({
    status: "success",
    sourceHandoffFingerprint: r.fingerprint,
    sourceTerminalEntryFingerprint: n.terminalEntryFingerprint,
    successorRootFingerprint: g.rootFingerprint,
    proposalFingerprint: d.proposalFingerprint,
    lifecycleFingerprint: d.lifecycleFingerprint,
    reviewId: l.reviewId,
    sidecarFingerprint: l.sidecarFingerprint,
    lineageFingerprint: B(
      "rebase-lineage",
      u,
      [
        u.sourceHandoffFingerprint,
        u.sourceTerminalEntryFingerprint,
        u.sourceRootFingerprint,
        u.successorRootFingerprint,
        u.proposalFingerprint,
        u.lifecycleFingerprint,
        u.sidecarFingerprint
      ]
    )
  });
}, Tr = (e) => c({
  status: "failure",
  lineage: null,
  diagnostic: ce({
    code: "collaboration-invariant-violation",
    stage: "rebase",
    path: e,
    recovery: "reject"
  })
}), jl = (e) => {
  var F, w;
  const t = dr(e.sourceTerminalEntry), r = pn(
    e.sourceHandoff
  ), i = De(
    e.currentBaseBinding
  ), n = _r(e.successorRoot), s = Pt(
    e.successorTransfer
  ), o = De(
    e.successorBaseBinding
  );
  if (t.status !== "success" || i.status !== "success" || n.status !== "success" || s.status !== "success" || o.status !== "success" || !e.sourceGraph.root)
    return Tr("$");
  const a = t.artifact, d = a.terminalLineage, l = e.sourceGraph.root, g = n.artifact, u = s.transfer, p = o.artifact, f = a.entryKind === "conflict-resolution" ? a.commandFingerprint : null, m = a.entryKind === "rebase", y = a.entryKind === "conflict-resolution", I = e.sourceHandoff.fingerprint;
  if (!m && !y || d === null || !C(I) || d.sourceHandoffFingerprint !== I || m && d.currentBaseBindingFingerprint !== null || y && (d.currentBaseBindingFingerprint !== i.artifact.fingerprint || ((F = a.terminalCurrentBaseBinding) == null ? void 0 : F.fingerprint) !== i.artifact.fingerprint) || !C(d.successorIdentityFingerprint) || d.successorRootFingerprint !== g.fingerprint || d.sourceRootFingerprint !== l.fingerprint || a.rootFingerprint !== l.fingerprint || a.reviewId !== l.reviewId || e.sourceGraph.status !== "accepted" || e.sourceGraph.acceptedHeadFingerprint !== a.fingerprint || g.reviewId !== u.sidecar.identity.reviewId || g.sessionTransferFingerprint !== u.fingerprint || g.proposalFingerprint !== u.proposal.fingerprint || g.lifecycleFingerprint !== u.lifecycle.fingerprint || g.initialSidecarFingerprint !== u.sidecar.fingerprint || g.baseBindingFingerprint !== p.fingerprint || p.reviewId !== g.reviewId || p.proposalFingerprint !== g.proposalFingerprint || p.lifecycleFingerprint !== g.lifecycleFingerprint || p.sidecarFingerprint !== g.initialSidecarFingerprint || y && ((w = a.command) == null ? void 0 : w.kind) !== "zx-ai-collaboration-conflict-resolution-command-v1" || m && (r.status !== "success" || r.artifact.fingerprint !== d.sourceHandoffFingerprint || r.artifact.sourceRootFingerprint !== l.fingerprint || r.artifact.sourceEntryFingerprint !== a.priorEntryFingerprint || r.artifact.sourceProposalFingerprint !== l.proposalFingerprint || r.artifact.sourceReviewFingerprint !== a.priorSidecarFingerprint || r.artifact.sourceBaseBindingFingerprint !== l.baseBindingFingerprint || r.artifact.currentBaseBindingFingerprint !== i.artifact.fingerprint || r.artifact.sourceTerminalSidecarFingerprint !== a.resultingSidecarFingerprint || r.artifact.nextProposalId !== u.proposal.identity.proposalId || r.artifact.nextVariantId !== u.proposal.identity.variantId) || y && (e.sourceHandoff.kind !== "zx-ai-review-regeneration-handoff-v1" || e.sourceHandoff.reviewFingerprint !== a.priorSidecarFingerprint || e.sourceHandoff.supersededProposalFingerprint !== l.proposalFingerprint))
    return Tr("$.bindings");
  const h = {
    kind: "zx-ai-collaboration-successor-lineage-v1",
    version: ne,
    reviewId: g.reviewId,
    rootFingerprint: g.fingerprint,
    sourceReviewId: l.reviewId,
    sourceRootFingerprint: l.fingerprint,
    sourceHeadFingerprint: d.sourceHeadFingerprint,
    sourceEntryFingerprint: a.priorEntryFingerprint,
    sourceReviewFingerprint: a.priorSidecarFingerprint,
    sourceTerminalEntryFingerprint: a.fingerprint,
    sourceTerminalSidecarFingerprint: a.resultingSidecarFingerprint,
    sourceTerminalArtifactFingerprint: a.terminalHistoricalEnvelope.closureFingerprint,
    sourceTerminalLineageFingerprint: d.fingerprint,
    sourceHandoffFingerprint: I,
    sourceResolutionCommandFingerprint: f,
    sourceProposalFingerprint: l.proposalFingerprint,
    sourceBaseBindingFingerprint: l.baseBindingFingerprint,
    currentBaseBindingFingerprint: i.artifact.fingerprint,
    successorIdentityFingerprint: d.successorIdentityFingerprint,
    successorTransferFingerprint: u.fingerprint,
    successorProposalFingerprint: u.proposal.fingerprint,
    successorLifecycleFingerprint: u.lifecycle.fingerprint,
    successorSidecarFingerprint: u.sidecar.fingerprint,
    successorBaseBindingFingerprint: p.fingerprint
  }, v = c({
    ...h,
    fingerprint: B(
      "successor-lineage",
      h,
      [
        h.rootFingerprint,
        h.sourceRootFingerprint,
        h.sourceHeadFingerprint,
        ...h.sourceEntryFingerprint ? [h.sourceEntryFingerprint] : [],
        h.sourceReviewFingerprint,
        h.sourceTerminalEntryFingerprint,
        h.sourceTerminalSidecarFingerprint,
        h.sourceTerminalArtifactFingerprint,
        h.sourceTerminalLineageFingerprint,
        h.sourceHandoffFingerprint,
        ...h.sourceResolutionCommandFingerprint ? [h.sourceResolutionCommandFingerprint] : [],
        h.sourceProposalFingerprint,
        h.sourceBaseBindingFingerprint,
        h.currentBaseBindingFingerprint,
        h.successorIdentityFingerprint,
        h.successorTransferFingerprint,
        h.successorProposalFingerprint,
        h.successorLifecycleFingerprint,
        h.successorSidecarFingerprint,
        h.successorBaseBindingFingerprint
      ]
    )
  });
  return Dr(v).status === "success" ? c({ status: "success", lineage: v }) : Tr("$.fingerprint");
}, rg = (e, t) => {
  const r = Dr(e), i = jl(t);
  return r.status === "success" && i.status === "success" && r.artifact.fingerprint === i.lineage.fingerprint ? c({ status: "success", lineage: r.artifact }) : Tr("$.lineage");
}, ig = async (e) => {
  const t = Dr(e.lineage);
  if (t.status !== "success")
    return Tr("$.lineage");
  const r = ft(t.artifact), i = await e.adapter.appendRecord({
    storageKey: r,
    value: t.artifact,
    originKind: "log"
  });
  if (!["appended", "idempotent"].includes(i.status))
    return c({
      status: i.status === "conflict" ? "storage-conflict" : "failure",
      lineage: null,
      diagnostic: ce({
        code: i.status === "conflict" ? "collaboration-storage-conflict" : "collaboration-invariant-violation",
        stage: "storage",
        path: "$.append",
        recovery: i.status === "conflict" ? "resolve-conflict" : "reconnect"
      })
    });
  const s = (await e.adapter.enumerateRecords({
    documentId: e.adapter.documentId,
    reviewId: t.artifact.reviewId
  })).records.find(
    (a) => a.storageKey === r
  ), o = Dr(s == null ? void 0 : s.value);
  return o.status === "success" && o.artifact.fingerprint === t.artifact.fingerprint ? c({
    status: i.status === "appended" ? "published" : "idempotent",
    lineage: o.artifact,
    storageKey: r
  }) : c({
    status: "failure",
    lineage: null,
    diagnostic: ce({
      code: "collaboration-storage-conflict",
      stage: "storage",
      path: "$.reread",
      recovery: "reconnect"
    })
  });
}, ng = (e) => {
  let t = (e == null ? void 0 : e.initialLogicalTime) ?? 1, r = 0;
  const i = [], n = async (s) => {
    for (; i.length > 0; ) {
      const o = s ? i.pop() : i.shift();
      o.cancelled || (t += 1, await o.task());
    }
  };
  return {
    now: () => t,
    schedule(s, o) {
      const a = {
        sequence: ++r,
        label: s,
        task: o,
        cancelled: !1
      };
      return i.push(a), { cancel: () => a.cancelled = !0 };
    },
    pending: () => i.filter((s) => !s.cancelled).length,
    advance(s = 1) {
      if (!Number.isSafeInteger(s) || s < 0)
        throw new TypeError("collaboration-logical-scheduler-step-invalid");
      t += s;
    },
    flushFIFO: () => n(!1),
    flushReverse: () => n(!0),
    clear() {
      i.splice(0).forEach((s) => s.cancelled = !0);
    }
  };
}, Yt = (e, t, r) => c({
  status: "unavailable",
  reason: e,
  providerStatus: t,
  pendingOfflineIntents: r
}), Dl = (e) => e.status === "accepted" || e.status === "review-conflict" ? "verified" : e.status === "pending" ? "pending" : e.status === "storage-conflict" ? "denied" : "invalid", sg = (e) => {
  if (e.namespace !== Ct || !Ge(e.limits, ae) || e.documentId !== e.adapter.documentId || e.documentId !== e.baseBinding.documentId || e.transfer.sidecar.identity.reviewId !== e.baseBinding.reviewId)
    throw new TypeError("collaboration-runtime-input-invalid");
  const t = ql(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set();
  let n = "disconnected", s = 0, o = !1, a = Yt("pending-sync", n, t.size());
  const d = (p) => {
    a = p, r.forEach((f) => f(a));
  }, l = (p) => {
    if (n = p, s += 1, a.status === "ready") {
      const y = _n({
        providerStatus: n,
        actors: e.readAwarenessActors()
      });
      d(
        c({
          ...a,
          freshness: p === "synced" ? a.freshness : "stale",
          providerStatus: n,
          projection: Ln({
            durable: a.projection.durable,
            ephemeral: y
          }),
          pendingOfflineIntents: t.size()
        })
      );
    } else
      d(Yt("pending-sync", n, t.size()));
    if (p !== "synced") return;
    let f, m = !1;
    f = e.scheduler.schedule("provider-status", async () => {
      await u(), m = !0, f && i.delete(f);
    }), m || i.add(f);
  }, g = e.adapter.observeStatus(l), u = async () => {
    if (o) return a;
    if (n !== "synced")
      return d(Yt("pending-sync", n, t.size())), a;
    const p = ++s;
    d(Yt("refreshing", n, t.size()));
    try {
      const f = await e.adapter.enumerateRecords({
        documentId: e.documentId,
        reviewId: e.transfer.sidecar.identity.reviewId
      }), m = await fn({
        enumeration: f,
        transfer: e.transfer,
        baseBinding: e.baseBinding,
        policy: e.policy,
        logicalTime: e.scheduler.now()
      }), y = ri(m), I = m.status === "review-conflict" || y !== null && ["reconciled", "idempotent"].includes(y.status), h = e.readCurrentContext(), v = Dl(m), F = I ? v : "invalid", w = Io({
        graph: m,
        baseBinding: e.baseBinding,
        currentBinding: h.binding,
        policyStatus: F,
        schemaCompatible: h.schemaCompatible,
        runtimeCompatible: h.runtimeCompatible,
        capabilityCompatible: h.capabilityCompatible,
        currentTargetAdmissible: h.currentTargetAdmissible,
        anchors: h.anchors
      }), x = await e.policy.verifyCommitFence({
        documentId: e.documentId,
        reviewId: e.transfer.sidecar.identity.reviewId
      });
      if (o || p !== s || n !== "synced")
        return a;
      const j = Cl({
        graph: m,
        baseBinding: e.baseBinding,
        currentBinding: h.binding,
        drift: w,
        policyStatus: F,
        commitFenceStatus: x
      }), _ = Ln({
        durable: j,
        ephemeral: _n({
          providerStatus: n,
          actors: e.readAwarenessActors()
        })
      });
      d(
        c({
          status: "ready",
          freshness: "complete",
          providerStatus: n,
          graph: m,
          projection: _,
          pendingOfflineIntents: t.size()
        })
      );
    } catch {
      !o && p === s && n === "synced" && d(Yt("failure", n, t.size()));
    }
    return a;
  };
  return {
    snapshot: () => a,
    observe(p) {
      return o ? () => {
      } : (r.add(p), () => r.delete(p));
    },
    refresh: u,
    queueOfflineDecision(p) {
      if (o) return "invalid";
      const f = t.enqueue(p);
      return a.status === "ready" && d(c({ ...a, pendingOfflineIntents: t.size() })), f;
    },
    async reconnect(p) {
      if (o)
        return c({
          replayStatus: "failure",
          replayedCommandIds: [],
          stageTrace: [],
          snapshot: a
        });
      const f = await t.reconnect({
        fullySynced: p.fullySynced && n === "synced",
        documentId: e.documentId,
        transfer: e.transfer,
        baseBinding: e.baseBinding,
        adapter: e.adapter,
        policy: e.policy,
        logicalTime: e.scheduler.now(),
        admissionPolicyFingerprint: e.readAdmissionPolicyFingerprint(),
        admit: p.admit
      }), m = await u();
      return c({
        replayStatus: f.status,
        replayedCommandIds: f.replayedCommandIds,
        stageTrace: f.stageTrace,
        snapshot: m
      });
    },
    destroy() {
      o || (o = !0, s += 1, g(), i.forEach((p) => p.cancel()), i.clear(), r.clear(), t.clear(), e.adapter.destroy(), a = Yt("destroyed", n, 0));
    }
  };
}, Gr = {
  version: 2,
  body: {
    format: "json",
    content: {
      type: "doc",
      content: [
        {
          type: "paragraph",
          attrs: { textAlign: null, blockId: "p_alpha" },
          content: [{ type: "text", text: "alpha" }]
        },
        {
          type: "paragraph",
          attrs: { textAlign: null, blockId: "p_beta" },
          content: [{ type: "text", text: "beta" }]
        }
      ]
    }
  },
  annotations: [],
  assets: [],
  meta: { schemaVersion: "stable-block-identity/v2" }
};
let Fo = 0;
const og = async () => {
  const e = ++Fo, t = (u) => `${u}:${e}`, r = await ci({
    document: Gr,
    scope: { kind: "document" }
  }), i = await Di(r, "p_alpha"), n = await Di(
    r,
    "p_beta"
  );
  if (!i.valid || !n.valid)
    throw new TypeError("collaboration-workbench-precondition-invalid");
  const s = {
    protocolVersion: gs,
    source: {
      snapshotFingerprint: r.fingerprint,
      documentRevision: r.documentRevision,
      descriptorFingerprint: r.descriptorFingerprint,
      registryFingerprint: fs
    },
    operations: [
      {
        kind: "text.replace",
        target: { blockId: "p_alpha", startOffset: 0, endOffset: 5 },
        precondition: i.precondition,
        text: "ALPHA"
      },
      {
        kind: "text.replace",
        target: { blockId: "p_beta", startOffset: 0, endOffset: 4 },
        precondition: n.precondition,
        text: "BETA"
      }
    ]
  }, o = zr({
    kind: "operation-envelope",
    contentDigest: pe(s),
    resourceTotals: { eventCount: 1, textBytes: 9, toolSummaryCount: 0 },
    operationEnvelope: s
  }), a = await ln({
    sealedResult: o,
    effect: {
      effectId: t("workbench-effect:proposal-handoff"),
      kind: "proposal-handoff",
      sessionId: t("workbench-session:collaboration-rebase"),
      requestId: t("workbench-request:collaboration-rebase"),
      attemptId: t("workbench-attempt:collaboration-rebase"),
      sourceRevision: 1,
      sourceFingerprint: pe({ source: "workbench", runId: e }),
      idempotencyKey: t("workbench-effect:proposal-handoff"),
      sealedResultFingerprint: o.fingerprint,
      resultKind: "operation-envelope"
    },
    snapshot: r,
    baseDocument: Gr,
    proposalId: t("workbench-proposal:collaboration-rebase"),
    variantId: t("workbench-variant:one"),
    reviewId: t("workbench-review:collaboration-rebase")
  });
  if (a.status !== "awaiting-review")
    throw new TypeError("collaboration-workbench-handoff-failed");
  const d = c({
    id: "document-v2",
    version: "2.0.0",
    fingerprint: pe({ id: "document-v2", version: "2.0.0" })
  }), l = c({
    id: kr.kind,
    version: kr.version,
    fingerprint: kr.fingerprint
  }), g = c({
    id: Ar.id,
    version: Ar.version,
    fingerprint: Ar.fingerprint
  });
  return c({
    transfer: a.transfer,
    baseDocument: Gr,
    schemaRef: d,
    runtimeRef: l,
    policyRef: g,
    documentFingerprint: pe(Gr)
  });
}, ag = async (e) => {
  var f, m;
  const t = ++Fo, r = await ci({
    document: e.latestDocument,
    scope: { kind: "document" }
  });
  if (r.fingerprint !== e.expectedSemanticSnapshotFingerprint)
    throw new TypeError("collaboration-workbench-rebase-snapshot-drift");
  const i = await Di(r, "p_alpha");
  if (!i.valid)
    throw new TypeError("collaboration-workbench-rebase-precondition-invalid");
  const n = (f = e.latestDocument.body.content.content) == null ? void 0 : f.find(
    (y) => {
      var I;
      return ((I = y.attrs) == null ? void 0 : I.blockId) === "p_alpha";
    }
  ), s = (m = n == null ? void 0 : n.content) == null ? void 0 : m.map((y) => y.text ?? "").join("");
  if (typeof s != "string")
    throw new TypeError("collaboration-workbench-rebase-source-missing");
  const o = {
    protocolVersion: gs,
    source: {
      snapshotFingerprint: r.fingerprint,
      documentRevision: r.documentRevision,
      descriptorFingerprint: r.descriptorFingerprint,
      registryFingerprint: fs
    },
    operations: [
      {
        kind: "text.replace",
        target: {
          blockId: "p_alpha",
          startOffset: 0,
          endOffset: s.length
        },
        precondition: i.precondition,
        text: "ALPHA REBASED"
      }
    ]
  }, a = await Zi({
    snapshot: r,
    envelope: o
  });
  if (!a.valid || !a.plan)
    throw new TypeError("collaboration-workbench-rebase-s2-invalid");
  const d = pe(o), l = pe(a.plan), g = zr({
    kind: "operation-envelope",
    contentDigest: d,
    resourceTotals: {
      eventCount: 1,
      textBytes: 13,
      toolSummaryCount: 0
    },
    operationEnvelope: o
  }), u = (y) => `${y}:${t}`, p = await ln({
    sealedResult: g,
    effect: {
      effectId: u("workbench-rebase-effect"),
      kind: "proposal-handoff",
      sessionId: u("workbench-rebase-session"),
      requestId: u("workbench-rebase-request"),
      attemptId: u("workbench-rebase-attempt"),
      sourceRevision: 1,
      sourceFingerprint: pe({
        domain: "workbench-rebase-source",
        semanticSnapshotFingerprint: r.fingerprint,
        operationIntentDigests: e.operationIntentDigests
      }),
      idempotencyKey: u("workbench-rebase-effect"),
      sealedResultFingerprint: g.fingerprint,
      resultKind: "operation-envelope"
    },
    snapshot: r,
    baseDocument: e.latestDocument,
    proposalId: e.proposalId,
    variantId: e.variantId,
    reviewId: e.reviewId
  });
  if (p.status !== "awaiting-review")
    throw new TypeError("collaboration-workbench-rebase-handoff-failed");
  return c({
    transfer: p.transfer,
    semanticSnapshotFingerprint: r.fingerprint,
    operationEnvelopeFingerprint: d,
    validatedEnvelopeFingerprint: l,
    runtimeReceiptFingerprint: p.transfer.proposal.runtimeExecution.trace.fingerprint
  });
}, cg = async (e) => {
  const t = "workbench-commit:fenced-accept", r = ao({
    commandId: t,
    graph: e.graph,
    reconciled: e.reconciled,
    currentBinding: e.currentBinding,
    drift: e.drift
  });
  if (!r)
    throw new TypeError("collaboration-workbench-commit-command-failed");
  const i = On({
    principalRef: e.principalRef,
    documentId: e.currentBinding.documentId,
    action: "commit",
    commandFingerprint: r.fingerprint,
    artifactFingerprint: co({
      command: r,
      principalRef: e.principalRef
    }),
    policyFingerprint: e.currentBinding.policyRef.fingerprint,
    issuedAtLogicalTime: e.logicalTime,
    expiresAtLogicalTime: e.logicalTime + 100,
    verifierEvidenceFingerprint: pe({
      domain: "collaboration-workbench-commit-evidence",
      commandFingerprint: r.fingerprint
    })
  });
  return ml({
    commandId: t,
    graph: e.graph,
    reconciled: e.reconciled,
    currentBinding: e.currentBinding,
    drift: e.drift,
    principalRef: e.principalRef,
    admission: i,
    logicalSequence: e.logicalSequence,
    logicalTime: e.logicalTime,
    adapter: e.adapter,
    policy: e.policy,
    authorizeTerminal: ({ command: n, artifactFingerprint: s, logicalTime: o }) => On({
      principalRef: e.principalRef,
      documentId: e.currentBinding.documentId,
      action: "commit",
      commandFingerprint: n.fingerprint,
      artifactFingerprint: s,
      policyFingerprint: e.currentBinding.policyRef.fingerprint,
      issuedAtLogicalTime: o,
      expiresAtLogicalTime: o + 100,
      verifierEvidenceFingerprint: pe({
        domain: "collaboration-workbench-terminal-evidence",
        commandFingerprint: n.fingerprint,
        artifactFingerprint: s
      })
    }),
    runS4Commit: e.runS4Commit,
    createProposalEnvelope: e.createProposalEnvelope
  });
}, dg = (e) => {
  const t = Io(e.s7);
  return e.address.kind === "validated-path" || e.policy === "exact-snapshot" ? c({
    status: t.disposition === "unchanged" ? "unchanged" : "conflict",
    drift: t
  }) : c({
    status: t.disposition === "unchanged" || t.disposition === "replication-coordinate-changed" ? "surviving" : t.disposition === "replan-required" ? "successor-required" : "conflict",
    drift: t
  });
}, lg = (e) => e.address.kind === "stable-local" ? $l({
  handoff: e.handoff,
  port: e.port
}) : Promise.resolve(
  c({
    status: "failure",
    diagnostic: {
      code: "collaboration-rebase-unsupported",
      severity: "error",
      stage: "rebase",
      path: "$.complexNode.address",
      recovery: "resolve-conflict"
    }
  })
), pg = 1, ug = 1, fg = (e) => {
  const t = /* @__PURE__ */ new Set();
  return {
    isolated: !0,
    async run(r) {
      if (e.forcedStatus)
        return c({
          status: e.forcedStatus,
          canonicalOutput: null
        });
      if (t.has(r.executionId))
        return c({ status: "cancelled", canonicalOutput: null });
      try {
        const i = JSON.parse(
          new TextDecoder().decode(r.canonicalInput)
        ), n = Ra(e.registry, {
          descriptor: i.adapter.descriptor,
          nodeType: i.adapter.nodeType,
          adapterId: i.adapter.adapterId
        }), s = n == null ? void 0 : n.operations[i.operation];
        if (!n || !s || s.compiler.id !== r.component.id || s.compiler.version !== r.component.version || s.compiler.fingerprint !== r.component.fingerprint)
          return c({ status: "failure", canonicalOutput: null });
        const o = s.validate(i.input), a = ka(o);
        return a.byteLength > r.maxOutputBytes ? c({ status: "over-limit", canonicalOutput: null }) : c({ status: "success", canonicalOutput: a });
      } catch {
        return c({ status: "malformed", canonicalOutput: null });
      }
    },
    terminate(r) {
      t.add(r);
    }
  };
}, he = (e) => {
  const t = {
    ...e,
    zxuiDifference: `ZXUI ${e.decision} keeps the portable mechanism "${e.mechanism}" but replaces upstream authority with: ${e.zxuiBoundary}`
  };
  return c({
    ...t,
    fingerprint: Ue("reference-provenance", t)
  });
}, zl = c([
  he({
    id: "REF-BN-UPDATE",
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    sourcePath: "packages/xl-ai/src/api/formats/base-tools/createUpdateBlockTool.ts",
    decision: "adapt",
    mechanism: "typed update narrows complex block changes",
    zxuiBoundary: "S2 envelope and adapter registry remain authoritative",
    fixtureIds: ["BN-update-typed", "BN-unknown-prop"]
  }),
  he({
    id: "REF-BN-STREAM",
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    sourcePath: "packages/xl-ai/src/streamTool/StreamToolExecutor.ts",
    decision: "adapt",
    mechanism: "partial tool state and completion routing",
    zxuiBoundary: "partial state belongs only to S5/S6",
    fixtureIds: ["BN-stream-chunks", "BN-stream-incomplete"]
  }),
  he({
    id: "REF-BN-TABLE",
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    sourcePath: "packages/core/src/api/blockManipulation/tables/tables.ts",
    decision: "adapt",
    mechanism: "row/cell operations and occupancy expectations",
    zxuiBoundary: "PM schema and S2 semantic plans replace BlockNote truth",
    fixtureIds: ["BN-table-span", "BN-table-selected-cell"]
  }),
  he({
    id: "REF-BN-CUSTOM",
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    sourcePath: "packages/core/src/schema/blocks/extendBlockSpec.test.ts",
    decision: "adapt",
    mechanism: "custom extension round trip",
    zxuiBoundary: "trusted host-installed adapter without dynamic compiler",
    fixtureIds: ["BN-custom-roundtrip"]
  }),
  he({
    id: "REF-PL-TABLE-PROMPT",
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    sourcePath: "apps/www/src/registry/app/api/ai/command/prompt/getEditTablePrompt.ts",
    decision: "adapt",
    mechanism: "selected-cell-only intent",
    zxuiBoundary: "prompt output is untrusted; adapter validates the cell",
    fixtureIds: ["PL-selected-cell-only"]
  }),
  he({
    id: "REF-PL-CELL-ID",
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    sourcePath: "packages/ai/src/react/ai-chat/utils/applyTableCellSuggestion.ts",
    decision: "adapt",
    mechanism: "stable cell reference alignment",
    zxuiBoundary: "materialized rowId/cellId plus S7, never React state",
    fixtureIds: ["PL-cell-id", "PL-cell-missing"]
  }),
  he({
    id: "REF-PL-STREAM",
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    sourcePath: "packages/ai/src/react/ai-chat/streaming/streamInsertChunk.ts",
    decision: "adapt/reject",
    mechanism: "complex-block atomic routing signal",
    zxuiBoundary: "reject direct Slate mutation",
    fixtureIds: ["PL-complex-atomic"]
  }),
  he({
    id: "REF-PL-MEDIA",
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    sourcePath: "packages/media/src/lib/BaseMediaPluginContracts.spec.ts",
    decision: "adapt",
    mechanism: "media contract and placeholder failure",
    zxuiBoundary: "document.assets and host receipt own resource validity",
    fixtureIds: ["PL-media-invalid", "PL-media-placeholder"]
  }),
  he({
    id: "REF-NOVEL-EXT",
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    sourcePath: "packages/headless/src/extensions/index.ts",
    decision: "adapt",
    mechanism: "extension composition",
    zxuiBoundary: "canonical descriptor remains package-owned",
    fixtureIds: ["NV-extension-composition"]
  }),
  he({
    id: "REF-NOVEL-CUSTOM",
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    sourcePath: "packages/headless/src/extensions/twitter.tsx",
    decision: "adapt/reject",
    mechanism: "custom node-view round trip",
    zxuiBoundary: "adapt schema/render fixture; reject render-view compiler",
    fixtureIds: ["NV-custom-node-roundtrip"]
  }),
  he({
    id: "REF-NOVEL-UPLOAD",
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    sourcePath: "packages/headless/src/plugins/upload-images.tsx",
    decision: "reject/adapt",
    mechanism: "upload and placeholder UX",
    zxuiBoundary: "host stages assets; S8 references canonical assetId only",
    fixtureIds: ["NV-upload-failure"]
  }),
  he({
    id: "REF-NOVEL-AI",
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    sourcePath: "apps/web/components/tailwind/generative/ai-completion-command.tsx",
    decision: "reject/adapt",
    mechanism: "command taxonomy and progressive disclosure",
    zxuiBoundary: "S6 owns UX; reject direct insertContentAt mutation",
    fixtureIds: ["NV-command-taxonomy"]
  }),
  he({
    id: "REF-TIPTAP-NODE",
    repository: "Tiptap",
    commit: "3.30.1",
    sourcePath: "packages/core/src/Node.ts",
    decision: "adapt",
    mechanism: "attrs/content/atom/isolating schema semantics",
    zxuiBoundary: "schema kernel is canonical; Tiptap is the editor adapter",
    fixtureIds: ["TT-node-flags"]
  }),
  he({
    id: "REF-TIPTAP-TABLE",
    repository: "Tiptap",
    commit: "3.30.1",
    sourcePath: "packages/extension-table/src/table.ts",
    decision: "adapt",
    mechanism: "table extension schema attributes and isolation semantics",
    zxuiBoundary: "package-owned rowId/cellId and S2 validation extend Tiptap without granting mutation authority",
    fixtureIds: ["TT-table-roundtrip"]
  }),
  he({
    id: "REF-PM-TABLEMAP",
    repository: "prosemirror-tables",
    commit: "1.8.5",
    sourcePath: "src/tablemap.ts",
    decision: "adapt",
    mechanism: "span-aware rectangular occupancy map",
    zxuiBoundary: "pure validator only; no direct mutation",
    fixtureIds: ["PM-span-grid"]
  }),
  he({
    id: "REF-PM-MAPPING",
    repository: "ProseMirror",
    commit: "official-api-2026-08-29",
    sourcePath: "prosemirror-transform/src/map.ts",
    decision: "adapt",
    mechanism: "runtime-local positional Mapping",
    zxuiBoundary: "mapping remains Runtime-local and is never persisted as stable identity",
    fixtureIds: ["PM-mapping-local"]
  }),
  he({
    id: "REF-Y-RELATIVE",
    repository: "Yjs",
    commit: "13.6.31",
    sourcePath: "src/utils/RelativePosition.js",
    decision: "adapt",
    mechanism: "collaboration-stable relative position",
    zxuiBoundary: "combined with block/local identity and owned by S7",
    fixtureIds: ["Y-relative-anchor"]
  }),
  he({
    id: "REF-Y-ORIGIN-UNDO",
    repository: "Yjs",
    commit: "13.6.31",
    sourcePath: "src/utils/Transaction.js; src/utils/UndoManager.js",
    decision: "adapt",
    mechanism: "transaction origin and tracked undo capture",
    zxuiBoundary: "one private S7 content origin and one undo item",
    fixtureIds: ["Y-origin-single", "Y-undo-single"]
  }),
  he({
    id: "REF-Y-ORIGIN",
    repository: "Yjs",
    commit: "13.6.31",
    sourcePath: "src/utils/Transaction.js",
    decision: "adapt",
    mechanism: "transaction origin identity",
    zxuiBoundary: "only the delivered S7 private content origin may commit",
    fixtureIds: ["Y-origin-single"]
  }),
  he({
    id: "REF-Y-UNDO",
    repository: "Yjs",
    commit: "13.6.31",
    sourcePath: "src/utils/UndoManager.js",
    decision: "adapt",
    mechanism: "tracked origin and capture boundary",
    zxuiBoundary: "one accepted complex operation is one S7-managed undo item",
    fixtureIds: ["Y-undo-single"]
  }),
  he({
    id: "REF-YP",
    repository: "y-prosemirror",
    commit: "1.3.7",
    sourcePath: "src/plugins/sync-plugin.js",
    decision: "adapt",
    mechanism: "ProseMirror/Yjs binding",
    zxuiBoundary: "used only at the S7 adapter boundary",
    fixtureIds: ["YP-two-peer"]
  })
]), gg = () => zl.every(
  (e) => e.commit.length > 0 && e.sourcePath.length > 0 && e.decision.length > 0 && e.zxuiBoundary.length > 0 && e.zxuiDifference.length > 0 && e.zxuiDifference !== e.zxuiBoundary && e.zxuiDifference.includes(e.mechanism) && e.zxuiDifference.includes(e.zxuiBoundary) && e.fixtureIds.length > 0 && e.fingerprint === Ue("reference-provenance", {
    id: e.id,
    repository: e.repository,
    commit: e.commit,
    sourcePath: e.sourcePath,
    decision: e.decision,
    mechanism: e.mechanism,
    zxuiBoundary: e.zxuiBoundary,
    zxuiDifference: e.zxuiDifference,
    fixtureIds: e.fixtureIds
  })
), Ol = (e) => e, mg = (e) => {
  const t = {
    kind: "zx-ai-complex-node-resource-receipt-v1",
    ...e
  };
  return c({
    ...t,
    fingerprint: Ue("resource-receipt", t)
  });
}, xo = (e) => {
  const { fingerprint: t, ...r } = e;
  return e.kind === "zx-ai-complex-node-resource-receipt-v1" && (e.phase === "proposal" || e.phase === "commit") && Le(e.documentRevision) && Sr(e.assetId) && Le(e.assetFingerprint) && Le(e.principalFingerprint) && Le(e.adapterFingerprint) && Le(e.policyFingerprint) && Number.isSafeInteger(e.expiresAt) && Sr(e.nonce) && t === Ue(
    "resource-receipt",
    Ol(r)
  );
}, vg = () => {
  const e = /* @__PURE__ */ new Set();
  return {
    async verify(t) {
      const r = t.receipt;
      return !xo(r) || r.phase !== t.expectedPhase || r.documentRevision !== t.expectedDocumentRevision || r.assetId !== t.expectedAssetId || r.assetFingerprint !== t.expectedAssetFingerprint || r.principalFingerprint !== t.expectedPrincipalFingerprint || r.adapterFingerprint !== t.expectedAdapterFingerprint || r.policyFingerprint !== t.expectedPolicyFingerprint ? c({ status: "invalid" }) : r.expiresAt < t.logicalTime ? c({ status: "expired" }) : e.has(r.nonce) ? c({ status: "replayed" }) : (e.add(r.nonce), c({
        status: "verified",
        receiptFingerprint: r.fingerprint
      }));
    }
  };
}, wo = (e, t) => {
  var r;
  if (((r = e.attrs) == null ? void 0 : r.blockId) === t) return e;
  for (const i of e.content ?? []) {
    const n = wo(i, t);
    if (n) return n;
  }
  return null;
}, Nl = (e, t) => {
  var i;
  let r = e;
  for (const n of t) r = ((i = r == null ? void 0 : r.content) == null ? void 0 : i[n]) ?? null;
  return r;
}, hg = async (e) => {
  const t = e.sourceTransfer.proposal.base.plan.steps;
  if (t.length === 0 || t.some((d) => d.kind !== "node.apply"))
    return c({ status: "failure", transfer: null });
  const r = await ci({
    document: e.currentDocument,
    scope: { kind: "document" }
  }), i = t.map((d) => {
    if (d.kind !== "node.apply") throw new TypeError("complex-step-invalid");
    const l = ms(e.registry, {
      adapter: d.adapter,
      operation: d.operation
    }), g = wo(
      e.currentDocument.body.content,
      d.target.blockId
    );
    if (!l || !g) throw new TypeError("complex-target-drifted");
    const u = d.target.kind === "validated-path" ? Nl(g, d.target.path) : g;
    if (!u) throw new TypeError("complex-target-drifted");
    const p = d.target.kind === "validated-path" ? {
      ...d.target,
      ancestorFingerprint: Ue(
        "node-ancestor",
        g
      ),
      nodeTypeFingerprint: Ue(
        "node-type",
        u.type ?? null
      ),
      contentFingerprint: wn(u),
      shapeFingerprint: xn(u),
      sourceSnapshotFingerprint: r.fingerprint
    } : d.target.localType === "list-item" ? (() => {
      const f = Sa(
        g,
        d.target.localId
      );
      if (!f) throw new TypeError("complex-target-drifted");
      return { ...d.target, structure: f };
    })() : d.target;
    return {
      kind: "node.apply",
      adapter: d.adapter,
      target: p,
      preconditions: {
        addressFingerprint: Ea(p),
        blockId: p.blockId,
        nodeType: u.type,
        contentFingerprint: wn(u),
        shapeFingerprint: xn(u),
        capabilityFingerprint: Aa(
          l.entry,
          d.operation
        )
      },
      operation: d.operation,
      payload: d.payload
    };
  }), n = {
    protocolVersion: 2,
    source: {
      snapshotFingerprint: r.fingerprint,
      documentRevision: r.documentRevision,
      descriptorFingerprint: r.descriptorFingerprint,
      registryFingerprint: e.registry.fingerprint
    },
    operations: i
  }, s = zr({
    kind: "operation-envelope",
    contentDigest: pe(n),
    resourceTotals: {
      eventCount: 1,
      textBytes: new TextEncoder().encode(JSON.stringify(i)).length,
      toolSummaryCount: 0
    },
    operationEnvelope: n
  }), o = Ue("fresh-source", {
    sourceProposalFingerprint: e.sourceTransfer.proposal.fingerprint,
    currentDocumentRevision: r.documentRevision,
    operationEnvelope: n
  }), a = await ln(
    {
      sealedResult: s,
      effect: {
        effectId: `${e.proposalId}:fresh-handoff`,
        kind: "proposal-handoff",
        sessionId: `${e.proposalId}:fresh-session`,
        requestId: `${e.proposalId}:fresh-request`,
        attemptId: `${e.proposalId}:fresh-attempt`,
        sourceRevision: 1,
        sourceFingerprint: o,
        idempotencyKey: `${e.proposalId}:fresh-handoff`,
        sealedResultFingerprint: s.fingerprint,
        resultKind: "operation-envelope"
      },
      snapshot: r,
      baseDocument: e.currentDocument,
      proposalId: e.proposalId,
      variantId: e.variantId,
      reviewId: e.reviewId
    },
    {
      complex: {
        document: e.currentDocument,
        registry: e.registry,
        runner: e.runner,
        resourceProfileFingerprint: e.resourceProfileFingerprint,
        addressResolution: e.addressResolution,
        resourceAdmissions: e.resourceAdmissions
      }
    }
  );
  return a.status !== "awaiting-review" ? c({ status: "failure", transfer: null }) : c({
    status: "success",
    transfer: a.transfer,
    proof: {
      sourceProposalFingerprint: e.sourceTransfer.proposal.fingerprint,
      sourcePlanDigest: e.sourceTransfer.proposal.base.planDigest,
      currentDocumentRevision: r.documentRevision,
      successorProposalFingerprint: a.transfer.proposal.fingerprint,
      successorPlanDigest: a.transfer.proposal.base.planDigest,
      successorRuntimeReceiptFingerprint: a.transfer.proposal.runtimeExecution.trace.fingerprint,
      oldExecutableArtifactReused: !1,
      fingerprint: Ue("fresh-successor-proof", {
        sourceProposalFingerprint: e.sourceTransfer.proposal.fingerprint,
        sourcePlanDigest: e.sourceTransfer.proposal.base.planDigest,
        currentDocumentRevision: r.documentRevision,
        successorProposalFingerprint: a.transfer.proposal.fingerprint,
        successorPlanDigest: a.transfer.proposal.base.planDigest
      })
    }
  });
}, yg = async (e) => {
  const t = (o, a) => c({
    status: "resource-rejected",
    result: null,
    reason: o,
    operationIndex: a,
    receiptFingerprints: []
  });
  if ((await ci({
    document: e.currentDocument,
    scope: { kind: "document" }
  })).documentRevision !== e.currentDocumentRevision || e.currentDocumentRevision !== e.transfer.proposal.base.documentRevision)
    return t("current-base-mismatch", null);
  const i = [];
  for (const o of e.transfer.proposal.base.plan.steps) {
    if (o.kind !== "node.apply") continue;
    const a = ms(e.registry, {
      adapter: o.adapter,
      operation: o.operation
    });
    if (!a || a.entry.family !== "media") continue;
    const d = o.payload, l = d && typeof d == "object" && !Array.isArray(d) ? d.assetId : null, g = typeof l == "string" ? e.currentDocument.assets.find(
      (u) => u.id === l
    ) : null;
    if (!g)
      return t("media-binding-invalid", o.operationIndex);
    i.push({
      expectedPhase: "commit",
      operationIndex: o.operationIndex,
      documentRevision: e.currentDocumentRevision,
      assetId: g.id,
      assetFingerprint: Ue("asset", g),
      principalFingerprint: e.principalFingerprint,
      adapterFingerprint: a.entry.adapter.adapterFingerprint,
      policyFingerprint: e.policyFingerprint,
      logicalTime: e.logicalTime
    });
  }
  const n = [];
  for (const o of i) {
    let a;
    try {
      a = await e.requestCommitReceipt(o);
    } catch {
      return t("receipt-request-failed", o.operationIndex);
    }
    if (!xo(a) || a.phase !== "commit")
      return t("receipt-invalid", o.operationIndex);
    const d = await e.port.verify({
      receipt: a,
      expectedPhase: "commit",
      expectedDocumentRevision: o.documentRevision,
      expectedAssetId: o.assetId,
      expectedAssetFingerprint: o.assetFingerprint,
      expectedPrincipalFingerprint: o.principalFingerprint,
      expectedAdapterFingerprint: o.adapterFingerprint,
      expectedPolicyFingerprint: o.policyFingerprint,
      logicalTime: o.logicalTime
    });
    if (d.status !== "verified" || d.receiptFingerprint !== a.fingerprint) {
      const l = d.status === "expired" ? "receipt-expired" : d.status === "replayed" ? "receipt-replayed" : d.status === "unavailable" ? "receipt-unavailable" : "receipt-invalid";
      return t(l, o.operationIndex);
    }
    n.push(a.fingerprint);
  }
  const s = await e.dispatch();
  return c({
    status: "dispatched",
    result: s,
    receiptFingerprints: n
  });
}, _l = 1, qi = (e) => !!(e && typeof e == "object" && !Array.isArray(e)), Hn = (e, t) => {
  const r = Object.keys(e).sort(), i = [...t].sort();
  return r.length === i.length && r.every((n, s) => n === i[s]);
}, Ll = /* @__PURE__ */ new Set([
  "text.replace",
  "block.insert",
  "block.replace",
  "block.delete"
]), Ig = (e) => {
  try {
    vs(e), ke(e);
  } catch {
    return c({ status: "unsupported", audit: null });
  }
  return !qi(e) || !Hn(e, ["protocolVersion", "source", "operations"]) || e.protocolVersion !== 1 || !qi(e.source) || !Hn(e.source, [
    "snapshotFingerprint",
    "documentRevision",
    "descriptorFingerprint"
  ]) || !Object.values(e.source).every(
    (t) => typeof t == "string" && t.length > 0
  ) || !Array.isArray(e.operations) || e.operations.length === 0 || e.operations.some(
    (t) => !qi(t) || typeof t.kind != "string" || !Ll.has(t.kind)
  ) ? c({ status: "unsupported", audit: null }) : c({
    status: "audited",
    audit: {
      readerVersion: _l,
      protocolVersion: 1,
      operationKinds: e.operations.map(
        (t) => t.kind
      ),
      envelopeFingerprint: pe(e),
      liveEligible: !1,
      conversionAvailable: !1
    }
  });
}, mt = (e) => {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const t = Object.getPrototypeOf(e);
  return t === Object.prototype || t === null;
}, Ye = (e, t, r = []) => mt(e) && t.every((i) => Object.hasOwn(e, i)) && Object.keys(e).every(
  (i) => t.includes(i) || r.includes(i)
), gi = (e, t) => pe({ domain: e, value: t }), Ro = (e, t = /* @__PURE__ */ new Set()) => !e || typeof e != "object" || t.has(e) ? !0 : Object.isFrozen(e) ? (t.add(e), Object.values(e).every(
  (r) => Ro(r, t)
)) : !1, bt = (e) => {
  for (let t = 0; t < e.length; t += 1) {
    const r = e.charCodeAt(t);
    if (r >= 55296 && r <= 56319) {
      const i = e.charCodeAt(t + 1);
      if (!(i >= 56320 && i <= 57343)) return !1;
      t += 1;
    } else if (r >= 56320 && r <= 57343)
      return !1;
  }
  return !0;
}, St = (e, t) => {
  if (!Number.isSafeInteger(t) || t < 0 || t > e.length)
    return !1;
  if (t === 0 || t === e.length) return !0;
  const r = e.charCodeAt(t - 1), i = e.charCodeAt(t);
  return !(r >= 55296 && r <= 56319 && i >= 56320 && i <= 57343);
}, ko = (e) => {
  if (typeof e.text == "string")
    return bt(e.text) ? e.text : null;
  if (e.type === "hardBreak") return `
`;
  if (e.content === void 0) return "";
  if (!Array.isArray(e.content)) return null;
  let t = "";
  for (const r of e.content) {
    if (!mt(r)) return null;
    const i = ko(r);
    if (i === null) return null;
    t += i;
  }
  return t;
}, Vl = (e, t) => {
  const r = t.at(-1);
  return e === "paragraph" && r === "doc" ? "paragraph" : e === "heading" && r === "doc" ? "heading" : e === "paragraph" && r === "listItem" && ["bulletList", "orderedList"].includes(t.at(-2) ?? "") && t.at(-3) === "doc" ? "list-paragraph" : null;
}, Hi = (e, t) => {
  if (!Wr(t) || !Ye(e, [
    "version",
    "body",
    "annotations",
    "assets",
    "meta"
  ]) || e.version !== 2 || !Ye(e.body, ["format", "content"]) || e.body.format !== "json" || !mt(e.body.content) || !Array.isArray(e.annotations) || !Array.isArray(e.assets) || !mt(e.meta))
    return null;
  let r = null;
  const i = /* @__PURE__ */ new Set(), n = (s, o) => {
    if (typeof s.type != "string" || s.type.length === 0) return !1;
    const a = s.attrs === void 0 ? {} : mt(s.attrs) ? s.attrs : null;
    if (a === null) return !1;
    const d = Object.hasOwn(a, "blockId"), l = d ? a.blockId : void 0;
    if (d && (!Wr(l) || i.has(l)))
      return !1;
    if (Wr(l) && i.add(l), l === t) {
      const g = ko(s);
      if (g === null) return !1;
      r = {
        blockId: l,
        nodeType: s.type,
        presentationType: Vl(s.type, o),
        attrsFingerprint: pe(a),
        text: g
      };
    }
    if (s.content !== void 0) {
      if (!Array.isArray(s.content)) return !1;
      for (const g of s.content)
        if (!mt(g) || !n(g, [...o, s.type]))
          return !1;
    }
    return !0;
  };
  try {
    return n(e.body.content, []) ? r : null;
  } catch {
    return null;
  }
}, Hl = [
  "version",
  "editorBindingId",
  "productScope",
  "target",
  "semanticSnapshotRef",
  "scopeRef",
  "baseDocumentRef",
  "locale",
  "capabilityReceipts",
  "fingerprint"
], So = (e) => {
  if (!Ye(e, Hl)) return null;
  const t = e, r = Hd({
    editorBindingId: t.editorBindingId,
    productScope: t.productScope,
    target: t.target,
    semanticSnapshotRef: t.semanticSnapshotRef,
    scopeRef: t.scopeRef,
    baseDocumentRef: t.baseDocumentRef,
    locale: t.locale,
    capabilityReceipts: t.capabilityReceipts
  });
  return r.status !== "success" || r.context.fingerprint !== t.fingerprint || !Ot(r.context, t) ? null : r.context;
}, Kl = (e, t, r, i) => {
  const n = [], s = (d) => !mt(d) || (typeof d.text == "string" && mt(d.address) && d.address.blockId === t && Number.isSafeInteger(d.address.startOffset) && Number.isSafeInteger(d.address.endOffset) && n.push({
    start: d.address.startOffset,
    end: d.address.endOffset,
    text: d.text
  }), !Array.isArray(d.children)) ? !1 : d.children.every(s);
  if (!Array.isArray(e.nodes) || !e.nodes.every(s))
    return null;
  n.sort((d, l) => d.start - l.start);
  let o = r, a = "";
  for (const d of n) {
    if (d.start !== o || d.end < d.start || d.end > i || d.text.length !== d.end - d.start)
      return null;
    o = d.end, a += d.text;
  }
  return o === i ? a : null;
}, Be = (e, t) => c({ status: e, reason: t }), bg = (e) => {
  if (!Ye(e, [
    "exactInvocation",
    "semanticSnapshot",
    "baseDocument"
  ]))
    return Be("failure", "baseline-invalid");
  const t = e.exactInvocation, r = mt(t == null ? void 0 : t.target) ? t.target : null;
  if (typeof (t == null ? void 0 : t.editorBindingId) == "string" && r && typeof r.editorBindingId == "string" && t.editorBindingId !== r.editorBindingId)
    return Be("failure", "editor-binding-mismatch");
  const i = So(
    e.exactInvocation
  );
  if (!i) return Be("failure", "baseline-invalid");
  if (i.target.editorBindingId !== i.editorBindingId)
    return Be("failure", "editor-binding-mismatch");
  if (i.target.kind !== "selection")
    return Be("unsupported", "baseline-invalid");
  const n = i.target;
  if (n.collapsed) return Be("unsupported", "collapsed-selection");
  if (n.blockIds.length !== 1 || n.start.blockId !== n.end.blockId || n.start.blockId !== n.blockIds[0])
    return Be("unsupported", "multi-block-selection");
  if (!Ye(e.semanticSnapshot, [
    "contractVersion",
    "documentVersion",
    "schemaVersion",
    "documentRevision",
    "fingerprint",
    "descriptorFingerprint",
    "scope",
    "selection",
    "manifest",
    "nodes",
    "operableBlockIds",
    "diagnostics"
  ]) || e.semanticSnapshot.contractVersion !== 1 || e.semanticSnapshot.documentVersion !== 2 || !X(e.semanticSnapshot.fingerprint) || e.semanticSnapshot.fingerprint !== n.semanticSnapshotFingerprint || e.semanticSnapshot.fingerprint !== i.semanticSnapshotRef.fingerprint || i.baseDocumentRef.fingerprint !== n.baseDocumentFingerprint || !e.semanticSnapshot.selection || e.semanticSnapshot.selection.collapsed || e.semanticSnapshot.selection.blockIds.length !== 1 || e.semanticSnapshot.selection.start.blockId !== n.start.blockId || e.semanticSnapshot.selection.start.offset !== n.start.offset || e.semanticSnapshot.selection.end.blockId !== n.end.blockId || e.semanticSnapshot.selection.end.offset !== n.end.offset)
    return Be("failure", "target-mismatch");
  let s;
  try {
    s = pe(e.baseDocument);
  } catch {
    return Be("failure", "baseline-invalid");
  }
  if (e.semanticSnapshot.documentRevision !== s || i.semanticSnapshotRef.revision !== void 0 && i.semanticSnapshotRef.revision !== s || i.baseDocumentRef.revision !== void 0 && i.baseDocumentRef.revision !== s)
    return Be("failure", "base-verification-failed");
  const o = Hi(
    e.baseDocument,
    n.start.blockId
  );
  if (!o) return Be("failure", "baseline-invalid");
  if (!o.presentationType)
    return Be("unsupported", "unsupported-node");
  const { start: a, end: d } = {
    start: n.start.offset,
    end: n.end.offset
  };
  if (!Number.isSafeInteger(a) || !Number.isSafeInteger(d) || a < 0 || d <= a || d > o.text.length || !St(o.text, a) || !St(o.text, d) || !bt(o.text))
    return Be("failure", "baseline-invalid");
  const l = o.text.slice(a, d);
  if (/[\r\n]/u.test(l))
    return Be("unsupported", "explicit-line-break");
  if (Kl(e.semanticSnapshot, o.blockId, a, d) !== l)
    return Be("failure", "base-verification-failed");
  const g = {
    kind: "zx-ai-review-presentation-baseline-v1",
    version: "1.0.0",
    editorBindingId: i.editorBindingId,
    invocationFingerprint: i.fingerprint,
    targetFingerprint: n.fingerprint,
    baseDocumentFingerprint: n.baseDocumentFingerprint,
    blockId: o.blockId,
    blockType: o.presentationType,
    blockAttrsFingerprint: o.attrsFingerprint,
    blockText: o.text,
    startOffset: a,
    endOffset: d,
    selectedText: l
  };
  return c({
    status: "success",
    baseline: {
      ...g,
      fingerprint: gi(
        "zx-ai-review-presentation-baseline:v1",
        g
      )
    }
  });
}, Ml = (e) => {
  if (!Ye(e, [
    "kind",
    "version",
    "editorBindingId",
    "invocationFingerprint",
    "targetFingerprint",
    "baseDocumentFingerprint",
    "blockId",
    "blockType",
    "blockAttrsFingerprint",
    "blockText",
    "startOffset",
    "endOffset",
    "selectedText",
    "fingerprint"
  ]) || e.kind !== "zx-ai-review-presentation-baseline-v1" || e.version !== "1.0.0" || !U(e.editorBindingId) || !Wr(e.blockId) || !X(e.invocationFingerprint) || !X(e.targetFingerprint) || !X(e.baseDocumentFingerprint) || !X(e.blockAttrsFingerprint) || !["paragraph", "heading", "list-paragraph"].includes(
    String(e.blockType)
  ) || typeof e.blockText != "string" || typeof e.selectedText != "string" || !bt(e.blockText) || !bt(e.selectedText) || !Number.isSafeInteger(e.startOffset) || !Number.isSafeInteger(e.endOffset) || e.startOffset < 0 || e.endOffset <= e.startOffset || e.endOffset > e.blockText.length || !St(e.blockText, e.startOffset) || !St(e.blockText, e.endOffset) || e.selectedText !== e.blockText.slice(
    e.startOffset,
    e.endOffset
  ) || /[\r\n]/u.test(e.selectedText) || !Ro(e))
    return c({ status: "failure", reason: "baseline-invalid" });
  const { fingerprint: t, ...r } = e;
  return t !== gi(
    "zx-ai-review-presentation-baseline:v1",
    r
  ) ? c({ status: "failure", reason: "baseline-invalid" }) : c({
    status: "success",
    baseline: e
  });
}, Kn = {
  id: "single-text-replace-v1",
  version: "1.0.0",
  maxCandidateUtf16: 65536,
  maxSemanticTokens: 4096,
  maxEditGraphSteps: 1e6
}, _e = c({
  ...Kn,
  fingerprint: gi(
    "zx-ai-review-presentation-profile:v1",
    Kn
  )
}), Ao = (e) => Ye(e, [
  "id",
  "version",
  "maxCandidateUtf16",
  "maxSemanticTokens",
  "maxEditGraphSteps",
  "fingerprint"
]) && e.id === _e.id && e.version === _e.version && e.maxCandidateUtf16 === _e.maxCandidateUtf16 && e.maxSemanticTokens === _e.maxSemanticTokens && e.maxEditGraphSteps === _e.maxEditGraphSteps && e.fingerprint === _e.fingerprint, Mn = (e) => new RegExp("\\p{White_Space}", "u").test(e), Ul = (e) => /[\p{Punctuation}\p{Symbol}]/u.test(e), Gl = (e) => new RegExp("\\p{Mark}", "u").test(e), Wl = (e) => /^[A-Za-z0-9_]$/u.test(e), Un = (e) => {
  const t = [];
  let r = 0;
  for (const i of e) {
    const n = r;
    r += i.length;
    const s = t.at(-1), o = Mn(i) ? "whitespace" : Ul(i) ? "punctuation" : Wl(i) ? "ascii-word" : Gl(i) ? "mark" : "code-point", a = s ? Mn(s.text.at(-1) ?? "") ? "whitespace" : /^[A-Za-z0-9_]+$/u.test(s.text) ? "ascii-word" : null : null;
    s && (o === "mark" || o === "whitespace" && a === "whitespace" || o === "ascii-word" && a === "ascii-word") ? t[t.length - 1] = {
      text: s.text + i,
      start: s.start,
      end: r
    } : t.push({ text: i, start: n, end: r });
  }
  return t;
}, Yl = (e, t) => {
  const r = Array.from(e), i = Array.from(t);
  let n = 0;
  for (; n < r.length && n < i.length && r[n] === i[n]; )
    n += 1;
  let s = 0;
  for (; s < r.length - n && s < i.length - n && r[r.length - 1 - s] === i[i.length - 1 - s]; )
    s += 1;
  return {
    prefixUtf16: r.slice(0, n).reduce((o, a) => o + a.length, 0),
    suffixUtf16: r.slice(r.length - s).reduce((o, a) => o + a.length, 0)
  };
}, ir = (e, t) => {
  if (t.text.length === 0) return;
  const r = e.at(-1);
  if (r && r.kind === t.kind && t.kind !== "inserted" && r.kind !== "inserted" && r.sourceEnd === t.sourceStart) {
    e[e.length - 1] = {
      kind: t.kind,
      sourceStart: r.sourceStart,
      sourceEnd: t.sourceEnd,
      text: r.text + t.text
    };
    return;
  }
  if ((r == null ? void 0 : r.kind) === "inserted" && t.kind === "inserted" && r.atSourceOffset === t.atSourceOffset) {
    e[e.length - 1] = {
      kind: "inserted",
      atSourceOffset: t.atSourceOffset,
      text: r.text + t.text
    };
    return;
  }
  e.push(t);
}, Xl = (e, t, r, i) => {
  const n = e.length + 1, s = t.length + 1, o = e.length * t.length;
  if (e.length + t.length > i.maxSemanticTokens || o > i.maxEditGraphSteps)
    return null;
  const a = new Uint32Array(n * s);
  for (let p = e.length - 1; p >= 0; p -= 1)
    for (let f = t.length - 1; f >= 0; f -= 1) {
      const m = p * s + f;
      a[m] = e[p].text === t[f].text ? a[(p + 1) * s + f + 1] + 1 : Math.max(
        a[(p + 1) * s + f],
        a[p * s + f + 1]
      );
    }
  const d = [];
  let l = 0, g = 0, u = r;
  for (; l < e.length || g < t.length; ) {
    const p = e[l], f = t[g];
    if (p && f && p.text === f.text) {
      ir(d, {
        kind: "equal",
        sourceStart: u,
        sourceEnd: u + p.text.length,
        text: p.text
      }), u += p.text.length, l += 1, g += 1;
      continue;
    }
    const m = g < t.length ? a[l * s + g + 1] : -1, y = l < e.length ? a[(l + 1) * s + g] : -1;
    if (p && (!f || y >= m)) {
      ir(d, {
        kind: "removed",
        sourceStart: u,
        sourceEnd: u + p.text.length,
        text: p.text
      }), u += p.text.length, l += 1;
      continue;
    }
    if (f) {
      ir(d, {
        kind: "inserted",
        atSourceOffset: u,
        text: f.text
      }), g += 1;
      continue;
    }
    return null;
  }
  return d;
}, Eo = (e) => {
  if (!Ye(
    e,
    ["sourceText", "candidateText"],
    ["profile"]
  ))
    return c({ status: "failure", reason: "baseline-invalid" });
  const t = e.profile ?? _e;
  if (!Ao(t) || typeof e.sourceText != "string" || typeof e.candidateText != "string" || !bt(e.sourceText) || !bt(e.candidateText))
    return c({ status: "failure", reason: "baseline-invalid" });
  if (e.sourceText.length > t.maxCandidateUtf16 || e.candidateText.length > t.maxCandidateUtf16)
    return c({
      status: "budget-exceeded",
      reason: "projection-budget-exceeded"
    });
  if (e.sourceText === e.candidateText)
    return c({
      status: "success",
      changeKind: "no-change",
      segments: []
    });
  if (e.candidateText.length === 0)
    return c({
      status: "success",
      changeKind: "deletion",
      segments: e.sourceText ? [
        {
          kind: "removed",
          sourceStart: 0,
          sourceEnd: e.sourceText.length,
          text: e.sourceText
        }
      ] : []
    });
  const { prefixUtf16: r, suffixUtf16: i } = Yl(
    e.sourceText,
    e.candidateText
  );
  if (!St(e.sourceText, r) || !St(e.sourceText, e.sourceText.length - i) || !St(e.candidateText, r) || !St(
    e.candidateText,
    e.candidateText.length - i
  ))
    return c({ status: "failure", reason: "baseline-invalid" });
  const n = e.sourceText.slice(
    r,
    e.sourceText.length - i
  ), s = e.candidateText.slice(
    r,
    e.candidateText.length - i
  ), o = Xl(
    Un(n),
    Un(s),
    r,
    t
  );
  if (!o)
    return c({
      status: "budget-exceeded",
      reason: "projection-budget-exceeded"
    });
  const a = [];
  return r > 0 && ir(a, {
    kind: "equal",
    sourceStart: 0,
    sourceEnd: r,
    text: e.sourceText.slice(0, r)
  }), o.forEach((d) => ir(a, d)), i > 0 && ir(a, {
    kind: "equal",
    sourceStart: e.sourceText.length - i,
    sourceEnd: e.sourceText.length,
    text: e.sourceText.slice(e.sourceText.length - i)
  }), c({
    status: "success",
    changeKind: "replacement",
    segments: a
  });
}, Gn = (e, t = _e.maxCandidateUtf16) => {
  if (typeof e != "string" || !bt(e) || !Number.isSafeInteger(t) || t < 0)
    return "";
  const r = Math.min(
    t,
    _e.maxCandidateUtf16
  );
  let i = "", n = 0;
  for (const s of e) {
    if (n + s.length > r) break;
    i += s, n += s.length;
  }
  return i;
}, nr = (e) => c({
  ...e,
  fingerprint: gi(
    "zx-ai-review-presentation-projection:v1",
    e
  )
}), Ki = (e) => nr({ status: "empty", reason: e }), Ie = (e) => nr(e), Zl = /* @__PURE__ */ new Set([
  "idle",
  "composing",
  "prepared",
  "starting",
  "streaming",
  "abort-requested",
  "awaiting-review",
  "error",
  "conflict",
  "stopped",
  "completed",
  "detached"
]), Jl = new Set(pi), Co = new TextEncoder(), ii = (e) => typeof e == "number" && Number.isSafeInteger(e) && e >= 0, qo = (e) => Ye(e, ["ordinal", "text", "byteLength"]) && ii(e.ordinal) && typeof e.text == "string" && bt(e.text) && ii(e.byteLength) && e.byteLength === Co.encode(e.text).byteLength, Ql = (e) => Y(
  e,
  ["sessionId", "revision", "fingerprint"],
  ["requestId", "attemptId"]
) && U(e.sessionId) && ii(e.revision) && X(e.fingerprint) && (!Object.hasOwn(e, "requestId") || U(e.requestId)) && (!Object.hasOwn(e, "attemptId") || U(e.attemptId)), ep = (e) => Y(e, ["reviewId", "revision", "fingerprint"]) && U(e.reviewId) && ii(e.revision) && X(e.fingerprint), tp = (e) => Y(e, pi) && Object.values(e).every((t) => typeof t == "boolean"), rp = (e) => {
  if (!Y(
    e,
    [
      "version",
      "editorBindingId",
      "state",
      "previewSegments",
      "previewTruncated",
      "actions",
      "fingerprint"
    ],
    [
      "sessionRef",
      "reviewRef",
      "reviewRefinement",
      "pendingActionId",
      "targetFingerprint",
      "error"
    ]
  ) || e.version !== "1.0.0" || !U(e.editorBindingId) || !Zl.has(e.state) || Object.hasOwn(e, "sessionRef") && !Ql(e.sessionRef) || Object.hasOwn(e, "reviewRef") && !ep(e.reviewRef) || Object.hasOwn(e, "pendingActionId") && !Jl.has(String(e.pendingActionId)) || Object.hasOwn(e, "targetFingerprint") && !X(e.targetFingerprint) || !Array.isArray(e.previewSegments) || !e.previewSegments.every(qo) || typeof e.previewTruncated != "boolean" || !tp(e.actions) || !X(e.fingerprint))
    return null;
  const { fingerprint: t, ...r } = e;
  try {
    if (t !== re("zx-ai-authoring-projection:v1", r))
      return null;
  } catch {
    return null;
  }
  return e;
}, ip = (e) => {
  const t = e.sessionRef;
  return !t || !U(t.sessionId) || !U(t.requestId) || !U(t.attemptId) ? null : {
    kind: "provisional-attempt",
    sessionId: t.sessionId,
    requestId: t.requestId,
    attemptId: t.attemptId
  };
}, np = (e) => {
  var i, n, s;
  const { sidecar: t, proposal: r } = e;
  return !U((i = t == null ? void 0 : t.identity) == null ? void 0 : i.reviewId) || !Number.isSafeInteger(t == null ? void 0 : t.revision) || t.revision < 0 || !U((n = r == null ? void 0 : r.identity) == null ? void 0 : n.proposalId) || !U((s = r == null ? void 0 : r.identity) == null ? void 0 : s.variantId) || typeof (r == null ? void 0 : r.fingerprint) != "string" ? null : {
    kind: "verified-review",
    reviewId: t.identity.reviewId,
    revision: t.revision,
    proposalId: r.identity.proposalId,
    variantId: r.identity.variantId,
    proposalFingerprint: r.fingerprint
  };
}, sp = (e) => {
  const { authoring: t, baseline: r, source: i } = e;
  if (t.previewTruncated)
    return Ie({
      status: "unsupported",
      editorBindingId: r.editorBindingId,
      source: i,
      reason: "projection-truncated"
    });
  if (!t.previewSegments.every(
    (o, a) => qo(o) && o.ordinal === a && o.byteLength === Co.encode(o.text).byteLength
  ))
    return Ie({
      status: "unverified",
      editorBindingId: r.editorBindingId,
      source: i,
      reason: "source-identity-invalid"
    });
  if (t.previewSegments.length === 0)
    return Ki("no-active-candidate");
  const n = t.previewSegments.map((o) => o.text).join("");
  if (n.length === 0)
    return Ki("no-active-candidate");
  const s = Eo({
    sourceText: r.selectedText,
    candidateText: n,
    profile: _e
  });
  return s.status !== "success" ? Ie({
    status: "unsupported",
    editorBindingId: r.editorBindingId,
    source: i,
    reason: s.status === "budget-exceeded" ? "projection-budget-exceeded" : "baseline-invalid"
  }) : nr({
    status: "provisional",
    editorBindingId: r.editorBindingId,
    source: i,
    baselineFingerprint: r.fingerprint,
    candidateText: n,
    segments: s.segments,
    changeKind: "replacement"
  });
}, op = (e, t, r) => !Ye(e, [
  "receipt",
  "proposal",
  "lifecycle",
  "sidecar",
  "initialSidecarFingerprint",
  "transferFingerprint"
]) || e.sidecar.status !== "active" || e.initialSidecarFingerprint !== e.sidecar.fingerprint || !t.reviewRef || t.reviewRef.reviewId !== r.reviewId || t.reviewRef.revision !== r.revision || t.reviewRef.fingerprint !== e.sidecar.fingerprint || !t.sessionRef || t.sessionRef.sessionId !== e.receipt.sessionId || t.sessionRef.requestId !== void 0 && t.sessionRef.requestId !== e.receipt.requestId || t.sessionRef.attemptId !== void 0 && t.sessionRef.attemptId !== e.receipt.attemptId ? !1 : Pt({
  kind: "zx-ai-session-review-artifact-transfer-v1",
  version: "1.0.0",
  receipt: e.receipt,
  proposal: e.proposal,
  lifecycle: e.lifecycle,
  sidecar: e.sidecar,
  fingerprint: e.transferFingerprint
}).status === "success", ap = (e) => {
  var m;
  const { bundle: t, source: r, authoring: i, baseline: n, exactInvocation: s } = e;
  if (!op(t, i, r))
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "review-bundle-mismatch"
    });
  if (or({
    mode: "exact-current",
    sidecar: t.sidecar,
    proposal: t.proposal,
    lifecycle: t.lifecycle
  }).status !== "audit-success")
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "proposal-audit-failed"
    });
  const a = t.proposal;
  if (a.base.plan.steps.length !== 1 || a.operationProjection.length !== 1 || ((m = a.base.plan.steps[0]) == null ? void 0 : m.kind) !== "text.replace")
    return Ie({
      status: "unsupported",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "plan-shape-unsupported"
    });
  const d = a.base.plan.steps[0];
  if (d.operationIndex !== 0 || d.target.blockId !== n.blockId || d.target.startOffset !== n.startOffset || d.target.endOffset !== n.endOffset)
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "target-mismatch"
    });
  if (s.baseDocumentRef.revision === void 0 || a.base.documentRevision !== s.baseDocumentRef.revision || s.semanticSnapshotRef.revision !== void 0 && a.base.documentRevision !== s.semanticSnapshotRef.revision)
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "base-verification-failed"
    });
  const l = Hi(
    a.base.document,
    n.blockId
  );
  if (!l || l.presentationType !== n.blockType || l.attrsFingerprint !== n.blockAttrsFingerprint || l.text !== n.blockText)
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "base-verification-failed"
    });
  const g = d.text;
  if (!bt(g))
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "result-verification-failed"
    });
  const u = Hi(
    a.runtimeExecution.resultDocument,
    n.blockId
  ), p = n.blockText.slice(0, n.startOffset) + g + n.blockText.slice(n.endOffset);
  if (!u || u.presentationType !== n.blockType || u.attrsFingerprint !== n.blockAttrsFingerprint || u.text !== p || a.runtimeExecution.resultFingerprint !== t.sidecar.proposalBinding.resultFingerprint || a.effectProof.fingerprint !== t.sidecar.proposalBinding.effectFingerprint)
    return Ie({
      status: "unverified",
      editorBindingId: n.editorBindingId,
      source: r,
      reason: "result-verification-failed"
    });
  const f = Eo({
    sourceText: n.selectedText,
    candidateText: g,
    profile: _e
  });
  return f.status === "failure" ? Ie({
    status: "unverified",
    editorBindingId: n.editorBindingId,
    source: r,
    reason: "operation-closure-failed"
  }) : f.status === "budget-exceeded" ? nr({
    status: "degraded",
    editorBindingId: n.editorBindingId,
    source: r,
    baselineFingerprint: n.fingerprint,
    reason: "projection-budget-exceeded",
    candidateText: Gn(
      g,
      _e.maxSemanticTokens
    ),
    previewTruncated: !0
  }) : a.richDiff.status === "unavailable" || t.sidecar.capability === "coarse-review-unavailable" ? nr({
    status: "degraded",
    editorBindingId: n.editorBindingId,
    source: r,
    baselineFingerprint: n.fingerprint,
    reason: a.richDiff.status === "unavailable" ? "rich-diff-unavailable" : "reject-only",
    candidateText: Gn(
      g,
      _e.maxSemanticTokens
    ),
    previewTruncated: !0
  }) : nr({
    status: "verified",
    editorBindingId: n.editorBindingId,
    source: r,
    baselineFingerprint: n.fingerprint,
    candidateText: g,
    segments: f.segments,
    changeKind: f.changeKind,
    planDigest: a.base.planDigest,
    resultFingerprint: a.runtimeExecution.resultFingerprint
  });
}, Fg = (e) => {
  var o, a;
  if (!Ye(e, [
    "profile",
    "baseline",
    "authoring",
    "exactInvocation",
    "exactActiveReview"
  ]) || !Ao(e.profile))
    return Ie({
      status: "unverified",
      editorBindingId: typeof ((o = e == null ? void 0 : e.baseline) == null ? void 0 : o.editorBindingId) == "string" ? e.baseline.editorBindingId : "invalid-editor-binding",
      source: { kind: "none" },
      reason: "baseline-invalid"
    });
  const t = Ml(e.baseline);
  if (t.status !== "success")
    return Ie({
      status: "unverified",
      editorBindingId: typeof ((a = e.baseline) == null ? void 0 : a.editorBindingId) == "string" ? e.baseline.editorBindingId : "invalid-editor-binding",
      source: { kind: "none" },
      reason: "baseline-invalid"
    });
  const r = t.baseline, i = rp(e.authoring);
  if (!i)
    return Ie({
      status: "unverified",
      editorBindingId: r.editorBindingId,
      source: { kind: "none" },
      reason: "source-identity-invalid"
    });
  const n = So(
    e.exactInvocation
  );
  if (!n)
    return Ie({
      status: "unverified",
      editorBindingId: r.editorBindingId,
      source: { kind: "none" },
      reason: "baseline-invalid"
    });
  if (r.editorBindingId !== i.editorBindingId || r.editorBindingId !== n.editorBindingId || r.editorBindingId !== n.target.editorBindingId)
    return Ie({
      status: "unverified",
      editorBindingId: r.editorBindingId,
      source: { kind: "none" },
      reason: "editor-binding-mismatch"
    });
  if (r.invocationFingerprint !== n.fingerprint || r.targetFingerprint !== n.target.fingerprint || r.baseDocumentFingerprint !== n.target.baseDocumentFingerprint || i.targetFingerprint !== r.targetFingerprint)
    return Ie({
      status: "unverified",
      editorBindingId: r.editorBindingId,
      source: { kind: "none" },
      reason: "target-mismatch"
    });
  if (e.exactActiveReview) {
    const d = np(e.exactActiveReview);
    return d ? ap({
      bundle: e.exactActiveReview,
      source: d,
      authoring: i,
      baseline: r,
      exactInvocation: n
    }) : Ie({
      status: "unverified",
      editorBindingId: r.editorBindingId,
      source: { kind: "none" },
      reason: "source-identity-invalid"
    });
  }
  if (!["starting", "streaming", "abort-requested"].includes(i.state))
    return Ki("no-active-source");
  const s = ip(i);
  return s ? sp({ source: s, authoring: i, baseline: r }) : Ie({
    status: "unverified",
    editorBindingId: r.editorBindingId,
    source: { kind: "none" },
    reason: "source-identity-invalid"
  });
}, xg = "1.0.0", cp = /* @__PURE__ */ new Set([
  "abort-won",
  "success-won",
  "failed",
  "not-requested"
]), dp = /* @__PURE__ */ new Set(["accept", "reject"]), lp = /* @__PURE__ */ new Set([
  "projection-budget-exceeded",
  "rich-diff-unavailable",
  "reject-only"
]), Wn = (e) => typeof e == "number" && Number.isFinite(e) && e >= 0 && e <= Number.MAX_SAFE_INTEGER, pp = (e) => !Ye(
  e,
  ["stopOutcome", "reviewRefineCount", "conflict"],
  ["firstTokenMs", "generateMs", "disposition", "degradeReason"]
) || !cp.has(e.stopOutcome) || !Number.isSafeInteger(e.reviewRefineCount) || e.reviewRefineCount < 0 || typeof e.conflict != "boolean" || e.firstTokenMs !== void 0 && !Wn(e.firstTokenMs) || e.generateMs !== void 0 && !Wn(e.generateMs) || e.disposition !== void 0 && !dp.has(e.disposition) || e.degradeReason !== void 0 && !lp.has(e.degradeReason) ? null : c({ ...e }), wg = (e) => {
  const t = (e == null ? void 0 : e.now) ?? (() => typeof performance == "object" ? performance.now() : Date.now());
  let r, i, n = 0, s, o = !1, a, d = 0, l = !1, g;
  const u = () => {
    r = void 0, i = void 0, n = 0, s = void 0, o = !1, a = void 0, d = 0, l = !1, g = void 0;
  };
  return {
    begin() {
      u(), r = t(), i = r;
    },
    beginGeneration() {
      r !== void 0 && i === void 0 && (i = t());
    },
    endGeneration() {
      r !== void 0 && i !== void 0 && (n += Math.max(0, t() - i), i = void 0);
    },
    markFirstToken() {
      r !== void 0 && s === void 0 && (s = t());
    },
    markStopRequested() {
      r !== void 0 && (o = !0);
    },
    markStopOutcome(p) {
      r !== void 0 && (a = p);
    },
    markTerminalFailure() {
      r !== void 0 && o && (a = "failed");
    },
    markReviewRefine() {
      r !== void 0 && (d += 1);
    },
    markConflict() {
      r !== void 0 && (l = !0);
    },
    markDegrade(p) {
      r !== void 0 && (g = p);
    },
    complete(p) {
      var m;
      if (r === void 0) return null;
      i !== void 0 && (n += Math.max(0, t() - i), i = void 0);
      const f = pp({
        ...s !== void 0 ? { firstTokenMs: Math.max(0, s - r) } : {},
        // Sum only active S5 generation windows. Review/Refine composition
        // dwell is intentionally excluded from generation latency.
        generateMs: n,
        // Never infer that completion won a Stop race. The Host Owner records
        // success, abort, or terminal failure from the authoritative receipt.
        stopOutcome: a ?? "not-requested",
        ...p ? { disposition: p } : {},
        reviewRefineCount: d,
        conflict: l,
        ...g ? { degradeReason: g } : {}
      });
      return u(), f && ((m = e == null ? void 0 : e.onEvent) == null || m.call(e, f)), f;
    },
    reset: u,
    isActive: () => r !== void 0
  };
}, Rg = c([
  {
    repository: "BlockNote",
    commit: "8cbc603e1d114101eebf857c8216695437dd1c53",
    paths: [
      "packages/xl-ai/src/prosemirror/changeset.ts",
      "packages/xl-ai/src/prosemirror/changeset.test.ts",
      "packages/xl-ai/src/prosemirror/__snapshots__/changeset.test.ts.snap",
      "packages/xl-ai/src/components/AIMenu/AIMenu.tsx"
    ],
    evidence: "source-and-tests",
    decision: "adapt",
    adaptedMechanism: "Change classification, common prefix/suffix trimming and regression cases become bounded, editor-agnostic UTF-16 segments.",
    rejectedBoundary: "BlockNote/React/Yjs authority, ProseMirror Changeset types, direct merge and commit remain outside ZXUI.",
    fixtureIds: [
      "RRP-BN-CHANGESET-DELETE-01",
      "RRP-BN-CHANGESET-REWRITE-02",
      "RRP-BN-CHANGESET-UNICODE-03"
    ]
  },
  {
    repository: "Plate",
    commit: "8abee2ba6db46e486ace3e9908d9550e3c05db13",
    paths: [
      "packages/suggestion/src/lib/diffToSuggestions.ts",
      "packages/suggestion/src/lib/diffToSuggestions.spec.ts"
    ],
    evidence: "source-and-tests",
    decision: "adapt",
    adaptedMechanism: "Equal/insert/delete classification and disposition fixtures become the Kernel segment union plus S4 exact dispositions.",
    rejectedBoundary: "Slate paths/plugins, persistent suggestion schema and Plate chat/action authority remain outside ZXUI.",
    fixtureIds: [
      "RRP-PLATE-DIFF-INSERT-01",
      "RRP-PLATE-DIFF-REMOVE-02",
      "RRP-PLATE-DIFF-NOCHANGE-03"
    ]
  },
  {
    repository: "Novel",
    commit: "fa95098e66476c466faebb8211baa5869c101a9c",
    paths: [
      "apps/web/components/tailwind/generative/ai-completion-command.tsx",
      "apps/web/components/tailwind/generative/ai-selector.tsx",
      "apps/web/components/tailwind/generative/generative-menu-switch.tsx"
    ],
    evidence: "source-only",
    decision: "adapt",
    adaptedMechanism: "Loading-to-content-to-follow-up sequencing and compact action hierarchy become Vue Chrome driven by exact Host Owner receipts.",
    rejectedBoundary: "React/provider hooks, current-selection insertContentAt and local AI lifecycle/action truth remain outside ZXUI.",
    fixtureIds: [
      "RRP-NOVEL-UX-LOADING-01",
      "RRP-NOVEL-UX-ACTIONS-02",
      "RRP-NOVEL-UX-NOWRITE-03"
    ]
  }
]), kg = c([
  {
    product: "Cursor Inline Edit",
    urls: ["https://docs.cursor.com/en/inline-edit/overview"],
    reviewedOn: "2026-07-30",
    adapt: "Selected-text Mod+K, follow-up and in-place review.",
    reject: "Provider/context internals and unselected full-file behavior."
  },
  {
    product: "Cursor Keyboard Shortcuts",
    urls: ["https://docs.cursor.com/advanced/keyboard-shortcuts"],
    reviewedOn: "2026-07-30",
    adapt: "Discoverable Open, Submit, Cancel, Accept and Reject commands.",
    reject: "Copying the complete product chord map."
  },
  {
    product: "Notion AI inline",
    urls: ["https://www.notion.com/help/notion-ai-faqs"],
    reviewedOn: "2026-07-30",
    adapt: "Content-first Accept, Discard and Try again hierarchy.",
    reject: "Agent and provider internals."
  },
  {
    product: "Notion Suggested Edits",
    urls: [
      "https://www.notion.com/en-gb/help/suggested-edits",
      "https://www.notion.com/releases/2024-07-29"
    ],
    reviewedOn: "2026-07-30",
    adapt: "Visible accept/reject controls with content priority.",
    reject: "Persistent suggestions, comments, notifications and collaboration identity are deferred to S7."
  }
]), Yn = "1.0.0", je = [
  "gate-0-baseline-authority",
  "gate-1-correctness-security",
  "gate-2-property-fuzz",
  "gate-3-collaboration-faults",
  "gate-4-performance-observability",
  "gate-5-rollout-dogfood-release"
];
class $ extends TypeError {
  constructor(t) {
    super(`Production contract rejected: ${t}`), this.name = "ProductionContractError", this.reason = t;
  }
}
const tt = () => {
  throw new $("contract-invalid");
}, J = (e, t) => {
  if (e === null || typeof e != "object" || Array.isArray(e) || Object.getPrototypeOf(e) !== Object.prototype && Object.getPrototypeOf(e) !== null)
    return tt();
  const r = Object.keys(e).sort(), i = [...t].sort();
  return ke(r) !== ke(i) ? tt() : e;
}, k = (e, t = {}) => typeof e != "string" || e.length < (t.min ?? 1) || e.length > (t.max ?? 256) || t.pattern && !t.pattern.test(e) ? tt() : e, To = (e) => e === null ? null : k(e), Me = (e) => typeof e != "boolean" ? tt() : e, W = (e, t = 0, r = Number.MAX_SAFE_INTEGER) => !Number.isSafeInteger(e) || e < t || e > r ? tt() : e, ni = (e, t = 0) => typeof e != "number" || !Number.isFinite(e) || e < t ? tt() : e, z = (e, t) => typeof e != "string" || !t.includes(e) ? tt() : e, Q = (e, t, r = 512) => !Array.isArray(e) || e.length > r ? tt() : c(e.map(t)), ue = (e) => new Set(e).size !== e.length ? tt() : e, gn = (e, t) => pe({ domain: e, value: t }), up = (e) => {
  const { fingerprint: t, ...r } = e;
  return r;
}, ge = (e, t) => {
  const r = k(t.fingerprint, {
    pattern: /^sha256:[a-f0-9]{64}$/,
    max: 71
  });
  if (r !== gn(e, up(t)))
    throw new $("fingerprint-mismatch");
  return r;
}, Re = (e, t) => {
  vs(e);
  try {
    Br(e, {
      maxBytes: Mt.maxBytes,
      maxDepth: Mt.maxDepth,
      maxArrayEntries: Mt.maxArrayEntries,
      maxObjectKeys: Mt.maxKeys,
      maxTotalObjectKeys: Mt.maxKeys
    });
  } catch (r) {
    throw r instanceof oa && r.usage.bytes !== null && r.usage.bytes > Mt.maxBytes ? new $a("limit-bytes") : new $("contract-invalid");
  }
  return c(t(e));
}, we = (e, t) => c({
  ...t,
  fingerprint: gn(e, t)
}), Yr = /^sha256:[a-f0-9]{64}$/, fp = /^[a-f0-9]{40}$/, gp = [
  "package-artifact",
  "runtime-import",
  "test-fixture",
  "evidence-tool"
], Xr = [
  "document",
  "schema",
  "operation",
  "runtime",
  "proposal",
  "review",
  "session",
  "collaboration",
  "complex-node"
], mp = (e) => {
  const t = J(e, [
    "node",
    "pnpm",
    "platform",
    "arch",
    "runner",
    "browser"
  ]);
  return {
    node: k(t.node, { max: 64 }),
    pnpm: k(t.pnpm, { max: 64 }),
    platform: k(t.platform, { max: 32 }),
    arch: k(t.arch, { max: 32 }),
    runner: k(t.runner, { max: 96 }),
    browser: To(t.browser)
  };
}, vp = (e) => {
  const t = J(e, [
    "owner",
    "version",
    "publicExport",
    "fingerprint"
  ]);
  return {
    owner: z(t.owner, Xr),
    version: k(t.version, { max: 64 }),
    publicExport: k(t.publicExport, { max: 256 }),
    fingerprint: k(t.fingerprint, { pattern: Yr, max: 71 })
  };
}, Ti = (e) => {
  const t = J(e, [
    "logicalName",
    "role",
    "pathClass",
    "commit",
    "clean",
    "dependencyReasons"
  ]), r = z(t.role, ["bound", "inventory"]), i = To(t.commit), n = t.clean === null ? null : Me(t.clean), s = ue(
    Q(
      t.dependencyReasons,
      (o) => z(o, gp)
    )
  );
  if (i !== null && !fp.test(i))
    throw new $("source-closure-invalid");
  if (r === "bound" && (i === null || n !== !0))
    throw new $("source-closure-invalid");
  if (r === "inventory" && s.length > 0)
    throw new $("source-closure-invalid");
  return {
    logicalName: k(t.logicalName, { max: 96 }),
    role: r,
    pathClass: z(t.pathClass, [
      "root",
      "independent-package"
    ]),
    commit: i,
    clean: n,
    dependencyReasons: s
  };
}, Bo = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "root",
    "textEditor",
    "repositories",
    "lockfileFingerprint",
    "artifactGraphFingerprint",
    "configurationFingerprint",
    "environmentProfile",
    "toolchain",
    "ownerManifests",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.source-closure.v1")
    throw new $("source-closure-invalid");
  const i = Ti(r.root), n = Ti(r.textEditor), s = Q(r.repositories, Ti, 32), o = Q(
    r.ownerManifests,
    vp,
    Xr.length
  );
  ue(s.map((g) => g.logicalName)), ue(o.map((g) => g.owner));
  const a = s.find(
    (g) => g.logicalName === "root"
  ), d = s.find(
    (g) => g.logicalName === "text-editor"
  );
  if (i.logicalName !== "root" || i.pathClass !== "root" || i.role !== "bound" || n.logicalName !== "text-editor" || n.pathClass !== "independent-package" || n.role !== "bound" || a === void 0 || d === void 0 || o.length !== Xr.length || o.some(
    (g, u) => g.owner !== Xr[u]
  ) || ke(a) !== ke(i) || ke(d) !== ke(n))
    throw new $("source-closure-invalid");
  const l = ge(
    "zx.ai.production.source-closure.v1",
    r
  );
  return {
    kind: "zx.ai.production.source-closure.v1",
    root: i,
    textEditor: n,
    repositories: s,
    lockfileFingerprint: k(r.lockfileFingerprint, {
      pattern: Yr,
      max: 71
    }),
    artifactGraphFingerprint: k(r.artifactGraphFingerprint, {
      pattern: Yr,
      max: 71
    }),
    configurationFingerprint: k(r.configurationFingerprint, {
      pattern: Yr,
      max: 71
    }),
    environmentProfile: k(r.environmentProfile, { max: 96 }),
    toolchain: mp(r.toolchain),
    ownerManifests: o,
    fingerprint: l
  };
}), At = /^sha256:[a-f0-9]{64}$/, Po = /^run_[a-z0-9][a-z0-9_-]{7,63}$/, hp = ["package-candidate", "host-deployment"], mn = [
  "zx-ai-production-baseline-v1",
  "zx-ai-production-correctness-v1",
  "zx-ai-production-property-v1",
  "zx-ai-production-collaboration-v1",
  "zx-ai-production-performance-v1",
  "zx-ai-production-release-v1"
], Xn = [
  "zx.ai.production.gate-0.raw.v1",
  "zx.ai.production.gate-1.raw.v1",
  "zx.ai.production.gate-2.raw.v1",
  "zx.ai.production.gate-3.raw.v1",
  "zx.ai.production.gate-4.raw.v1",
  "zx.ai.production.gate-5.raw.v1"
], yp = [
  "package-candidate-all-gates-v1",
  "host-deployment-not-claimed-v1"
], Ip = [
  "source-closure",
  "public-authority",
  "correctness-case",
  "resource-control",
  "security-control",
  "domain-property",
  "shrink-replay",
  "corpus-promotion",
  "fault-schedule",
  "terminal-state",
  "peer-convergence",
  "durable-recovery",
  "single-undo",
  "workload-stage",
  "performance-budget",
  "privacy-scan",
  "telemetry-cardinality",
  "rollout-shadow",
  "rollback-drill",
  "workbench-persona",
  "docs-contract",
  "independent-verifier"
], bp = {
  "gate-0-baseline-authority": ["source-closure", "public-authority"],
  "gate-1-correctness-security": [
    "correctness-case",
    "resource-control",
    "security-control",
    "public-authority"
  ],
  "gate-2-property-fuzz": [
    "domain-property",
    "shrink-replay",
    "corpus-promotion",
    "public-authority"
  ],
  "gate-3-collaboration-faults": [
    "fault-schedule",
    "terminal-state",
    "peer-convergence",
    "durable-recovery",
    "single-undo",
    "public-authority"
  ],
  "gate-4-performance-observability": [
    "workload-stage",
    "performance-budget",
    "privacy-scan",
    "telemetry-cardinality",
    "public-authority"
  ],
  "gate-5-rollout-dogfood-release": [
    "rollout-shadow",
    "rollback-drill",
    "workbench-persona",
    "docs-contract",
    "independent-verifier"
  ]
}, $o = (e) => je.indexOf(e), mi = (e) => z(e, je), vn = (e) => z(e, hp), jo = (e) => z(e, mn), vi = (e) => {
  const t = J(e, [
    "kind",
    "id",
    "mediaType",
    "bytes",
    "sha256",
    "retention",
    "redaction"
  ]);
  if (t.kind !== "zx.ai.production.evidence-ref.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.evidence-ref.v1",
    id: k(t.id, {
      max: 128,
      pattern: /^[a-z0-9][a-z0-9._-]{0,127}$/
    }),
    mediaType: k(t.mediaType, {
      max: 128,
      pattern: /^[a-z0-9.+-]+\/[a-z0-9.+-]+$/
    }),
    bytes: W(t.bytes, 0, 1073741824),
    sha256: k(t.sha256, { max: 71, pattern: At }),
    retention: z(t.retention, [
      "baseline",
      "regression-corpus",
      "run-artifact"
    ]),
    redaction: z(t.redaction, [
      "content-free",
      "redacted-and-scanned"
    ])
  };
}, Fp = (e) => {
  const t = J(e, [
    "kind",
    "id",
    "category",
    "artifactRefId",
    "inputFingerprint",
    "outputFingerprint",
    "observedCount",
    "failureCount",
    "fingerprint"
  ]);
  if (t.kind !== "zx.ai.production.measurement-fact.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.measurement-fact.v1",
    id: k(t.id, {
      max: 128,
      pattern: /^[a-z0-9][a-z0-9._-]{0,127}$/
    }),
    category: z(t.category, Ip),
    artifactRefId: k(t.artifactRefId, {
      max: 128,
      pattern: /^[a-z0-9][a-z0-9._-]{0,127}$/
    }),
    inputFingerprint: k(t.inputFingerprint, {
      max: 71,
      pattern: At
    }),
    outputFingerprint: k(t.outputFingerprint, {
      max: 71,
      pattern: At
    }),
    observedCount: W(t.observedCount, 0, 1e9),
    failureCount: W(t.failureCount, 0, 1e9),
    fingerprint: ge(
      "zx.ai.production.measurement-fact.v1",
      t
    )
  };
}, xp = (e) => {
  const t = J(e, [
    "kind",
    "gate",
    "claimScope",
    "owner",
    "risk",
    "compensation",
    "startsAtEpochSeconds",
    "expiresAtEpochSeconds",
    "fingerprint"
  ]);
  if (t.kind !== "zx.ai.production.waiver.v1")
    throw new $("contract-invalid");
  const r = W(t.startsAtEpochSeconds), i = W(t.expiresAtEpochSeconds);
  if (i <= r)
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.waiver.v1",
    gate: mi(t.gate),
    claimScope: vn(t.claimScope),
    owner: k(t.owner, { max: 64 }),
    risk: k(t.risk, { max: 256 }),
    compensation: k(t.compensation, { max: 256 }),
    startsAtEpochSeconds: r,
    expiresAtEpochSeconds: i,
    fingerprint: ge(
      "zx.ai.production.waiver.v1",
      t
    )
  };
}, wp = (e) => {
  const t = J(e, [
    "gate",
    "runnerId",
    "mandatory",
    "claimScope",
    "fingerprint"
  ]);
  return {
    gate: mi(t.gate),
    runnerId: jo(t.runnerId),
    mandatory: Me(t.mandatory),
    claimScope: vn(t.claimScope),
    fingerprint: ge(
      "zx.ai.production.gate-definition.v1",
      t
    )
  };
}, hn = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "version",
    "runId",
    "claimScope",
    "sourceClosureFingerprint",
    "gates",
    "applicabilityProfile",
    "applicability",
    "waivers",
    "evaluatedAtEpochSeconds",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.evidence-manifest.v1" || r.version !== Yn)
    throw new $("contract-invalid");
  const i = vn(r.claimScope), n = Q(r.gates, wp, 6);
  if (n.length !== je.length || n.some(
    (u, p) => u.gate !== je[p] || u.runnerId !== mn[p] || u.claimScope !== i
  ))
    throw new $("contract-invalid");
  const s = ue(
    Q(r.applicability, mi, je.length)
  ), o = z(
    r.applicabilityProfile,
    yp
  ), a = i === "package-candidate" ? "package-candidate-all-gates-v1" : "host-deployment-not-claimed-v1", d = i === "package-candidate" ? je : [];
  if (o !== a || s.length !== d.length || s.some((u, p) => u !== d[p]))
    throw new $("contract-invalid");
  const l = W(r.evaluatedAtEpochSeconds), g = Q(r.waivers, xp, 32);
  if (g.some((u) => {
    const p = n.find((f) => f.gate === u.gate);
    return (p == null ? void 0 : p.mandatory) !== !1 || u.claimScope !== i || l < u.startsAtEpochSeconds || l >= u.expiresAtEpochSeconds;
  }))
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.evidence-manifest.v1",
    version: Yn,
    runId: k(r.runId, { max: 64, pattern: Po }),
    claimScope: i,
    sourceClosureFingerprint: k(r.sourceClosureFingerprint, {
      max: 71,
      pattern: At
    }),
    gates: n,
    applicabilityProfile: o,
    applicability: s,
    waivers: g,
    evaluatedAtEpochSeconds: l,
    fingerprint: ge(
      "zx.ai.production.evidence-manifest.v1",
      r
    )
  };
}), Rp = (e) => Re(e, (t) => {
  const r = z(
    t.kind,
    Xn
  ), n = J(t, [
    "kind",
    "gate",
    "runnerId",
    "runnerVersion",
    "manifestFingerprint",
    "sourceClosureFingerprint",
    "logicalStartedAt",
    "logicalFinishedAt",
    "artifactRefs",
    "previousGateArtifactSha256",
    "observationFingerprints",
    "measurementFacts",
    "runId",
    "runnerBlocked",
    ...r === "zx.ai.production.gate-0.raw.v1" ? [
      "repositoryBindingCount",
      "sourceClosureMatched",
      "publicAuthorityMatched",
      "sourceBoundaryViolationCount"
    ] : r === "zx.ai.production.gate-1.raw.v1" ? [
      "caseCount",
      "correctnessFailureCount",
      "resourceControlFailureCount",
      "securityControlFailureCount"
    ] : r === "zx.ai.production.gate-2.raw.v1" ? [
      "seedCount",
      "propertyRunCount",
      "propertyFailureCount",
      "nonReproducibleFailureCount",
      "authorityPathFailureCount"
    ] : r === "zx.ai.production.gate-3.raw.v1" ? [
      "peerCount",
      "scheduleCount",
      "convergenceFailureCount",
      "recoveryFailureCount",
      "undoFailureCount"
    ] : r === "zx.ai.production.gate-4.raw.v1" ? [
      "profileCount",
      "environmentComparable",
      "authorityPathFailureCount",
      "budgetViolationCount",
      "privacyLeakCount",
      "cardinalityViolationCount"
    ] : [
      "rolloutDecision",
      "featureAuditValid",
      "rollbackDrillPassed",
      "workbenchPersonasPassed",
      "requiredWorkbenchPersonas",
      "docsValid",
      "independentVerifierValid"
    ],
    "fingerprint"
  ]), s = mi(n.gate), o = W(n.logicalStartedAt), a = W(n.logicalFinishedAt), d = $o(s);
  if (Xn[d] !== r || mn[d] !== n.runnerId || a < o)
    throw new $("contract-invalid");
  const l = Q(
    n.artifactRefs,
    vi
  ), g = Q(
    n.measurementFacts,
    Fp,
    1e4
  );
  if (new Set(g.map((f) => f.id)).size !== g.length || g.some(
    (f) => !l.some((m) => m.id === f.artifactRefId)
  ))
    throw new $("contract-invalid");
  const u = {
    gate: s,
    runnerId: jo(n.runnerId),
    runnerVersion: k(n.runnerVersion, { max: 32 }),
    manifestFingerprint: k(n.manifestFingerprint, {
      max: 71,
      pattern: At
    }),
    sourceClosureFingerprint: k(n.sourceClosureFingerprint, {
      max: 71,
      pattern: At
    }),
    logicalStartedAt: o,
    logicalFinishedAt: a,
    artifactRefs: l,
    previousGateArtifactSha256: n.previousGateArtifactSha256 === null ? null : k(n.previousGateArtifactSha256, {
      max: 71,
      pattern: At
    }),
    observationFingerprints: ue(
      Q(
        n.observationFingerprints,
        (f) => k(f, { max: 71, pattern: At })
      )
    ),
    measurementFacts: g,
    runId: k(n.runId, { max: 64, pattern: Po }),
    runnerBlocked: Me(n.runnerBlocked),
    fingerprint: ge(
      "zx.ai.production.gate-execution-receipt.v1",
      n
    )
  }, p = (f) => W(f, 0, 1e9);
  return r === "zx.ai.production.gate-0.raw.v1" ? {
    ...u,
    kind: r,
    gate: "gate-0-baseline-authority",
    runnerId: "zx-ai-production-baseline-v1",
    repositoryBindingCount: p(n.repositoryBindingCount),
    sourceClosureMatched: Me(n.sourceClosureMatched),
    publicAuthorityMatched: Me(n.publicAuthorityMatched),
    sourceBoundaryViolationCount: p(
      n.sourceBoundaryViolationCount
    )
  } : r === "zx.ai.production.gate-1.raw.v1" ? {
    ...u,
    kind: r,
    gate: "gate-1-correctness-security",
    runnerId: "zx-ai-production-correctness-v1",
    caseCount: p(n.caseCount),
    correctnessFailureCount: p(n.correctnessFailureCount),
    resourceControlFailureCount: p(n.resourceControlFailureCount),
    securityControlFailureCount: p(n.securityControlFailureCount)
  } : r === "zx.ai.production.gate-2.raw.v1" ? {
    ...u,
    kind: r,
    gate: "gate-2-property-fuzz",
    runnerId: "zx-ai-production-property-v1",
    seedCount: p(n.seedCount),
    propertyRunCount: p(n.propertyRunCount),
    propertyFailureCount: p(n.propertyFailureCount),
    nonReproducibleFailureCount: p(n.nonReproducibleFailureCount),
    authorityPathFailureCount: p(n.authorityPathFailureCount)
  } : r === "zx.ai.production.gate-3.raw.v1" ? {
    ...u,
    kind: r,
    gate: "gate-3-collaboration-faults",
    runnerId: "zx-ai-production-collaboration-v1",
    peerCount: p(n.peerCount),
    scheduleCount: p(n.scheduleCount),
    convergenceFailureCount: p(n.convergenceFailureCount),
    recoveryFailureCount: p(n.recoveryFailureCount),
    undoFailureCount: p(n.undoFailureCount)
  } : r === "zx.ai.production.gate-4.raw.v1" ? {
    ...u,
    kind: r,
    gate: "gate-4-performance-observability",
    runnerId: "zx-ai-production-performance-v1",
    profileCount: p(n.profileCount),
    environmentComparable: Me(n.environmentComparable),
    authorityPathFailureCount: p(n.authorityPathFailureCount),
    budgetViolationCount: p(n.budgetViolationCount),
    privacyLeakCount: p(n.privacyLeakCount),
    cardinalityViolationCount: p(n.cardinalityViolationCount)
  } : {
    ...u,
    kind: r,
    gate: "gate-5-rollout-dogfood-release",
    runnerId: "zx-ai-production-release-v1",
    rolloutDecision: z(n.rolloutDecision, [
      "advance",
      "hold",
      "rollback",
      "blocked"
    ]),
    featureAuditValid: Me(n.featureAuditValid),
    rollbackDrillPassed: Me(n.rollbackDrillPassed),
    workbenchPersonasPassed: p(n.workbenchPersonasPassed),
    requiredWorkbenchPersonas: p(n.requiredWorkbenchPersonas),
    docsValid: Me(n.docsValid),
    independentVerifierValid: Me(n.independentVerifierValid)
  };
}), kp = (e) => {
  const t = bp[e.gate], r = new Set(
    e.measurementFacts.map((i) => i.category)
  );
  if (e.observationFingerprints.length === 0 || e.measurementFacts.length === 0 || e.measurementFacts.some(
    (i) => i.observedCount === 0 || i.failureCount !== 0
  ) || t.some((i) => !r.has(i)))
    return !1;
  switch (e.kind) {
    case "zx.ai.production.gate-0.raw.v1":
      return e.repositoryBindingCount >= 2 && e.sourceClosureMatched && e.publicAuthorityMatched && e.sourceBoundaryViolationCount === 0;
    case "zx.ai.production.gate-1.raw.v1":
      return e.caseCount > 0 && e.correctnessFailureCount === 0 && e.resourceControlFailureCount === 0 && e.securityControlFailureCount === 0;
    case "zx.ai.production.gate-2.raw.v1":
      return e.seedCount > 0 && e.propertyRunCount > 0 && e.propertyFailureCount === 0 && e.nonReproducibleFailureCount === 0 && e.authorityPathFailureCount === 0;
    case "zx.ai.production.gate-3.raw.v1":
      return e.peerCount >= 2 && e.scheduleCount > 0 && e.convergenceFailureCount === 0 && e.recoveryFailureCount === 0 && e.undoFailureCount === 0;
    case "zx.ai.production.gate-4.raw.v1":
      return e.profileCount >= 3 && e.environmentComparable && e.authorityPathFailureCount === 0 && e.budgetViolationCount === 0 && e.privacyLeakCount === 0 && e.cardinalityViolationCount === 0;
    case "zx.ai.production.gate-5.raw.v1":
      return e.rolloutDecision === "advance" && e.featureAuditValid && e.rollbackDrillPassed && e.requiredWorkbenchPersonas >= 3 && e.workbenchPersonasPassed === e.requiredWorkbenchPersonas && e.docsValid && e.independentVerifierValid;
  }
}, Sp = (e, t, r) => {
  var a, d, l, g;
  const i = e.applicability.includes(t.gate), n = [...r].sort(
    (u, p) => u.logicalStartedAt - p.logicalStartedAt || u.fingerprint.localeCompare(p.fingerprint)
  );
  let s = "passed", o = "all-assertions-satisfied";
  return i ? n.length === 0 ? (s = "blocked", o = "mandatory-receipt-missing") : new Set(n.map((u) => u.fingerprint)).size > 1 ? (s = "failed", o = "receipt-conflict") : n[0].runnerBlocked ? (s = "blocked", o = "runner-blocked") : kp(n[0]) || (s = "failed", o = "assertion-failed") : (s = "not-applicable", o = "applicability-excluded"), we("zx.ai.production.gate-result.v1", {
    gate: t.gate,
    status: s,
    reason: o,
    claimScope: e.claimScope,
    manifestFingerprint: e.fingerprint,
    logicalStartedAt: ((a = n[0]) == null ? void 0 : a.logicalStartedAt) ?? 0,
    logicalFinishedAt: ((d = n[0]) == null ? void 0 : d.logicalFinishedAt) ?? 0,
    previousGateArtifactSha256: ((l = n[0]) == null ? void 0 : l.previousGateArtifactSha256) ?? null,
    evidence: c(((g = n[0]) == null ? void 0 : g.artifactRefs) ?? [])
  });
}, Ap = (e) => {
  var o, a;
  const t = hn(e.manifest), r = e.receipts.map(Rp);
  if (r.some(
    (d) => d.runId !== t.runId || d.manifestFingerprint !== t.fingerprint || d.sourceClosureFingerprint !== t.sourceClosureFingerprint
  ))
    throw new $("contract-invalid");
  for (const [d, l] of je.entries()) {
    const g = r.filter((p) => p.gate === l);
    if (g.length === 0) continue;
    const u = d === 0 ? null : (a = (o = r.find(
      (p) => p.gate === je[d - 1]
    )) == null ? void 0 : o.artifactRefs[0]) == null ? void 0 : a.sha256;
    if (u === void 0 || g.some(
      (p) => p.previousGateArtifactSha256 !== u
    ))
      throw new $("contract-invalid");
  }
  const i = t.gates.map(
    (d) => Sp(
      t,
      d,
      r.filter((l) => l.gate === d.gate)
    )
  ), n = i.map(
    (d) => we("zx.ai.production.evidence-claim.v1", {
      kind: "zx.ai.production.evidence-claim.v1",
      gate: d.gate,
      claimClass: d.status === "not-applicable" ? "not-claimed" : d.status === "blocked" ? "observation" : "verified",
      claimScope: t.claimScope,
      reason: d.reason,
      gateResultFingerprint: d.fingerprint
    })
  ), s = t.claimScope === "package-candidate" && t.waivers.every((d) => {
    const l = i[$o(d.gate)];
    return (l == null ? void 0 : l.status) === "not-applicable" && t.evaluatedAtEpochSeconds >= d.startsAtEpochSeconds && t.evaluatedAtEpochSeconds < d.expiresAtEpochSeconds;
  }) && i.every(
    (d, l) => t.gates[l].mandatory ? d.status === "passed" : d.status === "passed" || d.status === "not-applicable"
  );
  return we("zx.ai.production.release-verdict.v1", {
    kind: "zx.ai.production.release-verdict.v1",
    claimScope: t.claimScope,
    status: t.claimScope === "host-deployment" ? "not-claimed" : s ? "package-production-ready" : "not-ready",
    gates: c(i),
    claims: c(n),
    manifestFingerprint: t.fingerprint,
    sourceClosureFingerprint: t.sourceClosureFingerprint
  });
}, Ep = /^sha256:[a-f0-9]{64}$/, Do = [
  "long-form-writing",
  "knowledge-base",
  "business-document"
], zo = ["standard", "stress", "pathological"], Cp = ["node-fixed", "chromium-fixed", "host-bound"], Et = (e) => k(e, { max: 71, pattern: Ep }), qp = [
  "ask",
  "session",
  "proposal",
  "review",
  "collaboration-commit",
  "undo-recovery",
  "reject"
], Oo = (e) => {
  const t = J(e, ["id", "stage", "target", "expected"]);
  return {
    id: k(t.id, { max: 64 }),
    stage: z(t.stage, qp),
    target: k(t.target, { max: 96 }),
    expected: k(t.expected, { max: 96 })
  };
}, No = (e) => {
  const t = J(e, ["kind", "body", "assets", "expansion"]);
  if (t.kind !== "zx.ai.production.portable-document.v1")
    throw new $("contract-invalid");
  const r = J(t.body, ["type", "content"]);
  if (r.type !== "doc") throw new $("contract-invalid");
  const i = Q(
    r.content,
    (s) => {
      const o = J(s, ["type", "attrs", "text"]), a = J(o.attrs, ["blockId"]);
      return {
        type: k(o.type, { max: 64 }),
        attrs: { blockId: k(a.blockId, { max: 96 }) },
        text: k(o.text, { max: 256 })
      };
    },
    128
  ), n = J(t.expansion, [
    "seed",
    "blockCount",
    "wordCount",
    "nodeTypes"
  ]);
  return {
    kind: "zx.ai.production.portable-document.v1",
    body: { type: "doc", content: i },
    assets: Q(t.assets, (s) => s, 128),
    expansion: {
      seed: W(n.seed, 0, 4294967295),
      blockCount: W(n.blockCount, 1, 1e5),
      wordCount: W(n.wordCount, 1, 1e6),
      nodeTypes: ue(
        Q(n.nodeTypes, (s) => k(s, { max: 64 }))
      )
    }
  };
}, _o = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "id",
    "version",
    "persona",
    "scale",
    "fixtureId",
    "blockCount",
    "wordCount",
    "actions",
    "peerCount",
    "faults",
    "schemaRef",
    "manifestRef",
    "sourceClosureFingerprint",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.workload-profile.v1" || r.version !== "1.0.0")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.workload-profile.v1",
    id: k(r.id, { max: 96 }),
    version: "1.0.0",
    persona: z(r.persona, Do),
    scale: z(r.scale, zo),
    fixtureId: k(r.fixtureId, { max: 96 }),
    blockCount: W(r.blockCount, 1, 1e5),
    wordCount: W(r.wordCount, 1, 1e6),
    actions: ue(
      Q(r.actions, (i) => k(i, { max: 64 }), 256)
    ),
    peerCount: W(r.peerCount, 1, 16),
    faults: ue(
      Q(r.faults, (i) => k(i, { max: 64 }), 128)
    ),
    schemaRef: k(r.schemaRef, { max: 128 }),
    manifestRef: k(r.manifestRef, { max: 128 }),
    sourceClosureFingerprint: Et(r.sourceClosureFingerprint),
    fingerprint: ge(
      "zx.ai.production.workload-profile.v1",
      r
    )
  };
}), Sg = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "id",
    "version",
    "environmentClass",
    "machineClass",
    "runtime",
    "browser",
    "comparable",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.environment-profile.v1" || r.version !== "1.0.0")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.environment-profile.v1",
    id: k(r.id, { max: 96 }),
    version: "1.0.0",
    environmentClass: z(r.environmentClass, Cp),
    machineClass: k(r.machineClass, { max: 96 }),
    runtime: k(r.runtime, { max: 96 }),
    browser: r.browser === null ? null : k(r.browser, { max: 96 }),
    comparable: Me(r.comparable),
    fingerprint: ge(
      "zx.ai.production.environment-profile.v1",
      r
    )
  };
}), Tp = (e) => {
  const t = J(e, [
    "metric",
    "unit",
    "absoluteCeiling",
    "relativeRegressionCeiling"
  ]);
  return {
    metric: k(t.metric, { max: 96 }),
    unit: z(t.unit, [
      "milliseconds",
      "bytes",
      "count",
      "ratio"
    ]),
    absoluteCeiling: ni(t.absoluteCeiling),
    relativeRegressionCeiling: ni(t.relativeRegressionCeiling, 1)
  };
}, Ag = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "id",
    "version",
    "workloadFingerprint",
    "environmentFingerprint",
    "warmupCount",
    "sampleCount",
    "percentilePolicy",
    "outlierPolicy",
    "gcIdlePolicy",
    "metrics",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.budget-profile.v1" || r.version !== "1.0.0" || r.percentilePolicy !== "nearest-rank" || r.outlierPolicy !== "retain-all" || r.gcIdlePolicy !== "record-no-force")
    throw new $("contract-invalid");
  const i = Q(r.metrics, Tp, 128);
  return ue(i.map((n) => n.metric)), {
    kind: "zx.ai.production.budget-profile.v1",
    id: k(r.id, { max: 96 }),
    version: "1.0.0",
    workloadFingerprint: Et(r.workloadFingerprint),
    environmentFingerprint: Et(r.environmentFingerprint),
    warmupCount: W(r.warmupCount, 5, 1e4),
    sampleCount: W(r.sampleCount, 100, 1e5),
    percentilePolicy: "nearest-rank",
    outlierPolicy: "retain-all",
    gcIdlePolicy: "record-no-force",
    metrics: i,
    fingerprint: ge(
      "zx.ai.production.budget-profile.v1",
      r
    )
  };
}), yn = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "id",
    "version",
    "profileFingerprint",
    "schemaRef",
    "manifestRef",
    "sourceClosureFingerprint",
    "privacy",
    "provenanceFingerprint",
    "document",
    "actionPlan",
    "expectedInvariants",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.fixture.v1" || r.version !== "1.0.0" || r.privacy !== "synthetic-content-free")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.fixture.v1",
    id: k(r.id, { max: 96 }),
    version: "1.0.0",
    profileFingerprint: Et(r.profileFingerprint),
    schemaRef: k(r.schemaRef, { max: 128 }),
    manifestRef: k(r.manifestRef, { max: 128 }),
    sourceClosureFingerprint: Et(r.sourceClosureFingerprint),
    privacy: "synthetic-content-free",
    provenanceFingerprint: Et(r.provenanceFingerprint),
    document: No(r.document),
    actionPlan: Q(r.actionPlan, Oo, 256),
    expectedInvariants: ue(
      Q(
        r.expectedInvariants,
        (i) => k(i, { max: 96 })
      )
    ),
    fingerprint: ge(
      "zx.ai.production.fixture.v1",
      r
    )
  };
}), Eg = (e, t) => {
  if (!(e instanceof Uint8Array) || e.byteLength !== t.bytes)
    throw new $("contract-invalid");
  const r = new TextDecoder("utf-8", { fatal: !0 }).decode(e);
  if (t.mediaType !== "application/json" || t.sha256 !== `sha256:${ts(r)}`)
    throw new $("fingerprint-mismatch");
  return yn(JSON.parse(r));
}, Bp = (e, t) => {
  const r = yn(e), i = _o(t);
  if (r.id !== i.fixtureId || r.profileFingerprint !== i.fingerprint || r.schemaRef !== i.schemaRef || r.manifestRef !== i.manifestRef || r.sourceClosureFingerprint !== i.sourceClosureFingerprint)
    throw new $("contract-invalid");
  return c(r);
}, Cg = (e) => {
  const t = Re(e.template, (d) => {
    const l = J(d, [
      "kind",
      "id",
      "version",
      "persona",
      "scale",
      "blockCount",
      "wordCount",
      "actions",
      "peerCount",
      "faults",
      "schemaRef",
      "manifestRef",
      "seed",
      "provenanceFingerprint",
      "document",
      "actionPlan",
      "expectedInvariants"
    ]);
    if (l.kind !== "zx.ai.production.portable-fixture-template.v1" || l.version !== "1.0.0")
      throw new $("contract-invalid");
    return {
      kind: "zx.ai.production.portable-fixture-template.v1",
      id: k(l.id, { max: 96 }),
      version: "1.0.0",
      persona: z(l.persona, Do),
      scale: z(l.scale, zo),
      blockCount: W(l.blockCount, 1, 1e5),
      wordCount: W(l.wordCount, 1, 1e6),
      actions: ue(
        Q(l.actions, (g) => k(g, { max: 64 }), 256)
      ),
      peerCount: W(l.peerCount, 1, 16),
      faults: ue(
        Q(l.faults, (g) => k(g, { max: 64 }), 128)
      ),
      schemaRef: k(l.schemaRef, { max: 128 }),
      manifestRef: k(l.manifestRef, { max: 128 }),
      seed: W(l.seed, 0, 4294967295),
      provenanceFingerprint: Et(l.provenanceFingerprint),
      document: No(l.document),
      actionPlan: Q(l.actionPlan, Oo, 256),
      expectedInvariants: ue(
        Q(
          l.expectedInvariants,
          (g) => k(g, { max: 96 })
        )
      )
    };
  });
  if (t.document.expansion.seed !== t.seed || t.document.expansion.blockCount !== t.blockCount || t.document.expansion.wordCount !== t.wordCount || t.actions.length !== t.actionPlan.length || t.actions.some(
    (d, l) => d !== t.actionPlan[l].id
  ) || t.provenanceFingerprint !== gn("zx.ai.production.fixture-provenance.v1", {
    id: t.id,
    persona: t.persona,
    scale: t.scale,
    seed: t.seed,
    document: t.document,
    actionPlan: t.actionPlan
  }))
    throw new $("contract-invalid");
  const r = Et(e.sourceClosureFingerprint), i = we(
    "zx.ai.production.workload-profile.v1",
    {
      kind: "zx.ai.production.workload-profile.v1",
      id: `${t.persona}/v1/${t.scale}`,
      version: "1.0.0",
      persona: t.persona,
      scale: t.scale,
      fixtureId: t.id,
      blockCount: t.blockCount,
      wordCount: t.wordCount,
      actions: t.actions,
      peerCount: t.peerCount,
      faults: t.faults,
      schemaRef: t.schemaRef,
      manifestRef: t.manifestRef,
      sourceClosureFingerprint: r
    }
  ), n = we("zx.ai.production.fixture.v1", {
    kind: "zx.ai.production.fixture.v1",
    id: t.id,
    version: "1.0.0",
    profileFingerprint: i.fingerprint,
    schemaRef: t.schemaRef,
    manifestRef: t.manifestRef,
    sourceClosureFingerprint: r,
    privacy: "synthetic-content-free",
    provenanceFingerprint: t.provenanceFingerprint,
    document: t.document,
    actionPlan: t.actionPlan,
    expectedInvariants: t.expectedInvariants
  }), s = ke(n), o = new TextEncoder().encode(s), a = c({
    id: n.id,
    mediaType: "application/json",
    bytes: o.byteLength,
    sha256: `sha256:${ts(s)}`
  });
  return c({
    profile: _o(i),
    fixture: Bp(n, i),
    bytes: o,
    ref: a
  });
}, qg = (e) => {
  const t = yn(e), { expansion: r } = t.document;
  if (t.document.body.content.length === 0 || r.nodeTypes.length === 0)
    throw new $("contract-invalid");
  const n = Math.floor(r.wordCount / r.blockCount), s = r.wordCount % r.blockCount, o = (u, p) => `s${r.seed.toString(36)}${u.toString(36)}_${p}`, a = (u) => ({ type: "text", text: u }), d = (u, p) => ({
    type: "paragraph",
    attrs: { blockId: u, textAlign: null },
    content: [a(p)]
  }), l = (u, p, f, m) => {
    switch (u) {
      case "heading":
        return {
          type: u,
          attrs: { blockId: p, textAlign: null, level: m % 3 + 1 },
          content: [a(f)]
        };
      case "bulletList":
      case "orderedList":
        return {
          type: u,
          attrs: { blockId: p },
          content: [
            {
              type: "listItem",
              attrs: { blockId: o(m, "item") },
              content: [d(o(m, "listp"), f)]
            }
          ]
        };
      case "table":
        return {
          type: u,
          attrs: { blockId: p },
          content: [
            {
              type: "tableRow",
              attrs: { rowId: o(m, "row") },
              content: [
                {
                  type: "tableCell",
                  attrs: {
                    cellId: o(m, "cell"),
                    colspan: 1,
                    rowspan: 1,
                    colwidth: null,
                    align: null
                  },
                  content: [d(o(m, "tablep"), f)]
                }
              ]
            }
          ]
        };
      case "codeBlock":
        return {
          type: u,
          attrs: { blockId: p, language: "text" },
          content: [a(f)]
        };
      case "image":
        return {
          type: u,
          attrs: {
            blockId: p,
            assetId: `${p}-asset`,
            src: `https://synthetic.invalid/${t.id}/${p}`,
            alt: f
          }
        };
      case "blockquote":
        return {
          type: u,
          attrs: { blockId: p },
          content: [d(o(m, "quotep"), f)]
        };
      default:
        return d(p, f);
    }
  }, g = Array.from({ length: r.blockCount }, (u, p) => {
    const f = o(p, "root"), m = r.nodeTypes[p % r.nodeTypes.length], y = n + (p < s ? 1 : 0), I = Array.from({ length: y }, () => "w").join(" ");
    return {
      id: f,
      type: m,
      wordCount: y,
      text: I,
      node: l(m, f, I, p)
    };
  });
  return c({
    kind: "zx.ai.production.materialized-document.v1",
    fixtureFingerprint: t.fingerprint,
    seed: r.seed,
    wordCount: r.wordCount,
    actualWordCount: g.reduce(
      (u, p) => u + p.wordCount,
      0
    ),
    blockCount: g.length,
    structuralNodeTypes: [...new Set(g.map((u) => u.type))],
    body: {
      type: "doc",
      content: g.map((u) => u.node)
    },
    assets: g.filter((u) => u.type === "image").map((u) => ({
      id: `${u.id}-asset`,
      type: "image",
      src: `https://synthetic.invalid/${t.id}/${u.id}`,
      mimeType: "image/png",
      meta: { synthetic: !0, bytes: u.text.length }
    })),
    blocks: g
  });
}, Pp = [
  "admission",
  "runtime",
  "proposal",
  "review",
  "session",
  "collaboration",
  "evidence"
], $p = ["accepted", "rejected", "unavailable", "incident"], jp = [
  "all-assertions-satisfied",
  "applicability-excluded",
  "artifact-invalid",
  "assertion-failed",
  "environment-not-comparable",
  "evidence-missing",
  "feature-audit-invalid",
  "mandatory-receipt-missing",
  "receipt-conflict",
  "receipt-invalid",
  "rollout-threshold-not-met",
  "runner-blocked",
  "source-closure-invalid",
  "waiver-invalid"
], Dp = ["lt-10ms", "lt-100ms", "lt-1s", "gte-1s"], zp = ["small", "standard", "stress", "overflow"], Op = (e) => Re(e, (t) => {
  if (t === null || typeof t != "object" || Array.isArray(t))
    throw new $("contract-invalid");
  const r = [
    "reason",
    "durationBucket",
    "resourceBucket",
    "correlationRef"
  ].filter((s) => Object.prototype.hasOwnProperty.call(t, s)), i = J(t, [
    "kind",
    "stage",
    "outcome",
    "overflow",
    ...r
  ]);
  if (i.kind !== "zx.ai.production.telemetry.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.telemetry.v1",
    stage: z(i.stage, Pp),
    outcome: z(i.outcome, $p),
    ...i.reason === void 0 ? {} : { reason: z(i.reason, jp) },
    ...i.durationBucket === void 0 ? {} : { durationBucket: z(i.durationBucket, Dp) },
    ...i.resourceBucket === void 0 ? {} : { resourceBucket: z(i.resourceBucket, zp) },
    ...i.correlationRef === void 0 ? {} : {
      correlationRef: k(i.correlationRef, {
        min: 37,
        max: 37,
        pattern: /^corr_[a-f0-9]{32}$/
      })
    },
    overflow: Me(i.overflow)
  };
}), Tg = (e) => {
  const t = W(e.sampleEvery, 1, 1e4), r = W(e.maxCardinality, 1, 1e4), i = /* @__PURE__ */ new Set();
  let n = 0, s = 0, o = 0, a = 0, d = 0;
  return c({ record: (u) => {
    const p = Op(u);
    if (n += 1, (n - 1) % t !== 0)
      return o += 1, null;
    const f = [p.stage, p.outcome, p.reason ?? "none"].join("|");
    let m = p;
    !i.has(f) && i.size >= r ? (a += 1, m = c({
      kind: "zx.ai.production.telemetry.v1",
      stage: p.stage,
      outcome: p.outcome,
      resourceBucket: "overflow",
      overflow: !0
    })) : i.add(f);
    try {
      e.sink.emit(m), s += 1;
    } catch {
      d += 1;
    }
    return m;
  }, receipt: () => c({
    kind: "zx.ai.production.telemetry-flush.v1",
    accepted: s,
    sampledOut: o,
    overflowed: a,
    sinkFailures: d
  }) });
}, In = [
  "ai-entry",
  "session-stream",
  "review-commit",
  "collaboration-enhancement",
  "complex-node-ai",
  "telemetry-export"
], bn = ["enabled", "disabled"], Lo = ["ai-platform", "release-operator"], Zn = /^sha256:[a-f0-9]{64}$/, Np = /^host_[a-f0-9]{32}$/, Vo = (e) => e === null ? null : W(e), Jn = (e) => e === null ? null : z(e, bn), Ho = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "key",
    "defaultValue",
    "owner",
    "scope",
    "temporary",
    "startsAtEpochSeconds",
    "expiresAtEpochSeconds",
    "affectedGates",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.feature-definition.v1" || r.defaultValue !== "disabled" || typeof r.temporary != "boolean")
    throw new $("contract-invalid");
  const i = W(r.startsAtEpochSeconds), n = Vo(r.expiresAtEpochSeconds);
  if (r.temporary && n === null || n !== null && n <= i)
    throw new $("contract-invalid");
  const s = ue(
    Q(
      r.affectedGates,
      (o) => z(o, je)
    )
  );
  if (s.length === 0)
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.feature-definition.v1",
    key: z(r.key, In),
    defaultValue: "disabled",
    owner: z(r.owner, Lo),
    scope: z(r.scope, [
      "package-global",
      "host-environment",
      "opaque-cohort"
    ]),
    temporary: r.temporary,
    startsAtEpochSeconds: i,
    expiresAtEpochSeconds: n,
    affectedGates: s,
    fingerprint: ge(
      "zx.ai.production.feature-definition.v1",
      r
    )
  };
}), _p = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "definitionFingerprint",
    "hostBinding",
    "value",
    "reason",
    "evaluatedAtEpochSeconds",
    "contextFingerprint",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.feature-decision.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.feature-decision.v1",
    definitionFingerprint: k(r.definitionFingerprint, {
      max: 71,
      pattern: Zn
    }),
    hostBinding: k(r.hostBinding, {
      min: 37,
      max: 37,
      pattern: Np
    }),
    value: z(r.value, bn),
    reason: z(r.reason, [
      "provider-valid",
      "provider-invalid",
      "provider-unavailable",
      "provider-expired",
      "context-mismatch"
    ]),
    evaluatedAtEpochSeconds: W(r.evaluatedAtEpochSeconds),
    contextFingerprint: k(r.contextFingerprint, {
      max: 71,
      pattern: Zn
    }),
    fingerprint: ge(
      "zx.ai.production.feature-decision.v1",
      r
    )
  };
}), Lp = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "action",
    "key",
    "owner",
    "reason",
    "approvalSource",
    "startsAtEpochSeconds",
    "expiresAtEpochSeconds",
    "previousValue",
    "newValue",
    "affectedGates",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.feature-audit.v1")
    throw new $("contract-invalid");
  const i = z(r.action, [
    "created",
    "restricted",
    "relaxed",
    "extended",
    "deleted"
  ]), n = z(r.reason, [
    "incident-response",
    "reviewed-rollout",
    "scheduled-expiry"
  ]), s = z(r.approvalSource, [
    "security-review",
    "release-review",
    "incident-commander"
  ]), o = W(r.startsAtEpochSeconds), a = Vo(r.expiresAtEpochSeconds), d = Jn(r.previousValue), l = Jn(r.newValue), g = ue(
    Q(
      r.affectedGates,
      (p) => z(p, je)
    )
  );
  if (!(i === "created" && d === null && l !== null || i === "restricted" && d === "enabled" && l === "disabled" || i === "relaxed" && d === "disabled" && l === "enabled" || i === "extended" && d !== null && d === l || i === "deleted" && d !== null && l === null) || g.length === 0 || a !== null && a <= o || (i === "relaxed" || i === "extended") && (n !== "reviewed-rollout" || s === "incident-commander" || a === null))
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.feature-audit.v1",
    action: i,
    key: z(r.key, In),
    owner: z(r.owner, Lo),
    reason: n,
    approvalSource: s,
    startsAtEpochSeconds: o,
    expiresAtEpochSeconds: a,
    previousValue: d,
    newValue: l,
    affectedGates: g,
    fingerprint: ge(
      "zx.ai.production.feature-audit.v1",
      r
    )
  };
}), Bg = (e) => {
  const t = Ho(e.definition), r = Re(
    e.auditReceipts,
    (o) => Q(o, Lp, 128)
  ), i = W(e.nowEpochSeconds);
  if (r.length === 0)
    throw new $("contract-invalid");
  const n = JSON.stringify(t.affectedGates);
  for (const [o, a] of r.entries()) {
    const d = r[o - 1];
    if (a.key !== t.key || a.owner !== t.owner || JSON.stringify(a.affectedGates) !== n || o === 0 && (a.action !== "created" || a.previousValue !== null || a.newValue !== t.defaultValue || a.startsAtEpochSeconds !== t.startsAtEpochSeconds) || d !== void 0 && (a.startsAtEpochSeconds <= d.startsAtEpochSeconds || a.previousValue !== d.newValue))
      throw new $("contract-invalid");
  }
  const s = r[r.length - 1];
  if (s.newValue === null || s.expiresAtEpochSeconds !== t.expiresAtEpochSeconds || s.expiresAtEpochSeconds !== null && i >= s.expiresAtEpochSeconds)
    throw new $("contract-invalid");
  return we(
    "zx.ai.production.feature-audit-chain-verification.v1",
    {
      kind: "zx.ai.production.feature-audit-chain-verification.v1",
      key: t.key,
      owner: t.owner,
      currentValue: s.newValue,
      auditCount: r.length,
      latestAuditFingerprint: s.fingerprint,
      affectedGates: t.affectedGates
    }
  );
}, Pg = (e) => {
  const t = Ho(e.definition);
  let r = t.defaultValue, i = "provider-unavailable", n = null;
  try {
    if (e.providerReceipt !== null) {
      const s = _p(
        e.providerReceipt
      );
      n = s.fingerprint, s.definitionFingerprint !== t.fingerprint || s.contextFingerprint !== e.contextFingerprint || s.hostBinding !== e.hostBinding ? i = "context-mismatch" : e.nowEpochSeconds < t.startsAtEpochSeconds || s.evaluatedAtEpochSeconds > e.nowEpochSeconds || t.expiresAtEpochSeconds !== null && e.nowEpochSeconds >= t.expiresAtEpochSeconds ? i = "provider-expired" : s.reason === "provider-valid" ? (r = s.value, i = "provider-valid") : i = s.reason;
    }
  } catch {
    i = "provider-invalid";
  }
  return we("zx.ai.production.feature-evaluation.v1", {
    kind: "zx.ai.production.feature-evaluation.v1",
    key: t.key,
    value: r,
    reason: i,
    providerReceiptFingerprint: n
  });
}, $g = (e) => {
  const t = z(e.key, In), r = z(e.phase, [
    "pre-dispatch",
    "in-flight",
    "post-dispatch"
  ]), i = z(e.value, bn);
  return we(
    "zx.ai.production.feature-phase-decision.v1",
    {
      kind: "zx.ai.production.feature-phase-decision.v1",
      key: t,
      phase: r,
      value: i,
      disposition: i === "enabled" ? "continue-authority-path" : r === "pre-dispatch" ? "cancel-before-dispatch" : r === "post-dispatch" ? "incident-fence" : t === "session-stream" ? "abort-request" : "stop-before-commit"
    }
  );
}, Ko = ["shadow", "canary", "gradual", "general"], Mo = /^sha256:[a-f0-9]{64}$/, Vp = /^cohort_[a-f0-9]{16}$/, Uo = (e) => e === null ? null : k(e, { min: 23, max: 23, pattern: Vp }), Hp = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "id",
    "claimScope",
    "stage",
    "minimumSamples",
    "enterSuccessRatio",
    "exitFailureRatio",
    "cohortBucket",
    "rollbackTarget",
    "compatibilityProofRefs",
    "expiresAtEpochSeconds",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.rollout-policy.v1")
    throw new $("contract-invalid");
  const i = ni(r.enterSuccessRatio), n = ni(r.exitFailureRatio);
  if (i > 1 || n > 1)
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.rollout-policy.v1",
    id: k(r.id, { max: 96 }),
    claimScope: z(r.claimScope, [
      "package-candidate",
      "host-deployment"
    ]),
    stage: z(r.stage, Ko),
    minimumSamples: W(r.minimumSamples, 1, 1e6),
    enterSuccessRatio: i,
    exitFailureRatio: n,
    cohortBucket: Uo(r.cohortBucket),
    rollbackTarget: k(r.rollbackTarget, { max: 128 }),
    compatibilityProofRefs: ue(
      Q(
        r.compatibilityProofRefs,
        (s) => k(s, { max: 71, pattern: Mo })
      )
    ),
    expiresAtEpochSeconds: W(r.expiresAtEpochSeconds),
    fingerprint: ge(
      "zx.ai.production.rollout-policy.v1",
      r
    )
  };
}), Kp = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "policyFingerprint",
    "claimScope",
    "stage",
    "sampleCount",
    "successCount",
    "failureCount",
    "shadowArtifactCount",
    "liveArtifactCount",
    "cohortBucket",
    "measuredAtEpochSeconds",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.rollout-receipt.v1")
    throw new $("contract-invalid");
  const i = W(r.sampleCount), n = W(r.successCount), s = W(r.failureCount);
  if (n + s !== i)
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.rollout-receipt.v1",
    policyFingerprint: k(r.policyFingerprint, {
      max: 71,
      pattern: Mo
    }),
    claimScope: z(r.claimScope, [
      "package-candidate",
      "host-deployment"
    ]),
    stage: z(r.stage, Ko),
    sampleCount: i,
    successCount: n,
    failureCount: s,
    shadowArtifactCount: W(r.shadowArtifactCount),
    liveArtifactCount: W(r.liveArtifactCount),
    cohortBucket: Uo(r.cohortBucket),
    measuredAtEpochSeconds: W(r.measuredAtEpochSeconds),
    fingerprint: ge(
      "zx.ai.production.rollout-receipt.v1",
      r
    )
  };
}), jg = (e) => {
  const t = Hp(e.policy), r = Kp(e.receipt);
  let i = "advance", n = "threshold-satisfied";
  return r.policyFingerprint !== t.fingerprint || r.claimScope !== t.claimScope || r.stage !== t.stage || r.cohortBucket !== t.cohortBucket ? (i = "blocked", n = "cohort-mismatch") : e.nowEpochSeconds >= t.expiresAtEpochSeconds ? (i = "blocked", n = "policy-expired") : t.compatibilityProofRefs.length === 0 ? (i = "blocked", n = "compatibility-proof-missing") : t.stage === "shadow" && (r.liveArtifactCount > 0 || r.shadowArtifactCount > 0) ? (i = "blocked", n = "shadow-write-detected") : r.sampleCount < t.minimumSamples ? (i = "hold", n = "insufficient-samples") : r.sampleCount > 0 && r.failureCount / r.sampleCount >= t.exitFailureRatio ? (i = "rollback", n = "failure-threshold-exceeded") : (r.sampleCount === 0 || r.successCount / r.sampleCount < t.enterSuccessRatio) && (i = "hold", n = "insufficient-samples"), we("zx.ai.production.rollout-decision.v1", {
    kind: "zx.ai.production.rollout-decision.v1",
    decision: i,
    reason: n,
    policyFingerprint: t.fingerprint,
    receiptFingerprint: r.fingerprint
  });
}, Go = [
  "peer-connect",
  "peer-disconnect",
  "peer-restart",
  "message-delay",
  "message-reorder",
  "message-duplicate",
  "message-drop",
  "network-partition",
  "network-flush",
  "provider-gap",
  "provider-malformed",
  "provider-timeout",
  "page-offline",
  "page-online",
  "page-reload",
  "checkpoint",
  "compaction",
  "incident-fence",
  "kill-switch-transition"
], tr = /^sha256:[a-f0-9]{64}$/, Mp = (e) => {
  let t = Math.trunc(e);
  return t ^= t << 13, t ^= t >>> 17, t ^= t << 5, t >>> 0;
}, Up = (e) => {
  const t = J(e, [
    "kind",
    "logicalTime",
    "fault",
    "peer",
    "inputRef",
    "outputRef",
    "fingerprint"
  ]);
  if (t.kind !== "zx.ai.production.fault-step.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.fault-step.v1",
    logicalTime: W(t.logicalTime),
    fault: z(t.fault, Go),
    peer: t.peer === null ? null : k(t.peer, { max: 32 }),
    inputRef: k(t.inputRef, { max: 71, pattern: tr }),
    outputRef: k(t.outputRef, { max: 71, pattern: tr }),
    fingerprint: ge(
      "zx.ai.production.fault-step.v1",
      t
    )
  };
}, Qn = (e) => Re(e, (t) => {
  const r = J(t, ["kind", "seed", "steps", "fingerprint"]);
  if (r.kind !== "zx.ai.production.fault-schedule.v1")
    throw new $("contract-invalid");
  const i = Q(r.steps, Up, 1e4);
  for (let n = 1; n < i.length; n += 1)
    if (i[n].logicalTime < i[n - 1].logicalTime)
      throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.fault-schedule.v1",
    seed: W(r.seed, 0, 4294967295),
    steps: i,
    fingerprint: ge(
      "zx.ai.production.fault-schedule.v1",
      r
    )
  };
}), Dg = () => c({
  create(e) {
    const t = W(e.seed, 0, 4294967295);
    if (e.faults.length > 1e4 || e.peers.length > 16)
      throw new $("contract-invalid");
    const r = e.faults.map((a) => z(a, Go)), i = ue(
      e.peers.map((a) => k(a, { max: 32 }))
    ), n = k(e.inputRef, { max: 71, pattern: tr });
    let s = t || 2654435769;
    const o = r.map((a, d) => {
      s = Mp(s);
      const l = i.length === 0 ? null : i[s % i.length];
      return we("zx.ai.production.fault-step.v1", {
        kind: "zx.ai.production.fault-step.v1",
        logicalTime: d,
        fault: a,
        peer: l,
        inputRef: n,
        outputRef: we(
          "zx.ai.production.fault-output-ref.v1",
          { seed: t, index: d, fault: a, peer: l, inputRef: n }
        ).fingerprint
      });
    });
    return we("zx.ai.production.fault-schedule.v1", {
      kind: "zx.ai.production.fault-schedule.v1",
      seed: t,
      steps: c(o)
    });
  },
  replay(e) {
    const t = Qn(e), r = t.steps.map((i) => i.fingerprint);
    return we("zx.ai.production.fault-terminal.v1", {
      kind: "zx.ai.production.fault-terminal.v1",
      scheduleFingerprint: t.fingerprint,
      appliedSteps: t.steps.length,
      monotonicLogicalTime: t.steps.every(
        (i, n) => n === 0 || i.logicalTime >= t.steps[n - 1].logicalTime
      ),
      duplicateStepFingerprints: r.length - new Set(r).size,
      stepReceipts: [],
      authorityPreserved: !0,
      auditPreserved: !0,
      undoPreserved: !0,
      privacyPreserved: !0,
      terminalRef: we(
        "zx.ai.production.fault-terminal-ref.v1",
        { scheduleFingerprint: t.fingerprint, fingerprints: r }
      ).fingerprint
    });
  },
  async execute(e, t) {
    const r = Qn(e);
    if (t === null || typeof (t == null ? void 0 : t.apply) != "function")
      throw new $("contract-invalid");
    const i = [];
    for (const s of r.steps) {
      const o = await t.apply(s), a = k(o.terminalRef, {
        max: 71,
        pattern: tr
      });
      i.push(
        we(
          "zx.ai.production.fault-step-execution.v1",
          {
            kind: "zx.ai.production.fault-step-execution.v1",
            stepFingerprint: s.fingerprint,
            fault: s.fault,
            applied: o.applied === !0,
            effect: k(o.effect, { max: 96 }),
            beforeFingerprint: k(o.beforeFingerprint, {
              max: 71,
              pattern: tr
            }),
            afterFingerprint: k(o.afterFingerprint, {
              max: 71,
              pattern: tr
            }),
            terminalRef: a,
            authorityPreserved: o.authorityPreserved === !0,
            auditPreserved: o.auditPreserved === !0,
            undoPreserved: o.undoPreserved === !0,
            privacyPreserved: o.privacyPreserved === !0
          }
        )
      );
    }
    const n = r.steps.map((s) => s.fingerprint);
    return we("zx.ai.production.fault-terminal.v1", {
      kind: "zx.ai.production.fault-terminal.v1",
      scheduleFingerprint: r.fingerprint,
      appliedSteps: i.filter((s) => s.applied).length,
      monotonicLogicalTime: r.steps.every(
        (s, o) => o === 0 || s.logicalTime >= r.steps[o - 1].logicalTime
      ),
      duplicateStepFingerprints: n.length - new Set(n).size,
      stepReceipts: c(i),
      authorityPreserved: i.every(
        (s) => s.authorityPreserved
      ),
      auditPreserved: i.every((s) => s.auditPreserved),
      undoPreserved: i.every((s) => s.undoPreserved),
      privacyPreserved: i.every(
        (s) => s.privacyPreserved
      ),
      terminalRef: we(
        "zx.ai.production.fault-terminal-ref.v1",
        {
          scheduleFingerprint: r.fingerprint,
          stepReceiptFingerprints: i.map(
            (s) => s.fingerprint
          )
        }
      ).fingerprint
    });
  }
}), sr = /^sha256:[a-f0-9]{64}$/, Gp = ["package-candidate", "host-deployment"], Wp = ["passed", "failed", "blocked", "not-applicable"], Yp = ["verified", "observation", "not-claimed"], Wo = [
  "all-assertions-satisfied",
  "applicability-excluded",
  "artifact-invalid",
  "assertion-failed",
  "environment-not-comparable",
  "evidence-missing",
  "feature-audit-invalid",
  "mandatory-receipt-missing",
  "receipt-conflict",
  "receipt-invalid",
  "rollout-threshold-not-met",
  "runner-blocked",
  "source-closure-invalid",
  "waiver-invalid"
], Xp = [
  "package-production-ready",
  "not-ready",
  "not-claimed"
], Yo = [
  "workload-profile",
  "fixture",
  "seed-corpus",
  "feature-definition",
  "feature-decision",
  "feature-audit",
  "rollout-policy",
  "rollout-receipt",
  "rollout-decision",
  "rollback-drill",
  "reference-receipt",
  "fault-scenario",
  "workbench-receipt",
  "privacy-scan",
  "command"
], Xo = (e) => {
  const t = J(e, ["kind", "category", "id", "fingerprint"]);
  if (t.kind !== "zx.ai.production.evidence-binding.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.evidence-binding.v1",
    category: z(t.category, Yo),
    id: k(t.id, {
      max: 128,
      pattern: /^[a-z0-9][a-z0-9._/-]{0,127}$/
    }),
    fingerprint: k(t.fingerprint, {
      max: 71,
      pattern: sr
    })
  };
}, Zo = (e) => {
  ue(e.map((r) => `${r.category}:${r.id}`));
  const t = new Set(e.map((r) => r.category));
  if (Yo.some((r) => !t.has(r)))
    throw new $("contract-invalid");
}, hi = (e) => z(e, Gp), Jo = (e, t) => {
  const r = new Map(
    t.map((i) => [i.id, i])
  );
  return e.every(
    (i) => i.evidence.every((n) => {
      const s = r.get(n.id);
      return s !== void 0 && ke(s) === ke(n);
    })
  );
}, Qo = (e) => {
  const t = J(e, [
    "gate",
    "status",
    "reason",
    "claimScope",
    "manifestFingerprint",
    "logicalStartedAt",
    "logicalFinishedAt",
    "previousGateArtifactSha256",
    "evidence",
    "fingerprint"
  ]), r = W(t.logicalStartedAt), i = W(t.logicalFinishedAt);
  if (i < r)
    throw new $("contract-invalid");
  return {
    gate: z(t.gate, je),
    status: z(t.status, Wp),
    reason: z(t.reason, Wo),
    claimScope: hi(t.claimScope),
    manifestFingerprint: k(t.manifestFingerprint, {
      max: 71,
      pattern: sr
    }),
    logicalStartedAt: r,
    logicalFinishedAt: i,
    previousGateArtifactSha256: t.previousGateArtifactSha256 === null ? null : k(t.previousGateArtifactSha256, {
      max: 71,
      pattern: sr
    }),
    evidence: Q(t.evidence, vi),
    fingerprint: ge(
      "zx.ai.production.gate-result.v1",
      t
    )
  };
}, ea = (e) => {
  const t = J(e, [
    "kind",
    "gate",
    "claimClass",
    "claimScope",
    "reason",
    "gateResultFingerprint",
    "fingerprint"
  ]);
  if (t.kind !== "zx.ai.production.evidence-claim.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.evidence-claim.v1",
    gate: z(t.gate, je),
    claimClass: z(t.claimClass, Yp),
    claimScope: hi(t.claimScope),
    reason: z(t.reason, Wo),
    gateResultFingerprint: k(t.gateResultFingerprint, {
      max: 71,
      pattern: sr
    }),
    fingerprint: ge(
      "zx.ai.production.evidence-claim.v1",
      t
    )
  };
}, Zp = (e) => {
  const t = J(e, [
    "kind",
    "claimScope",
    "status",
    "gates",
    "claims",
    "manifestFingerprint",
    "sourceClosureFingerprint",
    "fingerprint"
  ]);
  if (t.kind !== "zx.ai.production.release-verdict.v1")
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.release-verdict.v1",
    claimScope: hi(t.claimScope),
    status: z(t.status, Xp),
    gates: Q(t.gates, Qo, 6),
    claims: Q(t.claims, ea, 6),
    manifestFingerprint: k(t.manifestFingerprint, {
      max: 71,
      pattern: sr
    }),
    sourceClosureFingerprint: k(t.sourceClosureFingerprint, {
      max: 71,
      pattern: sr
    }),
    fingerprint: ge(
      "zx.ai.production.release-verdict.v1",
      t
    )
  };
}, zg = (e) => {
  const t = Bo(e.sourceClosure), r = hn(e.manifest);
  if (r.sourceClosureFingerprint !== t.fingerprint)
    throw new $("contract-invalid");
  const i = Ap({
    manifest: r,
    receipts: e.receipts
  }), n = e.artifacts.map(vi), s = e.bindings.map(Xo);
  if (Zo(s), ue(n.map((o) => o.id)), !Jo(i.gates, n))
    throw new $("contract-invalid");
  return we("zx.ai.production.evidence-bundle.v1", {
    kind: "zx.ai.production.evidence-bundle.v1",
    version: "1.0.0",
    claimScope: r.claimScope,
    sourceClosure: t,
    manifest: r,
    gates: i.gates,
    claims: i.claims,
    artifacts: c(n),
    bindings: c(s),
    waivers: r.waivers,
    verdict: i
  });
}, Og = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "version",
    "claimScope",
    "sourceClosure",
    "manifest",
    "gates",
    "claims",
    "artifacts",
    "bindings",
    "waivers",
    "verdict",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.evidence-bundle.v1" || r.version !== "1.0.0")
    throw new $("contract-invalid");
  const i = hi(r.claimScope), n = Bo(r.sourceClosure), s = hn(r.manifest), o = Q(r.gates, Qo, 6), a = Q(r.claims, ea, 6), d = Q(r.artifacts, vi), l = Q(r.bindings, Xo, 1024);
  Zo(l);
  const g = Zp(r.verdict), u = i === "host-deployment" ? "not-claimed" : o.every(
    (p, f) => s.gates[f].mandatory ? p.status === "passed" : p.status === "passed" || p.status === "not-applicable"
  ) ? "package-production-ready" : "not-ready";
  if (i !== s.claimScope || s.sourceClosureFingerprint !== n.fingerprint || g.claimScope !== i || g.status !== u || g.manifestFingerprint !== s.fingerprint || g.sourceClosureFingerprint !== n.fingerprint || o.length !== 6 || a.length !== 6 || g.gates.length !== 6 || g.claims.length !== 6 || o.some(
    (p, f) => {
      var m, y;
      return p.gate !== je[f] || p.claimScope !== i || p.manifestFingerprint !== s.fingerprint || p.previousGateArtifactSha256 !== (f === 0 ? null : (m = d[f - 1]) == null ? void 0 : m.sha256) || p.fingerprint !== ((y = g.gates[f]) == null ? void 0 : y.fingerprint);
    }
  ) || a.some(
    (p, f) => {
      var m, y, I, h, v;
      return p.gate !== je[f] || p.claimScope !== i || p.reason !== ((m = o[f]) == null ? void 0 : m.reason) || p.gateResultFingerprint !== ((y = o[f]) == null ? void 0 : y.fingerprint) || p.claimClass !== (((I = o[f]) == null ? void 0 : I.status) === "not-applicable" ? "not-claimed" : ((h = o[f]) == null ? void 0 : h.status) === "blocked" ? "observation" : "verified") || p.fingerprint !== ((v = g.claims[f]) == null ? void 0 : v.fingerprint);
    }
  ) || ke(r.waivers) !== ke(s.waivers))
    throw new $("contract-invalid");
  if (ue(d.map((p) => p.id)), !Jo(o, d))
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.evidence-bundle.v1",
    version: "1.0.0",
    claimScope: i,
    sourceClosure: n,
    manifest: s,
    gates: o,
    claims: a,
    artifacts: d,
    bindings: l,
    waivers: s.waivers,
    verdict: g,
    fingerprint: ge(
      "zx.ai.production.evidence-bundle.v1",
      r
    )
  };
}), Jp = [
  "BLOCKNOTE",
  "PLATE",
  "NOVEL",
  "TIPTAP",
  "PROSEMIRROR",
  "YJS",
  "OWASP-API4",
  "OWASP-LLM01",
  "OWASP-XSS",
  "OTEL-METRICS",
  "OTEL-SEC",
  "OPENFEATURE",
  "PLAYWRIGHT-NETWORK",
  "PLAYWRIGHT-TRACE",
  "VITEST",
  "FASTCHECK",
  "SRE-CANARY"
], Qp = /^sha256:[a-f0-9]{64}$/, Ng = (e) => Re(e, (t) => {
  const r = J(t, [
    "kind",
    "sourceId",
    "url",
    "version",
    "exactPathsOrHeadings",
    "accessedOn",
    "summarySha256",
    "decision",
    "licenseNote",
    "zxuiBoundaryDiff",
    "fixtureIds",
    "regressionBindings",
    "freshnessDisposition",
    "fingerprint"
  ]);
  if (r.kind !== "zx.ai.production.reference-receipt.v1")
    throw new $("contract-invalid");
  const i = J(r.version, ["mode", "value"]), n = ue(
    Q(
      r.exactPathsOrHeadings,
      (d) => k(d, { max: 256 })
    )
  ), s = ue(
    Q(r.zxuiBoundaryDiff, (d) => k(d, { max: 512 }))
  ), o = ue(
    Q(r.fixtureIds, (d) => k(d, { max: 96 }))
  ), a = ue(
    Q(
      r.regressionBindings,
      (d) => k(d, {
        max: 3,
        pattern: /^M(?:0[1-9]|[1-6][0-9]|7[0-2])$/
      })
    )
  );
  if (n.length === 0 || s.length === 0 || o.length === 0 || a.length === 0)
    throw new $("contract-invalid");
  return {
    kind: "zx.ai.production.reference-receipt.v1",
    sourceId: z(r.sourceId, Jp),
    url: k(r.url, {
      max: 512,
      pattern: /^https:\/\//
    }),
    version: {
      mode: z(i.mode, ["commit", "tag", "rolling"]),
      value: k(i.value, { max: 128 })
    },
    exactPathsOrHeadings: n,
    accessedOn: k(r.accessedOn, {
      min: 10,
      max: 10,
      pattern: /^\d{4}-\d{2}-\d{2}$/
    }),
    summarySha256: k(r.summarySha256, {
      max: 71,
      pattern: Qp
    }),
    decision: z(r.decision, ["copy", "adapt", "reject"]),
    licenseNote: k(r.licenseNote, { max: 256 }),
    zxuiBoundaryDiff: s,
    fixtureIds: o,
    regressionBindings: a,
    freshnessDisposition: z(r.freshnessDisposition, [
      "fresh",
      "review-required",
      "rejected"
    ]),
    fingerprint: ge(
      "zx.ai.production.reference-receipt.v1",
      r
    )
  };
});
class vt extends Error {
  constructor(t, r) {
    super(r), this.code = t, this.name = "ZxAIContextError";
  }
}
const zt = (e) => {
  var n, s, o;
  const t = e.content ?? [];
  if (e.type === "text") {
    let a = e.text ?? "";
    for (const d of e.marks ?? [])
      d.type === "bold" ? a = `**${a}**` : d.type === "italic" ? a = `*${a}*` : d.type === "strike" ? a = `~~${a}~~` : d.type === "code" ? a = `\`${a}\`` : d.type === "link" && typeof ((n = d.attrs) == null ? void 0 : n.href) == "string" && (a = `[${a}](${d.attrs.href})`);
    return a;
  }
  if (e.type === "hardBreak") return `
`;
  const r = () => t.map(zt).join(""), i = () => t.map(zt).join(`

`);
  return e.type === "paragraph" ? r() : e.type === "heading" ? `${"#".repeat(Number((s = e.attrs) == null ? void 0 : s.level) || 1)} ${r()}` : e.type === "codeBlock" ? `\`\`\`${((o = e.attrs) == null ? void 0 : o.language) ?? ""}
${r()}
\`\`\`` : e.type === "blockquote" ? i().split(`
`).map((a) => `> ${a}`).join(`
`) : e.type === "bulletList" || e.type === "orderedList" ? t.map((a, d) => {
    var g;
    return `${e.type === "bulletList" ? "- " : `${Number(((g = e.attrs) == null ? void 0 : g.start) ?? 1) + d}. `}${zt(a).replace(
      /\n/g,
      `
  `
    )}`;
  }).join(`
`) : e.type === "table" ? t.map(zt).join(`
`) : e.type === "tableRow" ? `| ${t.map(zt).join(" | ")} |` : e.type === "horizontalRule" ? "---" : i();
}, eu = (e, t, r) => t || e.type === "paragraph" || e.type === "heading" ? zt(e) : r.serialize({ type: "doc", content: [e] }), tu = (e, t, r, i) => {
  let n = "ZXCONTEXTLEAF";
  const s = JSON.stringify(e);
  for (; s.includes(n); ) n += "X";
  const o = [], a = (u) => {
    if (u.type === "text" || u.type === "hardBreak") {
      const p = o.length;
      return o.push(u.type === "hardBreak" ? `
` : u.text ?? ""), { ...u, type: "text", text: `${n}${p}XZ` };
    }
    return {
      ...u,
      ...u.content ? { content: u.content.map(a) } : {}
    };
  }, d = [];
  let l = 0;
  return { text: eu(a(e), t, i).replace(
    new RegExp(`${n}(\\d+)XZ`, "g"),
    (u, p, f) => {
      const m = o[Number(p)], y = f + l;
      return m.length && d.push({
        start: y,
        end: y + m.length,
        span: r[Number(p)]
      }), l += m.length - u.length, m;
    }
  ), renderedSpans: d };
}, _g = async (e) => {
  var O;
  const t = e.descriptors ?? es, r = new Set(
    t.flatMap(
      (R) => Object.entries(R.ai.nodes).filter(
        ([, E]) => E.supported && E.addressability === "block"
      ).map(([E]) => E)
    )
  ), i = ja(
    e.document,
    r
  ), n = await Ca(
    t,
    e.policy
  ), s = Rn(
    { kind: "selection", anchor: e.target },
    e.document.body.content,
    i,
    n.admission,
    n.manifest
  ), o = (R) => {
    const E = i.get(R.blockId), D = E.textSegments.map((de) => de.node.text ?? `
`).join(""), K = R.offset;
    if (!Number.isInteger(K) || K > 0 && K < D.length && /[\uD800-\uDBFF]/.test(D[K - 1]) && /[\uDC00-\uDFFF]/.test(D[K]))
      throw new vt(
        "context-anchor-invalid",
        "The context anchor must be a valid UTF-16 boundary."
      );
    const te = E.textSegments.find(
      (de) => K >= de.startOffset && K <= de.endOffset
    );
    return te ? te.from + K - te.startOffset : E.pos + 1;
  }, a = o(e.target.start), d = o(e.target.end), l = Rn(
    { kind: "document" },
    e.document.body.content,
    i,
    n.admission,
    n.manifest
  ), g = {
    ...n.admission,
    deniedNodes: /* @__PURE__ */ new Set([
      ...n.admission.deniedNodes,
      ...n.manifest.unsupported.filter((R) => R.kind === "node").map((R) => R.type)
    ]),
    deniedMarks: /* @__PURE__ */ new Set([
      ...n.admission.deniedMarks,
      ...n.manifest.unsupported.filter((R) => R.kind === "mark").map((R) => R.type)
    ])
  }, u = qa(
    e.document.body.content,
    i,
    g,
    l,
    e.policy
  ), p = /* @__PURE__ */ new Map();
  i.forEach(
    (R) => R.textSegments.forEach(
      (E) => p.set(E.node, {
        span: {
          blockId: R.blockId,
          startOffset: E.startOffset,
          endOffset: E.endOffset
        },
        from: E.from,
        to: E.to
      })
    )
  );
  const f = /* @__PURE__ */ new Set(), m = (R, E) => {
    var te, de, V, me, Oe, lr;
    R.address && !("startOffset" in R.address) && f.add(R.address.blockId);
    const D = R.children.map((Ne) => {
      const Lr = Ne.address && !("startOffset" in Ne.address) ? i.get(Ne.address.blockId).node : E.content[Ne.relation.ordinal];
      return m(Ne, Lr);
    }), K = p.get(E);
    return {
      json: {
        type: R.type,
        attrs: { ...R.attrs },
        ...R.text !== void 0 ? { text: R.text } : {},
        ...R.marks.length ? {
          marks: R.marks.map((Ne) => ({
            type: Ne.type,
            attrs: { ...Ne.attrs }
          }))
        } : {},
        ...D.length ? { content: D.map((Ne) => Ne.json) } : {}
      },
      children: D,
      span: (K == null ? void 0 : K.span) ?? null,
      from: (K == null ? void 0 : K.from) ?? ((te = D[0]) == null ? void 0 : te.from) ?? ((V = i.get(((de = R.address) == null ? void 0 : de.blockId) ?? "")) == null ? void 0 : V.pos) ?? 0,
      to: (K == null ? void 0 : K.to) ?? ((me = D.at(-1)) == null ? void 0 : me.to) ?? ((lr = i.get(((Oe = R.address) == null ? void 0 : Oe.blockId) ?? "")) == null ? void 0 : lr.pos) ?? 0,
      originalText: E.text ?? (E.type === "hardBreak" ? `
` : null)
    };
  }, y = u.nodes[0] ? m(u.nodes[0], e.document.body.content) : null;
  if (!f.has(e.target.start.blockId) || !f.has(e.target.end.blockId))
    throw new vt(
      "context-anchor-invalid",
      "The context anchor is excluded by the snapshot policy."
    );
  const I = (R, E, D) => {
    if (R.to <= E || R.from >= D) return null;
    if (R.span) {
      const te = Math.max(0, E - R.from), de = Math.min(R.to - R.from, D - R.from), V = te > 0 || de < R.to - R.from;
      if (R.json.type === "text" && R.json.text !== R.originalText && V) {
        const Oe = s.selection.collapsed ? R.from : Math.max(R.from, a);
        return Oe < E || Oe >= D ? null : { json: R.json, spans: [R.span], partial: !0 };
      }
      return {
        json: R.json.type === "text" ? {
          ...R.json,
          text: R.json.text.slice(te, de)
        } : R.json,
        spans: [
          {
            blockId: R.span.blockId,
            startOffset: R.span.startOffset + te,
            endOffset: R.span.startOffset + de
          }
        ],
        partial: V
      };
    }
    const K = R.children.map((te) => I(te, E, D)).filter((te) => te !== null);
    return K.length ? {
      json: { ...R.json, content: K.map((te) => te.json) },
      spans: K.flatMap((te) => te.spans),
      partial: K.length !== R.children.length || K.some((te) => te.partial)
    } : null;
  }, h = {
    prefix: [Number.NEGATIVE_INFINITY, a],
    target: [a, d],
    suffix: [d, Number.POSITIVE_INFINITY]
  }, v = {
    "document-identity": [],
    outline: [],
    "elided-digest": [],
    prefix: [],
    suffix: [],
    target: []
  };
  for (const [R, E] of ((y == null ? void 0 : y.children) ?? []).entries())
    for (const [D, [K, te]] of Object.entries(h)) {
      const de = I(E, K, te);
      if (!de) continue;
      const V = E.from <= a && E.to >= a || E.from <= d && E.to >= d, me = tu(
        de.json,
        de.partial || V,
        de.spans,
        e.markdown
      );
      me.text && v[D].push({
        id: `${D}:${R}`,
        ...me,
        spans: de.spans
      });
    }
  const F = v.prefix.at(-1);
  F && e.target.start.offset === 0 && (v.prefix[v.prefix.length - 1] = {
    ...F,
    text: `${F.text}

`
  });
  const w = v.suffix[0];
  w && e.target.end.offset === i.get(e.target.end.blockId).textLength && (v.suffix[0] = {
    ...w,
    text: `

${w.text}`,
    renderedSpans: (O = w.renderedSpans) == null ? void 0 : O.map((R) => ({
      ...R,
      start: R.start + 2,
      end: R.end + 2
    }))
  });
  const x = [], j = (R) => {
    if (R.json.type === "heading") {
      const E = I(
        R,
        Number.NEGATIVE_INFINITY,
        Number.POSITIVE_INFINITY
      );
      E && x.push({
        source: {
          id: `heading:${x.length}`,
          text: zt(E.json),
          spans: E.spans
        },
        from: R.from
      });
    }
    R.children.forEach(j);
  };
  y && j(y);
  const _ = x.filter((R) => R.from <= a).at(-1);
  v.outline = x.map(({ source: R }) => ({
    ...R,
    text: `${R.text}${R.id === (_ == null ? void 0 : _.source.id) ? " [current section]" : ""}`
  })), x[0] && (v["document-identity"] = [x[0].source]);
  const G = new Set(
    [...v.prefix, ...v.target, ...v.suffix].flatMap(
      (R) => R.spans.map((E) => E.blockId)
    )
  ).size, ie = {
    kind: "zx-ai-context-sources-v1",
    sourceRevision: await Ta(e.document),
    targetFingerprint: e.targetFingerprint ?? re("zx-ai-context-target:v1", {
      start: e.target.start,
      end: e.target.end
    }),
    policyExcludedCount: [...n.diagnostics, ...u.diagnostics].filter(
      (R) => R.code === "scope-access-denied"
    ).length,
    sourceBlockCount: G,
    languageSample: [
      ...v.target,
      ...v.prefix.slice(-2),
      ...v.suffix.slice(0, 1)
    ].map((R) => R.text).join(`
`).slice(-2e3),
    sources: v
  };
  return c({
    ...ie,
    sourceFingerprint: re(
      "zx-ai-context-sources:v1",
      {
        ...ie,
        policy: e.policy ? { id: e.policy.id, version: e.policy.version } : null
      }
    )
  });
}, ta = (e) => {
  const t = /* @__PURE__ */ new Set();
  let r = 0;
  for (const i of e.rules) {
    if (t.has(i.source) || i.minShare < 0 || i.maxShare > 1 || i.minShare > i.maxShare || i.growWeight < 0 || ![
      i.minShare,
      i.maxShare,
      i.growWeight,
      i.priority,
      i.placement
    ].every(Number.isFinite) || i.completeness === "exact" && i.trim !== "forbidden")
      throw new vt(
        "context-policy-invalid",
        "Context segment rules must have unique roles and valid budget shares."
      );
    t.add(i.source), r += i.minShare;
  }
  if (!e.id || !e.version || r > 1 || !t.has(e.fallback.grow))
    throw new vt(
      "context-policy-invalid",
      "Context policy identity, floors or fallback is invalid."
    );
  return c({
    ...e,
    fingerprint: re("zx-ai-context-policy:v1", e)
  });
}, Xt = (e, t, r, i, n, s = 0) => ({
  source: e,
  priority: t,
  placement: r,
  minShare: i,
  maxShare: n,
  growWeight: s,
  trim: e === "prefix" ? "head" : "tail",
  required: !1,
  completeness: "partial",
  emptyBehavior: "omit"
}), Bi = (e, t, r = !1) => ta({
  id: e,
  version: "1",
  rules: [
    {
      ...Xt("target", 0, 3, 0, 1),
      completeness: "exact",
      trim: "forbidden"
    },
    Xt("document-identity", 5, 0, 0, 0.02),
    Xt("outline", r ? 3 : 1, 1, 0, t.outline),
    Xt("elided-digest", r ? 4 : 2, 2, 0, t.digest),
    Xt(
      "prefix",
      r ? 1 : 3,
      4,
      r ? 0.6 : 0,
      t.prefix,
      1
    ),
    Xt("suffix", r ? 2 : 4, 5, 0, t.suffix)
  ],
  fallback: { whenEmpty: "prefix", grow: "suffix" }
}), Lg = c({
  continuation: Bi(
    "near-caret-v1",
    { prefix: 0.6, outline: 0.1, digest: 0.15, suffix: 0.15 },
    !0
  ),
  outline: Bi("document-outline-v1", {
    prefix: 0.15,
    outline: 0.35,
    digest: 0.45,
    suffix: 0.05
  }),
  brainstorm: Bi("section-ideas-v1", {
    prefix: 0.2,
    outline: 0.2,
    digest: 0.5,
    suffix: 0.1
  })
}), ru = [
  "document-identity",
  "outline",
  "elided-digest",
  "prefix",
  "suffix",
  "target"
], Qe = (e) => e.map((t) => t.text).join(`

`), xr = (e) => new Set(e.flatMap((t) => t.spans.map((r) => r.blockId))).size, ra = (e, t, r) => e.renderedSpans ? e.renderedSpans.flatMap((i) => {
  const n = Math.max(t, i.start), s = Math.min(r, i.end);
  if (n >= s) return [];
  const o = i.span.endOffset - i.span.startOffset === i.end - i.start;
  return [
    {
      ...i.span,
      ...o ? {
        startOffset: i.span.startOffset + n - i.start,
        endOffset: i.span.startOffset + s - i.start
      } : {}
    }
  ];
}) : e.spans.length === 1 && e.spans[0].endOffset - e.spans[0].startOffset === e.text.length ? [
  {
    ...e.spans[0],
    startOffset: e.spans[0].startOffset + t,
    endOffset: e.spans[0].startOffset + r
  }
] : e.spans, iu = 64, nu = /* @__PURE__ */ new Set(["。", "！", "？", "；"]), su = /* @__PURE__ */ new Set([".", "!", "?"]), Mi = (e) => e !== void 0 && /\s/u.test(e), ia = (e, t) => nu.has(e[t - 1]) || su.has(e[t - 1]) && (t === e.length || Mi(e[t])), Ui = (e, t, r) => {
  if (t <= 0 || t >= e.length)
    return (r === "start" ? e.slice(0, t) : e.slice(t)).join("");
  const i = r === "start" ? -1 : 1, n = [];
  for (let o = t; o > 0 && o < e.length && Math.abs(o - t) <= iu; o += i)
    n.push(o);
  const s = n.find((o) => ia(e, o)) ?? n.find(
    (o) => Mi(e[o - 1]) || Mi(e[o])
  ) ?? t;
  return r === "start" ? e.slice(0, s).join("").trimEnd() : e.slice(s).join("").trimStart();
}, ou = (e, t, r, i) => {
  const n = Array.from(e);
  let s = 0, o = n.length;
  for (; s < o; ) {
    const a = Math.ceil((s + o) / 2), d = r === "head" ? n.slice(-a).join("") : n.slice(0, a).join("");
    i.count(d) <= t ? s = a : o = a - 1;
  }
  return s === 0 ? "" : r === "head" ? Ui(n, n.length - s, "end") : Ui(n, s, "start");
}, wr = (e, t, r, i) => {
  const n = [];
  for (const s of r === "head" ? [...e].reverse() : e) {
    const o = [...n, { ...s, complete: !0 }];
    if (i.count(Qe(o)) <= t) {
      n.push(o.at(-1));
      continue;
    }
    if (r === "forbidden")
      throw new vt(
        "context-budget-exceeded",
        "Required exact source exceeds the available context budget."
      );
    const a = t - i.count(Qe(n)) - (n.length ? i.count(`

`) : 0), d = ou(s.text, Math.max(0, a), r, i);
    if (d) {
      const l = r === "head" ? s.text.length - d.length : 0, g = ra(s, l, l + d.length);
      n.push({ ...s, text: d, spans: g, complete: !1 });
    }
    break;
  }
  return r === "head" ? n.reverse() : n;
}, Pi = (e, t) => {
  const r = new Map(t.map((i) => [i.id, i]));
  return e.flatMap((i) => {
    const n = r.get(i.id);
    if (n != null && n.complete) return [];
    const s = n ? i.id.startsWith("prefix:") ? i.text.slice(0, -n.text.length) : i.text.slice(n.text.length) : i.text, o = Array.from(s.trim()), a = o.findIndex((u, p) => ia(o, p + 1)) + 1, d = a > 0 && a <= 240 ? o.slice(0, a).join("") : Ui(o, 240, "start"), g = (!n || i.id.startsWith("prefix:") ? 0 : n.text.length) + s.indexOf(d);
    return d ? [
      {
        id: `digest:${i.id}`,
        text: d,
        spans: ra(i, g, g + d.length)
      }
    ] : [];
  });
}, Vg = (e) => {
  const { sources: t, budget: r, contextPolicy: i } = e, { fingerprint: n, ...s } = i;
  if (ta(s).fingerprint !== i.fingerprint)
    throw new vt(
      "context-policy-invalid",
      "Context policy fingerprint does not match its rules."
    );
  const o = e.tokenCounter ?? Qd, a = r.maxBytes ?? 64 * 1024;
  if (!Number.isInteger(r.bodyBudgetTokens) || r.bodyBudgetTokens < 0 || !Number.isInteger(a) || a <= 0)
    throw new vt(
      "context-budget-exceeded",
      "Context budget must use nonnegative token and positive byte limits."
    );
  const d = [...i.rules].sort(
    (f, m) => f.priority - m.priority || f.placement - m.placement
  );
  for (const f of d)
    if (f.required && f.emptyBehavior === "error" && t.sources[f.source].length === 0)
      throw new vt(
        "context-required-source-missing",
        "A required context source is empty."
      );
  const l = d.filter(
    (f) => f.completeness === "exact" && t.sources[f.source].length
  ), g = [
    ...t.sources.prefix,
    ...t.sources.target,
    ...t.sources.suffix
  ];
  let u = r.bodyBudgetTokens, p = !1;
  for (let f = 0; f < 12; f += 1) {
    const m = {
      "document-identity": [],
      outline: [],
      "elided-digest": [],
      prefix: [],
      suffix: [],
      target: []
    };
    let y = u;
    for (const O of l)
      m[O.source] = wr(
        t.sources[O.source],
        y,
        "forbidden",
        o
      ), y -= o.count(Qe(m[O.source]));
    if (o.count(Qe(g)) <= u)
      for (const O of ["prefix", "suffix", "target"])
        d.some((R) => R.source === O) && (m[O] = t.sources[O].map((R) => ({
          ...R,
          complete: !0
        })));
    else {
      const O = d.filter((V) => !l.includes(V)), R = y, E = /* @__PURE__ */ new Map();
      for (const V of O) {
        const me = Math.floor(R * V.maxShare);
        E.set(
          V.source,
          V.source === "document-identity" ? Math.min(60, me) : me
        );
        const Oe = Math.floor(R * V.minShare);
        Oe && V.source !== "elided-digest" && (m[V.source] = wr(
          t.sources[V.source],
          Oe,
          V.trim,
          o
        ), y -= o.count(Qe(m[V.source])));
      }
      for (const V of O) {
        const me = o.count(Qe(m[V.source])), Oe = Math.min(
          E.get(V.source),
          y + me
        );
        m[V.source] = wr(
          V.source === "elided-digest" ? Pi(g, [
            ...m.prefix,
            ...m.suffix,
            ...m.target
          ]) : t.sources[V.source],
          Oe,
          V.trim,
          o
        ), y -= o.count(Qe(m[V.source])) - me;
      }
      const D = O.find(
        (V) => V.source === "elided-digest"
      ), K = D ? o.count(Qe(m["elided-digest"])) : 0, te = t.sources[i.fallback.whenEmpty].length === 0 ? i.fallback.grow : null, de = O.filter((V) => V.growWeight > 0 || V.source === te).sort(
        (V, me) => V.source === te ? -1 : me.source === te ? 1 : me.growWeight - V.growWeight
      );
      for (const V of de) {
        const me = o.count(Qe(m[V.source]));
        m[V.source] = wr(
          t.sources[V.source],
          me + y,
          V.trim,
          o
        ), y -= o.count(Qe(m[V.source])) - me;
      }
      if (D) {
        const V = Pi(g, [
          ...m.prefix,
          ...m.suffix,
          ...m.target
        ]);
        m["elided-digest"] = wr(
          V,
          K,
          D.trim,
          o
        );
      }
    }
    const h = [...d].sort((O, R) => O.placement - R.placement).flatMap((O) => {
      const R = m[O.source];
      if (!R.length) return [];
      const E = Qe(R);
      return [
        {
          role: O.source,
          text: E,
          spans: R.flatMap((D) => D.spans),
          completeness: O.source === "elided-digest" ? "summary" : R.every((D) => D.complete) ? "exact" : "partial",
          estimatedTokens: o.count(E),
          bytes: ti(E)
        }
      ];
    }), v = h.reduce(
      (O, R) => O + R.estimatedTokens,
      0
    ), F = [
      ...m.prefix,
      ...m.suffix,
      ...m.target
    ], w = new Set(
      F.filter((O) => O.complete).map((O) => O.id)
    ), x = g.every(
      (O) => w.has(O.id)
    ), j = xr(F), _ = Object.fromEntries(
      ru.map((O) => {
        const R = m[O], E = O === "elided-digest" ? Pi(g, F) : t.sources[O], D = xr(
          R.filter((te) => te.complete)
        ), K = xr(
          R.filter((te) => !te.complete)
        );
        return [
          O,
          {
            included: D,
            partial: K,
            omitted: Math.max(
              0,
              xr(E) - xr(R)
            )
          }
        ];
      })
    ), G = {
      kind: "zx-ai-context-window-v1",
      version: 1,
      sourceRevision: t.sourceRevision,
      sourceFingerprint: t.sourceFingerprint,
      targetFingerprint: t.targetFingerprint,
      policyRef: {
        id: i.id,
        version: i.version,
        fingerprint: i.fingerprint
      },
      segments: h,
      receipt: {
        sourceFingerprint: t.sourceFingerprint,
        policyFingerprint: i.fingerprint,
        estimateMethod: `${o.id}@${o.version}`,
        inputBudgetTokens: r.inputBudgetTokens ?? r.bodyBudgetTokens,
        bodyBudgetTokens: r.bodyBudgetTokens,
        estimatedTokens: v,
        serializedBytes: 0,
        coverage: x ? "full-source" : m["elided-digest"].length ? "summarized" : "partial",
        documentCovered: x,
        sourceBlockCount: t.sourceBlockCount,
        includedBlockCount: j,
        omittedBlockCount: Math.max(
          0,
          t.sourceBlockCount - j
        ),
        policyExcludedCount: t.policyExcludedCount,
        limitingConstraint: p ? "bytes" : x ? "none" : "tokens",
        roles: _
      }
    };
    for (let O = 0; O < 4; O += 1)
      G.receipt.serializedBytes = ti(
        ke({
          ...G,
          fingerprint: `sha256:${"0".repeat(64)}`
        })
      );
    if (G.receipt.serializedBytes <= a && v <= r.bodyBudgetTokens)
      return c({
        ...G,
        fingerprint: re(
          "zx-ai-context-window:v1",
          G
        )
      });
    p = G.receipt.serializedBytes > a;
    const ie = Math.max(
      0,
      Math.floor(
        u * Math.min(0.75, a / G.receipt.serializedBytes * 0.9)
      )
    );
    if (ie === u) break;
    u = ie;
  }
  throw new vt(
    "context-budget-exceeded",
    "The context artifact cannot fit the configured token and byte limits."
  );
};
export {
  yu as $,
  mu as A,
  nt as B,
  Bu as C,
  Eu as D,
  en as E,
  Ku as F,
  Cu as G,
  qu as H,
  Vu as I,
  Pu as J,
  Nu as K,
  _u as L,
  ln as M,
  Uu as N,
  zr as O,
  Pt as P,
  Ms as Q,
  Lu as R,
  ed as S,
  Ni as T,
  Mu as U,
  Gu as V,
  Tu as W,
  Wu as X,
  wd as Y,
  _l as Z,
  Iu as _,
  Ig as a,
  Ha as a$,
  hu as a0,
  bf as a1,
  Ff as a2,
  xf as a3,
  wf as a4,
  dg as a5,
  lg as a6,
  pg as a7,
  ug as a8,
  fg as a9,
  df as aA,
  Zd as aB,
  cf as aC,
  $t as aD,
  lf as aE,
  pf as aF,
  yf as aG,
  uf as aH,
  gf as aI,
  ff as aJ,
  tl as aK,
  vf as aL,
  hf as aM,
  mf as aN,
  If as aO,
  tf as aP,
  Hd as aQ,
  ef as aR,
  Ld as aS,
  Qs as aT,
  _d as aU,
  rf as aV,
  Dd as aW,
  Fu as aX,
  hs as aY,
  La as aZ,
  xu as a_,
  zl as aa,
  gg as ab,
  mg as ac,
  xo as ad,
  vg as ae,
  kd as af,
  Sd as ag,
  Ad as ah,
  Ed as ai,
  hg as aj,
  yg as ak,
  bu as al,
  Su as am,
  Zu as an,
  pi as ao,
  Xu as ap,
  jr as aq,
  Yu as ar,
  Ju as as,
  Qu as at,
  sf as au,
  nf as av,
  Nd as aw,
  of as ax,
  af as ay,
  Yd as az,
  vu as b,
  Jf as b$,
  wu as b0,
  Ru as b1,
  ku as b2,
  Rf as b3,
  kf as b4,
  We as b5,
  De as b6,
  io as b7,
  pn as b8,
  Dr as b9,
  kl as bA,
  Sl as bB,
  ce as bC,
  Io as bD,
  ft as bE,
  ul as bF,
  Ef as bG,
  so as bH,
  Cf as bI,
  Af as bJ,
  un as bK,
  Lf as bL,
  Vf as bM,
  Hf as bN,
  Cl as bO,
  Ln as bP,
  _n as bQ,
  ql as bR,
  Yf as bS,
  Uf as bT,
  Wf as bU,
  Mf as bV,
  Kf as bW,
  Gf as bX,
  Xf as bY,
  Zf as bZ,
  Vn as b_,
  ui as ba,
  dr as bb,
  fi as bc,
  _r as bd,
  dl as be,
  ml as bf,
  ao as bg,
  qf as bh,
  co as bi,
  lo as bj,
  On as bk,
  Sf as bl,
  ki as bm,
  It as bn,
  Pf as bo,
  Tf as bp,
  Bf as bq,
  fn as br,
  ri as bs,
  Nf as bt,
  bl as bu,
  jf as bv,
  $f as bw,
  uo as bx,
  fo as by,
  _f as bz,
  gu as c,
  Jd as c$,
  eg as c0,
  tg as c1,
  Pl as c2,
  $l as c3,
  Qf as c4,
  jl as c5,
  ig as c6,
  rg as c7,
  ho as c8,
  go as c9,
  Cg as cA,
  Ag as cB,
  Sg as cC,
  _o as cD,
  Eg as cE,
  qg as cF,
  Bp as cG,
  Tg as cH,
  Lp as cI,
  _p as cJ,
  Ho as cK,
  Pg as cL,
  $g as cM,
  Bg as cN,
  Hp as cO,
  Kp as cP,
  jg as cQ,
  Dg as cR,
  zg as cS,
  Og as cT,
  Ng as cU,
  Jp as cV,
  _g as cW,
  ta as cX,
  Lg as cY,
  Vg as cZ,
  el as c_,
  mo as ca,
  vo as cb,
  zf as cc,
  yo as cd,
  Df as ce,
  Of as cf,
  sg as cg,
  ng as ch,
  og as ci,
  ag as cj,
  cg as ck,
  bg as cl,
  Ml as cm,
  Fg as cn,
  _e as co,
  Eo as cp,
  Gn as cq,
  xg as cr,
  pp as cs,
  wg as ct,
  kg as cu,
  Rg as cv,
  Yn as cw,
  Bo as cx,
  hn as cy,
  Ap as cz,
  fu as d,
  Qd as d0,
  vt as d1,
  $ as d2,
  zu as e,
  Ou as f,
  od as g,
  Id as h,
  gd as i,
  md as j,
  dd as k,
  Du as l,
  cd as m,
  pd as n,
  $u as o,
  ad as p,
  qn as q,
  Fd as r,
  ju as s,
  xd as t,
  Au as u,
  dn as v,
  N as w,
  qe as x,
  qr as y,
  Hu as z
};
//# sourceMappingURL=context-window-D6584tTc.mjs.map
