import * as u from "yjs";
import { c as h } from "./promise-CnVnurMX.mjs";
import { c as g, O as I } from "./error-Di1d9d9R.mjs";
const a = (t) => h((e, o) => {
  t.onerror = (s) => o(new Error(s.target.error)), t.onsuccess = (s) => e(s.target.result);
}), T = (t, e) => h((o, s) => {
  const r = indexedDB.open(t);
  r.onupgradeneeded = (n) => e(n.target.result), r.onerror = (n) => s(g(n.target.error)), r.onsuccess = (n) => {
    const c = n.target.result;
    c.onversionchange = () => {
      c.close();
    }, o(c);
  };
}), p = (t) => a(indexedDB.deleteDatabase(t)), B = (t, e) => e.forEach(
  (o) => (
    // @ts-ignore
    t.createObjectStore.apply(t, o)
  )
), d = (t, e, o = "readwrite") => {
  const s = t.transaction(e, o);
  return e.map((r) => w(s, r));
}, y = (t, e) => a(t.count(e)), D = (t, e) => a(t.get(e)), f = (t, e) => a(t.delete(e)), U = (t, e, o) => a(t.put(e, o)), l = (t, e) => a(t.add(e)), S = (t, e, o) => a(t.getAll(e, o)), A = (t, e, o) => {
  let s = null;
  return E(t, e, (r) => (s = r, !1), o).then(() => s);
}, R = (t, e = null) => A(t, e, "prev"), K = (t, e) => h((o, s) => {
  t.onerror = s, t.onsuccess = async (r) => {
    const n = r.target.result;
    if (n === null || await e(n) === !1)
      return o();
    n.continue();
  };
}), E = (t, e, o, s = "next") => K(t.openKeyCursor(e, s), (r) => o(r.key)), w = (t, e) => t.objectStore(e), x = (t, e) => IDBKeyRange.upperBound(t, e), k = (t, e) => IDBKeyRange.lowerBound(t, e), i = "custom", _ = "updates", m = 500, b = (t, e = () => {
}, o = () => {
}) => {
  const [s] = d(
    /** @type {IDBDatabase} */
    t.db,
    [_]
  );
  return S(s, k(t._dbref, !1)).then((r) => {
    t._destroyed || (e(s), u.transact(t.doc, () => {
      r.forEach((n) => u.applyUpdate(t.doc, n));
    }, t, !1), o(s));
  }).then(() => R(s).then((r) => {
    t._dbref = r + 1;
  })).then(() => y(s).then((r) => {
    t._dbsize = r;
  })).then(() => s);
}, z = (t, e = !0) => b(t).then((o) => {
  (e || t._dbsize >= m) && l(o, u.encodeStateAsUpdate(t.doc)).then(() => f(o, x(t._dbref, !0))).then(() => y(o).then((s) => {
    t._dbsize = s;
  }));
}), v = (t) => p(t);
class j extends I {
  /**
   * @param {string} name
   * @param {Y.Doc} doc
   */
  constructor(e, o) {
    super(), this.doc = o, this.name = e, this._dbref = 0, this._dbsize = 0, this._destroyed = !1, this.db = null, this.synced = !1, this._db = T(
      e,
      (s) => B(s, [
        ["updates", { autoIncrement: !0 }],
        ["custom"]
      ])
    ), this.whenSynced = h((s) => this.on("synced", () => s(this))), this._db.then((s) => {
      this.db = s, b(this, (c) => l(c, u.encodeStateAsUpdate(o)), () => {
        if (this._destroyed) return this;
        this.synced = !0, this.emit("synced", [this]);
      });
    }), this._storeTimeout = 1e3, this._storeTimeoutId = null, this._storeUpdate = (s, r) => {
      if (this.db && r !== this) {
        const [n] = d(
          /** @type {IDBDatabase} */
          this.db,
          [_]
        );
        l(n, s), ++this._dbsize >= m && (this._storeTimeoutId !== null && clearTimeout(this._storeTimeoutId), this._storeTimeoutId = setTimeout(() => {
          z(this, !1), this._storeTimeoutId = null;
        }, this._storeTimeout));
      }
    }, o.on("update", this._storeUpdate), this.destroy = this.destroy.bind(this), o.on("destroy", this.destroy);
  }
  destroy() {
    return this._storeTimeoutId && clearTimeout(this._storeTimeoutId), this.doc.off("update", this._storeUpdate), this.doc.off("destroy", this.destroy), this._destroyed = !0, this._db.then((e) => {
      e.close();
    });
  }
  /**
   * Destroys this instance and removes all data from indexeddb.
   *
   * @return {Promise<void>}
   */
  clearData() {
    return this.destroy().then(() => {
      p(this.name);
    });
  }
  /**
   * @param {String | number | ArrayBuffer | Date} key
   * @return {Promise<String | number | ArrayBuffer | Date | any>}
   */
  get(e) {
    return this._db.then((o) => {
      const [s] = d(o, [i], "readonly");
      return D(s, e);
    });
  }
  /**
   * @param {String | number | ArrayBuffer | Date} key
   * @param {String | number | ArrayBuffer | Date} value
   * @return {Promise<String | number | ArrayBuffer | Date>}
   */
  set(e, o) {
    return this._db.then((s) => {
      const [r] = d(s, [i]);
      return U(r, o, e);
    });
  }
  /**
   * @param {String | number | ArrayBuffer | Date} key
   * @return {Promise<undefined>}
   */
  del(e) {
    return this._db.then((o) => {
      const [s] = d(o, [i]);
      return f(s, e);
    });
  }
}
export {
  j as IndexeddbPersistence,
  m as PREFERRED_TRIM_SIZE,
  v as clearDocument,
  b as fetchUpdates,
  z as storeState
};
//# sourceMappingURL=y-indexeddb-CNWWqppD.mjs.map
