"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const e=require("./use-text-editor-command-keybindings-D-1N5QCM.js");exports.default=e._sfc_main$6;
//# sourceMappingURL=insert-video-B3WwQ6AY.js.map
