import { e as u, A as b, B as X, C as V, D as T, v as J, E as F, j as Z, i as H, z as D } from "./actions-Sd62WBGv.mjs";
import { formatShortcut as q, stringifyShortcut as U } from "@zxio/keybindings/core";
const x = ["html", "react", "text"], _ = () => ({
  html: "supported",
  react: "supported",
  text: "supported"
}), G = [
  "paragraph",
  "toggleSummary",
  "toggleContent",
  "blockquote",
  "bulletList",
  "doc",
  "hardBreak",
  "horizontalRule",
  "listItem",
  "orderedList",
  "text",
  "heading",
  "table",
  "taskList",
  "taskItem",
  "tableRow",
  "tableHeader",
  "tableCell",
  "pageBreak",
  "codeBlock",
  "attachment",
  "embed",
  "iframe",
  "image",
  "imageGroup",
  "mention",
  "tagItem",
  "toggle",
  "video"
], Y = [
  "link",
  "textStyle",
  "bold",
  "italic",
  "strike",
  "underline",
  "code",
  "comment",
  "namedHighlight"
], w = {
  renderAuthorityId: "zx.text-editor.render-registry-authority",
  renderAuthorityVersion: "1.0.0",
  targets: x,
  entries: [
    ...G.map(
      (e) => ({
        joinKey: `node:${e}`,
        targets: _(),
        passThroughTarget: null
      })
    ),
    ...Y.map(
      (e) => ({
        joinKey: `mark:${e}`,
        targets: _(),
        passThroughTarget: null
      })
    ),
    {
      joinKey: "mark:namedColor",
      targets: {
        html: "pass-through",
        react: "pass-through",
        text: "pass-through"
      },
      passThroughTarget: "mark:textStyle"
    }
  ],
  unknownEntryPolicy: "unsupported"
}, E = u({
  ...w,
  renderAuthorityFingerprint: b(w)
}), Q = u({
  id: E.renderAuthorityId,
  version: E.renderAuthorityVersion,
  fingerprint: E.renderAuthorityFingerprint
}), I = u({
  id: T.schemaKernelId,
  version: T.schemaKernelVersion,
  fingerprint: T.schemaKernelFingerprint
}), v = {
  id: "zx.text-editor.ai-capability-authority",
  version: "1.0.0",
  capabilities: V
}, W = u({
  id: v.id,
  version: v.version,
  fingerprint: b(v)
}), N = u({
  aiCapability: W,
  renderRegistry: Q
}), O = (e) => b(e), ee = ["supported", "pass-through", "unsupported"], te = (e) => {
  const o = x.map((t) => e[t]);
  return o.every((t) => t === "supported") ? "supported" : o.some((t) => t === "unsupported") ? "unsupported" : "pass-through";
}, re = (e = V, o = E.entries) => {
  const t = [], n = [
    ...T.nodes,
    ...T.marks
  ], a = new Map(
    n.map((r) => [r.joinKey, r])
  ), c = /* @__PURE__ */ new Map();
  Object.entries(e).forEach(([r, i]) => {
    ["nodes", "marks"].forEach((p) => {
      Object.entries(i[p]).forEach(([K, f]) => {
        const j = `${p === "nodes" ? "node" : "mark"}:${K}`;
        if (c.has(j) || f.supported !== !0 && f.supported !== !1) {
          t.push({
            code: "authority-join-contradictory",
            path: `$.authorityProjection.aiCapability.${r}.${p}.${K}`,
            joinKey: j
          });
          return;
        }
        c.set(j, {
          support: f.supported ? "supported" : "unsupported",
          passThroughTarget: j === "mark:namedColor" && f.supported ? "mark:textStyle" : null
        });
      });
    });
  }), c.forEach((r, i) => {
    !a.has(i) && i !== "mark:namedColor" && t.push({
      code: "authority-join-unknown",
      path: "$.authorityProjection.aiCapability",
      joinKey: i
    });
  });
  const h = /* @__PURE__ */ new Map();
  o.forEach((r, i) => {
    if (h.has(r.joinKey) || !x.every(
      (p) => ee.includes(r.targets[p])
    )) {
      t.push({
        code: "authority-join-contradictory",
        path: `$.authorityProjection.renderRegistry.entries[${i}]`,
        joinKey: r.joinKey
      });
      return;
    }
    h.set(r.joinKey, r), !a.has(r.joinKey) && r.joinKey !== "mark:namedColor" && t.push({
      code: "authority-join-unknown",
      path: `$.authorityProjection.renderRegistry.entries[${i}]`,
      joinKey: r.joinKey
    });
  });
  const m = n.flatMap(
    (r) => {
      const i = h.get(r.joinKey);
      if (!i)
        return t.push({
          code: "authority-join-contradictory",
          path: "$.authorityProjection.renderRegistry.entries",
          joinKey: r.joinKey
        }), [];
      const p = c.get(r.joinKey);
      return p || t.push({
        code: "authority-join-contradictory",
        path: "$.authorityProjection.aiCapability",
        joinKey: r.joinKey
      }), [
        {
          joinKey: r.joinKey,
          kernelKey: r.key,
          kernelVersion: T.schemaKernelVersion,
          structuralProjectionFingerprint: O(r),
          structuralSupport: "supported",
          aiSupport: (p == null ? void 0 : p.support) ?? "unsupported",
          renderSupport: te(i.targets),
          renderSupportByTarget: i.targets,
          passThroughTarget: i.passThroughTarget
        }
      ];
    }
  ), g = c.get("mark:namedColor"), d = h.get("mark:namedColor"), s = a.get("mark:textStyle");
  return !g || g.support !== "supported" || g.passThroughTarget !== "mark:textStyle" || !d || d.passThroughTarget !== "mark:textStyle" || !x.every(
    (r) => d.targets[r] === "pass-through"
  ) || !s ? t.push({
    code: "authority-join-contradictory",
    path: "$.authorityProjection.mark:namedColor",
    joinKey: "mark:namedColor"
  }) : m.push({
    joinKey: "mark:namedColor",
    kernelKey: "textStyle",
    kernelVersion: T.schemaKernelVersion,
    structuralProjectionFingerprint: O(s),
    structuralSupport: "supported",
    aiSupport: "pass-through",
    renderSupport: "pass-through",
    renderSupportByTarget: d.targets,
    passThroughTarget: "mark:textStyle"
  }), u({
    valid: t.length === 0,
    entries: m,
    diagnostics: t
  });
}, z = re();
if (!z.valid)
  throw new TypeError("Schema authority join projection is invalid.");
const L = z.entries, oe = {
  editor: ["command", "input-rule", "keymap", "node-view", "paste-drop", "ui"],
  render: ["renderer"],
  ai: []
}, $ = (e) => {
  const o = {
    adapterId: `zx.text-editor.schema-adapter.${e}`,
    adapterVersion: "1.0.0",
    surface: e,
    schemaKernel: I,
    authorityProjection: N,
    entries: L,
    nonStructuralBehaviors: oe[e]
  };
  return u({
    ...o,
    adapterFingerprint: b(o)
  });
}, A = u({
  editor: $("editor"),
  render: $("render"),
  ai: $("ai")
}), k = (e) => !!e && typeof e == "object" && !Array.isArray(e), S = (e, o) => o.every((t) => Object.hasOwn(e, t)) && Object.keys(e).every((t) => o.includes(t)), ie = (e) => k(e) && S(e, ["html", "react", "text"]) && ["html", "react", "text"].every(
  (o) => ["supported", "pass-through", "unsupported"].includes(String(e[o]))
), ne = (e, o) => !k(e) || !S(e, [
  "adapterId",
  "adapterVersion",
  "adapterFingerprint",
  "surface",
  "schemaKernel",
  "authorityProjection",
  "entries",
  "nonStructuralBehaviors"
]) || e.surface !== o || typeof e.adapterId != "string" || typeof e.adapterVersion != "string" || typeof e.adapterFingerprint != "string" || !k(e.schemaKernel) || !S(e.schemaKernel, ["id", "version", "fingerprint"]) || typeof e.schemaKernel.id != "string" || typeof e.schemaKernel.version != "string" || typeof e.schemaKernel.fingerprint != "string" || !k(e.authorityProjection) || !S(e.authorityProjection, [
  "aiCapability",
  "renderRegistry"
]) || ![
  e.authorityProjection.aiCapability,
  e.authorityProjection.renderRegistry
].every(
  (t) => k(t) && S(t, ["id", "version", "fingerprint"]) && ["id", "version", "fingerprint"].every(
    (n) => typeof t[n] == "string"
  )
) || !Array.isArray(e.entries) || !Array.isArray(e.nonStructuralBehaviors) || e.nonStructuralBehaviors.some((t) => typeof t != "string") ? !1 : e.entries.every(
  (t) => k(t) && S(t, [
    "joinKey",
    "kernelKey",
    "kernelVersion",
    "structuralProjectionFingerprint",
    "structuralSupport",
    "aiSupport",
    "renderSupport",
    "renderSupportByTarget",
    "passThroughTarget"
  ]) && [
    "joinKey",
    "kernelKey",
    "kernelVersion",
    "structuralProjectionFingerprint"
  ].every((n) => typeof t[n] == "string") && t.structuralSupport === "supported" && ["supported", "pass-through", "unsupported"].includes(
    String(t.aiSupport)
  ) && ["supported", "pass-through", "unsupported"].includes(
    String(t.renderSupport)
  ) && ie(t.renderSupportByTarget) && (t.passThroughTarget === null || typeof t.passThroughTarget == "string")
), ue = () => A, he = (e = A) => {
  try {
    X(e);
  } catch {
    return u({
      valid: !1,
      diagnostics: [{ code: "adapter-shape-invalid", path: "$" }]
    });
  }
  if (!k(e))
    return u({
      valid: !1,
      diagnostics: [{ code: "adapter-shape-invalid", path: "$" }]
    });
  const o = e;
  if (!S(o, ["editor", "render", "ai"]) || !["editor", "render", "ai"].every(
    (a) => ne(o[a], a)
  ))
    return u({
      valid: !1,
      diagnostics: [{ code: "adapter-shape-invalid", path: "$" }]
    });
  const t = [], n = new Map(
    L.map((a) => [a.joinKey, a])
  );
  return ["editor", "render", "ai"].forEach((a) => {
    const c = e[a], h = A[a], m = /* @__PURE__ */ new Set(), { adapterFingerprint: g, ...d } = c;
    (c.adapterId !== h.adapterId || c.adapterVersion !== h.adapterVersion || c.surface !== h.surface || g !== b(d) || g !== h.adapterFingerprint) && t.push({
      code: "adapter-descriptor-mismatch",
      path: `$.${a}`
    }), (c.schemaKernel.version !== I.version || c.schemaKernel.fingerprint !== I.fingerprint) && t.push({
      code: "adapter-kernel-version-mismatch",
      path: `$.${a}.schemaKernel`
    }), JSON.stringify(c.authorityProjection) !== JSON.stringify(N) && t.push({
      code: "authority-join-contradictory",
      path: `$.${a}.authorityProjection`
    }), c.entries.forEach((s, r) => {
      if (m.has(s.joinKey)) {
        t.push({
          code: "adapter-entry-duplicate",
          path: `$.${a}.entries[${r}]`,
          joinKey: s.joinKey
        });
        return;
      }
      m.add(s.joinKey);
      const i = n.get(s.joinKey);
      i ? s.kernelVersion !== i.kernelVersion || s.structuralProjectionFingerprint !== i.structuralProjectionFingerprint ? t.push({
        code: "adapter-structural-projection-mismatch",
        path: `$.${a}.entries[${r}]`,
        joinKey: s.joinKey
      }) : (s.aiSupport !== i.aiSupport || s.renderSupport !== i.renderSupport || JSON.stringify(s.renderSupportByTarget) !== JSON.stringify(i.renderSupportByTarget) || s.passThroughTarget !== i.passThroughTarget) && t.push({
        code: "authority-join-contradictory",
        path: `$.${a}.entries[${r}]`,
        joinKey: s.joinKey
      }) : t.push({
        code: "adapter-entry-unknown",
        path: `$.${a}.entries[${r}]`,
        joinKey: s.joinKey
      });
    }), n.forEach((s, r) => {
      m.has(r) || t.push({
        code: "adapter-entry-missing",
        path: `$.${a}.entries`,
        joinKey: r
      });
    });
  }), t.length === 0 ? u({ valid: !0, diagnostics: [] }) : u({ valid: !1, diagnostics: t });
}, ae = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : 0, C = (e) => typeof e.text == "string" ? e.text.length : e.type === "hardBreak" ? 1 : e.content ? e.content.reduce(
  (o, t) => o + C(t),
  2
) : 1, M = (e, o, t) => {
  const n = t === "require-addressable", a = [], c = [], h = /* @__PURE__ */ new Set();
  let m = 0;
  const g = (d, s, r) => {
    var P, B, R;
    const i = d.type ?? "unknown";
    let p = null;
    if (o.has(i)) {
      const l = (P = d.attrs) == null ? void 0 : P[Z], y = typeof l == "string" ? l : null;
      y ? H(y) ? h.has(y) ? n && a.push({
        code: "duplicate-block-id",
        severity: "error",
        message: `Addressable node "${i}" has a duplicate blockId.`,
        type: i,
        kind: "node",
        blockId: y
      }) : (h.add(y), p = {
        blockId: y,
        nodeType: i,
        node: d,
        order: m++,
        pos: s,
        nodeSize: C(d),
        textLength: 0,
        textSegments: [],
        parentBlockId: ((B = r.at(-1)) == null ? void 0 : B.blockId) ?? null
      }, c.push(p)) : n && a.push({
        code: "invalid-block-id",
        severity: "error",
        message: `Addressable node "${i}" has an invalid blockId.`,
        type: i,
        kind: "node",
        blockId: y
      }) : n && a.push({
        code: "missing-block-id",
        severity: "error",
        message: `Addressable node "${i}" is missing blockId.`,
        type: i,
        kind: "node",
        blockId: null
      });
    }
    const K = p ? [...r, p] : r, f = ae(d);
    f > 0 && K.forEach((l) => {
      const y = l.textLength;
      l.textLength += f, l.textSegments.push({
        node: d,
        from: s,
        to: s + f,
        startOffset: y,
        endOffset: l.textLength
      });
    });
    let j = d.type === "doc" ? s : s + 1;
    (R = d.content) == null || R.forEach((l) => {
      g(l, j, K), j += C(l);
    });
  };
  return g(e, 0, []), a.length > 0 && F(a), new Map(c.map((d) => [d.blockId, d]));
}, se = (e, o) => M(
  e,
  o,
  "require-addressable"
), le = (e, o) => M(
  e,
  o,
  "index-present"
), ge = (e, o) => {
  const t = J(e);
  return t.valid || F(
    t.issues.map((n) => ({
      code: n.code === "missing-block-id" || n.code === "invalid-block-id" || n.code === "duplicate-block-id" ? n.code : n.code === "document-schema-invalid" ? "unknown-document-node" : n.code === "document-version-mismatch" ? "document-version-unsupported" : "document-format-invalid",
      severity: "error",
      message: n.code === "document-version-mismatch" ? "AI semantic snapshots require document version 2." : n.code === "document-schema-invalid" ? "Canonical document v2 contains an unknown schema node or mark." : n.code === "missing-block-id" || n.code === "invalid-block-id" || n.code === "duplicate-block-id" ? `Canonical document v2 contains ${n.code}.` : "Canonical document v2 verification failed.",
      blockId: n.blockId
    }))
  ), se(
    e.body.content,
    o
  );
};
function de(e) {
  return D.bindings.find((o) => o.id === e);
}
function ye() {
  return Object.freeze({
    schemaVersion: 1,
    packageName: "@zxio/text-editor",
    shortcuts: Object.freeze(
      D.bindings.map(
        (e) => Object.freeze({
          id: e.id,
          titleKey: `${e.id}.title`,
          categoryKey: "textEditor.shortcuts",
          fallbackTitle: e.action.label,
          fallbackCategory: e.action.category ?? "Text editor",
          defaultShortcut: e.defaults.map((o) => U(o)).join(" | "),
          executionSurface: e.delivery === "editor" ? "editor-transaction" : e.scope === "textEditor.editor" ? "editor-command" : "product-shell",
          eventDomain: e.scope === "textEditor.editor" ? "editor-dom" : "authoring-host",
          activationPolicyId: e.scope ?? "textEditor",
          remappable: e.configurable !== !1,
          discoverable: e.id !== "textEditor.inlineAi.escape"
        })
      )
    )
  });
}
function me(e, o) {
  const t = de(e);
  if (!t || !t.defaults[0])
    throw new Error(`No default shortcut: ${e}`);
  return q(t.defaults[0], { platform: o });
}
export {
  x as Z,
  de as a,
  ye as b,
  E as c,
  le as d,
  ge as e,
  me as f,
  ue as g,
  se as h,
  he as v
};
//# sourceMappingURL=projection-r_4Na96h.mjs.map
