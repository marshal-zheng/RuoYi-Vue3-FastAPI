# @zxio/theme-industrial-blue

Factory Blue is an industrial cobalt Theme v4 package. It expresses tinted
depth, multi-layer inset glow, and colored panel elevation exclusively through
the public elevation and material contract.

Run `pnpm -C packages/theme-industrial-blue build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
