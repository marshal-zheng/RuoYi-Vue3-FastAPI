import { markRaw } from 'vue'
import {
  createZxuiBindings,
  createZxuiDefinitionPolicy,
  parseDefinition,
} from '@zxio/schema-form/formily'
import MeasurementRows from './MeasurementRows.vue'
import AttachmentField from './AttachmentField.vue'
import { decode, toDto } from './model'

import type { Bindings, Values } from '@zxio/schema-form'
import type {
  BusinessContext,
  NativeSchema,
  SettledCheck,
  Validate,
} from '@zxio/schema-form/formily'
import type { Services } from './services'

export const definitionText = JSON.stringify(
  {
    id: 'equipment-inspection',
    revision: 2,
    engine: 'formily@2.3.7',
    contract: 'zxui-schema-form-v2',
    schema: {
      type: 'object',
      properties: {
        title: {
          type: 'string',
          title: '记录名称',
          'x-component': 'ZxInput',
          'x-decorator': 'ZxField',
          'x-component-props': {
            placeholder: '输入巡检记录名称',
            'aria-label': '记录名称',
          },
          'x-validator': [
            {
              required: true,
              message: '请输入记录名称',
              triggerType: 'onBlur',
            },
          ],
        },
        equipmentId: {
          type: 'number',
          title: '巡检设备',
          'x-component': 'ZxSelect',
          'x-decorator': 'ZxField',
          'x-component-props': {
            clearable: true,
            filterable: true,
            remote: true,
            valueOnClear: null,
            'aria-label': '巡检设备',
          },
          'x-validator': [
            {
              required: true,
              valueType: 'number',
              message: '请选择设备',
              triggerType: 'onInput',
            },
          ],
        },
        result: {
          type: 'string',
          title: '巡检结果',
          'x-component': 'ZxSelect',
          'x-decorator': 'ZxField',
          'x-component-props': {
            'aria-label': '巡检结果',
            options: [
              {
                value: 'normal',
                label: '正常',
              },
              {
                value: 'abnormal',
                label: '异常',
              },
            ],
          },
        },
        explanation: {
          type: 'string',
          title: '异常说明（结果异常时必填）',
          'x-component': 'ZxInput',
          'x-decorator': 'ZxField',
          'x-component-props': {
            type: 'textarea',
            rows: 2,
            'aria-label': '异常说明',
          },
        },
        tags: {
          type: 'array',
          title: '标签',
          'x-component': 'ZxTagsInput',
          'x-decorator': 'ZxField',
          'x-component-props': {
            placeholder: '输入标签后按回车',
            maxCount: 5,
          },
        },
        measurements: {
          type: 'array',
          title: '检查项目',
          'x-component': 'InspectionMeasurements',
          'x-decorator': 'ZxField',
        },
        attachments: {
          type: 'array',
          title: '巡检附件',
          'x-component': 'InspectionAttachments',
          'x-decorator': 'ZxField',
        },
      },
    },
  },
  null,
  2
)

export function createInspection(services: Services, recordId: string) {
  const bindings: Bindings = {
    ...createZxuiBindings(),
    InspectionMeasurements: {
      component: markRaw(MeasurementRows),
      composite: true,
      validationOwnership: 'managed',
      editObservation: 'raw-sequence',
    },
    InspectionAttachments: {
      component: markRaw(AttachmentField),
      composite: true,
      validationOwnership: 'managed',
      editObservation: 'raw-sequence',
    },
  }
  const explanationState = (abnormal: boolean) => ({
    validator: [{ required: abnormal, message: '异常结果必须填写说明' }],
    validationActive: abnormal,
  })
  function createSchema(context: BusinessContext): NativeSchema {
    const schema = parseDefinition(definitionText, inspectionPolicy).schema
    const properties = schema.properties!
    properties.equipmentId['x-reactions'] = (field) => {
      let requestedKeyword: string | undefined
      const props = {
        ...properties.equipmentId['x-component-props'],
        onSearch: search,
        onRetry: retry,
      }
      const loading = () =>
        context.configure(field, {
          componentProps: { ...props, loading: true, error: null },
        })
      function retry() {
        loading()
        context.retryLatest('equipment-options', field)
      }
      function search(keyword = '') {
        if (requestedKeyword === keyword) return
        requestedKeyword = keyword
        loading()
        context.runLatest(
          'equipment-options',
          keyword,
          async (query, signal) => {
            try {
              return {
                ok: true as const,
                options: await services.equipment(query, signal),
              }
            } catch (error) {
              if (signal.aborted) throw error
              return {
                ok: false as const,
                error: error instanceof Error ? error.message : '设备加载失败',
              }
            }
          },
          (result) =>
            context.configure(field, {
              ...(result.ok ? { dataSource: result.options } : {}),
              componentProps: {
                ...props,
                loading: false,
                error: result.ok ? null : result.error,
              },
            }),
          { scope: field, blocking: false }
        )
      }
      search()
    }
    properties.explanation['x-reactions'] = (field) => {
      const required = field.form.values.result === 'abnormal'
      context.configure(field, explanationState(required))
    }
    properties.attachments['x-component-props'] = { upload: services.upload }
    return schema
  }
  const assertSettled: SettledCheck = (values, states) => {
    const expected = values.result === 'abnormal'
    const explanation = states.find(
      (state) => state.path.length === 1 && state.path[0] === 'explanation'
    )
    return explanation?.required === expected &&
      explanation.validationActive === expected &&
      JSON.stringify(explanation.validator) ===
        JSON.stringify(explanationState(expected).validator)
      ? []
      : [{ message: '异常说明字段状态尚未满足当前结果' }]
  }
  const validate: Validate = async (values, signal) => {
    try {
      decode(values)
    } catch (error) {
      const message = error instanceof Error ? error.message : '巡检数据无效'
      return [
        {
          path: message.includes('检查项') ? ['measurements'] : undefined,
          message,
        },
      ]
    }
    return (await services.checkTitle(String(values.title), signal))
      ? []
      : [{ path: ['title'], message: '记录名称已存在' }]
  }
  const save = (values: Values, signal: AbortSignal) =>
    services.save(toDto(values, recordId), signal)
  return { bindings, createSchema, assertSettled, validate, save }
}

/** Only the explicit JSON import path needs a policy; code bindings do not. */
export const inspectionPolicy = {
  ...createZxuiDefinitionPolicy(),
  InspectionMeasurements: { props: [] },
  InspectionAttachments: { props: [] },
}
