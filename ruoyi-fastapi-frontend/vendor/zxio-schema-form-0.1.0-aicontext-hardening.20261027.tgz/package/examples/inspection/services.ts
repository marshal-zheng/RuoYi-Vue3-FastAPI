import type { Attachment, InspectionDto } from './model'
import type { SaveResult } from '@zxio/schema-form/formily'

export interface Services {
  equipment(
    keyword: string,
    signal?: AbortSignal
  ): Promise<{ value: number; label: string }[]>
  checkTitle(title: string, signal: AbortSignal): Promise<boolean>
  upload(file: File, signal: AbortSignal): Promise<Attachment>
  save(dto: InspectionDto, signal: AbortSignal): Promise<SaveResult>
}
function delay(signal: AbortSignal | undefined, ms = 180) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted)
      return reject(new DOMException('Cancelled', 'AbortError'))
    const abort = () => {
      clearTimeout(timer)
      reject(new DOMException('Cancelled', 'AbortError'))
    }
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', abort)
      resolve()
    }, ms)
    signal?.addEventListener('abort', abort, { once: true })
  })
}
export function createServices(): Services {
  return {
    async equipment(keyword, signal) {
      await delay(signal)
      return [
        { value: 0, label: '设备 0 · 循环泵' },
        { value: 2, label: '设备 2 · 风机' },
      ].filter((item) => item.label.includes(keyword))
    },
    async checkTitle(title, signal) {
      await delay(signal)
      return title !== '重复名称'
    },
    async upload(file, signal) {
      await delay(signal)
      return {
        id: `attachment-${crypto.randomUUID()}`,
        name: file.name,
        url: '',
      }
    },
    async save(dto, signal) {
      await delay(signal, 350)
      if (dto.payload.title === '服务端拒绝')
        return {
          ok: false,
          issues: [
            {
              path: ['title'],
              message: '该名称与另一条记录冲突，请修改后重试',
            },
          ],
        }
      return { ok: true }
    },
  }
}
