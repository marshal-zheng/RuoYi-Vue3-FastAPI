"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const inputComposition = require("../input-composition-BhidVwrA.js");
const vue = require("vue");
const vue$1 = require("@formily/vue");
const input = require("@zxio/zxui/input");
const inputNumber = require("@zxio/zxui/input-number");
const elementPlus = require("element-plus");
const select = require("@zxio/zxui/select");
const tagsInput = require("@zxio/zxui/tags-input");
const aiContext = require("@zxio/zxui/ai-context");
const index = require("../index-BupWnDag.js");
const core = require("@formily/core");
const reactive = require("@formily/reactive");
const validator = require("@formily/validator");
const _sfc_main$3 = /* @__PURE__ */ vue.defineComponent({
  __name: "RadioOptions",
  props: {
    modelValue: { type: [String, Number, Boolean] },
    options: { type: [Array, Function] },
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["update:modelValue", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const resolved = vue.computed(
      () => typeof props.options === "function" ? props.options() : props.options ?? []
    );
    const group = vue.useTemplateRef("group");
    function interaction(type, event) {
      var _a;
      const root = (_a = group.value) == null ? void 0 : _a.$el;
      if (!(event.relatedTarget instanceof Node) || !(root == null ? void 0 : root.contains(event.relatedTarget)))
        emit(type, event);
    }
    __expose({
      focus() {
        var _a;
        const root = (_a = group.value) == null ? void 0 : _a.$el;
        const input2 = (root == null ? void 0 : root.querySelector("input:checked:not(:disabled)")) ?? (root == null ? void 0 : root.querySelector("input:not(:disabled)"));
        input2 == null ? void 0 : input2.focus();
      }
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(elementPlus.ElRadioGroup), {
        ref_key: "group",
        ref: group,
        "model-value": __props.modelValue,
        disabled: __props.disabled || __props.readonly,
        "validate-event": false,
        onFocusin: _cache[0] || (_cache[0] = ($event) => interaction("focus", $event)),
        onFocusout: _cache[1] || (_cache[1] = ($event) => interaction("blur", $event)),
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => emit("update:modelValue", $event))
      }, {
        default: vue.withCtx(() => [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(resolved.value, (option) => {
            return vue.openBlock(), vue.createBlock(vue.unref(elementPlus.ElRadio), {
              key: `${typeof option.value}:${option.value}`,
              value: option.value,
              disabled: option.disabled
            }, {
              default: vue.withCtx(() => [
                vue.createTextVNode(vue.toDisplayString(option.label), 1)
              ]),
              _: 2
            }, 1032, ["value", "disabled"]);
          }), 128))
        ]),
        _: 1
      }, 8, ["model-value", "disabled"]);
    };
  }
});
function createZxuiBindings$1() {
  return {
    ZxInput: vue.markRaw(input.ZxInput),
    ZxInputNumber: vue.markRaw(inputNumber.ZxInputNumber),
    ZxRadioGroup: vue.markRaw(_sfc_main$3),
    ZxSelect: vue.markRaw(select.ZxSelect),
    ZxTagsInput: vue.markRaw(tagsInput.ZxTagsInput)
  };
}
function createZxuiDefinitionPolicy$1() {
  return {
    ZxInput: {
      props: ["placeholder", "aria-label", "type", "rows", "maxlength"]
    },
    ZxInputNumber: {
      props: [
        "min",
        "max",
        "step",
        "precision",
        "controlsPosition",
        "aria-label"
      ]
    },
    ZxRadioGroup: {
      props: ["options", "disabled", "aria-label"]
    },
    ZxSelect: {
      props: [
        "clearable",
        "filterable",
        "remote",
        "valueOnClear",
        "aria-label",
        "options"
      ]
    },
    ZxTagsInput: {
      props: ["placeholder", "maxCount"]
    }
  };
}
const _hoisted_1$2 = ["data-severity"];
const _sfc_main$2 = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "NumberField",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    min: {},
    max: {},
    step: { default: 1 },
    precision: {},
    stepStrictly: { type: Boolean },
    disabledScientific: { type: Boolean },
    controls: { type: Boolean, default: true },
    controlsPosition: {},
    messages: {}
  },
  emits: ["update:modelValue", "edit-state", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const attrs = vue.useAttrs();
    const messagesId = `schema-number-${vue.useId()}`;
    const input2 = vue.useTemplateRef("input");
    const text = vue.ref(props.modelValue == null ? "" : String(props.modelValue));
    const composition = inputComposition.useInputComposition();
    const parsed = vue.computed(() => inputComposition.parseNumberText(text.value));
    const blocking = vue.computed(
      () => composition.blocked.value || parsed.value.status === "invalid" || props.disabledScientific && /e/i.test(text.value) ? [{ severity: "error", message: "请输入完整、有效的数字" }] : []
    );
    const visibleMessages = vue.computed(
      () => blocking.value.length ? blocking.value : props.messages ?? []
    );
    const describedBy = vue.computed(
      () => [attrs["aria-describedby"], visibleMessages.value.length ? messagesId : ""].filter(Boolean).join(" ") || void 0
    );
    let editSequence = 0;
    function report() {
      emit("edit-state", { blocking: blocking.value, editSequence });
    }
    function edit(value) {
      composition.acceptChange();
      text.value = value;
      editSequence++;
      report();
      if (!blocking.value.length && parsed.value.status !== "invalid")
        emit(
          "update:modelValue",
          parsed.value.status === "empty" ? null : parsed.value.value
        );
    }
    function nativeInput(event) {
      composition.observe(event);
      edit(event.target.value);
    }
    vue.watch(
      () => props.modelValue,
      (value) => {
        if (composition.blocked.value) return;
        if (parsed.value.status === "valid" && parsed.value.value === value || parsed.value.status === "empty" && value == null)
          return;
        text.value = value == null ? "" : String(value);
        report();
      }
    );
    __expose({
      focus: () => {
        var _a;
        return (_a = input2.value) == null ? void 0 : _a.focus();
      },
      validate: () => {
        report();
        return !blocking.value.length;
      },
      captureEdit: () => ({
        text: text.value,
        composition: composition.keys.value
      }),
      restoreEdit(draft) {
        if (draft && typeof draft === "object" && !Array.isArray(draft) && typeof draft.text === "string") {
          text.value = draft.text;
          composition.restore(draft.composition);
          report();
        }
      }
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        class: "schema-form__number-field",
        onInputCapture: nativeInput,
        onCompositionstartCapture: nativeInput,
        onCompositionendCapture: nativeInput
      }, [
        vue.createVNode(vue.unref(inputNumber.ZxInputNumber), vue.mergeProps({
          ref_key: "input",
          ref: input2
        }, _ctx.$attrs, {
          "model-value": __props.modelValue,
          text: text.value,
          disabled: __props.disabled,
          readonly: __props.readonly,
          min: __props.min,
          max: __props.max,
          step: __props.step,
          precision: __props.precision,
          "step-strictly": __props.stepStrictly,
          "disabled-scientific": __props.disabledScientific,
          controls: __props.controls,
          "controls-position": __props.controlsPosition,
          "validate-event": false,
          "aria-invalid": visibleMessages.value.some((message) => message.severity === "error") || void 0,
          "aria-describedby": describedBy.value,
          "onUpdate:text": edit,
          onFocus: _cache[0] || (_cache[0] = ($event) => emit("focus", $event)),
          onBlur: _cache[1] || (_cache[1] = ($event) => emit("blur", $event))
        }), null, 16, ["model-value", "text", "disabled", "readonly", "min", "max", "step", "precision", "step-strictly", "disabled-scientific", "controls", "controls-position", "aria-invalid", "aria-describedby"]),
        vue.createElementVNode("ul", {
          id: messagesId,
          class: "el-form-item__error zx-schema-field__messages",
          "aria-live": "polite"
        }, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(visibleMessages.value, (message, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: index2,
              "data-severity": message.severity
            }, vue.toDisplayString(message.message), 9, _hoisted_1$2);
          }), 128))
        ])
      ], 32);
    };
  }
});
const _hoisted_1$1 = ["data-severity"];
const _sfc_main$1 = /* @__PURE__ */ vue.defineComponent({
  ...{ inheritAttrs: false },
  __name: "TextField",
  props: {
    modelValue: {},
    messages: {}
  },
  emits: ["update:modelValue", "edit-state"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const input$1 = vue.ref();
    const raw = vue.ref(String(props.modelValue ?? ""));
    const composition = inputComposition.useInputComposition();
    const attrs = vue.useAttrs();
    const messageId = `conditional-text-${vue.useId()}`;
    const messages = vue.computed(
      () => composition.blocked.value ? [{ severity: "error", message: "请完成输入" }] : props.messages ?? []
    );
    const describedBy = vue.computed(
      () => [attrs["aria-describedby"], messages.value.length ? messageId : void 0].filter(Boolean).join(" ") || void 0
    );
    let editSequence = 0;
    function report() {
      emit("edit-state", {
        editSequence,
        blocking: composition.blocked.value ? [{ severity: "error", message: "请完成输入" }] : []
      });
    }
    function nativeEdit(event) {
      composition.observe(event);
      raw.value = event.target.value;
      editSequence++;
      report();
      if (!composition.blocked.value) update(raw.value);
    }
    function update(value) {
      const resumed = composition.acceptChange();
      if (raw.value !== value || resumed) {
        raw.value = value;
        editSequence++;
        report();
      }
      if (!composition.blocked.value) emit("update:modelValue", value);
    }
    vue.watch(
      () => props.modelValue,
      (value) => {
        if (String(value ?? "") !== raw.value && !composition.blocked.value)
          raw.value = String(value ?? "");
      }
    );
    __expose({
      focus: () => {
        var _a;
        return (_a = input$1.value) == null ? void 0 : _a.focus();
      },
      validate: () => !composition.blocked.value,
      captureEdit: () => ({ text: raw.value, composition: composition.keys.value }),
      restoreEdit(draft) {
        if (draft && typeof draft === "object" && !Array.isArray(draft) && typeof draft.text === "string") {
          raw.value = draft.text;
          composition.restore(draft.composition);
          report();
        }
      }
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        class: "schema-form__text-field",
        onInputCapture: nativeEdit,
        onCompositionstartCapture: nativeEdit,
        onCompositionendCapture: nativeEdit
      }, [
        vue.createVNode(vue.unref(input.ZxInput), vue.mergeProps({
          ref_key: "input",
          ref: input$1
        }, _ctx.$attrs, {
          "model-value": raw.value,
          "aria-describedby": describedBy.value,
          "validate-event": false,
          "onUpdate:modelValue": update
        }), null, 16, ["model-value", "aria-describedby"]),
        vue.createElementVNode("ul", {
          id: messageId,
          class: "el-form-item__error zx-schema-field__messages",
          "aria-live": "polite"
        }, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(messages.value, (message, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", {
              key: index2,
              "data-severity": message.severity
            }, vue.toDisplayString(message.message), 9, _hoisted_1$1);
          }), 128))
        ])
      ], 32);
    };
  }
});
function createZxuiBindings() {
  return {
    ...Object.fromEntries(
      Object.entries(createZxuiBindings$1()).map(([name, component]) => [
        name,
        {
          component,
          composite: false,
          editObservation: name === "ZxRadioGroup" || name === "ZxSelect" ? "canonical" : void 0,
          dataSourceProp: name === "ZxRadioGroup" || name === "ZxSelect" ? "options" : void 0
        }
      ])
    ),
    ZxInput: {
      component: vue.markRaw(_sfc_main$1),
      composite: true,
      group: false,
      validationOwnership: "managed",
      editObservation: "raw-sequence"
    },
    ZxInputNumber: {
      component: vue.markRaw(_sfc_main$2),
      composite: true,
      group: false,
      validationOwnership: "managed",
      editObservation: "raw-sequence"
    }
  };
}
function createZxuiDefinitionPolicy() {
  const policy = createZxuiDefinitionPolicy$1();
  policy.ZxInputNumber.props = [...policy.ZxInputNumber.props, "controls"];
  return policy;
}
function fieldInteraction(pattern, componentProps, disabled = false) {
  const unavailable = disabled || pattern === "disabled" || pattern === "readPretty" || !!componentProps.disabled;
  const readonly = pattern === "readOnly" || !!componentProps.readonly || !!componentProps.readOnly;
  return {
    disabled: unavailable,
    readonly,
    writable: pattern === "editable" && !unavailable && !readonly
  };
}
function parseAIContextReference(value) {
  if (value === void 0) return void 0;
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).join(",") !== "itemId" || !("itemId" in value) || typeof value.itemId !== "string" || !/^[a-zA-Z][a-zA-Z0-9]{0,63}$/.test(value.itemId))
    throw new Error("Invalid AI context reference");
  return { itemId: value.itemId };
}
function useFormilyAIContext(runtime) {
  const scope = aiContext.useAIContextScope();
  return (reference, field) => {
    const metadata = parseAIContextReference(reference);
    if (!metadata || !scope) return () => {
    };
    const release = scope.register(metadata.itemId, {
      value: () => field().value,
      available: () => {
        var _a, _b;
        const model = field();
        const state = (_a = runtime.controls.get(model)) == null ? void 0 : _a.state;
        return model.display === "visible" && !(state == null ? void 0 : state.pending) && !((_b = state == null ? void 0 : state.blocking) == null ? void 0 : _b.length);
      }
    });
    const stop = vue.watch(runtime.version, () => scope.invalidate(), {
      flush: "sync"
    });
    return () => {
      stop();
      release();
    };
  };
}
function createBindings(runtime, bindings, disabled = () => false) {
  const result = {
    ZxSection: vue.defineComponent({
      inheritAttrs: false,
      setup(_, { attrs, slots }) {
        const field = vue$1.useField();
        return () => {
          var _a;
          return vue.h(
            "fieldset",
            { ...attrs, class: ["schema-form__section", attrs.class] },
            [vue.h("legend", String(field.value.title ?? "")), (_a = slots.default) == null ? void 0 : _a.call(slots)]
          );
        };
      }
    }),
    ZxArray: vue.defineComponent({
      name: "ZxSchemaArray",
      inheritAttrs: false,
      setup() {
        const field = vue$1.useField();
        const schema = vue$1.useFieldSchema();
        const bindAIContext = useFormilyAIContext(runtime);
        const disposeAI = bindAIContext(
          schema.value["x-ai-context"],
          () => field.value
        );
        vue.onBeforeUnmount(disposeAI);
        const root = vue.shallowRef();
        const port = runtime.register(
          field.value,
          {
            focus: () => {
              var _a, _b;
              return (_b = (_a = root.value) == null ? void 0 : _a.querySelector("input,select,textarea,button")) == null ? void 0 : _b.focus();
            }
          },
          false,
          "canonical"
        );
        vue.onBeforeUnmount(port.dispose);
        return () => {
          runtime.version.value;
          const keys2 = runtime.arrayKeys(field.value);
          const model = field.value;
          return vue.h(
            inputComposition._sfc_main,
            {
              label: model.title ?? "",
              group: true,
              required: model.required,
              messages: (runtime.feedback.value.get(model) ?? []).map(
                (issue) => ({
                  message: issue.message,
                  severity: issue.severity ?? "error"
                })
              )
            },
            {
              default: ({
                controlProps
              }) => vue.h(
                "div",
                { ...controlProps, ref: root, class: "schema-form__array" },
                (field.value.value ?? []).map(
                  (_, index2) => vue.h(vue$1.RecursionField, {
                    key: keys2[index2],
                    schema: schema.value.items,
                    name: index2,
                    basePath: field.value.address
                  })
                )
              )
            }
          );
        };
      }
    }),
    ZxField: vue.defineComponent({
      inheritAttrs: false,
      setup(_, { slots }) {
        const field = vue$1.useField();
        const structural = !field.value.componentType;
        const root = vue.shallowRef();
        const port = structural ? runtime.register(
          field.value,
          {
            focus: () => {
              var _a, _b;
              return (_b = (_a = root.value) == null ? void 0 : _a.querySelector("input,select,textarea,button")) == null ? void 0 : _b.focus();
            }
          },
          false,
          "canonical"
        ) : void 0;
        vue.onBeforeUnmount(() => port == null ? void 0 : port.dispose());
        return () => {
          var _a;
          if (!structural) return (_a = slots.default) == null ? void 0 : _a.call(slots);
          runtime.version.value;
          const model = field.value;
          return vue.h(
            inputComposition._sfc_main,
            {
              label: model.title ?? "",
              group: true,
              required: model.required,
              messages: (runtime.feedback.value.get(model) ?? []).map(
                (issue) => ({
                  message: issue.message,
                  severity: issue.severity ?? "error"
                })
              )
            },
            {
              default: ({
                controlProps
              }) => {
                var _a2;
                return vue.h("div", { ...controlProps, ref: root }, (_a2 = slots.default) == null ? void 0 : _a2.call(slots));
              }
            }
          );
        };
      }
    })
  };
  for (const [name, binding] of Object.entries(bindings)) {
    const composite = "composite" in binding && binding.composite === true;
    const group = composite && (!("group" in binding) || binding.group !== false);
    const component = vue.toRaw(
      "component" in binding ? binding.component : binding
    );
    const dataSourceProp = "dataSourceProp" in binding ? binding.dataSourceProp : void 0;
    result[name] = vue.markRaw(
      vue.defineComponent({
        name: `Schema${name}`,
        inheritAttrs: false,
        props: { value: { type: null }, disabled: Boolean, readOnly: Boolean },
        // Declaring these consumes Formily's injected callbacks. Never emit them:
        // ReactiveField would invoke native onInput/onBlur and race our tickets.
        emits: ["change", "focus", "blur"],
        setup(props, { attrs, slots }) {
          const field = vue$1.useField();
          const schema = vue$1.useFieldSchema();
          const bindAIContext = useFormilyAIContext(runtime);
          const disposeAI = bindAIContext(
            schema.value["x-ai-context"],
            () => field.value
          );
          vue.onBeforeUnmount(disposeAI);
          const child = vue.shallowRef();
          const seenEvents = /* @__PURE__ */ new WeakSet();
          const interaction = (type, event) => {
            if (event && seenEvents.has(event)) return;
            if (event) seenEvents.add(event);
            runtime.event(field.value, type);
            const callback = field.value.componentProps[type === "focus" ? "onFocus" : "onBlur"];
            if (typeof callback === "function") callback(event);
          };
          let port;
          const mount = (value) => {
            if (child.value === value) return;
            port == null ? void 0 : port.dispose();
            child.value = value;
            if (value)
              port = runtime.register(
                field.value,
                {
                  focus: (path) => {
                    var _a, _b;
                    return (_b = (_a = child.value) == null ? void 0 : _a.focus) == null ? void 0 : _b.call(_a, path);
                  },
                  ...composite ? {
                    captureEdit: () => {
                      var _a, _b;
                      return ((_b = (_a = child.value) == null ? void 0 : _a.captureEdit) == null ? void 0 : _b.call(_a)) ?? null;
                    },
                    restoreEdit: (draft) => {
                      var _a, _b;
                      return (_b = (_a = child.value) == null ? void 0 : _a.restoreEdit) == null ? void 0 : _b.call(_a, draft);
                    },
                    validate: (context) => {
                      var _a, _b;
                      return ((_b = (_a = child.value) == null ? void 0 : _a.validate) == null ? void 0 : _b.call(_a, context)) ?? true;
                    }
                  } : {}
                },
                composite,
                "editObservation" in binding ? binding.editObservation : void 0,
                "validationOwnership" in binding ? binding.validationOwnership : void 0
              );
          };
          vue.onMounted(() => port == null ? void 0 : port.restore());
          vue.onBeforeUnmount(() => port == null ? void 0 : port.dispose());
          return () => {
            var _a;
            runtime.version.value;
            const model = field.value;
            const interactionState = fieldInteraction(
              model.pattern,
              model.componentProps,
              disabled()
            );
            const messages = (runtime.feedback.value.get(model) ?? []).map((issue) => {
              var _a2;
              return {
                severity: issue.severity ?? "error",
                message: issue.message,
                ...((_a2 = issue.path) == null ? void 0 : _a2.length) ? { path: issue.path.slice(model.path.toArr().length) } : {}
              };
            });
            return vue.h(
              inputComposition._sfc_main,
              {
                ...model.decoratorProps,
                label: model.title ?? "",
                description: model.description ? String(model.description) : void 0,
                required: model.required,
                messages: composite ? [] : messages,
                reserveFeedback: !composite,
                invalid: composite && [
                  ...messages,
                  ...((_a = runtime.controls.get(model)) == null ? void 0 : _a.state.blocking) ?? []
                ].some((issue) => issue.severity === "error"),
                group
              },
              {
                default: ({
                  controlProps
                }) => vue.h(
                  component,
                  {
                    ...attrs,
                    ...controlProps,
                    ref: mount,
                    modelValue: props.value,
                    disabled: interactionState.disabled,
                    readonly: interactionState.readonly,
                    ...dataSourceProp ? { [dataSourceProp]: model.dataSource } : {},
                    ...composite ? { messages } : {},
                    "onUpdate:modelValue": (value) => {
                      if (!fieldInteraction(model.pattern, model.componentProps).writable)
                        return;
                      runtime.event(model, "change", value);
                      const callback = model.componentProps.onChange;
                      if (typeof callback === "function") callback(value);
                    },
                    onFocus: (event) => interaction("focus", event),
                    onBlur: (event) => interaction("blur", event),
                    "onEdit-state": (state) => port == null ? void 0 : port.report(state)
                  },
                  slots
                )
              }
            );
          };
        }
      })
    );
  }
  return result;
}
function awaitSignal(work, signal) {
  return new Promise((resolve, reject2) => {
    const abort = () => reject2(new Error("表单已更新，请重新提交"));
    const cleanup = () => signal.removeEventListener("abort", abort);
    work.then(
      (value) => {
        cleanup();
        resolve(value);
      },
      (error) => {
        cleanup();
        reject2(error);
      }
    );
    if (signal.aborted) abort();
    else signal.addEventListener("abort", abort, { once: true });
  });
}
const unsafe = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
function validPath$1(path) {
  return Array.isArray(path) && path.every(
    (part) => typeof part === "string" ? !unsafe.has(part) : Number.isInteger(part) && part >= 0
  );
}
function readPath(value, path) {
  let current = value;
  for (const part of path) {
    if (!current || typeof current !== "object" || !Object.hasOwn(current, part))
      return void 0;
    current = current[part];
  }
  return current;
}
function anchorPath(path, submitted, keys2) {
  return path.map((part, index$1) => {
    var _a;
    if (typeof part === "string") return part;
    const arrayPath = path.slice(0, index$1);
    const rows = readPath(submitted, arrayPath);
    const key = (_a = keys2.find((item) => index.equal(item.path, arrayPath))) == null ? void 0 : _a.key;
    if (!Array.isArray(rows)) return { index: part, unsafe: true };
    if (!key) return { index: part, snapshot: index.copy(rows) };
    const value = readPath(rows[part], [key]);
    if (typeof value !== "string" && typeof value !== "number" || rows.filter((row) => readPath(row, [key]) === value).length !== 1)
      return { index: part, unsafe: true };
    return { index: part, key, value };
  });
}
function resolvePath(anchor, current) {
  const path = [];
  for (const part of anchor) {
    if (typeof part === "string") {
      path.push(part);
      continue;
    }
    const rows = readPath(current, path);
    if (!Array.isArray(rows) || part.unsafe) return {};
    if (!part.key) {
      if (!index.equal(rows, part.snapshot)) return {};
      path.push(part.index);
      continue;
    }
    const matches2 = rows.flatMap(
      (row, index2) => readPath(row, [part.key]) === part.value ? [index2] : []
    );
    if (!matches2.length) return { deleted: true };
    if (matches2.length !== 1) return {};
    path.push(matches2[0]);
  }
  return { path };
}
function dataPath(path, values) {
  const result = [];
  let parent = values;
  for (const part of path) {
    const normalized = Array.isArray(parent) && /^(0|[1-9]\d*)$/.test(String(part)) ? Number(part) : part;
    result.push(normalized);
    parent = readPath(parent, [normalized]);
  }
  return result;
}
function cloneConfig(input2) {
  if (Array.isArray(input2)) return input2.map(cloneConfig);
  if (input2 instanceof RegExp) return new RegExp(input2.source, input2.flags);
  if (input2 && typeof input2 === "object") {
    if (Object.getPrototypeOf(input2) !== Object.prototype)
      throw new Error("Configuration must contain plain objects");
    return Object.fromEntries(
      Object.entries(input2).map(([key, value]) => {
        if (["__proto__", "prototype", "constructor"].includes(key))
          throw new Error("Unsafe configuration key");
        return [key, cloneConfig(value)];
      })
    );
  }
  return input2;
}
function immutable(input2, fail) {
  const seen = /* @__PURE__ */ new WeakMap();
  const visit = (value) => {
    if (!value || typeof value !== "object") return value;
    if (seen.has(value)) return seen.get(value);
    const deny = () => {
      const message = "Read-only submission configuration/input was mutated";
      fail(message);
      throw new Error(message);
    };
    const proxy = new Proxy(value, {
      get(target, key, receiver) {
        if (target instanceof RegExp) {
          if (key === "compile") return deny;
          const result = Reflect.get(target, key, target);
          return typeof result === "function" ? result.bind(new RegExp(target.source, target.flags)) : result;
        }
        return visit(Reflect.get(target, key, receiver));
      },
      set: deny,
      deleteProperty: deny,
      defineProperty: deny,
      setPrototypeOf: deny
    });
    seen.set(value, proxy);
    return proxy;
  };
  return visit(input2);
}
function createErrorLedger(ports, keys2) {
  const sources = vue.shallowRef(/* @__PURE__ */ new Map());
  function indexFields(values) {
    const fields = new Set(ports.fields());
    const paths = /* @__PURE__ */ new Map();
    const byPath = /* @__PURE__ */ new Map();
    for (const field of fields) {
      const path = dataPath(field.path.toArr(), values);
      paths.set(field, path);
      const key = JSON.stringify(path);
      byPath.set(key, [...byPath.get(key) ?? [], field]);
    }
    return { fields, paths, byPath };
  }
  function fallbackPath(entry, paths) {
    var _a;
    return entry.model && ((_a = entry.anchor) == null ? void 0 : _a.some((part) => typeof part !== "string" && part.snapshot)) && !entry.anchor.some((part) => typeof part !== "string" && part.unsafe) ? paths.get(entry.model) : void 0;
  }
  const resolved = vue.computed(() => {
    ports.version();
    const values = ports.read();
    const { paths, byPath } = indexFields(values);
    const closest = (path, accepts) => {
      var _a;
      if (!path) return void 0;
      for (let length = path.length; length >= 0; length--) {
        const found = (_a = byPath.get(JSON.stringify(path.slice(0, length)))) == null ? void 0 : _a.find((field) => accepts(field, length === path.length));
        if (found) return found;
      }
      return void 0;
    };
    return [...sources.value].flatMap(
      ([code, entries]) => entries.flatMap((entry) => {
        const result = entry.anchor ? resolvePath(entry.anchor, values) : {};
        if (result.deleted) return [];
        const issue = {
          ...entry.issue,
          path: result.path ?? fallbackPath(entry, paths)
        };
        const anyField = closest(result.path, () => true);
        if (anyField && !ports.active(anyField)) return [];
        const field = closest(
          issue.path,
          (field2, exact) => ports.visible(field2) && (exact || ports.composite(field2))
        );
        return [{ code, issue, field }];
      })
    );
  });
  const messages = (field) => resolved.value.filter((entry) => entry.field === field).map(({ issue }) => issue);
  const formIssues = vue.computed(
    () => resolved.value.filter((entry) => !entry.field).map(({ issue }) => issue)
  );
  function project2() {
    var _a;
    const grouped = /* @__PURE__ */ new Map();
    for (const entry of resolved.value) {
      if (!entry.field) continue;
      let groups = grouped.get(entry.field);
      if (!groups) grouped.set(entry.field, groups = /* @__PURE__ */ new Map());
      const code = entry.code.split(":", 1)[0];
      const issues = groups.get(code) ?? [];
      issues.push(entry.issue);
      groups.set(code, issues);
    }
    for (const field of ports.fields()) {
      for (const code of [
        "SessionValidation",
        "SessionDomain",
        "SessionServer",
        "SessionDerivation"
      ]) {
        const issues = ((_a = grouped.get(field)) == null ? void 0 : _a.get(code)) ?? [];
        for (const severity of ["error", "warning", "info"]) {
          const type = severity === "info" ? "success" : severity;
          const messages2 = issues.filter((issue) => (issue.severity ?? "error") === severity).map((issue) => issue.message);
          const previous = field.queryFeedbacks({ code, type }).flatMap((feedback) => feedback.messages ?? []);
          if (!index.equal(previous, messages2))
            field.setFeedback({ code, type, messages: messages2 });
        }
      }
    }
  }
  function setMany(updates, submitted = ports.read()) {
    if (!updates.length) return;
    const { byPath } = indexFields(submitted);
    const next = new Map(sources.value);
    for (const { code, issues } of updates) {
      const entries = issues.map((issue) => {
        var _a, _b;
        if (typeof issue.message !== "string" || issue.path && !validPath$1(issue.path))
          throw new TypeError("Invalid field issue");
        const path = ((_a = issue.path) == null ? void 0 : _a.length) ? [...issue.path] : void 0;
        return {
          issue: { ...issue, path },
          anchor: path ? anchorPath(path, submitted, keys2) : void 0,
          value: path ? readPath(submitted, path) : void 0,
          model: path ? (_b = byPath.get(JSON.stringify(path))) == null ? void 0 : _b[0] : void 0
        };
      });
      if (entries.length) next.set(code, entries);
      else next.delete(code);
    }
    sources.value = next;
    ports.changed();
    project2();
  }
  function set(code, issues, submitted) {
    setMany([{ code, issues }], submitted);
  }
  function changed() {
    const values = ports.read();
    const { paths } = indexFields(values);
    sources.value = new Map(
      [...sources.value].map(([code, entries]) => [
        code,
        code.startsWith("SessionDomain") ? [] : entries.filter((entry) => {
          if (!entry.anchor) return false;
          const result = resolvePath(entry.anchor, values);
          const path = result.path ?? fallbackPath(entry, paths);
          return !result.deleted && (!path || index.equal(entry.value, readPath(values, path)));
        })
      ])
    );
    project2();
  }
  return {
    messages,
    formIssues,
    project: project2,
    set,
    setMany,
    forgetFields(fields) {
      sources.value = new Map(
        [...sources.value].map(([code, entries]) => [
          code,
          entries.flatMap((entry) => {
            if (!entry.model || !fields.has(entry.model)) return [entry];
            return code.startsWith("SessionValidation:") ? [] : [{ ...entry, model: void 0 }];
          })
        ]).filter(([, entries]) => entries.length)
      );
    },
    changed,
    clear: () => {
      sources.value = /* @__PURE__ */ new Map();
      ports.changed();
      project2();
    },
    clearValidation(identity) {
      const prefix2 = `SessionValidation:${identity}:`;
      const next = new Map(
        [...sources.value].filter(([code]) => !code.startsWith(prefix2))
      );
      if (next.size === sources.value.size) return;
      sources.value = next;
      ports.changed();
      project2();
    },
    clearField(field) {
      const prefix2 = dataPath(field.path.toArr(), ports.read());
      sources.value = new Map(
        [...sources.value].map(([code, entries]) => [
          code,
          entries.filter(
            (entry) => !entry.issue.path || !prefix2.every((part, index2) => {
              var _a;
              return part === ((_a = entry.issue.path) == null ? void 0 : _a[index2]);
            })
          )
        ])
      );
      project2();
      ports.changed();
    }
  };
}
function createResources(signal, semantic) {
  const version = vue.shallowRef(0);
  const tasks = /* @__PURE__ */ new Map();
  const bridges = /* @__PURE__ */ new Map();
  const retired = /* @__PURE__ */ new WeakSet();
  const scopeIds = /* @__PURE__ */ new WeakMap();
  let nextScope = 0;
  const identity = (key, scope) => {
    if (typeof scope === "object" && !scopeIds.has(scope))
      scopeIds.set(scope, ++nextScope);
    return `${typeof scope === "object" ? scopeIds.get(scope) : scope}\0${key}`;
  };
  const notify = (token) => {
    semantic == null ? void 0 : semantic(token);
    version.value++;
  };
  const active = (task) => !signal.aborted && !task.controller.signal.aborted && task.applicable() && tasks.get(identity(task.key, task.scope)) === task;
  function start(task) {
    var _a;
    tasks.set(identity(task.key, task.scope), task);
    notify((_a = task.origin) == null ? void 0 : _a.token);
    let work;
    try {
      work = Promise.resolve(
        task.load(index.copy(task.input), task.controller.signal)
      );
    } catch (error) {
      work = Promise.reject(error);
    }
    work.then(
      (value) => {
        if (!active(task)) return;
        try {
          task.value = index.copy(value);
          if (!retired.has(task.runtime)) {
            if (task.origin) task.origin.run(() => task.commit(index.copy(value)));
            else task.commit(index.copy(value));
          }
          if (!active(task)) return;
          task.state = "success";
        } catch (error) {
          if (!active(task)) return;
          task.state = "error";
          task.error = error instanceof Error ? error.message : "资源投影失败";
        }
      },
      (error) => {
        if (!active(task)) return;
        task.state = "error";
        task.error = error instanceof Error ? error.message : "资源读取失败";
      }
    ).finally(() => {
      var _a2;
      if (tasks.get(identity(task.key, task.scope)) === task)
        notify((_a2 = task.origin) == null ? void 0 : _a2.token);
    });
  }
  function runLatest(runtime, key, captured, load, commit, options = {}, applicable = () => true, origin) {
    var _a;
    if (signal.aborted || retired.has(runtime)) return;
    const scope = options.scope ?? "edit";
    const input2 = index.copy(captured);
    const id = identity(key, scope);
    const previous = tasks.get(id);
    if (previous && index.equal(previous.input, input2)) {
      const changedCallbacks = !((_a = previous.origin) == null ? void 0 : _a.identity) || previous.origin.identity.some(
        (item, i) => {
          var _a2;
          return item !== ((_a2 = origin == null ? void 0 : origin.identity) == null ? void 0 : _a2[i]);
        }
      );
      const changedRuntime = previous.runtime !== runtime;
      const changedBlocking = previous.blocking !== !!options.blocking;
      previous.blocking = !!options.blocking;
      previous.applicable = applicable;
      previous.load = load;
      previous.runtime = runtime;
      previous.commit = commit;
      if (changedRuntime) previous.origin = origin;
      if (changedBlocking || changedCallbacks || changedRuntime)
        notify(origin == null ? void 0 : origin.token);
      if (changedRuntime && previous.state === "success")
        previous.commit(index.copy(previous.value));
      return;
    }
    if (previous) {
      previous.state = "superseded";
      previous.controller.abort();
    }
    start({
      key,
      scope,
      input: input2,
      runtime,
      origin,
      applicable,
      load,
      commit,
      controller: new AbortController(),
      state: "pending",
      blocking: !!options.blocking
    });
  }
  function retry(key, scope = "edit") {
    const previous = tasks.get(identity(key, scope));
    if (!previous || previous.state === "pending" || signal.aborted) return;
    start({
      ...previous,
      origin: void 0,
      controller: new AbortController(),
      state: "pending",
      error: void 0
    });
  }
  function cancel(key, scope = "edit", applicable = true, token) {
    const task = tasks.get(identity(key, scope));
    if (!task) return;
    task.state = "cancelled";
    task.controller.abort();
    if (!applicable) tasks.delete(identity(key, scope));
    notify(token);
  }
  function bindResource(runtime, source, project2, applicable = () => true) {
    let previous;
    let projected = false;
    const projectCurrent = (value) => {
      if (!signal.aborted && applicable()) {
        previous = index.copy(value);
        projected = true;
        project2(value);
      }
    };
    const stop = vue.watch(
      source,
      (value) => {
        projectCurrent(value);
      },
      { immediate: true, flush: "sync", deep: true }
    );
    let set = bridges.get(runtime);
    if (!set) {
      set = /* @__PURE__ */ new Set();
      bridges.set(runtime, set);
    }
    const bridge = {
      stop,
      applicable,
      refresh() {
        const value = source();
        if (!projected || !index.equal(previous, value)) projectCurrent(value);
      }
    };
    set.add(bridge);
    return () => {
      stop();
      set == null ? void 0 : set.delete(bridge);
    };
  }
  function retire(runtime) {
    var _a;
    retired.add(runtime);
    (_a = bridges.get(runtime)) == null ? void 0 : _a.forEach((bridge) => bridge.stop());
    bridges.delete(runtime);
    for (const task of tasks.values())
      if (task.runtime === runtime && task.scope !== "record")
        cancel(task.key, task.scope, false);
  }
  const pending = () => {
    version.value;
    return [...tasks.values()].some(
      (task) => task.applicable() && task.state === "pending"
    );
  };
  const issues = () => {
    version.value;
    return [...tasks.values()].filter(
      (task) => task.applicable() && task.blocking && task.state !== "success"
    ).map((task) => ({
      message: task.error ?? (task.state === "pending" ? "请等待必要资源完成" : "必要资源未就绪，请重试")
    }));
  };
  const dispose = () => {
    for (const task of tasks.values()) task.controller.abort();
    for (const set of bridges.values()) set.forEach((bridge) => bridge.stop());
    tasks.clear();
    bridges.clear();
    notify();
  };
  signal.addEventListener("abort", dispose, { once: true });
  return {
    version,
    runLatest,
    retry,
    cancel,
    bindResource,
    refresh(runtime) {
      var _a;
      (_a = bridges.get(runtime)) == null ? void 0 : _a.forEach((bridge) => bridge.refresh());
    },
    prune(runtime, token) {
      var _a;
      (_a = bridges.get(runtime)) == null ? void 0 : _a.forEach((bridge) => {
        var _a2;
        if (!bridge.applicable()) {
          bridge.stop();
          (_a2 = bridges.get(runtime)) == null ? void 0 : _a2.delete(bridge);
        }
      });
      for (const task of tasks.values())
        if (task.runtime === runtime && !task.applicable())
          cancel(task.key, task.scope, false, token);
    },
    retire,
    pending,
    requiredPending: () => {
      version.value;
      return [...tasks.values()].some(
        (task) => task.blocking && task.state === "pending" && task.applicable()
      );
    },
    issues,
    feedback: () => {
      version.value;
      return [...tasks.values()].filter(
        (task) => task.applicable() && task.state !== "success" && (task.blocking || task.state === "error")
      ).map((task) => ({
        severity: task.blocking ? "error" : "warning",
        message: task.error ?? (task.state === "pending" ? "请等待必要资源完成" : "必要资源未就绪，请重试")
      }));
    },
    dispose,
    states: () => [...tasks.values()].map(({ key, scope, state, error }) => ({
      key,
      scope,
      state,
      error
    }))
  };
}
const operations = /* @__PURE__ */ new Set([
  "push",
  "pop",
  "insert",
  "remove",
  "shift",
  "unshift",
  "move",
  "moveUp",
  "moveDown"
]);
function createArrays(ports) {
  const arrays = /* @__PURE__ */ new WeakSet();
  const objectKeys = /* @__PURE__ */ new WeakMap();
  const modelKeys = /* @__PURE__ */ new WeakMap();
  const pendingKeys = /* @__PURE__ */ new Map();
  let nextKey = 0;
  function install(field) {
    if (arrays.has(field)) return;
    arrays.add(field);
    field.onInput = () => ports.validate(field).then(() => {
    });
  }
  const keyFor = (field) => {
    var _a;
    return (_a = ports.keys.find(
      (rule) => index.equal(rule.path, dataPath(field.path.toArr(), ports.form.values))
    )) == null ? void 0 : _a.key;
  };
  function uniqueIds(rows, key) {
    const ids = rows.map((row) => readPath(row, [key]));
    return ids.every(
      (id) => typeof id === "string" || typeof id === "number" && Number.isFinite(id)
    ) && new Set(ids).size === ids.length ? ids : void 0;
  }
  function renderKeys(field) {
    const rows = field.value ?? [];
    const declared = keyFor(field);
    const ids = declared && uniqueIds(rows, declared);
    return rows.map((row, index2) => {
      if (ids) return `${typeof ids[index2]}:${ids[index2]}`;
      if (row && typeof row === "object") {
        if (!objectKeys.has(row)) objectKeys.set(row, `object:${++nextKey}`);
        return objectKeys.get(row);
      }
      const address = field.address.concat(index2).toString();
      const model = ports.form.query(address).take();
      if (model && modelKeys.has(model)) return modelKeys.get(model);
      let pending = pendingKeys.get(address);
      if (!pending || pending.model && (ports.form.query(address).take() !== pending.model || pending.model.address.toString() !== address)) {
        pending = { key: `item:${++nextKey}` };
        pendingKeys.set(address, pending);
      }
      if (model) {
        pending.model = model;
        modelKeys.set(model, pending.key);
      }
      return pending.key;
    });
  }
  function invoke(field, method, args) {
    ports.assertCurrent(field);
    return ports.transaction(() => {
      var _a;
      const length = ((_a = field.value) == null ? void 0 : _a.length) ?? 0;
      const index$1 = (value, end = false) => {
        if (!Number.isInteger(value) || Number(value) < 0 || Number(value) >= length + (end ? 1 : 0))
          throw new Error("Invalid array operation index");
      };
      if (method === "insert") index$1(args[0], true);
      if (["remove", "moveUp", "moveDown"].includes(method)) index$1(args[0]);
      if (method === "move") {
        index$1(args[0]);
        index$1(args[1]);
      }
      const isolated = ["push", "unshift"].includes(method) ? args.map(index.copy) : method === "insert" ? [args[0], ...args.slice(1).map(index.copy)] : args;
      return field[method].apply(field, isolated);
    });
  }
  function align(field, next) {
    const previous = field.value ?? [];
    if (index.equal(previous, next)) return;
    const key = keyFor(field);
    const before = key && uniqueIds(previous, key);
    const after = key && uniqueIds(next, key);
    if (!before || !after) {
      ports.form.clearFormGraph(`${field.address}.*`, false);
      return;
    }
    const ids = [...before];
    for (let index2 = ids.length - 1; index2 >= 0; index2--)
      if (!after.includes(ids[index2])) {
        invoke(field, "remove", [index2]);
        ids.splice(index2, 1);
      }
    after.forEach((id, target) => {
      const from = ids.indexOf(id);
      if (from < 0) {
        invoke(field, "insert", [target, next[target]]);
        ids.splice(target, 0, id);
      } else if (from !== target) {
        invoke(field, "move", [from, target]);
        ids.splice(target, 0, ids.splice(from, 1)[0]);
      }
    });
  }
  function alignValues(next) {
    const models = ports.form.query("*").map().filter((field) => arrays.has(field));
    models.sort((left, right) => left.path.length - right.path.length);
    for (const field of models) {
      const rows = readPath(next, field.path.toArr());
      if (Array.isArray(rows)) align(field, rows);
    }
  }
  return {
    install,
    renderKeys,
    prune() {
      for (const [address, pending] of pendingKeys)
        if (pending.model && (ports.form.fields[address] !== pending.model || pending.model.address.toString() !== address))
          pendingKeys.delete(address);
    },
    alignValues,
    align,
    operation(field, key) {
      return arrays.has(field) && operations.has(String(key)) ? (...args) => invoke(field, String(key), args) : void 0;
    }
  };
}
function createModelBoundary(ports) {
  const { form, arrays: arrayTools, transaction, deny } = ports;
  const proxies = /* @__PURE__ */ new WeakMap();
  const rawFields = /* @__PURE__ */ new WeakMap();
  const fieldView = (field) => {
    if (rawFields.has(field)) return field;
    const cached = proxies.get(field);
    if (cached) return cached;
    const proxy = new Proxy(field, {
      get(target, key) {
        ports.assertCurrent(target);
        const value = readField(target, key);
        return typeof value === "function" ? (...args) => {
          ports.assertCurrent(target);
          return value(...args);
        } : value;
      },
      set(target, key, value) {
        ports.assertCurrent(target);
        if (["componentType", "decoratorType"].includes(String(key)))
          return deny(`dynamic ${String(key)}; use replaceSchema`);
        return Reflect.set(target, key, value, target);
      },
      defineProperty(target, key, descriptor) {
        ports.assertCurrent(target);
        return Reflect.defineProperty(target, key, descriptor);
      },
      deleteProperty(target, key) {
        ports.assertCurrent(target);
        return Reflect.deleteProperty(target, key);
      }
    });
    proxies.set(field, proxy);
    rawFields.set(proxy, field);
    return proxy;
  };
  function readField(target, key) {
    if (key === "form") return formView;
    if (key === "getState")
      return (getter) => getter ? getter(fieldView(target)) : target.getState();
    if (key === "setState")
      return (setter) => transaction(
        () => safeView(
          target.setState(
            typeof setter === "function" ? () => setter(fieldView(target)) : cloneConfig(setter)
          )
        )
      );
    if (["parent", "arrayParent", "objectParent"].includes(String(key))) {
      const parent = Reflect.get(target, key, target);
      return parent ? fieldView(parent) : parent;
    }
    if ([
      "validate",
      "submit",
      "onInput",
      "onFocus",
      "onBlur",
      "modify",
      "inject",
      "destroy",
      "addEffects",
      "setEffects",
      "setComponent",
      "setDecorator"
    ].includes(String(key)))
      return () => deny(String(key));
    if (key === "setValue" && core.isDataField(target))
      return (value2) => transaction(() => {
        const isolated = value2 === void 0 ? void 0 : index.copy(value2);
        if (core.isArrayField(target) && Array.isArray(isolated))
          arrayTools.align(target, isolated);
        target.setValue(isolated);
      });
    if (key === "query")
      return (pattern) => queryView(target.query(pattern), target);
    const operation = arrayTools.operation(target, key);
    if (operation) return operation;
    const value = Reflect.get(target, key, target);
    return typeof value === "function" ? value.bind(target) : value;
  }
  const queryView = (query, owner) => new Proxy(query, {
    get(target, key) {
      if (owner) ports.assertCurrent(owner);
      const value = readQuery(target, key);
      return typeof value === "function" ? (...args) => {
        if (owner) ports.assertCurrent(owner);
        return value(...args);
      } : value;
    }
  });
  function readQuery(target, key) {
    if (key === "form") return formView;
    if (key === "get")
      return (name) => {
        const field = target.take();
        return field && Reflect.get(fieldView(field), name);
      };
    if (key === "getIn")
      return (...args) => {
        const value2 = target.getIn(...args);
        if (typeof value2 === "function")
          return () => deny("Query.getIn function");
        return safeView(value2);
      };
    if (key === "take")
      return (fn) => {
        const field = target.take();
        return field && (fn ? fn(fieldView(field)) : fieldView(field));
      };
    if (key === "map")
      return (fn) => target.map((field) => fn ? fn(fieldView(field)) : fieldView(field));
    if (key === "forEach")
      return (fn) => target.forEach((field) => fn(fieldView(field)));
    if (key === "reduce")
      return (fn, initial) => target.reduce((acc, field) => fn(acc, fieldView(field)), initial);
    const value = Reflect.get(target, key, target);
    return typeof value === "function" ? value.bind(target) : value;
  }
  const formView = new Proxy(form, {
    get(target, key) {
      if (key === "graph") return deny("graph; use guarded schema and values");
      if (key === "fields") return fieldsView;
      if (key === "getState" || key === "getFormState")
        return (getter) => getter ? getter(formView) : target.getState();
      if (key === "getFieldState")
        return (pattern, getter) => target.getFieldState(
          pattern,
          (field) => getter ? getter(fieldView(field)) : field.getState()
        );
      if (key === "setState" || key === "setFormState")
        return (setter) => transaction(
          () => safeView(
            target.setState(
              typeof setter === "function" ? () => setter(formView) : cloneConfig(setter)
            )
          )
        );
      if (/^(create|addEffects|setEffects|setFieldState|setFormGraph|validate|submit|reset|onInit|onMount|onUnmount|notify)/.test(
        String(key)
      ))
        return () => deny(String(key));
      if (key === "setValuesIn")
        return (path, value2) => transaction(() => {
          const isolated = value2 === void 0 ? void 0 : index.copy(value2);
          const field = target.query(path).take();
          if (field && Array.isArray(isolated) && core.isArrayField(field))
            arrayTools.align(
              field,
              isolated
            );
          target.setValuesIn(path, isolated);
        });
      if (key === "setValues")
        return (values, strategy) => transaction(() => {
          const isolated = index.copy(values);
          arrayTools.alignValues(isolated);
          target.setValues(isolated, strategy);
        });
      if (key === "query")
        return (pattern) => queryView(target.query(pattern));
      const value = Reflect.get(target, key, target);
      return typeof value === "function" ? value.bind(target) : value;
    }
  });
  const fieldsView = new Proxy(form.fields, {
    get(target, key) {
      const value = Reflect.get(target, key);
      return core.isGeneralField(value) ? fieldView(value) : value;
    },
    set() {
      return deny("fields registration");
    },
    deleteProperty() {
      return deny("fields registration");
    },
    defineProperty() {
      return deny("fields registration");
    }
  });
  function safeView(value) {
    if (value === form) return formView;
    if (value === form.fields) return fieldsView;
    if (core.isGeneralField(value)) return fieldView(value);
    if (core.isQuery(value)) return queryView(value);
    return value;
  }
  const rawField = (field) => rawFields.get(field) ?? field;
  return { fieldView, formView, rawField };
}
function createRuntime(options) {
  const version = vue.shallowRef(0);
  const faults = vue.shallowRef([]);
  const form = core.createForm({ initialValues: index.copy(options.initial) });
  const record = new AbortController();
  const recordSignal = options.recordSignal ?? record.signal;
  const resources = options.resourceHost ?? createResources(recordSignal, options.semantic);
  const resourceOwner = {};
  const configs = /* @__PURE__ */ new Map();
  const identityKeys = [...options.arrayKeys ?? []];
  let conditionalArrays = [];
  function refreshIdentityKeys() {
    const keys2 = [...options.arrayKeys ?? []];
    for (const rule of conditionalArrays) {
      let paths = [[]];
      for (const part of rule.path) {
        paths = typeof part === "string" ? paths.map((path) => [...path, part]) : paths.flatMap((path) => {
          const rows = readPath(form.values, path);
          return Array.isArray(rows) ? rows.map((_, index2) => [...path, index2]) : [];
        });
      }
      for (const path of paths)
        if (!keys2.some((item) => index.equal(item.path, path)))
          keys2.push({ path, key: rule.key });
    }
    identityKeys.splice(0, identityKeys.length, ...keys2);
  }
  const controls = /* @__PURE__ */ new Map();
  const tokens = /* @__PURE__ */ new Map();
  const disposers = [];
  const fieldDisposers = /* @__PURE__ */ new Map();
  let alive = true;
  let mounted = false;
  let configWrite = 0;
  let initializing = 0;
  let calls = 0;
  let reactionCount = 0;
  let depth = 0;
  let deriving = 0;
  let origin;
  let mutationToken;
  const inFrame = (token, work) => {
    const previous = mutationToken;
    mutationToken = token;
    try {
      return work();
    } finally {
      mutationToken = previous;
    }
  };
  const structuralFrames = /* @__PURE__ */ new Map();
  let fieldFrames = /* @__PURE__ */ new WeakMap();
  const validationControllers = /* @__PURE__ */ new Set();
  const revokeValidation = () => {
    for (const controller of validationControllers) controller.abort();
    validationControllers.clear();
  };
  const semantic = () => {
    var _a;
    revokeValidation();
    if (!mutationToken) {
      structuralFrames.clear();
      fieldFrames = /* @__PURE__ */ new WeakMap();
    }
    refreshIdentityKeys();
    (_a = options.semantic) == null ? void 0 : _a.call(options, mutationToken);
  };
  function mountToken(field) {
    const known = fieldFrames.get(field);
    if (known) return known;
    const path = field.path.toArr();
    for (const [array, frame] of structuralFrames) {
      const parent = array.path.toArr();
      if (path.length > parent.length && parent.every((part, i) => String(part) === String(path[i])) && frame.rows.has(readPath(form.values, path.slice(0, parent.length + 1)))) {
        fieldFrames.set(field, frame.token);
        return frame.token;
      }
    }
    return void 0;
  }
  let valueRevision = 0;
  let configRevision = 0;
  let editRevision = 0;
  let controlsGeneration = 0;
  let replace;
  const fault = (message, field) => reactive.untracked(() => {
    if (!alive) return;
    const path = field == null ? void 0 : field.path.toArr();
    if (!faults.value.some(
      (issue) => issue.message === message && index.equal(issue.path, path)
    ))
      faults.value = [...faults.value, { message, ...path ? { path } : {} }];
    version.value++;
  });
  const changed = () => reactive.untracked(() => {
    if (alive) version.value++;
  });
  const registered = (field) => form.fields[field.address.toString()] === field;
  const assertCurrentField = (field) => {
    if (!alive || !registered(field))
      throw new Error("Retired form field is no longer available");
  };
  const liveFields = () => [...configs.keys()].filter(registered);
  const ledger = createErrorLedger(
    {
      read: () => read(),
      fields: liveFields,
      visible: (field) => {
        var _a;
        return field.display === "visible" && ((_a = controls.get(field)) == null ? void 0 : _a.mounted) === true;
      },
      composite: (field) => {
        var _a;
        return ((_a = controls.get(field)) == null ? void 0 : _a.composite) ?? false;
      },
      active: (field) => {
        var _a;
        return ((_a = configs.get(field)) == null ? void 0 : _a.validationActive) !== false;
      },
      version: () => version.value,
      changed
    },
    identityKeys
  );
  const feedback = vue.computed(
    () => new Map(liveFields().map((field) => [field, ledger.messages(field)]))
  );
  const activeControls = () => [...controls].filter(
    ([field]) => {
      var _a;
      return registered(field) && ((_a = configs.get(field)) == null ? void 0 : _a.validationActive) !== false;
    }
  );
  function retireFields() {
    const removed = /* @__PURE__ */ new Set();
    for (const [field, stop] of fieldDisposers) {
      if (registered(field)) continue;
      stop();
      fieldDisposers.delete(field);
      fieldFrames.delete(field);
      if (core.isDataField(field)) {
        removed.add(field);
        configs.delete(field);
        controls.delete(field);
        tokens.delete(field);
        structuralFrames.delete(field);
      }
    }
    if (removed.size) {
      arrayTools.prune();
      ledger.forgetFields(removed);
      resources.prune(resourceOwner, mutationToken);
      controlsGeneration++;
      semantic();
      changed();
    }
  }
  let retirementQueued = false;
  disposers.push(
    reactive.observe(form.fields, () => {
      if (retirementQueued) return;
      retirementQueued = true;
      queueMicrotask(() => {
        retirementQueued = false;
        if (alive) retireFields();
      });
    })
  );
  const ticket = () => `${valueRevision}/${configRevision}/${editRevision}/${controlsGeneration}`;
  const current = (stamp) => alive && stamp === ticket();
  const failWrite = (message) => fault(message);
  const read = () => {
    version.value;
    return reactive.untracked(() => {
      const snapshot = JSON.parse(JSON.stringify(form.values));
      index.safeJson(snapshot, "$", false);
      return snapshot;
    });
  };
  const observeValues = () => reactive.observe(
    form.values,
    () => {
      valueRevision++;
      semantic();
      changed();
    },
    true
  );
  let stopValues = observeValues();
  disposers.push(
    () => stopValues(),
    reactive.observe(form, (change) => {
      if (["pattern", "display"].includes(String(change.key))) {
        configRevision++;
        semantic();
        changed();
      }
      if (change.key === "values") {
        stopValues();
        stopValues = observeValues();
        valueRevision++;
        semantic();
        changed();
      }
    })
  );
  const transaction = (work, source) => {
    const previousOrigin = origin;
    origin = source ?? previousOrigin ?? (deriving ? "reaction" : "edit");
    if (!alive) throw new Error("Disposed form runtime");
    if (!depth && !deriving) calls = 0;
    depth++;
    try {
      return reactive.batch(work);
    } finally {
      depth--;
      if (!depth && !deriving) retireFields();
      changed();
      origin = previousOrigin;
    }
  };
  const arrayTools = createArrays({
    form,
    keys: identityKeys,
    assertCurrent: assertCurrentField,
    transaction,
    validate: (field) => mutationToken ? Promise.resolve(true) : validateField(field, "onInput")
  });
  const validationIds = /* @__PURE__ */ new WeakMap();
  let nextValidationId = 0;
  const validationId = (field) => {
    if (!validationIds.has(field)) validationIds.set(field, ++nextValidationId);
    return String(validationIds.get(field));
  };
  const deny = (name) => {
    fault(`Unsupported native registration/validation entry: ${name}`);
    throw new Error(`Use the schema/session boundary instead of ${name}`);
  };
  const { fieldView, formView, rawField } = createModelBoundary({
    form,
    arrays: arrayTools,
    transaction,
    deny,
    assertCurrent: assertCurrentField
  });
  const currentResourceField = (input2) => {
    const field = rawField(input2);
    assertCurrentField(field);
    return field;
  };
  function configure(input2, patch) {
    const field = rawField(input2);
    if (field.form === form) assertCurrentField(field);
    if (field.form !== form || !configs.has(field))
      return deny("configure foreign/uncompiled field");
    transaction(
      () => reactive.untracked(() => {
        var _a;
        configRevision++;
        semantic();
        const previous = configs.get(field);
        const next = { ...previous, ...cloneConfig(patch) };
        const dataSourceProp = typeof field.componentType === "string" ? (_a = options.dataSourceProps) == null ? void 0 : _a[field.componentType] : void 0;
        if (dataSourceProp && next.componentProps) {
          if (patch.dataSource === void 0 && Object.hasOwn(patch.componentProps ?? {}, dataSourceProp)) {
            const input22 = next.componentProps[dataSourceProp];
            if (!Array.isArray(input22))
              throw new TypeError(
                "Mapped options must be an array; load options with runLatest"
              );
            next.dataSource = input22;
          }
          const { [dataSourceProp]: _options, ...props } = next.componentProps;
          next.componentProps = props;
        }
        const descriptions = validator.parseValidatorDescriptions(next.validator ?? []);
        if (patch.required !== void 0 || previous.required !== void 0) {
          next.validator = descriptions.map((rule) => ({
            ...rule,
            required: void 0
          }));
          if (next.required)
            next.validator.unshift({ required: true });
        }
        const protectedConfig = immutable(
          cloneConfig(next),
          (message) => fault(message, field)
        );
        configs.set(field, protectedConfig);
        configWrite++;
        try {
          field.setValidator(protectedConfig.validator ?? []);
          field.setDataSource(protectedConfig.dataSource ?? []);
          field.componentProps = protectedConfig.componentProps ?? {};
        } finally {
          configWrite--;
        }
        tokens.set(field, (tokens.get(field) ?? 0) + 1);
        if (patch.validationActive === false || patch.validator !== void 0 || patch.required !== void 0)
          ledger.clearValidation(validationId(field));
      }),
      deriving ? "reaction" : "config"
    );
  }
  const compiledFields = /* @__PURE__ */ new WeakSet();
  const observedLayouts = /* @__PURE__ */ new WeakSet();
  function initialize(field, config, array = false) {
    compiledFields.add(field);
    if (!core.isDataField(field) && !observedLayouts.has(field)) {
      observedLayouts.add(field);
      fieldDisposers.set(
        field,
        reactive.observe(field, (change) => {
          if (!registered(field)) return;
          if (["selfDisplay", "selfPattern"].includes(String(change.key))) {
            configRevision++;
            semantic();
            changed();
          }
        })
      );
    }
    if (!core.isDataField(field) || configs.has(field)) return;
    configs.set(field, {});
    if (array) arrayTools.install(field);
    initializing++;
    try {
      inFrame(mountToken(field), () => configure(field, config));
    } finally {
      initializing--;
    }
    fieldDisposers.set(
      field,
      reactive.observe(field, (change) => {
        if (!registered(field)) return;
        const key = String(change.key);
        if ([
          "validator",
          "dataSource",
          "componentProps",
          "componentType",
          "decoratorType"
        ].includes(key)) {
          if (!configWrite)
            fault(`Configuration bypass: ${key}; use configure`, field);
        }
        if (["selfDisplay", "selfPattern"].includes(key)) {
          configRevision++;
          semantic();
          changed();
        }
      })
    );
  }
  function guard(fn) {
    reactionCount++;
    return (field) => {
      if (!alive || faults.value.length) return;
      calls++;
      if (calls > (options.reactionBudget ?? Math.max(1e4, reactionCount * 100))) {
        fault("Reaction activity budget exhausted", field);
        return;
      }
      deriving++;
      try {
        const result = inFrame(
          mutationToken ?? mountToken(field),
          () => fn(fieldView(field))
        );
        if (result && typeof result.then === "function") {
          fault(
            "A synchronous reaction returned a thenable; use runLatest",
            field
          );
          Promise.resolve(result).catch(() => {
          });
        }
      } catch (error) {
        fault(error instanceof Error ? error.message : "Reaction failed", field);
      } finally {
        deriving--;
      }
    };
  }
  const schemaConfigs = /* @__PURE__ */ new WeakMap();
  function compile(node) {
    var _a, _b;
    const checkStrings = (value, seen = /* @__PURE__ */ new WeakSet()) => {
      if (typeof value === "string" && value.includes("{{"))
        throw new Error(
          "String expressions are outside the trusted TypeScript schema profile"
        );
      if (!value || typeof value !== "object" || seen.has(value)) return;
      seen.add(value);
      for (const item of Object.values(value)) checkStrings(item, seen);
    };
    checkStrings(node);
    const next = { ...node };
    const contextReference = parseAIContextReference(node["x-ai-context"]);
    if (contextReference) {
      if (node.type === "void" || !node["x-component"])
        throw new Error("AI context requires a data field");
      next["x-ai-context"] = contextReference;
    }
    const decorator = node["x-decorator"];
    if (decorator && options.components && (typeof decorator !== "string" || !options.components.includes(decorator)))
      throw new Error(`Unregistered schema decorator: ${String(decorator)}`);
    const component = node["x-component"];
    if (component && options.components && (typeof component !== "string" || !options.components.includes(component)))
      throw new Error(`Unregistered schema component: ${String(component)}`);
    const reactions = node["x-reactions"];
    if (reactions !== void 0 && (Array.isArray(reactions) ? reactions : [reactions]).some(
      (fn) => typeof fn !== "function"
    ))
      throw new Error("Only native TypeScript function reactions are supported");
    const dataSourceProp = typeof component === "string" ? (_a = options.dataSourceProps) == null ? void 0 : _a[component] : void 0;
    const initialOptions = (_b = node["x-component-props"]) == null ? void 0 : _b[dataSourceProp ?? "options"];
    if (dataSourceProp && initialOptions !== void 0 && !Array.isArray(initialOptions))
      throw new TypeError(
        "Mapped options must be an array; load options with runLatest"
      );
    const config = {
      ...node.required !== void 0 ? { required: !!node.required } : {},
      validator: node["x-validator"] ?? [],
      componentProps: node["x-component-props"] ?? {},
      dataSource: Array.isArray(initialOptions) ? initialOptions : [],
      validationActive: true
    };
    schemaConfigs.set(next, config);
    delete next.required;
    delete next["x-validator"];
    if (node.type !== "void") delete next["x-component-props"];
    next["x-reactions"] = [
      (field) => reactive.untracked(() => initialize(field, config, node.type === "array")),
      ...reactions ? (Array.isArray(reactions) ? reactions : [reactions]).map(
        (fn) => guard(fn)
      ) : []
    ];
    if (node.properties)
      next.properties = Object.fromEntries(
        Object.entries(node.properties).map(([key, child]) => {
          if (["__proto__", "constructor", "prototype"].includes(key))
            throw new Error("Unsafe schema path");
          return [key, compile(child)];
        })
      );
    if (node.items)
      next.items = Array.isArray(node.items) ? node.items.map(compile) : compile(node.items);
    return next;
  }
  function states() {
    return liveFields().map((field) => {
      var _a, _b, _c, _d;
      return {
        path: dataPath(field.path.toArr(), form.values),
        address: field.address.toString(),
        required: field.required,
        display: field.display,
        pattern: field.pattern,
        validator: cloneConfig(((_a = configs.get(field)) == null ? void 0 : _a.validator) ?? []),
        dataSource: cloneConfig(((_b = configs.get(field)) == null ? void 0 : _b.dataSource) ?? []),
        componentProps: cloneConfig(((_c = configs.get(field)) == null ? void 0 : _c.componentProps) ?? {}),
        validationActive: ((_d = configs.get(field)) == null ? void 0 : _d.validationActive) !== false
      };
    });
  }
  function assert() {
    var _a;
    if (!alive || faults.value.length) return false;
    if (form.query("*").map().some((field) => !compiledFields.has(field))) {
      fault("Uncompiled field registration bypassed the schema boundary");
      return false;
    }
    if (reactionCount && !options.assertSettled) {
      fault("A schema with reactions requires assertSettled");
      return false;
    }
    const stamp = ticket();
    try {
      const issues = ((_a = options.assertSettled) == null ? void 0 : _a.call(
        options,
        immutable(read(), failWrite),
        immutable(states(), failWrite)
      )) ?? [];
      if (!Array.isArray(issues)) {
        if (issues && typeof issues.then === "function")
          Promise.resolve(issues).catch(() => {
          });
        throw new Error("assertSettled must synchronously return issues");
      }
      if (!current(stamp))
        throw new Error("assertSettled changed its save domain");
      assertionIssues.value = issues.map((issue) => ({
        ...issue,
        path: issue.path && [...issue.path]
      }));
      return !issues.length;
    } catch (error) {
      fault(error instanceof Error ? error.message : "assertSettled failed");
      return false;
    }
  }
  const assertionIssues = vue.shallowRef([]);
  const controlValidations = vue.shallowRef(0);
  async function validateField(field, triggerType, captured) {
    var _a, _b;
    if (!alive || ((_a = configs.get(field)) == null ? void 0 : _a.validationActive) === false) return true;
    const rules = (captured == null ? void 0 : captured.rules) ?? cloneConfig(((_b = configs.get(field)) == null ? void 0 : _b.validator) ?? []);
    const groups = /* @__PURE__ */ new Map();
    for (const description of validator.parseValidatorDescriptions(rules)) {
      const trigger = description.triggerType ?? "onInput";
      if (triggerType && trigger !== triggerType) continue;
      groups.set(trigger, [
        ...groups.get(trigger) ?? [],
        description
      ]);
    }
    if (!groups.size) return true;
    const token = (tokens.get(field) ?? 0) + 1;
    tokens.set(field, token);
    const stamp = (captured == null ? void 0 : captured.stamp) ?? ticket();
    const value = captured ? captured.value : cloneConfig(field.value);
    const results = await Promise.all(
      [...groups].map(async ([trigger, selected]) => {
        let issues;
        try {
          let failed = false;
          const checked = (captured == null ? void 0 : captured.propagateErrors) ? validator.parseValidatorDescriptions(selected).map((rule) => {
            if (typeof rule.pattern === "string") new RegExp(rule.pattern);
            const validator2 = rule.validator;
            return typeof validator2 === "function" ? {
              ...rule,
              validator: async (...args) => {
                try {
                  return await validator2(...args);
                } catch {
                  failed = true;
                  return false;
                }
              }
            } : rule;
          }) : selected;
          const result = await validator.validate(value, checked, {
            context: { field: fieldView(field), form: formView }
          });
          if (failed) throw new Error("Conditional validation failed");
          issues = [
            ...[...new Set(result.error ?? [])].map((message) => ({
              path: dataPath(field.path.toArr(), form.values),
              message,
              severity: "error"
            })),
            ...[...new Set(result.warning ?? [])].map((message) => ({
              path: dataPath(field.path.toArr(), form.values),
              message,
              severity: "warning"
            })),
            ...[...new Set(result.success ?? [])].map((message) => ({
              path: dataPath(field.path.toArr(), form.values),
              message,
              severity: "info"
            }))
          ];
        } catch (error) {
          if (captured == null ? void 0 : captured.propagateErrors) throw error;
          issues = [
            {
              path: dataPath(field.path.toArr(), form.values),
              message: error instanceof Error ? error.message : "Validation failed"
            }
          ];
        }
        return { trigger, issues };
      })
    );
    const ownsFeedback = () => {
      var _a2;
      return current(stamp) && tokens.get(field) === token && ((_a2 = captured == null ? void 0 : captured.owns) == null ? void 0 : _a2.call(captured)) !== false;
    };
    if (!ownsFeedback()) return false;
    const updates = results.map(({ trigger, issues }) => ({
      code: `SessionValidation:${validationId(field)}:${trigger}`,
      issues
    }));
    if (captured == null ? void 0 : captured.collect) captured.collect(updates, ownsFeedback);
    else ledger.setMany(updates);
    return !results.some(
      (result) => result.issues.some((issue) => (issue.severity ?? "error") === "error")
    );
  }
  async function validate(owns = () => true, propagateErrors = false, signal) {
    var _a, _b;
    if (!owns() || !assert()) return false;
    const stamp = ticket();
    const values = read();
    const captured = [...configs].filter(
      ([field, config]) => registered(field) && config.validationActive !== false
    ).map(([field]) => {
      var _a2;
      return {
        field,
        value: cloneConfig(field.value),
        rules: cloneConfig(((_a2 = configs.get(field)) == null ? void 0 : _a2.validator) ?? [])
      };
    });
    revokeValidation();
    for (const [field, item] of activeControls().filter(
      ([, item2]) => item2.mounted
    )) {
      let valid;
      const controller = new AbortController();
      const abort = () => controller.abort();
      signal == null ? void 0 : signal.addEventListener("abort", abort, { once: true });
      if (signal == null ? void 0 : signal.aborted) controller.abort();
      validationControllers.add(controller);
      const currentValidation = () => !controller.signal.aborted && validationControllers.has(controller) && owns() && current(stamp) && controls.get(field) === item && item.mounted;
      controlValidations.value++;
      try {
        if (!currentValidation()) return false;
        valid = await ((_b = (_a = item.control).validate) == null ? void 0 : _b.call(
          _a,
          Object.freeze({
            signal: controller.signal,
            current: currentValidation,
            commit(update) {
              if (!currentValidation()) return false;
              update();
              return true;
            }
          })
        ));
      } finally {
        signal == null ? void 0 : signal.removeEventListener("abort", abort);
        validationControllers.delete(controller);
        controller.abort();
        controlValidations.value--;
      }
      if (valid === false || !current(stamp) || !owns()) return false;
    }
    if (activeControls().some(([, item]) => {
      var _a2;
      return (_a2 = item.state.blocking) == null ? void 0 : _a2.length;
    }))
      return false;
    const feedback2 = [];
    const results = await Promise.all(
      captured.map(
        ({ field, value, rules }) => validateField(field, void 0, {
          value,
          rules,
          stamp,
          owns,
          propagateErrors,
          collect: (updates, current2) => feedback2.push({ updates, current: current2 })
        })
      )
    );
    if (!owns() || !current(stamp) || feedback2.some((item) => !item.current()))
      return false;
    ledger.setMany(
      feedback2.flatMap((item) => item.updates),
      values
    );
    return owns() && current(stamp) && results.every(Boolean) && assert() && index.equal(values, read());
  }
  function register(field, control, composite = false, editObservation, validationOwnership) {
    const previous = controls.get(field);
    const item = {
      control,
      state: {
        pending: (previous == null ? void 0 : previous.state.pending) ?? false,
        blocking: (previous == null ? void 0 : previous.state.blocking) ?? [],
        ...editObservation === "raw-sequence" ? { editSequence: 0 } : {}
      },
      composite,
      editObservation,
      validationOwnership,
      mounted: true,
      draft: previous == null ? void 0 : previous.draft
    };
    let disposed = false;
    inFrame(
      mountToken(field),
      () => transaction(() => {
        controls.set(field, item);
        controlsGeneration++;
        semantic();
        changed();
      }, "control")
    );
    return {
      restore() {
        var _a;
        if (!disposed && item.draft !== void 0)
          (_a = control.restoreEdit) == null ? void 0 : _a.call(control, item.draft);
      },
      report(state) {
        if (disposed || !alive || controls.get(field) !== item) return;
        const normalized = {
          pending: !!state.pending,
          blocking: cloneConfig(state.blocking ?? []),
          ...state.editSequence !== void 0 ? { editSequence: state.editSequence } : {}
        };
        if (state.editSequence !== void 0 && (!Number.isSafeInteger(state.editSequence) || state.editSequence < (item.state.editSequence ?? 0))) {
          fault("Invalid raw edit sequence", field);
          return;
        }
        const same = index.equal(
          { ...item.state, editSequence: item.state.editSequence ?? 0 },
          { ...normalized, editSequence: normalized.editSequence ?? 0 }
        );
        const semanticChanged = (item.state.editSequence ?? 0) !== (normalized.editSequence ?? 0) || !index.equal(item.state.blocking ?? [], normalized.blocking ?? []);
        item.state = normalized;
        if (same) return;
        if (semanticChanged) {
          editRevision++;
          inFrame(void 0, semantic);
        }
        changed();
      },
      dispose() {
        var _a;
        if (disposed || !alive || controls.get(field) !== item) return;
        const hiding = field.display !== "visible" && !field.destroyed;
        const draft = hiding ? (_a = control.captureEdit) == null ? void 0 : _a.call(control) : void 0;
        disposed = true;
        inFrame(
          mountToken(field),
          () => transaction(() => {
            if (hiding) {
              item.draft = draft;
              item.mounted = false;
            } else controls.delete(field);
            controlsGeneration++;
            semantic();
            resources.prune(resourceOwner, mutationToken);
            changed();
          }, "control")
        );
      }
    };
  }
  const context = {
    form: formView,
    read,
    signal: () => recordSignal,
    bindResource(source, project2, settings) {
      if (!alive) return () => {
      };
      const scope = (settings == null ? void 0 : settings.scope) && typeof settings.scope === "object" ? currentResourceField(settings.scope) : void 0;
      return resources.bindResource(
        resourceOwner,
        source,
        (value) => inFrame(
          void 0,
          () => transaction(() => {
            try {
              const result = project2(value);
              if (result && typeof result.then === "function") {
                Promise.resolve(result).catch(() => {
                });
                fault("Resource projections must be synchronous");
              }
            } catch (error) {
              fault(
                error instanceof Error ? error.message : "Resource projection failed"
              );
            }
          }, "config")
        ),
        () => {
          var _a;
          return !scope || !scope.destroyed && form.query(scope.address).take() === scope && ((_a = configs.get(scope)) == null ? void 0 : _a.validationActive) !== false;
        }
      );
    },
    runLatest(key, input2, load, commit, settings) {
      if (!alive) return;
      const scope = (settings == null ? void 0 : settings.scope) && typeof settings.scope === "object" ? currentResourceField(settings.scope) : settings == null ? void 0 : settings.scope;
      const token = mutationToken;
      resources.runLatest(
        resourceOwner,
        key,
        input2,
        load,
        (value) => transaction(() => {
          const before = valueRevision;
          const result = commit(value);
          if (result && typeof result.then === "function") {
            Promise.resolve(result).catch(() => {
            });
            fault("Task commits must be synchronous");
          }
          if (!(settings == null ? void 0 : settings.blocking) && before !== valueRevision)
            fault("A non-blocking task changed submission values");
        }, "config"),
        { ...settings, scope },
        () => {
          var _a;
          return typeof scope !== "object" || !scope.destroyed && form.query(scope.address).take() === scope && ((_a = configs.get(scope)) == null ? void 0 : _a.validationActive) !== false;
        },
        {
          token,
          run: (work) => inFrame(token, work),
          identity: [load, commit, scope]
        }
      );
    },
    retryLatest: (key, scope) => {
      if (alive)
        resources.retry(
          key,
          typeof scope === "object" ? currentResourceField(scope) : scope
        );
    },
    cancelLatest: (key, scope, applicable) => {
      if (alive)
        resources.cancel(
          key,
          typeof scope === "object" ? currentResourceField(scope) : scope,
          applicable
        );
    },
    configure,
    replaceSchema(schema) {
      if (!alive) return;
      if (!replace) return deny("replaceSchema before attachment");
      const compiled = compile(schema);
      replace(schema);
      transaction(() => {
        form.clearFormGraph("*", false);
        resources.prune(resourceOwner, mutationToken);
        configs.clear();
        controls.clear();
        configRevision++;
        semantic();
        controlsGeneration++;
        semantic();
        ledger.clear();
        schemaRef.value = compiled;
        schemaSerial.value++;
      });
    }
  };
  const schemaSerial = vue.shallowRef(0);
  const schemaRef = vue.shallowRef(compile(options.createSchema(context)));
  function prospectiveAvailable(path) {
    function visit(node, offset, allowed) {
      var _a;
      const props = ((_a = schemaConfigs.get(node)) == null ? void 0 : _a.componentProps) ?? {};
      allowed && (allowed = fieldInteraction(
        node["x-pattern"] ?? "editable",
        props
      ).writable);
      if (offset === path.length && node.type !== "void") return allowed;
      if (node.type === "array" && typeof path[offset] === "number") {
        const item = Array.isArray(node.items) ? node.items[path[offset]] : node.items;
        return !!item && visit(item, offset + 1, allowed);
      }
      return Object.entries(node.properties ?? {}).some(
        ([key, child]) => child.type === "void" ? visit(child, offset, allowed) : key === path[offset] && visit(child, offset + 1, allowed)
      );
    }
    return visit(schemaRef.value, 0, true);
  }
  function materializeRows(array) {
    var _a;
    let node = new vue$1.Schema(schemaRef.value);
    for (const part of array.address.toArr()) {
      const next = node.type === "array" ? Array.isArray(node.items) ? node.items[Number(part)] : node.items : (_a = node.properties) == null ? void 0 : _a[part];
      if (!next) throw new Error("Array schema unavailable");
      node = next;
    }
    function create(node2, name, basePath) {
      const props = { ...node2.toFieldProps(), name, basePath };
      const field = node2.type === "object" ? form.createObjectField(props) : node2.type === "array" ? form.createArrayField(props) : node2.type === "void" ? form.createVoidField(props) : form.createField(props);
      if (node2.type === "array") {
        const rows = field.value;
        if (Array.isArray(rows))
          rows.forEach((_, index2) => {
            const item = Array.isArray(node2.items) ? node2.items[index2] : node2.items;
            if (item) create(item, index2, field.address);
          });
      } else
        for (const [key, child] of Object.entries(node2.properties ?? {}))
          create(child, key, field.address);
    }
    if (Array.isArray(array.value))
      array.value.forEach((_, index2) => {
        const item = Array.isArray(node.items) ? node.items[index2] : node.items;
        if (item) create(item, index2, array.address);
      });
  }
  return {
    form,
    get schema() {
      return schemaRef.value;
    },
    get schemaSerial() {
      return schemaSerial.value;
    },
    context,
    version,
    faults,
    feedback,
    ledger,
    resources,
    flushResources: () => resources.refresh(resourceOwner),
    assertionIssues,
    controls,
    controlValidations,
    activeControls,
    arrayKeys: arrayTools.renderKeys,
    get initializing() {
      return initializing > 0;
    },
    get mutating() {
      return depth > 0 || deriving > 0;
    },
    get deriving() {
      return !!deriving;
    },
    get origin() {
      return origin ?? (deriving ? "reaction" : mounted ? "edit" : "initialization");
    },
    replaceCanonical(values) {
      return transaction(
        () => form.setValues(index.copy(values), "overwrite"),
        "authority"
      );
    },
    read,
    ticket,
    current,
    transaction,
    inFrame,
    liveFields,
    prospectiveAvailable,
    setConditionalArrays(rules) {
      conditionalArrays = rules;
      refreshIdentityKeys();
    },
    conditionalWrite(action, token) {
      return inFrame(token, () => {
        let array;
        transaction(() => {
          const field = liveFields().find(
            (field2) => index.equal(dataPath(field2.path.toArr(), form.values), action.path)
          );
          if (action.change.kind === "set" || action.change.kind === "clear") {
            if (action.value === void 0)
              form.deleteValuesIn([...action.path]);
            else if (field) field.setValue(action.value);
            else throw new Error("Field model unavailable");
          } else {
            if (!field) throw new Error("Array model unavailable");
            array = field;
            const method = action.change.kind === "arrayInsert" ? "insert" : action.change.kind === "arrayRemove" ? "remove" : "move";
            const operation = arrayTools.operation(field, method);
            if (!operation) throw new Error("Array model unavailable");
            for (const existing of liveFields())
              if (existing.path.toArr().slice(0, field.path.length).every(
                (part, i) => String(part) === String(field.path.toArr()[i])
              ))
                fieldFrames.set(existing, token);
            const result = operation(
              ...method === "insert" ? [action.index, action.value] : method === "remove" ? [action.index] : [action.index, action.to]
            );
            const frame = { token, rows: new Set(field.value) };
            structuralFrames.set(field, frame);
            vue.nextTick(() => {
              if (structuralFrames.get(field) === frame)
                structuralFrames.delete(field);
              fieldFrames = /* @__PURE__ */ new WeakMap();
            });
            if (result && typeof result.then === "function")
              Promise.resolve(result).catch(() => fault("Array write failed"));
          }
        });
        if (array) materializeRows(array);
      });
    },
    configure,
    assert,
    states,
    validate,
    validateField,
    register,
    setValues(patch) {
      return inFrame(
        void 0,
        () => transaction(() => {
          const isolated = index.copy(patch);
          arrayTools.alignValues({ ...read(), ...isolated });
          form.setValues(isolated, "shallowMerge");
          resources.prune(resourceOwner, mutationToken);
        })
      );
    },
    event(field, type, value) {
      if (!alive) return Promise.resolve(false);
      inFrame(
        void 0,
        () => transaction(() => {
          if (type === "change") {
            const isolated = value === void 0 ? void 0 : index.copy(value);
            if (Array.isArray(isolated))
              arrayTools.align(
                field,
                isolated
              );
            field.setValue(isolated);
          } else field.setState({ active: type === "focus", visited: true });
        }, "edit")
      );
      return validateField(
        field,
        type === "change" ? "onInput" : type === "blur" ? "onBlur" : "onFocus"
      );
    },
    mount() {
      mounted = true;
    },
    attachReplace(callback) {
      replace = callback;
    },
    dispose() {
      revokeValidation();
      if (!alive) return;
      alive = false;
      resources.retire(resourceOwner);
      record.abort();
      disposers.forEach((dispose) => dispose());
      fieldDisposers.forEach((dispose) => dispose());
      fieldDisposers.clear();
      configs.clear();
      controls.clear();
      tokens.clear();
      form.onUnmount();
    }
  };
}
const limits = Object.freeze({
  actions: 64,
  addressDepth: 32,
  planBytes: 256 * 1024,
  domainBytes: 1024 * 1024,
  outputBytes: 256 * 1024,
  observations: 16,
  candidates: 8,
  operations: 32,
  observationMs: 6e4,
  candidateMs: 3e5,
  retentionMs: 6e5,
  retainedBytes: 8 * 1024 * 1024,
  verificationMs: 3e4,
  waiters: 16,
  waitMs: 3e4,
  maxWaitMs: 6e4
});
class ConditionalError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "ConditionalError";
  }
}
const reject = (code) => {
  throw new ConditionalError(code);
};
const safeKey = (key) => !["__proto__", "prototype", "constructor"].includes(key);
const bytes = (value) => new TextEncoder().encode(JSON.stringify(value)).byteLength;
function freeze(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}
function jsonCopy(value, budget = limits.domainBytes) {
  let cost = 0;
  const seen = /* @__PURE__ */ new Set();
  function visit(input2, depth) {
    if (depth > limits.addressDepth) return reject("depth-limit");
    cost += 4;
    if (cost > budget) return reject("byte-limit");
    if (input2 === null || typeof input2 === "boolean") return input2;
    if (typeof input2 === "string") {
      cost += new TextEncoder().encode(input2).length;
      if (cost > budget) return reject("byte-limit");
      return input2;
    }
    if (typeof input2 === "number" && Number.isFinite(input2)) return input2;
    if (!input2 || typeof input2 !== "object") return reject("unsafe-json");
    const proto = Object.getPrototypeOf(input2);
    if (Array.isArray(input2) ? proto !== Array.prototype : proto !== Object.prototype && proto !== null)
      return reject("unsafe-json");
    if (seen.has(input2)) return reject("unsafe-json");
    seen.add(input2);
    const descriptors = Object.getOwnPropertyDescriptors(input2);
    if (Reflect.ownKeys(input2).some((key) => typeof key !== "string"))
      return reject("unsafe-json");
    const output2 = Array.isArray(input2) ? [] : {};
    for (const [key, descriptor] of Object.entries(descriptors)) {
      if (Array.isArray(input2) && key === "length") continue;
      if (!safeKey(key) || !("value" in descriptor) || !descriptor.enumerable)
        return reject("unsafe-json");
      if (Array.isArray(input2) && !/^(0|[1-9]\d*)$/.test(key))
        return reject("unsafe-json");
      cost += new TextEncoder().encode(key).length + 3;
      output2[key] = visit(
        descriptor.value,
        depth + 1
      );
    }
    if (Array.isArray(input2) && Object.keys(output2).length !== input2.length)
      return reject("unsafe-json");
    seen.delete(input2);
    return output2;
  }
  const output = visit(value, 0);
  if (bytes(output) > budget) return reject("byte-limit");
  return output;
}
function project(value, grant) {
  if (grant.kind === "none") return void 0;
  if (grant.kind === "all") return jsonCopy(value);
  if (grant.kind === "array") {
    if (!Array.isArray(value) || grant.items.kind === "none") return void 0;
    const children = value.map((item) => project(item, grant.items));
    return children.includes(void 0) ? void 0 : children;
  }
  if (!value || Array.isArray(value) || typeof value !== "object")
    return void 0;
  const output = {};
  for (const [key, child] of Object.entries(grant.properties)) {
    if (!Object.hasOwn(value, key)) continue;
    const projected = project(value[key], child);
    if (projected !== void 0) output[key] = projected;
  }
  return output;
}
function visibleValue(present, value, grant) {
  if (grant.kind === "none") return void 0;
  if (!present) return { present: false };
  const selected = project(value, grant);
  return selected === void 0 ? void 0 : { present: true, value: selected };
}
function matches(value, shape) {
  switch (shape.type) {
    case "null":
      return value === null;
    case "boolean":
      return typeof value === "boolean";
    case "enum":
      return shape.values.some((item) => index.equal(item, value));
    case "number":
      return typeof value === "number" && Number.isFinite(value) && (!shape.integer || Number.isInteger(value)) && (shape.minimum === void 0 || value >= shape.minimum) && (shape.maximum === void 0 || value <= shape.maximum);
    case "string":
      return typeof value === "string" && (shape.minLength === void 0 || value.length >= shape.minLength) && (shape.maxLength === void 0 || value.length <= shape.maxLength);
    case "array":
      return Array.isArray(value) && (shape.minItems === void 0 || value.length >= shape.minItems) && (shape.maxItems === void 0 || value.length <= shape.maxItems) && value.every((item) => matches(item, shape.items));
    case "object":
      return !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).every(
        (key) => Object.hasOwn(shape.properties, key) && matches(value[key], shape.properties[key])
      ) && (shape.required ?? []).every((key) => Object.hasOwn(value, key));
    default:
      return false;
  }
}
function validShape(shape) {
  if (!shape || typeof shape !== "object") return false;
  const allowed = {
    null: [],
    boolean: [],
    number: ["minimum", "maximum", "integer"],
    string: ["minLength", "maxLength"],
    array: ["items", "minItems", "maxItems"],
    object: ["properties", "required"],
    enum: ["values"]
  };
  if (!Object.hasOwn(allowed, shape.type) || Object.keys(shape).some(
    (key) => key !== "type" && !allowed[shape.type].includes(key)
  ))
    return false;
  const record = (value) => !!value && typeof value === "object" && !Array.isArray(value);
  const range = (min, max, integer) => [min, max].every(
    (value) => value === void 0 || typeof value === "number" && Number.isFinite(value) && (!integer || Number.isInteger(value) && value >= 0)
  ) && (min === void 0 || max === void 0 || min <= max);
  if (shape.type === "array")
    return validShape(shape.items) && range(shape.minItems, shape.maxItems, true);
  if (shape.type === "object")
    return record(shape.properties) && Object.values(shape.properties).every(validShape) && (shape.required === void 0 || Array.isArray(shape.required)) && (shape.required ?? []).every(
      (key) => typeof key === "string" && Object.hasOwn(shape.properties, key)
    );
  if (shape.type === "enum")
    return Array.isArray(shape.values) && shape.values.length > 0;
  if (shape.type === "string")
    return range(shape.minLength, shape.maxLength, true);
  if (shape.type === "number")
    return range(shape.minimum, shape.maximum, false) && (shape.integer === void 0 || typeof shape.integer === "boolean");
  return Object.entries(shape).every(
    ([key, value]) => key === "type" || (key === "integer" ? typeof value === "boolean" : typeof value === "number" && Number.isFinite(value))
  );
}
function validGrant(grant) {
  if (!grant || typeof grant !== "object") return false;
  if (grant.kind === "all" || grant.kind === "none")
    return Object.keys(grant).length === 1;
  if (grant.kind === "array")
    return Object.keys(grant).length === 2 && validGrant(grant.items);
  if (grant.kind === "object")
    return Object.keys(grant).length === 2 && !!grant.properties && typeof grant.properties === "object" && !Array.isArray(grant.properties) && Object.values(grant.properties).every(validGrant);
  return false;
}
const pathKey = (path) => JSON.stringify(
  path.map((part) => typeof part === "string" ? part : { row: true })
);
const prefix = (a, b) => a.length < b.length && a.every((part, i) => index.equal(part, b[i]));
const validPath = (path) => Array.isArray(path) && path.length > 0 && path.length <= 32 && path.every(
  (part) => typeof part === "string" ? !!part && safeKey(part) : !!part && Object.keys(part).length === 1 && part.row === true
);
function schemaNodes(schema) {
  const nodes = /* @__PURE__ */ new Map();
  function visit(node, path) {
    if (path.length && node.type !== "void") nodes.set(pathKey(path), node);
    for (const [key, child] of Object.entries(node.properties ?? {}))
      visit(child, child.type === "void" ? path : [...path, key]);
    if (node.items && !Array.isArray(node.items))
      visit(node.items, [...path, { row: true }]);
  }
  visit(schema, []);
  return nodes;
}
function installPolicy(input2, schema, keys2) {
  var _a, _b, _c;
  if (!input2) return void 0;
  try {
    const descriptor = Object.getOwnPropertyDescriptors(input2);
    if (Object.keys(descriptor).some(
      (key) => !["fields", "arrays", "authorizeApply"].includes(key) || !("value" in descriptor[key])
    ))
      return void 0;
    const authorize = (_a = descriptor.authorizeApply) == null ? void 0 : _a.value;
    if (authorize !== void 0 && typeof authorize !== "function")
      return void 0;
    const data = jsonCopy({
      fields: (_b = descriptor.fields) == null ? void 0 : _b.value,
      arrays: (_c = descriptor.arrays) == null ? void 0 : _c.value
    });
    if (!Array.isArray(data.fields) || !Array.isArray(data.arrays))
      return void 0;
    const nodes = schemaNodes(schema);
    const fieldValid = (rule) => validPath(rule.path) && typeof rule.describe === "boolean" && typeof rule.write === "boolean" && typeof rule.atomic === "boolean" && validGrant(rule.read) && validShape(rule.shape) && (!rule.clear || rule.clear.kind === "remove" && Object.keys(rule.clear).length === 1 || rule.clear.kind === "value" && Object.keys(rule.clear).length === 2 && matches(rule.clear.value, rule.shape)) && Object.keys(rule).every(
      (key) => [
        "path",
        "describe",
        "read",
        "write",
        "atomic",
        "shape",
        "clear"
      ].includes(key)
    );
    const paths = /* @__PURE__ */ new Set();
    const shapeFits = (rule, node) => {
      if (!rule.atomic && ["object", "array"].includes(rule.shape.type))
        return false;
      if (rule.shape.type === "enum")
        return rule.shape.values.every((value) => {
          const type = value === null ? "null" : Array.isArray(value) ? "array" : typeof value;
          return (!node.type || node.type === type) && (rule.atomic || !["object", "array"].includes(type));
        });
      return !node.type || node.type === rule.shape.type;
    };
    for (const rule of data.fields) {
      const node = nodes.get(pathKey(rule.path));
      if (!fieldValid(rule) || !node || paths.has(pathKey(rule.path)))
        return void 0;
      if (rule.write && (node.properties || node.items)) return void 0;
      if (!shapeFits(rule, node)) return void 0;
      paths.add(pathKey(rule.path));
    }
    for (const rule of data.arrays) {
      if (rule.defaults !== void 0 && (!rule.defaults || typeof rule.defaults !== "object" || Array.isArray(rule.defaults)))
        return void 0;
      const node = nodes.get(pathKey(rule.path));
      if (!validPath(rule.path) || !(node == null ? void 0 : node.items) || node.type !== "array" || paths.has(pathKey(rule.path)) || !safeKey(rule.key) || !rule.key)
        return void 0;
      if (["describe", "readRows", "readKeys", "insert", "remove", "move"].some(
        (key) => typeof rule[key] !== "boolean"
      ))
        return void 0;
      if (Object.keys(rule).some(
        (key) => ![
          "path",
          "describe",
          "readRows",
          "readKeys",
          "key",
          "insert",
          "remove",
          "move",
          "insertFields",
          "defaults"
        ].includes(key)
      ))
        return void 0;
      if (!Array.isArray(rule.insertFields) || rule.insertFields.some(
        (field) => !fieldValid(field) || !field.write || field.path.some((part) => typeof part !== "string")
      ))
        return void 0;
      if (new Set(
        rule.insertFields.map(
          (field) => pathKey(field.path)
        )
      ).size !== rule.insertFields.length)
        return void 0;
      for (const field of rule.insertFields) {
        const target = nodes.get(
          pathKey([...rule.path, { row: true }, ...field.path])
        );
        if (!target || target.properties || target.items || !shapeFits(field, target))
          return void 0;
      }
      if (keys2.some(
        ({ path, key }) => path.length === rule.path.length && rule.path.every(
          (part, index2) => typeof part === "string" ? part === path[index2] : typeof path[index2] === "number" && Number.isInteger(path[index2]) && Number(path[index2]) >= 0
        ) && key !== rule.key
      ))
        return void 0;
      paths.add(pathKey(rule.path));
    }
    for (const left of data.fields.filter((rule) => rule.write))
      if ([...data.fields, ...data.arrays].some(
        (right) => prefix(left.path, right.path)
      ))
        return void 0;
    for (const rule of [...data.fields, ...data.arrays])
      for (let i = 0; i < rule.path.length; i++)
        if (typeof rule.path[i] !== "string" && !data.arrays.some(
          (array) => pathKey(array.path) === pathKey(rule.path.slice(0, i))
        ))
          return void 0;
    return freeze({
      ...data,
      ...authorize ? { authorizeApply: authorize } : {}
    });
  } catch {
    return void 0;
  }
}
const idValid = (id) => typeof id === "string" || typeof id === "number" && Number.isFinite(id);
function rowIds(value, rule) {
  if (!Array.isArray(value)) return reject("target-unavailable");
  const ids = value.map(
    (row) => row && typeof row === "object" && !Array.isArray(row) ? row[rule.key] : void 0
  );
  if (!ids.every(idValid) || new Set(ids).size !== ids.length)
    return reject("row-identity");
  return ids;
}
function resolveAddress(values, address, policy) {
  if (!Array.isArray(address) || !address.length || address.length > 32)
    return reject("invalid-address");
  let value = values;
  let parent;
  let key = "";
  const path = [];
  for (let i = 0; i < address.length; i++) {
    const part = address[i];
    parent = value;
    if (!parent || typeof parent !== "object")
      return reject("target-unavailable");
    if (typeof part === "string") {
      if (!safeKey(part) || !part || Array.isArray(parent))
        return reject("invalid-address");
      key = part;
    } else {
      if (!part || Object.keys(part).length !== 1 || !("row" in part) || !idValid(part.row))
        return reject("row-identity");
      const rule = policy.arrays.find(
        (rule2) => pathKey(rule2.path) === pathKey(address.slice(0, i))
      );
      if (!rule) return reject("permission-denied");
      key = rowIds(parent, rule).indexOf(part.row);
      if (key < 0) return reject("row-identity");
    }
    path.push(key);
    value = Object.hasOwn(parent, key) ? parent[key] : void 0;
  }
  return {
    path,
    parent,
    key,
    value,
    present: value !== void 0
  };
}
function addresses(values, pattern, policy) {
  let targets = [[]];
  for (const part of pattern) {
    if (typeof part === "string")
      targets = targets.map((path) => [...path, part]);
    else
      targets = targets.flatMap((path) => {
        const array = policy.arrays.find(
          (rule) => pathKey(rule.path) === pathKey(path)
        );
        if (!array) return reject("row-identity");
        return rowIds(resolveAddress(values, path, policy).value, array).map(
          (row) => [...path, { row }]
        );
      });
  }
  return targets;
}
function describable(target, policy) {
  return target.every(
    (part, i) => typeof part === "string" || policy.arrays.some(
      (rule) => pathKey(rule.path) === pathKey(target.slice(0, i)) && rule.describe && rule.readRows && rule.readKeys
    )
  );
}
function grantFor(rule, policy) {
  const parent = policy.arrays.find(
    (array) => pathKey([...array.path, { row: true }, array.key]) === pathKey(rule.path)
  );
  return parent && !parent.readKeys ? { kind: "none" } : rule.read;
}
function projection(values, policy) {
  const fields = [];
  const arrays = [];
  for (const rule of policy.fields) {
    if (!rule.describe) continue;
    for (const target of addresses(values, rule.path, policy)) {
      if (!describable(target, policy)) continue;
      const current = resolveAddress(values, target, policy);
      const value = visibleValue(
        current.present,
        current.value,
        grantFor(rule, policy)
      );
      fields.push({
        target,
        ...value ? { value } : {},
        actions: rule.write ? ["set", ...rule.clear ? ["clear"] : []] : [],
        shape: rule.shape,
        ...rule.clear ? {
          clear: rule.clear.kind === "remove" ? { kind: "remove" } : {
            kind: "value",
            ...visibleValue(
              true,
              rule.clear.value,
              grantFor(rule, policy)
            ) ? {
              value: visibleValue(
                true,
                rule.clear.value,
                grantFor(rule, policy)
              )
            } : {}
          }
        } : {}
      });
    }
  }
  for (const rule of policy.arrays) {
    if (!rule.describe) continue;
    for (const target of addresses(values, rule.path, policy)) {
      if (!describable(target, policy)) continue;
      arrays.push({
        target,
        ...rule.readRows && rule.readKeys ? {
          rows: rowIds(resolveAddress(values, target, policy).value, rule)
        } : {},
        actions: [
          ...rule.insert ? ["arrayInsert"] : [],
          ...rule.remove ? ["arrayRemove"] : [],
          ...rule.move ? ["arrayMove"] : []
        ]
      });
    }
  }
  return { fields, arrays };
}
function differences(before, after, policy) {
  const result = [];
  for (const rule of policy.fields) {
    if (!rule.describe) continue;
    const targets = /* @__PURE__ */ new Map();
    for (const values of [before, after])
      for (const target of addresses(values, rule.path, policy))
        targets.set(JSON.stringify(target), target);
    for (const target of targets.values()) {
      if (!describable(target, policy)) continue;
      const at = (values) => {
        try {
          return resolveAddress(values, target, policy);
        } catch {
          return { present: false, value: void 0 };
        }
      };
      const left = at(before), right = at(after);
      const a = visibleValue(left.present, left.value, grantFor(rule, policy)), b = visibleValue(right.present, right.value, grantFor(rule, policy));
      if ((a || b) && !index.equal(a, b))
        result.push({
          target,
          ...a ? { before: a } : {},
          ...b ? { after: b } : {}
        });
    }
  }
  for (const rule of policy.arrays) {
    if (!rule.describe || !rule.readRows || !rule.readKeys) continue;
    const targets = /* @__PURE__ */ new Map();
    for (const values of [before, after])
      for (const target of addresses(values, rule.path, policy))
        targets.set(JSON.stringify(target), target);
    for (const target of targets.values()) {
      if (!describable(target, policy)) continue;
      const at = (values) => {
        try {
          return {
            present: true,
            value: rowIds(resolveAddress(values, target, policy).value, rule)
          };
        } catch {
          return { present: false };
        }
      };
      const a = at(before), b = at(after);
      if (!index.equal(a, b)) result.push({ target, before: a, after: b });
    }
  }
  return result;
}
function plan(values, changes, policy, available = () => true) {
  var _a;
  const draft = jsonCopy(values);
  const actions = [];
  const locals = /* @__PURE__ */ new Map();
  const newRows = [];
  const touched = [];
  const structures = [];
  const removed = [];
  const retiredIds = /* @__PURE__ */ new Set();
  const select2 = (selector, target) => {
    if (!selector || typeof selector !== "object" || Object.keys(selector).length !== 1)
      return reject("row-identity");
    if ("row" in selector && idValid(selector.row)) return { row: selector.row };
    if (!("inserted" in selector)) return reject("row-identity");
    const local = locals.get(selector.inserted);
    if (!local || local.container !== JSON.stringify(target))
      return reject("row-identity");
    return { row: local.id };
  };
  for (const input2 of changes) {
    if (!input2 || typeof input2 !== "object" || !Array.isArray(input2.target))
      return reject("invalid-plan");
    const allowed = {
      set: ["kind", "target", "value"],
      clear: ["kind", "target"],
      arrayInsert: ["kind", "target", "localRef", "before", "value"],
      arrayRemove: ["kind", "target", "row"],
      arrayMove: ["kind", "target", "row", "before"]
    };
    if (!allowed[input2.kind] || Object.keys(input2).length !== allowed[input2.kind].length || Object.keys(input2).some((key) => !allowed[input2.kind].includes(key)))
      return reject("invalid-plan");
    const target = [];
    for (const part of input2.target)
      target.push(typeof part === "string" ? part : select2(part, target));
    if (removed.some((path) => index.equal(path, target) || prefix(path, target)))
      return reject("ambiguous-plan");
    const resolved = resolveAddress(draft, target, policy);
    const inserted = newRows.some(
      (path) => prefix(path, target) || index.equal(path, target)
    );
    if (!available(
      inserted ? resolved.path : resolveAddress(values, target, policy).path,
      inserted
    ))
      return reject("target-unavailable");
    if (input2.kind === "set" || input2.kind === "clear") {
      const rule2 = policy.fields.find(
        (rule3) => pathKey(rule3.path) === pathKey(target)
      );
      if (!(rule2 == null ? void 0 : rule2.write) || input2.kind === "clear" && !rule2.clear)
        return reject("permission-denied");
      if (touched.some(
        (path) => index.equal(path, target) || prefix(path, target) || prefix(target, path)
      ))
        return reject("ambiguous-plan");
      const value = input2.kind === "set" ? input2.value : ((_a = rule2.clear) == null ? void 0 : _a.kind) === "value" ? rule2.clear.value : void 0;
      if (value !== void 0 && (!matches(value, rule2.shape) || !rule2.atomic && typeof value === "object" && value !== null))
        return reject("shape-invalid");
      if (value === void 0) delete resolved.parent[resolved.key];
      else resolved.parent[resolved.key] = jsonCopy(value);
      touched.push(target);
      actions.push({
        change: { ...input2, target },
        path: resolved.path,
        ...value !== void 0 ? { value } : {}
      });
      continue;
    }
    const rule = policy.arrays.find(
      (rule2) => pathKey(rule2.path) === pathKey(target)
    );
    if (!rule) return reject("permission-denied");
    const rows = resolved.value;
    const ids = rowIds(rows, rule);
    structures.push(target);
    const before = "before" in input2 && input2.before !== null ? select2(input2.before, target) : null;
    let to = before ? ids.indexOf(before.row) : ids.length;
    if (to < 0) return reject("row-identity");
    if (input2.kind === "arrayInsert") {
      if (!rule.insert || typeof input2.localRef !== "string" || !input2.localRef || locals.has(input2.localRef))
        return reject("permission-denied");
      if (!input2.value || Array.isArray(input2.value) || typeof input2.value !== "object")
        return reject("shape-invalid");
      const row = jsonCopy(rule.defaults ?? {});
      const payload = input2.value;
      const leaves = (value, path = []) => value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length ? Object.entries(value).flatMap(
        ([key, child]) => leaves(child, [...path, key])
      ) : path.length ? [path] : [];
      for (const path of leaves(payload))
        if (!rule.insertFields.some(
          (field) => index.equal(field.path, path) || field.atomic && prefix(field.path, path)
        ))
          return reject("permission-denied");
      for (const field of rule.insertFields) {
        const read = (root) => {
          let current = root;
          for (const key of field.path)
            current = current && typeof current === "object" && !Array.isArray(current) ? current[key] : void 0;
          return current;
        };
        const value = read(payload);
        if (value === void 0) continue;
        if (!available([...resolved.path, to, ...field.path], true))
          return reject("target-unavailable");
        if (!matches(value, field.shape)) return reject("shape-invalid");
        let parent = row;
        const path = field.path;
        for (const key of path.slice(0, -1)) {
          if (!parent[key]) parent[key] = {};
          parent = parent[key];
        }
        parent[path.at(-1)] = jsonCopy(value);
      }
      const id = row[rule.key];
      if (!idValid(id) || ids.includes(id) || retiredIds.has(JSON.stringify([target, id])))
        return reject("row-identity");
      locals.set(input2.localRef, { container: JSON.stringify(target), id });
      newRows.push([...target, { row: id }]);
      rows.splice(to, 0, row);
      actions.push({
        change: { ...input2, target, before },
        path: resolved.path,
        value: row,
        index: to
      });
    } else {
      const row = select2(input2.row, target);
      const index$1 = ids.indexOf(row.row);
      if (index$1 < 0) return reject("row-identity");
      const rowPath = [...target, row];
      if (input2.kind === "arrayRemove") {
        if (!rule.remove) return reject("permission-denied");
        if ([...touched, ...structures].some(
          (path) => prefix(rowPath, path) || index.equal(rowPath, path)
        ))
          return reject("ambiguous-plan");
        removed.push(rowPath);
        retiredIds.add(JSON.stringify([target, row.row]));
        rows.splice(index$1, 1);
        actions.push({
          change: { ...input2, target, row },
          path: resolved.path,
          index: index$1
        });
      } else {
        if (!rule.move) return reject("permission-denied");
        if (to > index$1) to--;
        if ((before == null ? void 0 : before.row) === row.row) to = index$1;
        rows.splice(to, 0, rows.splice(index$1, 1)[0]);
        actions.push({
          change: { ...input2, target, row, before },
          path: resolved.path,
          index: index$1,
          to
        });
      }
    }
  }
  return { draft, actions };
}
const checks = () => ({
  performed: [
    "json-shape",
    "identity",
    "direct-permission",
    "value-shape",
    "whole-domain-eligibility"
  ],
  deferred: ["live-reactions", "managed-resources", "live-validation"],
  issues: []
});
const now = () => performance.now();
const headSize = 8192;
const workspaceSize = 3 * limits.domainBytes;
function createConditionalEdit(ports) {
  const owner = crypto.randomUUID();
  let serial = 0, sequence = 0, authority = 0, generation = 0, external = 0;
  let policy;
  let slot;
  let recovery;
  let reserved = 0;
  const observations = /* @__PURE__ */ new Map();
  const candidates = /* @__PURE__ */ new Map();
  const operations2 = /* @__PURE__ */ new Map();
  const ref = (kind) => `${owner}:${kind}:${++serial}`;
  const revision = () => `${owner}/${authority}/${sequence}/${generation}`;
  const retained = () => reserved + [...observations.values()].reduce((sum, item) => sum + item.size, 0) + [...candidates.values()].reduce((sum, item) => sum + item.size, 0) + [...operations2.values()].reduce(
    (sum, item) => sum + item.size + item.waiters.size * 256,
    0
  ) + (recovery ? headSize : 0);
  const room = (size) => retained() + size <= limits.retainedBytes;
  const notify = (op) => [...op.waiters].forEach((fn) => fn());
  function complete(op, status, reason) {
    if (op.view.verification.status !== "pending") return;
    op.view.verification = {
      ...op.view.verification,
      status,
      issues: status === "invalid" ? [{ code: "validation-invalid" }] : status === "unverified" ? [{ code: reason ?? "verification-failed" }] : [],
      ...reason ? { reason } : {},
      ...status === "valid" || status === "invalid" ? { revision: revision(), current: true } : { current: false }
    };
    op.view.phase = "settled";
    op.expires = now() + limits.retentionMs;
    if (slot === op) slot = void 0;
    notify(op);
  }
  function changed(token) {
    sequence++;
    if (!slot || token !== slot.token) {
      external++;
      if ((slot == null ? void 0 : slot.view.verification.status) === "pending") {
        const op = slot;
        complete(op, "superseded", "external-change");
        op.controller.abort();
      }
    }
  }
  function eligibility(ignore) {
    const reasons = [...ports.eligibility()];
    if (!ports.alive()) reasons.push("owner-unavailable");
    if (!policy) reasons.push("policy-unavailable");
    if (recovery) reasons.push("recovery-required");
    if (slot && slot !== ignore) reasons.push("busy");
    return { canApply: !reasons.length, reasons: [...new Set(reasons)] };
  }
  function fact(op, outcome, reason, started = [], completed = []) {
    if (op.view.write) return;
    op.candidate.state = "terminal";
    op.candidate.claim = void 0;
    op.view.write = {
      outcome,
      ...reason ? { reason } : {},
      started,
      completed,
      actualDiff: [],
      diffComplete: !!op.before && !!op.after,
      recoveryRequired: outcome === "unknown"
    };
    op.view.phase = "settled";
    op.expires = now() + limits.retentionMs;
    if (outcome === "unknown") {
      recovery = {
        operationRef: op.view.operationRef,
        reason: "recovery-required"
      };
      op.view.verification = {
        ...op.view.verification,
        status: "unverified",
        reason: "recovery-required"
      };
      if (slot === op) slot = void 0;
      ports.recovery(true);
    } else if (outcome === "not-applied") {
      if (slot === op) slot = void 0;
    }
    notify(op);
  }
  function prune() {
    const time = now();
    for (const [key, observation] of observations)
      if (observation.expires <= time) observations.delete(key);
    for (const candidate of candidates.values())
      if (candidate.state === "ready" && candidate.expires <= time)
        fact(operations2.get(candidate.operation), "not-applied", "expired");
    for (const [key, operation] of operations2)
      if (operation.view.phase === "settled" && operation.expires <= time && !operation.waiters.size && slot !== operation) {
        operations2.delete(key);
        candidates.delete(operation.candidate.ref);
      }
  }
  function view(op) {
    const out = {
      ...op.view,
      write: op.view.write ? { ...op.view.write, actualDiff: [] } : null,
      verification: {
        ...op.view.verification,
        current: !!op.view.verification.revision && op.view.verification.revision === revision() && ports.alive()
      }
    };
    if (out.write && policy && op.before && op.after) {
      try {
        out.write.actualDiff = differences(op.before, op.after, policy);
      } catch {
        out.write.diffComplete = false;
        out.detailsComplete = false;
      }
    }
    if (bytes(out) > limits.outputBytes) {
      if (out.write) {
        out.write.actualDiff = [];
        out.write.diffComplete = false;
      }
      out.detailsComplete = false;
    }
    return freeze(jsonCopy(out, limits.outputBytes));
  }
  const failure = (error) => error instanceof ConditionalError ? error.code : "check-failed";
  const api = {
    readSnapshot() {
      prune();
      if (policy && !installPolicy(policy, ports.schema(), ports.arrayKeys()))
        policy = void 0;
      if (!ports.alive() || !policy)
        return {
          status: "unavailable",
          reason: !ports.alive() ? "owner-unavailable" : "policy-unavailable",
          complete: false
        };
      try {
        const stamp = revision(), values = ports.capture();
        const projected = projection(values, policy);
        if (stamp !== revision())
          return { status: "unavailable", reason: "conflict", complete: false };
        const result = {
          status: "observed",
          observationRef: ref("observation"),
          revision: stamp,
          complete: true,
          ...projected,
          eligibility: eligibility(),
          limits
        };
        const size = bytes(values) + 256;
        if (observations.size >= limits.observations || !room(size))
          return { status: "unavailable", reason: "capacity", complete: false };
        if (bytes(result) > limits.outputBytes)
          return {
            status: "unavailable",
            reason: "output-limit",
            complete: false
          };
        observations.set(result.observationRef, {
          ref: result.observationRef,
          revision: stamp,
          values: freeze(values),
          expires: now() + limits.observationMs,
          size
        });
        return freeze(result);
      } catch (error) {
        return {
          status: "unavailable",
          reason: failure(error),
          complete: false
        };
      }
    },
    prepareEdit(input2, options) {
      prune();
      try {
        const observation = observations.get(options.observationRef);
        if (!observation || observation.revision !== revision())
          return reject("observation-stale");
        if (policy && !installPolicy(policy, ports.schema(), ports.arrayKeys()))
          policy = void 0;
        const eligible = eligibility();
        if (!eligible.canApply)
          return {
            status: "rejected",
            reasons: eligible.reasons,
            checks: checks()
          };
        const changes = freeze(
          jsonCopy(input2, limits.planBytes)
        );
        if (!Array.isArray(changes) || !changes.length || changes.length > limits.actions)
          return reject("action-limit");
        const planned = plan(
          observation.values,
          changes,
          policy,
          ports.available
        );
        if (observation.revision !== revision()) return reject("conflict");
        const preview = {
          changes: differences(observation.values, planned.draft, policy),
          previewComplete: true,
          issuesComplete: true
        };
        if (bytes(preview) > limits.outputBytes - 4096) {
          preview.changes = [];
          preview.previewComplete = false;
        }
        const size = bytes(changes) + bytes(observation.values) + 512;
        if ([...candidates.values()].filter(
          (item) => item.state === "ready" || item.state === "authorizing"
        ).length >= limits.candidates || operations2.size >= limits.operations || !room(size + headSize))
          return reject("capacity");
        const candidate = {
          ref: ref("candidate"),
          operation: ref("operation"),
          observation: observation.ref,
          revision: observation.revision,
          expires: now() + limits.candidateMs,
          changes,
          base: observation.values,
          size,
          state: "ready"
        };
        const op = {
          candidate,
          token: {},
          external,
          expires: Number.POSITIVE_INFINITY,
          size: headSize,
          waiters: /* @__PURE__ */ new Set(),
          controller: new AbortController(),
          view: {
            operationRef: candidate.operation,
            candidateRef: candidate.ref,
            phase: "not-started",
            detailsComplete: true,
            write: null,
            verification: {
              status: "not-started",
              coverage: [
                "synchronous-reactions",
                "managed-resources",
                "live-validation"
              ],
              issues: [],
              current: false,
              issuesComplete: true
            }
          }
        };
        candidates.set(candidate.ref, candidate);
        operations2.set(candidate.operation, op);
        return freeze({
          status: "prepared",
          candidateRef: candidate.ref,
          operationRef: candidate.operation,
          baseRevision: candidate.revision,
          expiresAt: Date.now() + limits.candidateMs,
          preview,
          checks: checks(),
          eligibility: eligible
        });
      } catch (error) {
        return freeze({
          status: "rejected",
          reasons: [failure(error)],
          checks: checks()
        });
      }
    },
    applyPrepared(candidateRef, options = {}) {
      var _a;
      prune();
      if (!ports.alive())
        return { status: "unavailable", reason: "owner-unavailable" };
      const candidate = candidates.get(candidateRef), op = candidate && operations2.get(candidate.operation);
      if (!candidate || !op)
        return { status: "unavailable", reason: "expired-or-unknown" };
      const result = () => ({
        status: "recorded",
        operation: view(op)
      });
      if (candidate.state !== "ready") return result();
      const preflight = () => {
        var _a2;
        if ((_a2 = options.signal) == null ? void 0 : _a2.aborted) return reject("cancelled-before-write");
        if (candidate.expires <= now()) return reject("expired");
        if (candidate.revision !== revision()) return reject("conflict");
        const eligible = eligibility(op);
        if (!eligible.canApply) return reject(eligible.reasons[0]);
        return plan(
          ports.capture(),
          candidate.changes,
          policy,
          ports.available
        );
      };
      let planned;
      try {
        planned = preflight();
      } catch (error) {
        fact(op, "not-applied", failure(error));
        return result();
      }
      if (!room(workspaceSize)) {
        fact(op, "not-applied", "capacity");
        return result();
      }
      reserved += workspaceSize;
      candidate.state = "authorizing";
      candidate.claim = {};
      slot = op;
      const claim = candidate.claim;
      op.view.phase = "authorizing";
      try {
        if (policy.authorizeApply) {
          const allowed = policy.authorizeApply(
            freeze({
              owner,
              candidateRef,
              operationRef: candidate.operation,
              observationRef: candidate.observation,
              baseRevision: candidate.revision,
              policyGeneration: generation
            }),
            options.credential
          );
          if (allowed && typeof allowed.then === "function")
            Promise.resolve(allowed).catch(() => {
            });
          if (allowed !== true) return reject("authorization-denied");
        }
        if (candidate.state !== "authorizing" || candidate.claim !== claim || slot !== op)
          return result();
        planned = preflight();
        op.before = ports.capture();
        op.external = external;
        candidate.state = "writing";
        op.view.phase = "writing";
        const started = [], completed = [];
        let reason;
        let uncertain = false;
        try {
          for (const [index2, original] of planned.actions.entries()) {
            if (external !== op.external || !policy) {
              reason = "external-change";
              break;
            }
            const current = plan(
              ports.capture(),
              [original.change],
              policy,
              ports.available
            ).actions[0];
            started.push(index2);
            ports.write(current, op.token);
            completed.push(index2);
            if (ports.eligibility().includes("runtime-fault")) {
              reason = "runtime-fault";
              break;
            }
          }
        } catch (error) {
          reason = failure(error);
          uncertain = started.length > completed.length;
        }
        try {
          op.after = ports.capture();
        } catch {
          op.view.detailsComplete = false;
          uncertain = true;
        }
        if (op.before && op.after) {
          op.size += bytes(op.before) + bytes(op.after);
          if (retained() - workspaceSize > limits.retainedBytes) {
            op.after = void 0;
            op.view.detailsComplete = false;
            uncertain = true;
          }
        }
        const outcome = uncertain ? "unknown" : completed.length === planned.actions.length ? "applied" : completed.length || op.before && op.after && !index.equal(op.before, op.after) ? "partial" : "not-applied";
        fact(
          op,
          outcome,
          reason ?? (op.before && op.after && index.equal(op.before, op.after) ? "no-change" : void 0),
          started,
          completed
        );
        if (outcome === "applied" || outcome === "partial") {
          op.view.verification.status = "pending";
          if (external !== op.external)
            complete(op, "superseded", "external-change");
          else queueMicrotask(() => verify(op));
        }
        return result();
      } catch (error) {
        fact(op, "not-applied", failure(error));
        return result();
      } finally {
        reserved -= workspaceSize;
        if (((_a = op.view.write) == null ? void 0 : _a.outcome) === "not-applied" && slot === op)
          slot = void 0;
      }
    },
    discardPrepared(candidateRef) {
      prune();
      const candidate = candidates.get(candidateRef), op = candidate && operations2.get(candidate.operation);
      if (!op || !candidate)
        return { status: "unavailable", reason: "expired-or-unknown" };
      if (candidate.state === "writing" || op.view.write && op.view.write.outcome !== "not-applied")
        return { status: "not-discardable", operationRef: candidate.operation };
      fact(op, "not-applied", "discarded");
      return { status: "discarded", operationRef: candidate.operation };
    },
    getOperation(operationRef) {
      prune();
      if (!ports.alive())
        return { status: "unavailable", reason: "owner-unavailable" };
      const op = operations2.get(operationRef);
      return op ? { status: "available", operation: view(op) } : { status: "unavailable", reason: "expired-or-unknown" };
    },
    async waitOperation(operationRef, options = {}) {
      const current = api.getOperation(operationRef);
      if (current.status !== "available" || current.operation.verification.status !== "pending")
        return current;
      const op = operations2.get(operationRef);
      if (op.waiters.size >= limits.waiters || !room(256))
        return { status: "unavailable", reason: "capacity" };
      const timeout = options.timeoutMs ?? limits.waitMs;
      if (!Number.isFinite(timeout) || timeout < 0)
        return { status: "unavailable", reason: "invalid-timeout" };
      return new Promise((resolve) => {
        var _a, _b;
        let timer;
        const finish = (result) => {
          var _a2;
          clearTimeout(timer);
          op.waiters.delete(check);
          (_a2 = options.signal) == null ? void 0 : _a2.removeEventListener("abort", abort);
          resolve(result);
        };
        const check = () => {
          const latest = api.getOperation(operationRef);
          if (latest.status !== "available" || latest.operation.verification.status !== "pending")
            finish(latest);
        };
        const abort = () => finish({ status: "wait-cancelled", operationRef, latest: view(op) });
        op.waiters.add(check);
        timer = setTimeout(
          () => finish({ status: "timed-out", operationRef, latest: view(op) }),
          Math.min(timeout, limits.maxWaitMs)
        );
        (_a = options.signal) == null ? void 0 : _a.addEventListener("abort", abort, { once: true });
        if ((_b = options.signal) == null ? void 0 : _b.aborted) abort();
        else check();
      });
    }
  };
  async function verify(op) {
    if (op.view.verification.status !== "pending") return;
    const timer = setTimeout(() => {
      complete(op, "unverified", "verification-timeout");
      op.controller.abort();
    }, limits.verificationMs);
    try {
      const current = () => ports.alive() && external === op.external && op.view.verification.status === "pending";
      const result = await ports.verify(op.token, op.controller.signal, current);
      if (current())
        complete(
          op,
          result,
          result === "unverified" ? "verification-failed" : void 0
        );
    } catch {
      complete(op, "unverified", "verification-failed");
    } finally {
      clearTimeout(timer);
    }
  }
  return {
    readSnapshot: () => freeze(api.readSnapshot()),
    prepareEdit: (...args) => freeze(api.prepareEdit(...args)),
    applyPrepared: (...args) => freeze(api.applyPrepared(...args)),
    discardPrepared: (...args) => freeze(api.discardPrepared(...args)),
    getOperation: (...args) => freeze(api.getOperation(...args)),
    waitOperation: (...args) => api.waitOperation(...args).then(freeze),
    changed,
    get busy() {
      return !!slot;
    },
    setConditionalEditPolicy(next) {
      policy = installPolicy(next, ports.schema(), ports.arrayKeys());
      if (policy) ports.installArrays(policy.arrays);
      generation++;
      changed();
    },
    refreshRuntime() {
      if (policy) ports.installArrays(policy.arrays);
    },
    authorityChanged() {
      authority++;
      changed();
    },
    reconciled() {
      recovery = void 0;
      ports.recovery(false);
    },
    dispose() {
      changed();
      for (const op of operations2.values()) {
        op.controller.abort();
        notify(op);
      }
      observations.clear();
      candidates.clear();
      operations2.clear();
    }
  };
}
function createFormSession(options) {
  const seed = index.copy(options.initial);
  const record = new AbortController();
  let conditional;
  const conditionalValidations = /* @__PURE__ */ new Set();
  const conditionalValidationBusy = () => [...conditionalValidations].some((current) => current());
  const resources = createResources(
    record.signal,
    (token) => conditional == null ? void 0 : conditional.changed(token)
  );
  let alive = true;
  let epoch = 0;
  let nextAttempt = 0;
  const lifecycle = vue.shallowRef({
    baseline: void 0,
    ready: false,
    pending: false,
    phase: "initializing",
    status: "初始化中",
    reconciliationRequired: false
  });
  function member(key2) {
    return vue.computed({
      get: () => lifecycle.value[key2],
      set: (value) => {
        lifecycle.value = { ...lifecycle.value, [key2]: value };
      }
    });
  }
  const baseline = member("baseline");
  let attempt;
  let accepting;
  let resultLock;
  let stopRuntime;
  let ledgerRefreshQueued = false;
  let managedPreparation;
  const editedPreparations = /* @__PURE__ */ new WeakSet();
  const runtime = vue.shallowRef();
  const ready = member("ready");
  const pending = member("pending");
  const phase = member("phase");
  const status = member("status");
  const issues = vue.shallowRef([]);
  const reconciliationRequired = member("reconciliationRequired");
  const key = vue.shallowRef(0);
  function uncertain(owner, reason) {
    var _a;
    if (!alive || resultLock && resultLock !== owner) return;
    resultLock = owner;
    reconciliationRequired.value = true;
    phase.value = "uncertain";
    status.value = reason;
    (_a = options.reconcileRequired) == null ? void 0 : _a.call(options, { reason });
  }
  function cancel(reason = "表单已更新，请重新提交") {
    const owner = attempt;
    if (!owner) return;
    if (owner.dispatched) uncertain(owner, "保存结果需重新载入核对");
    owner.controller.abort(reason);
    if (attempt !== owner) return;
    attempt = void 0;
    lifecycle.value = {
      ...lifecycle.value,
      pending: false,
      ...!reconciliationRequired.value ? { phase: "idle", status: reason } : {}
    };
  }
  const enabled = () => {
    var _a;
    return ((_a = options.enabled) == null ? void 0 : _a.call(options)) !== false;
  };
  function owns(owner) {
    return alive && attempt === owner && owner.epoch === epoch && runtime.value === owner.runtime;
  }
  function active(owner) {
    return owns(owner) && !owner.controller.signal.aborted && owner.runtime.current(owner.stamp) && enabled();
  }
  function build(values, owner, schema) {
    var _a;
    conditional == null ? void 0 : conditional.authorityChanged();
    stopRuntime == null ? void 0 : stopRuntime();
    (_a = runtime.value) == null ? void 0 : _a.dispose();
    const buildingEpoch = ++epoch;
    ready.value = false;
    if (!alive || epoch !== buildingEpoch) return void 0;
    const next = createRuntime({
      initial: index.copy(values),
      semantic: (token) => conditional == null ? void 0 : conditional.changed(token),
      resourceHost: resources,
      recordSignal: record.signal,
      createSchema: options.createSchema,
      assertSettled: options.assertSettled,
      arrayKeys: options.arrayKeys,
      components: options.components,
      dataSourceProps: options.dataSourceProps
    });
    if (!alive || epoch !== buildingEpoch) {
      next.dispose();
      return void 0;
    }
    if (owner) {
      owner.runtime = next;
      owner.epoch = epoch;
      owner.stamp = next.ticket();
    }
    stopRuntime = vue.watch(
      () => {
        next.version.value;
        return next.ticket();
      },
      (stamp) => {
        if (managedPreparation === next && next.origin === "edit")
          editedPreparations.add(next);
        if (accepting && owns(accepting) && next.origin !== "edit") {
          accepting.stamp = stamp;
        } else if ((attempt == null ? void 0 : attempt.preparing) && (next.origin === "control" || next.origin === "initialization" || next.initializing || next.origin === "reaction"))
          attempt.stamp = stamp;
        else if (attempt) cancel();
        if (next.origin === "edit") {
          issues.value = [];
          if (!ledgerRefreshQueued) {
            ledgerRefreshQueued = true;
            queueMicrotask(() => {
              ledgerRefreshQueued = false;
              if (alive && runtime.value === next) next.ledger.changed();
            });
          }
        } else next.ledger.project();
      },
      { flush: "sync" }
    );
    next.attachReplace(() => {
      if (!alive || runtime.value !== next) return;
      cancel("表单结构已更新");
      ready.value = false;
      vue.nextTick().then(() => {
        if (alive && runtime.value === next) ready.value = next.assert();
      });
    });
    runtime.value = next;
    conditional == null ? void 0 : conditional.refreshRuntime();
    if (!alive || epoch !== buildingEpoch || runtime.value !== next)
      return void 0;
    key.value++;
    return next;
  }
  const read = () => runtime.value.read();
  const dirty = vue.computed(
    () => baseline.value === void 0 || !index.equal(read(), baseline.value)
  );
  const fieldPending = vue.computed(() => {
    runtime.value.version.value;
    return resources.pending() || runtime.value.activeControls().some(([, item]) => item.state.pending);
  });
  const hasUncommittedInput = vue.computed(() => {
    const model = runtime.value;
    model.version.value;
    const fields = new Set(model.liveFields());
    return [...model.controls].some(
      ([field, item]) => {
        var _a;
        return fields.has(field) && !!((_a = item.state.blocking) == null ? void 0 : _a.length);
      }
    );
  });
  const blocked = vue.computed(() => {
    const model = runtime.value;
    model.version.value;
    return !!resources.issues().length || !ready.value || reconciliationRequired.value || !!model.faults.value.length || !!model.assertionIssues.value.length || model.activeControls().some(([, item]) => {
      var _a;
      return (_a = item.state.blocking) == null ? void 0 : _a.length;
    });
  });
  const formIssues = vue.computed(() => [
    ...resources.feedback(),
    ...runtime.value.ledger.formIssues.value,
    ...runtime.value.faults.value,
    ...runtime.value.assertionIssues.value,
    ...runtime.value.activeControls().filter(
      ([field, item]) => !item.composite || !item.mounted || field.display !== "visible"
    ).flatMap(([, item]) => item.state.blocking ?? []).map((message) => ({ message: message.message }))
  ]);
  function focus(path) {
    const model = runtime.value;
    const values = model.read();
    const candidates = [...model.controls].filter(
      ([field, item]) => item.mounted && field.display === "visible"
    );
    const visibleError = () => candidates.find(
      ([field, item]) => {
        var _a, _b;
        return ((_a = model.feedback.value.get(field)) == null ? void 0 : _a.some((issue) => (issue.severity ?? "error") === "error")) || ((_b = item.state.blocking) == null ? void 0 : _b.length);
      }
    );
    const match = (path ? candidates.filter(
      ([field, item]) => (field.path.length === path.length || item.composite) && dataPath(field.path.toArr(), values).every(
        (segment, index2) => segment === path[index2]
      )
    ).sort((a, b) => b[0].path.length - a[0].path.length)[0] : void 0) ?? visibleError();
    match == null ? void 0 : match[1].control.focus(
      path && dataPath(match[0].path.toArr(), values).every(
        (segment, index2) => segment === path[index2]
      ) ? path.slice(match[0].path.length) : void 0
    );
  }
  function initialize() {
    if (!alive || ready.value) return false;
    const model = runtime.value;
    if (managedPreparation === model) return false;
    model.flushResources();
    if (resources.issues().length) {
      phase.value = "initializing";
      status.value = "等待必要资源";
      return false;
    }
    if (!model.assert()) {
      phase.value = "blocked";
      status.value = "初始化未满足提交约束";
      return false;
    }
    lifecycle.value = {
      ...lifecycle.value,
      // Resource completion can restore readiness after failed authority. Only
      // the first initialization may establish a baseline here; later authority
      // and save acceptance own explicit baseline transactions.
      baseline: baseline.value ?? model.read(),
      ready: true,
      phase: reconciliationRequired.value ? "uncertain" : "idle",
      status: reconciliationRequired.value ? "保存结果需重新载入核对" : "已载入"
    };
    return true;
  }
  function setValues(patch) {
    if (!alive) return false;
    const model = runtime.value;
    const before = model.read();
    const next = index.copy(patch);
    if (Object.entries(next).every(
      ([key2, value]) => index.equal(before[key2], value)
    ))
      return false;
    if (managedPreparation === model) editedPreparations.add(model);
    cancel();
    model.setValues(next);
    model.assert();
    return true;
  }
  async function settleBuilt(model, signal, commit) {
    await vue.nextTick();
    if (!alive || runtime.value !== model || (signal == null ? void 0 : signal.aborted)) return false;
    model.flushResources();
    if (resources.requiredPending()) {
      await new Promise((resolve) => {
        let stop;
        const finish = () => {
          stop == null ? void 0 : stop();
          signal == null ? void 0 : signal.removeEventListener("abort", finish);
          resolve();
        };
        const check = () => {
          if (!alive || runtime.value !== model || !resources.requiredPending() || (signal == null ? void 0 : signal.aborted))
            finish();
        };
        stop = vue.watch([resources.version, () => runtime.value], check, {
          flush: "sync"
        });
        signal == null ? void 0 : signal.addEventListener("abort", finish, { once: true });
        check();
      });
    }
    const valid = alive && runtime.value === model && !(signal == null ? void 0 : signal.aborted) && !resources.issues().length && model.assert() && !editedPreparations.has(model);
    if (alive && runtime.value === model && !(signal == null ? void 0 : signal.aborted)) commit == null ? void 0 : commit(valid);
    return valid;
  }
  async function replaceValues(values, mode) {
    if (!alive) return false;
    cancel();
    const previousBaseline = baseline.value;
    const next = build(values);
    if (!next || runtime.value !== next) return false;
    managedPreparation = next;
    if (!await settleBuilt(next)) {
      if (managedPreparation === next) managedPreparation = void 0;
      if (runtime.value === next && editedPreparations.has(next) && !resources.issues().length) {
        lifecycle.value = {
          ...lifecycle.value,
          ready: next.assert(),
          phase: reconciliationRequired.value ? "uncertain" : "idle",
          status: "权威回填已因新编辑取消"
        };
      }
      return false;
    }
    if (managedPreparation === next) managedPreparation = void 0;
    lifecycle.value = {
      ...lifecycle.value,
      baseline: mode === "authority" ? next.read() : previousBaseline,
      ready: true,
      phase: reconciliationRequired.value ? "uncertain" : "idle"
    };
    return true;
  }
  function reset() {
    if (!alive) return;
    cancel("已恢复保存基线");
    const previousBaseline = baseline.value;
    const next = build(previousBaseline ?? seed);
    if (!next || runtime.value !== next) return;
    managedPreparation = next;
    settleBuilt(next, void 0, (valid) => {
      if (!next || runtime.value !== next) return;
      if (managedPreparation === next) managedPreparation = void 0;
      lifecycle.value = {
        ...lifecycle.value,
        baseline: previousBaseline ?? (valid ? next.read() : void 0),
        ready: valid,
        phase: valid ? reconciliationRequired.value ? "uncertain" : "idle" : "blocked",
        status: valid ? reconciliationRequired.value ? "保存结果需重新载入核对" : "已恢复保存基线" : "基线初始化失败"
      };
    }).catch((error) => {
      if (alive && runtime.value === next)
        lifecycle.value = {
          ...lifecycle.value,
          ready: false,
          phase: "blocked",
          status: error instanceof Error ? error.message : "基线初始化失败"
        };
    });
  }
  async function reconcile(values) {
    if (!await replaceValues(values, "authority")) return false;
    resultLock = void 0;
    reconciliationRequired.value = false;
    phase.value = "idle";
    status.value = "已核对服务端记录";
    conditional == null ? void 0 : conditional.reconciled();
    return true;
  }
  function publishDomain(model, nextIssues, snapshot) {
    model.ledger.set("SessionDomain", nextIssues, snapshot);
    return !nextIssues.some((issue) => (issue.severity ?? "error") === "error");
  }
  async function run(saving) {
    var _a, _b, _c, _d, _e;
    conditional == null ? void 0 : conditional.changed();
    if (!alive || pending.value || conditionalValidationBusy() || !!((_a = runtime.value) == null ? void 0 : _a.controlValidations.value) || !ready.value || reconciliationRequired.value || !enabled() || saving && !options.save)
      return false;
    const model = runtime.value;
    model.flushResources();
    const owner = {
      id: ++nextAttempt,
      runtime: model,
      stamp: model.ticket(),
      epoch,
      controller: new AbortController(),
      dispatched: false
    };
    let focusWanted = false;
    let focusPath;
    const requestFocus = (path) => {
      focusWanted = true;
      focusPath = path;
    };
    attempt = owner;
    pending.value = true;
    const check = () => !resources.issues().length && active(owner) && owner.runtime.assert() && !owner.runtime.activeControls().some(([, item]) => {
      var _a2;
      return (_a2 = item.state.blocking) == null ? void 0 : _a2.length;
    });
    try {
      if (!active(owner)) return false;
      phase.value = "validating";
      if (!active(owner)) return false;
      status.value = "校验中";
      if (!active(owner)) return false;
      issues.value = [];
      owner.preparing = true;
      await vue.nextTick();
      owner.preparing = false;
      if (owns(owner)) owner.stamp = model.ticket();
      if (!check()) {
        if (active(owner)) requestFocus();
        return false;
      }
      const snapshot = model.read();
      if (!await awaitSignal(
        model.validate(() => active(owner), false, owner.controller.signal),
        owner.controller.signal
      ) || !check()) {
        if (active(owner)) requestFocus();
        return false;
      }
      const joint = await awaitSignal(
        Promise.resolve(
          ((_b = options.validate) == null ? void 0 : _b.call(options, index.copy(snapshot), owner.controller.signal)) ?? []
        ),
        owner.controller.signal
      );
      if (!check()) return false;
      if (!publishDomain(model, joint, snapshot)) {
        issues.value = joint;
        phase.value = "invalid";
        status.value = "请检查表单中的错误";
        requestFocus(
          (_c = joint.find((issue) => (issue.severity ?? "error") === "error")) == null ? void 0 : _c.path
        );
        return false;
      }
      if (!saving) {
        phase.value = "idle";
        status.value = "校验通过";
        return true;
      }
      phase.value = "saving";
      if (!check()) return false;
      status.value = "保存中";
      if (!check()) return false;
      owner.dispatched = true;
      const work = Promise.resolve(
        options.save(index.copy(snapshot), owner.controller.signal)
      );
      work.then(
        (result2) => {
          if (!result2.ok && result2.outcome !== "unknown" && resultLock === owner && alive) {
            resultLock = void 0;
            reconciliationRequired.value = false;
          }
        },
        () => {
        }
      );
      const result = await awaitSignal(work, owner.controller.signal);
      if (!active(owner)) return false;
      if (!result.ok) {
        if (result.outcome === "unknown")
          uncertain(owner, "保存结果需重新载入核对");
        else {
          model.ledger.set("SessionServer", result.issues, snapshot);
          issues.value = result.issues;
          phase.value = "invalid";
          status.value = "保存被拒绝，请纠正后重试";
          requestFocus(
            (_d = result.issues.find(
              (issue) => (issue.severity ?? "error") === "error"
            )) == null ? void 0 : _d.path
          );
        }
        return false;
      }
      accepting = owner;
      const authoritative = result.values ?? snapshot;
      if (!index.equal(authoritative, snapshot)) build(authoritative, owner);
      if (!await settleBuilt(owner.runtime, owner.controller.signal) || !check()) {
        uncertain(owner, "已保存，当前显示需重新载入核对");
        return false;
      }
      owner.runtime.ledger.clear();
      if (!check()) {
        uncertain(owner, "已保存，当前显示需重新载入核对");
        return false;
      }
      const committed = owner.runtime.read();
      accepting = void 0;
      attempt = void 0;
      lifecycle.value = {
        baseline: index.copy(committed),
        ready: true,
        pending: false,
        phase: "saved",
        status: "已保存",
        reconciliationRequired: false
      };
      (_e = options.saved) == null ? void 0 : _e.call(options, committed);
      return true;
    } catch (error) {
      if (owner.dispatched && alive) uncertain(owner, "保存结果需重新载入核对");
      else if (owns(owner) && !owner.controller.signal.aborted) {
        phase.value = "invalid";
        status.value = error instanceof Error ? error.message : "校验失败";
        issues.value = [{ message: status.value }];
        owner.runtime.ledger.set("SessionDomain", issues.value);
      }
      return false;
    } finally {
      if (accepting === owner) accepting = void 0;
      if (attempt === owner) {
        if (owner.dispatched && !active(owner) && alive)
          uncertain(owner, "保存结果需重新载入核对");
        const wasWorking = phase.value === "validating" || phase.value === "saving";
        const nextPhase = wasWorking ? blocked.value ? "blocked" : "invalid" : phase.value;
        const nextStatus = wasWorking ? "表单已更新或包含错误，请重新提交" : status.value;
        attempt = void 0;
        lifecycle.value = {
          ...lifecycle.value,
          pending: false,
          phase: nextPhase,
          status: nextStatus
        };
      }
      if (focusWanted) {
        await vue.nextTick();
        if (alive && !attempt && runtime.value === owner.runtime && !pending.value)
          focus(focusPath);
      }
    }
  }
  build(seed);
  conditional = createConditionalEdit({
    alive: () => alive,
    capture: () => jsonCopy(runtime.value.form.values),
    schema: () => runtime.value.schema,
    arrayKeys: () => options.arrayKeys ?? [],
    eligibility: () => {
      const model = runtime.value;
      const reasons = [];
      if (!ready.value || !enabled()) reasons.push("owner-unavailable");
      if (pending.value || conditionalValidationBusy() || model.controlValidations.value)
        reasons.push("verification-busy");
      if (reconciliationRequired.value) reasons.push("recovery-required");
      if (model.faults.value.length) reasons.push("runtime-fault");
      if (resources.issues().length) reasons.push("required-resource");
      if ([...model.controls.values()].some((item) => !item.editObservation))
        reasons.push("input-observation-unavailable");
      if ([...model.controls.values()].some(
        (item) => item.composite && item.validationOwnership !== "managed"
      ))
        reasons.push("validation-ownership-unavailable");
      if ([...model.controls.values()].some((item) => {
        var _a;
        return (_a = item.state.blocking) == null ? void 0 : _a.length;
      }))
        reasons.push("unfinished-input");
      return reasons;
    },
    available: (path, inserted) => {
      const model = runtime.value;
      if (inserted) return model.prospectiveAvailable(path);
      const field = model.liveFields().find(
        (field2) => index.equal(dataPath(field2.path.toArr(), model.form.values), path)
      );
      return field ? fieldInteraction(field.pattern, field.componentProps).writable : false;
    },
    installArrays: (rules) => runtime.value.setConditionalArrays(rules),
    write: (action, token) => runtime.value.conditionalWrite(action, token),
    async verify(token, signal, current) {
      var _a;
      const model = runtime.value;
      conditionalValidations.add(current);
      try {
        for (let pass = 0; pass < 8; pass++) {
          await vue.nextTick();
          if (!current() || signal.aborted) return "unverified";
          model.inFrame(token, () => model.flushResources());
          if (!await settleBuilt(model, signal) || !current())
            return "unverified";
          const stamp = model.ticket();
          const valid = await model.validate(
            () => current() && !signal.aborted,
            true,
            signal
          );
          if (!current() || signal.aborted) return "unverified";
          if (!model.current(stamp)) continue;
          const snapshot = model.read();
          const joint = await Promise.resolve(
            ((_a = options.validate) == null ? void 0 : _a.call(options, index.copy(snapshot), signal)) ?? []
          );
          if (!current() || signal.aborted) return "unverified";
          if (!model.current(stamp)) continue;
          const domainValid = publishDomain(model, joint, snapshot);
          if (model.faults.value.length || resources.issues().length)
            return "unverified";
          return valid && domainValid ? "valid" : "invalid";
        }
        return "unverified";
      } finally {
        conditionalValidations.delete(current);
      }
    },
    recovery(required) {
      var _a;
      reconciliationRequired.value = required;
      if (required) {
        phase.value = "uncertain";
        status.value = "条件编辑结果需 Host 核对";
        (_a = options.reconcileRequired) == null ? void 0 : _a.call(options, { reason: "conditional-edit-unknown" });
      }
    }
  });
  conditional.setConditionalEditPolicy(options.initialConditionalEditPolicy);
  const stopResources = vue.watch(
    resources.version,
    () => {
      if (!ready.value && !pending.value && !resources.issues().length)
        vue.nextTick().then(initialize);
    },
    { flush: "sync" }
  );
  return {
    readSnapshot: conditional.readSnapshot,
    prepareEdit: conditional.prepareEdit,
    applyPrepared: conditional.applyPrepared,
    discardPrepared: conditional.discardPrepared,
    getOperation: conditional.getOperation,
    waitOperation: conditional.waitOperation,
    setConditionalEditPolicy: conditional.setConditionalEditPolicy,
    runtime,
    key: vue.readonly(key),
    ready: vue.readonly(ready),
    dirty,
    hasUncommittedInput,
    pending: vue.readonly(pending),
    phase: vue.readonly(phase),
    status: vue.readonly(status),
    issues: vue.readonly(issues),
    formIssues,
    fieldPending,
    blocked,
    reconciliationRequired: vue.readonly(reconciliationRequired),
    read,
    setValues,
    replaceValues,
    reset,
    reconcile,
    focus,
    initialize,
    async rebind(components, dataSourceProps) {
      cancel("字段控件已替换");
      options.components = components;
      options.dataSourceProps = dataSourceProps;
      const values = read();
      const next = build(values);
      if (!next || runtime.value !== next) return;
      managedPreparation = next;
      await settleBuilt(next, void 0, (valid) => {
        if (managedPreparation === next) managedPreparation = void 0;
        lifecycle.value = {
          ...lifecycle.value,
          ready: valid,
          phase: reconciliationRequired.value ? "uncertain" : valid ? "idle" : "blocked"
        };
      });
    },
    validate: () => run(false),
    submit: () => run(true),
    cancel,
    dispose() {
      var _a;
      if (!alive) return;
      cancel();
      alive = false;
      conditional == null ? void 0 : conditional.dispose();
      stopResources();
      record.abort();
      stopRuntime == null ? void 0 : stopRuntime();
      (_a = runtime.value) == null ? void 0 : _a.dispose();
    }
  };
}
const _hoisted_1 = ["data-label-position"];
const _hoisted_2 = ["aria-busy"];
const _hoisted_3 = {
  key: 0,
  class: "schema-form__uncertain",
  role: "alert"
};
const _hoisted_4 = {
  key: 1,
  class: "schema-form__errors",
  role: "alert"
};
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxSchemaForm", inheritAttrs: false },
  __name: "SchemaForm",
  props: {
    initial: {},
    initialConditionalEditPolicy: {},
    createSchema: {},
    assertSettled: {},
    save: {},
    validate: {},
    bindings: {},
    disabled: { type: Boolean },
    arrayKeys: {},
    columns: { default: 1 },
    labelPosition: { default: "top" },
    labelWidth: { default: 120 }
  },
  emits: ["saved", "reconcile-required"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    vue.provide(
      inputComposition.fieldLayoutKey,
      vue.computed(() => ({
        labelPosition: props.labelPosition,
        labelWidth: props.labelWidth
      }))
    );
    const emit = __emit;
    const registeredBindings = vue.shallowRef({
      ...createZxuiBindings(),
      ...props.bindings
    });
    const dataSourceProps = () => Object.fromEntries(
      Object.entries(registeredBindings.value).flatMap(
        ([name, binding]) => "dataSourceProp" in binding && typeof binding.dataSourceProp === "string" ? [[name, binding.dataSourceProp]] : []
      )
    );
    const session = createFormSession({
      dataSourceProps: dataSourceProps(),
      components: [
        ...Object.keys(registeredBindings.value),
        "ZxSection",
        "ZxArray",
        "ZxField"
      ],
      initial: props.initial,
      initialConditionalEditPolicy: props.initialConditionalEditPolicy,
      createSchema: props.createSchema,
      assertSettled: props.assertSettled,
      arrayKeys: props.arrayKeys,
      save: props.save,
      validate: props.validate,
      enabled: () => !props.disabled,
      saved: (values) => emit("saved", values),
      reconcileRequired: (event) => emit("reconcile-required", event)
    });
    const Engine = vue.computed(() => {
      const runtime = session.runtime.value;
      const { SchemaField } = vue$1.createSchemaField({
        components: createBindings(
          runtime,
          registeredBindings.value,
          () => !!props.disabled || session.pending.value
        )
      });
      return vue.markRaw(
        vue.defineComponent({
          setup() {
            vue.onMounted(() => runtime.mount());
            return () => vue.h(
              vue$1.FormProvider,
              { form: runtime.form },
              {
                default: () => vue.h(SchemaField, {
                  key: runtime.schemaSerial,
                  schema: runtime.schema
                })
              }
            );
          }
        })
      );
    });
    vue.watch(
      () => props.bindings,
      (bindings) => {
        registeredBindings.value = { ...createZxuiBindings(), ...bindings };
        session.rebind(
          [
            ...Object.keys(registeredBindings.value),
            "ZxSection",
            "ZxArray",
            "ZxField"
          ],
          dataSourceProps()
        );
      }
    );
    vue.onMounted(session.initialize);
    vue.onBeforeUnmount(session.dispose);
    const messages = vue.computed(() => session.formIssues.value);
    __expose({
      readSnapshot: session.readSnapshot,
      prepareEdit: session.prepareEdit,
      applyPrepared: session.applyPrepared,
      discardPrepared: session.discardPrepared,
      getOperation: session.getOperation,
      waitOperation: session.waitOperation,
      setConditionalEditPolicy: session.setConditionalEditPolicy,
      read: session.read,
      setValues: session.setValues,
      replaceValues: session.replaceValues,
      validate: session.validate,
      submit: session.submit,
      reset: session.reset,
      reconcile: session.reconcile,
      focus: session.focus,
      ready: session.ready,
      dirty: session.dirty,
      hasUncommittedInput: session.hasUncommittedInput,
      pending: session.pending,
      fieldPending: session.fieldPending,
      blocked: session.blocked,
      reconciliationRequired: session.reconciliationRequired,
      phase: session.phase,
      status: session.status
    });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("section", vue.mergeProps(_ctx.$attrs, {
        class: ["schema-form", `schema-form--columns-${__props.columns}`],
        "data-label-position": __props.labelPosition
      }), [
        vue.createElementVNode("form", {
          class: "schema-form__grid",
          novalidate: "",
          "aria-busy": vue.unref(session).pending.value || void 0,
          onSubmit: _cache[0] || (_cache[0] = vue.withModifiers(($event) => vue.unref(session).submit(), ["prevent"]))
        }, [
          (vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(Engine.value), {
            key: vue.unref(session).key.value
          }))
        ], 40, _hoisted_2),
        vue.unref(session).reconciliationRequired.value ? (vue.openBlock(), vue.createElementBlock("p", _hoisted_3, vue.toDisplayString(vue.unref(session).status.value), 1)) : vue.createCommentVNode("", true),
        messages.value.length ? (vue.openBlock(), vue.createElementBlock("ul", _hoisted_4, [
          (vue.openBlock(true), vue.createElementBlock(vue.Fragment, null, vue.renderList(messages.value, (issue, index2) => {
            return vue.openBlock(), vue.createElementBlock("li", { key: index2 }, vue.toDisplayString(issue.message), 1);
          }), 128))
        ])) : vue.createCommentVNode("", true),
        vue.renderSlot(_ctx.$slots, "diagnostics", {
          status: vue.unref(session).status.value,
          ready: vue.unref(session).ready.value,
          dirty: vue.unref(session).dirty.value,
          hasUncommittedInput: vue.unref(session).hasUncommittedInput.value,
          pending: vue.unref(session).pending.value,
          fieldPending: vue.unref(session).fieldPending.value,
          blocked: vue.unref(session).blocked.value,
          phase: vue.unref(session).phase.value,
          reconciliationRequired: vue.unref(session).reconciliationRequired.value
        })
      ], 16, _hoisted_1);
    };
  }
});
function keys(value, allowed) {
  for (const key of Object.keys(value))
    if (!allowed.includes(key))
      throw new Error(`Unsupported definition key: ${key}`);
}
function prop(name, value) {
  if (["placeholder", "aria-label"].includes(name))
    return typeof value === "string";
  if (name === "type")
    return typeof value === "string" && [
      "text",
      "textarea",
      "password",
      "email",
      "url",
      "tel",
      "search",
      "number"
    ].includes(value);
  if (name === "controlsPosition") return value === "" || value === "right";
  if (["clearable", "filterable", "remote", "disabled", "controls"].includes(name))
    return typeof value === "boolean";
  if (name === "valueOnClear")
    return value === null || typeof value === "string" || typeof value === "number" && Number.isFinite(value);
  if ([
    "min",
    "max",
    "step",
    "precision",
    "rows",
    "maxlength",
    "maxCount"
  ].includes(name)) {
    if (typeof value !== "number" || !Number.isFinite(value)) return false;
    if (name === "step") return value > 0;
    if (["min", "max"].includes(name)) return true;
    return Number.isInteger(value) && value >= (name === "rows" ? 1 : 0) && value <= (name === "precision" ? 20 : name === "rows" ? 100 : 1e5);
  }
  if (name === "options")
    return Array.isArray(value) && value.length <= 200 && value.every((item) => {
      if (!index.record(item) || Object.keys(item).some(
        (key) => !["label", "value", "disabled"].includes(key)
      ))
        return false;
      return typeof item.label === "string" && ["string", "number", "boolean"].includes(typeof item.value) && (typeof item.value !== "number" || Number.isFinite(item.value)) && (item.disabled === void 0 || typeof item.disabled === "boolean");
    });
  return false;
}
function validation(input2) {
  if (!Array.isArray(input2))
    throw new Error("Expected validator description array");
  return input2.map((description) => {
    if (!index.record(description)) throw new Error("Invalid validation rule");
    keys(description, [
      "required",
      "valueType",
      "min",
      "max",
      "message",
      "triggerType"
    ]);
    if (description.required !== void 0 && typeof description.required !== "boolean")
      throw new Error("Invalid required");
    if (description.valueType !== void 0 && !["string", "number", "array"].includes(String(description.valueType)))
      throw new Error("Invalid valueType");
    if (description.triggerType !== void 0 && !["onInput", "onBlur"].includes(String(description.triggerType)))
      throw new Error("Invalid triggerType");
    if (description.message !== void 0 && typeof description.message !== "string")
      throw new Error("Invalid validation message");
    for (const bound of ["min", "max"])
      if (description[bound] !== void 0 && (typeof description[bound] !== "number" || !Number.isFinite(description[bound]) || Number(description[bound]) < 0))
        throw new Error("Invalid validation bound");
    if (typeof description.min === "number" && typeof description.max === "number" && description.min > description.max)
      throw new Error("Invalid validation range");
    const { valueType, min, max, message, required, triggerType } = description;
    return {
      ...required !== void 0 ? { required } : {},
      ...triggerType ? { triggerType } : {},
      message,
      validator(value) {
        if (value === void 0 || value === null || value === "") return "";
        const invalid = () => typeof message === "string" ? message : "字段值类型或范围不符合定义";
        if (valueType === "number" && (typeof value !== "number" || !Number.isFinite(value)))
          return invalid();
        if (valueType === "string" && typeof value !== "string")
          return invalid();
        if (valueType === "array" && !Array.isArray(value)) return invalid();
        const size = typeof value === "number" ? value : typeof value === "string" || Array.isArray(value) ? value.length : void 0;
        if ((min !== void 0 || max !== void 0) && (size === void 0 || typeof min === "number" && size < min || typeof max === "number" && size > max))
          return invalid();
        return "";
      }
    };
  });
}
function parseDefinition(text, policy) {
  if (text.length > 1e5) throw new Error("Definition exceeds supported size");
  const value = JSON.parse(text);
  index.safeJson(value);
  if (!index.record(value)) throw new Error("Expected definition object");
  keys(value, ["id", "revision", "engine", "contract", "schema"]);
  if (typeof value.id !== "string" || !value.id || value.id.length > 120 || !Number.isSafeInteger(value.revision) || Number(value.revision) < 1 || value.engine !== "formily@2.3.7" || value.contract !== "zxui-schema-form-v2")
    throw new Error("Unsupported definition identity/version");
  let count = 0;
  const fields = /* @__PURE__ */ new Set();
  function node(input2, depth = 0, root = false) {
    var _a, _b;
    if (++count > 200 || depth > 16)
      throw new Error("Definition exceeds schema node/depth limit");
    if (!index.record(input2)) throw new Error("Invalid schema node");
    keys(input2, [
      "type",
      "title",
      "properties",
      "x-component",
      "x-component-props",
      "x-decorator",
      "required",
      "x-validator",
      "x-ai-context"
    ]);
    if (!["object", "void", "string", "number", "array"].includes(
      String(input2.type)
    ) || root && input2.type !== "object")
      throw new Error("Invalid schema type");
    if (input2.title !== void 0 && typeof input2.title !== "string")
      throw new Error("Invalid title");
    if (input2.required !== void 0 && typeof input2.required !== "boolean")
      throw new Error("Invalid required");
    if (input2["x-decorator"] !== void 0 && input2["x-decorator"] !== "ZxField")
      throw new Error("Unknown decorator");
    const component = input2["x-component"];
    if (component !== void 0 && (typeof component !== "string" || !Object.hasOwn(policy, component)))
      throw new Error("Unknown component");
    if (!root && input2.type !== "void" && component === void 0)
      throw new Error("A data field requires a registered component");
    const result = { type: input2.type };
    const contextReference = parseAIContextReference(input2["x-ai-context"]);
    if (contextReference) {
      if (root || input2.type === "void")
        throw new Error("AI context requires a data field");
      result["x-ai-context"] = contextReference;
    }
    if (input2.title !== void 0) result.title = input2.title;
    if (input2.required !== void 0)
      result.required = input2.required;
    if (component !== void 0) result["x-component"] = component;
    if (input2["x-decorator"] !== void 0) result["x-decorator"] = "ZxField";
    if (input2["x-component-props"] !== void 0) {
      const props = input2["x-component-props"];
      if (!index.record(props) || typeof component !== "string")
        throw new Error("Invalid component props");
      keys(props, policy[component].props);
      for (const [name, v] of Object.entries(props))
        if (!(((_b = (_a = policy[component].validators) == null ? void 0 : _a[name]) == null ? void 0 : _b.call(_a, v)) ?? prop(name, v)))
          throw new Error(`Invalid component prop: ${name}`);
      result["x-component-props"] = props;
    }
    if (input2["x-validator"] !== void 0)
      result["x-validator"] = validation(input2["x-validator"]);
    if (input2.properties !== void 0) {
      if (!root && input2.type !== "void" || !index.record(input2.properties))
        throw new Error(
          "Only root object/void layout may contain JSON properties"
        );
      result.properties = Object.fromEntries(
        Object.entries(input2.properties).map(([name, child]) => {
          if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || Object.hasOwn(Object.prototype, name) || name === "prototype")
            throw new Error("Unsafe field path");
          if (index.record(child) && child.type !== "void") {
            if (fields.has(name)) throw new Error("Duplicate flat data path");
            fields.add(name);
          }
          return [name, node(child, depth + 1)];
        })
      );
    }
    return result;
  }
  return {
    id: value.id,
    revision: Number(value.revision),
    engine: "formily@2.3.7",
    contract: "zxui-schema-form-v2",
    schema: node(value.schema, 0, true)
  };
}
exports.ZxSchemaForm = _sfc_main;
exports.createZxuiBindings = createZxuiBindings;
exports.createZxuiDefinitionPolicy = createZxuiDefinitionPolicy;
exports.parseDefinition = parseDefinition;
