import { Field, Form, GeneralField } from '@formily/core';
import { createArrays } from './arrays';
/** One public-model boundary: native registration and automatic validation stay private. */
export declare function createModelBoundary(ports: {
    form: Form;
    assertCurrent(field: GeneralField): void;
    arrays: ReturnType<typeof createArrays>;
    deny(name: string): never;
    transaction<R>(work: () => R): R;
}): {
    fieldView: (field: GeneralField) => GeneralField;
    formView: Form<any>;
    rawField: (field: Field) => Field;
};
