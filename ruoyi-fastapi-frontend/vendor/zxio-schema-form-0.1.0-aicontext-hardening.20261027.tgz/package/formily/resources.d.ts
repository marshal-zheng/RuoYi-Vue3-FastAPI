import { FieldIssue } from './types';
import { Field } from '@formily/core';
export type ResourceScope = 'record' | 'edit' | Field;
export type TaskState = 'pending' | 'success' | 'error' | 'cancelled' | 'superseded';
export interface ResourceOptions {
    scope?: ResourceScope;
    blocking?: boolean;
}
export interface ResourceOrigin {
    token?: object;
    run<R>(work: () => R): R;
    identity?: readonly unknown[];
}
/** A lifecycle registry, with no dependency graph and no reaction scheduler. */
export declare function createResources(signal: AbortSignal, semantic?: (token: object | undefined) => void): {
    version: import('vue').ShallowRef<number, number>;
    runLatest: <I, R>(runtime: object, key: string, captured: I, load: (input: I, signal: AbortSignal) => Promise<R>, commit: (value: R) => void, options?: ResourceOptions, applicable?: () => boolean, origin?: ResourceOrigin) => void;
    retry: (key: string, scope?: ResourceScope) => void;
    cancel: (key: string, scope?: ResourceScope, applicable?: boolean, token?: object) => void;
    bindResource: <V>(runtime: object, source: () => V, project: (value: V) => void, applicable?: () => boolean) => () => void;
    refresh(runtime: object): void;
    prune(runtime: object, token?: object): void;
    retire: (runtime: object) => void;
    pending: () => boolean;
    requiredPending: () => boolean;
    issues: () => FieldIssue[];
    feedback: () => FieldIssue[];
    dispose: () => void;
    states: () => {
        key: string;
        scope: ResourceScope;
        state: TaskState;
        error: string | undefined;
    }[];
};
export type Resources = ReturnType<typeof createResources>;
