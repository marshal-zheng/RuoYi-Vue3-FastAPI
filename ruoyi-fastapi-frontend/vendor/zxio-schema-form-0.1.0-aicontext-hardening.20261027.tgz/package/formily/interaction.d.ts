/** Normalize native pattern and authored control flags at every write surface. */
export declare function fieldInteraction(pattern: string, componentProps: Record<string, unknown>, disabled?: boolean): {
    disabled: boolean;
    readonly: boolean;
    writable: boolean;
};
