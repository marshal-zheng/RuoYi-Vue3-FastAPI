# 一个保存域跨多个分区

void 节点只改变 address，不改变数据 path。下列两个区域的 canonical 仍是 `{ source, target }`，只校验/保存一次。真实独立保存的端口 tab 可以分别拥有自己的保存域，无需强制联合提交。

```ts
import type { BusinessContext, SettledCheck } from '@zxio/schema-form/formily'
type Value = { source: number; target: number }
export function createSchema(ctx: BusinessContext<Value>) {
  return {
    type: 'object',
    properties: {
      inputs: {
        type: 'void',
        title: '输入',
        'x-component': 'ZxSection',
        properties: {
          source: { type: 'number', 'x-component': 'ZxInputNumber' },
        },
      },
      outputs: {
        type: 'void',
        title: '输出',
        'x-component': 'ZxSection',
        properties: {
          target: {
            type: 'number',
            'x-component': 'ZxInputNumber',
            'x-reactions': (field) => {
              const values = field.form.values
              field.setValue(values.source * 2)
              field.disabled = values.source < 0
            },
          },
        },
      },
    },
  }
}
export const assertSettled: SettledCheck<Value> = (values, states) => {
  const target = states.find(
    (state) => state.path.length === 1 && state.path[0] === 'target'
  )
  return values.target === values.source * 2 &&
    target?.pattern === (values.source < 0 ? 'disabled' : 'editable')
    ? []
    : [{ path: ['target'], message: '派生值或状态不一致' }]
}
```

同步 function reaction 中普通 helper 读取 native observable values，Formily 自动收集分支依赖；不需要维护 link/update 列表。不要读取 ctx.read() 快照来期望引擎跟踪。assertSettled 输入只读且同步，检查值和动态状态，不写值、不重跑 reactions、不验证依赖表。分拆的自读自写 RS422 prefix/total 可能静默停在旧值，必须用只读完整 normalize 对照检出。

`ctx.configure(field, { required, validator, dataSource, componentProps, validationActive })` 复制配置并递增版本。配置数组/嵌套对象只读；不能原地 push/修改。不支持绕过编译的 createField/effects/原生 validate、动态替换 component；使用 `ctx.replaceSchema(schema)`，它编译所有 properties/items，保留同一个 Form 和 canonical，并废弃旧控件/反馈身份。显式动态 schema 边界使用原生 ISchema，其不确定性不伪装成静态顶层类型。

内置选择器的动态选项只写 `dataSource`，由适配器传给控件；不要同时写 `componentProps.options`。静态 `x-component-props.options` 仍可定义初始候选。提交断言核验当前 `states[].dataSource` 与领域候选一致即可，其他展示属性继续由 `componentProps` 承载。

Vue ref/props 使用 `ctx.bindResource(source, project, { scope })` 同步桥接。record scope 跨 reset 重投影，edit scope 随重建结束，原生 field scope 随字段删除释放。schema 删除后重挂不会重复订阅。

异步使用 `ctx.runLatest(key, input, load, commit, { scope, blocking })`。reaction 在 await 前捕获 input；load 接收 AbortSignal，commit 必须同步。只允许 blocking 任务提交 canonical；展示任务只更新展示配置。相同 input 复用当前任务；失败显式 retryLatest，cancelLatest 可保留阻断，只有政策不再适用时传 applicable=false 解除。逆序、忽略 signal、旧 finally 都按任务身份隔离。裸 Promise 不在 settled 契约内。

远程选择器使用 `onSearch` 事件发起 runLatest，在受管 commit 内更新 dataSource 和 loading/error 展示；通过 onRetry 重试当前关键词。不要把函数加载器写入字段的 options；候选请求归会话管理，字段删除、reset 和换记录时一并取消。可选候选加载使用 blocking=false，保留当前合法值的提交能力。

隐藏保留 canonical；display none 明确清值并进入值版本。可见性、保值、校验适用性和 DTO 包含性分别决定：退出分支用 configure validationActive=false 撤销旧规则及其反馈，单纯 hidden 不撤销有效错误/blocking。用户意图清空写在受控 onChange，不能在 authority/reset reaction 中冒充用户清空。

实际跨分区、JSON raw 和整记录校验例子：[LinkedSections.vue](../../examples/recipes/LinkedSections.vue)。
