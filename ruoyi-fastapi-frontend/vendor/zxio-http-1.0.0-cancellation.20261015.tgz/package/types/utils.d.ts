import type { RequestOptions, ResolvedRequestOptions } from './types.js';
export declare function isPlainObject(value: unknown): value is Record<string, unknown>;
export declare function deepMerge<T extends Record<string, unknown>>(target: T, ...sources: Array<Record<string, unknown> | undefined>): T;
export declare function joinTimestamp(join: boolean | undefined, restful?: boolean): string | {
    _t?: undefined;
} | {
    _t: number;
};
export declare function createUrlSearchParams(params: Record<string, unknown>): string;
export declare function resolveRequestOptions(base?: RequestOptions, override?: RequestOptions, defaults?: {
    successCodes?: Array<string | number>;
}): ResolvedRequestOptions;
export declare function isFormData(value: unknown): value is FormData;
/**
 * 生成请求负载的稳定描述，用于去重与取消的 key。
 * FormData、Blob、流等无法序列化的负载按实例区分，避免不同内容折叠成同一请求。
 */
export declare function describeRequestPayload(value: unknown): string;
export declare function isNil(value: unknown): value is null | undefined;
export declare function normalizeParams(input: Record<string, unknown>): Record<string, unknown>;
