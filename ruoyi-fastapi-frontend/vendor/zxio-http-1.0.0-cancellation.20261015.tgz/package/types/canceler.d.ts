import type { AxiosRequestConfig, GenericAbortSignal } from 'axios';
import type { HttpRequestConfig } from './types.js';
export declare function getPendingKey(config: AxiosRequestConfig): string;
export declare function createLinkedAbortController(signal?: GenericAbortSignal): {
    controller: AbortController;
    dispose: () => void;
};
export declare class AxiosCanceler {
    private pendingMap;
    private registrations;
    add(config: HttpRequestConfig): void;
    remove(config: AxiosRequestConfig, cancelPending?: boolean): void;
    clear(): void;
}
