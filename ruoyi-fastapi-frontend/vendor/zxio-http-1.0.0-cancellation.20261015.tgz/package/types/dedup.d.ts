import type { HttpRequestConfig } from './types.js';
export interface DedupConfig {
    /** 是否启用去重，默认 false */
    enabled?: boolean;
    /** 自定义 key 生成函数 */
    keyGenerator?: (config: HttpRequestConfig) => string;
}
/**
 * 默认的请求 key 生成函数
 * 根据 method, url, params, data 生成唯一标识
 */
export declare function defaultKeyGenerator(config: HttpRequestConfig): string;
export declare class DedupManager {
    private pending;
    private config;
    constructor(config?: DedupConfig);
    /**
     * 生成请求的唯一 key
     */
    generateKey(config: HttpRequestConfig): string;
    /**
     * 获取或创建请求 Promise
     * 如果已有相同 key 的请求在进行中，返回该 Promise
     * 否则执行 factory 创建新的 Promise
     */
    getOrCreate<T>(key: string, factory: () => Promise<T>): Promise<T>;
    /**
     * 清除指定 key 的 pending 状态
     */
    clear(key: string): void;
    /**
     * 清除所有 pending 状态
     */
    clearAll(): void;
    /**
     * 检查是否启用去重
     */
    isEnabled(): boolean;
    /**
     * 获取当前 pending 请求数量
     */
    getPendingCount(): number;
    /**
     * 检查指定 key 是否有 pending 请求
     */
    hasPending(key: string): boolean;
}
/**
 * 创建去重管理器
 */
export declare function createDedupManager(config?: DedupConfig): DedupManager;
