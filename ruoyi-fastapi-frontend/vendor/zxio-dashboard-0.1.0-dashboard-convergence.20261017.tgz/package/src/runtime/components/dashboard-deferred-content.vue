<template>
  <div
    ref="root"
    class="zx-dashboard-panel__deferred"
    :data-content-mounted="ready"
  >
    <slot v-if="ready" />
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'

import type { createDashboardContentVisibility } from '../content-visibility'

const props = defineProps<{
  visibility: ReturnType<typeof createDashboardContentVisibility>
}>()
const root = ref<HTMLElement>()
const ready = ref(false)
let stop: (() => void) | undefined
let focusRoot: Element | null = null
function reveal() {
  ready.value = true
  stop?.()
  focusRoot?.removeEventListener('focusin', reveal)
}
onMounted(() => {
  if (!root.value) return
  focusRoot =
    root.value.closest('[data-dashboard-panel-id]') ??
    root.value.closest('.zx-dashboard-grid__item')
  focusRoot?.addEventListener('focusin', reveal)
  stop = props.visibility.observe(root.value, reveal)
  if (focusRoot?.contains(document.activeElement)) reveal()
})
onBeforeUnmount(() => {
  stop?.()
  focusRoot?.removeEventListener('focusin', reveal)
})
</script>
