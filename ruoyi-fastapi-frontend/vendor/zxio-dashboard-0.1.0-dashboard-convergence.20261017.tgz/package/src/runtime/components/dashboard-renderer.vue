<script lang="ts">
import {
  type PropType,
  computed,
  defineComponent,
  h,
  nextTick,
  onBeforeUnmount,
  readonly,
  ref,
  watch,
} from 'vue'
import ZxDashboardGrid from './dashboard-grid.vue'
import ZxDashboardLayoutContainer from './dashboard-layout-container.vue'
import { mergeDashboardLeafPanels } from '../grid/grouping'
import ZxDashboardPanelChrome from './dashboard-panel-chrome.vue'
import ZxDashboardDeferredContent from './dashboard-deferred-content.vue'
import { createDashboardContentVisibility } from '../content-visibility'
import { provideDashboardRuntimeContext } from '../context/dashboard-runtime-context'
import { resolveDashboardRuntimeMode } from '../mode'
import { createDashboardPanelAction } from '../actions'
import {
  dashboardPanelLinkAction,
  resolveDashboardThresholdState,
  useDashboardHostData,
} from '../host-data'
import { normalizeDashboardPanelState } from '../panel-state'
import { isDashboardPanelHidden } from '../grid/panel-layout'
import {
  formatDashboardCopy,
  provideDashboardLocale,
  useDashboardLocale,
} from '../../locale'

import type {
  DashboardDocument,
  DashboardLayout,
  DashboardPanel,
} from '../../schema'
import type { DashboardLocaleSource } from '../../locale'
import type {
  DashboardChromeVariant,
  DashboardEditorCommandRequestEvent,
  DashboardGridOptions,
  DashboardLayoutChangeEvent,
  DashboardLayoutInteractionEvent,
  DashboardMaximizeChangeEvent,
  DashboardPanelActionEvent,
  DashboardPanelAddRequestEvent,
  DashboardPanelChromeOptions,
  DashboardPanelContentResolver,
  DashboardPanelRenderContext,
  DashboardPanelStateInfo,
  DashboardPanelStateInput,
  DashboardPanelUpdateRequestEvent,
  DashboardReadonlyDocument,
  DashboardRuntimeContext,
  DashboardRuntimeIssue,
  DashboardRuntimeMode,
  DashboardWidgetEvent,
} from '../types'

const KNOWN_CHROME_VARIANTS = new Set<DashboardChromeVariant>([
  'silent',
  'card',
])

export default defineComponent({
  name: 'ZxDashboardRenderer',
  props: {
    document: Object as PropType<DashboardDocument>,
    panels: Array as PropType<DashboardPanel[]>,
    mode: String as PropType<DashboardRuntimeMode>,
    editable: Boolean,
    lazy: Boolean,
    kiosk: Boolean,
    layoutOnlyMode: Boolean,
    grid: Object as PropType<DashboardGridOptions>,
    panelChrome: Object as PropType<DashboardPanelChromeOptions>,
    resolvePanelContent: Function as PropType<DashboardPanelContentResolver>,
    chromeVariant: String as PropType<DashboardChromeVariant>,
    selectedPanelId: String,
    /** Controlled maximized panel; `null` restores. Omit to let the renderer own it. */
    maximizedPanelId: {
      type: String as PropType<string | null>,
      default: undefined,
    },
    /** `'zh-CN'` / `'en'`, a full locale, or a partial override merged onto the base. */
    locale: {
      type: [String, Object] as PropType<DashboardLocaleSource>,
      default: undefined,
    },
  },
  emits: [
    'update:panels',
    'update:layout',
    'update:maximizedPanelId',
    'maximize-change',
    'layout-change',
    'drag-start',
    'drag-stop',
    'resize-start',
    'resize-stop',
    'panel-add-request',
    'editor-command-request',
    'panel-action',
    'panel-update-request',
    'widget-event',
    'runtime-issue',
    'refresh-request',
    'panel-link-request',
    'unresolved-panel',
  ],
  setup(props, { emit, slots }) {
    const contentVisibility = createDashboardContentVisibility()
    onBeforeUnmount(contentVisibility.dispose)
    const reportedUnresolvedPanels = new Set<string>()
    const reportedUnknownVariants = new Set<string>()
    // A host-provided locale (or an enclosing renderer / designer) stays in
    // effect unless this instance sets its own.
    const parentLocale = useDashboardLocale()
    const locale = provideDashboardLocale(
      () => props.locale ?? parentLocale.value
    )
    const runtimeMode = computed(() =>
      resolveDashboardRuntimeMode({
        mode: props.kiosk ? 'view' : props.mode,
        editable: props.editable,
        layoutOnlyMode: props.layoutOnlyMode,
      })
    )

    const resolvedChromeVariant = computed<DashboardChromeVariant>(() => {
      const requested = props.chromeVariant
      if (requested === undefined || requested === null || requested === '') {
        return 'silent'
      }
      if (KNOWN_CHROME_VARIANTS.has(requested)) {
        return requested
      }
      const offendingValue = String(requested)
      if (!reportedUnknownVariants.has(offendingValue)) {
        reportedUnknownVariants.add(offendingValue)
        const issue: DashboardRuntimeIssue = {
          severity: 'warn',
          code: 'unknown_chrome_variant',
          message: formatDashboardCopy(
            locale.value.issues.unknown_chrome_variant,
            { value: offendingValue }
          ),
        }
        scheduleRuntimeDiagnostic(() => emit('runtime-issue', issue))
      }
      return 'silent'
    })
    const resolvedPanels = computed<DashboardPanel[]>(
      () => props.panels ?? props.document?.panels ?? []
    )
    // Hidden panels (`metadata.layout.hidden`) stay in the document but leave
    // the grid outside edit mode; in edit mode they render dimmed so they can
    // be shown again.
    const gridPanels = computed<DashboardPanel[]>(() =>
      runtimeMode.value === 'edit'
        ? resolvedPanels.value
        : resolvedPanels.value.filter((panel) => !isDashboardPanelHidden(panel))
    )

    const rootRef = ref<HTMLElement>()

    // --- maximize ---------------------------------------------------------
    const internalMaximizedPanelId = ref<string | null>(null)
    const maximizedPanelId = computed<string | null>(() =>
      props.maximizedPanelId !== undefined
        ? props.maximizedPanelId
        : internalMaximizedPanelId.value
    )
    const maximizedPanel = computed<DashboardPanel | undefined>(() => {
      const id = maximizedPanelId.value
      if (!id) return undefined
      return gridPanels.value.find((panel) => panel.id === id)
    })

    function setMaximized(panelId: string | null) {
      if (maximizedPanelId.value === panelId) return
      const focusPanelId = panelId ?? maximizedPanelId.value
      internalMaximizedPanelId.value = panelId
      emit('update:maximizedPanelId', panelId)
      nextTick(() => {
        const root = rootRef.value
        // Remounting the grid can focus its first item. Restore the action on
        // the panel that initiated this transition after the engine has mounted.
        if (root) {
          const panelRoot = Array.from(
            root.querySelectorAll<HTMLElement>('.zx-dashboard-panel')
          ).find((panel) => panel.dataset.panelId === focusPanelId)
          const target = panelRoot?.querySelector<HTMLElement>(
            '.zx-dashboard-panel__action'
          )
          const focusTarget = target ?? root
          focusTarget.focus({ preventScroll: true })
        }
      })
      const panel = panelId
        ? resolvedPanels.value.find((candidate) => candidate.id === panelId)
        : undefined
      emit('maximize-change', {
        type: 'maximize-change',
        mode: runtimeMode.value,
        source: 'panel-chrome',
        panelId,
        panel,
      } satisfies DashboardMaximizeChangeEvent)
    }

    watch([maximizedPanelId, gridPanels], ([id, panels]) => {
      if (id && !panels.some((panel) => panel.id === id)) setMaximized(null)
    })

    function handleDocumentKeydown(event: KeyboardEvent) {
      if (event.key !== 'Escape' || event.defaultPrevented) return
      if (
        !maximizedPanelId.value ||
        rootRef.value?.querySelector('.zx-dashboard-panel.is-menu-open')
      )
        return
      setMaximized(null)
    }

    watch(
      maximizedPanelId,
      (id) => {
        if (typeof document === 'undefined') return
        if (id) document.addEventListener('keydown', handleDocumentKeydown)
        else document.removeEventListener('keydown', handleDocumentKeydown)
      },
      { immediate: true }
    )

    onBeforeUnmount(() => {
      if (typeof document === 'undefined') return
      document.removeEventListener('keydown', handleDocumentKeydown)
    })

    // Built-in view actions are handled here before the host sees them, so a
    // bare `createDashboardPanelAction('maximize')` works without wiring.
    function emitPanelAction(event: DashboardPanelActionEvent) {
      if (event.action === 'maximize') setMaximized(event.panelId)
      else if (event.action === 'restore') setMaximized(null)
      else if (event.action === 'refresh')
        hostData.requestRefresh({
          panelId: event.panelId,
          source: event.source,
        })
      else {
        const link = resolvedPanels.value
          .find((panel) => panel.id === event.panelId)
          ?.links?.find(
            (link) => dashboardPanelLinkAction(link.id) === event.action
          )
        if (link)
          hostData.requestPanelLink({
            panelId: event.panelId,
            linkId: link.id,
            source: event.source,
          })
      }
      emit('panel-action', event)
    }
    // Bound Vue's generic inference for recursive JSON; runtime readonly
    // still protects every nested value, as required by the public context.
    const readonlyDocument = computed(() => {
      const document = props.document
      return document
        ? (readonly<object>(document) as DashboardReadonlyDocument)
        : undefined
    })
    const editable = computed(() => runtimeMode.value === 'edit')
    const isReadonly = computed(() => runtimeMode.value === 'view')

    const hostData = useDashboardHostData({
      document: () => readonlyDocument.value,
      panels: () => resolvedPanels.value,
      mode: () => runtimeMode.value,
      onRefresh: (event) => emit('refresh-request', event),
      onLink: (event) => emit('panel-link-request', event),
    })

    const resolvePanelState = (
      panel: DashboardPanel
    ): DashboardPanelStateInfo | undefined => {
      const chromeOptions = props.panelChrome
      if (!chromeOptions) return resolveDashboardThresholdState(panel)

      if (typeof chromeOptions.getPanelState === 'function') {
        const value = chromeOptions.getPanelState(panel)
        const normalized = normalizeDashboardPanelState(value)
        if (normalized) return normalized
      }

      const map = chromeOptions.panelState
      if (map) {
        let raw: DashboardPanelStateInput | undefined
        if (
          typeof (map as Map<string, DashboardPanelStateInput>).get ===
          'function'
        ) {
          raw = (map as Map<string, DashboardPanelStateInput>).get(panel.id)
        } else {
          raw = (map as Record<string, DashboardPanelStateInput>)[panel.id]
        }
        const normalized = normalizeDashboardPanelState(raw)
        if (normalized) return normalized
      }

      return resolveDashboardThresholdState(panel)
    }

    const context: DashboardRuntimeContext = {
      mode: runtimeMode,
      editable,
      readonly: isReadonly,
      document: readonlyDocument,
      variables: hostData.variables,
      timeRange: hostData.timeRange,
      refresh: hostData.refresh,
      refreshTick: hostData.refreshTick,
      requestRefresh: hostData.requestRefresh,
      requestPanelLink: hostData.requestPanelLink,
      chromeVariant: resolvedChromeVariant,
      resolvePanelState,
      requestPanelUpdate: (input) => {
        emit('panel-update-request', {
          type: 'panel-update-request',
          mode: runtimeMode.value,
          source: input.source ?? 'panel-content',
          panelId: input.panelId,
          panel: input.panel,
          patch: input.patch,
        } satisfies DashboardPanelUpdateRequestEvent)
      },
      dispatchPanelAction: (input) => {
        emitPanelAction({
          type: 'panel-action',
          mode: runtimeMode.value,
          source: input.source ?? 'panel-content',
          panelId: input.panelId,
          panel: input.panel,
          action: input.action,
          payload: input.payload,
        } satisfies DashboardPanelActionEvent)
      },
      emitWidgetEvent: (input) => {
        emit('widget-event', {
          type: 'widget-event',
          mode: runtimeMode.value,
          source: input.source ?? 'panel-content',
          panelId: input.panelId,
          panel: input.panel,
          widget: input.widget,
          variant: input.variant,
          event: input.event,
          payload: input.payload,
        } satisfies DashboardWidgetEvent)
      },
      reportRuntimeIssue: (issue) => emit('runtime-issue', issue),
    }

    provideDashboardRuntimeContext(context)

    function panelRenderContext(): DashboardPanelRenderContext {
      return {
        mode: runtimeMode.value,
        document: readonlyDocument.value,
        ...hostData.view(),
        requestRefresh: hostData.requestRefresh,
        requestPanelLink: hostData.requestPanelLink,
        dispatchPanelAction: context.dispatchPanelAction,
        requestPanelUpdate: context.requestPanelUpdate,
        emitWidgetEvent: context.emitWidgetEvent,
      }
    }

    function reportUnresolvedPanel(
      panel: DashboardPanel
    ): DashboardRuntimeIssue {
      const issue: DashboardRuntimeIssue = {
        severity: 'warn',
        code: 'unresolved_widget',
        message: formatDashboardCopy(locale.value.issues.unresolved_widget, {
          widget: panel.widget,
        }),
        panelId: panel.id,
        path: `/panels/${panel.id}`,
      }

      if (!reportedUnresolvedPanels.has(panel.id)) {
        reportedUnresolvedPanels.add(panel.id)
        scheduleRuntimeDiagnostic(() => {
          emit('unresolved-panel', { panel, issue })
          emit('runtime-issue', issue)
        })
      }

      return issue
    }

    function renderPanelContent(panel: DashboardPanel) {
      const slotProps = {
        panel,
        mode: runtimeMode.value,
        context,
        dispatchPanelAction: context.dispatchPanelAction,
        requestPanelUpdate: context.requestPanelUpdate,
        emitWidgetEvent: context.emitWidgetEvent,
      }

      if (slots.panel) return slots.panel(slotProps)

      const resolved = props.resolvePanelContent?.(panel, panelRenderContext())

      if (resolved !== undefined && resolved !== null) return resolved

      const issue = reportUnresolvedPanel(panel)
      return (
        slots.unresolved?.({ panel, issue }) ??
        h(
          'div',
          {
            class: 'zx-dashboard-panel__unresolved',
            'data-dashboard-runtime-issue': issue.code,
          },
          formatDashboardCopy(locale.value.panel.unresolved, {
            widget: panel.widget,
          })
        )
      )
    }

    function renderPanel(panel: DashboardPanel, inGrid = false) {
      if (props.lazy && inGrid) {
        return h(
          ZxDashboardDeferredContent,
          { visibility: contentVisibility },
          { default: () => renderPanelChrome(panel, inGrid) }
        )
      }
      return renderPanelChrome(panel, inGrid)
    }

    function renderPanelChrome(panel: DashboardPanel, inGrid: boolean) {
      const chromeOptions = props.panelChrome ?? {}
      const iconSlot = slots['panel-icon']
      const defaults = chromeOptions.actions ?? [
        createDashboardPanelAction('maximize'),
      ]
      const actions = chromeOptions.getPanelActions
        ? chromeOptions.getPanelActions(panel, defaults)
        : defaults

      return h(
        ZxDashboardPanelChrome,
        {
          panel,
          mode: runtimeMode.value,
          showHeader: props.kiosk ? false : chromeOptions.showHeader,
          contentPadding: props.kiosk ? false : chromeOptions.contentPadding,
          draggableHandleClass: chromeOptions.draggableHandleClass,
          actions: props.kiosk
            ? []
            : [
                ...actions,
                ...(panel.links ?? []).map((link) => ({
                  type: dashboardPanelLinkAction(link.id),
                  label: link.title,
                  placement: 'menu' as const,
                  visibleIn: ['view', 'layout', 'edit'] as const,
                  group: 'links',
                })),
              ],
          headerMode: chromeOptions.headerMode,
          focusable: inGrid ? false : chromeOptions.focusable,
          managedFocus: inGrid,
          hoverElevation: chromeOptions.hoverElevation,
          selected:
            props.selectedPanelId !== undefined &&
            panel.id === props.selectedPanelId,
          maximized: panel.id === maximizedPanelId.value,
          onPanelAction: emitPanelAction,
          onPanelUpdateRequest: (event: DashboardPanelUpdateRequestEvent) =>
            emit('panel-update-request', event),
        },
        {
          default: () => renderPanelContent(panel),
          ...(iconSlot
            ? {
                icon: (slotProps: Record<string, unknown>) =>
                  iconSlot(slotProps),
              }
            : {}),
        }
      )
    }

    function renderMaximized(panel: DashboardPanel) {
      return h(
        'div',
        {
          class: 'zx-dashboard__maximized',
          'data-dashboard-maximized-panel': panel.id,
        },
        renderPanel(panel)
      )
    }

    function renderGrid(panelIds?: string[], containerId = '$root') {
      const members = panelIds
        ? gridPanels.value.filter((panel) => panelIds.includes(panel.id))
        : gridPanels.value
      return h(
        ZxDashboardGrid,
        {
          panels: members,
          mode: runtimeMode.value,
          grid: props.kiosk
            ? { ...props.grid, margin: [0, 0], containerPadding: [0, 0] }
            : props.grid,
          'onUpdate:panels': (panels: DashboardPanel[]) =>
            emit(
              'update:panels',
              mergeDashboardLeafPanels(resolvedPanels.value, members, panels),
              { containerId }
            ),
          onLayoutChange: (event: DashboardLayoutChangeEvent) =>
            emit('layout-change', {
              ...event,
              panels: mergeDashboardLeafPanels(
                resolvedPanels.value,
                members,
                event.panels
              ),
            }),
          onDragStart: (event: DashboardLayoutInteractionEvent) =>
            emit('drag-start', event),
          onDragStop: (event: DashboardLayoutInteractionEvent) =>
            emit('drag-stop', event),
          onResizeStart: (event: DashboardLayoutInteractionEvent) =>
            emit('resize-start', event),
          onResizeStop: (event: DashboardLayoutInteractionEvent) =>
            emit('resize-stop', event),
          onPanelAddRequest: (event: DashboardPanelAddRequestEvent) =>
            emit('panel-add-request', { ...event, containerId }),
          onEditorCommandRequest: (event: DashboardEditorCommandRequestEvent) =>
            emit('editor-command-request', event),
          onRuntimeIssue: (issue: DashboardRuntimeIssue) =>
            emit('runtime-issue', issue),
        },
        {
          default: ({ panel }: { panel: DashboardPanel }) =>
            renderPanel(panel, true),
        }
      )
    }

    return () =>
      h(
        'div',
        {
          class: [
            'zx-dashboard',
            `zx-dashboard--${runtimeMode.value}`,
            {
              'is-maximized': Boolean(maximizedPanel.value),
              'is-kiosk': props.kiosk,
            },
          ],
          ref: rootRef,
          tabindex: -1,
          'data-dashboard-mode': runtimeMode.value,
          'data-dashboard-chrome': resolvedChromeVariant.value,
          'data-zx-surface': 'canvas',
          'data-dashboard-maximized': maximizedPanel.value
            ? maximizedPanel.value.id
            : undefined,
        },
        [
          !props.kiosk && slots.controls?.({ context }),
          gridPanels.value.length === 0 && !props.document?.layout
            ? slots.empty?.({ mode: runtimeMode.value, context }) ??
              h('div', { class: 'zx-dashboard__empty' })
            : props.document?.layout
            ? [
                h(
                  ZxDashboardLayoutContainer,
                  {
                    layout: props.document.layout,
                    hidden: Boolean(maximizedPanel.value),
                    mode: runtimeMode.value,
                    'onUpdate:layout': (layout: DashboardLayout) =>
                      emit('update:layout', layout),
                  },
                  {
                    grid: ({
                      panelIds,
                      containerId,
                    }: {
                      panelIds: string[]
                      containerId: string
                    }) =>
                      maximizedPanel.value
                        ? []
                        : renderGrid(panelIds, containerId),
                  }
                ),
                maximizedPanel.value
                  ? renderMaximized(maximizedPanel.value)
                  : null,
              ]
            : maximizedPanel.value
            ? renderMaximized(maximizedPanel.value)
            : renderGrid(),
        ]
      )
  },
})

function scheduleRuntimeDiagnostic(callback: () => void): void {
  if (typeof globalThis.queueMicrotask === 'function') {
    globalThis.queueMicrotask(callback)
    return
  }

  Promise.resolve().then(callback)
}
</script>
