import {
  chmodSync,
  closeSync,
  existsSync,
  fsyncSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  openSync,
  readFileSync,
  readdirSync,
  readlinkSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'node:fs'
import { homedir } from 'node:os'
import {
  basename,
  dirname,
  isAbsolute,
  join,
  relative,
  resolve,
  sep,
} from 'node:path'
import { verifyTailwindContractArtifactSet } from '../adapters/tailwind'
import { verifyArtifactSet } from '../compiler'
import { decodeArtifactBytes } from '../core/artifact-graph'
import { compareCodePoint, sha256 } from '../core/canonical-text'
import { diagnostic } from '../core/diagnostics'
import { type CompilerResult, failure, success } from '../core/result'
import { validateThemeManifest } from '../targets/manifest/validator'

import type { WriteArtifactSetRequest } from '../model'
import type {
  ArtifactFile,
  TailwindContractArtifactSet,
  ThemeArtifactSet,
} from '../core/artifact-graph'

export interface WriteReceipt {
  readonly generatedRoot: string
  readonly added: readonly string[]
  readonly changed: readonly string[]
  readonly deleted: readonly string[]
  readonly artifactSetHash: `sha256:${string}`
}

export interface ArtifactDiff {
  readonly missing: readonly string[]
  readonly extra: readonly string[]
  readonly changed: readonly string[]
  readonly matches: boolean
}

export interface CompareArtifactSetRequest {
  readonly packageRoot: string
  readonly generatedRoot: 'generated'
  readonly artifactSet: ThemeArtifactSet | TailwindContractArtifactSet
}

function verifyCompleteArtifactSet(
  input: unknown
): CompilerResult<ThemeArtifactSet | TailwindContractArtifactSet> {
  if (
    input &&
    typeof input === 'object' &&
    (input as Readonly<{ kind?: unknown }>).kind === 'theme'
  ) {
    return verifyArtifactSet(input)
  }
  if (
    input &&
    typeof input === 'object' &&
    (input as Readonly<{ kind?: unknown }>).kind === 'tailwind-contract'
  ) {
    return verifyTailwindContractArtifactSet(input)
  }
  return failure([
    diagnostic({
      code: 'TC_INPUT_INVALID',
      phase: 'write',
      remediation: { code: 'PASS_VERIFIED_COMPLETE_ARTIFACT_SET' },
      details: { issue: 'unknown-artifact-set-kind' },
    }),
  ])
}

function within(parent: string, child: string): boolean {
  const path = relative(parent, child)
  return (
    path !== '' &&
    path !== '..' &&
    !path.startsWith(`..${sep}`) &&
    !isAbsolute(path)
  )
}

function safeRoots(
  packageRoot: string,
  generatedRoot: 'generated'
): CompilerResult<
  Readonly<{
    packageRoot: string
    generatedRoot: string
  }>
> {
  let realPackage: string
  try {
    realPackage = realpathSync(packageRoot)
  } catch {
    return failure([
      diagnostic({
        code: 'TC_WRITE_OUTSIDE_ROOT',
        phase: 'write',
        target: packageRoot,
        remediation: { code: 'USE_EXISTING_PACKAGE_ROOT' },
        details: { issue: 'package-root-missing' },
      }),
    ])
  }
  const target = resolve(realPackage, generatedRoot)
  const unsafe =
    realPackage === realpathSync(homedir()) ||
    realPackage === sep ||
    existsSync(join(realPackage, '.git')) ||
    !within(realPackage, target) ||
    basename(target) !== 'generated'
  if (unsafe) {
    return failure([
      diagnostic({
        code: 'TC_WRITE_OUTSIDE_ROOT',
        phase: 'write',
        target,
        remediation: { code: 'USE_PACKAGE_GENERATED_ROOT' },
        details: { packageRoot: realPackage, generatedRoot: target },
      }),
    ])
  }
  if (existsSync(target) && lstatSync(target).isSymbolicLink()) {
    return failure([
      diagnostic({
        code: 'TC_WRITE_SYMLINK_ESCAPE',
        phase: 'write',
        target,
        remediation: { code: 'REMOVE_GENERATED_ROOT_SYMLINK' },
        details: { issue: 'generated-root-is-symlink' },
      }),
    ])
  }
  return success({ packageRoot: realPackage, generatedRoot: target })
}

function inventory(
  root: string,
  prefix = ''
): ReadonlyMap<
  string,
  Readonly<{ hash: `sha256:${string}`; symlink: boolean }>
> {
  const output = new Map<
    string,
    Readonly<{ hash: `sha256:${string}`; symlink: boolean }>
  >()
  if (!existsSync(root)) return output
  for (const entry of readdirSync(root, { withFileTypes: true }).sort(
    (left, right) => compareCodePoint(left.name, right.name)
  )) {
    const path = prefix ? `${prefix}/${entry.name}` : entry.name
    const absolute = join(root, entry.name)
    if (entry.isSymbolicLink()) {
      output.set(path, { hash: sha256(readlinkSync(absolute)), symlink: true })
    } else if (entry.isDirectory()) {
      for (const [child, value] of inventory(absolute, path))
        output.set(child, value)
    } else if (entry.isFile()) {
      output.set(path, { hash: sha256(readFileSync(absolute)), symlink: false })
    }
  }
  return output
}

function adapterUpgradeOwnerSet(
  value: unknown,
  root: string,
  candidateFiles: readonly ArtifactFile[]
): ReadonlySet<string> | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null
  const old = value as Record<string, unknown>
  if (!Array.isArray(old.artifacts)) return null
  const expected = new Set(
    candidateFiles
      .map((file) => file.path)
      .filter((path) => path !== 'theme.manifest.json')
  )
  if (old.artifacts.length !== expected.size) return null
  const current = inventory(root)
  const owners = new Set<string>(['theme.manifest.json'])
  for (const item of old.artifacts) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return null
    const artifact = item as Record<string, unknown>
    if (
      typeof artifact.path !== 'string' ||
      typeof artifact.sha256 !== 'string' ||
      !expected.has(artifact.path) ||
      owners.has(artifact.path) ||
      current.get(artifact.path)?.hash !== artifact.sha256
    )
      return null
    owners.add(artifact.path)
  }
  return owners.size === expected.size + 1 ? owners : null
}

function oldOwnerSet(
  root: string,
  candidateFiles: readonly ArtifactFile[]
): CompilerResult<ReadonlySet<string>> {
  if (!existsSync(root)) return success(new Set())
  const themeManifest = join(root, 'theme.manifest.json')
  const tailwindManifest = join(root, 'adapter.manifest.json')
  const manifestPath = existsSync(themeManifest)
    ? themeManifest
    : existsSync(tailwindManifest)
    ? tailwindManifest
    : undefined
  if (!manifestPath) return success(new Set())
  try {
    const value = JSON.parse(readFileSync(manifestPath, 'utf8')) as unknown
    const owners = new Set<string>([basename(manifestPath)])
    if (manifestPath === themeManifest) {
      const validated = validateThemeManifest(value)
      if (!validated.ok) {
        const adapterOnly = validated.diagnostics.every((entry) =>
          ['$.adapters.tailwind', '$.adapters.elementPlus'].some(
            (path) =>
              entry.jsonPath === path || entry.jsonPath?.startsWith(`${path}.`)
          )
        )
        const migrated = adapterOnly
          ? adapterUpgradeOwnerSet(value, root, candidateFiles)
          : null
        if (!migrated)
          throw new Error(
            `invalid previous theme manifest: ${validated.diagnostics
              .map((entry) => `${entry.code}:${entry.jsonPath ?? '$'}`)
              .join(',')}`
          )
        return success(migrated)
      }
      for (const artifact of validated.value.artifacts) {
        owners.add(artifact.path)
      }
    } else {
      if (!value || typeof value !== 'object' || Array.isArray(value)) {
        throw new Error('invalid previous Tailwind manifest shape')
      }
      const record = value as Readonly<Record<string, unknown>>
      const keys = Object.keys(record).sort(compareCodePoint)
      if (
        record.schema !== 'zx.tailwind-adapter-manifest/1' ||
        JSON.stringify(keys) !==
          JSON.stringify(
            [
              'adapter',
              'artifacts',
              'coverage',
              'schema',
              'targetBaselines',
            ].sort(compareCodePoint)
          ) ||
        !Array.isArray(record.artifacts) ||
        record.artifacts.length !== 2
      ) {
        throw new Error('invalid previous Tailwind manifest contract')
      }
      const expected = new Set(['generated/preset-v3.cjs', 'generated/v4.css'])
      for (const artifact of record.artifacts) {
        if (
          !artifact ||
          typeof artifact !== 'object' ||
          Array.isArray(artifact) ||
          typeof (artifact as Record<string, unknown>).path !== 'string' ||
          !expected.has((artifact as Record<string, unknown>).path as string)
        ) {
          throw new Error('invalid previous Tailwind artifact owner')
        }
        const path = (artifact as Record<string, string>).path.slice(
          'generated/'.length
        )
        owners.add(path)
      }
    }
    return success(owners)
  } catch (error) {
    return failure([
      diagnostic({
        code: 'TC_WRITE_COMMIT_FAILED',
        phase: 'write',
        target: manifestPath,
        remediation: { code: 'RESTORE_VALID_GENERATED_MANIFEST' },
        details: {
          reason: error instanceof Error ? error.message : String(error),
        },
      }),
    ])
  }
}

function diff(
  root: string,
  files: readonly ArtifactFile[],
  rejectUnmanaged: boolean
): CompilerResult<ArtifactDiff> {
  const current = inventory(root)
  const owners = oldOwnerSet(root, files)
  if (!owners.ok) return failure(owners.diagnostics)
  const unmanaged = [...current.keys()].filter(
    (path) => !owners.value.has(path)
  )
  const symlinks = [...current.entries()]
    .filter(([, value]) => value.symlink)
    .map(([path]) => path)
  if (rejectUnmanaged && (unmanaged.length > 0 || symlinks.length > 0)) {
    return failure([
      diagnostic({
        code:
          symlinks.length > 0
            ? 'TC_WRITE_SYMLINK_ESCAPE'
            : 'TC_GENERATED_EXTRA',
        phase: 'write',
        remediation: {
          code:
            symlinks.length > 0
              ? 'REMOVE_GENERATED_SYMLINKS'
              : 'CLASSIFY_UNMANAGED_GENERATED_FILES',
        },
        details: { unmanaged, symlinks },
      }),
    ])
  }
  const expected = new Map(files.map((file) => [file.path, file.sha256]))
  const missing = [...expected.keys()]
    .filter((path) => !current.has(path))
    .sort(compareCodePoint)
  const extra = [...current.keys()]
    .filter((path) => !expected.has(path))
    .sort(compareCodePoint)
  const changed = [...expected.entries()]
    .filter(
      ([path, hash]) => current.has(path) && current.get(path)!.hash !== hash
    )
    .map(([path]) => path)
    .sort(compareCodePoint)
  return success({
    missing,
    extra,
    changed,
    matches: missing.length + extra.length + changed.length === 0,
  })
}

export function compareArtifactSet(
  request: CompareArtifactSetRequest
): CompilerResult<ArtifactDiff> {
  const verified = verifyCompleteArtifactSet(request.artifactSet)
  if (!verified.ok) return failure(verified.diagnostics)
  const roots = safeRoots(request.packageRoot, request.generatedRoot)
  if (!roots.ok) return failure(roots.diagnostics)
  return diff(roots.value.generatedRoot, verified.value.files, false)
}

function syncDirectory(path: string): void {
  const descriptor = openSync(path, 'r')
  try {
    fsyncSync(descriptor)
  } finally {
    closeSync(descriptor)
  }
}

interface WriteArtifactSetHooks {
  readonly afterPreviousRootMoved?: () => void
}

function writeArtifactSetInternal(
  request: WriteArtifactSetRequest,
  hooks: WriteArtifactSetHooks
): CompilerResult<WriteReceipt> {
  const verified = verifyCompleteArtifactSet(request.artifactSet)
  if (!verified.ok) return failure(verified.diagnostics)
  const artifactSet = verified.value
  const roots = safeRoots(request.packageRoot, request.generatedRoot)
  if (!roots.ok) return failure(roots.diagnostics)
  const before = diff(roots.value.generatedRoot, artifactSet.files, true)
  if (!before.ok) return failure(before.diagnostics)
  const parent = dirname(roots.value.generatedRoot)
  const stage = mkdtempSync(join(parent, '.zx-theme-stage-'))
  const backup = `${stage}-previous`
  let previousMoved = false
  try {
    for (const file of artifactSet.files) {
      const absolute = resolve(stage, file.path)
      if (!within(stage, absolute))
        throw new Error(`artifact escaped stage: ${file.path}`)
      mkdirSync(dirname(absolute), { recursive: true })
      const descriptor = openSync(absolute, 'wx', 0o644)
      try {
        writeFileSync(descriptor, decodeArtifactBytes(file.bytes))
        fsyncSync(descriptor)
      } finally {
        closeSync(descriptor)
      }
      if (sha256(readFileSync(absolute)) !== file.sha256) {
        throw new Error(`staged hash mismatch: ${file.path}`)
      }
    }
    syncDirectory(stage)
    if (existsSync(roots.value.generatedRoot)) {
      renameSync(roots.value.generatedRoot, backup)
      previousMoved = true
      hooks.afterPreviousRootMoved?.()
    }
    renameSync(stage, roots.value.generatedRoot)
    // mkdtempSync creates the stage as 0700. Vite and docs resolve through
    // package exports, so the published generated root must stay traversable.
    chmodSync(roots.value.generatedRoot, 0o755)
    syncDirectory(parent)
    if (previousMoved) rmSync(backup, { recursive: true, force: true })
    return success({
      generatedRoot: roots.value.generatedRoot,
      added: before.value.missing,
      changed: before.value.changed,
      deleted: before.value.extra,
      artifactSetHash: artifactSet.artifactSetHash,
    })
  } catch (error) {
    try {
      if (existsSync(roots.value.generatedRoot) && previousMoved) {
        rmSync(roots.value.generatedRoot, { recursive: true, force: true })
      }
      if (previousMoved && existsSync(backup)) {
        renameSync(backup, roots.value.generatedRoot)
      }
      if (existsSync(stage)) rmSync(stage, { recursive: true, force: true })
    } catch {
      // The original structured failure remains authoritative.
    }
    return failure([
      diagnostic({
        code: 'TC_WRITE_COMMIT_FAILED',
        phase: 'write',
        target: roots.value.generatedRoot,
        remediation: { code: 'FIX_GENERATED_ROOT_AND_RETRY' },
        details: {
          reason: error instanceof Error ? error.message : String(error),
        },
      }),
    ])
  }
}

export function writeArtifactSet(
  request: WriteArtifactSetRequest
): CompilerResult<WriteReceipt> {
  return writeArtifactSetInternal(request, {})
}

/** @internal Unit-test seam for proving rollback after the old root is moved. */
export function writeArtifactSetForTesting(
  request: WriteArtifactSetRequest,
  hooks: WriteArtifactSetHooks
): CompilerResult<WriteReceipt> {
  return writeArtifactSetInternal(request, hooks)
}
