import {
  canonicalJson,
  canonicalize,
  compareCodePoint,
} from '../../core/canonical-text'

import type { TargetTypeSerializer } from '../../core/type-serializers'
import type { ManifestPublicToken } from '../manifest/model'
import type { TypegenManifestInput, TypegenOutput } from './model'

type SerializerMap = Readonly<
  Record<string, TargetTypeSerializer<unknown> | undefined>
>

function tokenRecord(
  token: ManifestPublicToken,
  serializers: SerializerMap
): Readonly<Record<string, unknown>> {
  const serializer = serializers[token.typeId]
  if (!serializer)
    throw new Error(`missing typegen serializer: ${token.typeId}`)
  return {
    path: token.path,
    layer: token.layer,
    typeId: token.typeId,
    typeMetadata: canonicalize(serializer.typegen.runtimeMetadata),
    lifecycle: token.lifecycle,
    cssVariable: token.css.publicVariable,
    fields: token.css.fields ?? {},
    ...(token.deprecated ? { deprecated: token.deprecated } : {}),
  }
}

function compactJson(value: unknown): string {
  return canonicalJson(value).trimEnd()
}

function readonlyLiteralType(value: unknown): string {
  if (value === null) return 'null'
  if (typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'number' || typeof value === 'boolean')
    return JSON.stringify(value)
  if (Array.isArray(value))
    return `readonly [${value.map(readonlyLiteralType).join(', ')}]`
  if (!value || typeof value !== 'object')
    throw new TypeError(`unsupported literal type: ${typeof value}`)
  return `{ ${Object.entries(value)
    .sort(([left], [right]) => compareCodePoint(left, right))
    .map(
      ([key, entry]) =>
        `readonly ${JSON.stringify(key)}: ${readonlyLiteralType(entry)}`
    )
    .join('; ')} }`
}

const freezeHelper = `const deepFreeze = (value) => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const key of Object.keys(value)) deepFreeze(value[key])
    Object.freeze(value)
  }
  return value
}`

const declarationPrelude = `type Sha256 = \`sha256:\${string}\`
type CanonicalColor = { readonly colorSpace: 'srgb' | 'display-p3' | 'oklch'; readonly components: readonly [number, number, number]; readonly alpha: number }
type CanonicalDimension = { readonly kind: 'value'; readonly value: number; readonly unit: 'px' | 'rem' | 'em' | '%' | 'vw' | 'vh' | 'vmin' | 'vmax' | 'ch' | 'lh' | 'rlh' } | { readonly kind: 'calc'; readonly op: 'add' | 'subtract'; readonly args: readonly [CanonicalDimension, CanonicalDimension] } | { readonly kind: 'calc'; readonly op: 'multiply'; readonly args: readonly [CanonicalDimension, number] }
type CanonicalGradient = { readonly angle: number; readonly stops: readonly { readonly color: CanonicalColor; readonly position: number }[] }
type CanonicalShadowLayer = { readonly color: CanonicalColor; readonly offsetX: CanonicalDimension; readonly offsetY: CanonicalDimension; readonly blur: CanonicalDimension; readonly spread: CanonicalDimension; readonly inset: boolean }
type CanonicalBorder = { readonly color: CanonicalColor; readonly width: CanonicalDimension; readonly style: 'none' | 'solid' | 'dashed' | 'dotted' | 'double' }
type CanonicalTransition = { readonly duration: { readonly value: number; readonly unit: 'ms' }; readonly delay: { readonly value: number; readonly unit: 'ms' }; readonly timingFunction: readonly [number, number, number, number] }
type CanonicalTypography = { readonly fontFamily: readonly string[]; readonly fontSize: CanonicalDimension; readonly fontWeight: number; readonly lineHeight: number | CanonicalDimension; readonly letterSpacing: CanonicalDimension }
`

const completeManifestDeclarations = `export interface ThemeManifestArtifactRef { readonly path: string; readonly sha256: Sha256 }
export interface ThemeManifestArtifact { readonly path: string; readonly mediaType: string; readonly bytes: number; readonly sha256: Sha256; readonly purpose: 'core-css' | 'aggregate-css' | 'typegen-runtime' | 'typegen-declarations' | 'element-plus-alias' | 'element-plus-resolved' | 'dtcg-token-set' | 'dtcg-index'; readonly loadPhase: 'contract' | 'theme' | 'variant' | 'tooling' }
export interface ThemeManifestCoverage { readonly status: 'mapped' | 'not-applicable'; readonly targets: readonly string[]; readonly reasonCode?: string; readonly rationale?: string }
export interface ThemeManifestPublicToken { readonly path: ThemePublicTokenPath; readonly layer: 'foundation' | 'semantic' | 'components'; readonly component?: string; readonly typeId: string; readonly lifecycle: 'stable' | 'experimental' | 'deprecated'; readonly description: string; readonly css: { readonly internalVariable: \`--zx-internal-\${string}\`; readonly publicVariable: ThemePublicCssVariable; readonly fields?: Readonly<Record<string, \`--zx-\${string}\`>> }; readonly deprecated?: { readonly since: string; readonly replacement?: string; readonly noReplacementReason?: string }; readonly adapters: { readonly elementPlus: ThemeManifestCoverage; readonly tailwind: ThemeManifestCoverage; readonly dtcg: ThemeManifestCoverage } }
export interface ThemeManifestVariant { readonly variantKey: ThemeVariantKey; readonly selection: ThemeAxisSelection; readonly resolvedContentHash: Sha256; readonly selector: string; readonly artifacts: { readonly coreCss: ThemeManifestArtifactRef; readonly elementPlusResolvedCss: ThemeManifestArtifactRef; readonly dtcgTokens: ThemeManifestArtifactRef } }
export interface ThemeManifestLocalAdapter { readonly name: '@zxio/theme-compiler/element-plus' | '@zxio/theme-compiler/dtcg'; readonly version: string; readonly mappingSchema: string; readonly mappingVersion: string; readonly mappingHash: Sha256; readonly targetBaseline?: { readonly name: string; readonly exactVersion: string; readonly supportedRange: string; readonly inventoryHash: Sha256 }; readonly artifacts: readonly ThemeManifestArtifactRef[]; readonly coverage: readonly ({ readonly tokenPath: ThemePublicTokenPath } & ThemeManifestCoverage)[] }
export interface ThemeManifestExternalArtifactRef { readonly packageName: '@zxio/theme-tailwind'; readonly packageVersion: string; readonly exportPath: './v4.css' | './preset-v3' | './manifest.json'; readonly path: 'generated/v4.css' | 'generated/preset-v3.cjs' | 'generated/adapter.manifest.json'; readonly sha256: Sha256 }
export interface ThemeManifestTailwindAdapter { readonly name: '@zxio/theme-tailwind'; readonly version: string; readonly contractContentHash: Sha256; readonly mappingSchema: string; readonly mappingVersion: string; readonly mappingHash: Sha256; readonly adapterContractHash: Sha256; readonly targetBaselines: readonly { readonly name: 'tailwindcss'; readonly major: 3 | 4; readonly exactTestVersion: string; readonly supportedRange: string }[]; readonly manifest: ThemeManifestExternalArtifactRef & { readonly exportPath: './manifest.json' }; readonly artifacts: readonly ThemeManifestExternalArtifactRef[]; readonly coverage: readonly ({ readonly tokenPath: ThemePublicTokenPath } & ThemeManifestCoverage)[] }
export interface ThemeManifest { readonly schema: 'zx.theme-manifest/1'; readonly variantKeySchema: 'zx.variant-key/1'; readonly selectorSchema: 'zx.theme-selector/1'; readonly displayContract?: { readonly schema: 'zx.display-contract/1'; readonly version: 1; readonly scales: readonly [90, 100, 110, 125]; readonly profiles: readonly ['office', 'distance']; readonly metrics: Readonly<Record<string, unknown>>; readonly contentHash: Sha256 }; readonly identity: { readonly themeId: ThemeId; readonly packageName: string; readonly packageVersion: string; readonly compilerName: '@zxio/theme-compiler'; readonly compilerVersion: string; readonly sourceSchemaVersion: 4; readonly resolvedSchemaVersion: 1; readonly contractVersion: '4.0.0'; readonly sourceContentHash: Sha256; readonly contractContentHash: Sha256; readonly typeRegistryContentHash: Sha256 }; readonly axes: { readonly applicationOrder: readonly ['mode', 'density', 'contrast', 'motion', 'radius']; readonly declarations: typeof axisDeclarations; readonly variantCount: number }; readonly publicSurface: readonly ThemeManifestPublicToken[]; readonly variants: readonly ThemeManifestVariant[]; readonly artifacts: readonly ThemeManifestArtifact[]; readonly adapters: { readonly elementPlus: ThemeManifestLocalAdapter; readonly tailwind: ThemeManifestTailwindAdapter; readonly dtcg: ThemeManifestLocalAdapter } }
`

export function printTypegen(
  manifest: TypegenManifestInput,
  serializers: SerializerMap
): TypegenOutput {
  const tokens = Object.fromEntries(
    [...manifest.publicSurface]
      .sort((left, right) => compareCodePoint(left.path, right.path))
      .map((token) => [token.path, tokenRecord(token, serializers)])
  )
  const axes = manifest.axes.declarations
  const keys = manifest.variants.map((variant) => variant.variantKey)
  const shared = [
    `const themeId = ${JSON.stringify(manifest.identity.themeId)}`,
    `const axisDeclarations = deepFreeze(${compactJson(axes)})`,
    `const variantKeys = deepFreeze(${compactJson(keys)})`,
    `const publicTokensByPath = deepFreeze(${compactJson(tokens)})`,
  ].join('\n\n')
  const esm = `${freezeHelper}\n\n${shared}\n\nexport { axisDeclarations, publicTokensByPath, themeId, variantKeys }\n`
  const cjs = `'use strict'\n\n${freezeHelper}\n\n${shared}\n\nmodule.exports = deepFreeze({ axisDeclarations, publicTokensByPath, themeId, variantKeys })\n`
  const properties = [...manifest.publicSurface]
    .sort((left, right) => compareCodePoint(left.path, right.path))
    .map((token) => {
      const deprecated = token.deprecated
        ? `  /** @deprecated since ${token.deprecated.since}; ${
            token.deprecated.replacement
              ? `use ${token.deprecated.replacement}`
              : token.deprecated.noReplacementReason ?? 'no replacement'
          } */\n`
        : ''
      return `${deprecated}  readonly ${JSON.stringify(
        token.path
      )}: ${readonlyLiteralType(tokenRecord(token, serializers))}`
    })
    .join('\n')
  const valueProperties = [...manifest.publicSurface]
    .sort((left, right) => compareCodePoint(left.path, right.path))
    .map((token) => {
      const expression =
        serializers[token.typeId]!.typegen.readonlyTypeExpression
      return `  readonly ${JSON.stringify(token.path)}: ${expression}`
    })
    .join('\n')
  const declarations = `${declarationPrelude}\nexport declare const themeId: ${JSON.stringify(
    manifest.identity.themeId
  )}\nexport declare const axisDeclarations: ${readonlyLiteralType(
    axes
  )}\nexport declare const variantKeys: ${readonlyLiteralType(
    keys
  )}\nexport declare const publicTokensByPath: {\n${properties}\n}\n\nexport type ThemeId = typeof themeId\nexport type ThemeAxisName = keyof typeof axisDeclarations\nexport type ThemeAxisSelection = { readonly [K in ThemeAxisName]: (typeof axisDeclarations)[K]['supported'][number] }\nexport type ThemeVariantKey = (typeof variantKeys)[number]\nexport type ThemePublicTokenPath = keyof typeof publicTokensByPath\nexport type ThemePublicTokenMap = typeof publicTokensByPath\nexport type ThemePublicTokenRecord<P extends ThemePublicTokenPath> = ThemePublicTokenMap[P]\nexport type ThemePublicCssVariable = ThemePublicTokenMap[ThemePublicTokenPath]['cssVariable']\nexport type ThemePublicLifecycle = ThemePublicTokenMap[ThemePublicTokenPath]['lifecycle']\nexport interface ThemePublicTokenValueMap {\n${valueProperties}\n}\nexport type ThemePublicTokenValue<P extends ThemePublicTokenPath> = ThemePublicTokenValueMap[P]\n\n${completeManifestDeclarations}`
  return { esm, cjs, declarations }
}
