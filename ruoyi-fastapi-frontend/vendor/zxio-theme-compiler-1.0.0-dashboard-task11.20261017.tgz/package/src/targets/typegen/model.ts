import type { ThemeManifestV1 } from '../manifest/model'

export interface TypegenOutput {
  readonly esm: string
  readonly cjs: string
  readonly declarations: string
}

export type TypegenManifestInput = ThemeManifestV1
