import {
  type ZxDisplayMetricId,
  displayCssVariables,
  displayMetricCatalog,
} from '@zxio/tokens/display'
import { canonicalThemeContractV4 } from '@zxio/tokens/kernel'
import { publicCssVariable } from './css-variable'

export interface DisplayCssDeclaration {
  readonly property: `--zx-display-${string}`
  readonly value: string
}

// Every canonical contract entry is public surface.
const publicCorePaths = new Set(Object.keys(canonicalThemeContractV4.entries))

export { displayCssVariables } from '@zxio/tokens/display'

/** Compile only bases and aliases. Runtime projects the effective value per scope. */
export function compileDisplayCssDeclarations(): readonly DisplayCssDeclaration[] {
  const declarations: DisplayCssDeclaration[] = []
  for (const [id, metric] of Object.entries(displayMetricCatalog) as [
    ZxDisplayMetricId,
    (typeof displayMetricCatalog)[ZxDisplayMetricId]
  ][]) {
    if (metric.policy === 'domain-length' || metric.policy === 'unitless-ratio')
      continue
    const variables = displayCssVariables(id)
    let source: string
    if (metric.source.startsWith('semantic.')) {
      if (!publicCorePaths.has(metric.source))
        throw new Error(`Display source is not public: ${metric.source}`)
      source = `var(${publicCssVariable(metric.source)})`
    } else if (id === 'icon.default') {
      source = '1rem'
    } else if (id === 'stroke.hairline') {
      source = '1px'
    } else {
      throw new Error(`Unknown display source: ${metric.source}`)
    }
    declarations.push(
      { property: variables.base, value: source },
      {
        property: variables.effective,
        value: `var(${variables.base})`,
      }
    )
  }
  // office/100 baseline; structural control geometry multiplies by it.
  declarations.push(
    { property: '--zx-display-control-factor', value: '1' },
    { property: '--zx-display-control-min', value: '0px' }
  )
  return declarations.sort((a, b) => a.property.localeCompare(b.property))
}
