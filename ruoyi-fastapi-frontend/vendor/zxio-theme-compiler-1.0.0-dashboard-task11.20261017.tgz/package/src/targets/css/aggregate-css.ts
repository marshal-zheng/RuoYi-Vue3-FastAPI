import postcss from 'postcss'
import selectorParser from 'postcss-selector-parser'
import { canonicalCssBlock } from '../../core/canonical-text'

import type { CompiledVariantCss } from './variant-css'

/**
 * Factor declarations over exact, mutually exclusive variant selectors.
 * Never broaden a selector: unknown variants still match no rule, nested
 * scopes retain their own declarations, and :where specificity stays zero.
 * Standalone variant files remain complete and independently loadable.
 */
export function compileAggregateCss(
  variants: readonly CompiledVariantCss[]
): string {
  const original = () => variants.map((variant) => variant.text).join('')
  const seen = new Set<string>()
  const declarations = new Map<
    string,
    { property: string; value: string; selectors: string[] }
  >()
  for (const variant of variants) {
    const selector = selectorParser().astSync(variant.selector)
    const where = selector.nodes[0]?.nodes[0]
    if (
      selector.nodes.length !== 1 ||
      selector.nodes[0]?.nodes.length !== 1 ||
      where?.type !== 'pseudo' ||
      where.value !== ':where' ||
      where.nodes?.length !== 1
    )
      return original()
    const attributes = where.nodes[0]!.nodes
    if (
      attributes.length !== 2 ||
      attributes.some(
        (node, index) =>
          node.type !== 'attribute' ||
          node.operator !== '=' ||
          node.attribute !== ['data-zx-theme', 'data-zx-variant'][index]
      )
    )
      return original()
    const identity = JSON.stringify(
      attributes.map((node) => (node.type === 'attribute' ? node.value : ''))
    )
    if (seen.has(identity)) return original()
    seen.add(identity)
    const ast = postcss.parse(variant.text)
    if (
      ast.nodes.length !== 1 ||
      ast.nodes[0]?.type !== 'rule' ||
      ast.nodes[0].selector !== variant.selector
    )
      return original()
    const properties = new Set<string>()
    for (const node of ast.nodes[0].nodes) {
      if (
        node.type !== 'decl' ||
        !node.prop.startsWith('--') ||
        node.important ||
        properties.has(node.prop)
      )
        return original()
      properties.add(node.prop)
      const key = JSON.stringify([node.prop, node.value])
      const entry = declarations.get(key) ?? {
        property: node.prop,
        value: node.value,
        selectors: [],
      }
      entry.selectors.push(variant.selector)
      declarations.set(key, entry)
    }
  }
  // Properties sharing exactly the same selector set share one rule.
  const groups = new Map<string, { property: string; value: string }[]>()
  for (const { property, value, selectors } of declarations.values()) {
    const key = selectors.join(',\n')
    const group = groups.get(key) ?? []
    group.push({ property, value })
    groups.set(key, group)
  }
  const factored = [...groups]
    .map(([selector, values]) => canonicalCssBlock(selector, values))
    .join('')
  return Buffer.byteLength(factored) < Buffer.byteLength(original())
    ? factored
    : original()
}
