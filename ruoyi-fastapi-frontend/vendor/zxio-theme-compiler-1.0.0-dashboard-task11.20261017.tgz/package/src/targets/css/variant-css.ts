import { canonicalCssBlock, compareCodePoint } from '../../core/canonical-text'
import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'
import { serializeWithRegistry } from '../../core/type-serializers'
import { internalCssVariable, publicCssVariable } from './css-variable'
import { compileDisplayCssDeclarations } from './display-css'
import { serializeTypographyFields } from './value-serializers'

import type { MatrixVariant } from '../../core/matrix'
import type { TargetSerializerRegistry } from '../../core/type-serializers'
import type {
  BuiltInTypeMap,
  ResolvedThemeV1,
  ResolvedToken,
} from '@zxio/tokens/kernel'

export interface CompiledVariantCss {
  readonly variantKey: string
  readonly selector: string
  readonly text: string
  readonly publicFields: Readonly<
    Record<string, Readonly<Record<string, `--zx-${string}`>>>
  >
}

function tokenDeclarations(
  token: ResolvedToken<BuiltInTypeMap>,
  serializers: TargetSerializerRegistry<BuiltInTypeMap>
): CompilerResult<readonly Readonly<{ property: string; value: string }>[]> {
  const declarations: { property: string; value: string }[] = []
  const internal = internalCssVariable(token.path)
  if (token.typeId === 'typography') {
    const fields = serializeTypographyFields(token.value)
    for (const [field, value] of Object.entries(fields).sort(
      ([left], [right]) => compareCodePoint(left, right)
    )) {
      declarations.push({ property: `${internal}-${field}`, value })
      if (token.visibility === 'public') {
        declarations.push({
          property: `${publicCssVariable(token.path)}-${field}`,
          value: `var(${internal}-${field})`,
        })
      }
    }
    return success(declarations)
  }
  const serialized = serializeWithRegistry(
    serializers,
    token.typeId,
    token.value,
    { tokenPath: token.path, target: 'css' }
  )
  if (!serialized.ok) return failure(serialized.diagnostics)
  declarations.push({ property: internal, value: serialized.value })
  if (token.visibility === 'public') {
    declarations.push({
      property: publicCssVariable(token.path),
      value: `var(${internal})`,
    })
  }
  return success(declarations)
}

export function compileVariantCss(
  variant: MatrixVariant<BuiltInTypeMap>,
  serializers: TargetSerializerRegistry<BuiltInTypeMap>
): CompilerResult<CompiledVariantCss> {
  const declarations: { property: string; value: string }[] = []
  const diagnostics = []
  const properties = new Map<string, string[]>()
  const publicFields: Record<string, Record<string, `--zx-${string}`>> = {}
  const tokens = Object.values(variant.resolved.tokens).sort((left, right) =>
    compareCodePoint(left.path, right.path)
  )
  for (const token of tokens) {
    const result = tokenDeclarations(token, serializers)
    if (!result.ok) {
      diagnostics.push(...result.diagnostics)
      continue
    }
    for (const declaration of result.value) {
      declarations.push(declaration)
      properties.set(declaration.property, [
        ...(properties.get(declaration.property) ?? []),
        token.path,
      ])
    }
    if (token.typeId === 'typography' && token.visibility === 'public') {
      publicFields[token.path] = Object.fromEntries(
        Object.keys(serializeTypographyFields(token.value)).map((field) => [
          field,
          `${publicCssVariable(token.path)}-${field}` as `--zx-${string}`,
        ])
      )
    }
  }
  for (const declaration of compileDisplayCssDeclarations()) {
    declarations.push(declaration)
    properties.set(declaration.property, [
      ...(properties.get(declaration.property) ?? []),
      'display-contract',
    ])
  }
  // Native controls, scrollbars and system colours follow the variant's mode;
  // structural style applies it as `color-scheme` on every theme scope.
  declarations.push({
    property: '--zx-color-scheme',
    value: variant.selection.mode,
  })
  properties.set('--zx-color-scheme', [
    ...(properties.get('--zx-color-scheme') ?? []),
    'mode-axis',
  ])
  const collisions = [...properties.entries()]
    .filter(([, sources]) => sources.length > 1)
    .map(([property, sources]) => ({ property, sources }))
  if (collisions.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_CSS_VARIABLE_COLLISION',
        phase: 'serialize',
        variantKey: variant.variantKey,
        remediation: { code: 'FIX_TOKEN_VARIABLE_COLLISIONS' },
        details: { collisions },
      })
    )
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  declarations.sort((left, right) =>
    compareCodePoint(left.property, right.property)
  )
  return success({
    variantKey: variant.variantKey,
    selector: variant.selector,
    text: canonicalCssBlock(variant.selector, declarations),
    publicFields,
  })
}

export function compileAllVariantCss(
  variants: readonly MatrixVariant<BuiltInTypeMap>[],
  serializers: TargetSerializerRegistry<BuiltInTypeMap>
): CompilerResult<readonly CompiledVariantCss[]> {
  const output: CompiledVariantCss[] = []
  const diagnostics = []
  for (const variant of variants) {
    const result = compileVariantCss(variant, serializers)
    if (result.ok) output.push(result.value)
    else diagnostics.push(...result.diagnostics)
  }
  return diagnostics.length > 0 ? failure(diagnostics) : success(output)
}

export function resolvedToken(
  resolved: ResolvedThemeV1<BuiltInTypeMap>,
  path: string
): ResolvedToken<BuiltInTypeMap> | undefined {
  return Object.values(resolved.tokens).find((token) => token.path === path)
}
