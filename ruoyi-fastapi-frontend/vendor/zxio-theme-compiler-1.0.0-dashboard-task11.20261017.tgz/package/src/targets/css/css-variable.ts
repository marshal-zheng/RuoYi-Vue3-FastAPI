import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'

export interface PublicCssAlias {
  readonly path: string
  readonly internalVariable: `--zx-internal-${string}`
  readonly publicVariable: `--zx-${string}`
  readonly fields?: Readonly<Record<string, `--zx-${string}`>>
}

export type PublicCssAliasRegistry = Readonly<Record<string, PublicCssAlias>>

function encodeTokenPath(path: string): string {
  return path
    .split('.')
    .map((segment) =>
      [...segment]
        .map((character) =>
          /[a-z0-9-]/.test(character)
            ? character
            : `_${character.codePointAt(0)?.toString(16)}_`
        )
        .join('')
    )
    .join('-')
}

export function internalCssVariable(path: string): `--zx-internal-${string}` {
  return `--zx-internal-${encodeTokenPath(path)}`
}

export function publicCssVariable(path: string): `--zx-${string}` {
  return `--zx-${encodeTokenPath(path)}`
}

export function buildPublicCssAliases(
  publicPaths: readonly string[]
): CompilerResult<PublicCssAliasRegistry> {
  const output: Record<string, PublicCssAlias> = {}
  const targets = new Map<string, string[]>()
  for (const path of publicPaths) {
    const entry: PublicCssAlias = {
      path,
      internalVariable: internalCssVariable(path),
      publicVariable: publicCssVariable(path),
    }
    output[path] = entry
    for (const target of [entry.internalVariable, entry.publicVariable]) {
      targets.set(target, [...(targets.get(target) ?? []), path])
    }
  }
  const collisions = [...targets.entries()]
    .filter(([, sources]) => sources.length > 1)
    .map(([target, sources]) => ({ target, sources }))
  return collisions.length === 0
    ? success(output)
    : failure([
        diagnostic({
          code: 'TC_CSS_VARIABLE_COLLISION',
          phase: 'serialize',
          remediation: { code: 'RENAME_COLLIDING_TOKEN_PATHS' },
          details: { collisions },
        }),
      ])
}
