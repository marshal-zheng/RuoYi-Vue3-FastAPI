import {
  canonicalNumber,
  serializeBorder,
  serializeColor,
  serializeCubicBezier,
  serializeDimension,
  serializeDuration,
  serializeFontFamily,
  serializeGradient,
  serializeShadow,
  serializeTransition,
} from '@zxio/theme-css-codec'
import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'

import type {
  BuiltInTypeMap,
  CanonicalGradient,
  CanonicalStrokeStyle,
  CanonicalTransition,
} from '@zxio/tokens/kernel'
import type {
  BuiltInSerializerRegistry,
  CssSerializationContext,
  TargetTypeSerializer,
} from '../../core/type-serializers'

export {
  serializeColor,
  serializeDimension,
  serializeTypographyFields,
} from '@zxio/theme-css-codec'

function invalid(
  typeId: string,
  context: CssSerializationContext,
  issue: string
): CompilerResult<never> {
  return failure([
    diagnostic({
      code: 'TC_VALUE_UNREPRESENTABLE',
      phase: 'serialize',
      tokenPath: context.tokenPath,
      target: context.target,
      remediation: { code: 'USE_CANONICAL_REPRESENTABLE_VALUE' },
      details: { typeId, issue },
    }),
  ])
}

function define<Value>(
  typeId: string,
  expression: string,
  toCss: TargetTypeSerializer<Value>['toCss']
): TargetTypeSerializer<Value> {
  return {
    typeId,
    registrationPoint: `type-serializer:${typeId}`,
    typegen: {
      readonlyTypeExpression: expression,
      runtimeMetadata: { typeId },
    },
    toCss,
  }
}

export const builtInSerializers: BuiltInSerializerRegistry = {
  color: define('color', 'CanonicalColor', (value) =>
    success(serializeColor(value))
  ),
  dimension: define('dimension', 'CanonicalDimension', (value) =>
    success(serializeDimension(value))
  ),
  number: define('number', 'number', (value) =>
    success(canonicalNumber(value))
  ),
  duration: define(
    'duration',
    '{ readonly value: number; readonly unit: "ms" }',
    (value) => success(serializeDuration(value))
  ),
  'cubic-bezier': define(
    'cubic-bezier',
    'readonly [number, number, number, number]',
    (value) => success(serializeCubicBezier(value))
  ),
  'font-family': define('font-family', 'readonly string[]', (value) =>
    success(serializeFontFamily(value))
  ),
  'font-weight': define('font-weight', 'number', (value) =>
    success(canonicalNumber(value))
  ),
  gradient: define<CanonicalGradient>(
    'gradient',
    'CanonicalGradient',
    (value) => success(serializeGradient(value))
  ),
  shadow: define('shadow', 'readonly CanonicalShadowLayer[]', (value) =>
    success(serializeShadow(value))
  ),
  strokeStyle: define<CanonicalStrokeStyle>(
    'strokeStyle',
    'CanonicalStrokeStyle',
    (value, context) =>
      typeof value === 'string'
        ? success(value)
        : invalid(
            'strokeStyle',
            context,
            'strokeStyle-requires-field-expansion'
          )
  ),
  transition: define<CanonicalTransition>(
    'transition',
    'CanonicalTransition',
    (value) => success(serializeTransition(value))
  ),
  border: define('border', 'CanonicalBorder', (value) =>
    success(serializeBorder(value))
  ),
  typography: define('typography', 'CanonicalTypography', (_value, context) =>
    invalid('typography', context, 'typography-requires-field-expansion')
  ),
  string: define('string', 'string', (value, context) =>
    context.allowRawString
      ? success(value)
      : invalid('string', context, 'raw-string-target-not-declared')
  ),
} satisfies Required<{
  [K in keyof BuiltInTypeMap]: TargetTypeSerializer<BuiltInTypeMap[K]>
}>
