import postcss from 'postcss'
import { describe, expect, it } from 'vitest'
import { compileAggregateCss } from './aggregate-css'

import type { CompiledVariantCss } from './variant-css'

const make = (key: string, value: string): CompiledVariantCss => {
  const selector = `:where([data-zx-theme='test'][data-zx-variant='${key}'])`
  return {
    variantKey: key,
    selector,
    publicFields: {},
    text: `${selector} {\n${Array.from(
      { length: 30 },
      (_, i) => `  --shared-${i}: var(--base-${i});`
    ).join('\n')}\n  --specific: ${value};\n}\n`,
  }
}
function oracle(text: string, selector: string) {
  const values: Record<string, string> = {}
  postcss.parse(text).walkRules((rule) => {
    if (rule.selectors.includes(selector))
      rule.walkDecls((decl) => {
        values[decl.prop] = decl.value
      })
  })
  return values
}
describe('exact variant declaration factoring', () => {
  it('preserves every declaration of every variant without broadening selector coverage', () => {
    const variants = [
      make('light', 'white'),
      make('dark', 'black'),
      make('dim', 'gray'),
    ]
    const result = compileAggregateCss(variants)
    expect(result.length).toBeLessThan(
      variants.map((v) => v.text).join('').length
    )
    for (const variant of variants)
      expect(oracle(result, variant.selector)).toEqual(
        oracle(variant.text, variant.selector)
      )
    const selectors = new Set<string>()
    postcss.parse(result).walkRules((rule) => {
      rule.selectors.forEach((selector) => selectors.add(selector))
    })
    expect([...selectors].sort()).toEqual(
      variants.map((v) => v.selector).sort()
    )
  })
  it('keeps original order when selectors overlap or contain cascade-sensitive constructs', () => {
    const first = make('same', 'white')
    const second = make('same', 'black')
    expect(compileAggregateCss([first, second])).toBe(first.text + second.text)
    const arbitrary = {
      ...first,
      selector: ':where(.arbitrary)',
      text: ':where(.arbitrary) { --a: 1; }',
    }
    expect(compileAggregateCss([arbitrary])).toBe(arbitrary.text)
  })
})
