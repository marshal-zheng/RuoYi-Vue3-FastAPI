import type {
  AuthorCanonicalTokenPath,
  CanonicalTokenPath,
  PublicLifecycle,
  ThemeAxisDeclarations,
  ThemeAxisSelection,
} from '@zxio/tokens/kernel'
import type { ExternalTailwindAdapterContractRef } from '../../adapters/tailwind/model'
import type { AdapterCoverage } from '../../adapters/types'
import type { displayContractManifest } from '@zxio/tokens/display'

export interface ManifestArtifactRef {
  readonly path: string
  readonly sha256: `sha256:${string}`
}

export interface ManifestArtifact {
  readonly path: string
  readonly mediaType: string
  readonly bytes: number
  readonly sha256: `sha256:${string}`
  readonly purpose:
    | 'core-css'
    | 'aggregate-css'
    | 'typegen-runtime'
    | 'typegen-declarations'
    | 'element-plus-alias'
    | 'element-plus-resolved'
    | 'dtcg-token-set'
    | 'dtcg-index'
  readonly loadPhase: 'contract' | 'theme' | 'variant' | 'tooling'
}

export interface ManifestVariant {
  readonly variantKey: string
  readonly selection: ThemeAxisSelection
  readonly resolvedContentHash: `sha256:${string}`
  readonly selector: string
  readonly artifacts: Readonly<{
    coreCss: ManifestArtifactRef
    elementPlusResolvedCss: ManifestArtifactRef
    dtcgTokens: ManifestArtifactRef
  }>
}

export interface ThemeManifestTokenAdapterCoverage {
  readonly status: 'mapped' | 'not-applicable'
  readonly targets: readonly string[]
  readonly reasonCode?: string
  readonly rationale?: string
}

export interface ManifestPublicToken {
  readonly path: CanonicalTokenPath
  readonly layer: 'foundation' | 'semantic' | 'components'
  readonly component?: string
  readonly typeId: string
  readonly lifecycle: PublicLifecycle
  readonly description: string
  readonly css: Readonly<{
    internalVariable: `--zx-internal-${string}`
    publicVariable: `--zx-${string}`
    fields?: Readonly<Record<string, `--zx-${string}`>>
  }>
  readonly deprecated?: Readonly<{
    since: string
    replacement?: AuthorCanonicalTokenPath
    noReplacementReason?: string
  }>
  readonly adapters: Readonly<{
    elementPlus: ThemeManifestTokenAdapterCoverage
    tailwind: ThemeManifestTokenAdapterCoverage
    dtcg: ThemeManifestTokenAdapterCoverage
  }>
}

export interface LocalManifestAdapterContract {
  readonly name:
    | '@zxio/theme-compiler/element-plus'
    | '@zxio/theme-compiler/dtcg'
  readonly version: string
  readonly mappingSchema: string
  readonly mappingVersion: string
  readonly mappingHash: `sha256:${string}`
  readonly targetBaseline?: Readonly<{
    name: string
    exactVersion: string
    supportedRange: string
    inventoryHash: `sha256:${string}`
  }>
  readonly artifacts: readonly ManifestArtifactRef[]
  readonly coverage: readonly AdapterCoverage[]
}

export interface ThemeManifestV1 {
  readonly schema: 'zx.theme-manifest/1'
  readonly variantKeySchema: 'zx.variant-key/1'
  readonly selectorSchema: 'zx.theme-selector/1'
  readonly displayContract?: typeof displayContractManifest
  readonly identity: Readonly<{
    themeId: string
    packageName: string
    packageVersion: string
    compilerName: '@zxio/theme-compiler'
    compilerVersion: string
    sourceSchemaVersion: 4
    resolvedSchemaVersion: 1
    contractVersion: '4.0.0'
    sourceContentHash: `sha256:${string}`
    contractContentHash: `sha256:${string}`
    typeRegistryContentHash: `sha256:${string}`
  }>
  readonly axes: Readonly<{
    applicationOrder: readonly [
      'mode',
      'density',
      'contrast',
      'motion',
      'radius'
    ]
    declarations: ThemeAxisDeclarations
    variantCount: number
  }>
  readonly publicSurface: readonly ManifestPublicToken[]
  readonly variants: readonly ManifestVariant[]
  readonly artifacts: readonly ManifestArtifact[]
  readonly adapters: Readonly<{
    elementPlus: LocalManifestAdapterContract
    tailwind: ExternalTailwindAdapterContractRef
    dtcg: LocalManifestAdapterContract
  }>
}
