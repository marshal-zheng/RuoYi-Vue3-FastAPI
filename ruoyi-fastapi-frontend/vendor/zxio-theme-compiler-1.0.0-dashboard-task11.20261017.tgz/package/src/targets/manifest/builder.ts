import { compareCodePoint } from '../../core/canonical-text'
import { internalCssVariable, publicCssVariable } from '../css/css-variable'
import { displayContractManifest } from '@zxio/tokens/display'

import type {
  BuiltInTypeMap,
  ThemeAxisDeclarations,
  ValidatedThemePublicContractV4,
} from '@zxio/tokens/kernel'
import type { ExternalTailwindAdapterContractRef } from '../../adapters/tailwind/model'
import type { AdapterArtifactContribution } from '../../adapters/types'
import type { ArtifactFile } from '../../core/artifact-graph'
import type { MatrixVariant } from '../../core/matrix'
import type { CompilePackageMetadata } from '../../model'
import type { CompiledVariantCss } from '../css/variant-css'
import type {
  LocalManifestAdapterContract,
  ManifestArtifact,
  ManifestArtifactRef,
  ManifestPublicToken,
  ThemeManifestTokenAdapterCoverage,
  ThemeManifestV1,
} from './model'

interface BuildManifestInput {
  readonly package: CompilePackageMetadata
  readonly contract: ValidatedThemePublicContractV4<BuiltInTypeMap>
  readonly declarations: ThemeAxisDeclarations
  readonly variants: readonly MatrixVariant<BuiltInTypeMap>[]
  readonly css: readonly CompiledVariantCss[]
  readonly files: readonly ArtifactFile[]
  readonly elementPlus: AdapterArtifactContribution
  readonly dtcg: AdapterArtifactContribution
  readonly tailwind: ExternalTailwindAdapterContractRef
}

function ref(
  path: string,
  files: ReadonlyMap<string, ArtifactFile>
): ManifestArtifactRef {
  const file = files.get(path)
  if (!file) throw new Error(`manifest invariant: missing artifact ${path}`)
  return { path, sha256: file.sha256 }
}

function coverage(
  path: string,
  values: readonly Readonly<{
    tokenPath: string
    status: 'mapped' | 'not-applicable'
    targets: readonly string[]
    reasonCode?: string
  }>[]
): ThemeManifestTokenAdapterCoverage {
  const entry = values.find((candidate) => candidate.tokenPath === path)
  if (!entry) throw new Error(`manifest invariant: missing coverage ${path}`)
  return {
    status: entry.status,
    targets: entry.targets,
    ...(entry.reasonCode ? { reasonCode: entry.reasonCode } : {}),
  }
}

function localContract(
  contribution: AdapterArtifactContribution,
  files: ReadonlyMap<string, ArtifactFile>
): LocalManifestAdapterContract {
  return {
    ...contribution.contract,
    artifacts: contribution.files
      .map((file) => ref(file.path, files))
      .sort((left, right) => compareCodePoint(left.path, right.path)),
  }
}

export function buildThemeManifest(input: BuildManifestInput): ThemeManifestV1 {
  const byPath = new Map(input.files.map((file) => [file.path, file]))
  const first = input.variants[0]
  if (!first) throw new Error('manifest invariant: matrix is empty')
  const fields = input.css[0]?.publicFields ?? {}
  const publicSurface: ManifestPublicToken[] = first.resolved.publicSurface
    .map((path) => {
      const contractEntry = input.contract.entries[path]
      const token = first.resolved.tokens[path]
      if (!contractEntry) {
        throw new Error(`manifest invariant: missing contract entry ${path}`)
      }
      if (!token || token.visibility !== 'public') {
        throw new Error(`manifest invariant: unresolved public token ${path}`)
      }
      return {
        path: token.path,
        layer: token.layer,
        ...(token.component ? { component: token.component } : {}),
        typeId: token.typeId,
        lifecycle: contractEntry.lifecycle,
        description: contractEntry.description,
        css: {
          internalVariable: internalCssVariable(path),
          publicVariable: publicCssVariable(path),
          ...(fields[path] ? { fields: fields[path] } : {}),
        },
        ...(contractEntry.lifecycle === 'deprecated'
          ? {
              deprecated: {
                since: contractEntry.deprecatedSince,
                ...(contractEntry.migration.kind === 'replacement'
                  ? { replacement: contractEntry.migration.path }
                  : {
                      noReplacementReason:
                        contractEntry.migration.reason.detail,
                    }),
              },
            }
          : {}),
        adapters: {
          elementPlus: coverage(path, input.elementPlus.contract.coverage),
          tailwind: coverage(path, input.tailwind.coverage),
          dtcg: coverage(path, input.dtcg.contract.coverage),
        },
      }
    })
    .sort((left, right) => compareCodePoint(left.path, right.path))
  const artifacts: ManifestArtifact[] = input.files
    .filter((file) => file.purpose !== 'theme-manifest')
    .map((file) => ({
      path: file.path,
      mediaType: file.mediaType,
      bytes: file.byteLength,
      sha256: file.sha256,
      purpose: file.purpose as ManifestArtifact['purpose'],
      loadPhase: file.loadPhase,
    }))
    .sort((left, right) => compareCodePoint(left.path, right.path))
  return {
    schema: 'zx.theme-manifest/1',
    variantKeySchema: 'zx.variant-key/1',
    selectorSchema: 'zx.theme-selector/1',
    displayContract: displayContractManifest,
    identity: {
      themeId: first.resolved.themeId,
      packageName: input.package.packageName,
      packageVersion: input.package.packageVersion,
      compilerName: '@zxio/theme-compiler',
      compilerVersion: input.package.compilerVersion,
      sourceSchemaVersion: 4,
      resolvedSchemaVersion: 1,
      contractVersion: '4.0.0',
      sourceContentHash: first.resolved.sourceContentHash,
      contractContentHash: first.resolved.contractContentHash,
      typeRegistryContentHash: first.resolved.typeRegistryContentHash,
    },
    axes: {
      applicationOrder: ['mode', 'density', 'contrast', 'motion', 'radius'],
      declarations: input.declarations,
      variantCount: input.variants.length,
    },
    publicSurface,
    variants: input.variants.map((variant) => ({
      variantKey: variant.variantKey,
      selection: variant.selection,
      resolvedContentHash: variant.resolved.contentHash,
      selector: variant.selector,
      artifacts: {
        coreCss: ref(`variants/${variant.variantKey}.css`, byPath),
        elementPlusResolvedCss: ref(
          input.elementPlus.variantArtifacts[variant.variantKey]!,
          byPath
        ),
        dtcgTokens: ref(
          input.dtcg.variantArtifacts[variant.variantKey]!,
          byPath
        ),
      },
    })),
    artifacts,
    adapters: {
      elementPlus: localContract(input.elementPlus, byPath),
      tailwind: input.tailwind,
      dtcg: localContract(input.dtcg, byPath),
    },
  }
}
