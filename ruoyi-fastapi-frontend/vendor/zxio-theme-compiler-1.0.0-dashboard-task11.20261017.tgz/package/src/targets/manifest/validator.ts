import { isArtifactPath } from '../../core/artifact-graph'
import {
  canonicalJson,
  compareCodePoint,
  sha256,
} from '../../core/canonical-text'
import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'
import { APPLICATION_ORDER, enumerateSelections } from '../../core/matrix'
import { createThemeSelector } from '../../core/selector'
import { createVariantKey } from '../../core/variant-key'
import {
  elementPlusMapping,
  elementPlusTargetInventory,
} from '../../adapters/element-plus/mapping'
import {
  TAILWIND_TARGET_BASELINES,
  tailwindAdapterContractHash,
} from '../../adapters/tailwind/contract-integrity'
import { tailwindMapping } from '../../adapters/tailwind/mapping'
import { DTCG_ADAPTER_VERSION } from '../../adapters/dtcg/model'
import { DTCG_TO_KERNEL_TYPE } from '../../adapters/dtcg/value-mapping'
import { internalCssVariable, publicCssVariable } from '../css/css-variable'
import { checkDisplayContract } from '@zxio/tokens/display'

import type {
  ThemeAxisDeclarations,
  ThemeAxisSelection,
} from '@zxio/tokens/kernel'
import type { ThemeManifestV1 } from './model'

type Diagnostic = ReturnType<typeof diagnostic>
type RecordValue = Readonly<Record<string, unknown>>

const SHA256 = /^sha256:[a-f0-9]{64}$/
const SEMVER = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/
const AXIS_VALUES = {
  mode: new Set(['light', 'dark']),
  density: new Set(['compact', 'default', 'comfortable']),
  contrast: new Set(['normal', 'high', 'forced-colors']),
  motion: new Set(['full', 'reduced', 'none']),
  radius: new Set(['sharp', 'default', 'rounded']),
} as const
const ARTIFACT_PURPOSES = new Set([
  'core-css',
  'aggregate-css',
  'typegen-runtime',
  'typegen-declarations',
  'element-plus-alias',
  'element-plus-resolved',
  'dtcg-token-set',
  'dtcg-index',
])
const LOAD_PHASES = new Set(['contract', 'theme', 'variant', 'tooling'])
const UUID =
  /(?:^|[^0-9a-f])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?:$|[^0-9a-f])/i
const ISO_DATE_TIME =
  /(?:^|\D)\d{4}-\d{2}-\d{2}[Tt]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[Zz]|[+-]\d{2}:\d{2})?(?:$|\D)/
const UNIX_ABSOLUTE_ROOT = /(?:^|[^A-Za-z0-9._-])\//
const VOLATILE_KEY =
  /(?:timestamp|generatedat|createdat|updatedat|random|nonce|uuid|hostname|username|clock)/
const VOLATILE_LABEL =
  /(?:^|[^a-z0-9])(?:timestamp|generated[-_ ]?at|created[-_ ]?at|updated[-_ ]?at|clock|random(?:[-_ ]?id)?|nonce|uuid|hostname|username|cwd)(?=$|[^a-z0-9])/i

interface ExpectedArtifactMetadata {
  readonly purpose: string
  readonly mediaType: string
  readonly loadPhase: string
}

function expectedArtifactMetadata(
  path: string
): ExpectedArtifactMetadata | undefined {
  if (/^variants\/[^/]+\.css$/.test(path)) {
    return {
      purpose: 'core-css',
      mediaType: 'text/css',
      loadPhase: 'variant',
    }
  }
  if (path === 'theme.css') {
    return {
      purpose: 'aggregate-css',
      mediaType: 'text/css',
      loadPhase: 'theme',
    }
  }
  if (path === 'typegen.cjs' || path === 'typegen.mjs') {
    return {
      purpose: 'typegen-runtime',
      mediaType: 'text/javascript',
      loadPhase: 'tooling',
    }
  }
  if (path === 'typegen.d.ts') {
    return {
      purpose: 'typegen-declarations',
      mediaType: 'text/typescript',
      loadPhase: 'tooling',
    }
  }
  if (path === 'element-plus/aliases.css') {
    return {
      purpose: 'element-plus-alias',
      mediaType: 'text/css',
      loadPhase: 'theme',
    }
  }
  if (/^element-plus\/resolved\/[^/]+\.css$/.test(path)) {
    return {
      purpose: 'element-plus-resolved',
      mediaType: 'text/css',
      loadPhase: 'variant',
    }
  }
  if (/^dtcg\/[^/]+\.tokens\.json$/.test(path)) {
    return {
      purpose: 'dtcg-token-set',
      mediaType: 'application/design-tokens+json',
      loadPhase: 'variant',
    }
  }
  if (path === 'dtcg/variants.json') {
    return {
      purpose: 'dtcg-index',
      mediaType: 'application/json',
      loadPhase: 'tooling',
    }
  }
  return undefined
}

function isAbsoluteOrEnvironmentString(value: string): boolean {
  return (
    UNIX_ABSOLUTE_ROOT.test(value) ||
    /(?:^|[^A-Za-z0-9._-])~\//.test(value) ||
    /(?:^|[^A-Za-z0-9._-])file:\/\//i.test(value) ||
    /[A-Za-z]:[\\/]/.test(value) ||
    /(?:\\\\|\/\/)[^\\/\s]+[\\/]/.test(value) ||
    /(?:^|[^a-z0-9])(?:user(?:name)?|host(?:name)?)[=:][^\s]+/i.test(value)
  )
}

function validateStableManifestData(
  input: unknown,
  jsonPath: string,
  diagnostics: Diagnostic[]
): void {
  if (typeof input === 'string') {
    const issues = [
      ...(isAbsoluteOrEnvironmentString(input) ? ['absolute-or-env-path'] : []),
      ...(UUID.test(input) ? ['uuid'] : []),
      ...(ISO_DATE_TIME.test(input) ? ['clock-value'] : []),
      ...(/(?:^|[^a-z0-9])nonce(?:[-_:/.][a-z0-9]+)?(?:$|[^a-z0-9])/i.test(
        input
      )
        ? ['nonce']
        : []),
      ...(/(?:^|[^a-z0-9])(?:random(?:-?id)?|uuid)[=:][^\s]+/i.test(input)
        ? ['random-or-uuid-value']
        : []),
      ...(VOLATILE_LABEL.test(input) ? ['labelled-volatile-value'] : []),
    ]
    if (issues.length > 0) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          schemaVersion: 'zx.theme-manifest/1',
          jsonPath,
          expected: 'stable input-derived string',
          actual: issues,
          target: 'input-derived stable manifest',
          remediation: { code: 'REMOVE_VOLATILE_MANIFEST_DATA' },
          details: { issue: 'volatile-manifest-string', volatile: issues },
        })
      )
    }
    return
  }
  if (Array.isArray(input)) {
    input.forEach((value, index) =>
      validateStableManifestData(value, `${jsonPath}[${index}]`, diagnostics)
    )
    return
  }
  if (!isRecord(input)) return
  for (const key of Object.keys(input).sort(compareCodePoint)) {
    const normalized = key.replace(/[^a-z0-9]/gi, '').toLowerCase()
    if (normalized === 'cwd' || VOLATILE_KEY.test(normalized)) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          schemaVersion: 'zx.theme-manifest/1',
          jsonPath: `${jsonPath}.${key}`,
          expected: 'stable manifest field',
          actual: key,
          target: 'input-derived stable manifest',
          remediation: { code: 'REMOVE_VOLATILE_MANIFEST_DATA' },
          details: { issue: 'volatile-manifest-field', field: key },
        })
      )
    }
    validateStableManifestData(input[key], `${jsonPath}.${key}`, diagnostics)
  }
}

function isRecord(input: unknown): input is RecordValue {
  return !!input && typeof input === 'object' && !Array.isArray(input)
}

function addInvalid(
  diagnostics: Diagnostic[],
  jsonPath: string,
  issue: string,
  remediation = 'REBUILD_THEME_MANIFEST'
): void {
  diagnostics.push(
    diagnostic({
      code: 'TC_MANIFEST_INVALID',
      phase: 'manifest',
      schemaVersion: 'zx.theme-manifest/1',
      jsonPath,
      expected: 'valid exact manifest value',
      actual: issue,
      target: 'exact Theme Manifest v1 contract',
      remediation: { code: remediation },
      details: { issue },
    })
  )
}

function exactKeys(
  input: RecordValue,
  keys: readonly string[],
  jsonPath: string,
  diagnostics: Diagnostic[]
): void {
  const expected = [...keys].sort(compareCodePoint)
  const actual = Object.keys(input).sort(compareCodePoint)
  const missing = expected.filter((key) => !actual.includes(key))
  const extra = actual.filter((key) => !expected.includes(key))
  if (missing.length > 0 || extra.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        schemaVersion: 'zx.theme-manifest/1',
        jsonPath,
        expected,
        actual,
        target: 'exact manifest schema',
        remediation: { code: 'USE_EXACT_MANIFEST_KEYS' },
        details: { missing, extra },
      })
    )
  }
}

function optionalKeys(
  input: RecordValue,
  required: readonly string[],
  optional: readonly string[],
  jsonPath: string,
  diagnostics: Diagnostic[]
): void {
  exactKeys(
    input,
    [
      ...required,
      ...optional.filter((key) =>
        Object.prototype.hasOwnProperty.call(input, key)
      ),
    ],
    jsonPath,
    diagnostics
  )
}

function expectRecord(
  input: unknown,
  jsonPath: string,
  diagnostics: Diagnostic[]
): RecordValue | undefined {
  if (isRecord(input)) return input
  addInvalid(diagnostics, jsonPath, 'expected-object')
  return undefined
}

function validHash(value: unknown): value is `sha256:${string}` {
  return typeof value === 'string' && SHA256.test(value)
}

function same(left: unknown, right: unknown): boolean {
  return canonicalJson(left) === canonicalJson(right)
}

function validateIdentity(
  identity: RecordValue,
  diagnostics: Diagnostic[]
): void {
  exactKeys(
    identity,
    [
      'themeId',
      'packageName',
      'packageVersion',
      'compilerName',
      'compilerVersion',
      'sourceSchemaVersion',
      'resolvedSchemaVersion',
      'contractVersion',
      'sourceContentHash',
      'contractContentHash',
      'typeRegistryContentHash',
    ],
    '$.identity',
    diagnostics
  )
  if (
    typeof identity.themeId !== 'string' ||
    !/^[a-z][a-z0-9-]*$/.test(identity.themeId) ||
    typeof identity.packageName !== 'string' ||
    !identity.packageName.startsWith('@zxio/') ||
    typeof identity.packageVersion !== 'string' ||
    !SEMVER.test(identity.packageVersion) ||
    identity.compilerName !== '@zxio/theme-compiler' ||
    typeof identity.compilerVersion !== 'string' ||
    !SEMVER.test(identity.compilerVersion) ||
    identity.sourceSchemaVersion !== 4 ||
    identity.resolvedSchemaVersion !== 1 ||
    identity.contractVersion !== '4.0.0' ||
    !validHash(identity.sourceContentHash) ||
    !validHash(identity.contractContentHash) ||
    !validHash(identity.typeRegistryContentHash)
  ) {
    addInvalid(diagnostics, '$.identity', 'invalid-identity')
  }
}

function validateAxes(
  axes: RecordValue,
  diagnostics: Diagnostic[]
): ThemeAxisDeclarations | undefined {
  exactKeys(
    axes,
    ['applicationOrder', 'declarations', 'variantCount'],
    '$.axes',
    diagnostics
  )
  if (!same(axes.applicationOrder, APPLICATION_ORDER)) {
    addInvalid(
      diagnostics,
      '$.axes.applicationOrder',
      'invalid-application-order'
    )
  }
  const declarations = expectRecord(
    axes.declarations,
    '$.axes.declarations',
    diagnostics
  )
  if (!declarations) return undefined
  exactKeys(declarations, APPLICATION_ORDER, '$.axes.declarations', diagnostics)
  let valid = true
  for (const axis of APPLICATION_ORDER) {
    const declaration = expectRecord(
      declarations[axis],
      `$.axes.declarations.${axis}`,
      diagnostics
    )
    if (!declaration) {
      valid = false
      continue
    }
    exactKeys(
      declaration,
      ['supported', 'default'],
      `$.axes.declarations.${axis}`,
      diagnostics
    )
    const supported = declaration.supported
    if (
      !Array.isArray(supported) ||
      supported.length === 0 ||
      supported.some(
        (value) => typeof value !== 'string' || !AXIS_VALUES[axis].has(value)
      ) ||
      new Set(supported).size !== supported.length ||
      typeof declaration.default !== 'string' ||
      !supported.includes(declaration.default) ||
      (axis === 'mode' && supported.includes('system'))
    ) {
      addInvalid(
        diagnostics,
        `$.axes.declarations.${axis}`,
        'invalid-axis-declaration'
      )
      valid = false
    }
  }
  if (
    typeof axes.variantCount !== 'number' ||
    !Number.isSafeInteger(axes.variantCount) ||
    axes.variantCount < 1
  ) {
    addInvalid(diagnostics, '$.axes.variantCount', 'invalid-variant-count')
    valid = false
  }
  return valid ? (declarations as unknown as ThemeAxisDeclarations) : undefined
}

function validateArtifactRef(
  input: unknown,
  jsonPath: string,
  artifacts: ReadonlyMap<string, RecordValue>,
  diagnostics: Diagnostic[]
): RecordValue | undefined {
  const value = expectRecord(input, jsonPath, diagnostics)
  if (!value) return undefined
  exactKeys(value, ['path', 'sha256'], jsonPath, diagnostics)
  if (typeof value.path !== 'string' || !validHash(value.sha256)) {
    addInvalid(diagnostics, jsonPath, 'invalid-artifact-ref')
    return value
  }
  const artifact = artifacts.get(value.path)
  if (!artifact || artifact.sha256 !== value.sha256) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ARTIFACT_HASH_MISMATCH',
        phase: 'manifest',
        artifactPath: value.path,
        expected:
          artifact && typeof artifact.sha256 === 'string'
            ? artifact.sha256
            : null,
        actual: value.sha256,
        remediation: { code: 'FIX_MANIFEST_ARTIFACT_REFERENCE' },
        details: { jsonPath },
      })
    )
  }
  const expectedMetadata = expectedArtifactMetadata(value.path)
  if (
    !artifact ||
    !expectedMetadata ||
    artifact.purpose !== expectedMetadata.purpose ||
    artifact.mediaType !== expectedMetadata.mediaType ||
    artifact.loadPhase !== expectedMetadata.loadPhase
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        artifactPath: value.path,
        jsonPath,
        expected: expectedMetadata
          ? canonicalJson(expectedMetadata)
          : 'known locally owned artifact path',
        actual: artifact
          ? canonicalJson({
              purpose: String(artifact.purpose),
              mediaType: String(artifact.mediaType),
              loadPhase: String(artifact.loadPhase),
            })
          : null,
        target: 'exact local artifact ownership and metadata',
        remediation: { code: 'RESTORE_EXACT_ARTIFACT_METADATA' },
        details: { issue: 'local-artifact-metadata-mismatch' },
      })
    )
  }
  return value
}

function validateArtifacts(
  values: readonly unknown[],
  diagnostics: Diagnostic[]
): Map<string, RecordValue> {
  const artifacts = new Map<string, RecordValue>()
  const paths: string[] = []
  for (const [index, input] of values.entries()) {
    const jsonPath = `$.artifacts[${index}]`
    const value = expectRecord(input, jsonPath, diagnostics)
    if (!value) continue
    exactKeys(
      value,
      ['path', 'mediaType', 'bytes', 'sha256', 'purpose', 'loadPhase'],
      jsonPath,
      diagnostics
    )
    if (
      typeof value.path !== 'string' ||
      !isArtifactPath(value.path) ||
      value.path === 'theme.manifest.json' ||
      typeof value.mediaType !== 'string' ||
      value.mediaType.length === 0 ||
      typeof value.bytes !== 'number' ||
      !Number.isSafeInteger(value.bytes) ||
      value.bytes < 0 ||
      !validHash(value.sha256) ||
      typeof value.purpose !== 'string' ||
      !ARTIFACT_PURPOSES.has(value.purpose) ||
      typeof value.loadPhase !== 'string' ||
      !LOAD_PHASES.has(value.loadPhase)
    ) {
      addInvalid(diagnostics, jsonPath, 'invalid-artifact')
    }
    if (typeof value.path === 'string') {
      const expectedMetadata = expectedArtifactMetadata(value.path)
      if (
        !expectedMetadata ||
        value.purpose !== expectedMetadata.purpose ||
        value.mediaType !== expectedMetadata.mediaType ||
        value.loadPhase !== expectedMetadata.loadPhase
      ) {
        diagnostics.push(
          diagnostic({
            code: 'TC_MANIFEST_INVALID',
            phase: 'manifest',
            artifactPath: value.path,
            jsonPath,
            expected: expectedMetadata
              ? canonicalJson(expectedMetadata)
              : 'known locally owned artifact path',
            actual: canonicalJson({
              purpose: String(value.purpose),
              mediaType: String(value.mediaType),
              loadPhase: String(value.loadPhase),
            }),
            target: 'exact local artifact ownership and metadata',
            remediation: { code: 'RESTORE_EXACT_ARTIFACT_METADATA' },
            details: { issue: 'artifact-metadata-mismatch' },
          })
        )
      }
    }
    if (typeof value.path === 'string') {
      paths.push(value.path)
      if (artifacts.has(value.path)) {
        diagnostics.push(
          diagnostic({
            code: 'TC_ARTIFACT_DUPLICATE',
            phase: 'manifest',
            artifactPath: value.path,
            remediation: { code: 'REMOVE_DUPLICATE_MANIFEST_ARTIFACT' },
            details: { path: value.path },
          })
        )
      }
      artifacts.set(value.path, value)
    }
  }
  if (!same(paths, [...paths].sort(compareCodePoint))) {
    addInvalid(diagnostics, '$.artifacts', 'artifacts-not-canonically-sorted')
  }
  return artifacts
}

function validateVariants(
  values: readonly unknown[],
  declarations: ThemeAxisDeclarations | undefined,
  themeId: unknown,
  artifacts: ReadonlyMap<string, RecordValue>,
  declaredCount: unknown,
  diagnostics: Diagnostic[]
): {
  readonly artifactPaths: ReadonlySet<string>
  readonly variantKeys: readonly string[]
} {
  const referenced = new Set<string>()
  const variantKeys: string[] = []
  if (!declarations || typeof themeId !== 'string') {
    return { artifactPaths: referenced, variantKeys }
  }
  const expectedSelections = enumerateSelections(declarations)
  if (
    values.length !== expectedSelections.length ||
    declaredCount !== expectedSelections.length
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_MATRIX_INCOMPLETE',
        phase: 'manifest',
        expected: expectedSelections.length,
        actual: values.length,
        remediation: { code: 'REBUILD_COMPLETE_VARIANT_MATRIX' },
        details: {
          declared: typeof declaredCount === 'number' ? declaredCount : null,
          expected: expectedSelections.length,
          actual: values.length,
        },
      })
    )
  }
  for (const [index, input] of values.entries()) {
    const jsonPath = `$.variants[${index}]`
    const value = expectRecord(input, jsonPath, diagnostics)
    if (!value) continue
    exactKeys(
      value,
      [
        'variantKey',
        'selection',
        'resolvedContentHash',
        'selector',
        'artifacts',
      ],
      jsonPath,
      diagnostics
    )
    const selection = expectRecord(
      value.selection,
      `${jsonPath}.selection`,
      diagnostics
    )
    const refs = expectRecord(
      value.artifacts,
      `${jsonPath}.artifacts`,
      diagnostics
    )
    if (!selection || !refs) continue
    exactKeys(
      selection,
      APPLICATION_ORDER,
      `${jsonPath}.selection`,
      diagnostics
    )
    exactKeys(
      refs,
      ['coreCss', 'elementPlusResolvedCss', 'dtcgTokens'],
      `${jsonPath}.artifacts`,
      diagnostics
    )
    const expectedSelection = expectedSelections[index]
    const key = createVariantKey(
      selection as unknown as ThemeAxisSelection,
      APPLICATION_ORDER
    )
    const selector = createThemeSelector(
      themeId,
      selection as unknown as ThemeAxisSelection,
      APPLICATION_ORDER
    )
    if (typeof value.variantKey === 'string') variantKeys.push(value.variantKey)
    if (
      !expectedSelection ||
      !same(selection, expectedSelection) ||
      !key.ok ||
      key.value !== value.variantKey ||
      !selector.ok ||
      selector.value !== value.selector ||
      !validHash(value.resolvedContentHash)
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_IDENTITY_MISMATCH',
          phase: 'manifest',
          variantKey:
            typeof value.variantKey === 'string' ? value.variantKey : undefined,
          remediation: { code: 'RECOMPUTE_VARIANT_KEY_AND_SELECTOR' },
          details: { index, issue: 'variant-identity-or-order-mismatch' },
        })
      )
    }
    const refEntries = [
      ['coreCss', refs.coreCss, `variants/${String(value.variantKey)}.css`],
      [
        'elementPlusResolvedCss',
        refs.elementPlusResolvedCss,
        `element-plus/resolved/${String(value.variantKey)}.css`,
      ],
      [
        'dtcgTokens',
        refs.dtcgTokens,
        `dtcg/${String(value.variantKey)}.tokens.json`,
      ],
    ] as const
    for (const [name, refInput, expectedPath] of refEntries) {
      const ref = validateArtifactRef(
        refInput,
        `${jsonPath}.artifacts.${name}`,
        artifacts,
        diagnostics
      )
      if (ref && typeof ref.path === 'string') {
        referenced.add(ref.path)
        if (ref.path !== expectedPath) {
          addInvalid(
            diagnostics,
            `${jsonPath}.artifacts.${name}.path`,
            'variant-artifact-path-mismatch'
          )
        }
      }
    }
  }
  return { artifactPaths: referenced, variantKeys }
}

interface CoverageValue {
  readonly status: 'mapped' | 'not-applicable'
  readonly targets: readonly string[]
  readonly reasonCode?: string
}

function validateCoverageEntry(
  input: unknown,
  jsonPath: string,
  diagnostics: Diagnostic[],
  includeTokenPath: boolean
): (CoverageValue & { readonly tokenPath?: string }) | undefined {
  const value = expectRecord(input, jsonPath, diagnostics)
  if (!value) return undefined
  optionalKeys(
    value,
    [...(includeTokenPath ? ['tokenPath'] : []), 'status', 'targets'],
    ['reasonCode', ...(includeTokenPath ? [] : ['rationale'])],
    jsonPath,
    diagnostics
  )
  const targets = value.targets
  const tokenPathValid =
    !includeTokenPath ||
    (typeof value.tokenPath === 'string' && value.tokenPath.length > 0)
  if (
    !tokenPathValid ||
    (value.status !== 'mapped' && value.status !== 'not-applicable') ||
    !Array.isArray(targets) ||
    targets.some(
      (target) => typeof target !== 'string' || target.length === 0
    ) ||
    new Set(targets).size !== targets.length ||
    !same(targets, [...targets].sort(compareCodePoint)) ||
    (value.status === 'mapped' && targets.length === 0) ||
    (value.status === 'not-applicable' &&
      (targets.length !== 0 || typeof value.reasonCode !== 'string')) ||
    (value.reasonCode !== undefined && typeof value.reasonCode !== 'string') ||
    (value.rationale !== undefined && typeof value.rationale !== 'string')
  ) {
    addInvalid(diagnostics, jsonPath, 'invalid-adapter-coverage')
    return undefined
  }
  return {
    ...(includeTokenPath ? { tokenPath: value.tokenPath as string } : {}),
    status: value.status,
    targets: targets as string[],
    ...(typeof value.reasonCode === 'string'
      ? { reasonCode: value.reasonCode }
      : {}),
  }
}

function validatePublicSurface(
  values: readonly unknown[],
  diagnostics: Diagnostic[]
): {
  readonly paths: readonly string[]
  readonly byPath: ReadonlyMap<
    string,
    Readonly<Record<'elementPlus' | 'tailwind' | 'dtcg', CoverageValue>>
  >
} {
  const paths: string[] = []
  const byPath = new Map<
    string,
    Readonly<Record<'elementPlus' | 'tailwind' | 'dtcg', CoverageValue>>
  >()
  const variables = new Map<string, string[]>()
  for (const [index, input] of values.entries()) {
    const jsonPath = `$.publicSurface[${index}]`
    const value = expectRecord(input, jsonPath, diagnostics)
    if (!value) continue
    optionalKeys(
      value,
      [
        'path',
        'layer',
        'typeId',
        'lifecycle',
        'description',
        'css',
        'adapters',
      ],
      ['component', 'deprecated'],
      jsonPath,
      diagnostics
    )
    const css = expectRecord(value.css, `${jsonPath}.css`, diagnostics)
    const adapters = expectRecord(
      value.adapters,
      `${jsonPath}.adapters`,
      diagnostics
    )
    if (!css || !adapters) continue
    optionalKeys(
      css,
      ['internalVariable', 'publicVariable'],
      ['fields'],
      `${jsonPath}.css`,
      diagnostics
    )
    exactKeys(
      adapters,
      ['elementPlus', 'tailwind', 'dtcg'],
      `${jsonPath}.adapters`,
      diagnostics
    )
    const path = value.path
    const layerValid =
      value.layer === 'foundation' ||
      value.layer === 'semantic' ||
      value.layer === 'components'
    const componentValid =
      value.layer === 'components'
        ? typeof value.component === 'string' && value.component.length > 0
        : value.component === undefined
    const lifecycleValid =
      value.lifecycle === 'stable' ||
      value.lifecycle === 'experimental' ||
      value.lifecycle === 'deprecated'
    if (
      typeof path !== 'string' ||
      path.length === 0 ||
      !layerValid ||
      !componentValid ||
      typeof value.typeId !== 'string' ||
      value.typeId.length === 0 ||
      !lifecycleValid ||
      typeof value.description !== 'string' ||
      value.description.length === 0 ||
      css.internalVariable !== internalCssVariable(String(path)) ||
      css.publicVariable !== publicCssVariable(String(path))
    ) {
      addInvalid(diagnostics, jsonPath, 'invalid-public-token')
    }
    if (css.fields !== undefined) {
      const fields = expectRecord(
        css.fields,
        `${jsonPath}.css.fields`,
        diagnostics
      )
      if (
        fields &&
        Object.entries(fields).some(
          ([name, field]) =>
            !/^[a-z][a-z0-9-]*$/.test(name) ||
            field !== `${String(css.publicVariable)}-${name}`
        )
      ) {
        addInvalid(diagnostics, `${jsonPath}.css.fields`, 'invalid-css-fields')
      }
    }
    if (value.lifecycle === 'deprecated') {
      const deprecated = expectRecord(
        value.deprecated,
        `${jsonPath}.deprecated`,
        diagnostics
      )
      if (deprecated) {
        optionalKeys(
          deprecated,
          ['since'],
          ['replacement', 'noReplacementReason'],
          `${jsonPath}.deprecated`,
          diagnostics
        )
        if (
          typeof deprecated.since !== 'string' ||
          (typeof deprecated.replacement === 'string') ===
            (typeof deprecated.noReplacementReason === 'string')
        ) {
          addInvalid(
            diagnostics,
            `${jsonPath}.deprecated`,
            'invalid-deprecation'
          )
        }
      }
    } else if (value.deprecated !== undefined) {
      addInvalid(
        diagnostics,
        `${jsonPath}.deprecated`,
        'unexpected-deprecation'
      )
    }
    const coverage = {
      elementPlus: validateCoverageEntry(
        adapters.elementPlus,
        `${jsonPath}.adapters.elementPlus`,
        diagnostics,
        false
      ),
      tailwind: validateCoverageEntry(
        adapters.tailwind,
        `${jsonPath}.adapters.tailwind`,
        diagnostics,
        false
      ),
      dtcg: validateCoverageEntry(
        adapters.dtcg,
        `${jsonPath}.adapters.dtcg`,
        diagnostics,
        false
      ),
    }
    if (typeof path === 'string') {
      paths.push(path)
      if (byPath.has(path)) {
        addInvalid(diagnostics, `${jsonPath}.path`, 'duplicate-public-path')
      }
      if (coverage.elementPlus && coverage.tailwind && coverage.dtcg) {
        byPath.set(
          path,
          coverage as Record<'elementPlus' | 'tailwind' | 'dtcg', CoverageValue>
        )
      }
      const tokenVariables: Array<readonly [string, unknown]> = [
        ['internal', css.internalVariable],
        ['public', css.publicVariable],
      ]
      if (isRecord(css.fields)) {
        for (const [field, target] of Object.entries(css.fields)) {
          tokenVariables.push([`field:${field}`, target])
        }
      }
      for (const [kind, variable] of tokenVariables) {
        if (typeof variable === 'string') {
          variables.set(variable, [
            ...(variables.get(variable) ?? []),
            `${path}#${kind}`,
          ])
        }
      }
    }
  }
  if (!same(paths, [...paths].sort(compareCodePoint))) {
    addInvalid(
      diagnostics,
      '$.publicSurface',
      'public-surface-not-canonically-sorted'
    )
  }
  const collisions = [...variables.entries()]
    .filter(([, sources]) => sources.length > 1)
    .map(([variable, sources]) => ({ variable, sources }))
  if (collisions.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_CSS_VARIABLE_COLLISION',
        phase: 'manifest',
        remediation: { code: 'USE_UNIQUE_PUBLIC_VARIABLES' },
        details: { collisions },
      })
    )
  }
  return { paths, byPath }
}

function validateCoverageArray(
  input: unknown,
  jsonPath: string,
  publicPaths: readonly string[],
  diagnostics: Diagnostic[]
): Map<string, CoverageValue> {
  const output = new Map<string, CoverageValue>()
  if (!Array.isArray(input)) {
    addInvalid(diagnostics, jsonPath, 'expected-coverage-array')
    return output
  }
  const paths: string[] = []
  for (const [index, entry] of input.entries()) {
    const value = validateCoverageEntry(
      entry,
      `${jsonPath}[${index}]`,
      diagnostics,
      true
    )
    if (!value || !value.tokenPath) continue
    paths.push(value.tokenPath)
    if (output.has(value.tokenPath)) {
      addInvalid(
        diagnostics,
        `${jsonPath}[${index}].tokenPath`,
        'duplicate-coverage-path'
      )
    }
    output.set(value.tokenPath, {
      status: value.status,
      targets: value.targets,
      ...(value.reasonCode ? { reasonCode: value.reasonCode } : {}),
    })
  }
  if (!same(paths, publicPaths)) {
    addInvalid(diagnostics, jsonPath, 'coverage-public-surface-mismatch')
  }
  return output
}

function expectedCoverage(
  adapter: 'elementPlus' | 'tailwind' | 'dtcg',
  tokenPath: string
): CoverageValue | undefined {
  if (adapter === 'elementPlus') {
    const entry = elementPlusMapping.entries.find(
      (candidate) => candidate.source === tokenPath
    )
    if (!entry) return undefined
    return {
      status: entry.status,
      targets: 'targets' in entry ? [...entry.targets] : [],
      ...('reasonCode' in entry && typeof entry.reasonCode === 'string'
        ? { reasonCode: entry.reasonCode }
        : {}),
    }
  }
  if (adapter === 'tailwind') {
    const entry = tailwindMapping.entries.find(
      (candidate) => candidate.source === tokenPath
    )
    if (!entry) return undefined
    return {
      status: entry.status === 'mapped' ? 'mapped' : 'not-applicable',
      targets:
        entry.status === 'mapped'
          ? [`${String(entry.namespace)}.${String(entry.name)}`]
          : [],
      ...('reasonCode' in entry && typeof entry.reasonCode === 'string'
        ? { reasonCode: entry.reasonCode }
        : {}),
    }
  }
  return tokenPath.startsWith('semantic.')
    ? { status: 'mapped', targets: [tokenPath] }
    : {
        status: 'not-applicable',
        targets: [],
        reasonCode: 'PUBLIC_NON_SEMANTIC_NOT_EXPORTED',
      }
}

function validateCoverageContract(
  adapter: 'elementPlus' | 'tailwind' | 'dtcg',
  publicPaths: readonly string[],
  coverage: ReadonlyMap<string, CoverageValue>,
  diagnostics: Diagnostic[]
): void {
  for (const tokenPath of publicPaths) {
    const expected = expectedCoverage(adapter, tokenPath)
    const actual = coverage.get(tokenPath)
    if (!expected || !actual || !same(actual, expected)) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          adapter: adapter === 'elementPlus' ? 'element-plus' : adapter,
          tokenPath,
          jsonPath: `$.adapters.${adapter}.coverage`,
          expected: expected
            ? canonicalJson(expected)
            : 'known adapter mapping source',
          actual: actual ? canonicalJson(actual) : null,
          target: 'exact static adapter coverage contract',
          remediation: { code: 'RESTORE_EXACT_ADAPTER_COVERAGE' },
          details: { issue: 'adapter-coverage-contract-mismatch' },
        })
      )
    }
  }
}

function validateLocalAdapter(
  input: unknown,
  adapter: 'elementPlus' | 'dtcg',
  publicPaths: readonly string[],
  expectedArtifactPaths: ReadonlySet<string>,
  artifacts: ReadonlyMap<string, RecordValue>,
  diagnostics: Diagnostic[]
): {
  readonly coverage: ReadonlyMap<string, CoverageValue>
  readonly artifactPaths: ReadonlySet<string>
} {
  const jsonPath = `$.adapters.${adapter}`
  const value = expectRecord(input, jsonPath, diagnostics)
  const artifactPaths = new Set<string>()
  if (!value) return { coverage: new Map(), artifactPaths }
  optionalKeys(
    value,
    [
      'name',
      'version',
      'mappingSchema',
      'mappingVersion',
      'mappingHash',
      'artifacts',
      'coverage',
    ],
    ['targetBaseline'],
    jsonPath,
    diagnostics
  )
  const expectedName =
    adapter === 'elementPlus'
      ? '@zxio/theme-compiler/element-plus'
      : '@zxio/theme-compiler/dtcg'
  const expectedMapping =
    adapter === 'elementPlus'
      ? {
          schema: elementPlusMapping.schema,
          version: elementPlusMapping.version,
          hash: sha256(canonicalJson(elementPlusMapping)),
        }
      : {
          schema: 'zx.dtcg-2025.10-mapping/1',
          version: DTCG_ADAPTER_VERSION,
          hash: sha256(
            canonicalJson({
              schema: 'zx.dtcg-2025.10-mapping/1',
              version: DTCG_ADAPTER_VERSION,
              types: DTCG_TO_KERNEL_TYPE,
            })
          ),
        }
  if (
    value.name !== expectedName ||
    typeof value.version !== 'string' ||
    !SEMVER.test(value.version) ||
    (adapter === 'elementPlus' &&
      value.version !== elementPlusMapping.version) ||
    (adapter === 'dtcg' && value.version !== DTCG_ADAPTER_VERSION) ||
    value.mappingSchema !== expectedMapping.schema ||
    value.mappingVersion !== expectedMapping.version ||
    value.mappingHash !== expectedMapping.hash
  ) {
    addInvalid(diagnostics, jsonPath, 'invalid-local-adapter-identity')
  }
  if (adapter === 'elementPlus') {
    const baseline = expectRecord(
      value.targetBaseline,
      `${jsonPath}.targetBaseline`,
      diagnostics
    )
    if (baseline) {
      exactKeys(
        baseline,
        ['name', 'exactVersion', 'supportedRange', 'inventoryHash'],
        `${jsonPath}.targetBaseline`,
        diagnostics
      )
      if (
        baseline.name !== 'element-plus' ||
        baseline.exactVersion !== elementPlusTargetInventory.exactVersion ||
        baseline.supportedRange !== elementPlusTargetInventory.supportedRange ||
        baseline.inventoryHash !==
          sha256(canonicalJson(elementPlusTargetInventory))
      ) {
        addInvalid(
          diagnostics,
          `${jsonPath}.targetBaseline`,
          'invalid-target-baseline'
        )
      }
    }
  } else if (value.targetBaseline !== undefined) {
    addInvalid(
      diagnostics,
      `${jsonPath}.targetBaseline`,
      'unexpected-target-baseline'
    )
  }
  if (!Array.isArray(value.artifacts)) {
    addInvalid(
      diagnostics,
      `${jsonPath}.artifacts`,
      'expected-artifact-ref-array'
    )
  } else {
    const orderedPaths: string[] = []
    for (const [index, inputRef] of value.artifacts.entries()) {
      const ref = validateArtifactRef(
        inputRef,
        `${jsonPath}.artifacts[${index}]`,
        artifacts,
        diagnostics
      )
      if (ref && typeof ref.path === 'string') {
        orderedPaths.push(ref.path)
        artifactPaths.add(ref.path)
      }
    }
    if (!same(orderedPaths, [...orderedPaths].sort(compareCodePoint))) {
      addInvalid(
        diagnostics,
        `${jsonPath}.artifacts`,
        'adapter-artifacts-not-canonically-sorted'
      )
    }
    if (
      !same(orderedPaths, [...expectedArtifactPaths].sort(compareCodePoint))
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          adapter: adapter === 'elementPlus' ? 'element-plus' : adapter,
          jsonPath: `${jsonPath}.artifacts`,
          expected: [...expectedArtifactPaths].sort(compareCodePoint),
          actual: orderedPaths,
          target: 'exact local adapter artifact owner set',
          remediation: { code: 'RESTORE_EXACT_ADAPTER_ARTIFACTS' },
          details: { issue: 'adapter-artifact-owner-set-mismatch' },
        })
      )
    }
  }
  const coverage = validateCoverageArray(
    value.coverage,
    `${jsonPath}.coverage`,
    publicPaths,
    diagnostics
  )
  validateCoverageContract(adapter, publicPaths, coverage, diagnostics)
  return {
    coverage,
    artifactPaths,
  }
}

function validateExternalArtifactRef(
  input: unknown,
  jsonPath: string,
  diagnostics: Diagnostic[]
): RecordValue | undefined {
  const value = expectRecord(input, jsonPath, diagnostics)
  if (!value) return undefined
  exactKeys(
    value,
    ['packageName', 'packageVersion', 'exportPath', 'path', 'sha256'],
    jsonPath,
    diagnostics
  )
  if (
    value.packageName !== '@zxio/theme-tailwind' ||
    typeof value.packageVersion !== 'string' ||
    !SEMVER.test(value.packageVersion) ||
    typeof value.exportPath !== 'string' ||
    typeof value.path !== 'string' ||
    !value.path.startsWith('generated/') ||
    !validHash(value.sha256)
  ) {
    addInvalid(diagnostics, jsonPath, 'invalid-external-artifact-ref')
  }
  return value
}

function validateTailwindAdapter(
  input: unknown,
  publicPaths: readonly string[],
  contractContentHash: unknown,
  diagnostics: Diagnostic[]
): ReadonlyMap<string, CoverageValue> {
  const jsonPath = '$.adapters.tailwind'
  const value = expectRecord(input, jsonPath, diagnostics)
  if (!value) return new Map()
  exactKeys(
    value,
    [
      'name',
      'version',
      'contractContentHash',
      'mappingSchema',
      'mappingVersion',
      'mappingHash',
      'targetBaselines',
      'adapterContractHash',
      'manifest',
      'artifacts',
      'coverage',
    ],
    jsonPath,
    diagnostics
  )
  if (
    value.name !== '@zxio/theme-tailwind' ||
    value.version !== tailwindMapping.version ||
    value.contractContentHash !== contractContentHash ||
    !validHash(value.contractContentHash) ||
    value.mappingSchema !== tailwindMapping.schema ||
    value.mappingVersion !== tailwindMapping.version ||
    value.mappingHash !== sha256(canonicalJson(tailwindMapping)) ||
    !validHash(value.adapterContractHash)
  ) {
    addInvalid(diagnostics, jsonPath, 'invalid-tailwind-adapter-identity')
  }
  if (
    !Array.isArray(value.targetBaselines) ||
    value.targetBaselines.length !== 2
  ) {
    addInvalid(
      diagnostics,
      `${jsonPath}.targetBaselines`,
      'invalid-target-baselines'
    )
  } else {
    for (const [index, inputBaseline] of value.targetBaselines.entries()) {
      const baseline = expectRecord(
        inputBaseline,
        `${jsonPath}.targetBaselines[${index}]`,
        diagnostics
      )
      if (!baseline) continue
      exactKeys(
        baseline,
        ['name', 'major', 'exactTestVersion', 'supportedRange'],
        `${jsonPath}.targetBaselines[${index}]`,
        diagnostics
      )
      if (!same(baseline, TAILWIND_TARGET_BASELINES[index])) {
        addInvalid(
          diagnostics,
          `${jsonPath}.targetBaselines[${index}]`,
          'invalid-target-baseline'
        )
      }
    }
    if (!same(value.targetBaselines, TAILWIND_TARGET_BASELINES)) {
      addInvalid(
        diagnostics,
        `${jsonPath}.targetBaselines`,
        'tailwind-target-baseline-drift'
      )
    }
  }
  const manifest = validateExternalArtifactRef(
    value.manifest,
    `${jsonPath}.manifest`,
    diagnostics
  )
  if (
    manifest &&
    (manifest.exportPath !== './manifest.json' ||
      manifest.path !== 'generated/adapter.manifest.json')
  ) {
    addInvalid(diagnostics, `${jsonPath}.manifest`, 'invalid-manifest-ref')
  }
  let externalArtifacts: RecordValue[] = []
  if (!Array.isArray(value.artifacts) || value.artifacts.length !== 2) {
    addInvalid(
      diagnostics,
      `${jsonPath}.artifacts`,
      'invalid-external-artifacts'
    )
  } else {
    const refs = value.artifacts.map((entry, index) =>
      validateExternalArtifactRef(
        entry,
        `${jsonPath}.artifacts[${index}]`,
        diagnostics
      )
    )
    externalArtifacts = refs.filter(
      (ref): ref is RecordValue => ref !== undefined
    )
    const identities = refs.filter(Boolean).map((ref) => ({
      exportPath: ref!.exportPath,
      path: ref!.path,
    }))
    if (
      !same(identities, [
        {
          exportPath: './preset-v3',
          path: 'generated/preset-v3.cjs',
        },
        { exportPath: './v4.css', path: 'generated/v4.css' },
      ])
    ) {
      addInvalid(
        diagnostics,
        `${jsonPath}.artifacts`,
        'external-artifact-owner-set-mismatch'
      )
    }
    const packageVersions = new Set(
      [manifest, ...refs].filter(Boolean).map((ref) => ref!.packageVersion)
    )
    if (packageVersions.size !== 1) {
      addInvalid(diagnostics, jsonPath, 'external-package-version-mismatch')
    }
  }
  if (
    validHash(value.contractContentHash) &&
    validHash(value.mappingHash) &&
    externalArtifacts.length === 2 &&
    externalArtifacts.every(
      (artifact) =>
        typeof artifact.path === 'string' && validHash(artifact.sha256)
    )
  ) {
    const expectedContractHash = tailwindAdapterContractHash({
      contractContentHash: value.contractContentHash,
      mappingSchema: String(value.mappingSchema),
      mappingVersion: String(value.mappingVersion),
      mappingHash: value.mappingHash,
      artifacts: externalArtifacts.map((artifact) => ({
        path: String(artifact.path).replace(/^generated\//, ''),
        sha256: artifact.sha256 as `sha256:${string}`,
      })),
    })
    if (value.adapterContractHash !== expectedContractHash) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          adapter: 'tailwind',
          jsonPath: `${jsonPath}.adapterContractHash`,
          expected: expectedContractHash,
          actual: String(value.adapterContractHash),
          target: 'derived Tailwind adapter contract hash',
          remediation: { code: 'RECOMPUTE_TAILWIND_ADAPTER_CONTRACT_HASH' },
          details: { issue: 'tailwind-adapter-contract-hash-mismatch' },
        })
      )
    }
  }
  const coverage = validateCoverageArray(
    value.coverage,
    `${jsonPath}.coverage`,
    publicPaths,
    diagnostics
  )
  validateCoverageContract('tailwind', publicPaths, coverage, diagnostics)
  return coverage
}

function validateCoverageParity(
  publicCoverage: ReadonlyMap<
    string,
    Readonly<Record<'elementPlus' | 'tailwind' | 'dtcg', CoverageValue>>
  >,
  adapter: 'elementPlus' | 'tailwind' | 'dtcg',
  contractCoverage: ReadonlyMap<string, CoverageValue>,
  diagnostics: Diagnostic[]
): void {
  for (const [path, coverage] of publicCoverage) {
    const contractEntry = contractCoverage.get(path)
    if (!contractEntry || !same(coverage[adapter], contractEntry)) {
      addInvalid(
        diagnostics,
        `$.publicSurface[${JSON.stringify(path)}].adapters.${adapter}`,
        'adapter-coverage-parity-mismatch'
      )
    }
  }
}

function validateManifest(input: RecordValue): CompilerResult<ThemeManifestV1> {
  const diagnostics: Diagnostic[] = []
  exactKeys(
    input,
    [
      'schema',
      'variantKeySchema',
      'selectorSchema',
      ...(input.displayContract === undefined ? [] : ['displayContract']),
      'identity',
      'axes',
      'publicSurface',
      'variants',
      'artifacts',
      'adapters',
    ],
    '$',
    diagnostics
  )
  if (
    input.schema !== 'zx.theme-manifest/1' ||
    input.variantKeySchema !== 'zx.variant-key/1' ||
    input.selectorSchema !== 'zx.theme-selector/1'
  ) {
    addInvalid(
      diagnostics,
      '$',
      'unsupported-schema',
      'USE_SUPPORTED_MANIFEST_SCHEMA'
    )
  }
  const displayContract = checkDisplayContract(input.displayContract, false)
  if (!displayContract.ok)
    addInvalid(diagnostics, '$.displayContract', displayContract.code)
  const identity = expectRecord(input.identity, '$.identity', diagnostics)
  const axes = expectRecord(input.axes, '$.axes', diagnostics)
  const adapters = expectRecord(input.adapters, '$.adapters', diagnostics)
  if (!identity || !axes || !adapters) return failure(diagnostics)
  validateIdentity(identity, diagnostics)
  const declarations = validateAxes(axes, diagnostics)
  exactKeys(
    adapters,
    ['elementPlus', 'tailwind', 'dtcg'],
    '$.adapters',
    diagnostics
  )
  if (
    !Array.isArray(input.variants) ||
    !Array.isArray(input.artifacts) ||
    !Array.isArray(input.publicSurface)
  ) {
    addInvalid(
      diagnostics,
      '$',
      'variants-artifacts-public-surface-must-be-arrays'
    )
    return failure(diagnostics)
  }
  const artifactMap = validateArtifacts(input.artifacts, diagnostics)
  const variantOwned = validateVariants(
    input.variants,
    declarations,
    identity.themeId,
    artifactMap,
    axes.variantCount,
    diagnostics
  )
  const publicSurface = validatePublicSurface(input.publicSurface, diagnostics)
  const expectedElementPlusArtifacts = new Set([
    'element-plus/aliases.css',
    ...variantOwned.variantKeys.map(
      (variantKey) => `element-plus/resolved/${variantKey}.css`
    ),
  ])
  const expectedDtcgArtifacts = new Set([
    'dtcg/variants.json',
    ...variantOwned.variantKeys.map(
      (variantKey) => `dtcg/${variantKey}.tokens.json`
    ),
  ])
  const elementPlus = validateLocalAdapter(
    adapters.elementPlus,
    'elementPlus',
    publicSurface.paths,
    expectedElementPlusArtifacts,
    artifactMap,
    diagnostics
  )
  const dtcg = validateLocalAdapter(
    adapters.dtcg,
    'dtcg',
    publicSurface.paths,
    expectedDtcgArtifacts,
    artifactMap,
    diagnostics
  )
  const tailwind = validateTailwindAdapter(
    adapters.tailwind,
    publicSurface.paths,
    identity.contractContentHash,
    diagnostics
  )
  validateCoverageParity(
    publicSurface.byPath,
    'elementPlus',
    elementPlus.coverage,
    diagnostics
  )
  validateCoverageParity(
    publicSurface.byPath,
    'tailwind',
    tailwind,
    diagnostics
  )
  validateCoverageParity(
    publicSurface.byPath,
    'dtcg',
    dtcg.coverage,
    diagnostics
  )
  const ownedPaths = new Set([
    ...variantOwned.artifactPaths,
    ...elementPlus.artifactPaths,
    ...dtcg.artifactPaths,
    'theme.css',
    'typegen.cjs',
    'typegen.d.ts',
    'typegen.mjs',
  ])
  const missingOwners = [...artifactMap.keys()].filter(
    (path) => !ownedPaths.has(path)
  )
  const missingArtifacts = [...ownedPaths].filter(
    (path) => !artifactMap.has(path)
  )
  if (missingOwners.length > 0 || missingArtifacts.length > 0) {
    addInvalid(diagnostics, '$.artifacts', 'artifact-owner-set-mismatch')
  }
  validateStableManifestData(input, '$', diagnostics)
  const serialized = canonicalJson(input)
  return diagnostics.length > 0
    ? failure(diagnostics)
    : success(JSON.parse(serialized) as ThemeManifestV1)
}

export function validateThemeManifest(
  input: unknown
): CompilerResult<ThemeManifestV1> {
  if (!isRecord(input)) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        schemaVersion: 'zx.theme-manifest/1',
        jsonPath: '$',
        expected: 'object',
        actual: Array.isArray(input) ? 'array' : typeof input,
        target: 'theme manifest',
        remediation: { code: 'REBUILD_THEME_MANIFEST' },
        details: { issue: 'invalid-shape' },
      }),
    ])
  }
  try {
    return validateManifest(input)
  } catch (error) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        schemaVersion: 'zx.theme-manifest/1',
        jsonPath: '$',
        target: 'plain canonical manifest object',
        remediation: { code: 'REBUILD_THEME_MANIFEST' },
        details: {
          issue: 'manifest-validation-exception',
          reason: error instanceof Error ? error.message : String(error),
        },
      }),
    ])
  }
}
