import { diagnostic } from './diagnostics'
import { type CompilerResult, failure, success } from './result'
import { canonicalize, compareCodePoint } from './canonical-text'

import type {
  AuthorLogicalSourceLocator,
  BuiltInTypeMap,
  CanonicalJsonValue,
  ThemeTypeMap,
} from '@zxio/tokens/kernel'

export interface CssSerializationContext {
  readonly tokenPath: string
  readonly target: string
  readonly allowRawString?: boolean
}

export interface DtcgSerializationContext {
  readonly tokenPath: string
  readonly jsonPath: string
}

export interface TargetTypeSerializer<Value> {
  readonly typeId: string
  readonly registrationPoint: `type-serializer:${string}`
  readonly typegen: Readonly<{
    readonlyTypeExpression: string
    runtimeMetadata: CanonicalJsonValue
  }>
  readonly dtcg?: Readonly<{
    type:
      | 'color'
      | 'dimension'
      | 'number'
      | 'duration'
      | 'cubicBezier'
      | 'fontFamily'
      | 'fontWeight'
      | 'gradient'
      | 'shadow'
      | 'strokeStyle'
      | 'transition'
      | 'border'
      | 'typography'
      | 'string'
  }>
  toCss(
    value: Readonly<Value>,
    context: CssSerializationContext
  ): CompilerResult<string>
  toDtcg?(
    value: Readonly<Value>,
    context: DtcgSerializationContext
  ): CompilerResult<CanonicalJsonValue>
  fromDtcg?(
    value: unknown,
    context: DtcgSerializationContext
  ): CompilerResult<Value>
}

export type TargetSerializerRegistry<M extends ThemeTypeMap> = Readonly<{
  [K in Extract<keyof M, string>]?: TargetTypeSerializer<M[K]>
}>

export function serializerMissing(
  typeId: string,
  tokenPath: string,
  target: string
): CompilerResult<never> {
  const registrationPoint = `type-serializer:${typeId}`
  return failure([
    diagnostic({
      code: 'TC_SERIALIZER_MISSING',
      phase: 'serialize',
      tokenPath,
      target,
      remediation: {
        code: 'REGISTER_TARGET_SERIALIZER',
        registrationPoint,
      },
      details: {
        typeId,
        tokenPath,
        target,
        requiredRegistrationPoint: registrationPoint,
      },
    }),
  ])
}

export function serializeWithRegistry<M extends ThemeTypeMap>(
  registry: TargetSerializerRegistry<M>,
  typeId: Extract<keyof M, string>,
  value: M[Extract<keyof M, string>],
  context: CssSerializationContext
): CompilerResult<string> {
  const serializer = registry[typeId] as
    | TargetTypeSerializer<M[Extract<keyof M, string>]>
    | undefined
  return serializer
    ? serializer.toCss(value, context)
    : serializerMissing(typeId, context.tokenPath, context.target)
}

export type BuiltInSerializerRegistry = Required<
  TargetSerializerRegistry<BuiltInTypeMap>
>

export const BUILT_IN_TYPE_IDS = [
  'border',
  'color',
  'cubic-bezier',
  'dimension',
  'duration',
  'font-family',
  'font-weight',
  'gradient',
  'number',
  'shadow',
  'strokeStyle',
  'string',
  'transition',
  'typography',
] as const

export function validateSerializerCoverage(
  registeredTypeIds: readonly string[],
  tokens: readonly Readonly<{
    path: string
    typeId: string
    layer: 'foundation' | 'semantic' | 'components'
    visibility: 'internal' | 'public'
    source?: AuthorLogicalSourceLocator
  }>[],
  registry: Readonly<Record<string, TargetTypeSerializer<unknown> | undefined>>
): CompilerResult<true> {
  const diagnostics = []
  const registered = new Set(registeredTypeIds)
  const builtIns = new Set<string>(BUILT_IN_TYPE_IDS)
  const ordered = [...tokens].sort((left, right) =>
    compareCodePoint(
      `${left.path}\0${left.typeId}`,
      `${right.path}\0${right.typeId}`
    )
  )
  for (const token of ordered) {
    const serializer = registry[token.typeId]
    const registrationPoint = `type-serializer:${token.typeId}`
    const targets: string[] = []
    if (
      !registered.has(token.typeId) ||
      !serializer ||
      serializer.typeId !== token.typeId ||
      serializer.registrationPoint !== registrationPoint ||
      typeof serializer.toCss !== 'function'
    ) {
      targets.push('css')
    }
    let typegenValid = false
    if (serializer) {
      try {
        const expression = serializer.typegen?.readonlyTypeExpression
        canonicalize(serializer.typegen?.runtimeMetadata)
        typegenValid =
          typeof expression === 'string' &&
          expression.trim().length > 0 &&
          !/(?:^|\W)(?:any|unknown)(?:$|\W)/.test(expression)
      } catch {
        typegenValid = false
      }
    }
    if (token.visibility === 'public' && !typegenValid) targets.push('typegen')
    if (
      !builtIns.has(token.typeId) &&
      token.visibility === 'public' &&
      token.layer === 'semantic'
    ) {
      if (
        !serializer ||
        typeof serializer.toDtcg !== 'function' ||
        typeof serializer.dtcg?.type !== 'string'
      )
        targets.push('dtcg-export')
      if (!serializer || typeof serializer.fromDtcg !== 'function')
        targets.push('dtcg-import')
    }
    for (const target of targets) {
      diagnostics.push(
        diagnostic({
          code: 'TC_SERIALIZER_MISSING',
          phase: 'serialize',
          source: token.source,
          tokenPath: token.path,
          expected: registrationPoint,
          actual: 'missing-or-invalid',
          target,
          remediation: {
            code: 'REGISTER_TARGET_SERIALIZER',
            registrationPoint,
          },
          details: {
            typeId: token.typeId,
            tokenPath: token.path,
            target,
            requiredRegistrationPoint: registrationPoint,
          },
        })
      )
    }
  }
  return diagnostics.length > 0 ? failure(diagnostics) : success(true)
}

export { builtInSerializers } from '../targets/css/value-serializers'
