import { canonicalize } from './canonical-text'

import type {
  AuthorLogicalSourceLocator,
  CanonicalJsonValue,
  ThemeDiagnostic,
} from '@zxio/tokens/kernel'

export type ThemeCompilerDiagnosticCode =
  | 'TC_INPUT_INVALID'
  | 'TC_KERNEL_FAILURE'
  | 'TC_MATRIX_INCOMPLETE'
  | 'TC_VARIANT_KEY_COLLISION'
  | 'TC_IDENTITY_MISMATCH'
  | 'TC_SERIALIZER_MISSING'
  | 'TC_VALUE_UNREPRESENTABLE'
  | 'TC_CSS_VARIABLE_COLLISION'
  | 'TC_ARTIFACT_PATH_INVALID'
  | 'TC_ARTIFACT_DUPLICATE'
  | 'TC_ARTIFACT_HASH_MISMATCH'
  | 'TC_ADAPTER_MAPPING_MISSING'
  | 'TC_ADAPTER_MAPPING_COLLISION'
  | 'TC_ADAPTER_TARGET_UNKNOWN'
  | 'TC_ADAPTER_EMISSION_SCOPE_INVALID'
  | 'TC_DTCG_TYPE_REQUIRED'
  | 'TC_DTCG_TYPE_UNSUPPORTED'
  | 'TC_DTCG_VALUE_UNREPRESENTABLE'
  | 'TC_DTCG_EXTENSION_INVALID'
  | 'TC_MANIFEST_INVALID'
  | 'TC_WRITE_OUTSIDE_ROOT'
  | 'TC_WRITE_SYMLINK_ESCAPE'
  | 'TC_WRITE_COMMIT_FAILED'
  | 'TC_GENERATED_MISSING'
  | 'TC_GENERATED_EXTRA'
  | 'TC_GENERATED_CHANGED'
  | 'TC_READONLY_MUTATION'

export type ThemeCompilerPhase =
  | 'input'
  | 'matrix'
  | 'serialize'
  | 'adapter'
  | 'manifest'
  | 'write'
  | 'check'

export interface ThemeCompilerDiagnostic {
  readonly code: ThemeCompilerDiagnosticCode
  readonly phase: ThemeCompilerPhase
  readonly adapter?: 'element-plus' | 'tailwind' | 'dtcg'
  readonly source?: AuthorLogicalSourceLocator
  readonly tokenPath?: string
  readonly variantKey?: string
  readonly artifactPath?: string
  readonly schemaVersion?: string
  readonly jsonPath?: string
  readonly expected?: CanonicalJsonValue
  readonly actual?: CanonicalJsonValue
  readonly target?: string
  readonly remediation: Readonly<{
    code: string
    registrationPoint?: string
    hint?: string
  }>
  readonly details: Readonly<Record<string, CanonicalJsonValue>>
  readonly upstream?: ThemeDiagnostic
}

export type DiagnosticInput = Omit<
  ThemeCompilerDiagnostic,
  'remediation' | 'details'
> &
  Readonly<{
    remediation?: ThemeCompilerDiagnostic['remediation']
    details?: ThemeCompilerDiagnostic['details']
  }>

export function diagnostic(input: DiagnosticInput): ThemeCompilerDiagnostic {
  return canonicalize({
    ...input,
    remediation: input.remediation ?? { code: `${input.code}_REMEDIATE` },
    details: input.details ?? {},
  }) as unknown as ThemeCompilerDiagnostic
}

export function wrapKernelDiagnostics(
  upstream: readonly ThemeDiagnostic[],
  context: Readonly<{
    phase: ThemeCompilerPhase
    variantKey?: string
    adapter?: 'element-plus' | 'tailwind' | 'dtcg'
  }>
): readonly ThemeCompilerDiagnostic[] {
  return upstream.map((entry) =>
    diagnostic({
      code: 'TC_KERNEL_FAILURE',
      phase: context.phase,
      adapter: context.adapter,
      source: entry.source,
      tokenPath:
        entry.location.kind === 'token'
          ? String(entry.location.path)
          : undefined,
      variantKey: context.variantKey,
      expected: 'valid Kernel Theme v4 input',
      actual: entry.code,
      target: `Kernel ${entry.phase} boundary`,
      upstream: entry,
      remediation: {
        code: 'FIX_KERNEL_INPUT',
        hint: entry.hint,
      },
      details: {
        upstreamCode: entry.code,
        upstreamPhase: entry.phase,
        logicalLocation: entry.location.path,
        trace: (entry.trace ?? []) as CanonicalJsonValue,
        upstreamDetails: entry.details as CanonicalJsonValue,
      },
    })
  )
}
