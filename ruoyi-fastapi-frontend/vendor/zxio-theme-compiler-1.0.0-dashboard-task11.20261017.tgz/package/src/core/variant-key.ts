import { diagnostic } from './diagnostics'
import { type CompilerResult, failure, success } from './result'

import type { AxisOrder, ThemeAxisSelection } from '@zxio/tokens/kernel'

export const VARIANT_KEY_SCHEMA = 'zx.variant-key/1' as const
const safeSegment = /^[a-z][a-z0-9-]*$/

export function createVariantKey(
  selection: ThemeAxisSelection,
  applicationOrder: AxisOrder
): CompilerResult<string> {
  const invalid = applicationOrder.flatMap((axis) => {
    const value = selection[axis]
    return safeSegment.test(axis) && safeSegment.test(value)
      ? []
      : [{ axis, value }]
  })
  if (invalid.length > 0) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'matrix',
        remediation: { code: 'USE_SAFE_AXIS_SEGMENTS' },
        details: { invalid },
      }),
    ])
  }
  return success(
    applicationOrder.map((axis) => `${axis}-${selection[axis]}`).join('__')
  )
}
