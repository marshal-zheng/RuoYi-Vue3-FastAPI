import { createHash } from 'node:crypto'
import { canonicalNumber } from '@zxio/theme-css-codec'

import type { CanonicalJsonValue } from '@zxio/tokens/kernel'

export { canonicalNumber } from '@zxio/theme-css-codec'

export function compareCodePoint(left: string, right: string): number {
  const leftBytes = Buffer.from(left, 'utf8')
  const rightBytes = Buffer.from(right, 'utf8')
  return Buffer.compare(leftBytes, rightBytes)
}

export function canonicalize(input: unknown): CanonicalJsonValue {
  const active = new Set<object>()
  const visit = (value: unknown): CanonicalJsonValue => {
    if (
      value === null ||
      typeof value === 'string' ||
      typeof value === 'boolean'
    ) {
      return value
    }
    if (typeof value === 'number') {
      if (!Number.isFinite(value)) throw new TypeError('non-finite number')
      return Object.is(value, -0) ? 0 : value
    }
    if (Array.isArray(value)) {
      if (active.has(value)) throw new TypeError('cyclic array')
      active.add(value)
      const output = value.map(visit)
      active.delete(value)
      return output
    }
    if (typeof value !== 'object' || value === undefined) {
      throw new TypeError(`unsupported canonical value: ${typeof value}`)
    }
    if (active.has(value)) throw new TypeError('cyclic object')
    const prototype = Object.getPrototypeOf(value)
    if (prototype !== Object.prototype && prototype !== null) {
      throw new TypeError('canonical objects must be plain')
    }
    active.add(value)
    const output: Record<string, CanonicalJsonValue> = {}
    for (const key of Object.keys(value).sort(compareCodePoint)) {
      const descriptor = Object.getOwnPropertyDescriptor(value, key)
      if (!descriptor || !('value' in descriptor)) {
        throw new TypeError(`accessor property is not canonical: ${key}`)
      }
      if (descriptor.value !== undefined) output[key] = visit(descriptor.value)
    }
    active.delete(value)
    return output
  }
  return visit(input)
}

function printJson(value: CanonicalJsonValue, depth: number): string {
  if (value === null) return 'null'
  if (typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'boolean') return value ? 'true' : 'false'
  if (typeof value === 'number') return canonicalNumber(value)
  if (Array.isArray(value)) {
    if (value.length === 0) return '[]'
    const indent = '  '.repeat(depth + 1)
    return `[\n${value
      .map((entry) => `${indent}${printJson(entry, depth + 1)}`)
      .join(',\n')}\n${'  '.repeat(depth)}]`
  }
  const entries = Object.entries(value).sort(([left], [right]) =>
    compareCodePoint(left, right)
  )
  if (entries.length === 0) return '{}'
  const indent = '  '.repeat(depth + 1)
  return `{\n${entries
    .map(
      ([key, entry]) =>
        `${indent}${JSON.stringify(key)}: ${printJson(entry, depth + 1)}`
    )
    .join(',\n')}\n${'  '.repeat(depth)}}`
}

export function canonicalJson(input: unknown): string {
  return `${printJson(canonicalize(input), 0)}\n`
}

function printJcs(value: CanonicalJsonValue): string {
  if (value === null) return 'null'
  if (typeof value === 'string') return JSON.stringify(value)
  if (typeof value === 'boolean') return value ? 'true' : 'false'
  if (typeof value === 'number') return canonicalNumber(value)
  if (Array.isArray(value)) return `[${value.map(printJcs).join(',')}]`
  const record = value as Readonly<Record<string, CanonicalJsonValue>>
  return `{${Object.keys(record)
    .sort(compareCodePoint)
    .map((key) => `${JSON.stringify(key)}:${printJcs(record[key]!)}`)
    .join(',')}}`
}

export function canonicalJcs(input: unknown): string {
  return printJcs(canonicalize(input))
}

export function canonicalSnapshot(input: unknown): string {
  return canonicalJson(input)
}

export function utf8(input: string): Uint8Array {
  return new TextEncoder().encode(input.replace(/\r\n?/g, '\n'))
}

export function sha256(input: Uint8Array | string): `sha256:${string}` {
  return `sha256:${createHash('sha256').update(input).digest('hex')}`
}

export function canonicalHash(input: unknown): `sha256:${string}` {
  return sha256(canonicalJcs(input))
}

export function deepFreeze<T>(value: T): T {
  if (value === null || typeof value !== 'object' || Object.isFrozen(value)) {
    return value
  }
  if (ArrayBuffer.isView(value)) {
    throw new TypeError('mutable typed arrays cannot enter a public graph')
  }
  for (const key of Object.keys(value)) {
    deepFreeze((value as Record<string, unknown>)[key])
  }
  return Object.freeze(value)
}

export function canonicalCssBlock(
  selector: string,
  declarations: readonly Readonly<{ property: string; value: string }>[]
): string {
  const lines = declarations.map(
    ({ property, value }) => `  ${property}: ${value};`
  )
  return `${selector} {\n${lines.join('\n')}\n}\n`
}

export function quoteJs(value: string): string {
  return JSON.stringify(value).replace(/</g, '\\u003c')
}
