import {
  canonicalJson,
  compareCodePoint,
  deepFreeze,
  sha256,
  utf8,
} from './canonical-text'
import { diagnostic } from './diagnostics'
import { type CompilerResult, failure, success } from './result'

declare const canonicalBase64BytesBrand: unique symbol
export type CanonicalBase64Bytes = string & {
  readonly [canonicalBase64BytesBrand]: true
}

export type ArtifactLoadPhase = 'contract' | 'theme' | 'variant' | 'tooling'

export interface ArtifactFile<Purpose extends string = string> {
  readonly path: string
  readonly mediaType: string
  readonly purpose: Purpose
  readonly loadPhase: ArtifactLoadPhase
  readonly byteLength: number
  readonly sha256: `sha256:${string}`
  readonly bytes: CanonicalBase64Bytes
}

export type ThemeArtifactPurpose =
  | 'core-css'
  | 'aggregate-css'
  | 'typegen-runtime'
  | 'typegen-declarations'
  | 'element-plus-alias'
  | 'element-plus-resolved'
  | 'dtcg-token-set'
  | 'dtcg-index'
  | 'theme-manifest'

export type TailwindArtifactPurpose =
  | 'tailwind-v4-css'
  | 'tailwind-v3-preset'
  | 'tailwind-manifest'

export type ThemeArtifactFile = ArtifactFile<ThemeArtifactPurpose>
export type TailwindArtifactFile = ArtifactFile<TailwindArtifactPurpose>

export interface ThemeArtifactSet<Manifest = unknown> {
  readonly kind: 'theme'
  readonly themeId: string
  readonly files: readonly ThemeArtifactFile[]
  readonly manifest: Manifest
  readonly artifactSetHash: `sha256:${string}`
}

export interface TailwindContractArtifactSet<
  Manifest = unknown,
  ExternalRef = unknown
> {
  readonly kind: 'tailwind-contract'
  readonly contractContentHash: `sha256:${string}`
  readonly files: readonly TailwindArtifactFile[]
  readonly manifest: Manifest
  readonly externalRef: ExternalRef
  readonly artifactSetHash: `sha256:${string}`
}

export function isArtifactPath(path: string): boolean {
  if (
    !path ||
    path.startsWith('/') ||
    path.includes('\\') ||
    path.includes('\0')
  ) {
    return false
  }
  const segments = path.split('/')
  return segments.every(
    (segment) => segment !== '' && segment !== '.' && segment !== '..'
  )
}

export function encodeArtifactBytes(input: Uint8Array): CanonicalBase64Bytes {
  return Buffer.from(input).toString('base64') as CanonicalBase64Bytes
}

export function decodeArtifactBytes(input: CanonicalBase64Bytes): Uint8Array {
  return Uint8Array.from(Buffer.from(input, 'base64'))
}

function isCanonicalBase64(input: string): boolean {
  if (input.length % 4 !== 0) return false
  const padding = input.endsWith('==') ? 2 : input.endsWith('=') ? 1 : 0
  const bodyLength = input.length - padding
  for (let index = 0; index < bodyLength; index += 1) {
    const code = input.charCodeAt(index)
    const allowed =
      (code >= 48 && code <= 57) ||
      (code >= 65 && code <= 90) ||
      (code >= 97 && code <= 122) ||
      code === 43 ||
      code === 47
    if (!allowed) return false
  }
  return !input.slice(bodyLength).split('=').join('').length
}

export function verifyArtifactFile(
  file: ArtifactFile,
  phase: 'manifest' | 'write' | 'check' = 'manifest'
): CompilerResult<ArtifactFile> {
  if (!file || typeof file !== 'object' || Array.isArray(file)) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase,
        remediation: { code: 'PASS_EXACT_ARTIFACT_FILE' },
        details: { issue: 'artifact-file-not-object' },
      }),
    ])
  }
  const expectedKeys = [
    'byteLength',
    'bytes',
    'loadPhase',
    'mediaType',
    'path',
    'purpose',
    'sha256',
  ]
  const actualKeys = Object.keys(file).sort(compareCodePoint)
  const prototype = Object.getPrototypeOf(file)
  const dataPropertiesOnly = actualKeys.every((key) => {
    const descriptor = Object.getOwnPropertyDescriptor(file, key)
    return !!descriptor && 'value' in descriptor
  })
  if (
    (prototype !== Object.prototype && prototype !== null) ||
    !dataPropertiesOnly ||
    canonicalJson(actualKeys) !== canonicalJson(expectedKeys) ||
    typeof file.path !== 'string' ||
    typeof file.mediaType !== 'string' ||
    file.mediaType.length === 0 ||
    typeof file.purpose !== 'string' ||
    file.purpose.length === 0 ||
    !['contract', 'theme', 'variant', 'tooling'].includes(file.loadPhase) ||
    typeof file.byteLength !== 'number' ||
    !Number.isSafeInteger(file.byteLength) ||
    file.byteLength < 0 ||
    typeof file.sha256 !== 'string' ||
    !/^sha256:[a-f0-9]{64}$/.test(file.sha256) ||
    typeof file.bytes !== 'string'
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase,
        artifactPath:
          typeof file.path === 'string' ? file.path : '<invalid-artifact-path>',
        expected: expectedKeys,
        actual: actualKeys,
        remediation: { code: 'PASS_EXACT_ARTIFACT_FILE' },
        details: { issue: 'invalid-artifact-file-shape' },
      }),
    ])
  }
  if (!isArtifactPath(file.path)) {
    return failure([
      diagnostic({
        code: 'TC_ARTIFACT_PATH_INVALID',
        phase,
        artifactPath: file.path,
        expected: 'normalized relative POSIX artifact path',
        actual: file.path,
        target: 'artifact path',
        remediation: { code: 'USE_NORMALIZED_ARTIFACT_PATH' },
        details: { path: file.path },
      }),
    ])
  }
  if (!isCanonicalBase64(file.bytes)) {
    return failure([
      diagnostic({
        code: 'TC_ARTIFACT_HASH_MISMATCH',
        phase,
        artifactPath: file.path,
        expected: 'canonical RFC 4648 base64',
        actual: 'non-canonical-base64',
        target: 'artifact byte encoding',
        remediation: { code: 'USE_CANONICAL_BASE64' },
        details: { issue: 'non-canonical-base64' },
      }),
    ])
  }
  const decoded = decodeArtifactBytes(file.bytes)
  if (encodeArtifactBytes(decoded) !== file.bytes) {
    return failure([
      diagnostic({
        code: 'TC_ARTIFACT_HASH_MISMATCH',
        phase,
        artifactPath: file.path,
        expected: 'canonical RFC 4648 base64',
        actual: 'non-canonical-base64',
        target: 'artifact byte encoding',
        remediation: { code: 'USE_CANONICAL_BASE64' },
        details: { issue: 'non-canonical-base64' },
      }),
    ])
  }
  const actualHash = sha256(decoded)
  if (decoded.byteLength !== file.byteLength || actualHash !== file.sha256) {
    return failure([
      diagnostic({
        code: 'TC_ARTIFACT_HASH_MISMATCH',
        phase,
        artifactPath: file.path,
        expected: file.sha256,
        actual: actualHash,
        target: 'artifact SHA-256 and decoded byte length',
        remediation: { code: 'RESTORE_EXACT_ARTIFACT_BYTES' },
        details: {
          expectedBytes: file.byteLength,
          actualBytes: decoded.byteLength,
        },
      }),
    ])
  }
  return success(file)
}

export class ArtifactGraphBuilder<Purpose extends string> {
  readonly #files: ArtifactFile<Purpose>[] = []

  addText(
    input: Readonly<{
      path: string
      mediaType: string
      purpose: Purpose
      loadPhase: ArtifactLoadPhase
      text: string
    }>
  ): this {
    const normalized = input.text.replace(/\r\n?/g, '\n')
    const bytes = utf8(`${normalized.replace(/\n+$/g, '')}\n`)
    this.#files.push({
      path: input.path,
      mediaType: input.mediaType,
      purpose: input.purpose,
      loadPhase: input.loadPhase,
      byteLength: bytes.byteLength,
      sha256: sha256(bytes),
      bytes: encodeArtifactBytes(bytes),
    })
    return this
  }

  addJson(
    input: Omit<
      Parameters<ArtifactGraphBuilder<Purpose>['addText']>[0],
      'text'
    > & {
      readonly value: unknown
    }
  ): this {
    return this.addText({ ...input, text: canonicalJson(input.value) })
  }

  finalize(): CompilerResult<readonly ArtifactFile<Purpose>[]> {
    const diagnostics = []
    const byPath = new Map<string, ArtifactFile<Purpose>[]>()
    for (const file of this.#files) {
      const existing = byPath.get(file.path) ?? []
      existing.push(file)
      byPath.set(file.path, existing)
      const verified = verifyArtifactFile(file)
      if (!verified.ok) diagnostics.push(...verified.diagnostics)
    }
    for (const [path, sources] of byPath) {
      if (sources.length > 1) {
        diagnostics.push(
          diagnostic({
            code: 'TC_ARTIFACT_DUPLICATE',
            phase: 'manifest',
            artifactPath: path,
            details: {
              path,
              sources: sources.map(
                (entry) => `${entry.purpose}:${entry.sha256}`
              ),
            },
          })
        )
      }
    }
    if (diagnostics.length > 0) return failure(diagnostics)
    return success(
      deepFreeze(
        [...this.#files].sort((left, right) =>
          compareCodePoint(left.path, right.path)
        )
      )
    )
  }
}

export function artifactSetHash(
  files: readonly ArtifactFile[]
): `sha256:${string}` {
  return sha256(
    canonicalJson(
      files.map(
        ({
          path,
          sha256: hash,
          byteLength,
          purpose,
          mediaType,
          loadPhase,
        }) => ({
          path,
          sha256: hash,
          byteLength,
          purpose,
          mediaType,
          loadPhase,
        })
      )
    )
  )
}
