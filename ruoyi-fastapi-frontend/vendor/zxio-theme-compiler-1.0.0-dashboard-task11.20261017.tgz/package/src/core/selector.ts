import { createVariantKey } from './variant-key'
import { type CompilerResult, failure, success } from './result'

import type { AxisOrder, ThemeAxisSelection } from '@zxio/tokens/kernel'

export const SELECTOR_SCHEMA = 'zx.theme-selector/1' as const

function cssAttributeEscape(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\n/g, '\\a ')
}

export function createThemeSelector(
  themeId: string,
  selection: ThemeAxisSelection,
  applicationOrder: AxisOrder
): CompilerResult<string> {
  const key = createVariantKey(selection, applicationOrder)
  if (!key.ok) return failure(key.diagnostics)
  return success(
    `:where([data-zx-theme='${cssAttributeEscape(
      themeId
    )}'][data-zx-variant='${cssAttributeEscape(key.value)}'])`
  )
}

export function createThemeScopeSelector(themeId: string): string {
  return `:where([data-zx-theme='${cssAttributeEscape(themeId)}'])`
}
