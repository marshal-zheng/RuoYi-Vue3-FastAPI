import { createHash } from 'node:crypto'
import { compareCodePoint } from './canonical-text'

function primitiveSnapshot(value: unknown): string {
  if (value === null) return 'null'
  switch (typeof value) {
    case 'undefined':
      return '"primitive:undefined"'
    case 'boolean':
    case 'number':
    case 'string':
      return JSON.stringify(value) ?? 'null'
    case 'bigint':
      return JSON.stringify(`primitive:bigint:${value.toString(10)}`)
    case 'symbol':
      return JSON.stringify(
        `primitive:symbol:${String(value.description ?? '')}`
      )
    default:
      return JSON.stringify(`primitive:${typeof value}`)
  }
}

/**
 * Creates two comparable snapshots over the same identity table. The snapshot
 * never evaluates accessors and records identity, descriptors, prototypes and
 * byte views in addition to values, so a structurally equal replacement still
 * counts as caller-input mutation.
 *
 * The traversal streams an unambiguous canonical serialization into a SHA-256
 * digest instead of materializing one giant string, so full resolved-matrix
 * requests (hundreds of megabytes of serialized form) stay comparable without
 * hitting the engine string-length ceiling.
 */
export function createMutationSnapshotter(): Readonly<{
  snapshot(input: unknown): string
}> {
  const identities = new WeakMap<object, number>()
  const symbolIdentities = new Map<symbol, number>()
  let nextIdentity = 1

  const identityOf = (value: object): number => {
    const existing = identities.get(value)
    if (existing !== undefined) return existing
    const identity = nextIdentity++
    identities.set(value, identity)
    return identity
  }
  const symbolIdentityOf = (value: symbol): number => {
    const existing = symbolIdentities.get(value)
    if (existing !== undefined) return existing
    const identity = nextIdentity++
    symbolIdentities.set(value, identity)
    return identity
  }

  const snapshot = (input: unknown): string => {
    const hash = createHash('sha256')
    const emit = (chunk: string): void => {
      hash.update(chunk, 'utf8')
    }
    const expanded = new Set<object>()

    const visit = (value: unknown): void => {
      if (
        value === null ||
        (typeof value !== 'object' && typeof value !== 'function')
      ) {
        emit(`P${primitiveSnapshot(value)};`)
        return
      }
      const object = value as object
      const identity = identityOf(object)
      if (expanded.has(object)) {
        emit(`R${identity};`)
        return
      }
      expanded.add(object)

      if (value instanceof ArrayBuffer) {
        emit(
          `B${identity}:ArrayBuffer:${Buffer.from(value).toString('base64')};`
        )
        return
      }
      if (ArrayBuffer.isView(value)) {
        emit(
          `B${identity}:${JSON.stringify(value.constructor.name)}:${Buffer.from(
            value.buffer,
            value.byteOffset,
            value.byteLength
          ).toString('base64')};`
        )
        return
      }
      if (value instanceof Date) {
        emit(`D${identity}:${value.toISOString()};`)
        return
      }
      if (value instanceof Map) {
        emit(`M${identity}[`)
        for (const [key, entry] of value.entries()) {
          emit('<')
          visit(key)
          emit('>')
          visit(entry)
        }
        emit('];')
        return
      }
      if (value instanceof Set) {
        emit(`S${identity}[`)
        for (const entry of value.values()) visit(entry)
        emit('];')
        return
      }

      const prototype = Object.getPrototypeOf(object) as object | null
      const plain =
        prototype === null ||
        prototype === Object.prototype ||
        prototype === Array.prototype
      const keys = Reflect.ownKeys(object)
        .map((key) => ({
          key,
          order:
            typeof key === 'string'
              ? `string:${key}`
              : `symbol:${String(key.description ?? '')}:${symbolIdentityOf(
                  key
                )}`,
        }))
        .sort((left, right) => compareCodePoint(left.order, right.order))
      const kind = Array.isArray(value)
        ? 'Array'
        : typeof value === 'function'
        ? 'Function'
        : value.constructor?.name ?? 'Object'
      emit(
        `O${identity}:${JSON.stringify(kind)}:${
          Object.isExtensible(object) ? 1 : 0
        }${Object.isSealed(object) ? 1 : 0}${Object.isFrozen(object) ? 1 : 0}:${
          prototype === null ? 'null' : identityOf(prototype)
        }[`
      )
      for (const { key, order } of keys) {
        const descriptor = Object.getOwnPropertyDescriptor(object, key)
        if (!descriptor) throw new TypeError(`missing descriptor: ${order}`)
        emit(
          `K${JSON.stringify(order)}:${descriptor.configurable ? 1 : 0}${
            descriptor.enumerable ? 1 : 0
          }`
        )
        if ('value' in descriptor) {
          emit(`=${descriptor.writable ? 1 : 0}:`)
          const recurse = plain || descriptor.enumerable
          if (recurse) {
            visit(descriptor.value)
          } else if (
            descriptor.value !== null &&
            (typeof descriptor.value === 'object' ||
              typeof descriptor.value === 'function')
          ) {
            const opaque = descriptor.value as {
              constructor?: { name?: string }
            }
            emit(
              `Q${identityOf(descriptor.value as object)}:${JSON.stringify(
                opaque.constructor?.name ?? typeof descriptor.value
              )};`
            )
          } else {
            emit(`P${primitiveSnapshot(descriptor.value)};`)
          }
        } else {
          emit(
            `A${
              descriptor.get === undefined
                ? 'null'
                : identityOf(descriptor.get as object)
            }:${
              descriptor.set === undefined
                ? 'null'
                : identityOf(descriptor.set as object)
            };`
          )
        }
      }
      emit('];')
    }

    visit(input)
    return `sha256:${hash.digest('hex')}`
  }

  return Object.freeze({ snapshot })
}
