import { canonicalSnapshot } from './canonical-text'
import { diagnostic, wrapKernelDiagnostics } from './diagnostics'
import { enumerateSelections } from './matrix'
import { type CompilerResult, failure, success } from './result'

import type {
  AuthorLogicalSourceLocator,
  ThemeAxisDeclarations,
  ThemeKernel,
  ThemeTypeMap,
  ValidatedResolvedThemeV1,
  ValidatedThemePublicContractV4,
  ValidatedThemeSourceV4,
} from '@zxio/tokens/kernel'

export interface KernelPort<M extends ThemeTypeMap> {
  readonly kernel: ThemeKernel<M>
  validateSource(
    source: unknown,
    sourceLocation: AuthorLogicalSourceLocator
  ): CompilerResult<ValidatedThemeSourceV4<M>>
  validateContract(
    contract: unknown,
    contractLocation: AuthorLogicalSourceLocator
  ): CompilerResult<ValidatedThemePublicContractV4<M>>
  resolveAll(
    input: Readonly<{
      source: ValidatedThemeSourceV4<M>
      contract: ValidatedThemePublicContractV4<M>
      sourceLocation: AuthorLogicalSourceLocator
      contractLocation: AuthorLogicalSourceLocator
    }>
  ): CompilerResult<readonly ValidatedResolvedThemeV1<M>[]>
  validateResolvedMatrix(
    input: Readonly<{
      resolved: readonly unknown[]
      declarations: ThemeAxisDeclarations
      sourceLocation: AuthorLogicalSourceLocator
    }>
  ): CompilerResult<readonly ValidatedResolvedThemeV1<M>[]>
}

function mutationDiagnostic(): ReturnType<typeof diagnostic> {
  return diagnostic({
    code: 'TC_INPUT_INVALID',
    phase: 'input',
    remediation: { code: 'DO_NOT_MUTATE_COMPILE_INPUT' },
    details: { issue: 'kernel-mutated-input' },
  })
}

export function createKernelPort<M extends ThemeTypeMap>(
  kernel: ThemeKernel<M>
): KernelPort<M> {
  const ownedCanonical = <T>(input: T): T =>
    JSON.parse(canonicalSnapshot(input)) as T
  const guard = <T>(
    input: unknown,
    run: () => CompilerResult<T>
  ): CompilerResult<T> => {
    let before: string
    try {
      before = canonicalSnapshot(input)
    } catch (error) {
      return failure([
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'input',
          remediation: { code: 'USE_CANONICAL_PLAIN_INPUT' },
          details: {
            issue: 'non-canonical-input',
            reason: error instanceof Error ? error.message : String(error),
          },
        }),
      ])
    }
    const result = run()
    return before === canonicalSnapshot(input)
      ? result
      : failure([mutationDiagnostic()])
  }

  return {
    kernel,
    validateSource(source, sourceLocation) {
      return guard({ source, sourceLocation }, () => {
        const owned = ownedCanonical({ source, sourceLocation })
        const result = kernel.validateThemeSource(owned)
        return result.ok
          ? success(result.value)
          : failure(
              wrapKernelDiagnostics(result.diagnostics, { phase: 'input' })
            )
      })
    },
    validateContract(contract, contractLocation) {
      return guard({ contract, contractLocation }, () => {
        const owned = ownedCanonical({ contract, contractLocation })
        const authorContract =
          owned.contract &&
          typeof owned.contract === 'object' &&
          !Array.isArray(owned.contract) &&
          'source' in owned.contract
            ? Object.fromEntries(
                Object.entries(owned.contract).filter(
                  ([key]) => key !== 'source'
                )
              )
            : owned.contract
        const result = kernel.validateThemeContract({
          contract: authorContract,
          contractLocation: owned.contractLocation,
        })
        return result.ok
          ? success(result.value)
          : failure(
              wrapKernelDiagnostics(result.diagnostics, { phase: 'input' })
            )
      })
    },
    resolveAll(input) {
      return guard(input, () => {
        const owned = ownedCanonical(input)
        const matrix = [] as ValidatedResolvedThemeV1<M>[]
        const diagnostics = []
        for (const selection of enumerateSelections(owned.source.axes)) {
          const result = kernel.resolveTheme({
            source: owned.source,
            sourceLocation: owned.sourceLocation,
            contract: owned.contract,
            contractLocation: owned.contractLocation,
            axes: selection,
          })
          if (result.ok) matrix.push(result.value)
          else
            diagnostics.push(
              ...wrapKernelDiagnostics(result.diagnostics, { phase: 'matrix' })
            )
        }
        return diagnostics.length > 0 ? failure(diagnostics) : success(matrix)
      })
    },
    validateResolvedMatrix(input) {
      return guard(input, () => {
        const owned = ownedCanonical(input)
        const output: ValidatedResolvedThemeV1<M>[] = []
        const diagnostics = []
        for (const entry of owned.resolved) {
          const result = kernel.validateResolvedTheme(
            entry,
            owned.sourceLocation
          )
          const hash = kernel.computeResolvedThemeHash(
            entry,
            owned.sourceLocation
          )
          if (result.ok && hash.ok && hash.value === result.value.contentHash) {
            output.push(result.value)
          } else {
            diagnostics.push(
              ...(!result.ok
                ? wrapKernelDiagnostics(result.diagnostics, {
                    phase: 'matrix',
                  })
                : []),
              ...(!hash.ok
                ? wrapKernelDiagnostics(hash.diagnostics, { phase: 'matrix' })
                : []),
              ...(result.ok &&
              hash.ok &&
              hash.value !== result.value.contentHash
                ? [
                    diagnostic({
                      code: 'TC_IDENTITY_MISMATCH',
                      phase: 'matrix',
                      source: owned.sourceLocation,
                      expected: result.value.contentHash,
                      actual: hash.value,
                      target: 'Kernel recomputed resolved content hash',
                      remediation: { code: 'RESTORE_RESOLVED_CONTENT_HASH' },
                      details: { identity: 'resolvedContentHash' },
                    }),
                  ]
                : [])
            )
          }
        }
        if (diagnostics.length > 0) return failure(diagnostics)
        const expected = enumerateSelections(owned.declarations)
        if (output.length !== expected.length) {
          return failure([
            diagnostic({
              code: 'TC_MATRIX_INCOMPLETE',
              phase: 'matrix',
              source: owned.sourceLocation,
              expected: expected.length,
              actual: output.length,
              details: {
                expectedCount: expected.length,
                actualCount: output.length,
              },
            }),
          ])
        }
        return success(output)
      })
    },
  }
}
