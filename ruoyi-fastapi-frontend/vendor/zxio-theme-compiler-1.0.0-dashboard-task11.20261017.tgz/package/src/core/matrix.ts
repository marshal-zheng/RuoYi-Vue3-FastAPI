import { canonicalJson, compareCodePoint } from './canonical-text'
import { diagnostic } from './diagnostics'
import { type CompilerResult, failure, success } from './result'
import { createThemeSelector } from './selector'
import { createVariantKey } from './variant-key'

import type {
  AuthorLogicalSourceLocator,
  AxisOrder,
  ResolvedThemeV1,
  ThemeAxisDeclarations,
  ThemeAxisName,
  ThemeAxisSelection,
} from '@zxio/tokens/kernel'

const AXIS_DOMAINS = {
  mode: ['light', 'dark'],
  density: ['compact', 'default', 'comfortable'],
  contrast: ['normal', 'high', 'forced-colors'],
  motion: ['full', 'reduced', 'none'],
  radius: ['sharp', 'default', 'rounded'],
} as const

export const APPLICATION_ORDER: AxisOrder = [
  'mode',
  'density',
  'contrast',
  'motion',
  'radius',
]

export interface MatrixVariant<M extends object = object> {
  readonly selection: ThemeAxisSelection
  readonly variantKey: string
  readonly selector: string
  readonly resolved: ResolvedThemeV1<M>
}

function isRecord(input: unknown): input is Readonly<Record<string, unknown>> {
  return !!input && typeof input === 'object' && !Array.isArray(input)
}

export function validateAxisDeclarations(
  input: unknown,
  source?: AuthorLogicalSourceLocator
): CompilerResult<ThemeAxisDeclarations> {
  const diagnostics = []
  if (!isRecord(input)) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'matrix',
        source,
        target: 'Kernel ThemeAxisDeclarations',
        remediation: { code: 'PASS_EXACT_AXIS_DECLARATIONS' },
        details: { issue: 'axes-not-object' },
      }),
    ])
  }
  const axisKeys = Object.keys(input).sort(compareCodePoint)
  const expectedAxisKeys = [...APPLICATION_ORDER].sort(compareCodePoint)
  if (canonicalJson(axisKeys) !== canonicalJson(expectedAxisKeys)) {
    diagnostics.push(
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'matrix',
        source,
        target: 'Kernel five-axis declaration set',
        expected: expectedAxisKeys,
        actual: axisKeys,
        remediation: { code: 'PASS_EXACT_AXIS_DECLARATIONS' },
        details: { issue: 'axis-owner-set-mismatch' },
      })
    )
  }
  const output: Record<string, unknown> = {}
  for (const axis of APPLICATION_ORDER) {
    const declaration = input[axis]
    const domain = AXIS_DOMAINS[axis]
    if (!isRecord(declaration)) {
      diagnostics.push(
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'matrix',
          source,
          jsonPath: `$.matrix.axes.${axis}`,
          target: `Kernel ${axis} declaration`,
          remediation: { code: 'PASS_EXACT_AXIS_DECLARATION' },
          details: { issue: 'axis-declaration-not-object', axis },
        })
      )
      continue
    }
    const keys = Object.keys(declaration).sort(compareCodePoint)
    const supported = declaration.supported
    const expectedKeys = ['default', 'supported']
    const validSupported =
      Array.isArray(supported) &&
      supported.length > 0 &&
      supported.every(
        (value) =>
          typeof value === 'string' &&
          (domain as readonly string[]).includes(value)
      ) &&
      new Set(supported).size === supported.length
    const canonicalSupported = validSupported
      ? domain.filter((value) => supported.includes(value))
      : []
    if (
      canonicalJson(keys) !== canonicalJson(expectedKeys) ||
      !validSupported ||
      canonicalJson(supported) !== canonicalJson(canonicalSupported) ||
      typeof declaration.default !== 'string' ||
      !canonicalSupported.includes(declaration.default as never)
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'matrix',
          source,
          jsonPath: `$.matrix.axes.${axis}`,
          target: `Kernel ${axis} supported/default declaration`,
          expected: {
            keys: expectedKeys,
            platformDomain: domain,
            canonicalSupported,
          },
          actual: {
            keys,
            supported: Array.isArray(supported) ? supported : null,
            default:
              typeof declaration.default === 'string'
                ? declaration.default
                : null,
          },
          remediation: { code: 'RESTORE_KERNEL_AXIS_FACTS' },
          details: { issue: 'invalid-axis-supported-or-default', axis },
        })
      )
      continue
    }
    output[axis] = {
      supported: canonicalSupported,
      default: declaration.default,
    }
  }
  return diagnostics.length > 0
    ? failure(diagnostics)
    : success(output as unknown as ThemeAxisDeclarations)
}

export function enumerateSelections(
  declarations: ThemeAxisDeclarations,
  applicationOrder: AxisOrder = APPLICATION_ORDER
): readonly ThemeAxisSelection[] {
  const output: ThemeAxisSelection[] = []
  const selection: Partial<Record<ThemeAxisName, string>> = {}
  const visit = (index: number): void => {
    if (index === applicationOrder.length) {
      output.push({ ...selection } as ThemeAxisSelection)
      return
    }
    const axis = applicationOrder[index]
    for (const value of declarations[axis].supported) {
      selection[axis] = value
      visit(index + 1)
    }
  }
  visit(0)
  return output
}

function identityOf<M extends object>(entry: ResolvedThemeV1<M>): string {
  return canonicalJson({
    themeId: entry.themeId,
    sourceSchemaVersion: entry.sourceSchemaVersion,
    resolvedSchemaVersion: entry.resolvedSchemaVersion,
    contractVersion: entry.contractVersion,
    sourceContentHash: entry.sourceContentHash,
    contractContentHash: entry.contractContentHash,
    typeRegistryContentHash: entry.typeRegistryContentHash,
    applicationOrder: entry.axes.applicationOrder,
  })
}

export function planResolvedMatrix<M extends object>(
  themeId: string,
  declarations: ThemeAxisDeclarations,
  resolved: readonly ResolvedThemeV1<M>[],
  source?: AuthorLogicalSourceLocator
): CompilerResult<readonly MatrixVariant<M>[]> {
  const expectedSelections = enumerateSelections(declarations)
  const expected = new Map(
    expectedSelections.map((selection) => [canonicalJson(selection), selection])
  )
  const actual = new Map<string, ResolvedThemeV1<M>[]>()
  for (const entry of resolved) {
    const key = canonicalJson(entry.axes.selection)
    const values = actual.get(key) ?? []
    values.push(entry)
    actual.set(key, values)
  }

  const missing = [...expected.keys()].filter((key) => !actual.has(key))
  const extra = [...actual.keys()].filter((key) => !expected.has(key))
  const duplicates = [...actual.entries()]
    .filter(([, entries]) => entries.length > 1)
    .map(([selection, entries]) => ({ selection, count: entries.length }))
  const diagnostics = []
  if (missing.length > 0 || extra.length > 0 || duplicates.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_MATRIX_INCOMPLETE',
        phase: 'matrix',
        source,
        remediation: { code: 'PROVIDE_EXACT_CARTESIAN_MATRIX' },
        details: { missing, extra, duplicates },
      })
    )
  }

  const referenceIdentity = resolved[0] ? identityOf(resolved[0]) : ''
  for (const entry of resolved) {
    const mismatches: string[] = []
    if (entry.themeId !== themeId) mismatches.push('themeId')
    if (
      canonicalJson(entry.axes.applicationOrder) !==
      canonicalJson(APPLICATION_ORDER)
    ) {
      mismatches.push('applicationOrder')
    }
    if (identityOf(entry) !== referenceIdentity) {
      mismatches.push('identity')
    }
    if (mismatches.length > 0) {
      diagnostics.push(
        diagnostic({
          code: 'TC_IDENTITY_MISMATCH',
          phase: 'matrix',
          source,
          remediation: { code: 'USE_ONE_VALIDATED_MATRIX_IDENTITY' },
          details: { selection: entry.axes.selection, mismatches },
        })
      )
    }
  }

  const variants: MatrixVariant<M>[] = []
  const keySources = new Map<string, ThemeAxisSelection[]>()
  const selectorSources = new Map<string, ThemeAxisSelection[]>()
  for (const selection of expectedSelections) {
    const entry = actual.get(canonicalJson(selection))?.[0]
    if (!entry) continue
    const key = createVariantKey(selection, APPLICATION_ORDER)
    const selector = createThemeSelector(themeId, selection, APPLICATION_ORDER)
    if (!key.ok) diagnostics.push(...key.diagnostics)
    if (!selector.ok) diagnostics.push(...selector.diagnostics)
    if (!key.ok || !selector.ok) continue
    keySources.set(key.value, [...(keySources.get(key.value) ?? []), selection])
    selectorSources.set(selector.value, [
      ...(selectorSources.get(selector.value) ?? []),
      selection,
    ])
    variants.push({
      selection,
      variantKey: key.value,
      selector: selector.value,
      resolved: entry,
    })
  }
  for (const [key, sources] of [...keySources, ...selectorSources]) {
    if (sources.length > 1) {
      diagnostics.push(
        diagnostic({
          code: 'TC_VARIANT_KEY_COLLISION',
          phase: 'matrix',
          source,
          target: key,
          remediation: { code: 'RESOLVE_VARIANT_IDENTITY_COLLISION' },
          details: { sources },
        })
      )
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  return success(variants)
}
