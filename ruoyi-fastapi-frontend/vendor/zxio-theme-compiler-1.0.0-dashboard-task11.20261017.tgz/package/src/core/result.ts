import { compareCodePoint, deepFreeze } from './canonical-text'

import type { ThemeCompilerDiagnostic } from './diagnostics'

export type CompilerResult<T> =
  | Readonly<{ ok: true; value: Readonly<T>; diagnostics: readonly [] }>
  | Readonly<{ ok: false; diagnostics: readonly ThemeCompilerDiagnostic[] }>

function diagnosticIdentity(value: ThemeCompilerDiagnostic): string {
  return [
    value.phase,
    value.code,
    value.source?.file ?? '',
    value.tokenPath ?? '',
    value.variantKey ?? '',
    value.artifactPath ?? '',
    value.jsonPath ?? '',
    value.target ?? '',
  ].join('\u0000')
}

export function success<T>(value: T): CompilerResult<T> {
  return deepFreeze({ ok: true as const, value, diagnostics: [] as const })
}

export function failure<T = never>(
  diagnostics: readonly ThemeCompilerDiagnostic[]
): CompilerResult<T> {
  const sorted = [...diagnostics].sort((left, right) =>
    compareCodePoint(diagnosticIdentity(left), diagnosticIdentity(right))
  )
  return deepFreeze({ ok: false as const, diagnostics: sorted })
}

export function mapResult<Input, Output>(
  result: CompilerResult<Input>,
  mapper: (value: Readonly<Input>) => Output
): CompilerResult<Output> {
  return result.ok ? success(mapper(result.value)) : result
}
