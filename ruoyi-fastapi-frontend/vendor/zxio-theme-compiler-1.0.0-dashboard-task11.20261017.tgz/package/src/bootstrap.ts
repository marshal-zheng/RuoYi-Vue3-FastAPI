import { createHash } from 'node:crypto'
import postcss from 'postcss'
import selectorParser from 'postcss-selector-parser'

export interface ThemeBootstrapCssInput {
  readonly text: string
  readonly sha256: string
  readonly themeId: string
  readonly variantKey?: string
  readonly scopeIds: readonly string[]
}

export interface ThemeBootstrapProfile {
  readonly schema: 'zx.theme-bootstrap/1'
  readonly id: string
  readonly css: string
  readonly sha256: string
  readonly integrity: string
  readonly byteLength: number
  readonly sources: readonly string[]
}

const safeKey = /^[a-z0-9](?:[a-z0-9._:-]{0,126}[a-z0-9])?$/
const hashPattern = /^sha256:[a-f0-9]{64}$/

function invalid(reason: string): never {
  throw new Error(`TC_BOOTSTRAP_INVALID: ${reason}`)
}

/**
 * `:not(:where(.el-x--y, .el-x.is-z))`: the exclusion set that keeps a
 * component-root alias off the modifier and state selectors where Element Plus
 * declares the same property with a different role. `:where` holds the set at
 * zero specificity, so the scoped selector stays one class.
 */
function isExclusionSet(node: selectorParser.Node): boolean {
  if (
    node.type !== 'pseudo' ||
    node.value !== ':not' ||
    node.nodes.length !== 1
  )
    return false
  const inner = node.nodes[0]!.nodes
  const scoped = inner[0]
  if (
    inner.length !== 1 ||
    scoped?.type !== 'pseudo' ||
    scoped.value !== ':where' ||
    scoped.nodes.length === 0
  )
    return false
  return scoped.nodes.every(
    (selector) =>
      selector.nodes.length > 0 &&
      selector.nodes.every(
        (part) =>
          part.type === 'class' && /^(?:el|is)-[a-z0-9_-]+$/.test(part.value)
      )
  )
}

/**
 * Scope already resolved public CSS plans. The host's existing selection
 * resolver owns axis inheritance; this compiler only verifies and transforms
 * CSS, so the compiler never depends on the UI runtime.
 */
export function compileThemeBootstrap(input: {
  readonly id: string
  readonly assets: readonly ThemeBootstrapCssInput[]
}): ThemeBootstrapProfile {
  if (
    !input ||
    !safeKey.test(input.id) ||
    !Array.isArray(input.assets) ||
    !input.assets.length
  )
    invalid('profile-input')
  const output = postcss.root()
  const sources = new Set<string>()
  for (const asset of input.assets) {
    if (
      typeof asset.text !== 'string' ||
      !hashPattern.test(asset.sha256) ||
      `sha256:${createHash('sha256').update(asset.text).digest('hex')}` !==
        asset.sha256 ||
      !safeKey.test(asset.themeId) ||
      (asset.variantKey !== undefined && !safeKey.test(asset.variantKey)) ||
      !Array.isArray(asset.scopeIds) ||
      !asset.scopeIds.length ||
      !asset.scopeIds.every(
        (id: unknown) => typeof id === 'string' && safeKey.test(id)
      ) ||
      /<\/style/i.test(asset.text)
    )
      invalid('asset-identity-or-content')
    sources.add(asset.sha256)
    const ast = postcss.parse(asset.text)
    ast.walkAtRules((rule) => {
      if (!['media', 'supports', 'layer'].includes(rule.name) || !rule.nodes)
        invalid('unsupported-at-rule')
    })
    ast.walkRules((rule) => {
      const parsed = selectorParser().astSync(rule.selector)
      if (parsed.nodes.length !== 1) invalid('selector-list')
      const nodes = parsed.nodes[0]!.nodes
      const where = nodes[0]
      if (
        where?.type !== 'pseudo' ||
        where.value !== ':where' ||
        where.nodes?.length !== 1
      )
        invalid('selector-shape')
      // Element Plus root aliases carry an extra attribute to match :root's
      // specificity. A bootstrap scope is already an attribute selector, so
      // remove that guard when rewriting the verified theme identity.
      const suffix = nodes.slice(1)
      const specificityGuard = suffix[0]
      if (
        specificityGuard?.type === 'attribute' &&
        specificityGuard.attribute === 'data-zx-theme' &&
        specificityGuard.operator === undefined
      )
        suffix.shift()
      if (suffix.length) {
        const parts = suffix.slice(1)
        const exclusion =
          parts.at(-1)?.type === 'pseudo' ? parts.pop() : undefined
        if (
          asset.variantKey !== undefined ||
          suffix[0]?.type !== 'combinator' ||
          suffix[0].value !== ' ' ||
          parts.length < 1 ||
          parts.length > 3 ||
          parts.some(
            (part, index) =>
              part.type !== 'class' ||
              !(
                index === 0 ? /^el-[a-z0-9_-]+$/ : /^(?:el|is)-[a-z0-9_-]+$/
              ).test(part.value)
          ) ||
          (exclusion !== undefined && !isExclusionSet(exclusion))
        )
          invalid('selector-suffix')
      }
      const attributes = where.nodes[0]!.nodes
      const expected = [
        ['data-zx-theme', asset.themeId],
        ...(asset.variantKey ? [['data-zx-variant', asset.variantKey]] : []),
      ]
      if (
        attributes.length !== expected.length ||
        attributes.some(
          (node, index) =>
            node.type !== 'attribute' ||
            node.attribute !== expected[index]![0] ||
            node.operator !== '=' ||
            node.value !== expected[index]![1]
        )
      )
        invalid('selector-identity')
      if (
        rule.nodes.some(
          (node) => node.type !== 'decl' && node.type !== 'comment'
        )
      )
        invalid('nested-rule')
      rule.walkDecls((declaration) => {
        if (!declaration.prop.startsWith('--') || declaration.important)
          invalid('non-token-declaration')
      })
      const selectors = [...new Set(asset.scopeIds)].map(
        (id) =>
          `[data-zx-scope="${id}"]${suffix
            .map((node) => node.toString())
            .join('')}`
      )
      rule.selector = selectors.join(',')
    })
    output.append(ast.nodes)
  }
  // Merge only adjacent equal bodies. Moving equal blocks across intervening
  // declarations could change the cascade for an overlapping scope.
  for (const node of [...output.nodes]) {
    if (node.type !== 'rule') continue
    const previous = node.prev()
    if (previous?.type !== 'rule') continue
    if (
      previous.nodes.map((item) => item.toString()).join(';') !==
      node.nodes.map((item) => item.toString()).join(';')
    )
      continue
    previous.selector = [
      ...new Set([
        ...previous.selector.split(','),
        ...node.selector.split(','),
      ]),
    ].join(',')
    node.remove()
  }
  const css = output.toString()
  const digest = createHash('sha256').update(css).digest()
  return Object.freeze({
    schema: 'zx.theme-bootstrap/1',
    id: input.id,
    css,
    sha256: `sha256:${digest.toString('hex')}`,
    integrity: `sha256-${digest.toString('base64')}`,
    byteLength: Buffer.byteLength(css),
    sources: Object.freeze([...sources].sort()),
  })
}
