import { existsSync, realpathSync, statSync } from 'node:fs'
import { extname, isAbsolute, relative, resolve, sep } from 'node:path'

export interface ThemeAssetRequest {
  readonly url: string
  readonly base: string
  readonly outputDir: string
  readonly assetDirectory: string
}

/** Resolve ordinary public theme files before Vite's CSS transform middleware. */
export function resolveThemeAssetRequest(input: ThemeAssetRequest): {
  readonly file: string
  readonly contentType: string
} | null {
  let pathname: string
  let base: string
  try {
    pathname = decodeURIComponent(
      new URL(input.url, 'http://vite.local').pathname
    )
    base = new URL(input.base, 'http://vite.local').pathname.replace(/\/$/, '')
  } catch {
    return null
  }
  const prefix = `${base}/${input.assetDirectory}/`
  if (!pathname.startsWith(prefix)) return null
  const file = resolve(input.outputDir, pathname.slice(prefix.length))
  const inside = (root: string, target: string) => {
    const part = relative(root, target)
    return (
      part && part !== '..' && !part.startsWith(`..${sep}`) && !isAbsolute(part)
    )
  }
  if (
    !inside(input.outputDir, file) ||
    !existsSync(file) ||
    !statSync(file).isFile()
  )
    return null
  if (!inside(realpathSync(input.outputDir), realpathSync(file))) return null
  const extension = extname(file)
  if (extension !== '.css' && extension !== '.json') return null
  // The emitter's ownership inventory is private build metadata.
  if (
    pathname
      .slice(prefix.length)
      .split('/')
      .some((part) => part.startsWith('.'))
  )
    return null
  return {
    file,
    contentType: extension === '.css' ? 'text/css' : 'application/json',
  }
}
