import { TextDecoder } from 'node:util'
import { canonicalize, sha256 } from '../core/canonical-text'
import { diagnostic } from '../core/diagnostics'
import { failure, success } from '../core/result'
import { validateThemeManifest } from '../targets/manifest/validator'
import { themeCssExports } from './css-exports'

import type { ThemeCompilerDiagnosticCode } from '../core/diagnostics'
import type { CompilerResult } from '../core/result'
import type { ThemeDeploymentIdentity, ThemeDeploymentMapV1 } from './emitter'
import type {
  ManifestArtifact,
  ManifestPublicToken,
  ManifestVariant,
  ThemeManifestV1,
} from '../targets/manifest/model'

export interface ThemeRuntimeCssArtifact
  extends Omit<ManifestArtifact, 'mediaType' | 'purpose' | 'loadPhase'> {
  readonly mediaType: 'text/css'
  readonly purpose:
    | 'core-css'
    | 'aggregate-css'
    | 'element-plus-alias'
    | 'element-plus-resolved'
  readonly loadPhase: 'theme' | 'variant'
}

export interface ThemeRuntimeVariant
  extends Omit<ManifestVariant, 'artifacts'> {
  readonly artifacts: Pick<
    ManifestVariant['artifacts'],
    'coreCss' | 'elementPlusResolvedCss'
  >
}

export interface ThemeRuntimePublicToken
  extends Pick<
    ManifestPublicToken,
    'path' | 'typeId' | 'lifecycle' | 'css' | 'deprecated'
  > {
  readonly adapters: Pick<ManifestPublicToken['adapters'], 'elementPlus'>
}

export interface ThemeRuntimePayloadV1
  extends Pick<
    ThemeManifestV1,
    | 'variantKeySchema'
    | 'selectorSchema'
    | 'identity'
    | 'axes'
    | 'displayContract'
  > {
  readonly schema: 'zx.theme-runtime-payload/1'
  readonly sourceManifestSha256: `sha256:${string}`
  readonly publicSurface: readonly ThemeRuntimePublicToken[]
  readonly variants: readonly ThemeRuntimeVariant[]
  readonly artifacts: readonly ThemeRuntimeCssArtifact[]
}

export interface ThemeRuntimeDeploymentOutput {
  readonly schema: 'zx.theme-runtime-deployment/1'
  readonly deployment: ThemeDeploymentMapV1
  readonly registrations: readonly Readonly<{
    runtime: ThemeRuntimePayloadV1
  }>[]
}

export interface CreateThemeRuntimeDeploymentOptions {
  readonly deployment: ThemeDeploymentMapV1
  readonly manifestSources: readonly Uint8Array[]
}

const HASH = /^sha256:[a-f0-9]{64}$/
const identityKeys = [
  'packageName',
  'packageVersion',
  'themeId',
  'contractVersion',
  'sourceContentHash',
  'contractContentHash',
  'typeRegistryContentHash',
] as const

class ProjectionError extends Error {
  constructor(
    readonly reason: string,
    readonly jsonPath: string,
    readonly code: ThemeCompilerDiagnosticCode
  ) {
    super(reason)
    this.name = 'ProjectionError'
  }
}

function invalid(
  reason: string,
  jsonPath = '$',
  code: ThemeCompilerDiagnosticCode = 'TC_INPUT_INVALID'
): never {
  throw new ProjectionError(reason, jsonPath, code)
}

function record(input: unknown): input is Record<string, unknown> {
  return Boolean(
    input &&
      typeof input === 'object' &&
      !Array.isArray(input) &&
      (Object.getPrototypeOf(input) === Object.prototype ||
        Object.getPrototypeOf(input) === null) &&
      Object.values(Object.getOwnPropertyDescriptors(input)).every(
        (descriptor) => 'value' in descriptor
      )
  )
}

function exact(
  input: Record<string, unknown>,
  keys: readonly string[]
): boolean {
  return (
    Reflect.ownKeys(input).length === keys.length &&
    keys.every((key) => Object.prototype.hasOwnProperty.call(input, key))
  )
}

function owner(
  identity: Pick<ThemeDeploymentIdentity, 'packageName' | 'packageVersion'>
): string {
  return `${identity.packageName}|${identity.packageVersion}`
}

function validAssetPath(input: string): boolean {
  // eslint-disable-next-line no-control-regex -- Asset text must reject control characters before URL parsing.
  if (/[\\\u0000-\u0020\u007F]/.test(input) || input.startsWith('//'))
    return false
  try {
    for (const segment of input.split('/')) {
      const decoded = decodeURIComponent(segment)
      if (
        decoded === '.' ||
        decoded === '..' ||
        decoded.includes('/') ||
        decoded.includes('\\') ||
        // eslint-disable-next-line no-control-regex -- Encoded segments require the same control-character rejection.
        /[\u0000-\u0020\u007F]/.test(decoded) ||
        decodeURIComponent(decoded) !== decoded
      )
        return false
    }
    const url = new URL(input, 'https://theme-deployment.invalid/')
    return (
      ['http:', 'https:'].includes(url.protocol) &&
      !url.username &&
      !url.password &&
      !url.search &&
      !url.hash
    )
  } catch {
    return false
  }
}

function deploymentSnapshot(input: unknown): ThemeDeploymentMapV1 {
  // Validate original keys before canonicalization can omit undefined fields.
  const value = input
  if (
    !record(value) ||
    !exact(value, ['schema', 'manifests', 'entries']) ||
    value.schema !== 'zx.theme-deployment/1' ||
    !Array.isArray(value.manifests) ||
    !value.manifests.length ||
    !Array.isArray(value.entries) ||
    !value.entries.length
  )
    invalid('runtime-deployment-schema-invalid', '$.deployment')
  const owners = new Set<string>()
  const themeIds = new Set<string>()
  for (const [index, row] of value.manifests.entries()) {
    const path = `$.deployment.manifests[${index}]`
    if (
      !record(row) ||
      !exact(row, ['identity', 'manifestSha256']) ||
      !record(row.identity) ||
      !exact(row.identity, identityKeys) ||
      typeof row.manifestSha256 !== 'string' ||
      !HASH.test(row.manifestSha256)
    )
      invalid('runtime-deployment-manifest-invalid', path)
    const identity = row.identity
    if (!identityKeys.every((key) => typeof identity[key] === 'string'))
      invalid('runtime-deployment-manifest-invalid', path)
    const key = `${row.identity.packageName}|${row.identity.packageVersion}`
    if (owners.has(key) || themeIds.has(String(row.identity.themeId)))
      invalid(
        'runtime-deployment-identity-duplicate',
        path,
        'TC_IDENTITY_MISMATCH'
      )
    owners.add(key)
    themeIds.add(String(row.identity.themeId))
  }
  const tuples = new Set<string>()
  for (const [index, entry] of value.entries.entries()) {
    const path = `$.deployment.entries[${index}]`
    if (
      !record(entry) ||
      !exact(entry, [
        'packageName',
        'packageVersion',
        'exportPath',
        'sha256',
        'assetPath',
        'integrity',
        'byteLength',
      ]) ||
      typeof entry.packageName !== 'string' ||
      typeof entry.packageVersion !== 'string' ||
      !owners.has(`${entry.packageName}|${entry.packageVersion}`) ||
      typeof entry.exportPath !== 'string' ||
      !/^\.\/[a-z0-9][a-z0-9._/-]*$/.test(entry.exportPath) ||
      !validAssetPath(entry.exportPath.slice(2)) ||
      typeof entry.sha256 !== 'string' ||
      !HASH.test(entry.sha256) ||
      typeof entry.assetPath !== 'string' ||
      !entry.assetPath ||
      !validAssetPath(entry.assetPath) ||
      entry.integrity !==
        `sha256-${Buffer.from(entry.sha256.slice(7), 'hex').toString(
          'base64'
        )}` ||
      !Number.isSafeInteger(entry.byteLength) ||
      Number(entry.byteLength) < 0
    )
      invalid('runtime-deployment-entry-invalid', path)
    const key = `${entry.packageName}|${entry.packageVersion}|${entry.exportPath}`
    if (tuples.has(key))
      invalid(
        'runtime-deployment-entry-duplicate',
        path,
        'TC_ARTIFACT_DUPLICATE'
      )
    tuples.add(key)
  }
  // All identity values are compared with fully validated source identities below.
  return canonicalize(value) as unknown as ThemeDeploymentMapV1
}

function cssArtifacts(manifest: ThemeManifestV1): ThemeRuntimeCssArtifact[] {
  return manifest.artifacts.filter(
    (artifact): artifact is ThemeRuntimeCssArtifact =>
      artifact.mediaType === 'text/css'
  )
}

function checkCssDeployment(
  manifest: ThemeManifestV1,
  deployment: ThemeDeploymentMapV1
): void {
  const expected = themeCssExports(manifest)
  const artifacts = cssArtifacts(manifest)
  const entries = deployment.entries.filter(
    (entry) => owner(entry) === owner(manifest.identity)
  )
  if (entries.length !== artifacts.length)
    invalid('runtime-deployment-css-set-mismatch', '$.deployment.entries')
  const byExport = new Map(entries.map((entry) => [entry.exportPath, entry]))
  for (const artifact of artifacts) {
    const entry = byExport.get(expected.get(artifact.path)!)
    if (
      !entry ||
      entry.sha256 !== artifact.sha256 ||
      entry.byteLength !== artifact.bytes
    )
      invalid(
        'runtime-deployment-css-mismatch',
        '$.deployment.entries',
        'TC_ARTIFACT_HASH_MISMATCH'
      )
  }
}

function projectManifest(
  manifest: ThemeManifestV1,
  sourceManifestSha256: `sha256:${string}`
): ThemeRuntimePayloadV1 {
  return {
    schema: 'zx.theme-runtime-payload/1',
    variantKeySchema: manifest.variantKeySchema,
    selectorSchema: manifest.selectorSchema,
    sourceManifestSha256,
    identity: manifest.identity,
    axes: manifest.axes,
    ...(manifest.displayContract === undefined
      ? {}
      : { displayContract: manifest.displayContract }),
    publicSurface: manifest.publicSurface.map(
      ({ path, typeId, lifecycle, css, deprecated, adapters }) => ({
        path,
        typeId,
        lifecycle,
        css,
        ...(deprecated === undefined ? {} : { deprecated }),
        adapters: { elementPlus: adapters.elementPlus },
      })
    ),
    variants: manifest.variants.map(({ artifacts, ...variant }) => ({
      ...variant,
      artifacts: {
        coreCss: artifacts.coreCss,
        elementPlusResolvedCss: artifacts.elementPlusResolvedCss,
      },
    })),
    artifacts: cssArtifacts(manifest),
  }
}

/** Derive runtime data only after validating original public file bytes and deployment. */
export function createThemeRuntimeDeployment(
  options: CreateThemeRuntimeDeploymentOptions
): CompilerResult<ThemeRuntimeDeploymentOutput> {
  try {
    if (
      !record(options) ||
      !exact(options, ['deployment', 'manifestSources']) ||
      !Array.isArray(options.manifestSources) ||
      !options.manifestSources.length ||
      !options.manifestSources.every((source) => source instanceof Uint8Array)
    )
      invalid('runtime-projection-options-invalid')
    const sources = options.manifestSources.map(
      (source) => new Uint8Array(source)
    )
    const deployment = deploymentSnapshot(options.deployment)
    if (sources.length !== deployment.manifests.length)
      invalid('runtime-manifest-source-set-mismatch', '$.manifestSources')
    const manifests = new Map<string, ThemeRuntimePayloadV1>()
    for (const [index, source] of sources.entries()) {
      let raw: unknown
      try {
        raw = JSON.parse(
          new TextDecoder('utf-8', { fatal: true }).decode(source)
        )
      } catch {
        invalid(
          'runtime-manifest-source-encoding-invalid',
          `$.manifestSources[${index}]`,
          'TC_MANIFEST_INVALID'
        )
      }
      const checked = validateThemeManifest(raw)
      if (!checked.ok) return checked
      const manifest = checked.value
      const key = owner(manifest.identity)
      if (manifests.has(key))
        invalid(
          'runtime-manifest-source-duplicate',
          `$.manifestSources[${index}]`,
          'TC_IDENTITY_MISMATCH'
        )
      const row = deployment.manifests.find(
        (item) => owner(item.identity) === key
      )
      if (
        !row ||
        !identityKeys.every(
          (field) => row.identity[field] === manifest.identity[field]
        )
      )
        invalid(
          'runtime-manifest-deployment-identity-mismatch',
          `$.manifestSources[${index}]`,
          'TC_IDENTITY_MISMATCH'
        )
      const digest = sha256(source)
      if (digest !== row.manifestSha256)
        invalid(
          'runtime-manifest-source-sha-mismatch',
          `$.manifestSources[${index}]`,
          'TC_ARTIFACT_HASH_MISMATCH'
        )
      checkCssDeployment(manifest, deployment)
      manifests.set(key, projectManifest(manifest, digest))
    }
    return success({
      schema: 'zx.theme-runtime-deployment/1',
      deployment,
      registrations: deployment.manifests.map(({ identity }) => ({
        runtime: manifests.get(owner(identity))!,
      })),
    })
  } catch (error) {
    return failure([
      diagnostic({
        code:
          error instanceof ProjectionError ? error.code : 'TC_INPUT_INVALID',
        phase: 'manifest',
        jsonPath: error instanceof ProjectionError ? error.jsonPath : '$',
        target: 'theme runtime deployment',
        details: {
          reason:
            error instanceof ProjectionError
              ? error.reason
              : 'runtime-projection-input-invalid',
        },
        remediation: { code: 'CHECK_THEME_RUNTIME_DEPLOYMENT_INPUTS' },
      }),
    ])
  }
}
