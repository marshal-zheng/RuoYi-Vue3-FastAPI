import { createHash } from 'node:crypto'
import {
  existsSync,
  lstatSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  readdirSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'node:fs'
import { createRequire } from 'node:module'
import {
  basename,
  dirname,
  isAbsolute,
  relative,
  resolve,
  sep,
} from 'node:path'
import { canonicalJson, compareCodePoint } from '../core/canonical-text'
import { diagnostic } from '../core/diagnostics'
import { failure, success } from '../core/result'
import { validateThemeManifest } from '../targets/manifest/validator'
import { themeCssExports } from './css-exports'

import type { ThemeCompilerDiagnosticCode } from '../core/diagnostics'
import type { CompilerResult } from '../core/result'
import type { ThemeManifestV1 } from '../targets/manifest/model'

export type ThemeDeploymentIdentity = Readonly<
  Pick<
    ThemeManifestV1['identity'],
    | 'packageName'
    | 'packageVersion'
    | 'themeId'
    | 'contractVersion'
    | 'sourceContentHash'
    | 'contractContentHash'
    | 'typeRegistryContentHash'
  >
>

export interface ThemeDeploymentEntry {
  readonly packageName: string
  readonly packageVersion: string
  readonly exportPath: string
  readonly sha256: `sha256:${string}`
  readonly assetPath: string
  readonly integrity: string
  readonly byteLength: number
}

export interface ThemeDeploymentMapV1 {
  readonly schema: 'zx.theme-deployment/1'
  readonly manifests: readonly Readonly<{
    identity: ThemeDeploymentIdentity
    manifestSha256: `sha256:${string}`
  }>[]
  readonly entries: readonly ThemeDeploymentEntry[]
}

export interface EmitThemeDeploymentOptions {
  /** Installed packages; only public manifest.json/package.json/CSS exports are read. */
  readonly packages: readonly string[]
  /** A dedicated directory owned exclusively by this emitter. */
  readonly outputDir: string
  /** Directory relative to the application base, or an explicitly configured CDN URL. */
  readonly assetBasePath: string
  /** Package resolution anchor; defaults to the calling application's package.json. */
  readonly resolveFrom?: string
}

export interface ThemeDeploymentOutput {
  readonly deployment: ThemeDeploymentMapV1
  readonly registrations: readonly Readonly<{ manifest: ThemeManifestV1 }>[]
}

const OWNER_FILE = '.zx-theme-deployment-owner.json'
const OWNER_SCHEMA = 'zx.theme-deployment-owner/1'
const PACKAGE = /^@[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]*$/
const SEGMENT = /^[a-zA-Z0-9_-][a-zA-Z0-9._-]*$/

class DeploymentError extends Error {
  constructor(readonly code: ThemeCompilerDiagnosticCode, reason: string) {
    super(reason)
    this.name = 'DeploymentError'
  }
}
function invalid(
  reason: string,
  code: ThemeCompilerDiagnosticCode = 'TC_INPUT_INVALID'
): never {
  throw new DeploymentError(code, reason)
}
function hash(bytes: Buffer): `sha256:${string}` {
  return `sha256:${createHash('sha256').update(bytes).digest('hex')}`
}
function inside(root: string, path: string): boolean {
  const part = relative(root, path)
  return part !== '..' && !part.startsWith(`..${sep}`) && !isAbsolute(part)
}
function record(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value))
}
function safeSegments(path: string): boolean {
  return path
    .split('/')
    .every((part) => SEGMENT.test(part) && part !== '.' && part !== '..')
}
function assetBase(input: string): string {
  if (/^https?:\/\//.test(input)) {
    const url = new URL(input)
    const path = input
      .slice(input.indexOf('://') + 3)
      .replace(/^[^/]+/, '')
      .replace(/^\//, '')
      .replace(/\/$/, '')
    if (
      url.username ||
      url.password ||
      url.search ||
      url.hash ||
      (path && !safeSegments(path))
    )
      invalid('asset-base-invalid')
    return `${url.href.replace(/\/$/, '')}/`
  }
  const path = input.replace(/\/$/, '')
  if (!safeSegments(path)) invalid('asset-base-invalid')
  return `${path}/`
}

/** Resolve the export map, without treating a private on-disk path as a fallback. */
function publicCssExport(
  exports: unknown,
  packageRoot: string,
  artifactPath: string
): string {
  if (!record(exports)) invalid('package-exports-missing')
  const matches: string[] = []
  for (const [key, value] of Object.entries(exports)) {
    if (
      !key.startsWith('./') ||
      typeof value !== 'string' ||
      !value.startsWith('./')
    )
      continue
    if (key.split('*').length > 2 || value.split('*').length > 2) continue
    if (!key.includes('*') && !value.includes('*')) {
      if (resolve(packageRoot, value) === artifactPath) matches.push(key)
      continue
    }
    if (!key.includes('*') || !value.includes('*')) continue
    const target = resolve(packageRoot, value)
    const [prefix, suffix] = target.split('*') as [string, string]
    if (!artifactPath.startsWith(prefix) || !artifactPath.endsWith(suffix))
      continue
    const wildcard = artifactPath.slice(
      prefix.length,
      artifactPath.length - suffix.length || undefined
    )
    if (wildcard && safeSegments(wildcard))
      matches.push(key.replace('*', wildcard))
  }
  if (matches.length !== 1) invalid('css-export-missing-or-ambiguous')
  const match = matches[0]!
  if (!safeSegments(match.slice(2)))
    invalid('css-export-path-invalid', 'TC_ARTIFACT_PATH_INVALID')
  return match
}

function rejectSymlinkAncestors(path: string): void {
  // Resolve the nearest existing ancestor once. This checks the entire path
  // without reading unrelated parent directories outside a restricted consumer.
  let ancestor = path
  while (!existsSync(ancestor)) {
    const parent = dirname(ancestor)
    if (parent === ancestor)
      invalid('output-parent-missing', 'TC_WRITE_OUTSIDE_ROOT')
    ancestor = parent
  }
  if (
    lstatSync(ancestor).isSymbolicLink() ||
    realpathSync(ancestor) !== ancestor
  ) {
    invalid('output-symlink', 'TC_WRITE_SYMLINK_ESCAPE')
  }
}

function verifyOwnedDirectory(output: string): void {
  if (!existsSync(output)) return
  if (
    !lstatSync(output).isDirectory() ||
    !existsSync(resolve(output, OWNER_FILE))
  )
    invalid('output-not-owned', 'TC_WRITE_COMMIT_FAILED')
  const markerPath = resolve(output, OWNER_FILE)
  if (!lstatSync(markerPath).isFile() || lstatSync(markerPath).isSymbolicLink())
    invalid('owner-marker-invalid', 'TC_WRITE_COMMIT_FAILED')
  const marker: unknown = JSON.parse(readFileSync(markerPath, 'utf8'))
  if (
    !record(marker) ||
    marker.schema !== OWNER_SCHEMA ||
    !record(marker.files)
  )
    invalid('owner-marker-invalid', 'TC_WRITE_COMMIT_FAILED')
  const files = marker.files
  const actual = readdirSync(output).sort(compareCodePoint)
  const expected = [...Object.keys(files), OWNER_FILE].sort(compareCodePoint)
  if (JSON.stringify(actual) !== JSON.stringify(expected))
    invalid('output-has-foreign-files', 'TC_WRITE_COMMIT_FAILED')
  for (const [name, digest] of Object.entries(files)) {
    if (
      name === OWNER_FILE ||
      !SEGMENT.test(name) ||
      !/^sha256:[a-f0-9]{64}$/.test(String(digest))
    )
      invalid('owner-inventory-invalid', 'TC_WRITE_COMMIT_FAILED')
    const file = resolve(output, name)
    const stat = lstatSync(file)
    if (
      !stat.isFile() ||
      stat.isSymbolicLink() ||
      hash(readFileSync(file)) !== digest
    )
      invalid('owned-output-modified', 'TC_WRITE_COMMIT_FAILED')
  }
}

function writeOwnedDirectory(
  output: string,
  files: ReadonlyMap<string, Buffer>
): void {
  rejectSymlinkAncestors(output)
  mkdirSync(dirname(output), { recursive: true })
  const lock = `${output}.lock`
  try {
    mkdirSync(lock)
  } catch {
    invalid('output-locked', 'TC_WRITE_COMMIT_FAILED')
  }
  let staging: string | undefined
  let backup: string | undefined
  try {
    verifyOwnedDirectory(output)
    staging = mkdtempSync(
      resolve(dirname(output), `.${basename(output)}-stage-`)
    )
    const inventory: Record<string, string> = {}
    for (const [name, bytes] of files) {
      if (!SEGMENT.test(name) || name === OWNER_FILE)
        invalid('output-file-invalid', 'TC_ARTIFACT_PATH_INVALID')
      writeFileSync(resolve(staging, name), bytes, { flag: 'wx' })
      inventory[name] = hash(bytes)
    }
    writeFileSync(
      resolve(staging, OWNER_FILE),
      canonicalJson({ schema: OWNER_SCHEMA, files: inventory })
    )
    verifyOwnedDirectory(staging)
    // Recheck before replacing: an external write during staging must not be lost.
    verifyOwnedDirectory(output)
    if (existsSync(output)) {
      backup = `${staging}-previous`
      renameSync(output, backup)
    }
    try {
      renameSync(staging, output)
    } catch (error) {
      if (backup) {
        renameSync(backup, output)
        backup = undefined
      }
      throw error
    }
    staging = undefined
    if (backup) {
      rmSync(backup, { recursive: true })
      backup = undefined
    }
  } finally {
    if (staging) rmSync(staging, { recursive: true, force: true })
    // A failed rollback deliberately retains the previous directory for recovery.
    rmSync(lock, { recursive: true, force: true })
  }
}

export function emitThemeDeployment(
  options: EmitThemeDeploymentOptions
): CompilerResult<ThemeDeploymentOutput> {
  try {
    if (
      !record(options) ||
      !Array.isArray(options.packages) ||
      !options.packages.length ||
      !options.packages.every(
        (name) => typeof name === 'string' && PACKAGE.test(name)
      ) ||
      new Set(options.packages).size !== options.packages.length ||
      typeof options.outputDir !== 'string' ||
      !options.outputDir ||
      typeof options.assetBasePath !== 'string' ||
      (options.resolveFrom !== undefined &&
        typeof options.resolveFrom !== 'string')
    )
      invalid('deployment-options-invalid')
    const output = resolve(options.outputDir)
    if (output === dirname(output))
      invalid('output-root-forbidden', 'TC_WRITE_OUTSIDE_ROOT')
    const base = assetBase(options.assetBasePath)
    const fromApplication = createRequire(
      resolve(options.resolveFrom ?? resolve(process.cwd(), 'package.json'))
    )
    const files = new Map<string, Buffer>()
    const entries: ThemeDeploymentEntry[] = []
    const manifests: ThemeDeploymentMapV1['manifests'][number][] = []
    const registrations: { manifest: ThemeManifestV1 }[] = []
    const themeIds = new Set<string>()
    const publicTuples = new Set<string>()
    for (const packageName of [...options.packages].sort(compareCodePoint)) {
      const metadataPath = fromApplication.resolve(
        `${packageName}/package.json`
      )
      const packageRoot = dirname(metadataPath)
      if (inside(output, packageRoot) || inside(packageRoot, output))
        invalid('output-overlaps-package', 'TC_WRITE_OUTSIDE_ROOT')
      const metadata: unknown = JSON.parse(readFileSync(metadataPath, 'utf8'))
      if (
        !record(metadata) ||
        metadata.name !== packageName ||
        typeof metadata.version !== 'string'
      )
        invalid('package-identity-invalid', 'TC_IDENTITY_MISMATCH')
      const manifestPath = fromApplication.resolve(
        `${packageName}/manifest.json`
      )
      if (!inside(packageRoot, manifestPath))
        invalid('manifest-outside-package', 'TC_ARTIFACT_PATH_INVALID')
      const manifestBytes = readFileSync(manifestPath)
      const checked = validateThemeManifest(
        JSON.parse(manifestBytes.toString('utf8'))
      )
      if (!checked.ok) return checked
      const manifest = checked.value
      if (
        manifest.identity.packageName !== packageName ||
        manifest.identity.packageVersion !== metadata.version ||
        themeIds.has(manifest.identity.themeId)
      )
        invalid('manifest-identity-conflict', 'TC_IDENTITY_MISMATCH')
      themeIds.add(manifest.identity.themeId)
      registrations.push({ manifest })
      const {
        packageVersion,
        themeId,
        contractVersion,
        sourceContentHash,
        contractContentHash,
        typeRegistryContentHash,
      } = manifest.identity
      manifests.push({
        identity: {
          packageName,
          packageVersion,
          themeId,
          contractVersion,
          sourceContentHash,
          contractContentHash,
          typeRegistryContentHash,
        },
        manifestSha256: hash(manifestBytes),
      })
      const requiredExports = themeCssExports(manifest)
      for (const artifact of manifest.artifacts.filter(
        (item) => item.mediaType === 'text/css'
      )) {
        if (!safeSegments(artifact.path))
          invalid('artifact-path-invalid', 'TC_ARTIFACT_PATH_INVALID')
        const expectedPath = resolve(dirname(manifestPath), artifact.path)
        if (!inside(packageRoot, expectedPath))
          invalid('artifact-outside-package', 'TC_ARTIFACT_PATH_INVALID')
        const exportPath = publicCssExport(
          metadata.exports,
          packageRoot,
          expectedPath
        )
        if (requiredExports.get(artifact.path) !== exportPath)
          invalid('load-plan-export-mismatch')
        // The only CSS read goes through the package resolver, including wildcard exports.
        const publicPath = fromApplication.resolve(
          `${packageName}/${exportPath.slice(2)}`
        )
        if (
          realpathSync(publicPath) !== realpathSync(expectedPath) ||
          !inside(realpathSync(packageRoot), realpathSync(publicPath))
        )
          invalid('css-export-target-mismatch', 'TC_ARTIFACT_PATH_INVALID')
        const bytes = readFileSync(publicPath)
        if (
          bytes.byteLength !== artifact.bytes ||
          hash(bytes) !== artifact.sha256
        )
          invalid('css-content-mismatch', 'TC_ARTIFACT_HASH_MISMATCH')
        const tuple = `${packageName}|${packageVersion}|${exportPath}`
        if (publicTuples.has(tuple))
          invalid('duplicate-css-export', 'TC_ARTIFACT_DUPLICATE')
        publicTuples.add(tuple)
        const filename = `${artifact.sha256.slice(7)}.css`
        const previous = files.get(filename)
        if (previous && !previous.equals(bytes))
          invalid('css-hash-collision', 'TC_ARTIFACT_HASH_MISMATCH')
        files.set(filename, bytes)
        entries.push({
          packageName,
          packageVersion,
          exportPath,
          sha256: artifact.sha256,
          assetPath: `${base}${filename}`,
          integrity: `sha256-${Buffer.from(
            artifact.sha256.slice(7),
            'hex'
          ).toString('base64')}`,
          byteLength: bytes.byteLength,
        })
      }
    }
    entries.sort((a, b) =>
      compareCodePoint(
        `${a.packageName}|${a.packageVersion}|${a.exportPath}|${a.sha256}`,
        `${b.packageName}|${b.packageVersion}|${b.exportPath}|${b.sha256}`
      )
    )
    const deployment: ThemeDeploymentMapV1 = {
      schema: 'zx.theme-deployment/1',
      manifests,
      entries,
    }
    files.set('deployment.json', Buffer.from(canonicalJson(deployment)))
    writeOwnedDirectory(output, files)
    return success({ deployment, registrations })
  } catch (error) {
    return failure([
      diagnostic({
        code:
          error instanceof DeploymentError
            ? error.code
            : 'TC_WRITE_COMMIT_FAILED',
        phase: 'write',
        jsonPath: '$',
        target: 'theme deployment',
        expected: 'verified public assets and a dedicated owned output',
        actual:
          error instanceof DeploymentError
            ? error.message
            : 'deployment-assembly-failed',
        details: {
          reason:
            error instanceof DeploymentError
              ? error.message
              : 'deployment-assembly-failed',
        },
        remediation: { code: 'CHECK_THEME_DEPLOYMENT_INPUTS' },
      }),
    ])
  }
}
