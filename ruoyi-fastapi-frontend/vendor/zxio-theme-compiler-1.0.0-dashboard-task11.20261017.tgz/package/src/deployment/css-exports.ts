import type { ThemeManifestV1 } from '../targets/manifest/model'

/** Public CSS protocol shared by physical emission and runtime projection. */
export function themeCssExports(
  manifest: ThemeManifestV1
): Map<string, string> {
  return new Map([
    ['theme.css', './theme.css'],
    ['element-plus/aliases.css', './element-plus.css'],
    ...manifest.variants.flatMap((variant) => [
      [variant.artifacts.coreCss.path, `./variants/${variant.variantKey}`] as [
        string,
        string
      ],
      [
        variant.artifacts.elementPlusResolvedCss.path,
        `./element-plus/${variant.variantKey}`,
      ] as [string, string],
    ]),
  ])
}
