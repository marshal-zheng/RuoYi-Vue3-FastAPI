import type {
  AuthorCanonicalTokenPath,
  BuiltInTypeId,
} from '@zxio/tokens/kernel'

export interface ElementPlusMappingEntry {
  readonly source: AuthorCanonicalTokenPath
  readonly sourceType: BuiltInTypeId
  readonly status: 'mapped' | 'not-applicable'
  readonly targets?: readonly `--el-${string}`[]
  readonly reasonCode?:
    | 'NO_ELEMENT_EQUIVALENT'
    | 'ZX_ONLY_BEHAVIOR'
    | 'TYPE_NOT_SUPPORTED'
  readonly rationale: string
}

/**
 * Why a component-private Element Plus property is intentionally left to
 * Element Plus's own declaration instead of being re-pointed:
 * - `INHERITS_ELEMENT_CHAIN`: its value is a `var(--el-…)` chain, so it already
 *   follows the bridged global-theme variables or another governed property.
 * - `GEOMETRY`: sizes, radii, z-indexes, timing functions and other non-color
 *   facts that theme packages do not own.
 * - `MODIFIER_ONLY`: declared only on modifier or state selectors, where the
 *   chain to global-theme variables is the intended per-type behavior.
 * - `ELEMENT_INTERNAL`: content-level colors (illustrations, checkerboards,
 *   rating stars, fixed-column shadows) that are not UI chrome.
 */
export type ElementPlusPassthroughReason =
  | 'INHERITS_ELEMENT_CHAIN'
  | 'GEOMETRY'
  | 'MODIFIER_ONLY'
  | 'ELEMENT_INTERNAL'

export interface ElementPlusPassthroughTarget {
  readonly target: `--el-${string}`
  readonly reasonCode: ElementPlusPassthroughReason
  readonly rationale: string
}

/**
 * A role that one Element Plus property takes on a single declaring modifier
 * selector, different from the default role it takes on the component root.
 * Element Plus reuses one property name (`--el-button-bg-color`) for several
 * roles by re-declaring it per type, which `entries` cannot express because a
 * target there has exactly one source. An override owns exactly one
 * `(target, selector)` pair, and `selector` must be one of that target's
 * `declaredOn` entries so the alias lands where Element Plus declares it.
 */
export interface ElementPlusModifierOverride {
  readonly target: `--el-${string}`
  readonly selector: string
  readonly source: AuthorCanonicalTokenPath
  readonly sourceType: BuiltInTypeId
  readonly rationale: string
}

/** Component UI defaults, separate from theme tokens and raw length overrides. */
export interface ElementPlusDisplayDefault {
  readonly target: `--el-${string}`
  readonly value:
    | { readonly kind: 'scaled-px'; readonly px: number }
    | {
        readonly kind: 'variable'
        readonly variable:
          | '--el-component-size'
          | '--el-font-size-extra-small'
          | '--zx-semantic-spacing-control-y'
        readonly factor: number
      }
}

/**
 * Mapping table v2: every inventory target is owned by one public token,
 * a component display default, or explicitly passed through. The control-y dimension is converted to final control heights by the
 * adapter's reviewed density table. Other global-theme targets are aliased on the theme scope root; component-private targets are
 * aliased on the selectors that declare them (`ElementPlusTargetEntry.declaredOn`
 * roots), so Element Plus components read theme values without any consumer
 * writing `.el-*` overrides. `modifierTargets` re-points the same property on a
 * declaring modifier selector where Element Plus gives it a different role.
 */
export interface ElementPlusMappingTableV2 {
  readonly schema: 'zx.element-plus-mapping/2'
  readonly version: string
  readonly entries: readonly ElementPlusMappingEntry[]
  readonly passthroughTargets: readonly ElementPlusPassthroughTarget[]
  readonly modifierTargets: readonly ElementPlusModifierOverride[]
  /** Added in 2.5.0; older custom mappings can omit this collection. */
  readonly displayDefaults?: readonly ElementPlusDisplayDefault[]
}

export type ElementPlusTargetClassification =
  | 'global-theme'
  | 'component-private'

/**
 * One Element Plus custom property as declared by the locked theme-chalk
 * source. `declaredOn` lists every selector that declares the property (code
 * point order, deduplicated). `global-theme` properties are the reviewed host
 * bridge and must be declared on `:root`; `component-private` properties are
 * re-pointed on their declaring roots (`:root` or component root classes) by
 * the alias artifact, or explicitly passed through to Element Plus.
 */
export interface ElementPlusTargetEntry {
  readonly name: `--el-${string}`
  readonly classification: ElementPlusTargetClassification
  readonly declaredOn: readonly string[]
}

export interface ElementPlusTargetInventoryV2 {
  readonly schema: 'zx.element-plus-target-inventory/2'
  readonly packageName: 'element-plus'
  readonly exactVersion: string
  readonly supportedRange: string
  readonly sourceFiles: readonly string[]
  readonly sourceContentHash: `sha256:${string}`
  readonly targets: readonly ElementPlusTargetEntry[]
}
