/**
 * Preserve Element Plus's size resolution; only theme its final metrics.
 * At the default 8px control-y rhythm these are EP's 24 / 32 / 40px.
 * Compact (6px) and comfortable (10px) move each size by -4px / +4px.
 */
export const elementPlusControlSizeOffsets = {
  '--el-component-size': 16,
  '--el-component-size-large': 24,
  '--el-component-size-small': 8,
} as const

export function elementPlusDensityValue(
  source: string,
  target: string,
  value: string
): string {
  if (source !== 'semantic.spacing.control-y') return value
  const offset =
    elementPlusControlSizeOffsets[
      target as keyof typeof elementPlusControlSizeOffsets
    ]
  return offset === undefined ? value : `calc(${value} * 2 + ${offset}px)`
}
