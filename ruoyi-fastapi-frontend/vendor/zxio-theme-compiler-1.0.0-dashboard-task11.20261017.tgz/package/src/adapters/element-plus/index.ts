import {
  canonicalCssBlock,
  canonicalJson,
  compareCodePoint,
  sha256,
} from '../../core/canonical-text'
import { isArtifactPath } from '../../core/artifact-graph'
import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'
import { createThemeScopeSelector } from '../../core/selector'
import { serializeWithRegistry } from '../../core/type-serializers'
import { publicCssVariable } from '../../targets/css/css-variable'
import { elementPlusMapping, elementPlusTargetInventory } from './mapping'
import { elementPlusDensityValue } from './density'
import {
  elementPlusDisplayDefaultValue,
  validElementPlusDisplayDefaultValue,
} from './display-defaults'

import type {
  AdapterArtifactContribution,
  AdapterCoverage,
  AdapterTextArtifact,
  ThemeAdapter,
  ThemeAdapterContext,
} from '../types'
import type { CanonicalTokenPath } from '@zxio/tokens/kernel'
import type {
  ElementPlusMappingEntry,
  ElementPlusMappingTableV2,
  ElementPlusTargetEntry,
  ElementPlusTargetInventoryV2,
} from './model'

export type * from './model'
export { elementPlusMapping, elementPlusTargetInventory }

function isRecord(input: unknown): input is Readonly<Record<string, unknown>> {
  return !!input && typeof input === 'object' && !Array.isArray(input)
}

function validDeclaredOn(input: unknown): input is readonly string[] {
  return (
    Array.isArray(input) &&
    input.length > 0 &&
    input.every(
      (selector) =>
        typeof selector === 'string' &&
        selector.length > 0 &&
        selector === selector.trim()
    ) &&
    new Set(input).size === input.length &&
    canonicalJson(input) === canonicalJson([...input].sort(compareCodePoint))
  )
}

/**
 * A declaring selector that Element Plus uses as a component root: one
 * `.el-*` block class, optionally with one BEM element, and without modifier
 * (`--`), state (`.is-*`), pseudo or combinator parts. Component-private
 * aliases carry the property's default role and are emitted on these roots.
 */
export const ELEMENT_PLUS_BASE_ROOT_SELECTOR =
  /^\.el-[a-z0-9]+(?:-[a-z0-9]+)*(?:__[a-z0-9]+(?:-[a-z0-9]+)*)?$/

export function elementPlusBaseRootSelectors(
  entry: Pick<ElementPlusTargetEntry, 'declaredOn'>
): readonly string[] {
  return entry.declaredOn.filter((selector) =>
    ELEMENT_PLUS_BASE_ROOT_SELECTOR.test(selector)
  )
}

/**
 * Whether `candidate` re-declares the property on a narrowed form of `root`:
 * the same block class plus a BEM modifier (`.el-button--primary`), a state
 * class (`.el-button.is-plain`) or a pseudo. Sibling component roots that
 * merely share a name prefix (`.el-table-v2` against `.el-table`) are not
 * narrowed forms and keep their own emission root.
 */
function narrowsSelector(candidate: string, root: string): boolean {
  if (candidate === root || !candidate.startsWith(root)) return false
  const rest = candidate.slice(root.length)
  return rest.startsWith('--') || rest.startsWith('.') || rest.startsWith(':')
}

/**
 * One place an alias is emitted, and the declaring selectors excluded from it.
 *
 * Element Plus reuses a single property name for several roles by re-declaring
 * it on type modifiers (`.el-button--primary { --el-button-bg-color: … }`).
 * Those modifiers are one class, exactly as specific as the component root, so
 * an alias on the root alone would decide the type colors by source order and
 * flatten every type to the default role. Each emission root therefore excludes
 * the property's other declaring selectors, which keeps the alias to the role it
 * actually owns and leaves the modifier roles to Element Plus's own chain into
 * the bridged global-theme variables.
 */
export interface ElementPlusEmissionRoot {
  readonly selector: string
  readonly excludes: readonly string[]
}

/**
 * Selectors an alias for this property is emitted on: `:root` (the theme
 * scope root block) when Element Plus declares it there, plus every component
 * root selector with its exclusion set. Empty means the property can only be
 * passed through.
 */
export function elementPlusEmissionRoots(
  entry: Pick<ElementPlusTargetEntry, 'declaredOn'>
): readonly ElementPlusEmissionRoot[] {
  return [
    ...(entry.declaredOn.includes(':root')
      ? [{ selector: ':root', excludes: [] as readonly string[] }]
      : []),
    ...elementPlusBaseRootSelectors(entry).map((selector) => ({
      selector,
      excludes: elementPlusExclusions(entry, selector),
    })),
  ]
}

/**
 * The declaring selectors that narrow `root` for this property, in the
 * inventory's code point order.
 */
export function elementPlusExclusions(
  entry: Pick<ElementPlusTargetEntry, 'declaredOn'>,
  root: string
): readonly string[] {
  return entry.declaredOn.filter((candidate) =>
    narrowsSelector(candidate, root)
  )
}

/**
 * The emitted selector for one root. A theme attribute gives the global root
 * the same specificity as Element Plus's `:root`, so source order can override
 * its defaults. `:not(:where(…))` keeps nested exclusions at zero specificity.
 */
export function elementPlusEmissionSelector(
  scopeSelector: string,
  root: ElementPlusEmissionRoot
): string {
  if (root.selector === ':root') return `${scopeSelector}[data-zx-theme]`
  const base = `${scopeSelector} ${root.selector}`
  return root.excludes.length === 0
    ? base
    : `${base}:not(:where(${root.excludes.join(', ')}))`
}

const PASSTHROUGH_REASONS = new Set([
  'INHERITS_ELEMENT_CHAIN',
  'GEOMETRY',
  'MODIFIER_ONLY',
  'ELEMENT_INTERNAL',
])

export function validateElementPlusTargetInventory(
  input: unknown
): CompilerResult<ElementPlusTargetInventoryV2> {
  const diagnostics = []
  const topKeys = [
    'exactVersion',
    'packageName',
    'schema',
    'sourceContentHash',
    'sourceFiles',
    'supportedRange',
    'targets',
  ]
  if (!isRecord(input)) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'element-plus',
        target: 'Element Plus target inventory v1',
        remediation: { code: 'PASS_EXACT_ELEMENT_INVENTORY' },
        details: { issue: 'inventory-not-object' },
      }),
    ])
  }
  const actualKeys = Object.keys(input).sort(compareCodePoint)
  const versionMatch =
    typeof input.exactVersion === 'string'
      ? /^(\d+)\.(\d+)\.(\d+)$/.exec(input.exactVersion)
      : null
  const expectedRange = versionMatch
    ? `>=${input.exactVersion} <${versionMatch[1]}.${
        Number(versionMatch[2]) + 1
      }.0`
    : null
  if (
    canonicalJson(actualKeys) !== canonicalJson(topKeys) ||
    input.schema !== 'zx.element-plus-target-inventory/2' ||
    input.packageName !== 'element-plus' ||
    !versionMatch ||
    input.supportedRange !== expectedRange ||
    typeof input.sourceContentHash !== 'string' ||
    !/^sha256:[a-f0-9]{64}$/.test(input.sourceContentHash) ||
    !Array.isArray(input.sourceFiles) ||
    input.sourceFiles.length === 0 ||
    input.sourceFiles.some(
      (path) => typeof path !== 'string' || !isArtifactPath(path)
    ) ||
    new Set(input.sourceFiles).size !== input.sourceFiles.length ||
    canonicalJson(input.sourceFiles) !==
      canonicalJson([...input.sourceFiles].sort(compareCodePoint)) ||
    !Array.isArray(input.targets) ||
    input.targets.length === 0
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'element-plus',
        expected: { keys: topKeys, supportedRange: expectedRange },
        actual: {
          keys: actualKeys,
          supportedRange:
            typeof input.supportedRange === 'string'
              ? input.supportedRange
              : null,
        },
        target: 'exact Element Plus inventory identity',
        remediation: { code: 'REGENERATE_ELEMENT_INVENTORY' },
        details: { issue: 'invalid-inventory-identity' },
      })
    )
  }
  const targetNames: string[] = []
  if (Array.isArray(input.targets)) {
    for (const [index, entry] of input.targets.entries()) {
      if (
        !isRecord(entry) ||
        canonicalJson(Object.keys(entry).sort(compareCodePoint)) !==
          canonicalJson(['classification', 'declaredOn', 'name']) ||
        typeof entry.name !== 'string' ||
        !/^--el-[a-z0-9-]+$/.test(entry.name) ||
        (entry.classification !== 'global-theme' &&
          entry.classification !== 'component-private') ||
        !validDeclaredOn(entry.declaredOn) ||
        (entry.classification === 'global-theme' &&
          !entry.declaredOn.includes(':root'))
      ) {
        diagnostics.push(
          diagnostic({
            code: 'TC_INPUT_INVALID',
            phase: 'adapter',
            adapter: 'element-plus',
            jsonPath: `$.targets[${index}]`,
            target: 'exact Element Plus target entry',
            remediation: { code: 'REVIEW_ELEMENT_TARGET_ENTRY' },
            details: { issue: 'invalid-target-entry' },
          })
        )
      } else {
        targetNames.push(entry.name)
      }
    }
  }
  if (
    new Set(targetNames).size !== targetNames.length ||
    canonicalJson(targetNames) !==
      canonicalJson([...targetNames].sort(compareCodePoint))
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_COLLISION',
        phase: 'adapter',
        adapter: 'element-plus',
        target: 'Element Plus inventory target owner set',
        remediation: { code: 'SORT_AND_DEDUPLICATE_ELEMENT_TARGETS' },
        details: {
          issue: 'inventory-targets-unsorted-or-duplicate',
          targetNames,
        },
      })
    )
  }
  return diagnostics.length > 0
    ? failure(diagnostics)
    : success(JSON.parse(canonicalJson(input)) as ElementPlusTargetInventoryV2)
}

function validateMapping(
  mapping: ElementPlusMappingTableV2,
  inventory: ElementPlusTargetInventoryV2,
  context: ThemeAdapterContext
): CompilerResult<readonly AdapterCoverage[]> {
  const diagnostics = []
  const publicSet = new Set(context.publicPaths)
  const entrySources = new Map<string, ElementPlusMappingEntry[]>()
  const targetSources = new Map<string, string[]>()
  const targets = new Map(inventory.targets.map((entry) => [entry.name, entry]))
  for (const entry of mapping.entries) {
    entrySources.set(entry.source, [
      ...(entrySources.get(entry.source) ?? []),
      entry,
    ])
    const source = entry.source as CanonicalTokenPath
    const sample = context.variants[0]?.resolved.tokens[source]
    if (!publicSet.has(source) || !sample || sample.visibility !== 'public') {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'element-plus',
          tokenPath: entry.source,
          remediation: { code: 'MAP_ONLY_PUBLIC_CONTRACT_TOKENS' },
          details: { issue: 'unknown-or-internal-source' },
        })
      )
    } else if (sample.typeId !== entry.sourceType) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'element-plus',
          source: sample.source,
          tokenPath: entry.source,
          expected: sample.typeId,
          actual: entry.sourceType,
          target: 'Element Plus source type mapping',
          remediation: { code: 'FIX_MAPPING_SOURCE_TYPE' },
          details: { issue: 'type-mismatch' },
        })
      )
    }
    if (entry.status === 'mapped') {
      if (!entry.targets || entry.targets.length === 0 || entry.reasonCode) {
        diagnostics.push(
          diagnostic({
            code: 'TC_ADAPTER_MAPPING_MISSING',
            phase: 'adapter',
            adapter: 'element-plus',
            tokenPath: entry.source,
            remediation: { code: 'ADD_EXPLICIT_ELEMENT_TARGET' },
            details: { issue: 'mapped-target-required' },
          })
        )
      }
      for (const target of entry.targets ?? []) {
        targetSources.set(target, [
          ...(targetSources.get(target) ?? []),
          entry.source,
        ])
        const inventoryEntry = targets.get(target)
        if (!inventoryEntry) {
          diagnostics.push(
            diagnostic({
              code: 'TC_ADAPTER_TARGET_UNKNOWN',
              phase: 'adapter',
              adapter: 'element-plus',
              tokenPath: entry.source,
              target,
              remediation: { code: 'REVIEW_ELEMENT_TARGET_INVENTORY' },
              details: { classification: 'missing' },
            })
          )
        } else if (elementPlusEmissionRoots(inventoryEntry).length === 0) {
          diagnostics.push(
            diagnostic({
              code: 'TC_ADAPTER_TARGET_UNKNOWN',
              phase: 'adapter',
              adapter: 'element-plus',
              tokenPath: entry.source,
              target,
              remediation: { code: 'PASS_THROUGH_MODIFIER_ONLY_TARGET' },
              details: {
                classification: inventoryEntry.classification,
                issue: 'no-emission-root',
                declaredOn: inventoryEntry.declaredOn,
              },
            })
          )
        }
      }
    } else if (entry.targets || !entry.reasonCode) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'element-plus',
          tokenPath: entry.source,
          remediation: { code: 'ADD_NOT_APPLICABLE_REASON' },
          details: { issue: 'invalid-not-applicable' },
        })
      )
    }
  }
  const missing = [...publicSet].filter((path) => !entrySources.has(path))
  const extra = [...entrySources.keys()].filter(
    (path) => !publicSet.has(path as CanonicalTokenPath)
  )
  const duplicates = [...entrySources.entries()]
    .filter(([, entries]) => entries.length > 1)
    .map(([source, entries]) => ({ source, count: entries.length }))
  if (missing.length > 0 || extra.length > 0 || duplicates.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_MISSING',
        phase: 'adapter',
        adapter: 'element-plus',
        remediation: { code: 'PROVIDE_EXACT_ELEMENT_COVERAGE' },
        details: { missing, extra, duplicates },
      })
    )
  }
  const collisions = [...targetSources.entries()]
    .filter(([, sources]) => sources.length > 1)
    .map(([target, sources]) => ({ target, sources }))
  if (collisions.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_COLLISION',
        phase: 'adapter',
        adapter: 'element-plus',
        remediation: { code: 'USE_ONE_SOURCE_PER_ELEMENT_TARGET' },
        details: { collisions },
      })
    )
  }
  const overrideKeys = mapping.modifierTargets.map(
    (entry) => `${entry.target} ${entry.selector}`
  )
  for (const [index, override] of mapping.modifierTargets.entries()) {
    const inventoryEntry = targets.get(override.target)
    const source = override.source as CanonicalTokenPath
    const sample = context.variants[0]?.resolved.tokens[source]
    if (!publicSet.has(source) || !sample || sample.visibility !== 'public') {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'element-plus',
          jsonPath: `$.modifierTargets[${index}]`,
          tokenPath: override.source,
          remediation: { code: 'MAP_ONLY_PUBLIC_CONTRACT_TOKENS' },
          details: { issue: 'unknown-or-internal-override-source' },
        })
      )
    } else if (sample.typeId !== override.sourceType) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'element-plus',
          jsonPath: `$.modifierTargets[${index}]`,
          tokenPath: override.source,
          expected: sample.typeId,
          actual: override.sourceType,
          target: override.target,
          remediation: { code: 'FIX_MAPPING_SOURCE_TYPE' },
          details: { issue: 'override-type-mismatch' },
        })
      )
    }
    if (!inventoryEntry) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_TARGET_UNKNOWN',
          phase: 'adapter',
          adapter: 'element-plus',
          jsonPath: `$.modifierTargets[${index}]`,
          target: override.target,
          remediation: { code: 'REVIEW_ELEMENT_TARGET_INVENTORY' },
          details: { classification: 'missing' },
        })
      )
      continue
    }
    // An override must land on a selector Element Plus actually declares the
    // property on, and must be a narrowed form of a component root: a base root
    // carries the default role and belongs in `entries`.
    if (
      !inventoryEntry.declaredOn.includes(override.selector) ||
      ELEMENT_PLUS_BASE_ROOT_SELECTOR.test(override.selector) ||
      !elementPlusBaseRootSelectors(inventoryEntry).some((root) =>
        narrowsSelector(override.selector, root)
      )
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_EMISSION_SCOPE_INVALID',
          phase: 'adapter',
          adapter: 'element-plus',
          jsonPath: `$.modifierTargets[${index}]`,
          target: override.target,
          expected: inventoryEntry.declaredOn as unknown as readonly string[],
          actual: override.selector,
          remediation: { code: 'OVERRIDE_ON_DECLARING_MODIFIER_SELECTOR' },
          details: { issue: 'override-selector-not-a-declared-modifier' },
        })
      )
    }
  }
  if (
    new Set(overrideKeys).size !== overrideKeys.length ||
    canonicalJson(overrideKeys) !==
      canonicalJson([...overrideKeys].sort(compareCodePoint))
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_COLLISION',
        phase: 'adapter',
        adapter: 'element-plus',
        remediation: { code: 'SORT_AND_DEDUPLICATE_ELEMENT_OVERRIDES' },
        details: { issue: 'modifier-overrides-unsorted-or-duplicate' },
      })
    )
  }
  const displayDefaults = mapping.displayDefaults ?? []
  const displayDefaultNames = displayDefaults.map((entry) => entry.target)
  const invalidDisplayDefaults = displayDefaults.filter(
    (entry) =>
      targets.get(entry.target)?.classification !== 'component-private' ||
      elementPlusBaseRootSelectors(
        targets.get(entry.target) ?? { declaredOn: [] }
      ).length === 0 ||
      !validElementPlusDisplayDefaultValue(entry.value) ||
      targetSources.has(entry.target)
  )
  if (
    invalidDisplayDefaults.length > 0 ||
    new Set(displayDefaultNames).size !== displayDefaultNames.length ||
    canonicalJson(displayDefaultNames) !==
      canonicalJson([...displayDefaultNames].sort(compareCodePoint))
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_MISSING',
        phase: 'adapter',
        adapter: 'element-plus',
        remediation: { code: 'REVIEW_ELEMENT_DISPLAY_DEFAULTS' },
        details: {
          issue: 'invalid-display-default',
          targets: invalidDisplayDefaults.map((entry) => entry.target),
        },
      })
    )
  }
  const passthroughNames = mapping.passthroughTargets.map(
    (entry) => entry.target
  )
  const invalidPassthrough = mapping.passthroughTargets.filter(
    (entry) =>
      targets.get(entry.target)?.classification !== 'component-private' ||
      !PASSTHROUGH_REASONS.has(entry.reasonCode) ||
      typeof entry.rationale !== 'string' ||
      entry.rationale.length === 0 ||
      targetSources.has(entry.target) ||
      displayDefaultNames.includes(entry.target)
  )
  if (
    invalidPassthrough.length > 0 ||
    new Set(passthroughNames).size !== passthroughNames.length ||
    canonicalJson(passthroughNames) !==
      canonicalJson([...passthroughNames].sort(compareCodePoint))
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_MISSING',
        phase: 'adapter',
        adapter: 'element-plus',
        remediation: { code: 'REVIEW_ELEMENT_PASSTHROUGH_TARGETS' },
        details: {
          issue: 'invalid-passthrough',
          targets: invalidPassthrough.map((entry) => entry.target),
        },
      })
    )
  }
  const covered = new Set([
    ...targetSources.keys(),
    ...displayDefaultNames,
    ...passthroughNames,
  ])
  const uncoveredTargets = inventory.targets
    .map((entry) => entry.name)
    .filter((name) => !covered.has(name))
  if (uncoveredTargets.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_MISSING',
        phase: 'adapter',
        adapter: 'element-plus',
        remediation: { code: 'PROVIDE_EXACT_ELEMENT_TARGET_CLOSURE' },
        details: { uncoveredTargets },
      })
    )
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  return success(
    mapping.entries.map((entry) => ({
      tokenPath: entry.source,
      status: entry.status,
      targets: entry.targets ?? [],
      ...(entry.reasonCode ? { reasonCode: entry.reasonCode } : {}),
    }))
  )
}

function compileElementPlus(
  mapping: ElementPlusMappingTableV2,
  inventory: ElementPlusTargetInventoryV2,
  context: ThemeAdapterContext
): CompilerResult<AdapterArtifactContribution> {
  const validatedInventory = validateElementPlusTargetInventory(inventory)
  if (!validatedInventory.ok) return failure(validatedInventory.diagnostics)
  const exactInventory = validatedInventory.value
  const coverage = validateMapping(mapping, exactInventory, context)
  if (!coverage.ok) return failure(coverage.diagnostics)
  const mapped = mapping.entries.filter(
    (
      entry
    ): entry is ElementPlusMappingEntry & {
      readonly status: 'mapped'
      readonly targets: readonly `--el-${string}`[]
    } => entry.status === 'mapped'
  )
  const inventoryByName = new Map(
    exactInventory.targets.map((entry) => [entry.name, entry])
  )
  const emissionRootsOf = (
    target: `--el-${string}`
  ): readonly ElementPlusEmissionRoot[] =>
    elementPlusEmissionRoots(inventoryByName.get(target)!)
  const scopeSelector = createThemeScopeSelector(context.themeId)
  // Element Plus declares its defaults on :root (one pseudo-class). The
  // zero-specificity theme identity alone cannot override them on html, even
  // when the theme stylesheet loads later. Keep the same identity and add one
  // attribute of equal specificity; this also works for nested theme scopes.
  const rootAliasSelector = `${scopeSelector}[data-zx-theme]`
  const rootAliasDeclarations: { property: string; value: string }[] = []
  // Keyed by emission root and exclusion set: two properties on the same
  // component root with different exclusion sets are different blocks.
  const componentAliasBlocks = new Map<
    string,
    ElementPlusEmissionRoot & {
      declarations: { property: string; value: string }[]
    }
  >()
  const addComponentDeclaration = (
    root: ElementPlusEmissionRoot,
    declaration: { property: string; value: string }
  ) => {
    const key = `${root.selector}|${root.excludes.join(',')}`
    const block = componentAliasBlocks.get(key) ?? {
      ...root,
      declarations: [],
    }
    block.declarations.push(declaration)
    componentAliasBlocks.set(key, block)
  }
  for (const entry of mapped) {
    for (const target of entry.targets) {
      const value = elementPlusDensityValue(
        entry.source,
        target,
        `var(${publicCssVariable(entry.source)})`
      )
      for (const root of emissionRootsOf(target)) {
        if (root.selector === ':root') {
          rootAliasDeclarations.push({ property: target, value })
          continue
        }
        addComponentDeclaration(root, { property: target, value })
      }
    }
  }
  for (const entry of mapping.displayDefaults ?? []) {
    for (const root of emissionRootsOf(entry.target)) {
      addComponentDeclaration(root, {
        property: entry.target,
        value: elementPlusDisplayDefaultValue(entry.value),
      })
    }
  }
  for (const override of mapping.modifierTargets) {
    const entry = inventoryByName.get(override.target)!
    addComponentDeclaration(
      {
        selector: override.selector,
        excludes: elementPlusExclusions(entry, override.selector),
      },
      {
        property: override.target,
        value: `var(${publicCssVariable(override.source)})`,
      }
    )
  }
  const sortDeclarations = (
    declarations: { property: string; value: string }[]
  ) =>
    declarations.sort((left, right) =>
      compareCodePoint(left.property, right.property)
    )
  const scopeDiagnostics = []
  // Every declaration in a block must own that block's exclusion set. This
  // fails closed if the grouping above ever merges properties whose declaring
  // modifiers differ, which is what silently flattened the typed roles before.
  for (const block of componentAliasBlocks.values()) {
    for (const { property } of block.declarations) {
      const required = elementPlusExclusions(
        inventoryByName.get(property as `--el-${string}`)!,
        block.selector
      )
      if (canonicalJson(required) === canonicalJson(block.excludes)) continue
      scopeDiagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_EMISSION_SCOPE_INVALID',
          phase: 'adapter',
          adapter: 'element-plus',
          target: property,
          expected: required as unknown as readonly string[],
          actual: block.excludes as unknown as readonly string[],
          remediation: { code: 'EXCLUDE_DECLARING_MODIFIER_SELECTORS' },
          details: {
            issue: 'emission-block-exclusions-mismatch',
            selector: block.selector,
          },
        })
      )
    }
  }
  if (scopeDiagnostics.length > 0) return failure(scopeDiagnostics)
  const aliasText = [
    canonicalCssBlock(
      rootAliasSelector,
      sortDeclarations(rootAliasDeclarations)
    ),
    ...[...componentAliasBlocks.values()]
      .sort(
        (left, right) =>
          compareCodePoint(left.selector, right.selector) ||
          compareCodePoint(left.excludes.join(','), right.excludes.join(','))
      )
      .map((block) =>
        canonicalCssBlock(
          elementPlusEmissionSelector(scopeSelector, block),
          sortDeclarations(block.declarations)
        )
      ),
  ].join('')
  const files: AdapterTextArtifact[] = [
    {
      path: 'element-plus/aliases.css',
      mediaType: 'text/css',
      purpose: 'element-plus-alias' as const,
      loadPhase: 'theme' as const,
      text: aliasText,
    },
  ]
  const variantArtifacts: Record<string, string> = {}
  const diagnostics = []
  for (const variant of context.variants) {
    const declarations = []
    for (const entry of mapped) {
      const rootTargets = entry.targets.filter((target) =>
        emissionRootsOf(target).some((root) => root.selector === ':root')
      )
      if (rootTargets.length === 0) continue
      const token = variant.resolved.tokens[entry.source as CanonicalTokenPath]
      if (!token) continue
      const serialized = serializeWithRegistry(
        context.serializers,
        token.typeId,
        token.value,
        { tokenPath: token.path, target: 'element-plus' }
      )
      if (!serialized.ok) {
        diagnostics.push(...serialized.diagnostics)
        continue
      }
      for (const target of rootTargets) {
        declarations.push({
          property: target,
          value: elementPlusDensityValue(
            entry.source,
            target,
            serialized.value
          ),
        })
      }
    }
    declarations.sort((left, right) =>
      compareCodePoint(left.property, right.property)
    )
    const path = `element-plus/resolved/${variant.variantKey}.css`
    variantArtifacts[variant.variantKey] = path
    files.push({
      path,
      mediaType: 'text/css',
      purpose: 'element-plus-resolved',
      loadPhase: 'variant',
      text: canonicalCssBlock(
        `${variant.selector}[data-zx-theme]`,
        declarations
      ),
    })
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  return success({
    files,
    variantArtifacts,
    contract: {
      name: '@zxio/theme-compiler/element-plus',
      version: mapping.version,
      mappingSchema: mapping.schema,
      mappingVersion: mapping.version,
      mappingHash: sha256(canonicalJson(mapping)),
      targetBaseline: {
        name: exactInventory.packageName,
        exactVersion: exactInventory.exactVersion,
        supportedRange: exactInventory.supportedRange,
        inventoryHash: sha256(canonicalJson(exactInventory)),
      },
      coverage: coverage.value,
    },
  })
}

export function createElementPlusAdapter(
  options: Readonly<{
    mapping: ElementPlusMappingTableV2
    targetInventory: ElementPlusTargetInventoryV2
  }> = {
    mapping: elementPlusMapping,
    targetInventory: elementPlusTargetInventory,
  }
): ThemeAdapter {
  return {
    id: 'element-plus',
    version: options.mapping.version,
    compile: (context) =>
      compileElementPlus(options.mapping, options.targetInventory, context),
  }
}
