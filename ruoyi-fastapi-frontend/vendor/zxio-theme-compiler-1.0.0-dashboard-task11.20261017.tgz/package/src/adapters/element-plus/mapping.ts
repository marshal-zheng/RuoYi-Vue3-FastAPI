import { elementPlusControlSizeOffsets } from './density'
import { elementPlusDisplayDefaults } from './display-defaults'
import inventoryJson from './baselines/element-plus-2.13.0.targets.json'
import { elementPlusPassthroughTargets } from './passthrough'

import type {
  AuthorCanonicalTokenPath,
  BuiltInTypeId,
} from '@zxio/tokens/kernel'
import type {
  ElementPlusMappingEntry,
  ElementPlusMappingTableV2,
  ElementPlusTargetInventoryV2,
} from './model'

// Surface roles of the public contract (`semantic.surface.<role>.<facet>`),
// listed locally so the adapters stay free of runtime Kernel imports; the
// Kernel exports the same list for consumers that derive themes.
const SURFACE_ROLES = [
  'canvas',
  'panel',
  'card',
  'field',
  'header',
  'overlay',
  'blocking',
  'selected',
  'brand',
] as const

const mappedRationale =
  'This public role owns the listed Element Plus global theme targets; each target remains a direct CSS-variable alias with one source.'
const notApplicableRationale =
  'Element Plus has no compatible global variable for this ZXUI semantic role; the role remains explicit so adapter coverage is total.'

type MappedEntry = Omit<
  ElementPlusMappingEntry,
  'status' | 'targets' | 'reasonCode'
> &
  Readonly<{
    status: 'mapped'
    targets: readonly `--el-${string}`[]
  }>
type NotApplicableEntry = Omit<
  ElementPlusMappingEntry,
  'status' | 'targets' | 'reasonCode'
> &
  Readonly<{
    status: 'not-applicable'
    reasonCode: NonNullable<ElementPlusMappingEntry['reasonCode']>
  }>

function mapped(
  source: AuthorCanonicalTokenPath,
  sourceType: BuiltInTypeId,
  targets: readonly `--el-${string}`[]
): MappedEntry {
  return {
    source,
    sourceType,
    status: 'mapped',
    targets: [...targets].sort(),
    rationale: mappedRationale,
  }
}

function notApplicable(
  source: AuthorCanonicalTokenPath,
  sourceType: BuiltInTypeId,
  reasonCode: NonNullable<ElementPlusMappingEntry['reasonCode']>
): NotApplicableEntry {
  return {
    source,
    sourceType,
    status: 'not-applicable',
    reasonCode,
    rationale: notApplicableRationale,
  }
}

const statusEntries = (
  ['success', 'warning', 'info', 'danger'] as const
).flatMap((family) => {
  const targets = (suffix = ''): `--el-${string}`[] =>
    family === 'danger'
      ? [`--el-color-danger${suffix}`, `--el-color-error${suffix}`]
      : [`--el-color-${family}${suffix}`]
  return [
    mapped(`semantic.status.${family}`, 'color', targets()),
    mapped(`semantic.status.${family}-shade-2`, 'color', targets('-dark-2')),
    ...([3, 5, 7, 8, 9] as const).map((step) =>
      mapped(
        `semantic.status.${family}-tint-${step}`,
        'color',
        targets(`-light-${step}`)
      )
    ),
  ]
})

const typographyEntries = [
  mapped('semantic.typography.family', 'font-family', ['--el-font-family']),
  mapped('semantic.typography.line-height-base', 'dimension', [
    '--el-font-line-height-primary',
  ]),
  ...(
    ['base', 'extra-large', 'extra-small', 'large', 'medium', 'small'] as const
  ).map((size) =>
    mapped(`semantic.typography.size-${size}`, 'dimension', [
      `--el-font-size-${size}`,
    ])
  ),
  mapped('semantic.typography.weight-primary', 'font-weight', [
    '--el-font-weight-primary',
  ]),
]

const rootEntries = [
  mapped('semantic.accent.shade-2', 'color', ['--el-color-primary-dark-2']),
  ...([3, 5, 7, 8, 9] as const).map((step) =>
    mapped(`semantic.accent.tint-${step}`, 'color', [
      `--el-color-primary-light-${step}`,
    ])
  ),
  mapped('semantic.accent.base', 'color', ['--el-color-primary']),
  mapped('semantic.border.subtle', 'color', [
    '--el-border-color',
    '--el-border-color-light',
    '--el-border-color-lighter',
    '--el-border-color-extra-light',
  ]),
  mapped('semantic.border.strong', 'color', [
    '--el-border-color-hover',
    '--el-border-color-dark',
    '--el-border-color-darker',
  ]),
  mapped('semantic.fill.subtle', 'color', [
    '--el-fill-color',
    '--el-fill-color-lighter',
    '--el-fill-color-extra-light',
  ]),
  mapped('semantic.fill.hover', 'color', ['--el-fill-color-light']),
  mapped('semantic.fill.active', 'color', [
    '--el-fill-color-dark',
    '--el-fill-color-darker',
  ]),
  mapped('semantic.motion.duration', 'duration', ['--el-transition-duration']),
  mapped('semantic.motion.duration-fast', 'duration', [
    '--el-transition-duration-fast',
  ]),
  mapped('semantic.overlay.mask', 'color', [
    '--el-mask-color',
    '--el-mask-color-extra-light',
  ]),
  mapped('semantic.overlay.modal', 'color', [
    '--el-overlay-color',
    '--el-overlay-color-light',
    '--el-overlay-color-lighter',
  ]),
  mapped('semantic.radius.control', 'dimension', ['--el-border-radius-base']),
  mapped('semantic.elevation.raised.shadow', 'shadow', [
    '--el-box-shadow-light',
    '--el-box-shadow-lighter',
  ]),
  mapped('semantic.elevation.overlay.shadow', 'shadow', ['--el-box-shadow']),
  mapped('semantic.elevation.blocking.shadow', 'shadow', [
    '--el-box-shadow-dark',
  ]),
  ...statusEntries,
  mapped('semantic.surface.body', 'color', ['--el-bg-color']),
  mapped('semantic.surface.elevated', 'color', ['--el-fill-color-blank']),
  mapped('semantic.surface.page', 'color', [
    '--el-bg-color-page',
    '--el-disabled-bg-color',
    '--el-disabled-border-color',
  ]),
  mapped('semantic.text.disabled', 'color', ['--el-text-color-disabled']),
  mapped('semantic.text.primary', 'color', [
    '--el-text-color-primary',
    '--el-text-color-regular',
  ]),
  mapped('semantic.text.secondary', 'color', [
    '--el-disabled-text-color',
    '--el-text-color-placeholder',
    '--el-text-color-secondary',
  ]),
  ...typographyEntries,

  notApplicable('semantic.action.focus-ring', 'color', 'NO_ELEMENT_EQUIVALENT'),
  ...(['primary', 'success', 'warning', 'danger', 'info'] as const).flatMap(
    (type) =>
      [
        'fill',
        'on-fill',
        'fill-hover',
        'fill-active',
        'fill-disabled',
        'on-fill-disabled',
      ].map((facet) =>
        notApplicable(
          `semantic.action.${type}.${facet}`,
          'color',
          'NO_ELEMENT_EQUIVALENT'
        )
      )
  ),
  notApplicable('semantic.accent.subtle', 'color', 'NO_ELEMENT_EQUIVALENT'),
  notApplicable(
    'semantic.radius.surface',
    'dimension',
    'NO_ELEMENT_EQUIVALENT'
  ),
  // One density source feeds the three final EP size metrics; the adapter
  // applies the reviewed offsets without changing component size inheritance.
  mapped(
    'semantic.spacing.control-y',
    'dimension',
    Object.keys(elementPlusControlSizeOffsets) as `--el-${string}`[]
  ),
  notApplicable(
    'semantic.elevation.flat.shadow',
    'shadow',
    'NO_ELEMENT_EQUIVALENT'
  ),
  ...(['flat', 'raised', 'overlay', 'blocking'] as const).flatMap((role) => [
    notApplicable(
      `semantic.elevation.${role}.surface`,
      'color',
      'NO_ELEMENT_EQUIVALENT'
    ),
    notApplicable(
      `semantic.elevation.${role}.border`,
      'color',
      'NO_ELEMENT_EQUIVALENT'
    ),
  ]),
  ...(
    [
      'accent-hover',
      'selected',
      'selected-hover',
      'accent-active',
      'status-subtle',
      'scrollbar-thumb',
      'scrollbar-thumb-hover',
      'scrollbar-track',
    ] as const
  ).map((role) =>
    notApplicable(`semantic.fill.${role}`, 'color', 'NO_ELEMENT_EQUIVALENT')
  ),
  notApplicable('semantic.fill.current-tint', 'number', 'TYPE_NOT_SUPPORTED'),
  notApplicable('semantic.border.default', 'color', 'NO_ELEMENT_EQUIVALENT'),
  notApplicable('semantic.border.control', 'color', 'NO_ELEMENT_EQUIVALENT'),
  notApplicable('semantic.border.current-tint', 'number', 'TYPE_NOT_SUPPORTED'),
  ...(['subtle', 'default', 'strong', 'focus', 'focus-inline'] as const).map(
    (role) =>
      notApplicable(`semantic.stroke.${role}`, 'border', 'TYPE_NOT_SUPPORTED')
  ),
  ...(
    [
      'accent',
      'status.success',
      'status.warning',
      'status.danger',
      'status.info',
    ] as const
  ).flatMap((role) =>
    [
      'on-surface',
      'on-fill',
      'on-fill-hover',
      'on-fill-active',
      'on-fill-disabled',
      'fill-hover',
      'fill-active',
    ].map((facet) =>
      notApplicable(
        `semantic.${role}${role === 'accent' ? '.' : '-'}${facet}`,
        'color',
        'NO_ELEMENT_EQUIVALENT'
      )
    )
  ),
  ...(
    [
      ['tonal-tint', 'color'],
      ['tonal-gradient', 'gradient'],
      ['brand-shadow.raised', 'shadow'],
      ['brand-shadow.overlay', 'shadow'],
      ['brand-shadow.blocking', 'shadow'],
      ['inner-glow', 'shadow'],
      ['inner-stroke', 'shadow'],
      ['inner-stroke-accent', 'shadow'],
      ['inner-stroke-danger', 'shadow'],
      ['focus-ring', 'shadow'],
      ['cutout-ring', 'shadow'],
      ['focus-ring-transition', 'transition'],
    ] as const
  ).map(([role, type]) =>
    notApplicable(`semantic.material.${role}`, type, 'ZX_ONLY_BEHAVIOR')
  ),
  // Surface roles are a ZXUI shell contract; Element Plus keeps reading its
  // own global-theme variables, which the mapped roles above already feed.
  ...SURFACE_ROLES.flatMap((role) => [
    notApplicable(
      `semantic.surface.${role}.fill`,
      'color',
      'NO_ELEMENT_EQUIVALENT'
    ),
    notApplicable(
      `semantic.surface.${role}.edge`,
      'border',
      'TYPE_NOT_SUPPORTED'
    ),
    notApplicable(
      `semantic.surface.${role}.depth`,
      'shadow',
      'ZX_ONLY_BEHAVIOR'
    ),
    notApplicable(
      `semantic.surface.${role}.inner`,
      'shadow',
      'ZX_ONLY_BEHAVIOR'
    ),
    notApplicable(
      `semantic.surface.${role}.highlight`,
      'gradient',
      'ZX_ONLY_BEHAVIOR'
    ),
    notApplicable(
      `semantic.surface.${role}.on-text`,
      'color',
      'NO_ELEMENT_EQUIVALENT'
    ),
    notApplicable(
      `semantic.surface.${role}.on-text-secondary`,
      'color',
      'NO_ELEMENT_EQUIVALENT'
    ),
  ]),
].sort((left, right) =>
  left.source < right.source ? -1 : left.source > right.source ? 1 : 0
)

// Component-level targets (THEME-surface-skin-governance D2.4): the public
// token that owns each governed Element Plus component-private property, plus
// the root re-point of `--el-bg-color-overlay` onto the overlay surface role.
// A property may appear once; every other component-private property is an
// explicit passthrough (`./passthrough`). Aliases are emitted on the selectors
// that declare the property (inventory `declaredOn` roots), so Element Plus's
// own modifier and state re-declarations keep chaining to the bridged globals.
const componentTargets: Readonly<Record<string, readonly `--el-${string}`[]>> =
  {
    'semantic.accent.on-surface': [
      '--el-button-hover-text-color',
      '--el-button-hover-link-text-color',
      '--el-button-active-color',
      '--el-link-hover-text-color',
      '--el-checkbox-checked-text-color',
      '--el-cascader-menu-selected-text-color',
      '--el-menu-active-color',
    ],
    'semantic.accent.on-fill': [
      '--el-checkbox-checked-icon-color',
      '--el-checkbox-button-checked-text-color',
      '--el-radio-button-checked-text-color',
    ],
    'semantic.surface.field.fill': [
      '--el-input-bg-color',
      '--el-button-bg-color',
      '--el-checkbox-bg-color',
      '--el-pagination-button-bg-color',
      '--el-radio-input-bg-color',
    ],
    'semantic.border.strong': [
      '--el-input-border-color',
      '--el-button-border-color',
      '--el-radio-input-border-color',
      '--el-switch-off-color',
    ],
    'semantic.border.default': [
      '--el-input-hover-border-color',
      '--el-input-hover-border',
      '--el-select-border-color-hover',
      '--el-input-tag-border-color-hover',
    ],
    'semantic.action.focus-ring': [
      '--el-input-focus-border',
      '--el-input-focus-border-color',
      '--el-select-input-focus-border-color',
      '--el-input-tag-input-focus-border-color',
      '--el-button-outline-color',
    ],
    'semantic.surface.field.on-text': [
      '--el-input-text-color',
      '--el-select-multiple-input-color',
      '--el-input-tag-text-color',
    ],
    'semantic.text.primary': [
      '--el-input-clear-hover-color',
      '--el-select-close-hover-color',
      '--el-input-tag-close-hover-color',
      '--el-button-text-color',
      '--el-pagination-button-color',
      '--el-pagination-text-color',
      '--el-checkbox-text-color',
      '--el-table-text-color',
      '--el-messagebox-title-color',
      '--el-messagebox-content-color',
      '--el-popover-title-text-color',
    ],
    'semantic.text.secondary': [
      '--el-input-placeholder-color',
      '--el-input-icon-color',
      '--el-select-input-color',
      '--el-input-tag-placeholder-color',
    ],
    'semantic.text.disabled': [
      '--el-select-disabled-color',
      '--el-input-tag-disabled-color',
      '--el-button-disabled-text-color',
      '--el-pagination-button-disabled-color',
    ],
    'semantic.surface.overlay.fill': [
      '--el-bg-color-overlay',
      '--el-popover-bg-color',
      '--el-tour-bg-color',
    ],
    'semantic.elevation.overlay.border': [
      '--el-popover-border-color',
      '--el-datepicker-border-color',
      '--el-notification-border-color',
    ],
    'semantic.elevation.overlay.shadow': [
      '--el-dropdown-menu-box-shadow',
      '--el-notification-shadow',
      '--el-cascader-menu-shadow',
      '--el-mention-shadow',
    ],
    'semantic.surface.blocking.fill': [
      '--el-dialog-bg-color',
      '--el-drawer-bg-color',
    ],
    'semantic.elevation.blocking.shadow': [
      '--el-dialog-box-shadow',
      '--el-messagebox-box-shadow',
    ],
    'semantic.radius.control': [
      '--el-dialog-border-radius',
      '--el-messagebox-border-radius',
      '--el-popover-border-radius',
    ],
    'semantic.surface.header.fill': [
      '--el-table-header-bg-color',
      '--el-collapse-header-bg-color',
      '--el-transfer-panel-header-bg-color',
      '--el-descriptions-item-bordered-label-background',
    ],
    'semantic.surface.header.on-text-secondary': [
      '--el-table-header-text-color',
    ],
    'semantic.border.subtle': ['--el-table-border-color'],
    // `fill.*` are translucent wash layers, correct for rows and menu items that
    // have no resting background of their own. A button's resting fill is opaque,
    // and `background-color` replaces rather than layers, so a wash here would
    // drop the button's own fill on hover and show the parent surface through it.
    // Element Plus's own hover chain is opaque and already bridged.
    'semantic.fill.hover': [
      '--el-table-row-hover-bg-color',
      '--el-menu-hover-bg-color',
      '--el-menu-item-hover-fill',
    ],
    'semantic.fill.selected': [
      '--el-table-current-row-bg-color',
      '--el-calendar-selected-bg-color',
      '--el-datepicker-inrange-bg-color',
    ],
    'semantic.fill.selected-hover': ['--el-datepicker-inrange-hover-bg-color'],
    'semantic.fill.subtle': [
      '--el-segmented-bg-color',
      '--el-empty-fill-color-3',
    ],
    'semantic.elevation.raised.shadow': ['--el-table-fixed-box-shadow'],
    'semantic.elevation.raised.border': ['--el-card-border-color'],
    'semantic.surface.card.fill': [
      '--el-card-bg-color',
      '--el-collapse-content-bg-color',
    ],
    // Empty's default SVG is painted with 10 component-private stops. Dark
    // `fill.*` tokens are light washes and would keep the illustration white;
    // opaque surface roles invert with the theme instead.
    'semantic.surface.elevated': [
      '--el-empty-fill-color-0',
      '--el-empty-fill-color-1',
      '--el-empty-fill-color-2',
    ],
    'semantic.surface.page': [
      '--el-empty-fill-color-4',
      '--el-empty-fill-color-5',
      '--el-empty-fill-color-6',
      '--el-empty-fill-color-7',
      '--el-empty-fill-color-8',
      '--el-empty-fill-color-9',
    ],
    'semantic.surface.panel.fill': ['--el-menu-bg-color'],
    'semantic.surface.brand.on-text': ['--el-color-white'],
    'semantic.surface.brand.on-text-secondary': [
      '--el-button-divide-border-color',
    ],
  }

const entries = rootEntries
  .map((entry) => {
    const extra = componentTargets[entry.source]
    if (!extra) return entry
    return mapped(entry.source, entry.sourceType, [
      ...(entry.status === 'mapped' ? entry.targets : []),
      ...extra,
    ])
  })
  .sort((left, right) =>
    left.source < right.source ? -1 : left.source > right.source ? 1 : 0
  )

// Modifier aliases follow the actual EP foreground role. Link/text buttons
// stay on neutral surfaces; plain hover and solid states use paired fill text.
const modifierTargets = (
  ['primary', 'danger', 'info', 'success', 'warning'] as const
)
  .flatMap((type) => {
    const role =
      type === 'primary' ? 'semantic.accent.' : `semantic.status.${type}-`
    const action = `semantic.action.${type}.`
    const button = `.el-button--${type}`
    const aliases = [
      ['--el-button-bg-color', button, `${action}fill`],
      ['--el-button-border-color', button, `${action}fill`],
      ['--el-button-text-color', button, `${action}on-fill`],
      ['--el-button-hover-text-color', button, `${action}on-fill`],
      ['--el-button-hover-bg-color', button, `${action}fill-hover`],
      ['--el-button-hover-border-color', button, `${action}fill-hover`],
      ['--el-button-active-bg-color', button, `${action}fill-active`],
      ['--el-button-active-border-color', button, `${action}fill-active`],
      // EP otherwise uses --el-color-white, which is the brand foreground
      // and can be black even when this type's disabled fill is dark.
      ['--el-button-disabled-text-color', button, `${action}on-fill-disabled`],
      ['--el-button-disabled-bg-color', button, `${action}fill-disabled`],
      ['--el-button-disabled-border-color', button, `${action}fill-disabled`],
      ['--el-button-hover-link-text-color', button, `${role}on-surface`],
      ['--el-button-active-color', button, `${role}on-surface`],
      ...['is-plain', 'is-link', 'is-text'].flatMap((modifier) => [
        ...(modifier === 'is-plain'
          ? [
              [
                '--el-button-hover-bg-color',
                `${button}.${modifier}`,
                `${action}fill`,
              ],
              [
                '--el-button-hover-border-color',
                `${button}.${modifier}`,
                `${action}fill`,
              ],
            ]
          : []),
        [
          '--el-button-text-color',
          `${button}.${modifier}`,
          `${role}on-surface`,
        ],
        [
          '--el-button-hover-text-color',
          `${button}.${modifier}`,
          modifier === 'is-plain' ? `${action}on-fill` : `${role}on-surface`,
        ],
        [
          '--el-button-active-text-color',
          `${button}.${modifier}`,
          modifier === 'is-plain' ? `${action}on-fill` : `${role}on-surface`,
        ],
      ]),
      ...[type, ...(type === 'danger' ? ['error'] : [])].flatMap((linkType) => [
        [
          '--el-link-text-color',
          `.el-link.el-link--${linkType}`,
          `${role}on-surface`,
        ],
        [
          '--el-link-hover-text-color',
          `.el-link.el-link--${linkType}`,
          `${role}on-surface`,
        ],
      ]),
    ]
    return aliases.map(([target, selector, source]) => ({
      target: target as `--el-${string}`,
      selector: selector!,
      source: source as AuthorCanonicalTokenPath,
      sourceType: 'color' as const,
      rationale:
        'Pair solid actions with a dedicated light-label palette; neutral link/text actions retain their content colors.',
    }))
  })
  .concat([
    {
      target: '--el-button-hover-text-color',
      selector: '.el-button.is-plain',
      source: 'semantic.accent.on-surface',
      sourceType: 'color',
      rationale: 'Default plain buttons keep a neutral surface on hover.',
    },
  ])
  .sort((left, right) =>
    `${left.target} ${left.selector}` < `${right.target} ${right.selector}`
      ? -1
      : `${left.target} ${left.selector}` > `${right.target} ${right.selector}`
      ? 1
      : 0
  )

export const elementPlusMapping = {
  schema: 'zx.element-plus-mapping/2',
  version: '2.8.0',
  entries,
  passthroughTargets: elementPlusPassthroughTargets,
  modifierTargets,
  displayDefaults: elementPlusDisplayDefaults,
} as const satisfies ElementPlusMappingTableV2

export const elementPlusTargetInventory =
  inventoryJson as ElementPlusTargetInventoryV2
