import type {
  AuthorCanonicalTokenPath,
  BuiltInTypeMap,
  CanonicalTokenPath,
} from '@zxio/tokens/kernel'
import type {
  ArtifactLoadPhase,
  ThemeArtifactPurpose,
} from '../core/artifact-graph'
import type { MatrixVariant } from '../core/matrix'
import type { CompilerResult } from '../core/result'
import type { TargetSerializerRegistry } from '../core/type-serializers'
import type { PublicCssAliasRegistry } from '../targets/css/css-variable'

export interface AdapterCoverage {
  readonly tokenPath: AuthorCanonicalTokenPath
  readonly status: 'mapped' | 'not-applicable'
  readonly targets: readonly string[]
  readonly reasonCode?: string
}

export interface AdapterTextArtifact {
  readonly path: string
  readonly mediaType: string
  readonly purpose: ThemeArtifactPurpose
  readonly loadPhase: ArtifactLoadPhase
  readonly text: string
}

export interface LocalAdapterContract {
  readonly name:
    | '@zxio/theme-compiler/element-plus'
    | '@zxio/theme-compiler/dtcg'
  readonly version: string
  readonly mappingSchema: string
  readonly mappingVersion: string
  readonly mappingHash: `sha256:${string}`
  readonly targetBaseline?: Readonly<{
    name: string
    exactVersion: string
    supportedRange: string
    inventoryHash: `sha256:${string}`
  }>
  readonly coverage: readonly AdapterCoverage[]
}

export interface AdapterArtifactContribution {
  readonly files: readonly AdapterTextArtifact[]
  readonly contract: LocalAdapterContract
  readonly variantArtifacts: Readonly<Record<string, string>>
}

export interface ThemeAdapterContext {
  readonly themeId: string
  readonly variants: readonly MatrixVariant<BuiltInTypeMap>[]
  readonly publicPaths: readonly CanonicalTokenPath[]
  readonly publicAliases: PublicCssAliasRegistry
  readonly serializers: TargetSerializerRegistry<BuiltInTypeMap>
}

export interface ThemeAdapter {
  readonly id: 'element-plus' | 'dtcg'
  readonly version: string
  compile(
    context: ThemeAdapterContext
  ): CompilerResult<AdapterArtifactContribution>
}
