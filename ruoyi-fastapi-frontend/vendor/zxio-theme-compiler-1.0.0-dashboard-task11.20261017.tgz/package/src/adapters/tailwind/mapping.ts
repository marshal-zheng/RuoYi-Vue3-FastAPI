import type {
  AuthorCanonicalTokenPath,
  BuiltInTypeId,
} from '@zxio/tokens/kernel'
import type { TailwindMappingEntry, TailwindMappingTableV1 } from './model'

// Surface roles of the public contract (`semantic.surface.<role>.<facet>`),
// listed locally so the adapters stay free of runtime Kernel imports; the
// Kernel exports the same list for consumers that derive themes.
const SURFACE_ROLES = [
  'canvas',
  'panel',
  'card',
  'field',
  'header',
  'overlay',
  'blocking',
  'selected',
  'brand',
] as const

type Namespace = NonNullable<TailwindMappingEntry['namespace']>
type MappedEntry = Omit<
  TailwindMappingEntry,
  'status' | 'namespace' | 'name' | 'reasonCode'
> &
  Readonly<{
    status: 'mapped'
    namespace: Namespace
    name: string
  }>
type UnsupportedEntry = Omit<
  TailwindMappingEntry,
  'status' | 'namespace' | 'name' | 'reasonCode'
> &
  Readonly<{
    status: 'unsupported'
    reasonCode: NonNullable<TailwindMappingEntry['reasonCode']>
  }>

function mapped(
  source: AuthorCanonicalTokenPath,
  sourceType: BuiltInTypeId,
  namespace: Namespace,
  name: string
): MappedEntry {
  return { source, sourceType, status: 'mapped', namespace, name }
}

function unsupported(
  source: AuthorCanonicalTokenPath,
  sourceType: BuiltInTypeId,
  reasonCode: NonNullable<TailwindMappingEntry['reasonCode']>
): UnsupportedEntry {
  return { source, sourceType, status: 'unsupported', reasonCode }
}

const statusEntries = (
  ['success', 'warning', 'info', 'danger'] as const
).flatMap((family) => [
  mapped(`semantic.status.${family}`, 'color', 'color', family),
  mapped(
    `semantic.status.${family}-shade-2`,
    'color',
    'color',
    `status-${family}-shade-2`
  ),
  ...([3, 5, 7, 8, 9] as const).map((step) =>
    mapped(
      `semantic.status.${family}-tint-${step}`,
      'color',
      'color',
      `status-${family}-tint-${step}`
    )
  ),
])

const typographyEntries = [
  mapped('semantic.typography.family', 'font-family', 'font', 'family'),
  mapped(
    'semantic.typography.line-height-base',
    'dimension',
    'leading',
    'line-height-base'
  ),
  ...(
    ['base', 'extra-large', 'extra-small', 'large', 'medium', 'small'] as const
  ).map((size) =>
    mapped(
      `semantic.typography.size-${size}`,
      'dimension',
      'text',
      `size-${size}`
    )
  ),
  mapped(
    'semantic.typography.weight-primary',
    'font-weight',
    'font',
    'weight-primary'
  ),
]

const entries = [
  mapped('semantic.accent.base', 'color', 'color', 'accent'),
  mapped('semantic.accent.subtle', 'color', 'color', 'accent-subtle'),
  mapped('semantic.accent.shade-2', 'color', 'color', 'accent-shade-2'),
  ...([3, 5, 7, 8, 9] as const).map((step) =>
    mapped(
      `semantic.accent.tint-${step}`,
      'color',
      'color',
      `accent-tint-${step}`
    )
  ),
  mapped('semantic.action.focus-ring', 'color', 'color', 'action-focus-ring'),
  ...(['primary', 'success', 'warning', 'danger', 'info'] as const).flatMap(
    (type) =>
      [
        'fill',
        'on-fill',
        'fill-hover',
        'fill-active',
        'fill-disabled',
        'on-fill-disabled',
      ].map((facet) =>
        mapped(
          `semantic.action.${type}.${facet}`,
          'color',
          'color',
          `action-${type}-${facet}`
        )
      )
  ),
  mapped('semantic.border.subtle', 'color', 'color', 'border-subtle'),
  mapped('semantic.border.strong', 'color', 'color', 'border-strong'),
  mapped('semantic.fill.active', 'color', 'color', 'fill-active'),
  mapped('semantic.fill.hover', 'color', 'color', 'fill-hover'),
  mapped('semantic.motion.duration', 'duration', 'duration', 'motion'),
  mapped(
    'semantic.motion.duration-fast',
    'duration',
    'duration',
    'motion-fast'
  ),
  mapped('semantic.overlay.mask', 'color', 'color', 'overlay-mask'),
  mapped('semantic.overlay.modal', 'color', 'color', 'overlay-modal'),
  mapped('semantic.radius.control', 'dimension', 'radius', 'control'),
  mapped('semantic.radius.surface', 'dimension', 'radius', 'surface'),
  mapped('semantic.spacing.control-y', 'dimension', 'spacing', 'control-y'),
  ...statusEntries,
  mapped('semantic.surface.body', 'color', 'color', 'surface-base'),
  mapped('semantic.surface.elevated', 'color', 'color', 'surface-elevated'),
  mapped('semantic.surface.page', 'color', 'color', 'surface-page'),
  mapped('semantic.text.disabled', 'color', 'color', 'text-disabled'),
  mapped('semantic.text.primary', 'color', 'color', 'text-primary'),
  mapped('semantic.text.secondary', 'color', 'color', 'text-secondary'),
  ...typographyEntries,

  ...(['flat', 'raised', 'overlay', 'blocking'] as const).flatMap((role) => [
    mapped(
      `semantic.elevation.${role}.shadow`,
      'shadow',
      'shadow',
      `elevation-${role}`
    ),
    mapped(
      `semantic.elevation.${role}.surface`,
      'color',
      'color',
      `elevation-${role}-surface`
    ),
    mapped(
      `semantic.elevation.${role}.border`,
      'color',
      'color',
      `elevation-${role}-border`
    ),
  ]),
  ...(
    [
      'subtle',
      'accent-hover',
      'selected',
      'selected-hover',
      'accent-active',
      'status-subtle',
      'scrollbar-thumb',
      'scrollbar-thumb-hover',
      'scrollbar-track',
    ] as const
  ).map((role) =>
    mapped(`semantic.fill.${role}`, 'color', 'color', `fill-${role}`)
  ),
  mapped('semantic.border.default', 'color', 'color', 'border-default'),
  mapped('semantic.border.control', 'color', 'color', 'border-control'),
  ...(
    [
      'accent',
      'status.success',
      'status.warning',
      'status.danger',
      'status.info',
    ] as const
  ).flatMap((role) =>
    [
      'on-surface',
      'on-fill',
      'on-fill-hover',
      'on-fill-active',
      'on-fill-disabled',
      'fill-hover',
      'fill-active',
    ].map((facet) =>
      mapped(
        `semantic.${role}${role === 'accent' ? '.' : '-'}${facet}`,
        'color',
        'color',
        `${role.replace('.', '-')}-${facet}`
      )
    )
  ),
  mapped(
    'semantic.material.tonal-tint',
    'color',
    'color',
    'material-tonal-tint'
  ),
  ...(
    [
      'brand-shadow.raised',
      'brand-shadow.overlay',
      'brand-shadow.blocking',
      'inner-glow',
      'inner-stroke',
      'inner-stroke-accent',
      'inner-stroke-danger',
      'focus-ring',
      'cutout-ring',
    ] as const
  ).map((role) =>
    mapped(
      `semantic.material.${role}`,
      'shadow',
      'shadow',
      `material-${role.replace('.', '-')}`
    )
  ),

  ...SURFACE_ROLES.flatMap((role) => [
    mapped(
      `semantic.surface.${role}.fill`,
      'color',
      'color',
      `surface-${role}-fill`
    ),
    mapped(
      `semantic.surface.${role}.on-text`,
      'color',
      'color',
      `surface-${role}-on-text`
    ),
    mapped(
      `semantic.surface.${role}.on-text-secondary`,
      'color',
      'color',
      `surface-${role}-on-text-secondary`
    ),
    mapped(
      `semantic.surface.${role}.depth`,
      'shadow',
      'shadow',
      `surface-${role}-depth`
    ),
    mapped(
      `semantic.surface.${role}.inner`,
      'shadow',
      'shadow',
      `surface-${role}-inner`
    ),
    unsupported(
      `semantic.surface.${role}.edge`,
      'border',
      'NO_TAILWIND_NAMESPACE'
    ),
    unsupported(
      `semantic.surface.${role}.highlight`,
      'gradient',
      'NO_TAILWIND_NAMESPACE'
    ),
  ]),

  unsupported('semantic.fill.current-tint', 'number', 'ZX_ONLY_BEHAVIOR'),
  unsupported('semantic.border.current-tint', 'number', 'ZX_ONLY_BEHAVIOR'),
  ...(['subtle', 'default', 'strong', 'focus', 'focus-inline'] as const).map(
    (role) =>
      unsupported(`semantic.stroke.${role}`, 'border', 'NO_TAILWIND_NAMESPACE')
  ),
  unsupported(
    'semantic.material.tonal-gradient',
    'gradient',
    'NO_TAILWIND_NAMESPACE'
  ),
  unsupported(
    'semantic.material.focus-ring-transition',
    'transition',
    'NO_TAILWIND_NAMESPACE'
  ),
].sort((left, right) =>
  left.source < right.source ? -1 : left.source > right.source ? 1 : 0
)

export const tailwindMapping = {
  schema: 'zx.tailwind-mapping/1',
  version: '1.8.0',
  entries,
} as const satisfies TailwindMappingTableV1
