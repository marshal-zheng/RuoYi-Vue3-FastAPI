import { canonicalJson, sha256 } from '../../core/canonical-text'

export const TAILWIND_TARGET_BASELINES = [
  {
    name: 'tailwindcss',
    major: 3,
    exactTestVersion: '3.4.17',
    supportedRange: '>=3.4.0 <4.0.0',
  },
  {
    name: 'tailwindcss',
    major: 4,
    exactTestVersion: '4.2.4',
    supportedRange: '>=4.0.0 <5.0.0',
  },
] as const

export interface TailwindContractHashInput {
  readonly contractContentHash: `sha256:${string}`
  readonly mappingSchema: string
  readonly mappingVersion: string
  readonly mappingHash: `sha256:${string}`
  readonly artifacts: readonly Readonly<{
    path: string
    sha256: `sha256:${string}`
  }>[]
}

export function tailwindAdapterContractHash(
  input: TailwindContractHashInput
): `sha256:${string}` {
  return sha256(canonicalJson(input))
}
