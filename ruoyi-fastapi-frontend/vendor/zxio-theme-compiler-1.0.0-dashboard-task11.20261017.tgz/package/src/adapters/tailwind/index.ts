import {
  ArtifactGraphBuilder,
  type TailwindArtifactFile,
  type TailwindContractArtifactSet,
  artifactSetHash,
  decodeArtifactBytes,
  verifyArtifactFile,
} from '../../core/artifact-graph'
import {
  canonicalHash,
  canonicalJson,
  compareCodePoint,
  deepFreeze,
  sha256,
} from '../../core/canonical-text'
import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'
import {
  internalCssVariable,
  publicCssVariable,
} from '../../targets/css/css-variable'
import { tailwindMapping } from './mapping'
import {
  TAILWIND_TARGET_BASELINES,
  tailwindAdapterContractHash,
} from './contract-integrity'

import type {
  CompileTailwindContractOptions,
  ExternalTailwindAdapterContractRef,
  TailwindAdapterCoverage,
  TailwindAdapterManifestV1,
  TailwindMappingEntry,
  TailwindMappingTableV1,
  ValidatedExternalTailwindAdapterContractRef,
} from './model'

export type * from './model'
export { tailwindMapping }

const validatedRefs = new WeakSet<object>()
const targetBaselines = TAILWIND_TARGET_BASELINES

export function isValidatedTailwindContractRef(
  input: unknown
): input is ValidatedExternalTailwindAdapterContractRef {
  return typeof input === 'object' && input !== null && validatedRefs.has(input)
}

function targetName(entry: TailwindMappingEntry): string {
  return `${entry.namespace}.${entry.name}`
}

function validateMapping(
  options: CompileTailwindContractOptions
): CompilerResult<readonly TailwindAdapterCoverage[]> {
  const diagnostics = []
  const entries = Object.entries(options.contract.entries)
  const publicSet = new Set(entries.map(([path]) => path))
  const aliasKeys = Object.keys(options.cssAliases)
  const missingAliases = [...publicSet].filter(
    (path) => !Object.prototype.hasOwnProperty.call(options.cssAliases, path)
  )
  const extraAliases = aliasKeys.filter((path) => !publicSet.has(path))
  const invalidAliases = entries.flatMap(([path]) => {
    const alias = options.cssAliases[path]
    return alias &&
      alias.path === path &&
      alias.internalVariable === internalCssVariable(path) &&
      alias.publicVariable === publicCssVariable(path)
      ? []
      : [path]
  })
  if (
    missingAliases.length > 0 ||
    extraAliases.length > 0 ||
    invalidAliases.length > 0
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_MISSING',
        phase: 'adapter',
        adapter: 'tailwind',
        remediation: { code: 'RESTORE_EXACT_PUBLIC_CSS_ALIASES' },
        details: {
          missingAliases,
          extraAliases,
          invalidAliases,
        },
      })
    )
  }
  const sourceEntries = new Map<string, TailwindMappingEntry[]>()
  const targets = new Map<string, string[]>()
  for (const entry of options.mapping.entries) {
    sourceEntries.set(entry.source, [
      ...(sourceEntries.get(entry.source) ?? []),
      entry,
    ])
    const contractEntry = options.contract.entries[entry.source]
    if (!contractEntry || contractEntry.typeId !== entry.sourceType) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'tailwind',
          tokenPath: entry.source,
          remediation: { code: 'FIX_TAILWIND_SOURCE_OR_TYPE' },
          details: {
            expectedType: contractEntry?.typeId ?? null,
            actualType: entry.sourceType,
          },
        })
      )
    }
    if (entry.status === 'mapped') {
      if (!entry.namespace || !entry.name || entry.reasonCode) {
        diagnostics.push(
          diagnostic({
            code: 'TC_ADAPTER_MAPPING_MISSING',
            phase: 'adapter',
            adapter: 'tailwind',
            tokenPath: entry.source,
            remediation: { code: 'ADD_TAILWIND_NAMESPACE_AND_NAME' },
            details: { issue: 'mapped-target-required' },
          })
        )
      } else {
        const target = targetName(entry)
        targets.set(target, [...(targets.get(target) ?? []), entry.source])
      }
    } else if (entry.namespace || entry.name || !entry.reasonCode) {
      diagnostics.push(
        diagnostic({
          code: 'TC_ADAPTER_MAPPING_MISSING',
          phase: 'adapter',
          adapter: 'tailwind',
          tokenPath: entry.source,
          remediation: { code: 'ADD_UNSUPPORTED_REASON_ONLY' },
          details: { issue: 'invalid-unsupported' },
        })
      )
    }
  }
  const missing = [...publicSet].filter((path) => !sourceEntries.has(path))
  const extra = [...sourceEntries.keys()].filter((path) => !publicSet.has(path))
  const duplicates = [...sourceEntries.entries()]
    .filter(([, values]) => values.length > 1)
    .map(([source, values]) => ({ source, count: values.length }))
  const collisions = [...targets.entries()]
    .filter(([, sources]) => sources.length > 1)
    .map(([target, sources]) => ({ target, sources }))
  if (missing.length > 0 || extra.length > 0 || duplicates.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_MISSING',
        phase: 'adapter',
        adapter: 'tailwind',
        remediation: { code: 'PROVIDE_EXACT_TAILWIND_COVERAGE' },
        details: { missing, extra, duplicates },
      })
    )
  }
  if (collisions.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ADAPTER_MAPPING_COLLISION',
        phase: 'adapter',
        adapter: 'tailwind',
        remediation: { code: 'USE_UNIQUE_TAILWIND_TARGETS' },
        details: { collisions },
      })
    )
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  return success(
    options.mapping.entries.map((entry) => ({
      tokenPath: entry.source,
      status: entry.status,
      targets: entry.status === 'mapped' ? [targetName(entry)] : [],
      ...(entry.reasonCode ? { reasonCode: entry.reasonCode } : {}),
    }))
  )
}

const displayTailwindVariables: Readonly<
  Record<string, `--zx-display-${string}`>
> = {
  'semantic.typography.size-extra-small': '--zx-display-text-extra-small',
  'semantic.typography.size-small': '--zx-display-text-small',
  'semantic.typography.size-base': '--zx-display-text-body',
  'semantic.typography.size-medium': '--zx-display-text-medium',
  'semantic.typography.size-large': '--zx-display-text-large',
  'semantic.typography.size-extra-large': '--zx-display-text-title',
  'semantic.typography.line-height-base': '--zx-display-line-body',
  'semantic.spacing.control-y': '--zx-display-spacing-control-y',
}

function tailwindCssReference(entry: TailwindMappingEntry): string {
  const source = publicCssVariable(entry.source)
  const displayVariable = displayTailwindVariables[entry.source]
  return displayVariable
    ? `var(${displayVariable}, var(${source}))`
    : `var(${source})`
}

function v4Css(entries: readonly TailwindMappingEntry[]): string {
  const declarations = entries
    .filter((entry) => entry.status === 'mapped')
    .map(
      (entry) =>
        `  --${entry.namespace}-zx-${entry.name}: ${tailwindCssReference(
          entry
        )};`
    )
    .sort(compareCodePoint)
  return `/* @zxio/theme-tailwind contract; no theme values */\n@theme inline {\n${declarations.join(
    '\n'
  )}\n}\n`
}

function presetV3(entries: readonly TailwindMappingEntry[]): string {
  const namespaces: Record<string, Record<string, string>> = {}
  const presetNamespace: Readonly<Record<string, string>> = {
    color: 'colors',
    spacing: 'spacing',
    radius: 'borderRadius',
    shadow: 'boxShadow',
    font: 'fontFamily',
    text: 'fontSize',
    leading: 'lineHeight',
    duration: 'transitionDuration',
    number: 'zIndex',
  }
  for (const entry of entries) {
    if (entry.status !== 'mapped' || !entry.namespace || !entry.name) continue
    const namespaceName = presetNamespace[entry.namespace]
    const namespace = namespaces[namespaceName] ?? {}
    namespace[`zx-${entry.name}`] = tailwindCssReference(entry)
    namespaces[namespaceName] = namespace
  }
  const value = Object.fromEntries(
    Object.entries(namespaces)
      .sort(([left], [right]) => compareCodePoint(left, right))
      .map(([namespace, values]) => [
        namespace,
        Object.fromEntries(
          Object.entries(values).sort(([left], [right]) =>
            compareCodePoint(left, right)
          )
        ),
      ])
  )
  return `'use strict'\n\nconst deepFreeze = (value) => {\n  if (value && typeof value === 'object' && !Object.isFrozen(value)) {\n    for (const key of Object.keys(value)) deepFreeze(value[key])\n    Object.freeze(value)\n  }\n  return value\n}\n\nmodule.exports = deepFreeze({ theme: { extend: ${JSON.stringify(
    value,
    null,
    2
  )} } })\n`
}

function makeExternalRef(
  manifest: TailwindAdapterManifestV1,
  manifestFile: TailwindArtifactFile,
  packageVersion: string
): ValidatedExternalTailwindAdapterContractRef {
  const ref: ExternalTailwindAdapterContractRef = {
    name: '@zxio/theme-tailwind',
    version: manifest.adapter.version,
    contractContentHash: manifest.adapter.contractContentHash,
    mappingSchema: manifest.adapter.mappingSchema,
    mappingVersion: manifest.adapter.mappingVersion,
    mappingHash: manifest.adapter.mappingHash,
    targetBaselines: manifest.targetBaselines.map((entry) => ({ ...entry })),
    adapterContractHash: manifest.adapter.adapterContractHash,
    manifest: {
      packageName: '@zxio/theme-tailwind',
      packageVersion,
      exportPath: './manifest.json',
      path: 'generated/adapter.manifest.json',
      sha256: manifestFile.sha256,
    },
    artifacts: manifest.artifacts.map((artifact) => ({
      packageName: '@zxio/theme-tailwind',
      packageVersion,
      exportPath: artifact.exportPath,
      path: artifact.path,
      sha256: artifact.sha256,
    })),
    coverage: manifest.coverage.map((entry) => ({
      tokenPath: entry.tokenPath,
      status: entry.status === 'mapped' ? 'mapped' : 'not-applicable',
      targets: [...entry.targets],
      ...(entry.reasonCode ? { reasonCode: entry.reasonCode } : {}),
    })),
  }
  const frozen = deepFreeze(ref) as ValidatedExternalTailwindAdapterContractRef
  validatedRefs.add(frozen)
  return frozen
}

export function compileTailwindContract(
  options: CompileTailwindContractOptions
): CompilerResult<
  TailwindContractArtifactSet<
    TailwindAdapterManifestV1,
    ValidatedExternalTailwindAdapterContractRef
  >
> {
  const coverage = validateMapping(options)
  if (!coverage.ok) return failure(coverage.diagnostics)
  const graph = new ArtifactGraphBuilder<
    'tailwind-v4-css' | 'tailwind-v3-preset'
  >()
  graph.addText({
    path: 'v4.css',
    mediaType: 'text/css',
    purpose: 'tailwind-v4-css',
    loadPhase: 'contract',
    text: v4Css(options.mapping.entries),
  })
  graph.addText({
    path: 'preset-v3.cjs',
    mediaType: 'text/javascript',
    purpose: 'tailwind-v3-preset',
    loadPhase: 'contract',
    text: presetV3(options.mapping.entries),
  })
  const built = graph.finalize()
  if (!built.ok) return failure(built.diagnostics)
  const mappingHash = sha256(canonicalJson(options.mapping))
  const contractInput = {
    contractContentHash: canonicalHash(options.contract),
    mappingSchema: options.mapping.schema,
    mappingVersion: options.mapping.version,
    mappingHash,
    artifacts: built.value.map(({ path, sha256: hash }) => ({
      path,
      sha256: hash,
    })),
  }
  const adapterContractHash = tailwindAdapterContractHash(contractInput)
  const manifest: TailwindAdapterManifestV1 = {
    schema: 'zx.tailwind-adapter-manifest/1',
    adapter: {
      name: '@zxio/theme-tailwind',
      version: options.mapping.version,
      contractContentHash: contractInput.contractContentHash,
      mappingSchema: options.mapping.schema,
      mappingVersion: options.mapping.version,
      mappingHash,
      adapterContractHash,
    },
    targetBaselines,
    artifacts: built.value.map((file) => ({
      exportPath: file.path === 'v4.css' ? './v4.css' : './preset-v3',
      path:
        file.path === 'v4.css' ? 'generated/v4.css' : 'generated/preset-v3.cjs',
      mediaType: file.mediaType,
      bytes: file.byteLength,
      sha256: file.sha256,
    })),
    coverage: coverage.value,
  }
  const manifestGraph = new ArtifactGraphBuilder<'tailwind-manifest'>()
  manifestGraph.addJson({
    path: 'adapter.manifest.json',
    mediaType: 'application/json',
    purpose: 'tailwind-manifest',
    loadPhase: 'contract',
    value: manifest,
  })
  const manifestBuilt = manifestGraph.finalize()
  if (!manifestBuilt.ok) return failure(manifestBuilt.diagnostics)
  const files = [...built.value, ...manifestBuilt.value].sort((left, right) =>
    compareCodePoint(left.path, right.path)
  ) as readonly TailwindArtifactFile[]
  const externalRef = makeExternalRef(
    manifest,
    manifestBuilt.value[0],
    options.package.packageVersion
  )
  return verifyTailwindContractArtifactSet({
    kind: 'tailwind-contract',
    contractContentHash: manifest.adapter.contractContentHash,
    files,
    manifest,
    externalRef,
    artifactSetHash: artifactSetHash(files),
  })
}

function isPlainExactRecord(input: unknown, keys: readonly string[]): boolean {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return false
  const prototype = Object.getPrototypeOf(input)
  if (prototype !== Object.prototype && prototype !== null) return false
  const actual = Object.keys(input).sort(compareCodePoint)
  if (canonicalJson(actual) !== canonicalJson([...keys].sort(compareCodePoint)))
    return false
  return actual.every((key) => {
    const descriptor = Object.getOwnPropertyDescriptor(input, key)
    return !!descriptor && 'value' in descriptor
  })
}

function hasExactTailwindManifestShape(input: unknown): boolean {
  if (
    !isPlainExactRecord(input, [
      'adapter',
      'artifacts',
      'coverage',
      'schema',
      'targetBaselines',
    ])
  )
    return false
  const manifest = input as Readonly<Record<string, unknown>>
  if (
    !isPlainExactRecord(manifest.adapter, [
      'adapterContractHash',
      'contractContentHash',
      'mappingHash',
      'mappingSchema',
      'mappingVersion',
      'name',
      'version',
    ]) ||
    !Array.isArray(manifest.targetBaselines) ||
    !manifest.targetBaselines.every((entry) =>
      isPlainExactRecord(entry, [
        'exactTestVersion',
        'major',
        'name',
        'supportedRange',
      ])
    ) ||
    !Array.isArray(manifest.artifacts) ||
    !manifest.artifacts.every((entry) =>
      isPlainExactRecord(entry, [
        'bytes',
        'exportPath',
        'mediaType',
        'path',
        'sha256',
      ])
    ) ||
    !Array.isArray(manifest.coverage)
  )
    return false
  return manifest.coverage.every((entry) => {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry))
      return false
    const value = entry as Readonly<Record<string, unknown>>
    return isPlainExactRecord(entry, [
      'tokenPath',
      'status',
      'targets',
      ...(value.reasonCode === undefined ? [] : ['reasonCode']),
    ])
  })
}

function hasExactTailwindFileMetadata(file: TailwindArtifactFile): boolean {
  if (file.path === 'adapter.manifest.json') {
    return (
      file.purpose === 'tailwind-manifest' &&
      file.mediaType === 'application/json' &&
      file.loadPhase === 'contract'
    )
  }
  if (file.path === 'preset-v3.cjs') {
    return (
      file.purpose === 'tailwind-v3-preset' &&
      file.mediaType === 'text/javascript' &&
      file.loadPhase === 'contract'
    )
  }
  if (file.path === 'v4.css') {
    return (
      file.purpose === 'tailwind-v4-css' &&
      file.mediaType === 'text/css' &&
      file.loadPhase === 'contract'
    )
  }
  return false
}

function verifyTailwindContractArtifactSetInternal(
  input: unknown
): CompilerResult<
  TailwindContractArtifactSet<
    TailwindAdapterManifestV1,
    ValidatedExternalTailwindAdapterContractRef
  >
> {
  if (!input || typeof input !== 'object') {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_TAILWIND_ARTIFACT_SET' },
        details: { issue: 'not-object' },
      }),
    ])
  }
  const candidate = input as Partial<
    TailwindContractArtifactSet<
      TailwindAdapterManifestV1,
      ExternalTailwindAdapterContractRef
    >
  >
  const manifestIsRecord =
    !!candidate.manifest &&
    typeof candidate.manifest === 'object' &&
    !Array.isArray(candidate.manifest)
  const externalRefIsRecord =
    !!candidate.externalRef &&
    typeof candidate.externalRef === 'object' &&
    !Array.isArray(candidate.externalRef)
  const externalManifest = externalRefIsRecord
    ? candidate.externalRef.manifest
    : undefined
  const externalManifestIsRecord =
    !!externalManifest &&
    typeof externalManifest === 'object' &&
    !Array.isArray(externalManifest)
  const topLevelKeys = Object.keys(candidate).sort(compareCodePoint)
  const expectedTopLevelKeys = [
    'artifactSetHash',
    'contractContentHash',
    'externalRef',
    'files',
    'kind',
    'manifest',
  ]
  if (
    candidate.kind !== 'tailwind-contract' ||
    !Array.isArray(candidate.files) ||
    !manifestIsRecord ||
    !externalRefIsRecord ||
    !externalManifestIsRecord ||
    JSON.stringify(topLevelKeys) !== JSON.stringify(expectedTopLevelKeys)
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_TAILWIND_ARTIFACT_SET' },
        details: { issue: 'invalid-shape' },
      }),
    ])
  }
  const files = candidate.files as readonly TailwindArtifactFile[]
  const diagnostics = files.flatMap((file) => {
    const result = verifyArtifactFile(file)
    return result.ok ? [] : result.diagnostics
  })
  if (diagnostics.length > 0) return failure(diagnostics)
  const expectedPaths = ['adapter.manifest.json', 'preset-v3.cjs', 'v4.css']
  if (
    canonicalJson(files.map((file) => file.path)) !==
      canonicalJson(expectedPaths) ||
    new Set(files.map((file) => file.path)).size !== files.length ||
    files.some((file) => !hasExactTailwindFileMetadata(file))
  ) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        remediation: { code: 'RESTORE_EXACT_TAILWIND_OWNER_SET' },
        details: {
          expectedPaths,
          actualPaths: files.map((file) => file.path),
        },
      }),
    ])
  }
  const manifest = candidate.manifest
  if (!hasExactTailwindManifestShape(manifest)) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        remediation: { code: 'RESTORE_EXACT_TAILWIND_MANIFEST_SHAPE' },
        details: { issue: 'invalid-tailwind-manifest-shape' },
      }),
    ])
  }
  const manifestFile = files[0]
  const manifestText = new TextDecoder().decode(
    decodeArtifactBytes(manifestFile.bytes)
  )
  const expectedManifestText = canonicalJson(manifest)
  const manifestArtifacts = Array.isArray(manifest.artifacts)
    ? manifest.artifacts
    : []
  const coverage = Array.isArray(manifest.coverage) ? manifest.coverage : []
  const coveragePaths = coverage.map((entry) => entry.tokenPath)
  const coverageValid =
    new Set(coveragePaths).size === coveragePaths.length &&
    canonicalJson(coveragePaths) ===
      canonicalJson([...coveragePaths].sort(compareCodePoint)) &&
    coverage.every(
      (entry) =>
        typeof entry.tokenPath === 'string' &&
        ((entry.status === 'mapped' &&
          entry.targets.length === 1 &&
          !entry.reasonCode) ||
          (entry.status === 'unsupported' &&
            entry.targets.length === 0 &&
            typeof entry.reasonCode === 'string'))
    )
  const artifactsValid =
    manifestArtifacts.length === 2 &&
    manifestArtifacts.every((artifact, index) => {
      const expectedFile = files[index + 1]
      const expectedPath =
        expectedFile.path === 'v4.css'
          ? 'generated/v4.css'
          : 'generated/preset-v3.cjs'
      const expectedExport =
        expectedFile.path === 'v4.css' ? './v4.css' : './preset-v3'
      return (
        artifact.path === expectedPath &&
        artifact.exportPath === expectedExport &&
        artifact.mediaType === expectedFile.mediaType &&
        artifact.bytes === expectedFile.byteLength &&
        artifact.sha256 === expectedFile.sha256
      )
    })
  const contractInput = {
    contractContentHash: manifest.adapter?.contractContentHash,
    mappingSchema: manifest.adapter?.mappingSchema,
    mappingVersion: manifest.adapter?.mappingVersion,
    mappingHash: manifest.adapter?.mappingHash,
    artifacts: manifestArtifacts.map((artifact) => ({
      path: artifact.path === 'generated/v4.css' ? 'v4.css' : 'preset-v3.cjs',
      sha256: artifact.sha256,
    })),
  }
  const expectedContractHash = sha256(canonicalJson(contractInput))
  const expectedSetHash = artifactSetHash(files)
  const baselinesValid =
    canonicalJson(manifest.targetBaselines) === canonicalJson(targetBaselines)
  const manifestValid =
    manifest.schema === 'zx.tailwind-adapter-manifest/1' &&
    manifest.adapter?.name === '@zxio/theme-tailwind' &&
    manifestText === expectedManifestText &&
    manifest.adapter.adapterContractHash === expectedContractHash &&
    candidate.contractContentHash === manifest.adapter.contractContentHash &&
    candidate.artifactSetHash === expectedSetHash &&
    artifactsValid &&
    coverageValid &&
    baselinesValid
  if (!manifestValid) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        remediation: { code: 'RESTORE_VERIFIED_TAILWIND_CONTRACT' },
        expected: expectedContractHash,
        actual: manifest.adapter?.adapterContractHash,
        details: {
          manifestBytesMatch: manifestText === expectedManifestText,
          artifactsValid,
          coverageValid,
          baselinesValid,
          artifactSetHashMatch: candidate.artifactSetHash === expectedSetHash,
        },
      }),
    ])
  }
  if (!/^\d+\.\d+\.\d+$/.test(candidate.externalRef.manifest.packageVersion)) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        remediation: { code: 'RESTORE_TAILWIND_PACKAGE_VERSION' },
        details: {
          packageVersion: candidate.externalRef.manifest.packageVersion,
        },
      }),
    ])
  }
  const externalRef = makeExternalRef(
    manifest,
    manifestFile,
    candidate.externalRef.manifest.packageVersion
  )
  if (canonicalJson(candidate.externalRef) !== canonicalJson(externalRef)) {
    return failure([
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        remediation: { code: 'RESTORE_TAILWIND_MANIFEST_REF' },
        details: { issue: 'external-ref-mismatch' },
      }),
    ])
  }
  const copiedFiles = files.map((file) => ({
    ...file,
  })) as readonly TailwindArtifactFile[]
  const copiedManifest = JSON.parse(
    expectedManifestText
  ) as TailwindAdapterManifestV1
  return success({
    kind: 'tailwind-contract',
    contractContentHash: manifest.adapter.contractContentHash,
    files: copiedFiles,
    manifest: copiedManifest,
    externalRef,
    artifactSetHash: expectedSetHash,
  })
}

export function verifyTailwindContractArtifactSet(
  input: unknown
): CompilerResult<
  TailwindContractArtifactSet<
    TailwindAdapterManifestV1,
    ValidatedExternalTailwindAdapterContractRef
  >
> {
  try {
    return verifyTailwindContractArtifactSetInternal(input)
  } catch (error) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_TAILWIND_ARTIFACT_SET' },
        details: {
          issue: 'malformed-nested-structure',
          error: error instanceof Error ? error.name : 'UnknownError',
        },
      }),
    ])
  }
}

export const defaultTailwindMapping: TailwindMappingTableV1 = tailwindMapping
