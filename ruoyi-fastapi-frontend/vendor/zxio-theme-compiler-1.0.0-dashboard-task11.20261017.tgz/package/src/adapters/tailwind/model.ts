import type {
  AuthorCanonicalTokenPath,
  BuiltInTypeId,
  ValidatedThemePublicContractV4,
} from '@zxio/tokens/kernel'
import type { CompilePackageMetadata } from '../../model'
import type { PublicCssAliasRegistry } from '../../targets/css/css-variable'

export interface TailwindMappingEntry {
  readonly source: AuthorCanonicalTokenPath
  readonly sourceType: BuiltInTypeId
  readonly status: 'mapped' | 'unsupported'
  readonly namespace?:
    | 'color'
    | 'spacing'
    | 'radius'
    | 'shadow'
    | 'font'
    | 'text'
    | 'leading'
    | 'duration'
    | 'number'
  readonly name?: string
  readonly reasonCode?:
    | 'NO_TAILWIND_NAMESPACE'
    | 'COMPOSITE_NOT_EXPOSED'
    | 'ZX_ONLY_BEHAVIOR'
}

export interface TailwindMappingTableV1 {
  readonly schema: 'zx.tailwind-mapping/1'
  readonly version: string
  readonly entries: readonly TailwindMappingEntry[]
}

export interface TailwindAdapterCoverage {
  readonly tokenPath: AuthorCanonicalTokenPath
  readonly status: 'mapped' | 'unsupported'
  readonly targets: readonly string[]
  readonly reasonCode?: string
}

export interface TailwindAdapterManifestV1 {
  readonly schema: 'zx.tailwind-adapter-manifest/1'
  readonly adapter: Readonly<{
    name: '@zxio/theme-tailwind'
    version: string
    contractContentHash: `sha256:${string}`
    mappingSchema: string
    mappingVersion: string
    mappingHash: `sha256:${string}`
    adapterContractHash: `sha256:${string}`
  }>
  readonly targetBaselines: readonly Readonly<{
    name: 'tailwindcss'
    major: 3 | 4
    exactTestVersion: string
    supportedRange: string
  }>[]
  readonly artifacts: readonly Readonly<{
    exportPath: './v4.css' | './preset-v3'
    path: 'generated/v4.css' | 'generated/preset-v3.cjs'
    mediaType: string
    bytes: number
    sha256: `sha256:${string}`
  }>[]
  readonly coverage: readonly TailwindAdapterCoverage[]
}

export interface ExternalPackageArtifactRef {
  readonly packageName: '@zxio/theme-tailwind'
  readonly packageVersion: string
  readonly exportPath: './v4.css' | './preset-v3' | './manifest.json'
  readonly path:
    | 'generated/v4.css'
    | 'generated/preset-v3.cjs'
    | 'generated/adapter.manifest.json'
  readonly sha256: `sha256:${string}`
}

export interface ExternalTailwindAdapterContractRef {
  readonly name: '@zxio/theme-tailwind'
  readonly version: string
  readonly contractContentHash: `sha256:${string}`
  readonly mappingSchema: string
  readonly mappingVersion: string
  readonly mappingHash: `sha256:${string}`
  readonly targetBaselines: TailwindAdapterManifestV1['targetBaselines']
  readonly adapterContractHash: `sha256:${string}`
  readonly manifest: ExternalPackageArtifactRef & {
    readonly exportPath: './manifest.json'
  }
  readonly artifacts: readonly ExternalPackageArtifactRef[]
  readonly coverage: readonly Readonly<{
    tokenPath: AuthorCanonicalTokenPath
    status: 'mapped' | 'not-applicable'
    targets: readonly string[]
    reasonCode?: string
  }>[]
}

declare const validatedTailwindContractRefBrand: unique symbol
export type ValidatedExternalTailwindAdapterContractRef =
  ExternalTailwindAdapterContractRef & {
    readonly [validatedTailwindContractRefBrand]: true
  }

export interface CompileTailwindContractOptions {
  readonly contract: ValidatedThemePublicContractV4
  readonly mapping: TailwindMappingTableV1
  readonly cssAliases: PublicCssAliasRegistry
  readonly package: CompilePackageMetadata
}
