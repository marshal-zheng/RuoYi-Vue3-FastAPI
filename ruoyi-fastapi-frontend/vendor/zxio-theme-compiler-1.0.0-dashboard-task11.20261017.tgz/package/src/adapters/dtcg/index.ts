import {
  canonicalJson,
  canonicalize,
  compareCodePoint,
  deepFreeze,
  sha256,
} from '../../core/canonical-text'
import {
  type DiagnosticInput,
  type ThemeCompilerDiagnostic,
  diagnostic as baseDiagnostic,
} from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'
import {
  DTCG_ADAPTER_VERSION,
  DTCG_MEDIA_TYPE,
  DTCG_SCHEMA_URI,
  DTCG_SPEC_VERSION,
  type DtcgImportRequest,
  type DtcgImportResult,
  type DtcgReexportRequest,
  type DtcgReexportResult,
} from './model'
import {
  DTCG_TO_KERNEL_TYPE,
  KERNEL_TO_DTCG_TYPE,
  fromDtcgValue,
  toDtcgValue,
} from './value-mapping'

import type {
  AdapterArtifactContribution,
  AdapterCoverage,
  AdapterTextArtifact,
  ThemeAdapter,
  ThemeAdapterContext,
} from '../types'
import type {
  BuiltInTypeId,
  CanonicalGradient,
  CanonicalJsonValue,
  CanonicalTokenPath,
  ThemeSourceAuthorInput,
} from '@zxio/tokens/kernel'

export * from './model'
export { DTCG_TO_KERNEL_TYPE, KERNEL_TO_DTCG_TYPE, fromDtcgValue, toDtcgValue }

interface FlatToken {
  readonly segments: readonly string[]
  readonly jsonPath: string
  readonly type?: string
  readonly value: unknown
  readonly deprecated?: unknown
  readonly reference?: string
  readonly extensions?: Readonly<Record<string, unknown>>
}

const DTCG_2025_10_TYPES = new Set([
  'border',
  'color',
  'cubicBezier',
  'dimension',
  'duration',
  'fontFamily',
  'fontWeight',
  'gradient',
  'number',
  'shadow',
  'strokeStyle',
  'transition',
  'typography',
  // The ZX contract deliberately retains the explicit string mapping frozen
  // in this Spec even though it is not a value type in the official schema.
  'string',
])

function diagnostic(input: DiagnosticInput): ThemeCompilerDiagnostic {
  const details = input.details ?? {}
  return baseDiagnostic({
    ...input,
    schemaVersion: input.schemaVersion ?? DTCG_SPEC_VERSION,
    expected: input.expected ?? null,
    actual: input.actual ?? null,
    target: input.target ?? 'DTCG Format Module 2025.10',
    details: {
      reasonCode:
        typeof details.issue === 'string' ? details.issue : input.code,
      ...details,
    },
  })
}

function isRecord(input: unknown): input is Readonly<Record<string, unknown>> {
  return !!input && typeof input === 'object' && !Array.isArray(input)
}

function parseDocument(
  request: DtcgImportRequest
): CompilerResult<Readonly<Record<string, unknown>>> {
  let value: unknown = request.document
  if (value instanceof Uint8Array) {
    const maximum = request.maxBytes ?? 1_048_576
    if (value.byteLength > maximum) {
      return failure([
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: '$',
          expected: maximum,
          actual: value.byteLength,
          target: 'DTCG UTF-8 document',
          remediation: { code: 'REDUCE_DTCG_DOCUMENT_SIZE' },
          details: { maximum, actual: value.byteLength },
        }),
      ])
    }
    try {
      value = JSON.parse(
        new TextDecoder('utf-8', { fatal: true }).decode(value)
      ) as unknown
    } catch (error) {
      return failure([
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: '$',
          target: 'DTCG UTF-8 JSON',
          remediation: { code: 'PROVIDE_VALID_UTF8_JSON' },
          details: {
            reason: error instanceof Error ? error.message : String(error),
          },
        }),
      ])
    }
  }
  if (
    request.maxDepth !== undefined &&
    (!Number.isSafeInteger(request.maxDepth) ||
      request.maxDepth < 1 ||
      request.maxDepth > 256)
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$',
        expected: 'integer 1..256',
        actual: typeof request.maxDepth === 'number' ? request.maxDepth : null,
        target: 'DTCG maximum traversal depth',
        remediation: { code: 'USE_BOUNDED_DTCG_DEPTH' },
        details: { issue: 'invalid-max-depth' },
      }),
    ])
  }
  if (isRecord(value)) {
    if (value.$schema !== DTCG_SCHEMA_URI) {
      return failure([
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: '$.$schema',
          expected: DTCG_SCHEMA_URI,
          actual: typeof value.$schema === 'string' ? value.$schema : null,
          target: 'DTCG Format Module 2025.10 schema',
          remediation: { code: 'USE_DTCG_2025_10_SCHEMA' },
          details: { issue: 'incompatible-dtcg-schema' },
        }),
      ])
    }
    try {
      return success(canonicalize(value) as Readonly<Record<string, unknown>>)
    } catch {
      return failure([
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: '$',
          target: 'canonical DTCG JSON document',
          remediation: { code: 'USE_CANONICAL_JSON_DOCUMENT' },
          details: { issue: 'document-not-canonical-json' },
        }),
      ])
    }
  }
  return failure([
    diagnostic({
      code: 'TC_INPUT_INVALID',
      phase: 'adapter',
      adapter: 'dtcg',
      source: request.sourceLocation,
      schemaVersion: DTCG_SPEC_VERSION,
      jsonPath: '$',
      expected: 'object',
      actual: Array.isArray(value) ? 'array' : typeof value,
      target: 'DTCG document',
      remediation: { code: 'PROVIDE_DTCG_OBJECT' },
      details: { issue: 'root-not-object' },
    }),
  ])
}

function flattenTokens(
  input: Readonly<Record<string, unknown>>,
  inheritedType: string | undefined,
  segments: readonly string[],
  jsonPath: string,
  output: FlatToken[],
  extensions: Record<string, CanonicalJsonValue>,
  diagnostics: ReturnType<typeof diagnostic>[],
  source: DtcgImportRequest['sourceLocation'],
  depth: number,
  maximumDepth: number
): void {
  if (depth > maximumDepth) {
    diagnostics.push(
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath,
        expected: maximumDepth,
        actual: depth,
        target: 'DTCG traversal depth',
        remediation: { code: 'REDUCE_DTCG_NESTING' },
        details: { issue: 'maximum-depth-exceeded' },
      })
    )
    return
  }
  const isToken = '$value' in input || '$ref' in input
  const allowedReserved = new Set(
    isToken
      ? [
          '$value',
          '$ref',
          '$type',
          '$description',
          '$deprecated',
          '$extensions',
        ]
      : [
          ...(jsonPath === '$' ? ['$schema'] : []),
          '$type',
          '$description',
          '$deprecated',
          '$extensions',
          '$extends',
        ]
  )
  const invalidReserved = Object.keys(input).filter(
    (key) => key.startsWith('$') && !allowedReserved.has(key)
  )
  const childKeys = Object.keys(input).filter((key) => !key.startsWith('$'))
  const invalidChildren = childKeys.filter(
    (key) =>
      key.startsWith('$') ||
      key.includes('.') ||
      key.includes('{') ||
      key.includes('}')
  )
  const nonObjectChildren = childKeys.filter((key) => !isRecord(input[key]))
  const invalidType =
    '$type' in input &&
    (typeof input.$type !== 'string' || !DTCG_2025_10_TYPES.has(input.$type))
  const invalidReference =
    '$ref' in input &&
    (typeof input.$ref !== 'string' || !input.$ref.startsWith('#/'))
  if (
    invalidReserved.length > 0 ||
    invalidChildren.length > 0 ||
    nonObjectChildren.length > 0 ||
    (isToken && childKeys.length > 0) ||
    ('$value' in input && '$ref' in input) ||
    (jsonPath === '$' && isToken) ||
    (jsonPath !== '$' && '$schema' in input) ||
    ('$description' in input && typeof input.$description !== 'string') ||
    invalidType ||
    invalidReference ||
    ('$deprecated' in input &&
      typeof input.$deprecated !== 'boolean' &&
      typeof input.$deprecated !== 'string') ||
    ('$extensions' in input && !isRecord(input.$extensions)) ||
    '$extends' in input
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath,
        target: 'DTCG Format Module 2025.10 object schema',
        remediation: { code: 'FIX_DTCG_OBJECT_SCHEMA' },
        details: {
          issue: 'invalid-dtcg-object-shape',
          invalidReserved,
          invalidChildren,
          nonObjectChildren,
          tokenHasChildren: isToken && childKeys.length > 0,
          rootIsToken: jsonPath === '$' && isToken,
          mixedValueAndRef: '$value' in input && '$ref' in input,
          invalidType,
          invalidReference,
          groupExtendsUnsupported: '$extends' in input,
          rootTokenUnsupported: '$root' in input,
        },
      })
    )
  }
  const groupType =
    typeof input.$type === 'string' ? input.$type : inheritedType
  if ('$extensions' in input) {
    try {
      extensions[`${jsonPath}.$extensions`] = canonicalize(input.$extensions)
    } catch {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_EXTENSION_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: `${jsonPath}.$extensions`,
          target: 'DTCG extensions',
          remediation: { code: 'USE_CANONICAL_JSON_EXTENSION' },
          details: { issue: 'extension-not-canonical' },
        })
      )
    }
  }
  if (isToken) {
    output.push({
      segments,
      jsonPath,
      type: typeof input.$type === 'string' ? input.$type : groupType,
      value: '$value' in input ? input.$value : input.$ref,
      deprecated: input.$deprecated,
      ...('$ref' in input && typeof input.$ref === 'string'
        ? { reference: input.$ref }
        : {}),
      ...('$extensions' in input && isRecord(input.$extensions)
        ? { extensions: input.$extensions }
        : {}),
    })
    return
  }
  for (const [key, value] of Object.entries(input).sort(([left], [right]) =>
    compareCodePoint(left, right)
  )) {
    if (key.startsWith('$')) continue
    if (isRecord(value)) {
      flattenTokens(
        value,
        groupType,
        [...segments, key],
        `${jsonPath}.${key}`,
        output,
        extensions,
        diagnostics,
        source,
        depth + 1,
        maximumDepth
      )
    }
  }
}

function parseAliasTarget(
  token: FlatToken,
  targetLayer: DtcgImportRequest['targetLayer'],
  source: DtcgImportRequest['sourceLocation'],
  diagnostics: ReturnType<typeof diagnostic>[]
): string | undefined {
  const tokenPath = `${targetLayer}.${token.segments.join(
    '.'
  )}` as CanonicalTokenPath
  const raw =
    token.reference ??
    (typeof token.value === 'string' && token.value.startsWith('{')
      ? token.value
      : undefined)
  if (raw === undefined) return undefined
  if (token.reference !== undefined) {
    if (!raw.startsWith('#/')) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_VALUE_UNREPRESENTABLE',
          phase: 'adapter',
          adapter: 'dtcg',
          source,
          tokenPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: `${token.jsonPath}.$ref`,
          expected: '#/token/path or #/token/path/$value',
          actual: raw,
          target: 'DTCG JSON Pointer token reference',
          remediation: { code: 'USE_LOCAL_DTCG_TOKEN_POINTER' },
          details: { issue: 'invalid-json-pointer-reference' },
        })
      )
      return undefined
    }
    const segments = raw
      .slice(2)
      .split('/')
      .map((segment) => segment.replace(/~1/g, '/').replace(/~0/g, '~'))
    const valueIndex = segments.indexOf('$value')
    if (
      (valueIndex >= 0 && valueIndex !== segments.length - 1) ||
      segments.some(
        (segment, index) =>
          segment.length === 0 ||
          (segment.startsWith('$') &&
            !(segment === '$value' && index === segments.length - 1))
      )
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_VALUE_UNREPRESENTABLE',
          phase: 'adapter',
          adapter: 'dtcg',
          source,
          tokenPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: `${token.jsonPath}.$ref`,
          target: 'complete DTCG token reference',
          remediation: { code: 'REFERENCE_COMPLETE_DTCG_TOKEN' },
          details: { issue: 'property-level-reference-not-importable', raw },
        })
      )
      return undefined
    }
    return (valueIndex >= 0 ? segments.slice(0, -1) : segments).join('.')
  }
  const match = /^\{([^{}]+)\}$/.exec(raw)
  if (
    !match ||
    match[1]!
      .split('.')
      .some(
        (segment) =>
          segment.length === 0 ||
          segment.startsWith('$') ||
          segment.includes('{') ||
          segment.includes('}')
      )
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_DTCG_VALUE_UNREPRESENTABLE',
        phase: 'adapter',
        adapter: 'dtcg',
        source,
        tokenPath,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: `${token.jsonPath}.$value`,
        target: 'DTCG curly-brace token reference',
        remediation: { code: 'USE_VALID_DTCG_TOKEN_ALIAS' },
        details: { issue: 'invalid-curly-reference', raw },
      })
    )
    return undefined
  }
  return match[1]
}

function resolveAliasTypes(
  tokens: readonly FlatToken[],
  targetLayer: DtcgImportRequest['targetLayer'],
  source: DtcgImportRequest['sourceLocation'],
  maximumDepth: number,
  diagnostics: ReturnType<typeof diagnostic>[]
): Readonly<{
  types: ReadonlyMap<string, string>
  targets: ReadonlyMap<string, string>
}> {
  const byPath = new Map(
    tokens.map((token) => [token.segments.join('.'), token])
  )
  const types = new Map<string, string>()
  const targets = new Map<string, string>()
  const resolving = new Set<string>()
  const resolveType = (path: string, depth: number): string | undefined => {
    const cached = types.get(path)
    if (cached) return cached
    const token = byPath.get(path)
    if (!token) return undefined
    const tokenPath = `${targetLayer}.${path}` as CanonicalTokenPath
    if (depth > maximumDepth) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_VALUE_UNREPRESENTABLE',
          phase: 'adapter',
          adapter: 'dtcg',
          source,
          tokenPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: token.jsonPath,
          expected: maximumDepth,
          actual: depth,
          target: 'DTCG alias chain depth',
          remediation: { code: 'SHORTEN_DTCG_ALIAS_CHAIN' },
          details: { issue: 'alias-depth-exceeded', path },
        })
      )
      return undefined
    }
    if (resolving.has(path)) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_VALUE_UNREPRESENTABLE',
          phase: 'adapter',
          adapter: 'dtcg',
          source,
          tokenPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: token.jsonPath,
          target: 'acyclic DTCG alias graph',
          remediation: { code: 'BREAK_DTCG_ALIAS_CYCLE' },
          details: {
            issue: 'alias-cycle',
            cycle: [...resolving, path],
          },
        })
      )
      return undefined
    }
    resolving.add(path)
    const target = parseAliasTarget(token, targetLayer, source, diagnostics)
    let resolved = token.type
    if (target !== undefined) {
      targets.set(path, target)
      const targetToken = byPath.get(target)
      if (!targetToken) {
        diagnostics.push(
          diagnostic({
            code: 'TC_DTCG_VALUE_UNREPRESENTABLE',
            phase: 'adapter',
            adapter: 'dtcg',
            source,
            tokenPath,
            schemaVersion: DTCG_SPEC_VERSION,
            jsonPath: token.jsonPath,
            target: 'existing DTCG token alias target',
            remediation: { code: 'FIX_DTCG_ALIAS_TARGET' },
            details: {
              issue: 'alias-target-missing',
              path,
              aliasTarget: target,
            },
          })
        )
      } else {
        const targetType = resolveType(target, depth + 1)
        if (resolved && targetType && resolved !== targetType) {
          diagnostics.push(
            diagnostic({
              code: 'TC_DTCG_TYPE_UNSUPPORTED',
              phase: 'adapter',
              adapter: 'dtcg',
              source,
              tokenPath,
              schemaVersion: DTCG_SPEC_VERSION,
              jsonPath: `${token.jsonPath}.$type`,
              expected: targetType,
              actual: resolved,
              target: 'DTCG alias target type',
              remediation: { code: 'MATCH_DTCG_ALIAS_TYPE' },
              details: {
                issue: 'alias-type-mismatch',
                path,
                aliasTarget: target,
              },
            })
          )
        }
        resolved ??= targetType
      }
    }
    resolving.delete(path)
    if (resolved) types.set(path, resolved)
    return resolved
  }
  for (const path of [...byPath.keys()].sort(compareCodePoint)) {
    resolveType(path, 0)
  }
  return { types, targets }
}

// eslint-disable-next-line camelcase -- the versioned public API mirrors DTCG 2025.10
export function importDtcg2025_10(
  request: DtcgImportRequest
): CompilerResult<DtcgImportResult> {
  const parsed = parseDocument(request)
  if (!parsed.ok) return failure(parsed.diagnostics)
  const flat: FlatToken[] = []
  const extensions: Record<string, CanonicalJsonValue> = {}
  const diagnostics: ReturnType<typeof diagnostic>[] = []
  const maximumDepth = request.maxDepth ?? 64
  flattenTokens(
    parsed.value,
    undefined,
    [],
    '$',
    flat,
    extensions,
    diagnostics,
    request.sourceLocation,
    0,
    maximumDepth
  )
  if (
    request.passthroughPolicy === 'reject' &&
    Object.keys(extensions).length > 0
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_DTCG_EXTENSION_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$',
        target: 'DTCG extensions',
        remediation: { code: 'ENABLE_EXPLICIT_EXTENSION_PRESERVATION' },
        details: {
          extensionPaths: Object.keys(extensions).sort(compareCodePoint),
        },
      })
    )
  }
  const aliases = resolveAliasTypes(
    flat,
    request.targetLayer,
    request.sourceLocation,
    maximumDepth,
    diagnostics
  )
  const records: Record<string, unknown> = {}
  const sourceMap: Record<string, typeof request.sourceLocation> = {}
  const lifecycleOutput: Record<
    string,
    Readonly<{
      status: 'stable' | 'experimental' | 'deprecated'
      deprecated?: boolean | string
    }>
  > = {}
  for (const token of flat) {
    const localName = token.segments.join('.')
    const canonicalPath =
      `${request.targetLayer}.${localName}` as CanonicalTokenPath
    const rawType = aliases.types.get(localName)
    if (!rawType) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_TYPE_REQUIRED',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          tokenPath: canonicalPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: token.jsonPath,
          target: 'Kernel type',
          remediation: { code: 'DECLARE_DTCG_TYPE' },
          details: { token: token.segments.join('.') },
        })
      )
      continue
    }
    const typeId =
      DTCG_TO_KERNEL_TYPE[rawType as keyof typeof DTCG_TO_KERNEL_TYPE]
    if (!typeId) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_TYPE_UNSUPPORTED',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          tokenPath: canonicalPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: `${token.jsonPath}.$type`,
          expected: Object.keys(DTCG_TO_KERNEL_TYPE),
          actual: rawType,
          target: 'Kernel built-in type',
          remediation: { code: 'USE_SUPPORTED_DTCG_TYPE' },
          details: { type: rawType },
        })
      )
      continue
    }
    if (
      token.deprecated !== undefined &&
      typeof token.deprecated !== 'boolean' &&
      typeof token.deprecated !== 'string'
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_EXTENSION_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          tokenPath: canonicalPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: `${token.jsonPath}.$deprecated`,
          expected: 'boolean|string',
          actual: typeof token.deprecated,
          target: '$deprecated',
          remediation: { code: 'FIX_DTCG_DEPRECATED' },
          details: { issue: 'invalid-deprecated' },
        })
      )
    }
    const lifecycle =
      request.lifecycleByPath[canonicalPath] ?? request.lifecycleByPath['*']
    if (!lifecycle) {
      diagnostics.push(
        diagnostic({
          code: 'TC_INPUT_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          tokenPath: canonicalPath,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath: token.jsonPath,
          target: 'ZX public lifecycle strategy',
          remediation: { code: 'DECLARE_DTCG_IMPORT_LIFECYCLE' },
          details: { canonicalPath },
        })
      )
      continue
    }
    sourceMap[canonicalPath] = request.sourceLocation
    const status =
      token.deprecated !== undefined && token.deprecated !== false
        ? 'deprecated'
        : lifecycle
    lifecycleOutput[canonicalPath] = {
      status,
      ...(token.deprecated !== undefined
        ? { deprecated: token.deprecated as boolean | string }
        : {}),
    }
    const aliasTarget = aliases.targets.get(localName)
    if (aliasTarget !== undefined) {
      records[localName] = {
        type: typeId,
        value: {
          $ref: `${request.targetLayer}.${aliasTarget}`,
          expect: typeId,
        },
      }
      continue
    }
    const converted = fromDtcgValue(
      typeId,
      token.value,
      `${token.jsonPath}.$value`,
      {
        gradientAngle: isRecord(token.extensions?.['org.zxio.theme'])
          ? token.extensions['org.zxio.theme'].gradientAngle
          : undefined,
      }
    )
    if (!converted.ok) {
      diagnostics.push(
        ...converted.diagnostics.map((entry) =>
          diagnostic({
            ...entry,
            source: request.sourceLocation,
            tokenPath: canonicalPath,
          })
        )
      )
      continue
    }
    records[localName] = {
      type: typeId,
      value: { kind: 'literal', value: converted.value },
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  const first = Object.entries(records)[0]
  const foundation =
    request.targetLayer === 'foundation'
      ? records
      : Object.fromEntries(
          Object.entries(records)
            .filter(([path]) => !aliases.targets.has(path))
            .map(([path, definition]) => [`dtcg.${path}`, definition])
        )
  const semantic =
    request.targetLayer === 'semantic'
      ? Object.fromEntries(
          Object.entries(records).map(([path, definition]) => {
            if (aliases.targets.has(path)) return [path, definition]
            const type = (definition as Readonly<Record<string, unknown>>).type
            return [
              path,
              {
                type,
                value: {
                  $ref: `foundation.dtcg.${path}`,
                  expect: type,
                },
              },
            ]
          })
        )
      : Object.fromEntries(
          Object.entries(records).map(([path, definition]) => [
            path,
            {
              type: (definition as Readonly<Record<string, unknown>>).type,
              value: {
                $ref: `foundation.${path}`,
                expect: (definition as Readonly<Record<string, unknown>>).type,
              },
            },
          ])
        )
  const componentRecord = first
    ? {
        token: {
          type: (first[1] as Readonly<Record<string, unknown>>).type,
          value: {
            $ref: `semantic.${first[0]}`,
            expect: (first[1] as Readonly<Record<string, unknown>>).type,
          },
        },
      }
    : {}
  const themeSourceInput = {
    meta: {
      themeId: request.identity.themeId,
      name: request.identity.name,
      schemaVersion: request.identity.sourceVersion,
      contractVersion: request.identity.contractVersion,
    },
    axes: request.axes,
    foundation,
    semantic,
    components: { imported: componentRecord },
    transforms: request.transforms,
  } as unknown as ThemeSourceAuthorInput
  return success(
    deepFreeze({
      themeSourceInput,
      passthroughExtensions: extensions,
      sourceMap,
      lifecycle: lifecycleOutput,
      canonicalDocument: parsed.value as Readonly<
        Record<string, CanonicalJsonValue>
      >,
    })
  )
}

function canonicalDepth(value: unknown, depth = 0): number {
  if (!value || typeof value !== 'object') return depth
  if (Array.isArray(value)) {
    return value.reduce(
      (maximum, entry) => Math.max(maximum, canonicalDepth(entry, depth + 1)),
      depth
    )
  }
  return Object.values(value).reduce(
    (maximum, entry) => Math.max(maximum, canonicalDepth(entry, depth + 1)),
    depth
  )
}

// eslint-disable-next-line camelcase -- the versioned public API mirrors DTCG 2025.10
export function reexportDtcg2025_10(
  request: DtcgReexportRequest
): CompilerResult<DtcgReexportResult> {
  const maximumDepth = request.maxDepth ?? 64
  const importResultKeys = isRecord(request.importResult)
    ? Object.keys(request.importResult).sort(compareCodePoint)
    : []
  const expectedImportResultKeys = [
    'canonicalDocument',
    'lifecycle',
    'passthroughExtensions',
    'sourceMap',
    'themeSourceInput',
  ]
  if (
    !Number.isSafeInteger(maximumDepth) ||
    maximumDepth < 1 ||
    maximumDepth > 256 ||
    !isRecord(request.importResult) ||
    canonicalJson(importResultKeys) !==
      canonicalJson(expectedImportResultKeys) ||
    !isRecord(request.importResult.canonicalDocument) ||
    !isRecord(request.importResult.passthroughExtensions)
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$',
        target: 'validated DTCG import result',
        remediation: { code: 'PASS_DTCG_IMPORT_RESULT' },
        details: { issue: 'invalid-reexport-request' },
      }),
    ])
  }
  let document: Record<string, CanonicalJsonValue>
  try {
    document = canonicalize(request.importResult.canonicalDocument) as Record<
      string,
      CanonicalJsonValue
    >
  } catch {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$.canonicalDocument',
        target: 'canonical DTCG import document',
        remediation: { code: 'USE_UNMODIFIED_DTCG_IMPORT_RESULT' },
        details: { issue: 'non-canonical-reexport-document' },
      }),
    ])
  }
  const diagnostics: ReturnType<typeof diagnostic>[] = []
  const discoveredExtensions: Record<string, CanonicalJsonValue> = {}
  flattenTokens(
    document,
    undefined,
    [],
    '$',
    [],
    discoveredExtensions,
    diagnostics,
    request.sourceLocation,
    0,
    maximumDepth
  )
  const extensionPaths =
    Object.keys(discoveredExtensions).sort(compareCodePoint)
  const suppliedExtensionPaths = Object.keys(
    request.importResult.passthroughExtensions
  ).sort(compareCodePoint)
  if (
    canonicalJson(extensionPaths) !== canonicalJson(suppliedExtensionPaths) ||
    extensionPaths.some(
      (path) =>
        canonicalJson(discoveredExtensions[path]) !==
        canonicalJson(request.importResult.passthroughExtensions[path])
    )
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_DTCG_EXTENSION_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$',
        expected: extensionPaths,
        actual: suppliedExtensionPaths,
        target: 'exact importer passthrough extension set',
        remediation: { code: 'USE_UNMODIFIED_DTCG_IMPORT_RESULT' },
        details: { issue: 'passthrough-extension-drift' },
      })
    )
  }
  for (const [jsonPath, extension] of Object.entries(
    request.importResult.passthroughExtensions
  ).sort(([left], [right]) => compareCodePoint(left, right))) {
    const segments = jsonPath.split('.').slice(1)
    if (
      segments.length === 0 ||
      segments.at(-1) !== '$extensions' ||
      segments.some((segment) => segment.length === 0)
    ) {
      diagnostics.push(
        diagnostic({
          code: 'TC_DTCG_EXTENSION_INVALID',
          phase: 'adapter',
          adapter: 'dtcg',
          source: request.sourceLocation,
          schemaVersion: DTCG_SPEC_VERSION,
          jsonPath,
          target: 'preserved DTCG extension JSON path',
          remediation: { code: 'USE_IMPORTER_EXTENSION_PATHS' },
          details: { issue: 'invalid-passthrough-extension-path' },
        })
      )
      continue
    }
    let cursor: Record<string, CanonicalJsonValue> = document
    let parentFound = true
    for (const segment of segments.slice(0, -1)) {
      const next = cursor[segment]
      if (!isRecord(next)) {
        diagnostics.push(
          diagnostic({
            code: 'TC_DTCG_EXTENSION_INVALID',
            phase: 'adapter',
            adapter: 'dtcg',
            source: request.sourceLocation,
            schemaVersion: DTCG_SPEC_VERSION,
            jsonPath,
            target: 'existing DTCG extension parent',
            remediation: { code: 'USE_UNMODIFIED_DTCG_IMPORT_RESULT' },
            details: { issue: 'extension-parent-missing' },
          })
        )
        parentFound = false
        break
      }
      cursor = next as Record<string, CanonicalJsonValue>
    }
    if (parentFound) cursor.$extensions = canonicalize(extension)
  }
  const depth = canonicalDepth(document)
  if (depth > maximumDepth) {
    diagnostics.push(
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$',
        expected: maximumDepth,
        actual: depth,
        target: 'DTCG re-export depth',
        remediation: { code: 'REDUCE_DTCG_NESTING' },
        details: { issue: 'maximum-depth-exceeded' },
      })
    )
  }
  if (document.$schema !== DTCG_SCHEMA_URI) {
    diagnostics.push(
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'adapter',
        adapter: 'dtcg',
        source: request.sourceLocation,
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath: '$.$schema',
        expected: DTCG_SCHEMA_URI,
        actual: typeof document.$schema === 'string' ? document.$schema : null,
        target: 'DTCG Format Module 2025.10 schema',
        remediation: { code: 'USE_DTCG_2025_10_SCHEMA' },
        details: { issue: 'incompatible-dtcg-schema' },
      })
    )
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  const text = canonicalJson(document)
  return success(
    deepFreeze({
      document: deepFreeze(document),
      text,
      mediaType: DTCG_MEDIA_TYPE,
      sha256: sha256(text),
    })
  )
}

function setNestedToken(
  root: Record<string, unknown>,
  path: string,
  value: Readonly<Record<string, unknown>>
): void {
  const segments = path.split('.').slice(1)
  let cursor = root
  for (const segment of segments.slice(0, -1)) {
    const next = cursor[segment]
    if (!isRecord(next)) cursor[segment] = {}
    cursor = cursor[segment] as Record<string, unknown>
  }
  cursor[segments.at(-1) ?? path] = value
}

function compileDtcg(
  context: ThemeAdapterContext,
  version: string
): CompilerResult<AdapterArtifactContribution> {
  const files: AdapterTextArtifact[] = []
  const coverage: AdapterCoverage[] = context.publicPaths.map((tokenPath) => ({
    tokenPath,
    status: tokenPath.startsWith('semantic.') ? 'mapped' : 'not-applicable',
    targets: tokenPath.startsWith('semantic.') ? [tokenPath] : [],
    ...(!tokenPath.startsWith('semantic.')
      ? { reasonCode: 'PUBLIC_NON_SEMANTIC_NOT_EXPORTED' }
      : {}),
  }))
  const variantArtifacts: Record<string, string> = {}
  const index = []
  const diagnostics = []
  for (const variant of context.variants) {
    const document: Record<string, unknown> = { $schema: DTCG_SCHEMA_URI }
    for (const path of context.publicPaths) {
      if (!path.startsWith('semantic.')) continue
      const token = variant.resolved.tokens[path]
      if (!token) continue
      const serializer = (
        context.serializers as Readonly<
          Record<
            string,
            import('../../core/type-serializers').TargetTypeSerializer<unknown>
          >
        >
      )[token.typeId]
      const builtInMappedType =
        KERNEL_TO_DTCG_TYPE[token.typeId as BuiltInTypeId]
      const mappedType = builtInMappedType ?? serializer?.dtcg?.type
      if (!mappedType) {
        diagnostics.push(
          diagnostic({
            code: 'TC_DTCG_TYPE_UNSUPPORTED',
            phase: 'adapter',
            adapter: 'dtcg',
            source: token.source,
            tokenPath: path,
            variantKey: variant.variantKey,
            schemaVersion: DTCG_SPEC_VERSION,
            jsonPath: `$.${path}`,
            expected: Object.keys(KERNEL_TO_DTCG_TYPE),
            actual: token.typeId,
            target: 'DTCG 2025.10',
            remediation: { code: 'REGISTER_DTCG_TYPE_MAPPING' },
            details: { typeId: token.typeId },
          })
        )
        continue
      }
      const converted = builtInMappedType
        ? toDtcgValue(
            token.typeId as BuiltInTypeId,
            token.value,
            `$.${path}.$value`
          )
        : serializer!.toDtcg!(token.value, {
            tokenPath: path,
            jsonPath: `$.${path}.$value`,
          })
      if (!converted.ok) {
        diagnostics.push(
          ...converted.diagnostics.map((entry) =>
            diagnostic({
              ...entry,
              source: token.source,
              tokenPath: path,
              variantKey: variant.variantKey,
            })
          )
        )
        continue
      }
      setNestedToken(document, path, {
        $type: mappedType,
        $value: converted.value,
        ...(token.visibility === 'public' &&
        token.public.lifecycle === 'deprecated'
          ? {
              $deprecated:
                token.public.migration.kind === 'replacement'
                  ? `Use ${token.public.migration.path}`
                  : token.public.migration.reason.detail,
            }
          : {}),
        $extensions: {
          'org.zxio.theme': {
            lifecycle:
              token.visibility === 'public'
                ? token.public.lifecycle
                : 'internal',
            variantKey: variant.variantKey,
            resolvedContentHash: variant.resolved.contentHash,
            ...(token.typeId === 'gradient'
              ? {
                  gradientAngle: (token.value as CanonicalGradient).angle,
                }
              : {}),
          },
        },
      })
    }
    const path = `dtcg/${variant.variantKey}.tokens.json`
    const text = canonicalJson(document)
    const hash = sha256(text)
    variantArtifacts[variant.variantKey] = path
    files.push({
      path,
      mediaType: DTCG_MEDIA_TYPE,
      purpose: 'dtcg-token-set' as const,
      loadPhase: 'variant' as const,
      text,
    })
    index.push({
      variantKey: variant.variantKey,
      selection: variant.selection,
      file: path,
      sha256: hash,
    })
  }
  if (diagnostics.length > 0) return failure(diagnostics)
  files.push({
    path: 'dtcg/variants.json',
    mediaType: 'application/json',
    purpose: 'dtcg-index',
    loadPhase: 'tooling',
    text: canonicalJson({ schema: 'zx.dtcg-variant-index/1', variants: index }),
  })
  const mapping = {
    schema: 'zx.dtcg-2025.10-mapping/1',
    version,
    types: DTCG_TO_KERNEL_TYPE,
  }
  return success({
    files,
    variantArtifacts,
    contract: {
      name: '@zxio/theme-compiler/dtcg',
      version,
      mappingSchema: mapping.schema,
      mappingVersion: version,
      mappingHash: sha256(canonicalJson(mapping)),
      coverage,
    },
  })
}

// eslint-disable-next-line camelcase -- the versioned public API mirrors DTCG 2025.10
export function createDtcg2025_10Adapter(): ThemeAdapter {
  return {
    id: 'dtcg',
    version: DTCG_ADAPTER_VERSION,
    compile: (context) => compileDtcg(context, DTCG_ADAPTER_VERSION),
  }
}
