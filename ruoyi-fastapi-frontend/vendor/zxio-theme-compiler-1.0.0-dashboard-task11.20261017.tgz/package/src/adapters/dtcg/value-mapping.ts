import { diagnostic } from '../../core/diagnostics'
import { type CompilerResult, failure, success } from '../../core/result'
import { DTCG_SPEC_VERSION } from './model'

import type {
  BuiltInTypeId,
  CanonicalBorder,
  CanonicalColor,
  CanonicalDimension,
  CanonicalGradient,
  CanonicalJsonValue,
  CanonicalShadowLayer,
  CanonicalStrokeStyle,
  CanonicalTransition,
  CanonicalTypography,
} from '@zxio/tokens/kernel'

export const DTCG_TO_KERNEL_TYPE = {
  color: 'color',
  dimension: 'dimension',
  number: 'number',
  duration: 'duration',
  cubicBezier: 'cubic-bezier',
  fontFamily: 'font-family',
  fontWeight: 'font-weight',
  gradient: 'gradient',
  shadow: 'shadow',
  strokeStyle: 'strokeStyle',
  transition: 'transition',
  border: 'border',
  typography: 'typography',
  string: 'string',
} as const

export const KERNEL_TO_DTCG_TYPE = Object.fromEntries(
  Object.entries(DTCG_TO_KERNEL_TYPE).map(([dtcg, kernel]) => [kernel, dtcg])
) as Readonly<Record<BuiltInTypeId, string>>

function isRecord(input: unknown): input is Readonly<Record<string, unknown>> {
  return !!input && typeof input === 'object' && !Array.isArray(input)
}

function hasExactKeys(
  input: Readonly<Record<string, unknown>>,
  required: readonly string[],
  optional: readonly string[] = []
): boolean {
  const allowed = new Set([...required, ...optional])
  return (
    required.every((key) => key in input) &&
    Object.keys(input).every((key) => allowed.has(key))
  )
}

function fail(
  code: 'TC_DTCG_TYPE_UNSUPPORTED' | 'TC_DTCG_VALUE_UNREPRESENTABLE',
  jsonPath: string,
  expected: CanonicalJsonValue,
  actual: CanonicalJsonValue,
  target: string
): CompilerResult<never> {
  return failure([
    diagnostic({
      code,
      phase: 'adapter',
      adapter: 'dtcg',
      schemaVersion: DTCG_SPEC_VERSION,
      jsonPath,
      expected,
      actual,
      target,
      remediation: { code: 'USE_DTCG_2025_10_REPRESENTABLE_VALUE' },
      details: {
        schemaVersion: DTCG_SPEC_VERSION,
        jsonPath,
        expected,
        actual,
        target,
      },
    }),
  ])
}

function dimensionFromDtcg(
  value: unknown,
  jsonPath: string
): CompilerResult<CanonicalDimension> {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ['unit', 'value']) ||
    typeof value.value !== 'number' ||
    !Number.isFinite(value.value) ||
    (value.unit !== 'px' && value.unit !== 'rem')
  ) {
    return fail(
      'TC_DTCG_VALUE_UNREPRESENTABLE',
      jsonPath,
      'finite {value, unit:px|rem}',
      typeof value,
      'dimension'
    )
  }
  return success({ kind: 'value', value: value.value, unit: value.unit })
}

function colorFromDtcg(
  value: unknown,
  jsonPath: string
): CompilerResult<CanonicalColor> {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ['colorSpace', 'components'], ['alpha']) ||
    (value.colorSpace !== 'srgb' &&
      value.colorSpace !== 'display-p3' &&
      value.colorSpace !== 'oklch') ||
    !Array.isArray(value.components) ||
    value.components.length !== 3 ||
    !value.components.every(
      (entry) => typeof entry === 'number' && Number.isFinite(entry)
    ) ||
    (value.alpha !== undefined &&
      (typeof value.alpha !== 'number' ||
        !Number.isFinite(value.alpha) ||
        value.alpha < 0 ||
        value.alpha > 1)) ||
    (value.colorSpace !== 'oklch' &&
      !value.components.every(
        (entry) => (entry as number) >= 0 && (entry as number) <= 1
      )) ||
    (value.colorSpace === 'oklch' &&
      ((value.components[0] as number) < 0 ||
        (value.components[0] as number) > 1 ||
        (value.components[1] as number) < 0 ||
        (value.components[2] as number) < 0 ||
        (value.components[2] as number) >= 360))
  ) {
    return fail(
      'TC_DTCG_VALUE_UNREPRESENTABLE',
      jsonPath,
      'canonical DTCG color',
      typeof value,
      'color'
    )
  }
  return success({
    colorSpace: value.colorSpace,
    components: value.components as unknown as readonly [
      number,
      number,
      number
    ],
    alpha: value.alpha === undefined ? 1 : value.alpha,
  })
}

function shadowLayerFromDtcg(
  value: unknown,
  jsonPath: string
): CompilerResult<CanonicalShadowLayer> {
  if (
    !isRecord(value) ||
    !hasExactKeys(
      value,
      ['blur', 'color', 'offsetX', 'offsetY', 'spread'],
      ['inset']
    ) ||
    (value.inset !== undefined && typeof value.inset !== 'boolean')
  ) {
    return fail(
      'TC_DTCG_VALUE_UNREPRESENTABLE',
      jsonPath,
      'DTCG shadow layer',
      typeof value,
      'shadow'
    )
  }
  const color = colorFromDtcg(value.color, `${jsonPath}.color`)
  const offsetX = dimensionFromDtcg(value.offsetX, `${jsonPath}.offsetX`)
  const offsetY = dimensionFromDtcg(value.offsetY, `${jsonPath}.offsetY`)
  const blur = dimensionFromDtcg(value.blur, `${jsonPath}.blur`)
  const spread = dimensionFromDtcg(value.spread, `${jsonPath}.spread`)
  const results = [color, offsetX, offsetY, blur, spread]
  const diagnostics = results.flatMap((result) =>
    result.ok ? [] : result.diagnostics
  )
  if (diagnostics.length > 0) return failure(diagnostics)
  return success({
    color: color.ok ? color.value : ({} as CanonicalColor),
    offsetX: offsetX.ok ? offsetX.value : ({} as CanonicalDimension),
    offsetY: offsetY.ok ? offsetY.value : ({} as CanonicalDimension),
    blur: blur.ok ? blur.value : ({} as CanonicalDimension),
    spread: spread.ok ? spread.value : ({} as CanonicalDimension),
    inset: value.inset ?? false,
  })
}

function gradientFromDtcg(
  value: unknown,
  jsonPath: string,
  rawAngle: unknown
): CompilerResult<CanonicalGradient> {
  const angle = rawAngle === undefined ? 180 : rawAngle
  if (
    !Array.isArray(value) ||
    value.length === 0 ||
    typeof angle !== 'number' ||
    !Number.isFinite(angle)
  ) {
    return fail(
      'TC_DTCG_VALUE_UNREPRESENTABLE',
      jsonPath,
      'non-empty DTCG gradient stop array',
      typeof value,
      'gradient'
    )
  }
  const stops: Array<CanonicalGradient['stops'][number]> = []
  for (const [index, entry] of value.entries()) {
    if (
      !isRecord(entry) ||
      !hasExactKeys(entry, ['color', 'position']) ||
      typeof entry.position !== 'number' ||
      !Number.isFinite(entry.position)
    ) {
      return fail(
        'TC_DTCG_VALUE_UNREPRESENTABLE',
        `${jsonPath}[${index}]`,
        '{color, position}',
        typeof entry,
        'gradient'
      )
    }
    const color = colorFromDtcg(entry.color, `${jsonPath}[${index}].color`)
    if (!color.ok) return color
    stops.push({
      color: color.value,
      position: Math.min(1, Math.max(0, entry.position)),
    })
  }
  return success({
    angle: ((angle % 360) + 360) % 360,
    stops,
  })
}

function strokeStyleFromDtcg(
  value: unknown,
  jsonPath: string
): CompilerResult<CanonicalStrokeStyle> {
  const keywords = new Set([
    'solid',
    'dashed',
    'dotted',
    'double',
    'groove',
    'ridge',
    'outset',
    'inset',
  ])
  if (typeof value === 'string') {
    return keywords.has(value)
      ? success(value as CanonicalStrokeStyle)
      : fail(
          'TC_DTCG_VALUE_UNREPRESENTABLE',
          jsonPath,
          'DTCG strokeStyle keyword',
          value,
          'strokeStyle'
        )
  }
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ['dashArray', 'lineCap']) ||
    !Array.isArray(value.dashArray) ||
    value.dashArray.length === 0 ||
    typeof value.lineCap !== 'string' ||
    !['butt', 'round', 'square'].includes(value.lineCap)
  ) {
    return fail(
      'TC_DTCG_VALUE_UNREPRESENTABLE',
      jsonPath,
      '{dashArray, lineCap}',
      typeof value,
      'strokeStyle'
    )
  }
  const dashArray = value.dashArray.map((entry, index) =>
    dimensionFromDtcg(entry, `${jsonPath}.dashArray[${index}]`)
  )
  const diagnostics = dashArray.flatMap((entry) =>
    entry.ok ? [] : entry.diagnostics
  )
  return diagnostics.length > 0
    ? failure(diagnostics)
    : success({
        dashArray: dashArray.map((entry) =>
          entry.ok ? entry.value : ({} as CanonicalDimension)
        ),
        lineCap: value.lineCap as 'butt' | 'round' | 'square',
      })
}

function transitionFromDtcg(
  value: unknown,
  jsonPath: string
): CompilerResult<CanonicalTransition> {
  if (
    !isRecord(value) ||
    !hasExactKeys(value, ['duration', 'delay', 'timingFunction'])
  ) {
    return fail(
      'TC_DTCG_VALUE_UNREPRESENTABLE',
      jsonPath,
      '{duration, delay, timingFunction}',
      typeof value,
      'transition'
    )
  }
  const duration = fromDtcgValue(
    'duration',
    value.duration,
    `${jsonPath}.duration`
  )
  const delay = fromDtcgValue('duration', value.delay, `${jsonPath}.delay`)
  const timingFunction = fromDtcgValue(
    'cubic-bezier',
    value.timingFunction,
    `${jsonPath}.timingFunction`
  )
  const diagnostics = [duration, delay, timingFunction].flatMap((entry) =>
    entry.ok ? [] : entry.diagnostics
  )
  return diagnostics.length > 0
    ? failure(diagnostics)
    : success({
        duration: duration.ok
          ? (duration.value as CanonicalTransition['duration'])
          : { value: 0, unit: 'ms' },
        delay: delay.ok
          ? (delay.value as CanonicalTransition['delay'])
          : { value: 0, unit: 'ms' },
        timingFunction: timingFunction.ok
          ? (timingFunction.value as CanonicalTransition['timingFunction'])
          : [0, 0, 1, 1],
      })
}

export function fromDtcgValue(
  typeId: BuiltInTypeId,
  value: unknown,
  jsonPath: string,
  options: Readonly<{ gradientAngle?: unknown }> = {}
): CompilerResult<unknown> {
  switch (typeId) {
    case 'color':
      return colorFromDtcg(value, jsonPath)
    case 'dimension':
      return dimensionFromDtcg(value, jsonPath)
    case 'number':
      return typeof value === 'number' && Number.isFinite(value)
        ? success(value)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'finite number',
            typeof value,
            'number'
          )
    case 'duration':
      return isRecord(value) &&
        hasExactKeys(value, ['unit', 'value']) &&
        typeof value.value === 'number' &&
        Number.isFinite(value.value) &&
        (value.unit === 'ms' || value.unit === 's')
        ? success({
            value: value.unit === 's' ? value.value * 1000 : value.value,
            unit: 'ms',
          })
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            '{value,unit:ms|s}',
            typeof value,
            'duration'
          )
    case 'cubic-bezier':
      return Array.isArray(value) &&
        value.length === 4 &&
        value.every(
          (entry) => typeof entry === 'number' && Number.isFinite(entry)
        ) &&
        value[0] >= 0 &&
        value[0] <= 1 &&
        value[2] >= 0 &&
        value[2] <= 1
        ? success(value as unknown as readonly [number, number, number, number])
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'four finite numbers',
            typeof value,
            'cubicBezier'
          )
    case 'font-family':
      return typeof value === 'string'
        ? success([value])
        : Array.isArray(value) &&
          value.length > 0 &&
          value.every((entry) => typeof entry === 'string')
        ? success(value)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'string|string[]',
            typeof value,
            'fontFamily'
          )
    case 'font-weight':
      return typeof value === 'number' &&
        Number.isFinite(value) &&
        value >= 1 &&
        value <= 1000
        ? success(value)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'number 1..1000',
            typeof value,
            'fontWeight'
          )
    case 'gradient':
      return gradientFromDtcg(value, jsonPath, options.gradientAngle)
    case 'shadow': {
      const entries = Array.isArray(value) ? value : [value]
      const layers = entries.map((entry, index) =>
        shadowLayerFromDtcg(entry, `${jsonPath}[${index}]`)
      )
      const diagnostics = layers.flatMap((entry) =>
        entry.ok ? [] : entry.diagnostics
      )
      return diagnostics.length > 0
        ? failure(diagnostics)
        : success(
            layers.map((entry) =>
              entry.ok ? entry.value : ({} as CanonicalShadowLayer)
            )
          )
    }
    case 'strokeStyle':
      return strokeStyleFromDtcg(value, jsonPath)
    case 'transition':
      return transitionFromDtcg(value, jsonPath)
    case 'border': {
      if (
        !isRecord(value) ||
        !hasExactKeys(value, ['color', 'style', 'width']) ||
        !['none', 'solid', 'dashed', 'dotted', 'double'].includes(
          String(value.style)
        )
      ) {
        return fail(
          'TC_DTCG_VALUE_UNREPRESENTABLE',
          jsonPath,
          'DTCG border',
          typeof value,
          'border'
        )
      }
      const width = dimensionFromDtcg(value.width, `${jsonPath}.width`)
      const color = colorFromDtcg(value.color, `${jsonPath}.color`)
      if (!width.ok || !color.ok)
        return failure([
          ...(!width.ok ? width.diagnostics : []),
          ...(!color.ok ? color.diagnostics : []),
        ])
      return success({
        width: width.value,
        style: value.style,
        color: color.value,
      } as CanonicalBorder)
    }
    case 'typography': {
      if (
        !isRecord(value) ||
        !hasExactKeys(value, [
          'fontFamily',
          'fontSize',
          'fontWeight',
          'letterSpacing',
          'lineHeight',
        ])
      )
        return fail(
          'TC_DTCG_VALUE_UNREPRESENTABLE',
          jsonPath,
          'DTCG typography',
          typeof value,
          'typography'
        )
      const family = fromDtcgValue(
        'font-family',
        value.fontFamily,
        `${jsonPath}.fontFamily`
      )
      const size = dimensionFromDtcg(value.fontSize, `${jsonPath}.fontSize`)
      const weight = fromDtcgValue(
        'font-weight',
        value.fontWeight,
        `${jsonPath}.fontWeight`
      )
      const spacing = dimensionFromDtcg(
        value.letterSpacing,
        `${jsonPath}.letterSpacing`
      )
      const lineHeight =
        typeof value.lineHeight === 'number' &&
        Number.isFinite(value.lineHeight)
          ? success(value.lineHeight)
          : fail(
              'TC_DTCG_VALUE_UNREPRESENTABLE',
              `${jsonPath}.lineHeight`,
              'finite number',
              typeof value.lineHeight,
              'typography.lineHeight'
            )
      const diagnostics = [family, size, weight, spacing, lineHeight].flatMap(
        (entry) => (entry.ok ? [] : entry.diagnostics)
      )
      if (diagnostics.length > 0) return failure(diagnostics)
      return success({
        fontFamily: family.ok ? family.value : [],
        fontSize: size.ok ? size.value : ({} as CanonicalDimension),
        fontWeight: weight.ok ? weight.value : 400,
        lineHeight: lineHeight.ok ? lineHeight.value : 1,
        letterSpacing: spacing.ok ? spacing.value : ({} as CanonicalDimension),
      } as CanonicalTypography)
    }
    case 'string':
      return typeof value === 'string'
        ? success(value)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'string',
            typeof value,
            'string'
          )
  }
}

function exportDimension(
  value: CanonicalDimension,
  jsonPath: string
): CompilerResult<CanonicalJsonValue> {
  return value.kind === 'value' && (value.unit === 'px' || value.unit === 'rem')
    ? success({ value: value.value, unit: value.unit })
    : fail(
        'TC_DTCG_VALUE_UNREPRESENTABLE',
        jsonPath,
        'px|rem literal dimension',
        value.kind,
        'dtcg'
      )
}

function exportColor(value: CanonicalColor): CanonicalJsonValue {
  return {
    colorSpace: value.colorSpace,
    components: value.components,
    alpha: value.alpha,
  }
}

export function toDtcgValue(
  typeId: BuiltInTypeId,
  value: BuiltInTypeMapValue,
  jsonPath: string
): CompilerResult<CanonicalJsonValue> {
  switch (typeId) {
    case 'color':
      return success(exportColor(value as CanonicalColor))
    case 'dimension':
      return exportDimension(value as CanonicalDimension, jsonPath)
    case 'number':
    case 'font-weight':
    case 'string':
      return success(value as CanonicalJsonValue)
    case 'duration': {
      const duration = value as Readonly<Record<string, unknown>>
      return isRecord(value) &&
        hasExactKeys(duration, ['unit', 'value']) &&
        duration.unit === 'ms' &&
        typeof duration.value === 'number' &&
        Number.isFinite(duration.value)
        ? success(value as CanonicalJsonValue)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'finite canonical {value,unit:ms}',
            typeof value,
            'duration'
          )
    }
    case 'cubic-bezier':
      if (
        !Array.isArray(value) ||
        value.length !== 4 ||
        !value.every(
          (entry) => typeof entry === 'number' && Number.isFinite(entry)
        ) ||
        value[0] < 0 ||
        value[0] > 1 ||
        value[2] < 0 ||
        value[2] > 1
      ) {
        return fail(
          'TC_DTCG_VALUE_UNREPRESENTABLE',
          jsonPath,
          'four finite numbers with x coordinates in 0..1',
          typeof value,
          'cubicBezier'
        )
      }
      return success(value as CanonicalJsonValue)
    case 'font-family':
      return Array.isArray(value) &&
        value.length > 0 &&
        value.every((entry) => typeof entry === 'string')
        ? success(value as CanonicalJsonValue)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'non-empty string[]',
            typeof value,
            'fontFamily'
          )
    case 'gradient': {
      const gradient = value as unknown as CanonicalGradient
      const output: CanonicalJsonValue[] = []
      for (const [index, stop] of gradient.stops.entries()) {
        output.push({
          color: exportColor(stop.color),
          position: stop.position,
        })
        if (!Number.isFinite(stop.position)) {
          return fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            `${jsonPath}[${index}].position`,
            'finite position',
            String(stop.position),
            'gradient'
          )
        }
      }
      return output.length > 0
        ? success(output)
        : fail(
            'TC_DTCG_VALUE_UNREPRESENTABLE',
            jsonPath,
            'non-empty gradient stop array',
            'empty',
            'gradient'
          )
    }
    case 'shadow': {
      const output = []
      for (const [index, layer] of (
        value as readonly CanonicalShadowLayer[]
      ).entries()) {
        const dimensions = [
          layer.offsetX,
          layer.offsetY,
          layer.blur,
          layer.spread,
        ].map((entry, position) =>
          exportDimension(
            entry,
            `${jsonPath}[${index}].${
              ['offsetX', 'offsetY', 'blur', 'spread'][position]
            }`
          )
        )
        const diagnostics = dimensions.flatMap((entry) =>
          entry.ok ? [] : entry.diagnostics
        )
        if (diagnostics.length > 0) return failure(diagnostics)
        output.push({
          color: exportColor(layer.color),
          offsetX: dimensions[0].ok ? dimensions[0].value : null,
          offsetY: dimensions[1].ok ? dimensions[1].value : null,
          blur: dimensions[2].ok ? dimensions[2].value : null,
          spread: dimensions[3].ok ? dimensions[3].value : null,
          inset: layer.inset,
        })
      }
      return success(output)
    }
    case 'strokeStyle': {
      const strokeStyle = value as unknown as CanonicalStrokeStyle
      if (typeof strokeStyle === 'string') return success(strokeStyle)
      const dashArray = strokeStyle.dashArray.map((entry, index) =>
        exportDimension(entry, `${jsonPath}.dashArray[${index}]`)
      )
      const diagnostics = dashArray.flatMap((entry) =>
        entry.ok ? [] : entry.diagnostics
      )
      return diagnostics.length > 0
        ? failure(diagnostics)
        : success({
            dashArray: dashArray.map((entry) =>
              entry.ok ? entry.value : null
            ),
            lineCap: strokeStyle.lineCap,
          })
    }
    case 'transition': {
      const transition = value as unknown as CanonicalTransition
      return success({
        duration: {
          value: transition.duration.value,
          unit: transition.duration.unit,
        },
        delay: {
          value: transition.delay.value,
          unit: transition.delay.unit,
        },
        timingFunction: transition.timingFunction,
      })
    }
    case 'border': {
      const border = value as unknown as CanonicalBorder
      const width = exportDimension(border.width, `${jsonPath}.width`)
      return width.ok
        ? success({
            width: width.value,
            style: border.style,
            color: exportColor(border.color),
          })
        : width
    }
    case 'typography': {
      const typography = value as unknown as CanonicalTypography
      const fontSize = exportDimension(
        typography.fontSize,
        `${jsonPath}.fontSize`
      )
      const letterSpacing = exportDimension(
        typography.letterSpacing,
        `${jsonPath}.letterSpacing`
      )
      const lineHeight =
        typeof typography.lineHeight === 'number' &&
        Number.isFinite(typography.lineHeight)
          ? success(typography.lineHeight)
          : fail(
              'TC_DTCG_VALUE_UNREPRESENTABLE',
              `${jsonPath}.lineHeight`,
              'finite number',
              typeof typography.lineHeight,
              'typography.lineHeight'
            )
      if (!fontSize.ok || !letterSpacing.ok || !lineHeight.ok) {
        return failure([
          ...(!fontSize.ok ? fontSize.diagnostics : []),
          ...(!letterSpacing.ok ? letterSpacing.diagnostics : []),
          ...(!lineHeight.ok ? lineHeight.diagnostics : []),
        ])
      }
      return success({
        fontFamily: typography.fontFamily,
        fontSize: fontSize.value,
        fontWeight: typography.fontWeight,
        lineHeight: lineHeight.value,
        letterSpacing: letterSpacing.value,
      })
    }
  }
}

type BuiltInTypeMapValue =
  | CanonicalColor
  | CanonicalDimension
  | number
  | string
  | readonly unknown[]
  | Readonly<Record<string, unknown>>
