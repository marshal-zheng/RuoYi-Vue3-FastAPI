import type {
  AuthorLogicalSourceLocator,
  CanonicalJsonValue,
  ThemeAxisDeclarations,
  ThemeSourceAuthorInput,
} from '@zxio/tokens/kernel'

export const DTCG_SPEC_VERSION = '2025.10' as const
export const DTCG_SCHEMA_URI =
  'https://www.designtokens.org/schemas/2025.10/format.json' as const
export const DTCG_MEDIA_TYPE = 'application/design-tokens+json' as const
export const DTCG_ADAPTER_VERSION = '1.0.0' as const

export interface DtcgImportRequest {
  readonly document: unknown | Uint8Array
  readonly identity: Readonly<{
    themeId: string
    name: string
    sourceVersion: 4
    contractVersion: '4.0.0'
  }>
  readonly sourceLocation: AuthorLogicalSourceLocator
  readonly targetLayer: 'foundation' | 'semantic'
  readonly lifecycleByPath: Readonly<
    Record<string, 'stable' | 'experimental' | 'deprecated'>
  >
  readonly axes: ThemeAxisDeclarations
  readonly transforms: ThemeSourceAuthorInput['transforms']
  readonly passthroughPolicy?: 'preserve' | 'reject'
  readonly maxBytes?: number
  readonly maxDepth?: number
}

export interface DtcgImportResult {
  readonly themeSourceInput: ThemeSourceAuthorInput
  readonly passthroughExtensions: Readonly<Record<string, CanonicalJsonValue>>
  readonly sourceMap: Readonly<Record<string, AuthorLogicalSourceLocator>>
  readonly lifecycle: Readonly<
    Record<
      string,
      Readonly<{
        status: 'stable' | 'experimental' | 'deprecated'
        deprecated?: boolean | string
      }>
    >
  >
  readonly canonicalDocument: Readonly<Record<string, CanonicalJsonValue>>
}

export interface DtcgReexportRequest {
  readonly importResult: DtcgImportResult
  readonly sourceLocation: AuthorLogicalSourceLocator
  readonly maxDepth?: number
}

export interface DtcgReexportResult {
  readonly document: Readonly<Record<string, CanonicalJsonValue>>
  readonly text: string
  readonly mediaType: typeof DTCG_MEDIA_TYPE
  readonly sha256: `sha256:${string}`
}
