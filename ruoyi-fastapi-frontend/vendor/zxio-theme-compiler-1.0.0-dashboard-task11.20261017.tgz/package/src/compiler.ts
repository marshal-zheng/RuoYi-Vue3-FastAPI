import { compileAggregateCss } from './targets/css/aggregate-css'
import { isValidatedTailwindContractRef } from './adapters/tailwind'
import {
  ArtifactGraphBuilder,
  type ThemeArtifactFile,
  type ThemeArtifactPurpose,
  type ThemeArtifactSet,
  artifactSetHash,
  decodeArtifactBytes,
  verifyArtifactFile,
} from './core/artifact-graph'
import {
  canonicalHash,
  canonicalJson,
  compareCodePoint,
  deepFreeze,
} from './core/canonical-text'
import { diagnostic } from './core/diagnostics'
import { createKernelPort } from './core/kernel-port'
import {
  type MatrixVariant,
  planResolvedMatrix,
  validateAxisDeclarations,
} from './core/matrix'
import { createMutationSnapshotter } from './core/mutation-snapshot'
import { type CompilerResult, failure, success } from './core/result'
import { validateSerializerCoverage } from './core/type-serializers'
import { buildPublicCssAliases } from './targets/css/css-variable'
import {
  type CompiledVariantCss,
  compileAllVariantCss,
} from './targets/css/variant-css'
import { buildThemeManifest } from './targets/manifest/builder'
import { validateThemeManifest } from './targets/manifest/validator'
import { printTypegen } from './targets/typegen/printer'

import type { ThemeManifestV1 } from './targets/manifest/model'
import type {
  CompileResolvedMatrixRequest,
  CompileThemeSourceRequest,
  CreateResolvedMatrixAxesProofRequest,
  ResolvedMatrixAxesProof,
} from './model'
import type { AdapterArtifactContribution } from './adapters/types'
import type {
  BuiltInTypeMap,
  ThemeAxisDeclarations,
  ValidatedResolvedThemeV1,
  ValidatedThemePublicContractV4,
} from '@zxio/tokens/kernel'

type ThemeSet = ThemeArtifactSet<ThemeManifestV1>

interface PreparedCompile {
  readonly contract: ValidatedThemePublicContractV4<BuiltInTypeMap>
  readonly declarations: ThemeAxisDeclarations
  readonly resolved: readonly ValidatedResolvedThemeV1<BuiltInTypeMap>[]
}

const validatedResolvedMatrixAxesProofs = new WeakSet<object>()

function isValidatedResolvedMatrixAxesProof(
  input: unknown
): input is ResolvedMatrixAxesProof {
  return (
    input !== null &&
    typeof input === 'object' &&
    validatedResolvedMatrixAxesProofs.has(input)
  )
}

export function createResolvedMatrixAxesProof(
  request: CreateResolvedMatrixAxesProofRequest
): CompilerResult<ResolvedMatrixAxesProof> {
  const port = createKernelPort(request.kernel)
  const source = port.validateSource(request.source, request.sourceLocation)
  const contract = port.validateContract(
    request.contract,
    request.contractLocation
  )
  if (!source.ok || !contract.ok) {
    return failure([
      ...(!source.ok ? source.diagnostics : []),
      ...(!contract.ok ? contract.diagnostics : []),
    ])
  }
  const resolved = port.resolveAll({
    source: source.value,
    contract: contract.value,
    sourceLocation: request.sourceLocation,
    contractLocation: request.contractLocation,
  })
  if (!resolved.ok) return failure(resolved.diagnostics)
  const identity = resolved.value[0]
  if (!identity) {
    return failure([
      diagnostic({
        code: 'TC_MATRIX_INCOMPLETE',
        phase: 'matrix',
        source: request.sourceLocation,
        remediation: { code: 'PROVIDE_KERNEL_RESOLVABLE_AXIS_MATRIX' },
        details: { issue: 'empty-kernel-resolved-matrix' },
      }),
    ])
  }
  const proof = deepFreeze({
    themeId: identity.themeId,
    sourceSchemaVersion: identity.sourceSchemaVersion,
    sourceContentHash: identity.sourceContentHash,
    contractContentHash: identity.contractContentHash,
    typeRegistryContentHash: identity.typeRegistryContentHash,
    axes: source.value.axes,
  }) as ResolvedMatrixAxesProof
  validatedResolvedMatrixAxesProofs.add(proof)
  return success(proof)
}

function validateTailwind(
  contractHash: `sha256:${string}`,
  tailwindContract: CompileThemeSourceRequest['tailwindContract']
): CompilerResult<true> {
  if (!isValidatedTailwindContractRef(tailwindContract)) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        adapter: 'tailwind',
        remediation: { code: 'USE_VERIFIED_TAILWIND_CONTRACT_REF' },
        details: { issue: 'unbranded-tailwind-contract-ref' },
      }),
    ])
  }
  if (tailwindContract.contractContentHash !== contractHash) {
    return failure([
      diagnostic({
        code: 'TC_IDENTITY_MISMATCH',
        phase: 'adapter',
        adapter: 'tailwind',
        expected: contractHash,
        actual: tailwindContract.contractContentHash,
        remediation: { code: 'RECOMPILE_TAILWIND_FOR_EXACT_CONTRACT' },
        details: { identity: 'contractContentHash' },
      }),
    ])
  }
  return success(true)
}

function compileAdapters(
  request: CompileThemeSourceRequest,
  variants: readonly MatrixVariant<BuiltInTypeMap>[],
  css: readonly CompiledVariantCss[],
  contract: ValidatedThemePublicContractV4<BuiltInTypeMap>
): CompilerResult<
  Readonly<{
    elementPlus: AdapterArtifactContribution
    dtcg: AdapterArtifactContribution
  }>
> {
  const publicPaths = Object.keys(
    contract.entries
  ) as unknown as readonly import('@zxio/tokens/kernel').CanonicalTokenPath[]
  const aliases = buildPublicCssAliases(publicPaths)
  if (!aliases.ok) return failure(aliases.diagnostics)
  const adapters = new Map(
    request.adapters.map((adapter) => [adapter.id, adapter])
  )
  if (
    request.adapters.length !== 2 ||
    !adapters.has('element-plus') ||
    !adapters.has('dtcg')
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_EXACT_BUILTIN_THEME_ADAPTERS' },
        details: { adapterIds: request.adapters.map((adapter) => adapter.id) },
      }),
    ])
  }
  const context = {
    themeId: variants[0]?.resolved.themeId ?? '',
    variants,
    publicPaths,
    publicAliases: aliases.value,
    serializers: request.serializers,
    css,
  }
  const elementPlus = adapters.get('element-plus')!.compile(context)
  const dtcg = adapters.get('dtcg')!.compile(context)
  if (!elementPlus.ok || !dtcg.ok) {
    return failure([
      ...(!elementPlus.ok ? elementPlus.diagnostics : []),
      ...(!dtcg.ok ? dtcg.diagnostics : []),
    ])
  }
  return success({ elementPlus: elementPlus.value, dtcg: dtcg.value })
}

function addThemeFiles(
  graph: ArtifactGraphBuilder<ThemeArtifactPurpose>,
  css: readonly CompiledVariantCss[],
  adapters: Readonly<{
    elementPlus: AdapterArtifactContribution
    dtcg: AdapterArtifactContribution
  }>
): void {
  for (const variant of css) {
    graph.addText({
      path: `variants/${variant.variantKey}.css`,
      mediaType: 'text/css',
      purpose: 'core-css',
      loadPhase: 'variant',
      text: variant.text,
    })
  }
  graph.addText({
    path: 'theme.css',
    mediaType: 'text/css',
    purpose: 'aggregate-css',
    loadPhase: 'theme',
    text: compileAggregateCss(css),
  })
  for (const file of [...adapters.elementPlus.files, ...adapters.dtcg.files]) {
    graph.addText(file)
  }
}

function compilePrepared(
  request: CompileThemeSourceRequest,
  prepared: PreparedCompile
): CompilerResult<ThemeSet> {
  const planned = planResolvedMatrix(
    prepared.resolved[0]?.themeId ?? '',
    prepared.declarations,
    prepared.resolved,
    request.sourceLocation
  )
  if (!planned.ok) return failure(planned.diagnostics)
  const serializerCoverage = validateSerializerCoverage(
    request.kernel.registeredTypeIds,
    Object.entries(planned.value[0]?.resolved.tokens ?? {}).map(
      ([path, token]) => ({
        path,
        typeId: token.typeId,
        layer: path.split('.')[0] as 'foundation' | 'semantic' | 'components',
        visibility: token.visibility,
        source: token.source,
      })
    ),
    request.serializers as Readonly<
      Record<
        string,
        import('./core/type-serializers').TargetTypeSerializer<unknown>
      >
    >
  )
  if (!serializerCoverage.ok) return failure(serializerCoverage.diagnostics)
  const tailwind = validateTailwind(
    planned.value[0]?.resolved.contractContentHash ?? 'sha256:',
    request.tailwindContract
  )
  if (!tailwind.ok) return failure(tailwind.diagnostics)
  const css = compileAllVariantCss(planned.value, request.serializers)
  if (!css.ok) return failure(css.diagnostics)
  const adapters = compileAdapters(
    request,
    planned.value,
    css.value,
    prepared.contract
  )
  if (!adapters.ok) return failure(adapters.diagnostics)

  const graph = new ArtifactGraphBuilder<ThemeArtifactPurpose>()
  addThemeFiles(graph, css.value, adapters.value)
  const base = graph.finalize()
  if (!base.ok) return failure(base.diagnostics)
  const provisional = buildThemeManifest({
    package: request.package,
    contract: prepared.contract,
    declarations: prepared.declarations,
    variants: planned.value,
    css: css.value,
    files: base.value,
    elementPlus: adapters.value.elementPlus,
    dtcg: adapters.value.dtcg,
    tailwind: request.tailwindContract,
  })
  const typegen = printTypegen(
    provisional,
    request.serializers as Readonly<
      Record<
        string,
        import('./core/type-serializers').TargetTypeSerializer<unknown>
      >
    >
  )
  graph.addText({
    path: 'typegen.mjs',
    mediaType: 'text/javascript',
    purpose: 'typegen-runtime',
    loadPhase: 'tooling',
    text: typegen.esm,
  })
  graph.addText({
    path: 'typegen.cjs',
    mediaType: 'text/javascript',
    purpose: 'typegen-runtime',
    loadPhase: 'tooling',
    text: typegen.cjs,
  })
  graph.addText({
    path: 'typegen.d.ts',
    mediaType: 'text/typescript',
    purpose: 'typegen-declarations',
    loadPhase: 'tooling',
    text: typegen.declarations,
  })
  const withoutManifest = graph.finalize()
  if (!withoutManifest.ok) return failure(withoutManifest.diagnostics)
  const manifest = buildThemeManifest({
    package: request.package,
    contract: prepared.contract,
    declarations: prepared.declarations,
    variants: planned.value,
    css: css.value,
    files: withoutManifest.value,
    elementPlus: adapters.value.elementPlus,
    dtcg: adapters.value.dtcg,
    tailwind: request.tailwindContract,
  })
  const validated = validateThemeManifest(manifest)
  if (!validated.ok) return failure(validated.diagnostics)
  const manifestGraph = new ArtifactGraphBuilder<'theme-manifest'>()
  manifestGraph.addJson({
    path: 'theme.manifest.json',
    mediaType: 'application/json',
    purpose: 'theme-manifest',
    loadPhase: 'tooling',
    value: manifest,
  })
  const manifestFile = manifestGraph.finalize()
  if (!manifestFile.ok) return failure(manifestFile.diagnostics)
  const files = [...withoutManifest.value, ...manifestFile.value].sort(
    (left, right) => compareCodePoint(left.path, right.path)
  ) as readonly ThemeArtifactFile[]
  return verifyArtifactSet({
    kind: 'theme',
    themeId: manifest.identity.themeId,
    files,
    manifest,
    artifactSetHash: artifactSetHash(files),
  })
}

function compileThemeInternal(
  request: CompileThemeSourceRequest
): CompilerResult<ThemeSet> {
  if (request.kind !== 'source') {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'USE_SOURCE_COMPILE_REQUEST' },
        details: {
          kind: String((request as Readonly<{ kind?: unknown }>).kind),
        },
      }),
    ])
  }
  const port = createKernelPort(request.kernel)
  const source = port.validateSource(request.source, request.sourceLocation)
  const contract = port.validateContract(
    request.contract,
    request.contractLocation
  )
  if (!source.ok || !contract.ok) {
    return failure([
      ...(!source.ok ? source.diagnostics : []),
      ...(!contract.ok ? contract.diagnostics : []),
    ])
  }
  const resolved = port.resolveAll({
    source: source.value,
    contract: contract.value,
    sourceLocation: request.sourceLocation,
    contractLocation: request.contractLocation,
  })
  if (!resolved.ok) return failure(resolved.diagnostics)
  return compilePrepared(request, {
    contract: contract.value,
    declarations: source.value.axes,
    resolved: resolved.value,
  })
}

function compileResolvedThemeMatrixInternal(
  request: CompileResolvedMatrixRequest
): CompilerResult<ThemeSet> {
  if (request.kind !== 'resolved-matrix') {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'USE_RESOLVED_MATRIX_REQUEST' },
        details: { issue: 'wrong-request-kind' },
      }),
    ])
  }
  const expectedEnvelopeKeys = [
    'axesProof',
    'contractContentHash',
    'resolved',
    'sourceContentHash',
    'sourceSchemaVersion',
    'themeId',
    'typeRegistryContentHash',
  ]
  const envelopeKeys = Object.keys(request.matrix).sort(compareCodePoint)
  const hashPattern = /^sha256:[a-f0-9]{64}$/
  if (
    canonicalJson(envelopeKeys) !== canonicalJson(expectedEnvelopeKeys) ||
    request.matrix.sourceSchemaVersion !== 4 ||
    typeof request.matrix.themeId !== 'string' ||
    !/^[a-z][a-z0-9-]*$/.test(request.matrix.themeId) ||
    !hashPattern.test(request.matrix.sourceContentHash) ||
    !hashPattern.test(request.matrix.contractContentHash) ||
    !hashPattern.test(request.matrix.typeRegistryContentHash) ||
    !Array.isArray(request.matrix.resolved)
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'matrix',
        source: request.sourceLocation,
        expected: expectedEnvelopeKeys,
        actual: envelopeKeys,
        target: 'exact resolved-matrix envelope',
        remediation: { code: 'PASS_EXACT_RESOLVED_MATRIX_ENVELOPE' },
        details: { issue: 'invalid-resolved-matrix-envelope' },
      }),
    ])
  }
  if (!isValidatedResolvedMatrixAxesProof(request.matrix.axesProof)) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'matrix',
        source: request.sourceLocation,
        jsonPath: '$.matrix.axesProof',
        target: 'Kernel-validated resolved matrix axes proof',
        remediation: { code: 'CREATE_RESOLVED_MATRIX_AXES_PROOF' },
        details: { issue: 'unvalidated-resolved-matrix-axes-proof' },
      }),
    ])
  }
  const proof = request.matrix.axesProof
  const axes = validateAxisDeclarations(proof.axes, request.sourceLocation)
  if (!axes.ok) return failure(axes.diagnostics)
  const port = createKernelPort(request.kernel)
  const contract = port.validateContract(
    request.contract,
    request.contractLocation
  )
  if (!contract.ok) return failure(contract.diagnostics)
  const contractContentHash = canonicalHash(contract.value)
  const envelopeIdentityDiagnostics = []
  for (const identity of [
    'themeId',
    'sourceSchemaVersion',
    'sourceContentHash',
    'contractContentHash',
    'typeRegistryContentHash',
  ] as const) {
    if (request.matrix[identity] !== proof[identity]) {
      envelopeIdentityDiagnostics.push(
        diagnostic({
          code: 'TC_IDENTITY_MISMATCH',
          phase: 'matrix',
          source: request.sourceLocation,
          expected: proof[identity],
          actual: request.matrix[identity],
          target: `Kernel-proven ${identity}`,
          remediation: { code: 'USE_MATCHING_RESOLVED_MATRIX_AXES_PROOF' },
          details: { identity },
        })
      )
    }
  }
  if (contractContentHash !== request.matrix.contractContentHash) {
    envelopeIdentityDiagnostics.push(
      diagnostic({
        code: 'TC_IDENTITY_MISMATCH',
        phase: 'matrix',
        source: request.contractLocation,
        expected: contractContentHash,
        actual: request.matrix.contractContentHash,
        target: 'validated Kernel public contract hash',
        remediation: { code: 'USE_MATCHING_VALIDATED_CONTRACT' },
        details: { identity: 'contractContentHash' },
      })
    )
  }
  if (
    request.kernel.typeRegistryContentHash !==
    request.matrix.typeRegistryContentHash
  ) {
    envelopeIdentityDiagnostics.push(
      diagnostic({
        code: 'TC_IDENTITY_MISMATCH',
        phase: 'matrix',
        source: request.sourceLocation,
        expected: request.kernel.typeRegistryContentHash,
        actual: request.matrix.typeRegistryContentHash,
        target: 'Kernel type registry identity',
        remediation: { code: 'USE_MATCHING_KERNEL_REGISTRY' },
        details: { identity: 'typeRegistryContentHash' },
      })
    )
  }
  if (envelopeIdentityDiagnostics.length > 0)
    return failure(envelopeIdentityDiagnostics)
  const matrix = port.validateResolvedMatrix({
    resolved: request.matrix.resolved,
    declarations: axes.value,
    sourceLocation: request.sourceLocation,
  })
  if (!matrix.ok) return failure(matrix.diagnostics)
  const identities = matrix.value.flatMap((entry) => {
    const mismatches = []
    if (entry.themeId !== request.matrix.themeId) mismatches.push('themeId')
    if (entry.sourceSchemaVersion !== request.matrix.sourceSchemaVersion)
      mismatches.push('sourceSchemaVersion')
    if (entry.sourceContentHash !== request.matrix.sourceContentHash)
      mismatches.push('sourceContentHash')
    if (entry.contractContentHash !== request.matrix.contractContentHash)
      mismatches.push('contractContentHash')
    if (
      entry.typeRegistryContentHash !== request.matrix.typeRegistryContentHash
    )
      mismatches.push('typeRegistryContentHash')
    return mismatches.length === 0
      ? []
      : [{ selection: entry.axes.selection, mismatches }]
  })
  if (identities.length > 0) {
    return failure([
      diagnostic({
        code: 'TC_IDENTITY_MISMATCH',
        phase: 'matrix',
        source: request.sourceLocation,
        remediation: { code: 'USE_ONE_EXACT_MATRIX_ENVELOPE' },
        details: { identities },
      }),
    ])
  }
  return compilePrepared(
    { ...request, kind: 'source', source: {} },
    {
      contract: contract.value,
      declarations: axes.value,
      resolved: matrix.value,
    }
  )
}

function guardCompileRequest(
  request: unknown,
  compile: () => CompilerResult<ThemeSet>
): CompilerResult<ThemeSet> {
  const snapshotter = createMutationSnapshotter()
  let before: string
  try {
    before = snapshotter.snapshot(request)
  } catch (error) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'USE_SNAPSHOT_SAFE_COMPILE_REQUEST' },
        details: {
          issue: 'compile-request-snapshot-failed',
          error: error instanceof Error ? error.name : 'UnknownError',
        },
      }),
    ])
  }
  let result: CompilerResult<ThemeSet>
  try {
    result = compile()
  } catch (error) {
    result = failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'FIX_COMPILE_REQUEST_OR_EXTENSION' },
        details: {
          issue: 'compile-request-threw',
          error: error instanceof Error ? error.name : 'UnknownError',
        },
      }),
    ])
  }
  let after: string
  try {
    after = snapshotter.snapshot(request)
  } catch (error) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'DO_NOT_MUTATE_COMPILE_INPUT' },
        details: {
          issue: 'compile-request-mutated-to-unsnapshotable-state',
          error: error instanceof Error ? error.name : 'UnknownError',
        },
      }),
    ])
  }
  if (before !== after) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'DO_NOT_MUTATE_COMPILE_INPUT' },
        details: { issue: 'compile-request-mutated' },
      }),
    ])
  }
  return result
}

export function compileTheme(
  request: CompileThemeSourceRequest
): CompilerResult<ThemeSet> {
  return guardCompileRequest(request, () => compileThemeInternal(request))
}

export function compileResolvedThemeMatrix(
  request: CompileResolvedMatrixRequest
): CompilerResult<ThemeSet> {
  return guardCompileRequest(request, () =>
    compileResolvedThemeMatrixInternal(request)
  )
}

const THEME_ARTIFACT_SET_KEYS = [
  'artifactSetHash',
  'files',
  'kind',
  'manifest',
  'themeId',
] as const

function hasExactThemeFileMetadata(file: ThemeArtifactFile): boolean {
  switch (file.purpose) {
    case 'core-css':
      return (
        file.mediaType === 'text/css' &&
        file.loadPhase === 'variant' &&
        /^variants\/[^/]+\.css$/.test(file.path)
      )
    case 'aggregate-css':
      return (
        file.path === 'theme.css' &&
        file.mediaType === 'text/css' &&
        file.loadPhase === 'theme'
      )
    case 'typegen-runtime':
      return (
        (file.path === 'typegen.mjs' || file.path === 'typegen.cjs') &&
        file.mediaType === 'text/javascript' &&
        file.loadPhase === 'tooling'
      )
    case 'typegen-declarations':
      return (
        file.path === 'typegen.d.ts' &&
        file.mediaType === 'text/typescript' &&
        file.loadPhase === 'tooling'
      )
    case 'element-plus-alias':
      return (
        file.path === 'element-plus/aliases.css' &&
        file.mediaType === 'text/css' &&
        file.loadPhase === 'theme'
      )
    case 'element-plus-resolved':
      return (
        /^element-plus\/resolved\/[^/]+\.css$/.test(file.path) &&
        file.mediaType === 'text/css' &&
        file.loadPhase === 'variant'
      )
    case 'dtcg-token-set':
      return (
        /^dtcg\/[^/]+\.tokens\.json$/.test(file.path) &&
        file.mediaType === 'application/design-tokens+json' &&
        file.loadPhase === 'variant'
      )
    case 'dtcg-index':
      return (
        file.path === 'dtcg/variants.json' &&
        file.mediaType === 'application/json' &&
        file.loadPhase === 'tooling'
      )
    case 'theme-manifest':
      return (
        file.path === 'theme.manifest.json' &&
        file.mediaType === 'application/json' &&
        file.loadPhase === 'tooling'
      )
    default:
      return false
  }
}

function verifyArtifactSetInternal(input: unknown): CompilerResult<ThemeSet> {
  if (!input || typeof input !== 'object') {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_THEME_ARTIFACT_SET' },
        details: { issue: 'not-object' },
      }),
    ])
  }
  const candidate = input as Partial<ThemeSet>
  const actualTopLevelKeys = Object.keys(candidate).sort(compareCodePoint)
  if (
    candidate.kind !== 'theme' ||
    !Array.isArray(candidate.files) ||
    !candidate.manifest ||
    typeof candidate.themeId !== 'string' ||
    typeof candidate.artifactSetHash !== 'string' ||
    !/^sha256:[a-f0-9]{64}$/.test(candidate.artifactSetHash) ||
    canonicalJson(actualTopLevelKeys) !== canonicalJson(THEME_ARTIFACT_SET_KEYS)
  ) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_THEME_ARTIFACT_SET' },
        expected: THEME_ARTIFACT_SET_KEYS,
        actual: actualTopLevelKeys,
        details: { issue: 'invalid-shape' },
      }),
    ])
  }
  const files = candidate.files as readonly ThemeArtifactFile[]
  const diagnostics = files.flatMap((file) => {
    const result = verifyArtifactFile(file)
    return result.ok ? [] : result.diagnostics
  })
  if (diagnostics.length > 0) return failure(diagnostics)
  const paths = files.map((file) => file.path)
  const sortedPaths = [...paths].sort(compareCodePoint)
  if (
    canonicalJson(paths) !== canonicalJson(sortedPaths) ||
    new Set(paths).size !== paths.length
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ARTIFACT_DUPLICATE',
        phase: 'manifest',
        remediation: { code: 'RESTORE_SORTED_UNIQUE_THEME_OWNER_SET' },
        expected: sortedPaths,
        actual: paths,
        details: { issue: 'unsorted-or-duplicate-owner-set' },
      })
    )
  }
  const invalidMetadata = files
    .filter((file) => !hasExactThemeFileMetadata(file))
    .map((file) => ({
      path: file.path,
      mediaType: file.mediaType,
      purpose: file.purpose,
      loadPhase: file.loadPhase,
    }))
  if (invalidMetadata.length > 0) {
    diagnostics.push(
      diagnostic({
        code: 'TC_MANIFEST_INVALID',
        phase: 'manifest',
        remediation: { code: 'RESTORE_THEME_ARTIFACT_METADATA' },
        details: { issue: 'invalid-file-metadata', invalidMetadata },
      })
    )
  }
  const manifest = validateThemeManifest(candidate.manifest)
  if (!manifest.ok) diagnostics.push(...manifest.diagnostics)
  const manifestFiles = files.filter(
    (file) => file.path === 'theme.manifest.json'
  )
  const manifestFile = manifestFiles[0]
  if (
    manifestFiles.length !== 1 ||
    !manifestFile ||
    new TextDecoder().decode(decodeArtifactBytes(manifestFile.bytes)) !==
      canonicalJson(candidate.manifest)
  ) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ARTIFACT_HASH_MISMATCH',
        phase: 'manifest',
        artifactPath: 'theme.manifest.json',
        remediation: { code: 'RESTORE_CANONICAL_MANIFEST_BYTES' },
        details: { issue: 'manifest-bytes-mismatch' },
      })
    )
  }
  if (manifest.ok) {
    if (candidate.themeId !== manifest.value.identity.themeId) {
      diagnostics.push(
        diagnostic({
          code: 'TC_IDENTITY_MISMATCH',
          phase: 'manifest',
          expected: manifest.value.identity.themeId,
          actual: candidate.themeId,
          remediation: { code: 'RESTORE_THEME_IDENTITY' },
          details: { identity: 'themeId' },
        })
      )
    }
    const manifestArtifacts = new Map(
      manifest.value.artifacts.map((artifact) => [artifact.path, artifact])
    )
    const nonManifestFiles = files.filter(
      (file) => file.path !== 'theme.manifest.json'
    )
    const expectedPaths = [
      ...manifest.value.artifacts.map((artifact) => artifact.path),
      'theme.manifest.json',
    ].sort(compareCodePoint)
    if (canonicalJson(paths) !== canonicalJson(expectedPaths)) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          expected: expectedPaths,
          actual: paths,
          remediation: { code: 'RESTORE_EXACT_THEME_OWNER_SET' },
          details: { issue: 'artifact-owner-set-mismatch' },
        })
      )
    }
    const metadataMismatches = nonManifestFiles.flatMap((file) => {
      const declared = manifestArtifacts.get(file.path)
      const actual = {
        path: file.path,
        mediaType: file.mediaType,
        bytes: file.byteLength,
        sha256: file.sha256,
        purpose: file.purpose,
        loadPhase: file.loadPhase,
      }
      return !declared || canonicalJson(declared) !== canonicalJson(actual)
        ? [{ path: file.path, expected: declared ?? null, actual }]
        : []
    })
    if (metadataMismatches.length > 0) {
      diagnostics.push(
        diagnostic({
          code: 'TC_MANIFEST_INVALID',
          phase: 'manifest',
          remediation: { code: 'RESTORE_MANIFEST_FILE_METADATA_PARITY' },
          details: {
            issue: 'manifest-file-metadata-mismatch',
            metadataMismatches:
              metadataMismatches as unknown as import('@zxio/tokens/kernel').CanonicalJsonValue,
          },
        })
      )
    }
  }
  if (candidate.artifactSetHash !== artifactSetHash(files)) {
    diagnostics.push(
      diagnostic({
        code: 'TC_ARTIFACT_HASH_MISMATCH',
        phase: 'manifest',
        remediation: { code: 'RECOMPUTE_ARTIFACT_SET_HASH' },
        details: { issue: 'artifact-set-hash-mismatch' },
      })
    )
  }
  if (diagnostics.length > 0 || !manifest.ok) return failure(diagnostics)
  return success({
    kind: 'theme',
    themeId: manifest.value.identity.themeId,
    files: files.map((file) => ({ ...file })) as readonly ThemeArtifactFile[],
    manifest: manifest.value,
    artifactSetHash: candidate.artifactSetHash!,
  })
}

export function verifyArtifactSet(input: unknown): CompilerResult<ThemeSet> {
  try {
    return verifyArtifactSetInternal(input)
  } catch (error) {
    return failure([
      diagnostic({
        code: 'TC_INPUT_INVALID',
        phase: 'input',
        remediation: { code: 'PASS_THEME_ARTIFACT_SET' },
        details: {
          issue: 'malformed-nested-structure',
          error: error instanceof Error ? error.name : 'UnknownError',
        },
      }),
    ])
  }
}
