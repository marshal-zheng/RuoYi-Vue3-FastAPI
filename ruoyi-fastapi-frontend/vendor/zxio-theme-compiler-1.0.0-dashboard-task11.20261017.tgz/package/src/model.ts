import type {
  AuthorLogicalSourceLocator,
  BuiltInTypeMap,
  ThemeAxisDeclarations,
  ThemeKernel,
  ThemeTypeMap,
} from '@zxio/tokens/kernel'
import type { ThemeAdapter } from './adapters/types'
import type { ValidatedExternalTailwindAdapterContractRef } from './adapters/tailwind/model'
import type {
  TailwindContractArtifactSet,
  ThemeArtifactSet,
} from './core/artifact-graph'
import type { TargetSerializerRegistry } from './core/type-serializers'

export interface CompilePackageMetadata {
  readonly packageName: `@zxio/${string}`
  readonly packageVersion: `${number}.${number}.${number}`
  readonly compilerVersion: `${number}.${number}.${number}`
}

interface CompileRequestBase<M extends ThemeTypeMap> {
  readonly kernel: ThemeKernel<M>
  readonly contract: unknown
  readonly sourceLocation: AuthorLogicalSourceLocator
  readonly contractLocation: AuthorLogicalSourceLocator
  readonly package: CompilePackageMetadata
  readonly serializers: TargetSerializerRegistry<M>
  readonly adapters: readonly ThemeAdapter[]
  readonly tailwindContract: ValidatedExternalTailwindAdapterContractRef
}

declare const resolvedMatrixAxesProofBrand: unique symbol

/**
 * An opaque, process-local attestation that the Kernel accepted the source,
 * contract, and the source-owned supported/default axis declarations.
 *
 * Callers cannot reconstruct this value from a resolved matrix. They must use
 * `createResolvedMatrixAxesProof` with the exact author source and contract.
 */
export interface ResolvedMatrixAxesProof {
  readonly themeId: string
  readonly sourceSchemaVersion: 4
  readonly sourceContentHash: `sha256:${string}`
  readonly contractContentHash: `sha256:${string}`
  readonly typeRegistryContentHash: `sha256:${string}`
  readonly axes: ThemeAxisDeclarations
  readonly [resolvedMatrixAxesProofBrand]: true
}

export interface CreateResolvedMatrixAxesProofRequest<
  M extends ThemeTypeMap = BuiltInTypeMap
> {
  readonly kernel: ThemeKernel<M>
  readonly source: unknown
  readonly contract: unknown
  readonly sourceLocation: AuthorLogicalSourceLocator
  readonly contractLocation: AuthorLogicalSourceLocator
}

export interface CompileThemeSourceRequest<
  M extends ThemeTypeMap = BuiltInTypeMap
> extends CompileRequestBase<M> {
  readonly kind: 'source'
  readonly source: unknown
}

export interface CompileResolvedMatrixRequest<
  M extends ThemeTypeMap = BuiltInTypeMap
> extends CompileRequestBase<M> {
  readonly kind: 'resolved-matrix'
  readonly matrix: Readonly<{
    readonly themeId: string
    readonly sourceSchemaVersion: 4
    readonly sourceContentHash: `sha256:${string}`
    readonly contractContentHash: `sha256:${string}`
    readonly typeRegistryContentHash: `sha256:${string}`
    readonly axesProof: ResolvedMatrixAxesProof
    readonly resolved: readonly unknown[]
  }>
}

export interface WriteArtifactSetRequest {
  readonly packageRoot: string
  readonly generatedRoot: 'generated'
  readonly artifactSet: ThemeArtifactSet | TailwindContractArtifactSet
}
