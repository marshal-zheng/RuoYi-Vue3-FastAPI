export {
  compileResolvedThemeMatrix,
  compileTheme,
  createResolvedMatrixAxesProof,
  verifyArtifactSet,
} from './compiler'
export {
  ArtifactGraphBuilder,
  artifactSetHash,
  decodeArtifactBytes,
  encodeArtifactBytes,
  verifyArtifactFile,
} from './core/artifact-graph'
export type {
  ArtifactFile,
  CanonicalBase64Bytes,
  TailwindContractArtifactSet,
  ThemeArtifactSet,
} from './core/artifact-graph'
export type {
  ThemeCompilerDiagnostic,
  ThemeCompilerDiagnosticCode,
} from './core/diagnostics'
export { createKernelPort } from './core/kernel-port'
export {
  APPLICATION_ORDER,
  enumerateSelections,
  planResolvedMatrix,
} from './core/matrix'
export type { CompilerResult } from './core/result'
export { createThemeSelector } from './core/selector'
export { builtInSerializers } from './core/type-serializers'
export type {
  TargetSerializerRegistry,
  TargetTypeSerializer,
} from './core/type-serializers'
export { createVariantKey, VARIANT_KEY_SCHEMA } from './core/variant-key'
export type {
  CompilePackageMetadata,
  CreateResolvedMatrixAxesProofRequest,
  CompileResolvedMatrixRequest,
  CompileThemeSourceRequest,
  ResolvedMatrixAxesProof,
  WriteArtifactSetRequest,
} from './model'
export type {
  ManifestArtifact,
  ManifestPublicToken,
  ManifestVariant,
  ThemeManifestV1,
} from './targets/manifest/model'
export { validateThemeManifest } from './targets/manifest/validator'
export {
  buildPublicCssAliases,
  internalCssVariable,
  publicCssVariable,
} from './targets/css/css-variable'
export type {
  PublicCssAlias,
  PublicCssAliasRegistry,
} from './targets/css/css-variable'
export { compareArtifactSet, writeArtifactSet } from './writer'
export type {
  ArtifactDiff,
  CompareArtifactSetRequest,
  WriteReceipt,
} from './writer'
