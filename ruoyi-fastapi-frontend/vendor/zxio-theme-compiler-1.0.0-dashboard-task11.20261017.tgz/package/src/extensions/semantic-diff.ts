import {
  canonicalThemeExtensionJson,
  validateThemeExtensionCoreRequirements,
} from '@zxio/tokens/extensions'

import type { ThemeSemanticCatalog } from '@zxio/tokens/semantic-contract'
import type { ValidatedThemeExtensionManifestV1 } from '@zxio/tokens/extensions'

/** Structural reporting does not replace the existing exact admission policy. */
export function diffThemeSemanticContracts(
  previous: ThemeSemanticCatalog,
  next: ThemeSemanticCatalog,
  consumers: readonly ValidatedThemeExtensionManifestV1[] = []
) {
  const old = new Map(previous.entries.map((entry) => [entry.path, entry]))
  const current = new Map(next.entries.map((entry) => [entry.path, entry]))
  const changes: {
    path: string
    field: string
    previous: unknown
    next: unknown
  }[] = []
  for (const path of [...new Set([...old.keys(), ...current.keys()])].sort()) {
    const a = old.get(path),
      b = current.get(path)
    if (!a || !b) {
      changes.push({
        path,
        field: a ? 'removed' : 'added',
        previous: a ?? null,
        next: b ?? null,
      })
      continue
    }
    for (const field of [
      'typeId',
      'css',
      'lifecycle',
      'deprecated',
      'description',
    ] as const)
      if (
        canonicalThemeExtensionJson(a[field] ?? null) !==
        canonicalThemeExtensionJson(b[field] ?? null)
      )
        changes.push({
          path,
          field,
          previous: a[field] ?? null,
          next: b[field] ?? null,
        })
  }
  return {
    changes,
    compatibility: consumers.map((manifest) => ({
      packageName: manifest.identity.packageName,
      result: validateThemeExtensionCoreRequirements([manifest], next),
    })),
  }
}
