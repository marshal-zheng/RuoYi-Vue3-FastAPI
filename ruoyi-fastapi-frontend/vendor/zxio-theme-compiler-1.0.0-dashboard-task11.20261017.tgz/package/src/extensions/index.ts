import {
  lstat,
  mkdir,
  mkdtemp,
  readFile,
  readdir,
  rename,
  rm,
  writeFile,
} from 'node:fs/promises'
import { basename, dirname, resolve } from 'node:path'
import {
  canonicalThemeExtensionJson,
  createThemeExtensionBundle,
  validateThemeExtensionBundle,
} from '@zxio/tokens/extensions'
import { themeExtensionCssEncoder } from '@zxio/theme-css-codec'

import type {
  CreateThemeExtensionPlanInput,
  ThemeExtensionBundleV1,
  ThemeExtensionResult,
} from '@zxio/tokens/extensions'

export type CompileThemeExtensionsInput = Omit<
  CreateThemeExtensionPlanInput,
  'encoder'
> &
  Partial<Pick<CreateThemeExtensionPlanInput, 'encoder'>>
function isPlainInput(input: unknown): boolean {
  try {
    if (!input || typeof input !== 'object' || Array.isArray(input))
      return false
    const prototype = Object.getPrototypeOf(input)
    return (
      (prototype === Object.prototype || prototype === null) &&
      Object.getOwnPropertySymbols(input).length === 0 &&
      Object.values(Object.getOwnPropertyDescriptors(input)).every(
        (descriptor) => 'value' in descriptor
      )
    )
  } catch {
    return false
  }
}
export function compileThemeExtensions(
  input: CompileThemeExtensionsInput
): ThemeExtensionResult<ThemeExtensionBundleV1> {
  if (!isPlainInput(input)) {
    return {
      ok: false,
      diagnostics: [
        {
          code: 'TX_INPUT_INVALID',
          severity: 'error',
          path: '$',
          details: { issue: 'data-properties-required' },
        },
      ],
    }
  }
  return createThemeExtensionBundle({
    ...input,
    encoder: input.encoder ?? themeExtensionCssEncoder,
  })
}
/** Writes a new release directory atomically; an identical existing release is a no-op. */
export async function writeThemeExtensionBundle(input: {
  readonly directory: string
  readonly bundle: ThemeExtensionBundleV1
  readonly dependencies?: readonly import('@zxio/tokens/extensions').ThemeExtensionManifestV1[]
}): Promise<ThemeExtensionResult<readonly string[]>> {
  const verified = validateThemeExtensionBundle(input.bundle, {
    encoder: themeExtensionCssEncoder,
    dependencies: input.dependencies,
  })
  if (!verified.ok) return verified
  const files = [
    ...verified.value.files,
    {
      path: 'extension.manifest.json',
      mediaType: 'application/json',
      text: `${canonicalThemeExtensionJson(verified.value.manifest)}\n`,
    },
  ]
  let staging: string | undefined
  let lock: string | undefined
  try {
    const directory = resolve(input.directory)
    const stat = await lstat(directory).catch((error) => {
      if (error.code === 'ENOENT') return undefined
      throw error
    })
    if (stat && (!stat.isDirectory() || stat.isSymbolicLink()))
      throw new Error('output-path-must-be-a-real-directory')
    await mkdir(dirname(directory), { recursive: true })
    const lockPath = `${directory}.lock`
    await mkdir(lockPath)
    lock = lockPath
    const existing = await readdir(directory).catch((error) => {
      if (error.code === 'ENOENT') return undefined
      throw error
    })
    if (existing) {
      if (
        JSON.stringify(existing.sort()) !==
        JSON.stringify(files.map((file) => file.path).sort())
      )
        throw new Error('existing-output-is-not-this-release')
      for (const file of files) {
        const path = resolve(directory, file.path),
          stat = await lstat(path)
        if (
          !stat.isFile() ||
          stat.isSymbolicLink() ||
          (await readFile(path, 'utf8')) !== file.text
        )
          throw new Error('existing-output-is-not-this-release')
      }
    } else {
      staging = await mkdtemp(
        resolve(dirname(directory), `.${basename(directory)}-stage-`)
      )
      for (const file of files)
        await writeFile(resolve(staging, file.path), file.text, {
          encoding: 'utf8',
          flag: 'wx',
        })
      await rename(staging, directory)
      staging = undefined
    }
    return {
      ok: true,
      value: files.map((file) => resolve(directory, file.path)),
      diagnostics: verified.diagnostics,
    }
  } catch {
    return {
      ok: false,
      diagnostics: [
        {
          code: 'TX_ARTIFACT_INVALID',
          severity: 'error',
          path: '$.directory',
          details: {
            issue: 'write-failed-or-existing-output-differs',
            hint: 'Use a new release directory; existing or foreign files are preserved.',
          },
        },
      ],
    }
  } finally {
    if (staging) await rm(staging, { recursive: true, force: true })
    if (lock) await rm(lock, { recursive: true, force: true })
  }
}
export type {
  ThemeExtensionBundleV1,
  ThemeExtensionManifestV1,
} from '@zxio/tokens/extensions'

export { diffThemeSemanticContracts } from './semantic-diff'
