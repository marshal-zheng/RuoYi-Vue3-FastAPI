/** Public, versioned display roles. Values in theme assets remain unscaled bases. */
export declare const DISPLAY_CONTRACT_VERSION: 1;
export declare const DISPLAY_SCALES: readonly [90, 100, 110, 125];
export declare const DISPLAY_PROFILES: readonly ["office", "distance"];
export type ZxDisplayScale = (typeof DISPLAY_SCALES)[number];
export type ZxDisplayProfile = (typeof DISPLAY_PROFILES)[number];
export interface ZxDisplayRequest {
    readonly profile?: ZxDisplayProfile;
    readonly scale?: ZxDisplayScale;
}
export type ZxDisplayMetricPolicy = 'ui-length' | 'fixed-length' | 'domain-length' | 'unitless-ratio';
export interface ZxDisplayMetricDefinition {
    readonly source: string;
    readonly policy: ZxDisplayMetricPolicy;
    readonly role: 'text' | 'line-box' | 'icon' | 'spacing' | 'stroke' | 'content';
    /** Calibration at the default 16px browser font and default density. */
    readonly office100Px?: number;
    /** Initial distance calibration; final values require device and viewing-distance checks. */
    readonly distance100Px?: number;
    readonly officeFloorPx?: number;
    readonly distanceFloorPx?: number;
}
export declare const displayMetricCatalog: Readonly<{
    readonly 'text.extra-small': {
        readonly source: "semantic.typography.size-extra-small";
        readonly policy: "ui-length";
        readonly role: "text";
        readonly office100Px: 12;
        readonly distance100Px: 20;
        readonly officeFloorPx: 11;
        readonly distanceFloorPx: 18;
    };
    readonly 'text.small': {
        readonly source: "semantic.typography.size-small";
        readonly policy: "ui-length";
        readonly role: "text";
        readonly office100Px: 13;
        readonly distance100Px: 20;
        readonly officeFloorPx: 12;
        readonly distanceFloorPx: 18;
    };
    readonly 'text.body': {
        readonly source: "semantic.typography.size-base";
        readonly policy: "ui-length";
        readonly role: "text";
        readonly office100Px: 14;
        readonly distance100Px: 24;
        readonly officeFloorPx: 12;
        readonly distanceFloorPx: 20;
    };
    readonly 'text.medium': {
        readonly source: "semantic.typography.size-medium";
        readonly policy: "ui-length";
        readonly role: "text";
        readonly office100Px: 16;
        readonly distance100Px: 24;
        readonly officeFloorPx: 14;
        readonly distanceFloorPx: 20;
    };
    readonly 'text.large': {
        readonly source: "semantic.typography.size-large";
        readonly policy: "ui-length";
        readonly role: "text";
        readonly office100Px: 18;
        readonly distance100Px: 28;
        readonly officeFloorPx: 16;
        readonly distanceFloorPx: 24;
    };
    readonly 'text.title': {
        readonly source: "semantic.typography.size-extra-large";
        readonly policy: "ui-length";
        readonly role: "text";
        readonly office100Px: 20;
        readonly distance100Px: 32;
        readonly officeFloorPx: 18;
        readonly distanceFloorPx: 28;
    };
    readonly 'line.body': {
        readonly source: "semantic.typography.line-height-base";
        readonly policy: "ui-length";
        readonly role: "line-box";
        readonly office100Px: 24;
        readonly distance100Px: 32;
        readonly officeFloorPx: 22;
        readonly distanceFloorPx: 28;
    };
    readonly 'spacing.control-y': {
        readonly source: "semantic.spacing.control-y";
        readonly policy: "ui-length";
        readonly role: "spacing";
        readonly office100Px: 8;
        readonly distance100Px: 12;
    };
    readonly 'icon.default': {
        readonly source: "display.icon.default";
        readonly policy: "ui-length";
        readonly role: "icon";
        readonly office100Px: 16;
        readonly distance100Px: 28;
        readonly officeFloorPx: 14;
        readonly distanceFloorPx: 24;
    };
    readonly 'stroke.hairline': {
        readonly source: "display.stroke.hairline";
        readonly policy: "fixed-length";
        readonly role: "stroke";
        readonly office100Px: 1;
        readonly distance100Px: 1;
    };
    readonly 'content.canvas-pixel': {
        readonly source: "display.content.canvas-pixel";
        readonly policy: "domain-length";
        readonly role: "content";
    };
    readonly 'text.line-height-ratio': {
        readonly source: "display.text.line-height-ratio";
        readonly policy: "unitless-ratio";
        readonly role: "text";
    };
}>;
export type ZxDisplayMetricId = keyof typeof displayMetricCatalog;
export declare function displayCssVariables(id: ZxDisplayMetricId): {
    base: `--zx-display-base-${string}`;
    effective: `--zx-display-${string}`;
};
/** Scope-local CSS projection. CSS evaluates rem/calc at the target element. */
export declare function displayProjectionDeclarations(profile: ZxDisplayProfile, scale: ZxDisplayScale): readonly Readonly<[string, string]>[];
export declare function displayControlFactor(profile: ZxDisplayProfile, scale: ZxDisplayScale): number;
/** Identity travels with the packed package and can be checked by a deployment. */
export declare const displayContractManifest: Readonly<{
    contentHash: "sha256:49178b3aa8469e5e0b25c156e4e00d5e0ca5260e99b8f9f58e78b4013a8e94b1";
    schema: "zx.display-contract/1";
    version: 1;
    scales: readonly [90, 100, 110, 125];
    profiles: readonly ["office", "distance"];
    metrics: Readonly<{
        readonly 'text.extra-small': {
            readonly source: "semantic.typography.size-extra-small";
            readonly policy: "ui-length";
            readonly role: "text";
            readonly office100Px: 12;
            readonly distance100Px: 20;
            readonly officeFloorPx: 11;
            readonly distanceFloorPx: 18;
        };
        readonly 'text.small': {
            readonly source: "semantic.typography.size-small";
            readonly policy: "ui-length";
            readonly role: "text";
            readonly office100Px: 13;
            readonly distance100Px: 20;
            readonly officeFloorPx: 12;
            readonly distanceFloorPx: 18;
        };
        readonly 'text.body': {
            readonly source: "semantic.typography.size-base";
            readonly policy: "ui-length";
            readonly role: "text";
            readonly office100Px: 14;
            readonly distance100Px: 24;
            readonly officeFloorPx: 12;
            readonly distanceFloorPx: 20;
        };
        readonly 'text.medium': {
            readonly source: "semantic.typography.size-medium";
            readonly policy: "ui-length";
            readonly role: "text";
            readonly office100Px: 16;
            readonly distance100Px: 24;
            readonly officeFloorPx: 14;
            readonly distanceFloorPx: 20;
        };
        readonly 'text.large': {
            readonly source: "semantic.typography.size-large";
            readonly policy: "ui-length";
            readonly role: "text";
            readonly office100Px: 18;
            readonly distance100Px: 28;
            readonly officeFloorPx: 16;
            readonly distanceFloorPx: 24;
        };
        readonly 'text.title': {
            readonly source: "semantic.typography.size-extra-large";
            readonly policy: "ui-length";
            readonly role: "text";
            readonly office100Px: 20;
            readonly distance100Px: 32;
            readonly officeFloorPx: 18;
            readonly distanceFloorPx: 28;
        };
        readonly 'line.body': {
            readonly source: "semantic.typography.line-height-base";
            readonly policy: "ui-length";
            readonly role: "line-box";
            readonly office100Px: 24;
            readonly distance100Px: 32;
            readonly officeFloorPx: 22;
            readonly distanceFloorPx: 28;
        };
        readonly 'spacing.control-y': {
            readonly source: "semantic.spacing.control-y";
            readonly policy: "ui-length";
            readonly role: "spacing";
            readonly office100Px: 8;
            readonly distance100Px: 12;
        };
        readonly 'icon.default': {
            readonly source: "display.icon.default";
            readonly policy: "ui-length";
            readonly role: "icon";
            readonly office100Px: 16;
            readonly distance100Px: 28;
            readonly officeFloorPx: 14;
            readonly distanceFloorPx: 24;
        };
        readonly 'stroke.hairline': {
            readonly source: "display.stroke.hairline";
            readonly policy: "fixed-length";
            readonly role: "stroke";
            readonly office100Px: 1;
            readonly distance100Px: 1;
        };
        readonly 'content.canvas-pixel': {
            readonly source: "display.content.canvas-pixel";
            readonly policy: "domain-length";
            readonly role: "content";
        };
        readonly 'text.line-height-ratio': {
            readonly source: "display.text.line-height-ratio";
            readonly policy: "unitless-ratio";
            readonly role: "text";
        };
    }>;
}>;
export type ZxDisplayContractCheck = Readonly<{
    ok: true;
    capability: 'legacy-default' | 'display-v1';
}> | Readonly<{
    ok: false;
    code: 'ZX_DISPLAY_CONTRACT_MISSING' | 'ZX_DISPLAY_CONTRACT_MISMATCH';
}>;
/**
 * Assets without a catalog, or compiled against another catalog revision,
 * remain usable at office/100 because that baseline never reads the catalog.
 * Only an explicit display request needs this exact catalog.
 */
export declare function checkDisplayContract(candidate: unknown, explicitDisplay: boolean): ZxDisplayContractCheck;
export declare function isDisplayScale(value: unknown): value is ZxDisplayScale;
export declare function isDisplayProfile(value: unknown): value is ZxDisplayProfile;
/** Apply the scale once to an unscaled source; non-UI values keep their original meaning. */
export declare function projectDisplayLength(basePx: number, policy: ZxDisplayMetricPolicy, scale: ZxDisplayScale): number;
/** Distance seeds are role-specific ratios, preserving theme and density base values. */
export declare function projectDisplayMetric(id: ZxDisplayMetricId, basePx: number, profile: ZxDisplayProfile, scale: ZxDisplayScale): number;
export type ZxElementPlusSize = 'small' | 'default' | 'large';
/** Shared control recipe: 28 / 36 / 44px at the default 8px density rhythm. */
export declare const elementPlusSizeOffsets: {
    readonly small: 12;
    readonly default: 20;
    readonly large: 28;
};
/** Scoped overrides use the same unscaled density source as both EP adapter outputs. */
export declare function elementPlusDisplayProjectionDeclarations(profile: ZxDisplayProfile, scale: ZxDisplayScale): readonly Readonly<[string, string]>[];
export declare function elementPlusTypographyProjectionDeclarations(): readonly Readonly<[
    string,
    string
]>[];
/** Both the density-derived padding and the EP offset are one UI recipe. */
export declare function projectElementPlusControlHeight(controlYPx: number, size: ZxElementPlusSize, profile: ZxDisplayProfile, scale: ZxDisplayScale): number;
/** Interaction capability is independent of the saved display preference. */
export declare function projectInteractionHeight(contentHeightPx: number, touch: boolean): number;
