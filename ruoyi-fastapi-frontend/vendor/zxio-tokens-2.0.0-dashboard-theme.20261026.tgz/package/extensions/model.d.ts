import { AuthorCanonicalTokenPath, BuiltInTypeId, BuiltInTypeMap, CanonicalJsonValue, ThemeAxisDomains, ThemeAxisName, ThemeAxisSelection, ValidatedThemePublicContractV4 } from '../kernel/model';
export type ThemeExtensionDiagnosticCode = 'TX_INPUT_INVALID' | 'TX_MODULE_INVALID' | 'TX_TOKEN_INVALID' | 'TX_DEPENDENCY_INVALID' | 'TX_REFERENCE_INVALID' | 'TX_TYPE_MISMATCH' | 'TX_CYCLE' | 'TX_AXIS_INVALID' | 'TX_AXIS_CONFLICT' | 'TX_CORE_REQUIREMENT' | 'TX_EXPERIMENTAL_OPT_IN' | 'TX_DEPRECATED' | 'TX_CSS_ENCODING' | 'TX_CSS_COLLISION' | 'TX_ADAPTER_INVALID' | 'TX_ADAPTER_VERSION' | 'TX_MANIFEST_INVALID' | 'TX_ARTIFACT_INVALID' | 'TX_OVERRIDE_INVALID' | 'TX_DISPLAY_METRIC_INVALID';
export interface ThemeExtensionDiagnostic {
    readonly code: ThemeExtensionDiagnosticCode;
    readonly severity: 'error' | 'warning';
    readonly path: string;
    readonly moduleId?: string;
    readonly tokenPath?: string;
    readonly details: Readonly<Record<string, CanonicalJsonValue>>;
}
export type ThemeExtensionResult<T> = {
    readonly ok: true;
    readonly value: T;
    readonly diagnostics: readonly ThemeExtensionDiagnostic[];
} | {
    readonly ok: false;
    readonly diagnostics: readonly ThemeExtensionDiagnostic[];
};
export type ThemeExtensionLiteral = {
    [K in BuiltInTypeId]: {
        readonly kind: 'literal';
        readonly typeId: K;
        readonly value: BuiltInTypeMap[K];
    };
}[BuiltInTypeId];
export type ThemeExtensionValue<K extends BuiltInTypeId = BuiltInTypeId> = {
    readonly kind: 'literal';
    readonly value: BuiltInTypeMap[K];
} | {
    readonly kind: 'core-ref';
    readonly path: AuthorCanonicalTokenPath;
} | {
    readonly kind: 'module-ref';
    readonly module: string;
    readonly path: string;
};
export type ThemeExtensionCssEncoding = {
    readonly kind: 'scalar';
    readonly value: string;
} | {
    readonly kind: 'fields';
    readonly fields: Readonly<Record<ThemeTypographyField, string>>;
};
export type ThemeTypographyField = 'fontFamily' | 'fontSize' | 'fontWeight' | 'lineHeight' | 'letterSpacing';
export interface ThemeExtensionLiteralCssEncoder {
    readonly abi: 'zx.theme-extension-css/1';
    encode(literal: ThemeExtensionLiteral): ThemeExtensionResult<ThemeExtensionCssEncoding>;
}
export interface ThemeModuleInput {
    readonly schema: 'zx.theme-module/1';
    readonly id: string;
    readonly namespace: string;
    readonly version: string;
    readonly description: string;
    readonly owner: string;
    readonly dependencies?: readonly ThemeModuleDependency[];
    readonly core?: {
        readonly tokens?: readonly AuthorCanonicalTokenPath[];
        readonly experimental?: readonly AuthorCanonicalTokenPath[];
    };
    readonly tokens: Readonly<Record<string, ThemeModuleTokenInput>>;
    readonly displayMetrics?: Readonly<Record<string, ThemeDisplayMetricInput>>;
}
/**
 * A module length exposed as `--zx-display-<namespace>-<path>`. A `ui-length`
 * metric follows the requested display `scale` only: the `distance` profile's
 * ratios are calibrated per core role and do not apply to module metrics.
 */
export interface ThemeDisplayMetricInput {
    readonly role: string;
    readonly policy: 'ui-length' | 'fixed-length' | 'domain-length' | 'unitless-ratio';
    readonly source: {
        readonly module: string;
        readonly path: string;
        readonly field?: 'fontSize' | 'letterSpacing';
    };
}
export interface ThemeDisplayMetricReference extends ThemeDisplayMetricInput {
    readonly id: string;
    readonly base: {
        readonly variable: string;
        readonly ref: string;
    };
    readonly effective: {
        readonly variable: string;
        readonly ref: string;
    };
}
export interface ThemeModuleDependency {
    readonly id: string;
    readonly version: string;
    readonly contractHash?: string;
}
export interface ThemeModuleDeprecation {
    readonly since: string;
    readonly replacement?: {
        readonly module: string;
        readonly path: string;
    };
    readonly reason?: string;
}
export type ThemeModuleTokenInput = {
    [K in BuiltInTypeId]: {
        readonly type: K;
        readonly description: string;
        readonly owner?: string;
        readonly visibility: 'public' | 'private';
        readonly lifecycle: 'stable' | 'experimental' | 'deprecated';
        readonly deprecated?: ThemeModuleDeprecation;
        readonly overridable?: boolean;
        readonly value: ThemeExtensionValue<K>;
        readonly overrides?: {
            readonly [A in ThemeAxisName]?: Partial<Record<ThemeAxisDomains[A], ThemeExtensionValue<K>>>;
        };
        readonly conflictPolicy?: {
            readonly axisOrder: readonly ThemeAxisName[];
            readonly rationale: string;
        };
    };
}[BuiltInTypeId];
declare const moduleBrand: unique symbol;
export type ValidatedThemeModule<T extends ThemeModuleInput = ThemeModuleInput> = T & {
    readonly [moduleBrand]: true;
};
export interface ThemeCssAdapterInput {
    readonly id: string;
    readonly version: string;
    readonly targetPackage: {
        readonly name: string;
        readonly supportedRange: string;
    };
    readonly propertyPrefix: string;
    readonly mappings: readonly {
        readonly property: string;
        readonly token: {
            readonly module: string;
            readonly path: string;
        };
    }[];
}
export interface ThemeExtensionTokenCss {
    readonly publicVariable?: string;
    readonly fields?: Readonly<Record<string, string>>;
}
export interface ThemeExtensionTokenReference<K extends BuiltInTypeId = BuiltInTypeId, O extends boolean = boolean> {
    readonly kind: 'theme-extension-token';
    readonly module: string;
    readonly path: string;
    readonly typeId: K;
    readonly overridable: O;
    readonly css: ThemeExtensionTokenCss;
    readonly ref?: string;
    readonly fields?: Readonly<Record<string, string>>;
}
export interface ThemeExtensionTokenDescriptorV1 extends ThemeExtensionTokenReference {
    readonly key: string;
    readonly owner: string;
    readonly description: string;
    readonly visibility: 'public';
    readonly lifecycle: 'stable' | 'experimental' | 'deprecated';
    readonly deprecated?: ThemeModuleDeprecation;
}
export interface ThemeExtensionCoreTokenRequirement {
    readonly path: AuthorCanonicalTokenPath;
    readonly typeId: BuiltInTypeId;
    readonly lifecycle: 'stable' | 'experimental' | 'deprecated';
    readonly css: {
        readonly publicVariable: string;
        readonly fields?: Readonly<Record<string, string>>;
    };
    readonly deprecated?: {
        readonly since: string;
        readonly replacement?: AuthorCanonicalTokenPath;
        readonly noReplacementReason?: string;
    };
}
export interface ThemeExtensionCoreRequirementsV1 {
    readonly contractVersion: '4.0.0';
    readonly typeRegistryContentHash: string;
    readonly experimentalContractContentHash?: string;
    readonly tokens: readonly ThemeExtensionCoreTokenRequirement[];
}
export interface ThemeExtensionCoreDescriptor {
    readonly contractVersion: string;
    readonly contractContentHash: string;
    readonly typeRegistryContentHash: string;
    readonly publicSurface: readonly {
        readonly path: string;
        readonly typeId: string;
        readonly lifecycle: string;
        readonly css: {
            readonly publicVariable: string;
            readonly fields?: Readonly<Record<string, string>>;
        };
        readonly deprecated?: {
            readonly since: string;
            readonly replacement?: string;
            readonly noReplacementReason?: string;
        };
    }[];
}
export interface CompiledThemeModuleV1 {
    readonly definition: ThemeModuleInput;
    readonly contractHash: string;
    readonly selectorKey: string;
    readonly corePaths: readonly AuthorCanonicalTokenPath[];
}
export interface ThemeExtensionDependencyLockV1 {
    readonly packageName: string;
    readonly packageVersion: string;
    readonly contentHash: string;
    readonly modules: readonly {
        readonly id: string;
        readonly version: string;
        readonly contractHash: string;
    }[];
}
export interface CompiledThemeCssAdapterV1 extends ThemeCssAdapterInput {
    readonly selectorKey: string;
    readonly moduleIds: readonly string[];
    readonly declarations: readonly (readonly [string, string])[];
}
export type ThemeExtensionArtifactPurpose = 'css' | 'refs-esm' | 'refs-cjs' | 'types';
export interface ThemeExtensionArtifact {
    readonly path: string;
    readonly mediaType: string;
    readonly purpose: ThemeExtensionArtifactPurpose;
    readonly byteLength: number;
    readonly sha256: string;
}
export interface ThemeExtensionManifestV1 {
    readonly schema: 'zx.theme-extension-manifest/1';
    readonly identity: {
        readonly packageName: string;
        readonly packageVersion: string;
        readonly planHash: string;
        readonly contentHash: string;
    };
    readonly selectorSchema: 'zx.theme-extension-selector/1';
    readonly encoderAbi: 'zx.theme-extension-css/1';
    readonly modules: readonly CompiledThemeModuleV1[];
    readonly coreRequirements: ThemeExtensionCoreRequirementsV1;
    readonly dependencies: readonly ThemeExtensionDependencyLockV1[];
    readonly publicTokens: readonly ThemeExtensionTokenDescriptorV1[];
    readonly cssAdapters: readonly CompiledThemeCssAdapterV1[];
    readonly artifacts: readonly ThemeExtensionArtifact[];
}
export interface ThemeExtensionFile {
    readonly path: string;
    readonly mediaType: string;
    readonly text: string;
}
export interface ThemeExtensionBundleV1 {
    readonly manifest: ThemeExtensionManifestV1;
    readonly files: readonly ThemeExtensionFile[];
}
declare const manifestBrand: unique symbol;
declare const bundleBrand: unique symbol;
export type ValidatedThemeExtensionManifestV1 = ThemeExtensionManifestV1 & {
    readonly [manifestBrand]: true;
};
export type ValidatedThemeExtensionBundleV1 = ThemeExtensionBundleV1 & {
    readonly manifest: ValidatedThemeExtensionManifestV1;
    readonly [bundleBrand]: true;
};
export type ThemeExtensionOverrides = Readonly<Record<string, ThemeExtensionValue>>;
export interface ResolvedThemeExtensionSelectionV1 {
    readonly selectedModules: readonly string[];
    readonly normalizedOverrides: ThemeExtensionOverrides;
    readonly selectionHash: string;
    readonly attributes: Readonly<{
        'data-zx-extension': string;
        'data-zx-ext-axes': string;
    }>;
    /** Ownership metadata for every registered module, including private and inactive tokens. */
    readonly managedProperties: readonly string[];
    readonly declarations: readonly (readonly [string, string])[];
    readonly publicTokens: readonly ThemeExtensionTokenDescriptorV1[];
    readonly cssAdapters: readonly CompiledThemeCssAdapterV1[];
}
export interface ResolveThemeExtensionDeclarationsInput {
    readonly manifests: readonly ValidatedThemeExtensionManifestV1[];
    readonly modules?: readonly string[];
    readonly axes: ThemeAxisSelection;
    readonly overrides?: ThemeExtensionOverrides;
    readonly encoder: ThemeExtensionLiteralCssEncoder;
}
export interface CreateThemeExtensionPlanInput {
    readonly package: {
        readonly name: string;
        readonly version: string;
    };
    readonly modules: readonly ThemeModuleInput[];
    readonly coreContract: ValidatedThemePublicContractV4;
    readonly dependencies?: readonly ThemeExtensionManifestV1[];
    readonly cssAdapters?: readonly ThemeCssAdapterInput[];
    readonly encoder: ThemeExtensionLiteralCssEncoder;
}
export type ThemeExtensionManifestPlanV1 = Omit<ThemeExtensionManifestV1, 'artifacts' | 'identity'> & {
    readonly identity: Omit<ThemeExtensionManifestV1['identity'], 'contentHash'>;
};
export {};
