import { AuthorCanonicalTokenPath, BuiltInTypeId, ThemeAxisSelection } from '../kernel/model';
import { CompiledThemeModuleV1, CreateThemeExtensionPlanInput, ThemeCssAdapterInput, ThemeDisplayMetricReference, ThemeExtensionCoreRequirementsV1, ThemeExtensionCoreTokenRequirement, ThemeExtensionDependencyLockV1, ThemeExtensionDiagnostic, ThemeExtensionLiteralCssEncoder, ThemeExtensionManifestPlanV1, ThemeExtensionManifestV1, ThemeExtensionTokenCss, ThemeExtensionTokenDescriptorV1, ThemeExtensionValue, ThemeModuleInput, ThemeModuleTokenInput } from './model';
export declare function publicCoreVariable(path: string): string;
export declare function tokenCss(module: ThemeModuleInput, path: string, type: BuiltInTypeId): ThemeExtensionTokenCss;
export declare function cssVariables(css: ThemeExtensionTokenCss): readonly string[];
export declare function moduleContractHash(module: ThemeModuleInput): string;
export declare function displayMetricReference(module: ThemeModuleInput, path: string, metric: NonNullable<ThemeModuleInput['displayMetrics']>[string]): ThemeDisplayMetricReference;
export declare function tokenDescriptor(module: ThemeModuleInput, path: string, token: ThemeModuleTokenInput): ThemeExtensionTokenDescriptorV1;
export declare function allValues(token: ThemeModuleTokenInput): readonly ThemeExtensionValue[];
export declare function effectiveValue(token: ThemeModuleTokenInput, axes: ThemeAxisSelection): ThemeExtensionValue;
export declare function moduleCorePaths(module: ThemeModuleInput): AuthorCanonicalTokenPath[];
export declare function checkRequirementsShape(requirements: unknown): asserts requirements is ThemeExtensionCoreRequirementsV1;
export declare function coreRequirementsFromContract(input: CreateThemeExtensionPlanInput, modules: readonly ThemeModuleInput[]): ThemeExtensionCoreRequirementsV1;
export declare function validateReference(module: ThemeModuleInput, path: string, token: ThemeModuleTokenInput, value: ThemeExtensionValue, modules: ReadonlyMap<string, ThemeModuleInput>, core: ReadonlyMap<string, ThemeExtensionCoreTokenRequirement>): void;
export declare function checkCycles(modules: ReadonlyMap<string, ThemeModuleInput>, axes: ThemeAxisSelection, overrides?: Readonly<Record<string, ThemeExtensionValue>>): void;
export declare function valueDeclarations(module: ThemeModuleInput, path: string, token: ThemeModuleTokenInput, value: ThemeExtensionValue, modules: ReadonlyMap<string, ThemeModuleInput>, core: ReadonlyMap<string, ThemeExtensionCoreTokenRequirement>, encoder: ThemeExtensionLiteralCssEncoder): readonly (readonly [string, string])[];
export declare function renderThemeExtensionCss(plan: ThemeExtensionManifestPlanV1 | ThemeExtensionManifestV1, encoder: ThemeExtensionLiteralCssEncoder, dependencyModules?: readonly CompiledThemeModuleV1[]): string;
export interface BuildPlanInput {
    readonly package: {
        readonly name: string;
        readonly version: string;
    };
    readonly modules: readonly ThemeModuleInput[];
    readonly coreRequirements: ThemeExtensionCoreRequirementsV1;
    readonly dependencies: readonly ThemeExtensionDependencyLockV1[];
    readonly dependencyModules?: readonly CompiledThemeModuleV1[];
    readonly cssAdapters: readonly ThemeCssAdapterInput[];
    readonly encoder: ThemeExtensionLiteralCssEncoder;
}
export declare function buildPlan(input: BuildPlanInput, warnings?: ThemeExtensionDiagnostic[]): ThemeExtensionManifestPlanV1;
