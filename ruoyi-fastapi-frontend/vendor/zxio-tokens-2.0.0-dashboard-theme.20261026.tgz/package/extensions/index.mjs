import { d as displayMetricReference, c as canonicalThemeExtensionJson, r as renderThemeExtensionCss, h as hashThemeExtensionContent, a as hashThemeExtensionText, b as result, s as snapshot, e as exact, f as requireThat, g as sortText, n as normalizeAdapter, i as buildPlan, j as coreRequirementsFromContract, v as versionSatisfies, k as axisSelection, u as unwrap, l as fail, m as cssVariables, t as tokenCss, o as moduleContractHash, q as normalizeValue, w as validateReference, x as valueDeclarations, y as checkCycles, A as AXES } from "../_chunks/plan--YyWT46z.mjs";
import { B, z } from "../_chunks/plan--YyWT46z.mjs";
const EXTENSION_ARTIFACTS = [
  { path: "extension.css", mediaType: "text/css", purpose: "css" },
  { path: "refs.mjs", mediaType: "text/javascript", purpose: "refs-esm" },
  { path: "refs.cjs", mediaType: "text/javascript", purpose: "refs-cjs" },
  { path: "refs.d.ts", mediaType: "text/typescript", purpose: "types" }
];
function refValue(descriptor) {
  const { kind, module, path, typeId, overridable, css, ref, fields } = descriptor;
  return {
    kind,
    module,
    path,
    typeId,
    overridable,
    css,
    ...ref ? { ref } : {},
    ...fields ? { fields } : {}
  };
}
function renderThemeExtensionFiles(plan, encoder, dependencies = []) {
  var _a;
  const refs = Object.fromEntries(
    plan.publicTokens.map((token) => [token.key, refValue(token)])
  );
  const displayMetricRefs = Object.fromEntries(
    plan.modules.flatMap(
      (module) => Object.entries(module.definition.displayMetrics ?? {}).map(
        ([path, metric]) => {
          const ref = displayMetricReference(module.definition, path, metric);
          return [ref.id, ref];
        }
      )
    )
  );
  const hasDisplayMetrics = Object.keys(displayMetricRefs).length > 0;
  const nested = {};
  for (const token of plan.publicTokens)
    (nested[_a = token.module] ?? (nested[_a] = {}))[token.path] = refValue(token);
  const freeze = 'const freeze = value => { if (value && typeof value === "object") { Object.values(value).forEach(freeze); Object.freeze(value) } return value }\n';
  const data = `const tokenRefs = freeze(${canonicalThemeExtensionJson(
    refs
  )})
const tokens = freeze(${canonicalThemeExtensionJson(nested)})
${hasDisplayMetrics ? `const displayMetricRefs = freeze(${canonicalThemeExtensionJson(displayMetricRefs)})
` : ""}`;
  const declarations = [
    "import type { ThemeExtensionTokenReference, ThemeExtensionValue } from '@zxio/tokens/extensions'",
    "export declare const tokenRefs: {",
    ...plan.publicTokens.map(
      (token) => `  readonly ${JSON.stringify(
        token.key
      )}: ThemeExtensionTokenReference<${JSON.stringify(token.typeId)}, ${token.overridable}>`
    ),
    "}",
    "export declare const tokens: {",
    ...Object.keys(nested).map(
      (id) => `  readonly ${JSON.stringify(id)}: {
${plan.publicTokens.filter((token) => token.module === id).map(
        (token) => `    readonly ${JSON.stringify(
          token.path
        )}: typeof tokenRefs[${JSON.stringify(token.key)}]`
      ).join("\n")}
  }`
    ),
    "}",
    "export type ThemePublicTokenKey = keyof typeof tokenRefs",
    ...hasDisplayMetrics ? [
      "import type { ThemeDisplayMetricReference } from '@zxio/tokens/extensions'",
      "export declare const displayMetricRefs: {",
      ...Object.keys(displayMetricRefs).map(
        (id) => `  readonly ${JSON.stringify(id)}: ThemeDisplayMetricReference`
      ),
      "}"
    ] : [],
    "export interface ThemeExtensionOverrideMap {",
    ...plan.publicTokens.filter((token) => token.overridable).map(
      (token) => `  readonly ${JSON.stringify(
        token.key
      )}?: ThemeExtensionValue<${JSON.stringify(token.typeId)}>`
    ),
    "}",
    "export declare function defineThemeOverrides<const T extends ThemeExtensionOverrideMap>(value: T & Record<Exclude<keyof T, keyof ThemeExtensionOverrideMap>, never>): T",
    ""
  ].join("\n");
  const content = [
    renderThemeExtensionCss(plan, encoder, dependencies),
    `${freeze}${data}const defineThemeOverrides = value => value
export { tokenRefs, tokens, defineThemeOverrides${hasDisplayMetrics ? ", displayMetricRefs" : ""} }
`,
    `'use strict'
${freeze}${data}const defineThemeOverrides = value => value
module.exports = { tokenRefs, tokens, defineThemeOverrides${hasDisplayMetrics ? ", displayMetricRefs" : ""} }
`,
    declarations
  ];
  return EXTENSION_ARTIFACTS.map((artifact, i) => ({
    path: artifact.path,
    mediaType: artifact.mediaType,
    text: content[i]
  }));
}
function artifactDescriptors(files) {
  return files.map((file, index) => ({
    ...EXTENSION_ARTIFACTS[index],
    byteLength: new TextEncoder().encode(file.text).byteLength,
    sha256: hashThemeExtensionText(file.text)
  }));
}
function sealThemeExtensionManifest(plan, artifacts) {
  const body = { ...plan, artifacts };
  return { ...body, identity: { ...body.identity, contentHash: hashThemeExtensionContent(body) } };
}
const verifiedObjects = /* @__PURE__ */ new WeakMap();
function remember(manifest, encoder) {
  if (!Object.isFrozen(encoder)) return;
  let values = verifiedObjects.get(encoder);
  if (!values) {
    values = /* @__PURE__ */ new WeakSet();
    verifiedObjects.set(encoder, values);
  }
  values.add(manifest);
}
function trustedClosure(input, options) {
  const trusted = verifiedObjects.get(options.encoder);
  const dependencies = options.dependencies ?? [];
  if (!trusted || !input || typeof input !== "object" || !trusted.has(input) || !Array.isArray(dependencies) || Object.values(Object.getOwnPropertyDescriptors(dependencies)).some(
    (descriptor) => !("value" in descriptor)
  ) || !dependencies.every((manifest) => trusted.has(manifest)))
    return false;
  const manifests = [
    ...dependencies,
    input
  ];
  const registered = /* @__PURE__ */ new Map();
  for (const manifest of manifests) {
    const prior = registered.get(manifest.identity.packageName);
    if (prior && prior.identity.contentHash !== manifest.identity.contentHash)
      return false;
    registered.set(manifest.identity.packageName, manifest);
  }
  return manifests.every(
    (manifest) => manifest.dependencies.every(
      (dependency) => {
        var _a;
        return ((_a = registered.get(dependency.packageName)) == null ? void 0 : _a.identity.contentHash) === dependency.contentHash;
      }
    )
  );
}
function context(options, own) {
  const sources = /* @__PURE__ */ new Map();
  for (const input of [
    ...snapshot(options.dependencies ?? []),
    ...own === void 0 ? [] : [own]
  ]) {
    exact(
      input,
      [
        "schema",
        "identity",
        "selectorSchema",
        "encoderAbi",
        "modules",
        "coreRequirements",
        "dependencies",
        "publicTokens",
        "cssAdapters",
        "artifacts"
      ],
      [],
      "$.manifest"
    );
    exact(
      input.identity,
      ["packageName", "packageVersion", "planHash", "contentHash"],
      [],
      "$.manifest.identity"
    );
    requireThat(
      typeof input.identity.packageName === "string",
      "TX_MANIFEST_INVALID",
      "$.manifest.identity"
    );
    const prior = sources.get(input.identity.packageName);
    requireThat(
      !prior || canonicalThemeExtensionJson(prior) === canonicalThemeExtensionJson(input),
      "TX_DEPENDENCY_INVALID",
      "$.dependencies",
      { issue: "conflicting-package-identity" }
    );
    sources.set(input.identity.packageName, input);
  }
  requireThat(sources.size <= 128, "TX_DEPENDENCY_INVALID", "$.dependencies", {
    issue: "package-budget"
  });
  return {
    encoder: options.encoder,
    sources,
    verified: /* @__PURE__ */ new Map(),
    active: /* @__PURE__ */ new Set()
  };
}
function lockFor(manifest) {
  return {
    packageName: manifest.identity.packageName,
    packageVersion: manifest.identity.packageVersion,
    contentHash: manifest.identity.contentHash,
    modules: manifest.modules.map((module) => ({
      id: module.definition.id,
      version: module.definition.version,
      contractHash: module.contractHash
    }))
  };
}
function dependencyModules(manifests, ctx) {
  const modules = /* @__PURE__ */ new Map(), visited = /* @__PURE__ */ new Set();
  const visit = (manifest) => {
    if (visited.has(manifest.identity.packageName)) return;
    visited.add(manifest.identity.packageName);
    for (const dep of manifest.dependencies)
      visit(verifyPackage(dep.packageName, ctx));
    for (const module of manifest.modules) {
      const prior = modules.get(module.definition.id);
      requireThat(
        !prior || canonicalThemeExtensionJson(prior) === canonicalThemeExtensionJson(module),
        "TX_DEPENDENCY_INVALID",
        module.definition.id,
        { issue: "conflicting-dependency-module" }
      );
      modules.set(module.definition.id, module);
    }
  };
  manifests.forEach(visit);
  return [...modules.values()].sort(
    (a, b) => sortText(a.definition.id, b.definition.id)
  );
}
function verifyPackage(name, ctx) {
  const cached = ctx.verified.get(name);
  if (cached) return cached;
  requireThat(
    !ctx.active.has(name) && ctx.active.size < 16,
    "TX_DEPENDENCY_INVALID",
    name,
    { issue: "dependency-cycle-or-depth" }
  );
  const input = ctx.sources.get(name);
  requireThat(input, "TX_DEPENDENCY_INVALID", name, {
    issue: "registered-dependency-manifest-required"
  });
  ctx.active.add(name);
  exact(
    input,
    [
      "schema",
      "identity",
      "selectorSchema",
      "encoderAbi",
      "modules",
      "coreRequirements",
      "dependencies",
      "publicTokens",
      "cssAdapters",
      "artifacts"
    ],
    [],
    "$.manifest"
  );
  exact(
    input.identity,
    ["packageName", "packageVersion", "planHash", "contentHash"],
    [],
    "$.manifest.identity"
  );
  requireThat(
    input.schema === "zx.theme-extension-manifest/1" && input.selectorSchema === "zx.theme-extension-selector/1" && input.encoderAbi === ctx.encoder.abi && Array.isArray(input.modules) && Array.isArray(input.dependencies) && input.dependencies.length <= 128 && Array.isArray(input.cssAdapters),
    "TX_MANIFEST_INVALID",
    "$.manifest"
  );
  const dependencies = input.dependencies.map((dep) => {
    exact(
      dep,
      ["packageName", "packageVersion", "contentHash", "modules"],
      [],
      "$.manifest.dependencies"
    );
    requireThat(
      typeof dep.packageName === "string",
      "TX_DEPENDENCY_INVALID",
      "$.manifest.dependencies"
    );
    const verified = verifyPackage(dep.packageName, ctx);
    requireThat(
      canonicalThemeExtensionJson(lockFor(verified)) === canonicalThemeExtensionJson(dep),
      "TX_DEPENDENCY_INVALID",
      "$.manifest.dependencies",
      { issue: "dependency-lock-mismatch" }
    );
    return verified;
  });
  const locks = dependencies.map(lockFor).sort((a, b) => sortText(a.packageName, b.packageName));
  requireThat(
    new Set(locks.map((lock) => lock.packageName)).size === locks.length,
    "TX_DEPENDENCY_INVALID",
    "$.manifest.dependencies"
  );
  const adapterSources = input.cssAdapters.map((adapter) => {
    exact(
      adapter,
      [
        "id",
        "version",
        "targetPackage",
        "propertyPrefix",
        "mappings",
        "selectorKey",
        "moduleIds",
        "declarations"
      ],
      [],
      "$.manifest.cssAdapters"
    );
    const {
      selectorKey: _key,
      moduleIds: _ids,
      declarations: _declarations,
      ...source
    } = adapter;
    return normalizeAdapter(source);
  });
  const modules = input.modules.map((module) => {
    exact(
      module,
      ["definition", "contractHash", "selectorKey", "corePaths"],
      [],
      "$.manifest.modules"
    );
    return module.definition;
  });
  const external = dependencyModules(dependencies, ctx);
  const plan = buildPlan({
    package: {
      name: input.identity.packageName,
      version: input.identity.packageVersion
    },
    modules,
    coreRequirements: input.coreRequirements,
    dependencies: locks,
    dependencyModules: external,
    cssAdapters: adapterSources,
    encoder: ctx.encoder
  });
  const files = renderThemeExtensionFiles(plan, ctx.encoder, external);
  const expected = sealThemeExtensionManifest(plan, artifactDescriptors(files));
  requireThat(
    canonicalThemeExtensionJson(input) === canonicalThemeExtensionJson(expected),
    "TX_MANIFEST_INVALID",
    "$.manifest",
    { issue: "plan-owner-selector-or-identity-mismatch" }
  );
  ctx.active.delete(name);
  ctx.verified.set(name, expected);
  return expected;
}
function verifyAll(ctx) {
  for (const name of [...ctx.sources.keys()].sort(sortText))
    verifyPackage(name, ctx);
}
function validateThemeExtensionManifest(input, options) {
  if (trustedClosure(input, options))
    return Object.freeze({
      ok: true,
      value: input,
      diagnostics: []
    });
  const verified = result(() => {
    const copy = snapshot(input), ctx = context(options, copy);
    verifyAll(ctx);
    return ctx.verified.get(
      copy.identity.packageName
    );
  });
  if (verified.ok) remember(verified.value, options.encoder);
  return verified;
}
function validateThemeExtensionBundle(input, options) {
  const verified = result(() => {
    const copy = snapshot(input);
    exact(copy, ["manifest", "files"], [], "$.bundle");
    const ctx = context(options, copy.manifest);
    verifyAll(ctx);
    const manifest = ctx.verified.get(
      copy.manifest.identity.packageName
    );
    requireThat(
      Array.isArray(copy.files),
      "TX_ARTIFACT_INVALID",
      "$.bundle.files"
    );
    const external = dependencyModules(
      manifest.dependencies.map((dep) => verifyPackage(dep.packageName, ctx)),
      ctx
    );
    const files = renderThemeExtensionFiles(manifest, options.encoder, external);
    requireThat(
      canonicalThemeExtensionJson(copy.files) === canonicalThemeExtensionJson(files),
      "TX_ARTIFACT_INVALID",
      "$.bundle.files",
      { issue: "exact-owner-set-and-bytes-required" }
    );
    return { manifest, files };
  });
  if (verified.ok) remember(verified.value.manifest, options.encoder);
  return verified;
}
function createThemeExtensionBundle(input) {
  const warnings = [];
  return result(() => {
    exact(
      input,
      ["package", "modules", "coreContract", "encoder"],
      ["dependencies", "cssAdapters"],
      "$.compile"
    );
    const modules = snapshot(input.modules);
    const ctx = context({
      encoder: input.encoder,
      dependencies: input.dependencies
    });
    verifyAll(ctx);
    const dependencies = [...ctx.verified.values()].sort(
      (a, b) => sortText(a.identity.packageName, b.identity.packageName)
    );
    const external = dependencyModules(dependencies, ctx);
    const requirements = coreRequirementsFromContract(input, [
      ...external.map((module) => module.definition),
      ...modules
    ]);
    const plan = buildPlan(
      {
        package: snapshot(input.package),
        modules,
        coreRequirements: requirements,
        dependencies: dependencies.map(lockFor),
        dependencyModules: external,
        cssAdapters: snapshot(input.cssAdapters ?? []),
        encoder: input.encoder
      },
      warnings
    );
    const files = renderThemeExtensionFiles(plan, input.encoder, external);
    return {
      manifest: sealThemeExtensionManifest(plan, artifactDescriptors(files)),
      files
    };
  }, warnings);
}
function validateThemeExtensionCoreRequirements(manifests, input) {
  return result(() => {
    const core = snapshot(input);
    requireThat(
      core && typeof core === "object" && Array.isArray(core.publicSurface),
      "TX_CORE_REQUIREMENT",
      "$.core"
    );
    const entries = new Map(
      core.publicSurface.map((token) => [token.path, token])
    );
    requireThat(
      entries.size === core.publicSurface.length,
      "TX_CORE_REQUIREMENT",
      "$.core.publicSurface"
    );
    for (const manifest of manifests) {
      const requirements = manifest.coreRequirements;
      requireThat(
        core.contractVersion === requirements.contractVersion && core.typeRegistryContentHash === requirements.typeRegistryContentHash && (!requirements.experimentalContractContentHash || core.contractContentHash === requirements.experimentalContractContentHash),
        "TX_CORE_REQUIREMENT",
        manifest.identity.packageName,
        { issue: "core-identity-mismatch" }
      );
      for (const token of requirements.tokens) {
        const target = entries.get(token.path);
        requireThat(
          target && target.typeId === token.typeId && target.lifecycle === token.lifecycle && canonicalThemeExtensionJson({
            publicVariable: target.css.publicVariable,
            ...target.css.fields ? { fields: target.css.fields } : {}
          }) === canonicalThemeExtensionJson(token.css) && canonicalThemeExtensionJson(target.deprecated ?? null) === canonicalThemeExtensionJson(token.deprecated ?? null),
          "TX_CORE_REQUIREMENT",
          token.path,
          { issue: "core-public-signature-mismatch" }
        );
      }
    }
    return true;
  });
}
function validateThemeCssAdapterTarget(input) {
  return result(() => {
    const adapter = snapshot(input.adapter);
    const {
      selectorKey: _key,
      moduleIds: _ids,
      declarations: _declarations,
      ...source
    } = adapter;
    normalizeAdapter(source);
    requireThat(
      versionSatisfies(
        input.actualVersion,
        adapter.targetPackage.supportedRange
      ) === true,
      "TX_ADAPTER_VERSION",
      adapter.id,
      {
        actualVersion: input.actualVersion,
        supportedRange: adapter.targetPackage.supportedRange
      }
    );
    return true;
  });
}
function resolveThemeExtensionDeclarations(input) {
  return result(() => {
    var _a, _b;
    const axes = axisSelection(snapshot(input.axes));
    const manifests = input.manifests.map(
      (manifest) => unwrap(
        validateThemeExtensionManifest(manifest, {
          encoder: input.encoder,
          dependencies: input.manifests
        })
      )
    ).sort((a, b) => sortText(a.identity.packageName, b.identity.packageName));
    requireThat(
      new Set(manifests.map((manifest) => manifest.identity.packageName)).size === manifests.length,
      "TX_DEPENDENCY_INVALID",
      "$.manifests"
    );
    const registered = new Map(
      manifests.map((manifest) => [manifest.identity.packageName, manifest])
    );
    for (const manifest of manifests)
      for (const dependency of manifest.dependencies) {
        requireThat(
          ((_a = registered.get(dependency.packageName)) == null ? void 0 : _a.identity.contentHash) === dependency.contentHash,
          "TX_DEPENDENCY_INVALID",
          manifest.identity.packageName,
          {
            issue: "registered-dependency-required",
            packageName: dependency.packageName
          }
        );
      }
    const adapterOwners = /* @__PURE__ */ new Map();
    const cssAdapters = manifests.flatMap((manifest) => {
      for (const adapter of manifest.cssAdapters) {
        const owner = adapterOwners.get(adapter.id);
        if (owner !== void 0)
          fail("TX_ADAPTER_INVALID", `$.cssAdapters.${adapter.id}`, {
            issue: "duplicate-public-adapter-id",
            id: adapter.id,
            packages: [owner, manifest.identity.packageName]
          });
        adapterOwners.set(adapter.id, manifest.identity.packageName);
      }
      return manifest.cssAdapters;
    });
    const compiledModules = manifests.flatMap((manifest) => manifest.modules);
    const all = new Map(
      compiledModules.map((module) => [module.definition.id, module.definition])
    );
    requireThat(
      all.size === compiledModules.length && new Set(compiledModules.map((module) => module.definition.namespace)).size === compiledModules.length,
      "TX_MODULE_INVALID",
      "$.modules",
      { issue: "composition-id-or-namespace-collision" }
    );
    const variables = /* @__PURE__ */ new Set();
    for (const module of all.values()) {
      for (const [path, token] of Object.entries(module.tokens)) {
        for (const variable of cssVariables(
          tokenCss(module, path, token.type)
        )) {
          requireThat(
            !variables.has(variable),
            "TX_CSS_COLLISION",
            `${module.id}/${path}`,
            { variable }
          );
          variables.add(variable);
        }
      }
      for (const [path, metric] of Object.entries(
        module.displayMetrics ?? {}
      )) {
        const ref = displayMetricReference(module, path, metric);
        for (const variable of [ref.base.variable, ref.effective.variable]) {
          requireThat(!variables.has(variable), "TX_CSS_COLLISION", ref.id, {
            variable
          });
          variables.add(variable);
        }
      }
    }
    const chosen = input.modules === void 0 ? [...all.keys()] : snapshot(input.modules);
    requireThat(
      Array.isArray(chosen) && new Set(chosen).size === chosen.length && chosen.every((id) => all.has(id)),
      "TX_MODULE_INVALID",
      "$.modules",
      { issue: "registered-modules-required" }
    );
    const selectedModules = [...chosen].sort(sortText);
    const selected = new Map(selectedModules.map((id) => [id, all.get(id)]));
    for (const module of selected.values())
      for (const dep of module.dependencies ?? [])
        requireThat(
          ((_b = selected.get(dep.id)) == null ? void 0 : _b.version) === dep.version && (!dep.contractHash || moduleContractHash(selected.get(dep.id)) === dep.contractHash),
          "TX_DEPENDENCY_INVALID",
          module.id,
          { issue: "selected-dependency-required", dependency: dep.id }
        );
    const core = /* @__PURE__ */ new Map();
    for (const manifest of manifests)
      for (const token of manifest.coreRequirements.tokens) {
        const prior = core.get(token.path);
        requireThat(
          !prior || canonicalThemeExtensionJson(prior) === canonicalThemeExtensionJson(token),
          "TX_CORE_REQUIREMENT",
          token.path,
          { issue: "conflicting-core-signature" }
        );
        core.set(token.path, token);
      }
    const raw = snapshot(input.overrides ?? {});
    requireThat(
      raw && typeof raw === "object" && !Array.isArray(raw),
      "TX_OVERRIDE_INVALID",
      "$.overrides"
    );
    const overrides = {};
    const declarations = [];
    for (const key of Object.keys(raw).sort(sortText)) {
      const parts = key.split("/");
      requireThat(parts.length === 2, "TX_OVERRIDE_INVALID", key);
      const module = selected.get(parts[0]), token = module == null ? void 0 : module.tokens[parts[1]];
      requireThat(
        module && (token == null ? void 0 : token.visibility) === "public" && token.overridable,
        "TX_OVERRIDE_INVALID",
        key,
        { issue: "selected-public-overridable-token-required" }
      );
      const value = normalizeValue(raw[key], token.type, `$.overrides.${key}`);
      validateReference(module, parts[1], token, value, selected, core);
      overrides[key] = value;
      declarations.push(
        ...valueDeclarations(
          module,
          parts[1],
          token,
          value,
          selected,
          core,
          input.encoder
        )
      );
    }
    checkCycles(selected, axes, overrides);
    for (const module of all.values())
      if (!selected.has(module.id)) {
        for (const [path, token] of Object.entries(module.tokens))
          for (const variable of cssVariables(
            tokenCss(module, path, token.type)
          ))
            declarations.push([variable, "initial"]);
        for (const [path, metric] of Object.entries(
          module.displayMetrics ?? {}
        )) {
          const ref = displayMetricReference(module, path, metric);
          declarations.push(
            [ref.base.variable, "initial"],
            [ref.effective.variable, "initial"]
          );
        }
      }
    const normalizedOverrides = overrides;
    const attributes = {
      "data-zx-extension": compiledModules.filter((module) => selected.has(module.definition.id)).map((module) => module.selectorKey).sort(sortText).join(" "),
      "data-zx-ext-axes": AXES.map((axis) => `${axis}-${axes[axis]}`).join(" ")
    };
    return {
      selectedModules,
      normalizedOverrides,
      attributes,
      selectionHash: hashThemeExtensionContent({
        manifests: manifests.map((manifest) => manifest.identity.contentHash),
        selectedModules,
        axes,
        overrides
      }),
      managedProperties: [...variables].sort(sortText),
      declarations: declarations.sort(([a], [b]) => sortText(a, b)),
      publicTokens: manifests.flatMap((manifest) => manifest.publicTokens).filter((token) => selected.has(token.module)),
      cssAdapters: cssAdapters.filter(
        (adapter) => adapter.moduleIds.every((id) => selected.has(id))
      )
    };
  });
}
export {
  canonicalThemeExtensionJson,
  createThemeExtensionBundle,
  B as defineThemeCssAdapter,
  z as defineThemeModule,
  displayMetricReference,
  hashThemeExtensionContent,
  hashThemeExtensionText,
  resolveThemeExtensionDeclarations,
  validateThemeCssAdapterTarget,
  validateThemeExtensionBundle,
  validateThemeExtensionCoreRequirements,
  validateThemeExtensionManifest
};
