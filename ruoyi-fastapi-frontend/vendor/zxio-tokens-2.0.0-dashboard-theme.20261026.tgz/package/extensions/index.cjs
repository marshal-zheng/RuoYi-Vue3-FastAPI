"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const plan = require("../_chunks/plan-_xl4-gpu.cjs");
const EXTENSION_ARTIFACTS = [
  { path: "extension.css", mediaType: "text/css", purpose: "css" },
  { path: "refs.mjs", mediaType: "text/javascript", purpose: "refs-esm" },
  { path: "refs.cjs", mediaType: "text/javascript", purpose: "refs-cjs" },
  { path: "refs.d.ts", mediaType: "text/typescript", purpose: "types" }
];
function refValue(descriptor) {
  const { kind, module: module2, path, typeId, overridable, css, ref, fields } = descriptor;
  return {
    kind,
    module: module2,
    path,
    typeId,
    overridable,
    css,
    ...ref ? { ref } : {},
    ...fields ? { fields } : {}
  };
}
function renderThemeExtensionFiles(plan$1, encoder, dependencies = []) {
  var _a;
  const refs = Object.fromEntries(
    plan$1.publicTokens.map((token) => [token.key, refValue(token)])
  );
  const displayMetricRefs = Object.fromEntries(
    plan$1.modules.flatMap(
      (module2) => Object.entries(module2.definition.displayMetrics ?? {}).map(
        ([path, metric]) => {
          const ref = plan.displayMetricReference(module2.definition, path, metric);
          return [ref.id, ref];
        }
      )
    )
  );
  const hasDisplayMetrics = Object.keys(displayMetricRefs).length > 0;
  const nested = {};
  for (const token of plan$1.publicTokens)
    (nested[_a = token.module] ?? (nested[_a] = {}))[token.path] = refValue(token);
  const freeze = 'const freeze = value => { if (value && typeof value === "object") { Object.values(value).forEach(freeze); Object.freeze(value) } return value }\n';
  const data = `const tokenRefs = freeze(${plan.canonicalThemeExtensionJson(
    refs
  )})
const tokens = freeze(${plan.canonicalThemeExtensionJson(nested)})
${hasDisplayMetrics ? `const displayMetricRefs = freeze(${plan.canonicalThemeExtensionJson(displayMetricRefs)})
` : ""}`;
  const declarations = [
    "import type { ThemeExtensionTokenReference, ThemeExtensionValue } from '@zxio/tokens/extensions'",
    "export declare const tokenRefs: {",
    ...plan$1.publicTokens.map(
      (token) => `  readonly ${JSON.stringify(
        token.key
      )}: ThemeExtensionTokenReference<${JSON.stringify(token.typeId)}, ${token.overridable}>`
    ),
    "}",
    "export declare const tokens: {",
    ...Object.keys(nested).map(
      (id) => `  readonly ${JSON.stringify(id)}: {
${plan$1.publicTokens.filter((token) => token.module === id).map(
        (token) => `    readonly ${JSON.stringify(
          token.path
        )}: typeof tokenRefs[${JSON.stringify(token.key)}]`
      ).join("\n")}
  }`
    ),
    "}",
    "export type ThemePublicTokenKey = keyof typeof tokenRefs",
    ...hasDisplayMetrics ? [
      "import type { ThemeDisplayMetricReference } from '@zxio/tokens/extensions'",
      "export declare const displayMetricRefs: {",
      ...Object.keys(displayMetricRefs).map(
        (id) => `  readonly ${JSON.stringify(id)}: ThemeDisplayMetricReference`
      ),
      "}"
    ] : [],
    "export interface ThemeExtensionOverrideMap {",
    ...plan$1.publicTokens.filter((token) => token.overridable).map(
      (token) => `  readonly ${JSON.stringify(
        token.key
      )}?: ThemeExtensionValue<${JSON.stringify(token.typeId)}>`
    ),
    "}",
    "export declare function defineThemeOverrides<const T extends ThemeExtensionOverrideMap>(value: T & Record<Exclude<keyof T, keyof ThemeExtensionOverrideMap>, never>): T",
    ""
  ].join("\n");
  const content = [
    plan.renderThemeExtensionCss(plan$1, encoder, dependencies),
    `${freeze}${data}const defineThemeOverrides = value => value
export { tokenRefs, tokens, defineThemeOverrides${hasDisplayMetrics ? ", displayMetricRefs" : ""} }
`,
    `'use strict'
${freeze}${data}const defineThemeOverrides = value => value
module.exports = { tokenRefs, tokens, defineThemeOverrides${hasDisplayMetrics ? ", displayMetricRefs" : ""} }
`,
    declarations
  ];
  return EXTENSION_ARTIFACTS.map((artifact, i) => ({
    path: artifact.path,
    mediaType: artifact.mediaType,
    text: content[i]
  }));
}
function artifactDescriptors(files) {
  return files.map((file, index) => ({
    ...EXTENSION_ARTIFACTS[index],
    byteLength: new TextEncoder().encode(file.text).byteLength,
    sha256: plan.hashThemeExtensionText(file.text)
  }));
}
function sealThemeExtensionManifest(plan$1, artifacts) {
  const body = { ...plan$1, artifacts };
  return { ...body, identity: { ...body.identity, contentHash: plan.hashThemeExtensionContent(body) } };
}
const verifiedObjects = /* @__PURE__ */ new WeakMap();
function remember(manifest, encoder) {
  if (!Object.isFrozen(encoder)) return;
  let values = verifiedObjects.get(encoder);
  if (!values) {
    values = /* @__PURE__ */ new WeakSet();
    verifiedObjects.set(encoder, values);
  }
  values.add(manifest);
}
function trustedClosure(input, options) {
  const trusted = verifiedObjects.get(options.encoder);
  const dependencies = options.dependencies ?? [];
  if (!trusted || !input || typeof input !== "object" || !trusted.has(input) || !Array.isArray(dependencies) || Object.values(Object.getOwnPropertyDescriptors(dependencies)).some(
    (descriptor) => !("value" in descriptor)
  ) || !dependencies.every((manifest) => trusted.has(manifest)))
    return false;
  const manifests = [
    ...dependencies,
    input
  ];
  const registered = /* @__PURE__ */ new Map();
  for (const manifest of manifests) {
    const prior = registered.get(manifest.identity.packageName);
    if (prior && prior.identity.contentHash !== manifest.identity.contentHash)
      return false;
    registered.set(manifest.identity.packageName, manifest);
  }
  return manifests.every(
    (manifest) => manifest.dependencies.every(
      (dependency) => {
        var _a;
        return ((_a = registered.get(dependency.packageName)) == null ? void 0 : _a.identity.contentHash) === dependency.contentHash;
      }
    )
  );
}
function context(options, own) {
  const sources = /* @__PURE__ */ new Map();
  for (const input of [
    ...plan.snapshot(options.dependencies ?? []),
    ...own === void 0 ? [] : [own]
  ]) {
    plan.exact(
      input,
      [
        "schema",
        "identity",
        "selectorSchema",
        "encoderAbi",
        "modules",
        "coreRequirements",
        "dependencies",
        "publicTokens",
        "cssAdapters",
        "artifacts"
      ],
      [],
      "$.manifest"
    );
    plan.exact(
      input.identity,
      ["packageName", "packageVersion", "planHash", "contentHash"],
      [],
      "$.manifest.identity"
    );
    plan.requireThat(
      typeof input.identity.packageName === "string",
      "TX_MANIFEST_INVALID",
      "$.manifest.identity"
    );
    const prior = sources.get(input.identity.packageName);
    plan.requireThat(
      !prior || plan.canonicalThemeExtensionJson(prior) === plan.canonicalThemeExtensionJson(input),
      "TX_DEPENDENCY_INVALID",
      "$.dependencies",
      { issue: "conflicting-package-identity" }
    );
    sources.set(input.identity.packageName, input);
  }
  plan.requireThat(sources.size <= 128, "TX_DEPENDENCY_INVALID", "$.dependencies", {
    issue: "package-budget"
  });
  return {
    encoder: options.encoder,
    sources,
    verified: /* @__PURE__ */ new Map(),
    active: /* @__PURE__ */ new Set()
  };
}
function lockFor(manifest) {
  return {
    packageName: manifest.identity.packageName,
    packageVersion: manifest.identity.packageVersion,
    contentHash: manifest.identity.contentHash,
    modules: manifest.modules.map((module2) => ({
      id: module2.definition.id,
      version: module2.definition.version,
      contractHash: module2.contractHash
    }))
  };
}
function dependencyModules(manifests, ctx) {
  const modules = /* @__PURE__ */ new Map(), visited = /* @__PURE__ */ new Set();
  const visit = (manifest) => {
    if (visited.has(manifest.identity.packageName)) return;
    visited.add(manifest.identity.packageName);
    for (const dep of manifest.dependencies)
      visit(verifyPackage(dep.packageName, ctx));
    for (const module2 of manifest.modules) {
      const prior = modules.get(module2.definition.id);
      plan.requireThat(
        !prior || plan.canonicalThemeExtensionJson(prior) === plan.canonicalThemeExtensionJson(module2),
        "TX_DEPENDENCY_INVALID",
        module2.definition.id,
        { issue: "conflicting-dependency-module" }
      );
      modules.set(module2.definition.id, module2);
    }
  };
  manifests.forEach(visit);
  return [...modules.values()].sort(
    (a, b) => plan.sortText(a.definition.id, b.definition.id)
  );
}
function verifyPackage(name, ctx) {
  const cached = ctx.verified.get(name);
  if (cached) return cached;
  plan.requireThat(
    !ctx.active.has(name) && ctx.active.size < 16,
    "TX_DEPENDENCY_INVALID",
    name,
    { issue: "dependency-cycle-or-depth" }
  );
  const input = ctx.sources.get(name);
  plan.requireThat(input, "TX_DEPENDENCY_INVALID", name, {
    issue: "registered-dependency-manifest-required"
  });
  ctx.active.add(name);
  plan.exact(
    input,
    [
      "schema",
      "identity",
      "selectorSchema",
      "encoderAbi",
      "modules",
      "coreRequirements",
      "dependencies",
      "publicTokens",
      "cssAdapters",
      "artifacts"
    ],
    [],
    "$.manifest"
  );
  plan.exact(
    input.identity,
    ["packageName", "packageVersion", "planHash", "contentHash"],
    [],
    "$.manifest.identity"
  );
  plan.requireThat(
    input.schema === "zx.theme-extension-manifest/1" && input.selectorSchema === "zx.theme-extension-selector/1" && input.encoderAbi === ctx.encoder.abi && Array.isArray(input.modules) && Array.isArray(input.dependencies) && input.dependencies.length <= 128 && Array.isArray(input.cssAdapters),
    "TX_MANIFEST_INVALID",
    "$.manifest"
  );
  const dependencies = input.dependencies.map((dep) => {
    plan.exact(
      dep,
      ["packageName", "packageVersion", "contentHash", "modules"],
      [],
      "$.manifest.dependencies"
    );
    plan.requireThat(
      typeof dep.packageName === "string",
      "TX_DEPENDENCY_INVALID",
      "$.manifest.dependencies"
    );
    const verified = verifyPackage(dep.packageName, ctx);
    plan.requireThat(
      plan.canonicalThemeExtensionJson(lockFor(verified)) === plan.canonicalThemeExtensionJson(dep),
      "TX_DEPENDENCY_INVALID",
      "$.manifest.dependencies",
      { issue: "dependency-lock-mismatch" }
    );
    return verified;
  });
  const locks = dependencies.map(lockFor).sort((a, b) => plan.sortText(a.packageName, b.packageName));
  plan.requireThat(
    new Set(locks.map((lock) => lock.packageName)).size === locks.length,
    "TX_DEPENDENCY_INVALID",
    "$.manifest.dependencies"
  );
  const adapterSources = input.cssAdapters.map((adapter) => {
    plan.exact(
      adapter,
      [
        "id",
        "version",
        "targetPackage",
        "propertyPrefix",
        "mappings",
        "selectorKey",
        "moduleIds",
        "declarations"
      ],
      [],
      "$.manifest.cssAdapters"
    );
    const {
      selectorKey: _key,
      moduleIds: _ids,
      declarations: _declarations,
      ...source
    } = adapter;
    return plan.normalizeAdapter(source);
  });
  const modules = input.modules.map((module2) => {
    plan.exact(
      module2,
      ["definition", "contractHash", "selectorKey", "corePaths"],
      [],
      "$.manifest.modules"
    );
    return module2.definition;
  });
  const external = dependencyModules(dependencies, ctx);
  const plan$1 = plan.buildPlan({
    package: {
      name: input.identity.packageName,
      version: input.identity.packageVersion
    },
    modules,
    coreRequirements: input.coreRequirements,
    dependencies: locks,
    dependencyModules: external,
    cssAdapters: adapterSources,
    encoder: ctx.encoder
  });
  const files = renderThemeExtensionFiles(plan$1, ctx.encoder, external);
  const expected = sealThemeExtensionManifest(plan$1, artifactDescriptors(files));
  plan.requireThat(
    plan.canonicalThemeExtensionJson(input) === plan.canonicalThemeExtensionJson(expected),
    "TX_MANIFEST_INVALID",
    "$.manifest",
    { issue: "plan-owner-selector-or-identity-mismatch" }
  );
  ctx.active.delete(name);
  ctx.verified.set(name, expected);
  return expected;
}
function verifyAll(ctx) {
  for (const name of [...ctx.sources.keys()].sort(plan.sortText))
    verifyPackage(name, ctx);
}
function validateThemeExtensionManifest(input, options) {
  if (trustedClosure(input, options))
    return Object.freeze({
      ok: true,
      value: input,
      diagnostics: []
    });
  const verified = plan.result(() => {
    const copy = plan.snapshot(input), ctx = context(options, copy);
    verifyAll(ctx);
    return ctx.verified.get(
      copy.identity.packageName
    );
  });
  if (verified.ok) remember(verified.value, options.encoder);
  return verified;
}
function validateThemeExtensionBundle(input, options) {
  const verified = plan.result(() => {
    const copy = plan.snapshot(input);
    plan.exact(copy, ["manifest", "files"], [], "$.bundle");
    const ctx = context(options, copy.manifest);
    verifyAll(ctx);
    const manifest = ctx.verified.get(
      copy.manifest.identity.packageName
    );
    plan.requireThat(
      Array.isArray(copy.files),
      "TX_ARTIFACT_INVALID",
      "$.bundle.files"
    );
    const external = dependencyModules(
      manifest.dependencies.map((dep) => verifyPackage(dep.packageName, ctx)),
      ctx
    );
    const files = renderThemeExtensionFiles(manifest, options.encoder, external);
    plan.requireThat(
      plan.canonicalThemeExtensionJson(copy.files) === plan.canonicalThemeExtensionJson(files),
      "TX_ARTIFACT_INVALID",
      "$.bundle.files",
      { issue: "exact-owner-set-and-bytes-required" }
    );
    return { manifest, files };
  });
  if (verified.ok) remember(verified.value.manifest, options.encoder);
  return verified;
}
function createThemeExtensionBundle(input) {
  const warnings = [];
  return plan.result(() => {
    plan.exact(
      input,
      ["package", "modules", "coreContract", "encoder"],
      ["dependencies", "cssAdapters"],
      "$.compile"
    );
    const modules = plan.snapshot(input.modules);
    const ctx = context({
      encoder: input.encoder,
      dependencies: input.dependencies
    });
    verifyAll(ctx);
    const dependencies = [...ctx.verified.values()].sort(
      (a, b) => plan.sortText(a.identity.packageName, b.identity.packageName)
    );
    const external = dependencyModules(dependencies, ctx);
    const requirements = plan.coreRequirementsFromContract(input, [
      ...external.map((module2) => module2.definition),
      ...modules
    ]);
    const plan$1 = plan.buildPlan(
      {
        package: plan.snapshot(input.package),
        modules,
        coreRequirements: requirements,
        dependencies: dependencies.map(lockFor),
        dependencyModules: external,
        cssAdapters: plan.snapshot(input.cssAdapters ?? []),
        encoder: input.encoder
      },
      warnings
    );
    const files = renderThemeExtensionFiles(plan$1, input.encoder, external);
    return {
      manifest: sealThemeExtensionManifest(plan$1, artifactDescriptors(files)),
      files
    };
  }, warnings);
}
function validateThemeExtensionCoreRequirements(manifests, input) {
  return plan.result(() => {
    const core = plan.snapshot(input);
    plan.requireThat(
      core && typeof core === "object" && Array.isArray(core.publicSurface),
      "TX_CORE_REQUIREMENT",
      "$.core"
    );
    const entries = new Map(
      core.publicSurface.map((token) => [token.path, token])
    );
    plan.requireThat(
      entries.size === core.publicSurface.length,
      "TX_CORE_REQUIREMENT",
      "$.core.publicSurface"
    );
    for (const manifest of manifests) {
      const requirements = manifest.coreRequirements;
      plan.requireThat(
        core.contractVersion === requirements.contractVersion && core.typeRegistryContentHash === requirements.typeRegistryContentHash && (!requirements.experimentalContractContentHash || core.contractContentHash === requirements.experimentalContractContentHash),
        "TX_CORE_REQUIREMENT",
        manifest.identity.packageName,
        { issue: "core-identity-mismatch" }
      );
      for (const token of requirements.tokens) {
        const target = entries.get(token.path);
        plan.requireThat(
          target && target.typeId === token.typeId && target.lifecycle === token.lifecycle && plan.canonicalThemeExtensionJson({
            publicVariable: target.css.publicVariable,
            ...target.css.fields ? { fields: target.css.fields } : {}
          }) === plan.canonicalThemeExtensionJson(token.css) && plan.canonicalThemeExtensionJson(target.deprecated ?? null) === plan.canonicalThemeExtensionJson(token.deprecated ?? null),
          "TX_CORE_REQUIREMENT",
          token.path,
          { issue: "core-public-signature-mismatch" }
        );
      }
    }
    return true;
  });
}
function validateThemeCssAdapterTarget(input) {
  return plan.result(() => {
    const adapter = plan.snapshot(input.adapter);
    const {
      selectorKey: _key,
      moduleIds: _ids,
      declarations: _declarations,
      ...source
    } = adapter;
    plan.normalizeAdapter(source);
    plan.requireThat(
      plan.versionSatisfies(
        input.actualVersion,
        adapter.targetPackage.supportedRange
      ) === true,
      "TX_ADAPTER_VERSION",
      adapter.id,
      {
        actualVersion: input.actualVersion,
        supportedRange: adapter.targetPackage.supportedRange
      }
    );
    return true;
  });
}
function resolveThemeExtensionDeclarations(input) {
  return plan.result(() => {
    var _a, _b;
    const axes = plan.axisSelection(plan.snapshot(input.axes));
    const manifests = input.manifests.map(
      (manifest) => plan.unwrap(
        validateThemeExtensionManifest(manifest, {
          encoder: input.encoder,
          dependencies: input.manifests
        })
      )
    ).sort((a, b) => plan.sortText(a.identity.packageName, b.identity.packageName));
    plan.requireThat(
      new Set(manifests.map((manifest) => manifest.identity.packageName)).size === manifests.length,
      "TX_DEPENDENCY_INVALID",
      "$.manifests"
    );
    const registered = new Map(
      manifests.map((manifest) => [manifest.identity.packageName, manifest])
    );
    for (const manifest of manifests)
      for (const dependency of manifest.dependencies) {
        plan.requireThat(
          ((_a = registered.get(dependency.packageName)) == null ? void 0 : _a.identity.contentHash) === dependency.contentHash,
          "TX_DEPENDENCY_INVALID",
          manifest.identity.packageName,
          {
            issue: "registered-dependency-required",
            packageName: dependency.packageName
          }
        );
      }
    const adapterOwners = /* @__PURE__ */ new Map();
    const cssAdapters = manifests.flatMap((manifest) => {
      for (const adapter of manifest.cssAdapters) {
        const owner = adapterOwners.get(adapter.id);
        if (owner !== void 0)
          plan.fail("TX_ADAPTER_INVALID", `$.cssAdapters.${adapter.id}`, {
            issue: "duplicate-public-adapter-id",
            id: adapter.id,
            packages: [owner, manifest.identity.packageName]
          });
        adapterOwners.set(adapter.id, manifest.identity.packageName);
      }
      return manifest.cssAdapters;
    });
    const compiledModules = manifests.flatMap((manifest) => manifest.modules);
    const all = new Map(
      compiledModules.map((module2) => [module2.definition.id, module2.definition])
    );
    plan.requireThat(
      all.size === compiledModules.length && new Set(compiledModules.map((module2) => module2.definition.namespace)).size === compiledModules.length,
      "TX_MODULE_INVALID",
      "$.modules",
      { issue: "composition-id-or-namespace-collision" }
    );
    const variables = /* @__PURE__ */ new Set();
    for (const module2 of all.values()) {
      for (const [path, token] of Object.entries(module2.tokens)) {
        for (const variable of plan.cssVariables(
          plan.tokenCss(module2, path, token.type)
        )) {
          plan.requireThat(
            !variables.has(variable),
            "TX_CSS_COLLISION",
            `${module2.id}/${path}`,
            { variable }
          );
          variables.add(variable);
        }
      }
      for (const [path, metric] of Object.entries(
        module2.displayMetrics ?? {}
      )) {
        const ref = plan.displayMetricReference(module2, path, metric);
        for (const variable of [ref.base.variable, ref.effective.variable]) {
          plan.requireThat(!variables.has(variable), "TX_CSS_COLLISION", ref.id, {
            variable
          });
          variables.add(variable);
        }
      }
    }
    const chosen = input.modules === void 0 ? [...all.keys()] : plan.snapshot(input.modules);
    plan.requireThat(
      Array.isArray(chosen) && new Set(chosen).size === chosen.length && chosen.every((id) => all.has(id)),
      "TX_MODULE_INVALID",
      "$.modules",
      { issue: "registered-modules-required" }
    );
    const selectedModules = [...chosen].sort(plan.sortText);
    const selected = new Map(selectedModules.map((id) => [id, all.get(id)]));
    for (const module2 of selected.values())
      for (const dep of module2.dependencies ?? [])
        plan.requireThat(
          ((_b = selected.get(dep.id)) == null ? void 0 : _b.version) === dep.version && (!dep.contractHash || plan.moduleContractHash(selected.get(dep.id)) === dep.contractHash),
          "TX_DEPENDENCY_INVALID",
          module2.id,
          { issue: "selected-dependency-required", dependency: dep.id }
        );
    const core = /* @__PURE__ */ new Map();
    for (const manifest of manifests)
      for (const token of manifest.coreRequirements.tokens) {
        const prior = core.get(token.path);
        plan.requireThat(
          !prior || plan.canonicalThemeExtensionJson(prior) === plan.canonicalThemeExtensionJson(token),
          "TX_CORE_REQUIREMENT",
          token.path,
          { issue: "conflicting-core-signature" }
        );
        core.set(token.path, token);
      }
    const raw = plan.snapshot(input.overrides ?? {});
    plan.requireThat(
      raw && typeof raw === "object" && !Array.isArray(raw),
      "TX_OVERRIDE_INVALID",
      "$.overrides"
    );
    const overrides = {};
    const declarations = [];
    for (const key of Object.keys(raw).sort(plan.sortText)) {
      const parts = key.split("/");
      plan.requireThat(parts.length === 2, "TX_OVERRIDE_INVALID", key);
      const module2 = selected.get(parts[0]), token = module2 == null ? void 0 : module2.tokens[parts[1]];
      plan.requireThat(
        module2 && (token == null ? void 0 : token.visibility) === "public" && token.overridable,
        "TX_OVERRIDE_INVALID",
        key,
        { issue: "selected-public-overridable-token-required" }
      );
      const value = plan.normalizeValue(raw[key], token.type, `$.overrides.${key}`);
      plan.validateReference(module2, parts[1], token, value, selected, core);
      overrides[key] = value;
      declarations.push(
        ...plan.valueDeclarations(
          module2,
          parts[1],
          token,
          value,
          selected,
          core,
          input.encoder
        )
      );
    }
    plan.checkCycles(selected, axes, overrides);
    for (const module2 of all.values())
      if (!selected.has(module2.id)) {
        for (const [path, token] of Object.entries(module2.tokens))
          for (const variable of plan.cssVariables(
            plan.tokenCss(module2, path, token.type)
          ))
            declarations.push([variable, "initial"]);
        for (const [path, metric] of Object.entries(
          module2.displayMetrics ?? {}
        )) {
          const ref = plan.displayMetricReference(module2, path, metric);
          declarations.push(
            [ref.base.variable, "initial"],
            [ref.effective.variable, "initial"]
          );
        }
      }
    const normalizedOverrides = overrides;
    const attributes = {
      "data-zx-extension": compiledModules.filter((module2) => selected.has(module2.definition.id)).map((module2) => module2.selectorKey).sort(plan.sortText).join(" "),
      "data-zx-ext-axes": plan.AXES.map((axis) => `${axis}-${axes[axis]}`).join(" ")
    };
    return {
      selectedModules,
      normalizedOverrides,
      attributes,
      selectionHash: plan.hashThemeExtensionContent({
        manifests: manifests.map((manifest) => manifest.identity.contentHash),
        selectedModules,
        axes,
        overrides
      }),
      managedProperties: [...variables].sort(plan.sortText),
      declarations: declarations.sort(([a], [b]) => plan.sortText(a, b)),
      publicTokens: manifests.flatMap((manifest) => manifest.publicTokens).filter((token) => selected.has(token.module)),
      cssAdapters: cssAdapters.filter(
        (adapter) => adapter.moduleIds.every((id) => selected.has(id))
      )
    };
  });
}
exports.canonicalThemeExtensionJson = plan.canonicalThemeExtensionJson;
exports.defineThemeCssAdapter = plan.defineThemeCssAdapter;
exports.defineThemeModule = plan.defineThemeModule;
exports.displayMetricReference = plan.displayMetricReference;
exports.hashThemeExtensionContent = plan.hashThemeExtensionContent;
exports.hashThemeExtensionText = plan.hashThemeExtensionText;
exports.createThemeExtensionBundle = createThemeExtensionBundle;
exports.resolveThemeExtensionDeclarations = resolveThemeExtensionDeclarations;
exports.validateThemeCssAdapterTarget = validateThemeCssAdapterTarget;
exports.validateThemeExtensionBundle = validateThemeExtensionBundle;
exports.validateThemeExtensionCoreRequirements = validateThemeExtensionCoreRequirements;
exports.validateThemeExtensionManifest = validateThemeExtensionManifest;
