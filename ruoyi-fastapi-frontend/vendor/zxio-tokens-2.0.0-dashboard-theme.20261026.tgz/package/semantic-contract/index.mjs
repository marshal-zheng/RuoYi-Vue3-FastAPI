import { canonicalThemeContractV4, themeKernel } from "../kernel/index.mjs";
import { p as publicCoreVariable, T as TYPOGRAPHY_FIELDS, s as snapshot, h as hashThemeExtensionContent } from "../_chunks/plan--YyWT46z.mjs";
function createThemeSemanticCatalog() {
  const entries = Object.entries(canonicalThemeContractV4.entries).sort(([a], [b]) => a.localeCompare(b)).map(([path, candidate]) => {
    const entry = candidate;
    return {
      path,
      typeId: entry.typeId,
      lifecycle: entry.lifecycle,
      description: entry.description,
      css: {
        publicVariable: publicCoreVariable(path),
        ...entry.typeId === "typography" ? {
          fields: Object.fromEntries(
            TYPOGRAPHY_FIELDS.map((field) => [
              field,
              `${publicCoreVariable(path)}-${field}`
            ])
          )
        } : {}
      },
      ...entry.lifecycle === "deprecated" ? {
        deprecated: {
          since: entry.deprecatedSince,
          ...entry.migration.kind === "replacement" ? { replacement: entry.migration.path } : { noReplacementReason: entry.migration.reason.detail }
        }
      } : {}
    };
  });
  return snapshot({
    schema: "zx.theme-semantic-contract/1",
    contractVersion: canonicalThemeContractV4.contractVersion,
    typeRegistryContentHash: themeKernel.typeRegistryContentHash,
    contractContentHash: hashThemeExtensionContent(canonicalThemeContractV4),
    entries,
    publicSurface: entries.map(
      ({ description: _description, ...entry }) => entry
    )
  });
}
const themeSemanticCatalog = createThemeSemanticCatalog();
const stableThemeSemantics = Object.freeze(
  themeSemanticCatalog.entries.filter((entry) => entry.lifecycle === "stable")
);
export {
  createThemeSemanticCatalog,
  stableThemeSemantics,
  themeSemanticCatalog
};
