"use strict";
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class CanonicalJsonError extends Error {
  constructor(issue, instancePath, firstSeenPath, numberKind) {
    super(`${issue} at ${instancePath}`);
    __publicField(this, "issue");
    __publicField(this, "instancePath");
    __publicField(this, "firstSeenPath");
    __publicField(this, "numberKind");
    this.name = "CanonicalJsonError";
    this.issue = issue;
    this.instancePath = instancePath;
    this.firstSeenPath = firstSeenPath;
    this.numberKind = numberKind;
  }
}
function compareUtf16(left, right) {
  return left < right ? -1 : left > right ? 1 : 0;
}
function compareAscii(left, right) {
  const length = Math.min(left.length, right.length);
  for (let index = 0; index < length; index += 1) {
    const delta = left.charCodeAt(index) - right.charCodeAt(index);
    if (delta !== 0) return delta;
  }
  return left.length - right.length;
}
function compareBytes(left, right) {
  const length = Math.min(left.length, right.length);
  for (let index = 0; index < length; index += 1) {
    const delta = left[index] - right[index];
    if (delta !== 0) return delta;
  }
  return left.length - right.length;
}
function valueKind(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}
function isPlainObject(value) {
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
function childPath(parent, key) {
  if (typeof key === "number") return `${parent}[${key}]`;
  return `${parent}.${key}`;
}
function snapshotValue(input, instancePath, depth, state) {
  state.nodes += 1;
  if (depth > state.maxDepth || state.nodes > state.maxNodes) {
    throw new CanonicalJsonError("resource-limit", instancePath);
  }
  if (input === null || typeof input === "boolean" || typeof input === "string") {
    return input;
  }
  if (typeof input === "number") {
    if (!Number.isFinite(input)) {
      throw new CanonicalJsonError(
        "non-finite-number",
        instancePath,
        void 0,
        Number.isNaN(input) ? "nan" : input === Number.POSITIVE_INFINITY ? "positive-infinity" : "negative-infinity"
      );
    }
    return Object.is(input, -0) ? 0 : input;
  }
  if (typeof input !== "object") {
    throw new CanonicalJsonError("unsupported-kind", instancePath);
  }
  const objectInput = input;
  const firstSeenPath = state.seen.get(objectInput);
  if (firstSeenPath) {
    throw new CanonicalJsonError("cycle", instancePath, firstSeenPath);
  }
  state.seen.set(objectInput, instancePath);
  try {
    const symbols = Object.getOwnPropertySymbols(objectInput);
    if (symbols.length > 0) {
      throw new CanonicalJsonError("symbol-key", instancePath);
    }
    if (Array.isArray(input)) {
      const output2 = [];
      for (let index = 0; index < input.length; index += 1) {
        if (!Object.prototype.hasOwnProperty.call(input, index)) {
          throw new CanonicalJsonError(
            "sparse-array",
            childPath(instancePath, index)
          );
        }
        const descriptor = Object.getOwnPropertyDescriptor(input, `${index}`);
        if (!descriptor || !("value" in descriptor)) {
          throw new CanonicalJsonError(
            "accessor-property",
            childPath(instancePath, index)
          );
        }
        output2.push(
          snapshotValue(
            descriptor.value,
            childPath(instancePath, index),
            depth + 1,
            state
          )
        );
      }
      const extraKeys = Object.keys(input).filter(
        (key) => !/^\d+$/.test(key) || Number(key) >= input.length
      );
      if (extraKeys.length > 0) {
        throw new CanonicalJsonError(
          "unsupported-kind",
          childPath(instancePath, extraKeys.sort(compareUtf16)[0])
        );
      }
      return output2;
    }
    if (!isPlainObject(objectInput)) {
      throw new CanonicalJsonError("non-plain-object", instancePath);
    }
    const descriptors = Object.getOwnPropertyDescriptors(objectInput);
    const output = /* @__PURE__ */ Object.create(null);
    for (const key of Object.keys(descriptors).sort(compareUtf16)) {
      const descriptor = descriptors[key];
      if (!("value" in descriptor)) {
        throw new CanonicalJsonError(
          "accessor-property",
          childPath(instancePath, key)
        );
      }
      output[key] = snapshotValue(
        descriptor.value,
        childPath(instancePath, key),
        depth + 1,
        state
      );
    }
    return output;
  } catch (error) {
    if (error instanceof CanonicalJsonError) throw error;
    throw new CanonicalJsonError("inspection-failed", instancePath);
  } finally {
    state.seen.delete(objectInput);
  }
}
function snapshotCanonicalJson(input, options = {}) {
  const output = snapshotValue(input, "$", 0, {
    seen: /* @__PURE__ */ new Map(),
    nodes: 0,
    maxDepth: options.maxDepth ?? 128,
    maxNodes: options.maxNodes ?? 1e5
  });
  freezeObjectGraph(output);
  return output;
}
function freezeObjectGraph(input) {
  if (input && typeof input === "object" && !ArrayBuffer.isView(input) && !Object.isFrozen(input)) {
    for (const key of Reflect.ownKeys(input)) {
      freezeObjectGraph(input[key]);
    }
    Object.freeze(input);
  }
}
function deepFreeze(input) {
  freezeObjectGraph(input);
  return input;
}
function serializeValue(value) {
  if (value === null) return "null";
  if (typeof value === "boolean") return value ? "true" : "false";
  if (typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) {
      throw new CanonicalJsonError(
        "non-finite-number",
        "$",
        void 0,
        Number.isNaN(value) ? "nan" : value === Number.POSITIVE_INFINITY ? "positive-infinity" : "negative-infinity"
      );
    }
    return JSON.stringify(Object.is(value, -0) ? 0 : value);
  }
  if (Array.isArray(value)) {
    return `[${value.map((item) => serializeValue(item)).join(",")}]`;
  }
  const objectValue = value;
  return `{${Object.keys(objectValue).sort(compareUtf16).map((key) => `${JSON.stringify(key)}:${serializeValue(objectValue[key])}`).join(",")}}`;
}
function canonicalJsonStringify(input) {
  const owned = snapshotCanonicalJson(input);
  return serializeValue(owned);
}
const utf8Encoder = new TextEncoder();
function utf8ByteLength(value) {
  return utf8Encoder.encode(value).byteLength;
}
function bytesToHex(bytes) {
  let hex = "";
  for (let index = 0; index < bytes.length; index += 1) {
    hex += bytes[index].toString(16).padStart(2, "0");
  }
  return hex;
}
function canonicalJsonBytes(input) {
  return utf8Encoder.encode(canonicalJsonStringify(input));
}
function describeValueKind(input) {
  return valueKind(input);
}
const DIAGNOSTIC_CORE_DEFINITIONS = {
  TK_SOURCE_LOCATOR_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_SCHEMA_VERSION_REQUIRED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_SCHEMA_VERSION_UNSUPPORTED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_SCHEMA_THEME_ID_REQUIRED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_SCHEMA_NAME_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_SCHEMA_JSON_VALUE_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_CONTRACT_VERSION_REQUIRED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_CONTRACT_VERSION_UNSUPPORTED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_RESOLVED_VERSION_UNSUPPORTED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_UNKNOWN: {
    phase: "schema",
    location: "token",
    trace: "forbidden"
  },
  TK_TYPE_VALUE_INVALID: {
    phase: "schema",
    location: "token",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_ID_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_VERSION_MISMATCH: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_SCHEMA_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_DUPLICATE: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_BUILTIN_CONFLICT: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_REGISTRY_NON_DETERMINISTIC: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  },
  TK_TYPE_ALIAS_MISMATCH: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_EXPR_OPERATOR_UNKNOWN: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_EXPR_RESULT_TYPE_MISMATCH: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_EXPR_OPERAND_INVALID: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_EXPR_EVALUATION_INVALID: {
    phase: "resolve",
    location: "token",
    trace: "required"
  },
  TK_EXPR_NON_DETERMINISTIC: {
    phase: "resolve",
    location: "token",
    trace: "required"
  },
  TK_AXIS_DECLARATION_INVALID: {
    phase: "schema",
    location: "axis",
    trace: "forbidden"
  },
  TK_AXIS_DEFAULT_REQUIRED: {
    phase: "schema",
    location: "axis",
    trace: "forbidden"
  },
  TK_AXIS_DEFAULT_INVALID: {
    phase: "schema",
    location: "axis",
    trace: "forbidden"
  },
  TK_AXIS_VALUE_UNSUPPORTED: {
    phase: "transform",
    location: "axis",
    trace: "forbidden"
  },
  TK_TRANSFORM_PATH_UNKNOWN: {
    phase: "transform",
    location: "token",
    trace: "required"
  },
  TK_TRANSFORM_MUTATION_FORBIDDEN: {
    phase: "transform",
    location: "token",
    trace: "required"
  },
  TK_TRANSFORM_TYPE_MISMATCH: {
    phase: "transform",
    location: "token",
    trace: "required"
  },
  TK_TRANSFORM_CONFLICT: {
    phase: "transform",
    location: "token",
    trace: "required"
  },
  TK_DIFF_SOURCE_MISMATCH: {
    phase: "resolve",
    location: "theme",
    trace: "forbidden"
  },
  TK_DIFF_AXES_INVALID: {
    phase: "resolve",
    location: "theme",
    trace: "forbidden"
  },
  TK_DIFF_OUTSIDE_CLOSURE: {
    phase: "resolve",
    location: "token",
    trace: "optional"
  },
  TK_REF_TARGET_MISSING: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_REF_LAYER_FORBIDDEN: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_REF_COMPONENT_FORBIDDEN: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_REF_CYCLE: {
    phase: "reference/expression",
    location: "token",
    trace: "required"
  },
  TK_CONTRACT_ENTRY_MISSING: {
    phase: "contract",
    location: "token",
    trace: "forbidden"
  },
  TK_ELEVATION_GROUP_INCOMPLETE: {
    phase: "contract",
    location: "token",
    trace: "forbidden"
  },
  TK_CONTRACT_TYPE_MISMATCH: {
    phase: "contract",
    location: "token",
    trace: "forbidden"
  },
  TK_CONTRACT_LIFECYCLE_INVALID: {
    phase: "contract",
    location: "token",
    trace: "forbidden"
  },
  TK_CONTRACT_REPLACEMENT_INVALID: {
    phase: "contract",
    location: "token",
    trace: "forbidden"
  },
  TK_CONTRACT_BREAKING_CHANGE: {
    phase: "contract",
    location: "token",
    trace: "forbidden"
  },
  TK_RESOURCE_LIMIT_EXCEEDED: {
    phase: "schema",
    location: "theme",
    trace: "forbidden"
  }
};
const DIAGNOSTIC_PHASE_SUPPRESSION = {
  schema: [],
  transform: ["schema"],
  "reference/expression": ["schema", "transform"],
  resolve: ["schema", "transform", "reference/expression"],
  contract: ["schema", "transform", "reference/expression", "resolve"]
};
function details(fields, branches, optional = []) {
  return Object.freeze({
    fields: Object.freeze(fields),
    branches: Object.freeze(
      branches ?? [
        Object.freeze({
          required: Object.freeze(
            Object.keys(fields).filter((field) => !optional.includes(field))
          ),
          optional: Object.freeze([...optional])
        })
      ]
    )
  });
}
const missingVersionDetails = details({
  receivedVersion: "null",
  supportedVersions: "nonempty-array<string|number>"
});
const unsupportedVersionDetails = details({
  receivedVersion: "string|number",
  supportedVersions: "nonempty-array<string|number>"
});
const axisValueDetails = details({
  axis: "theme-axis-name",
  receivedValue: "string",
  platformDomain: "nonempty-array<string>",
  themeSupportedValues: "nonempty-array<string>"
});
const referenceDetails = details({
  from: "canonical-token-path",
  to: "string",
  allowedTargets: "array<string>"
});
const DIAGNOSTIC_DETAIL_SCHEMAS = {
  TK_SOURCE_LOCATOR_INVALID: details({
    entrypoint: "enum:defineTheme|defineThemeContract|defineThemeV4|defineThemeContractV4|createThemeKernel|validateThemeSource|validateThemeContract|resolveTheme|resolveThemeDiff|validateResolvedTheme|serializeResolvedTheme|computeResolvedThemeHash",
    parameter: "enum:source|sourceLocation|contractLocation|fromLocation|toLocation|inputLocation",
    instancePath: "source-locator-instance-path",
    issue: "enum:missing|not-object|non-plain-object|accessor-property|symbol-key|inspection-failed|file-not-string|file-empty|absolute-or-drive|backslash|dot-or-empty-segment|nul|unknown-property|line-invalid|column-invalid",
    receivedKind: "enum:undefined|null|boolean|number|bigint|string|symbol|function|array|object"
  }),
  TK_SCHEMA_VERSION_REQUIRED: missingVersionDetails,
  TK_SCHEMA_VERSION_UNSUPPORTED: unsupportedVersionDetails,
  TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED: details({
    matchedFields: "nonempty-array<string>",
    supportedVersions: "tuple:4"
  }),
  TK_SCHEMA_THEME_ID_REQUIRED: details({
    field: "nonempty-string",
    received: "json|null",
    rule: "nonempty-string"
  }),
  TK_SCHEMA_NAME_INVALID: details({
    field: "nonempty-string",
    received: "json|null",
    rule: "nonempty-string"
  }),
  TK_SCHEMA_JSON_VALUE_INVALID: details(
    {
      valueKind: "nonempty-string",
      instancePath: "string",
      issue: "enum:unsupported-kind|non-finite-number|non-plain-object|accessor-property|symbol-key|sparse-array|cycle|resource-limit|inspection-failed|alias-envelope|component-namespace-invalid|component-namespace-repeated|conflict-policy-invalid|conflict-policy-object-required|contract-envelope|expression-depth-limit|expression-envelope|expression-literal-envelope|expression-nested-envelope|expression-operand-envelope|expression-operand-kind|expression-ref-envelope|literal-envelope|locator-mismatch|non-empty-components-required|non-empty-token-record-required|resolved-axes-invalid|resolved-dependency-missing|resolved-public-invalid|resolved-public-surface-invalid|resolved-shape-invalid|resolved-token-catalog-invalid|resolved-token-invalid|resolved-trace-causality-invalid|resolved-value-not-canonical|resolved-visibility-invalid|theme-envelope|theme-object-required|token-definition-invalid|token-path-invalid|token-value-branch|transform-array-required|transform-axis-object-required|transform-invalid|transforms-object-required|unknown-axis|unknown-transform-axis|unknown-transform-axis-value|content-hash-mismatch",
      expectedHash: "sha256",
      receivedHash: "sha256"
    },
    [
      {
        when: { issue: "content-hash-mismatch" },
        required: [
          "valueKind",
          "instancePath",
          "issue",
          "expectedHash",
          "receivedHash"
        ],
        optional: []
      },
      {
        required: ["valueKind", "instancePath"],
        optional: ["issue"]
      }
    ]
  ),
  TK_CONTRACT_VERSION_REQUIRED: missingVersionDetails,
  TK_CONTRACT_VERSION_UNSUPPORTED: unsupportedVersionDetails,
  TK_RESOLVED_VERSION_UNSUPPORTED: unsupportedVersionDetails,
  TK_TYPE_UNKNOWN: details({
    receivedTypeId: "string",
    registeredTypeIds: "array<string>"
  }),
  TK_TYPE_VALUE_INVALID: details(
    {
      expectedTypeId: "string",
      actualTypeId: "string|null",
      actualValue: "json|null",
      validationRule: "nonempty-string",
      instancePath: "string"
    },
    void 0,
    ["instancePath"]
  ),
  TK_TYPE_REGISTRY_ID_INVALID: details({
    descriptorIndex: "nonnegative-safe-integer",
    typeId: "string",
    rule: "nonempty-string"
  }),
  TK_TYPE_REGISTRY_VERSION_MISMATCH: details({
    descriptorIndex: "nonnegative-safe-integer",
    typeId: "string",
    schemaVersion: "finite-number|null",
    expectedSchemaVersion: "positive-safe-integer"
  }),
  TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID: details(
    {
      descriptorIndex: "nonnegative-safe-integer",
      typeId: "string|null",
      instancePath: "string",
      receivedKind: "nonempty-string",
      issue: "enum:non-finite-number|cycle|resource-limit|non-plain-object|accessor-property|symbol-key|sparse-array|unsupported-kind|inspection-failed|descriptor-non-plain|descriptor-symbol-key|descriptor-accessor",
      numberKind: "enum:nan|positive-infinity|negative-infinity",
      firstSeenPath: "string",
      resource: "enum:schema-depth|schema-nodes|schema-properties|schema-enum-members|schema-bytes",
      limit: "nonnegative-safe-integer",
      actual: "nonnegative-safe-integer",
      truncated: "boolean"
    },
    [
      {
        when: { issue: "non-finite-number" },
        required: [
          "descriptorIndex",
          "typeId",
          "instancePath",
          "receivedKind",
          "issue",
          "numberKind"
        ],
        optional: []
      },
      {
        when: { issue: "cycle" },
        required: [
          "descriptorIndex",
          "typeId",
          "instancePath",
          "receivedKind",
          "issue",
          "firstSeenPath"
        ],
        optional: []
      },
      {
        when: { issue: "resource-limit" },
        required: [
          "descriptorIndex",
          "typeId",
          "instancePath",
          "receivedKind",
          "issue",
          "resource",
          "limit",
          "actual",
          "truncated"
        ],
        optional: []
      },
      {
        when: {
          issue: [
            "non-plain-object",
            "accessor-property",
            "symbol-key",
            "sparse-array",
            "unsupported-kind",
            "inspection-failed",
            "descriptor-non-plain",
            "descriptor-symbol-key",
            "descriptor-accessor"
          ]
        },
        required: [
          "descriptorIndex",
          "typeId",
          "instancePath",
          "receivedKind",
          "issue"
        ],
        optional: []
      }
    ]
  ),
  TK_TYPE_REGISTRY_SCHEMA_INVALID: details(
    {
      descriptorIndex: "nonnegative-safe-integer",
      typeId: "string",
      instancePath: "string",
      keyword: "string|null",
      issue: "enum:unknown-keyword|keyword-not-allowed-for-type|missing-required-keyword|type-mismatch|invalid-range|duplicate-required|required-property-unknown|enum-empty|enum-type-mismatch|enum-duplicate",
      receivedKind: "nonempty-string",
      firstIndex: "nonnegative-safe-integer",
      duplicateIndex: "nonnegative-safe-integer"
    },
    [
      {
        when: { issue: "enum-duplicate" },
        required: [
          "descriptorIndex",
          "typeId",
          "instancePath",
          "keyword",
          "issue",
          "receivedKind",
          "firstIndex",
          "duplicateIndex"
        ],
        optional: []
      },
      {
        when: {
          issue: [
            "unknown-keyword",
            "keyword-not-allowed-for-type",
            "missing-required-keyword",
            "type-mismatch",
            "invalid-range",
            "duplicate-required",
            "required-property-unknown",
            "enum-empty",
            "enum-type-mismatch"
          ]
        },
        required: [
          "descriptorIndex",
          "typeId",
          "instancePath",
          "keyword",
          "issue",
          "receivedKind"
        ],
        optional: []
      }
    ]
  ),
  TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED: details({
    descriptorIndex: "nonnegative-safe-integer",
    typeId: "string",
    stage: "enum:jcs|utf8",
    issue: "enum:serializer-rejected|encoding-failed"
  }),
  TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID: details(
    {
      failure: "enum:format|mismatch",
      descriptorIndex: "nonnegative-safe-integer",
      typeId: "string",
      declaredHash: "string",
      requiredFormat: "literal:sha256:<64-lowercase-hex>",
      computedHash: "sha256"
    },
    [
      {
        when: { failure: "format" },
        required: [
          "failure",
          "descriptorIndex",
          "typeId",
          "declaredHash",
          "requiredFormat"
        ],
        optional: []
      },
      {
        when: { failure: "mismatch" },
        required: [
          "failure",
          "descriptorIndex",
          "typeId",
          "declaredHash",
          "computedHash"
        ],
        optional: []
      }
    ]
  ),
  TK_TYPE_REGISTRY_DUPLICATE: details({
    typeId: "string",
    firstIndex: "nonnegative-safe-integer",
    duplicateIndex: "nonnegative-safe-integer"
  }),
  TK_TYPE_REGISTRY_BUILTIN_CONFLICT: details({
    descriptorIndex: "nonnegative-safe-integer",
    typeId: "string",
    builtInTypeId: "built-in-type-id"
  }),
  TK_TYPE_REGISTRY_NON_DETERMINISTIC: details({
    descriptorIndex: "nonnegative-safe-integer",
    typeId: "string",
    firstHash: "sha256",
    replayHash: "sha256"
  }),
  TK_TYPE_ALIAS_MISMATCH: details({
    from: "canonical-token-path",
    to: "canonical-token-path",
    projection: "built-in-field-projection|null",
    expectedTypeId: "string",
    actualTypeId: "string",
    actualValue: "json|null"
  }),
  TK_EXPR_OPERATOR_UNKNOWN: details({
    operator: "string",
    supportedOperators: "array<operator-id>"
  }),
  TK_EXPR_RESULT_TYPE_MISMATCH: details({
    mismatch: "enum:declared-vs-operator|declared-vs-context",
    operator: "operator-id",
    declaredResultTypeId: "string",
    operatorResultTypeIds: "nonempty-array<string>",
    expectedResultTypeId: "string"
  }),
  TK_EXPR_OPERAND_INVALID: details(
    {
      issue: "enum:arity|operand-type",
      operator: "string",
      receivedArity: "nonnegative-safe-integer",
      expectedArities: "nonempty-array<nonnegative-safe-integer>",
      operandIndex: "nonnegative-safe-integer",
      expectedTypeIds: "nonempty-array<string>",
      actualTypeId: "string|null",
      actualValue: "json|null"
    },
    [
      {
        when: { issue: "arity" },
        required: ["issue", "operator", "receivedArity", "expectedArities"],
        optional: []
      },
      {
        when: { issue: "operand-type" },
        required: [
          "issue",
          "operator",
          "operandIndex",
          "expectedTypeIds",
          "actualTypeId",
          "actualValue"
        ],
        optional: []
      }
    ]
  ),
  TK_EXPR_EVALUATION_INVALID: details(
    {
      issue: "enum:operand-order|color-space-mismatch|operand-range|non-finite-result|canonical-result-invalid",
      operator: "operator-id",
      constraint: "literal:min-lte-max",
      minOperandIndex: "literal:1",
      maxOperandIndex: "literal:2",
      minValue: "finite-number",
      maxValue: "finite-number",
      leftOperandIndex: "literal:0",
      rightOperandIndex: "literal:1",
      leftColorSpace: "canonical-color-space",
      rightColorSpace: "canonical-color-space",
      operandIndex: "nonnegative-safe-integer",
      operandRole: "enum:rightWeight|alpha",
      receivedValue: "finite-number|json",
      inclusiveMinimum: "literal:0",
      inclusiveMaximum: "literal:1",
      resultTypeId: "string",
      resultInstancePath: "string",
      numberKind: "enum:positive-infinity|negative-infinity",
      validationRule: "nonempty-string",
      causalOperands: "nonempty-array<expression-causal-operand>"
    },
    [
      {
        when: { issue: "operand-order" },
        required: [
          "issue",
          "operator",
          "constraint",
          "minOperandIndex",
          "maxOperandIndex",
          "minValue",
          "maxValue"
        ],
        optional: []
      },
      {
        when: { issue: "color-space-mismatch" },
        required: [
          "issue",
          "operator",
          "leftOperandIndex",
          "rightOperandIndex",
          "leftColorSpace",
          "rightColorSpace"
        ],
        optional: []
      },
      {
        when: { issue: "operand-range" },
        required: [
          "issue",
          "operator",
          "operandIndex",
          "operandRole",
          "receivedValue",
          "inclusiveMinimum",
          "inclusiveMaximum"
        ],
        optional: []
      },
      {
        when: { issue: "non-finite-result" },
        required: [
          "issue",
          "operator",
          "resultTypeId",
          "resultInstancePath",
          "numberKind",
          "causalOperands"
        ],
        optional: []
      },
      {
        when: { issue: "canonical-result-invalid" },
        required: [
          "issue",
          "operator",
          "resultTypeId",
          "resultInstancePath",
          "validationRule",
          "receivedValue",
          "causalOperands"
        ],
        optional: []
      }
    ]
  ),
  TK_EXPR_NON_DETERMINISTIC: details({
    operator: "operator-id",
    firstHash: "sha256",
    replayHash: "sha256"
  }),
  TK_AXIS_DECLARATION_INVALID: details(
    {
      issue: "enum:declaration-missing|declaration-shape|supported-missing|supported-empty|supported-value-unsupported|supported-duplicate",
      axis: "theme-axis-name",
      platformDomain: "nonempty-array<string>",
      receivedValue: "string",
      valueIndex: "nonnegative-safe-integer",
      firstIndex: "nonnegative-safe-integer",
      duplicateIndex: "nonnegative-safe-integer"
    },
    [
      {
        when: {
          issue: [
            "declaration-missing",
            "declaration-shape",
            "supported-missing",
            "supported-empty"
          ]
        },
        required: ["issue", "axis", "platformDomain"],
        optional: []
      },
      {
        when: { issue: "supported-value-unsupported" },
        required: [
          "issue",
          "axis",
          "receivedValue",
          "valueIndex",
          "platformDomain"
        ],
        optional: []
      },
      {
        when: { issue: "supported-duplicate" },
        required: [
          "issue",
          "axis",
          "receivedValue",
          "firstIndex",
          "duplicateIndex",
          "platformDomain"
        ],
        optional: []
      }
    ]
  ),
  TK_AXIS_DEFAULT_REQUIRED: details({
    axis: "theme-axis-name",
    platformDomain: "nonempty-array<string>",
    themeSupportedValues: "nonempty-array<string>"
  }),
  TK_AXIS_DEFAULT_INVALID: axisValueDetails,
  TK_AXIS_VALUE_UNSUPPORTED: axisValueDetails,
  TK_TRANSFORM_PATH_UNKNOWN: details({ path: "canonical-token-path" }),
  TK_TRANSFORM_MUTATION_FORBIDDEN: details({
    path: "canonical-token-path",
    forbiddenFields: "nonempty-array<string>"
  }),
  TK_TRANSFORM_TYPE_MISMATCH: details(
    {
      issue: "enum:expect-vs-base|value-declared-type-vs-expect|literal-invalid-for-expect",
      path: "canonical-token-path",
      baseTypeId: "string",
      expectTypeId: "string",
      valueKind: "enum:alias|expression",
      declaredValueTypeId: "string",
      actualValue: "json",
      validationRule: "nonempty-string"
    },
    [
      {
        when: { issue: "expect-vs-base" },
        required: ["issue", "path", "baseTypeId", "expectTypeId"],
        optional: []
      },
      {
        when: { issue: "value-declared-type-vs-expect" },
        required: [
          "issue",
          "path",
          "baseTypeId",
          "expectTypeId",
          "valueKind",
          "declaredValueTypeId"
        ],
        optional: []
      },
      {
        when: { issue: "literal-invalid-for-expect" },
        required: [
          "issue",
          "path",
          "baseTypeId",
          "expectTypeId",
          "actualValue",
          "validationRule"
        ],
        optional: []
      }
    ]
  ),
  TK_TRANSFORM_CONFLICT: details({
    path: "canonical-token-path",
    writers: "tuple-at-least-2<theme-axis-name>"
  }),
  TK_DIFF_SOURCE_MISMATCH: details({
    mismatches: "nonempty-array<diff-identity-mismatch>"
  }),
  TK_DIFF_AXES_INVALID: details({
    differingAxes: "array<theme-axis-name>",
    requiredDifferenceCount: "literal:1"
  }),
  TK_DIFF_OUTSIDE_CLOSURE: details({
    path: "canonical-token-path",
    changedFields: "array<string>"
  }),
  TK_REF_TARGET_MISSING: referenceDetails,
  TK_REF_LAYER_FORBIDDEN: referenceDetails,
  TK_REF_COMPONENT_FORBIDDEN: referenceDetails,
  TK_REF_CYCLE: details({
    cycle: "tuple-at-least-2<canonical-token-path>",
    edgeCount: "positive-safe-integer"
  }),
  TK_CONTRACT_ENTRY_MISSING: details({ path: "canonical-token-path" }),
  TK_ELEVATION_GROUP_INCOMPLETE: details({
    role: "nonempty-string",
    issue: "enum:missing-facets|unknown-role|unknown-facet",
    facets: "array<string>"
  }),
  TK_CONTRACT_TYPE_MISMATCH: details({
    path: "canonical-token-path",
    expectedTypeId: "string",
    actualTypeId: "string"
  }),
  TK_CONTRACT_LIFECYCLE_INVALID: details({
    path: "canonical-token-path",
    from: "string",
    to: "string",
    rule: "nonempty-string"
  }),
  TK_CONTRACT_REPLACEMENT_INVALID: details({
    path: "canonical-token-path",
    replacement: "canonical-token-path|null",
    reason: "nonempty-string"
  }),
  TK_CONTRACT_BREAKING_CHANGE: details({
    path: "canonical-token-path",
    changedFields: "nonempty-array<string>",
    baselineVersion: "semver"
  }),
  TK_RESOURCE_LIMIT_EXCEEDED: details({
    resource: "enum:tokens|edges|path-length|expression-depth|diagnostics",
    limit: "nonnegative-safe-integer",
    actual: "nonnegative-safe-integer",
    truncated: "boolean"
  })
};
const DIAGNOSTIC_DEFINITIONS = Object.freeze(
  Object.fromEntries(
    Object.keys(DIAGNOSTIC_CORE_DEFINITIONS).map(
      (code) => {
        const core = DIAGNOSTIC_CORE_DEFINITIONS[code];
        return [
          code,
          Object.freeze({
            ...core,
            details: DIAGNOSTIC_DETAIL_SCHEMAS[code],
            suppressedBy: DIAGNOSTIC_PHASE_SUPPRESSION[core.phase],
            defaultHintKey: `theme-kernel.${code.toLowerCase()}`
          })
        ];
      }
    )
  )
);
function matchesFieldType(descriptor, value) {
  if (descriptor.startsWith("enum:")) {
    return typeof value === "string" && descriptor.slice("enum:".length).split("|").includes(value);
  }
  if (descriptor.startsWith("literal:")) {
    const literal = descriptor.slice("literal:".length);
    return String(value) === literal;
  }
  if (descriptor.includes("|")) {
    return descriptor.split("|").some((candidate) => matchesFieldType(candidate, value));
  }
  if (descriptor === "null") return value === null;
  if (descriptor === "boolean") return typeof value === "boolean";
  if (descriptor === "number") return typeof value === "number";
  if (descriptor === "finite-number") {
    return typeof value === "number" && Number.isFinite(value);
  }
  if (descriptor === "nonnegative-safe-integer") {
    return Number.isSafeInteger(value) && value >= 0;
  }
  if (descriptor === "positive-safe-integer") {
    return Number.isSafeInteger(value) && value > 0;
  }
  if (descriptor === "sha256") {
    return typeof value === "string" && /^sha256:[a-f0-9]{64}$/.test(value);
  }
  if (descriptor === "semver") {
    return typeof value === "string" && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value);
  }
  if (descriptor === "nonempty-string") {
    return typeof value === "string" && value.length > 0;
  }
  if (descriptor === "string" || descriptor.endsWith("-id") || descriptor.endsWith("-path") || descriptor.endsWith("-name") || descriptor === "built-in-field-projection" || descriptor === "canonical-color-space" || descriptor === "source-locator-instance-path" || descriptor === "schema-json-issue") {
    return typeof value === "string";
  }
  if (descriptor.startsWith("array<") || descriptor.startsWith("nonempty-array<") || descriptor.startsWith("tuple")) {
    return Array.isArray(value) && (!descriptor.startsWith("nonempty-array<") || value.length > 0) && (!descriptor.startsWith("tuple-at-least-2<") || value.length >= 2) && (descriptor !== "tuple:4" || value.length === 1 && value[0] === 4);
  }
  if (descriptor === "json") return value !== void 0;
  return true;
}
function branchConditionMatches(branch, input) {
  return Object.entries(branch.when ?? {}).every(
    ([field, expected]) => Array.isArray(expected) ? expected.includes(input[field]) : input[field] === expected
  );
}
function diagnosticDetailsMatch(code, input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return false;
  const record = input;
  const schema = DIAGNOSTIC_DEFINITIONS[code].details;
  const conditional = schema.branches.filter(
    (branch) => branch.when && branchConditionMatches(branch, record)
  );
  const candidates = conditional.length > 0 ? conditional : schema.branches.filter((branch) => !branch.when);
  return candidates.some((branch) => {
    const allowed = /* @__PURE__ */ new Set([...branch.required, ...branch.optional]);
    return branch.required.every(
      (field) => Object.prototype.hasOwnProperty.call(record, field)
    ) && Object.keys(record).every((field) => allowed.has(field)) && Object.entries(record).every(([field, value]) => {
      const descriptor = schema.fields[field];
      return descriptor !== void 0 && matchesFieldType(descriptor, value);
    });
  });
}
const KERNEL_INPUT_DIAGNOSTIC_SOURCE = deepFreeze({
  file: "packages/tokens/src/kernel/index.ts"
});
const PHASE_RANK = {
  schema: 0,
  transform: 1,
  "reference/expression": 2,
  resolve: 3,
  contract: 4
};
const MAX_THEME_DIAGNOSTICS = 256;
function compareOptionalNumber(left, right) {
  return (left ?? 0) - (right ?? 0);
}
function diagnosticIdentity(diagnostic) {
  return [
    PHASE_RANK[diagnostic.phase],
    diagnostic.code,
    diagnostic.source.file,
    diagnostic.source.line ?? 0,
    diagnostic.source.column ?? 0,
    diagnostic.location.kind,
    diagnostic.location.path,
    canonicalJsonStringify(diagnostic.details),
    canonicalJsonStringify(diagnostic.trace ?? [])
  ].join("\0");
}
function sortAndDedupeDiagnostics(diagnostics) {
  const sorted = [...diagnostics].sort((left, right) => {
    const phase = PHASE_RANK[left.phase] - PHASE_RANK[right.phase];
    if (phase !== 0) return phase;
    const code = compareAscii(left.code, right.code);
    if (code !== 0) return code;
    const source = compareAscii(left.source.file, right.source.file);
    if (source !== 0) return source;
    const line = compareOptionalNumber(left.source.line, right.source.line);
    if (line !== 0) return line;
    const column = compareOptionalNumber(
      left.source.column,
      right.source.column
    );
    if (column !== 0) return column;
    const kind = compareAscii(left.location.kind, right.location.kind);
    if (kind !== 0) return kind;
    const path = compareAscii(left.location.path, right.location.path);
    if (path !== 0) return path;
    return compareAscii(diagnosticIdentity(left), diagnosticIdentity(right));
  });
  const output = [];
  let previousIdentity;
  for (const diagnostic of sorted) {
    const identity = diagnosticIdentity(diagnostic);
    if (identity !== previousIdentity) output.push(diagnostic);
    previousIdentity = identity;
  }
  return Object.freeze(output);
}
function createDiagnostic(code, input) {
  const definition = DIAGNOSTIC_DEFINITIONS[code];
  if (definition.trace === "required" && !input.trace) {
    throw new Error(`Kernel invariant: ${code} requires trace`);
  }
  if (definition.trace === "forbidden" && input.trace) {
    throw new Error(`Kernel invariant: ${code} forbids trace`);
  }
  if (definition.location !== input.location.kind) {
    throw new Error(`Kernel invariant: ${code} location mismatch`);
  }
  if (!diagnosticDetailsMatch(code, input.details)) {
    throw new Error(`Kernel invariant: ${code} details mismatch`);
  }
  const diagnostic = {
    code,
    phase: definition.phase,
    source: input.source ?? KERNEL_INPUT_DIAGNOSTIC_SOURCE,
    ...input.themeId ? { themeId: input.themeId } : {},
    location: input.location,
    reason: input.reason ?? code,
    hint: input.hint ?? definition.defaultHintKey,
    details: input.details,
    ...input.trace ? { trace: input.trace } : {}
  };
  return snapshotCanonicalJson(diagnostic);
}
function ok(value) {
  return Object.freeze({
    ok: true,
    diagnosticSchemaVersion: 1,
    value
  });
}
function failure(diagnostics) {
  var _a, _b;
  const normalized = sortAndDedupeDiagnostics(diagnostics);
  const bounded = normalized.length <= MAX_THEME_DIAGNOSTICS ? normalized : sortAndDedupeDiagnostics([
    ...normalized.slice(0, MAX_THEME_DIAGNOSTICS - 1),
    createDiagnostic("TK_RESOURCE_LIMIT_EXCEEDED", {
      source: ((_a = normalized[0]) == null ? void 0 : _a.source) ?? KERNEL_INPUT_DIAGNOSTIC_SOURCE,
      themeId: (_b = normalized[0]) == null ? void 0 : _b.themeId,
      location: themeLocation(),
      details: {
        resource: "diagnostics",
        limit: MAX_THEME_DIAGNOSTICS,
        actual: normalized.length,
        truncated: true
      }
    })
  ]);
  return Object.freeze({
    ok: false,
    diagnosticSchemaVersion: 1,
    diagnostics: bounded
  });
}
function themeLocation() {
  return { kind: "theme", path: "$" };
}
function tokenLocation(path) {
  return { kind: "token", path };
}
function axisLocation(path) {
  return { kind: "axis", path };
}
const K = new Uint32Array([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
function rotateRight(value, bits) {
  return value >>> bits | value << 32 - bits;
}
function sha256Hex(input) {
  const bitLow = input.byteLength << 3 >>> 0;
  const bitHigh = Math.floor(input.byteLength / 536870912);
  const paddedLength = input.byteLength + 72 >> 6 << 6;
  const padded = new Uint8Array(paddedLength);
  padded.set(input);
  padded[input.byteLength] = 128;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 8, bitHigh, false);
  view.setUint32(paddedLength - 4, bitLow, false);
  const hash = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  const words = new Uint32Array(64);
  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4, false);
    }
    for (let index = 16; index < 64; index += 1) {
      const s0 = rotateRight(words[index - 15], 7) ^ rotateRight(words[index - 15], 18) ^ words[index - 15] >>> 3;
      const s1 = rotateRight(words[index - 2], 17) ^ rotateRight(words[index - 2], 19) ^ words[index - 2] >>> 10;
      words[index] = words[index - 16] + s0 + words[index - 7] + s1 >>> 0;
    }
    let a = hash[0];
    let b = hash[1];
    let c = hash[2];
    let d = hash[3];
    let e = hash[4];
    let f = hash[5];
    let g = hash[6];
    let h = hash[7];
    for (let index = 0; index < 64; index += 1) {
      const sigma1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const ch = e & f ^ ~e & g;
      const temp1 = h + sigma1 + ch + K[index] + words[index] >>> 0;
      const sigma0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const maj = a & b ^ a & c ^ b & c;
      const temp2 = sigma0 + maj >>> 0;
      h = g;
      g = f;
      f = e;
      e = d + temp1 >>> 0;
      d = c;
      c = b;
      b = a;
      a = temp1 + temp2 >>> 0;
    }
    hash[0] = hash[0] + a >>> 0;
    hash[1] = hash[1] + b >>> 0;
    hash[2] = hash[2] + c >>> 0;
    hash[3] = hash[3] + d >>> 0;
    hash[4] = hash[4] + e >>> 0;
    hash[5] = hash[5] + f >>> 0;
    hash[6] = hash[6] + g >>> 0;
    hash[7] = hash[7] + h >>> 0;
  }
  let hex = "";
  for (let index = 0; index < 8; index += 1) {
    hex += hash[index].toString(16).padStart(8, "0");
  }
  return hex;
}
function sha256Bytes(input) {
  return `sha256:${sha256Hex(input)}`;
}
function computeCanonicalHash(input) {
  return sha256Bytes(canonicalJsonBytes(input));
}
const DIMENSION_UNITS = /* @__PURE__ */ new Set([
  "px",
  "rem",
  "em",
  "%",
  "vw",
  "vh",
  "vmin",
  "vmax",
  "ch",
  "lh",
  "rlh"
]);
const BORDER_STYLES = /* @__PURE__ */ new Set(["none", "solid", "dashed", "dotted", "double"]);
const STROKE_STYLE_KEYWORDS = /* @__PURE__ */ new Set([
  "solid",
  "dashed",
  "dotted",
  "double",
  "groove",
  "ridge",
  "outset",
  "inset"
]);
const STROKE_LINE_CAPS = /* @__PURE__ */ new Set(["butt", "round", "square"]);
const BUILT_IN_TYPE_IDS = deepFreeze([
  "border",
  "color",
  "cubic-bezier",
  "dimension",
  "duration",
  "font-family",
  "font-weight",
  "gradient",
  "number",
  "shadow",
  "strokeStyle",
  "string",
  "transition",
  "typography"
]);
const BUILT_IN_TYPE_ID_SET = new Set(BUILT_IN_TYPE_IDS);
function success(value) {
  return { ok: true, value };
}
function invalid(rule, instancePath = "$") {
  return { ok: false, rule, instancePath };
}
function isRecord$2(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return false;
  const prototype = Object.getPrototypeOf(input);
  return prototype === Object.prototype || prototype === null;
}
function hasExactKeys(input, required, optional = []) {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  const keys = Object.keys(input);
  return required.every((key) => Object.prototype.hasOwnProperty.call(input, key)) && keys.every((key) => allowed.has(key));
}
function finiteNumber(input) {
  if (typeof input !== "number" || !Number.isFinite(input)) {
    return invalid("finite-number");
  }
  return success(Object.is(input, -0) ? 0 : input);
}
function canonicalizeDimension(input, depth = 0) {
  if (depth > 32) return invalid("dimension-depth");
  if (!isRecord$2(input) || typeof input.kind !== "string") {
    return invalid("dimension-object");
  }
  if (input.kind === "value") {
    if (!hasExactKeys(input, ["kind", "value", "unit"])) {
      return invalid("dimension-value-shape");
    }
    const value = finiteNumber(input.value);
    if (!value.ok || typeof input.unit !== "string" || !DIMENSION_UNITS.has(input.unit)) {
      return invalid("dimension-value");
    }
    return success({
      kind: "value",
      value: value.value,
      unit: input.unit
    });
  }
  if (input.kind !== "calc" || !hasExactKeys(input, ["kind", "op", "args"]) || !Array.isArray(input.args) || input.args.length !== 2) {
    return invalid("dimension-calc-shape");
  }
  if (input.op === "add" || input.op === "subtract") {
    const left = canonicalizeDimension(input.args[0], depth + 1);
    const right = canonicalizeDimension(input.args[1], depth + 1);
    if (!left.ok || !right.ok) return invalid("dimension-calc-operands");
    return success({
      kind: "calc",
      op: input.op,
      args: [left.value, right.value]
    });
  }
  if (input.op === "multiply") {
    const dimension = canonicalizeDimension(input.args[0], depth + 1);
    const multiplier = finiteNumber(input.args[1]);
    if (!dimension.ok || !multiplier.ok) {
      return invalid("dimension-multiply-operands");
    }
    return success({
      kind: "calc",
      op: "multiply",
      args: [dimension.value, multiplier.value]
    });
  }
  return invalid("dimension-operation");
}
function canonicalizeColor(input) {
  if (!isRecord$2(input) || !hasExactKeys(input, ["colorSpace", "components", "alpha"]) || !Array.isArray(input.components) || input.components.length !== 3 || !["srgb", "display-p3", "oklch"].includes(String(input.colorSpace))) {
    return invalid("color-shape");
  }
  const components = input.components.map(
    (component) => finiteNumber(component)
  );
  const alpha = finiteNumber(input.alpha);
  if (components.some((component) => !component.ok) || !alpha.ok) {
    return invalid("color-finite-components");
  }
  const values = components.map(
    (component) => component.value
  );
  if (alpha.value < 0 || alpha.value > 1) return invalid("color-alpha-range");
  if (input.colorSpace === "oklch") {
    if (values[0] < 0 || values[0] > 1 || values[1] < 0) {
      return invalid("color-oklch-range");
    }
    values[2] = (values[2] % 360 + 360) % 360;
  } else if (values.some((component) => component < 0 || component > 1)) {
    return invalid("color-component-range");
  }
  return success({
    colorSpace: input.colorSpace,
    components: values,
    alpha: alpha.value
  });
}
function canonicalizeShadowLayer(input) {
  if (!isRecord$2(input) || !hasExactKeys(input, [
    "color",
    "offsetX",
    "offsetY",
    "blur",
    "spread",
    "inset"
  ]) || typeof input.inset !== "boolean") {
    return invalid("shadow-layer-shape");
  }
  const color = canonicalizeColor(input.color);
  const offsetX = canonicalizeDimension(input.offsetX);
  const offsetY = canonicalizeDimension(input.offsetY);
  const blur = canonicalizeDimension(input.blur);
  const spread = canonicalizeDimension(input.spread);
  if (!color.ok || !offsetX.ok || !offsetY.ok || !blur.ok || !spread.ok) {
    return invalid("shadow-layer-value");
  }
  return success({
    color: color.value,
    offsetX: offsetX.value,
    offsetY: offsetY.value,
    blur: blur.value,
    spread: spread.value,
    inset: input.inset
  });
}
function canonicalizeGradient(input) {
  if (!isRecord$2(input) || !hasExactKeys(input, ["angle", "stops"]) || !Array.isArray(input.stops) || input.stops.length === 0) {
    return invalid("gradient-shape");
  }
  const angle = finiteNumber(input.angle);
  if (!angle.ok) return invalid("gradient-angle", "$.angle");
  const stops = [];
  for (const [index, entry] of input.stops.entries()) {
    if (!isRecord$2(entry) || !hasExactKeys(entry, ["color", "position"])) {
      return invalid("gradient-stop-shape", `$.stops[${index}]`);
    }
    const color = canonicalizeColor(entry.color);
    const position = finiteNumber(entry.position);
    if (!color.ok) {
      return invalid("gradient-stop-color", `$.stops[${index}].color`);
    }
    if (!position.ok) {
      return invalid("gradient-stop-position", `$.stops[${index}].position`);
    }
    stops.push({
      color: color.value,
      position: Math.min(1, Math.max(0, position.value))
    });
  }
  return success({
    angle: (angle.value % 360 + 360) % 360,
    stops
  });
}
function canonicalizeStrokeStyle(input) {
  if (typeof input === "string") {
    return STROKE_STYLE_KEYWORDS.has(input) ? success(input) : invalid("stroke-style-keyword");
  }
  if (!isRecord$2(input) || !hasExactKeys(input, ["dashArray", "lineCap"]) || !Array.isArray(input.dashArray) || input.dashArray.length === 0 || typeof input.lineCap !== "string" || !STROKE_LINE_CAPS.has(input.lineCap)) {
    return invalid("stroke-style-shape");
  }
  const dashArray = input.dashArray.map((entry) => canonicalizeDimension(entry));
  const invalidIndex = dashArray.findIndex((entry) => !entry.ok);
  if (invalidIndex >= 0) {
    return invalid("stroke-style-dash-array", `$.dashArray[${invalidIndex}]`);
  }
  return success({
    dashArray: dashArray.map(
      (entry) => entry.value
    ),
    lineCap: input.lineCap
  });
}
function canonicalizeTransition(input) {
  if (!isRecord$2(input) || !hasExactKeys(input, ["duration", "delay", "timingFunction"])) {
    return invalid("transition-shape");
  }
  const duration = canonicalizeBuiltIn("duration", input.duration);
  const delay = canonicalizeBuiltIn("duration", input.delay);
  const timingFunction = canonicalizeBuiltIn(
    "cubic-bezier",
    input.timingFunction
  );
  if (!duration.ok) return invalid("transition-duration", "$.duration");
  if (!delay.ok) return invalid("transition-delay", "$.delay");
  if (!timingFunction.ok) {
    return invalid("transition-timing-function", "$.timingFunction");
  }
  return success({
    duration: duration.value,
    delay: delay.value,
    timingFunction: timingFunction.value
  });
}
function canonicalizeBorder(input) {
  if (!isRecord$2(input) || !hasExactKeys(input, ["width", "style", "color"]) || typeof input.style !== "string" || !BORDER_STYLES.has(input.style)) {
    return invalid("border-shape");
  }
  const width = canonicalizeDimension(input.width);
  const color = canonicalizeColor(input.color);
  if (!width.ok || !color.ok) return invalid("border-value");
  return success({
    width: width.value,
    style: input.style,
    color: color.value
  });
}
function canonicalizeTypography(input) {
  if (!isRecord$2(input) || !hasExactKeys(input, [
    "fontFamily",
    "fontSize",
    "fontWeight",
    "lineHeight",
    "letterSpacing"
  ])) {
    return invalid("typography-shape");
  }
  const fontFamily = canonicalizeBuiltIn("font-family", input.fontFamily);
  const fontSize = canonicalizeDimension(input.fontSize);
  const fontWeight = canonicalizeBuiltIn("font-weight", input.fontWeight);
  const lineHeight = typeof input.lineHeight === "number" ? finiteNumber(input.lineHeight) : canonicalizeDimension(input.lineHeight);
  const letterSpacing = canonicalizeDimension(input.letterSpacing);
  if (!fontFamily.ok || !fontSize.ok || !fontWeight.ok || !lineHeight.ok || !letterSpacing.ok) {
    return invalid("typography-value");
  }
  return success({
    fontFamily: fontFamily.value,
    fontSize: fontSize.value,
    fontWeight: fontWeight.value,
    lineHeight: lineHeight.value,
    letterSpacing: letterSpacing.value
  });
}
function canonicalizeBuiltIn(typeId, input) {
  let result;
  switch (typeId) {
    case "number":
      result = finiteNumber(input);
      break;
    case "string":
      result = typeof input === "string" ? success(input) : invalid("string-value");
      break;
    case "color":
      result = canonicalizeColor(input);
      break;
    case "dimension":
      result = canonicalizeDimension(input);
      break;
    case "duration": {
      if (!isRecord$2(input) || !hasExactKeys(input, ["value", "unit"]) || input.unit !== "ms") {
        result = invalid("duration-shape");
        break;
      }
      const value = finiteNumber(input.value);
      result = value.ok && value.value >= 0 ? success({ value: value.value, unit: "ms" }) : invalid("duration-range");
      break;
    }
    case "cubic-bezier": {
      if (!Array.isArray(input) || input.length !== 4) {
        result = invalid("cubic-bezier-shape");
        break;
      }
      const values = input.map((value) => finiteNumber(value));
      if (values.some((value) => !value.ok)) {
        result = invalid("cubic-bezier-finite");
        break;
      }
      const tuple = values.map(
        (value) => value.value
      );
      result = tuple[0] >= 0 && tuple[0] <= 1 && tuple[2] >= 0 && tuple[2] <= 1 ? success(tuple) : invalid("cubic-bezier-x-range");
      break;
    }
    case "font-family":
      result = Array.isArray(input) && input.length > 0 && input.every((value) => typeof value === "string" && value.length > 0) ? success([...input]) : invalid("font-family-non-empty");
      break;
    case "font-weight": {
      const value = finiteNumber(input);
      result = value.ok && Number.isInteger(value.value) && value.value >= 1 && value.value <= 1e3 ? success(value.value) : invalid("font-weight-range");
      break;
    }
    case "gradient":
      result = canonicalizeGradient(input);
      break;
    case "shadow": {
      if (!Array.isArray(input)) {
        result = invalid("shadow-array");
        break;
      }
      const layers = input.map((layer) => canonicalizeShadowLayer(layer));
      result = layers.every((layer) => layer.ok) ? success(
        layers.map(
          (layer) => layer.value
        )
      ) : invalid("shadow-layer");
      break;
    }
    case "strokeStyle":
      result = canonicalizeStrokeStyle(input);
      break;
    case "transition":
      result = canonicalizeTransition(input);
      break;
    case "border":
      result = canonicalizeBorder(input);
      break;
    case "typography":
      result = canonicalizeTypography(input);
      break;
    default:
      result = invalid("unknown-built-in-type");
  }
  return result;
}
function schemaAllowedKeys(type) {
  switch (type) {
    case "number":
      return ["enum", "maximum", "minimum", "type"];
    case "array":
      return ["enum", "items", "type"];
    case "object":
      return ["additionalProperties", "enum", "properties", "required", "type"];
    default:
      return ["enum", "type"];
  }
}
const SCHEMA_KEYWORDS = /* @__PURE__ */ new Set([
  "additionalProperties",
  "enum",
  "items",
  "maximum",
  "minimum",
  "properties",
  "required",
  "type"
]);
function validateSchemaNode(input, path, issues) {
  if (!isRecord$2(input) || typeof input.type !== "string") {
    issues.push({
      issue: "type-mismatch",
      instancePath: path,
      keyword: "type",
      receivedKind: describeValueKind(input)
    });
    return;
  }
  const supported = /* @__PURE__ */ new Set([
    "null",
    "boolean",
    "string",
    "number",
    "array",
    "object"
  ]);
  if (!supported.has(input.type)) {
    issues.push({
      issue: "type-mismatch",
      instancePath: `${path}.type`,
      keyword: "type",
      receivedKind: "string"
    });
    return;
  }
  const allowed = new Set(schemaAllowedKeys(input.type));
  for (const key of Object.keys(input)) {
    if (!allowed.has(key)) {
      issues.push({
        issue: SCHEMA_KEYWORDS.has(key) ? "keyword-not-allowed-for-type" : "unknown-keyword",
        instancePath: `${path}.${key}`,
        keyword: key,
        receivedKind: describeValueKind(input[key])
      });
    }
  }
  if (input.type === "number") {
    for (const key of ["minimum", "maximum"]) {
      if (key in input && (typeof input[key] !== "number" || !Number.isFinite(input[key]))) {
        issues.push({
          issue: "invalid-range",
          instancePath: `${path}.${key}`,
          keyword: key,
          receivedKind: describeValueKind(input[key])
        });
      }
    }
    if (typeof input.minimum === "number" && typeof input.maximum === "number" && input.minimum > input.maximum) {
      issues.push({
        issue: "invalid-range",
        instancePath: path,
        keyword: "minimum",
        receivedKind: "object"
      });
    }
  }
  if (input.type === "array") {
    if (!("items" in input)) {
      issues.push({
        issue: "missing-required-keyword",
        instancePath: path,
        keyword: "items",
        receivedKind: "object"
      });
    } else {
      validateSchemaNode(input.items, `${path}.items`, issues);
    }
  }
  if (input.type === "object") {
    if (input.additionalProperties !== false) {
      issues.push({
        issue: "missing-required-keyword",
        instancePath: `${path}.additionalProperties`,
        keyword: "additionalProperties",
        receivedKind: describeValueKind(input.additionalProperties)
      });
    }
    if (!isRecord$2(input.properties)) {
      issues.push({
        issue: "missing-required-keyword",
        instancePath: `${path}.properties`,
        keyword: "properties",
        receivedKind: describeValueKind(input.properties)
      });
    } else {
      const properties = input.properties;
      for (const key of Object.keys(properties).sort(compareUtf16)) {
        validateSchemaNode(properties[key], `${path}.properties.${key}`, issues);
      }
      if (input.required !== void 0) {
        if (!Array.isArray(input.required)) {
          issues.push({
            issue: "type-mismatch",
            instancePath: `${path}.required`,
            keyword: "required",
            receivedKind: describeValueKind(input.required)
          });
        } else {
          const seen = /* @__PURE__ */ new Set();
          input.required.forEach((key, index) => {
            if (typeof key !== "string" || !(key in properties)) {
              issues.push({
                issue: "required-property-unknown",
                instancePath: `${path}.required[${index}]`,
                keyword: "required",
                receivedKind: describeValueKind(key)
              });
            } else if (seen.has(key)) {
              issues.push({
                issue: "duplicate-required",
                instancePath: `${path}.required`,
                keyword: "required",
                receivedKind: "array"
              });
            }
            if (typeof key === "string") seen.add(key);
          });
        }
      }
    }
  }
  if (input.enum !== void 0) {
    if (!Array.isArray(input.enum) || input.enum.length === 0) {
      issues.push({
        issue: "enum-empty",
        instancePath: `${path}.enum`,
        keyword: "enum",
        receivedKind: describeValueKind(input.enum)
      });
    } else {
      const schemaWithoutEnum = { ...input };
      delete schemaWithoutEnum.enum;
      const seenMembers = /* @__PURE__ */ new Map();
      input.enum.forEach((member, memberIndex) => {
        const identity = bytesToHex(canonicalJsonBytes(member));
        const firstIndex = seenMembers.get(identity);
        if (firstIndex !== void 0) {
          issues.push({
            issue: "enum-duplicate",
            instancePath: `${path}.enum`,
            keyword: "enum",
            receivedKind: "array",
            firstIndex,
            duplicateIndex: memberIndex
          });
        } else {
          seenMembers.set(identity, memberIndex);
        }
        if (!schemaAccepts(
          schemaWithoutEnum,
          member
        )) {
          issues.push({
            issue: "enum-type-mismatch",
            instancePath: `${path}.enum[${memberIndex}]`,
            keyword: "enum",
            receivedKind: describeValueKind(member)
          });
        }
      });
    }
  }
}
function normalizeSchema(input) {
  var _a;
  const record = input;
  const output = { type: input.type };
  if (input.type === "number") {
    if (input.minimum !== void 0) {
      output.minimum = Object.is(input.minimum, -0) ? 0 : input.minimum;
    }
    if (input.maximum !== void 0) {
      output.maximum = Object.is(input.maximum, -0) ? 0 : input.maximum;
    }
  }
  if (input.type === "array") output.items = normalizeSchema(input.items);
  if (input.type === "object") {
    output.properties = Object.fromEntries(
      Object.keys(input.properties).sort(compareUtf16).map((key) => [key, normalizeSchema(input.properties[key])])
    );
    const required = (_a = input.required) == null ? void 0 : _a.slice().sort(compareUtf16);
    if (required && required.length > 0) output.required = required;
    output.additionalProperties = false;
  }
  if (record.enum !== void 0) {
    const members = record.enum.map(
      (member) => snapshotCanonicalJson(member)
    );
    members.sort(
      (left, right) => compareBytes(canonicalJsonBytes(left), canonicalJsonBytes(right))
    );
    output.enum = members;
  }
  return snapshotCanonicalJson(output);
}
function schemaAccepts(schema, input) {
  var _a;
  const canonical = (() => {
    try {
      return snapshotCanonicalJson(input);
    } catch {
      return void 0;
    }
  })();
  if (canonical === void 0) return false;
  if (schema.enum) {
    const candidate = canonicalJsonBytes(canonical);
    if (!schema.enum.some(
      (member) => compareBytes(canonicalJsonBytes(member), candidate) === 0
    )) {
      return false;
    }
  }
  switch (schema.type) {
    case "null":
      return canonical === null;
    case "boolean":
      return typeof canonical === "boolean";
    case "string":
      return typeof canonical === "string";
    case "number":
      return typeof canonical === "number" && (schema.minimum === void 0 || canonical >= schema.minimum) && (schema.maximum === void 0 || canonical <= schema.maximum);
    case "array":
      return Array.isArray(canonical) && canonical.every((value) => schemaAccepts(schema.items, value));
    case "object":
      if (!isRecord$2(canonical)) return false;
      if (Object.keys(canonical).some((key) => !(key in schema.properties))) {
        return false;
      }
      if ((_a = schema.required) == null ? void 0 : _a.some((key) => !(key in canonical))) return false;
      return Object.entries(canonical).every(
        ([key, value]) => schemaAccepts(schema.properties[key], value)
      );
  }
}
const SCHEMA_RESOURCE_LIMITS = {
  "schema-depth": 64,
  "schema-nodes": 2e4,
  "schema-properties": 1e4,
  "schema-enum-members": 1e4,
  "schema-bytes": 1048576
};
function inspectSchemaResources(input) {
  const stack = [{ value: input, path: "$", depth: 0 }];
  const seen = /* @__PURE__ */ new WeakSet();
  let nodes = 0;
  let properties = 0;
  let enumMembers = 0;
  let bytes = 0;
  const exceeded = (resource, actual, instancePath) => actual > SCHEMA_RESOURCE_LIMITS[resource] ? {
    resource,
    limit: SCHEMA_RESOURCE_LIMITS[resource],
    actual,
    truncated: true,
    instancePath
  } : null;
  while (stack.length > 0) {
    const current = stack.pop();
    const depthIssue = exceeded("schema-depth", current.depth, current.path);
    if (depthIssue) return depthIssue;
    nodes += 1;
    const nodeIssue = exceeded("schema-nodes", nodes, current.path);
    if (nodeIssue) return nodeIssue;
    const value = current.value;
    if (value === null || typeof value !== "object") {
      bytes += typeof value === "string" ? utf8ByteLength(value) + 2 : utf8ByteLength(String(value));
      const byteIssue2 = exceeded("schema-bytes", bytes, current.path);
      if (byteIssue2) return byteIssue2;
      continue;
    }
    if (seen.has(value)) continue;
    seen.add(value);
    let descriptors;
    let symbols;
    try {
      descriptors = Object.getOwnPropertyDescriptors(value);
      symbols = Object.getOwnPropertySymbols(value);
    } catch {
      return null;
    }
    if (symbols.length > 0 || Object.values(descriptors).some((descriptor) => !("value" in descriptor))) {
      return null;
    }
    const names = Object.keys(descriptors);
    bytes += names.reduce((total, name) => total + utf8ByteLength(name) + 3, 2);
    const byteIssue = exceeded("schema-bytes", bytes, current.path);
    if (byteIssue) return byteIssue;
    if (current.keyword === "properties") {
      properties += names.length;
      const propertyIssue = exceeded(
        "schema-properties",
        properties,
        current.path
      );
      if (propertyIssue) return propertyIssue;
    }
    if (current.keyword === "enum" && Array.isArray(value)) {
      enumMembers += value.length;
      const enumIssue = exceeded(
        "schema-enum-members",
        enumMembers,
        current.path
      );
      if (enumIssue) return enumIssue;
    }
    names.slice().reverse().forEach((name) => {
      stack.push({
        value: descriptors[name].value,
        path: Array.isArray(value) ? `${current.path}[${name}]` : `${current.path}.${name}`,
        depth: current.depth + 1,
        keyword: name
      });
    });
  }
  return null;
}
function createTypeRegistry(source, descriptors) {
  const diagnostics = [];
  const extensions = /* @__PURE__ */ Object.create(null);
  const seen = /* @__PURE__ */ new Map();
  descriptors.forEach((descriptor, descriptorIndex) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
    let fields;
    let inspectionIssue = "inspection-failed";
    try {
      if (!isRecord$2(descriptor)) {
        inspectionIssue = "descriptor-non-plain";
        throw new Error(inspectionIssue);
      }
      if (Object.getOwnPropertySymbols(descriptor).length > 0) {
        inspectionIssue = "descriptor-symbol-key";
        throw new Error(inspectionIssue);
      }
      fields = Object.getOwnPropertyDescriptors(descriptor);
      if (Object.values(fields).some((field) => !("value" in field))) {
        inspectionIssue = "descriptor-accessor";
        throw new Error(inspectionIssue);
      }
    } catch {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId: null,
            instancePath: "$",
            receivedKind: describeValueKind(descriptor),
            issue: inspectionIssue
          }
        })
      );
      return;
    }
    const typeId = (_a = fields.typeId) == null ? void 0 : _a.value;
    if (typeof typeId !== "string") {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_ID_INVALID", {
          source,
          location: themeLocation(),
          details: { descriptorIndex, typeId: "", rule: "extension-type-id" }
        })
      );
      return;
    }
    if (BUILT_IN_TYPE_ID_SET.has(typeId)) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_BUILTIN_CONFLICT", {
          source,
          location: themeLocation(),
          details: { descriptorIndex, typeId, builtInTypeId: typeId }
        })
      );
      return;
    }
    const match = /^([a-z][a-z0-9-]*)\.([a-z][a-z0-9-]*)@([1-9]\d*)$/.exec(
      typeId
    );
    if (!match) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_ID_INVALID", {
          source,
          location: themeLocation(),
          details: { descriptorIndex, typeId, rule: "namespace.name@version" }
        })
      );
      return;
    }
    const schemaVersion = (_b = fields.schemaVersion) == null ? void 0 : _b.value;
    const expectedSchemaVersion = Number(match[3]);
    if (!Number.isSafeInteger(expectedSchemaVersion)) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_ID_INVALID", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            rule: "namespace.name@positive-safe-integer-version"
          }
        })
      );
      return;
    }
    if (schemaVersion !== expectedSchemaVersion) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_VERSION_MISMATCH", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            schemaVersion: typeof schemaVersion === "number" && Number.isFinite(schemaVersion) ? schemaVersion : null,
            expectedSchemaVersion
          }
        })
      );
      return;
    }
    const firstIndex = seen.get(typeId);
    if (firstIndex !== void 0) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_DUPLICATE", {
          source,
          location: themeLocation(),
          details: { typeId, firstIndex, duplicateIndex: descriptorIndex }
        })
      );
      return;
    }
    seen.set(typeId, descriptorIndex);
    const resourceIssue = inspectSchemaResources((_c = fields.canonicalSchema) == null ? void 0 : _c.value);
    if (resourceIssue) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            instancePath: resourceIssue.instancePath,
            receivedKind: describeValueKind((_d = fields.canonicalSchema) == null ? void 0 : _d.value),
            issue: "resource-limit",
            resource: resourceIssue.resource,
            limit: resourceIssue.limit,
            actual: resourceIssue.actual,
            truncated: resourceIssue.truncated
          }
        })
      );
      return;
    }
    let schemaSnapshot;
    try {
      schemaSnapshot = snapshotCanonicalJson((_e = fields.canonicalSchema) == null ? void 0 : _e.value, {
        maxDepth: 64,
        maxNodes: 2e4
      });
    } catch (error) {
      const canonicalError = error instanceof CanonicalJsonError ? error : void 0;
      const baseDetails = {
        descriptorIndex,
        typeId,
        instancePath: (canonicalError == null ? void 0 : canonicalError.instancePath) ?? "$",
        receivedKind: describeValueKind((_f = fields.canonicalSchema) == null ? void 0 : _f.value)
      };
      const issue = (canonicalError == null ? void 0 : canonicalError.issue) ?? "inspection-failed";
      const details2 = issue === "non-finite-number" ? {
        ...baseDetails,
        issue,
        numberKind: (canonicalError == null ? void 0 : canonicalError.numberKind) ?? "nan"
      } : issue === "cycle" ? {
        ...baseDetails,
        issue,
        firstSeenPath: (canonicalError == null ? void 0 : canonicalError.firstSeenPath) ?? "$"
      } : issue === "resource-limit" ? {
        ...baseDetails,
        issue,
        resource: "schema-nodes",
        limit: SCHEMA_RESOURCE_LIMITS["schema-nodes"],
        actual: SCHEMA_RESOURCE_LIMITS["schema-nodes"] + 1,
        truncated: true
      } : {
        ...baseDetails,
        issue
      };
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID", {
          source,
          location: themeLocation(),
          details: details2
        })
      );
      return;
    }
    let exactSchemaBytes;
    try {
      exactSchemaBytes = canonicalJsonBytes(schemaSnapshot).byteLength;
    } catch (error) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            stage: error instanceof CanonicalJsonError ? "jcs" : "utf8",
            issue: error instanceof CanonicalJsonError ? "serializer-rejected" : "encoding-failed"
          }
        })
      );
      return;
    }
    if (exactSchemaBytes > SCHEMA_RESOURCE_LIMITS["schema-bytes"]) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_JCS_INVALID", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            instancePath: "$",
            receivedKind: describeValueKind((_g = fields.canonicalSchema) == null ? void 0 : _g.value),
            issue: "resource-limit",
            resource: "schema-bytes",
            limit: SCHEMA_RESOURCE_LIMITS["schema-bytes"],
            actual: exactSchemaBytes,
            truncated: true
          }
        })
      );
      return;
    }
    const schemaIssues = [];
    validateSchemaNode(schemaSnapshot, "$", schemaIssues);
    if (schemaIssues.length > 0) {
      for (const issue of schemaIssues) {
        diagnostics.push(
          createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_INVALID", {
            source,
            location: themeLocation(),
            details: {
              descriptorIndex,
              typeId,
              ...issue
            }
          })
        );
      }
      return;
    }
    let normalized;
    let computedHash;
    try {
      normalized = normalizeSchema(schemaSnapshot);
      computedHash = sha256Bytes(canonicalJsonBytes(normalized));
    } catch (error) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_CANONICALIZATION_FAILED", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            stage: error instanceof CanonicalJsonError ? "jcs" : "utf8",
            issue: error instanceof CanonicalJsonError ? "serializer-rejected" : "encoding-failed"
          }
        })
      );
      return;
    }
    const declaredHash = (_h = fields.canonicalSchemaHash) == null ? void 0 : _h.value;
    if (typeof declaredHash !== "string" || !/^sha256:[a-f0-9]{64}$/.test(declaredHash)) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID", {
          source,
          location: themeLocation(),
          details: {
            failure: "format",
            descriptorIndex,
            typeId,
            declaredHash: typeof declaredHash === "string" ? declaredHash : "",
            requiredFormat: "sha256:<64-lowercase-hex>"
          }
        })
      );
      return;
    }
    if (declaredHash !== computedHash) {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_HASH_INVALID", {
          source,
          location: themeLocation(),
          details: {
            failure: "mismatch",
            descriptorIndex,
            typeId,
            declaredHash,
            computedHash
          }
        })
      );
      return;
    }
    if (typeof ((_i = fields.validate) == null ? void 0 : _i.value) !== "function" || typeof ((_j = fields.canonicalize) == null ? void 0 : _j.value) !== "function") {
      diagnostics.push(
        createDiagnostic("TK_TYPE_REGISTRY_SCHEMA_INVALID", {
          source,
          location: themeLocation(),
          details: {
            descriptorIndex,
            typeId,
            instancePath: "$",
            keyword: null,
            issue: "missing-required-keyword",
            receivedKind: "object"
          }
        })
      );
      return;
    }
    extensions[typeId] = Object.freeze({
      descriptorIndex,
      typeId,
      schemaVersion,
      canonicalSchema: normalized,
      canonicalSchemaHash: computedHash,
      validate: fields.validate.value,
      canonicalize: fields.canonicalize.value
    });
  });
  if (diagnostics.length > 0) return failure(diagnostics);
  const identities = [
    ...BUILT_IN_TYPE_IDS.map((typeId) => ({
      typeId,
      schemaVersion: 1,
      canonicalSchemaHash: computeCanonicalHash({ typeId, version: 1 })
    })),
    ...Object.values(extensions).map((descriptor) => ({
      typeId: descriptor.typeId,
      schemaVersion: descriptor.schemaVersion,
      canonicalSchemaHash: descriptor.canonicalSchemaHash
    }))
  ].sort((left, right) => compareAscii(left.typeId, right.typeId));
  const registeredTypeIds = identities.map((identity) => identity.typeId);
  const registry = deepFreeze({
    registeredTypeIds,
    typeRegistryContentHash: computeCanonicalHash(identities),
    extensions
  });
  return ok(registry);
}
function createBuiltInTypeRegistry() {
  const result = createTypeRegistry(
    deepFreeze({
      file: "packages/tokens/src/kernel/index.ts"
    }),
    []
  );
  if (!result.ok) throw new Error("Kernel invariant: built-in registry failed");
  return result.value;
}
function safeActualValue(input) {
  try {
    return snapshotCanonicalJson(input);
  } catch {
    return null;
  }
}
function canonicalizeTypeValue(registry, typeId, input, context) {
  if (!registry.registeredTypeIds.includes(typeId)) {
    return failure([
      createDiagnostic("TK_TYPE_UNKNOWN", {
        source: context.source,
        themeId: context.themeId,
        location: tokenLocation(context.tokenPath),
        details: {
          receivedTypeId: typeId,
          registeredTypeIds: registry.registeredTypeIds
        }
      })
    ]);
  }
  if (BUILT_IN_TYPE_ID_SET.has(typeId)) {
    const result = canonicalizeBuiltIn(typeId, input);
    if (!result.ok) {
      return failure([
        createDiagnostic("TK_TYPE_VALUE_INVALID", {
          source: context.source,
          themeId: context.themeId,
          location: tokenLocation(context.tokenPath),
          details: {
            expectedTypeId: typeId,
            actualTypeId: null,
            actualValue: safeActualValue(input),
            validationRule: result.rule,
            instancePath: result.instancePath
          }
        })
      ]);
    }
    return ok(snapshotCanonicalJson(result.value));
  }
  const extension = registry.extensions[typeId];
  if (!extension) {
    return failure([
      createDiagnostic("TK_TYPE_UNKNOWN", {
        source: context.source,
        themeId: context.themeId,
        location: tokenLocation(context.tokenPath),
        details: {
          receivedTypeId: typeId,
          registeredTypeIds: registry.registeredTypeIds
        }
      })
    ]);
  }
  let issues;
  try {
    issues = extension.validate(input);
  } catch {
    issues = [{ keyword: "validator-threw" }];
  }
  if (issues.length > 0) {
    return failure([
      createDiagnostic("TK_TYPE_VALUE_INVALID", {
        source: context.source,
        themeId: context.themeId,
        location: tokenLocation(context.tokenPath),
        details: {
          expectedTypeId: typeId,
          actualTypeId: null,
          actualValue: safeActualValue(input),
          validationRule: "extension-validator"
        }
      })
    ]);
  }
  try {
    const first = snapshotCanonicalJson(extension.canonicalize(input));
    if (!schemaAccepts(extension.canonicalSchema, first)) {
      throw new Error("schema replay failed");
    }
    const replay = snapshotCanonicalJson(extension.canonicalize(input));
    const firstHash = computeCanonicalHash(first);
    const replayHash = computeCanonicalHash(replay);
    if (firstHash !== replayHash) {
      return failure([
        createDiagnostic("TK_TYPE_REGISTRY_NON_DETERMINISTIC", {
          source: context.source,
          themeId: context.themeId,
          location: themeLocation(),
          details: {
            descriptorIndex: extension.descriptorIndex,
            typeId,
            firstHash,
            replayHash
          }
        })
      ]);
    }
    return ok(first);
  } catch {
    return failure([
      createDiagnostic("TK_TYPE_VALUE_INVALID", {
        source: context.source,
        themeId: context.themeId,
        location: tokenLocation(context.tokenPath),
        details: {
          expectedTypeId: typeId,
          actualTypeId: null,
          actualValue: safeActualValue(input),
          validationRule: "extension-canonicalizer"
        }
      })
    ]);
  }
}
const AXIS_ORDER = deepFreeze([
  "mode",
  "density",
  "contrast",
  "motion",
  "radius"
]);
const AXIS_DOMAINS = deepFreeze({
  mode: ["light", "dark"],
  density: ["compact", "default", "comfortable"],
  contrast: ["normal", "high", "forced-colors"],
  motion: ["full", "reduced", "none"],
  radius: ["sharp", "default", "rounded"]
});
const SEGMENT_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const FORBIDDEN_TRANSFORM_FIELDS = [
  "component",
  "delete",
  "lifecycle",
  "public",
  "type",
  "visibility"
];
function isRecord$1(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return false;
  const prototype = Object.getPrototypeOf(input);
  return prototype === Object.prototype || prototype === null;
}
function exactKeys$1(input, required, optional = []) {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  return required.every((key) => Object.prototype.hasOwnProperty.call(input, key)) && Object.keys(input).every((key) => allowed.has(key));
}
function locatorIssue(input, entrypoint, parameter, issue, instancePath) {
  return failure([
    createDiagnostic("TK_SOURCE_LOCATOR_INVALID", {
      source: KERNEL_INPUT_DIAGNOSTIC_SOURCE,
      location: themeLocation(),
      details: {
        entrypoint,
        parameter,
        instancePath,
        issue,
        receivedKind: describeValueKind(
          input
        )
      }
    })
  ]);
}
function parseLogicalSourceLocator(input, entrypoint, parameter) {
  var _a, _b, _c, _d;
  let descriptors;
  try {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
      return locatorIssue(
        input,
        entrypoint,
        parameter,
        input === void 0 ? "missing" : "not-object",
        `$.${parameter}`
      );
    }
    const prototype = Object.getPrototypeOf(input);
    if (prototype !== Object.prototype && prototype !== null) {
      return locatorIssue(
        input,
        entrypoint,
        parameter,
        "non-plain-object",
        `$.${parameter}`
      );
    }
    if (Object.getOwnPropertySymbols(input).length > 0) {
      return locatorIssue(
        input,
        entrypoint,
        parameter,
        "symbol-key",
        `$.${parameter}`
      );
    }
    descriptors = Object.getOwnPropertyDescriptors(input);
  } catch {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "inspection-failed",
      `$.${parameter}`
    );
  }
  if (Object.values(descriptors).some((descriptor) => !("value" in descriptor))) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "accessor-property",
      `$.${parameter}`
    );
  }
  const keys = Object.keys(descriptors);
  if (keys.some((key) => !["file", "line", "column"].includes(key))) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "unknown-property",
      `$.${parameter}`
    );
  }
  const file = (_a = descriptors.file) == null ? void 0 : _a.value;
  if (typeof file !== "string") {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "file-not-string",
      `$.${parameter}.file`
    );
  }
  if (file.length === 0) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "file-empty",
      `$.${parameter}.file`
    );
  }
  if (/^(?:\/|[A-Za-z]:[\\/]|\\\\)/.test(file)) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "absolute-or-drive",
      `$.${parameter}.file`
    );
  }
  if (file.includes("\\")) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "backslash",
      `$.${parameter}.file`
    );
  }
  if (file.includes("\0")) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "nul",
      `$.${parameter}.file`
    );
  }
  const segments = file.split("/");
  if (segments.some(
    (segment) => segment === "" || segment === "." || segment === ".."
  )) {
    return locatorIssue(
      input,
      entrypoint,
      parameter,
      "dot-or-empty-segment",
      `$.${parameter}.file`
    );
  }
  for (const key of ["line", "column"]) {
    const value = (_b = descriptors[key]) == null ? void 0 : _b.value;
    if (value !== void 0 && (!Number.isSafeInteger(value) || typeof value !== "number" || value < 1)) {
      return locatorIssue(
        input,
        entrypoint,
        parameter,
        `${key}-invalid`,
        `$.${parameter}.${key}`
      );
    }
  }
  return ok(
    deepFreeze({
      file,
      ...((_c = descriptors.line) == null ? void 0 : _c.value) !== void 0 ? { line: descriptors.line.value } : {},
      ...((_d = descriptors.column) == null ? void 0 : _d.value) !== void 0 ? { column: descriptors.column.value } : {}
    })
  );
}
function isLocalTokenPath(input) {
  if (input.length === 0 || input.startsWith("$")) return false;
  const segments = input.split(".");
  return segments.every(
    (segment) => segment.length > 0 && SEGMENT_PATTERN.test(segment)
  );
}
function isComponentNamespace(input) {
  return SEGMENT_PATTERN.test(input) && !input.startsWith("$");
}
function parseCanonicalTokenPath(input) {
  if (typeof input !== "string") return null;
  if (input.startsWith("foundation.")) {
    const local = input.slice("foundation.".length);
    return isLocalTokenPath(local) ? input : null;
  }
  if (input.startsWith("semantic.")) {
    const local = input.slice("semantic.".length);
    return isLocalTokenPath(local) ? input : null;
  }
  if (input.startsWith("components.")) {
    const remainder = input.slice("components.".length);
    const separator = remainder.indexOf(".");
    if (separator <= 0) return null;
    const namespace = remainder.slice(0, separator);
    const local = remainder.slice(separator + 1);
    return isComponentNamespace(namespace) && isLocalTokenPath(local) ? input : null;
  }
  return null;
}
function toCanonicalTokenPath(layer, localPath, component) {
  return layer === "components" ? `components.${component}.${localPath}` : `${layer}.${localPath}`;
}
function schemaDiagnostic(source, themeId, path, details2) {
  return createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
    source,
    themeId,
    location: themeLocation(),
    details: { instancePath: path, ...details2 }
  });
}
function validateAxes(source, themeId, input) {
  const diagnostics = [];
  const output = /* @__PURE__ */ Object.create(null);
  const record = isRecord$1(input) ? input : /* @__PURE__ */ Object.create(null);
  for (const axis of AXIS_ORDER) {
    const declaration = record[axis];
    const domain = AXIS_DOMAINS[axis];
    if (!isRecord$1(declaration)) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_DECLARATION_INVALID", {
          source,
          themeId,
          location: axisLocation(axis),
          details: {
            issue: "declaration-missing",
            axis,
            platformDomain: domain
          }
        })
      );
      continue;
    }
    if (!exactKeys$1(declaration, ["supported"], ["default"])) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_DECLARATION_INVALID", {
          source,
          themeId,
          location: axisLocation(axis),
          details: {
            issue: "declaration-shape",
            axis,
            platformDomain: domain
          }
        })
      );
      continue;
    }
    if (!Array.isArray(declaration.supported)) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_DECLARATION_INVALID", {
          source,
          themeId,
          location: axisLocation(axis),
          details: {
            issue: "supported-missing",
            axis,
            platformDomain: domain
          }
        })
      );
      continue;
    }
    if (declaration.supported.length === 0) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_DECLARATION_INVALID", {
          source,
          themeId,
          location: axisLocation(axis),
          details: {
            issue: "supported-empty",
            axis,
            platformDomain: domain
          }
        })
      );
      continue;
    }
    const seen = /* @__PURE__ */ new Map();
    declaration.supported.forEach((value, valueIndex) => {
      if (typeof value !== "string" || !domain.includes(value)) {
        diagnostics.push(
          createDiagnostic("TK_AXIS_DECLARATION_INVALID", {
            source,
            themeId,
            location: axisLocation(axis),
            details: {
              issue: "supported-value-unsupported",
              axis,
              receivedValue: typeof value === "string" ? value : "",
              valueIndex,
              platformDomain: domain
            }
          })
        );
      } else if (seen.has(value)) {
        diagnostics.push(
          createDiagnostic("TK_AXIS_DECLARATION_INVALID", {
            source,
            themeId,
            location: axisLocation(axis),
            details: {
              issue: "supported-duplicate",
              axis,
              receivedValue: value,
              firstIndex: seen.get(value),
              duplicateIndex: valueIndex,
              platformDomain: domain
            }
          })
        );
      } else {
        seen.set(value, valueIndex);
      }
    });
    if (diagnostics.some((diagnostic) => diagnostic.location.path === axis)) {
      continue;
    }
    const canonicalSupported = domain.filter((value) => seen.has(value));
    if (!Object.prototype.hasOwnProperty.call(declaration, "default")) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_DEFAULT_REQUIRED", {
          source,
          themeId,
          location: axisLocation(axis),
          details: {
            axis,
            platformDomain: domain,
            themeSupportedValues: canonicalSupported
          }
        })
      );
      continue;
    }
    if (typeof declaration.default !== "string" || !canonicalSupported.includes(declaration.default)) {
      diagnostics.push(
        createDiagnostic("TK_AXIS_DEFAULT_INVALID", {
          source,
          themeId,
          location: axisLocation(axis),
          details: {
            axis,
            receivedValue: typeof declaration.default === "string" ? declaration.default : "",
            platformDomain: domain,
            themeSupportedValues: canonicalSupported
          }
        })
      );
      continue;
    }
    output[axis] = {
      supported: canonicalSupported,
      default: declaration.default
    };
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  return ok(snapshotCanonicalJson(output));
}
function branchKind(input) {
  if (!isRecord$1(input)) return null;
  if (input.kind === "literal") return "literal";
  if ("$ref" in input) return "alias";
  if ("$expr" in input) return "expression";
  return null;
}
function validateTokenValueShape(registry, input, path, tokenPath, source, themeId, diagnostics, depth = 0) {
  if (depth > 64) {
    diagnostics.push(
      schemaDiagnostic(source, themeId, path, {
        valueKind: "object",
        issue: "expression-depth-limit"
      })
    );
    return void 0;
  }
  const kind = branchKind(input);
  if (!kind || !isRecord$1(input)) {
    diagnostics.push(
      schemaDiagnostic(source, themeId, path, {
        valueKind: describeValueKind(input),
        issue: "token-value-branch"
      })
    );
    return void 0;
  }
  if (kind === "literal") {
    if (!exactKeys$1(input, ["kind", "value"]) || input.kind !== "literal") {
      diagnostics.push(
        schemaDiagnostic(source, themeId, path, {
          valueKind: "object",
          issue: "literal-envelope"
        })
      );
      return void 0;
    }
    return { kind: "literal", value: input.value };
  }
  if (kind === "alias") {
    if (!exactKeys$1(input, ["$ref", "expect"], ["targetType", "field"]) || parseCanonicalTokenPath(input.$ref) === null || typeof input.expect !== "string" || ("targetType" in input || "field" in input) && (typeof input.targetType !== "string" || typeof input.field !== "string")) {
      diagnostics.push(
        schemaDiagnostic(source, themeId, path, {
          valueKind: "object",
          issue: "alias-envelope"
        })
      );
      return void 0;
    }
    return {
      $ref: input.$ref,
      expect: input.expect,
      ...typeof input.targetType === "string" ? { targetType: input.targetType, field: input.field } : {}
    };
  }
  if (!exactKeys$1(input, ["$expr", "resultType", "args"]) || typeof input.$expr !== "string" || typeof input.resultType !== "string" || !Array.isArray(input.args)) {
    diagnostics.push(
      schemaDiagnostic(source, themeId, path, {
        valueKind: "object",
        issue: "expression-envelope"
      })
    );
    return void 0;
  }
  const args = [];
  for (let index = 0; index < input.args.length; index += 1) {
    const operand = input.args[index];
    const operandPath = `${path}.args[${index}]`;
    if (!isRecord$1(operand) || typeof operand.kind !== "string") {
      diagnostics.push(
        schemaDiagnostic(source, themeId, operandPath, {
          valueKind: describeValueKind(operand),
          issue: "expression-operand-envelope"
        })
      );
      continue;
    }
    if (operand.kind === "literal") {
      if (!exactKeys$1(operand, ["kind", "type", "value"]) || typeof operand.type !== "string") {
        diagnostics.push(
          schemaDiagnostic(source, themeId, operandPath, {
            valueKind: "object",
            issue: "expression-literal-envelope"
          })
        );
        continue;
      }
      const canonical = canonicalizeTypeValue(
        registry,
        operand.type,
        operand.value,
        {
          source,
          tokenPath,
          themeId
        }
      );
      if (!canonical.ok) {
        diagnostics.push(...canonical.diagnostics);
        continue;
      }
      args.push({
        kind: "literal",
        type: operand.type,
        value: canonical.value
      });
      continue;
    }
    if (operand.kind === "ref") {
      if (!exactKeys$1(operand, ["kind", "ref"])) {
        diagnostics.push(
          schemaDiagnostic(source, themeId, operandPath, {
            valueKind: "object",
            issue: "expression-ref-envelope"
          })
        );
        continue;
      }
      const ref = validateTokenValueShape(
        registry,
        operand.ref,
        `${operandPath}.ref`,
        tokenPath,
        source,
        themeId,
        diagnostics,
        depth + 1
      );
      if (!ref || branchKind(ref) !== "alias") continue;
      args.push({ kind: "ref", ref });
      continue;
    }
    if (operand.kind === "expr") {
      if (!exactKeys$1(operand, ["kind", "expr"])) {
        diagnostics.push(
          schemaDiagnostic(source, themeId, operandPath, {
            valueKind: "object",
            issue: "expression-nested-envelope"
          })
        );
        continue;
      }
      const expr = validateTokenValueShape(
        registry,
        operand.expr,
        `${operandPath}.expr`,
        tokenPath,
        source,
        themeId,
        diagnostics,
        depth + 1
      );
      if (!expr || branchKind(expr) !== "expression") continue;
      args.push({ kind: "expr", expr });
      continue;
    }
    diagnostics.push(
      schemaDiagnostic(source, themeId, operandPath, {
        valueKind: "object",
        issue: "expression-operand-kind"
      })
    );
  }
  if (args.length !== input.args.length) return void 0;
  return {
    $expr: input.$expr,
    resultType: input.resultType,
    args
  };
}
function normalizeTokenRecord(registry, input, layer, source, themeId, diagnostics, entrypoint, component) {
  const output = /* @__PURE__ */ Object.create(null);
  if (!isRecord$1(input) || Object.keys(input).length === 0) {
    diagnostics.push(
      schemaDiagnostic(source, themeId, `$.${layer}`, {
        valueKind: describeValueKind(input),
        issue: "non-empty-token-record-required"
      })
    );
    return output;
  }
  for (const localPath of Object.keys(input).sort(compareAscii)) {
    const canonicalPath = toCanonicalTokenPath(layer, localPath, component);
    const firstSegment = localPath.split(".")[0];
    if (!isLocalTokenPath(localPath) || ["foundation", "semantic", "components"].includes(firstSegment) || layer === "components" && firstSegment === component) {
      diagnostics.push(
        schemaDiagnostic(source, themeId, `$.${layer}.${localPath}`, {
          valueKind: "string",
          issue: layer === "components" && firstSegment === component ? "component-namespace-repeated" : "token-path-invalid"
        })
      );
      continue;
    }
    const definition = input[localPath];
    if (!isRecord$1(definition) || !exactKeys$1(definition, ["type", "value"], ["source"]) || typeof definition.type !== "string") {
      diagnostics.push(
        schemaDiagnostic(source, themeId, `$.${layer}.${localPath}`, {
          valueKind: describeValueKind(definition),
          issue: "token-definition-invalid"
        })
      );
      continue;
    }
    const tokenSource = definition.source ? parseLogicalSourceLocator(definition.source, entrypoint, "source") : ok(source);
    if (!tokenSource.ok) {
      diagnostics.push(...tokenSource.diagnostics);
      continue;
    }
    const value = validateTokenValueShape(
      registry,
      definition.value,
      `$.${layer}.${localPath}.value`,
      canonicalPath,
      tokenSource.value,
      themeId,
      diagnostics
    );
    if (!value) continue;
    if (value.kind === "literal") {
      const canonical = canonicalizeTypeValue(
        registry,
        definition.type,
        value.value,
        { source: tokenSource.value, tokenPath: canonicalPath, themeId }
      );
      if (!canonical.ok) {
        diagnostics.push(...canonical.diagnostics);
        continue;
      }
      output[localPath] = {
        type: definition.type,
        value: { kind: "literal", value: canonical.value },
        source: tokenSource.value
      };
    } else {
      output[localPath] = {
        type: definition.type,
        value,
        source: tokenSource.value
      };
    }
  }
  return output;
}
function normalizeTransforms(registry, input, source, themeId, diagnostics, entrypoint) {
  const root = isRecord$1(input) ? input : /* @__PURE__ */ Object.create(null);
  const output = /* @__PURE__ */ Object.create(null);
  if (!isRecord$1(input)) {
    diagnostics.push(
      schemaDiagnostic(source, themeId, "$.transforms", {
        valueKind: describeValueKind(input),
        issue: "transforms-object-required"
      })
    );
  } else if (Object.keys(input).some(
    (axis) => !AXIS_ORDER.includes(axis)
  )) {
    diagnostics.push(
      schemaDiagnostic(source, themeId, "$.transforms", {
        valueKind: "object",
        issue: "unknown-transform-axis"
      })
    );
  }
  for (const axis of AXIS_ORDER) {
    const axisInput = isRecord$1(root[axis]) ? root[axis] : /* @__PURE__ */ Object.create(null);
    const axisOutput = /* @__PURE__ */ Object.create(null);
    if (!Object.prototype.hasOwnProperty.call(root, axis) || !isRecord$1(root[axis])) {
      diagnostics.push(
        schemaDiagnostic(source, themeId, `$.transforms.${axis}`, {
          valueKind: describeValueKind(root[axis]),
          issue: "transform-axis-object-required"
        })
      );
    }
    if (Object.keys(axisInput).some(
      (value) => !AXIS_DOMAINS[axis].includes(value)
    )) {
      diagnostics.push(
        schemaDiagnostic(source, themeId, `$.transforms.${axis}`, {
          valueKind: "object",
          issue: "unknown-transform-axis-value"
        })
      );
    }
    for (const value of AXIS_DOMAINS[axis]) {
      const writes = axisInput[value];
      if (writes === void 0) continue;
      if (!Array.isArray(writes)) {
        diagnostics.push(
          schemaDiagnostic(source, themeId, `$.transforms.${axis}.${value}`, {
            valueKind: describeValueKind(writes),
            issue: "transform-array-required"
          })
        );
        continue;
      }
      const normalizedWrites = [];
      writes.forEach((write, order) => {
        const allowedOptionalFields = ["source", ...FORBIDDEN_TRANSFORM_FIELDS];
        if (!isRecord$1(write) || !exactKeys$1(
          write,
          ["path", "expectType", "value"],
          allowedOptionalFields
        ) || parseCanonicalTokenPath(write.path) === null || typeof write.expectType !== "string") {
          diagnostics.push(
            schemaDiagnostic(
              source,
              themeId,
              `$.transforms.${axis}.${value}[${order}]`,
              {
                valueKind: describeValueKind(write),
                issue: "transform-invalid"
              }
            )
          );
          return;
        }
        const writeSource = write.source ? parseLogicalSourceLocator(write.source, entrypoint, "source") : ok(source);
        if (!writeSource.ok) {
          diagnostics.push(...writeSource.diagnostics);
          return;
        }
        const normalizedValue = validateTokenValueShape(
          registry,
          write.value,
          `$.transforms.${axis}.${value}[${order}].value`,
          write.path,
          writeSource.value,
          themeId,
          diagnostics
        );
        if (!normalizedValue) return;
        normalizedWrites.push({
          path: write.path,
          expectType: write.expectType,
          value: normalizedValue,
          source: writeSource.value,
          ...Object.fromEntries(
            FORBIDDEN_TRANSFORM_FIELDS.filter((field) => field in write).map(
              (field) => [field, write[field]]
            )
          )
        });
      });
      axisOutput[value] = normalizedWrites;
    }
    output[axis] = axisOutput;
  }
  return output;
}
function validateThemeSourceObject(registry, source, input, entrypoint = "validateThemeSource") {
  const parsedSource = parseLogicalSourceLocator(
    source,
    entrypoint,
    "sourceLocation"
  );
  if (!parsedSource.ok) return parsedSource;
  let owned;
  try {
    owned = snapshotCanonicalJson(input);
  } catch (error) {
    const canonicalError = error instanceof CanonicalJsonError ? error : void 0;
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: parsedSource.value,
        location: themeLocation(),
        details: {
          valueKind: describeValueKind(input),
          instancePath: (canonicalError == null ? void 0 : canonicalError.instancePath) ?? "$",
          issue: (canonicalError == null ? void 0 : canonicalError.issue) ?? "inspection-failed"
        }
      })
    ]);
  }
  if (!isRecord$1(owned)) {
    return failure([
      schemaDiagnostic(parsedSource.value, void 0, "$", {
        valueKind: describeValueKind(owned),
        issue: "theme-object-required"
      })
    ]);
  }
  const meta = isRecord$1(owned.meta) ? owned.meta : /* @__PURE__ */ Object.create(null);
  const themeId = typeof meta.themeId === "string" ? meta.themeId : void 0;
  const legacyFields = [
    "defaults" in owned ? "defaults" : null,
    "modes" in owned ? "modes" : null,
    "publicSurface" in owned ? "publicSurface" : null
  ].filter((value) => value !== null);
  if (legacyFields.length > 0) {
    return failure([
      createDiagnostic("TK_SCHEMA_LEGACY_SHAPE_UNSUPPORTED", {
        source: parsedSource.value,
        themeId,
        location: themeLocation(),
        details: {
          matchedFields: legacyFields,
          supportedVersions: [4]
        }
      })
    ]);
  }
  if (!Object.prototype.hasOwnProperty.call(meta, "schemaVersion")) {
    return failure([
      createDiagnostic("TK_SCHEMA_VERSION_REQUIRED", {
        source: parsedSource.value,
        themeId,
        location: themeLocation(),
        details: { receivedVersion: null, supportedVersions: [4] }
      })
    ]);
  }
  if (meta.schemaVersion !== 4) {
    return failure([
      createDiagnostic("TK_SCHEMA_VERSION_UNSUPPORTED", {
        source: parsedSource.value,
        themeId,
        location: themeLocation(),
        details: {
          receivedVersion: typeof meta.schemaVersion === "number" || typeof meta.schemaVersion === "string" ? meta.schemaVersion : -1,
          supportedVersions: [4]
        }
      })
    ]);
  }
  if (!Object.prototype.hasOwnProperty.call(meta, "contractVersion")) {
    return failure([
      createDiagnostic("TK_CONTRACT_VERSION_REQUIRED", {
        source: parsedSource.value,
        themeId,
        location: themeLocation(),
        details: {
          receivedVersion: null,
          supportedVersions: ["4.0.0"]
        }
      })
    ]);
  }
  if (meta.contractVersion !== "4.0.0") {
    return failure([
      createDiagnostic("TK_CONTRACT_VERSION_UNSUPPORTED", {
        source: parsedSource.value,
        themeId,
        location: themeLocation(),
        details: {
          receivedVersion: typeof meta.contractVersion === "string" || typeof meta.contractVersion === "number" ? meta.contractVersion : "",
          supportedVersions: ["4.0.0"]
        }
      })
    ]);
  }
  const schemaDiagnostics = [];
  if (!themeId || themeId.length === 0) {
    schemaDiagnostics.push(
      createDiagnostic("TK_SCHEMA_THEME_ID_REQUIRED", {
        source: parsedSource.value,
        location: themeLocation(),
        details: {
          field: "themeId",
          received: themeId ?? null,
          rule: "non-empty-string"
        }
      })
    );
  }
  if (typeof meta.name !== "string" || meta.name.length === 0) {
    schemaDiagnostics.push(
      createDiagnostic("TK_SCHEMA_NAME_INVALID", {
        source: parsedSource.value,
        themeId,
        location: themeLocation(),
        details: {
          field: "name",
          received: typeof meta.name === "string" ? meta.name : null,
          rule: "non-empty-string"
        }
      })
    );
  }
  if (schemaDiagnostics.length > 0) return failure(schemaDiagnostics);
  if (!exactKeys$1(
    owned,
    ["meta", "axes", "foundation", "semantic", "components", "transforms"],
    ["conflictPolicy"]
  ) || !exactKeys$1(meta, ["themeId", "name", "schemaVersion", "contractVersion"])) {
    return failure([
      schemaDiagnostic(parsedSource.value, themeId, "$", {
        valueKind: "object",
        issue: "theme-envelope"
      })
    ]);
  }
  if (isRecord$1(owned.axes) && Object.keys(owned.axes).some(
    (axis) => !AXIS_ORDER.includes(axis)
  )) {
    return failure([
      schemaDiagnostic(parsedSource.value, themeId, "$.axes", {
        valueKind: "object",
        issue: "unknown-axis"
      })
    ]);
  }
  const axes = validateAxes(parsedSource.value, themeId, owned.axes);
  if (!axes.ok) return axes;
  const diagnostics = [];
  const foundation = normalizeTokenRecord(
    registry,
    owned.foundation,
    "foundation",
    parsedSource.value,
    themeId,
    diagnostics,
    entrypoint
  );
  const semantic = normalizeTokenRecord(
    registry,
    owned.semantic,
    "semantic",
    parsedSource.value,
    themeId,
    diagnostics,
    entrypoint
  );
  const components = /* @__PURE__ */ Object.create(null);
  if (!isRecord$1(owned.components) || Object.keys(owned.components).length === 0) {
    diagnostics.push(
      schemaDiagnostic(parsedSource.value, themeId, "$.components", {
        valueKind: describeValueKind(owned.components),
        issue: "non-empty-components-required"
      })
    );
  } else {
    for (const namespace of Object.keys(owned.components).sort(compareAscii)) {
      if (!isComponentNamespace(namespace)) {
        diagnostics.push(
          schemaDiagnostic(
            parsedSource.value,
            themeId,
            `$.components.${namespace}`,
            { valueKind: "string", issue: "component-namespace-invalid" }
          )
        );
        continue;
      }
      components[namespace] = normalizeTokenRecord(
        registry,
        owned.components[namespace],
        "components",
        parsedSource.value,
        themeId,
        diagnostics,
        entrypoint,
        namespace
      );
    }
  }
  const transforms = normalizeTransforms(
    registry,
    owned.transforms,
    parsedSource.value,
    themeId,
    diagnostics,
    entrypoint
  );
  const conflictPolicy = /* @__PURE__ */ Object.create(null);
  if (owned.conflictPolicy !== void 0) {
    if (!isRecord$1(owned.conflictPolicy)) {
      diagnostics.push(
        schemaDiagnostic(parsedSource.value, themeId, "$.conflictPolicy", {
          valueKind: describeValueKind(owned.conflictPolicy),
          issue: "conflict-policy-object-required"
        })
      );
    } else {
      for (const path of Object.keys(owned.conflictPolicy).sort(compareAscii)) {
        const policy = owned.conflictPolicy[path];
        const writers = isRecord$1(policy) && Array.isArray(policy.writers) ? policy.writers : [];
        const canonicalWriters = AXIS_ORDER.filter(
          (axis) => writers.includes(axis)
        );
        if (parseCanonicalTokenPath(path) === null || !isRecord$1(policy) || !exactKeys$1(policy, ["writers", "resolution", "rationale"]) || writers.length < 2 || writers.some(
          (writer) => typeof writer !== "string" || !AXIS_ORDER.includes(writer)
        ) || new Set(writers).size !== writers.length || canonicalWriters.some((writer, index) => writer !== writers[index]) || policy.resolution !== "fixed-axis-order" || typeof policy.rationale !== "string" || policy.rationale.length === 0) {
          diagnostics.push(
            schemaDiagnostic(
              parsedSource.value,
              themeId,
              `$.conflictPolicy.${path}`,
              {
                valueKind: describeValueKind(policy),
                issue: "conflict-policy-invalid"
              }
            )
          );
          continue;
        }
        conflictPolicy[path] = policy;
      }
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  const normalized = {
    meta: {
      themeId,
      name: meta.name,
      schemaVersion: 4,
      contractVersion: "4.0.0",
      source: parsedSource.value
    },
    axes: axes.value,
    foundation,
    semantic,
    components,
    transforms,
    ...Object.keys(conflictPolicy).length > 0 ? { conflictPolicy } : {}
  };
  return ok(
    snapshotCanonicalJson(normalized)
  );
}
function defineThemeObject(registry, source, input, entrypoint = "defineTheme") {
  return validateThemeSourceObject(registry, source, input, entrypoint);
}
function validateTokenLiteralWithRegistry(registry, input) {
  let owned;
  try {
    owned = snapshotCanonicalJson(input);
    if (!owned || typeof owned !== "object" || Array.isArray(owned) || Object.keys(owned).length !== 3 || !["typeId", "value", "source"].every(
      (key) => Object.prototype.hasOwnProperty.call(owned, key)
    ) || typeof owned.typeId !== "string") {
      throw new CanonicalJsonError("inspection-failed", "$");
    }
  } catch (error) {
    const canonical = error instanceof CanonicalJsonError ? error : void 0;
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: KERNEL_INPUT_DIAGNOSTIC_SOURCE,
        location: themeLocation(),
        details: {
          valueKind: describeValueKind(input),
          instancePath: (canonical == null ? void 0 : canonical.instancePath) ?? "$",
          issue: (canonical == null ? void 0 : canonical.issue) ?? "inspection-failed"
        }
      })
    ]);
  }
  const source = parseLogicalSourceLocator(
    owned.source,
    "validateThemeSource",
    "source"
  );
  if (!source.ok) return source;
  const value = canonicalizeTypeValue(registry, owned.typeId, owned.value, {
    source: source.value,
    tokenPath: "semantic.literal"
  });
  if (!value.ok) return value;
  return ok({ typeId: owned.typeId, value: value.value });
}
const THEME_SURFACE_ROLES = [
  "canvas",
  "panel",
  "card",
  "field",
  "header",
  "overlay",
  "blocking",
  "selected",
  "brand"
];
const THEME_SURFACE_FACETS = [
  "fill",
  "edge",
  "depth",
  "inner",
  "highlight",
  "on-text",
  "on-text-secondary"
];
function isRecord(input) {
  return Boolean(input) && typeof input === "object" && !Array.isArray(input);
}
function isStrictSemVer(input) {
  return typeof input === "string" && /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(input);
}
function nonEmpty(input) {
  return typeof input === "string" && input.trim().length > 0;
}
function exactKeys(input, required, optional = []) {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  return required.every((key) => Object.prototype.hasOwnProperty.call(input, key)) && Object.keys(input).every((key) => allowed.has(key));
}
function repoRelativeEvidence(input) {
  return input.length > 0 && !/^(?:\/|[A-Za-z]:[\\/]|\\\\)/.test(input) && !input.includes("\\") && !input.includes("\0") && input.split("/").every((segment) => segment !== "" && segment !== "." && segment !== "..");
}
function contractDiagnostic(source, code, path, details2) {
  const locationPath = parseCanonicalTokenPath(path) ?? "semantic.contract";
  return code === "TK_CONTRACT_LIFECYCLE_INVALID" ? createDiagnostic("TK_CONTRACT_LIFECYCLE_INVALID", {
    source,
    location: tokenLocation(locationPath),
    details: details2
  }) : createDiagnostic("TK_CONTRACT_REPLACEMENT_INVALID", {
    source,
    location: tokenLocation(locationPath),
    details: details2
  });
}
function isValidPublicAdmissionRationale(path, rationale) {
  if (!isRecord(rationale) || !Array.isArray(rationale.evidence) || rationale.evidence.length === 0) {
    return false;
  }
  if (!rationale.evidence.every(
    (evidence) => nonEmpty(evidence) && repoRelativeEvidence(evidence)
  )) {
    return false;
  }
  if (path.startsWith("foundation.")) {
    return exactKeys(rationale, [
      "kind",
      "crossThemeAuthoringUseCase",
      "evidence"
    ]) && rationale.kind === "foundation-authoring" && nonEmpty(rationale.crossThemeAuthoringUseCase);
  }
  if (path.startsWith("components.")) {
    return exactKeys(rationale, [
      "kind",
      "crossPackageUseCase",
      "semanticGap",
      "evidence"
    ]) && rationale.kind === "component-external-api" && nonEmpty(rationale.crossPackageUseCase) && nonEmpty(rationale.semanticGap);
  }
  return exactKeys(rationale, ["kind", "consumerUseCase", "evidence"]) && (rationale.kind === "cross-component" || rationale.kind === "external-api") && nonEmpty(rationale.consumerUseCase);
}
function isValidPublicMigration(input) {
  if (!isRecord(input)) return false;
  if (input.kind === "replacement") {
    return exactKeys(input, ["kind", "path"]) && parseCanonicalTokenPath(input.path) !== null;
  }
  return input.kind === "none" && exactKeys(input, ["kind", "reason"]) && isRecord(input.reason) && exactKeys(input.reason, ["code", "detail"]) && ["removed-concept", "merged-concept", "unsafe-api"].includes(
    String(input.reason.code)
  ) && nonEmpty(input.reason.detail);
}
function validateThemeContractObject(registry, source, input, entrypoint = "validateThemeContract") {
  const parsedSource = parseLogicalSourceLocator(
    source,
    entrypoint,
    "contractLocation"
  );
  if (!parsedSource.ok) return parsedSource;
  let owned;
  try {
    owned = snapshotCanonicalJson(input);
  } catch {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: parsedSource.value,
        location: themeLocation(),
        details: {
          valueKind: "object",
          instancePath: "$.contract"
        }
      })
    ]);
  }
  if (!isRecord(owned)) {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: parsedSource.value,
        location: themeLocation(),
        details: { valueKind: typeof owned, instancePath: "$.contract" }
      })
    ]);
  }
  if (!Object.prototype.hasOwnProperty.call(owned, "contractVersion")) {
    return failure([
      createDiagnostic("TK_CONTRACT_VERSION_REQUIRED", {
        source: parsedSource.value,
        location: themeLocation(),
        details: {
          receivedVersion: null,
          supportedVersions: ["4.0.0"]
        }
      })
    ]);
  }
  if (owned.contractVersion !== "4.0.0") {
    return failure([
      createDiagnostic("TK_CONTRACT_VERSION_UNSUPPORTED", {
        source: parsedSource.value,
        location: themeLocation(),
        details: {
          receivedVersion: typeof owned.contractVersion === "string" || typeof owned.contractVersion === "number" ? owned.contractVersion : "",
          supportedVersions: ["4.0.0"]
        }
      })
    ]);
  }
  if (!exactKeys(owned, ["contractVersion", "entries"])) {
    return failure([
      createDiagnostic("TK_SCHEMA_JSON_VALUE_INVALID", {
        source: parsedSource.value,
        location: themeLocation(),
        details: {
          valueKind: "object",
          instancePath: "$.contract",
          issue: "contract-envelope"
        }
      })
    ]);
  }
  if (!isRecord(owned.entries) || Object.keys(owned.entries).length === 0) {
    return failure([
      createDiagnostic("TK_CONTRACT_ENTRY_MISSING", {
        source: parsedSource.value,
        location: tokenLocation("semantic.contract"),
        details: { path: "semantic.contract" }
      })
    ]);
  }
  const diagnostics = [];
  const entries = /* @__PURE__ */ Object.create(null);
  for (const rawPath of Object.keys(owned.entries).sort(compareAscii)) {
    const path = parseCanonicalTokenPath(rawPath);
    const entry = owned.entries[rawPath];
    if (!path || !isRecord(entry)) {
      diagnostics.push(
        contractDiagnostic(
          parsedSource.value,
          "TK_CONTRACT_LIFECYCLE_INVALID",
          rawPath,
          {
            path: parseCanonicalTokenPath(rawPath) ?? "semantic.contract",
            from: "invalid",
            to: "invalid",
            rule: "canonical-entry"
          }
        )
      );
      continue;
    }
    const baseKeys = [
      "typeId",
      "description",
      "owner",
      "rationale",
      "lifecycle"
    ];
    const lifecycleShapeValid = entry.lifecycle === "stable" && exactKeys(entry, baseKeys, ["source"]) || entry.lifecycle === "experimental" && exactKeys(entry, [...baseKeys, "introducedIn"], ["source"]) || entry.lifecycle === "deprecated" && exactKeys(
      entry,
      [...baseKeys, "deprecatedSince", "migration"],
      ["source"]
    );
    if (!lifecycleShapeValid || typeof entry.typeId !== "string" || !registry.registeredTypeIds.includes(entry.typeId) || !nonEmpty(entry.description) || !nonEmpty(entry.owner) || !isValidPublicAdmissionRationale(path, entry.rationale)) {
      diagnostics.push(
        contractDiagnostic(
          parsedSource.value,
          "TK_CONTRACT_LIFECYCLE_INVALID",
          path,
          {
            path,
            from: "invalid",
            to: typeof entry.lifecycle === "string" ? entry.lifecycle : "invalid",
            rule: "metadata-and-rationale-required"
          }
        )
      );
      continue;
    }
    const entrySource = entry.source ? parseLogicalSourceLocator(entry.source, entrypoint, "source") : ok(parsedSource.value);
    if (!entrySource.ok) {
      diagnostics.push(...entrySource.diagnostics);
      continue;
    }
    if (entry.lifecycle === "experimental") {
      if (!isStrictSemVer(entry.introducedIn)) {
        diagnostics.push(
          contractDiagnostic(
            parsedSource.value,
            "TK_CONTRACT_LIFECYCLE_INVALID",
            path,
            {
              path,
              from: "experimental",
              to: "experimental",
              rule: "introducedIn-semver"
            }
          )
        );
        continue;
      }
    } else if (entry.lifecycle === "deprecated") {
      if (!isStrictSemVer(entry.deprecatedSince) || !isRecord(entry.migration)) {
        diagnostics.push(
          contractDiagnostic(
            parsedSource.value,
            "TK_CONTRACT_LIFECYCLE_INVALID",
            path,
            {
              path,
              from: "deprecated",
              to: "deprecated",
              rule: "migration-required"
            }
          )
        );
        continue;
      }
      if (entry.migration.kind === "replacement" && (!exactKeys(entry.migration, ["kind", "path"]) || parseCanonicalTokenPath(entry.migration.path) === null)) {
        diagnostics.push(
          contractDiagnostic(
            parsedSource.value,
            "TK_CONTRACT_REPLACEMENT_INVALID",
            path,
            {
              path,
              replacement: typeof entry.migration.path === "string" ? entry.migration.path : null,
              reason: "replacement-path-invalid"
            }
          )
        );
        continue;
      }
      if (entry.migration.kind === "none" && (!exactKeys(entry.migration, ["kind", "reason"]) || !isRecord(entry.migration.reason) || !exactKeys(entry.migration.reason, ["code", "detail"]) || !["removed-concept", "merged-concept", "unsafe-api"].includes(
        String(entry.migration.reason.code)
      ) || !nonEmpty(entry.migration.reason.detail))) {
        diagnostics.push(
          contractDiagnostic(
            parsedSource.value,
            "TK_CONTRACT_REPLACEMENT_INVALID",
            path,
            { path, replacement: null, reason: "no-replacement-reason-invalid" }
          )
        );
        continue;
      }
      if (entry.migration.kind !== "replacement" && entry.migration.kind !== "none") {
        diagnostics.push(
          contractDiagnostic(
            parsedSource.value,
            "TK_CONTRACT_REPLACEMENT_INVALID",
            path,
            { path, replacement: null, reason: "migration-kind-invalid" }
          )
        );
        continue;
      }
    } else if (entry.lifecycle !== "stable") {
      diagnostics.push(
        contractDiagnostic(
          parsedSource.value,
          "TK_CONTRACT_LIFECYCLE_INVALID",
          path,
          {
            path,
            from: "invalid",
            to: String(entry.lifecycle),
            rule: "known-lifecycle"
          }
        )
      );
      continue;
    }
    entries[path] = { ...entry, source: entrySource.value };
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  const elevationRoles = /* @__PURE__ */ new Set(["flat", "raised", "overlay", "blocking"]);
  const elevationFacets = /* @__PURE__ */ new Set(["shadow", "surface", "border"]);
  const facetsByRole = /* @__PURE__ */ new Map();
  for (const path of Object.keys(entries).sort(compareAscii)) {
    if (!path.startsWith("semantic.elevation.")) continue;
    const [, , role = "", facet = ""] = path.split(".");
    if (!elevationRoles.has(role)) {
      diagnostics.push(
        createDiagnostic("TK_ELEVATION_GROUP_INCOMPLETE", {
          source: parsedSource.value,
          location: tokenLocation(path),
          details: { role, issue: "unknown-role", facets: [facet] }
        })
      );
      continue;
    }
    if (!elevationFacets.has(facet)) {
      diagnostics.push(
        createDiagnostic("TK_ELEVATION_GROUP_INCOMPLETE", {
          source: parsedSource.value,
          location: tokenLocation(path),
          details: { role, issue: "unknown-facet", facets: [facet] }
        })
      );
      continue;
    }
    const facets = facetsByRole.get(role) ?? /* @__PURE__ */ new Set();
    facets.add(facet);
    facetsByRole.set(role, facets);
  }
  for (const [role, facets] of facetsByRole) {
    const missing = [...elevationFacets].filter((facet) => !facets.has(facet));
    if (missing.length === 0) continue;
    diagnostics.push(
      createDiagnostic("TK_ELEVATION_GROUP_INCOMPLETE", {
        source: parsedSource.value,
        location: tokenLocation(
          `semantic.elevation.${role}.${missing[0]}`
        ),
        details: { role, issue: "missing-facets", facets: missing }
      })
    );
  }
  const surfaceRoles = new Set(THEME_SURFACE_ROLES);
  const surfaceFacets = new Set(THEME_SURFACE_FACETS);
  const surfaceFacetsByRole = /* @__PURE__ */ new Map();
  for (const path of Object.keys(entries).sort(compareAscii)) {
    if (!path.startsWith("semantic.surface.")) continue;
    const segments = path.split(".");
    if (segments.length !== 4) continue;
    const [, , role = "", facet = ""] = segments;
    if (!surfaceRoles.has(role)) {
      diagnostics.push(
        createDiagnostic("TK_ELEVATION_GROUP_INCOMPLETE", {
          source: parsedSource.value,
          location: tokenLocation(path),
          details: { role, issue: "unknown-role", facets: [facet] }
        })
      );
      continue;
    }
    if (!surfaceFacets.has(facet)) {
      diagnostics.push(
        createDiagnostic("TK_ELEVATION_GROUP_INCOMPLETE", {
          source: parsedSource.value,
          location: tokenLocation(path),
          details: { role, issue: "unknown-facet", facets: [facet] }
        })
      );
      continue;
    }
    const facets = surfaceFacetsByRole.get(role) ?? /* @__PURE__ */ new Set();
    facets.add(facet);
    surfaceFacetsByRole.set(role, facets);
  }
  for (const [role, facets] of surfaceFacetsByRole) {
    const missing = THEME_SURFACE_FACETS.filter((facet) => !facets.has(facet));
    if (missing.length === 0) continue;
    diagnostics.push(
      createDiagnostic("TK_ELEVATION_GROUP_INCOMPLETE", {
        source: parsedSource.value,
        location: tokenLocation(
          `semantic.surface.${role}.${missing[0]}`
        ),
        details: { role, issue: "missing-facets", facets: [...missing] }
      })
    );
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  for (const [path, rawEntry] of Object.entries(entries)) {
    const entry = rawEntry;
    if (entry.lifecycle !== "deprecated") continue;
    const migration = entry.migration;
    if (migration.kind !== "replacement") continue;
    const replacement = migration.path;
    const target = entries[replacement];
    if (!target || target.lifecycle === "deprecated" || target.typeId !== entry.typeId) {
      diagnostics.push(
        contractDiagnostic(
          parsedSource.value,
          "TK_CONTRACT_REPLACEMENT_INVALID",
          path,
          {
            path,
            replacement,
            reason: "replacement-must-be-public-compatible"
          }
        )
      );
    }
    const seen = /* @__PURE__ */ new Set([path]);
    let cursor = replacement;
    while (cursor) {
      if (seen.has(cursor)) {
        diagnostics.push(
          contractDiagnostic(
            parsedSource.value,
            "TK_CONTRACT_REPLACEMENT_INVALID",
            path,
            {
              path,
              replacement,
              reason: "replacement-cycle"
            }
          )
        );
        break;
      }
      seen.add(cursor);
      const cursorEntry = entries[cursor];
      const cursorMigration = cursorEntry == null ? void 0 : cursorEntry.migration;
      cursor = (cursorEntry == null ? void 0 : cursorEntry.lifecycle) === "deprecated" && (cursorMigration == null ? void 0 : cursorMigration.kind) === "replacement" ? cursorMigration.path : void 0;
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  return ok(
    snapshotCanonicalJson({
      contractVersion: "4.0.0",
      source: parsedSource.value,
      entries
    })
  );
}
function defineThemeContractObject(registry, source, input, entrypoint = "defineThemeContract") {
  return validateThemeContractObject(registry, source, input, entrypoint);
}
function applyPublicContract(graph, contract, themeId) {
  const diagnostics = [];
  const output = /* @__PURE__ */ Object.create(null);
  const contractEntries = contract.entries;
  for (const [path, token] of Object.entries(graph.tokens).sort(
    ([left], [right]) => compareAscii(left, right)
  )) {
    const entry = contractEntries[path];
    output[path] = {
      path: token.path,
      layer: token.layer,
      ...token.component ? { component: token.component } : {},
      typeId: token.typeId,
      value: token.canonicalValue,
      source: token.source,
      directDependencies: token.directDependencies,
      trace: token.trace,
      appliedTransforms: token.appliedTransforms,
      ...entry ? { visibility: "public", public: entry } : { visibility: "internal" }
    };
  }
  for (const path of Object.keys(contractEntries).sort(compareAscii)) {
    const token = graph.tokens[path];
    const entry = contractEntries[path];
    if (!token) {
      diagnostics.push(
        createDiagnostic("TK_CONTRACT_ENTRY_MISSING", {
          source: contract.source,
          themeId,
          location: tokenLocation(path),
          details: { path }
        })
      );
    } else if (token.typeId !== entry.typeId) {
      diagnostics.push(
        createDiagnostic("TK_CONTRACT_TYPE_MISMATCH", {
          source: contract.source,
          themeId,
          location: tokenLocation(path),
          details: {
            path,
            expectedTypeId: entry.typeId,
            actualTypeId: token.typeId
          }
        })
      );
    }
  }
  if (diagnostics.length > 0) return failure(diagnostics);
  return ok(
    snapshotCanonicalJson(output)
  );
}
function createDefaultCanonicalContract(registry, input) {
  const result = defineThemeContractObject(
    registry,
    { file: "packages/tokens/src/contracts/theme-contract-v4.ts" },
    input,
    "defineThemeContractV4"
  );
  if (!result.ok) {
    throw new Error("Kernel invariant: canonical Theme Contract v4 is invalid");
  }
  return result.value;
}
exports.AXIS_DOMAINS = AXIS_DOMAINS;
exports.AXIS_ORDER = AXIS_ORDER;
exports.BUILT_IN_TYPE_IDS = BUILT_IN_TYPE_IDS;
exports.THEME_SURFACE_FACETS = THEME_SURFACE_FACETS;
exports.THEME_SURFACE_ROLES = THEME_SURFACE_ROLES;
exports.applyPublicContract = applyPublicContract;
exports.axisLocation = axisLocation;
exports.canonicalJsonBytes = canonicalJsonBytes;
exports.canonicalJsonStringify = canonicalJsonStringify;
exports.canonicalizeBuiltIn = canonicalizeBuiltIn;
exports.canonicalizeTypeValue = canonicalizeTypeValue;
exports.compareAscii = compareAscii;
exports.computeCanonicalHash = computeCanonicalHash;
exports.createBuiltInTypeRegistry = createBuiltInTypeRegistry;
exports.createDefaultCanonicalContract = createDefaultCanonicalContract;
exports.createDiagnostic = createDiagnostic;
exports.createTypeRegistry = createTypeRegistry;
exports.defineThemeContractObject = defineThemeContractObject;
exports.defineThemeObject = defineThemeObject;
exports.failure = failure;
exports.isStrictSemVer = isStrictSemVer;
exports.isValidPublicAdmissionRationale = isValidPublicAdmissionRationale;
exports.isValidPublicMigration = isValidPublicMigration;
exports.ok = ok;
exports.parseCanonicalTokenPath = parseCanonicalTokenPath;
exports.parseLogicalSourceLocator = parseLogicalSourceLocator;
exports.sha256Bytes = sha256Bytes;
exports.snapshotCanonicalJson = snapshotCanonicalJson;
exports.themeLocation = themeLocation;
exports.toCanonicalTokenPath = toCanonicalTokenPath;
exports.tokenLocation = tokenLocation;
exports.validateThemeContractObject = validateThemeContractObject;
exports.validateThemeSourceObject = validateThemeSourceObject;
exports.validateTokenLiteralWithRegistry = validateTokenLiteralWithRegistry;
