import { THEME_SURFACE_FACETS, THEME_SURFACE_ROLES } from './surface-contract';
import { ThemeSourceAuthorInput } from './model';
/**
 * Version of the seed-derivation pipeline. Compiled manifests and any future
 * runtime overlay must agree on this version for a derived overlay to be
 * provably identical to a recompile from the same seeds.
 *
 * 1.1.0 adds the surface-role model (`semantic.surface.<role>.<facet>`), the
 * dark canvas / glow / tint-base seeds, and material depth styles.
 * 1.2.0 separates action foregrounds from fills and resolves on-fill contrast
 * after axis transforms and seed overrides.
 * 1.3.0 pairs disabled action foregrounds with the resolved tint-5 fill.
 * 1.4.0 adds softer action ink and dedicated, contrast-safe solid state fills.
 * 1.5.0 separates solid action pairs from brand/status fills, with light labels.
 * 1.6.0 separates field interaction edges from decorative tint and glow.
 */
export declare const THEME_DERIVATION_VERSION = "1.6.0";
export type ThemeSeedRgb = readonly [number, number, number];
/**
 * Surface roles a consumer may declare with `data-zx-surface`. Every role
 * derives the same seven facets so a skin can restyle a whole product shell
 * without touching component CSS.
 */
export { THEME_SURFACE_ROLES, THEME_SURFACE_FACETS } from './surface-contract';
export type ThemeSurfaceRole = (typeof THEME_SURFACE_ROLES)[number];
export type ThemeSurfaceFacet = (typeof THEME_SURFACE_FACETS)[number];
/**
 * How depth is expressed on surfaces: neutral drop shadows (`shadow`),
 * edge-local luminous insets and tinted halos (`glow`), or flat tonal sheens
 * without any glow (`tonal`).
 */
export type ThemeSurfaceDepthStyle = 'shadow' | 'glow' | 'tonal';
/** Which color the translucent hairlines and fills are mixed from. */
export type ThemeTintBase = 'neutral' | 'brand' | 'glow';
export interface ThemeSeedsV1 {
    /** Brand color; becomes the focus/action foundation and the accent ramps. */
    readonly brand: ThemeSeedRgb;
    /**
     * Light page surface seed. When present, all remaining surfaces, text
     * colors, mix targets, and the high-contrast focus color are derived from
     * it in OKLCH; when absent, the reference (default-theme) palette is used.
     */
    readonly neutral?: ThemeSeedRgb;
    /**
     * Dark-mode canvas seed. When present, every dark surface, text, and mix
     * target is derived from it in OKLCH instead of from the neutral seed or
     * the reference palette, so a skin can own its own night palette.
     */
    readonly canvas?: Readonly<{
        dark?: ThemeSeedRgb;
    }>;
    /** Luminous accent used by glow materials; defaults to the brand color. */
    readonly glow?: ThemeSeedRgb;
    /**
     * Color the translucent borders and fills are mixed from. `neutral` (the
     * default) follows the primary text color; `brand` and `glow` tint every
     * hairline and hover fill with the skin's accent.
     */
    readonly tintBase?: ThemeTintBase;
    readonly material?: Readonly<{
        depthStyle?: ThemeSurfaceDepthStyle;
        /** Multiplier applied to every glow alpha; 1 is the reference strength. */
        glowIntensity?: number;
    }>;
    readonly status?: Readonly<{
        success?: ThemeSeedRgb;
        warning?: ThemeSeedRgb;
        danger?: ThemeSeedRgb;
        info?: ThemeSeedRgb;
    }>;
    readonly typography?: Readonly<{
        family?: readonly string[];
    }>;
    readonly metrics?: Readonly<{
        spacingControlYPx?: number;
        radiusControlPx?: number;
        radiusSurfacePx?: number;
        motionDurationMs?: number;
        motionDurationFastMs?: number;
    }>;
    /** Alpha constants for the translucent semantic roles. */
    readonly tone?: Readonly<{
        focusRingAlpha?: number;
        borderSubtleAlpha?: number;
        borderStrongAlpha?: number;
        borderDefaultAlpha?: number;
        /** Light-mode hairline alpha for glow materials (glow color). */
        hairlineAlpha?: number;
        fillHoverAlpha?: number;
        fillActiveAlpha?: number;
        accentSubtleAlpha?: number;
        /**
         * Dark-mode overrides. A translucent tint over a dark canvas needs far
         * more alpha to stay visible than the same tint over white, so borders
         * and hairlines carry their own dark constants.
         */
        dark?: Readonly<{
            borderSubtleAlpha?: number;
            borderStrongAlpha?: number;
            borderDefaultAlpha?: number;
            hairlineAlpha?: number;
        }>;
    }>;
}
export interface ThemeDerivationMeta {
    readonly themeId: string;
    readonly name: string;
}
/**
 * Exact-value escape hatch applied after derivation: entries replace whole
 * derived entries by key; transform entries replace derived transforms of the
 * same axis value path by path, so a refine only has to list the paths it
 * pins. The result still flows through `defineThemeV4` validation.
 */
export interface ThemeDerivationRefine {
    readonly foundation?: Readonly<Record<string, unknown>>;
    readonly semantic?: Readonly<Record<string, unknown>>;
    readonly components?: Readonly<Record<string, unknown>>;
    readonly transforms?: Readonly<Partial<Record<'mode' | 'density' | 'contrast' | 'motion' | 'radius', Readonly<Record<string, readonly unknown[]>>>>>;
}
export declare function borderComposeExpr(widthPath: string, stylePath: string, colorPath: string): {
    type: "border";
    value: {
        $expr: "border.compose@1";
        resultType: "border";
        args: ({
            kind: "ref";
            ref: {
                $ref: string;
                expect: "color";
            };
        } | {
            kind: "ref";
            ref: {
                $ref: string;
                expect: "dimension";
            };
        } | {
            kind: "ref";
            ref: {
                $ref: string;
                expect: "string";
            };
        })[];
    };
};
/**
 * Derives a complete Theme Source 4.0 author input from a small seed set.
 * Pure and deterministic: identical seeds always produce identical sources,
 * so the compiled artifacts of a derived theme are fully reproducible. The
 * returned object is plain data — callers may adjust it before `defineThemeV4`
 * or pass `refine` to pin exact values per entry or per transform path.
 *
 * Besides the classic foundation/semantic roles, the derivation emits nine
 * surface roles × seven facets (`semantic.surface.<role>.<facet>`) whose
 * depth language follows `seeds.material.depthStyle`, so consumers that
 * declare `data-zx-surface` follow a skin's material without code changes.
 */
export declare function deriveThemeSourceV4(seeds: ThemeSeedsV1, meta: ThemeDerivationMeta, refine?: ThemeDerivationRefine): ThemeSourceAuthorInput;
