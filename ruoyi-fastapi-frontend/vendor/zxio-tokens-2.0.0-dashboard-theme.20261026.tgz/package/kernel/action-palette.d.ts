import { CanonicalColor } from './model';
export declare const ACTION_TEXT_CONTRAST_FLOOR = 4.55;
export declare const ACTION_HOVER_STRENGTH = 0.08;
export declare const ACTION_ACTIVE_STRENGTH = 0.14;
export declare const SOLID_ACTION_TEXT_CONTRAST_TARGET = 5;
export declare function actionColorLuminance(color: CanonicalColor): number;
export declare function actionColorContrast(foreground: CanonicalColor, background: CanonicalColor): number;
/** A deliberate light foreground for solid actions, independent of fill tone. */
export declare function deriveSolidActionText(seed: CanonicalColor): CanonicalColor;
/**
 * Keep the seed hue and as much chroma/lightness as a light label permits.
 * Button fills are separate from generic brand/status colors: readable solid
 * actions must not darken charts, links, badges, or checkable controls.
 */
export declare function deriveSolidActionFill(seed: CanonicalColor, foreground: CanonicalColor, minimumContrast?: number): CanonicalColor;
/** Inputs have already been validated as opaque sRGB by the operator. */
export declare function deriveActionText(background: CanonicalColor): CanonicalColor;
/**
 * State emphasis moves away from the fixed enabled ink, improving contrast
 * monotonically. A stronger press uses the same hue family and label rather
 * than crossing the black/white threshold of a general-purpose tint ramp.
 */
export declare function deriveActionStateFill(background: CanonicalColor, foreground: CanonicalColor, strength: number): CanonicalColor;
