export type SrgbTriplet = readonly [number, number, number];
export interface Oklch {
    l: number;
    c: number;
    h: number;
}
export declare function rgbToOklch([r, g, b]: SrgbTriplet): Oklch;
/** Preserve the existing seed pipeline's quantization and clipping behavior. */
export declare function oklchToRgb(value: Oklch): SrgbTriplet;
/** Reduce chroma at a fixed hue/lightness instead of clipping RGB channels. */
export declare function gamutMappedOklchToRgb(value: Oklch): SrgbTriplet;
