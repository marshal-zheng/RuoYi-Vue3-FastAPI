# @zxio/theme-css-codec

Deterministic CSS text encoders for validated canonical theme values. This package has no runtime imports, DOM access, Node built-ins or compiler state. Type declarations reference the public `@zxio/tokens/kernel` and `@zxio/tokens/extensions` types.

```ts
import { canonicalNumber, serializeColor } from '@zxio/theme-css-codec'
canonicalNumber(-0) // '0'
serializeColor({ colorSpace: 'srgb', components: [0.25, 0.55, 0.98], alpha: 1 })
```

`themeExtensionCssEncoder` implements the `zx.theme-extension-css/1` port used by extension compilers and Host validation:

```ts
import { themeExtensionCssEncoder } from '@zxio/theme-css-codec'

themeExtensionCssEncoder.encode({
  kind: 'literal',
  typeId: 'dimension',
  value: { kind: 'value', value: 12, unit: 'px' },
}) // { ok: true, value: { kind: 'scalar', value: '12px' }, diagnostics: [] }
```

The port accepts literals already normalized by the Kernel. It preserves whole values as scalars and expands typography into `fontFamily`, `fontSize`, `fontWeight`, `lineHeight`, and `letterSpacing`. Empty shadow lists encode as `none`. Stroke keywords are supported; a stroke object requires a field projection that this ABI does not provide and returns `TX_CSS_ENCODING`.

String literals are always quoted CSS strings, including CSS escapes for controls and style delimiters. They do not authorize raw CSS expressions. Font names receive equivalent escaping; strings containing NUL or lone surrogates are rejected because CSS cannot preserve them. All emitted scalars and fields undergo an output safety check; failures return diagnostics with no partial value. This check supplements the authoring boundary and does not replace Kernel input validation.

Existing serializers retain their output conventions and consumer-specific policies. Encoding support does not authorize an input. Build with `pnpm -C packages/theme-css-codec build`; public ESM, CommonJS and declarations are emitted under `dist/`.
