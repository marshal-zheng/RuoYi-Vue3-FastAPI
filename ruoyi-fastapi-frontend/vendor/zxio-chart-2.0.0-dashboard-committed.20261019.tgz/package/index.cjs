"use strict";
Object.defineProperties(exports, { __esModule: { value: true }, [Symbol.toStringTag]: { value: "Module" } });
const shared = require("@zxio/shared");
const vue = require("vue");
const VChartsComponent = require("vue-echarts");
const core = require("echarts/core");
const renderers = require("echarts/renderers");
const charts = require("echarts/charts");
const components = require("echarts/components");
const zxChartProps = shared.buildProps({
  // 支持 对象 | Promise | 函数（返回对象或 Promise）
  options: { type: [Object, Function], default: () => ({}) },
  // 在 options 解析后应用的转换器（可链式）
  transform: { type: [Function, Array], default: () => [] },
  // 空状态判定函数，自定义"暂无数据"的判断逻辑
  isEmpty: { type: Function, default: void 0 },
  // 出错后是否显示重试按钮
  enableRetry: { type: Boolean, default: true },
  // 加载中文案
  loadingText: { type: String, default: "加载中..." },
  // 空状态文案
  emptyText: { type: String, default: "暂无数据" },
  // 错误状态文案
  errorText: { type: String, default: "加载失败" },
  width: { type: String, default: "100%" },
  height: { type: String, default: "100%" },
  autoResize: { type: Boolean, default: true },
  themeMode: {
    type: String,
    default: "projection",
    values: ["projection", "neutral"]
  },
  themeProjection: {
    type: Object
  }
});
const zxChartEmits = {
  ready: () => true,
  click: (_payload) => {
    return true;
  },
  loading: (loading) => typeof loading === "boolean",
  error: (_error) => {
    return true;
  },
  empty: (empty) => typeof empty === "boolean",
  refreshed: (_options) => {
    return true;
  }
};
const ROOT_KEYS = [
  "manifestIdentity",
  "variantIdentity",
  "color",
  "status",
  "palette",
  "grid",
  "overlayShadow",
  "motionDurationMs",
  "radiusPx"
];
const MANIFEST_KEYS = [
  "packageName",
  "packageVersion",
  "themeId",
  "contractVersion",
  "sourceContentHash",
  "contractContentHash",
  "typeRegistryContentHash"
];
const VARIANT_KEYS = [
  "variantKey",
  "resolvedContentHash",
  "coreCssSha256",
  "elementPlusResolvedCssSha256"
];
const COLOR_KEYS = ["surface", "text", "mutedText", "focus", "accent"];
const STATUS_KEYS = ["success", "warning", "danger", "info"];
const GRID_KEYS = ["line", "axis"];
const MANIFEST_BUILD_KEYS = [
  "sourceSchemaVersion",
  "resolvedSchemaVersion",
  "compilerName",
  "compilerVersion"
];
const SHA256 = /^sha256:[a-f0-9]{64}$/u;
const SEMVER = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/u;
const PACKAGE_NAME = /^@[a-z0-9][a-z0-9._-]*\/[a-z0-9][a-z0-9._-]*$/u;
const SAFE_ID = /^[a-z0-9](?:[a-z0-9._-]{0,254}[a-z0-9])?$/u;
const SAFE_COLOR = /^(?!.*(?:var\s*\(|url\s*\(|[;{}]))\S(?:.{0,126}\S)?$/iu;
const SAFE_SHADOW = /^(?!.*(?:var\s*\(|url\s*\(|[;{}]))\S(?:.{0,2046}\S)?$/iu;
function failure(path, reason, code = "CHART_THEME_PROJECTION_INVALID") {
  return {
    ok: false,
    diagnostics: [{ code, path, reason }]
  };
}
function record(value, keys) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return null;
  const actualKeys = Object.keys(value).sort();
  const expectedKeys = [...keys].sort();
  if (actualKeys.length !== expectedKeys.length || actualKeys.some((key, index) => key !== expectedKeys[index]))
    return null;
  return value;
}
function validHash(value) {
  return typeof value === "string" && SHA256.test(value);
}
function validSafeId(value) {
  return typeof value === "string" && SAFE_ID.test(value);
}
function validColor(value) {
  return typeof value === "string" && value === value.trim() && SAFE_COLOR.test(value);
}
function identityKey(identity) {
  return JSON.stringify([
    identity.manifestIdentity.packageName,
    identity.manifestIdentity.packageVersion,
    identity.manifestIdentity.themeId,
    identity.manifestIdentity.contractVersion,
    identity.manifestIdentity.sourceContentHash,
    identity.manifestIdentity.contractContentHash,
    identity.manifestIdentity.typeRegistryContentHash,
    identity.variantIdentity.variantKey,
    identity.variantIdentity.resolvedContentHash,
    identity.variantIdentity.coreCssSha256,
    identity.variantIdentity.elementPlusResolvedCssSha256
  ]);
}
function createChartThemeProjection(input, expectedIdentity) {
  const root = record(input, ROOT_KEYS);
  if (!root) return failure("$", "shape");
  const manifest = record(root.manifestIdentity, [...MANIFEST_KEYS, ...MANIFEST_BUILD_KEYS]) ?? record(root.manifestIdentity, MANIFEST_KEYS);
  if (!manifest) return failure("$.manifestIdentity", "shape");
  if (typeof manifest.packageName !== "string" || !PACKAGE_NAME.test(manifest.packageName))
    return failure("$.manifestIdentity.packageName", "package-name");
  if (typeof manifest.packageVersion !== "string" || !SEMVER.test(manifest.packageVersion))
    return failure("$.manifestIdentity.packageVersion", "semver");
  if (!validSafeId(manifest.themeId))
    return failure("$.manifestIdentity.themeId", "safe-id");
  if (manifest.contractVersion !== "4.0.0")
    return failure("$.manifestIdentity.contractVersion", "contract-version");
  for (const key of [
    "sourceContentHash",
    "contractContentHash",
    "typeRegistryContentHash"
  ]) {
    if (!validHash(manifest[key]))
      return failure(`$.manifestIdentity.${key}`, "sha256");
  }
  if ("compilerName" in manifest) {
    if (manifest.sourceSchemaVersion !== 4)
      return failure("$.manifestIdentity.sourceSchemaVersion", "schema-version");
    if (manifest.resolvedSchemaVersion !== 1)
      return failure(
        "$.manifestIdentity.resolvedSchemaVersion",
        "schema-version"
      );
    if (typeof manifest.compilerName !== "string" || !PACKAGE_NAME.test(manifest.compilerName))
      return failure("$.manifestIdentity.compilerName", "package-name");
    if (typeof manifest.compilerVersion !== "string" || !SEMVER.test(manifest.compilerVersion))
      return failure("$.manifestIdentity.compilerVersion", "semver");
  }
  const variant = record(root.variantIdentity, VARIANT_KEYS);
  if (!variant) return failure("$.variantIdentity", "shape");
  if (!validSafeId(variant.variantKey))
    return failure("$.variantIdentity.variantKey", "safe-id");
  for (const key of [
    "resolvedContentHash",
    "coreCssSha256",
    "elementPlusResolvedCssSha256"
  ]) {
    if (!validHash(variant[key]))
      return failure(`$.variantIdentity.${key}`, "sha256");
  }
  const color = record(root.color, COLOR_KEYS);
  if (!color) return failure("$.color", "shape");
  for (const key of COLOR_KEYS) {
    if (!validColor(color[key])) return failure(`$.color.${key}`, "color");
  }
  const status = record(root.status, STATUS_KEYS);
  if (!status) return failure("$.status", "shape");
  for (const key of STATUS_KEYS) {
    if (!validColor(status[key])) return failure(`$.status.${key}`, "color");
  }
  const grid = record(root.grid, GRID_KEYS);
  if (!grid) return failure("$.grid", "shape");
  for (const key of GRID_KEYS) {
    if (!validColor(grid[key])) return failure(`$.grid.${key}`, "color");
  }
  if (!Array.isArray(root.palette) || root.palette.length === 0 || root.palette.length > 256)
    return failure("$.palette", "array-range");
  for (let index = 0; index < root.palette.length; index++) {
    if (!validColor(root.palette[index]))
      return failure(`$.palette[${index}]`, "color");
  }
  if (typeof root.overlayShadow !== "string" || root.overlayShadow !== root.overlayShadow.trim() || !SAFE_SHADOW.test(root.overlayShadow))
    return failure("$.overlayShadow", "shadow");
  if (typeof root.motionDurationMs !== "number" || !Number.isInteger(root.motionDurationMs) || root.motionDurationMs < 0 || root.motionDurationMs > 6e4)
    return failure("$.motionDurationMs", "integer-range");
  if (typeof root.radiusPx !== "number" || !Number.isFinite(root.radiusPx) || root.radiusPx < 0 || root.radiusPx > 1e3)
    return failure("$.radiusPx", "number-range");
  const projection = Object.freeze({
    manifestIdentity: Object.freeze({
      packageName: manifest.packageName,
      packageVersion: manifest.packageVersion,
      themeId: manifest.themeId,
      contractVersion: manifest.contractVersion,
      sourceContentHash: manifest.sourceContentHash,
      contractContentHash: manifest.contractContentHash,
      typeRegistryContentHash: manifest.typeRegistryContentHash,
      ..."compilerName" in manifest ? {
        sourceSchemaVersion: manifest.sourceSchemaVersion,
        resolvedSchemaVersion: manifest.resolvedSchemaVersion,
        compilerName: manifest.compilerName,
        compilerVersion: manifest.compilerVersion
      } : {}
    }),
    variantIdentity: Object.freeze({
      variantKey: variant.variantKey,
      resolvedContentHash: variant.resolvedContentHash,
      coreCssSha256: variant.coreCssSha256,
      elementPlusResolvedCssSha256: variant.elementPlusResolvedCssSha256
    }),
    color: Object.freeze({
      surface: color.surface,
      text: color.text,
      mutedText: color.mutedText,
      focus: color.focus,
      accent: color.accent
    }),
    status: Object.freeze({ ...status }),
    palette: Object.freeze([...root.palette]),
    grid: Object.freeze({ ...grid }),
    overlayShadow: root.overlayShadow,
    motionDurationMs: root.motionDurationMs,
    radiusPx: root.radiusPx
  });
  if (expectedIdentity && identityKey(projection) !== identityKey(expectedIdentity))
    return failure(
      "$.identity",
      "expected-identity",
      "CHART_THEME_PROJECTION_IDENTITY_MISMATCH"
    );
  return { ok: true, value: projection, diagnostics: [] };
}
function chartThemeProjectionIdentityKey(projection) {
  return identityKey(projection);
}
function echartsColor(value) {
  const match = /^color\(srgb\s+([\d.e+-]+)\s+([\d.e+-]+)\s+([\d.e+-]+)\s*\/\s*([\d.e+-]+)\)$/iu.exec(
    value
  );
  if (!match) return value;
  const channels = match.slice(1).map(Number);
  if (channels.some((channel) => !Number.isFinite(channel))) return value;
  const clamp = (channel) => Math.min(1, Math.max(0, channel));
  const [red, green, blue] = channels.slice(0, 3).map((channel) => Math.round(clamp(channel) * 255));
  return `rgba(${red},${green},${blue},${clamp(channels[3])})`;
}
function createChartEChartsTheme(projection) {
  const surface = echartsColor(projection.color.surface);
  const text = echartsColor(projection.color.text);
  const mutedText = echartsColor(projection.color.mutedText);
  const focus = echartsColor(projection.color.focus);
  const axis = {
    axisLine: { lineStyle: { color: echartsColor(projection.grid.axis) } },
    axisTick: { lineStyle: { color: echartsColor(projection.grid.axis) } },
    axisLabel: { color: mutedText },
    splitLine: {
      lineStyle: { color: echartsColor(projection.grid.line), type: "dashed" }
    }
  };
  return {
    color: projection.palette.map(echartsColor),
    backgroundColor: surface,
    animationDurationUpdate: projection.motionDurationMs,
    textStyle: { color: text },
    title: {
      textStyle: { color: text },
      subtextStyle: { color: mutedText }
    },
    legend: {
      textStyle: { color: text },
      inactiveColor: mutedText
    },
    categoryAxis: axis,
    valueAxis: axis,
    tooltip: {
      backgroundColor: surface,
      borderColor: focus,
      borderWidth: 1,
      textStyle: { color: text },
      extraCssText: `border-radius: ${projection.radiusPx}px; box-shadow: ${projection.overlayShadow}`
    },
    gauge: {
      axisLine: {
        lineStyle: { color: [[1, echartsColor(projection.color.accent)]] }
      },
      axisTick: { lineStyle: { color: surface } },
      splitLine: { lineStyle: { color: surface } },
      axisLabel: { color: mutedText },
      pointer: { itemStyle: { color: echartsColor(projection.color.accent) } },
      title: { color: text },
      detail: { color: text }
    }
  };
}
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{
    name: "ZxChart"
  },
  __name: "chart",
  props: zxChartProps,
  emits: zxChartEmits,
  setup(__props, { expose: __expose, emit: __emit }) {
    const VCharts = VChartsComponent;
    const props = __props;
    const emit = __emit;
    core.use([
      renderers.CanvasRenderer,
      charts.BarChart,
      charts.CustomChart,
      charts.GaugeChart,
      charts.LineChart,
      charts.PieChart,
      charts.RadarChart,
      charts.ScatterChart,
      charts.BoxplotChart,
      charts.ParallelChart,
      components.GridComponent,
      components.TooltipComponent,
      components.LegendComponent,
      components.DataZoomComponent,
      components.DatasetComponent,
      components.TransformComponent,
      components.GraphicComponent,
      components.TitleComponent,
      components.ParallelComponent
    ]);
    const ns = shared.useNamespace("chart");
    const chartContainer = vue.ref(null);
    const chartRef = vue.ref(null);
    const chartReady = vue.ref(false);
    const status = vue.ref("loading");
    const errorMessage = vue.ref("");
    const resolvedOptions = vue.ref({});
    let currentTaskId = 0;
    const projectionResult = vue.computed(() => {
      if (props.themeMode === "neutral") return null;
      return createChartThemeProjection(props.themeProjection);
    });
    const projectionDiagnostic = vue.computed(() => {
      const result = projectionResult.value;
      return result && !result.ok ? result.diagnostics[0] : void 0;
    });
    const resolvedProjection = vue.computed(() => {
      const result = projectionResult.value;
      return (result == null ? void 0 : result.ok) ? result.value : void 0;
    });
    const echartsTheme = vue.computed(() => {
      const projection = resolvedProjection.value;
      return projection ? createChartEChartsTheme(projection) : void 0;
    });
    const chartInstanceKey = vue.computed(() => {
      const projection = resolvedProjection.value;
      return projection ? chartThemeProjectionIdentityKey(projection) : props.themeMode;
    });
    const containerStyle = vue.computed(() => {
      const projection = resolvedProjection.value;
      return {
        width: props.width,
        height: props.height,
        ...projection ? {
          backgroundColor: projection.color.surface,
          color: projection.color.text,
          borderRadius: `${projection.radiusPx}px`
        } : {}
      };
    });
    const app = vue.getCurrentInstance();
    const zxEmptyComp = vue.computed(() => {
      var _a;
      return (_a = app == null ? void 0 : app.appContext.components) == null ? void 0 : _a["ZxEmpty"];
    });
    const normalizeTransforms = (t) => {
      if (!t) return [];
      return Array.isArray(t) ? t : [t];
    };
    const isEmptyDefault = (opt) => {
      if (!opt) return true;
      const series = opt.series;
      if (!series || Array.isArray(series) && series.length === 0) return true;
      const list = Array.isArray(series) ? series : [series];
      const hasData = list.some(
        (s) => Array.isArray(s == null ? void 0 : s.data) ? s.data.length > 0 : !!(s == null ? void 0 : s.data)
      );
      return !hasData;
    };
    const resolveInputOptions = async () => {
      const src = props.options;
      let result;
      if (typeof src === "function") {
        result = src();
      } else {
        result = src;
      }
      if (result && typeof result.then === "function") {
        result = await result;
      }
      return result || {};
    };
    const applyTransforms = async (opt) => {
      const transformers = normalizeTransforms(props.transform);
      let out = opt;
      for (const fn of transformers) {
        const r = fn ? fn(out) : out;
        out = r && typeof r.then === "function" ? await r : r;
      }
      return out;
    };
    const refresh = async () => {
      const taskId = ++currentTaskId;
      status.value = "loading";
      errorMessage.value = "";
      emit("loading", true);
      const themeFailure = projectionDiagnostic.value;
      if (themeFailure) {
        status.value = "error";
        errorMessage.value = themeFailure.code;
        emit("error", themeFailure);
        emit("loading", false);
        return;
      }
      await Promise.resolve().then(async () => {
        let opt = await resolveInputOptions();
        opt = await applyTransforms(opt);
        const isEmpty = props.isEmpty ? !!props.isEmpty(opt) : isEmptyDefault(opt);
        if (taskId !== currentTaskId) return;
        if (isEmpty) {
          resolvedOptions.value = {};
          status.value = "empty";
          emit("empty", true);
        } else {
          resolvedOptions.value = opt;
          status.value = "ready";
          emit("empty", false);
        }
        emit("refreshed", resolvedOptions.value);
      }).catch((err) => {
        if (taskId !== currentTaskId) return;
        status.value = "error";
        errorMessage.value = (err == null ? void 0 : err.message) || String(err || "");
        emit("error", err);
      }).finally(() => {
        emit("loading", false);
      });
    };
    const onClick = (payload) => emit("click", payload);
    vue.onMounted(async () => {
      chartReady.value = true;
      await refresh();
      if (status.value !== "error") {
        await vue.nextTick();
        emit("ready");
      }
    });
    vue.watch(
      () => [
        props.options,
        props.transform,
        props.isEmpty,
        props.themeMode,
        props.themeProjection
      ],
      async () => {
        var _a;
        await refresh();
        await vue.nextTick();
        if (typeof ((_a = chartRef.value) == null ? void 0 : _a.resize) === "function") chartRef.value.resize();
      },
      { deep: true }
    );
    __expose({
      resize: () => {
        var _a;
        if (typeof ((_a = chartRef.value) == null ? void 0 : _a.resize) === "function") chartRef.value.resize();
      },
      clear: () => {
        var _a;
        if (typeof ((_a = chartRef.value) == null ? void 0 : _a.clear) === "function") chartRef.value.clear();
      },
      getContainer: () => chartContainer.value,
      getChart: () => chartRef.value
    });
    const loadingText = vue.computed(() => props.loadingText);
    const emptyText = vue.computed(() => props.emptyText);
    const errorText = vue.computed(() => props.errorText);
    const enableRetry = vue.computed(() => props.enableRetry);
    const autoResize = vue.computed(() => props.autoResize);
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createElementBlock("div", {
        ref_key: "chartContainer",
        ref: chartContainer,
        class: vue.normalizeClass(vue.unref(ns).b()),
        style: vue.normalizeStyle(containerStyle.value)
      }, [
        status.value === "loading" ? (vue.openBlock(), vue.createElementBlock("div", {
          key: 0,
          class: vue.normalizeClass(vue.unref(ns).e("loading"))
        }, [
          vue.renderSlot(_ctx.$slots, "loading", {}, () => [
            vue.createTextVNode(vue.toDisplayString(loadingText.value), 1)
          ])
        ], 2)) : status.value === "error" ? (vue.openBlock(), vue.createElementBlock("div", {
          key: 1,
          class: vue.normalizeClass(vue.unref(ns).e("inner"))
        }, [
          vue.createElementVNode("div", {
            class: vue.normalizeClass(vue.unref(ns).e("status"))
          }, [
            vue.renderSlot(_ctx.$slots, "error", {
              error: errorMessage.value,
              retry: refresh
            }, () => [
              vue.createElementVNode("div", {
                class: vue.normalizeClass(vue.unref(ns).e("error"))
              }, vue.toDisplayString(errorText.value) + vue.toDisplayString(errorMessage.value ? `：${errorMessage.value}` : ""), 3),
              enableRetry.value ? (vue.openBlock(), vue.createElementBlock("div", {
                key: 0,
                class: vue.normalizeClass(vue.unref(ns).e("actions"))
              }, [
                vue.createElementVNode("button", {
                  type: "button",
                  class: vue.normalizeClass(vue.unref(ns).e("button")),
                  onClick: refresh
                }, " 重试 ", 2)
              ], 2)) : vue.createCommentVNode("", true)
            ])
          ], 2)
        ], 2)) : status.value === "empty" ? (vue.openBlock(), vue.createElementBlock("div", {
          key: 2,
          class: vue.normalizeClass(vue.unref(ns).e("inner"))
        }, [
          vue.createElementVNode("div", {
            class: vue.normalizeClass(vue.unref(ns).e("status"))
          }, [
            vue.renderSlot(_ctx.$slots, "empty", {}, () => [
              zxEmptyComp.value ? (vue.openBlock(), vue.createBlock(vue.resolveDynamicComponent(zxEmptyComp.value), {
                key: 0,
                description: emptyText.value
              }, null, 8, ["description"])) : (vue.openBlock(), vue.createElementBlock("div", {
                key: 1,
                class: vue.normalizeClass(vue.unref(ns).e("empty"))
              }, vue.toDisplayString(emptyText.value), 3))
            ])
          ], 2)
        ], 2)) : (vue.openBlock(), vue.createElementBlock("div", {
          key: 3,
          class: vue.normalizeClass(vue.unref(ns).e("inner"))
        }, [
          chartReady.value ? (vue.openBlock(), vue.createBlock(vue.unref(VCharts), {
            key: chartInstanceKey.value,
            ref_key: "chartRef",
            ref: chartRef,
            option: resolvedOptions.value,
            theme: echartsTheme.value,
            autoresize: autoResize.value,
            style: { width: "100%", height: "100%" },
            onClick
          }, null, 8, ["option", "theme", "autoresize"])) : vue.renderSlot(_ctx.$slots, "default", {}, void 0, void 0, 1)
        ], 2))
      ], 6);
    };
  }
});
const ZxChart = shared.withInstall(_sfc_main);
exports.ZxChart = ZxChart;
exports.chartThemeProjectionIdentityKey = chartThemeProjectionIdentityKey;
exports.createChartEChartsTheme = createChartEChartsTheme;
exports.createChartThemeProjection = createChartThemeProjection;
exports.default = ZxChart;
exports.zxChartEmits = zxChartEmits;
exports.zxChartProps = zxChartProps;
