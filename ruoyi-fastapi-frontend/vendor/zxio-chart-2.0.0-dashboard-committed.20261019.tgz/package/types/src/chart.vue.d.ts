import { DefineComponent, ExtractPropTypes, PropType, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
import { EpPropFinalized, EpPropMergeType } from '@zxio/shared';
import { ChartThemeProjection } from './theme';
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: {
        loading?(_: {}): any;
        error?(_: {
            error: string;
            retry: () => Promise<void>;
        }): any;
        empty?(_: {}): any;
        default?(_: {}): any;
    };
    refs: {
        chartContainer: HTMLDivElement;
        chartRef: unknown;
    };
    rootEl: HTMLDivElement;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: DefineComponent<ExtractPropTypes<{
    readonly options: EpPropFinalized<any, unknown, unknown, () => {}, boolean>;
    readonly transform: EpPropFinalized<any, unknown, unknown, () => never[], boolean>;
    readonly isEmpty: EpPropFinalized<any, unknown, unknown, undefined, boolean>;
    readonly enableRetry: EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadingText: EpPropFinalized<StringConstructor, unknown, unknown, "加载中...", boolean>;
    readonly emptyText: EpPropFinalized<StringConstructor, unknown, unknown, "暂无数据", boolean>;
    readonly errorText: EpPropFinalized<StringConstructor, unknown, unknown, "加载失败", boolean>;
    readonly width: EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly height: EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly autoResize: EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly themeMode: EpPropFinalized<(new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral") | (((new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral")) | null)[], "projection" | "neutral", unknown, "projection", boolean>;
    readonly themeProjection: {
        readonly type: PropType<ChartThemeProjection>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>, {
    resize: () => void;
    clear: () => void;
    getContainer: () => HTMLElement | null;
    getChart: () => any;
}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    ready: () => void;
    click: (_payload: any) => void;
    loading: (loading: boolean) => void;
    error: (_error: any) => void;
    empty: (empty: boolean) => void;
    refreshed: (_options: any) => void;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    readonly options: EpPropFinalized<any, unknown, unknown, () => {}, boolean>;
    readonly transform: EpPropFinalized<any, unknown, unknown, () => never[], boolean>;
    readonly isEmpty: EpPropFinalized<any, unknown, unknown, undefined, boolean>;
    readonly enableRetry: EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadingText: EpPropFinalized<StringConstructor, unknown, unknown, "加载中...", boolean>;
    readonly emptyText: EpPropFinalized<StringConstructor, unknown, unknown, "暂无数据", boolean>;
    readonly errorText: EpPropFinalized<StringConstructor, unknown, unknown, "加载失败", boolean>;
    readonly width: EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly height: EpPropFinalized<StringConstructor, unknown, unknown, "100%", boolean>;
    readonly autoResize: EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly themeMode: EpPropFinalized<(new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral") | (((new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral")) | null)[], "projection" | "neutral", unknown, "projection", boolean>;
    readonly themeProjection: {
        readonly type: PropType<ChartThemeProjection>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>> & Readonly<{
    onReady?: (() => any) | undefined;
    onClick?: ((_payload: any) => any) | undefined;
    onLoading?: ((loading: boolean) => any) | undefined;
    onError?: ((_error: any) => any) | undefined;
    onEmpty?: ((empty: boolean) => any) | undefined;
    onRefreshed?: ((_options: any) => any) | undefined;
}>, {
    readonly height: string;
    readonly transform: any;
    readonly width: string;
    readonly options: any;
    readonly isEmpty: any;
    readonly enableRetry: EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly emptyText: string;
    readonly errorText: string;
    readonly autoResize: EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly themeMode: EpPropMergeType<(new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral") | (((new (...args: any[]) => "projection" | "neutral") | (() => "projection" | "neutral")) | null)[], "projection" | "neutral", unknown>;
}, {}, {}, {}, string, ComponentProvideOptions, true, {
    chartContainer: HTMLDivElement;
    chartRef: unknown;
}, HTMLDivElement>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
