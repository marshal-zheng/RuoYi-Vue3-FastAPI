# @zxio/chart

基于 ECharts 封装的 Vue 3 图表组件。

`@zxio/chart` 是 standalone package。它不创建 Theme Runtime，也不查找页面主题状态；宿主通过显式、不可变的 `ChartThemeProjection` 把已激活 scope 的主题值交给每个图表实例。

## 安装

```bash
pnpm add @zxio/chart echarts@^6 vue-echarts@^8
```

```ts
import { createApp } from 'vue'
import { ZxChart } from '@zxio/chart'
import '@zxio/chart/style'
import { themeHost } from './theme-host'

const app = createApp(App)
app.component('ZxChart', ZxChart)
const bound = themeHost.bind(app)
if (!bound.ok) throw new Error(bound.diagnostics[0]?.code)
app.mount(document.querySelector('#app')!)
```

`themeHost` belongs to the product shell and is created from public Theme v4
manifests and required ports. The chart package never creates or discovers it.

## 显式主题投影

正式主题模式要求 `themeProjection`。identity 必须来自同一个 v4 manifest、concrete Variant 及其精确 CSS artifacts；颜色、动效时长与圆角值由宿主 adapter 在 scope 激活后生成。

2.0.0 移除了旧五键格式。ZXUI 宿主可直接传入 `createZxChartThemeProjection`
的成功结果 `value`；其他宿主须提供下列完整字段，包含 palette、status、grid 和阴影。

```vue
<template>
  <ZxChart :options="option" :theme-projection="projection" />
</template>

<script setup lang="ts">
import { createChartThemeProjection } from '@zxio/chart'

const sha256 = (digit: string) => `sha256:${digit.repeat(64)}`
const result = createChartThemeProjection({
  manifestIdentity: {
    packageName: '@zxio/theme-default',
    packageVersion: '1.0.3',
    themeId: 'default',
    contractVersion: '4.0.0',
    sourceContentHash: sha256('1'),
    contractContentHash: sha256('2'),
    typeRegistryContentHash: sha256('3'),
  },
  variantIdentity: {
    variantKey:
      'mode-light__density-default__contrast-normal__motion-full__radius-default',
    resolvedContentHash: sha256('4'),
    coreCssSha256: sha256('5'),
    elementPlusResolvedCssSha256: sha256('6'),
  },
  color: {
    surface: '#ffffff',
    text: '#1f2937',
    mutedText: '#64748b',
    focus: '#2563eb',
    accent: '#3b82f6',
  },
  status: {
    success: '#16a34a',
    warning: '#d97706',
    danger: '#dc2626',
    info: '#64748b',
  },
  palette: ['#3b82f6', '#16a34a', '#d97706', '#dc2626', '#64748b'],
  grid: { line: '#e2e8f0', axis: '#94a3b8' },
  overlayShadow: '0px 4px 12px 0px rgba(0, 0, 0, 0.12)',
  motionDurationMs: 200,
  radiusPx: 6,
})

if (!result.ok) throw new Error(result.diagnostics[0].code)
const projection = result.value
const option = {
  xAxis: { type: 'category', data: ['A', 'B', 'C'] },
  yAxis: { type: 'value' },
  series: [{ type: 'bar', data: [12, 8, 16] }],
}
</script>
```

根宿主 adapter 还必须在构造 projection 前完成以下检查：

- 输入是显式 `ThemeScopeHandle` 与该 scope 拥有的 root，不执行页面搜索；
- root 的 `data-zx-theme`、`data-zx-variant`、`data-zx-scope` 与 handle 完全一致；
- 只读取当前 manifest public surface 中声明的变量；
- Variant 的 resolved content hash、core CSS hash 与 Element Plus resolved CSS hash 完全匹配。

projection 由工厂复制并冻结。每个 `ZxChart` 实例仅持有自己的 prop；替换一个实例的 projection 会以完整 identity 创建新的 ECharts instance key，不修改其他图表。

## 显式 neutral mode

不需要主题值的纯数据图可明确选择 neutral mode。省略 projection 但未声明 neutral mode 会失败关闭。

```vue
<ZxChart theme-mode="neutral" :options="option" />
```

## 验证

```bash
pnpm --filter @zxio/chart typecheck
pnpm --filter @zxio/chart test
pnpm --filter @zxio/chart build
```

## License

MIT
