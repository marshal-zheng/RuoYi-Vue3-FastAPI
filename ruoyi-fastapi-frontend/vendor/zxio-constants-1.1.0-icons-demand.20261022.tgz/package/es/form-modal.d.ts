export type ButtonType = '' | 'default' | 'primary' | 'success' | 'warning' | 'info' | 'danger' | 'text';
/** Button keys used by modal footers */
export declare const BUTTON_KEYS: {
    readonly SAVE: "save";
    readonly SUBMIT: "submit";
    readonly CANCEL: "cancel";
    readonly PREV: "prev";
    readonly NEXT: "next";
    readonly CONTINUE: "continue";
};
export type ButtonKey = (typeof BUTTON_KEYS)[keyof typeof BUTTON_KEYS];
/** Tags that should not initiate dragging when they receive a mouse event */
export declare const INTERACTIVE_TAGS: Set<string>;
export type FooterButtonText = string | Record<string, any> | undefined;
/** Container appearance maps to the existing Button API, independently of tone. */
export type ButtonVariant = 'default' | 'plain' | 'text' | 'link';
export declare const buttonVariantProps: (variant?: ButtonVariant) => {
    plain: boolean;
    text: boolean;
    link: boolean;
};
export interface FooterButtonConfig {
    key: string;
    type?: ButtonType;
    text?: FooterButtonText;
    icon?: string;
    loading?: boolean;
    disabled?: boolean;
    show?: boolean | (() => boolean);
    permission?: string;
    order?: number;
    variant?: ButtonVariant;
}
export interface StepEventParams {
    currentStep: number;
    totalSteps: number;
    targetStep: number;
}
export declare const resolveText: (text: FooterButtonText) => string;
/**
 * Structural equality for editable records and supported collection/value types.
 * Opaque instances (including File/Blob) compare by identity. Keys whose value
 * is `undefined` are treated as absent.
 */
export declare const isDeepEqual: (left: unknown, right: unknown) => boolean;
export declare const normalizeButtons: (buttons: FooterButtonConfig[]) => FooterButtonConfig[];
/** Default footer copy; hosts pass a localized set through `useFormModal`. */
export interface FormModalMessages {
    ok: string;
    cancel: string;
    saveAndContinue: string;
    prev: string;
    next: string;
    submit: string;
}
export interface FormModalProps {
    buttons?: FooterButtonConfig[];
    enableSteps?: boolean;
    currentStep?: number;
    totalSteps?: number;
    /** Field names validated by "Next" for each step (index 0 = step 1). */
    stepFields?: string[][];
    /** Custom per-step validator; return `false` to stay on the current step. */
    validateStep?: (step: number) => boolean | Promise<boolean>;
    showCancel?: boolean;
    showContinue?: boolean;
    cancelText?: FooterButtonText;
    prevText?: FooterButtonText;
    nextText?: FooterButtonText;
    okText?: FooterButtonText;
    saveContinueText?: FooterButtonText;
    submitText?: FooterButtonText;
    buttonAlign?: 'left' | 'center' | 'right';
    formRef?: Record<string, any> | null;
    formModel?: Record<string, any> | null;
    autoResetForm?: boolean;
    preValidate?: boolean;
    autoScrollToError?: boolean;
    scrollErrorOffset?: number;
    beforeSave?: () => boolean | Promise<boolean>;
    afterSave?: (success: boolean) => void;
    preventRepeatSubmit?: boolean;
    debounce?: number;
    throttle?: number;
    confirm?: (...args: any[]) => any;
    okLoading?: boolean;
    okDisabled?: boolean;
}
