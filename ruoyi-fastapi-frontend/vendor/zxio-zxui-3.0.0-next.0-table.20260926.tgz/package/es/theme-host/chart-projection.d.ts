import type { AdapterContractPort, ManifestIdentity, ThemeScopeHandle } from '../theme-runtime';
export interface ZxChartThemeProjection {
    readonly manifestIdentity: ManifestIdentity;
    readonly variantIdentity: Readonly<{
        readonly variantKey: string;
        readonly resolvedContentHash: string;
        readonly coreCssSha256: string;
        readonly elementPlusResolvedCssSha256: string;
    }>;
    readonly color: Readonly<{
        readonly surface: string;
        readonly text: string;
        readonly mutedText: string;
        readonly focus: string;
        readonly accent: string;
    }>;
    readonly status: Readonly<{
        readonly success: string;
        readonly warning: string;
        readonly danger: string;
        readonly info: string;
    }>;
    readonly palette: readonly [
        string,
        string,
        string,
        string,
        string,
        string,
        string,
        string,
        string,
        string
    ];
    readonly grid: Readonly<{
        readonly line: string;
        readonly axis: string;
    }>;
    readonly overlayShadow: string;
    readonly motionDurationMs: number;
    readonly radiusPx: number;
}
export type ZxChartProjectionResult = Readonly<{
    ok: true;
    value: ZxChartThemeProjection;
    diagnostics: readonly [];
}> | Readonly<{
    ok: false;
    diagnostics: readonly [
        Readonly<{
            code: 'CONSUMER_CHART_PROJECTION_INVALID';
            phase: 'owner' | 'manifest' | 'artifact';
            details: Readonly<{
                reason: string;
            }>;
        }>
    ];
}>;
export interface CreateZxChartThemeProjectionInput {
    readonly adapterContract: AdapterContractPort;
    readonly manifest: unknown;
    readonly scope: ThemeScopeHandle;
    readonly root: HTMLElement;
}
/**
 * Creates the standalone Chart projection from one explicit active Runtime
 * scope and that scope's exact owner root. It never searches the document,
 * reads classes, or infers ownership from an ancestor.
 */
export declare function createZxChartThemeProjection(input: CreateZxChartThemeProjectionInput): ZxChartProjectionResult;
