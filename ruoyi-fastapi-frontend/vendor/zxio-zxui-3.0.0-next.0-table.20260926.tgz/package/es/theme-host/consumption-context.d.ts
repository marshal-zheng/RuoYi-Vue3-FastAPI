import type { InjectionKey } from 'vue';
import type { ThemeExtensionTokenDescriptorV1 } from '@zxio/tokens/extensions';
import type { ZxThemeConsumptionService } from './consumption';
export interface ThemeHostConsumptionContext {
    readonly service: ZxThemeConsumptionService | null;
    readonly publicTokens: readonly ThemeExtensionTokenDescriptorV1[];
    readonly server: boolean;
}
export declare const themeHostConsumptionKey: InjectionKey<ThemeHostConsumptionContext>;
