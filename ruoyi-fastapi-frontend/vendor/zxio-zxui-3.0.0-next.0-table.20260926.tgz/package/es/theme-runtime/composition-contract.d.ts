import { hashThemeCss } from './asset-integrity';
import type { ResolvedThemeState } from './runtime';
import type { ThemeRuntimeResult } from './result';
export interface ThemeScopeIdentity {
    readonly runtimeId: string;
    readonly scopeId: string;
}
export interface ThemeCompositionStyle {
    readonly id: string;
    readonly cssText: string;
    readonly hash: string;
}
export interface PreparedThemeComposition {
    readonly contentHash: string;
    readonly attributes: Readonly<Record<string, string>>;
    readonly styles: readonly ThemeCompositionStyle[];
    readonly managedProperties: Readonly<{
        readonly scope: readonly string[];
        readonly adapters: Readonly<Record<string, readonly string[]>>;
    }>;
    readonly state: unknown;
}
export interface ThemeScopeCompositionPort {
    prepare(input: {
        readonly scopeId: string;
        readonly parentScopeId: string | null;
        readonly parent: PreparedThemeComposition | null;
        readonly request: unknown;
        readonly resolved: ResolvedThemeState;
        readonly previous: PreparedThemeComposition | null;
    }): ThemeRuntimeResult<PreparedThemeComposition>;
}
export interface ThemeCompositionHydrationScope {
    readonly scopeId: string;
    readonly parentScopeId: string | null;
    readonly localRequest: unknown;
    readonly contentHash: string;
    readonly attributes: Readonly<Record<string, string>>;
    readonly styleIds: readonly string[];
}
export interface ThemeCompositionHydrationSnapshot {
    readonly schema: 'zx.theme-composition-hydration/1';
    readonly appKey: string;
    readonly coreSnapshotHash: string;
    readonly scopes: readonly ThemeCompositionHydrationScope[];
    readonly styles: readonly ThemeCompositionStyle[];
}
export interface ThemeCompositionHydrationInput {
    readonly snapshot: unknown;
    readonly scopeElements: readonly HTMLElement[];
    readonly styleElements: readonly HTMLElement[];
    readonly ownership: 'transferred' | 'external';
}
export declare const compositionAttributeNames: readonly ["data-zx-extension", "data-zx-ext-axes", "data-zx-composition"];
export declare const compositionHash: typeof hashThemeCss;
export declare const compositionStyleIdPattern: RegExp;
/** Snapshot only bounded JSON data; accessors are rejected without invoking them. */
export declare function snapshotCompositionData(value: unknown): unknown;
export declare function validateCompositionStyles(styles: readonly ThemeCompositionStyle[]): void;
export declare function validatePreparedComposition(input: unknown): ThemeRuntimeResult<PreparedThemeComposition>;
export declare function prepareComposition(port: ThemeScopeCompositionPort | undefined, input: Parameters<ThemeScopeCompositionPort['prepare']>[0]): ThemeRuntimeResult<PreparedThemeComposition | null>;
export declare function effectiveCompositionHash(resolved: ResolvedThemeState, composition: PreparedThemeComposition | null): string;
