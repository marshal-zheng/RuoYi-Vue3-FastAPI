import { type SFCWithInstall } from '@zxio/shared';
import Input from '../components/input/src/input-core.vue';
import InputNumber from '../components/input-number/src/input-number-core.vue';
import ListView from '../components/list-view/src/list-view-core.vue';
/** Explicit capability assembly; root/leaf convenience entries stay compatible. */
export declare const ZxButton: SFCWithInstall<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly debounce: number;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    } & {
        'tooltip-content'?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    };
})> & Record<string, any>;
export declare const ZxIcon: SFCWithInstall<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig) | (((new (...args: any[]) => string | import("../components/index").TooltipConfig) | (() => string | import("../components/index").TooltipConfig)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
})> & Record<string, any>;
export declare const ZxTag: SFCWithInstall<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly theme: import("@zxio/shared").EpPropMergeType<StringConstructor, "plain" | "light" | "dark", unknown>;
    readonly width: number;
    readonly selfStyle: import("vue").CSSProperties;
    readonly maxWidth: string;
    readonly noMargin: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly tooltipDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        icon?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    };
})> & Record<string, any>;
export declare const ZxInput: SFCWithInstall<typeof Input>;
export declare const ZxInputNumber: SFCWithInstall<typeof InputNumber>;
export declare const ZxDialog: SFCWithInstall<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/core").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly beforeClose: import("../components/index").DialogBeforeClose;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: import("../components/index").ThemeRequiredPortalTarget;
    readonly confirm: import("../components/index").DialogConfirm;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly locale: Partial<import("../components/index").DialogMessages>;
    readonly debounce: number;
    readonly throttle: number;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly buttons: import("@zxio/constants").FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right")) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard) | (((new (...args: any[]) => boolean | import("../components/index").DialogDirtyGuard) | (() => boolean | import("../components/index").DialogDirtyGuard)) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (((new (...args: any[]) => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[]) | (() => import("../components/index").DialogConfirm | import("../components/index").DialogConfirm[])) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("../components/index").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton")) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noContentPadding: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly headerPadding: string;
    readonly bodyPadding: string;
    readonly footerPadding: string;
    readonly handleBeforeCancel: Function;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: import("../components/index").DialogSlots;
})> & Record<string, any>;
export declare const ZxListView: SFCWithInstall<typeof ListView>;
export declare const ZxSelect: SFCWithInstall<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: {
        content?: string;
        placement?: import("@zxio/utils/dist/es/index.js").StandardPlacement;
    };
    readonly modelValue: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor, ArrayConstructor, ObjectConstructor], unknown, unknown>;
    readonly entity: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").SelectOption | import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | import("../components/index").SelectOption[] | null) | (((new (...args: any[]) => import("../components/index").SelectOption | import("../components/index").SelectOption[]) | (() => import("../components/index").SelectOption | import("../components/index").SelectOption[] | null)) | null)[], unknown, unknown>;
    readonly hasAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultAllSelect: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly defaultFirst: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly remote: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchKeys: string[];
    readonly valueKey: string;
    readonly labelKey: string;
    readonly options: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (((new (...args: any[]) => import("../components/index").SelectOption[] | import("../components/index").OptionsLoader) | (() => import("../components/index").SelectOption[] | import("../components/index").OptionsLoader)) | null)[], unknown, unknown>;
    readonly transform: (list: any) => import("../components/index").SelectOption[];
    readonly objectValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly atLeastOne: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly notAutoInitSearch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly optionNotExitsText: string;
    readonly shouldCalculateMaxTag: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly optionLabelRender: (item: import("../components/index").SelectOption) => string;
    readonly resolvedOptions: import("../components/index").SelectOption[];
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        header?: (props: {}) => any;
    } & {
        footer?: (props: {}) => any;
    } & {
        empty?: (props: {}) => any;
    } & {
        header?: (props: {}) => any;
    } & {
        footer?: (props: {}) => any;
    } & {
        empty?: (props: {}) => any;
    };
})> & Record<string, any>;
export { createZxUiCapabilities } from '../components/capabilities/context';
export type { ZxUiCapabilities } from '../components/capabilities/context';
