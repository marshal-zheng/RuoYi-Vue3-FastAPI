import type { DrawerDirection } from './constants';
type __VLS_Slots = {
    header?(props: {
        titleId: string;
        titleClass: string;
    }): any;
    default?(): any;
    footer?(): any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {
    handleClose: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => void;
    closed: () => void;
    open: () => void;
    opened: () => void;
    "update:modelValue": (value: boolean) => void;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    "onUpdate:modelValue"?: ((value: boolean) => any) | undefined;
    onClose?: (() => any) | undefined;
    onClosed?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
    onOpened?: (() => any) | undefined;
}>, {
    modal: boolean;
    lockScroll: boolean;
    showClose: boolean;
    closeOnClickModal: boolean;
    closeOnPressEscape: boolean;
    direction: DrawerDirection;
    modelValue: boolean;
    destroyOnClose: boolean;
    modalPenetrable: boolean;
    trapFocus: boolean;
    withHeader: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
