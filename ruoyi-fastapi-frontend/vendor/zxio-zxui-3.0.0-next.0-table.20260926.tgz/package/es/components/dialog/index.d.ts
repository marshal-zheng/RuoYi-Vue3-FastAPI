import { type SFCWithInstall } from '@zxio/shared';
import DialogComponent from './src/dialog.vue';
export declare const ZxDialog: SFCWithInstall<typeof DialogComponent>;
export default ZxDialog;
export * from './src/props';
export type { ZxDialogInstance, ZxDialogExpose } from './src/instance';
export type { DialogBeforeClose, DialogCloseReason, DialogConfirm, DialogConfirmContext, DialogDescriptionItem, DialogDirtyGuard, DialogSize, } from './src/constants';
export type { DialogMessages, DialogLocaleKey } from './src/locale';
export type { DialogSlots, DialogSlotContext } from './src/slots';
