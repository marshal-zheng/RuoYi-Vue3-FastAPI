import type { MessageParams, NotificationParams } from 'element-plus';
import type { ThemeFeedback, ThemeMessageBoxOptions, ThemeRuntimeResult } from '../../theme-provider';
import type { ZxConfigProviderContext } from './types';
export interface ZxFeedbackApi {
    message(options: MessageParams): ReturnType<ThemeFeedback['message']>;
    notification(options: NotificationParams): ReturnType<ThemeFeedback['notification']>;
    modal: Readonly<{
        confirm(options: ThemeMessageBoxOptions): ReturnType<ThemeFeedback['confirm']>;
    }>;
}
export declare function createZxFeedback(feedback: ThemeFeedback, config?: Partial<ZxConfigProviderContext>): ZxFeedbackApi;
export declare function useZxFeedback(): ThemeRuntimeResult<ZxFeedbackApi>;
