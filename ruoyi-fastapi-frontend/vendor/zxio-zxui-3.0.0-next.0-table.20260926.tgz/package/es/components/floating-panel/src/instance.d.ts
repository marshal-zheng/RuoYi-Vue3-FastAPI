import type { ZxFloatingPanelPoint, ZxFloatingPanelResizeEvent } from './props';
export interface ZxFloatingPanelInstance {
    /** Current collapse state. */
    readonly isCollapsed: boolean;
    /** Current visibility. */
    readonly visible: boolean;
    toggleCollapse: () => void;
    expand: () => void;
    collapse: () => void;
    /** Show the panel; emits `update:modelValue`. */
    open: () => void;
    /** Hide the panel; emits `update:modelValue` and `close`. */
    close: () => void;
    /** Move a free-floating panel to an offset relative to its offset parent. */
    setPosition: (x: number, y: number) => void;
    /** Drop any dragged offset and fall back to the `position` prop. */
    resetPosition: () => void;
    /** Override the expanded size (px) as if the user had resized the panel. */
    setSize: (size: Partial<ZxFloatingPanelResizeEvent>) => void;
    /** Drop any user size and fall back to the `size` prop. */
    resetSize: () => void;
    /** Last known offset relative to the offset parent. */
    getPosition: () => ZxFloatingPanelPoint;
}
