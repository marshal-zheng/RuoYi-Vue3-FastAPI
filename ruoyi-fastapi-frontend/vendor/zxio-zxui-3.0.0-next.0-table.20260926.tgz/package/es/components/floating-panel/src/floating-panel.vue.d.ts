import { type ZxFloatingPanelAnchorTarget, type ZxFloatingPanelCssLength, type ZxFloatingPanelPoint, type ZxFloatingPanelResizeEvent } from './props';
import type { ThemeRequiredPortalTarget } from '../../theme-provider';
declare var __VLS_5: {}, __VLS_11: {
    loading: any;
    completed: any;
    error: any;
}, __VLS_22: {
    isCollapsed: any;
    toggle: any;
    close: any;
}, __VLS_34: {
    isCollapsed: any;
    toggleCollapse: any;
    close: any;
};
type __VLS_Slots = {} & {
    header?: (props: typeof __VLS_5) => any;
} & {
    status?: (props: typeof __VLS_11) => any;
} & {
    actions?: (props: typeof __VLS_22) => any;
} & {
    default?: (props: typeof __VLS_34) => any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {
    isCollapsed: import("vue").ComputedRef<any>;
    visible: import("vue").ComputedRef<any>;
    toggleCollapse: () => void;
    expand: () => void;
    collapse: () => void;
    open: () => void;
    close: () => void;
    setPosition: (x: number, y: number) => void;
    resetPosition: () => void;
    setSize: (size: Partial<ZxFloatingPanelResizeEvent>) => void;
    resetSize: () => void;
    getPosition: () => ZxFloatingPanelPoint;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    title: string;
    anchor: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null) | (((new (...args: any[]) => string | Element | import("@floating-ui/dom").VirtualElement | import("vue").Ref<ZxFloatingPanelAnchorTarget | null, ZxFloatingPanelAnchorTarget | null> | (() => ZxFloatingPanelAnchorTarget | null)) | (() => import("./props").ZxFloatingPanelAnchor | null)) | null)[], unknown, unknown>;
    shift: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    error: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    customClass: string;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    offset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | [number, number]) | (() => number | [number, number]) | (((new (...args: any[]) => number | [number, number]) | (() => number | [number, number])) | null)[], unknown, unknown>;
    placement: any;
    zIndex: number;
    position: Partial<Record<"left" | "right" | "top" | "bottom", ZxFloatingPanelCssLength>>;
    portalTarget: ThemeRequiredPortalTarget;
    loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    size: Partial<Record<"width" | "minWidth" | "maxWidth" | "height" | "minHeight" | "maxHeight", ZxFloatingPanelCssLength>>;
    ariaLabel: string;
    modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | (((new (...args: any[]) => boolean) | (() => boolean | undefined)) | null)[], unknown, unknown>;
    loadingText: string;
    flip: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    titleTag: string;
    resizable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    minSize: ZxFloatingPanelResizeEvent;
    errorText: string;
    completed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapsed: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | (((new (...args: any[]) => boolean) | (() => boolean | undefined)) | null)[], unknown, unknown>;
    defaultCollapsed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    headerClickable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    collapsedSize: Partial<Record<"width" | "height", ZxFloatingPanelCssLength>>;
    collapsedShape: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape) | (((new (...args: any[]) => "circle" | "rounded") | (() => import("./props").ZxFloatingPanelCollapsedShape)) | null)[], unknown, unknown>;
    expandIcon: import("./props").ZxFloatingPanelIcon;
    collapseIconProp: import("./props").ZxFloatingPanelIcon;
    showCollapseBtn: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    showStatus: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completedText: string;
    expandTooltip: string;
    collapseTooltip: string;
    closeTooltip: string;
    autoExpand: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    completedDuration: number;
    transitionDuration: number;
    autoDirection: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    positionStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy) | (((new (...args: any[]) => "free" | "anchored") | (() => import("./props").ZxFloatingPanelPositionStrategy)) | null)[], unknown, unknown>;
    shiftPadding: number;
    keyboardStep: number;
    teleport: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    responsive: Record<string, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
