declare const _default: {
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
});
export default _default;
