import { ElInputNumber } from 'element-plus';
type __VLS_Slots = {
    prefix?(props: Record<string, unknown>): unknown;
    suffix?(props: Record<string, unknown>): unknown;
    'increase-icon'?(props: Record<string, unknown>): unknown;
    'decrease-icon'?(props: Record<string, unknown>): unknown;
};
type NumberInstance = InstanceType<typeof ElInputNumber>;
declare const __VLS_component: import("vue").DefineComponent<unknown, {
    focus: (...args: Parameters<NumberInstance["focus"]>) => any;
    blur: (...args: Parameters<NumberInstance["blur"]>) => any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    id: string;
    disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    valueOnClear: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null) | ((new (...args: any[]) => number | "min" | "max") | (() => number | "min" | "max" | null))[], unknown, unknown>;
    min: number;
    max: number;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown>;
    readonly: boolean;
    validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    align: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right") | ((new (...args: any[]) => "center" | "left" | "right") | (() => "center" | "left" | "right"))[], unknown, unknown>;
    disabledScientific: boolean;
    step: number;
    stepStrictly: boolean;
    controls: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    controlsPosition: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "right", unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
