declare const _default: import("vue").DefineComponent<unknown, {
    /** 打开面板 */
    open: () => void;
    /** 关闭面板 */
    close: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end")) | null)[], unknown, unknown>;
    readonly showArrow: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: string;
    readonly showFooter: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmText: string;
    readonly clearable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly placeholder: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly columns: number;
    readonly sources: import("./props").IconSource[];
    readonly iconifyCollections: string[];
    readonly customIcons: import("./props").IconMeta[];
    readonly tabMode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode)) | null)[], unknown, unknown>;
    readonly showTabs: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly categories: import("./props").IconCategory[];
    readonly itemHeight: number;
    readonly panelHeight: number;
    readonly panelMode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover")) | null)[], unknown, unknown>;
    readonly popoverWidth: number;
    readonly allowModeSwitch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | (((new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement)) | null)[], unknown, unknown>;
    readonly showRecent: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly recentMax: number;
    readonly recentScope: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope)) | null)[], unknown, unknown>;
    readonly recentScopeKey: string;
    readonly recentScopeResolver: (icon: import("./props").IconMeta) => string;
    readonly recentSaveStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | (((new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy)) | null)[], unknown, unknown>;
    readonly recentKey: string;
    readonly recentKeyPrefix: string;
    readonly recentStorage: import("./props").IconSelectStorage;
    readonly triggerMode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "input" | "icon") | (() => import("./props").TriggerMode) | (((new (...args: any[]) => "input" | "icon") | (() => import("./props").TriggerMode)) | null)[], unknown, unknown>;
    readonly triggerSize: number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
