import * as icons from '@element-plus/icons-vue';
/** Complete synchronous name lookup is retained only by the convenience entry. */
export declare const legacyUiCapabilities: Readonly<{
    icons: typeof icons;
    tooltip: import("@zxio/shared").SFCWithInstall<{
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
        readonly title: string;
        readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly offset: number;
        readonly placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end" | "auto-start" | "auto-end") | (() => import("@zxio/zxui").StandardPlacement) | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end" | "auto-start" | "auto-end") | (() => import("@zxio/zxui").StandardPlacement)) | null)[], unknown, unknown>;
        readonly content: string;
        readonly variant: import("@zxio/shared").EpPropMergeType<StringConstructor, "auto" | "tooltip" | "popover", unknown>;
        readonly visible: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean) | (() => boolean | undefined) | (((new (...args: any[]) => boolean) | (() => boolean | undefined)) | null)[], unknown, unknown>;
        readonly trigger: import("@zxio/shared").EpPropMergeType<StringConstructor, "click" | "contextmenu" | "focus" | "hover", unknown>;
        readonly hideAfter: number;
        readonly showAfter: number;
        readonly width: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
        readonly enterable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly persistent: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showArrow: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly popperClass: string;
        readonly contentClass: string;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            default?: (props: {}) => any;
        } & {
            content?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        };
    })>;
}>;
