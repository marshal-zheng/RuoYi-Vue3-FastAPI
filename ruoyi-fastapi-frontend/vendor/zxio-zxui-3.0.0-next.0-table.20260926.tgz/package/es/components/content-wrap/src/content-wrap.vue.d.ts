import { type ContentWrapSlots } from './props';
import type { ActionRef } from '@zxio/keybindings/core';
import type { FooterButtonConfig } from '@zxio/constants/form-modal';
declare const _default: __VLS_WithSlots<import("vue").DefineComponent<unknown, {
    submit: () => import("@zxio/keybindings/vue").ActionAdmission<unknown>;
    validate: () => Promise<boolean>;
    scrollToFirstError: () => void;
    setLoading: (value: boolean) => {
        readonly status: "rejected";
        readonly reason: "host-action-owned";
    } | undefined;
    setDisabled: (value: boolean) => {
        readonly status: "rejected";
        readonly reason: "host-action-owned";
    } | undefined;
    reset: () => {
        readonly status: "rejected";
        readonly reason: "host-action-owned";
    } | {
        readonly status: "rejected";
        readonly reason: "save-in-progress";
    } | undefined;
    prev: () => void;
    next: () => Promise<import("@zxio/keybindings/vue").ActionAdmission<unknown> | undefined>;
    cancel: () => import("@zxio/keybindings/vue").ActionAdmission<void>;
    isSubmitting: import("vue").ComputedRef<boolean>;
    isLoading: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    readonly title: string;
    readonly fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly message: string;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly saveAction: ActionRef<unknown>;
    readonly showFooter: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly isEdit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly footerFixed: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly cancelText: string;
    readonly saveText: string;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: string;
    readonly nextText: string;
    readonly submitText: string;
    readonly handleBack: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => void) | (() => (() => void) | undefined) | {
        (): (() => void) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly buttons: FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<StringConstructor, "left" | "center" | "right", unknown>;
    readonly readonly: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly validateForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly formRef: any;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly enableKeyboardShortcuts: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollOffset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
    readonly transformOffset: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (offset: number) => number) | (() => ((offset: number) => number) | undefined) | {
        (): ((offset: number) => number) | undefined;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly contentPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
    readonly footerMarginOffset: number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>, ContentWrapSlots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
