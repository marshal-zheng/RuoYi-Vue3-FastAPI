declare const _default: import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    list: import("vue").ComputedRef<any>;
    onEnter: (el: Element, done: () => void) => void;
    onLeave: (el: Element, done: () => void) => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
    collapsed: boolean;
}, {}, {
    'zx-list-view-row': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
        isSelected: import("vue").ComputedRef<any>;
        isActive: import("vue").ComputedRef<any>;
        hasRowActions: import("vue").ComputedRef<boolean>;
        rowActionsWidth: import("vue").ComputedRef<any>;
        rowHeight: import("vue").ComputedRef<any>;
        rowClasses: import("vue").ComputedRef<(string | {
            [x: string]: any;
        })[]>;
        linkProps: import("vue").ComputedRef<{
            to: any;
            onClick: (event: Event) => void;
            role?: undefined;
            tabindex?: undefined;
            onKeydown?: undefined;
        } | {
            role: string;
            tabindex: number;
            onClick: (event: Event) => void;
            onKeydown: (event: KeyboardEvent) => void;
            to?: undefined;
        } | {
            to?: undefined;
            onClick?: undefined;
            role?: undefined;
            tabindex?: undefined;
            onKeydown?: undefined;
        }>;
        onRowClick: (event: Event) => void;
        onRowKeydown: (event: KeyboardEvent) => void;
        handleCheckboxClick: (event: MouseEvent) => void;
        getGridTemplateColumns: typeof import("./utils.js").getGridTemplateColumns;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
        ElCheckbox: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            ariaControls: StringConstructor;
            modelValue: {
                type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            label: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            value: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            indeterminate: BooleanConstructor;
            disabled: {
                type: BooleanConstructor;
                default: undefined;
            };
            checked: BooleanConstructor;
            name: {
                type: StringConstructor;
                default: undefined;
            };
            trueValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            trueLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            id: {
                type: StringConstructor;
                default: undefined;
            };
            border: BooleanConstructor;
            size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            tabindex: (NumberConstructor | StringConstructor)[];
            validateEvent: {
                type: BooleanConstructor;
                default: boolean;
            };
            ariaLabel: StringConstructor;
        }>> & {
            "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
            onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
        }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
            change: (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
        }, string, {
            label: string | number | boolean | Record<string, any>;
            disabled: boolean;
            border: boolean;
            value: string | number | boolean | Record<string, any>;
            id: string;
            name: string;
            modelValue: string | number | boolean;
            validateEvent: boolean;
            indeterminate: boolean;
            checked: boolean;
            trueValue: string | number;
            falseValue: string | number;
            trueLabel: string | number;
            falseLabel: string | number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        }) & import("vue").ObjectPlugin & {
            CheckboxButton: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                ariaControls: StringConstructor;
                modelValue: {
                    type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                label: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                value: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                indeterminate: BooleanConstructor;
                disabled: {
                    type: BooleanConstructor;
                    default: undefined;
                };
                checked: BooleanConstructor;
                name: {
                    type: StringConstructor;
                    default: undefined;
                };
                trueValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                trueLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                id: {
                    type: StringConstructor;
                    default: undefined;
                };
                border: BooleanConstructor;
                size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                tabindex: (NumberConstructor | StringConstructor)[];
                validateEvent: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                ariaLabel: StringConstructor;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
                onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
                change: (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
            }, string, {
                label: string | number | boolean | Record<string, any>;
                disabled: boolean;
                border: boolean;
                value: string | number | boolean | Record<string, any>;
                id: string;
                name: string;
                modelValue: string | number | boolean;
                validateEvent: boolean;
                indeterminate: boolean;
                checked: boolean;
                trueValue: string | number;
                falseValue: string | number;
                trueLabel: string | number;
                falseLabel: string | number;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
            CheckboxGroup: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly ariaLabel: StringConstructor;
                readonly modelValue: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
                readonly disabled: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                readonly min: NumberConstructor;
                readonly max: NumberConstructor;
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly fill: StringConstructor;
                readonly textColor: StringConstructor;
                readonly tag: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
                readonly validateEvent: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly options: {
                    readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly props: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | (() => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | ((new (...args: any[]) => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | (() => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }))[], unknown, unknown, () => Required<{
                    value?: string;
                    label?: string;
                    disabled?: string;
                }>, boolean>;
                readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
                onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
                change: (val: import("element-plus").CheckboxValueType[]) => void;
            }, string, {
                readonly disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
                readonly props: {
                    value?: string;
                    label?: string;
                    disabled?: string;
                };
                readonly tag: string;
                readonly modelValue: import("element-plus").CheckboxGroupValueType;
                readonly validateEvent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
        };
        'zx-list-view-row-item': import("vue").DefineComponent<unknown, {
            Tooltip: import("vue").ComponentOptions<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions, any, any, any, string, {}, {}, string, {}, {}, {}, string, import("vue").ComponentProvideOptions> | {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } | import("vue").FunctionalComponent<{}, {}, any, {}>;
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            label: import("vue").ComputedRef<any>;
            tooltip: import("vue").ComputedRef<any>;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
            item: string | number | Record<string, any>;
            column: Record<string, any>;
            row: Record<string, any>;
            align: string;
            isSecondary: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
