import type { ListViewDensity, ListViewGroupRow } from './props';
declare const _default: import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    props: LooseRequired<any>;
    showGroupedRows: import("vue").ComputedRef<any>;
    selectable: import("vue").ComputedRef<boolean>;
    showHeader: import("vue").ComputedRef<boolean>;
    density: import("vue").ComputedRef<ListViewDensity>;
    densityClass: import("vue").ComputedRef<string>;
    virtualEnabled: import("vue").ComputedRef<boolean>;
    handleColumnWidthUpdated: (payload: {
        key: string;
        width: string;
    }) => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:selections': (selections: Set<any>) => boolean;
    'update:activeRow': (_activeRow: any) => boolean;
    columnWidthUpdated: (column: import("./props").ListViewColumn) => boolean;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    onColumnWidthUpdated?: ((column: import("./props").ListViewColumn) => any) | undefined;
    "onUpdate:selections"?: ((selections: Set<any>) => any) | undefined;
    "onUpdate:activeRow"?: ((_activeRow: any) => any) | undefined;
}>, {
    readonly options: import("./props").ListViewOptions;
    readonly rows: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("./props").ListViewRow[] | ListViewGroupRow[]) | (() => import("./props").ListViewRow[] | ListViewGroupRow[]) | (((new (...args: any[]) => import("./props").ListViewRow[] | ListViewGroupRow[]) | (() => import("./props").ListViewRow[] | ListViewGroupRow[])) | null)[], unknown, unknown>;
    readonly columns: import("./props").ListViewColumn[];
}, {}, {
    'zx-list-view-empty-state': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
        ElButton: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly nativeType: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "reset" | "submit", unknown, "button", boolean>;
            readonly loading: BooleanConstructor;
            readonly loadingIcon: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, () => any, boolean>;
            readonly plain: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly text: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly link: BooleanConstructor;
            readonly bg: BooleanConstructor;
            readonly autofocus: BooleanConstructor;
            readonly round: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly circle: BooleanConstructor;
            readonly color: StringConstructor;
            readonly dark: BooleanConstructor;
            readonly autoInsertSpace: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly tag: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, "button", boolean>;
        }>> & {
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }, {
            ref: import("vue").Ref<HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "small" | "default" | "large">;
            type: import("vue").ComputedRef<string>;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, string, {
            readonly link: boolean;
            readonly circle: boolean;
            readonly text: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly round: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly dark: boolean;
            readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
            readonly bg: boolean;
            readonly tag: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
            readonly loading: boolean;
            readonly autofocus: boolean;
            readonly plain: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoInsertSpace: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly nativeType: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "reset" | "submit", unknown>;
            readonly loadingIcon: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                loading?: (props: {}) => any;
            } & {
                icon?: (props: {}) => any;
            } & {
                default?: (props: {}) => any;
            };
        }) & import("vue").ObjectPlugin & {
            ButtonGroup: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
                readonly direction: {
                    readonly type: import("vue").PropType<"horizontal" | "vertical">;
                    readonly values: readonly ["horizontal", "vertical"];
                    readonly default: "horizontal";
                };
            }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                readonly direction: "horizontal" | "vertical";
                readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
        };
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    'zx-list-view-header': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
        emit: (event: "columnWidthUpdated", ...args: any[]) => void;
        hasRowActions: import("vue").ComputedRef<boolean>;
        rowActionsWidth: import("vue").ComputedRef<any>;
        getGridTemplateColumns: typeof import("./utils").getGridTemplateColumns;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "columnWidthUpdated"[], "columnWidthUpdated", import("vue").PublicProps, Readonly<unknown> & Readonly<{
        onColumnWidthUpdated?: ((...args: any[]) => any) | undefined;
    }>, {}, {}, {
        ElCheckbox: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            ariaControls: StringConstructor;
            modelValue: {
                type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            label: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            value: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            indeterminate: BooleanConstructor;
            disabled: {
                type: BooleanConstructor;
                default: undefined;
            };
            checked: BooleanConstructor;
            name: {
                type: StringConstructor;
                default: undefined;
            };
            trueValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            trueLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            id: {
                type: StringConstructor;
                default: undefined;
            };
            border: BooleanConstructor;
            size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            tabindex: (NumberConstructor | StringConstructor)[];
            validateEvent: {
                type: BooleanConstructor;
                default: boolean;
            };
            ariaLabel: StringConstructor;
        }>> & {
            "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
            onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
        }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
            change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
        }, string, {
            label: string | number | boolean | Record<string, any>;
            disabled: boolean;
            border: boolean;
            value: string | number | boolean | Record<string, any>;
            id: string;
            name: string;
            modelValue: string | number | boolean;
            validateEvent: boolean;
            indeterminate: boolean;
            checked: boolean;
            trueValue: string | number;
            falseValue: string | number;
            trueLabel: string | number;
            falseLabel: string | number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        }) & import("vue").ObjectPlugin & {
            CheckboxButton: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                ariaControls: StringConstructor;
                modelValue: {
                    type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                label: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                value: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                indeterminate: BooleanConstructor;
                disabled: {
                    type: BooleanConstructor;
                    default: undefined;
                };
                checked: BooleanConstructor;
                name: {
                    type: StringConstructor;
                    default: undefined;
                };
                trueValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                trueLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                id: {
                    type: StringConstructor;
                    default: undefined;
                };
                border: BooleanConstructor;
                size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                tabindex: (NumberConstructor | StringConstructor)[];
                validateEvent: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                ariaLabel: StringConstructor;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
            }, string, {
                label: string | number | boolean | Record<string, any>;
                disabled: boolean;
                border: boolean;
                value: string | number | boolean | Record<string, any>;
                id: string;
                name: string;
                modelValue: string | number | boolean;
                validateEvent: boolean;
                indeterminate: boolean;
                checked: boolean;
                trueValue: string | number;
                falseValue: string | number;
                trueLabel: string | number;
                falseLabel: string | number;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
            CheckboxGroup: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly ariaLabel: StringConstructor;
                readonly modelValue: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
                readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                readonly min: NumberConstructor;
                readonly max: NumberConstructor;
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly fill: StringConstructor;
                readonly textColor: StringConstructor;
                readonly tag: import("element-plus/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
                readonly validateEvent: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly options: {
                    readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly props: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | (() => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | ((new (...args: any[]) => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | (() => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }))[], unknown, unknown, () => Required<{
                    value?: string;
                    label?: string;
                    disabled?: string;
                }>, boolean>;
                readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
                onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
                change: (val: import("element-plus").CheckboxValueType[]) => void;
            }, string, {
                readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
                readonly props: {
                    value?: string;
                    label?: string;
                    disabled?: string;
                };
                readonly tag: string;
                readonly modelValue: import("element-plus").CheckboxGroupValueType;
                readonly validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
        };
        'zx-list-view-header-item': import("vue").DefineComponent<unknown, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            columnRef: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
            isResizing: import("vue").Ref<boolean, boolean>;
            startResizing: (e: MouseEvent) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "columnWidthUpdated"[], "columnWidthUpdated", import("vue").PublicProps, Readonly<unknown> & Readonly<{
            onColumnWidthUpdated?: ((...args: any[]) => any) | undefined;
        }>, {
            debounceTime: number;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    'zx-list-view-rows': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
        'zx-list-view-row': import("vue").DefineComponent<unknown, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            isSelected: import("vue").ComputedRef<any>;
            isActive: import("vue").ComputedRef<any>;
            hasRowActions: import("vue").ComputedRef<boolean>;
            rowActionsWidth: import("vue").ComputedRef<any>;
            rowHeight: import("vue").ComputedRef<any>;
            rowClasses: import("vue").ComputedRef<(string | {
                [x: string]: any;
            })[]>;
            linkProps: import("vue").ComputedRef<{
                to: any;
                onClick: (event: Event) => void;
                role?: undefined;
                tabindex?: undefined;
                onKeydown?: undefined;
            } | {
                role: string;
                tabindex: number;
                onClick: (event: Event) => void;
                onKeydown: (event: KeyboardEvent) => void;
                to?: undefined;
            } | {
                to?: undefined;
                onClick?: undefined;
                role?: undefined;
                tabindex?: undefined;
                onKeydown?: undefined;
            }>;
            onRowClick: (event: Event) => void;
            onRowKeydown: (event: KeyboardEvent) => void;
            handleCheckboxClick: (event: MouseEvent) => void;
            getGridTemplateColumns: typeof import("./utils").getGridTemplateColumns;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
            ElCheckbox: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                ariaControls: StringConstructor;
                modelValue: {
                    type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                label: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                value: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                indeterminate: BooleanConstructor;
                disabled: {
                    type: BooleanConstructor;
                    default: undefined;
                };
                checked: BooleanConstructor;
                name: {
                    type: StringConstructor;
                    default: undefined;
                };
                trueValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                trueLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                id: {
                    type: StringConstructor;
                    default: undefined;
                };
                border: BooleanConstructor;
                size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                tabindex: (NumberConstructor | StringConstructor)[];
                validateEvent: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                ariaLabel: StringConstructor;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
            }, string, {
                label: string | number | boolean | Record<string, any>;
                disabled: boolean;
                border: boolean;
                value: string | number | boolean | Record<string, any>;
                id: string;
                name: string;
                modelValue: string | number | boolean;
                validateEvent: boolean;
                indeterminate: boolean;
                checked: boolean;
                trueValue: string | number;
                falseValue: string | number;
                trueLabel: string | number;
                falseLabel: string | number;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) & import("vue").ObjectPlugin & {
                CheckboxButton: {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                    ariaControls: StringConstructor;
                    modelValue: {
                        type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    label: {
                        type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    value: {
                        type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    indeterminate: BooleanConstructor;
                    disabled: {
                        type: BooleanConstructor;
                        default: undefined;
                    };
                    checked: BooleanConstructor;
                    name: {
                        type: StringConstructor;
                        default: undefined;
                    };
                    trueValue: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    falseValue: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    trueLabel: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    falseLabel: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    id: {
                        type: StringConstructor;
                        default: undefined;
                    };
                    border: BooleanConstructor;
                    size: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    tabindex: (NumberConstructor | StringConstructor)[];
                    validateEvent: {
                        type: BooleanConstructor;
                        default: boolean;
                    };
                    ariaLabel: StringConstructor;
                }>> & {
                    "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                    onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                    change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                }, string, {
                    label: string | number | boolean | Record<string, any>;
                    disabled: boolean;
                    border: boolean;
                    value: string | number | boolean | Record<string, any>;
                    id: string;
                    name: string;
                    modelValue: string | number | boolean;
                    validateEvent: boolean;
                    indeterminate: boolean;
                    checked: boolean;
                    trueValue: string | number;
                    falseValue: string | number;
                    trueLabel: string | number;
                    falseLabel: string | number;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                });
                CheckboxGroup: {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                    readonly ariaLabel: StringConstructor;
                    readonly modelValue: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
                    readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                    readonly min: NumberConstructor;
                    readonly max: NumberConstructor;
                    readonly size: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly fill: StringConstructor;
                    readonly textColor: StringConstructor;
                    readonly tag: import("element-plus/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
                    readonly validateEvent: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly options: {
                        readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly props: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }) | (() => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }) | ((new (...args: any[]) => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }) | (() => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }))[], unknown, unknown, () => Required<{
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }>, boolean>;
                    readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
                }>> & {
                    "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
                    onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
                }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
                    change: (val: import("element-plus").CheckboxValueType[]) => void;
                }, string, {
                    readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
                    readonly props: {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    };
                    readonly tag: string;
                    readonly modelValue: import("element-plus").CheckboxGroupValueType;
                    readonly validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                });
            };
            'zx-list-view-row-item': import("vue").DefineComponent<unknown, {
                Tooltip: import("vue").ComponentOptions<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions, any, any, any, string, {}, {}, string, {}, {}, {}, string, import("vue").ComponentProvideOptions> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | import("vue").FunctionalComponent<{}, {}, any, {}>;
                ns: {
                    namespace: import("vue").ComputedRef<string>;
                    b: (blockSuffix?: string) => string;
                    e: (element?: string) => string;
                    m: (modifier?: string) => string;
                    be: (blockSuffix?: string, element?: string) => string;
                    em: (element?: string, modifier?: string) => string;
                    bm: (blockSuffix?: string, modifier?: string) => string;
                    bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                    is: {
                        (name: string, state: boolean | undefined): string;
                        (name: string): string;
                    };
                    cssVar: (object: Record<string, string>) => Record<string, string>;
                    cssVarName: (name: string) => string;
                    cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                    cssVarBlockName: (name: string) => string;
                };
                list: import("vue").ComputedRef<any>;
                label: import("vue").ComputedRef<any>;
                tooltip: import("vue").ComputedRef<any>;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
                item: string | number | Record<string, any>;
                column: Record<string, any>;
                row: Record<string, any>;
                align: string;
                isSecondary: boolean;
            }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    'zx-list-view-groups': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
        getGroupStateKey: (group: any, index: number) => any;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
        'zx-list-view-group-header': import("vue").DefineComponent<unknown, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            toggleGroup: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "toggle"[], "toggle", import("vue").PublicProps, Readonly<unknown> & Readonly<{
            onToggle?: ((...args: any[]) => any) | undefined;
        }>, {
            collapsed: boolean;
        }, {}, {
            ElIcon: import("element-plus/es/utils").SFCWithInstall<{
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly color: {
                    readonly type: import("vue").PropType<string>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
            }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            })>;
            ArrowDown: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        'zx-list-view-group-rows': import("vue").DefineComponent<unknown, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            onEnter: (el: Element, done: () => void) => void;
            onLeave: (el: Element, done: () => void) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
            collapsed: boolean;
        }, {}, {
            'zx-list-view-row': import("vue").DefineComponent<unknown, {
                ns: {
                    namespace: import("vue").ComputedRef<string>;
                    b: (blockSuffix?: string) => string;
                    e: (element?: string) => string;
                    m: (modifier?: string) => string;
                    be: (blockSuffix?: string, element?: string) => string;
                    em: (element?: string, modifier?: string) => string;
                    bm: (blockSuffix?: string, modifier?: string) => string;
                    bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                    is: {
                        (name: string, state: boolean | undefined): string;
                        (name: string): string;
                    };
                    cssVar: (object: Record<string, string>) => Record<string, string>;
                    cssVarName: (name: string) => string;
                    cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                    cssVarBlockName: (name: string) => string;
                };
                list: import("vue").ComputedRef<any>;
                isSelected: import("vue").ComputedRef<any>;
                isActive: import("vue").ComputedRef<any>;
                hasRowActions: import("vue").ComputedRef<boolean>;
                rowActionsWidth: import("vue").ComputedRef<any>;
                rowHeight: import("vue").ComputedRef<any>;
                rowClasses: import("vue").ComputedRef<(string | {
                    [x: string]: any;
                })[]>;
                linkProps: import("vue").ComputedRef<{
                    to: any;
                    onClick: (event: Event) => void;
                    role?: undefined;
                    tabindex?: undefined;
                    onKeydown?: undefined;
                } | {
                    role: string;
                    tabindex: number;
                    onClick: (event: Event) => void;
                    onKeydown: (event: KeyboardEvent) => void;
                    to?: undefined;
                } | {
                    to?: undefined;
                    onClick?: undefined;
                    role?: undefined;
                    tabindex?: undefined;
                    onKeydown?: undefined;
                }>;
                onRowClick: (event: Event) => void;
                onRowKeydown: (event: KeyboardEvent) => void;
                handleCheckboxClick: (event: MouseEvent) => void;
                getGridTemplateColumns: typeof import("./utils").getGridTemplateColumns;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
                ElCheckbox: {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                    ariaControls: StringConstructor;
                    modelValue: {
                        type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    label: {
                        type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    value: {
                        type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    indeterminate: BooleanConstructor;
                    disabled: {
                        type: BooleanConstructor;
                        default: undefined;
                    };
                    checked: BooleanConstructor;
                    name: {
                        type: StringConstructor;
                        default: undefined;
                    };
                    trueValue: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    falseValue: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    trueLabel: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    falseLabel: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    id: {
                        type: StringConstructor;
                        default: undefined;
                    };
                    border: BooleanConstructor;
                    size: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    tabindex: (NumberConstructor | StringConstructor)[];
                    validateEvent: {
                        type: BooleanConstructor;
                        default: boolean;
                    };
                    ariaLabel: StringConstructor;
                }>> & {
                    "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                    onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                    change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                }, string, {
                    label: string | number | boolean | Record<string, any>;
                    disabled: boolean;
                    border: boolean;
                    value: string | number | boolean | Record<string, any>;
                    id: string;
                    name: string;
                    modelValue: string | number | boolean;
                    validateEvent: boolean;
                    indeterminate: boolean;
                    checked: boolean;
                    trueValue: string | number;
                    falseValue: string | number;
                    trueLabel: string | number;
                    falseLabel: string | number;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                }) & import("vue").ObjectPlugin & {
                    CheckboxButton: {
                        new (...args: any[]): any;
                        __isFragment?: never;
                        __isTeleport?: never;
                        __isSuspense?: never;
                    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                        ariaControls: StringConstructor;
                        modelValue: {
                            type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                            default: undefined;
                        };
                        label: {
                            type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                            default: undefined;
                        };
                        value: {
                            type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                            default: undefined;
                        };
                        indeterminate: BooleanConstructor;
                        disabled: {
                            type: BooleanConstructor;
                            default: undefined;
                        };
                        checked: BooleanConstructor;
                        name: {
                            type: StringConstructor;
                            default: undefined;
                        };
                        trueValue: {
                            type: (NumberConstructor | StringConstructor)[];
                            default: undefined;
                        };
                        falseValue: {
                            type: (NumberConstructor | StringConstructor)[];
                            default: undefined;
                        };
                        trueLabel: {
                            type: (NumberConstructor | StringConstructor)[];
                            default: undefined;
                        };
                        falseLabel: {
                            type: (NumberConstructor | StringConstructor)[];
                            default: undefined;
                        };
                        id: {
                            type: StringConstructor;
                            default: undefined;
                        };
                        border: BooleanConstructor;
                        size: {
                            readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                            readonly required: false;
                            readonly validator: ((val: unknown) => boolean) | undefined;
                            __epPropKey: true;
                        };
                        tabindex: (NumberConstructor | StringConstructor)[];
                        validateEvent: {
                            type: BooleanConstructor;
                            default: boolean;
                        };
                        ariaLabel: StringConstructor;
                    }>> & {
                        "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                        onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                    }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                        "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                        change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                    }, string, {
                        label: string | number | boolean | Record<string, any>;
                        disabled: boolean;
                        border: boolean;
                        value: string | number | boolean | Record<string, any>;
                        id: string;
                        name: string;
                        modelValue: string | number | boolean;
                        validateEvent: boolean;
                        indeterminate: boolean;
                        checked: boolean;
                        trueValue: string | number;
                        falseValue: string | number;
                        trueLabel: string | number;
                        falseLabel: string | number;
                    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                        $slots: {
                            default?: (props: {}) => any;
                        };
                    });
                    CheckboxGroup: {
                        new (...args: any[]): any;
                        __isFragment?: never;
                        __isTeleport?: never;
                        __isSuspense?: never;
                    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                        readonly ariaLabel: StringConstructor;
                        readonly modelValue: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
                        readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                        readonly min: NumberConstructor;
                        readonly max: NumberConstructor;
                        readonly size: {
                            readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                            readonly required: false;
                            readonly validator: ((val: unknown) => boolean) | undefined;
                            __epPropKey: true;
                        };
                        readonly fill: StringConstructor;
                        readonly textColor: StringConstructor;
                        readonly tag: import("element-plus/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
                        readonly validateEvent: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                        readonly options: {
                            readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                            readonly required: false;
                            readonly validator: ((val: unknown) => boolean) | undefined;
                            __epPropKey: true;
                        };
                        readonly props: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => {
                            value?: string;
                            label?: string;
                            disabled?: string;
                        }) | (() => {
                            value?: string;
                            label?: string;
                            disabled?: string;
                        }) | ((new (...args: any[]) => {
                            value?: string;
                            label?: string;
                            disabled?: string;
                        }) | (() => {
                            value?: string;
                            label?: string;
                            disabled?: string;
                        }))[], unknown, unknown, () => Required<{
                            value?: string;
                            label?: string;
                            disabled?: string;
                        }>, boolean>;
                        readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
                    }>> & {
                        "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
                        onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
                    }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                        "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
                        change: (val: import("element-plus").CheckboxValueType[]) => void;
                    }, string, {
                        readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                        readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
                        readonly props: {
                            value?: string;
                            label?: string;
                            disabled?: string;
                        };
                        readonly tag: string;
                        readonly modelValue: import("element-plus").CheckboxGroupValueType;
                        readonly validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                        $slots: {
                            default?: (props: {}) => any;
                        };
                    });
                };
                'zx-list-view-row-item': import("vue").DefineComponent<unknown, {
                    Tooltip: import("vue").ComponentOptions<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions, any, any, any, string, {}, {}, string, {}, {}, {}, string, import("vue").ComponentProvideOptions> | {
                        new (...args: any[]): any;
                        __isFragment?: never;
                        __isTeleport?: never;
                        __isSuspense?: never;
                    } | import("vue").FunctionalComponent<{}, {}, any, {}>;
                    ns: {
                        namespace: import("vue").ComputedRef<string>;
                        b: (blockSuffix?: string) => string;
                        e: (element?: string) => string;
                        m: (modifier?: string) => string;
                        be: (blockSuffix?: string, element?: string) => string;
                        em: (element?: string, modifier?: string) => string;
                        bm: (blockSuffix?: string, modifier?: string) => string;
                        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                        is: {
                            (name: string, state: boolean | undefined): string;
                            (name: string): string;
                        };
                        cssVar: (object: Record<string, string>) => Record<string, string>;
                        cssVarName: (name: string) => string;
                        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                        cssVarBlockName: (name: string) => string;
                    };
                    list: import("vue").ComputedRef<any>;
                    label: import("vue").ComputedRef<any>;
                    tooltip: import("vue").ComputedRef<any>;
                }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
                    item: string | number | Record<string, any>;
                    column: Record<string, any>;
                    row: Record<string, any>;
                    align: string;
                    isSecondary: boolean;
                }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
            }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    'zx-list-view-virtual-rows': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
        viewportRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
        onScroll: (event: Event) => void;
        totalHeight: import("vue").ComputedRef<number>;
        offsetTop: import("vue").ComputedRef<number>;
        visibleItems: import("vue").ComputedRef<({
            type: "row";
            key: string;
            row: any;
            height: number;
        } | {
            type: "group";
            key: string;
            group: any;
            groupIndex: number;
            collapsed: boolean;
            height: number;
        })[]>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
        'zx-list-view-row': import("vue").DefineComponent<unknown, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            isSelected: import("vue").ComputedRef<any>;
            isActive: import("vue").ComputedRef<any>;
            hasRowActions: import("vue").ComputedRef<boolean>;
            rowActionsWidth: import("vue").ComputedRef<any>;
            rowHeight: import("vue").ComputedRef<any>;
            rowClasses: import("vue").ComputedRef<(string | {
                [x: string]: any;
            })[]>;
            linkProps: import("vue").ComputedRef<{
                to: any;
                onClick: (event: Event) => void;
                role?: undefined;
                tabindex?: undefined;
                onKeydown?: undefined;
            } | {
                role: string;
                tabindex: number;
                onClick: (event: Event) => void;
                onKeydown: (event: KeyboardEvent) => void;
                to?: undefined;
            } | {
                to?: undefined;
                onClick?: undefined;
                role?: undefined;
                tabindex?: undefined;
                onKeydown?: undefined;
            }>;
            onRowClick: (event: Event) => void;
            onRowKeydown: (event: KeyboardEvent) => void;
            handleCheckboxClick: (event: MouseEvent) => void;
            getGridTemplateColumns: typeof import("./utils").getGridTemplateColumns;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
            ElCheckbox: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                ariaControls: StringConstructor;
                modelValue: {
                    type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                label: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                value: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                indeterminate: BooleanConstructor;
                disabled: {
                    type: BooleanConstructor;
                    default: undefined;
                };
                checked: BooleanConstructor;
                name: {
                    type: StringConstructor;
                    default: undefined;
                };
                trueValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                trueLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                id: {
                    type: StringConstructor;
                    default: undefined;
                };
                border: BooleanConstructor;
                size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                tabindex: (NumberConstructor | StringConstructor)[];
                validateEvent: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                ariaLabel: StringConstructor;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
            }, string, {
                label: string | number | boolean | Record<string, any>;
                disabled: boolean;
                border: boolean;
                value: string | number | boolean | Record<string, any>;
                id: string;
                name: string;
                modelValue: string | number | boolean;
                validateEvent: boolean;
                indeterminate: boolean;
                checked: boolean;
                trueValue: string | number;
                falseValue: string | number;
                trueLabel: string | number;
                falseLabel: string | number;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            }) & import("vue").ObjectPlugin & {
                CheckboxButton: {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                    ariaControls: StringConstructor;
                    modelValue: {
                        type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    label: {
                        type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    value: {
                        type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                        default: undefined;
                    };
                    indeterminate: BooleanConstructor;
                    disabled: {
                        type: BooleanConstructor;
                        default: undefined;
                    };
                    checked: BooleanConstructor;
                    name: {
                        type: StringConstructor;
                        default: undefined;
                    };
                    trueValue: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    falseValue: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    trueLabel: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    falseLabel: {
                        type: (NumberConstructor | StringConstructor)[];
                        default: undefined;
                    };
                    id: {
                        type: StringConstructor;
                        default: undefined;
                    };
                    border: BooleanConstructor;
                    size: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    tabindex: (NumberConstructor | StringConstructor)[];
                    validateEvent: {
                        type: BooleanConstructor;
                        default: boolean;
                    };
                    ariaLabel: StringConstructor;
                }>> & {
                    "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                    onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                    change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                }, string, {
                    label: string | number | boolean | Record<string, any>;
                    disabled: boolean;
                    border: boolean;
                    value: string | number | boolean | Record<string, any>;
                    id: string;
                    name: string;
                    modelValue: string | number | boolean;
                    validateEvent: boolean;
                    indeterminate: boolean;
                    checked: boolean;
                    trueValue: string | number;
                    falseValue: string | number;
                    trueLabel: string | number;
                    falseLabel: string | number;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                });
                CheckboxGroup: {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                    readonly ariaLabel: StringConstructor;
                    readonly modelValue: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
                    readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                    readonly min: NumberConstructor;
                    readonly max: NumberConstructor;
                    readonly size: {
                        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly fill: StringConstructor;
                    readonly textColor: StringConstructor;
                    readonly tag: import("element-plus/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
                    readonly validateEvent: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                    readonly options: {
                        readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                        readonly required: false;
                        readonly validator: ((val: unknown) => boolean) | undefined;
                        __epPropKey: true;
                    };
                    readonly props: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }) | (() => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }) | ((new (...args: any[]) => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }) | (() => {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }))[], unknown, unknown, () => Required<{
                        value?: string;
                        label?: string;
                        disabled?: string;
                    }>, boolean>;
                    readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
                }>> & {
                    "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
                    onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
                }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                    "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
                    change: (val: import("element-plus").CheckboxValueType[]) => void;
                }, string, {
                    readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                    readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
                    readonly props: {
                        value?: string;
                        label?: string;
                        disabled?: string;
                    };
                    readonly tag: string;
                    readonly modelValue: import("element-plus").CheckboxGroupValueType;
                    readonly validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                    $slots: {
                        default?: (props: {}) => any;
                    };
                });
            };
            'zx-list-view-row-item': import("vue").DefineComponent<unknown, {
                Tooltip: import("vue").ComponentOptions<any, any, any, import("vue").ComputedOptions, import("vue").MethodOptions, any, any, any, string, {}, {}, string, {}, {}, {}, string, import("vue").ComponentProvideOptions> | {
                    new (...args: any[]): any;
                    __isFragment?: never;
                    __isTeleport?: never;
                    __isSuspense?: never;
                } | import("vue").FunctionalComponent<{}, {}, any, {}>;
                ns: {
                    namespace: import("vue").ComputedRef<string>;
                    b: (blockSuffix?: string) => string;
                    e: (element?: string) => string;
                    m: (modifier?: string) => string;
                    be: (blockSuffix?: string, element?: string) => string;
                    em: (element?: string, modifier?: string) => string;
                    bm: (blockSuffix?: string, modifier?: string) => string;
                    bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                    is: {
                        (name: string, state: boolean | undefined): string;
                        (name: string): string;
                    };
                    cssVar: (object: Record<string, string>) => Record<string, string>;
                    cssVarName: (name: string) => string;
                    cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                    cssVarBlockName: (name: string) => string;
                };
                list: import("vue").ComputedRef<any>;
                label: import("vue").ComputedRef<any>;
                tooltip: import("vue").ComputedRef<any>;
            }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
                item: string | number | Record<string, any>;
                column: Record<string, any>;
                row: Record<string, any>;
                align: string;
                isSecondary: boolean;
            }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        'zx-list-view-group-header': import("vue").DefineComponent<unknown, {
            ns: {
                namespace: import("vue").ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            list: import("vue").ComputedRef<any>;
            toggleGroup: () => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "toggle"[], "toggle", import("vue").PublicProps, Readonly<unknown> & Readonly<{
            onToggle?: ((...args: any[]) => any) | undefined;
        }>, {
            collapsed: boolean;
        }, {}, {
            ElIcon: import("element-plus/es/utils").SFCWithInstall<{
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly color: {
                    readonly type: import("vue").PropType<string>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
            }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            })>;
            ArrowDown: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    'zx-list-view-select-banner': import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        list: import("vue").ComputedRef<any>;
        selectedText: import("vue").ComputedRef<any>;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
        ElButton: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly nativeType: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "reset" | "submit", unknown, "button", boolean>;
            readonly loading: BooleanConstructor;
            readonly loadingIcon: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, () => any, boolean>;
            readonly plain: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly text: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly link: BooleanConstructor;
            readonly bg: BooleanConstructor;
            readonly autofocus: BooleanConstructor;
            readonly round: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly circle: BooleanConstructor;
            readonly color: StringConstructor;
            readonly dark: BooleanConstructor;
            readonly autoInsertSpace: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly tag: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, "button", boolean>;
        }>> & {
            onClick?: ((evt: MouseEvent) => any) | undefined;
        }, {
            ref: import("vue").Ref<HTMLButtonElement | undefined>;
            size: import("vue").ComputedRef<"" | "small" | "default" | "large">;
            type: import("vue").ComputedRef<string>;
            disabled: import("vue").ComputedRef<boolean>;
            shouldAddSpace: import("vue").ComputedRef<boolean>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            click: (evt: MouseEvent) => void;
        }, string, {
            readonly link: boolean;
            readonly circle: boolean;
            readonly text: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly round: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly dark: boolean;
            readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
            readonly bg: boolean;
            readonly tag: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
            readonly loading: boolean;
            readonly autofocus: boolean;
            readonly plain: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly autoInsertSpace: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly nativeType: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "reset" | "submit", unknown>;
            readonly loadingIcon: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                loading?: (props: {}) => any;
            } & {
                icon?: (props: {}) => any;
            } & {
                default?: (props: {}) => any;
            };
        }) & import("vue").ObjectPlugin & {
            ButtonGroup: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
                readonly direction: {
                    readonly type: import("vue").PropType<"horizontal" | "vertical">;
                    readonly values: readonly ["horizontal", "vertical"];
                    readonly default: "horizontal";
                };
            }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
                readonly direction: "horizontal" | "vertical";
                readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
        };
        ElCheckbox: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            ariaControls: StringConstructor;
            modelValue: {
                type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            label: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            value: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            indeterminate: BooleanConstructor;
            disabled: {
                type: BooleanConstructor;
                default: undefined;
            };
            checked: BooleanConstructor;
            name: {
                type: StringConstructor;
                default: undefined;
            };
            trueValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            trueLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            id: {
                type: StringConstructor;
                default: undefined;
            };
            border: BooleanConstructor;
            size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            tabindex: (NumberConstructor | StringConstructor)[];
            validateEvent: {
                type: BooleanConstructor;
                default: boolean;
            };
            ariaLabel: StringConstructor;
        }>> & {
            "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
            onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
        }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
            change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
        }, string, {
            label: string | number | boolean | Record<string, any>;
            disabled: boolean;
            border: boolean;
            value: string | number | boolean | Record<string, any>;
            id: string;
            name: string;
            modelValue: string | number | boolean;
            validateEvent: boolean;
            indeterminate: boolean;
            checked: boolean;
            trueValue: string | number;
            falseValue: string | number;
            trueLabel: string | number;
            falseLabel: string | number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        }) & import("vue").ObjectPlugin & {
            CheckboxButton: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                ariaControls: StringConstructor;
                modelValue: {
                    type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                label: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                value: {
                    type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                    default: undefined;
                };
                indeterminate: BooleanConstructor;
                disabled: {
                    type: BooleanConstructor;
                    default: undefined;
                };
                checked: BooleanConstructor;
                name: {
                    type: StringConstructor;
                    default: undefined;
                };
                trueValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseValue: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                trueLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                falseLabel: {
                    type: (NumberConstructor | StringConstructor)[];
                    default: undefined;
                };
                id: {
                    type: StringConstructor;
                    default: undefined;
                };
                border: BooleanConstructor;
                size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                tabindex: (NumberConstructor | StringConstructor)[];
                validateEvent: {
                    type: BooleanConstructor;
                    default: boolean;
                };
                ariaLabel: StringConstructor;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
                onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
                change: (val: import("element-plus/es/components/checkbox/src/checkbox").CheckboxValueType) => void;
            }, string, {
                label: string | number | boolean | Record<string, any>;
                disabled: boolean;
                border: boolean;
                value: string | number | boolean | Record<string, any>;
                id: string;
                name: string;
                modelValue: string | number | boolean;
                validateEvent: boolean;
                indeterminate: boolean;
                checked: boolean;
                trueValue: string | number;
                falseValue: string | number;
                trueLabel: string | number;
                falseLabel: string | number;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
            CheckboxGroup: {
                new (...args: any[]): any;
                __isFragment?: never;
                __isTeleport?: never;
                __isSuspense?: never;
            } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
                readonly ariaLabel: StringConstructor;
                readonly modelValue: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
                readonly disabled: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
                readonly min: NumberConstructor;
                readonly max: NumberConstructor;
                readonly size: {
                    readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly fill: StringConstructor;
                readonly textColor: StringConstructor;
                readonly tag: import("element-plus/es/utils").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
                readonly validateEvent: import("element-plus/es/utils").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
                readonly options: {
                    readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                    readonly required: false;
                    readonly validator: ((val: unknown) => boolean) | undefined;
                    __epPropKey: true;
                };
                readonly props: import("element-plus/es/utils").EpPropFinalized<(new (...args: any[]) => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | (() => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | ((new (...args: any[]) => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }) | (() => {
                    value?: string;
                    label?: string;
                    disabled?: string;
                }))[], unknown, unknown, () => Required<{
                    value?: string;
                    label?: string;
                    disabled?: string;
                }>, boolean>;
                readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
            }>> & {
                "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
                onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
            }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
                "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
                change: (val: import("element-plus").CheckboxValueType[]) => void;
            }, string, {
                readonly disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
                readonly props: {
                    value?: string;
                    label?: string;
                    disabled?: string;
                };
                readonly tag: string;
                readonly modelValue: import("element-plus").CheckboxGroupValueType;
                readonly validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
                $slots: {
                    default?: (props: {}) => any;
                };
            });
        };
        ElIcon: import("element-plus/es/utils").SFCWithInstall<{
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly color: {
                readonly type: import("vue").PropType<string>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        })>;
        Close: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
