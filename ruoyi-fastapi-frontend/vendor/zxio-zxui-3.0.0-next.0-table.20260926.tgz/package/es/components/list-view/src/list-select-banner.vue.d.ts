declare const _default: import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    list: import("vue").ComputedRef<any>;
    selectedText: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
    ElButton: {
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
        readonly icon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly nativeType: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "button" | "reset" | "submit", unknown, "button", boolean>;
        readonly loading: BooleanConstructor;
        readonly loadingIcon: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, () => any, boolean>;
        readonly plain: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly text: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly link: BooleanConstructor;
        readonly bg: BooleanConstructor;
        readonly autofocus: BooleanConstructor;
        readonly round: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly circle: BooleanConstructor;
        readonly color: StringConstructor;
        readonly dark: BooleanConstructor;
        readonly autoInsertSpace: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly tag: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, "button", boolean>;
    }>> & {
        onClick?: ((evt: MouseEvent) => any) | undefined;
    }, {
        ref: import("vue").Ref<HTMLButtonElement | undefined>;
        size: import("vue").ComputedRef<"" | "small" | "default" | "large">;
        type: import("vue").ComputedRef<string>;
        disabled: import("vue").ComputedRef<boolean>;
        shouldAddSpace: import("vue").ComputedRef<boolean>;
    }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        click: (evt: MouseEvent) => void;
    }, string, {
        readonly link: boolean;
        readonly circle: boolean;
        readonly text: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly round: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly dark: boolean;
        readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
        readonly bg: boolean;
        readonly tag: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
        readonly loading: boolean;
        readonly autofocus: boolean;
        readonly plain: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly autoInsertSpace: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly nativeType: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "button" | "reset" | "submit", unknown>;
        readonly loadingIcon: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            loading?: (props: {}) => any;
        } & {
            icon?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        };
    }) & import("vue").ObjectPlugin & {
        ButtonGroup: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
            readonly direction: {
                readonly type: import("vue").PropType<"horizontal" | "vertical">;
                readonly values: readonly ["horizontal", "vertical"];
                readonly default: "horizontal";
            };
        }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            readonly direction: "horizontal" | "vertical";
            readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        });
    };
    ElCheckbox: {
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        ariaControls: StringConstructor;
        modelValue: {
            type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
            default: undefined;
        };
        label: {
            type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
            default: undefined;
        };
        value: {
            type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
            default: undefined;
        };
        indeterminate: BooleanConstructor;
        disabled: {
            type: BooleanConstructor;
            default: undefined;
        };
        checked: BooleanConstructor;
        name: {
            type: StringConstructor;
            default: undefined;
        };
        trueValue: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        falseValue: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        trueLabel: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        falseLabel: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        id: {
            type: StringConstructor;
            default: undefined;
        };
        border: BooleanConstructor;
        size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        tabindex: (NumberConstructor | StringConstructor)[];
        validateEvent: {
            type: BooleanConstructor;
            default: boolean;
        };
        ariaLabel: StringConstructor;
    }>> & {
        "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
        onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
    }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
        change: (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
    }, string, {
        label: string | number | boolean | Record<string, any>;
        disabled: boolean;
        border: boolean;
        value: string | number | boolean | Record<string, any>;
        id: string;
        name: string;
        modelValue: string | number | boolean;
        validateEvent: boolean;
        indeterminate: boolean;
        checked: boolean;
        trueValue: string | number;
        falseValue: string | number;
        trueLabel: string | number;
        falseLabel: string | number;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            default?: (props: {}) => any;
        };
    }) & import("vue").ObjectPlugin & {
        CheckboxButton: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            ariaControls: StringConstructor;
            modelValue: {
                type: (NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            label: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            value: {
                type: (ObjectConstructor | NumberConstructor | StringConstructor | BooleanConstructor)[];
                default: undefined;
            };
            indeterminate: BooleanConstructor;
            disabled: {
                type: BooleanConstructor;
                default: undefined;
            };
            checked: BooleanConstructor;
            name: {
                type: StringConstructor;
                default: undefined;
            };
            trueValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseValue: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            trueLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            falseLabel: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            id: {
                type: StringConstructor;
                default: undefined;
            };
            border: BooleanConstructor;
            size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            tabindex: (NumberConstructor | StringConstructor)[];
            validateEvent: {
                type: BooleanConstructor;
                default: boolean;
            };
            ariaLabel: StringConstructor;
        }>> & {
            "onUpdate:modelValue"?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
            onChange?: ((val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => any) | undefined;
        }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
            change: (val: import("element-plus/es/components/checkbox/src/checkbox.js").CheckboxValueType) => void;
        }, string, {
            label: string | number | boolean | Record<string, any>;
            disabled: boolean;
            border: boolean;
            value: string | number | boolean | Record<string, any>;
            id: string;
            name: string;
            modelValue: string | number | boolean;
            validateEvent: boolean;
            indeterminate: boolean;
            checked: boolean;
            trueValue: string | number;
            falseValue: string | number;
            trueLabel: string | number;
            falseLabel: string | number;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        });
        CheckboxGroup: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly ariaLabel: StringConstructor;
            readonly modelValue: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType) | ((new (...args: any[]) => import("element-plus").CheckboxGroupValueType) | (() => import("element-plus").CheckboxGroupValueType))[], unknown, unknown, () => never[], boolean>;
            readonly disabled: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly min: NumberConstructor;
            readonly max: NumberConstructor;
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly fill: StringConstructor;
            readonly textColor: StringConstructor;
            readonly tag: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
            readonly validateEvent: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly options: {
                readonly type: import("vue").PropType<import("element-plus").CheckboxOption[]>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly props: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => {
                value?: string;
                label?: string;
                disabled?: string;
            }) | (() => {
                value?: string;
                label?: string;
                disabled?: string;
            }) | ((new (...args: any[]) => {
                value?: string;
                label?: string;
                disabled?: string;
            }) | (() => {
                value?: string;
                label?: string;
                disabled?: string;
            }))[], unknown, unknown, () => Required<{
                value?: string;
                label?: string;
                disabled?: string;
            }>, boolean>;
            readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "button" | "checkbox", unknown, "checkbox", boolean>;
        }>> & {
            "onUpdate:modelValue"?: ((val: import("element-plus").CheckboxGroupValueType) => any) | undefined;
            onChange?: ((val: import("element-plus").CheckboxValueType[]) => any) | undefined;
        }, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            "update:modelValue": (val: import("element-plus").CheckboxGroupValueType) => void;
            change: (val: import("element-plus").CheckboxValueType[]) => void;
        }, string, {
            readonly disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "button" | "checkbox", unknown>;
            readonly props: {
                value?: string;
                label?: string;
                disabled?: string;
            };
            readonly tag: string;
            readonly modelValue: import("element-plus").CheckboxGroupValueType;
            readonly validateEvent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        });
    };
    ElIcon: import("element-plus/es/utils/index.js").SFCWithInstall<{
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly color: {
            readonly type: import("vue").PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            default?: (props: {}) => any;
        };
    })>;
    Close: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
