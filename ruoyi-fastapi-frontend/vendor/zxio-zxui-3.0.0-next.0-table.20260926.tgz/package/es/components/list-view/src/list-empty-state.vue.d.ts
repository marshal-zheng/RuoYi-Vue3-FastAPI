declare const _default: import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    list: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {
    ElButton: {
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
        readonly icon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly nativeType: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "button" | "reset" | "submit", unknown, "button", boolean>;
        readonly loading: BooleanConstructor;
        readonly loadingIcon: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, () => any, boolean>;
        readonly plain: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly text: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly link: BooleanConstructor;
        readonly bg: BooleanConstructor;
        readonly autofocus: BooleanConstructor;
        readonly round: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly circle: BooleanConstructor;
        readonly color: StringConstructor;
        readonly dark: BooleanConstructor;
        readonly autoInsertSpace: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly tag: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown, "button", boolean>;
    }>> & {
        onClick?: ((evt: MouseEvent) => any) | undefined;
    }, {
        ref: import("vue").Ref<HTMLButtonElement | undefined>;
        size: import("vue").ComputedRef<"" | "small" | "default" | "large">;
        type: import("vue").ComputedRef<string>;
        disabled: import("vue").ComputedRef<boolean>;
        shouldAddSpace: import("vue").ComputedRef<boolean>;
    }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        click: (evt: MouseEvent) => void;
    }, string, {
        readonly link: boolean;
        readonly circle: boolean;
        readonly text: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly round: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly dark: boolean;
        readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
        readonly bg: boolean;
        readonly tag: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
        readonly loading: boolean;
        readonly autofocus: boolean;
        readonly plain: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly autoInsertSpace: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly nativeType: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "button" | "reset" | "submit", unknown>;
        readonly loadingIcon: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            loading?: (props: {}) => any;
        } & {
            icon?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        };
    }) & import("vue").ObjectPlugin & {
        ButtonGroup: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly size: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
            readonly direction: {
                readonly type: import("vue").PropType<"horizontal" | "vertical">;
                readonly values: readonly ["horizontal", "vertical"];
                readonly default: "horizontal";
            };
        }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            readonly direction: "horizontal" | "vertical";
            readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        });
    };
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
