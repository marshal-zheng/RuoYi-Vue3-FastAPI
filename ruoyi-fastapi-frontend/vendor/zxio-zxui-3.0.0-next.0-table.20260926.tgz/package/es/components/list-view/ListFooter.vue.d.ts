import Component from './src/list-footer.vue';
export default Component;
