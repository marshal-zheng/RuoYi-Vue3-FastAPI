import Component from './src/list-empty-state.vue';
export default Component;
