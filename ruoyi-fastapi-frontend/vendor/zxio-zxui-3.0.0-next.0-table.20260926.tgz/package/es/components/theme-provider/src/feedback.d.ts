import type { MessageParams } from 'element-plus/es/components/message/index';
import type { ElMessageBoxOptions, MessageBoxData } from 'element-plus/es/components/message-box/index';
import type { NotificationParams } from 'element-plus/es/components/notification/index';
import type { ThemeAppHandle, ThemeFeedbackHandle, ThemeRuntimePort, ThemeRuntimeResult, ThemeScopeHandle } from './types';
export interface ThemeMessageBoxOptions extends Partial<ElMessageBoxOptions> {
    readonly onVanish?: () => void;
}
export interface ThemeFeedback {
    message(options: MessageParams): Promise<ThemeRuntimeResult<ThemeFeedbackHandle>>;
    notification(options: NotificationParams): Promise<ThemeRuntimeResult<ThemeFeedbackHandle>>;
    confirm(options: ThemeMessageBoxOptions): Promise<ThemeRuntimeResult<MessageBoxData>>;
}
export declare function createThemeFeedback(runtime: ThemeRuntimePort, owner: ThemeAppHandle | ThemeScopeHandle): ThemeRuntimeResult<ThemeFeedback>;
export declare function useThemeFeedback(): ThemeRuntimeResult<ThemeFeedback>;
