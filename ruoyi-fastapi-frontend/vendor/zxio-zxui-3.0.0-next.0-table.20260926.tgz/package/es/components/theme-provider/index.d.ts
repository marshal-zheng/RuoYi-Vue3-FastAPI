import ThemeProvider from './src/theme-provider.vue';
import type { App, Component } from 'vue';
type ThemeProviderWithInstall = typeof ThemeProvider & Component & {
    install(app: App): void;
};
export declare const ZxThemeProvider: ThemeProviderWithInstall;
export default ZxThemeProvider;
export { preparedSsrThemeScopeKey, preparedThemeScopeKey, themeAppKey, themePortalBindingKey, themePortalTargetKey, themeRuntimeKey, themeScopeKey, themeSsrRuntimeKey, } from './src/context';
export { ThemeRuntimeVueError } from './src/theme-runtime-vue-error';
export { adoptHydratedThemeScope, completeThemeHydration, } from './src/hydration-coordinator';
export { createThemeFeedback, useThemeFeedback } from './src/feedback';
export type { ThemeFeedback, ThemeMessageBoxOptions } from './src/feedback';
export { useThemeApp, useThemeRuntime, useThemeScope, usePreparedThemeConsumption, } from './src/use-theme-scope';
export { useRequiredThemePortalBinding } from './src/use-theme-portal-binding';
export * from './src/types';
