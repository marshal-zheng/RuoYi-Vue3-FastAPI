import { type SFCWithInstall } from '@zxio/shared';
import GridList from './src/grid-list.vue';
export declare const ZxGridList: SFCWithInstall<typeof GridList>;
export default ZxGridList;
export * from './src/props';
export type { ZxGridListInstance } from './src/instance';
