import type { GridListState } from './props';
export type ZxGridListInstance = {
    loadData: (params?: any, options?: any) => any;
    refresh: (options?: any) => any;
    state: Readonly<GridListState>;
};
