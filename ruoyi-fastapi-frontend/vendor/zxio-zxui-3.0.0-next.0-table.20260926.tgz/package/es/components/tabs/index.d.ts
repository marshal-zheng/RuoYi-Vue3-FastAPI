export declare const ZxTabs: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    activeKey: import("vue").Ref<string, string>;
    sortedItems: import("vue").ComputedRef<any[]>;
    handleTabClick: (tab: any, event: Event) => void;
    handleTabRemove: (key: string | number) => any;
    handleTabAdd: () => any;
    handleEdit: (targetName: string | number | undefined, action: "add" | "remove") => any;
    handleComponentMounted: (instance: any) => any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("update:modelValue" | "tab-click" | "tab-remove" | "tab-add" | "edit" | "drag-ended" | "component-mounted")[], "update:modelValue" | "tab-click" | "tab-remove" | "tab-add" | "edit" | "drag-ended" | "component-mounted", import("vue").PublicProps, Readonly<unknown> & Readonly<{
    "onUpdate:modelValue"?: ((...args: any[]) => any) | undefined;
    onEdit?: ((...args: any[]) => any) | undefined;
    "onTab-click"?: ((...args: any[]) => any) | undefined;
    "onTab-remove"?: ((...args: any[]) => any) | undefined;
    "onTab-add"?: ((...args: any[]) => any) | undefined;
    "onDrag-ended"?: ((...args: any[]) => any) | undefined;
    "onComponent-mounted"?: ((...args: any[]) => any) | undefined;
}>, {
    fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    lazy: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    items: import("./src/props").ZxTabsItem[];
    trackTabRecord: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    useUrlParams: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    paramName: string;
    contentTransition: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide") | (((new (...args: any[]) => "none" | "fade" | "slide") | (() => "none" | "fade" | "slide")) | null)[], unknown, unknown>;
}, {}, {
    ElTabs: {
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly type: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "" | "card" | "border-card", unknown, "", boolean>;
        readonly closable: BooleanConstructor;
        readonly addable: BooleanConstructor;
        readonly modelValue: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly defaultValue: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly editable: BooleanConstructor;
        readonly tabPosition: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "left" | "right" | "top" | "bottom", unknown, "top", boolean>;
        readonly beforeLeave: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>) | {
            (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>) | (() => (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>) | {
            (): (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => true, boolean>;
        readonly stretch: BooleanConstructor;
        readonly tabindex: import("element-plus/es/utils/index.js").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, 0, boolean>;
    }>> & {
        "onUpdate:modelValue"?: ((name: import("element-plus").TabPaneName) => any) | undefined;
        onTabClick?: ((pane: {
            uid: number;
            getVnode: () => import("vue").VNode;
            slots: import("vue").Slots;
            props: {
                readonly label: string;
                readonly disabled: boolean;
                readonly lazy: boolean;
                readonly name?: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined;
                readonly closable?: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
            };
            paneName: import("element-plus").TabPaneName | undefined;
            active: boolean;
            index: string | undefined;
            isClosable: boolean;
            isFocusInsidePane: () => boolean | undefined;
        }, ev: Event) => any) | undefined;
        onTabRemove?: ((name: import("element-plus").TabPaneName) => any) | undefined;
        onTabChange?: ((name: import("element-plus").TabPaneName) => any) | undefined;
        onEdit?: ((paneName: import("element-plus").TabPaneName | undefined, action: "add" | "remove") => any) | undefined;
        onTabAdd?: (() => any) | undefined;
    }, () => import("vue/jsx-runtime").JSX.Element, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        "update:modelValue": (name: import("element-plus").TabPaneName) => name is string | number;
        tabClick: (pane: import("element-plus").TabsPaneContext, ev: Event) => boolean;
        tabChange: (name: import("element-plus").TabPaneName) => name is string | number;
        edit: (paneName: import("element-plus").TabPaneName | undefined, action: "remove" | "add") => boolean;
        tabRemove: (name: import("element-plus").TabPaneName) => name is string | number;
        tabAdd: () => boolean;
    }, string, {
        readonly tabindex: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
        readonly stretch: boolean;
        readonly type: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "card" | "border-card", unknown>;
        readonly closable: boolean;
        readonly beforeLeave: (newName: import("element-plus").TabPaneName, oldName: import("element-plus").TabPaneName) => import("element-plus/es/utils/typescript.js").Awaitable<void | boolean>;
        readonly editable: boolean;
        readonly tabPosition: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "left" | "right" | "top" | "bottom", unknown>;
        readonly addable: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        TabPane: {
            new (...args: any[]): any;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly label: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly name: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly closable: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
            readonly disabled: BooleanConstructor;
            readonly lazy: BooleanConstructor;
        }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            readonly label: string;
            readonly disabled: boolean;
            readonly closable: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly lazy: boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
            $slots: {
                default?: (props: {}) => any;
            };
        });
    };
    ElTabPane: import("element-plus/es/utils/index.js").SFCWithInstall<{
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly label: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly name: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly closable: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly disabled: BooleanConstructor;
        readonly lazy: BooleanConstructor;
    }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
        readonly label: string;
        readonly disabled: boolean;
        readonly closable: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly lazy: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            default?: (props: {}) => any;
        };
    })>;
    ElIcon: import("element-plus/es/utils/index.js").SFCWithInstall<{
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly size: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly color: {
            readonly type: import("vue").PropType<string>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & (new () => {
        $slots: {
            default?: (props: {}) => any;
        };
    })>;
    Loading: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxTabs;
export * from './src/props';
export * from './src/instance';
