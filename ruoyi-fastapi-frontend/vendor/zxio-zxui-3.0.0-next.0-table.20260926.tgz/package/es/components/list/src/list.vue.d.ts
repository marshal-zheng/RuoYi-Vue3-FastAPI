import type { VNode } from 'vue';
import type { ActionItem } from '../../more-action';
import type { ListItem, ListItemKey } from './props';
interface ZxListSlots {
    default?: () => VNode[];
    item?: (scope: {
        item: ListItem;
        index: number;
    }) => VNode[];
    title?: (scope: {
        item: ListItem;
        index: number;
    }) => VNode[];
    description?: (scope: {
        item: ListItem;
        index: number;
    }) => VNode[];
    'item-action'?: (scope: {
        item: ListItem;
        index: number;
    }) => VNode[];
    /** @deprecated Use the `item-action` slot. */
    itemAction?: (scope: {
        item: ListItem;
        index: number;
    }) => VNode[];
    empty?: () => VNode[];
}
type __VLS_Slots = ZxListSlots;
declare const __VLS_component: import("vue").DefineComponent<unknown, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    readonly data: ListItem[];
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly emptyText: string;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly maxHeight: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly itemKey: string;
    readonly focusItemKey: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => ListItemKey) | (((new (...args: any[]) => string | number) | (() => ListItemKey)) | null)[], unknown, unknown>;
    readonly itemActions: ActionItem[];
    readonly noMoreData: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noMoreText: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
