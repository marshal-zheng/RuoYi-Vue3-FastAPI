import type { Ref } from 'vue';
import type { ZxDialogProps } from '../../dialog/src/props';
import type { DialogConfirmContext } from '../../dialog/src/constants';
import type { ZxDialogExpose } from '../../dialog/src/instance';
type MaybeRef<T> = T | Ref<T>;
declare const OPTION_KEYS: readonly ["width", "height", "dialogSize", "subtitle", "showCancel", "showContinue", "showClose", "showFullScreen", "showBack", "fullscreenShortcut", "destroyOnClose", "modal", "modalClass", "closeOnClickModal", "closeOnPressEscape", "footer", "noTitle", "noContentPadding", "dialogStyle", "headerPadding", "bodyPadding", "footerPadding", "draggable", "titleTag", "titleTagColor", "descriptions", "loading", "loadingType", "loadingText", "loadingBackground", "showSkeleton", "okText", "cancelText", "saveContinueText", "prevText", "nextText", "submitText", "locale", "formRef", "autoResetForm", "preValidate", "autoScrollToError", "scrollErrorOffset", "confirmOnDirty", "enableSteps", "currentStep", "totalSteps", "stepFields", "validateStep", "buttons", "buttonAlign", "beforeSave", "afterSave", "beforeClose", "debounce", "throttle", "appendTo"];
type BindableOptions = {
    [K in (typeof OPTION_KEYS)[number]]?: MaybeRef<ZxDialogProps[K] | undefined>;
};
export interface DialogOptions<T = Record<string, unknown>> extends BindableOptions {
    title?: MaybeRef<string | ((data: T) => string)>;
    /** @deprecated Use showClose. */
    closable?: MaybeRef<boolean>;
    /** @deprecated Use closeOnClickModal. */
    maskClosable?: MaybeRef<boolean>;
    /** Maps to the component's class attribute. */
    customClass?: MaybeRef<string | string[] | Record<string, boolean>>;
    defaultData?: () => T;
    dataTransform?: (rawData: unknown) => T;
    onConfirm?: (data: T, context: DialogConfirmContext) => unknown | Promise<unknown>;
    onConfirmError?: (error: unknown) => void;
    onCancel?: (data: T) => void;
    onContinue?: (data: T) => void;
    onOpen?: (data: T) => void;
    onOpened?: (data: T) => void;
    onClose?: (data: T) => void;
    onClosed?: (data: T) => void;
    onBack?: (data: T) => void;
    onBeforeClose?: (data: T) => boolean | Promise<boolean>;
    onDataChange?: (data: T, key?: keyof T) => void;
    onFullscreenChange?: (fullscreen: boolean) => void;
}
export interface DialogState<T = Record<string, unknown>> {
    visible: boolean;
    loading: boolean;
    disabled: boolean;
    title: string;
    isFullscreen: boolean;
    data: T;
}
export declare function useDialog<T extends Record<string, any> = Record<string, any>>(options?: DialogOptions<T>): {
    state: {
        visible: boolean;
        loading: boolean;
        disabled: boolean;
        title: string;
        isFullscreen: boolean;
        data: import("vue").UnwrapRef<T>;
    };
    visible: Ref<boolean, boolean>;
    loading: Ref<boolean, boolean>;
    disabled: Ref<boolean, boolean>;
    isFullscreen: Ref<boolean, boolean>;
    isDirty: import("vue").ComputedRef<boolean>;
    dialogRef: import("vue").ShallowRef<ZxDialogExpose | undefined, ZxDialogExpose | undefined>;
    dialogProps: import("vue").ComputedRef<{
        ref: import("vue").ShallowRef<ZxDialogExpose | undefined, ZxDialogExpose | undefined>;
        modelValue: boolean;
        title: string;
        showClose: boolean;
        closeOnClickModal: boolean;
        class: string | string[] | Record<string, boolean> | undefined;
        okLoading: boolean;
        okDisabled: boolean;
        formModel: import("vue").UnwrapRef<T>;
        confirm: (context: DialogConfirmContext) => Promise<unknown>;
        handleBeforeCancel: (() => boolean | Promise<boolean>) | undefined;
    }>;
    dialogEvents: import("vue").ComputedRef<{
        'update:modelValue': (value: boolean) => void;
        'update:currentStep': (value: number) => void;
        cancel: () => void | undefined;
        continue: () => void | undefined;
        open: () => void | undefined;
        opened: () => void | undefined;
        close: () => void | undefined;
        closed: () => void;
        back: () => void | undefined;
        'confirm-error': (error: unknown) => void | undefined;
        'fullscreen-change': (value: boolean) => void;
    }>;
    open: (data?: Partial<T> | T, title?: string) => void;
    close: () => Promise<void>;
    updateField: <K extends keyof T>(key: K, value: T[K]) => void;
    updateData: (data: Partial<T>) => void;
    setData: (data: T) => void;
    setTitle: (title: string) => void;
    setLoading: (value: boolean) => void;
    setDisabled: (value: boolean) => void;
    resetData: () => void;
    updateOptions: (value: Partial<DialogOptions<T>>) => void;
    toggleFullscreen: () => void | undefined;
};
export type UseDialogReturn<T extends Record<string, any> = Record<string, any>> = ReturnType<typeof useDialog<T>>;
export {};
