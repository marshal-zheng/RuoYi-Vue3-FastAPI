export { default } from '../components/config-provider/index';
export * from '../components/config-provider/index';
export { ZxConfigPlugin } from './install';
export type { InstallOptions } from './install';
