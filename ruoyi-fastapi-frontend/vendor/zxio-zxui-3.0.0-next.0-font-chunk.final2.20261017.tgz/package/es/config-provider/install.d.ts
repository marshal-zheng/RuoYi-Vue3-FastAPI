import type { App } from 'vue';
export interface InstallOptions {
    size?: 'large' | 'default' | 'small';
    zIndex?: number;
    namespace?: string;
    locale?: any;
}
/** Shared by the complete plugin and configuration-only installation. */
export declare function installZxConfig(app: App, options?: InstallOptions): void;
/** Installs app configuration without globally registering UI components. */
export declare const ZxConfigPlugin: {
    install: typeof installZxConfig;
};
