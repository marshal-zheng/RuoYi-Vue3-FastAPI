export { default } from '../components/confirm-input/index';
export * from '../components/confirm-input/index';
