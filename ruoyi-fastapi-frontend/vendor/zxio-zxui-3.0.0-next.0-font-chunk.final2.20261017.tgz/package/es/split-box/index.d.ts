export { default } from '../components/split-box/index';
export * from '../components/split-box/index';
