export { default } from '../components/flex-view/index';
export * from '../components/flex-view/index';
