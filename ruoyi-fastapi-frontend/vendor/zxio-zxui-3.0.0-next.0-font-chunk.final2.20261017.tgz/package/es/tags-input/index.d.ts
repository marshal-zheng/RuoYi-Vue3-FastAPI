export { default } from '../components/tags-input/index';
export * from '../components/tags-input/index';
