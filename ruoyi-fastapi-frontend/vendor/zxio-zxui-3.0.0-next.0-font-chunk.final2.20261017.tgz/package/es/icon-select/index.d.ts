export { default } from '../components/icon-select/index';
export * from '../components/icon-select/index';
