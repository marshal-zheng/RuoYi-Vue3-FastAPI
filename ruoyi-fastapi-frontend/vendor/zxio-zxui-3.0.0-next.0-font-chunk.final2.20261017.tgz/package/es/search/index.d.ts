export { default } from '../components/search/index';
export * from '../components/search/index';
