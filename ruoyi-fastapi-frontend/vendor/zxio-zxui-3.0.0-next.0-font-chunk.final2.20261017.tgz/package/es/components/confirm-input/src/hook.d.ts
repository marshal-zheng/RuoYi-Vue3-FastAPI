import type { ThemeFeedback } from '../../theme-provider';
import type { ConfirmInputTranslator } from './locale';
export declare function useFormValidation(props: any, t: ConfirmInputTranslator): {
    form: {
        value: string;
    };
    localValid: import("vue").Ref<boolean, boolean>;
    rules: any;
    isMatch: () => Promise<any>;
    errorText: import("vue").ComputedRef<string>;
    normalizedPattern: import("vue").ComputedRef<any>;
};
export declare function useDialogState(props: any, emit: any): {
    visible: import("vue").Ref<any, any>;
    handleOpen: () => void;
    handleClose: () => void;
    handleCancel: () => void;
    markConfirmed: () => void;
};
export declare function useConfirmAction(props: any, emit: any, formValidation: any, dialogState: any, feedback: ThemeFeedback | null, t: ConfirmInputTranslator): {
    internalLoading: import("vue").Ref<boolean, boolean>;
    isLoading: import("vue").ComputedRef<any>;
    confirmDisabled: import("vue").ComputedRef<any>;
    tryConfirm: (formRef?: any) => Promise<any>;
};
export declare function useFormReset(form: any, formRef: any, inputRef: any, props: any): {
    resetForm: () => void;
    focusInput: () => void;
    handleDialogOpen: () => void;
};
export declare function useKeyboardEvents(): {
    handleEnterKey: (event: Event, confirmCallback: any) => void;
    handleEscapeKey: (event: KeyboardEvent, cancelCallback: any) => void;
};
export declare function useZxConfirmInput(props: any, emit: any, feedback: ThemeFeedback | null, t: ConfirmInputTranslator): {
    handleEnterKey: (event: Event, confirmCallback: any) => void;
    handleEscapeKey: (event: KeyboardEvent, cancelCallback: any) => void;
    resetForm: () => void;
    focusInput: () => void;
    handleDialogOpen: () => void;
    internalLoading: import("vue").Ref<boolean, boolean>;
    isLoading: import("vue").ComputedRef<any>;
    confirmDisabled: import("vue").ComputedRef<any>;
    tryConfirm: (formRef?: any) => Promise<any>;
    handleOpen: () => void;
    handleOpenAutoFocus: () => void;
    visible: import("vue").Ref<any, any>;
    handleClose: () => void;
    handleCancel: () => void;
    markConfirmed: () => void;
    form: {
        value: string;
    };
    localValid: import("vue").Ref<boolean, boolean>;
    rules: any;
    isMatch: () => Promise<any>;
    errorText: import("vue").ComputedRef<string>;
    normalizedPattern: import("vue").ComputedRef<any>;
    formRef: import("vue").Ref<null, null>;
    inputRef: import("vue").Ref<null, null>;
};
