import ConfirmInput from './src/confirm-input.vue';
import { type SFCWithInstall } from '@zxio/shared';
declare const Comp: SFCWithInstall<typeof ConfirmInput>;
export default Comp;
export declare const ZxConfirmInput: typeof Comp;
export * from './src/props';
export { createBoundConfirmInputFactory } from './src/service';
export type { BoundConfirmInputFactory, BoundConfirmInputHandle, BoundConfirmInputOptions, } from './src/service';
