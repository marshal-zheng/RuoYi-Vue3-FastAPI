import type { Action, ElMessageBoxOptions, MessageBoxInputData } from 'element-plus/es/components/message-box/index';
import type { ThemeAppHandle, ThemeFeedbackHandle, ThemeRuntimePort, ThemeRuntimeResult, ThemeScopeHandle } from './types';
import type { ZxMessageParams } from '../../message';
import type { ZxNotificationParams } from '../../notification';
export interface ThemeMessageBoxOptions extends Partial<ElMessageBoxOptions> {
    readonly onVanish?: () => void;
    /** Show the same header/footer separators as Dialog. */
    readonly divider?: boolean;
}
export interface ThemeFeedback {
    message(options: ZxMessageParams): Promise<ThemeRuntimeResult<ThemeFeedbackHandle>>;
    notification(options: ZxNotificationParams): Promise<ThemeRuntimeResult<ThemeFeedbackHandle>>;
    confirm(options: ThemeMessageBoxOptions): Promise<ThemeRuntimeResult<Action | MessageBoxInputData>>;
}
/** Native MessageBox channels supplied by the default UI feedback adapter. */
export interface ThemeMessageBoxFeedback extends ThemeFeedback {
    alert(options: ThemeMessageBoxOptions): Promise<ThemeRuntimeResult<Action | MessageBoxInputData>>;
    prompt(options: ThemeMessageBoxOptions): Promise<ThemeRuntimeResult<Action | MessageBoxInputData>>;
}
export declare function createThemeFeedback(runtime: ThemeRuntimePort, owner: ThemeAppHandle | ThemeScopeHandle, nextZIndex?: () => number): ThemeRuntimeResult<ThemeMessageBoxFeedback>;
export declare function useThemeFeedback(): ThemeRuntimeResult<ThemeMessageBoxFeedback>;
