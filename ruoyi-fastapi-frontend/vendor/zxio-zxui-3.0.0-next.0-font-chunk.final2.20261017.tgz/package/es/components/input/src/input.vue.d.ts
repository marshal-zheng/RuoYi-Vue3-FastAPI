import Core from './input-core.vue';
declare const Input: typeof Core;
export default Input;
