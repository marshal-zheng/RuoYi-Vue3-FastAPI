import { type SFCWithInstall } from '@zxio/shared';
import Timeline from './src/timeline.vue';
export declare const ZxTimeline: SFCWithInstall<typeof Timeline>;
export declare const ZxTimelineItem: SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly density: import("@zxio/shared").EpPropFinalized<StringConstructor, "default" | "compact" | "comfortable", unknown, undefined, boolean>;
    readonly dotColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly fillDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly hideDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly hideOpposite: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
    readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly lineInset: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly side: import("@zxio/shared").EpPropFinalized<StringConstructor, "end" | "start", unknown, undefined, boolean>;
    readonly height: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly maxHeight: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly maxWidth: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly minHeight: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly minWidth: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly width: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly elevation: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly rounded: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown, undefined, boolean>;
    readonly tag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
    readonly status: import("@zxio/shared").EpPropFinalized<StringConstructor, "success" | "error" | "wait" | "process", unknown, undefined, boolean>;
    readonly progress: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly lineStatus: import("@zxio/shared").EpPropFinalized<StringConstructor, "success" | "error" | "wait" | "process", unknown, undefined, boolean>;
    readonly lineProgress: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    readonly lineColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly processCursor: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly processLineColorOwner: import("@zxio/shared").EpPropFinalized<StringConstructor, "split" | "process", unknown, undefined, boolean>;
    readonly progressIndicator: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator) | (((new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator)) | null)[], unknown, unknown, undefined, boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    rootRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
    dotRef: import("vue").Ref<{
        dotEl: HTMLElement | null;
    } | null, {
        dotEl: HTMLElement | null;
    } | {
        dotEl: HTMLElement | null;
    } | null>;
    rootClasses: import("vue").ComputedRef<string[]>;
    itemRole: import("vue").ComputedRef<"listitem" | undefined>;
    rootStyles: import("vue").ComputedRef<Record<string, string>>;
    bodyStyles: import("vue").ComputedRef<{
        height: string | undefined;
        maxHeight: string | undefined;
        maxWidth: string | undefined;
        minHeight: string | undefined;
        minWidth: string | undefined;
        width: string | undefined;
    }>;
    showOppositeContainer: import("vue").ComputedRef<boolean>;
    showOppositeContent: import("vue").ComputedRef<boolean>;
    resolvedDotColor: import("vue").ComputedRef<string>;
    resolvedFillDot: import("vue").ComputedRef<boolean>;
    resolvedIconColor: import("vue").ComputedRef<string | undefined>;
    resolvedLineColor: import("vue").ComputedRef<string | undefined>;
    resolvedSize: import("vue").ComputedRef<import("./src/timeline").TimelineSize | undefined>;
    resolvedProcessCursor: import("vue").ComputedRef<boolean>;
    resolvedProgressIndicator: import("vue").ComputedRef<import("./src/hooks/use-timeline-progress-indicator-config.js").TimelineProgressIndicatorResolvedOptions>;
    progressIndicatorAnchorState: import("vue").ComputedRef<import("./src/hooks/use-timeline-progress-indicator-anchor.js").TimelineProgressIndicatorAnchorState>;
    progressIndicatorRenderState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState>;
    edgeGeometry: import("vue").Ref<{
        length: number;
        offset: number;
        startRadius: number;
        endRadius: number;
    } | null, import("./src/hooks/use-timeline-edge-geometry.js").TimelineEdgeGeometry | {
        length: number;
        offset: number;
        startRadius: number;
        endRadius: number;
    } | null>;
    edgeMeasured: import("vue").ComputedRef<boolean>;
    tag: string;
    elevation: number;
    icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
    rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown> | undefined;
    hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly density: import("@zxio/shared").EpPropFinalized<StringConstructor, "default" | "compact" | "comfortable", unknown, undefined, boolean>;
    readonly dotColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly fillDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly hideDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly hideOpposite: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
    readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly lineInset: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly side: import("@zxio/shared").EpPropFinalized<StringConstructor, "end" | "start", unknown, undefined, boolean>;
    readonly height: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly maxHeight: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly maxWidth: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly minHeight: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly minWidth: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly width: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, undefined, boolean>;
    readonly elevation: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly rounded: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown, undefined, boolean>;
    readonly tag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "div", boolean>;
    readonly status: import("@zxio/shared").EpPropFinalized<StringConstructor, "success" | "error" | "wait" | "process", unknown, undefined, boolean>;
    readonly progress: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly lineStatus: import("@zxio/shared").EpPropFinalized<StringConstructor, "success" | "error" | "wait" | "process", unknown, undefined, boolean>;
    readonly lineProgress: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, undefined, boolean>;
    readonly lineColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly processCursor: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly processLineColorOwner: import("@zxio/shared").EpPropFinalized<StringConstructor, "split" | "process", unknown, undefined, boolean>;
    readonly progressIndicator: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator) | (((new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator)) | null)[], unknown, unknown, undefined, boolean>;
}>> & Readonly<{}>, {
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly tag: string;
    readonly progress: number;
    readonly size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown>;
    readonly status: import("@zxio/shared").EpPropMergeType<StringConstructor, "success" | "error" | "wait" | "process", unknown>;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly density: import("@zxio/shared").EpPropMergeType<StringConstructor, "default" | "compact" | "comfortable", unknown>;
    readonly rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown>;
    readonly maxHeight: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly maxWidth: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly minHeight: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly minWidth: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly side: import("@zxio/shared").EpPropMergeType<StringConstructor, "end" | "start", unknown>;
    readonly lineColor: string;
    readonly dotColor: string;
    readonly fillDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly hideOpposite: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconColor: string;
    readonly lineInset: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly processCursor: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly processLineColorOwner: import("@zxio/shared").EpPropMergeType<StringConstructor, "split" | "process", unknown>;
    readonly progressIndicator: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator) | (((new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator)) | null)[], unknown, unknown>;
    readonly hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly elevation: number;
    readonly lineStatus: import("@zxio/shared").EpPropMergeType<StringConstructor, "success" | "error" | "wait" | "process", unknown>;
    readonly lineProgress: number;
}, {}, {
    ZxTimelineDivider: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
        readonly dotColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly fillDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly hideDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
        readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly lineColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly rounded: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown, undefined, boolean>;
        readonly size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown, undefined, boolean>;
        readonly elevation: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    }>, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        dotEl: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
        rootClasses: import("vue").ComputedRef<string[]>;
        dotClasses: import("vue").ComputedRef<string[]>;
        dotStyles: import("vue").ComputedRef<Record<string, string>>;
        innerDotClasses: import("vue").ComputedRef<string[]>;
        innerDotStyles: import("vue").ComputedRef<Record<string, string>>;
        dotAnchorClasses: import("vue").ComputedRef<string[]>;
        beforeClasses: import("vue").ComputedRef<string[]>;
        afterClasses: import("vue").ComputedRef<string[]>;
        edgeClasses: import("vue").ComputedRef<string[]>;
        edgeTrackClasses: import("vue").ComputedRef<string[]>;
        lineStyles: import("vue").ComputedRef<{
            backgroundColor: string;
        } | undefined>;
        slotProps: import("vue").ComputedRef<{
            icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
            iconColor: string | undefined;
            size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown> | undefined;
        }>;
        iconSize: import("vue").ComputedRef<string | number | undefined>;
        edgeEnabled: import("vue").ComputedRef<boolean>;
        dotAnchorVisible: import("vue").ComputedRef<boolean>;
        edgeAnchorVisible: import("vue").ComputedRef<boolean>;
        progressIndicatorState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState | null>;
        hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
        iconColor: string | undefined;
        progressIndicatorRenderState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState> | null;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
        readonly dotColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly fillDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
        readonly hideDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
        readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly lineColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
        readonly rounded: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown, undefined, boolean>;
        readonly size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown, undefined, boolean>;
        readonly elevation: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    }>> & Readonly<{}>, {
        readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
        readonly size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown>;
        readonly rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown>;
        readonly lineColor: string;
        readonly dotColor: string;
        readonly fillDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconColor: string;
        readonly hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly elevation: number;
    }, {}, {
        ZxIcon: SFCWithInstall<__ZXUI_WithSlots<{
            new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
                readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
                readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
                readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
                readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
                readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            }>> & Readonly<{
                onClick?: ((ev: Event) => any) | undefined;
            }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
                click: (ev: Event) => any;
            }, import("vue").PublicProps, {
                readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
                readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
                readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
                readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
                readonly color: string;
                readonly hoverColor: string;
                readonly className: string;
            }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<import("vue").ExtractPropTypes<{
                readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
                readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
                readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
                readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
                readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
                readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
            }>> & Readonly<{
                onClick?: ((ev: Event) => any) | undefined;
            }>, {}, {}, {}, {}, {
                readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
                readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
                readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
                readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
                readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
                readonly color: string;
                readonly hoverColor: string;
                readonly className: string;
            }>;
            __isFragment?: never;
            __isTeleport?: never;
            __isSuspense?: never;
        } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
            readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
            readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        }>> & Readonly<{
            onClick?: ((ev: Event) => any) | undefined;
        }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
            click: (ev: Event) => any;
        }, string, {
            readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
            readonly color: string;
            readonly hoverColor: string;
            readonly className: string;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
            $slots: {
                popoverContent?: (props: {}) => any;
            };
        }>>;
        ZxTimelineAnchor: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
            target: {
                type: import("vue").PropType<import("./src/timeline-anchor.vue").TimelineAnchorTarget>;
                required: true;
            };
        }>, () => string | number | boolean | void | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | import("vue").VNodeArrayChildren | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            target: {
                type: import("vue").PropType<import("./src/timeline-anchor.vue").TimelineAnchorTarget>;
                required: true;
            };
        }>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
export declare const ZxTimelineDivider: SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly dotColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly fillDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly hideDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
    readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly lineColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly rounded: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown, undefined, boolean>;
    readonly elevation: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    dotEl: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    rootClasses: import("vue").ComputedRef<string[]>;
    dotClasses: import("vue").ComputedRef<string[]>;
    dotStyles: import("vue").ComputedRef<Record<string, string>>;
    innerDotClasses: import("vue").ComputedRef<string[]>;
    innerDotStyles: import("vue").ComputedRef<Record<string, string>>;
    dotAnchorClasses: import("vue").ComputedRef<string[]>;
    beforeClasses: import("vue").ComputedRef<string[]>;
    afterClasses: import("vue").ComputedRef<string[]>;
    edgeClasses: import("vue").ComputedRef<string[]>;
    edgeTrackClasses: import("vue").ComputedRef<string[]>;
    lineStyles: import("vue").ComputedRef<{
        backgroundColor: string;
    } | undefined>;
    slotProps: import("vue").ComputedRef<{
        icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
        iconColor: string | undefined;
        size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown> | undefined;
    }>;
    iconSize: import("vue").ComputedRef<string | number | undefined>;
    edgeEnabled: import("vue").ComputedRef<boolean>;
    dotAnchorVisible: import("vue").ComputedRef<boolean>;
    edgeAnchorVisible: import("vue").ComputedRef<boolean>;
    progressIndicatorState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState | null>;
    hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined;
    iconColor: string | undefined;
    progressIndicatorRenderState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState> | null;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly dotColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly fillDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly hideDot: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
    readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly lineColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly rounded: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown, undefined, boolean>;
    readonly elevation: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
}>> & Readonly<{}>, {
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown>;
    readonly rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown>;
    readonly lineColor: string;
    readonly dotColor: string;
    readonly fillDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconColor: string;
    readonly hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly elevation: number;
}, {}, {
    ZxIcon: SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
            readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        }>> & Readonly<{
            onClick?: ((ev: Event) => any) | undefined;
        }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
            click: (ev: Event) => any;
        }, import("vue").PublicProps, {
            readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
            readonly color: string;
            readonly hoverColor: string;
            readonly className: string;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
            readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        }>> & Readonly<{
            onClick?: ((ev: Event) => any) | undefined;
        }>, {}, {}, {}, {}, {
            readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
            readonly color: string;
            readonly hoverColor: string;
            readonly className: string;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
        readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
        readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
        readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    }>> & Readonly<{
        onClick?: ((ev: Event) => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
        click: (ev: Event) => any;
    }, string, {
        readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
        readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
        readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
        readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
        readonly color: string;
        readonly hoverColor: string;
        readonly className: string;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            popoverContent?: (props: {}) => any;
        };
    }>>;
    ZxTimelineAnchor: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
        target: {
            type: import("vue").PropType<import("./src/timeline-anchor.vue").TimelineAnchorTarget>;
            required: true;
        };
    }>, () => string | number | boolean | void | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }> | import("vue").VNodeArrayChildren | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
        target: {
            type: import("vue").PropType<import("./src/timeline-anchor.vue").TimelineAnchorTarget>;
            required: true;
        };
    }>> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
export declare const ZxTimelineCard: SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
    readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly iconSize: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly shadow: import("@zxio/shared").EpPropFinalized<StringConstructor, "hover" | "always" | "never", unknown, "hover", boolean>;
    readonly headerStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties) | (((new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties)) | null)[], unknown, unknown, undefined, boolean>;
    readonly headerTextColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly headerPadding: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly bodyPadding: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly footerPadding: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    showHeader: import("vue").ComputedRef<boolean>;
    cardClasses: import("vue").ComputedRef<string[]>;
    headerClasses: import("vue").ComputedRef<string[]>;
    computedHeaderStyles: import("vue").ComputedRef<import("vue").CSSProperties>;
    bodyStyles: import("vue").ComputedRef<import("vue").CSSProperties>;
    footerStyles: import("vue").ComputedRef<import("vue").CSSProperties>;
    cardVars: import("vue").ComputedRef<Record<string, string>>;
    shadow: import("vue").Ref<import("@zxio/shared").EpPropMergeType<StringConstructor, "hover" | "always" | "never", unknown>, import("@zxio/shared").EpPropMergeType<StringConstructor, "hover" | "always" | "never", unknown>>;
    icon: import("vue").Ref<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined, import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown> | undefined>;
    iconSize: import("vue").Ref<import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined, import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown> | undefined>;
    iconColor: import("vue").Ref<string | undefined, string | undefined>;
    title: import("vue").Ref<string, string>;
    subtitle: import("vue").Ref<string, string>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, undefined, boolean>;
    readonly iconColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly iconSize: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly shadow: import("@zxio/shared").EpPropFinalized<StringConstructor, "hover" | "always" | "never", unknown, "hover", boolean>;
    readonly headerStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties) | (((new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties)) | null)[], unknown, unknown, undefined, boolean>;
    readonly headerTextColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly headerPadding: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly bodyPadding: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly footerPadding: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
}>> & Readonly<{}>, {
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly title: string;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly shadow: import("@zxio/shared").EpPropMergeType<StringConstructor, "hover" | "always" | "never", unknown>;
    readonly iconSize: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly subtitle: string;
    readonly iconColor: string;
    readonly headerStyle: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties) | (((new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties)) | null)[], unknown, unknown>;
    readonly headerTextColor: string;
}, {}, {
    ElCard: import("element-plus/es/utils/index.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly header: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly footer: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly bodyStyle: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
            readonly headerClass: StringConstructor;
            readonly bodyClass: StringConstructor;
            readonly footerClass: StringConstructor;
            readonly shadow: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
        }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
            readonly footer: string;
            readonly header: string;
            readonly bodyStyle: import("vue").StyleValue;
            readonly shadow: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly header: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly footer: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly bodyStyle: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
            readonly headerClass: StringConstructor;
            readonly bodyClass: StringConstructor;
            readonly footerClass: StringConstructor;
            readonly shadow: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
        }>>, {}, {}, {}, {}, {
            readonly footer: string;
            readonly header: string;
            readonly bodyStyle: import("vue").StyleValue;
            readonly shadow: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly header: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly footer: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly bodyStyle: import("element-plus/es/utils/index.mjs").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
        readonly headerClass: StringConstructor;
        readonly bodyClass: StringConstructor;
        readonly footerClass: StringConstructor;
        readonly shadow: import("element-plus/es/utils/index.mjs").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
    }>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
        readonly footer: string;
        readonly header: string;
        readonly bodyStyle: import("vue").StyleValue;
        readonly shadow: import("element-plus/es/utils/index.mjs").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            header?: (props: {}) => any;
        } & {
            default?: (props: {}) => any;
        } & {
            footer?: (props: {}) => any;
        };
    }>>;
    ZxIcon: SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
            readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
            readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        }>> & Readonly<{
            onClick?: ((ev: Event) => any) | undefined;
        }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
            click: (ev: Event) => any;
        }, import("vue").PublicProps, {
            readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
            readonly color: string;
            readonly hoverColor: string;
            readonly className: string;
        }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("vue").ExtractPropTypes<{
            readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
            readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
            readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
            readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
        }>> & Readonly<{
            onClick?: ((ev: Event) => any) | undefined;
        }>, {}, {}, {}, {}, {
            readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
            readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
            readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
            readonly color: string;
            readonly hoverColor: string;
            readonly className: string;
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
        readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
        readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
        readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
        readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    }>> & Readonly<{
        onClick?: ((ev: Event) => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
        click: (ev: Event) => any;
    }, string, {
        readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
        readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
        readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
        readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
        readonly color: string;
        readonly hoverColor: string;
        readonly className: string;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            popoverContent?: (props: {}) => any;
        };
    }>>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
export default ZxTimeline;
export * from './src/timeline';
export type { ZxTimelineDividerInstance, ZxTimelineInstance, ZxTimelineItemInstance, ZxTimelineCardInstance, } from './src/instance';

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
