import Core from './dialog-core.vue';
declare const Dialog: typeof Core;
export default Dialog;
