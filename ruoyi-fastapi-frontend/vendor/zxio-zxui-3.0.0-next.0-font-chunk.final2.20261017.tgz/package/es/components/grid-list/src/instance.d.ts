import type { DeepReadonly, VNode } from 'vue';
import type { GridListControlledState, GridListDisplayState, GridListState, GridListStateSnapshot } from './props';
import type { GridListLoadOptions } from './use-grid-request';
export type ZxGridListInstance = {
    readonly mode: 'request' | 'controlled';
    loadData: (params?: Record<string, unknown>, options?: GridListLoadOptions) => Promise<void> | undefined;
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    state: DeepReadonly<GridListDisplayState>;
    updateState: (key: string, value: unknown) => void;
    updateMultiState: (state: Partial<GridListState>) => void;
    clearTableSelection: () => void;
    getStateSnapshot: () => GridListStateSnapshot;
    renderTableEmpty: () => VNode;
};
/** External state owns freshness; refresh only emits a synchronous intent. */
export type ZxGridListControlledInstance<Row = any> = Pick<ZxGridListInstance, 'clearTableSelection' | 'renderTableEmpty'> & {
    readonly mode: 'controlled';
    readonly state: DeepReadonly<GridListControlledState<Row>>;
    refresh: () => void;
};
