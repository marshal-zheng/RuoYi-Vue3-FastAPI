import { type SFCWithInstall } from '@zxio/shared';
import { zxGridListEmits, zxGridListProps } from './src/props';
import type { SFCWithSlots } from '../_shared/component-slots';
import type { GridListSlots } from './src/slots';
import type { ZxGridListInstance } from './src/instance';
import type { GridListPublicProps } from './src/props';
type Component = SFCWithSlots<typeof zxGridListProps, typeof zxGridListEmits, GridListSlots, ZxGridListInstance>;
type OriginalInstance = InstanceType<Component>;
type PublicComponent = Omit<Component, 'props'> & {
    new (): Omit<OriginalInstance, '$props' | '$slots' | '$emit'> & ZxGridListInstance & {
        $props: Omit<OriginalInstance['$props'], keyof GridListPublicProps> & GridListPublicProps;
        $slots: GridListSlots;
        $emit: OriginalInstance['$emit'];
    };
};
export declare const ZxGridList: SFCWithInstall<PublicComponent>;
export default ZxGridList;
export * from './src/props';
export type { ZxGridListInstance, ZxGridListControlledInstance, } from './src/instance';
export type { GridListSlots, GridListFormSlot, GridListTableSlot, GridListControlledFormSlot, GridListControlledTableSlot, } from './src/slots';
