declare var __VLS_14: {}, __VLS_19: {}, __VLS_21: {}, __VLS_32: {}, __VLS_37: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_14) => any;
} & {
    loading?: (props: typeof __VLS_19) => any;
} & {
    'tooltip-content'?: (props: typeof __VLS_21) => any;
} & {
    default?: (props: typeof __VLS_32) => any;
} & {
    loading?: (props: typeof __VLS_37) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    success: () => void;
    error: (error: Error) => void;
    startLoading: () => void;
    endLoading: () => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onSuccess?: (() => any) | undefined;
    onError?: ((error: Error) => any) | undefined;
    onStartLoading?: (() => any) | undefined;
    onEndLoading?: (() => any) | undefined;
}>, {
    readonly debounce: number;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
