import { G as f } from "./use-text-editor-command-keybindings-DEFth4pA.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-link-DCF3o7WR.mjs.map
